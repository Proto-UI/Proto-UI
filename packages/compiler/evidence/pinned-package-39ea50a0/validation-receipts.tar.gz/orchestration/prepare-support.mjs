import assert from 'node:assert/strict';
import { cpSync, existsSync, mkdirSync, readFileSync, realpathSync, readdirSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import path from 'node:path';

const [sourceRoot, destination] = process.argv.slice(2);
assert.ok(sourceRoot && destination && process.argv.length === 4);
assert.ok(!existsSync(destination), 'Support snapshot must be fresh');
mkdirSync(destination, { recursive: true });
const json = file => JSON.parse(readFileSync(file, 'utf8'));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
for (const name of ['core', 'types']) {
  cpSync(path.join(sourceRoot, 'packages', name, 'src'), path.join(destination, 'packages', name, 'src'), { recursive: true, dereference: true });
}
mkdirSync(path.join(destination, 'packages/compiler'), { recursive: true });
cpSync(path.join(sourceRoot, 'packages/compiler/package.json'), path.join(destination, 'packages/compiler/package.json'));
const packages = new Map();
function copyPackage(name, from) {
  const require = createRequire(from);
  let directory = path.dirname(realpathSync(require.resolve(name)));
  while (!existsSync(path.join(directory, 'package.json')) || json(path.join(directory, 'package.json')).name !== name) {
    const parent = path.dirname(directory);
    assert.notEqual(parent, directory, 'Could not find package: ' + name);
    directory = parent;
  }
  const manifest = json(path.join(directory, 'package.json'));
  if (packages.has(name)) {
    assert.equal(packages.get(name).version, manifest.version);
    return;
  }
  packages.set(name, { version: manifest.version, source: directory });
  cpSync(directory, path.join(destination, 'node_modules', name), { recursive: true, dereference: true, filter: file => path.basename(file) !== 'node_modules' });
  for (const dependency of Object.keys(manifest.dependencies ?? {})) copyPackage(dependency, path.join(directory, 'package.json'));
}
for (const name of ['react', 'react-dom']) copyPackage(name, path.join(sourceRoot, 'packages/compiler/package.json'));
const files = [];
function visit(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const file = path.join(directory, entry.name);
    if (entry.isDirectory()) visit(file);
    else {
      assert.ok(entry.isFile(), 'Snapshot contains a non-regular file: ' + file);
      const bytes = readFileSync(file);
      files.push({ path: path.relative(destination, file), bytes: bytes.length, sha256: sha(bytes) });
    }
  }
}
visit(destination);
files.sort((a, b) => a.path.localeCompare(b.path));
const report = { scope: 'Copied candidate authoring SDK and independently copied installed React package closure. No compiler/native source checkout is included.', sourceRoot, destination, packages: Object.fromEntries(packages), files };
writeFileSync(path.join(destination, 'snapshot.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ destination, packageVersions: Object.fromEntries([...packages].map(([k,v]) => [k,v.version])), fileCount: files.length, sha256: sha(JSON.stringify(files)) }));
