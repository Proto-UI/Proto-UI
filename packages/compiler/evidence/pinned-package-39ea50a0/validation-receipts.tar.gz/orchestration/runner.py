#!/usr/bin/env python3
"""Validate one explicitly supplied clean candidate; never changes tracked files."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import signal
import subprocess
import sys
import tarfile
import tempfile
import time
import traceback

DEFAULT_ROOT = '/home/ezra/.t3/worktrees/proto-ui/compiler-ast-pipeline-1809-20261125'
OLD_PINS = {'59c18246275c9a5ed0ad313c6da2627956930597', '28e9e3dd514df8b4f1b23e416d1c0ad3c0cc2e96'}
CONSUMERS = [
    {'name': 'shenko', 'root': '/tank/shared/projects/shenko/shenko', 'target': 'react'},
    {'name': 'verdant', 'root': '/tank/shared/projects/opengreendam/verdant-plugin-suite-20261122', 'target': 'gpui'},
]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read_json(file):
    return json.loads(Path(file).read_text())

def atomic_json(file, value):
    file = Path(file)
    pending = file.with_suffix(file.suffix + '.pending')
    pending.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
    pending.replace(file)

def git(root, *args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()

def identity(root):
    return {'revision': git(root, 'rev-parse', 'HEAD'), 'tree': git(root, 'rev-parse', 'HEAD^{tree}'), 'status': git(root, 'status', '--porcelain', '--untracked-files=normal')}

def file_receipt(file, base=None):
    file = Path(file)
    data = file.read_bytes()
    return {'path': str(file.relative_to(base) if base else file), 'bytes': len(data), 'sha256': sha(data)}

def source_snapshot(root):
    names = subprocess.check_output(['git', 'ls-files', '-z', '--', 'packages/compiler', 'packages/core/src', 'packages/types/src', 'scripts/compiler', 'scripts/ci/compiler-library-inventory.mjs', 'package.json', 'pnpm-lock.yaml'], cwd=root).decode().split('\0')
    rows = [file_receipt(Path(root, name), Path(root)) for name in names if name]
    return sorted(rows, key=lambda row: row['path'])

def verify_package(package, revision):
    metadata = read_json(package / 'compiler-build.json')
    assert metadata['schema'] == 'proto-ui.compiler-package.v3'
    assert metadata['revision'] == revision
    rows = []
    for item in metadata['files']:
        file = package / item['path']
        assert file.is_file() and not file.is_symlink(), str(file)
        assert file.resolve().is_relative_to(package.resolve()), str(file)
        actual = file_receipt(file, package)
        assert actual == {'path': item['path'], 'bytes': item['bytes'], 'sha256': item['sha256']}, item['path']
        rows.append(actual)
    rows.append(file_receipt(package / 'compiler-build.json', package))
    return sorted(rows, key=lambda row: row['path'])

def probe_consumer(item):
    root = Path(item['root'])
    result = {**item, **identity(root)}
    names = subprocess.check_output(['git', 'ls-files', '-z', '--', '*.proto.ts'], cwd=root).decode().split('\0')
    result['entries'] = [file_receipt(root / name, root) for name in names if name]
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--revision', required=True)
    parser.add_argument('--worktree', default=DEFAULT_ROOT)
    parser.add_argument('--report-directory')
    args = parser.parse_args()
    revision = args.revision
    assert re.fullmatch('[0-9a-f]{40}', revision), 'Full exact SHA is required'
    assert revision not in OLD_PINS, 'This run is reserved for the new continuation candidate, not historical pins'
    root = Path(args.worktree).resolve()
    before = identity(root)
    assert before['revision'] == revision and before['status'] == '', 'Candidate must be the clean checked-out HEAD'
    output = Path(args.report_directory).resolve() if args.report_directory else root / '.cache/compiler-deliveries' / revision / 'exact-package'
    assert output.is_relative_to(root / '.cache'), 'Receipts must remain in ignored worktree cache'
    ignored = subprocess.run(['git', 'check-ignore', '--quiet', '--', str(output)], cwd=root)
    assert ignored.returncode == 0, 'Receipt directory must be ignored'
    output.mkdir(parents=True, exist_ok=False)
    scripts = Path(__file__).resolve().parent
    for name in ['runner.py', 'prepare-support.mjs', 'consumer-sdk-admission.mjs']:
        shutil.copy2(scripts / name, output / name)
    started = time.time()
    work = Path(tempfile.mkdtemp(prefix='pui-exact-' + revision[:8] + '-'))
    report = {
        'schema': 'proto-ui.exact-candidate-package-verification.v1',
        'revision': revision, 'worktree': str(root), 'receiptDirectory': str(output),
        'work': str(work), 'startedAtEpoch': started, 'sourceBefore': before,
        'steps': [], 'errors': [], 'consumerAdmissions': [],
        'packageVerificationPassed': False, 'applicationMigrationVerified': False,
        'status': 'running',
        'scope': 'Exact candidate package build, relocation, cold native builders, real emitted artifact execution, CLI safety, bounded library worker admission, and unchanged real consumer source admission. Consumer checkout source errors and SDK-bound admission remain separate; no full application migration is claimed.',
    }
    atomic_json(output / 'summary.json', report)
    snapshots = source_snapshot(root)
    atomic_json(output / 'candidate-input-hashes.json', snapshots)
    consumers_before = [probe_consumer(item) for item in CONSUMERS]
    atomic_json(output / 'consumers-before.json', consumers_before)

    def save():
        atomic_json(output / 'summary.json', report)

    def run(name, argv, cwd=None, env=None, timeout=600, required=True):
        index = len(report['steps']) + 1
        prefix = f'{index:02d}-{name}'
        stdout = output / (prefix + '.stdout.log')
        stderr = output / (prefix + '.stderr.log')
        cwd = Path(cwd or root)
        supplied_env = dict(env or {})
        supplied_env.update({'NODE_OPTIONS': '', 'NODE_PATH': ''})
        step = {'name': name, 'argv': [str(a) for a in argv], 'cwd': str(cwd), 'environmentOverrides': supplied_env, 'timeoutSeconds': timeout, 'requiredPackageGate': required, 'stdout': stdout.name, 'stderr': stderr.name, 'startedAtEpoch': time.time()}
        report['steps'].append(step)
        save()
        print('START', name, flush=True)
        t0 = time.time()
        timed_out = False
        with stdout.open('wb') as out, stderr.open('wb') as err:
            # A login shell selects the workstation's declared Node 24 toolchain.
            process = subprocess.Popen(['bash', '-lc', 'exec ' + shlex.join([str(a) for a in argv])], cwd=cwd, env={**os.environ, **supplied_env}, stdout=out, stderr=err, start_new_session=True)
            try:
                code = process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    code = process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    code = process.wait()
        step.update({'exitCode': code, 'timedOut': timed_out, 'seconds': round(time.time() - t0, 3), 'stdoutReceipt': file_receipt(stdout, output), 'stderrReceipt': file_receipt(stderr, output)})
        atomic_json(output / (prefix + '.exit.json'), step)
        save()
        print('END', name, 'exit', code, flush=True)
        return code

    def require_run(name, argv, **kwargs):
        code = run(name, argv, **kwargs)
        assert code == 0, name + ' failed; original output retained'

    try:
        require_run('toolchain', ['node', '-p', 'JSON.stringify({node:process.version,execPath:process.execPath})'])
        node_info = json.loads((output / report['steps'][-1]['stdout']).read_text())
        assert node_info['node'].startswith('v24.'), node_info
        built = work / 'built-package'
        require_run('build-pinned', ['node', '--import', 'tsx', root / 'scripts/compiler/build-pinned.ts', '--revision', revision, '--output', built])
        initial_package = verify_package(built, revision)
        atomic_json(output / 'package-before-install.json', initial_package)
        require_run('npm-ci', ['npm', 'ci', '--ignore-scripts', '--no-audit', '--no-fund'], cwd=built)
        assert verify_package(built, revision) == initial_package, 'Installation changed packaged output bytes'
        package = work / 'relocated' / 'compiler'
        package.parent.mkdir()
        built.rename(package)
        assert not built.exists()
        assert verify_package(package, revision) == initial_package
        atomic_json(output / 'package-relocation.json', {'from': str(built), 'to': str(package), 'originalAbsent': True, 'filesUnchanged': True, 'files': initial_package})
        report['package'] = str(package)
        save()
        require_run('build-info', ['node', package / 'cli.js', '--build-info'], cwd=work)
        require_run('cli-info', ['node', package / 'cli.js', 'info', '--json'], cwd=work)
        support = work / 'authoring-support'
        require_run('copy-authoring-support', ['node', output / 'prepare-support.mjs', root, support])
        shutil.copy2(support / 'snapshot.json', output / 'authoring-support-snapshot.json')
        cold = work / 'cold-native-cache'
        cold.mkdir()
        assert not list(cold.iterdir())
        atomic_json(output / 'cold-cache-before.json', {'TMPDIR': str(cold), 'entries': []})
        require_run('pinned-ast', ['node', root / 'scripts/compiler/pinned-ast-smoke.mjs', '--compiler', package / 'index.js', '--source-root', support, '--llvm', '--gpui'], cwd=work, env={'TMPDIR': str(cold)})
        ast_summaries = list(cold.glob('proto-pinned-ast-consumer-*/summary.json'))
        assert len(ast_summaries) == 1
        ast_summary = read_json(ast_summaries[0])
        assert ast_summary['ok'] is True and ast_summary['revision'] == revision
        report['pinnedAst'] = {'path': str(ast_summaries[0]), 'checks': ast_summary['checks'], 'receipt': file_receipt(ast_summaries[0])}
        cli_temp = work / 'cli-temp'
        cli_temp.mkdir()
        require_run('pinned-cli', ['node', root / 'scripts/compiler/pinned-cli-smoke.mjs'], env={'NATIVE_CONSUMER_COMPILER': str(package / 'index.js'), 'TMPDIR': str(cli_temp)})
        cli_summaries = list(cli_temp.glob('proto-pinned-cli-ast-*/summary.json'))
        assert len(cli_summaries) == 1 and read_json(cli_summaries[0])['ok'] is True
        report['pinnedCli'] = {'path': str(cli_summaries[0]), 'receipt': file_receipt(cli_summaries[0]), 'checks': read_json(cli_summaries[0])['checks']}
        library = work / 'library-text-button'
        require_run('library-coordinator', ['node', '--import', 'tsx', root / 'scripts/compiler/library-profile-inventory.mjs', '--compiler', package / 'index.js', '--profiles', 'react,gpui', '--entry', 'packages/prototypes/base/src/text/root.proto.ts', '--entry', 'packages/prototypes/base/src/button/button.proto.ts', '--output', library], timeout=600)
        library_report = read_json(library / 'report.json')
        assert library_report['selectedComplete'] is True
        selected = [row for row in library_report['rows'] if row['entry'] in ['packages/prototypes/base/src/text/root.proto.ts', 'packages/prototypes/base/src/button/button.proto.ts'] and row['profile'] in ['react', 'gpui']]
        assert len(selected) == 4
        for row in selected:
            assert row['status'] == ('PASS' if '/text/' in row['entry'] else 'UNSUPPORTED'), row
        report['libraryCoordinator'] = {'path': str(library / 'report.json'), 'counts': library_report['counts'], 'selectedComplete': True, 'admissionCoverageComplete': library_report['admissionCoverageComplete'], 'selectedRows': selected, 'scope': 'Only Text and Button x React and GPUI workers executed. All other source/target rows remain visible and untested; native execution count is zero.'}
        save()
        for item in CONSUMERS:
            name = item['name']
            raw_output = output / (name + '-untouched-checkout.json')
            raw_code = run(name + '-untouched-checkout', ['node', root / 'scripts/compiler/consumer-project-inventory.mjs', '--compiler', package / 'index.js', '--consumer-root', item['root'], '--name', name, '--target', item['target'], '--out', raw_output], required=False)
            raw_report = read_json(raw_output)
            assert raw_report['compilerBuild']['revision'] == revision
            assert raw_report['applicationMigrationVerified'] is False
            assert raw_report['executionVerifiedPrototypes'] == 0
            config = output / (name + '-candidate-sdk.tsconfig.json')
            atomic_json(config, {'compilerOptions': {'target': 'ES2022', 'module': 'ESNext', 'moduleResolution': 'Bundler', 'strict': True, 'skipLibCheck': True, 'baseUrl': str(support), 'paths': {'@proto.ui/core': [str(support / 'packages/core/src/index.ts')], '@proto.ui/types': [str(support / 'packages/types/src/index.ts')]}}})
            sdk_output = output / (name + '-candidate-sdk-admission.json')
            sdk_code = run(name + '-candidate-sdk-admission', ['node', output / 'consumer-sdk-admission.mjs', '--compiler', package / 'index.js', '--consumer-root', item['root'], '--name', name, '--target', item['target'], '--tsconfig', config, '--sdk-root', support, '--revision', revision, '--out', sdk_output], required=False)
            sdk_report = read_json(sdk_output)
            assert sdk_report['compilerBuild']['revision'] == revision
            assert sdk_report['applicationMigrationVerified'] is False
            assert sdk_report['executionVerifiedPrototypes'] == 0
            report['consumerAdmissions'].append({'name': name, 'target': item['target'], 'untouchedCheckout': {'exitCode': raw_code, 'report': raw_output.name, 'totals': raw_report['result'].get('value', {}).get('totals'), 'compilerFailures': len(raw_report['compilerFailures'])}, 'candidateSdk': {'exitCode': sdk_code, 'report': sdk_output.name, 'totals': sdk_report['result'].get('value', {}).get('totals'), 'compilerFailures': len(sdk_report['compilerFailures'])}, 'applicationMigrationVerified': False})
            save()
        final_package = verify_package(package, revision)
        assert final_package == initial_package
        atomic_json(output / 'package-after-execution.json', final_package)
        consumers_after = [probe_consumer(item) for item in CONSUMERS]
        atomic_json(output / 'consumers-after.json', consumers_after)
        assert consumers_after == consumers_before, 'Real consumer checkout or source changed'
        assert identity(root) == before and source_snapshot(root) == snapshots, 'Candidate changed during validation'
        report['sourceAfter'] = identity(root)
        report['packageVerificationPassed'] = True
        report['status'] = 'completed-with-consumer-admission-failures' if any(x['untouchedCheckout']['exitCode'] or x['candidateSdk']['exitCode'] for x in report['consumerAdmissions']) else 'completed'
        # Package archive excludes npm-installed dependencies and contains exact recorded bytes.
        archive = output / ('proto-ui-compiler-' + revision[:8] + '.tar.gz')
        with tarfile.open(archive, 'x:gz') as tar:
            for file in initial_package:
                tar.add(package / file['path'], arcname='compiler/' + file['path'], recursive=False)
        report['packageArchive'] = file_receipt(archive, output)
        # Preserve nested raw receipts and generated artifacts without bulky dependencies/cache binaries.
        evidence = output / 'execution-receipts.tar.gz'
        with tarfile.open(evidence, 'x:gz') as tar:
            for base in [cold, cli_temp, library]:
                for file in sorted(base.rglob('*')):
                    if not file.is_file() or file.is_symlink():
                        continue
                    relative = file.relative_to(work)
                    if 'node_modules' in relative.parts or 'target' in relative.parts:
                        continue
                    if file.suffix not in {'.json', '.log', '.txt', '.ts', '.tsx', '.mjs', '.rs', '.toml', '.ll', '.wasm', '.lock', '.map'}:
                        continue
                    tar.add(file, arcname=str(relative), recursive=False)
            for file in sorted(output.iterdir()):
                if file.is_file() and file.name not in ['summary.json'] and file.suffix != '.gz':
                    tar.add(file, arcname='orchestration/' + file.name, recursive=False)
        report['executionArchive'] = file_receipt(evidence, output)
    except Exception as error:
        report['errors'].append({'message': str(error), 'traceback': traceback.format_exc()})
        report['status'] = 'failed'
        (output / 'orchestrator-error.log').write_text(traceback.format_exc())
    finally:
        report['seconds'] = round(time.time() - started, 3)
        report['completedAtEpoch'] = time.time()
        save()
        print(json.dumps({'status': report['status'], 'packageVerificationPassed': report['packageVerificationPassed'], 'summary': str(output / 'summary.json'), 'sha256': sha((output / 'summary.json').read_bytes())}), flush=True)
    return 1 if report['status'] == 'failed' else 2 if report['status'] == 'completed-with-consumer-admission-failures' else 0

if __name__ == '__main__':
    raise SystemExit(main())
