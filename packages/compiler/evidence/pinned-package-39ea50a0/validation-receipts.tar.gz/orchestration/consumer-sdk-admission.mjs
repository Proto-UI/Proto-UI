import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const options = new Map();
for (let i = 2; i < process.argv.length; i += 2) {
  const key = process.argv[i], value = process.argv[i + 1];
  assert.ok(['--compiler', '--consumer-root', '--name', '--target', '--tsconfig', '--sdk-root', '--revision', '--out'].includes(key) && value, 'Invalid argument: ' + key);
  assert.ok(!options.has(key), 'Duplicate argument: ' + key);
  options.set(key, value);
}
for (const key of ['--compiler', '--consumer-root', '--name', '--target', '--tsconfig', '--sdk-root', '--revision', '--out']) assert.ok(options.has(key), 'Missing ' + key);
const entry = path.resolve(options.get('--compiler'));
const installation = path.dirname(entry);
const root = path.resolve(options.get('--consumer-root'));
const config = path.resolve(options.get('--tsconfig'));
const sdkRoot = path.resolve(options.get('--sdk-root'));
const output = path.resolve(options.get('--out'));
const revision = options.get('--revision');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const git = (...args) => execFileSync('git', args, { cwd: root, encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 });
const identity = () => ({ revision: git('rev-parse', 'HEAD').trim(), status: git('status', '--porcelain') });
const metadata = JSON.parse(readFileSync(path.join(installation, 'compiler-build.json'), 'utf8'));
assert.equal(metadata.schema, 'proto-ui.compiler-package.v3');
assert.equal(metadata.revision, revision);
const verifyPackage = () => {
  for (const file of metadata.files) {
    const bytes = readFileSync(path.join(installation, file.path));
    assert.equal(bytes.length, file.bytes);
    assert.equal(hash(bytes), file.sha256);
  }
};
verifyPackage();
const before = identity();
const entries = git('ls-files', '-z', '--', '*.proto.ts').split('\0').filter(Boolean);
assert.ok(entries.length > 0, 'No real authored source in consumer');
const sources = entries.map(file => ({ path: file, sha256: hash(readFileSync(path.join(root, file))) }));
const api = await import(pathToFileURL(entry).href);
assert.ok(api.COMPONENT_TARGETS.includes(options.get('--target')));
const compiler = api.createCompiler({ rootDir: root, tsconfigPath: config });
const program = compiler.session.ensureFiles(entries);
const inputs = program.getSourceFiles().map(file => ({ path: path.resolve(file.fileName), sha256: hash(file.text), bytes: Buffer.byteLength(file.text), declaration: file.isDeclarationFile })).sort((a,b) => a.path.localeCompare(b.path));
const result = compiler.inventoryProject(entries, { target: options.get('--target') });
const explicitlyUnsupported = diagnostic => diagnostic.category === 'unsupported-input' || ['PUI_REACT_UNSUPPORTED', 'PUI_GPUI_UNSUPPORTED', 'PUI_KERNEL_UNSUPPORTED', 'PUI_FE002'].includes(diagnostic.code);
const compilerFailures = result.ok ? result.value.files.filter(file => {
  if (file.status === 'emitted' || file.status === 'hook-analysis') return false;
  const errors = file.diagnostics.filter(diagnostic => !['info', 'warning'].includes(diagnostic.severity));
  return errors.length === 0 || !errors.every(explicitlyUnsupported);
}).map(file => ({ sourceFile: file.sourceFile, diagnostics: file.diagnostics })) : [];
for (const file of inputs) assert.equal(hash(readFileSync(file.path)), file.sha256, 'Input changed: ' + file.path);
for (const file of sources) assert.equal(hash(readFileSync(path.join(root, file.path))), file.sha256);
assert.deepEqual(identity(), before);
verifyPackage();
const report = {
  schema: 'proto-ui.candidate-sdk-consumer-admission.v1',
  scope: 'Unmodified real consumer authored source, explicitly bound to the candidate authoring SDK through an external tsconfig. This is a separate compatibility/admission experiment, not the consumer checkout dependency setup, generated application migration, or execution.',
  consumer: { name: options.get('--name'), root, ...before, entries: sources },
  compilerBuild: metadata,
  authoringSdk: { revision, root: sdkRoot, tsconfig: config, tsconfigSha256: hash(readFileSync(config)), mappings: JSON.parse(readFileSync(config, 'utf8')).compilerOptions.paths },
  inputs,
  target: options.get('--target'),
  result,
  compilerFailures,
  executionVerifiedPrototypes: 0,
  applicationMigrationVerified: false,
};
writeFileSync(output, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ output, sha256: hash(readFileSync(output)), totals: result.ok ? result.value.totals : null, applicationMigrationVerified: false }));
if (!result.ok || result.value.totals.sourceErrorFiles > 0 || compilerFailures.length > 0) process.exitCode = 1;
