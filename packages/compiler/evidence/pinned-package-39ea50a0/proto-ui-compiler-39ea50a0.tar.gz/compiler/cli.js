#!/usr/bin/env node

// scripts/compiler/pinned-cli-entry.ts
import { readFileSync } from "node:fs";

// packages/compiler/src/cli.ts
import fs6 from "node:fs";
import path7 from "node:path";

// packages/compiler/src/compiler.ts
import fs4 from "node:fs";
import path5 from "node:path";

// packages/compiler/src/diagnostics.ts
function ok(value, diagnostics = []) {
  return { ok: true, value, diagnostics };
}
function err(diagnostics) {
  return { ok: false, diagnostics };
}
function diagnostic(code, category, message, span, severity = "error") {
  return span ? { code, severity, category, message, span } : { code, severity, category, message };
}
function formatDiagnostic(d) {
  const loc = d.span ? `${d.span.file}:${d.span.line}:${d.span.column} ` : "";
  return `${loc}${d.severity}[${d.code}/${d.category}]: ${d.message}`;
}
function formatDiagnostics(list) {
  return list.map(formatDiagnostic).join("\n");
}

// packages/compiler/src/frontend/program.ts
import fs from "node:fs";
import path from "node:path";
import ts from "typescript";
var TsProgramSession = class {
  rootDir;
  compilerOptions;
  baseHost;
  sourceCache = /* @__PURE__ */ new Map();
  virtualFiles = /* @__PURE__ */ new Map();
  program;
  rootNames = /* @__PURE__ */ new Set();
  constructor(options = {}) {
    this.rootDir = path.resolve(options.rootDir ?? process.cwd());
    this.compilerOptions = loadCompilerOptions(this.rootDir, options.tsconfigPath);
    this.baseHost = ts.createCompilerHost(this.compilerOptions, true);
  }
  createHost() {
    const { baseHost, sourceCache, virtualFiles } = this;
    const norm = (fileName) => path.resolve(fileName);
    return {
      ...baseHost,
      getCurrentDirectory: () => this.rootDir,
      fileExists: (fileName) => {
        const key = norm(fileName);
        if (virtualFiles.has(key)) return true;
        return baseHost.fileExists(fileName);
      },
      readFile: (fileName) => {
        const key = norm(fileName);
        const virtual = virtualFiles.get(key);
        if (virtual !== void 0) return virtual;
        return baseHost.readFile(fileName);
      },
      getSourceFile: (fileName, languageVersion, onError, shouldCreateNewSourceFile) => {
        const key = norm(fileName);
        const virtual = virtualFiles.get(key);
        if (virtual !== void 0) {
          return ts.createSourceFile(fileName, virtual, languageVersion, true);
        }
        if (!shouldCreateNewSourceFile) {
          const cached = sourceCache.get(key);
          if (cached) return cached;
        }
        const sf = baseHost.getSourceFile(
          fileName,
          languageVersion,
          onError,
          shouldCreateNewSourceFile
        );
        if (sf) sourceCache.set(key, sf);
        return sf;
      },
      writeFile: () => {
      }
    };
  }
  /** Ensure all given real files are present in the active ts.Program. */
  ensureFiles(files) {
    const resolved = files.map((f2) => path.resolve(this.rootDir, f2));
    let dirty = !this.program;
    for (const file of resolved) {
      if (!this.rootNames.has(file)) {
        this.rootNames.add(file);
        dirty = true;
      }
    }
    if (!dirty && this.program) return this.program;
    this.program = ts.createProgram(
      [...this.rootNames],
      this.compilerOptions,
      this.createHost(),
      this.program
    );
    return this.program;
  }
  /** Compile in-memory virtual source(s) reusing cached libs & workspace types. */
  createVirtualProgram(entryFile, sourceText, extraFiles = {}) {
    const entryPath = path.isAbsolute(entryFile) ? path.resolve(entryFile) : path.resolve(this.rootDir, entryFile);
    const prevKeys = [...this.virtualFiles.keys()];
    this.virtualFiles.clear();
    this.virtualFiles.set(entryPath, sourceText);
    const roots = [entryPath];
    for (const [rel, content] of Object.entries(extraFiles)) {
      const abs = path.isAbsolute(rel) ? path.resolve(rel) : path.resolve(this.rootDir, rel);
      this.virtualFiles.set(abs, content);
      roots.push(abs);
    }
    const program = ts.createProgram(roots, this.compilerOptions, this.createHost(), this.program);
    if (prevKeys.length === 0) {
      this.virtualFiles.clear();
    }
    return { program, entryPath };
  }
  invalidateFile(filePath) {
    const abs = path.resolve(this.rootDir, filePath);
    this.sourceCache.delete(abs);
    this.program = void 0;
  }
};
function loadCompilerOptions(rootDir, explicitTsconfig) {
  const configPath = explicitTsconfig ?? ts.findConfigFile(rootDir, (f2) => fs.existsSync(f2), "tsconfig.json");
  const fallback = {
    target: ts.ScriptTarget.ES2024,
    module: ts.ModuleKind.ESNext,
    moduleResolution: ts.ModuleResolutionKind.Bundler,
    jsx: ts.JsxEmit.ReactJSX,
    strict: true,
    noEmit: true,
    skipLibCheck: true,
    esModuleInterop: true
  };
  if (!configPath) return fallback;
  const read = ts.readConfigFile(configPath, (f2) => fs.readFileSync(f2, "utf8"));
  if (read.error) return fallback;
  const parsed = ts.parseJsonConfigFileContent(
    read.config,
    ts.sys,
    path.dirname(configPath),
    void 0,
    configPath
  );
  return {
    ...fallback,
    ...parsed.options,
    noEmit: true,
    skipLibCheck: true
  };
}

// packages/compiler/src/frontend/extract.ts
import ts9 from "typescript";

// packages/compiler/src/frontend/syntax.ts
import ts4 from "typescript";

// packages/compiler/src/frontend/constants.ts
import ts3 from "typescript";

// packages/compiler/src/frontend/bindings.ts
import ts2 from "typescript";
function hasBindingWrites(binding, checker) {
  const files = new Set(
    binding.declarations?.map((declaration) => declaration.getSourceFile()) ?? []
  );
  let written = false;
  const mentions = (node) => {
    if (ts2.isIdentifier(node)) return checker.getSymbolAtLocation(node) === binding;
    if (ts2.isPropertyAccessExpression(node) || ts2.isElementAccessExpression(node)) return false;
    return ts2.forEachChild(node, (child) => mentions(child) || void 0) === true;
  };
  const inspect = (node) => {
    if (written) return;
    if (ts2.isBinaryExpression(node) && node.operatorToken.kind >= ts2.SyntaxKind.FirstAssignment && node.operatorToken.kind <= ts2.SyntaxKind.LastAssignment && mentions(node.left))
      written = true;
    if ((ts2.isPrefixUnaryExpression(node) || ts2.isPostfixUnaryExpression(node)) && (node.operator === ts2.SyntaxKind.PlusPlusToken || node.operator === ts2.SyntaxKind.MinusMinusToken) && mentions(node.operand))
      written = true;
    ts2.forEachChild(node, inspect);
  };
  files.forEach(inspect);
  return written;
}
function isConstDeclaration(declaration) {
  return ts2.isVariableDeclarationList(declaration.parent) && !!(declaration.parent.flags & ts2.NodeFlags.Const);
}
function executionScope(node) {
  let parent = node.parent;
  while (parent && !ts2.isSourceFile(parent) && !ts2.isFunctionLike(parent)) parent = parent.parent;
  return parent ?? node.getSourceFile();
}
function atExecutionPoint(node, inherited = /* @__PURE__ */ new Map()) {
  const points = new Map(inherited);
  points.set(executionScope(node), node.getStart());
  return points;
}
var dependencyCache = /* @__PURE__ */ new WeakMap();
function valueDependencies(source, checker) {
  let cache = dependencyCache.get(checker);
  if (!cache) dependencyCache.set(checker, cache = /* @__PURE__ */ new Map());
  const cached = cache.get(source);
  if (cached) return cached;
  const result = /* @__PURE__ */ new Set();
  const visit = (file) => {
    for (const statement of file.statements) {
      if (!ts2.isImportDeclaration(statement) && !ts2.isExportDeclaration(statement) || !statement.moduleSpecifier || ts2.isExportDeclaration(statement) && statement.isTypeOnly || ts2.isImportDeclaration(statement) && statement.importClause?.isTypeOnly)
        continue;
      const bindings = ts2.isImportDeclaration(statement) ? statement.importClause?.namedBindings : statement.exportClause;
      if (bindings && (ts2.isNamedImports(bindings) || ts2.isNamedExports(bindings)) && bindings.elements.length > 0 && bindings.elements.every((element) => element.isTypeOnly) && !(ts2.isImportDeclaration(statement) && statement.importClause?.name))
        continue;
      const imported = checker.getSymbolAtLocation(statement.moduleSpecifier)?.declarations?.find(ts2.isSourceFile);
      if (!imported || imported.isDeclarationFile || result.has(imported)) continue;
      result.add(imported);
      visit(imported);
    }
  };
  visit(source);
  cache.set(source, result);
  return result;
}
function isBindingInitialized(declaration, points, checker) {
  if (ts2.isFunctionDeclaration(declaration)) return !!declaration.body;
  const owner = executionScope(declaration);
  const position = points.get(owner);
  if (position !== void 0) return declaration.end <= position;
  if (ts2.isSourceFile(owner)) {
    for (const active of points.keys()) {
      if (ts2.isSourceFile(active) && active !== owner && valueDependencies(owner, checker).has(active))
        return false;
    }
  }
  return true;
}

// packages/compiler/src/frontend/constants.ts
var unknown = { known: false };
function evaluateStaticScalar(expression, checker, bindings = /* @__PURE__ */ new Map(), initializationPoints = /* @__PURE__ */ new Map()) {
  let budget = 512;
  const active = /* @__PURE__ */ new Set();
  const known = (value) => ({ known: true, value });
  const symbol = (node) => {
    const value = checker.getSymbolAtLocation(node);
    return value && value.flags & ts3.SymbolFlags.Alias ? checker.getAliasedSymbol(value) : value;
  };
  const evaluate = (raw, scope, inheritedPoints) => {
    const points = atExecutionPoint(raw, inheritedPoints);
    if (--budget < 0) return unknown;
    if (ts3.isParenthesizedExpression(raw) || ts3.isAsExpression(raw) || ts3.isTypeAssertionExpression(raw) || ts3.isSatisfiesExpression(raw) || ts3.isNonNullExpression(raw))
      return evaluate(raw.expression, scope, points);
    if (ts3.isStringLiteral(raw) || ts3.isNoSubstitutionTemplateLiteral(raw)) return known(raw.text);
    if (ts3.isNumericLiteral(raw)) return known(Number(raw.text));
    if (raw.kind === ts3.SyntaxKind.TrueKeyword) return known(true);
    if (raw.kind === ts3.SyntaxKind.FalseKeyword) return known(false);
    if (raw.kind === ts3.SyntaxKind.NullKeyword) return known(null);
    if (ts3.isIdentifier(raw)) {
      const binding = symbol(raw);
      if (!binding) return unknown;
      if (scope.has(binding)) return known(scope.get(binding));
      const declaration = binding.valueDeclaration ?? binding.declarations?.[0];
      if (declaration && ts3.isVariableDeclaration(declaration) && declaration.initializer && ts3.isVariableDeclarationList(declaration.parent) && declaration.parent.flags & ts3.NodeFlags.Const && isBindingInitialized(declaration, points, checker) && !active.has(declaration)) {
        active.add(declaration);
        const result2 = evaluate(declaration.initializer, scope, points);
        active.delete(declaration);
        return result2;
      }
      return unknown;
    }
    if (ts3.isPrefixUnaryExpression(raw)) {
      const operand = evaluate(raw.operand, scope, points);
      if (!operand.known) return unknown;
      if (raw.operator === ts3.SyntaxKind.ExclamationToken) return known(!operand.value);
      if (typeof operand.value !== "number") return unknown;
      if (raw.operator === ts3.SyntaxKind.MinusToken) return known(-operand.value);
      if (raw.operator === ts3.SyntaxKind.PlusToken) return known(+operand.value);
      return unknown;
    }
    if (ts3.isConditionalExpression(raw)) {
      const condition = evaluate(raw.condition, scope, points);
      return condition.known ? evaluate(condition.value ? raw.whenTrue : raw.whenFalse, scope, points) : unknown;
    }
    if (ts3.isBinaryExpression(raw)) {
      const left = evaluate(raw.left, scope, points);
      if (!left.known) return unknown;
      const op = raw.operatorToken.kind;
      if (op === ts3.SyntaxKind.AmpersandAmpersandToken)
        return left.value ? evaluate(raw.right, scope, points) : left;
      if (op === ts3.SyntaxKind.BarBarToken)
        return left.value ? left : evaluate(raw.right, scope, points);
      if (op === ts3.SyntaxKind.QuestionQuestionToken)
        return left.value === null ? evaluate(raw.right, scope, points) : left;
      const right = evaluate(raw.right, scope, points);
      if (!right.known) return unknown;
      if (op === ts3.SyntaxKind.EqualsEqualsEqualsToken) return known(left.value === right.value);
      if (op === ts3.SyntaxKind.ExclamationEqualsEqualsToken)
        return known(left.value !== right.value);
      if (typeof left.value === "string" && typeof right.value === "string" && op === ts3.SyntaxKind.PlusToken) {
        return known(left.value + right.value);
      }
      if (typeof left.value !== "number" || typeof right.value !== "number") return unknown;
      switch (op) {
        case ts3.SyntaxKind.PlusToken:
          return known(left.value + right.value);
        case ts3.SyntaxKind.MinusToken:
          return known(left.value - right.value);
        case ts3.SyntaxKind.AsteriskToken:
          return known(left.value * right.value);
        case ts3.SyntaxKind.SlashToken:
          return known(left.value / right.value);
        case ts3.SyntaxKind.PercentToken:
          return known(left.value % right.value);
        case ts3.SyntaxKind.LessThanToken:
          return known(left.value < right.value);
        case ts3.SyntaxKind.LessThanEqualsToken:
          return known(left.value <= right.value);
        case ts3.SyntaxKind.GreaterThanToken:
          return known(left.value > right.value);
        case ts3.SyntaxKind.GreaterThanEqualsToken:
          return known(left.value >= right.value);
        default:
          return unknown;
      }
    }
    if (ts3.isCallExpression(raw) && ts3.isIdentifier(raw.expression)) {
      const binding = symbol(raw.expression);
      const declaration = binding?.valueDeclaration ?? binding?.declarations?.[0];
      if (!declaration || !isBindingInitialized(declaration, points, checker)) return unknown;
      const fn = declaration && ts3.isFunctionDeclaration(declaration) ? declaration : declaration && ts3.isVariableDeclaration(declaration) && isConstDeclaration(declaration) && declaration.initializer && (ts3.isArrowFunction(declaration.initializer) || ts3.isFunctionExpression(declaration.initializer)) ? declaration.initializer : void 0;
      if (!fn?.body || raw.arguments.length !== fn.parameters.length || active.has(fn))
        return unknown;
      if (!binding || hasBindingWrites(binding, checker)) return unknown;
      if (fn.modifiers?.some((m) => m.kind === ts3.SyntaxKind.AsyncKeyword) || fn.asteriskToken)
        return unknown;
      const local = new Map(scope);
      for (let i = 0; i < fn.parameters.length; i++) {
        const parameter = fn.parameters[i];
        if (!ts3.isIdentifier(parameter.name) || parameter.dotDotDotToken || parameter.initializer)
          return unknown;
        const parameterSymbol = symbol(parameter.name);
        const argument = evaluate(raw.arguments[i], scope, points);
        if (!parameterSymbol || !argument.known) return unknown;
        local.set(parameterSymbol, argument.value);
      }
      active.add(fn);
      const result2 = ts3.isBlock(fn.body) ? execute(fn.body.statements, local, points) : evaluate(fn.body, local, points);
      active.delete(fn);
      return result2;
    }
    return unknown;
  };
  const execute = (statements, outer, points) => {
    const local = new Map(outer);
    for (const stmt of statements) {
      if (--budget < 0) return unknown;
      if (ts3.isReturnStatement(stmt))
        return stmt.expression ? evaluate(stmt.expression, local, points) : unknown;
      if (ts3.isVariableStatement(stmt) && stmt.declarationList.flags & ts3.NodeFlags.Const) {
        for (const declaration of stmt.declarationList.declarations) {
          if (!ts3.isIdentifier(declaration.name) || !declaration.initializer) return unknown;
          const binding = symbol(declaration.name);
          const result2 = evaluate(declaration.initializer, local, points);
          if (!binding || !result2.known) return unknown;
          local.set(binding, result2.value);
        }
      } else if (ts3.isIfStatement(stmt)) {
        const condition = evaluate(stmt.expression, local, points);
        if (!condition.known) return unknown;
        const chosen = condition.value ? stmt.thenStatement : stmt.elseStatement;
        if (chosen) {
          const branch = execute(ts3.isBlock(chosen) ? chosen.statements : [chosen], local, points);
          if (branch.known) return branch;
          return unknown;
        }
      } else if (!ts3.isEmptyStatement(stmt)) return unknown;
    }
    return unknown;
  };
  const result = evaluate(expression, bindings, initializationPoints);
  return result.known ? result.value : void 0;
}

// packages/compiler/src/frontend/syntax.ts
function spanOf(node, sf) {
  const start = sf.getLineAndCharacterOfPosition(node.getStart(sf));
  const end = sf.getLineAndCharacterOfPosition(node.getEnd());
  return {
    file: sf.fileName,
    line: start.line + 1,
    column: start.character + 1,
    endLine: end.line + 1,
    endColumn: end.character + 1
  };
}
function sanitizeSym(name) {
  return name.replace(/[^A-Za-z0-9_]/g, "_").replace(/^(\d)/, "_$1");
}
function unwrapExpr(expr) {
  let cur = expr;
  while (ts4.isParenthesizedExpression(cur) || ts4.isAsExpression(cur) || ts4.isTypeAssertionExpression(cur) || ts4.isSatisfiesExpression(cur) || ts4.isNonNullExpression(cur)) {
    cur = cur.expression;
  }
  return cur;
}
function extractScalarLiteral(expr, checker) {
  return evaluateStaticScalar(expr, checker);
}
function isKnownUndefined(expr, checker) {
  const value = unwrapExpr(expr);
  return ts4.isIdentifier(value) && value.text === "undefined" && !checker.getSymbolAtLocation(value)?.valueDeclaration || ts4.isVoidExpression(value) && evaluateStaticScalar(value.expression, checker) !== void 0;
}
function resolveAliasedSymbol(checker, sym) {
  const visited = /* @__PURE__ */ new Set();
  while (sym && !visited.has(sym)) {
    visited.add(sym);
    if (sym.flags & ts4.SymbolFlags.Alias) {
      sym = checker.getAliasedSymbol(sym);
      continue;
    }
    const declaration = sym.valueDeclaration;
    if (declaration && ts4.isShorthandPropertyAssignment(declaration)) {
      const value = checker.getShorthandAssignmentValueSymbol(declaration);
      if (value && value !== sym) {
        sym = value;
        continue;
      }
    }
    return sym;
  }
  return void 0;
}
function resolveCallName(expr, checker, visited = /* @__PURE__ */ new Set(), initializationPoints = /* @__PURE__ */ new Map()) {
  const e = unwrapExpr(expr);
  const points = atExecutionPoint(e, initializationPoints);
  const sym = resolveAliasedSymbol(checker, checker.getSymbolAtLocation(e));
  if (sym) {
    if (visited.has(sym)) return void 0;
    visited.add(sym);
    const decl = sym.valueDeclaration ?? sym.declarations?.[0];
    if (decl && ts4.isVariableDeclaration(decl) && !isBindingInitialized(decl, points, checker))
      return void 0;
    if (decl && ts4.isVariableDeclaration(decl) && isConstDeclaration(decl) && decl.initializer && (ts4.isIdentifier(unwrapExpr(decl.initializer)) || ts4.isPropertyAccessExpression(unwrapExpr(decl.initializer)))) {
      return resolveCallName(decl.initializer, checker, visited, points);
    }
    return { name: sym.getName(), sourceFile: decl?.getSourceFile().fileName };
  }
  if (ts4.isIdentifier(e)) return { name: e.text };
  return void 0;
}
function findFactoryCall(expr, checker, factoryNames, visited = /* @__PURE__ */ new Set(), initializationPoints = /* @__PURE__ */ new Map()) {
  const e = unwrapExpr(expr);
  const points = atExecutionPoint(e, initializationPoints);
  if (visited.has(e)) return void 0;
  visited.add(e);
  if (ts4.isCallExpression(e)) {
    const resolved = resolveCallName(e.expression, checker, /* @__PURE__ */ new Set(), points);
    if (resolved && factoryNames.includes(resolved.name) && isCoreIntrinsic(resolved)) {
      return { call: e, factory: resolved.name };
    }
  }
  if (ts4.isIdentifier(e)) {
    const sym = resolveAliasedSymbol(checker, checker.getSymbolAtLocation(e));
    const decl = sym?.valueDeclaration ?? sym?.declarations?.[0];
    if (decl && ts4.isVariableDeclaration(decl) && isConstDeclaration(decl) && decl.initializer && isBindingInitialized(decl, points, checker)) {
      return findFactoryCall(decl.initializer, checker, factoryNames, visited, points);
    }
  }
  return void 0;
}
function isCoreIntrinsic(binding) {
  const file = binding.sourceFile?.replaceAll("\\", "/");
  return !!file && (file.includes("/packages/core/src/") || file.includes("/@proto.ui/core/"));
}
function resolveFunctionLike(expr, checker, initializationPoints = /* @__PURE__ */ new Map(), visited = /* @__PURE__ */ new Set()) {
  const e = unwrapExpr(expr);
  const points = atExecutionPoint(e, initializationPoints);
  if (visited.has(e)) return void 0;
  visited.add(e);
  if (ts4.isArrowFunction(e) || ts4.isFunctionExpression(e)) return e;
  if (ts4.isIdentifier(e)) {
    const sym = resolveAliasedSymbol(checker, checker.getSymbolAtLocation(e));
    const decl = sym?.valueDeclaration ?? sym?.declarations?.[0];
    if (!decl) return void 0;
    if (ts4.isFunctionDeclaration(decl))
      return sym && !hasBindingWrites(sym, checker) ? decl : void 0;
    if (ts4.isMethodDeclaration(decl)) return decl;
    if (ts4.isVariableDeclaration(decl) && isConstDeclaration(decl) && decl.initializer && isBindingInitialized(decl, points, checker)) {
      return resolveFunctionLike(decl.initializer, checker, points, visited);
    }
  }
  return void 0;
}
function isPrototypeType(expression, checker) {
  const visited = /* @__PURE__ */ new Set();
  const check = (type) => {
    if (visited.has(type)) return false;
    visited.add(type);
    const symbol = type.aliasSymbol ?? type.getSymbol();
    if (symbol?.getName() === "Prototype" && symbol.declarations?.some(
      (declaration) => isCoreIntrinsic({ sourceFile: declaration.getSourceFile().fileName })
    ))
      return true;
    if (type.isUnionOrIntersection()) return type.types.some(check);
    const setup = checker.getPropertyOfType(type, "setup");
    return !!setup?.declarations?.some(
      (declaration) => isCoreIntrinsic({ sourceFile: declaration.getSourceFile().fileName })
    );
  };
  return check(checker.getTypeAtLocation(expression));
}
function propAccessChain(expr) {
  const parts = [];
  let cur = unwrapExpr(expr);
  while (ts4.isPropertyAccessExpression(cur)) {
    parts.unshift(cur.name.text);
    cur = unwrapExpr(cur.expression);
  }
  if (ts4.isIdentifier(cur)) {
    parts.unshift(cur.text);
    return parts;
  }
  return void 0;
}
function extractObjectProperty(obj, name) {
  for (const prop2 of [...obj.properties].reverse()) {
    if (ts4.isPropertyAssignment(prop2)) {
      const key = ts4.isIdentifier(prop2.name) || ts4.isStringLiteral(prop2.name) ? prop2.name.text : void 0;
      if (key === name) return prop2.initializer;
    } else if (ts4.isShorthandPropertyAssignment(prop2) && prop2.name.text === name) {
      return prop2.name;
    } else if (ts4.isMethodDeclaration(prop2)) {
      const key = ts4.isIdentifier(prop2.name) || ts4.isStringLiteral(prop2.name) ? prop2.name.text : void 0;
      if (key === name) {
        return void 0;
      }
    }
  }
  return void 0;
}
function extractSetupFunction(obj, checker, initializationPoints = /* @__PURE__ */ new Map()) {
  for (const prop2 of [...obj.properties].reverse()) {
    if (ts4.isMethodDeclaration(prop2) && (ts4.isIdentifier(prop2.name) || ts4.isStringLiteral(prop2.name)) && prop2.name.text === "setup") {
      return prop2;
    }
    if (ts4.isPropertyAssignment(prop2) && (ts4.isIdentifier(prop2.name) || ts4.isStringLiteral(prop2.name)) && prop2.name.text === "setup") {
      return resolveFunctionLike(prop2.initializer, checker, initializationPoints);
    }
    if (ts4.isShorthandPropertyAssignment(prop2) && prop2.name.text === "setup") {
      return resolveFunctionLike(prop2.name, checker, initializationPoints);
    }
  }
  return void 0;
}
function resolveDefinitionObject(expression, checker, initializationPoints = /* @__PURE__ */ new Map()) {
  const value = unwrapExpr(expression);
  if (ts4.isObjectLiteralExpression(value)) return value;
  if (!ts4.isIdentifier(value)) return void 0;
  const binding = resolveAliasedSymbol(checker, checker.getSymbolAtLocation(value));
  const declaration = binding?.valueDeclaration;
  if (!declaration || !ts4.isVariableDeclaration(declaration) || !declaration.initializer || !ts4.isVariableDeclarationList(declaration.parent) || !(declaration.parent.flags & ts4.NodeFlags.Const) || !isBindingInitialized(declaration, atExecutionPoint(value, initializationPoints), checker))
    return void 0;
  const object = unwrapExpr(declaration.initializer);
  if (!ts4.isObjectLiteralExpression(object)) return void 0;
  let escaped = false;
  const inspect = (node) => {
    if (escaped) return;
    if (ts4.isIdentifier(node) && node !== declaration.name && resolveAliasedSymbol(checker, checker.getSymbolAtLocation(node)) === binding) {
      const parent = node.parent;
      const intrinsic = ts4.isCallExpression(parent) && parent.arguments.includes(node) ? resolveCallName(parent.expression, checker) : void 0;
      if (!intrinsic || !isCoreIntrinsic(intrinsic) || !["definePrototype", "defineAsHook", "defineHook"].includes(intrinsic.name))
        escaped = true;
    }
    ts4.forEachChild(node, inspect);
  };
  inspect(declaration.getSourceFile());
  return escaped ? void 0 : object;
}

// packages/compiler/src/frontend/scalars.ts
function propKindToSsaType(kind) {
  switch (kind) {
    case "boolean":
      return "i1";
    case "number":
      return "f64";
    case "string":
    case "enum":
      return "i32";
    // Interned string/enum ID in LLVM kernel ABI
    default:
      return "ptr";
  }
}
function stateKindToSsaType(kind) {
  switch (kind) {
    case "bool":
      return "i1";
    case "number.discrete":
    case "number.range":
      return "f64";
    case "string":
    case "enum":
      return "i32";
  }
}
function internString(table, value) {
  const existing = table.indexOf(value);
  if (existing >= 0) return existing;
  table.push(value);
  return table.length - 1;
}

// packages/compiler/src/frontend/rules.ts
import ts5 from "typescript";
function parseRuleCondition(expr, builderParam, stateVarToName, checker, constant = (expression) => extractScalarLiteral(expression, checker)) {
  const e = unwrapExpr(expr);
  if (!ts5.isCallExpression(e)) return void 0;
  const callee = unwrapExpr(e.expression);
  if (!ts5.isPropertyAccessExpression(callee)) return void 0;
  const method = callee.name.text;
  const recv = unwrapExpr(callee.expression);
  if (ts5.isIdentifier(recv) && recv.text === builderParam) {
    if (method === "t" && e.arguments.length === 0) return { kind: "true" };
    if (method === "f" && e.arguments.length === 0) return { kind: "false" };
    if (method === "not" && e.arguments.length === 1) {
      const inner = parseRuleCondition(
        e.arguments[0],
        builderParam,
        stateVarToName,
        checker,
        constant
      );
      return inner ? { kind: "not", expr: inner } : void 0;
    }
    if ((method === "all" || method === "any") && e.arguments.length > 0) {
      const exprs = [];
      for (const arg of e.arguments) {
        const sub = parseRuleCondition(arg, builderParam, stateVarToName, checker, constant);
        if (!sub) return void 0;
        exprs.push(sub);
      }
      return { kind: method, exprs };
    }
    return void 0;
  }
  if ((method === "eq" || method === "gte") && ts5.isCallExpression(recv) && e.arguments.length === 1) {
    const innerCallee = unwrapExpr(recv.expression);
    if (ts5.isPropertyAccessExpression(innerCallee) && ts5.isIdentifier(unwrapExpr(innerCallee.expression)) && unwrapExpr(innerCallee.expression).text === builderParam && recv.arguments.length === 1) {
      const src = innerCallee.name.text;
      if (src !== "prop" && src !== "state" && src !== "meta") return void 0;
      const rhs = constant(e.arguments[0]);
      if (rhs === void 0) return void 0;
      let key;
      if (src === "state") {
        const arg = unwrapExpr(recv.arguments[0]);
        if (ts5.isIdentifier(arg)) key = stateVarToName.get(checker.getSymbolAtLocation(arg));
      } else {
        const lit = constant(recv.arguments[0]);
        if (typeof lit === "string") key = lit;
      }
      if (key === void 0) return void 0;
      return { kind: "cmp", operator: method, source: src, key, value: rhs };
    }
  }
  return void 0;
}

// packages/compiler/src/frontend/template.ts
import ts6 from "typescript";
function collectTwTokens(expr, checker, out, constant = (expression) => extractScalarLiteral(expression, checker), initializationPoints = /* @__PURE__ */ new Map()) {
  const value = unwrapExpr(expr);
  if (!ts6.isCallExpression(value)) return false;
  const resolved = resolveCallName(value.expression, checker, /* @__PURE__ */ new Set(), initializationPoints);
  if (resolved?.name !== "tw" || !isCoreIntrinsic(resolved) || value.arguments.length === 0)
    return false;
  const tokens = [];
  for (const arg of value.arguments) {
    const literal = constant(arg);
    if (typeof literal !== "string") return false;
    tokens.push(...literal.trim().split(/\s+/).filter(Boolean));
  }
  out.push(...tokens);
  return true;
}
function collectRuleStyleTokens(expr, checker, out, constant = (expression) => extractScalarLiteral(expression, checker), initializationPoints = /* @__PURE__ */ new Map()) {
  const fn = resolveFunctionLike(expr, checker, initializationPoints);
  if (!fn?.body || fn.asteriskToken || fn.modifiers?.some((modifier) => modifier.kind === ts6.SyntaxKind.AsyncKeyword) || fn.parameters.length !== 1 || !ts6.isIdentifier(fn.parameters[0].name) || fn.parameters[0].initializer || fn.parameters[0].dotDotDotToken)
    return false;
  const parameter = fn.parameters[0].name.text;
  const expressions = [];
  if (ts6.isBlock(fn.body)) {
    for (const statement of fn.body.statements) {
      if (ts6.isExpressionStatement(statement)) expressions.push(statement.expression);
      else if (ts6.isReturnStatement(statement)) {
        if (statement.expression) expressions.push(statement.expression);
        break;
      } else if (!ts6.isEmptyStatement(statement)) return false;
    }
  } else expressions.push(fn.body);
  const tokens = [];
  for (const expression of expressions) {
    const call2 = unwrapExpr(expression);
    if (!ts6.isCallExpression(call2) || propAccessChain(call2.expression)?.join(".") !== parameter + ".feedback.style.use" || call2.arguments.length === 0)
      return false;
    for (const argument of call2.arguments)
      if (!collectTwTokens(argument, checker, tokens, constant, initializationPoints)) return false;
  }
  out.push(...tokens);
  return true;
}
function parseTemplateChild(expr, renderParam, stateVarToName, checker, constant = (expression) => extractScalarLiteral(expression, checker), initializationPoints = /* @__PURE__ */ new Map()) {
  const e = unwrapExpr(expr);
  if (ts6.isArrayLiteralExpression(e)) {
    const children = [];
    let reactive = false;
    for (const elem of e.elements) {
      const parsed = parseTemplateChild(
        elem,
        renderParam,
        stateVarToName,
        checker,
        constant,
        initializationPoints
      );
      if (!parsed) return void 0;
      children.push(...parsed.children);
      reactive ||= parsed.reactive;
    }
    return { children, reactive };
  }
  const lit = constant(e);
  if (lit === null) return { children: [], reactive: false };
  if (typeof lit === "string" || typeof lit === "number") {
    return { children: [{ kind: "text", value: String(lit) }], reactive: false };
  }
  if (ts6.isCallExpression(e)) {
    const chain = propAccessChain(e.expression);
    if (chain && chain[0] === renderParam) {
      const operation = chain.slice(1).join(".");
      if (operation === "slot" || operation === "r.slot") {
        if (e.arguments.length) return void 0;
        return { children: [{ kind: "slot" }], reactive: false };
      }
      if (operation === "el") {
        const el = parseTemplateElement(
          e,
          renderParam,
          stateVarToName,
          checker,
          constant,
          initializationPoints
        );
        if (!el) return void 0;
        return { children: [{ kind: "element", node: el.node }], reactive: el.reactive };
      }
    }
    if (chain && chain.length === 2 && chain[1] === "get") {
      if (e.arguments.length) return void 0;
      const stateName = ts6.isPropertyAccessExpression(e.expression) && ts6.isIdentifier(e.expression.expression) ? stateVarToName.get(checker.getSymbolAtLocation(e.expression.expression)) : void 0;
      if (stateName !== void 0) {
        return { children: [{ kind: "state-read", stateName }], reactive: true };
      }
    }
  }
  if (ts6.isPropertyAccessExpression(e) && ts6.isCallExpression(unwrapExpr(e.expression))) {
    const call2 = unwrapExpr(e.expression);
    const chain = propAccessChain(call2.expression);
    if (chain && chain[0] === renderParam && chain.slice(1).join(".") === "read.props.get") {
      if (call2.arguments.length) return void 0;
      return { children: [{ kind: "prop-read", propName: e.name.text }], reactive: true };
    }
  }
  return void 0;
}
function parseTemplateElement(call2, renderParam, stateVarToName, checker, constant = (expression) => extractScalarLiteral(expression, checker), initializationPoints = /* @__PURE__ */ new Map()) {
  if (call2.arguments.length === 0) return void 0;
  if (call2.arguments.length > 3) return void 0;
  const tagLit = constant(call2.arguments[0]);
  if (typeof tagLit !== "string") return void 0;
  let styleTokens;
  let childrenArg;
  if (call2.arguments.length === 2) {
    const second = unwrapExpr(call2.arguments[1]);
    if (ts6.isObjectLiteralExpression(second)) {
      if (second.properties.some(
        (p) => !ts6.isPropertyAssignment(p) || !ts6.isIdentifier(p.name) && !ts6.isStringLiteral(p.name) || p.name.text !== "style"
      ))
        return void 0;
      const styleExpr = extractObjectProperty(second, "style");
      if (styleExpr) {
        const toks = [];
        if (!collectTwTokens(styleExpr, checker, toks, constant, initializationPoints))
          return void 0;
        if (toks.length) styleTokens = toks;
      }
    } else {
      childrenArg = second;
    }
  } else if (call2.arguments.length >= 3) {
    const second = unwrapExpr(call2.arguments[1]);
    if (ts6.isObjectLiteralExpression(second)) {
      if (second.properties.some(
        (p) => !ts6.isPropertyAssignment(p) || !ts6.isIdentifier(p.name) && !ts6.isStringLiteral(p.name) || p.name.text !== "style"
      ))
        return void 0;
      const styleExpr = extractObjectProperty(second, "style");
      if (styleExpr) {
        const toks = [];
        if (!collectTwTokens(styleExpr, checker, toks, constant, initializationPoints))
          return void 0;
        if (toks.length) styleTokens = toks;
      }
    } else return void 0;
    childrenArg = call2.arguments[2];
  }
  let children = [];
  let reactive = false;
  if (childrenArg) {
    const parsed = parseTemplateChild(
      childrenArg,
      renderParam,
      stateVarToName,
      checker,
      constant,
      initializationPoints
    );
    if (!parsed) return void 0;
    children = parsed.children;
    reactive = parsed.reactive;
  }
  return {
    node: { tag: tagLit, ...styleTokens ? { styleTokens } : {}, children },
    reactive
  };
}

// packages/compiler/src/frontend/kernel.ts
import ts7 from "typescript";

// packages/compiler/src/ir/types.ts
var PROTO_IR_VERSION = 2;
var CAPABILITY_BITS = {
  props: 1n << 0n,
  state: 1n << 1n,
  expose: 1n << 2n,
  event: 1n << 3n,
  lifecycle: 1n << 4n,
  context: 1n << 5n,
  style: 1n << 6n,
  rule: 1n << 7n,
  render: 1n << 8n,
  trigger: 1n << 9n,
  focus: 1n << 10n,
  accessible: 1n << 11n,
  controlLabel: 1n << 12n,
  anatomy: 1n << 13n,
  collection: 1n << 14n,
  overlay: 1n << 15n,
  boundary: 1n << 16n,
  hitParticipation: 1n << 17n,
  positioning: 1n << 18n,
  scroll: 1n << 19n,
  textControl: 1n << 20n,
  imageView: 1n << 21n,
  tableStructure: 1n << 22n,
  nativeLink: 1n << 23n,
  axisInput: 1n << 24n,
  presence: 1n << 25n,
  shader: 1n << 26n,
  authoredHooks: 1n << 27n
};
function encodeCapabilityMask(caps) {
  let mask = 0n;
  for (const cap2 of caps) {
    mask |= CAPABILITY_BITS[cap2];
  }
  return mask;
}

// packages/compiler/src/ir/builder.ts
var SsaBuilder = class {
  constructor(name, params, returnType, options = {}) {
    this.name = name;
    this.params = params;
    this.returnType = returnType;
    this.options = options;
    this.current = this.createBlock("entry");
  }
  nextId = 0;
  blocks = [];
  current;
  fresh(prefix = "v") {
    return `%${prefix}${this.nextId++}`;
  }
  createBlock(label) {
    const block2 = {
      label,
      instructions: [],
      terminator: { op: "unreachable" }
    };
    this.blocks.push(block2);
    return block2;
  }
  positionAt(block2) {
    this.current = block2;
  }
  currentBlock() {
    return this.current;
  }
  emit(inst) {
    this.current.instructions.push(inst);
  }
  constI1(value) {
    const result = this.fresh("c");
    this.emit({ op: "const", result, type: "i1", value });
    return result;
  }
  constI32(value) {
    const result = this.fresh("c");
    this.emit({ op: "const", result, type: "i32", value: value | 0 });
    return result;
  }
  constF64(value) {
    const result = this.fresh("c");
    this.emit({ op: "const", result, type: "f64", value });
    return result;
  }
  loadProp(propsPtr, slot, propName, type) {
    const result = this.fresh("prop");
    this.emit({ op: "load_prop", result, type, propsPtr, slot, propName });
    return result;
  }
  loadState(statesPtr, slot, stateName, type) {
    const result = this.fresh("st");
    this.emit({ op: "load_state", result, type, statesPtr, slot, stateName });
    return result;
  }
  storeState(statesPtr, slot, value, valueType) {
    this.emit({ op: "store_state", statesPtr, slot, value, valueType });
  }
  binop(operator, type, lhs, rhs) {
    const result = this.fresh(operator);
    this.emit({ op: "binop", result, operator, type, lhs, rhs });
    return result;
  }
  cmp(operator, operandType, lhs, rhs) {
    const result = this.fresh("cmp");
    this.emit({ op: "cmp", result, operator, operandType, lhs, rhs });
    return result;
  }
  not(operand) {
    const result = this.fresh("not");
    this.emit({ op: "not", result, operand });
    return result;
  }
  fneg(operand) {
    const result = this.fresh("neg");
    this.emit({ op: "fneg", result, operand });
    return result;
  }
  select(type, cond, thenVal, elseVal) {
    const result = this.fresh("sel");
    this.emit({ op: "select", result, type, cond, thenVal, elseVal });
    return result;
  }
  phi(type, incoming) {
    const result = this.fresh("phi");
    this.emit({ op: "phi", result, type, incoming });
    return result;
  }
  call(callee, returnType, args) {
    const result = returnType === "void" ? void 0 : this.fresh("call");
    this.emit({ op: "call", result, callee, returnType, args });
    return result;
  }
  hostOp(kind, args) {
    this.emit({ op: "host_op", kind, args });
  }
  terminate(terminator) {
    this.current.terminator = terminator;
  }
  br(target) {
    this.terminate({ op: "br", target });
  }
  condbr(cond, thenTarget, elseTarget) {
    this.terminate({ op: "condbr", cond, thenTarget, elseTarget });
  }
  ret(value) {
    this.terminate(
      value !== void 0 ? { op: "ret", value, type: this.returnType } : { op: "ret", type: "void" }
    );
  }
  build() {
    return {
      name: this.name,
      params: this.params,
      returnType: this.returnType,
      blocks: this.blocks,
      ...this.options
    };
  }
};

// packages/compiler/src/ir/verify.ts
var HOST_SIGNATURES = {
  emit_event: ["ptr", "i32"],
  request_update: ["ptr"],
  set_present: ["ptr", "i1"],
  apply_style_rule: ["ptr", "i32"]
};
function resultType(inst) {
  switch (inst.op) {
    case "const":
    case "load_prop":
    case "load_state":
    case "binop":
    case "select":
    case "phi":
      return inst.type;
    case "cmp":
    case "not":
      return "i1";
    case "fneg":
      return "f64";
    case "call":
      return inst.result ? inst.returnType : void 0;
    case "store_state":
    case "host_op":
      return void 0;
  }
}
function successors(fn, label) {
  const term = fn.blocks.find((block2) => block2.label === label)?.terminator;
  if (term?.op === "br") return [term.target];
  if (term?.op === "condbr") return [term.thenTarget, term.elseTarget];
  return [];
}
function verifySsaFunction(fn, functions = /* @__PURE__ */ new Map([[fn.name, fn]])) {
  const issues = [];
  const push = (message) => issues.push(diagnostic("PUI_IR001", "ir", fn.name + ": " + message));
  if (fn.blocks.length === 0) {
    push("SSA function must contain an entry basic block.");
    return issues;
  }
  const blocks = new Map(fn.blocks.map((block2) => [block2.label, block2]));
  if (blocks.size !== fn.blocks.length) push("Basic block labels must be unique.");
  const definitions = /* @__PURE__ */ new Map();
  const define = (id2, definition) => {
    if (definitions.has(id2)) push("Duplicate SSA definition " + id2 + ".");
    definitions.set(id2, definition);
  };
  for (const param of fn.params) define(param.id, { type: param.type, index: -1 });
  for (const block2 of fn.blocks) {
    block2.instructions.forEach((inst, index) => {
      const type = resultType(inst);
      if ("result" in inst && inst.result && type) {
        define(inst.result, { type, block: block2.label, index });
      }
    });
  }
  const predecessors = /* @__PURE__ */ new Map();
  for (const label of blocks.keys()) predecessors.set(label, /* @__PURE__ */ new Map());
  for (const block2 of fn.blocks) {
    for (const target of successors(fn, block2.label)) {
      const incoming = predecessors.get(target);
      if (!incoming) {
        push("Branch from " + block2.label + " to unknown block " + target + ".");
      } else {
        incoming.set(block2.label, (incoming.get(block2.label) ?? 0) + 1);
      }
    }
  }
  const entry = fn.blocks[0].label;
  if (predecessors.get(entry)?.size) push("The entry block cannot have predecessors.");
  const reachable = /* @__PURE__ */ new Set();
  const queue = [entry];
  while (queue.length) {
    const label = queue.pop();
    if (reachable.has(label) || !blocks.has(label)) continue;
    reachable.add(label);
    queue.push(...successors(fn, label));
  }
  const dominators = /* @__PURE__ */ new Map();
  for (const label of reachable) {
    dominators.set(label, label === entry ? /* @__PURE__ */ new Set([entry]) : new Set(reachable));
  }
  let changed = true;
  while (changed) {
    changed = false;
    for (const label of reachable) {
      if (label === entry) continue;
      const parents = [...predecessors.get(label).keys()].filter((p) => reachable.has(p));
      const next = new Set(parents.length ? dominators.get(parents[0]) : []);
      for (const parent of parents.slice(1)) {
        for (const candidate of next) {
          if (!dominators.get(parent).has(candidate)) next.delete(candidate);
        }
      }
      next.add(label);
      const previous = dominators.get(label);
      if (next.size !== previous.size || [...next].some((v) => !previous.has(v))) {
        dominators.set(label, next);
        changed = true;
      }
    }
  }
  const operand = (id2, expected, context, block2, index) => {
    const definition = definitions.get(id2);
    if (!definition) {
      push("Undefined SSA value " + id2 + " in " + context + ".");
      return;
    }
    if (definition.type !== expected) {
      push(
        "Type mismatch for " + id2 + " in " + context + ": expected " + expected + ", got " + definition.type + "."
      );
    }
    if (!definition.block) return;
    if (definition.block === block2) {
      if (definition.index >= index) {
        push("Definition of " + id2 + " does not precede its use in " + context + ".");
      }
    } else if (reachable.has(block2) && !dominators.get(block2)?.has(definition.block)) {
      push("Definition of " + id2 + " does not dominate its use in " + context + ".");
    }
  };
  const slot = (value, context) => {
    if (!Number.isSafeInteger(value) || value < 0) {
      push(context + " slot must be a non-negative safe integer.");
    }
  };
  for (const block2 of fn.blocks) {
    let seenNonPhi = false;
    block2.instructions.forEach((inst, index) => {
      const use = (id2, type, context = inst.op) => operand(id2, type, context, block2.label, index);
      if (inst.op === "phi") {
        if (seenNonPhi) push("Phi instructions must precede all other instructions.");
        const expected = predecessors.get(block2.label);
        const incoming = /* @__PURE__ */ new Map();
        const incomingValues = /* @__PURE__ */ new Map();
        for (const edge of inst.incoming) {
          incoming.set(edge.label, (incoming.get(edge.label) ?? 0) + 1);
          const previous = incomingValues.get(edge.label);
          if (previous !== void 0 && previous !== edge.value) {
            push("Duplicate phi edges from " + edge.label + " must carry the same value.");
          }
          incomingValues.set(edge.label, edge.value);
          const parent = blocks.get(edge.label);
          if (!parent) push("Phi references unknown predecessor " + edge.label + ".");
          else
            operand(
              edge.value,
              inst.type,
              "phi " + inst.result,
              edge.label,
              parent.instructions.length
            );
        }
        if (inst.incoming.length === 0 || incoming.size !== expected.size || [...expected].some(([label, count]) => incoming.get(label) !== count)) {
          push("Phi " + inst.result + " incoming edges must exactly match CFG predecessors.");
        }
        return;
      }
      seenNonPhi = true;
      switch (inst.op) {
        case "const":
          if (inst.type === "i1" && typeof inst.value !== "boolean" || inst.type === "f64" && typeof inst.value !== "number" || inst.type === "i32" && (typeof inst.value !== "number" || !Number.isInteger(inst.value) || inst.value < -2147483648 || inst.value > 2147483647) || inst.type === "ptr" && inst.value !== null) {
            push("Constant " + inst.result + " has an invalid value for " + inst.type + ".");
          }
          break;
        case "load_prop":
          use(inst.propsPtr, "ptr");
          slot(inst.slot, inst.op);
          break;
        case "load_state":
          use(inst.statesPtr, "ptr");
          slot(inst.slot, inst.op);
          break;
        case "store_state":
          use(inst.statesPtr, "ptr");
          use(inst.value, inst.valueType);
          slot(inst.slot, inst.op);
          if (fn.pure) push("Pure function cannot store state.");
          break;
        case "binop":
          use(inst.lhs, inst.type);
          use(inst.rhs, inst.type);
          if (inst.type === "i1" && !["and", "or", "xor"].includes(inst.operator) || inst.type === "f64" && ["and", "or", "xor"].includes(inst.operator)) {
            push("Invalid " + inst.type + " binary operation " + inst.operator + ".");
          }
          break;
        case "cmp":
          use(inst.lhs, inst.operandType);
          use(inst.rhs, inst.operandType);
          break;
        case "not":
          use(inst.operand, "i1");
          break;
        case "fneg":
          use(inst.operand, "f64");
          break;
        case "select":
          use(inst.cond, "i1");
          use(inst.thenVal, inst.type);
          use(inst.elseVal, inst.type);
          break;
        case "call": {
          for (const arg of inst.args) use(arg.id, arg.type, "call " + inst.callee);
          const callee = functions.get(inst.callee);
          if (!callee) push("Call references unknown function " + inst.callee + ".");
          else {
            if (callee.returnType !== inst.returnType || callee.params.length !== inst.args.length || callee.params.some((p, i) => p.type !== inst.args[i]?.type)) {
              push("Call to " + inst.callee + " does not match its declared signature.");
            }
            if (fn.pure && !callee.pure) push("Pure function calls impure " + inst.callee + ".");
          }
          if (inst.returnType === "void" !== (inst.result === void 0)) {
            push("Call result must be present exactly when its return type is non-void.");
          }
          break;
        }
        case "host_op": {
          const signature = HOST_SIGNATURES[inst.kind];
          for (const arg of inst.args) use(arg.id, arg.type, "host_op " + inst.kind);
          if (signature.length !== inst.args.length || signature.some((type, i) => type !== inst.args[i]?.type)) {
            push("Host operation " + inst.kind + " has an invalid signature.");
          }
          if (fn.pure) push("Pure function cannot invoke a host operation.");
          break;
        }
      }
    });
    const term = block2.terminator;
    if (term.op === "condbr") {
      operand(term.cond, "i1", "condbr", block2.label, block2.instructions.length);
    } else if (term.op === "ret") {
      if (term.type !== fn.returnType) push("Return instruction type differs from function type.");
      if (fn.returnType === "void") {
        if (term.value !== void 0) push("Void function cannot return a value.");
      } else if (term.value === void 0) {
        push("Non-void function must return a value.");
      } else {
        operand(term.value, fn.returnType, "return", block2.label, block2.instructions.length);
      }
    }
  }
  return issues;
}
function verifyModuleIR(mod) {
  const issues = [];
  if (mod.irVersion !== PROTO_IR_VERSION) {
    issues.push(
      diagnostic(
        "PUI_IR002",
        "ir",
        "Unsupported IR version " + String(mod.irVersion) + "; expected " + PROTO_IR_VERSION + "."
      )
    );
  }
  const functions = /* @__PURE__ */ new Map();
  const all = [...mod.functions, ...mod.prototypes.flatMap((proto) => proto.functions)];
  for (const fn of all) {
    if (functions.has(fn.name)) {
      issues.push(diagnostic("PUI_IR003", "ir", "Duplicate SSA function " + fn.name + "."));
    }
    functions.set(fn.name, fn);
  }
  for (const fn of all) issues.push(...verifySsaFunction(fn, functions));
  return issues;
}

// packages/compiler/src/ir/passes.ts
function isPureInst(inst) {
  switch (inst.op) {
    case "const":
    case "load_prop":
    case "load_state":
    case "binop":
    case "cmp":
    case "not":
    case "fneg":
    case "select":
    case "phi":
      return true;
    case "store_state":
    case "host_op":
    case "call":
      return false;
  }
}
function usedOperands(inst) {
  switch (inst.op) {
    case "const":
      return [];
    case "load_prop":
      return [inst.propsPtr];
    case "load_state":
      return [inst.statesPtr];
    case "store_state":
      return [inst.statesPtr, inst.value];
    case "binop":
    case "cmp":
      return [inst.lhs, inst.rhs];
    case "not":
    case "fneg":
      return [inst.operand];
    case "select":
      return [inst.cond, inst.thenVal, inst.elseVal];
    case "phi":
      return inst.incoming.map((inc) => inc.value);
    case "call":
    case "host_op":
      return inst.args.map((a) => a.id);
  }
}
function terminatorOperands(term) {
  if (term.op === "condbr") return [term.cond];
  if (term.op === "ret" && term.value !== void 0) return [term.value];
  return [];
}
function evalBinOp(op, type, a, b) {
  if (type === "i1") {
    const ba = Boolean(a);
    const bb = Boolean(b);
    if (op === "and") return ba && bb;
    if (op === "or") return ba || bb;
    if (op === "xor") return ba !== bb;
    return void 0;
  }
  const na = Number(a);
  const nb = Number(b);
  let out;
  switch (op) {
    case "add":
      out = na + nb;
      break;
    case "sub":
      out = na - nb;
      break;
    case "mul":
      out = type === "i32" ? Math.imul(na, nb) : na * nb;
      break;
    case "div":
      if (type === "i32" && (nb | 0) === 0) return void 0;
      if (type === "i32" && na === -2147483648 && nb === -1) return void 0;
      out = type === "i32" ? Math.trunc(na / nb) : na / nb;
      break;
    case "rem":
      if (type === "i32" && (nb | 0) === 0) return void 0;
      if (type === "i32" && na === -2147483648 && nb === -1) return void 0;
      out = na % nb;
      break;
    case "and":
      out = (na | 0) & (nb | 0);
      break;
    case "or":
      out = na | 0 | (nb | 0);
      break;
    case "xor":
      out = (na | 0) ^ (nb | 0);
      break;
  }
  return type === "i32" ? out | 0 : out;
}
function evalCmp(op, a, b) {
  const na = typeof a === "boolean" ? a ? 1 : 0 : a;
  const nb = typeof b === "boolean" ? b ? 1 : 0 : b;
  switch (op) {
    case "eq":
      return na === nb;
    case "ne":
      return na !== nb;
    case "lt":
      return na < nb;
    case "le":
      return na <= nb;
    case "gt":
      return na > nb;
    case "ge":
      return na >= nb;
  }
}
function optimizeSsaFunction(fn) {
  const blocksBefore = fn.blocks.length;
  const instructionsBefore = fn.blocks.reduce((sum, b) => sum + b.instructions.length, 0);
  let foldedConstants = 0;
  const consts = /* @__PURE__ */ new Map();
  const aliases = /* @__PURE__ */ new Map();
  const resolve = (id2) => {
    let cur = id2;
    while (aliases.has(cur)) cur = aliases.get(cur);
    return cur;
  };
  let blocks = fn.blocks.map((block2) => ({
    label: block2.label,
    instructions: block2.instructions.map((inst) => ({ ...inst })),
    terminator: { ...block2.terminator }
  }));
  for (let round = 0; round < 4; round++) {
    let changed = false;
    for (const block2 of blocks) {
      const nextInsts = [];
      for (const raw of block2.instructions) {
        const inst = rewriteInstOperands(raw, resolve);
        if (inst.op === "const") {
          consts.set(inst.result, inst.value);
          nextInsts.push(inst);
          continue;
        }
        if (inst.op === "not") {
          const cv = consts.get(inst.operand);
          if (typeof cv === "boolean") {
            consts.set(inst.result, !cv);
            nextInsts.push({ op: "const", result: inst.result, type: "i1", value: !cv });
            foldedConstants++;
            changed = true;
            continue;
          }
        }
        if (inst.op === "fneg") {
          const cv = consts.get(inst.operand);
          if (typeof cv === "number") {
            const folded = -cv;
            consts.set(inst.result, folded);
            nextInsts.push({ op: "const", result: inst.result, type: "f64", value: folded });
            foldedConstants++;
            changed = true;
            continue;
          }
        }
        if (inst.op === "binop") {
          const lv = consts.get(inst.lhs);
          const rv = consts.get(inst.rhs);
          if ((typeof lv === "boolean" || typeof lv === "number") && (typeof rv === "boolean" || typeof rv === "number")) {
            const folded = evalBinOp(inst.operator, inst.type, lv, rv);
            if (folded !== void 0) {
              consts.set(inst.result, folded);
              nextInsts.push({
                op: "const",
                result: inst.result,
                type: inst.type,
                value: folded
              });
              foldedConstants++;
              changed = true;
              continue;
            }
          }
          if (inst.type === "i1" && inst.operator === "and") {
            if (lv === false || rv === false) {
              consts.set(inst.result, false);
              nextInsts.push({ op: "const", result: inst.result, type: "i1", value: false });
              foldedConstants++;
              changed = true;
              continue;
            }
            if (lv === true) {
              aliases.set(inst.result, inst.rhs);
              foldedConstants++;
              changed = true;
              continue;
            }
            if (rv === true) {
              aliases.set(inst.result, inst.lhs);
              foldedConstants++;
              changed = true;
              continue;
            }
          }
          if (inst.type === "i1" && inst.operator === "or") {
            if (lv === true || rv === true) {
              consts.set(inst.result, true);
              nextInsts.push({ op: "const", result: inst.result, type: "i1", value: true });
              foldedConstants++;
              changed = true;
              continue;
            }
            if (lv === false) {
              aliases.set(inst.result, inst.rhs);
              foldedConstants++;
              changed = true;
              continue;
            }
            if (rv === false) {
              aliases.set(inst.result, inst.lhs);
              foldedConstants++;
              changed = true;
              continue;
            }
          }
        }
        if (inst.op === "cmp") {
          const lv = consts.get(inst.lhs);
          const rv = consts.get(inst.rhs);
          if ((typeof lv === "boolean" || typeof lv === "number") && (typeof rv === "boolean" || typeof rv === "number")) {
            const folded = evalCmp(inst.operator, lv, rv);
            consts.set(inst.result, folded);
            nextInsts.push({ op: "const", result: inst.result, type: "i1", value: folded });
            foldedConstants++;
            changed = true;
            continue;
          }
        }
        if (inst.op === "select") {
          const cv = consts.get(inst.cond);
          if (typeof cv === "boolean") {
            aliases.set(inst.result, cv ? inst.thenVal : inst.elseVal);
            foldedConstants++;
            changed = true;
            continue;
          }
          if (inst.thenVal === inst.elseVal) {
            aliases.set(inst.result, inst.thenVal);
            foldedConstants++;
            changed = true;
            continue;
          }
        }
        nextInsts.push(inst);
      }
      block2.instructions.splice(0, block2.instructions.length, ...nextInsts);
      block2.terminator = rewriteTerminatorOperands(block2.terminator, resolve);
      if (block2.terminator.op === "condbr") {
        const cv = consts.get(block2.terminator.cond);
        if (typeof cv === "boolean") {
          block2.terminator = {
            op: "br",
            target: cv ? block2.terminator.thenTarget : block2.terminator.elseTarget
          };
          foldedConstants++;
          changed = true;
        }
      }
    }
    if (!changed) break;
  }
  const blockMap = new Map(blocks.map((b) => [b.label, b]));
  const reachable = /* @__PURE__ */ new Set();
  const queue = blocks.length ? [blocks[0].label] : [];
  while (queue.length) {
    const label = queue.shift();
    if (reachable.has(label)) continue;
    reachable.add(label);
    const blk = blockMap.get(label);
    if (!blk) continue;
    if (blk.terminator.op === "br") queue.push(blk.terminator.target);
    else if (blk.terminator.op === "condbr") {
      queue.push(blk.terminator.thenTarget, blk.terminator.elseTarget);
    }
  }
  blocks = blocks.filter((b) => reachable.has(b.label));
  const incomingEdges = /* @__PURE__ */ new Map();
  for (const block2 of blocks) incomingEdges.set(block2.label, /* @__PURE__ */ new Map());
  for (const block2 of blocks) {
    const term = block2.terminator;
    const targets2 = term.op === "br" ? [term.target] : term.op === "condbr" ? [term.thenTarget, term.elseTarget] : [];
    for (const target of targets2) {
      const incoming = incomingEdges.get(target);
      if (incoming) incoming.set(block2.label, (incoming.get(block2.label) ?? 0) + 1);
    }
  }
  for (const block2 of blocks) {
    for (let i = 0; i < block2.instructions.length; i++) {
      const inst = block2.instructions[i];
      if (inst.op === "phi") {
        const remaining = new Map(incomingEdges.get(block2.label));
        const live2 = inst.incoming.filter((inc) => {
          const count = remaining.get(inc.label) ?? 0;
          if (count === 0) return false;
          remaining.set(inc.label, count - 1);
          return true;
        });
        block2.instructions[i] = { ...inst, incoming: live2 };
      }
    }
  }
  const defToInst = /* @__PURE__ */ new Map();
  const live = /* @__PURE__ */ new Set();
  const worklist = [];
  for (const block2 of blocks) {
    for (const inst of block2.instructions) {
      if ("result" in inst && inst.result) defToInst.set(inst.result, inst);
      if (!isPureInst(inst)) {
        live.add(inst);
        worklist.push(inst);
      }
    }
  }
  const markVal = (id2) => {
    const def = defToInst.get(id2);
    if (def && !live.has(def)) {
      live.add(def);
      worklist.push(def);
    }
  };
  for (const block2 of blocks) {
    for (const id2 of terminatorOperands(block2.terminator)) markVal(id2);
  }
  while (worklist.length) {
    const inst = worklist.pop();
    for (const id2 of usedOperands(inst)) markVal(id2);
  }
  for (const block2 of blocks) {
    const kept = block2.instructions.filter((inst) => live.has(inst));
    block2.instructions.splice(0, block2.instructions.length, ...kept);
  }
  const blocksAfter = blocks.length;
  const instructionsAfter = blocks.reduce((sum, b) => sum + b.instructions.length, 0);
  return {
    fn: { ...fn, blocks },
    stats: {
      instructionsBefore,
      instructionsAfter,
      blocksBefore,
      blocksAfter,
      foldedConstants,
      eliminatedInstructions: Math.max(0, instructionsBefore - instructionsAfter),
      eliminatedBlocks: Math.max(0, blocksBefore - blocksAfter)
    }
  };
}
function rewriteInstOperands(inst, resolve) {
  switch (inst.op) {
    case "const":
      return inst;
    case "load_prop":
      return { ...inst, propsPtr: resolve(inst.propsPtr) };
    case "load_state":
      return { ...inst, statesPtr: resolve(inst.statesPtr) };
    case "store_state":
      return {
        ...inst,
        statesPtr: resolve(inst.statesPtr),
        value: resolve(inst.value)
      };
    case "binop":
      return { ...inst, lhs: resolve(inst.lhs), rhs: resolve(inst.rhs) };
    case "cmp":
      return { ...inst, lhs: resolve(inst.lhs), rhs: resolve(inst.rhs) };
    case "not":
    case "fneg":
      return { ...inst, operand: resolve(inst.operand) };
    case "select":
      return {
        ...inst,
        cond: resolve(inst.cond),
        thenVal: resolve(inst.thenVal),
        elseVal: resolve(inst.elseVal)
      };
    case "phi":
      return {
        ...inst,
        incoming: inst.incoming.map((inc) => ({ label: inc.label, value: resolve(inc.value) }))
      };
    case "call":
    case "host_op":
      return { ...inst, args: inst.args.map((a) => ({ ...a, id: resolve(a.id) })) };
  }
}
function rewriteTerminatorOperands(term, resolve) {
  if (term.op === "condbr") return { ...term, cond: resolve(term.cond) };
  if (term.op === "ret" && term.value !== void 0) return { ...term, value: resolve(term.value) };
  return term;
}
var HOOK_CAPABILITY_MAP = {
  asTrigger: "trigger",
  asFocusable: "focus",
  asFocusEntry: "focus",
  asFocusScope: "focus",
  asFocusRoving: "focus",
  asAccessible: "accessible",
  asControlLabel: "controlLabel",
  asAnatomy: "anatomy",
  asCollection: "collection",
  asCollectionItem: "collection",
  asOverlay: "overlay",
  asBoundary: "boundary",
  asHitParticipation: "hitParticipation",
  asPositioning: "positioning",
  asScrollSurface: "scroll",
  asTextControl: "textControl",
  asImageView: "imageView",
  asTableStructure: "tableStructure",
  asNativeLink: "nativeLink",
  asAxisInput: "axisInput",
  asPresence: "presence"
};
function computePrototypeCapabilities(proto) {
  const caps = /* @__PURE__ */ new Set();
  if (proto.props.length > 0) caps.add("props");
  if (proto.states.length > 0) caps.add("state");
  if (proto.exposes.length > 0) caps.add("expose");
  if (proto.events.length > 0) caps.add("event");
  if (proto.lifecycle.length > 0) caps.add("lifecycle");
  if (proto.contexts.length > 0) caps.add("context");
  if (proto.staticStyleTokens.length > 0) caps.add("style");
  if (proto.rules.length > 0) {
    caps.add("rule");
    caps.add("style");
  }
  if (proto.render.kind !== "default-slot") caps.add("render");
  for (const hook of proto.hooks) {
    if (hook.lowered) continue;
    const mapped = HOOK_CAPABILITY_MAP[hook.name];
    if (mapped) caps.add(mapped);
    else if (hook.kind === "authored") caps.add("authoredHooks");
  }
  const capabilities = [...caps].sort();
  return { capabilities, capabilityMask: encodeCapabilityMask(capabilities) };
}
function optimizeModuleIR(mod) {
  let instructionsBefore = 0;
  let instructionsAfter = 0;
  let blocksBefore = 0;
  let blocksAfter = 0;
  let foldedConstants = 0;
  let eliminatedInstructions = 0;
  let eliminatedBlocks = 0;
  const merge = (s) => {
    instructionsBefore += s.instructionsBefore;
    instructionsAfter += s.instructionsAfter;
    blocksBefore += s.blocksBefore;
    blocksAfter += s.blocksAfter;
    foldedConstants += s.foldedConstants;
    eliminatedInstructions += s.eliminatedInstructions;
    eliminatedBlocks += s.eliminatedBlocks;
  };
  const optFn = (fn) => {
    const res = optimizeSsaFunction(fn);
    merge(res.stats);
    return res.fn;
  };
  const functions = mod.functions.map(optFn);
  const prototypes = mod.prototypes.map((proto) => ({
    ...proto,
    functions: proto.functions.map(optFn)
  }));
  return {
    ir: { ...mod, functions, prototypes },
    stats: {
      instructionsBefore,
      instructionsAfter,
      blocksBefore,
      blocksAfter,
      foldedConstants,
      eliminatedInstructions,
      eliminatedBlocks
    }
  };
}

// packages/compiler/src/ir/print.ts
function printIR(value) {
  return JSON.stringify(
    value,
    (_key, field) => {
      if (typeof field === "bigint") return { $bigint: field.toString() };
      if (typeof field === "number") {
        if (Object.is(field, -0)) return { $number: "-0" };
        if (!Number.isFinite(field)) return { $number: String(field) };
      }
      return field;
    },
    2
  ) + "\n";
}
function printModuleIR(module) {
  return printIR(module);
}

// packages/compiler/src/frontend/kernel.ts
function detectSimpleEventAction(handler, stateVarToName, checker) {
  if (!handler.body) return void 0;
  const stmts = ts7.isBlock(handler.body) ? handler.body.statements : [];
  let expr;
  if (ts7.isBlock(handler.body)) {
    if (stmts.length !== 1 || !ts7.isExpressionStatement(stmts[0])) return void 0;
    expr = stmts[0].expression;
  } else {
    expr = handler.body;
  }
  const call2 = unwrapExpr(expr);
  if (!ts7.isCallExpression(call2)) return void 0;
  const chain = propAccessChain(call2.expression);
  if (!chain || chain.length !== 2 || chain[1] !== "set" || call2.arguments.length < 1) {
    return void 0;
  }
  const stateName = ts7.isPropertyAccessExpression(call2.expression) && ts7.isIdentifier(call2.expression.expression) ? stateVarToName.get(checker.getSymbolAtLocation(call2.expression.expression)) : void 0;
  if (stateName === void 0) return void 0;
  const arg = unwrapExpr(call2.arguments[0]);
  if (ts7.isBinaryExpression(arg) && (arg.operatorToken.kind === ts7.SyntaxKind.PlusToken || arg.operatorToken.kind === ts7.SyntaxKind.MinusToken)) {
    const left = unwrapExpr(arg.left);
    const right = extractScalarLiteral(arg.right, checker);
    if (ts7.isCallExpression(left) && typeof right === "number") {
      const lc = propAccessChain(left.expression);
      if (lc && lc.length === 2 && lc[0] === chain[0] && lc[1] === "get") {
        const delta = arg.operatorToken.kind === ts7.SyntaxKind.PlusToken ? right : -right;
        return { kind: "increment-state", stateName, delta };
      }
    }
  }
  if (ts7.isPrefixUnaryExpression(arg) && arg.operator === ts7.SyntaxKind.ExclamationToken) {
    const inner = unwrapExpr(arg.operand);
    if (ts7.isCallExpression(inner)) {
      const ic = propAccessChain(inner.expression);
      if (ic && ic.length === 2 && ic[0] === chain[0] && ic[1] === "get") {
        return { kind: "toggle-state", stateName };
      }
    }
  }
  const lit = extractScalarLiteral(arg, checker);
  if (lit !== void 0) {
    return { kind: "set-state", stateName, value: lit };
  }
  return void 0;
}
function lowerRuleToSsa(protoSym, rule, props, states, stringTable) {
  const b = new SsaBuilder(
    `${protoSym}_rule_${rule.id}`,
    [
      { id: "%props", type: "ptr" },
      { id: "%states", type: "ptr" }
    ],
    "i1",
    {
      exported: true,
      pure: true,
      comment: `Compiled rule #${rule.id} -> [${rule.styleTokens.join(" ")}]`
    }
  );
  const propByName = new Map(props.map((p) => [p.name, p]));
  const stateByName = new Map(states.map((s) => [s.name, s]));
  const compareNumber = (value, threshold, operator) => {
    const comparison = b.cmp(operator, "f64", value, b.constF64(threshold));
    if (operator === "eq") return comparison;
    const finite = b.binop(
      "and",
      "i1",
      b.cmp("lt", "f64", value, b.constF64(Infinity)),
      b.cmp("gt", "f64", value, b.constF64(-Infinity))
    );
    return b.binop("and", "i1", comparison, finite);
  };
  const emitExpr = (expr) => {
    switch (expr.kind) {
      case "true":
        return b.constI1(true);
      case "false":
        return b.constI1(false);
      case "not":
        return b.not(emitExpr(expr.expr));
      case "all": {
        let acc = emitExpr(expr.exprs[0]);
        for (let i = 1; i < expr.exprs.length; i++) {
          acc = b.binop("and", "i1", acc, emitExpr(expr.exprs[i]));
        }
        return acc;
      }
      case "any": {
        let acc = emitExpr(expr.exprs[0]);
        for (let i = 1; i < expr.exprs.length; i++) {
          acc = b.binop("or", "i1", acc, emitExpr(expr.exprs[i]));
        }
        return acc;
      }
      case "cmp": {
        const cmpOp = expr.operator === "eq" ? "eq" : "ge";
        if (expr.source === "prop") {
          const prop2 = propByName.get(expr.key);
          const slot = prop2?.index ?? 0;
          if (typeof expr.value === "boolean") {
            const v = b.loadProp("%props", slot, expr.key, "i1");
            return b.cmp(cmpOp, "i1", v, b.constI1(expr.value));
          }
          if (typeof expr.value === "number") {
            const v = b.loadProp("%props", slot, expr.key, "f64");
            return compareNumber(v, expr.value, cmpOp);
          }
          if (typeof expr.value === "string") {
            const v = b.loadProp("%props", slot, expr.key, "i32");
            return b.cmp(cmpOp, "i32", v, b.constI32(internString(stringTable, expr.value)));
          }
          return b.constI1(false);
        }
        if (expr.source === "state") {
          const st = stateByName.get(expr.key);
          const slot = st?.index ?? 0;
          if (typeof expr.value === "boolean") {
            const v = b.loadState("%states", slot, expr.key, "i1");
            return b.cmp(cmpOp, "i1", v, b.constI1(expr.value));
          }
          if (typeof expr.value === "number") {
            const v = b.loadState("%states", slot, expr.key, "f64");
            return compareNumber(v, expr.value, cmpOp);
          }
          if (typeof expr.value === "string") {
            const v = b.loadState("%states", slot, expr.key, "i32");
            return b.cmp(cmpOp, "i32", v, b.constI32(internString(stringTable, expr.value)));
          }
          return b.constI1(false);
        }
        return b.constI1(false);
      }
    }
  };
  const res = emitExpr(rule.condition);
  b.ret(res);
  return b.build();
}
function lowerCombinedRuleMask(protoSym, rules) {
  const b = new SsaBuilder(
    `${protoSym}_eval_rules`,
    [
      { id: "%props", type: "ptr" },
      { id: "%states", type: "ptr" }
    ],
    "i32",
    { exported: true, pure: true, comment: `Evaluates bitmask of ${rules.length} compiled rules` }
  );
  let mask = b.constI32(0);
  const limit = Math.min(rules.length, 31);
  for (let i = 0; i < limit; i++) {
    const matched = b.call(`${protoSym}_rule_${rules[i].id}`, "i1", [
      { id: "%props", type: "ptr" },
      { id: "%states", type: "ptr" }
    ]);
    const bit = b.select("i32", matched, b.constI32(1 << i), b.constI32(0));
    mask = b.binop("or", "i32", mask, bit);
  }
  b.ret(mask);
  return b.build();
}
function lowerEventActionsToSsa(protoSym, events, states, stringTable) {
  const stateByName = new Map(states.map((s) => [s.name, s]));
  const fns = [];
  events.forEach((ev, idx) => {
    const act = ev.simpleAction;
    if (!act) return;
    const st = stateByName.get(act.stateName);
    if (!st) return;
    const b = new SsaBuilder(
      `${protoSym}_on_${sanitizeSym(ev.eventName)}_${idx}`,
      [{ id: "%states", type: "ptr" }],
      "void",
      { exported: true, comment: `State transition kernel for event '${ev.eventName}'` }
    );
    if (act.kind === "increment-state" && st.ssaType === "f64") {
      const cur = b.loadState("%states", st.index, st.name, "f64");
      const next = b.binop("add", "f64", cur, b.constF64(act.delta));
      b.storeState("%states", st.index, next, "f64");
    } else if (act.kind === "toggle-state" && st.ssaType === "i1") {
      const cur = b.loadState("%states", st.index, st.name, "i1");
      const next = b.not(cur);
      b.storeState("%states", st.index, next, "i1");
    } else if (act.kind === "set-state") {
      if (st.ssaType === "i1" && typeof act.value === "boolean") {
        b.storeState("%states", st.index, b.constI1(act.value), "i1");
      } else if (st.ssaType === "f64" && typeof act.value === "number") {
        b.storeState("%states", st.index, b.constF64(act.value), "f64");
      } else if (st.ssaType === "i32" && typeof act.value === "string") {
        b.storeState("%states", st.index, b.constI32(internString(stringTable, act.value)), "i32");
      }
    }
    b.ret();
    fns.push(b.build());
  });
  return fns;
}
function tryLowerPureScalarFunction(fn, checker) {
  if (!fn.name || !fn.body) return void 0;
  const sig = checker.getSignatureFromDeclaration(fn);
  if (!sig) return void 0;
  const tsTypeToSsa = (t) => {
    if (t.flags & (ts7.TypeFlags.Number | ts7.TypeFlags.NumberLiteral)) return "f64";
    if (t.flags & (ts7.TypeFlags.Boolean | ts7.TypeFlags.BooleanLiteral)) return "i1";
    return void 0;
  };
  const retType = tsTypeToSsa(checker.getReturnTypeOfSignature(sig));
  if (!retType) return void 0;
  const params = [];
  for (const p of fn.parameters) {
    if (!ts7.isIdentifier(p.name) || p.dotDotDotToken) return void 0;
    const pt = tsTypeToSsa(checker.getTypeAtLocation(p));
    if (!pt) return void 0;
    params.push({ id: `%${sanitizeSym(p.name.text)}`, name: p.name.text, type: pt });
  }
  const b = new SsaBuilder(
    `helper_${sanitizeSym(fn.name.text)}`,
    params.map(({ id: id2, type }) => ({ id: id2, type })),
    retType,
    { exported: true, pure: true, comment: `Lowered pure scalar helper ${fn.name.text}` }
  );
  const env = new Map(
    params.map((p) => [p.name, { id: p.id, type: p.type }])
  );
  const lowerExpr = (raw) => {
    const e = unwrapExpr(raw);
    if (ts7.isNumericLiteral(e)) return { id: b.constF64(Number(e.text)), type: "f64" };
    if (e.kind === ts7.SyntaxKind.TrueKeyword) return { id: b.constI1(true), type: "i1" };
    if (e.kind === ts7.SyntaxKind.FalseKeyword) return { id: b.constI1(false), type: "i1" };
    if (ts7.isIdentifier(e)) return env.get(e.text);
    if (ts7.isPrefixUnaryExpression(e)) {
      const inner = lowerExpr(e.operand);
      if (!inner) return void 0;
      if (e.operator === ts7.SyntaxKind.ExclamationToken && inner.type === "i1") {
        return { id: b.not(inner.id), type: "i1" };
      }
      if (e.operator === ts7.SyntaxKind.MinusToken && inner.type === "f64") {
        return { id: b.fneg(inner.id), type: "f64" };
      }
      return void 0;
    }
    if (ts7.isBinaryExpression(e)) {
      const l = lowerExpr(e.left);
      const r = lowerExpr(e.right);
      if (!l || !r || l.type !== r.type) return void 0;
      const k = e.operatorToken.kind;
      if (l.type === "f64") {
        if (k === ts7.SyntaxKind.PlusToken)
          return { id: b.binop("add", "f64", l.id, r.id), type: "f64" };
        if (k === ts7.SyntaxKind.MinusToken)
          return { id: b.binop("sub", "f64", l.id, r.id), type: "f64" };
        if (k === ts7.SyntaxKind.AsteriskToken)
          return { id: b.binop("mul", "f64", l.id, r.id), type: "f64" };
        if (k === ts7.SyntaxKind.SlashToken)
          return { id: b.binop("div", "f64", l.id, r.id), type: "f64" };
        if (k === ts7.SyntaxKind.EqualsEqualsEqualsToken)
          return { id: b.cmp("eq", "f64", l.id, r.id), type: "i1" };
        if (k === ts7.SyntaxKind.ExclamationEqualsEqualsToken)
          return { id: b.cmp("ne", "f64", l.id, r.id), type: "i1" };
        if (k === ts7.SyntaxKind.LessThanToken)
          return { id: b.cmp("lt", "f64", l.id, r.id), type: "i1" };
        if (k === ts7.SyntaxKind.LessThanEqualsToken)
          return { id: b.cmp("le", "f64", l.id, r.id), type: "i1" };
        if (k === ts7.SyntaxKind.GreaterThanToken)
          return { id: b.cmp("gt", "f64", l.id, r.id), type: "i1" };
        if (k === ts7.SyntaxKind.GreaterThanEqualsToken)
          return { id: b.cmp("ge", "f64", l.id, r.id), type: "i1" };
      } else {
        if (k === ts7.SyntaxKind.AmpersandAmpersandToken)
          return { id: b.binop("and", "i1", l.id, r.id), type: "i1" };
        if (k === ts7.SyntaxKind.BarBarToken)
          return { id: b.binop("or", "i1", l.id, r.id), type: "i1" };
        if (k === ts7.SyntaxKind.EqualsEqualsEqualsToken)
          return { id: b.cmp("eq", "i1", l.id, r.id), type: "i1" };
        if (k === ts7.SyntaxKind.ExclamationEqualsEqualsToken)
          return { id: b.cmp("ne", "i1", l.id, r.id), type: "i1" };
      }
      return void 0;
    }
    if (ts7.isConditionalExpression(e)) {
      const c = lowerExpr(e.condition);
      const t = lowerExpr(e.whenTrue);
      const f2 = lowerExpr(e.whenFalse);
      if (!c || c.type !== "i1" || !t || !f2 || t.type !== f2.type) return void 0;
      return { id: b.select(t.type, c.id, t.id, f2.id), type: t.type };
    }
    return void 0;
  };
  let blockIdx = 0;
  let terminated = false;
  for (const stmt of fn.body.statements) {
    if (terminated) break;
    if (ts7.isVariableStatement(stmt)) {
      for (const decl of stmt.declarationList.declarations) {
        if (!ts7.isIdentifier(decl.name) || !decl.initializer) return void 0;
        const val = lowerExpr(decl.initializer);
        if (!val) return void 0;
        env.set(decl.name.text, val);
      }
    } else if (ts7.isIfStatement(stmt)) {
      const cond = lowerExpr(stmt.expression);
      if (!cond || cond.type !== "i1") return void 0;
      const thenRet = ts7.isReturnStatement(stmt.thenStatement) && stmt.thenStatement.expression ? stmt.thenStatement.expression : ts7.isBlock(stmt.thenStatement) && stmt.thenStatement.statements.length === 1 && ts7.isReturnStatement(stmt.thenStatement.statements[0]) && stmt.thenStatement.statements[0].expression ? stmt.thenStatement.statements[0].expression : void 0;
      if (!thenRet) return void 0;
      const id2 = blockIdx++;
      const thenBlk = b.createBlock(`if_then_${id2}`);
      const elseBlk = b.createBlock(`if_else_${id2}`);
      b.condbr(cond.id, thenBlk.label, elseBlk.label);
      b.positionAt(thenBlk);
      const tv = lowerExpr(thenRet);
      if (!tv || tv.type !== retType) return void 0;
      b.ret(tv.id);
      b.positionAt(elseBlk);
      if (stmt.elseStatement) {
        const other = stmt.elseStatement;
        const elseRet = ts7.isReturnStatement(other) ? other.expression : ts7.isBlock(other) && other.statements.length === 1 && ts7.isReturnStatement(other.statements[0]) ? other.statements[0].expression : void 0;
        if (!elseRet) return void 0;
        const fv = lowerExpr(elseRet);
        if (!fv || fv.type !== retType) return void 0;
        b.ret(fv.id);
        terminated = true;
      }
    } else if (ts7.isReturnStatement(stmt) && stmt.expression) {
      const rv = lowerExpr(stmt.expression);
      if (!rv || rv.type !== retType) return void 0;
      b.ret(rv.id);
      terminated = true;
    } else {
      return void 0;
    }
  }
  if (!terminated) return void 0;
  return b.build();
}

// packages/compiler/src/frontend/actions.ts
import ts8 from "typescript";
var binaryOperators = /* @__PURE__ */ new Map([
  [ts8.SyntaxKind.PlusToken, "+"],
  [ts8.SyntaxKind.MinusToken, "-"],
  [ts8.SyntaxKind.AsteriskToken, "*"],
  [ts8.SyntaxKind.SlashToken, "/"],
  [ts8.SyntaxKind.PercentToken, "%"],
  [ts8.SyntaxKind.EqualsEqualsEqualsToken, "==="],
  [ts8.SyntaxKind.ExclamationEqualsEqualsToken, "!=="],
  [ts8.SyntaxKind.LessThanToken, "<"],
  [ts8.SyntaxKind.LessThanEqualsToken, "<="],
  [ts8.SyntaxKind.GreaterThanToken, ">"],
  [ts8.SyntaxKind.GreaterThanEqualsToken, ">="],
  [ts8.SyntaxKind.AmpersandAmpersandToken, "&&"],
  [ts8.SyntaxKind.BarBarToken, "||"],
  [ts8.SyntaxKind.QuestionQuestionToken, "??"]
]);
function childScope(parent) {
  return {
    locals: new Map(parent.locals),
    props: new Map(parent.props),
    runs: new Set(parent.runs),
    states: new Map(parent.states),
    initializationPoints: parent.initializationPoints
  };
}
function lowerActionBody(fn, bindings) {
  if (!fn.body) return { ok: false, node: fn, message: "Callback has no implementation body." };
  const unsupportedParameter = fn.parameters.find(
    (parameter) => !ts8.isIdentifier(parameter.name) || parameter.dotDotDotToken || parameter.initializer
  );
  if (unsupportedParameter)
    return {
      ok: false,
      node: unsupportedParameter,
      message: "Callback parameter defaults, destructuring and rest require explicit argument semantics."
    };
  if (fn.modifiers?.some((modifier) => modifier.kind === ts8.SyntaxKind.AsyncKeyword) || fn.asteriskToken)
    return {
      ok: false,
      node: fn,
      message: "Asynchronous and generator callbacks require separate action semantics."
    };
  let failure;
  let nextLocal = 0;
  let budget = 4096;
  const active = /* @__PURE__ */ new Set();
  const reject = (node, message) => {
    failure ??= { node, message };
    return void 0;
  };
  const symbol = (node) => bindings.checker.getSymbolAtLocation(node);
  const propsSource = (raw, scope) => {
    const expression = unwrapExpr(raw);
    if (ts8.isIdentifier(expression)) return scope.props.get(symbol(expression));
    if (!ts8.isCallExpression(expression) || expression.arguments.length || !ts8.isPropertyAccessExpression(expression.expression) || expression.expression.name.text !== "get")
      return void 0;
    const props = unwrapExpr(expression.expression.expression);
    if (ts8.isPropertyAccessExpression(props) && props.name.text === "props" && ts8.isIdentifier(props.expression) && scope.runs.has(symbol(props.expression)))
      return "current";
    return void 0;
  };
  const value = (expression, scope) => {
    if (--budget < 0)
      return reject(expression, "Action expansion exceeded its finite lowering budget.");
    const expr = unwrapExpr(expression);
    if (ts8.isIdentifier(expr) && scope.locals.has(symbol(expr)))
      return { kind: "local", name: scope.locals.get(symbol(expr)) };
    if (ts8.isPropertyAccessExpression(expr)) {
      const source = propsSource(expr.expression, scope);
      if (source) return { kind: "prop", name: expr.name.text, source };
    }
    if (ts8.isCallExpression(expr) && ts8.isPropertyAccessExpression(expr.expression)) {
      const recv = unwrapExpr(expr.expression.expression);
      if (ts8.isIdentifier(recv) && expr.expression.name.text === "get" && expr.arguments.length === 0) {
        const state = scope.states.get(symbol(recv));
        if (state !== void 0) return { kind: "state", name: state };
      }
    }
    if (ts8.isPrefixUnaryExpression(expr)) {
      const operator = expr.operator === ts8.SyntaxKind.ExclamationToken ? "!" : expr.operator === ts8.SyntaxKind.MinusToken ? "-" : expr.operator === ts8.SyntaxKind.PlusToken ? "+" : void 0;
      const operand = operator ? value(expr.operand, scope) : void 0;
      if (operator && operand) return { kind: "unary", operator, operand };
      return reject(expr, "Unsupported unary action expression.");
    }
    if (ts8.isBinaryExpression(expr)) {
      const operator = binaryOperators.get(expr.operatorToken.kind);
      if (!operator)
        return reject(
          expr,
          "Unsupported action operator; source coercion is not silently changed."
        );
      const left = value(expr.left, scope), right = value(expr.right, scope);
      return left && right ? { kind: "binary", operator, left, right } : void 0;
    }
    if (ts8.isConditionalExpression(expr)) {
      const condition = value(expr.condition, scope), then = value(expr.whenTrue, scope), otherwise = value(expr.whenFalse, scope);
      return condition && then && otherwise ? { kind: "conditional", condition, then, otherwise } : void 0;
    }
    const literal = bindings.constant(expr, scope.initializationPoints);
    if (literal !== void 0) return { kind: "literal", value: literal };
    return reject(
      expr,
      "Action value has no semantic lowering; no source text or callback is copied to the target."
    );
  };
  const bindAlias = (binding, raw, scope, target) => {
    const expression = unwrapExpr(raw);
    const props = propsSource(expression, scope);
    if (props) {
      target.props.set(binding, props);
      return true;
    }
    if (ts8.isIdentifier(expression)) {
      const source = symbol(expression);
      if (scope.runs.has(source)) {
        target.runs.add(binding);
        return true;
      }
      const state = scope.states.get(source);
      if (state !== void 0) {
        target.states.set(binding, state);
        return true;
      }
    }
    return false;
  };
  const action = (expression, scope) => {
    const expr = unwrapExpr(expression);
    if (!ts8.isCallExpression(expr))
      return reject(expr, "Callback operation has no target-independent lowering.");
    if (ts8.isPropertyAccessExpression(expr.expression)) {
      const receiver = unwrapExpr(expr.expression.expression);
      if (ts8.isIdentifier(receiver)) {
        if (scope.runs.has(symbol(receiver)) && expr.expression.name.text === "update") {
          if (expr.arguments.length)
            return reject(
              expr,
              "run.update() takes no arguments; argument effects cannot be discarded."
            );
          return [{ kind: "request-update" }];
        }
        const stateName = scope.states.get(symbol(receiver));
        if (stateName !== void 0 && expr.expression.name.text === "set" && expr.arguments.length >= 1 && expr.arguments.length <= 2) {
          if (expr.arguments[1] && typeof bindings.constant(expr.arguments[1], scope.initializationPoints) !== "string")
            return reject(
              expr.arguments[1],
              "A state reason must be a proven static string; its evaluation cannot be discarded."
            );
          const next = value(expr.arguments[0], scope);
          return next ? [{ kind: "state-set", stateName, value: next }] : void 0;
        }
      }
    }
    const callPoints = atExecutionPoint(expr, scope.initializationPoints);
    const helper = resolveFunctionLike(expr.expression, bindings.checker, callPoints);
    if (!helper?.body)
      return reject(expr, "Callback operation has no target-independent lowering.");
    if (active.has(helper))
      return reject(expr, "Recursive action helpers require an explicit call representation.");
    if (helper.modifiers?.some((modifier) => modifier.kind === ts8.SyntaxKind.AsyncKeyword) || helper.asteriskToken)
      return reject(expr, "Asynchronous and generator helpers require separate action semantics.");
    if (expr.arguments.length > helper.parameters.length || helper.parameters.some(
      (parameter) => !ts8.isIdentifier(parameter.name) || parameter.dotDotDotToken
    ))
      return reject(expr, "Helper arguments must bind to explicit positional parameters.");
    const local = { ...childScope(scope), initializationPoints: callPoints };
    const prefix = [];
    for (let index = 0; index < helper.parameters.length; index++) {
      const parameter = helper.parameters[index];
      const argument = expr.arguments[index] ?? parameter.initializer;
      if (!argument)
        return reject(
          parameter,
          "Missing helper arguments require an explicit undefined representation."
        );
      const binding = symbol(parameter.name);
      const argumentScope = expr.arguments[index] ? scope : local;
      if (bindAlias(binding, argument, argumentScope, local)) continue;
      const initial = value(argument, argumentScope);
      if (!initial) return void 0;
      const name = "local" + nextLocal++;
      local.locals.set(binding, name);
      prefix.push({ kind: "local", name, value: initial });
    }
    active.add(helper);
    const body2 = ts8.isBlock(helper.body) ? statements(helper.body.statements, local) : action(helper.body, local);
    active.delete(helper);
    return body2 ? [{ kind: "invoke", body: [...prefix, ...body2] }] : void 0;
  };
  const statements = (nodes, outer) => {
    const scope = childScope(outer);
    const result = [];
    for (const node of nodes) {
      if (--budget < 0)
        return reject(node, "Action expansion exceeded its finite lowering budget.");
      if (ts8.isEmptyStatement(node) || ts8.isFunctionDeclaration(node)) continue;
      if (ts8.isBlock(node)) {
        const nested = statements(node.statements, scope);
        if (!nested) return void 0;
        result.push(...nested);
      } else if (ts8.isVariableStatement(node)) {
        if (!(node.declarationList.flags & ts8.NodeFlags.Const))
          return reject(node, "Mutable local bindings require explicit assignment lowering.");
        for (const declaration of node.declarationList.declarations) {
          if (!ts8.isIdentifier(declaration.name) || !declaration.initializer)
            return reject(declaration, "Action bindings must have an explicit initializer.");
          if (ts8.isArrowFunction(unwrapExpr(declaration.initializer)) || ts8.isFunctionExpression(unwrapExpr(declaration.initializer)))
            continue;
          const binding = symbol(declaration.name);
          if (bindAlias(binding, declaration.initializer, scope, scope)) continue;
          const initial = value(declaration.initializer, scope);
          if (!initial) return void 0;
          const name = "local" + nextLocal++;
          scope.locals.set(binding, name);
          result.push({ kind: "local", name, value: initial });
        }
      } else if (ts8.isExpressionStatement(node)) {
        const lowered = action(node.expression, scope);
        if (!lowered) return void 0;
        result.push(...lowered);
      } else if (ts8.isIfStatement(node)) {
        const condition = value(node.expression, scope);
        const then = statements(
          ts8.isBlock(node.thenStatement) ? node.thenStatement.statements : [node.thenStatement],
          scope
        );
        const otherwise = node.elseStatement ? statements(
          ts8.isBlock(node.elseStatement) ? node.elseStatement.statements : [node.elseStatement],
          scope
        ) : [];
        if (!condition || !then || !otherwise) return void 0;
        result.push({ kind: "if", condition, then, otherwise });
      } else if (ts8.isReturnStatement(node)) {
        if (node.expression) {
          const returned = unwrapExpr(node.expression);
          if (ts8.isCallExpression(returned)) {
            const lowered = action(returned, scope);
            if (!lowered) return void 0;
            result.push(...lowered);
          } else if (!value(returned, scope)) return void 0;
        }
        result.push({ kind: "return" });
        break;
      } else
        return reject(
          node,
          "Statement has no action lowering; the compiler will not drop control flow or effects."
        );
    }
    return result;
  };
  const root = {
    locals: /* @__PURE__ */ new Map(),
    props: /* @__PURE__ */ new Map(),
    runs: /* @__PURE__ */ new Set(),
    states: new Map(bindings.states),
    initializationPoints: bindings.initializationPoints ?? /* @__PURE__ */ new Map()
  };
  for (const parameter of fn.parameters) {
    if (!ts8.isIdentifier(parameter.name)) continue;
    const binding = symbol(parameter.name);
    if (parameter.name.text === bindings.runParameter) root.runs.add(binding);
    const props = bindings.propParameters?.get(parameter.name.text);
    if (props) root.props.set(binding, props);
  }
  active.add(fn);
  const body = ts8.isBlock(fn.body) ? statements(fn.body.statements, root) : action(fn.body, root);
  return body ? { ok: true, body } : { ok: false, ...failure ?? { node: fn, message: "Action lowering failed." } };
}

// packages/compiler/src/frontend/extract.ts
var BUILTIN_HOOK_NAMES = /* @__PURE__ */ new Set([
  "asTrigger",
  "asFocusable",
  "asFocusEntry",
  "asFocusScope",
  "asFocusRoving",
  "asAccessible",
  "asControlLabel",
  "asAnatomy",
  "asCollection",
  "asCollectionItem",
  "asOverlay",
  "asBoundary",
  "asHitParticipation",
  "asPositioning",
  "asScrollSurface",
  "asTextControl",
  "asImageView",
  "asTableStructure",
  "asNativeLink",
  "asAxisInput",
  "asPresence"
]);
var LIFECYCLE_METHODS = /* @__PURE__ */ new Set([
  "onCreated",
  "onMounted",
  "onUpdated",
  "onUnmounted",
  "onBeforeDispose"
]);
function extractModuleIR(program, entryPath, options = {}) {
  const diagnostics = [];
  const sf = program.getSourceFile(entryPath);
  if (!sf) {
    return {
      ir: {
        irVersion: PROTO_IR_VERSION,
        sourceFile: entryPath,
        prototypes: [],
        authoredHooks: [],
        functions: []
      },
      diagnostics: [
        diagnostic(
          "PUI_FE001",
          "input",
          `Source file not found in TypeScript program: ${entryPath}`
        )
      ]
    };
  }
  const checker = program.getTypeChecker();
  if (options.checkTypes !== false) {
    const tsDiags = [...program.getSyntacticDiagnostics(sf), ...program.getSemanticDiagnostics(sf)];
    for (const d of tsDiags) {
      const msg = ts9.flattenDiagnosticMessageText(d.messageText, "\n");
      const sp = d.file && d.start !== void 0 ? (() => {
        const lc = d.file.getLineAndCharacterOfPosition(d.start);
        return { file: d.file.fileName, line: lc.line + 1, column: lc.character + 1 };
      })() : void 0;
      diagnostics.push(diagnostic(`TS${d.code}`, "typecheck", msg, sp));
    }
  }
  const prototypes = [];
  const authoredHooks = [];
  const moduleFunctions = [];
  for (const stmt of sf.statements) {
    if (ts9.isFunctionDeclaration(stmt)) {
      const lowered = tryLowerPureScalarFunction(stmt, checker);
      if (lowered) moduleFunctions.push(lowered);
    }
  }
  const moduleSym = checker.getSymbolAtLocation(sf);
  const exportsList = moduleSym ? checker.getExportsOfModule(moduleSym) : [];
  const seenCalls = /* @__PURE__ */ new Map();
  for (const expSym of exportsList) {
    const expName = expSym.getName();
    if (options.exportName && expName !== options.exportName) continue;
    const target = resolveAliasedSymbol(checker, expSym);
    const decl = target?.valueDeclaration ?? target?.declarations?.[0];
    if (!decl) continue;
    let initExpr;
    if (ts9.isExportAssignment(decl)) initExpr = decl.expression;
    else if (ts9.isVariableDeclaration(decl) && decl.initializer) initExpr = decl.initializer;
    if (!initExpr) continue;
    const found = findFactoryCall(initExpr, checker, [
      "definePrototype",
      "defineAsHook",
      "defineHook"
    ]);
    if (!found) {
      const value = unwrapExpr(initExpr);
      if (isPrototypeType(value, checker)) {
        const partial = ts9.isCallExpression(value) ? extractPrototype(value, expName, expName === "default", sf.fileName, checker) : {
          name: expName,
          exportName: expName,
          isDefaultExport: expName === "default",
          sourceFile: sf.fileName,
          span: spanOf(value, sf),
          tier: "static",
          props: [],
          states: [],
          exposes: [],
          events: [],
          hooks: [],
          contexts: [],
          staticStyleTokens: [],
          rules: [],
          lifecycle: [],
          render: { kind: "default-slot" },
          capabilities: [],
          capabilityMask: 0n,
          functions: [],
          stringTable: []
        };
        prototypes.push({
          ...partial,
          unlowered: [
            ...partial.unlowered ?? [],
            {
              operation: "prototype-factory",
              message: "The prototype-producing call has no proven factory lowering; its declaration remains in coverage.",
              span: spanOf(value, sf)
            }
          ]
        });
      }
      continue;
    }
    if (found.factory === "definePrototype") {
      const prior = seenCalls.get(found.call);
      if (prior !== void 0 && !options.exportName) {
        if (expName === "default")
          prototypes[prior] = { ...prototypes[prior], isDefaultExport: true };
        continue;
      }
      seenCalls.set(found.call, prototypes.length);
      const proto = extractPrototype(
        found.call,
        expName,
        expName === "default",
        sf.fileName,
        checker
      );
      if (proto) prototypes.push(proto);
    } else {
      const hookSummary = extractAuthoredHookSummary(found.call, expName, found.factory, checker);
      if (hookSummary) authoredHooks.push(hookSummary);
    }
  }
  if (prototypes.length === 0 && authoredHooks.length === 0 && !options.exportName) {
    for (const stmt of sf.statements) {
      if (ts9.isExportAssignment(stmt)) {
        const found = findFactoryCall(stmt.expression, checker, ["definePrototype"]);
        if (found) {
          const proto = extractPrototype(found.call, "default", true, sf.fileName, checker);
          if (proto) prototypes.push(proto);
        }
      }
    }
  }
  const moduleEffects = [
    ...collectModuleEffects(sf, checker),
    ...collectImportedModuleEffects(sf, checker)
  ];
  if (moduleEffects.length) {
    for (let index = 0; index < prototypes.length; index++)
      prototypes[index] = {
        ...prototypes[index],
        unlowered: [...moduleEffects, ...prototypes[index].unlowered ?? []]
      };
  }
  return {
    ir: {
      irVersion: PROTO_IR_VERSION,
      sourceFile: sf.fileName,
      prototypes,
      authoredHooks,
      functions: moduleFunctions
    },
    diagnostics
  };
}
function collectModuleEffects(sf, checker) {
  const activeInitializers = /* @__PURE__ */ new Set();
  const pureInitializer = (raw, inheritedPoints = /* @__PURE__ */ new Map()) => {
    const value = unwrapExpr(raw);
    const points = atExecutionPoint(value, inheritedPoints);
    if (evaluateStaticScalar(value, checker, /* @__PURE__ */ new Map(), points) !== void 0 || ts9.isArrowFunction(value) || ts9.isFunctionExpression(value))
      return true;
    if (ts9.isIdentifier(value)) {
      const binding = resolveAliasedSymbol(checker, checker.getSymbolAtLocation(value));
      const declaration = binding?.valueDeclaration ?? binding?.declarations?.[0];
      if (!binding || !declaration || !isBindingInitialized(declaration, points, checker))
        return false;
      if (ts9.isFunctionDeclaration(declaration))
        return !!declaration.body && !hasBindingWrites(binding, checker);
      if (!ts9.isVariableDeclaration(declaration) || !isConstDeclaration(declaration) || !declaration.initializer || activeInitializers.has(declaration))
        return false;
      activeInitializers.add(declaration);
      const result = pureInitializer(declaration.initializer, points);
      activeInitializers.delete(declaration);
      return result;
    }
    if (ts9.isArrayLiteralExpression(value))
      return value.elements.every(
        (element) => !ts9.isSpreadElement(element) && pureInitializer(element, points)
      );
    if (ts9.isObjectLiteralExpression(value))
      return value.properties.every(
        (field) => (ts9.isMethodDeclaration(field) || ts9.isGetAccessorDeclaration(field) || ts9.isSetAccessorDeclaration(field)) && !ts9.isComputedPropertyName(field.name) || ts9.isShorthandPropertyAssignment(field) && pureInitializer(field.name, points) || ts9.isPropertyAssignment(field) && !ts9.isComputedPropertyName(field.name) && pureInitializer(field.initializer, points)
      );
    const intrinsic = ts9.isCallExpression(value) || ts9.isPropertyAccessExpression(value) ? resolveCallName(
      ts9.isCallExpression(value) ? value.expression : value,
      checker,
      /* @__PURE__ */ new Set(),
      points
    ) : void 0;
    if (!intrinsic || !isCoreIntrinsic(intrinsic) || !["definePrototype", "defineAsHook", "defineHook"].includes(intrinsic.name))
      return false;
    if (!ts9.isCallExpression(value)) return true;
    if (value.arguments.length !== 1 || !value.arguments.every((argument) => pureInitializer(argument, points)))
      return false;
    const definition = resolveDefinitionObject(value.arguments[0], checker, points);
    if (!definition) return false;
    const name = extractObjectProperty(definition, "name");
    const nameValue = name && evaluateStaticScalar(name, checker, /* @__PURE__ */ new Map(), points);
    if (typeof nameValue !== "string" || !nameValue || !extractSetupFunction(definition, checker, points))
      return false;
    const modules = extractObjectProperty(definition, "modules");
    if (modules && (!ts9.isArrayLiteralExpression(unwrapExpr(modules)) || unwrapExpr(modules).elements.length))
      return false;
    return !definition.properties.some(
      (field) => ts9.isGetAccessorDeclaration(field) || ts9.isSetAccessorDeclaration(field) || ts9.isSpreadAssignment(field)
    );
  };
  return sf.statements.filter((statement) => {
    if (ts9.canHaveModifiers(statement) && ts9.getModifiers(statement)?.some((modifier) => modifier.kind === ts9.SyntaxKind.DeclareKeyword))
      return false;
    if (ts9.isExpressionStatement(statement)) return !ts9.isStringLiteral(statement.expression);
    if (ts9.isExportAssignment(statement)) return !pureInitializer(statement.expression);
    if (ts9.isVariableStatement(statement))
      return statement.declarationList.declarations.some(
        (declaration) => !ts9.isIdentifier(declaration.name) || declaration.initializer && !pureInitializer(declaration.initializer)
      );
    if (ts9.isImportDeclaration(statement)) return !statement.importClause;
    return !(ts9.isFunctionDeclaration(statement) || ts9.isInterfaceDeclaration(statement) || ts9.isTypeAliasDeclaration(statement) || ts9.isExportDeclaration(statement) || ts9.isEmptyStatement(statement));
  }).map((statement) => ({
    operation: "module-effect",
    message: "Top-level executable effects require explicit module-initialization lowering.",
    span: spanOf(statement, sf)
  }));
}
function collectImportedModuleEffects(sf, checker) {
  const checked = /* @__PURE__ */ new Set([sf]);
  const issues = [];
  const visit = (source) => {
    for (const statement of source.statements) {
      if (!ts9.isImportDeclaration(statement) && !ts9.isExportDeclaration(statement) || !statement.moduleSpecifier || ts9.isExportDeclaration(statement) && statement.isTypeOnly)
        continue;
      if (ts9.isImportDeclaration(statement) && statement.importClause?.isTypeOnly) continue;
      if (ts9.isImportDeclaration(statement) && !statement.importClause?.name && statement.importClause?.namedBindings && ts9.isNamedImports(statement.importClause.namedBindings) && statement.importClause.namedBindings.elements.every((element) => element.isTypeOnly))
        continue;
      if (ts9.isExportDeclaration(statement) && statement.exportClause && ts9.isNamedExports(statement.exportClause) && statement.exportClause.elements.every((element) => element.isTypeOnly))
        continue;
      const binding = checker.getSymbolAtLocation(statement.moduleSpecifier);
      const imported = binding?.declarations?.find(ts9.isSourceFile);
      if (!imported || checked.has(imported) || imported.isDeclarationFile || isCoreIntrinsic({ sourceFile: imported.fileName }))
        continue;
      checked.add(imported);
      issues.push(...collectModuleEffects(imported, checker));
      visit(imported);
    }
  };
  visit(sf);
  return issues;
}
function extractAuthoredHookSummary(call2, exportName, factory, checker) {
  const arg = call2.arguments[0] ? resolveDefinitionObject(call2.arguments[0], checker) : void 0;
  if (!arg)
    return {
      name: exportName,
      exportName,
      kind: factory === "defineAsHook" ? "as-hook" : "hook",
      sourceFile: call2.getSourceFile().fileName,
      capabilities: []
    };
  const nameExpr = extractObjectProperty(arg, "name");
  const nameLit = nameExpr ? extractScalarLiteral(nameExpr, checker) : void 0;
  const name = typeof nameLit === "string" ? nameLit : exportName;
  const setupFn = extractSetupFunction(arg, checker);
  const proto = setupFn ? analyzeSetup(setupFn, name, exportName, false, call2.getSourceFile().fileName, call2, checker) : void 0;
  return {
    name,
    exportName,
    kind: factory === "defineAsHook" ? "as-hook" : "hook",
    sourceFile: call2.getSourceFile().fileName,
    capabilities: proto?.capabilities ?? []
  };
}
function extractPrototype(call2, exportName, isDefaultExport, entryFile, checker) {
  const arg = call2.arguments[0] ? resolveDefinitionObject(call2.arguments[0], checker) : void 0;
  const definitionGaps = [];
  const definitionGap = (node, operation, message) => definitionGaps.push({ operation, message, span: spanOf(node, node.getSourceFile()) });
  if (!arg)
    definitionGap(
      call2,
      "prototype-options",
      "Definition options cannot be resolved without evaluating dynamic code; the declaration remains in coverage."
    );
  if (call2.arguments.length !== 1)
    definitionGap(call2, "prototype-options", "Unexpected definition arguments require lowering.");
  for (const field of arg?.properties ?? []) {
    if (!("name" in field) || !field.name || !ts9.isIdentifier(field.name) && !ts9.isStringLiteral(field.name) || !["name", "setup"].includes(field.name.text))
      definitionGap(
        field,
        "prototype-options",
        "Definition field requires explicit semantic lowering."
      );
  }
  const nameExpr = arg ? extractObjectProperty(arg, "name") : void 0;
  const nameLit = nameExpr ? extractScalarLiteral(nameExpr, checker) : void 0;
  const name = typeof nameLit === "string" ? nameLit : exportName;
  if (typeof nameLit !== "string" || !nameLit)
    definitionGap(
      nameExpr ?? call2,
      "prototype-name",
      "Prototype name must be a non-empty proven static string."
    );
  const setupFn = arg ? extractSetupFunction(arg, checker) : void 0;
  const setupField = arg?.properties.find(
    (field) => "name" in field && field.name && (ts9.isIdentifier(field.name) || ts9.isStringLiteral(field.name)) && field.name.text === "setup"
  );
  if (!setupFn)
    definitionGap(
      setupField ?? call2,
      "prototype-setup",
      "The required setup implementation could not be resolved."
    );
  const propsTypeText = call2.typeArguments?.[0]?.getText(call2.getSourceFile());
  const exposesTypeText = call2.typeArguments?.[1]?.getText(call2.getSourceFile());
  if (!setupFn) {
    const base = {
      name,
      exportName,
      isDefaultExport,
      sourceFile: entryFile,
      span: spanOf(call2, call2.getSourceFile()),
      tier: "static",
      propsTypeText,
      exposesTypeText,
      props: [],
      states: [],
      exposes: [],
      events: [],
      hooks: [],
      contexts: [],
      staticStyleTokens: [],
      rules: [],
      lifecycle: [],
      render: { kind: "default-slot" },
      functions: [],
      stringTable: [],
      unlowered: definitionGaps
    };
    return { ...base, ...computePrototypeCapabilities(base) };
  }
  const result = analyzeSetup(
    setupFn,
    name,
    exportName,
    isDefaultExport,
    entryFile,
    call2,
    checker,
    propsTypeText,
    exposesTypeText
  );
  return { ...result, unlowered: [...definitionGaps, ...result.unlowered ?? []] };
}
function analyzeSetup(setupFn, name, exportName, isDefaultExport, entryFile, originCall, checker, propsTypeText, exposesTypeText) {
  const propsMap = /* @__PURE__ */ new Map();
  const states = [];
  const stateVarToName = /* @__PURE__ */ new Map();
  const exposes = [];
  const events = [];
  const hooks = [];
  const contexts = [];
  const staticStyleTokens = [];
  const rules = [];
  const lifecycle = /* @__PURE__ */ new Set();
  const lifecycleHandlers = [];
  const propWatches = [];
  const stringTable = [];
  const unlowered = [];
  const gap = (node, operation, message) => {
    unlowered.push({ operation, message, span: spanOf(node, node.getSourceFile()) });
  };
  const renderBox = { current: { kind: "default-slot" } };
  const acceptsDefault = (declaration, value) => {
    if (value === null) return declaration.empty !== "error";
    if (typeof value === "number" && !Number.isFinite(value)) return false;
    if (declaration.kind === "enum") {
      if (typeof value !== "string" || !declaration.options?.includes(value)) return false;
    } else if (declaration.kind !== "any" && typeof value !== declaration.kind) return false;
    return !declaration.range || typeof value === "number" && (declaration.range.min === void 0 || value >= declaration.range.min) && (declaration.range.max === void 0 || value <= declaration.range.max);
  };
  const activeFns = /* @__PURE__ */ new Set();
  const hookResults = /* @__PURE__ */ new Map();
  const hookBindings = /* @__PURE__ */ new Map();
  const recordContextCall = (method, keyArg) => {
    const mode = method === "provide" ? "provide" : method.includes("Subscribe") || method === "subscribe" ? "subscribe" : method.includes("Update") || method === "update" ? "update" : "read";
    const keyName = keyArg ? keyArg.getText(keyArg.getSourceFile()) : "unknown";
    contexts.push({ keyName, mode });
  };
  const scanRunCallback = (cb) => {
    if (!cb?.body) return;
    const p0 = cb.parameters[0];
    const runName = p0 && ts9.isIdentifier(p0.name) ? p0.name.text : void 0;
    if (!runName) return;
    const scan = (n) => {
      if (ts9.isCallExpression(n)) {
        const ch = propAccessChain(n.expression);
        if (ch && ch[0] === runName && ch[1] === "context" && ch.length >= 3) {
          recordContextCall(ch.slice(2).join("."), n.arguments[0]);
        }
      }
      ts9.forEachChild(n, scan);
    };
    scan(cb.body);
  };
  const walkFunction = (fn, defParamName, constants = /* @__PURE__ */ new Map(), discardedHelperReturn = false, initializationPoints = /* @__PURE__ */ new Map()) => {
    const boundConstants = new Map(constants);
    const scalar2 = (expression, points = initializationPoints) => evaluateStaticScalar(expression, checker, boundConstants, points);
    let functionRender;
    if (!fn.body) {
      gap(fn, "setup", "Setup implementation is not available.");
      return;
    }
    if (activeFns.has(fn)) {
      gap(
        fn,
        "setup-composition",
        "Recursive setup composition cannot be expanded into a finite declaration sequence."
      );
      return;
    }
    activeFns.add(fn);
    const p0 = fn.parameters[0];
    const defName = defParamName ?? (p0 && ts9.isIdentifier(p0.name) ? p0.name.text : void 0);
    const defBinding = fn.parameters.find(
      (parameter) => ts9.isIdentifier(parameter.name) && parameter.name.text === defName
    );
    const defSymbol = defBinding && checker.getSymbolAtLocation(defBinding.name);
    const defAliases = new Set(defSymbol ? [defSymbol] : []);
    for (const parameter of fn.parameters) {
      if (!ts9.isIdentifier(parameter.name) || parameter.dotDotDotToken) {
        gap(
          parameter,
          "setup-binding",
          "Setup parameter destructuring and rest bindings require explicit lowering."
        );
        continue;
      }
      const binding = checker.getSymbolAtLocation(parameter.name);
      if (binding === defSymbol || boundConstants.has(binding) || !parameter.initializer) continue;
      const initial = scalar2(parameter.initializer);
      if (initial === void 0)
        gap(
          parameter.initializer,
          "setup-binding",
          "Default parameter effects and values require explicit lowering."
        );
      else boundConstants.set(binding, initial);
    }
    const rootBinding = (expression) => {
      let root = unwrapExpr(expression);
      while (ts9.isPropertyAccessExpression(root)) root = unwrapExpr(root.expression);
      return ts9.isIdentifier(root) ? checker.getSymbolAtLocation(root) : void 0;
    };
    let returned = false;
    const captureReturn = (expression, node) => {
      const returnedValue = unwrapExpr(expression);
      if (ts9.isPropertyAccessExpression(returnedValue) && ts9.isIdentifier(returnedValue.expression) && returnedValue.name.text === "render") {
        const result = hookBindings.get(checker.getSymbolAtLocation(returnedValue.expression));
        if (result) {
          functionRender = result.render;
          return;
        }
      }
      const returnPoints = atExecutionPoint(node, initializationPoints);
      const retFn = resolveFunctionLike(expression, checker, returnPoints);
      if (retFn && retFn.body) {
        if (retFn.parameters.length > 1 || retFn.parameters.some(
          (parameter) => !ts9.isIdentifier(parameter.name) || parameter.dotDotDotToken
        )) {
          gap(
            retFn,
            "render",
            "Render parameter destructuring, rest and additional defaults require explicit binding semantics."
          );
          return;
        }
        if (retFn.modifiers?.some((modifier) => modifier.kind === ts9.SyntaxKind.AsyncKeyword) || retFn.asteriskToken) {
          gap(
            retFn,
            "render",
            "Asynchronous and generator render functions require separate execution semantics."
          );
          return;
        }
        const rp = retFn.parameters[0];
        const renderParam = rp && ts9.isIdentifier(rp.name) ? rp.name.text : "r";
        const bodyExpr = !ts9.isBlock(retFn.body) ? retFn.body : retFn.body.statements.length === 1 && ts9.isReturnStatement(retFn.body.statements[0]) && retFn.body.statements[0].expression ? retFn.body.statements[0].expression : void 0;
        if (bodyExpr) {
          const parsed = parseTemplateChild(
            bodyExpr,
            renderParam,
            stateVarToName,
            checker,
            (expression2) => scalar2(expression2, returnPoints),
            returnPoints
          );
          const only = parsed?.children.length === 1 ? parsed.children[0] : void 0;
          functionRender = !parsed ? { kind: "dynamic" } : only?.kind === "slot" ? { kind: "default-slot" } : only?.kind === "element" ? { kind: parsed.reactive ? "reactive-tree" : "static-tree", root: only.node } : { kind: "fragment", children: parsed.children };
        } else {
          functionRender = { kind: "dynamic" };
        }
      } else if (!isKnownUndefined(expression, checker) && (!discardedHelperReturn || scalar2(expression) === void 0)) {
        gap(
          node,
          "setup-return",
          "A returned value requires explicit function or hook-result lowering."
        );
      }
    };
    const visit = (node) => {
      if (returned) return;
      if (node !== fn && ts9.isFunctionLike(node)) return;
      if (ts9.isBlock(node)) {
        for (const statement of node.statements) {
          if (returned) break;
          visit(statement);
        }
        return;
      }
      if (ts9.isReturnStatement(node)) returned = true;
      if (ts9.isVariableDeclaration(node) && !ts9.isIdentifier(node.name)) {
        gap(
          node,
          "setup-binding",
          "Destructuring requires explicit binding and property-access lowering."
        );
        return;
      }
      if (ts9.isExpressionStatement(node) && !ts9.isCallExpression(unwrapExpr(node.expression))) {
        gap(node, "setup-effect", "This setup effect has no semantic lowering.");
        return;
      }
      if (ts9.isIfStatement(node)) {
        const condition = scalar2(node.expression);
        if (condition === void 0)
          gap(
            node,
            "setup-control-flow",
            "Dynamic setup branches require conditional declaration semantics."
          );
        else {
          const selected = condition ? node.thenStatement : node.elseStatement;
          if (selected) visit(selected);
        }
        return;
      }
      if (ts9.isIterationStatement(node, false) || ts9.isSwitchStatement(node) || ts9.isTryStatement(node) || ts9.isThrowStatement(node)) {
        gap(
          node,
          "setup-control-flow",
          "Dynamic setup control flow is retained as an unsupported operation; declarations are not hoisted out of branches."
        );
        return;
      }
      if (ts9.isVariableDeclaration(node) && ts9.isIdentifier(node.name) && node.initializer) {
        const initial = unwrapExpr(node.initializer);
        if (ts9.isIdentifier(initial) && defAliases.has(checker.getSymbolAtLocation(initial))) {
          defAliases.add(checker.getSymbolAtLocation(node.name));
          return;
        }
        if (ts9.isIdentifier(initial) && stateVarToName.has(checker.getSymbolAtLocation(initial))) {
          stateVarToName.set(
            checker.getSymbolAtLocation(node.name),
            stateVarToName.get(checker.getSymbolAtLocation(initial))
          );
          return;
        }
        if (!ts9.isCallExpression(initial) && !ts9.isArrowFunction(initial) && !ts9.isFunctionExpression(initial) && scalar2(initial) === void 0) {
          gap(node, "setup-binding", "The local binding initializer has no semantic lowering.");
          return;
        }
      }
      if (ts9.isReturnStatement(node) && node.expression) {
        captureReturn(node.expression, node);
        return;
      }
      if (ts9.isReturnStatement(node)) {
        if (node.expression && scalar2(node.expression) === void 0)
          gap(node, "setup-return", "A helper return value requires explicit lowering.");
        return;
      }
      if (ts9.isCallExpression(node)) {
        const callPoints = atExecutionPoint(node, initializationPoints);
        const chain = propAccessChain(node.expression);
        if (chain && defAliases.has(rootBinding(node.expression))) {
          const sub = chain.slice(1).join(".");
          if (sub === "props.define" && node.arguments[0]) {
            if (node.arguments.length !== 1)
              gap(node, sub, "Unexpected declaration arguments cannot be discarded.");
            const obj = unwrapExpr(node.arguments[0]);
            if (ts9.isObjectLiteralExpression(obj)) {
              for (const p of obj.properties) {
                if (!ts9.isPropertyAssignment(p)) {
                  gap(p, sub, "Property declarations must be explicit named fields.");
                  continue;
                }
                const key = ts9.isIdentifier(p.name) || ts9.isStringLiteral(p.name) ? p.name.text : void 0;
                if (!key) {
                  gap(p, sub, "Computed property names need explicit lowering.");
                  continue;
                }
                const spec = unwrapExpr(p.initializer);
                let kind = "any";
                let defaultValue;
                let empty;
                let options;
                let range;
                if (ts9.isObjectLiteralExpression(spec)) {
                  const typeExpr = extractObjectProperty(spec, "type");
                  const typeLit = typeExpr ? scalar2(typeExpr) : void 0;
                  if (typeLit === "boolean" || typeLit === "number" || typeLit === "string" || typeLit === "enum" || typeLit === "object" || typeLit === "any") {
                    kind = typeLit;
                  }
                  const defExpr = extractObjectProperty(spec, "default");
                  if (defExpr) {
                    defaultValue = scalar2(defExpr);
                    if (defaultValue === void 0)
                      gap(defExpr, sub, "Property default is not a proven static scalar.");
                  }
                  const emptyExpr = extractObjectProperty(spec, "empty");
                  const emptyLit = emptyExpr ? scalar2(emptyExpr) : void 0;
                  if (emptyLit === "accept" || emptyLit === "fallback" || emptyLit === "error") {
                    empty = emptyLit;
                  } else if (emptyExpr)
                    gap(emptyExpr, sub, "Empty behavior must be statically known.");
                  const optExpr = extractObjectProperty(spec, "options");
                  if (optExpr && ts9.isArrayLiteralExpression(unwrapExpr(optExpr))) {
                    options = unwrapExpr(optExpr).elements.map((el) => scalar2(el)).filter((v) => v !== void 0);
                    if (options.length !== unwrapExpr(optExpr).elements.length)
                      gap(optExpr, sub, "Every enum option must be a proven scalar.");
                  } else if (optExpr)
                    gap(optExpr, sub, "Property options require an explicit scalar array.");
                  const rangeExpr = extractObjectProperty(spec, "range");
                  if (rangeExpr && ts9.isObjectLiteralExpression(unwrapExpr(rangeExpr))) {
                    const limits = unwrapExpr(rangeExpr);
                    if (limits.properties.some(
                      (field) => !ts9.isPropertyAssignment(field) || !ts9.isIdentifier(field.name) && !ts9.isStringLiteral(field.name) || !["min", "max"].includes(field.name.text)
                    ))
                      gap(rangeExpr, sub, "Every range field must have explicit lowering.");
                    const minExpr = extractObjectProperty(limits, "min");
                    const maxExpr = extractObjectProperty(limits, "max");
                    const min = minExpr ? scalar2(minExpr) : void 0;
                    const max = maxExpr ? scalar2(maxExpr) : void 0;
                    if (minExpr && typeof min !== "number" || maxExpr && typeof max !== "number")
                      gap(rangeExpr, sub, "Property range bounds must be static numbers.");
                    range = {
                      ...typeof min === "number" ? { min } : {},
                      ...typeof max === "number" ? { max } : {}
                    };
                  } else if (rangeExpr)
                    gap(rangeExpr, sub, "Property range must be statically available.");
                  for (const field of spec.properties) {
                    if (!ts9.isPropertyAssignment(field) || !ts9.isIdentifier(field.name) && !ts9.isStringLiteral(field.name) || !["type", "default", "empty", "options", "range"].includes(field.name.text)) {
                      gap(field, sub, "Property configuration has no semantic lowering.");
                    }
                  }
                } else gap(spec, sub, "Property specification must be statically available.");
                const tsType = kind === "enum" && options?.length ? options.map((v) => JSON.stringify(v)).join(" | ") : kind === "object" ? "Record<string, unknown>" : kind === "any" ? "unknown" : kind;
                if (!propsMap.has(key)) {
                  propsMap.set(key, {
                    index: propsMap.size,
                    name: key,
                    tsType,
                    kind,
                    ...defaultValue !== void 0 ? { defaultValue } : {},
                    ...options ? { options } : {},
                    ...empty ? { empty } : {},
                    ...range ? { range } : {},
                    ssaType: propKindToSsaType(kind)
                  });
                } else
                  gap(p, sub, "Repeated property definitions require declaration merge lowering.");
              }
            } else gap(obj, sub, "Dynamic props declarations require explicit lowering.");
          } else if (sub === "props.setDefaults" && node.arguments[0]) {
            if (node.arguments.length !== 1)
              gap(node, sub, "Unexpected default arguments cannot be discarded.");
            const obj = unwrapExpr(node.arguments[0]);
            if (ts9.isObjectLiteralExpression(obj)) {
              for (const p of obj.properties) {
                if (!ts9.isPropertyAssignment(p)) {
                  gap(p, sub, "Defaults must be explicit named fields.");
                  continue;
                }
                const key = ts9.isIdentifier(p.name) || ts9.isStringLiteral(p.name) ? p.name.text : void 0;
                if (!key) {
                  gap(p, sub, "Computed default names require lowering.");
                  continue;
                }
                const existing = propsMap.get(key);
                const val = scalar2(p.initializer);
                if (existing && val !== void 0) {
                  if (typeof val === "number" && !Number.isFinite(val)) {
                    gap(p, sub, "Defaults must be JSON scalar values.");
                  } else if (acceptsDefault(existing, val)) {
                    propsMap.set(key, { ...existing, defaultValue: val });
                  }
                } else
                  gap(
                    p,
                    sub,
                    "Defaults must target a declared property and have a proven scalar value."
                  );
              }
            } else gap(obj, sub, "Dynamic defaults require explicit lowering.");
          } else if (sub === "state.bool" || sub === "state.string" || sub === "state.enum" || sub === "state.numberDiscrete" || sub === "state.numberRange") {
            if (node.arguments.length < 2 || node.arguments.length > 3)
              gap(node, sub, "Unexpected state declaration arguments cannot be discarded.");
            const nameLit = node.arguments[0] ? scalar2(node.arguments[0]) : void 0;
            const initLit = node.arguments[1] ? scalar2(node.arguments[1]) : void 0;
            const kindMap = {
              "state.bool": "bool",
              "state.string": "string",
              "state.enum": "enum",
              "state.numberDiscrete": "number.discrete",
              "state.numberRange": "number.range"
            };
            const kind = kindMap[sub];
            if (typeof nameLit !== "string")
              gap(node, sub, "State semantic must be a proven static string.");
            if (initLit === void 0)
              gap(node, sub, "State initializer has no proven value or expression lowering.");
            if (typeof initLit === "string") internString(stringTable, initLit);
            const stateName = typeof nameLit === "string" ? nameLit : "";
            if (states.some((s) => s.name === stateName))
              gap(node, sub, "Repeated state names require explicit identity resolution.");
            const stateSpec = {};
            const specArg = node.arguments[2] && unwrapExpr(node.arguments[2]);
            if (specArg) {
              if (ts9.isObjectLiteralExpression(specArg)) {
                for (const field of specArg.properties) {
                  if (!ts9.isPropertyAssignment(field) || !ts9.isIdentifier(field.name) && !ts9.isStringLiteral(field.name)) {
                    gap(field, sub, "State specification must use explicit fields.");
                    continue;
                  }
                  const key = field.name.text;
                  const init = unwrapExpr(field.initializer);
                  if (key === "options" && ts9.isArrayLiteralExpression(init)) {
                    const values = init.elements.map((e) => scalar2(e));
                    if (values.some((v) => v === void 0))
                      gap(field, sub, "State options must be static scalar values.");
                    else stateSpec.options = values;
                  } else {
                    const v = scalar2(init);
                    if (["min", "max", "step"].includes(key) && typeof v === "number")
                      stateSpec[key] = v;
                    else if (key === "clamp" && typeof v === "boolean") stateSpec.clamp = v;
                    else gap(field, sub, "State specification field is not lowered.");
                  }
                }
              } else gap(specArg, sub, "Dynamic state specifications are not lowered.");
            }
            let variableName;
            if (ts9.isVariableDeclaration(node.parent) && ts9.isIdentifier(node.parent.name)) {
              variableName = node.parent.name.text;
              stateVarToName.set(checker.getSymbolAtLocation(node.parent.name), stateName);
            }
            states.push({
              index: states.length,
              name: stateName,
              variableName,
              kind,
              ...initLit !== void 0 ? { initialValue: initLit } : {},
              ...stateSpec,
              ssaType: stateKindToSsaType(kind)
            });
          } else if (sub === "expose.state" || sub === "expose.event" || sub === "expose.method" || sub === "expose.value") {
            const keyLit = node.arguments[0] ? scalar2(node.arguments[0]) : void 0;
            if (typeof keyLit === "string") {
              const kind = sub.slice("expose.".length);
              const valType = node.arguments[1] ? checker.typeToString(checker.getTypeAtLocation(node.arguments[1])) : "void";
              exposes.push({ name: keyLit, kind, tsType: valType });
            }
          } else if (sub.startsWith("props.watch")) {
            if (node.arguments.length !== (sub === "props.watch" ? 2 : 1))
              gap(node, sub, "Unexpected watcher arguments cannot be discarded.");
            const cbArg = node.arguments[node.arguments.length - 1];
            const handler = cbArg ? resolveFunctionLike(cbArg, checker, callPoints) : void 0;
            scanRunCallback(handler);
            if (sub !== "props.watch" && sub !== "props.watchAll") {
              gap(
                node,
                sub,
                "Raw property subscriptions require a raw snapshot and metadata lowering."
              );
            } else {
              let keys = sub === "props.watchAll" ? null : void 0;
              const keysArg = node.arguments[0] && unwrapExpr(node.arguments[0]);
              if (sub === "props.watch" && keysArg && ts9.isArrayLiteralExpression(keysArg)) {
                const values = keysArg.elements.map((key) => scalar2(key));
                if (values.every((key) => typeof key === "string")) keys = values;
              }
              const propParameters = /* @__PURE__ */ new Map();
              if (handler?.parameters[1] && ts9.isIdentifier(handler.parameters[1].name))
                propParameters.set(handler.parameters[1].name.text, "current");
              if (handler?.parameters[2] && ts9.isIdentifier(handler.parameters[2].name))
                propParameters.set(handler.parameters[2].name.text, "previous");
              const lowered = handler ? lowerActionBody(handler, {
                states: stateVarToName,
                checker,
                runParameter: handler.parameters[0] && ts9.isIdentifier(handler.parameters[0].name) ? handler.parameters[0].name.text : void 0,
                propParameters,
                constant: scalar2,
                initializationPoints: callPoints
              }) : void 0;
              if (keys === void 0 || keys?.some((key) => !propsMap.has(key)))
                gap(node, sub, "A watcher must select static declared property keys.");
              else if (!lowered?.ok)
                gap(
                  lowered && !lowered.ok ? lowered.node : node,
                  sub,
                  lowered && !lowered.ok ? lowered.message : "Watcher callback is unavailable."
                );
              else propWatches.push({ keys, body: lowered.body });
            }
          } else if (sub === "event.on" || sub === "event.onGlobal") {
            if (node.arguments.length !== 2)
              gap(node, sub, "Event options need explicit host lowering.");
            const evLit = node.arguments[0] ? scalar2(node.arguments[0]) : void 0;
            if (typeof evLit === "string") {
              const handler = node.arguments[1] ? resolveFunctionLike(node.arguments[1], checker, callPoints) : void 0;
              scanRunCallback(handler);
              const simpleAction = handler ? detectSimpleEventAction(handler, stateVarToName, checker) : void 0;
              const action = handler ? lowerActionBody(handler, {
                states: stateVarToName,
                checker,
                runParameter: handler.parameters[0] && ts9.isIdentifier(handler.parameters[0].name) ? handler.parameters[0].name.text : void 0,
                constant: scalar2,
                initializationPoints: callPoints
              }) : void 0;
              if (!action?.ok)
                gap(
                  action && !action.ok ? action.node : node,
                  sub,
                  action && !action.ok ? action.message : "Event callback body is unavailable."
                );
              events.push({
                scope: sub === "event.onGlobal" ? "global" : "root",
                eventName: evLit,
                ...simpleAction ? { simpleAction } : {},
                ...action?.ok ? { body: action.body } : {}
              });
            } else gap(node, sub, "Event identity must be a static supported name.");
          } else if (sub.startsWith("lifecycle.")) {
            if (node.arguments.length !== 1)
              gap(node, sub, "Unexpected lifecycle arguments cannot be discarded.");
            const method = sub.slice("lifecycle.".length);
            if (LIFECYCLE_METHODS.has(method)) lifecycle.add(method);
            const cbArg = node.arguments[0];
            const handler = cbArg ? resolveFunctionLike(cbArg, checker, callPoints) : void 0;
            scanRunCallback(handler);
            const lowered = handler ? lowerActionBody(handler, {
              states: stateVarToName,
              checker,
              runParameter: handler.parameters[0] && ts9.isIdentifier(handler.parameters[0].name) ? handler.parameters[0].name.text : void 0,
              constant: scalar2,
              initializationPoints: callPoints
            }) : void 0;
            const phases = {
              onCreated: "created",
              onMounted: "mounted",
              onUpdated: "updated",
              onUnmounted: "unmounted",
              onBeforeDispose: "before-dispose"
            };
            if (!LIFECYCLE_METHODS.has(method)) gap(node, sub, "Lifecycle phase is unknown.");
            else if (!lowered?.ok)
              gap(
                lowered && !lowered.ok ? lowered.node : node,
                sub,
                lowered && !lowered.ok ? lowered.message : "Lifecycle callback is unavailable."
              );
            else lifecycleHandlers.push({ phase: phases[method], body: lowered.body });
          } else if (sub.startsWith("context.")) {
            const method = sub.slice("context.".length);
            recordContextCall(method, node.arguments[0]);
            if (node.arguments[1])
              scanRunCallback(resolveFunctionLike(node.arguments[1], checker, callPoints));
          } else if (sub === "feedback.style.use") {
            for (const a of node.arguments) {
              if (!collectTwTokens(a, checker, staticStyleTokens, scalar2, callPoints))
                gap(
                  a,
                  sub,
                  "Style values must have explicit semantic lowering; dynamic expressions are not flattened."
                );
            }
          } else if (sub === "rule" && node.arguments[0]) {
            if (node.arguments.length !== 1)
              gap(node, sub, "Unexpected rule arguments cannot be discarded.");
            const obj = unwrapExpr(node.arguments[0]);
            if (ts9.isObjectLiteralExpression(obj)) {
              const whenExpr = extractObjectProperty(obj, "when");
              const intentExpr = extractObjectProperty(obj, "intent");
              const styleTokens = [];
              if (!intentExpr || !collectRuleStyleTokens(
                intentExpr,
                checker,
                styleTokens,
                (expression) => scalar2(expression, callPoints),
                callPoints
              )) {
                gap(
                  intentExpr ?? obj,
                  sub,
                  "The rule intent must lower every operation and effect."
                );
              }
              for (const field of obj.properties) {
                if (!ts9.isPropertyAssignment(field) || !ts9.isIdentifier(field.name) && !ts9.isStringLiteral(field.name) || !["when", "intent"].includes(field.name.text))
                  gap(field, sub, "Rule configuration has no semantic lowering.");
              }
              let condition = { kind: "true" };
              let dynamic = false;
              if (whenExpr) {
                const whenFn = resolveFunctionLike(whenExpr, checker, callPoints);
                if (whenFn && whenFn.body && !whenFn.asteriskToken && !whenFn.modifiers?.some(
                  (modifier) => modifier.kind === ts9.SyntaxKind.AsyncKeyword
                ) && whenFn.parameters.length <= 1 && whenFn.parameters.every(
                  (parameter) => ts9.isIdentifier(parameter.name) && !parameter.initializer && !parameter.dotDotDotToken
                )) {
                  const wp = whenFn.parameters[0];
                  const wName = wp && ts9.isIdentifier(wp.name) ? wp.name.text : "w";
                  const bodyExpr = !ts9.isBlock(whenFn.body) ? whenFn.body : whenFn.body.statements.length === 1 && ts9.isReturnStatement(whenFn.body.statements[0]) && whenFn.body.statements[0].expression ? whenFn.body.statements[0].expression : void 0;
                  const parsed = bodyExpr ? parseRuleCondition(
                    bodyExpr,
                    wName,
                    stateVarToName,
                    checker,
                    (expression) => scalar2(expression, callPoints)
                  ) : void 0;
                  if (parsed) condition = parsed;
                  else dynamic = true;
                } else {
                  dynamic = true;
                }
              }
              rules.push({
                id: rules.length,
                condition,
                styleTokens,
                ...dynamic ? { dynamic: true } : {}
              });
            } else gap(obj, sub, "Rule declaration must be statically available.");
          } else {
            gap(node, sub, "This Proto operation has no semantic lowering.");
          }
          return;
        }
        const resolved = resolveCallName(node.expression, checker, /* @__PURE__ */ new Set(), callPoints);
        const hookFactory = findFactoryCall(
          node.expression,
          checker,
          ["defineAsHook", "defineHook"],
          /* @__PURE__ */ new Set(),
          callPoints
        );
        if (hookFactory) {
          const gapStart = unlowered.length;
          const hookArg = hookFactory.call.arguments[0] ? resolveDefinitionObject(hookFactory.call.arguments[0], checker, callPoints) : void 0;
          const nameExpression = hookArg && extractObjectProperty(hookArg, "name");
          const hookName = nameExpression && scalar2(nameExpression);
          const nestedSetup = hookArg && extractSetupFunction(hookArg, checker, callPoints);
          if (hookFactory.call.arguments.length !== 1 || !hookArg || typeof hookName !== "string" || !nestedSetup) {
            gap(
              node,
              "hook-composition",
              "Hook identity and setup must resolve to a canonical authored definition."
            );
            hooks.push({ name: resolved?.name ?? "unknown", kind: "authored" });
            return;
          }
          for (const field of hookArg.properties) {
            if (ts9.isGetAccessorDeclaration(field) || ts9.isSetAccessorDeclaration(field) || ts9.isSpreadAssignment(field)) {
              gap(
                field,
                "hook-composition",
                "Hook definition accessors and spreads require explicit effect lowering."
              );
              continue;
            }
            const key = "name" in field && field.name && (ts9.isIdentifier(field.name) || ts9.isStringLiteral(field.name)) ? field.name.text : void 0;
            if (key === "name" || key === "setup" || key === "mode") continue;
            const modules = key === "modules" ? extractObjectProperty(hookArg, "modules") : void 0;
            if (modules && ts9.isArrayLiteralExpression(unwrapExpr(modules)) && unwrapExpr(modules).elements.length === 0)
              continue;
            gap(
              field,
              "hook-composition",
              "Hook configuration, projected handles and module declarations require explicit lowering."
            );
          }
          const modeExpression = extractObjectProperty(hookArg, "mode");
          if (modeExpression && scalar2(modeExpression) !== "once")
            gap(
              modeExpression,
              "hook-composition",
              "Configurable and multiple hooks require their own registration semantics."
            );
          if (node.arguments.length > (hookFactory.factory === "defineAsHook" ? 0 : 1))
            gap(node, "hook-composition", "Unexpected hook arguments cannot be omitted.");
          const childConstants = new Map(boundConstants);
          for (const argument of node.arguments)
            if (scalar2(argument) === void 0)
              gap(
                argument,
                "hook-composition",
                "Hook options require proven static argument binding."
              );
          const optionsParameter = nestedSetup.parameters[1];
          if (hookFactory.factory === "defineHook" && optionsParameter) {
            const argument = node.arguments[0] ?? optionsParameter.initializer;
            const value = argument && scalar2(argument);
            if (argument && value !== void 0 && ts9.isIdentifier(optionsParameter.name))
              childConstants.set(checker.getSymbolAtLocation(optionsParameter.name), value);
          }
          let result = hookResults.get(hookName);
          if (!result) {
            result = { lowered: false };
            hookResults.set(hookName, result);
            result.render = walkFunction(nestedSetup, void 0, childConstants, false, callPoints);
            result.lowered = unlowered.length === gapStart;
          }
          const lowered = result.lowered && unlowered.length === gapStart;
          hooks.push({
            name: resolved?.name ?? hookName,
            moduleSpecifier: resolved?.sourceFile,
            kind: "authored",
            lowered
          });
          if (ts9.isVariableDeclaration(node.parent) && ts9.isIdentifier(node.parent.name))
            hookBindings.set(checker.getSymbolAtLocation(node.parent.name), result);
        } else if (resolved && BUILTIN_HOOK_NAMES.has(resolved.name)) {
          hooks.push({
            name: resolved.name,
            moduleSpecifier: resolved.sourceFile,
            kind: "builtin"
          });
        } else if (defName && node.arguments.some(
          (argument) => ts9.isIdentifier(unwrapExpr(argument)) && defAliases.has(checker.getSymbolAtLocation(unwrapExpr(argument)))
        )) {
          const helperFn = resolveFunctionLike(node.expression, checker, callPoints);
          if (!helperFn) {
            gap(node, "setup-composition", "Setup helper implementation could not be resolved.");
            return;
          }
          const defArgIdx = node.arguments.findIndex(
            (argument) => ts9.isIdentifier(unwrapExpr(argument)) && defAliases.has(checker.getSymbolAtLocation(unwrapExpr(argument)))
          );
          const targetParam = helperFn.parameters[defArgIdx];
          if (!targetParam || !ts9.isIdentifier(targetParam.name) || node.arguments.length > helperFn.parameters.length || helperFn.parameters.some(
            (parameter) => !ts9.isIdentifier(parameter.name) || parameter.dotDotDotToken
          )) {
            gap(
              node,
              "setup-composition",
              "Setup helper parameters require explicit scalar and definition-handle bindings."
            );
            return;
          }
          const childConstants = new Map(boundConstants);
          let bound = true;
          for (let index = 0; index < helperFn.parameters.length; index++) {
            if (index === defArgIdx) continue;
            const parameter = helperFn.parameters[index];
            const argument = node.arguments[index] ?? parameter.initializer;
            const value = argument && evaluateStaticScalar(argument, checker, childConstants, callPoints);
            if (argument && value !== void 0)
              childConstants.set(checker.getSymbolAtLocation(parameter.name), value);
            else if (argument) {
              gap(
                argument,
                "setup-composition",
                "A helper argument requires a proven static value before declaration expansion."
              );
              bound = false;
            }
          }
          if (bound)
            walkFunction(helperFn, targetParam.name.text, childConstants, true, callPoints);
        } else if (scalar2(node) === void 0) {
          gap(node, resolved?.name ?? "call", "Setup call has no lowering and cannot be omitted.");
        }
        return;
      }
      ts9.forEachChild(node, visit);
    };
    try {
      if (fn.modifiers?.some((modifier) => modifier.kind === ts9.SyntaxKind.AsyncKeyword) || fn.asteriskToken)
        gap(
          fn,
          "setup",
          "Asynchronous and generator setup bodies require separate execution semantics."
        );
      else if (ts9.isBlock(fn.body)) visit(fn.body);
      else captureReturn(fn.body, fn);
      return functionRender;
    } finally {
      activeFns.delete(fn);
    }
  };
  renderBox.current = walkFunction(setupFn) ?? { kind: "default-slot" };
  const props = [...propsMap.values()];
  const protoSym = sanitizeSym(name);
  const functions = [];
  for (const rule of rules) {
    const needsHostMeta = (condition) => condition.kind === "cmp" ? condition.source === "meta" : condition.kind === "not" ? needsHostMeta(condition.expr) : condition.kind === "all" || condition.kind === "any" ? condition.exprs.some(needsHostMeta) : false;
    if (needsHostMeta(rule.condition))
      gap(
        originCall,
        "rule.meta",
        "Host meta must be an explicit kernel input; it cannot be replaced with false."
      );
    if (!rule.dynamic && !needsHostMeta(rule.condition)) {
      functions.push(lowerRuleToSsa(protoSym, rule, props, states, stringTable));
    }
  }
  const compiledRules = rules.filter(
    (r) => functions.some((f2) => f2.name === `${protoSym}_rule_${r.id}`)
  );
  if (compiledRules.length > 0) {
    functions.push(lowerCombinedRuleMask(protoSym, compiledRules));
  }
  functions.push(...lowerEventActionsToSsa(protoSym, events, states, stringTable));
  const render = renderBox.current;
  const tier = props.length || states.length || events.length || lifecycle.size || propWatches.length || rules.length ? "reactive" : "static";
  const partial = {
    name,
    exportName,
    isDefaultExport,
    sourceFile: entryFile,
    span: spanOf(originCall, originCall.getSourceFile()),
    tier,
    propsTypeText,
    exposesTypeText,
    props,
    states,
    exposes,
    events,
    hooks,
    contexts,
    staticStyleTokens,
    rules,
    lifecycle: [...lifecycle],
    lifecycleHandlers,
    propWatches,
    render,
    functions,
    stringTable,
    unlowered
  };
  return {
    ...partial,
    ...computePrototypeCapabilities(partial)
  };
}

// packages/compiler/src/llvm/toolchain.ts
import { spawnSync } from "node:child_process";
import fs2 from "node:fs";
import os from "node:os";
import path3 from "node:path";
import { createHash } from "node:crypto";

// packages/compiler/src/native-assets.ts
import path2 from "node:path";
import { fileURLToPath } from "node:url";
function resolveCompilerNativeAsset(asset) {
  const relativeBase = false ? "../native/" : "./native/";
  return path2.resolve(path2.dirname(fileURLToPath(import.meta.url)), relativeBase, asset);
}

// packages/compiler/src/llvm/toolchain.ts
function findBinary(name) {
  const candidates = path3.isAbsolute(name) ? [name] : (process.env.PATH ?? "").split(path3.delimiter).filter(Boolean).map((dir) => path3.join(dir, name));
  for (const candidate of candidates) {
    try {
      fs2.accessSync(candidate, fs2.constants.X_OK);
      if (fs2.statSync(candidate).isFile()) return candidate;
    } catch {
    }
  }
  return void 0;
}
var cachedToolchain;
function detectLlvmToolchain(forceRefresh = false) {
  if (cachedToolchain && !forceRefresh) return cachedToolchain;
  const opt = findBinary("opt");
  const llc = findBinary("llc");
  const llvmAs = findBinary("llvm-as");
  const wasmLd = findBinary("wasm-ld");
  const llvmConfig = findBinary(process.env.PUI_LLVM_CONFIG ?? "llvm-config");
  let version;
  if (llvmConfig) {
    const v = spawnSync(llvmConfig, ["--version"], { encoding: "utf8" });
    if (v.status === 0) version = v.stdout.trim();
  } else if (opt) {
    const v = spawnSync(opt, ["--version"], { encoding: "utf8" });
    const m = v.stdout.match(/LLVM version\s+([^\s]+)/);
    if (m) version = m[1];
  }
  cachedToolchain = {
    available: Boolean(opt),
    version,
    opt,
    llc,
    llvmAs,
    wasmLd,
    llvmConfig
  };
  return cachedToolchain;
}
function verifyLlvmIr(ll) {
  const tc = detectLlvmToolchain();
  if (!tc.opt) {
    return err([
      diagnostic(
        "PUI_LLVM001",
        "llvm",
        "LLVM `opt` binary not found on PATH; cannot verify LLVM IR."
      )
    ]);
  }
  const res = spawnSync(tc.opt, ["-passes=verify", "-disable-output"], {
    input: ll,
    encoding: "utf8"
  });
  if (res.status !== 0) {
    return err([
      diagnostic(
        "PUI_LLVM002",
        "llvm",
        `LLVM IR verification failed:
${(res.stderr || res.stdout).trim()}`
      )
    ]);
  }
  return ok({ verified: true, version: tc.version });
}
function optimizeLlvmIr(ll, options = {}) {
  const tc = detectLlvmToolchain();
  if (!tc.opt) {
    return err([
      diagnostic(
        "PUI_LLVM001",
        "llvm",
        "LLVM `opt` binary not found on PATH; cannot optimize LLVM IR."
      )
    ]);
  }
  const passes = options.passes ?? `verify,default<${options.level ?? "O2"}>`;
  const res = spawnSync(tc.opt, ["-S", `-passes=${passes}`], {
    input: ll,
    encoding: "utf8"
  });
  if (res.status !== 0) {
    return err([
      diagnostic(
        "PUI_LLVM003",
        "llvm",
        `LLVM opt (${passes}) failed:
${(res.stderr || res.stdout).trim()}`
      )
    ]);
  }
  const out = res.stdout;
  return ok({
    ir: out,
    passes,
    linesBefore: ll.split("\n").length,
    linesAfter: out.split("\n").length
  });
}
function compileLlvmToObject(ll, options = {}) {
  const tc = detectLlvmToolchain();
  if (!tc.llc) {
    return err([diagnostic("PUI_LLVM001", "llvm", "LLVM `llc` binary not found on PATH.")]);
  }
  const args = ["-filetype=obj", `-O${options.optLevel ?? "2"}`];
  if (options.targetTriple) args.push(`-mtriple=${options.targetTriple}`);
  const res = spawnSync(tc.llc, args, { input: Buffer.from(ll, "utf8") });
  if (res.status !== 0) {
    return err([
      diagnostic(
        "PUI_LLVM006",
        "llvm",
        `llc object emission failed:
${res.stderr.toString("utf8").trim()}`
      )
    ]);
  }
  return ok(new Uint8Array(res.stdout));
}
function compileLlvmToWasm(ll, options = {}) {
  const tc = detectLlvmToolchain();
  if (!tc.opt || !tc.llc || !tc.wasmLd) {
    return err([
      diagnostic(
        "PUI_LLVM001",
        "llvm",
        "Compiling to WebAssembly requires LLVM `opt`, `llc`, and `wasm-ld` on PATH."
      )
    ]);
  }
  const optRes = optimizeLlvmIr(ll, { level: options.level ?? "O2" });
  if (!optRes.ok) return optRes;
  const objRes = compileLlvmToObject(optRes.value.ir, {
    targetTriple: "wasm32-unknown-unknown",
    optLevel: "2"
  });
  if (!objRes.ok) return objRes;
  const tmpDir = fs2.mkdtempSync(path3.join(os.tmpdir(), "pui-llvm-wasm-"));
  try {
    const objPath = path3.join(tmpDir, "module.o");
    const wasmPath = path3.join(tmpDir, "module.wasm");
    fs2.writeFileSync(objPath, objRes.value);
    const link = spawnSync(
      tc.wasmLd,
      ["--no-entry", "--export-all", "--allow-undefined", "-o", wasmPath, objPath],
      { encoding: "utf8" }
    );
    if (link.status !== 0) {
      return err([
        diagnostic(
          "PUI_LLVM007",
          "llvm",
          `wasm-ld link failed:
${(link.stderr || link.stdout).trim()}`
        )
      ]);
    }
    const wasm = new Uint8Array(fs2.readFileSync(wasmPath));
    return ok({ wasm, optimizedIr: optRes.value.ir });
  } finally {
    fs2.rmSync(tmpDir, { recursive: true, force: true });
  }
}
function configArguments(output) {
  const result = [];
  let token = "";
  let quote = "";
  let escaped = false;
  for (const character of output.trim()) {
    if (escaped) {
      token += character;
      escaped = false;
      continue;
    }
    if (character === "\\" && quote !== "'") {
      escaped = true;
      continue;
    }
    if (quote) {
      if (character === quote) quote = "";
      else token += character;
    } else if (character === '"' || character === "'") {
      quote = character;
    } else if (/\s/.test(character)) {
      if (token) result.push(token);
      token = "";
    } else token += character;
  }
  if (quote || escaped) throw new Error("llvm-config returned malformed quoted arguments.");
  if (token) result.push(token);
  return result;
}
function llvmBuilderBinary() {
  const tc = detectLlvmToolchain();
  const cxx = findBinary(process.env.PUI_LLVM_CXX ?? "clang++") ?? findBinary("g++") ?? findBinary("c++");
  if (!tc.llvmConfig || !cxx || !tc.version?.startsWith("22.")) {
    return err([
      diagnostic(
        "PUI_LLVM_BUILDER001",
        "llvm",
        "LLVM emission requires the LLVM 22 development SDK (llvm-config, headers and shared library) and a C++ compiler. No textual emitter fallback is available."
      )
    ]);
  }
  const sourcePath = resolveCompilerNativeAsset("llvm-builder.cpp");
  if (!fs2.existsSync(sourcePath)) {
    return err([
      diagnostic(
        "PUI_LLVM_BUILDER001",
        "llvm",
        "The native LLVM builder source is missing from this compiler installation."
      )
    ]);
  }
  const config = spawnSync(
    tc.llvmConfig,
    ["--cxxflags", "--ldflags", "--link-shared", "--libs", "all", "--system-libs"],
    { encoding: "utf8", timeout: 1e4, maxBuffer: 1024 * 1024 }
  );
  const libdir = spawnSync(tc.llvmConfig, ["--libdir"], { encoding: "utf8", timeout: 1e4 });
  const identity = spawnSync(cxx, ["--version"], { encoding: "utf8", timeout: 1e4 });
  if (config.status !== 0 || libdir.status !== 0 || identity.status !== 0) {
    return err([
      diagnostic(
        "PUI_LLVM_BUILDER001",
        "llvm",
        "Cannot inspect the LLVM development SDK and C++ compiler: " + [config.stderr, libdir.stderr, identity.stderr].filter(Boolean).join("\n")
      )
    ]);
  }
  let flags;
  try {
    flags = configArguments(config.stdout).filter((flag) => flag !== "-fno-exceptions");
  } catch (error) {
    return err([diagnostic("PUI_LLVM_BUILDER001", "llvm", String(error))]);
  }
  const digest = createHash("sha256").update(fs2.readFileSync(sourcePath)).update(JSON.stringify({ cxx, identity: identity.stdout, version: tc.version, flags })).digest("hex");
  const cacheDir = path3.join(os.tmpdir(), "pui-llvm-builder", digest);
  const binaryPath = path3.join(
    cacheDir,
    process.platform === "win32" ? "llvm-builder.exe" : "llvm-builder"
  );
  if (fs2.existsSync(binaryPath)) return ok(binaryPath);
  fs2.mkdirSync(cacheDir, { recursive: true });
  const buildDir = fs2.mkdtempSync(path3.join(cacheDir, "build-"));
  const temporaryBinary = path3.join(buildDir, "llvm-builder");
  try {
    const args = [
      sourcePath,
      "-o",
      temporaryBinary,
      ...flags,
      "-std=c++17",
      "-fexceptions",
      "-O2",
      ...process.platform === "win32" ? [] : ["-Wl,-rpath," + libdir.stdout.trim()]
    ];
    const built = spawnSync(cxx, args, {
      encoding: "utf8",
      timeout: 12e4,
      maxBuffer: 4 * 1024 * 1024
    });
    if (built.status !== 0) {
      return err([
        diagnostic(
          "PUI_LLVM_BUILDER002",
          "llvm",
          "Building the LLVM IRBuilder driver failed: " + (built.stderr || built.stdout || built.error?.message || String(built.signal)).trim()
        )
      ]);
    }
    fs2.renameSync(temporaryBinary, binaryPath);
    return ok(binaryPath);
  } finally {
    fs2.rmSync(buildDir, { recursive: true, force: true });
  }
}
function invokeLlvmBuilder(requestJson) {
  const binary = llvmBuilderBinary();
  if (!binary.ok) return binary;
  const emitted = spawnSync(binary.value, [], {
    input: requestJson,
    encoding: "utf8",
    timeout: 3e4,
    maxBuffer: 16 * 1024 * 1024
  });
  if (emitted.status !== 0) {
    return err([
      diagnostic(
        "PUI_LLVM_BUILDER003",
        "llvm",
        "LLVM could not construct and verify this module: " + (emitted.stderr || emitted.stdout || emitted.error?.message || String(emitted.signal)).trim()
      )
    ]);
  }
  return ok(emitted.stdout);
}

// packages/compiler/src/llvm/emit.ts
function encodeScalar(_key, value) {
  if (typeof value === "bigint") return value.toString();
  if (typeof value === "number") {
    if (Number.isNaN(value)) return { $number: "nan" };
    if (value === Infinity) return { $number: "+infinity" };
    if (value === -Infinity) return { $number: "-infinity" };
    if (Object.is(value, -0)) return { $number: "-zero" };
  }
  return value;
}
function emitLlvmIRResult(mod, options = {}) {
  const issues = verifyModuleIR(mod);
  if (issues.length) return err(issues);
  return invokeLlvmBuilder(
    JSON.stringify(
      {
        protocolVersion: 1,
        targetTriple: options.targetTriple ?? "wasm32-unknown-unknown",
        module: mod
      },
      encodeScalar
    )
  );
}

// packages/compiler/src/targets/react.ts
import ts10 from "typescript";

// packages/core/src/spec/feedback/placeholder.ts
var PLACEHOLDER_COLOR_TOKENS = /* @__PURE__ */ new Set([
  "placeholder:text-foreground",
  "placeholder:text-muted-foreground",
  "placeholder:text-primary",
  "placeholder:text-destructive"
]);
function isPlaceholderColorTokenV0(token) {
  return PLACEHOLDER_COLOR_TOKENS.has(token);
}

// packages/core/src/spec/feedback/semantic-merge.ts
var PREFIXES_V0 = [
  // Color
  "bg-",
  // Spacing
  "p-",
  "px-",
  "py-",
  "pt-",
  "pr-",
  "pb-",
  "pl-",
  "m-",
  "mx-",
  "my-",
  "mt-",
  "mr-",
  "mb-",
  "ml-",
  // Sizing
  "w-",
  "h-",
  "min-w-",
  "min-h-",
  "max-w-",
  "max-h-",
  // Layout
  "justify-",
  "items-",
  "content-",
  // Effects
  "opacity-",
  "shadow-",
  "tracking-",
  "transition-",
  "rounded"
];
var TEXT_SIZE_TOKENS = /* @__PURE__ */ new Set([
  "xs",
  "sm",
  "base",
  "lg",
  "xl",
  "2xl",
  "3xl",
  "4xl",
  "5xl",
  "6xl",
  "7xl",
  "8xl",
  "9xl"
]);
var TEXT_ALIGN_TOKENS = /* @__PURE__ */ new Set(["left", "right", "center", "justify", "start", "end"]);
function getSemanticGroupKeyV0(token) {
  if (token === "-mx-4") return "mx-";
  if (token === "-mb-4") return "mb-";
  if (token === "ease-linear" || token === "ease-in-out") return "transition timing";
  if (token === "box-border" || token === "box-content") return "box sizing";
  if (token === "float-left" || token === "float-right") return "float placement";
  if (token === "text-balance") return "text wrapping";
  if (/^font-(normal|medium|semibold|bold|black|\[100\])$/.test(token)) return "font weight";
  if (token === "border-collapse" || token === "border-separate") return "table border model";
  if (token === "border-spacing-0") return "table border spacing";
  if (token === "caption-bottom") return "table caption side";
  if (token === "align-top" || token === "align-middle" || token === "align-bottom")
    return "vertical alignment";
  const roundedSide = token.match(/^rounded-([trbl])-/);
  if (roundedSide) return `rounded-${roundedSide[1]}-`;
  if (token === "scroll-py-1" || token === "scroll-py-1.5") return "finite scroll padding block";
  if (token === "scroll-my-1" || token === "scroll-my-1.5") return "finite scroll margin block";
  if (isPlaceholderColorTokenV0(token)) return "placeholder:text-color";
  if (/^(?:-z-(?:1|10)|z-(?:10|40|50|\[(?:2|1000|1051)\]))$/.test(token)) return "finite z index";
  if (token === "backdrop-blur-xs" || token === "backdrop-filter-[blur(40px)_saturate(1.5)]")
    return "complete backdrop filter";
  const selectionPrefix = "selection:";
  if (token.startsWith(selectionPrefix)) {
    return `${selectionPrefix}${getSemanticGroupKeyV0(token.slice(selectionPrefix.length))}`;
  }
  if (token === "resize-y" || token === "resize-none") return "field resize affordance";
  if (token === "field-sizing-content" || token === "field-sizing-fixed") {
    return "field intrinsic sizing";
  }
  const translateAxis = token.match(/^-?translate-([xy])-/);
  if (translateAxis) return `translate-${translateAxis[1]}-`;
  if (token === "select-auto" || token === "select-text" || token === "select-none") {
    return "content-selection affordance";
  }
  if (token === "flex" || token === "inline-flex" || token === "block" || token === "inline-block" || token === "table" || token === "table-row" || token === "table-cell" || token === "table-caption") {
    return "display";
  }
  if (token === "flex-row" || token === "flex-row-reverse" || token === "flex-col" || token === "flex-col-reverse") {
    return "flex-direction";
  }
  if (token === "border" || token === "border-0" || token === "border-2" || token === "border-[3px]" || token === "border-4" || token === "border-8") {
    return "border-width";
  }
  const directionalBorderWidth = token.match(/^border-([trblxy])(?:-(0|2|4|8))?$/);
  if (directionalBorderWidth) {
    return `border-${directionalBorderWidth[1]}-width`;
  }
  if (token.startsWith("border-b-")) return "border-b-color";
  if (token.startsWith("border-")) {
    return "border-color";
  }
  if (token.startsWith("bg-clip-")) return "bg-clip-";
  if (token.startsWith("text-")) {
    const suffix = token.slice("text-".length);
    if (TEXT_ALIGN_TOKENS.has(suffix)) return "text-align";
    if (/^\[#[0-9a-fA-F]+\]$/.test(suffix)) return "text-color";
    if (TEXT_SIZE_TOKENS.has(suffix) || suffix.startsWith("[")) return "text-size";
    return "text-color";
  }
  for (const p of PREFIXES_V0) {
    if (token.startsWith(p)) return p;
  }
  return token;
}

// packages/core/src/prototype.ts
var MODULE_DECLARATION_TOKEN_BRAND = Symbol("@proto.ui/module-declaration-token");

// packages/core/src/caps/token.ts
function cap(id2) {
  return { id: id2 };
}

// packages/core/src/caps/host.ts
var HOST_ELEMENT_CAP = cap("@proto.ui/web/hostElement");

// packages/core/src/shader-presentation.ts
var SHADER_PRESENTATION_LIMITS = Object.freeze({
  maxExtent: 1024,
  maxTexels: 262144,
  maxPasses: 16,
  maxResourceBytes: 16 * 1024 * 1024
});

// packages/compiler/src/targets/action-flow.ts
function getUpdateOrderingIssues(body) {
  const issues = /* @__PURE__ */ new Set();
  const merge = (into, source) => {
    for (const value of source) into.add(value);
  };
  const walk = (nodes, incoming) => {
    let normal = new Set(incoming);
    const returned = /* @__PURE__ */ new Set();
    for (const statement of nodes) {
      if (!normal.size) break;
      if (statement.kind === "return") {
        merge(returned, normal);
        normal.clear();
        break;
      }
      if (statement.kind === "request-update") {
        if (normal.has(true))
          issues.add(
            "Multiple update requests on one callback path require native commit scheduling."
          );
        normal = /* @__PURE__ */ new Set([true]);
        continue;
      }
      if (normal.has(true))
        issues.add(
          "An update before later callback operations requires a render snapshot at the request point."
        );
      if (statement.kind === "invoke") {
        const result = walk(statement.body, normal);
        normal = result.normal;
        merge(normal, result.returned);
      } else if (statement.kind === "if") {
        const then = walk(statement.then, normal);
        const otherwise = walk(statement.otherwise, normal);
        normal = then.normal;
        merge(normal, otherwise.normal);
        merge(returned, then.returned);
        merge(returned, otherwise.returned);
      }
    }
    return { normal, returned };
  };
  walk(body, /* @__PURE__ */ new Set([false]));
  return [...issues];
}

// packages/compiler/src/targets/react.ts
var f = ts10.factory;
var id = (name) => f.createIdentifier(name);
var prop = (value, name) => f.createPropertyAccessExpression(value, name);
var item = (value, name) => f.createElementAccessExpression(value, f.createStringLiteral(name));
var call = (value, args = [], types) => f.createCallExpression(value, types, args);
var react = (name, args = [], types) => call(prop(id("React"), name), args, types);
var bin = (left, op, right) => f.createBinaryExpression(left, op, right);
var eq = (a, b) => bin(a, ts10.SyntaxKind.EqualsEqualsEqualsToken, b);
var ne = (a, b) => bin(a, ts10.SyntaxKind.ExclamationEqualsEqualsToken, b);
var and = (a, b) => bin(a, ts10.SyntaxKind.AmpersandAmpersandToken, b);
var or = (a, b) => bin(a, ts10.SyntaxKind.BarBarToken, b);
var not = (value) => f.createPrefixUnaryExpression(ts10.SyntaxKind.ExclamationToken, value);
var assign = (left, right) => f.createExpressionStatement(bin(left, ts10.SyntaxKind.EqualsToken, right));
var block = (statements) => f.createBlock(statements, true);
var reactType = (name) => f.createTypeReferenceNode(f.createQualifiedName(id("React"), name));
var nullable = (type) => f.createUnionTypeNode([type, f.createLiteralTypeNode(f.createNull())]);
function variable(name, init, type, mutable = false) {
  return f.createVariableStatement(
    void 0,
    f.createVariableDeclarationList(
      [f.createVariableDeclaration(name, void 0, type, init)],
      mutable ? ts10.NodeFlags.Let : ts10.NodeFlags.Const
    )
  );
}
function scalar(value) {
  if (value === null) return f.createNull();
  if (typeof value === "boolean") return value ? f.createTrue() : f.createFalse();
  if (typeof value === "string") return f.createStringLiteral(value);
  if (Number.isNaN(value))
    return bin(f.createNumericLiteral(0), ts10.SyntaxKind.SlashToken, f.createNumericLiteral(0));
  if (!Number.isFinite(value)) {
    const infinity = bin(
      f.createNumericLiteral(1),
      ts10.SyntaxKind.SlashToken,
      f.createNumericLiteral(0)
    );
    return value < 0 ? f.createPrefixUnaryExpression(ts10.SyntaxKind.MinusToken, infinity) : infinity;
  }
  if (value < 0 || Object.is(value, -0))
    return f.createPrefixUnaryExpression(ts10.SyntaxKind.MinusToken, f.createNumericLiteral(-value));
  return f.createNumericLiteral(value);
}
function scalarType(kind) {
  switch (kind) {
    case "boolean":
    case "bool":
      return f.createKeywordTypeNode(ts10.SyntaxKind.BooleanKeyword);
    case "number":
    case "number.discrete":
    case "number.range":
      return f.createKeywordTypeNode(ts10.SyntaxKind.NumberKeyword);
    default:
      return f.createKeywordTypeNode(ts10.SyntaxKind.StringKeyword);
  }
}
var DOM_EVENTS = {
  "key.down": "keydown",
  "key.up": "keyup",
  "pointer.down": "pointerdown",
  "pointer.move": "pointermove",
  "pointer.up": "pointerup",
  "pointer.cancel": "pointercancel",
  "pointer.enter": "pointerenter",
  "pointer.leave": "pointerleave",
  "input": "input",
  "change": "change",
  "context.menu": "contextmenu",
  "host:click": "click",
  "host:keydown": "keydown",
  "host:keyup": "keyup",
  "host:pointerdown": "pointerdown",
  "host:pointerup": "pointerup",
  "host:pointermove": "pointermove",
  "host:pointercancel": "pointercancel",
  "host:pointerenter": "pointerenter",
  "host:pointerleave": "pointerleave",
  "host:input": "input",
  "host:change": "change",
  "host:contextmenu": "contextmenu",
  "host:focus": "focus",
  "host:blur": "blur"
};
var SUPPORTED_CAPABILITIES = /* @__PURE__ */ new Set([
  "props",
  "state",
  "event",
  "style",
  "rule",
  "render",
  "lifecycle"
]);
var RESERVED_COMPONENT_NAMES = /* @__PURE__ */ new Set([
  "React",
  "Number",
  "String",
  "Boolean",
  "Object",
  "TypeError"
]);
function validStateValue(state, value, isInitial) {
  if (value === void 0) return false;
  if (state.kind === "bool") return typeof value === "boolean";
  if (state.kind === "string" || state.kind === "enum") {
    return typeof value === "string" && (state.kind !== "enum" || !!state.options?.length) && (!state.options?.length || state.options.includes(value));
  }
  if (typeof value !== "number" || Number.isNaN(value)) return false;
  if (state.kind === "number.range" && (state.min === void 0 || state.max === void 0))
    return false;
  if (state.options?.length) return state.options.includes(value);
  if (!(isInitial && state.kind === "number.range" && state.clamp)) {
    if (state.min !== void 0 && value < state.min) return false;
    if (state.max !== void 0 && value > state.max) return false;
  }
  return state.step === void 0 || state.step <= 0 || Number.isInteger((value - (state.min ?? 0)) / state.step);
}
function checkValue(expr, proto, locals, reject, previousAllowed = false) {
  switch (expr.kind) {
    case "literal":
      return;
    case "state":
      if (!proto.states.some((state) => state.name === expr.name))
        reject("Action reads an undeclared state: " + expr.name + ".");
      return;
    case "prop":
      if (!proto.props.some((declaration) => declaration.name === expr.name))
        reject("Action reads an undeclared prop: " + expr.name + ".");
      if (expr.source === "previous" && !previousAllowed)
        reject("Previous resolved props are available only inside a props watcher.");
      return;
    case "local":
      if (!locals.has(expr.name)) reject("Action reads an undeclared local: " + expr.name + ".");
      return;
    case "unary":
      return checkValue(expr.operand, proto, locals, reject, previousAllowed);
    case "binary":
      checkValue(expr.left, proto, locals, reject, previousAllowed);
      checkValue(expr.right, proto, locals, reject, previousAllowed);
      return;
    case "conditional":
      checkValue(expr.condition, proto, locals, reject, previousAllowed);
      checkValue(expr.then, proto, locals, reject, previousAllowed);
      checkValue(expr.otherwise, proto, locals, reject, previousAllowed);
  }
}
function checkActions(actions, proto, outer, reject, previousAllowed = false, updatesAllowed = true) {
  const locals = new Set(outer);
  const declaredHere = /* @__PURE__ */ new Set();
  for (const action of actions) {
    switch (action.kind) {
      case "state-set":
        if (!proto.states.some((state) => state.name === action.stateName))
          reject("Action writes an undeclared state: " + action.stateName + ".");
        checkValue(action.value, proto, locals, reject, previousAllowed);
        break;
      case "local":
        checkValue(action.value, proto, locals, reject, previousAllowed);
        if (declaredHere.has(action.name))
          reject("Action local is declared more than once: " + action.name + ".");
        declaredHere.add(action.name);
        locals.add(action.name);
        break;
      case "if":
        checkValue(action.condition, proto, locals, reject, previousAllowed);
        checkActions(action.then, proto, locals, reject, previousAllowed, updatesAllowed);
        checkActions(action.otherwise, proto, locals, reject, previousAllowed, updatesAllowed);
        break;
      case "invoke":
        checkActions(action.body, proto, locals, reject, previousAllowed, updatesAllowed);
        break;
      case "request-update":
        if (!updatesAllowed)
          reject(
            "A render request during creation or detached cleanup needs explicit lifecycle scheduling."
          );
        break;
      case "return":
        break;
    }
  }
}
function eventActionFlow(event) {
  if (event.body) return event.body;
  const action = event.simpleAction;
  if (!action) return [];
  const current = { kind: "state", name: action.stateName };
  const value = action.kind === "set-state" ? { kind: "literal", value: action.value } : action.kind === "toggle-state" ? { kind: "unary", operator: "!", operand: current } : {
    kind: "binary",
    operator: "+",
    left: current,
    right: { kind: "literal", value: action.delta }
  };
  return [{ kind: "state-set", stateName: action.stateName, value }];
}
function getReactLoweringDiagnostics(proto) {
  const issues = [];
  const reject = (message) => issues.push(diagnostic("PUI_REACT_UNSUPPORTED", "codegen", message, proto.span));
  for (const remaining of proto.unlowered ?? [])
    issues.push(
      diagnostic(
        "PUI_REACT_UNSUPPORTED",
        "codegen",
        remaining.operation + ": " + remaining.message,
        remaining.span ?? proto.span
      )
    );
  if (proto.render.kind === "dynamic")
    reject("React AST lowering does not cover this dynamic render expression.");
  for (const cap2 of proto.capabilities)
    if (!SUPPORTED_CAPABILITIES.has(cap2))
      reject("React AST lowering does not yet cover capability: " + cap2 + ".");
  if (proto.hooks.some((hook) => !hook.lowered))
    reject("Hook bodies must be lowered to supported semantic operations before React emission.");
  if (proto.contexts.length)
    reject("Context operations need executable semantic IR before React emission.");
  if (proto.exposes.length)
    reject("Expose operations need executable semantic IR before React emission.");
  const lifecyclePhases = {
    onCreated: "created",
    onMounted: "mounted",
    onUpdated: "updated",
    onUnmounted: "unmounted"
  };
  for (const registration of proto.lifecycle) {
    const phase = lifecyclePhases[registration];
    if (!phase || !proto.lifecycleHandlers?.some((handler) => handler.phase === phase))
      reject("Lifecycle registration has no executable native lowering: " + registration + ".");
  }
  for (const handler of proto.lifecycleHandlers ?? []) {
    if (handler.phase === "before-dispose")
      reject("Terminal disposal cannot be equated with React effect cleanup or StrictMode replay.");
    checkActions(
      handler.body,
      proto,
      /* @__PURE__ */ new Set(),
      reject,
      false,
      handler.phase !== "created" && handler.phase !== "unmounted"
    );
  }
  for (const watch of proto.propWatches ?? []) {
    if (watch.keys && (!watch.keys.length || watch.keys.some((key) => !proto.props.some((declaration) => declaration.name === key))))
      reject("A keyed props watcher requires non-empty declared keys.");
    checkActions(watch.body, proto, /* @__PURE__ */ new Set(), reject, true);
  }
  const checkGroup = (bodies) => {
    const invocations = bodies.map((body) => ({ kind: "invoke", body }));
    for (const issue of getUpdateOrderingIssues(invocations)) reject(issue);
  };
  const eventGroups = /* @__PURE__ */ new Map();
  for (const event of proto.events) {
    const key = event.scope + ":" + (DOM_EVENTS[event.eventName] ?? event.eventName);
    const group = eventGroups.get(key) ?? [];
    group.push(eventActionFlow(event));
    eventGroups.set(key, group);
  }
  for (const group of eventGroups.values()) checkGroup(group);
  checkGroup(
    (proto.lifecycleHandlers ?? []).filter((handler) => handler.phase === "mounted").map((handler) => handler.body)
  );
  checkGroup([
    ...(proto.propWatches ?? []).map((watch) => watch.body),
    ...(proto.lifecycleHandlers ?? []).filter((handler) => handler.phase === "updated").map((handler) => handler.body)
  ]);
  for (const declaration of proto.props) {
    if (declaration.kind === "object" || declaration.kind === "any")
      reject(
        "Native React prop validation does not yet cover non-scalar prop: " + declaration.name + "."
      );
    if (declaration.kind === "enum" && (!declaration.options?.length || declaration.options.some((value) => typeof value !== "string")))
      reject("Enum prop requires a non-empty string domain: " + declaration.name + ".");
    if (["className", "style", "children"].includes(declaration.name))
      reject(
        "Declared prop collides with React host presentation input: " + declaration.name + "."
      );
  }
  for (const state of proto.states) {
    if (!validStateValue(state, state.initialValue, true))
      reject("State initial value or domain is missing or invalid: " + state.name + ".");
  }
  for (const event of proto.events) {
    if (event.scope !== "root")
      reject("Global event ownership is not yet represented by React AST lowering.");
    if (!Object.hasOwn(DOM_EVENTS, event.eventName))
      reject(
        "Event requires explicit host semantics before React emission: " + event.eventName + "."
      );
    if (event.body) {
      checkActions(event.body, proto, /* @__PURE__ */ new Set(), reject);
      continue;
    }
    if (!event.simpleAction) {
      reject("Event callback requires executable semantic IR: " + event.eventName + ".");
      continue;
    }
    const action = event.simpleAction;
    const state = proto.states.find((declaration) => declaration.name === action.stateName);
    if (!state) {
      reject("Event references an undeclared state: " + action.stateName + ".");
      continue;
    }
    if (action.kind === "toggle-state" && state.kind !== "bool")
      reject("Toggle requires a boolean state: " + action.stateName + ".");
    if (action.kind === "increment-state" && (state.kind !== "number.discrete" && state.kind !== "number.range" || Number.isNaN(action.delta)))
      reject("Increment requires a numeric state and non-NaN delta: " + action.stateName + ".");
    if (action.kind === "set-state" && !validStateValue(state, action.value, false))
      reject("Literal state update violates the declared domain: " + action.stateName + ".");
  }
  const checkCondition = (condition) => {
    if (condition.kind === "not") return checkCondition(condition.expr);
    if (condition.kind === "all" || condition.kind === "any") {
      condition.exprs.forEach(checkCondition);
      return;
    }
    if (condition.kind !== "cmp") return;
    const declaration = condition.source === "prop" ? proto.props.find((value) => value.name === condition.key) : condition.source === "state" ? proto.states.find((value) => value.name === condition.key) : void 0;
    if (!declaration)
      reject(
        "Rule condition requires a declared prop or state: " + condition.source + "." + condition.key + "."
      );
    if (condition.operator === "gte" && (typeof condition.value !== "number" || !Number.isFinite(condition.value) || !declaration || !["number", "number.discrete", "number.range"].includes(declaration.kind)))
      reject("Rule gte requires numeric operands and a finite threshold.");
  };
  for (const rule of proto.rules) {
    if (rule.dynamic) reject("Dynamic rule conditions require executable semantic IR.");
    checkCondition(rule.condition);
  }
  let slots = 0;
  const checkChildren = (children) => {
    for (const child of children) {
      if (child.kind === "slot") slots += 1;
      if (child.kind === "prop-read" && !proto.props.some((declaration) => declaration.name === child.propName))
        reject("Render references an undeclared prop: " + child.propName + ".");
      if (child.kind === "state-read" && !proto.states.some((state) => state.name === child.stateName))
        reject("Render references an undeclared state: " + child.stateName + ".");
      if (child.kind === "element") checkChildren(child.node.children);
    }
  };
  if (proto.render.kind === "static-tree" || proto.render.kind === "reactive-tree")
    checkChildren(proto.render.root.children);
  else if (proto.render.kind === "fragment") checkChildren(proto.render.children);
  if (slots > 1) reject("A prototype template can contain at most one default slot.");
  return issues;
}
function toPascalCase(name) {
  const parts = name.replace(/[^A-Za-z0-9]+/g, " ").trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "CompiledComponent";
  const result = parts.map((part) => part[0].toUpperCase() + part.slice(1)).join("");
  return /^[0-9]/.test(result) ? "C" + result : result;
}
function throwError(message) {
  return f.createThrowStatement(
    f.createNewExpression(id("TypeError"), void 0, [f.createStringLiteral(message)])
  );
}
function isEmpty(value) {
  return or(eq(value, f.createNull()), eq(value, f.createVoidZero()));
}
function validPropExpression(declaration, value) {
  let result = eq(
    f.createTypeOfExpression(value),
    f.createStringLiteral(declaration.kind === "enum" ? "string" : declaration.kind)
  );
  if (declaration.kind === "number")
    result = and(result, call(prop(id("Number"), "isFinite"), [value]));
  if (declaration.kind === "enum")
    result = and(
      result,
      call(
        prop(f.createArrayLiteralExpression((declaration.options ?? []).map(scalar)), "includes"),
        [value]
      )
    );
  if (declaration.range?.min !== void 0)
    result = and(
      result,
      bin(value, ts10.SyntaxKind.GreaterThanEqualsToken, scalar(declaration.range.min))
    );
  if (declaration.range?.max !== void 0)
    result = and(
      result,
      bin(value, ts10.SyntaxKind.LessThanEqualsToken, scalar(declaration.range.max))
    );
  return result;
}
function isValidPropDefault(declaration) {
  const value = declaration.defaultValue;
  if (value === void 0 || value === null) return false;
  if (declaration.kind === "enum")
    return typeof value === "string" && !!declaration.options?.includes(value);
  if (typeof value !== declaration.kind) return false;
  if (typeof value === "number") {
    if (!Number.isFinite(value)) return false;
    if (declaration.range?.min !== void 0 && value < declaration.range.min) return false;
    if (declaration.range?.max !== void 0 && value > declaration.range.max) return false;
  }
  return true;
}
function emitPropResolution(declaration, index) {
  const resolved = id("_prop" + index);
  const previous = id("_previousProp" + index);
  const previousValue = prop(previous, "current");
  const raw = id("_rawProp" + index);
  const provided = id("_providedProp" + index);
  const remember = id("_rememberProp" + index);
  const type = nullable(scalarType(declaration.kind));
  const defaultValue = isValidPropDefault(declaration) ? scalar(declaration.defaultValue) : f.createNull();
  const acceptsEmpty = declaration.empty === "accept";
  const requireNonEmpty = declaration.empty === "error";
  const missing = [assign(resolved, defaultValue)];
  if (requireNonEmpty)
    missing.push(
      f.createIfStatement(
        eq(resolved, f.createNull()),
        throwError("Missing prop has no non-empty fallback: " + declaration.name + ".")
      )
    );
  const unusable = [
    assign(
      resolved,
      f.createConditionalExpression(
        ne(previousValue, f.createNull()),
        void 0,
        previousValue,
        void 0,
        defaultValue
      )
    ),
    assign(remember, ne(resolved, f.createNull()))
  ];
  if (requireNonEmpty)
    unusable.push(
      f.createIfStatement(
        eq(resolved, f.createNull()),
        throwError("Unusable prop has no non-empty fallback: " + declaration.name + ".")
      )
    );
  const providedResolution = f.createIfStatement(
    acceptsEmpty ? isEmpty(raw) : f.createFalse(),
    block([assign(resolved, f.createNull())]),
    f.createIfStatement(
      validPropExpression(declaration, raw),
      block([assign(resolved, raw), assign(remember, f.createTrue())]),
      block(unusable)
    )
  );
  return [
    variable(previous, react("useRef", [f.createNull()], [type])),
    variable(
      provided,
      call(prop(prop(prop(id("Object"), "prototype"), "hasOwnProperty"), "call"), [
        id("props"),
        f.createStringLiteral(declaration.name)
      ])
    ),
    variable(
      raw,
      f.createConditionalExpression(
        provided,
        void 0,
        item(id("props"), declaration.name),
        void 0,
        f.createVoidZero()
      )
    ),
    variable(resolved, f.createNull(), type, true),
    variable(remember, f.createFalse(), void 0, true),
    f.createIfStatement(not(provided), block(missing), providedResolution),
    f.createExpressionStatement(
      react("useLayoutEffect", [
        f.createArrowFunction(
          void 0,
          void 0,
          [],
          void 0,
          void 0,
          block([f.createIfStatement(remember, assign(previousValue, resolved))])
        ),
        f.createArrayLiteralExpression([resolved, remember])
      ])
    )
  ];
}
function stateValidity(state, value) {
  const kind = state.kind === "bool" ? "boolean" : state.kind === "enum" ? "string" : state.kind.startsWith("number.") ? "number" : state.kind;
  let result = eq(f.createTypeOfExpression(value), f.createStringLiteral(kind));
  if (kind === "number") result = and(result, not(call(prop(id("Number"), "isNaN"), [value])));
  if (state.options?.length)
    return and(
      result,
      call(prop(f.createArrayLiteralExpression(state.options.map(scalar)), "includes"), [value])
    );
  if (state.min !== void 0)
    result = and(result, bin(value, ts10.SyntaxKind.GreaterThanEqualsToken, scalar(state.min)));
  if (state.max !== void 0)
    result = and(result, bin(value, ts10.SyntaxKind.LessThanEqualsToken, scalar(state.max)));
  if (state.step !== void 0 && state.step > 0)
    result = and(
      result,
      call(prop(id("Number"), "isInteger"), [
        bin(
          bin(value, ts10.SyntaxKind.MinusToken, scalar(state.min ?? 0)),
          ts10.SyntaxKind.SlashToken,
          scalar(state.step)
        )
      ])
    );
  return result;
}
function initialStateValue(state) {
  let value = state.initialValue;
  if (state.kind === "number.range" && state.clamp && typeof value === "number") {
    if (state.min !== void 0 && value < state.min) value = state.min;
    if (state.max !== void 0 && value > state.max) value = state.max;
  }
  return value;
}
function emitState(state, index, created, feedback) {
  const type = scalarType(state.kind);
  const initial = created ? f.createElementAccessExpression(id("_createdStates"), index) : scalar(initialStateValue(state));
  const ref = id("_stateRef" + index);
  const next = id("_nextState");
  return [
    variable(ref, react("useRef", [initial], [type])),
    variable(
      "_writeState" + index,
      f.createArrowFunction(
        void 0,
        void 0,
        [
          f.createParameterDeclaration(
            void 0,
            void 0,
            next,
            void 0,
            f.createKeywordTypeNode(ts10.SyntaxKind.UnknownKeyword)
          )
        ],
        void 0,
        void 0,
        block([
          f.createIfStatement(
            not(stateValidity(state, next)),
            throwError("State update violates domain: " + state.name + ".")
          ),
          assign(prop(ref, "current"), next),
          ...feedback ? [f.createExpressionStatement(call(id("_refreshFeedback")))] : []
        ])
      )
    )
  ];
}
function emitRenderRequest(prototype) {
  if (!prototype.states.length && !prototype.events.length && !prototype.lifecycleHandlers?.length && !prototype.propWatches?.length)
    return [];
  const tuple = f.createTupleTypeNode(prototype.states.map((state) => scalarType(state.kind)));
  const liveStates = () => f.createArrayLiteralExpression(
    prototype.states.map((_state, index) => prop(id("_stateRef" + index), "current"))
  );
  const inputs = f.createArrayLiteralExpression(
    prototype.props.flatMap((declaration) => [
      call(prop(id("Object"), "hasOwn"), [id("props"), f.createStringLiteral(declaration.name)]),
      item(id("props"), declaration.name)
    ])
  );
  const snapshot = prop(id("_templateState"), "current");
  const version = prop(id("_requestVersion"), "current");
  const statements = [
    variable("_templateState", react("useRef", [liveStates()], [tuple])),
    variable("_requestVersion", react("useRef", [f.createNumericLiteral(0)])),
    variable("_renderVersion", version),
    variable(
      "_renderInputs",
      inputs,
      f.createArrayTypeNode(f.createKeywordTypeNode(ts10.SyntaxKind.UnknownKeyword))
    ),
    variable("_committedInputs", react("useRef", [id("_renderInputs")])),
    variable(
      "_inputsChanged",
      call(prop(id("_renderInputs"), "some"), [
        f.createArrowFunction(
          void 0,
          void 0,
          [
            f.createParameterDeclaration(void 0, void 0, "_value"),
            f.createParameterDeclaration(void 0, void 0, "_index")
          ],
          void 0,
          void 0,
          not(
            call(prop(id("Object"), "is"), [
              id("_value"),
              f.createElementAccessExpression(
                prop(id("_committedInputs"), "current"),
                id("_index")
              )
            ])
          )
        )
      ])
    ),
    variable(
      "_renderStates",
      f.createConditionalExpression(
        id("_inputsChanged"),
        void 0,
        liveStates(),
        void 0,
        snapshot
      ),
      tuple
    ),
    variable(
      f.createArrayBindingPattern([
        f.createOmittedExpression(),
        f.createBindingElement(void 0, void 0, "_setRenderRevision")
      ]),
      react("useState", [f.createNumericLiteral(0)])
    ),
    variable(
      "_requestUpdate",
      f.createArrowFunction(
        void 0,
        void 0,
        [],
        void 0,
        void 0,
        block([
          assign(snapshot, liveStates()),
          assign(version, bin(version, ts10.SyntaxKind.PlusToken, f.createNumericLiteral(1))),
          f.createExpressionStatement(
            call(id("_setRenderRevision"), [
              f.createArrowFunction(
                void 0,
                void 0,
                [f.createParameterDeclaration(void 0, void 0, "_revision")],
                void 0,
                void 0,
                bin(id("_revision"), ts10.SyntaxKind.PlusToken, f.createNumericLiteral(1))
              )
            ])
          )
        ])
      )
    ),
    f.createExpressionStatement(
      react("useLayoutEffect", [
        f.createArrowFunction(
          void 0,
          void 0,
          [],
          void 0,
          void 0,
          block([
            assign(prop(id("_committedInputs"), "current"), id("_renderInputs")),
            f.createIfStatement(
              eq(version, id("_renderVersion")),
              assign(snapshot, id("_renderStates"))
            )
          ])
        )
      ])
    )
  ];
  prototype.states.forEach(
    (_state, index) => statements.push(
      variable("_state" + index, f.createElementAccessExpression(id("_renderStates"), index))
    )
  );
  return statements;
}
var operatorTokens = {
  "+": ts10.SyntaxKind.PlusToken,
  "-": ts10.SyntaxKind.MinusToken,
  "*": ts10.SyntaxKind.AsteriskToken,
  "/": ts10.SyntaxKind.SlashToken,
  "%": ts10.SyntaxKind.PercentToken,
  "===": ts10.SyntaxKind.EqualsEqualsEqualsToken,
  "!==": ts10.SyntaxKind.ExclamationEqualsEqualsToken,
  "<": ts10.SyntaxKind.LessThanToken,
  "<=": ts10.SyntaxKind.LessThanEqualsToken,
  ">": ts10.SyntaxKind.GreaterThanToken,
  ">=": ts10.SyntaxKind.GreaterThanEqualsToken,
  "&&": ts10.SyntaxKind.AmpersandAmpersandToken,
  "||": ts10.SyntaxKind.BarBarToken,
  "??": ts10.SyntaxKind.QuestionQuestionToken
};
var operatorHelpers = {
  "+": "_valueAdd",
  "-": "_valueSubtract",
  "*": "_valueMultiply",
  "/": "_valueDivide",
  "%": "_valueRemainder",
  "===": "_valueEqual",
  "!==": "_valueNotEqual",
  "<": "_valueLess",
  "<=": "_valueLessEqual",
  ">": "_valueGreater",
  ">=": "_valueGreaterEqual",
  "&&": "_valueAnd",
  "||": "_valueOr",
  "??": "_valueCoalesce"
};
function primitiveType() {
  return f.createUnionTypeNode([
    f.createKeywordTypeNode(ts10.SyntaxKind.StringKeyword),
    f.createKeywordTypeNode(ts10.SyntaxKind.NumberKeyword),
    f.createKeywordTypeNode(ts10.SyntaxKind.BooleanKeyword),
    f.createLiteralTypeNode(f.createNull())
  ]);
}
function emitValueHelpers(prototype) {
  const operators = /* @__PURE__ */ new Set();
  const value = (expression) => {
    if (expression.kind === "unary") value(expression.operand);
    else if (expression.kind === "binary") {
      operators.add(expression.operator);
      value(expression.left);
      value(expression.right);
    } else if (expression.kind === "conditional") {
      value(expression.condition);
      value(expression.then);
      value(expression.otherwise);
    }
  };
  const actions = (body) => {
    for (const action of body) {
      if (action.kind === "state-set" || action.kind === "local") value(action.value);
      else if (action.kind === "if") {
        value(action.condition);
        actions(action.then);
        actions(action.otherwise);
      } else if (action.kind === "invoke") actions(action.body);
    }
  };
  const rule = (condition) => {
    if (condition.kind === "cmp" && condition.operator === "eq") operators.add("===");
    else if (condition.kind === "not") rule(condition.expr);
    else if (condition.kind === "all" || condition.kind === "any") condition.exprs.forEach(rule);
  };
  for (const event of prototype.events) if (event.body) actions(event.body);
  for (const handler of prototype.lifecycleHandlers ?? []) actions(handler.body);
  for (const watch of prototype.propWatches ?? []) actions(watch.body);
  for (const definition of prototype.rules) rule(definition.condition);
  return [...operators].map((operator) => {
    const left = id("_left");
    const right = id("_right");
    const lazy = operator === "&&" || operator === "||" || operator === "??";
    const numeric = (operand) => call(id("Number"), [operand]);
    const string = (operand) => call(id("String"), [operand]);
    const isString = (operand) => eq(f.createTypeOfExpression(operand), f.createStringLiteral("string"));
    let expression;
    if (lazy) expression = bin(left, operatorTokens[operator], call(right));
    else if (operator === "===" || operator === "!==")
      expression = bin(left, operatorTokens[operator], right);
    else if (operator === "+")
      expression = f.createConditionalExpression(
        or(isString(left), isString(right)),
        void 0,
        bin(string(left), ts10.SyntaxKind.PlusToken, string(right)),
        void 0,
        bin(numeric(left), ts10.SyntaxKind.PlusToken, numeric(right))
      );
    else if (["<", "<=", ">", ">="].includes(operator))
      expression = f.createConditionalExpression(
        and(isString(left), isString(right)),
        void 0,
        bin(left, operatorTokens[operator], right),
        void 0,
        bin(numeric(left), operatorTokens[operator], numeric(right))
      );
    else expression = bin(numeric(left), operatorTokens[operator], numeric(right));
    return variable(
      operatorHelpers[operator],
      f.createArrowFunction(
        void 0,
        void 0,
        [
          f.createParameterDeclaration(void 0, void 0, left, void 0, primitiveType()),
          f.createParameterDeclaration(
            void 0,
            void 0,
            right,
            void 0,
            lazy ? f.createFunctionTypeNode(void 0, [], primitiveType()) : primitiveType()
          )
        ],
        void 0,
        void 0,
        expression
      )
    );
  });
}
function emitValue(expression, proto, locals, context = {}) {
  switch (expression.kind) {
    case "literal":
      return scalar(expression.value);
    case "state": {
      const index = proto.states.findIndex((state) => state.name === expression.name);
      return context.stateMode === "created" ? id("_createdState" + index) : prop(id("_stateRef" + index), "current");
    }
    case "prop": {
      const index = proto.props.findIndex((declaration) => declaration.name === expression.name);
      if (expression.source === "previous")
        return f.createElementAccessExpression(context.previousProps, index);
      if (context.currentProps === "committed")
        return f.createElementAccessExpression(prop(id("_committedProps"), "current"), index);
      return id("_prop" + index);
    }
    case "local":
      return id(locals.get(expression.name));
    case "unary": {
      const operand = emitValue(expression.operand, proto, locals, context);
      if (expression.operator === "!") return not(call(id("Boolean"), [operand]));
      const numeric = call(id("Number"), [operand]);
      return expression.operator === "-" ? f.createPrefixUnaryExpression(ts10.SyntaxKind.MinusToken, numeric) : numeric;
    }
    case "binary": {
      const left = emitValue(expression.left, proto, locals, context);
      let right = emitValue(expression.right, proto, locals, context);
      if (["&&", "||", "??"].includes(expression.operator))
        right = f.createArrowFunction(void 0, void 0, [], void 0, void 0, right);
      return call(id(operatorHelpers[expression.operator]), [left, right]);
    }
    case "conditional":
      return f.createConditionalExpression(
        call(id("Boolean"), [emitValue(expression.condition, proto, locals, context)]),
        void 0,
        emitValue(expression.then, proto, locals, context),
        void 0,
        emitValue(expression.otherwise, proto, locals, context)
      );
  }
}
function emitActions(actions, proto, inherited, counter, context = {}) {
  const locals = new Map(inherited);
  const output = [];
  for (const action of actions) {
    switch (action.kind) {
      case "state-set":
        output.push(
          f.createExpressionStatement(
            call(
              id(
                (context.stateMode === "created" ? "_createdWriteState" : "_writeState") + proto.states.findIndex((state) => state.name === action.stateName)
              ),
              [emitValue(action.value, proto, locals, context)]
            )
          )
        );
        break;
      case "local": {
        const name = "_local" + counter.value++;
        output.push(variable(name, emitValue(action.value, proto, locals, context)));
        locals.set(action.name, name);
        break;
      }
      case "if":
        output.push(
          f.createIfStatement(
            call(id("Boolean"), [emitValue(action.condition, proto, locals, context)]),
            block(emitActions(action.then, proto, locals, counter, context)),
            action.otherwise.length ? block(emitActions(action.otherwise, proto, locals, counter, context)) : void 0
          )
        );
        break;
      case "return":
        output.push(f.createReturnStatement());
        break;
      case "request-update":
        output.push(f.createExpressionStatement(call(id("_requestUpdate"))));
        break;
      case "invoke":
        output.push(
          f.createExpressionStatement(
            call(
              f.createArrowFunction(
                void 0,
                void 0,
                [],
                void 0,
                void 0,
                block(emitActions(action.body, proto, locals, counter, context))
              )
            )
          )
        );
        break;
    }
  }
  return output;
}
function emitCondition(condition, prototype, committed = false) {
  if (condition.kind === "true") return f.createTrue();
  if (condition.kind === "false") return f.createFalse();
  if (condition.kind === "not") return not(emitCondition(condition.expr, prototype, committed));
  if (condition.kind === "all" || condition.kind === "any") {
    const values = condition.exprs.map(
      (expression) => emitCondition(expression, prototype, committed)
    );
    const identity = condition.kind === "all" ? f.createTrue() : f.createFalse();
    return values.reduce(
      (acc, value) => condition.kind === "all" ? and(acc, value) : or(acc, value),
      identity
    );
  }
  const source = condition.source === "prop" ? committed ? f.createElementAccessExpression(
    prop(id("_committedProps"), "current"),
    prototype.props.findIndex((declaration) => declaration.name === condition.key)
  ) : id(
    "_prop" + prototype.props.findIndex((declaration) => declaration.name === condition.key)
  ) : prop(
    id("_stateRef" + prototype.states.findIndex((state) => state.name === condition.key)),
    "current"
  );
  if (condition.operator === "eq")
    return call(id(operatorHelpers["==="]), [source, scalar(condition.value)]);
  return and(
    and(
      eq(f.createTypeOfExpression(source), f.createStringLiteral("number")),
      call(prop(id("Number"), "isFinite"), [source])
    ),
    bin(source, ts10.SyntaxKind.GreaterThanEqualsToken, scalar(condition.value))
  );
}
function invokeActions(actions, prototype, context = {}) {
  return f.createExpressionStatement(
    call(
      f.createArrowFunction(
        void 0,
        void 0,
        [],
        void 0,
        void 0,
        block(emitActions(actions, prototype, /* @__PURE__ */ new Map(), { value: 0 }, context))
      )
    )
  );
}
function propsTupleType(prototype) {
  return f.createTupleTypeNode(
    prototype.props.map((declaration) => nullable(scalarType(declaration.kind)))
  );
}
function propsTupleValue(prototype) {
  return f.createArrayLiteralExpression(
    prototype.props.map((_declaration, index) => id("_prop" + index))
  );
}
function emitCreatedInitializer(prototype) {
  const handlers = (prototype.lifecycleHandlers ?? []).filter(
    (handler) => handler.phase === "created"
  );
  if (!handlers.length) return [];
  const body = [];
  prototype.states.forEach((state, index) => {
    const next = id("_nextState");
    body.push(
      variable(
        "_createdState" + index,
        scalar(initialStateValue(state)),
        scalarType(state.kind),
        true
      ),
      variable(
        "_createdWriteState" + index,
        f.createArrowFunction(
          void 0,
          void 0,
          [
            f.createParameterDeclaration(
              void 0,
              void 0,
              next,
              void 0,
              f.createKeywordTypeNode(ts10.SyntaxKind.UnknownKeyword)
            )
          ],
          void 0,
          void 0,
          block([
            f.createIfStatement(
              not(stateValidity(state, next)),
              throwError("Created state update violates domain: " + state.name + ".")
            ),
            assign(id("_createdState" + index), next)
          ])
        )
      )
    );
  });
  for (const handler of handlers)
    body.push(invokeActions(handler.body, prototype, { stateMode: "created" }));
  body.push(
    f.createReturnStatement(
      f.createArrayLiteralExpression(
        prototype.states.map((_state, index) => id("_createdState" + index))
      )
    )
  );
  return [
    variable(
      "_createdStates",
      f.createElementAccessExpression(
        react(
          "useState",
          [f.createArrowFunction(void 0, void 0, [], void 0, void 0, block(body))],
          [f.createTupleTypeNode(prototype.states.map((state) => scalarType(state.kind)))]
        ),
        0
      )
    )
  ];
}
function emitCommittedProps(prototype) {
  if (!prototype.rules.length && !(prototype.lifecycleHandlers ?? []).some((handler) => handler.phase !== "created"))
    return [];
  return [
    variable(
      "_committedProps",
      react("useRef", [propsTupleValue(prototype)], [propsTupleType(prototype)])
    ),
    f.createExpressionStatement(
      react("useLayoutEffect", [
        f.createArrowFunction(
          void 0,
          void 0,
          [],
          void 0,
          void 0,
          block([assign(prop(id("_committedProps"), "current"), propsTupleValue(prototype))])
        )
      ])
    )
  ];
}
function emitPropWatches(prototype) {
  const watches = prototype.propWatches ?? [];
  if (!watches.length) return [];
  const previous = id("_watchPrevious");
  const body = [
    variable(previous, prop(id("_watchSnapshot"), "current")),
    // Clear the pending window before invoking callbacks, matching the canonical dispatcher.
    assign(prop(id("_watchSnapshot"), "current"), propsTupleValue(prototype))
  ];
  const dispatch = [];
  for (const watch of watches) {
    const keys = watch.keys ?? prototype.props.map((declaration) => declaration.name);
    const changed = keys.map((key) => {
      const index = prototype.props.findIndex((declaration) => declaration.name === key);
      return not(
        call(prop(id("Object"), "is"), [
          f.createElementAccessExpression(previous, index),
          id("_prop" + index)
        ])
      );
    }).reduce((result, condition) => or(result, condition), f.createFalse());
    dispatch.push(
      f.createIfStatement(
        changed,
        block([invokeActions(watch.body, prototype, { previousProps: previous })])
      )
    );
  }
  body.push(f.createIfStatement(ne(previous, f.createNull()), block(dispatch)));
  return [
    variable(
      "_watchSnapshot",
      react("useRef", [f.createNull()], [nullable(propsTupleType(prototype))])
    ),
    f.createExpressionStatement(
      react("useLayoutEffect", [
        f.createArrowFunction(void 0, void 0, [], void 0, void 0, block(body))
      ])
    )
  ];
}
function emitLifecycleEffects(prototype) {
  const handlers = prototype.lifecycleHandlers ?? [];
  const mounted = handlers.filter((handler) => handler.phase === "mounted");
  const updated = handlers.filter((handler) => handler.phase === "updated");
  const unmounted = handlers.filter((handler) => handler.phase === "unmounted");
  if (!mounted.length && !updated.length && !unmounted.length) return [];
  const hasCommitted = prop(id("_lifecycleMounted"), "current");
  const context = { currentProps: "committed" };
  const mountBody = [assign(hasCommitted, f.createTrue())];
  mounted.forEach((handler) => mountBody.push(invokeActions(handler.body, prototype, context)));
  const updateBody = updated.map((handler) => invokeActions(handler.body, prototype, context));
  const cleanup = [assign(hasCommitted, f.createFalse())];
  unmounted.forEach((handler) => cleanup.push(invokeActions(handler.body, prototype, context)));
  return [
    variable("_lifecycleMounted", react("useRef", [f.createFalse()])),
    f.createExpressionStatement(
      react("useLayoutEffect", [
        f.createArrowFunction(
          void 0,
          void 0,
          [],
          void 0,
          void 0,
          block([f.createIfStatement(not(hasCommitted), block(mountBody), block(updateBody))])
        )
      ])
    ),
    f.createExpressionStatement(
      react("useLayoutEffect", [
        f.createArrowFunction(
          void 0,
          void 0,
          [],
          void 0,
          void 0,
          block([
            f.createReturnStatement(
              f.createArrowFunction(void 0, void 0, [], void 0, void 0, block(cleanup))
            )
          ])
        ),
        f.createArrayLiteralExpression([])
      ])
    )
  ];
}
function eventBody(event, prototype) {
  if (event.body) return emitActions(event.body, prototype, /* @__PURE__ */ new Map(), { value: 0 });
  const action = event.simpleAction;
  const index = prototype.states.findIndex((state) => state.name === action.stateName);
  const current = prop(id("_stateRef" + index), "current");
  const next = action.kind === "increment-state" ? bin(current, ts10.SyntaxKind.PlusToken, scalar(action.delta)) : action.kind === "toggle-state" ? not(current) : scalar(action.value);
  return [f.createExpressionStatement(call(id("_writeState" + index), [next]))];
}
function emitEventEffects(prototype) {
  if (!prototype.events.length) return [];
  const root = id("_eventRoot");
  const setup = [
    variable(root, prop(id("_rootRef"), "current")),
    f.createIfStatement(eq(root, f.createNull()), f.createReturnStatement())
  ];
  const cleanup = [];
  prototype.events.forEach((event, index) => {
    const listener = id("_listener" + index);
    const nativeEvent = f.createStringLiteral(DOM_EVENTS[event.eventName]);
    setup.push(
      variable(
        listener,
        f.createArrowFunction(
          void 0,
          void 0,
          [],
          void 0,
          void 0,
          block(eventBody(event, prototype))
        )
      ),
      f.createExpressionStatement(call(prop(root, "addEventListener"), [nativeEvent, listener]))
    );
    cleanup.push(
      f.createExpressionStatement(call(prop(root, "removeEventListener"), [nativeEvent, listener]))
    );
  });
  setup.push(
    f.createReturnStatement(
      f.createArrowFunction(void 0, void 0, [], void 0, void 0, block(cleanup))
    )
  );
  return [
    f.createExpressionStatement(
      react("useLayoutEffect", [
        f.createArrowFunction(void 0, void 0, [], void 0, void 0, block(setup))
      ])
    )
  ];
}
function emitMergedTokens(tokens) {
  const groups = /* @__PURE__ */ new Map();
  for (const token of tokens) {
    const key = getSemanticGroupKeyV0(token.token);
    const group = groups.get(key) ?? [];
    group.push(token);
    groups.set(key, group);
  }
  const earlier = /* @__PURE__ */ new Map();
  const output = [];
  for (const token of tokens) {
    const key = getSemanticGroupKeyV0(token.token);
    const preceding = earlier.get(key) ?? [];
    earlier.set(key, [...preceding, token]);
    if (preceding.some((value) => !value.condition)) continue;
    let selected = f.createVoidZero();
    for (const candidate of groups.get(key)) {
      selected = candidate.condition ? f.createConditionalExpression(
        candidate.condition,
        void 0,
        f.createStringLiteral(candidate.token),
        void 0,
        selected
      ) : f.createStringLiteral(candidate.token);
    }
    const isFirst = preceding.reduce(
      (condition, value) => and(condition, not(value.condition)),
      token.condition ?? f.createTrue()
    );
    output.push(
      !token.condition && !preceding.length ? selected : f.createConditionalExpression(isFirst, void 0, selected, void 0, f.createVoidZero())
    );
  }
  return output;
}
function emitClassName(classes) {
  return or(
    call(
      prop(call(prop(f.createArrayLiteralExpression(classes), "filter"), [id("Boolean")]), "join"),
      [f.createStringLiteral(" ")]
    ),
    f.createVoidZero()
  );
}
function emitFeedbackEffects(prototype) {
  if (!prototype.rules.length) return [];
  const active = prop(id("_feedbackActive"), "current");
  const root = id("_feedbackRoot");
  const tokens = prototype.staticStyleTokens.map((token) => ({ token }));
  const body = [
    variable(root, prop(id("_rootRef"), "current")),
    f.createIfStatement(or(not(active), eq(root, f.createNull())), f.createReturnStatement())
  ];
  prototype.rules.forEach((rule, index) => {
    const condition = id("_feedbackRule" + index);
    body.push(variable(condition, emitCondition(rule.condition, prototype, true)));
    tokens.push(...rule.styleTokens.map((token) => ({ token, condition })));
  });
  body.push(
    variable(
      "_feedbackClasses",
      emitClassName([prop(id("_feedbackClassName"), "current"), ...emitMergedTokens(tokens)])
    )
  );
  body.push(
    f.createIfStatement(
      ne(
        call(prop(root, "getAttribute"), [f.createStringLiteral("class")]),
        bin(id("_feedbackClasses"), ts10.SyntaxKind.QuestionQuestionToken, f.createNull())
      ),
      block([
        f.createIfStatement(
          id("_feedbackClasses"),
          f.createExpressionStatement(
            call(prop(root, "setAttribute"), [
              f.createStringLiteral("class"),
              id("_feedbackClasses")
            ])
          ),
          f.createExpressionStatement(
            call(prop(root, "removeAttribute"), [f.createStringLiteral("class")])
          )
        )
      ])
    )
  );
  return [
    variable("_feedbackActive", react("useRef", [f.createFalse()])),
    variable("_feedbackClassName", react("useRef", [prop(id("props"), "className")])),
    variable(
      "_refreshFeedback",
      f.createArrowFunction(void 0, void 0, [], void 0, void 0, block(body))
    ),
    f.createExpressionStatement(
      react("useLayoutEffect", [
        f.createArrowFunction(
          void 0,
          void 0,
          [],
          void 0,
          void 0,
          block([
            assign(prop(id("_feedbackClassName"), "current"), prop(id("props"), "className")),
            assign(active, f.createTrue()),
            f.createExpressionStatement(call(id("_refreshFeedback")))
          ])
        )
      ])
    ),
    f.createExpressionStatement(
      react("useLayoutEffect", [
        f.createArrowFunction(
          void 0,
          void 0,
          [],
          void 0,
          void 0,
          block([
            f.createReturnStatement(
              f.createArrowFunction(
                void 0,
                void 0,
                [],
                void 0,
                void 0,
                block([assign(active, f.createFalse())])
              )
            )
          ])
        ),
        f.createArrayLiteralExpression([])
      ])
    )
  ];
}
function emitTemplate(node, prototype, root) {
  const properties = [];
  const classes = root ? [prop(id("props"), "className")] : [];
  const tokens = [];
  if (root) for (const token of prototype.staticStyleTokens) tokens.push({ token });
  for (const token of node.styleTokens ?? []) tokens.push({ token });
  if (root)
    prototype.rules.forEach((rule, index) => {
      for (const token of rule.styleTokens) tokens.push({ token, condition: id("_rule" + index) });
    });
  classes.push(...emitMergedTokens(tokens));
  if (classes.length)
    properties.push(f.createPropertyAssignment("className", emitClassName(classes)));
  if (root) {
    properties.push(f.createPropertyAssignment("style", prop(id("props"), "style")));
    if (prototype.events.length || prototype.rules.length)
      properties.push(
        f.createPropertyAssignment(
          "ref",
          f.createArrowFunction(
            void 0,
            void 0,
            [
              f.createParameterDeclaration(
                void 0,
                void 0,
                "_element",
                void 0,
                nullable(f.createTypeReferenceNode("Element"))
              )
            ],
            void 0,
            void 0,
            block([assign(prop(id("_rootRef"), "current"), id("_element"))])
          )
        )
      );
  }
  const child = (value) => {
    switch (value.kind) {
      case "text":
        return f.createStringLiteral(value.value);
      case "slot":
        return prop(id("props"), "children");
      case "prop-read":
        return id(
          "_prop" + prototype.props.findIndex((declaration) => declaration.name === value.propName)
        );
      case "state-read":
        return id("_state" + prototype.states.findIndex((state) => state.name === value.stateName));
      case "element":
        return emitTemplate(value.node, prototype, false);
    }
  };
  return react("createElement", [
    f.createStringLiteral(node.tag),
    properties.length ? f.createObjectLiteralExpression(properties, true) : f.createNull(),
    ...node.children.map(child)
  ]);
}
function emitReactComponent(prototype, options = {}) {
  const issues = getReactLoweringDiagnostics(prototype);
  if (issues.length)
    throw new Error(issues.map((issue) => issue.code + ": " + issue.message).join("\n"));
  const defaultName = toPascalCase(prototype.name);
  const componentName = options.componentName ?? (RESERVED_COMPONENT_NAMES.has(defaultName) ? "Compiled" + defaultName : defaultName);
  if (!/^[A-Z_$][A-Za-z0-9_$]*$/.test(componentName))
    throw new Error("React componentName must be a valid uppercase or prefixed identifier.");
  if (RESERVED_COMPONENT_NAMES.has(componentName))
    throw new Error(
      "React componentName shadows an imported or native binding: " + componentName + "."
    );
  const propsName = componentName + "Props";
  const propsMembers = prototype.props.map(
    (declaration) => f.createPropertySignature(
      void 0,
      f.createStringLiteral(declaration.name),
      f.createToken(ts10.SyntaxKind.QuestionToken),
      nullable(scalarType(declaration.kind))
    )
  );
  propsMembers.push(
    f.createPropertySignature(
      void 0,
      "className",
      f.createToken(ts10.SyntaxKind.QuestionToken),
      f.createKeywordTypeNode(ts10.SyntaxKind.StringKeyword)
    ),
    f.createPropertySignature(
      void 0,
      "style",
      f.createToken(ts10.SyntaxKind.QuestionToken),
      reactType("CSSProperties")
    ),
    f.createPropertySignature(
      void 0,
      "children",
      f.createToken(ts10.SyntaxKind.QuestionToken),
      reactType("ReactNode")
    )
  );
  const statements = [
    f.createImportDeclaration(
      void 0,
      f.createImportClause(false, void 0, f.createNamespaceImport(id("React"))),
      f.createStringLiteral("react")
    ),
    f.createInterfaceDeclaration(
      [f.createModifier(ts10.SyntaxKind.ExportKeyword)],
      propsName,
      void 0,
      void 0,
      propsMembers
    )
  ];
  const body = [...emitValueHelpers(prototype)];
  prototype.props.forEach(
    (declaration, index) => body.push(...emitPropResolution(declaration, index))
  );
  const hasCreated = !!prototype.lifecycleHandlers?.some((handler) => handler.phase === "created");
  body.push(...emitCreatedInitializer(prototype));
  prototype.states.forEach(
    (state, index) => body.push(...emitState(state, index, hasCreated, prototype.rules.length > 0))
  );
  body.push(...emitRenderRequest(prototype));
  body.push(...emitCommittedProps(prototype));
  if (prototype.events.length || prototype.rules.length)
    body.push(
      variable(
        "_rootRef",
        react("useRef", [f.createNull()], [nullable(f.createTypeReferenceNode("Element"))])
      )
    );
  body.push(...emitFeedbackEffects(prototype));
  body.push(...emitEventEffects(prototype));
  body.push(...emitPropWatches(prototype));
  body.push(...emitLifecycleEffects(prototype));
  prototype.rules.forEach(
    (rule, index) => body.push(variable("_rule" + index, emitCondition(rule.condition, prototype)))
  );
  const children = prototype.render.kind === "static-tree" || prototype.render.kind === "reactive-tree" ? [{ kind: "element", node: prototype.render.root }] : prototype.render.kind === "fragment" ? prototype.render.children : [{ kind: "slot" }];
  const root = { tag: "div", children };
  body.push(f.createReturnStatement(emitTemplate(root, prototype, true)));
  statements.push(
    f.createFunctionDeclaration(
      [f.createModifier(ts10.SyntaxKind.ExportKeyword)],
      void 0,
      componentName,
      void 0,
      [
        f.createParameterDeclaration(
          void 0,
          void 0,
          "props",
          void 0,
          f.createTypeReferenceNode(propsName)
        )
      ],
      reactType("ReactElement"),
      block(body)
    ),
    f.createExportAssignment(void 0, false, id(componentName))
  );
  const source = f.createSourceFile(
    statements,
    f.createToken(ts10.SyntaxKind.EndOfFileToken),
    ts10.NodeFlags.None
  );
  return {
    code: ts10.createPrinter({ newLine: ts10.NewLineKind.LineFeed }).printFile(source),
    componentName,
    tier: prototype.props.length || prototype.states.length || prototype.events.length || prototype.lifecycleHandlers?.length || prototype.propWatches?.length ? "reactive" : "static",
    dependencies: ["react"]
  };
}

// packages/compiler/src/targets/gpui.ts
import fs3 from "node:fs";
import os2 from "node:os";
import path4 from "node:path";
import { spawnSync as spawnSync2 } from "node:child_process";
import { createHash as createHash2 } from "node:crypto";
var GPUI_V2_DEPENDENCY = Object.freeze({
  git: "https://github.com/zed-industries/zed",
  revision: "62e5991dd0f0c8a3af8d5e7e9c4652490d468db8"
});
var STYLE_METHODS = {
  flex: "flex",
  "flex-col": "flex_col",
  "flex-row": "flex_row",
  "items-center": "items_center",
  "items-start": "items_start",
  "items-end": "items_end",
  "justify-center": "justify_center",
  "justify-between": "justify_between",
  "justify-start": "justify_start",
  "justify-end": "justify_end",
  "w-full": "w_full",
  "h-full": "h_full",
  "size-full": "size_full",
  "rounded-none": "rounded_none",
  rounded: "rounded",
  "rounded-sm": "rounded_sm",
  "rounded-md": "rounded_md",
  "rounded-lg": "rounded_lg",
  "rounded-full": "rounded_full",
  "cursor-pointer": "cursor_pointer",
  "overflow-hidden": "overflow_hidden",
  "text-xs": "text_xs",
  "text-sm": "text_sm",
  "text-base": "text_base",
  "text-lg": "text_lg",
  "text-xl": "text_xl",
  "text-2xl": "text_2xl"
};
var COLORS = {
  black: 0,
  white: 16777215,
  "red-500": 15680580,
  "green-500": 2278750,
  "blue-500": 3900150,
  "gray-100": 15987958,
  "gray-500": 7041664,
  "gray-900": 1120295
};
var identifier = (prefix, name) => prefix + name.replace(/[^A-Za-z0-9_]/g, "_");
var scalarType2 = (value) => typeof value === "number" || typeof value === "string" || typeof value === "boolean" ? typeof value : void 0;
var hasLoneSurrogate = (value) => /[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/u.test(value);
function buildPlan(proto, options) {
  const issues = [];
  const reject = (message) => issues.push(diagnostic("PUI_GPUI_UNSUPPORTED", "codegen", message, proto.span));
  const componentName = options.componentName ?? proto.name.split(/[^A-Za-z0-9]+/).map((part) => part.slice(0, 1).toUpperCase() + part.slice(1)).join("");
  if (!/^[A-Z][A-Za-z0-9_]*$/.test(componentName) || componentName === "Self") {
    reject("GPUI requires a non-reserved PascalCase component name.");
  }
  for (const gap of proto.unlowered ?? []) reject(gap.operation + ": " + gap.message);
  if (proto.hooks.some((hook) => !hook.lowered) || proto.contexts.length || proto.exposes.length) {
    reject(
      "GPUI unlowered hooks, context and expose require native lowering that is not implemented."
    );
  }
  if (proto.lifecycle.some((name) => name !== "onCreated") || proto.lifecycleHandlers?.some((handler) => handler.phase !== "created")) {
    reject(
      "GPUI mount/update/unmount/dispose callbacks require native commit and mount-epoch lowering."
    );
  }
  if (proto.lifecycle.includes("onCreated") && !proto.lifecycleHandlers?.some((handler) => handler.phase === "created")) {
    reject("GPUI created callbacks require a lowered ordered action body.");
  }
  const hasUpdateRequest = (body) => body.some(
    (statement) => statement.kind === "request-update" || statement.kind === "invoke" && hasUpdateRequest(statement.body) || statement.kind === "if" && (hasUpdateRequest(statement.then) || hasUpdateRequest(statement.otherwise))
  );
  if (proto.lifecycleHandlers?.some(
    (handler) => handler.phase === "created" && hasUpdateRequest(handler.body)
  )) {
    reject(
      "GPUI created-time update requests require a native instance context before initial render."
    );
  }
  const checkCallbackOrder = (label, bodies) => {
    const callbacks = bodies.map((body) => ({ kind: "invoke", body }));
    for (const issue of getUpdateOrderingIssues(callbacks)) reject(label + ": " + issue);
  };
  const eventBodies = /* @__PURE__ */ new Map();
  for (const event of proto.events) {
    const key = event.scope + ":" + event.eventName;
    const group = eventBodies.get(key) ?? [];
    group.push(event.body ?? []);
    eventBodies.set(key, group);
  }
  for (const [key, bodies] of eventBodies) checkCallbackOrder("GPUI event " + key, bodies);
  checkCallbackOrder(
    "GPUI resolved prop watchers",
    (proto.propWatches ?? []).map((watch) => watch.body)
  );
  if (proto.render.kind === "dynamic") reject("GPUI dynamic render requires native lowering.");
  const props = /* @__PURE__ */ new Map();
  const nullableProps = /* @__PURE__ */ new Set();
  const propPlans = [];
  const states = /* @__PURE__ */ new Map();
  const statePlans = [];
  const names = /* @__PURE__ */ new Set();
  const checkLiteral = (literal, expected, label) => {
    if (literal === void 0 || scalarType2(literal) !== expected)
      reject(label + " requires an explicit " + expected + " value.");
    if (typeof literal === "string" && hasLoneSurrogate(literal))
      reject(label + " contains an unpaired UTF-16 surrogate.");
  };
  for (const prop2 of proto.props) {
    const type = prop2.kind === "enum" ? "string" : prop2.kind;
    if (type !== "number" && type !== "boolean" && type !== "string") {
      reject("GPUI prop " + prop2.name + " has unsupported type " + prop2.kind + ".");
      continue;
    }
    props.set(prop2.name, type);
    if (prop2.range && type !== "number") reject("GPUI range constraints require a numeric prop.");
    if (typeof prop2.defaultValue === "string" && hasLoneSurrogate(prop2.defaultValue)) {
      reject("Default for prop " + prop2.name + " contains an unpaired UTF-16 surrogate.");
    }
    const validDefault = scalarType2(prop2.defaultValue ?? null) === type && (type !== "number" || Number.isFinite(prop2.defaultValue)) && (prop2.kind !== "enum" || !!prop2.options?.includes(prop2.defaultValue)) && (!prop2.range || typeof prop2.defaultValue === "number" && (prop2.range.min === void 0 || prop2.defaultValue >= prop2.range.min) && (prop2.range.max === void 0 || prop2.defaultValue <= prop2.range.max));
    if (!validDefault || prop2.empty === "accept") nullableProps.add(prop2.name);
    propPlans.push({ ...prop2, resolvedDefault: validDefault ? prop2.defaultValue : null });
    const field = identifier("prop_", prop2.name);
    if (names.has(field)) reject("GPUI prop names collide after identifier normalization.");
    names.add(field);
    if (prop2.kind === "enum" && (!prop2.options?.length || prop2.options.some((v) => typeof v !== "string"))) {
      reject("GPUI enums require a non-empty list of string members.");
    }
  }
  for (const state of proto.states) {
    const type = state.kind === "bool" ? "boolean" : state.kind === "string" || state.kind === "enum" ? "string" : "number";
    states.set(state.name, type);
    if (state.options?.some(
      (value) => scalarType2(value) !== type || typeof value === "string" && hasLoneSurrogate(value)
    )) {
      reject("GPUI state options must be well-formed literals of the declared scalar type.");
    }
    checkLiteral(state.initialValue, type, "Initial state " + state.name);
    let initialValue = state.initialValue;
    if (state.kind === "number.range") {
      if (typeof state.min !== "number" || typeof state.max !== "number" || Number.isNaN(state.min) || Number.isNaN(state.max))
        reject("GPUI number.range requires explicit non-NaN min and max bounds.");
      if (typeof initialValue === "number" && state.clamp) {
        if (state.min !== void 0 && initialValue < state.min) initialValue = state.min;
        else if (state.max !== void 0 && initialValue > state.max) initialValue = state.max;
      }
    }
    if (state.step !== void 0 && state.kind !== "number.discrete")
      reject("GPUI step policy belongs to number.discrete state.");
    if (state.clamp !== void 0 && state.kind !== "number.range")
      reject("GPUI clamp policy belongs to number.range state.");
    if (type === "number" && Number.isNaN(state.initialValue)) {
      reject("GPUI numeric state initial value cannot be NaN.");
    }
    if (state.options?.length && !state.options.includes(initialValue)) {
      reject("GPUI initial state must be in its declared options.");
    } else if (!state.options?.length && typeof initialValue === "number" && (state.min !== void 0 && initialValue < state.min || state.max !== void 0 && initialValue > state.max)) {
      reject("GPUI initial state violates its numeric bounds.");
    }
    if (state.kind === "number.discrete" && !state.options?.length && state.step !== void 0 && state.step > 0 && typeof initialValue === "number" && !Number.isInteger((initialValue - (state.min ?? 0)) / state.step)) {
      reject("GPUI initial state violates its numeric step.");
    }
    statePlans.push({ ...state, initialValue });
    const field = identifier("state_", state.name);
    if (names.has(field)) reject("GPUI state names collide after identifier normalization.");
    names.add(field);
    if (state.kind === "enum" && (!state.options?.length || state.options.some((v) => typeof v !== "string"))) {
      reject("GPUI enums require a non-empty list of string members.");
    }
  }
  const styles = (tokens) => tokens.flatMap((token) => {
    if (STYLE_METHODS[token]) return [{ method: STYLE_METHODS[token] }];
    const spacing = /^(p|px|py|pt|pb|pl|pr|gap|w|h)-(0|1|2|3|4|5|6|8|10|12|16|20|24|32|48|64)$/.exec(token);
    if (spacing) return [{ method: spacing[1] + "_" + spacing[2] }];
    const color = /^(bg|text)-(.+)$/.exec(token);
    if (color && COLORS[color[2]] !== void 0) {
      return [{ method: color[1] === "bg" ? "bg" : "text_color", color: COLORS[color[2]] }];
    }
    if (token === "font-bold" || token === "font-normal") {
      return [{ method: "font_weight", weight: token === "font-bold" ? "BOLD" : "NORMAL" }];
    }
    reject("GPUI style token is unsupported: " + token);
    return [];
  });
  const checkStyleCascade = (declarations) => {
    const properties = /* @__PURE__ */ new Map();
    for (const style of declarations) {
      const method = style.method;
      let affected = [method];
      const spacing = /^(p|px|py|pt|pb|pl|pr|gap|w|h|size)_/.exec(method)?.[1];
      if (spacing)
        affected = {
          p: ["padding-top", "padding-bottom", "padding-left", "padding-right"],
          px: ["padding-left", "padding-right"],
          py: ["padding-top", "padding-bottom"],
          pt: ["padding-top"],
          pb: ["padding-bottom"],
          pl: ["padding-left"],
          pr: ["padding-right"],
          gap: ["gap-x", "gap-y"],
          w: ["width"],
          h: ["height"],
          size: ["width", "height"]
        }[spacing];
      else if (method === "flex_row" || method === "flex_col") affected = ["flex-direction"];
      else if (method.startsWith("items_")) affected = ["align-items"];
      else if (method.startsWith("justify_")) affected = ["justify-content"];
      else if (method.startsWith("rounded")) affected = ["border-radius"];
      else if (method.startsWith("text_") && method !== "text_color")
        affected = ["font-size", "line-height"];
      const signature = JSON.stringify(style);
      for (const property of affected) {
        if (properties.has(property) && properties.get(property) !== signature) {
          reject(
            "Overlapping GPUI styles require canonical cascade lowering for " + property + "."
          );
        }
        properties.set(property, signature);
      }
    }
  };
  const expression = (expr, locals, previousAllowed = false) => {
    let type;
    let data = { ...expr };
    if (expr.kind === "literal") {
      type = scalarType2(expr.value);
      if (typeof expr.value === "string" && hasLoneSurrogate(expr.value))
        reject("A GPUI string literal contains an unpaired surrogate.");
    } else if (expr.kind === "state") type = states.get(expr.name);
    else if (expr.kind === "prop") {
      if (expr.source === "previous" && !previousAllowed)
        reject("GPUI previous-props reads are only valid inside a prop watch.");
      if (nullableProps.has(expr.name))
        reject(
          "Nullable GPUI prop " + expr.name + " is currently supported only in direct render and rule conditions."
        );
      type = props.get(expr.name);
    } else if (expr.kind === "local") type = locals.get(expr.name);
    else if (expr.kind === "unary") {
      const operand = expression(expr.operand, locals, previousAllowed);
      type = expr.operator === "!" ? "boolean" : "number";
      if (operand.valueType !== type)
        reject("GPUI unary operands require an explicit native scalar type.");
      data = { ...expr, operand };
    } else if (expr.kind === "binary") {
      const left = expression(expr.left, locals, previousAllowed), right = expression(expr.right, locals, previousAllowed);
      if (left.valueType !== right.valueType)
        reject("GPUI binary operands must have matching scalar types.");
      if (["===", "!==", "<", "<=", ">", ">="].includes(expr.operator)) type = "boolean";
      else type = left.valueType;
      if (["&&", "||"].includes(expr.operator) && left.valueType !== "boolean")
        reject("GPUI short-circuit operands must be boolean.");
      if (expr.operator === "+" && left.valueType !== "number" && left.valueType !== "string")
        reject("GPUI addition requires number or string operands.");
      if (["-", "*", "/", "%", "<", "<=", ">", ">="].includes(expr.operator) && left.valueType !== "number") {
        reject("GPUI arithmetic and ordered comparison require numbers.");
      }
      if (expr.operator === "??")
        reject("GPUI nullish values are not represented by this typed target.");
      data = { ...expr, left, right };
    } else if (expr.kind === "conditional") {
      const condition = expression(expr.condition, locals, previousAllowed);
      const then = expression(expr.then, locals, previousAllowed), otherwise = expression(expr.otherwise, locals, previousAllowed);
      if (condition.valueType !== "boolean" || then.valueType !== otherwise.valueType) {
        reject("GPUI conditional expression has incompatible native types.");
      }
      type = then.valueType;
      data = { ...expr, condition, then, otherwise };
    }
    if (!type) reject("GPUI expression has no supported native scalar type.");
    return { ...data, valueType: type };
  };
  const actions = (body, inherited = /* @__PURE__ */ new Map(), previousAllowed = false) => {
    const locals = new Map(inherited);
    return body.map((statement) => {
      if (statement.kind === "return" || statement.kind === "request-update") return statement;
      if (statement.kind === "invoke")
        return { ...statement, body: actions(statement.body, locals, previousAllowed) };
      if (statement.kind === "if") {
        const condition = expression(statement.condition, locals, previousAllowed);
        if (condition.valueType !== "boolean") reject("GPUI action condition must be boolean.");
        return {
          ...statement,
          condition,
          then: actions(statement.then, locals, previousAllowed),
          otherwise: actions(statement.otherwise, locals, previousAllowed)
        };
      }
      const value = expression(statement.value, locals, previousAllowed);
      if (statement.kind === "local") locals.set(statement.name, value.valueType);
      else if (value.valueType !== states.get(statement.stateName))
        reject("GPUI state assignment has the wrong scalar type.");
      return { ...statement, value };
    });
  };
  const feedbackStates = /* @__PURE__ */ new Set();
  const rules = (rule) => {
    if (rule.kind === "cmp") {
      if (rule.source === "state") feedbackStates.add(rule.key);
      const type = rule.source === "state" ? states.get(rule.key) : rule.source === "prop" ? props.get(rule.key) : void 0;
      if (!type || type !== scalarType2(rule.value) || rule.operator === "gte" && type !== "number") {
        reject(
          "GPUI rule requires a known compatible prop/state scalar; meta reads are unsupported."
        );
      }
      return { ...rule, valueType: type };
    }
    if (rule.kind === "not") return { ...rule, expr: rules(rule.expr) };
    if (rule.kind === "all" || rule.kind === "any")
      return { ...rule, exprs: rule.exprs.map(rules) };
    return rule;
  };
  let slotCount = 0;
  const children = (input) => input.map((child) => {
    if (child.kind === "element") return { ...child, node: tree(child.node) };
    if (child.kind === "slot") slotCount += 1;
    if (child.kind === "text" && hasLoneSurrogate(child.value))
      reject("GPUI text contains an unpaired UTF-16 surrogate.");
    if (child.kind === "state-read" && !states.has(child.stateName))
      reject("GPUI render reads undeclared state.");
    if (child.kind === "prop-read" && !props.has(child.propName))
      reject("GPUI render reads undeclared prop.");
    if (child.kind === "state-read" && states.get(child.stateName) === "boolean" || child.kind === "prop-read" && props.get(child.propName) === "boolean") {
      reject(
        "Boolean values are not TemplateChildrenInput; GPUI does not invent their text representation."
      );
    }
    return child;
  });
  const tree = (node) => {
    if (node.tag !== "div" && node.tag !== "span") {
      reject(
        "GPUI element " + node.tag + " requires explicit native semantics; only div/span are currently admitted."
      );
    }
    const nativeStyles = styles(node.styleTokens ?? []);
    checkStyleCascade(nativeStyles);
    return {
      ...node,
      styles: nativeStyles,
      children: children(node.children)
    };
  };
  checkStyleCascade(
    styles([...proto.staticStyleTokens, ...proto.rules.flatMap((rule) => rule.styleTokens)])
  );
  const root = {
    tag: "div",
    styles: [],
    children: children(
      proto.render.kind === "static-tree" || proto.render.kind === "reactive-tree" ? [{ kind: "element", node: proto.render.root }] : proto.render.kind === "default-slot" ? [{ kind: "slot" }] : proto.render.kind === "fragment" ? proto.render.children : []
    )
  };
  if (slotCount > 1) reject("A template may contain at most one anonymous slot.");
  const plan = {
    protocolVersion: 1,
    componentName,
    propsTypeName: componentName + "Props",
    childrenTypeName: slotCount === 1 ? componentName + "Child" : void 0,
    hasSlot: slotCount === 1,
    dependency: GPUI_V2_DEPENDENCY,
    workspaceDependency: options.gpuiDependency === "workspace",
    props: propPlans,
    states: statePlans,
    created: (proto.lifecycleHandlers ?? []).filter((handler) => handler.phase === "created").map((handler, index) => ({
      method: "handle_created_" + index,
      body: actions(handler.body)
    })),
    propWatches: (proto.propWatches ?? []).map((watch, index) => {
      if (watch.keys !== null && (!watch.keys.length || watch.keys.some((key) => !props.has(key))))
        reject("GPUI prop watches require a non-empty selection of declared keys or watchAll.");
      return {
        method: "handle_props_watch_" + index,
        keys: watch.keys ?? [...props.keys()],
        body: actions(watch.body, /* @__PURE__ */ new Map(), true)
      };
    }),
    styles: styles(proto.staticStyleTokens),
    root,
    rules: proto.rules.map((rule) => {
      if (rule.dynamic) reject("GPUI dynamic rule has no native lowering.");
      return { ...rule, condition: rules(rule.condition), styles: styles(rule.styleTokens) };
    }),
    feedbackStates: [...feedbackStates],
    events: proto.events.map((event, index) => {
      if (event.scope !== "root" || event.eventName !== "host:click") {
        reject(
          "GPUI event " + event.eventName + " has no admitted native mapping; semantic intents are not aliased to clicks."
        );
      }
      if (!event.body) reject("GPUI events require a lowered ordered action body.");
      return { method: "handle_click_" + index, body: actions(event.body ?? []) };
    })
  };
  return issues.length ? err(issues) : ok(plan);
}
function stringifyPlan(plan) {
  return JSON.stringify(plan, (_key, value) => {
    if (typeof value === "bigint") return value.toString();
    if (typeof value === "number" && (!Number.isFinite(value) || Object.is(value, -0))) {
      return {
        $number: Number.isNaN(value) ? "nan" : value === Infinity ? "+infinity" : value === -Infinity ? "-infinity" : "-zero"
      };
    }
    return value;
  });
}
function emitGpuiComponent(proto, options = {}) {
  const plan = buildPlan(proto, options);
  if (!plan.ok) return plan;
  const root = resolveCompilerNativeAsset("rust-builder");
  const manifest = path4.join(root, "Cargo.toml");
  const source = path4.join(root, "src/main.rs");
  const lock = path4.join(root, "Cargo.lock");
  if (!fs3.existsSync(manifest) || !fs3.existsSync(source) || !fs3.existsSync(lock)) {
    return err([
      diagnostic(
        "PUI_GPUI_BUILDER001",
        "codegen",
        "The Rust AST builder is missing from this compiler installation."
      )
    ]);
  }
  const version = spawnSync2("cargo", ["--version"], { encoding: "utf8", timeout: 1e4 });
  if (version.status !== 0)
    return err([
      diagnostic(
        "PUI_GPUI_BUILDER001",
        "codegen",
        "GPUI emission requires Cargo and the Rust AST builder; there is no source-template fallback."
      )
    ]);
  const digest = createHash2("sha256").update(fs3.readFileSync(source)).update(fs3.readFileSync(manifest)).update(fs3.readFileSync(lock)).update(version.stdout).digest("hex");
  const targetDir = path4.join(os2.tmpdir(), "pui-rust-ast-builder", digest);
  const executable = path4.join(
    targetDir,
    "debug",
    process.platform === "win32" ? "proto-ui-rust-ast-builder.exe" : "proto-ui-rust-ast-builder"
  );
  if (!fs3.existsSync(executable)) {
    const built2 = spawnSync2(
      "cargo",
      ["build", "--locked", "--manifest-path", manifest, "--target-dir", targetDir],
      { encoding: "utf8", timeout: 12e4, maxBuffer: 4 * 1024 * 1024 }
    );
    if (built2.status !== 0)
      return err([
        diagnostic(
          "PUI_GPUI_BUILDER002",
          "codegen",
          "Building the syn/prettyplease driver failed: " + (built2.stderr || built2.error?.message || "unknown failure")
        )
      ]);
  }
  const built = spawnSync2(executable, [], {
    input: stringifyPlan(plan.value),
    encoding: "utf8",
    timeout: 3e4,
    maxBuffer: 8 * 1024 * 1024
  });
  if (built.status !== 0)
    return err([
      diagnostic(
        "PUI_GPUI_BUILDER003",
        "codegen",
        "Rust AST construction failed: " + (built.stderr || built.error?.message || "unknown failure")
      )
    ]);
  try {
    const output = JSON.parse(built.stdout);
    return ok({ ...output, dependency: GPUI_V2_DEPENDENCY, backend: "syn-prettyplease" });
  } catch (error) {
    return err([
      diagnostic(
        "PUI_GPUI_BUILDER003",
        "codegen",
        "Invalid Rust builder response: " + String(error)
      )
    ]);
  }
}

// packages/compiler/src/targets/kernel.ts
function getKernelLoweringDiagnostics(module) {
  const issues = [];
  for (const proto of module.prototypes) {
    const reject = (message) => issues.push(diagnostic("PUI_KERNEL_UNSUPPORTED", "llvm", message, proto.span));
    for (const gap of proto.unlowered ?? []) reject(gap.operation + ": " + gap.message);
    if (proto.hooks.some((hook) => !hook.lowered) || proto.contexts.length || proto.exposes.length || proto.lifecycle.length || proto.propWatches?.length) {
      reject(
        "The scalar kernel target cannot omit host hooks, context, exposed operations, lifecycle effects or property subscriptions."
      );
    }
    if (proto.rules.length > 31)
      reject(
        "The current combined rule ABI has 31 bits; additional rules require a wider representation."
      );
    const condition = (value) => {
      if (value.kind === "not") return condition(value.expr);
      if (value.kind === "all" || value.kind === "any") {
        value.exprs.forEach(condition);
        return;
      }
      if (value.kind !== "cmp") return;
      const declaration = value.source === "prop" ? proto.props.find((prop2) => prop2.name === value.key) : value.source === "state" ? proto.states.find((state) => state.name === value.key) : void 0;
      if (!declaration) {
        reject("Kernel rule references an unresolved input: " + value.source + "." + value.key);
        return;
      }
      const kind = declaration.kind;
      const type = kind === "bool" ? "boolean" : kind === "enum" ? "string" : kind.startsWith("number.") ? "number" : kind;
      if (value.value === null || typeof value.value !== type)
        reject("Kernel comparison requires compatible non-null scalar inputs.");
      if (value.operator === "gte" && (type !== "number" || typeof value.value !== "number" || !Number.isFinite(value.value)))
        reject("Kernel gte requires a numeric input and a finite threshold.");
      if (value.source === "prop") {
        const prop2 = proto.props.find((prop3) => prop3.name === value.key);
        if (prop2.empty === "accept" || prop2.defaultValue === void 0 || prop2.defaultValue === null)
          reject("Nullable props require a tagged kernel representation.");
      }
    };
    for (const rule of proto.rules) {
      if (rule.dynamic) reject("Dynamic rule conditions have no scalar kernel lowering.");
      condition(rule.condition);
    }
    const validInitial = (state) => {
      const value = state.initialValue;
      if (state.kind === "bool") return typeof value === "boolean";
      if (state.kind === "enum" || state.kind === "string")
        return typeof value === "string" && (state.kind !== "enum" || !!state.options?.length) && (!state.options?.length || state.options.includes(value));
      if (typeof value !== "number" || Number.isNaN(value)) return false;
      if (state.options?.length) return state.options.includes(value);
      return (state.min === void 0 || value >= state.min) && (state.max === void 0 || value <= state.max) && (state.step === void 0 || state.step <= 0 || Number.isInteger((value - (state.min ?? 0)) / state.step));
    };
    for (const state of proto.states)
      if (!validInitial(state))
        reject("Kernel state initializer requires domain normalization: " + state.name);
    for (const event of proto.events) {
      const action = event.simpleAction;
      if (!action) {
        reject("The ordered event action body needs SSA control-flow lowering: " + event.eventName);
        continue;
      }
      const state = proto.states.find((state2) => state2.name === action.stateName);
      if (!state) {
        reject("Kernel event references an undeclared state: " + action.stateName);
        continue;
      }
      if (state.min !== void 0 || state.max !== void 0 || state.step !== void 0 || state.options?.length) {
        reject("Kernel event writes require domain validation before storage: " + state.name);
      }
      if (action.kind === "increment-state" && (state.ssaType !== "f64" || !Number.isFinite(action.delta)))
        reject("Kernel increment requires a numeric state and a finite delta.");
      if (action.kind === "toggle-state" && state.kind !== "bool")
        reject("Kernel toggle requires a boolean state.");
      if (action.kind === "set-state" && !validInitial({ ...state, initialValue: action.value }))
        reject("Kernel state assignment violates its scalar domain.");
    }
  }
  return issues;
}

// packages/compiler/src/targets/kinds.ts
var COMPONENT_TARGETS = ["react", "gpui"];
var COMPILATION_TARGETS = [...COMPONENT_TARGETS, "kernel", "ir"];

// packages/compiler/src/compiler.ts
function selectedTarget(options) {
  return options.target ?? "react";
}
function finalizeCompilation(extracted, options, startedAt) {
  const allDiags = [...extracted.diagnostics];
  const target = selectedTarget(options);
  if (!COMPILATION_TARGETS.includes(target))
    return err([
      ...allDiags,
      diagnostic(
        "PUI_TARGET_INVALID",
        "input",
        "Unsupported compilation target: " + String(target),
        {
          file: extracted.ir.sourceFile,
          line: 1,
          column: 1
        }
      )
    ]);
  const hasErrors = allDiags.some((d) => d.severity === "error");
  if (hasErrors) return err(allDiags);
  const { ir: rawIr } = extracted;
  if (rawIr.prototypes.length === 0 && !(options.allowHookOnly && rawIr.authoredHooks.length > 0)) {
    const detail = options.exportName ? `Export '${options.exportName}' is not a definePrototype() declaration in ${rawIr.sourceFile}.` : `No definePrototype() declaration found in ${rawIr.sourceFile}.`;
    return err([
      ...allDiags,
      diagnostic("PUI_FE002", "frontend", detail, { file: rawIr.sourceFile, line: 1, column: 1 })
    ]);
  }
  const verifyIssues = verifyModuleIR(rawIr);
  if (verifyIssues.length > 0) return err([...allDiags, ...verifyIssues]);
  const { ir, stats: ssaStats } = optimizeModuleIR(rawIr);
  const postVerifyIssues = verifyModuleIR(ir);
  if (postVerifyIssues.length > 0) return err([...allDiags, ...postVerifyIssues]);
  if (target === "react") {
    for (const proto of ir.prototypes) allDiags.push(...getReactLoweringDiagnostics(proto));
    if (allDiags.some((d) => d.severity === "error")) return err(allDiags);
  }
  const prototypes = [];
  const gpuiPrototypes = [];
  for (const [index, proto] of ir.prototypes.entries()) {
    const component = index === 0 && options.componentName ? { componentName: options.componentName } : {};
    if (target === "react") {
      try {
        const react2 = emitReactComponent(proto, component);
        prototypes.push({
          name: proto.name,
          exportName: proto.exportName,
          tier: react2.tier,
          react: react2
        });
      } catch (error) {
        return err([
          ...allDiags,
          diagnostic(
            "PUI_REACT_EMIT",
            "codegen",
            error instanceof Error ? error.message : String(error),
            proto.span
          )
        ]);
      }
    } else if (target === "gpui") {
      const output = emitGpuiComponent(proto, { ...options.gpui, ...component });
      allDiags.push(...output.diagnostics);
      if (!output.ok) return err(allDiags);
      gpuiPrototypes.push({ name: proto.name, exportName: proto.exportName, gpui: output.value });
    }
  }
  let llvmIr = "";
  const llvmRequested = options.llvm !== void 0 || target === "kernel";
  const tc = llvmRequested ? detectLlvmToolchain() : { available: false, version: void 0 };
  if (llvmRequested) {
    const kernelIssues = getKernelLoweringDiagnostics(ir);
    if (kernelIssues.length) return err([...allDiags, ...kernelIssues]);
    const emission = emitLlvmIRResult(ir, { targetTriple: options.llvm?.targetTriple });
    if (!emission.ok) return err([...allDiags, ...emission.diagnostics]);
    llvmIr = emission.value;
  }
  let verified = false;
  let optimizedIr;
  let wasm;
  if (options.llvm?.emitWasm) {
    const wasmRes = compileLlvmToWasm(llvmIr, {
      level: typeof options.llvm.optimize === "string" ? options.llvm.optimize : "O2"
    });
    if (!wasmRes.ok) return err([...allDiags, ...wasmRes.diagnostics]);
    verified = true;
    optimizedIr = wasmRes.value.optimizedIr;
    wasm = wasmRes.value.wasm;
  } else if (options.llvm?.optimize) {
    if (tc.available) {
      const level = typeof options.llvm.optimize === "string" ? options.llvm.optimize : "O2";
      const optRes = optimizeLlvmIr(llvmIr, { level });
      if (!optRes.ok) return err([...allDiags, ...optRes.diagnostics]);
      verified = true;
      optimizedIr = optRes.value.ir;
    } else {
      return err([
        ...allDiags,
        diagnostic(
          "PUI_LLVM_UNAVAILABLE",
          "llvm",
          "LLVM optimization was requested but its toolchain is unavailable."
        )
      ]);
    }
  } else if (options.llvm?.verify && tc.available) {
    const verRes = verifyLlvmIr(llvmIr);
    if (!verRes.ok) return err([...allDiags, ...verRes.diagnostics]);
    verified = true;
  } else if (options.llvm?.verify) {
    return err([
      ...allDiags,
      diagnostic(
        "PUI_LLVM_UNAVAILABLE",
        "llvm",
        "LLVM verification was requested but its toolchain is unavailable."
      )
    ]);
  }
  return ok(
    {
      artifactKind: target === "react" ? "react-components" : target === "gpui" ? "gpui-components" : target === "kernel" ? "kernel-module" : "semantic-ir",
      sourceFile: ir.sourceFile,
      ir,
      irText: printModuleIR(ir),
      ssaStats,
      prototypes,
      primary: prototypes[0],
      gpuiPrototypes,
      primaryGpui: gpuiPrototypes[0],
      llvm: {
        emitted: llvmRequested,
        ir: llvmIr,
        ...optimizedIr !== void 0 ? { optimizedIr } : {},
        verified,
        ...tc.version ? { toolchainVersion: tc.version } : {},
        ...wasm ? { wasm } : {}
      },
      elapsedMs: performance.now() - startedAt
    },
    allDiags
  );
}
function createCompiler(options = {}) {
  const session = new TsProgramSession(options);
  return {
    session,
    compileFile(entryFile, compileOptions = {}) {
      const startedAt = performance.now();
      const absPath = path5.resolve(session.rootDir, entryFile);
      if (!fs4.existsSync(absPath)) {
        return err([diagnostic("PUI_IO001", "io", `Entry file does not exist: ${absPath}`)]);
      }
      const program = session.ensureFiles([absPath]);
      const extracted = extractModuleIR(program, absPath, {
        exportName: compileOptions.exportName,
        checkTypes: compileOptions.checkTypes
      });
      return finalizeCompilation(extracted, compileOptions, startedAt);
    },
    compilePrototype(source, compileOptions = {}) {
      const startedAt = performance.now();
      const fileName = compileOptions.fileName ?? "__virtual__.proto.ts";
      const { program, entryPath } = session.createVirtualProgram(
        fileName,
        source,
        compileOptions.files
      );
      const extracted = extractModuleIR(program, entryPath, {
        exportName: compileOptions.exportName,
        checkTypes: compileOptions.checkTypes
      });
      return finalizeCompilation(extracted, compileOptions, startedAt);
    },
    compileProject(entries, compileOptions = {}) {
      const startedAt = performance.now();
      const resolved = entries.map((e) => path5.resolve(session.rootDir, e));
      for (const file of resolved) {
        if (!fs4.existsSync(file)) {
          return err([diagnostic("PUI_IO001", "io", `Entry file does not exist: ${file}`)]);
        }
      }
      const program = session.ensureFiles(resolved);
      const outputs = [];
      const diagnostics = [];
      let totalPrototypes = 0;
      let totalAuthoredHooks = 0;
      for (const absPath of resolved) {
        const fileStart = performance.now();
        const extracted = extractModuleIR(program, absPath, {
          exportName: compileOptions.exportName,
          checkTypes: compileOptions.checkTypes
        });
        const res = finalizeCompilation(extracted, compileOptions, fileStart);
        diagnostics.push(...res.diagnostics);
        if (!res.ok) return err(diagnostics);
        outputs.push(res.value);
        totalPrototypes += res.value.prototypes.length + res.value.gpuiPrototypes.length;
        totalAuthoredHooks += res.value.ir.authoredHooks.length;
      }
      return ok(
        {
          files: outputs,
          totalPrototypes,
          totalAuthoredHooks,
          totalElapsedMs: performance.now() - startedAt
        },
        diagnostics
      );
    },
    inventoryProject(entries, compileOptions = {}) {
      const target = selectedTarget(compileOptions);
      if (target !== "react" && target !== "gpui")
        return err([
          diagnostic(
            "PUI_COVERAGE_TARGET",
            "input",
            "Native coverage must select the React or GPUI component target."
          )
        ]);
      const resolved = [...new Set(entries.map((entry) => path5.resolve(session.rootDir, entry)))];
      for (const entry of resolved)
        if (!fs4.existsSync(entry))
          return err([diagnostic("PUI_IO001", "io", "Entry file does not exist: " + entry)]);
      const program = session.ensureFiles(resolved);
      const files = [];
      for (const entry of resolved) {
        const extracted = extractModuleIR(program, entry, {
          checkTypes: compileOptions.checkTypes,
          exportName: compileOptions.exportName
        });
        const prototypes = extracted.ir.prototypes.map((proto) => proto.name);
        const authoredHooks = extracted.ir.authoredHooks.map((hook) => hook.name);
        const base = { sourceFile: entry, prototypes, authoredHooks, nativeEmittedPrototypes: 0 };
        if (extracted.diagnostics.some((issue) => issue.severity === "error")) {
          files.push({ ...base, status: "source-error", diagnostics: extracted.diagnostics });
        } else if (prototypes.length === 0 && authoredHooks.length > 0) {
          files.push({ ...base, status: "hook-analysis", diagnostics: extracted.diagnostics });
        } else {
          const compiled = finalizeCompilation(
            extracted,
            { ...compileOptions, target, llvm: void 0 },
            performance.now()
          );
          files.push({
            ...base,
            status: compiled.ok ? "emitted" : "unsupported",
            nativeEmittedPrototypes: compiled.ok ? compiled.value.prototypes.length + compiled.value.gpuiPrototypes.length : 0,
            diagnostics: compiled.diagnostics
          });
        }
      }
      const totals = {
        inputFiles: files.length,
        analyzedFiles: files.filter((file) => file.status !== "source-error").length,
        prototypeDeclarations: files.reduce((sum, file) => sum + file.prototypes.length, 0),
        authoredHookDeclarations: files.reduce((sum, file) => sum + file.authoredHooks.length, 0),
        nativeEmittedPrototypes: files.reduce((sum, file) => sum + file.nativeEmittedPrototypes, 0),
        unsupportedPrototypes: files.filter((file) => file.status === "unsupported").reduce((sum, file) => sum + file.prototypes.length, 0),
        sourceErrorFiles: files.filter((file) => file.status === "source-error").length,
        executionVerifiedPrototypes: 0
      };
      return ok({
        schemaVersion: 1,
        target,
        files,
        totals,
        completeNativeCoverage: totals.prototypeDeclarations > 0 && files.every((file) => file.status === "emitted" || file.status === "hook-analysis") && totals.nativeEmittedPrototypes === totals.prototypeDeclarations
      });
    }
  };
}

// packages/compiler/src/output.ts
import fs5 from "node:fs";
import path6 from "node:path";
function existingStat(file) {
  try {
    return fs5.lstatSync(file);
  } catch (error) {
    if (error.code === "ENOENT") return void 0;
    throw error;
  }
}
function assertPlainPath(file) {
  const absolute = path6.resolve(file);
  const parts = absolute.slice(path6.parse(absolute).root.length).split(path6.sep).filter(Boolean);
  let current = path6.parse(absolute).root;
  for (let index = 0; index < parts.length; index++) {
    current = path6.join(current, parts[index]);
    const stat = existingStat(current);
    if (stat?.isSymbolicLink())
      throw new Error("Refusing a symbolic link in a generated output path: " + current);
    if (stat && index < parts.length - 1 && !stat.isDirectory())
      throw new Error("Generated output ancestor is not a directory: " + current);
  }
}
function sameFile(left, right) {
  return !!left && left.dev === right.dev && left.ino === right.ino;
}
function writeGeneratedArtifacts(outDir, artifacts, overwrite) {
  assertPlainPath(outDir);
  for (const artifact of artifacts) assertPlainPath(artifact.destination);
  fs5.mkdirSync(outDir, { recursive: true });
  assertPlainPath(outDir);
  const lock = path6.join(outDir, ".proto-compiler-write.lock");
  try {
    fs5.mkdirSync(lock);
  } catch (error) {
    if (error.code === "EEXIST")
      throw new Error("Output collision: another compiler invocation is writing " + outDir);
    throw error;
  }
  let staging;
  const published = [];
  try {
    for (const artifact of artifacts) {
      assertPlainPath(artifact.destination);
      const existing = existingStat(artifact.destination);
      if (existing && !existing.isFile())
        throw new Error("Generated output is not a regular file: " + artifact.destination);
      if (existing && !overwrite)
        throw new Error(
          "Output already exists; use --overwrite to replace generated artifacts: " + artifact.destination
        );
    }
    staging = fs5.mkdtempSync(path6.join(outDir, ".proto-compiler-stage-"));
    const prepared = artifacts.map((artifact, index) => {
      const source = path6.join(staging, String(index));
      fs5.writeFileSync(source, artifact.content, { flag: "wx" });
      return { ...artifact, source, identity: fs5.statSync(source) };
    });
    for (const artifact of prepared) {
      fs5.mkdirSync(path6.dirname(artifact.destination), { recursive: true });
      assertPlainPath(artifact.destination);
      let backup;
      if (overwrite && existingStat(artifact.destination)) {
        backup = artifact.source + ".previous";
        fs5.linkSync(artifact.destination, backup);
      }
      if (overwrite) fs5.renameSync(artifact.source, artifact.destination);
      else fs5.linkSync(artifact.source, artifact.destination);
      published.push({ destination: artifact.destination, identity: artifact.identity, backup });
    }
  } catch (error) {
    for (const artifact of published.reverse()) {
      if (!sameFile(existingStat(artifact.destination), artifact.identity)) continue;
      if (artifact.backup) fs5.renameSync(artifact.backup, artifact.destination);
      else fs5.unlinkSync(artifact.destination);
    }
    throw error;
  } finally {
    if (staging) fs5.rmSync(staging, { recursive: true, force: true });
    fs5.rmdirSync(lock);
  }
}

// packages/compiler/src/cli.ts
var commands = /* @__PURE__ */ new Set(["check", "compile", "ir", "llvm", "inventory", "info"]);
var valueFlags = /* @__PURE__ */ new Set([
  "--root",
  "--export",
  "--out",
  "--target",
  "--component",
  "--gpui-dependency"
]);
var booleanFlags = /* @__PURE__ */ new Set(["--json", "--optimize", "--wasm", "--ll", "--pir", "--overwrite"]);
var targets = new Set(COMPILATION_TARGETS);
var usage = [
  "Usage: proto-compiler <command> <entry> [options]",
  "",
  "Commands:",
  "  check      <entry>       Typecheck, verify IR and lower the selected native target",
  "  compile    <entry>       Emit the selected native target",
  "  ir         <entry>       Print semantic IR, including unresolved operations",
  "  llvm       <entry>       Build LLVM objects and print the resulting module",
  "  inventory  <paths...>    Report native emission and unsupported coverage separately",
  "  info                    Print compiler and installed LLVM toolchain status",
  "",
  "Options:",
  "  --target <react|gpui|kernel|ir>   Target (default: react)",
  "  --root <dir>                    Resolve inputs and outputs under this workspace",
  "  --export <name>                 Select one prototype export",
  "  --component <name>              Name the primary generated component",
  "  --out <dir>                     Write artifacts after all lowering succeeds",
  "  --gpui-dependency <pinned|workspace>   GPUI Cargo dependency mode",
  "  --ll                            Also emit the LLVM kernel",
  "  --wasm                          Also compile a WASM kernel (requires --out)",
  "  --optimize                      Optimize the requested LLVM kernel at O2",
  "  --pir                           Include the semantic IR artifact",
  "  --overwrite                     Replace existing generated output files",
  "  --json                          Print a structured result",
  ""
].join("\n");
function invalid(message) {
  return { exitCode: 2, stdout: "", stderr: message + "\n" };
}
function entriesUnder(input) {
  if (!fs6.statSync(input).isDirectory()) return [input];
  const entries = [];
  for (const item2 of fs6.readdirSync(input, { withFileTypes: true })) {
    if (item2.name === "node_modules" || item2.name === ".git") continue;
    const child = path7.join(input, item2.name);
    if (item2.isDirectory()) entries.push(...entriesUnder(child));
    else if (item2.isFile() && item2.name.endsWith(".proto.ts")) entries.push(child);
  }
  return entries.sort();
}
function runCompilerCli(argv) {
  const [command, ...rest] = argv;
  if (!command || command === "--help" || command === "-h")
    return { exitCode: 0, stdout: usage, stderr: "" };
  if (!commands.has(command)) return invalid("Unknown command: " + command);
  const values = /* @__PURE__ */ new Map();
  const flags = /* @__PURE__ */ new Set();
  const inputs = [];
  let positionalOnly = false;
  for (let index = 0; index < rest.length; index++) {
    const argument = rest[index];
    if (!positionalOnly && argument === "--") {
      positionalOnly = true;
      continue;
    }
    if (positionalOnly || !argument.startsWith("-")) {
      inputs.push(argument);
      continue;
    }
    if (valueFlags.has(argument)) {
      const value = rest[++index];
      if (!value || value.startsWith("--")) return invalid("Missing value for " + argument);
      if (values.has(argument)) return invalid("Duplicate option: " + argument);
      values.set(argument, value);
    } else if (booleanFlags.has(argument)) flags.add(argument);
    else return invalid("Unknown option: " + argument);
  }
  if (command === "info") {
    if (inputs.length) return invalid("The info command does not accept an entry.");
    if (values.size || [...flags].some((flag) => flag !== "--json"))
      return invalid("The info command accepts only --json.");
    return {
      exitCode: 0,
      stdout: JSON.stringify(
        {
          compiler: "@proto.ui/compiler",
          irVersion: 2,
          targets: COMPILATION_TARGETS,
          llvm: detectLlvmToolchain()
        },
        null,
        2
      ) + "\n",
      stderr: ""
    };
  }
  if (!inputs.length) return invalid("Missing entry for " + command);
  if (command !== "inventory" && inputs.length !== 1)
    return invalid(command + " accepts exactly one entry.");
  const targetText = values.get("--target") ?? (command === "llvm" ? "kernel" : command === "ir" ? "ir" : "react");
  if (!targets.has(targetText))
    return invalid("Unsupported target: " + targetText);
  const target = targetText;
  if (command === "ir" && target !== "ir" || command === "llvm" && target !== "kernel")
    return invalid("Command and target disagree.");
  const gpuiDependency = values.get("--gpui-dependency") ?? "pinned";
  if (gpuiDependency !== "pinned" && gpuiDependency !== "workspace")
    return invalid("GPUI dependency must be pinned or workspace.");
  if (values.has("--gpui-dependency") && target !== "gpui")
    return invalid("--gpui-dependency requires the GPUI target.");
  const outArgument = values.get("--out");
  if (command !== "compile" && (outArgument || ["--wasm", "--ll", "--pir", "--overwrite"].some((flag) => flags.has(flag))))
    return invalid("Artifact-writing options require the compile command.");
  if (flags.has("--pir") && !outArgument)
    return invalid("--pir requires --out; use the ir command to print IR.");
  if (flags.has("--overwrite") && !outArgument) return invalid("--overwrite requires --out.");
  if (flags.has("--optimize") && (command === "ir" || command === "inventory"))
    return invalid("--optimize requires a command that verifies or emits an LLVM kernel.");
  if (flags.has("--wasm") && !outArgument)
    return invalid("--wasm requires --out so the binary artifact can be written.");
  if (command === "inventory" && (outArgument || flags.has("--ll") || flags.has("--wasm") || flags.has("--optimize")))
    return invalid(
      "Inventory reports native component coverage and does not write kernel artifacts."
    );
  const rootDir = path7.resolve(values.get("--root") ?? process.cwd());
  const json = flags.has("--json");
  const compiler = createCompiler({ rootDir });
  const options = {
    target,
    exportName: values.get("--export"),
    componentName: values.get("--component"),
    gpui: { gpuiDependency }
  };
  try {
    if (command === "inventory") {
      if (target !== "react" && target !== "gpui")
        return invalid("Inventory requires the React or GPUI component target.");
      const entries = inputs.flatMap((input) => entriesUnder(path7.resolve(rootDir, input)));
      if (!entries.length) return invalid("No .proto.ts inputs found.");
      const report = compiler.inventoryProject(entries, options);
      if (!report.ok)
        return {
          exitCode: 1,
          stdout: json ? JSON.stringify(report, null, 2) + "\n" : "",
          stderr: json ? "" : formatDiagnostics(report.diagnostics) + "\n"
        };
      return { exitCode: 0, stdout: JSON.stringify(report.value, null, 2) + "\n", stderr: "" };
    }
    const requestLlvm = target === "kernel" || flags.has("--ll") || flags.has("--wasm") || flags.has("--optimize");
    const result = compiler.compileFile(inputs[0], {
      ...options,
      llvm: requestLlvm ? {
        verify: true,
        optimize: flags.has("--optimize") ? "O2" : false,
        emitWasm: flags.has("--wasm")
      } : void 0
    });
    if (!result.ok)
      return {
        exitCode: 1,
        stdout: json ? JSON.stringify(result, null, 2) + "\n" : "",
        stderr: json ? "" : formatDiagnostics(result.diagnostics) + "\n"
      };
    const output = result.value;
    if (command === "ir") return { exitCode: 0, stdout: output.irText + "\n", stderr: "" };
    if (command === "llvm")
      return { exitCode: 0, stdout: output.llvm.optimizedIr ?? output.llvm.ir, stderr: "" };
    if (command === "check")
      return {
        exitCode: 0,
        stdout: JSON.stringify(
          {
            ok: true,
            target,
            artifactKind: output.artifactKind,
            sourceFile: output.sourceFile,
            prototypes: output.ir.prototypes.map((proto) => proto.name),
            nativeEmittedPrototypes: output.prototypes.length + output.gpuiPrototypes.length,
            llvmEmitted: output.llvm.emitted,
            llvmVerified: output.llvm.verified,
            elapsedMs: output.elapsedMs
          },
          null,
          2
        ) + "\n",
        stderr: ""
      };
    if (!outArgument) {
      const code = target === "react" ? output.primary?.react.code : target === "gpui" ? output.primaryGpui?.gpui.code : target === "kernel" ? output.llvm.optimizedIr ?? output.llvm.ir : output.irText;
      if (code === void 0) return invalid("The selected entry has no target artifact.");
      return {
        exitCode: 0,
        stdout: json ? JSON.stringify({ ok: true, target, code }, null, 2) + "\n" : code,
        stderr: ""
      };
    }
    const outDir = path7.resolve(rootDir, outArgument);
    const artifacts = [];
    for (const artifact of output.prototypes)
      artifacts.push({
        destination: path7.join(outDir, artifact.react.componentName + ".tsx"),
        content: artifact.react.code
      });
    for (const artifact of output.gpuiPrototypes) {
      const crateDir = path7.join(outDir, artifact.gpui.componentName);
      artifacts.push({
        destination: path7.join(crateDir, "Cargo.toml"),
        content: artifact.gpui.cargoToml
      });
      artifacts.push({
        destination: path7.join(crateDir, "src/lib.rs"),
        content: artifact.gpui.code
      });
    }
    const moduleName = output.primary?.react.componentName ?? output.primaryGpui?.gpui.componentName ?? "module";
    if (output.llvm.emitted)
      artifacts.push({
        destination: path7.join(outDir, moduleName + ".ll"),
        content: output.llvm.optimizedIr ?? output.llvm.ir
      });
    if (output.llvm.wasm)
      artifacts.push({
        destination: path7.join(outDir, moduleName + ".wasm"),
        content: output.llvm.wasm
      });
    if (target === "ir" || flags.has("--pir"))
      artifacts.push({
        destination: path7.join(outDir, moduleName + ".pir.json"),
        content: output.irText
      });
    const inputPaths = new Set(
      compiler.session.ensureFiles([path7.resolve(rootDir, inputs[0])]).getSourceFiles().map((file) => path7.resolve(file.fileName))
    );
    const destinations = /* @__PURE__ */ new Set();
    for (const artifact of artifacts) {
      const relative = path7.relative(outDir, artifact.destination);
      if (relative.startsWith("..") || path7.isAbsolute(relative))
        return invalid("Generated artifact path escapes the output directory.");
      if (destinations.has(artifact.destination))
        return invalid("Generated components have a colliding artifact path.");
      destinations.add(artifact.destination);
      if (inputPaths.has(artifact.destination) || fs6.existsSync(artifact.destination) && inputPaths.has(fs6.realpathSync(artifact.destination)))
        return invalid("Refusing to overwrite a compiler input: " + artifact.destination);
      if (fs6.existsSync(artifact.destination) && !flags.has("--overwrite"))
        return invalid(
          "Output already exists; use --overwrite to replace generated artifacts: " + artifact.destination
        );
    }
    writeGeneratedArtifacts(outDir, artifacts, flags.has("--overwrite"));
    const written = artifacts.map((artifact) => artifact.destination);
    return {
      exitCode: 0,
      stdout: json ? JSON.stringify({ ok: true, target, written, elapsedMs: output.elapsedMs }, null, 2) + "\n" : written.map((file) => "wrote " + file).join("\n") + "\n",
      stderr: ""
    };
  } catch (error) {
    return {
      exitCode: 1,
      stdout: "",
      stderr: (error instanceof Error ? error.message : String(error)) + "\n"
    };
  }
}

// scripts/compiler/pinned-cli-entry.ts
if (process.argv.length === 3 && process.argv[2] === "--build-info") {
  process.stdout.write(readFileSync(new URL("./compiler-build.json", import.meta.url), "utf8"));
} else {
  const result = runCompilerCli(process.argv.slice(2));
  if (result.stdout) process.stdout.write(result.stdout);
  if (result.stderr) process.stderr.write(result.stderr);
  process.exitCode = result.exitCode;
}
//# sourceMappingURL=cli.js.map
