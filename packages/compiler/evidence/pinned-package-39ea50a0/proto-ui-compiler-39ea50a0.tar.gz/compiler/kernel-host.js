// packages/compiler/src/kernel-host.ts
var SLOT_BYTES = 8;
var PAGE_BYTES = 65536;
var MAX_WASM32_BYTES = 2 ** 32;
function nonnegativeInteger(value, label, maximum) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0 || value > maximum) {
    throw new RangeError(
      label + " must be a non-negative integer no greater than " + maximum + "."
    );
  }
  return value;
}
function metadata(exports, name) {
  const getter = exports[name];
  if (getter === void 0) return void 0;
  if (typeof getter !== "function") throw new TypeError(name + " must be an exported function.");
  return nonnegativeInteger(getter(), name, MAX_WASM32_BYTES / SLOT_BYTES);
}
function capacity(explicit, declared, label) {
  if (explicit === void 0 && declared === void 0) {
    throw new TypeError(
      "Missing " + label + ": supply an explicit capacity or compiler ABI metadata."
    );
  }
  const result = nonnegativeInteger(explicit ?? declared, label, MAX_WASM32_BYTES / SLOT_BYTES);
  if (declared !== void 0 && result < declared) {
    throw new RangeError(label + " is smaller than the capacity required by the compiled module.");
  }
  return result;
}
async function instantiateWasmKernel(wasmBytes, options = {}) {
  const { instance } = await WebAssembly.instantiate(
    wasmBytes,
    options.imports ?? {}
  );
  const memory = instance.exports.memory;
  if (!(memory instanceof WebAssembly.Memory)) {
    throw new TypeError("The compiled module must export the memory used by its kernels.");
  }
  const abiVersion = metadata(instance.exports, "__pui_abi_version");
  const slotBytes = metadata(instance.exports, "__pui_slot_bytes");
  if (abiVersion !== void 0 && (abiVersion !== 1 || slotBytes !== SLOT_BYTES)) {
    throw new TypeError("Unsupported compiler kernel ABI version or slot size.");
  }
  const propsSlots = capacity(
    options.propsSlots,
    metadata(instance.exports, "__pui_props_slots"),
    "propsSlots"
  );
  const statesSlots = capacity(
    options.statesSlots,
    metadata(instance.exports, "__pui_states_slots"),
    "statesSlots"
  );
  const exportedHeapBase = instance.exports.__heap_base;
  const moduleHeapBase = exportedHeapBase instanceof WebAssembly.Global ? Number(exportedHeapBase.value) : void 0;
  if (moduleHeapBase === void 0 && options.heapBase === void 0) {
    throw new TypeError(
      "The module must export __heap_base or the caller must supply its verified heap base."
    );
  }
  const heapBase = nonnegativeInteger(
    options.heapBase ?? moduleHeapBase,
    "heapBase",
    MAX_WASM32_BYTES
  );
  if (moduleHeapBase !== void 0 && heapBase < moduleHeapBase) {
    throw new RangeError("The requested heap base overlaps module-owned stack or data.");
  }
  const alignedHeapBase = Math.ceil(heapBase / SLOT_BYTES) * SLOT_BYTES;
  const propsPtr = nonnegativeInteger(
    options.propsOffset ?? alignedHeapBase,
    "propsOffset",
    MAX_WASM32_BYTES - 1
  );
  const propsEnd = propsPtr + propsSlots * SLOT_BYTES;
  const statesPtr = nonnegativeInteger(
    options.statesOffset ?? propsEnd,
    "statesOffset",
    MAX_WASM32_BYTES - 1
  );
  const statesEnd = statesPtr + statesSlots * SLOT_BYTES;
  for (const [label, start] of [
    ["propsOffset", propsPtr],
    ["statesOffset", statesPtr]
  ]) {
    if (start % SLOT_BYTES !== 0 || start < alignedHeapBase) {
      throw new RangeError(label + " must be 8-byte aligned and above the module heap base.");
    }
  }
  if (propsSlots > 0 && statesSlots > 0 && propsPtr < statesEnd && statesPtr < propsEnd) {
    throw new RangeError("Props and state memory ranges overlap.");
  }
  const neededBytes = Math.max(propsEnd, statesEnd);
  if (neededBytes > MAX_WASM32_BYTES) throw new RangeError("Kernel storage exceeds wasm32 memory.");
  const neededPages = Math.ceil(neededBytes / PAGE_BYTES);
  const availablePages = memory.buffer.byteLength / PAGE_BYTES;
  if (neededPages > availablePages) memory.grow(neededPages - availablePages);
  new Uint8Array(memory.buffer, propsPtr, propsSlots * SLOT_BYTES).fill(0);
  new Uint8Array(memory.buffer, statesPtr, statesSlots * SLOT_BYTES).fill(0);
  const address = (base, count, slot) => {
    nonnegativeInteger(slot, "slot", Math.max(0, count - 1));
    if (slot >= count) throw new RangeError("Slot index exceeds the declared kernel capacity.");
    return base + slot * SLOT_BYTES;
  };
  const view = () => new DataView(memory.buffer);
  const boolean = (value) => {
    if (typeof value !== "boolean") throw new TypeError("Boolean slots require boolean values.");
    return value ? 1 : 0;
  };
  const f64 = (value) => {
    if (typeof value !== "number") throw new TypeError("Numeric slots require number values.");
    return value;
  };
  const i32 = (value) => {
    if (!Number.isInteger(value) || value < -2147483648 || value > 2147483647) {
      throw new RangeError("Integer slots require a signed 32-bit integer.");
    }
    return value;
  };
  return {
    exports: instance.exports,
    memory,
    propsPtr,
    statesPtr,
    propsSlots,
    statesSlots,
    setPropBool(slot, value) {
      view().setUint8(address(propsPtr, propsSlots, slot), boolean(value));
    },
    setPropF64(slot, value) {
      view().setFloat64(address(propsPtr, propsSlots, slot), f64(value), true);
    },
    setPropI32(slot, value) {
      view().setInt32(address(propsPtr, propsSlots, slot), i32(value), true);
    },
    setStateBool(slot, value) {
      view().setUint8(address(statesPtr, statesSlots, slot), boolean(value));
    },
    setStateF64(slot, value) {
      view().setFloat64(address(statesPtr, statesSlots, slot), f64(value), true);
    },
    setStateI32(slot, value) {
      view().setInt32(address(statesPtr, statesSlots, slot), i32(value), true);
    },
    getStateBool(slot) {
      return view().getUint8(address(statesPtr, statesSlots, slot)) !== 0;
    },
    getStateF64(slot) {
      return view().getFloat64(address(statesPtr, statesSlots, slot), true);
    },
    getStateI32(slot) {
      return view().getInt32(address(statesPtr, statesSlots, slot), true);
    }
  };
}
export {
  instantiateWasmKernel
};
//# sourceMappingURL=kernel-host.js.map
