# Proto-UI pinned compiler

Source revision: 39ea50a0635be857734461a7af1bd6e61ecd70a6

Use Node 24. Run `npm ci --ignore-scripts` here, then `node cli.js --build-info` and `node cli.js info`.
Compile with `node cli.js compile <entry.proto.ts> --root <authoring workspace> --target react --out <fresh directory>`.
Targets are react, gpui, kernel and ir. `--ll`, `--wasm` and `--optimize` request optional LLVM kernel work.

The JavaScript package dependency is TypeScript 5.9.3. Node built-ins supply the remaining compiler imports.
The authoring workspace must resolve its own Proto-UI source/types. Generated React components import React only.
The GPUI backend requires Cargo and builds the included locked syn/prettyplease driver; generated crates declare their GPUI dependency.
The LLVM backend requires llvm-config and a compatible C++ compiler. Verification/WASM additionally require opt, llc and wasm-ld as reported by `info`.
The native/ directory is part of this package and must travel with index.js and cli.js. Builder binaries are cached outside the installation.

compiler-build.json records the full source SHA, lock/tool versions, input hashes and output hashes, including native source and Cargo.lock.
Move the whole directory as a unit. Compilation does not need the compiler source checkout.
Unsupported semantics produce diagnostics; this package does not promise that every Base prototype is admitted.
CLI compilation rejects existing generated files unless --overwrite is supplied. The current CLI does not provide the historical diff/watch commands.
index.js exports the current compiler API. This artifact does not publish TypeScript declaration files or the historical compilerBuildIdentity API.
kernel-host.js exposes bounded WASM ABI access under ./kernel-host; there is no ./runtime export or Proto interpreter.
