use gpui::prelude::*;
pub struct PinnedCounterProps {
    pub prop_label: Option<Option<String>>,
}
impl Default for PinnedCounterProps {
    fn default() -> Self {
        Self { prop_label: None }
    }
}
pub struct PinnedCounter {
    props: PinnedCounterProps,
    last_error: Option<String>,
    resolved_prop_label: Option<String>,
    previous_prop_label: Option<String>,
    state_count: f64,
}
impl PinnedCounter {
    pub fn read_prop_label(&self) -> Option<String> {
        self.resolved_prop_label.clone()
    }
    pub fn read_state_count(&self) -> f64 {
        self.state_count.clone()
    }
    fn set_state_count(&mut self, value: f64) -> Result<(), String> {
        if !!value.is_nan() {
            return Err("Invalid native value for count".to_owned());
        }
        self.state_count = value;
        Ok(())
    }
    pub fn new(props: PinnedCounterProps) -> Result<Self, String> {
        let mut component = Self {
            props: PinnedCounterProps::default(),
            last_error: None,
            resolved_prop_label: None,
            previous_prop_label: None,
            state_count: 0f64,
        };
        component.update_props(props)?;
        Ok(component)
    }
    pub fn update_props(&mut self, props: PinnedCounterProps) -> Result<(), String> {
        self.props = props;
        let resolved_label = if let Some(raw) = self.props.prop_label.clone() {
            if let Some(value) = raw {
                if true {
                    self.previous_prop_label = Some(value.clone());
                    Some(value)
                } else {
                    let fallback = self
                        .previous_prop_label
                        .clone()
                        .or(Some("Count:".to_owned()));
                    self.previous_prop_label = fallback.clone();
                    fallback
                }
            } else {
                let fallback = self
                    .previous_prop_label
                    .clone()
                    .or(Some("Count:".to_owned()));
                self.previous_prop_label = fallback.clone();
                fallback
            }
        } else {
            Some("Count:".to_owned())
        };
        self.resolved_prop_label = resolved_label;
        Ok(())
    }
    pub fn set_props(
        &mut self,
        props: PinnedCounterProps,
        cx: &mut gpui::Context<Self>,
    ) -> Result<(), String> {
        self.update_props(props)?;
        cx.notify();
        Ok(())
    }
    pub fn take_error(&mut self) -> Option<String> {
        self.last_error.take()
    }
    pub fn handle_click_0(&mut self) -> Result<(), String> {
        self.set_state_count(self.state_count.clone() + 1f64)?;
        Ok(())
    }
}
impl gpui::Render for PinnedCounter {
    fn render(
        &mut self,
        _window: &mut gpui::Window,
        cx: &mut gpui::Context<Self>,
    ) -> impl gpui::IntoElement {
        let root = gpui::div()
            .child(
                self
                    .resolved_prop_label
                    .clone()
                    .map_or_else(String::new, |value| { value.clone() }),
            )
            .child(ryu_js::Buffer::new().format(self.state_count).to_owned())
            .id(("proto-root", cx.entity_id()))
            .on_click(
                cx
                    .listener(|this, _event, _window, cx| {
                        if let Err(error) = (|| {
                            this.handle_click_0()?;
                            Ok(())
                        })() {
                            this.last_error = Some(error);
                        }
                        cx.notify();
                    }),
            );
        root.into_any_element()
    }
}
