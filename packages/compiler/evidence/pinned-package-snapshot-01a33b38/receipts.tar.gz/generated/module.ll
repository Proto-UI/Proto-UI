; ModuleID = 'proto-ui-kernels'
source_filename = "/tmp/proto-pinned-package-stage1-2m1oxb1g/fresh-native-cache/proto-pinned-ast-consumer-YBANmx/authoring/entry.proto.ts"
target datalayout = "e-m:e-p:32:32-p10:8:8-p20:8:8-i64:64-i128:128-n32:64-S128-ni:1:10:20"
target triple = "wasm32-unknown-unknown"

define double @helper_negate(double %value) {
entry:
  %neg0 = fneg double %value
  ret double %neg0
}

define void @pinned_counter_on_host_click_0(ptr %states) {
entry:
  %0 = getelementptr i8, ptr %states, i64 0
  %st0 = load double, ptr %0, align 8
  %add2 = fadd double %st0, 1.000000e+00
  %1 = getelementptr i8, ptr %states, i64 0
  store double %add2, ptr %1, align 8
  ret void
}

define i64 @pinned_counter_capabilities() {
entry:
  ret i64 267
}

define i32 @pinned_counter_prop_count() {
entry:
  ret i32 1
}

define i32 @pinned_counter_state_count() {
entry:
  ret i32 1
}

define i32 @pinned_counter_rule_count() {
entry:
  ret i32 0
}

define void @pinned_counter_init_state(ptr %states) {
entry:
  %0 = getelementptr i8, ptr %states, i64 0
  store double 0.000000e+00, ptr %0, align 8
  ret void
}

define i32 @__pui_abi_version() {
entry:
  ret i32 1
}

define i32 @__pui_slot_bytes() {
entry:
  ret i32 8
}

define i32 @__pui_props_slots() {
entry:
  ret i32 1
}

define i32 @__pui_states_slots() {
entry:
  ret i32 1
}
