import * as React from "react";
export function PinnedCounter(props) {
    const _valueAdd = (_left, _right) => typeof _left === "string" || typeof _right === "string" ? String(_left) + String(_right) : Number(_left) + Number(_right);
    const _previousProp0 = React.useRef(null);
    const _providedProp0 = Object.prototype.hasOwnProperty.call(props, "label");
    const _rawProp0 = _providedProp0 ? props["label"] : void 0;
    let _prop0 = null;
    let _rememberProp0 = false;
    if (!_providedProp0) {
        _prop0 = "Count:";
    }
    else if (false) {
        _prop0 = null;
    }
    else if (typeof _rawProp0 === "string") {
        _prop0 = _rawProp0;
        _rememberProp0 = true;
    }
    else {
        _prop0 = _previousProp0.current !== null ? _previousProp0.current : "Count:";
        _rememberProp0 = _prop0 !== null;
    }
    React.useLayoutEffect(() => {
        if (_rememberProp0)
            _previousProp0.current = _prop0;
    }, [_prop0, _rememberProp0]);
    const [_state0, _setState0] = React.useState(0);
    const _stateRef0 = React.useRef(0);
    const _writeState0 = (_nextState) => {
        if (!(typeof _nextState === "number" && !Number.isNaN(_nextState)))
            throw new TypeError("State update violates domain: count.");
        _stateRef0.current = _nextState;
        _setState0(_nextState);
    };
    const _rootRef = React.useRef(null);
    React.useLayoutEffect(() => {
        const _eventRoot = _rootRef.current;
        if (_eventRoot === null)
            return;
        const _listener0 = () => {
            _writeState0(_valueAdd(_stateRef0.current, 1));
        };
        _eventRoot.addEventListener("click", _listener0);
        return () => {
            _eventRoot.removeEventListener("click", _listener0);
        };
    });
    return React.createElement("div", {
        className: [props.className].filter(Boolean).join(" ") || void 0,
        style: props.style,
        ref: (_element) => {
            _rootRef.current = _element;
        }
    }, _prop0, _state0);
}
export default PinnedCounter;
