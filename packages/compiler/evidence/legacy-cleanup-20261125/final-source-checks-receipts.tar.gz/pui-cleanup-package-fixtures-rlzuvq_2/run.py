import pathlib,subprocess,json,time
r=pathlib.Path('/home/ezra/.t3/worktrees/proto-ui/compiler-ast-pipeline-1809-20261125')
d=pathlib.Path('/tmp/pui-cleanup-package-fixtures-rlzuvq_2')
t=time.monotonic()
with (d/"run.log").open("w") as f:p=subprocess.run(["bash","-lc",'node --import tsx /tmp/pui-cleanup-package-fixtures-rlzuvq_2/checks.mjs /home/ezra/.t3/worktrees/proto-ui/compiler-ast-pipeline-1809-20261125 /tmp/pui-cleanup-package-fixtures-rlzuvq_2/summary.json'],cwd=r,stdout=f,stderr=subprocess.STDOUT)
(d/"result.json").write_text(json.dumps({"command":'node --import tsx /tmp/pui-cleanup-package-fixtures-rlzuvq_2/checks.mjs /home/ezra/.t3/worktrees/proto-ui/compiler-ast-pipeline-1809-20261125 /tmp/pui-cleanup-package-fixtures-rlzuvq_2/summary.json',"exit":p.returncode,"seconds":round(time.monotonic()-t,2)},indent=2)+"\n")
