import pathlib,json,subprocess,time
r=pathlib.Path('/home/ezra/.t3/worktrees/proto-ui/compiler-ast-pipeline-1809-20261125')
d=pathlib.Path('/tmp/pui-cleanup-final-gates-v_5b0wv6')
steps=[{'name': 'format', 'command': 'corepack pnpm@10.32.1 exec prettier --write scripts/compiler/consumer-project-inventory.mjs packages/compiler/evidence/legacy-cleanup-20261125/README.md'}, {'name': 'consumer-syntax', 'command': 'node --check scripts/compiler/consumer-project-inventory.mjs'}, {'name': 'public-docs', 'command': 'corepack pnpm@10.32.1 -w -s check:public-docs'}]
for step in steps:
 t=time.monotonic()
 with (d/(step["name"]+".log")).open("w") as f:p=subprocess.run(["bash","-lc",step["command"]],cwd=r,stdout=f,stderr=subprocess.STDOUT)
 (d/(step["name"]+".json")).write_text(json.dumps({**step,"exit":p.returncode,"seconds":round(time.monotonic()-t,2)},indent=2)+"\n")
