import pathlib,subprocess,time,json
r=pathlib.Path('/home/ezra/.t3/worktrees/proto-ui/compiler-ast-pipeline-1809-20261125')
d=pathlib.Path('/tmp/pui-cleanup-native2-_ymhfqog')
t=time.monotonic()
with (d/"run.log").open("w") as f:
 p=subprocess.run(["bash","-lc","node --import tsx scripts/compiler/native-consumer-smoke.mjs"],cwd=r,stdout=f,stderr=subprocess.STDOUT)
(d/"result.json").write_text(json.dumps({"exit":p.returncode,"seconds":round(time.monotonic()-t,2)},indent=2)+"\n")
