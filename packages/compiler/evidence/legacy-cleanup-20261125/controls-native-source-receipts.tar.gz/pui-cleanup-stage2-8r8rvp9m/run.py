import pathlib,subprocess,time,json
r=pathlib.Path('/home/ezra/.t3/worktrees/proto-ui/compiler-ast-pipeline-1809-20261125')
d=pathlib.Path('/tmp/pui-cleanup-stage2-8r8rvp9m')
steps=[{'name': 'format', 'command': "corepack pnpm@10.32.1 exec prettier --write 'scripts/compiler/current-api.mjs' 'scripts/compiler/current-api.test.mjs' 'scripts/compiler/library-profile-inventory.mjs' 'scripts/compiler/library-profile-inventory.test.mjs' 'scripts/ci/compiler-library-inventory.mjs' 'scripts/ci/test/compiler-library-inventory.test.mjs' 'scripts/compiler/website-demo-inventory.mjs' 'scripts/compiler/verify-object-rest-controls.mjs' 'scripts/compiler/native-consumer-smoke.mjs' 'scripts/compiler/pinned-cli-smoke.mjs' 'scripts/compiler/consumer-project-inventory.mjs' 'scripts/compiler/pinned-ast-smoke.mjs' 'scripts/compiler/build-pinned.ts' 'scripts/compiler/fixtures/pinned-counter.proto.ts' 'scripts/compiler/fixtures/pinned-kernel.proto.ts' 'scripts/README.md' 'scripts/compiler/README.md' 'internal/compiler/legacy-cleanup.md' 'packages/compiler/README.md' 'apps/www/src/content/docs/en/build/compiler-guide.md' 'apps/www/src/content/docs/zh-cn/build/compiler-guide.md'"}, {'name': 'controls', 'command': 'node --test scripts/compiler/current-api.test.mjs scripts/compiler/library-profile-inventory.test.mjs scripts/ci/test/compiler-library-inventory.test.mjs scripts/compiler/verify-object-rest-controls.test.mjs scripts/compiler/website-demo-inventory.test.mjs'}, {'name': 'registry', 'command': 'node --import tsx scripts/compiler/library-profile-inventory.mjs --describe'}]
for step in steps:
 start=time.monotonic()
 with (d/(step["name"]+".log")).open("w") as f:
  p=subprocess.run(["bash","-lc",step["command"]],cwd=r,stdout=f,stderr=subprocess.STDOUT)
 (d/(step["name"]+".json")).write_text(json.dumps({**step,"exit":p.returncode,"seconds":round(time.monotonic()-start,2)},indent=2)+"\n")
 if step["name"]=="format" and p.returncode:break
