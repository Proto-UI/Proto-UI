import * as React from "react";
export interface OrdinaryCounterProps {
    "seed"?: number | null;
    "label"?: string | null;
    "active"?: boolean | null;
    className?: string;
    style?: React.CSSProperties;
    children?: React.ReactNode;
}
export function OrdinaryCounter(props: OrdinaryCounterProps): React.ReactElement {
    const _valueAdd = (_left: string | number | boolean | null, _right: string | number | boolean | null) => typeof _left === "string" || typeof _right === "string" ? String(_left) + String(_right) : Number(_left) + Number(_right);
    const _valueCoalesce = (_left: string | number | boolean | null, _right: () => string | number | boolean | null) => _left ?? _right();
    const _valueEqual = (_left: string | number | boolean | null, _right: string | number | boolean | null) => _left === _right;
    const _previousProp0 = React.useRef<number | null>(null);
    const _providedProp0 = Object.prototype.hasOwnProperty.call(props, "seed");
    const _rawProp0 = _providedProp0 ? props["seed"] : void 0;
    let _prop0: number | null = null;
    let _rememberProp0 = false;
    if (!_providedProp0) {
        _prop0 = 2;
    }
    else if (false) {
        _prop0 = null;
    }
    else if (typeof _rawProp0 === "number" && Number.isFinite(_rawProp0)) {
        _prop0 = _rawProp0;
        _rememberProp0 = true;
    }
    else {
        _prop0 = _previousProp0.current !== null ? _previousProp0.current : 2;
        _rememberProp0 = _prop0 !== null;
    }
    React.useLayoutEffect(() => {
        if (_rememberProp0)
            _previousProp0.current = _prop0;
    }, [_prop0, _rememberProp0]);
    const _previousProp1 = React.useRef<string | null>(null);
    const _providedProp1 = Object.prototype.hasOwnProperty.call(props, "label");
    const _rawProp1 = _providedProp1 ? props["label"] : void 0;
    let _prop1: string | null = null;
    let _rememberProp1 = false;
    if (!_providedProp1) {
        _prop1 = "Count:";
    }
    else if (false) {
        _prop1 = null;
    }
    else if (typeof _rawProp1 === "string") {
        _prop1 = _rawProp1;
        _rememberProp1 = true;
    }
    else {
        _prop1 = _previousProp1.current !== null ? _previousProp1.current : "Count:";
        _rememberProp1 = _prop1 !== null;
    }
    React.useLayoutEffect(() => {
        if (_rememberProp1)
            _previousProp1.current = _prop1;
    }, [_prop1, _rememberProp1]);
    const _previousProp2 = React.useRef<boolean | null>(null);
    const _providedProp2 = Object.prototype.hasOwnProperty.call(props, "active");
    const _rawProp2 = _providedProp2 ? props["active"] : void 0;
    let _prop2: boolean | null = null;
    let _rememberProp2 = false;
    if (!_providedProp2) {
        _prop2 = false;
    }
    else if (false) {
        _prop2 = null;
    }
    else if (typeof _rawProp2 === "boolean") {
        _prop2 = _rawProp2;
        _rememberProp2 = true;
    }
    else {
        _prop2 = _previousProp2.current !== null ? _previousProp2.current : false;
        _rememberProp2 = _prop2 !== null;
    }
    React.useLayoutEffect(() => {
        if (_rememberProp2)
            _previousProp2.current = _prop2;
    }, [_prop2, _rememberProp2]);
    const _createdStates = React.useState<[
        number
    ]>(() => {
        let _createdState0: number = 0;
        const _createdWriteState0 = (_nextState: unknown) => {
            if (!(typeof _nextState === "number" && !Number.isNaN(_nextState) && _nextState >= 0 && _nextState <= 100 && Number.isInteger((_nextState - 0) / 1)))
                throw new TypeError("Created state update violates domain: count.");
            _createdState0 = _nextState;
        };
        (() => {
            _createdWriteState0(_valueCoalesce(_prop0, () => 0));
        })();
        return [_createdState0];
    })[0];
    const _stateRef0 = React.useRef<number>(_createdStates[0]);
    const _writeState0 = (_nextState: unknown) => {
        if (!(typeof _nextState === "number" && !Number.isNaN(_nextState) && _nextState >= 0 && _nextState <= 100 && Number.isInteger((_nextState - 0) / 1)))
            throw new TypeError("State update violates domain: count.");
        _stateRef0.current = _nextState;
        _refreshFeedback();
    };
    const _templateState = React.useRef<[
        number
    ]>([_stateRef0.current]);
    const _requestVersion = React.useRef(0);
    const _renderVersion = _requestVersion.current;
    const _renderInputs: unknown[] = [Object.hasOwn(props, "seed"), props["seed"], Object.hasOwn(props, "label"), props["label"], Object.hasOwn(props, "active"), props["active"]];
    const _committedInputs = React.useRef(_renderInputs);
    const _inputsChanged = _renderInputs.some((_value, _index) => !Object.is(_value, _committedInputs.current[_index]));
    const _renderStates: [
        number
    ] = _inputsChanged ? [_stateRef0.current] : _templateState.current;
    const [, _setRenderRevision] = React.useState(0);
    const _requestUpdate = () => {
        _templateState.current = [_stateRef0.current];
        _requestVersion.current = _requestVersion.current + 1;
        _setRenderRevision(_revision => _revision + 1);
    };
    React.useLayoutEffect(() => {
        _committedInputs.current = _renderInputs;
        if (_requestVersion.current === _renderVersion)
            _templateState.current = _renderStates;
    });
    const _state0 = _renderStates[0];
    const _committedProps = React.useRef<[
        number | null,
        string | null,
        boolean | null
    ]>([_prop0, _prop1, _prop2]);
    React.useLayoutEffect(() => {
        _committedProps.current = [_prop0, _prop1, _prop2];
    });
    const _rootRef = React.useRef<Element | null>(null);
    const _feedbackActive = React.useRef(false);
    const _feedbackClassName = React.useRef(props.className);
    const _refreshFeedback = () => {
        const _feedbackRoot = _rootRef.current;
        if (!_feedbackActive.current || _feedbackRoot === null)
            return;
        const _feedbackRule0 = _valueEqual(_committedProps.current[2], true);
        const _feedbackClasses = [_feedbackClassName.current, _feedbackRule0 ? "bg-black" : "bg-white", "opacity-100"].filter(Boolean).join(" ") || void 0;
        if (_feedbackRoot.getAttribute("class") !== (_feedbackClasses ?? null)) {
            if (_feedbackClasses)
                _feedbackRoot.setAttribute("class", _feedbackClasses);
            else
                _feedbackRoot.removeAttribute("class");
        }
    };
    React.useLayoutEffect(() => {
        _feedbackClassName.current = props.className;
        _feedbackActive.current = true;
        _refreshFeedback();
    });
    React.useLayoutEffect(() => {
        return () => {
            _feedbackActive.current = false;
        };
    }, []);
    React.useLayoutEffect(() => {
        const _eventRoot = _rootRef.current;
        if (_eventRoot === null)
            return;
        const _listener0 = () => {
            _writeState0(_valueAdd(_stateRef0.current, 1));
        };
        _eventRoot.addEventListener("click", _listener0);
        const _listener1 = () => {
            _requestUpdate();
        };
        _eventRoot.addEventListener("keydown", _listener1);
        return () => {
            _eventRoot.removeEventListener("click", _listener0);
            _eventRoot.removeEventListener("keydown", _listener1);
        };
    });
    const _watchSnapshot = React.useRef<[
        number | null,
        string | null,
        boolean | null
    ] | null>(null);
    React.useLayoutEffect(() => {
        const _watchPrevious = _watchSnapshot.current;
        _watchSnapshot.current = [_prop0, _prop1, _prop2];
        if (_watchPrevious !== null) {
            if (false || !Object.is(_watchPrevious[0], _prop0)) {
                (() => {
                    _writeState0(_valueCoalesce(_prop0, () => 0));
                    _requestUpdate();
                })();
            }
        }
    });
    const _rule0 = _valueEqual(_prop2, true);
    return React.createElement("div", {
        className: [props.className, _rule0 ? "bg-black" : "bg-white", "opacity-100"].filter(Boolean).join(" ") || void 0,
        style: props.style,
        ref: (_element: Element | null) => {
            _rootRef.current = _element;
        }
    }, React.createElement("button", null, _prop1, _state0));
}
export default OrdinaryCounter;
