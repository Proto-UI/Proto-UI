import { definePrototype, tw } from '@proto.ui/core';
export default definePrototype<{ seed: number; label: string; active: boolean }>({
  name: 'ordinary-counter',
  setup(def) {
    def.props.define({seed:{type:'number',default:2},label:{type:'string',default:'Count:'},active:{type:'boolean',default:false}});
    const count = def.state.numberDiscrete('count', 0, {min:0,max:100,step:1});
    def.feedback.style.use(tw('bg-white','opacity-100'));
    def.rule({when: w => w.prop('active').eq(true), intent: i => i.feedback.style.use(tw('bg-black'))});
    def.lifecycle.onCreated(run => { count.set(run.props.get().seed ?? 0); });
    def.props.watch(['seed'], (run, next) => { count.set(next.seed ?? 0); run.update(); });
    def.event.on('host:click', () => { count.set(count.get() + 1); });
    def.event.on('host:keydown', run => { run.update(); });
    return render => render.el('button', [render.read.props.get().label, count.get()]);
  }
});