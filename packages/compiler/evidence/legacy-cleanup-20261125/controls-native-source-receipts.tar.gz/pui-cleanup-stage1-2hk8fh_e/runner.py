import subprocess,pathlib,json,time,sys
r=pathlib.Path(sys.argv[1]);o=pathlib.Path(sys.argv[2]);cmd=sys.argv[3];t=time.monotonic()
with o.with_suffix('.log').open('wb') as f:
 p=subprocess.run(['bash','-lc',cmd],cwd=r,stdout=f,stderr=subprocess.STDOUT,timeout=180)
o.with_suffix('.json').write_text(json.dumps({'command':cmd,'exitCode':p.returncode,'seconds':round(time.monotonic()-t,2)}))
