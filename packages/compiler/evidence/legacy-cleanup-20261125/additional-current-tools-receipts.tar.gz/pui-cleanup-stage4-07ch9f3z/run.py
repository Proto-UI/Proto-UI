import pathlib,subprocess,json,time
r=pathlib.Path('/home/ezra/.t3/worktrees/proto-ui/compiler-ast-pipeline-1809-20261125')
d=pathlib.Path('/tmp/pui-cleanup-stage4-07ch9f3z')
steps=[{'name': 'format', 'command': 'corepack pnpm@10.32.1 exec prettier --write scripts/gpui/audit-source-lowering.mjs'}, {'name': 'audit-controls', 'command': 'node --test scripts/gpui/test/current-source-audit.test.mjs'}, {'name': 'gpui-source-audit', 'command': 'node --import tsx scripts/gpui/audit-source-lowering.mjs packages/prototypes/base/src/text/root.proto.ts /tmp/pui-gpui-current-audit-20261125.json'}, {'name': 'public-docs', 'command': 'corepack pnpm@10.32.1 -w -s check:public-docs'}]
for step in steps:
 t=time.monotonic()
 with (d/(step["name"]+".log")).open("w") as f:p=subprocess.run(["bash","-lc",step["command"]],cwd=r,stdout=f,stderr=subprocess.STDOUT)
 (d/(step["name"]+".json")).write_text(json.dumps({**step,"exit":p.returncode,"seconds":round(time.monotonic()-t,2)},indent=2)+"\n")
