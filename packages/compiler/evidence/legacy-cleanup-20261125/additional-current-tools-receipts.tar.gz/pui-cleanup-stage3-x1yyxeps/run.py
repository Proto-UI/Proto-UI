import pathlib,subprocess,time,json
r=pathlib.Path('/home/ezra/.t3/worktrees/proto-ui/compiler-ast-pipeline-1809-20261125')
d=pathlib.Path('/tmp/pui-cleanup-stage3-x1yyxeps')
steps=[{'name': 'format', 'command': "corepack pnpm@10.32.1 exec prettier --write 'scripts/gpui/audit-source-lowering.mjs' 'scripts/gpui/check-cargo-graph.mjs' 'scripts/gpui/test/cargo-source-migration.test.mjs' 'scripts/gpui/test/current-source-audit.test.mjs' 'internal/compiler/gpui-dependency-migration.md' 'scripts/analysis/invisible-consumption/README.md' 'scripts/release/hook-closeout-container.mjs' 'internal/compiler/legacy-cleanup.md' 'scripts/compiler/README.md' 'packages/compiler/evidence/legacy-cleanup-20261125/README.md' 'packages/compiler/README.md' 'apps/www/src/content/docs/en/build/compiler-guide.md' 'apps/www/src/content/docs/zh-cn/build/compiler-guide.md'"}, {'name': 'cargo-audit-controls', 'command': 'node --test scripts/gpui/test/cargo-source-migration.test.mjs scripts/gpui/test/current-source-audit.test.mjs'}, {'name': 'hook-closeout-syntax', 'command': 'node --check scripts/release/hook-closeout-container.mjs'}, {'name': 'gpui-source-audit', 'command': "node --import tsx scripts/gpui/audit-source-lowering.mjs packages/prototypes/base/src/text/root.proto.ts '/tmp/pui-gpui-current-audit-20261125.json'"}]
for step in steps:
 t=time.monotonic()
 with (d/(step["name"]+".log")).open("w") as f:p=subprocess.run(["bash","-lc",step["command"]],cwd=r,stdout=f,stderr=subprocess.STDOUT)
 (d/(step["name"]+".json")).write_text(json.dumps({**step,"exit":p.returncode,"seconds":round(time.monotonic()-t,2)},indent=2)+"\n")
 if step["name"]=="format" and p.returncode:break
