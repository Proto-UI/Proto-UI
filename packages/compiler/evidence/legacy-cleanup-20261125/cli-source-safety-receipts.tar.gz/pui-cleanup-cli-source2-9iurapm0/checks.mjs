import assert from 'node:assert/strict';
import {spawn,spawnSync} from 'node:child_process';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,symlinkSync,readdirSync} from 'node:fs';
import path from 'node:path';
const root=process.argv[2],work=process.argv[3],cli=path.join(root,'scripts/compiler/pinned-cli-entry.ts');
const entry=path.join(work,'entry.proto.ts');
writeFileSync(entry,"import {definePrototype} from '@proto.ui/core'; export default definePrototype({name:'ownership-test',setup(){return r=>r.el('section','first');}});\n");
const flags=['compile',entry,'--root',root,'--target','react','--component','OwnershipTest','--json'];
const report={scope:'Current source CLI execution; not a source-pinned package receipt',head:spawnSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).stdout.trim(),steps:[],ok:false};
const run=(name,args,expected=0)=>{const p=spawnSync(process.execPath,['--import','tsx',cli,...args],{cwd:root,encoding:'utf8',timeout:90000});writeFileSync(path.join(work,name+'.stdout'),p.stdout??'');writeFileSync(path.join(work,name+'.stderr'),p.stderr??'');report.steps.push({name,status:p.status,signal:p.signal});assert.equal(p.error,undefined);assert.equal(p.status,expected,p.stderr+p.stdout);return p;};
const parallel=(name,args)=>new Promise((resolve,reject)=>{const p=spawn(process.execPath,['--import','tsx',cli,...args],{cwd:root,stdio:['ignore','pipe','pipe']});let out='',err='';p.stdout.on('data',s=>out+=s);p.stderr.on('data',s=>err+=s);p.on('error',reject);p.on('close',(status,signal)=>{writeFileSync(path.join(work,name+'.stdout'),out);writeFileSync(path.join(work,name+'.stderr'),err);const result={name,status,signal};report.steps.push(result);resolve(result);});});
try{
 const out=path.join(work,'out');run('fresh',[...flags,'--out',out]);const artifact=path.join(out,'OwnershipTest.tsx'),bytes=readFileSync(artifact);
 run('collision',[...flags,'--out',out],2);assert.deepEqual(readFileSync(artifact),bytes);
 const foreign=path.join(work,'foreign');mkdirSync(foreign);writeFileSync(path.join(foreign,'owned.txt'),'keep');
 const link=path.join(work,'link');symlinkSync(foreign,link,'dir');run('directory-link',[...flags,'--out',link],1);assert.deepEqual(readdirSync(foreign),['owned.txt']);
 const fileOut=path.join(work,'file-out');mkdirSync(fileOut);symlinkSync(path.join(foreign,'owned.txt'),path.join(fileOut,'OwnershipTest.tsx'));run('file-link',[...flags,'--out',fileOut,'--overwrite'],1);assert.equal(readFileSync(path.join(foreign,'owned.txt'),'utf8'),'keep');
 const race=path.join(work,'race');const races=await Promise.all([parallel('race-a',[...flags,'--out',race]),parallel('race-b',[...flags,'--out',race])]);assert.equal(races.filter(x=>x.status===0).length,1);assert.ok(races.every(x=>[0,1,2].includes(x.status)&&x.signal===null));assert.deepEqual(readFileSync(path.join(race,'OwnershipTest.tsx')),bytes);
 writeFileSync(artifact,Buffer.concat([Buffer.from('// consumer edit\n'),bytes]));const edited=readFileSync(artifact);run('edited-collision',[...flags,'--out',out],2);assert.deepEqual(readFileSync(artifact),edited);run('explicit-overwrite',[...flags,'--out',out,'--overwrite']);assert.deepEqual(readFileSync(artifact),bytes);
 report.ok=true;
}catch(error){report.error=error.stack;process.exitCode=1;}finally{writeFileSync(path.join(work,'result.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));}
