import {definePrototype} from '@proto.ui/core'; export default definePrototype({name:'ownership-test',setup(){return r=>r.el('section','first');}});
