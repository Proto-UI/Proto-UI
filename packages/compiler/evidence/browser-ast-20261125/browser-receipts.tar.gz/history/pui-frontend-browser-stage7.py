import subprocess,pathlib,json,time
root='/home/ezra/.t3/worktrees/proto-ui/compiler-ast-pipeline-1809-20261125'
steps=[
('format-gate', 'corepack pnpm@10.32.1 exec prettier --write scripts/coverage-matrices/browser-compiler-imports.mjs scripts/coverage-matrices/test/check-coverage-matrices.test.mjs internal/website/self-hosting-coverage-matrix.md'),
('exact-gate-tests', 'node --test --test-name-pattern="compiler closure|compiler browser source binding|browser compiler host source binding" scripts/coverage-matrices/test/check-coverage-matrices.test.mjs'),
('matrix-gate', 'node scripts/coverage-matrices/check-coverage-matrices.mjs'),
('browser-execution', 'node scripts/compiler/browser-ast-smoke.mjs --out /tmp/pui-browser-ast-execution-final'),
('browser-evidence', 'node --test scripts/compiler/browser-delivery-index.test.mjs scripts/compiler/browser-assets-production.test.mjs scripts/compiler/browser-repository-root.test.mjs')]
out={'steps':[]}
for name,cmd in steps:
 start=time.time();log='/tmp/pui-stage7-'+name+'.log'
 with open(log,'w') as f:
  p=subprocess.run(['bash','-lc',cmd],cwd=root,stdout=f,stderr=subprocess.STDOUT)
 out['steps'].append({'name':name,'exit_code':p.returncode,'seconds':time.time()-start,'log':log})
 pathlib.Path('/tmp/pui-frontend-browser-stage7.json').write_text(json.dumps(out))
