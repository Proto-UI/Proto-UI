from pathlib import Path
import subprocess,json,time
root='/home/ezra/.t3/worktrees/proto-ui/compiler-ast-pipeline-1809-20261125'
steps=[]
for name,command in [('browser-execution','node scripts/compiler/browser-ast-smoke.mjs --out /tmp/pui-browser-ast-execution-stage4'),('browser-production-assets','node --test scripts/compiler/browser-assets-production.test.mjs')]:
 start=time.time();log='/tmp/pui-stage4-'+name+'.log'
 with open(log,'w') as out: run=subprocess.run(['bash','-lc',command],cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=180)
 steps.append({'name':name,'exit_code':run.returncode,'seconds':time.time()-start,'log':log})
 Path('/tmp/pui-frontend-browser-stage4.json').write_text(json.dumps({'steps':steps}))
