import pathlib,subprocess,time,json
root='/home/ezra/.t3/worktrees/proto-ui/compiler-ast-pipeline-1809-20261125'
start=time.time()
log='/tmp/pui-stage6-browser-execution.log'
with open(log,'w') as f:
 p=subprocess.run(['bash','-lc','node scripts/compiler/browser-ast-smoke.mjs --out /tmp/pui-browser-ast-execution-stage6'],cwd=root,stdout=f,stderr=subprocess.STDOUT)
pathlib.Path('/tmp/pui-frontend-browser-stage6.json').write_text(json.dumps({'exit_code':p.returncode,'seconds':time.time()-start,'log':log}))
