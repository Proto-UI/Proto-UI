from pathlib import Path
import subprocess,json,time
root='/home/ezra/.t3/worktrees/proto-ui/compiler-ast-pipeline-1809-20261125'
steps=[]
for name,command in [('react-browser-tests','corepack pnpm@10.32.1 exec vitest run packages/compiler/test/react-ast-codegen.test.ts packages/compiler/test/real-base-react.test.ts packages/compiler/test/browser-ast.test.ts'),('compiler-types','corepack pnpm@10.32.1 exec tsc -p packages/compiler/tsconfig.check.json --noEmit'),('browser-execution','node scripts/compiler/browser-ast-smoke.mjs --out /tmp/pui-browser-ast-execution-stage3'),('browser-evidence-tests','node --test scripts/compiler/browser-delivery-index.test.mjs scripts/compiler/browser-repository-root.test.mjs')]:
 start=time.time();log='/tmp/pui-stage3-'+name+'.log'
 with open(log,'w') as out: run=subprocess.run(['bash','-lc',command],cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=180)
 steps.append({'name':name,'exit_code':run.returncode,'seconds':time.time()-start,'log':log})
 Path('/tmp/pui-frontend-browser-stage3.json').write_text(json.dumps({'steps':steps}))
