import pathlib,json,subprocess,time
root='/home/ezra/.t3/worktrees/proto-ui/compiler-ast-pipeline-1809-20261125';start=time.time()
with open('/tmp/pui-browser-source-types.log','w') as f:p=subprocess.run(['bash','-lc','corepack pnpm@10.32.1 exec tsc -p .cache/compiler-browser-source-check.json --noEmit'],cwd=root,stdout=f,stderr=subprocess.STDOUT)
pathlib.Path('/tmp/pui-browser-source-types.json').write_text(json.dumps({'exit_code':p.returncode,'seconds':time.time()-start}))
