import pathlib,subprocess,json,hashlib,time,datetime
root=pathlib.Path('/home/ezra/.t3/worktrees/proto-ui/compiler-ast-pipeline-1809-20261125')
def snapshot():
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'packages/compiler/src').rglob('*')) if p.is_file()}
before=snapshot();start=time.time();command='node scripts/compiler/browser-ast-smoke.mjs --out /tmp/pui-browser-ast-execution-final-p1-20261125'
with open('/tmp/pui-browser-final-p1.log','w') as f:p=subprocess.run(['bash','-lc',command],cwd=root,stdout=f,stderr=subprocess.STDOUT)
after=snapshot()
result={'command':command,'exit_code':p.returncode,'seconds':time.time()-start,'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceStable':before==after,'compilerSources':before,'baselineHead':subprocess.run(['git','rev-parse','HEAD'],cwd=root,capture_output=True,text=True,check=True).stdout.strip(),'candidateHasUncommittedChanges':bool(subprocess.run(['git','status','--porcelain'],cwd=root,capture_output=True,text=True,check=True).stdout.strip()),'log':'/tmp/pui-browser-final-p1.log','output':'/tmp/pui-browser-ast-execution-final-p1-20261125'}
pathlib.Path('/tmp/pui-browser-final-p1.json').write_text(json.dumps(result,indent=2)+chr(10))
