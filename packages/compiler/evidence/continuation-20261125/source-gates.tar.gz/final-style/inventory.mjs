import fs from 'node:fs';
import path from 'node:path';
import {createCompiler} from '../../../packages/compiler/src/index.ts';
const target=process.argv[2], output=process.argv[3];
function files(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(entry=>entry.isDirectory()?files(path.join(dir,entry.name)):entry.name.endsWith('.proto.ts')?[path.join(dir,entry.name)]:[]).sort();}
const entries=files(path.resolve('packages/prototypes/base/src'));
const report=createCompiler({rootDir:process.cwd()}).inventoryProject(entries,{target});
fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');
if(!report.ok) { console.error(JSON.stringify(report.diagnostics));process.exit(1); }
console.log(JSON.stringify({target,totals:report.value.totals,completeNativeCoverage:report.value.completeNativeCoverage,emitted:report.value.files.filter(file=>file.nativeEmittedPrototypes>0)},null,2));
if(report.value.totals.prototypeDeclarations!==212 || report.value.totals.sourceErrorFiles!==0)process.exitCode=1;
