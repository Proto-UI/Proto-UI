import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
const require = createRequire(resolve('package.json'));
const ts = require('typescript');
function parse(path) {
  const text = readFileSync(path, 'utf8');
  const source = ts.createSourceFile(path, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  const expects = [], matchers = [], titles = [], skips = [];
  const isExpect = node => ts.isCallExpression(node) && ts.isIdentifier(node.expression) && node.expression.text === 'expect';
  const visit = node => {
    if (isExpect(node)) expects.push(node.getText(source));
    if (ts.isCallExpression(node) && ts.isPropertyAccessExpression(node.expression) && isExpect(node.expression.expression)) matchers.push(node.getText(source));
    if (ts.isCallExpression(node) && ts.isIdentifier(node.expression) && node.expression.text === 'it') titles.push(node.arguments[0].getText(source));
    if (ts.isCallExpression(node) && ts.isPropertyAccessExpression(node.expression) && ['it','test','describe'].includes(node.expression.expression.getText(source)) && ['only','skip','todo'].includes(node.expression.name.text)) skips.push(node.getText(source));
    ts.forEachChild(node, visit);
  };
  visit(source); return { expects, matchers, titles, skips };
}
const base = parse(process.argv[2]), candidate = parse(process.argv[3]);
const same = field => JSON.stringify(base[field]) === JSON.stringify(candidate[field]);
const report = {
 baseExpectCalls:base.expects.length,candidateExpectCalls:candidate.expects.length,expectExpressionsUnchanged:same('expects'),
 baseMatcherCalls:base.matchers.length,candidateMatcherCalls:candidate.matchers.length,matcherCallsAndExpectedValuesUnchanged:same('matchers'),
 baseTestDefinitions:base.titles.length,candidateTestDefinitions:candidate.titles.length,testTitlesUnchanged:same('titles'),
 baseSelectiveOrSkippedCalls:base.skips,candidateSelectiveOrSkippedCalls:candidate.skips,
};
console.log(JSON.stringify(report,null,2));
if (!same('expects') || !same('matchers') || !same('titles') || candidate.skips.length || candidate.expects.length !== 29 || candidate.titles.length !== 7) process.exit(1);
