// @vitest-environment happy-dom
import { appendFileSync } from 'node:fs';
import { window as ownerWindow } from 'happy-dom/lib/PropertySymbol.js';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { nativeOwnerProfiles } from './native-owner-consumer';
import { cleanupScrollConsumers, mountScrollFamily } from './scroll-reveal-consumer';

afterEach(async () => {
  await cleanupScrollConsumers();
  activeTrace?.restore();
  activeTrace = undefined;
  vi.restoreAllMocks();
  document.body.replaceChildren();
});

/** Explicit geometry injection exercises emitted host behavior, not browser layout. */
function geometry(surface: HTMLElement, target: HTMLElement) {
  Object.defineProperties(surface, {
    clientWidth: { configurable: true, value: 100 },
    scrollWidth: { configurable: true, value: 400 },
    clientHeight: { configurable: true, value: 100 },
    scrollHeight: { configurable: true, value: 400 },
    clientTop: { configurable: true, value: 2 },
    offsetHeight: { configurable: true, value: 104 },
  });
  surface.scrollTop = 50;
  surface.scrollLeft = 17;
  const state = {
    start: 150,
    height: 20,
    rendered: true,
    onMeasure: undefined as (() => void) | undefined,
  };
  const surfaceBox = () => new DOMRect(20, 100, 104, 104);
  const targetBox = () => {
    const callback = state.onMeasure;
    state.onMeasure = undefined;
    callback?.();
    return new DOMRect(22, 102 + state.start - surface.scrollTop, 80, state.height);
  };
  vi.spyOn(surface, 'getBoundingClientRect').mockImplementation(surfaceBox);
  vi.spyOn(surface, 'getClientRects').mockImplementation(
    () => [surfaceBox()] as unknown as DOMRectList
  );
  vi.spyOn(target, 'getBoundingClientRect').mockImplementation(targetBox);
  vi.spyOn(target, 'getClientRects').mockImplementation(
    () => (state.rendered ? [targetBox()] : []) as unknown as DOMRectList
  );
  return state;
}
const unavailable = { kind: 'rejected', reason: 'unavailable' };


/** Temporary diagnostic only: real Happy DOM mount mutation delivery is delayed. */
function observeMutationTiming(profile: string) {
  const output = process.env.PUI_SCROLL_TRACE_FILE!;
  const mode = process.env.PUI_SCROLL_MUTATION_MODE ?? 'native';
  // Vitest replaces document.defaultView/window with its populated global.
  // This diagnostic reads the real Happy DOM owner to intercept its actual
  // MutationObserver timer, rather than a Node-global timer alias.
  const probe = new MutationObserver(() => {});
  const timerView = (probe as any)[ownerWindow] as Window;
  probe.disconnect();
  const set = timerView.setTimeout.bind(timerView), clear = timerView.clearTimeout.bind(timerView);
  const request = window.requestAnimationFrame.bind(window);
  const cancel = window.cancelAnimationFrame.bind(window);
  const timers = new Map<unknown, number>();
  let timerSequence = 0, frameSequence = 0, sequence = 0, phase = 'mount';
  let surface: HTMLElement | undefined;
  function event(kind: string, detail: Record<string, unknown> = {}) {
    appendFileSync(output, JSON.stringify({ profile, mode, sequence: ++sequence,
      time: performance.now(), phase, kind, offset: surface?.scrollTop,
      pendingMutationTimers: [...timers.values()], ...detail }) + '\n');
  }
  event('timer-window-identity', { sameWindow: window === timerView, sameTimerFunction: window.setTimeout === timerView.setTimeout });
  vi.spyOn(timerView, 'setTimeout').mockImplementation(((callback: (...args: any[]) => void, delay?: number, ...args: any[]) => {
    const stack = new Error().stack ?? '';
    if (!stack.includes('MutationObserverListener.report')) return set(callback, delay, ...args);
    const id = ++timerSequence;
    const scheduledDelay = mode === 'delay-mount-mutations' && phase === 'mount' ? 100 : delay;
    let handle: unknown;
    handle = set(() => {
      timers.delete(handle);
      event('mutation-delivery-start', { id, stack });
      try { callback(...args); } finally { event('mutation-delivery-return', { id }); }
    }, scheduledDelay);
    timers.set(handle, id);
    event('mutation-timer-scheduled', { id, scheduledDelay, stack });
    return handle;
  }) as any);
  vi.spyOn(timerView, 'clearTimeout').mockImplementation(((handle: number) => {
    const id = timers.get(handle);
    if (id !== undefined) { timers.delete(handle); event('mutation-timer-cancelled', { id }); }
    clear(handle);
  }) as any);
  // Use a wrapper below the fixture's temporary spies, so restoring those spies
  // continues to observe ordinary RAF work scheduled after the helper returned.
  window.requestAnimationFrame = callback => {
    const id = ++frameSequence;
    event('ordinary-raf-scheduled', { id, stack: new Error().stack });
    return request(time => {
      event('ordinary-raf-start', { id });
      try { callback(time); } finally { event('ordinary-raf-return', { id }); }
    });
  };
  window.cancelAnimationFrame = id => cancel(id);
  return {
    event,
    attach(current: HTMLElement) {
      if (surface === current) return;
      surface = current;
      let target: object | null = current, descriptor: PropertyDescriptor | undefined;
      while (target && !descriptor) {
        descriptor = Object.getOwnPropertyDescriptor(target, 'scrollTop');
        target = Object.getPrototypeOf(target);
      }
      let saved = current.scrollTop;
      Object.defineProperty(current, 'scrollTop', {
        configurable: true,
        enumerable: true,
        get() { return descriptor?.get ? descriptor.get.call(current) : saved; },
        set(value: number) {
          const before = current.scrollTop;
          if (descriptor?.set) descriptor.set.call(current, value); else saved = value;
          event('scrollTop-write', { before, requested: value, after: current.scrollTop, stack: new Error().stack });
        },
      });
      event('surface-observed');
    },
    phase(value: string) { phase = value; event('phase'); },
    request<T>(name: string, callback: () => T): T {
      phase = name + ':synchronous';
      event('request-before', { name });
      const result = callback();
      event('request-return', { name, result });
      phase = name + ':act-await';
      return result;
    },
    restore() {
      window.requestAnimationFrame = request;
      window.cancelAnimationFrame = cancel;
    },
  };
}
let activeTrace: ReturnType<typeof observeMutationTiming> | undefined;

/** Finish mounting's end-follow work before injecting request-specific geometry. */
async function mountSettledScrollFamily(profile: (typeof nativeOwnerProfiles)[number]) {
  let next = 0;
  const pending = new Map<number, FrameRequestCallback>();
  const request = vi.spyOn(window, 'requestAnimationFrame').mockImplementation((callback) => {
    pending.set(++next, callback);
    activeTrace?.event('fixture-raf-scheduled', { id: next, stack: new Error().stack });
    return next;
  });
  const cancel = vi.spyOn(window, 'cancelAnimationFrame').mockImplementation((id) => {
    pending.delete(id);
  });
  try {
    const owner = await mountScrollFamily(profile);
    activeTrace?.attach(owner.physical('surface'));
    // act also flushes mounting effects that can register another surface's frame.
    // Bound the fixture: a continuously rescheduling owner must fail, not hang.
    for (let round = 0; round < 8; ++round) {
      await owner.act(() => {
        const batch = [...pending.entries()];
        for (const [id, callback] of batch) {
          if (!pending.delete(id)) continue;
          activeTrace?.event('fixture-raf-start', { id, round });
          callback(performance.now());
          activeTrace?.event('fixture-raf-return', { id, round });
        }
      });
      if (!pending.size) {
        activeTrace?.event('helper-return', { round, pendingFrames: pending.size });
        return owner;
      }
    }
    throw new Error('scroll-family mounting did not finish its animation-frame work');
  } finally {
    request.mockRestore();
    cancel.mockRestore();
  }
}

for (const profile of nativeOwnerProfiles)
  describe(`C-SCROLL-TARGET-REVEAL-0001 ordinary ${profile}`, () => {
    it('reveals a real current part with minimal vertical movement and preserves unrelated host state', async () => {
      const owner = await mountScrollFamily(profile);
      const surface = owner.physical('surface'),
        target = owner.physical('direct');
      geometry(surface, target);
      const editor = document.createElement('input');
      owner.host.prepend(editor);
      editor.focus();
      owner.host.scrollTop = 43;
      owner.host.scrollLeft = 11;
      expect(await owner.act(() => owner.handles.surface.getExposes().reveal(0))).toEqual({
        kind: 'dispatched',
      });
      expect(surface.scrollTop).toBe(70);
      expect(surface.scrollLeft).toBe(17);
      expect(owner.host.scrollTop).toBe(43);
      expect(owner.host.scrollLeft).toBe(11);
      expect(document.activeElement).toBe(editor);
      expect(owner.handles.surface.getExposes().read().vertical.position).toBeCloseTo(70 / 300);
    });

    it('uses resolved insets, native clamping and no movement for a covering target', async () => {
      const owner = await mountScrollFamily(profile);
      const surface = owner.physical('surface'),
        target = owner.physical('direct');
      const state = geometry(surface, target);
      surface.style.scrollPaddingTop = '10px';
      surface.style.scrollPaddingBottom = '15%';
      target.style.scrollMarginTop = '5px';
      target.style.scrollMarginBottom = '7px';
      surface.style.setProperty('scroll-behavior', 'smooth', 'important');
      const reveal = () => owner.handles.surface.getExposes().reveal(0);
      expect(await owner.act(reveal)).toEqual({ kind: 'dispatched' });
      expect(surface.scrollTop).toBe(92);
      expect(surface.style.getPropertyValue('scroll-behavior')).toBe('smooth');
      expect(surface.style.getPropertyPriority('scroll-behavior')).toBe('important');
      state.start = 1000;
      expect(await owner.act(reveal)).toEqual({ kind: 'dispatched' });
      expect(surface.scrollTop).toBe(300);
      state.start = 250;
      state.height = 200;
      expect(await owner.act(reveal)).toEqual({ kind: 'dispatched' });
      expect(surface.scrollTop).toBe(300);
    });

    it('reveals a descendant surface part whose nearest strict same-role ancestor is this surface', async () => {
      const owner = await mountScrollFamily(profile);
      const surface = owner.physical('surface'),
        target = owner.physical('nested');
      geometry(surface, target);
      target.scrollTop = 23;
      const before = surface.scrollTop;
      const outcome = await owner.act(() => owner.handles.surface.getExposes().revealSurface(1));
      expect({ outcome, before, after: surface.scrollTop, nestedOffset: target.scrollTop }).toEqual(
        {
          outcome: { kind: 'dispatched' },
          before: 50,
          after: 70,
          nestedOffset: 23,
        }
      );
    });

    it('rejects an item owned by another surface, a sibling, self and another family before physical movement', async () => {
      const trace = profile === 'react-dom-source-v1' ? observeMutationTiming(profile) : undefined;
      activeTrace = trace;
      const owner = await mountSettledScrollFamily(profile);
      const surface = owner.physical('surface');
      trace?.phase('geometry');
      geometry(surface, owner.physical('direct'));
      const exposed = owner.handles.surface.getExposes();
      expect(await owner.act(() => trace ? trace.request('foreign-surface', () => exposed.reveal(1)) : exposed.reveal(1))).toEqual(unavailable);
      expect(await owner.act(() => trace ? trace.request('sibling', () => exposed.reveal(2)) : exposed.reveal(2))).toEqual(unavailable);
      expect(await owner.act(() => trace ? trace.request('self', () => exposed.revealSelf()) : exposed.revealSelf())).toEqual(unavailable);
      expect(await owner.act(() => trace ? trace.request('other-family', () => exposed.revealOther(0)) : exposed.revealOther(0))).toEqual(unavailable);
      if (trace) {
        trace.phase('complete-delayed-mount-work-before-original-oracle');
        await (window as any).happyDOM.waitUntilComplete();
      }
      expect(surface.scrollTop).toBe(50);
      expect(await owner.act(() => trace ? trace.request('valid', () => exposed.reveal(0)) : exposed.reveal(0))).toEqual({ kind: 'dispatched' });
      expect(surface.scrollTop).toBe(70);
    });

    it('rejects a retained part after that logical owner retires', async () => {
      const owner = await mountScrollFamily(profile);
      const surface = owner.physical('surface');
      geometry(surface, owner.physical('direct'));
      const exposed = owner.handles.surface.getExposes();
      await owner.act(() => exposed.capture(0));
      await owner.remove('direct');
      let beforeRequest = -1,
        afterSynchronousRequest = -1;
      const outcome = await owner.act(() => {
        beforeRequest = surface.scrollTop;
        const value = exposed.revealSaved();
        afterSynchronousRequest = surface.scrollTop;
        return value;
      });
      expect(outcome).toEqual(unavailable);
      // Flush may run an earlier end-follow frame; compare the request's own
      // synchronous effect. Pending-end ownership has a separate host case.
      expect(afterSynchronousRequest).toBe(beforeRequest);
    });

    it('does not replay a reveal from a detached surface into a later view', async () => {
      const owner = await mountScrollFamily(profile);
      const surface = owner.physical('surface');
      geometry(surface, owner.physical('direct'));
      const exposed = owner.handles.surface.getExposes();
      await owner.act(() => exposed.capture(0));
      await owner.act(() => exposed.hide());
      expect(await owner.act(() => exposed.revealSaved())).toEqual({
        kind: 'rejected',
        reason: 'not-mounted',
      });
      await owner.act(() => exposed.show());
      const current = owner.physical('surface');
      expect(current.scrollTop).toBe(profile === 'web-component-source-v1' ? 50 : 0);
    });

    it('rechecks target availability after geometry getters synchronously detach the physical target', async () => {
      const owner = await mountSettledScrollFamily(profile);
      const surface = owner.physical('surface');
      const target = owner.physical('direct'),
        parent = target.parentNode!,
        next = target.nextSibling;
      const state = geometry(surface, target);
      state.onMeasure = () => target.remove();
      let outcome: unknown;
      try {
        outcome = await owner.act(() => owner.handles.surface.getExposes().reveal(0));
      } finally {
        parent.insertBefore(target, next);
      }
      expect(outcome).toEqual(unavailable);
      expect(surface.scrollTop).toBe(50);
    });
  });
