from pathlib import Path
import subprocess

repo = Path('/workspace/scratch/0e9f736f5ffa/proto-ui-scroll-repro')
evidence = Path(__file__).resolve().parent
file = 'packages/compiler/test/scroll-reveal-consumers.test.ts'
base = subprocess.check_output(['git', '-C', str(repo), 'show', '795b1b4958333cf904547e484acb4de9d4b3ee80:' + file]).decode()
(evidence / 'base.test.ts').write_text(base)
instrument = r'''
/** Temporary diagnostic only: real Happy DOM mount mutation delivery is delayed. */
function observeMutationTiming(profile: string) {
  const output = process.env.PUI_SCROLL_TRACE_FILE!;
  const mode = process.env.PUI_SCROLL_MUTATION_MODE ?? 'native';
  // Vitest replaces document.defaultView/window with its populated global.
  // This diagnostic reads the real Happy DOM owner to intercept its actual
  // MutationObserver timer, rather than a Node-global timer alias.
  const probe = new MutationObserver(() => {});
  const timerView = (probe as any)[ownerWindow] as Window;
  probe.disconnect();
  const set = timerView.setTimeout.bind(timerView), clear = timerView.clearTimeout.bind(timerView);
  const request = window.requestAnimationFrame.bind(window);
  const cancel = window.cancelAnimationFrame.bind(window);
  const timers = new Map<unknown, number>();
  let timerSequence = 0, frameSequence = 0, sequence = 0, phase = 'mount';
  let surface: HTMLElement | undefined;
  function event(kind: string, detail: Record<string, unknown> = {}) {
    appendFileSync(output, JSON.stringify({ profile, mode, sequence: ++sequence,
      time: performance.now(), phase, kind, offset: surface?.scrollTop,
      pendingMutationTimers: [...timers.values()], ...detail }) + '\n');
  }
  event('timer-window-identity', { sameWindow: window === timerView, sameTimerFunction: window.setTimeout === timerView.setTimeout });
  vi.spyOn(timerView, 'setTimeout').mockImplementation(((callback: (...args: any[]) => void, delay?: number, ...args: any[]) => {
    const stack = new Error().stack ?? '';
    if (!stack.includes('MutationObserverListener.report')) return set(callback, delay, ...args);
    const id = ++timerSequence;
    const scheduledDelay = mode === 'delay-mount-mutations' && phase === 'mount' ? 100 : delay;
    let handle: unknown;
    handle = set(() => {
      timers.delete(handle);
      event('mutation-delivery-start', { id, stack });
      try { callback(...args); } finally { event('mutation-delivery-return', { id }); }
    }, scheduledDelay);
    timers.set(handle, id);
    event('mutation-timer-scheduled', { id, scheduledDelay, stack });
    return handle;
  }) as any);
  vi.spyOn(timerView, 'clearTimeout').mockImplementation(((handle: number) => {
    const id = timers.get(handle);
    if (id !== undefined) { timers.delete(handle); event('mutation-timer-cancelled', { id }); }
    clear(handle);
  }) as any);
  // Use a wrapper below the fixture's temporary spies, so restoring those spies
  // continues to observe ordinary RAF work scheduled after the helper returned.
  window.requestAnimationFrame = callback => {
    const id = ++frameSequence;
    event('ordinary-raf-scheduled', { id, stack: new Error().stack });
    return request(time => {
      event('ordinary-raf-start', { id });
      try { callback(time); } finally { event('ordinary-raf-return', { id }); }
    });
  };
  window.cancelAnimationFrame = id => cancel(id);
  return {
    event,
    attach(current: HTMLElement) {
      if (surface === current) return;
      surface = current;
      let target: object | null = current, descriptor: PropertyDescriptor | undefined;
      while (target && !descriptor) {
        descriptor = Object.getOwnPropertyDescriptor(target, 'scrollTop');
        target = Object.getPrototypeOf(target);
      }
      let saved = current.scrollTop;
      Object.defineProperty(current, 'scrollTop', {
        configurable: true,
        enumerable: true,
        get() { return descriptor?.get ? descriptor.get.call(current) : saved; },
        set(value: number) {
          const before = current.scrollTop;
          if (descriptor?.set) descriptor.set.call(current, value); else saved = value;
          event('scrollTop-write', { before, requested: value, after: current.scrollTop, stack: new Error().stack });
        },
      });
      event('surface-observed');
    },
    phase(value: string) { phase = value; event('phase'); },
    request<T>(name: string, callback: () => T): T {
      phase = name + ':synchronous';
      event('request-before', { name });
      const result = callback();
      event('request-return', { name, result });
      phase = name + ':act-await';
      return result;
    },
    restore() {
      window.requestAnimationFrame = request;
      window.cancelAnimationFrame = cancel;
    },
  };
}
let activeTrace: ReturnType<typeof observeMutationTiming> | undefined;
'''
source = base.replace("import { afterEach", "import { appendFileSync } from 'node:fs';\nimport { window as ownerWindow } from 'happy-dom/lib/PropertySymbol.js';\nimport { afterEach", 1)
source = source.replace('  vi.restoreAllMocks();', '  activeTrace?.restore();\n  activeTrace = undefined;\n  vi.restoreAllMocks();', 1)
source = source.replace('/** Finish mounting', instrument + '\n/** Finish mounting', 1)
source = source.replace('    pending.set(++next, callback);', "    pending.set(++next, callback);\n    activeTrace?.event('fixture-raf-scheduled', { id: next, stack: new Error().stack });", 1)
source = source.replace('    const owner = await mountScrollFamily(profile);\n    // act', "    const owner = await mountScrollFamily(profile);\n    activeTrace?.attach(owner.physical('surface'));\n    // act", 1)
source = source.replace('          callback(performance.now());', "          activeTrace?.event('fixture-raf-start', { id, round });\n          callback(performance.now());\n          activeTrace?.event('fixture-raf-return', { id, round });", 1)
source = source.replace('      if (!pending.size) return owner;', "      if (!pending.size) {\n        activeTrace?.event('helper-return', { round, pendingFrames: pending.size });\n        return owner;\n      }", 1)
start = source.index("    it('rejects an item owned by another surface")
end = source.index("    it('rejects a retained part", start)
case = source[start:end]
case = case.replace('      const owner = await mountSettledScrollFamily(profile);', "      const trace = profile === 'react-dom-source-v1' ? observeMutationTiming(profile) : undefined;\n      activeTrace = trace;\n      const owner = await mountSettledScrollFamily(profile);", 1)
case = case.replace("      geometry(surface, owner.physical('direct'));", "      trace?.phase('geometry');\n      geometry(surface, owner.physical('direct'));", 1)
for name,call in [('foreign-surface','exposed.reveal(1)'),('sibling','exposed.reveal(2)'),('self','exposed.revealSelf()'),('other-family','exposed.revealOther(0)'),('valid','exposed.reveal(0)')]:
    case = case.replace('() => ' + call, "() => trace ? trace.request('" + name + "', () => " + call + ') : ' + call, 1)
case = case.replace('      expect(surface.scrollTop).toBe(50);', "      if (trace) {\n        trace.phase('complete-delayed-mount-work-before-original-oracle');\n        await (window as any).happyDOM.waitUntilComplete();\n      }\n      expect(surface.scrollTop).toBe(50);", 1)
source = source[:start] + case + source[end:]
(evidence / 'diagnostic.test.ts').write_text(source)
(repo / file).write_text(source)
