#!/usr/bin/env python3
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

root = Path('/workspace/scratch/0e9f736f5ffa/proto-ui-scroll-repro')
evidence = Path(__file__).resolve().parent
node = Path('/home/agent/.npm/_npx/ef8b185be06dfeb4/node_modules/node/bin/node')
label = sys.argv[1]
selected = 'packages/compiler/test/scroll-reveal-consumers.test.ts'
command = [str(node), shutil.which('corepack'), 'pnpm@10.32.1', 'exec', 'vitest', 'run', selected,
           '--maxWorkers=1', '--minWorkers=1', '--reporter=default', '--reporter=json',
           '--outputFile=' + str(evidence / (label + '.vitest.json'))]
command += sys.argv[2:]
inputs = [selected, 'packages/compiler/test/scroll-reveal-consumer.ts',
          'packages/compiler/src/native-support/dom-modules.template.ts',
          'packages/compiler/src/native-scroll-reveal.ts', 'package.json', 'pnpm-lock.yaml',
          'vitest.config.ts']
def snapshot():
    return {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
            for name in inputs if (root / name).exists()}
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True)
receipt = {'label': label, 'source': git('rev-parse', 'HEAD').strip(), 'cwd': str(root),
           'timing_mode': os.environ.get('PUI_SCROLL_MUTATION_MODE', 'native'),
           'command': command, 'node': subprocess.check_output([str(node), '--version'], text=True).strip(),
           'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'inputs_before': snapshot(), 'worktree_before': git('status', '--short'),
           'timeout_seconds': 180}
(evidence / (label + '.patch')).write_text(git('diff', '--binary'))
env = dict(os.environ)
env['PATH'] = str(node.parent) + os.pathsep + env['PATH']
env['PUI_SCROLL_TRACE_FILE'] = str(evidence / (label + '.trace.jsonl'))
started = time.monotonic()
with (evidence / (label + '.log')).open('wb') as log:
    process = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        receipt['exit_code'] = process.wait(timeout=180)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        receipt['exit_code'] = process.returncode
        receipt['timed_out'] = True
receipt.update(duration_seconds=round(time.monotonic() - started, 3),
               finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               inputs_after=snapshot(), worktree_after=git('status', '--short'))
report_path = evidence / (label + '.vitest.json')
if report_path.exists():
    report = json.loads(report_path.read_text())
    receipt['results'] = {key: report.get(key) for key in
                          ['numTotalTests', 'numPassedTests', 'numFailedTests', 'numPendingTests', 'success']}
    receipt['failed_assertions'] = [assertion for result in report.get('testResults', [])
                                    for assertion in result.get('assertionResults', [])
                                    if assertion.get('status') == 'failed']
receipt['inputs_unchanged_during_run'] = receipt['inputs_before'] == receipt['inputs_after']
(evidence / (label + '.receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items()
                  if key not in ['inputs_before', 'inputs_after', 'failed_assertions']}, indent=2), flush=True)
if receipt.get('failed_assertions'):
    print(json.dumps(receipt['failed_assertions'], indent=2), flush=True)
