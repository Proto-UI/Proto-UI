#!/usr/bin/env bash
set -euo pipefail
base=/tank/shared/projects/proto-ui-agent/sprint5-f7b2
repo="$base/repo"
out="$base/focus-dir-prepared-f6bd"
candidate=f6bdadf1bf1791bab8a66d7c9a6c25993fc5c1f4
fixture=packages/adapters/web-component/test/shadow-closeout.browser.test.ts
toolbin=/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin
chrome=/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/playwright-browsers/chromium-1208/chrome-linux64/chrome
export PATH="$toolbin:$PATH" CHROME_PATH="$chrome" TMPDIR="$base/t"
tmux set-option -p -t "$TMUX_PANE" remain-on-exit on
cd "$repo"
test "$(git rev-parse HEAD)" = "$candidate"
git diff --quiet
git diff --cached --quiet
test ! -e "$out"
mkdir "$out"
date -u +%FT%TZ > "$out/started.txt"
finish() {
  status=$?
  trap - EXIT
  printf '%s\n' "$status" > "$out/exit-code.txt"
  date -u +%FT%TZ > "$out/finished.txt"
  git rev-parse HEAD > "$out/source-head-after.txt"
  git status --porcelain=v1 --untracked-files=no > "$out/tracked-status-after.txt"
  sha256sum "$fixture" > "$out/fixture-sha256-after.txt"
  exit "$status"
}
trap finish EXIT
test "$(sha256sum "$fixture" | cut -d' ' -f1)" = 4a8952da9763866ecf645480ba63b13815bf35bb799cfd9c52667372d6f13b27
cp "$fixture" "$out/fixture-preimage.ts"
git apply --check "$base/focus-dir-bounded-preparation.patch"
git apply "$base/focus-dir-bounded-preparation.patch"
test "$(sha256sum "$fixture" | cut -d' ' -f1)" = fc2157d23740281f7f840dcbfb7e42ca1f61cc45f18e66dda2d500e11bf23c9e
git diff --binary > "$out/applied.patch"
cmp "$base/focus-dir-bounded-preparation.patch" "$out/applied.patch"
git rev-parse HEAD > "$out/source-head.txt"
git rev-parse 'HEAD^{tree}' > "$out/base-tree.txt"
node --version > "$out/node.txt"
corepack pnpm@10.32.1 --version > "$out/pnpm.txt"
"$chrome" --version > "$out/browser.txt"
sha256sum pnpm-lock.yaml packages/adapters/web-component/src/runtime/modules.ts "$fixture" apps/www/src/content/docs/zh-cn/browser-harness.ts > "$out/input-sha256.txt"
cp "$fixture" "$out/fixture.ts"
cp apps/www/src/content/docs/zh-cn/browser-harness.ts "$out/browser-harness.ts"
cp "$base/focus-dir-$candidate/frozen-install.log" "$out/prior-same-lock-frozen-install.log"
cp "$base/start-native-dir-prepared-f6bd.sh" "$out/launch.sh"
printf '%s\n' 'CHROME_PATH=<recorded Chrome145> TMPDIR=<task-owned tank> corepack pnpm@10.32.1 exec vitest run packages/adapters/web-component/test/shadow-closeout.browser.test.ts -t "reprojects entry during native dir=auto" --maxWorkers=1 --minWorkers=1 --reporter=default --reporter=json --outputFile=<out>/vitest.json' > "$out/command.txt"
corepack pnpm@10.32.1 exec vitest run \
  packages/adapters/web-component/test/shadow-closeout.browser.test.ts \
  -t 'reprojects entry during native dir=auto' \
  --maxWorkers=1 --minWorkers=1 --reporter=default --reporter=json \
  --outputFile="$out/vitest.json" 2>&1 | tee "$out/vitest.log"
node --input-type=module - "$out/vitest.json" <<'JS'
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const report=JSON.parse(readFileSync(process.argv[2],'utf8'));
const cases=report.testResults.flatMap(result=>result.assertionResults);
const selected=cases.filter(entry=>entry.fullName.includes('reprojects entry during native dir=auto'));
assert.equal(selected.length,2);
assert.ok(selected.every(entry=>entry.status==='passed'));
assert.equal(report.numFailedTests,0);
console.log(JSON.stringify({selected:selected.map(({fullName,status,duration})=>({fullName,status,duration})),unselected:cases.length-selected.length,scope:'two native dir=auto controls, unchanged 5000 ms case bound; prepared pages under bounded 30000 ms beforeAll'}));
JS
