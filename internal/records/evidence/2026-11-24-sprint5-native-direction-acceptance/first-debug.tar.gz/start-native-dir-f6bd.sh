#!/usr/bin/env bash
set -euo pipefail
tmux set-window-option -t "$TMUX_PANE" remain-on-exit on
base=/tank/shared/projects/proto-ui-agent/sprint5-f7b2
candidate=f6bdadf1bf1791bab8a66d7c9a6c25993fc5c1f4
exec > >(tee "$base/native-dir-f6bd-preparation.log") 2>&1
finish() {
  status=$?
  trap - EXIT
  printf '%s\n' "$status" > "$base/native-dir-f6bd-exit-code.txt"
  date -u +%FT%TZ > "$base/native-dir-f6bd-finished.txt"
  exit "$status"
}
trap finish EXIT
date -u +%FT%TZ
cd "$base/repo"
head=$(git rev-parse HEAD)
if [ "$head" != 0b7b212d3193ea5c7ae219c0501036ee1255e3f2 ] && [ "$head" != "$candidate" ]; then
  printf 'Unexpected browser checkout: %s\n' "$head"
  exit 2
fi
git diff --quiet
git diff --cached --quiet
git fetch origin "$candidate"
git checkout --detach "$candidate"
git rev-parse HEAD
git rev-parse 'HEAD^{tree}'
bash "$base/run-focus-dir-native.sh" "$candidate"
