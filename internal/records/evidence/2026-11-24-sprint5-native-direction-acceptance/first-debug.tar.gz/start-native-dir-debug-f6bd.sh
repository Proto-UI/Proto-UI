#!/usr/bin/env bash
set -euo pipefail
tmux set-window-option -t "$TMUX_PANE" remain-on-exit on
base=/tank/shared/projects/proto-ui-agent/sprint5-f7b2
out="$base/focus-dir-debug-f6bd"
export PATH=/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:$PATH
export CHROME_PATH=/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/playwright-browsers/chromium-1208/chrome-linux64/chrome
export TMPDIR="$base/t"
export DEBUG=pw:api
cd "$base/repo"
test "$(git rev-parse HEAD)" = f6bdadf1bf1791bab8a66d7c9a6c25993fc5c1f4
git diff --quiet
git diff --cached --quiet
test ! -e "$out/started.txt"
mkdir -p "$out"
finish() {
 status=$?
 trap - EXIT
 printf '%s\n' "$status" > "$out/exit-code.txt"
 date -u +%FT%TZ > "$out/finished.txt"
 git status --porcelain=v1 --untracked-files=no > "$out/tracked-status-after.txt"
 exit "$status"
}
trap finish EXIT
date -u +%FT%TZ > "$out/started.txt"
git rev-parse HEAD > "$out/source-sha.txt"
sha256sum packages/adapters/web-component/src/runtime/modules.ts packages/adapters/web-component/test/shadow-closeout.browser.test.ts apps/www/src/content/docs/zh-cn/browser-harness.ts > "$out/input-sha256.txt"
corepack pnpm@10.32.1 exec vitest run packages/adapters/web-component/test/shadow-closeout.browser.test.ts -t 'reprojects entry during native dir=auto' --maxWorkers=1 --minWorkers=1 --reporter=default --reporter=json --outputFile="$out/vitest.json" 2>&1 | tee "$out/vitest-pw-api.log"
