#!/usr/bin/env bash
set -euo pipefail
candidate=${1:?exact candidate commit required}
if [[ ! "$candidate" =~ ^[0-9a-f]{40}$ ]]; then
  printf 'Expected a full commit SHA\n' >&2
  exit 2
fi
base=/tank/shared/projects/proto-ui-agent/sprint5-f7b2
repo="$base/repo"
toolbin=/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin
chrome=/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/playwright-browsers/chromium-1208/chrome-linux64/chrome
out="$base/focus-dir-$candidate"
export PATH="$toolbin:$PATH"
export CHROME_PATH="$chrome"
export TMPDIR="$base/t"
cd "$repo"
test "$(git rev-parse HEAD)" = "$candidate"
git diff --quiet
git diff --cached --quiet
test ! -e "$out/started.txt"
mkdir -p "$out" "$TMPDIR"
date -u +%FT%TZ > "$out/started.txt"
finish() {
  status=$?
  trap - EXIT
  printf '%s\n' "$status" > "$out/exit-code.txt"
  date -u +%FT%TZ > "$out/finished.txt"
  git rev-parse HEAD > "$out/source-head-after.txt"
  git status --porcelain=v1 --untracked-files=no > "$out/tracked-status-after.txt"
  exit "$status"
}
trap finish EXIT
git rev-parse HEAD > "$out/source-head.txt"
git rev-parse 'HEAD^{tree}' > "$out/source-tree.txt"
node --version > "$out/node.txt"
corepack pnpm@10.32.1 --version > "$out/pnpm.txt"
"$chrome" --version > "$out/browser.txt"
sha256sum pnpm-lock.yaml packages/adapters/web-component/src/runtime/modules.ts packages/adapters/web-component/test/shadow-closeout.browser.test.ts apps/www/src/content/docs/zh-cn/browser-harness.ts > "$out/input-sha256.txt"
cp packages/adapters/web-component/test/shadow-closeout.browser.test.ts "$out/fixture.ts"
cp apps/www/src/content/docs/zh-cn/browser-harness.ts "$out/browser-harness.ts"
printf '%s\n' 'CHROME_PATH=<recorded Chrome145> TMPDIR=<task-owned tank> corepack pnpm@10.32.1 exec vitest run packages/adapters/web-component/test/shadow-closeout.browser.test.ts -t "reprojects entry during native dir=auto" --maxWorkers=1 --minWorkers=1 --reporter=default --reporter=json --outputFile=<out>/vitest.json' > "$out/command.txt"
corepack pnpm@10.32.1 install --frozen-lockfile 2>&1 | tee "$out/frozen-install.log"
corepack pnpm@10.32.1 exec vitest run \
  packages/adapters/web-component/test/shadow-closeout.browser.test.ts \
  -t 'reprojects entry during native dir=auto' \
  --maxWorkers=1 --minWorkers=1 --reporter=default --reporter=json \
  --outputFile="$out/vitest.json" 2>&1 | tee "$out/vitest.log"
node --input-type=module - "$out/vitest.json" <<'JS'
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const report=JSON.parse(readFileSync(process.argv[2],'utf8'));
const cases=report.testResults.flatMap(result=>result.assertionResults);
const selected=cases.filter(entry=>entry.fullName.includes('reprojects entry during native dir=auto'));
assert.equal(selected.length,2);
assert.ok(selected.every(entry=>entry.status==='passed'));
assert.equal(report.numFailedTests,0);
console.log(JSON.stringify({selected: selected.map(({fullName,status,duration})=>({fullName,status,duration})),unselected:cases.length-selected.length,scope:'two native dir=auto controls only'}));
JS
