from pathlib import Path
import os, json, subprocess, datetime, signal, sys, hashlib
b = Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
p = b / 'percentage-native-4deb/attempt-03'
source = b / 'percentage-native-4deb/attempt-02/build'
observer = p / 'shadow-percentage-browser.mjs'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
expected_observer = '14614457e7d8c0e8ce7a1ff68ef66dde9bfbd34979d62f9a64beee1f6484e9ab'
expected_manifest = '48f1edfa77a7c6ce6a2097f7e02fa4c8b525b22d172b088b340fdaf7b72f9b72'
assert sha(observer) == expected_observer
assert sha(source / 'manifest.json') == expected_manifest
assert Path('/tmp/pui-s67-percent').resolve() == b / 'percentage-native-4deb/tmp'
if sys.argv[1:] == ['--start']:
    marker = p / 'start-03.json'
    try:
        receipt = marker.open('x')
    except FileExistsError:
        print(marker.read_text())
        raise SystemExit(0)
    with receipt, (p / 'wrapper-03.log').open('x') as log:
        child = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--run'], stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        record = {'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pid': child.pid, 'wrapperSha256': sha(Path(__file__)), 'observerCommit': '139f1598', 'observerSha256': expected_observer, 'readOnlyProducerManifestSha256': expected_manifest}
        receipt.write(json.dumps(record, indent=2) + '\n')
        receipt.flush()
        print(json.dumps(record))
elif sys.argv[1:] == ['--run']:
    env = dict(os.environ)
    env.pop('PUI_CHROME_NO_SANDBOX', None)
    env.update(TMPDIR='/tmp/pui-s67-percent', PUI_CHROME_EXECUTABLE=str(b / 'tools/playwright-browsers/chromium-1208/chrome-linux64/chrome'), PUI_PLAYWRIGHT_MODULE=str(b / 's67-734-calibration-4deb-04/candidate-consumer/node_modules/playwright-core/index.mjs'))
    cmd = [str(b / 'tools/node-v24.22.3-linux-x64/bin/node'), str(observer), str(source), str(p / 'native')]
    record = {'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'command': cmd, 'sourceProductHead': '87c3b0364bcc0495ae7bb6fbd969518b48e7c128', 'observerCommit': '139f1598', 'budgetMs': 180000, 'TMPDIR': env['TMPDIR'], 'PUI_CHROME_NO_SANDBOX_present': 'PUI_CHROME_NO_SANDBOX' in env, 'launchConstraint': 'Repository Shadow S3/S4 headless + executablePath only; no extra arguments'}
    with (p / 'browser-03.log').open('x') as log:
        child = subprocess.Popen(cmd, cwd=p, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        record['childPid'] = child.pid
        try:
            record['exitCode'] = child.wait(timeout=180)
        except subprocess.TimeoutExpired:
            record['timeout'] = True
            os.killpg(child.pid, signal.SIGTERM)
            try:
                record['exitCode'] = child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                record['exitCode'] = child.wait()
    record['sourceStable'] = sha(observer) == expected_observer and sha(source / 'manifest.json') == expected_manifest
    record['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (p / 'execution-03.json').write_text(json.dumps(record, indent=2) + '\n')
else:
    raise SystemExit('Expected --start or --run')
