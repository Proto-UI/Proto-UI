import { createPercentageLab } from "/workspace/scratch/4deb1fac371b/s67-type-boundary/apps/www/test-fixtures/shadow-percentage/consumer.ts";
import { protoShadowStyleArtifact } from "/workspace/scratch/4deb1fac371b/s67-type-boundary/internal/records/evidence/2026-11-23-shadow-percentage-native/build-03/artifact.js";
export const lab = createPercentageLab(protoShadowStyleArtifact);
