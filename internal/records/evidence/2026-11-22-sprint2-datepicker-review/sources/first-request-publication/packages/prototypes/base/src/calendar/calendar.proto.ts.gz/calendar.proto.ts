import {
  createAnatomyFamily,
  createContextKey,
  defineAsHook,
  definePrototype,
  type DefHandle,
  type RunHandle,
  tw,
} from '@proto.ui/core';
import {
  asAccessible,
  asCollection,
  asCollectionItem,
  asFocusable,
  asTrigger,
} from '@proto.ui/hooks';
import { asButton } from '../button';
import { callOwner, readPartState } from '../collection-controls/shared';
import {
  isCalendarValues,
  isCalendarRange,
  normalizeCalendarValues,
  normalizeCalendarRange,
  calendarValuesAvailable,
  calendarRangeAvailable,
  calendarRangeNights,
  calendarSelectionKey,
  calendarDaySelection,
} from './selection';
import {
  addDays,
  addMonths,
  dateAvailable,
  monthDays,
  parseDate,
  calendarDateLabel,
  calendarWeekdayInfo as weekdayInfo,
} from './model';
import type {
  CalendarCaptionProps,
  CalendarCaptionExposes,
  CalendarWeekdaysProps,
  CalendarWeekdaysExposes,
  CalendarWeekdayProps,
  CalendarWeekdayExposes,
  CalendarWeekdayAsHookContract,
  CalendarRootProps,
  CalendarRootExposes,
  CalendarDayProps,
  CalendarDayExposes,
  CalendarDayContract,
  CalendarRootAsHookContract,
  CalendarGridProps,
  CalendarGridExposes,
  CalendarRowProps,
  CalendarRowExposes,
  CalendarRowAsHookContract,
  CalendarHeadingProps,
  CalendarHeadingExposes,
  CalendarHeadingAsHookContract,
  CalendarPreviousProps,
  CalendarPreviousExposes,
  CalendarNavigationAsHookContract,
  CalendarSelectionMode,
  CalendarSelectionReason,
  CalendarRange,
} from './types';
export * from './model';
export * from './caption-composition';
export type * from './types';
export const CALENDAR_FAMILY = createAnatomyFamily('base-calendar', {
  roles: {
    root: { cardinality: { min: 1, max: 1 } },
    grid: { cardinality: { min: 0, max: 1 } },
    row: { cardinality: { min: 0, max: '*' } },
    day: { cardinality: { min: 0, max: '*' } },
    heading: { cardinality: { min: 0, max: 1 } },
    caption: { cardinality: { min: 0, max: 1 } },
    weekdays: { cardinality: { min: 0, max: 1 } },
    weekday: { cardinality: { min: 0, max: 7 } },
    previous: { cardinality: { min: 0, max: 1 } },
    next: { cardinality: { min: 0, max: 1 } },
  },
  relations: [
    { kind: 'contains', parent: 'root', child: 'grid' },
    { kind: 'contains', parent: 'grid', child: 'row' },
    { kind: 'contains', parent: 'root', child: 'caption' },
    { kind: 'contains', parent: 'grid', child: 'weekdays' },
    { kind: 'contains', parent: 'weekdays', child: 'weekday' },
    { kind: 'contains', parent: 'row', child: 'day' },
  ],
});
type CalendarContext = {
  mode: CalendarSelectionMode;
  value: string;
  values: string[];
  range: CalendarRange;
  selectionRequestId: number;
  selectionCommit: { id: number; complete: boolean; reason: CalendarSelectionReason } | null;
  month: string;
  min: string;
  max: string;
  unavailable: string[];
  disabled: boolean;
  readOnly: boolean;
  weekStartsOn: number;
  fixedWeeks: boolean;
  weekCount: number;
  today: string;
  locale: string;
  direction: 'ltr' | 'rtl';
  active: string;
  focusRequest: { id: number; date: string } | null;
};
export const CALENDAR_CONTEXT = createContextKey<CalendarContext>('base-calendar');
const initial: CalendarContext = {
  mode: 'single',
  value: '',
  values: [],
  range: {},
  selectionRequestId: 0,
  selectionCommit: null,
  month: '1970-01',
  min: '',
  max: '',
  unavailable: [],
  disabled: false,
  readOnly: false,
  weekStartsOn: 0,
  fixedWeeks: false,
  weekCount: 5,
  today: '',
  locale: 'en-US',
  direction: 'ltr',
  active: '',
  focusRequest: null,
};
function setupRoot(def: DefHandle<CalendarRootProps, CalendarRootExposes>) {
  def.anatomy.claim(CALENDAR_FAMILY, { role: 'root' });
  asCollection().configure({ family: CALENDAR_FAMILY, itemRole: 'day' });
  def.props.define({
    mode: { type: 'enum', options: ['single', 'multiple', 'range'] },
    value: { type: 'string' },
    defaultValue: { type: 'string' },
    values: { type: 'object', validator: isCalendarValues },
    defaultValues: { type: 'object', validator: isCalendarValues },
    range: { type: 'object', validator: isCalendarRange },
    defaultRange: { type: 'object', validator: isCalendarRange },
    minSelected: { type: 'number', validator: (n) => Number.isSafeInteger(n) && n >= 0 },
    maxSelected: { type: 'number', validator: (n) => Number.isSafeInteger(n) && n >= 0 },
    minNights: { type: 'number', validator: (n) => Number.isSafeInteger(n) && n >= 0 },
    maxNights: { type: 'number', validator: (n) => Number.isSafeInteger(n) && n >= 0 },
    month: { type: 'string' },
    defaultMonth: { type: 'string' },
    min: { type: 'string' },
    max: { type: 'string' },
    unavailable: {
      type: 'object',
      validator: (value) => Array.isArray(value) && value.every((date) => typeof date === 'string'),
    },
    disabled: { type: 'boolean' },
    readOnly: { type: 'boolean' },
    weekStartsOn: { type: 'number' },
    fixedWeeks: { type: 'boolean' },
    a11yLabel: { type: 'string' },
    today: { type: 'string', validator: (value) => value === '' || !!parseDate(value) },
    locale: { type: 'string' },
    direction: { type: 'enum', options: ['ltr', 'rtl'] },
  });
  def.props.setDefaults({
    mode: 'single',
    defaultValue: '',
    defaultValues: [],
    defaultRange: {},
    minSelected: 0,
    minNights: 0,
    min: '',
    max: '',
    unavailable: [],
    disabled: false,
    readOnly: false,
    weekStartsOn: 0,
    fixedWeeks: false,
    a11yLabel: 'Calendar',
    today: '',
    locale: 'en-US',
    direction: 'ltr',
  });
  const value = def.state.string('value', ''),
    mode = def.state.string('mode', 'single'),
    selectedCount = def.state.numberDiscrete('selectedCount', 0),
    rangeComplete = def.state.bool('rangeComplete', false),
    month = def.state.string('month', '1970-01'),
    label = def.state.string('a11yLabel', 'Calendar'),
    disabled = def.state.bool('disabled', false),
    direction = def.state.string('direction', 'ltr'),
    weekCount = def.state.numberDiscrete('weekCount', 5);
  const a11y = asAccessible();
  a11y.role('group');
  a11y.name(label);
  def.context.provide(CALENDAR_CONTEXT, initial);
  def.context.subscribe(CALENDAR_CONTEXT);
  def.expose.state('value', value);
  def.expose.state('mode', mode);
  def.expose.state('selectedCount', selectedCount);
  def.expose.state('rangeComplete', rangeComplete);
  def.expose.state('month', month);
  def.expose.state('disabled', disabled);
  def.expose.state('direction', direction);
  def.expose.state('weekCount', weekCount);
  def.expose.event('valueChange', { payload: 'json' });
  def.expose.event('valuesChange', { payload: 'json' });
  def.expose.event('rangeChange', { payload: 'json' });
  def.expose.event('monthChange', { payload: 'json' });
  let owner: RunHandle<CalendarRootProps> | null = null;
  let viewEpoch = 0;
  let pendingNavigation: { month: string; date: string; fromMonth: string } | null = null;
  let focusRequestId = 0;
  let values: string[] = [];
  let range: CalendarRange = {};
  let selectionId = 0;
  let publicationId = 0;
  let pendingSelection: {
    id: number;
    mode: CalendarSelectionMode;
    expected: string;
    previous: string;
    complete: boolean;
    reason: CalendarSelectionReason;
    allowMinimumProgress: boolean;
    proposalDelivered: boolean;
  } | null = null;
  def.expose.method('getValues', () => [...values]);
  def.expose.method('getRange', () => ({ ...range }));
  const publish = (run: RunHandle<CalendarRootProps>, active?: string) => {
    const epoch = viewEpoch;
    const publication = ++publicationId;
    const p = run.props.get(),
      old = run.context.read(CALENDAR_CONTEXT);
    const next: CalendarContext = {
      mode: p.mode ?? 'single',
      value: value.get(),
      values: [...values],
      range: { ...range },
      selectionRequestId: selectionId,
      selectionCommit: old.selectionCommit,
      month: month.get(),
      min: p.min ?? '',
      max: p.max ?? '',
      unavailable: [...(p.unavailable ?? [])],
      disabled: !!p.disabled,
      readOnly: !!p.readOnly,
      weekStartsOn: Number.isFinite(p.weekStartsOn)
        ? ((Math.trunc(p.weekStartsOn!) % 7) + 7) % 7
        : 0,
      fixedWeeks: !!p.fixedWeeks,
      weekCount: monthDays(month.get(), p.weekStartsOn, !!p.fixedWeeks).length / 7,
      today: p.today ?? '',
      locale: p.locale || 'en-US',
      direction: p.direction ?? 'ltr',
      active: active ?? old.active,
      focusRequest: null,
    };
    const pending = pendingSelection;
    let completedSelection = false;
    if (pending) {
      const key = calendarSelectionKey(next.mode, next.value, next.values, next.range);
      const eligible =
        !next.disabled &&
        !next.readOnly &&
        next.mode === pending.mode &&
        (next.mode === 'multiple'
          ? calendarValuesAvailable(next.values, p, pending.allowMinimumProgress)
          : next.mode === 'range'
            ? calendarRangeAvailable(next.range, p)
            : dateAvailable(next.value, next.min, next.max, next.unavailable));
      if (eligible && key === pending.expected) {
        // Canonical facts may update inside a proposal callback, but completion
        // belongs to the still-current request after that callback returns.
        if (pending.proposalDelivered) {
          next.selectionCommit = {
            id: pending.id,
            complete: pending.complete,
            reason: pending.reason,
          };
          completedSelection = true;
        }
      } else if (
        next.disabled ||
        next.readOnly ||
        next.mode !== pending.mode ||
        key !== pending.previous
      ) {
        pendingSelection = null;
      }
    }
    mode.set(next.mode, 'calendar selection mode');
    if (owner !== run || viewEpoch !== epoch || publication !== publicationId) return;
    selectedCount.set(
      next.mode === 'multiple'
        ? next.values.length
        : next.mode === 'range'
          ? next.range.to
            ? calendarRangeNights(next.range) + 1
            : next.range.from
              ? 1
              : 0
          : next.value
            ? 1
            : 0,
      'calendar selected count'
    );
    if (owner !== run || viewEpoch !== epoch || publication !== publicationId) return;
    rangeComplete.set(
      next.mode === 'range' && !!next.range.from && !!next.range.to,
      'calendar range completeness'
    );
    if (owner !== run || viewEpoch !== epoch || publication !== publicationId) return;
    weekCount.set(next.weekCount, 'calendar visible week count');
    if (owner !== run || viewEpoch !== epoch || publication !== publicationId) return;
    const navigation = pendingNavigation;
    const acceptedNavigation = navigation?.month === next.month && !next.disabled;
    if (acceptedNavigation) next.active = navigation!.date;
    if (navigation && (acceptedNavigation || next.disabled || next.month !== navigation.fromMonth))
      pendingNavigation = null;
    const selectedDate =
      next.mode === 'multiple'
        ? (next.values[0] ?? '')
        : next.mode === 'range'
          ? (next.range.from ?? '')
          : next.value;
    if (
      !next.active ||
      next.active.slice(0, 7) !== next.month ||
      !dateAvailable(next.active, next.min, next.max, next.unavailable)
    )
      next.active =
        selectedDate.slice(0, 7) === next.month &&
        dateAvailable(selectedDate, next.min, next.max, next.unavailable)
          ? selectedDate
          : (monthDays(next.month, next.weekStartsOn, next.fixedWeeks).find(
              (date) =>
                date.slice(0, 7) === next.month &&
                dateAvailable(date, next.min, next.max, next.unavailable)
            ) ?? '');
    if (
      acceptedNavigation &&
      next.active &&
      run.anatomy
        .partsOf(CALENDAR_FAMILY, 'day')
        .some((part) => readPartState(part, 'focused') === true)
    )
      next.focusRequest = { id: ++focusRequestId, date: next.active };
    // State observers may synchronously publish a newer owner snapshot above.
    // Consume acceptance only once this publication still owns the context write.
    if (completedSelection && pendingSelection === pending) pendingSelection = null;
    if (JSON.stringify(old) !== JSON.stringify(next)) run.context.update(CALENDAR_CONTEXT, next);
  };
  const requestMonth = (next: string, navigationDate?: string) => {
    if (!owner || owner.props.get().disabled || !parseDate(`${next}-01`)) return false;
    const current = owner,
      epoch = viewEpoch;
    const c = owner.context.read(CALENDAR_CONTEXT);
    const validNavigation =
      navigationDate &&
      navigationDate.slice(0, 7) === next &&
      dateAvailable(navigationDate, c.min, c.max, c.unavailable);
    pendingNavigation = validNavigation
      ? { month: next, date: navigationDate, fromMonth: month.get() }
      : null;
    if (next === month.get()) {
      if (validNavigation) publish(owner);
      return !!validNavigation;
    }
    if (!owner.props.isProvided('month')) month.set(next, 'calendar month request');
    if (owner !== current || viewEpoch !== epoch) return true;
    publish(owner);
    if (owner !== current || viewEpoch !== epoch) return true;
    owner.expose.emit('monthChange', { month: next });
    return true;
  };
  def.expose.method('requestMonth', requestMonth);
  const requestSelection = (
    nextValue: string,
    nextValues: string[],
    nextRange: CalendarRange,
    reason: CalendarSelectionReason,
    active?: string
  ) => {
    if (!owner) return false;
    const current = owner,
      epoch = viewEpoch;
    const c = current.context.read(CALENDAR_CONTEXT);
    const p = current.props.get();
    const previous = calendarSelectionKey(c.mode, c.value, c.values, c.range);
    const expected = calendarSelectionKey(c.mode, nextValue, nextValues, nextRange);
    const allowMinimumProgress =
      c.mode === 'multiple' && active !== undefined && nextValues.length === c.values.length + 1;
    if (c.disabled || c.readOnly || expected === previous) return false;
    if (
      c.mode === 'multiple'
        ? !calendarValuesAvailable(nextValues, p, allowMinimumProgress)
        : c.mode === 'range'
          ? !calendarRangeAvailable(nextRange, p)
          : !dateAvailable(nextValue, c.min, c.max, c.unavailable)
    )
      return false;
    const id = ++selectionId;
    pendingSelection = {
      id,
      mode: c.mode,
      previous,
      expected,
      complete: c.mode === 'single' || (c.mode === 'range' && !!nextRange.from && !!nextRange.to),
      reason,
      allowMinimumProgress,
      proposalDelivered: false,
    };
    pendingNavigation = null;
    // Freeze the request's consumer session before any public State can notify.
    // A State observer may open/reopen a Picker; that later session must never
    // be captured as the one this selection is allowed to complete.
    current.context.update(CALENDAR_CONTEXT, { ...c, selectionRequestId: id });
    if (
      owner !== current ||
      viewEpoch !== epoch ||
      selectionId !== id ||
      pendingSelection?.id !== id
    )
      return true;
    if (c.mode === 'multiple') {
      if (!current.props.isProvided('values')) values = [...nextValues];
    } else if (c.mode === 'range') {
      if (!current.props.isProvided('range')) range = { ...nextRange };
    } else if (!current.props.isProvided('value')) value.set(nextValue, 'calendar date request');
    if (owner !== current || viewEpoch !== epoch || selectionId !== id) return true;
    publish(current, active);
    if (owner !== current || viewEpoch !== epoch || selectionId !== id) return true;
    if (active) requestMonth(active.slice(0, 7));
    if (owner !== current || viewEpoch !== epoch || selectionId !== id) return true;
    if (c.mode === 'multiple') current.expose.emit('valuesChange', { values: [...nextValues] });
    else if (c.mode === 'range') current.expose.emit('rangeChange', { range: { ...nextRange } });
    else current.expose.emit('valueChange', { value: nextValue });
    if (owner !== current || viewEpoch !== epoch || selectionId !== id) return true;
    if (pendingSelection?.id === id) {
      pendingSelection.proposalDelivered = true;
      publish(current);
    }
    return true;
  };
  def.expose.method('requestValues', (next: readonly string[]) => {
    if (!owner || owner.props.get().mode !== 'multiple' || !isCalendarValues(next)) return false;
    return requestSelection(value.get(), normalizeCalendarValues(next), range, 'programmatic');
  });
  def.expose.method('requestRange', (next: CalendarRange) => {
    if (!owner || owner.props.get().mode !== 'range' || !isCalendarRange(next)) return false;
    return requestSelection(value.get(), values, normalizeCalendarRange(next), 'programmatic');
  });
  def.expose.method(
    'requestValue',
    (next: string, inputReason: CalendarSelectionReason = 'programmatic') => {
      if (!owner || typeof next !== 'string' || !parseDate(next)) return false;
      const c = owner.context.read(CALENDAR_CONTEXT);
      if (!dateAvailable(next, c.min, c.max, c.unavailable)) return false;
      const reason =
        inputReason === 'pointer' || inputReason === 'keyboard' ? inputReason : 'programmatic';
      if (c.mode === 'multiple') {
        const nextValues = c.values.includes(next)
          ? c.values.filter((date) => date !== next)
          : normalizeCalendarValues([...c.values, next]);
        return requestSelection(c.value, nextValues, c.range, reason, next);
      }
      if (c.mode === 'range') {
        const nextRange =
          !c.range.from || c.range.to
            ? { from: next }
            : normalizeCalendarRange({ from: c.range.from, to: next });
        return requestSelection(c.value, [...c.values], nextRange, reason, next);
      }
      return requestSelection(next, [...c.values], c.range, reason, next);
    }
  );
  const sync = (run: RunHandle<CalendarRootProps>, created = false) => {
    owner = run;
    const p = run.props.get();
    if (created || run.props.isProvided('value'))
      value.set(
        (run.props.isProvided('value') ? p.value : p.defaultValue) ?? '',
        'calendar owner value'
      );
    if (created || run.props.isProvided('values'))
      values = normalizeCalendarValues(
        (run.props.isProvided('values') ? p.values : p.defaultValues) ?? []
      );
    if (created || run.props.isProvided('range'))
      range = normalizeCalendarRange(
        (run.props.isProvided('range') ? p.range : p.defaultRange) ?? {}
      );
    if (created || run.props.isProvided('month')) {
      const selectedDate =
        p.mode === 'multiple'
          ? (values[0] ?? '')
          : p.mode === 'range'
            ? (range.from ?? '')
            : value.get();
      const candidate =
        (run.props.isProvided('month') ? p.month : p.defaultMonth) ??
        (selectedDate.slice(0, 7) || p.today?.slice(0, 7) || '1970-01');
      month.set(parseDate(`${candidate}-01`) ? candidate : '1970-01', 'calendar owner month');
    }
    label.set(p.a11yLabel ?? 'Calendar', 'calendar accessible name');
    disabled.set(!!p.disabled, 'calendar disabled');
    direction.set(p.direction ?? 'ltr', 'calendar direction');
    publish(run);
  };
  def.lifecycle.onCreated((run) => sync(run, true));
  def.lifecycle.onMounted((run) => sync(run));
  def.props.watchAll((run) => sync(run));
  def.lifecycle.onUnmounted(() => {
    viewEpoch++;
    pendingNavigation = null;
    pendingSelection = null;
    owner = null;
  });
  def.lifecycle.onBeforeDispose(() => {
    pendingSelection = null;
    owner = null;
  });
}
export const asCalendarRoot = defineAsHook<
  CalendarRootProps,
  CalendarRootExposes,
  CalendarRootAsHookContract
>({
  name: 'as-calendar-root',
  setup: setupRoot,
});
export const calendarRoot = definePrototype({ name: 'base-calendar-root', setup: setupRoot });
function setupDay(def: DefHandle<CalendarDayProps, CalendarDayExposes>) {
  asCollectionItem().configure({
    family: CALENDAR_FAMILY,
    role: 'day',
    getMeta: () => ({ value: date.get(), disabled: disabled.get() }),
  });
  def.props.define({
    date: { type: 'string' },
    offset: { type: 'number' },
    disabled: { type: 'boolean' },
  });
  def.props.setDefaults({ date: '', offset: 0, disabled: false });
  const date = def.state.string('date', ''),
    selected = def.state.bool('selected', false),
    rangeStart = def.state.bool('rangeStart', false),
    rangeEnd = def.state.bool('rangeEnd', false),
    rangeMiddle = def.state.bool('rangeMiddle', false),
    rangePending = def.state.bool('rangePending', false),
    disabled = def.state.bool('disabled', false),
    outside = def.state.bool('outside', false),
    hidden = def.state.bool('hidden', false),
    today = def.state.bool('today', false),
    hovered = def.state.bool('hovered', false),
    pressed = def.state.bool('pressed', false),
    dateLabel = def.state.string('dateLabel', ''),
    current = def.state.string('current', 'false');
  const focus = asFocusable<CalendarDayProps>();
  focus.configure({ disabled: false, navParticipation: 'none' });
  asTrigger();
  const a11y = asAccessible();
  a11y.role('gridcell');
  a11y.name(dateLabel);
  a11y.state('current', current);
  a11y.state('selected', selected);
  a11y.action('activate');
  a11y.state('hidden', hidden);
  def.rule({
    when: (w) => w.state(hidden).eq(true),
    intent: (i) => i.feedback.style.use(tw('hidden')),
  });
  a11y.state('disabled', disabled);
  for (const [name, state] of Object.entries({
    date,
    selected,
    rangeStart,
    rangeEnd,
    rangeMiddle,
    rangePending,
    disabled,
    outside,
    hidden,
    today,
    hovered,
    pressed,
    focused: focus.focused,
    focusVisible: focus.focusVisible,
  }))
    def.expose.state(name as keyof CalendarDayExposes, state);
  def.expose.method('focusSelf', (options) => {
    if (!disabled.get()) focus.focusSelf(options);
  });
  let mounted = false;
  let handledFocusRequest = 0;
  const sync = (run: RunHandle<CalendarDayProps>) => {
    const c = run.context.read(CALENDAR_CONTEXT),
      p = run.props.get();
    const next =
      p.date || monthDays(c.month, c.weekStartsOn, c.fixedWeeks)[Math.trunc(p.offset ?? 0)] || '';
    const changed = next !== date.get();
    date.set(next, 'calendar day date');
    hidden.set(!next, 'calendar unused capacity');
    const selection = calendarDaySelection(next, c.mode, c.value, c.values, c.range);
    selected.set(selection.selected, 'calendar selected date');
    rangeStart.set(selection.rangeStart, 'calendar range start');
    rangeEnd.set(selection.rangeEnd, 'calendar range end');
    rangeMiddle.set(selection.rangeMiddle, 'calendar range middle');
    rangePending.set(selection.rangePending, 'calendar incomplete range');
    outside.set(next.slice(0, 7) !== c.month, 'calendar outside month');
    today.set(!!next && next === c.today, 'calendar current date');
    current.set(today.get() ? 'date' : 'false', 'calendar current date semantics');
    dateLabel.set(calendarDateLabel(next, c.locale), 'calendar localized date name');
    disabled.set(
      c.disabled || !!p.disabled || !dateAvailable(next, c.min, c.max, c.unavailable),
      'calendar unavailable date'
    );
    if (changed || disabled.get()) {
      hovered.set(false, 'calendar day interaction reset');
      pressed.set(false, 'calendar day interaction reset');
    }
    focus.setDisabled(disabled.get());
    focus.setNavParticipation(!disabled.get() && next === c.active ? 'auto' : 'none');
    if (mounted && changed) run.update();
    if (
      mounted &&
      !disabled.get() &&
      c.active === next &&
      c.focusRequest?.date === next &&
      c.focusRequest.id !== handledFocusRequest
    ) {
      handledFocusRequest = c.focusRequest.id;
      focus.focusSelf({ reason: 'keyboard' });
    }
  };
  def.context.subscribe(CALENDAR_CONTEXT, sync);
  def.lifecycle.onCreated(sync);
  def.lifecycle.onMounted((run) => {
    mounted = true;
    sync(run);
    run.update();
  });
  def.props.watchAll(sync);
  const clearInteraction = () => {
    hovered.set(false, 'calendar day interaction end');
    pressed.set(false, 'calendar day interaction end');
  };
  def.lifecycle.onUnmounted(() => {
    mounted = false;
    clearInteraction();
  });
  def.event.on('pointer.enter', () => {
    if (!disabled.get()) hovered.set(true, 'calendar day hover');
  });
  def.event.on('pointer.down', () => {
    if (!disabled.get()) pressed.set(true, 'calendar day press');
  });
  def.event.on('pointer.up', () => pressed.set(false, 'calendar day release'));
  def.event.on('pointer.leave', clearInteraction);
  def.event.on('pointer.cancel', clearInteraction);
  def.event.on('press.cancel', clearInteraction);
  def.event.on('press.commit', (run, event) => {
    pressed.set(false, 'calendar day commit');
    if (!disabled.get())
      callOwner(
        run,
        CALENDAR_FAMILY,
        'requestValue',
        date.get(),
        event.key ? 'keyboard' : 'pointer'
      );
  });
  def.event.on('key.down', (run, event) => {
    if (!focus.focused.get() || disabled.get() || event.ctrlKey || event.metaKey || event.altKey)
      return;
    if (event.key === ' ') {
      event.control.requestDefaultActionPrevention({
        reason: 'calendar.space-selection',
        source: 'base-calendar-day',
      });
      return;
    }
    const c = run.context.read(CALENDAR_CONTEXT);
    const current = parseDate(date.get());
    if (!current) return;
    let target = '';
    if (event.key === 'ArrowLeft') target = addDays(date.get(), c.direction === 'rtl' ? 1 : -1);
    if (event.key === 'ArrowRight') target = addDays(date.get(), c.direction === 'rtl' ? -1 : 1);
    if (event.key === 'ArrowUp') target = addDays(date.get(), -7);
    if (event.key === 'ArrowDown') target = addDays(date.get(), 7);
    if (event.key === 'Home')
      target = addDays(date.get(), -(current.getUTCDay() - c.weekStartsOn + 7) % 7);
    if (event.key === 'End')
      target = addDays(date.get(), 6 - ((current.getUTCDay() - c.weekStartsOn + 7) % 7));
    if (event.key === 'PageUp') target = addMonths(date.get(), event.shiftKey ? -12 : -1);
    if (event.key === 'PageDown') target = addMonths(date.get(), event.shiftKey ? 12 : 1);
    if (!target) return;
    const direction = target < date.get() ? -1 : 1;
    const stride = event.key === 'ArrowUp' || event.key === 'ArrowDown' ? 7 : 1;
    for (
      let attempts = 0;
      !dateAvailable(target, c.min, c.max, c.unavailable) && attempts < 366;
      attempts++
    ) {
      if ((c.min && target < c.min && direction < 0) || (c.max && target > c.max && direction > 0))
        return;
      target = addDays(target, direction * stride);
    }
    if (!dateAvailable(target, c.min, c.max, c.unavailable)) return;
    event.control.requestDefaultActionPrevention({
      reason: 'calendar.date-navigation',
      source: 'base-calendar-day',
    });
    callOwner(run, CALENDAR_FAMILY, 'requestMonth', target.slice(0, 7), target);
  });
  return () => (date.get() ? [String(Number(date.get().slice(-2)))] : null);
}
export const asCalendarDay = defineAsHook<
  CalendarDayProps,
  CalendarDayExposes,
  CalendarDayContract
>({ name: 'as-calendar-day', setup: setupDay });
export const calendarDay = definePrototype({ name: 'base-calendar-day', setup: setupDay });
function setupGrid(def: DefHandle<CalendarGridProps, CalendarGridExposes>) {
  def.anatomy.claim(CALENDAR_FAMILY, { role: 'grid' });
  const multiselectable = def.state.bool('multiselectable', false);
  const a11y = asAccessible();
  a11y.role('grid');
  a11y.state('multiSelectable', multiselectable);
  const sync = (run: RunHandle<CalendarGridProps>) =>
    multiselectable.set(
      run.context.read(CALENDAR_CONTEXT).mode !== 'single',
      'calendar grid selection mode'
    );
  def.context.subscribe(CALENDAR_CONTEXT, sync);
  def.lifecycle.onCreated(sync);
  def.lifecycle.onMounted(sync);
}
function setupRow(def: DefHandle<CalendarRowProps, CalendarRowExposes>) {
  def.anatomy.claim(CALENDAR_FAMILY, { role: 'row' });
  def.props.define({
    index: { type: 'number', validator: (value) => Number.isSafeInteger(value) && value >= 0 },
  });
  const hidden = def.state.bool('hidden', false);
  def.expose.state('hidden', hidden);
  const a = asAccessible();
  a.role('row');
  a.state('hidden', hidden);
  def.rule({
    when: (w) => w.state(hidden).eq(true),
    intent: (i) => i.feedback.style.use(tw('hidden')),
  });
  const sync = (run: RunHandle<CalendarRowProps>) => {
    const index = run.props.get().index;
    hidden.set(
      index !== undefined && index >= run.context.read(CALENDAR_CONTEXT).weekCount,
      'calendar unused row capacity'
    );
  };
  def.context.subscribe(CALENDAR_CONTEXT, sync);
  def.lifecycle.onCreated(sync);
  def.lifecycle.onMounted(sync);
  def.props.watchAll(sync);
}
function setupHeading(def: DefHandle<CalendarHeadingProps, CalendarHeadingExposes>) {
  def.anatomy.claim(CALENDAR_FAMILY, { role: 'heading' });
  const value = def.state.string('month', ''),
    display = def.state.string('displayValue', '');
  def.expose.state('month', value);
  def.expose.state('displayValue', display);
  let mounted = false;
  const sync = (run: RunHandle<any>) => {
    const c = run.context.read(CALENDAR_CONTEXT);
    const next = c.month;
    const text = calendarDateLabel(`${next}-01`, c.locale, { month: 'long', year: 'numeric' });
    if (next === value.get() && text === display.get()) return;
    value.set(next, 'calendar heading');
    display.set(text, 'calendar heading text');
    if (mounted) run.update();
  };
  def.context.subscribe(CALENDAR_CONTEXT, sync);
  def.lifecycle.onCreated(sync);
  def.lifecycle.onMounted((run) => {
    mounted = true;
    sync(run);
    run.update();
  });
  def.lifecycle.onUnmounted(() => {
    mounted = false;
  });
  return () => [display.get()];
}
export const asCalendarGrid = defineAsHook({ name: 'as-calendar-grid', setup: setupGrid });
export const asCalendarRow = defineAsHook<
  CalendarRowProps,
  CalendarRowExposes,
  CalendarRowAsHookContract
>({ name: 'as-calendar-row', setup: setupRow });
export const asCalendarHeading = defineAsHook<
  CalendarHeadingProps,
  CalendarHeadingExposes,
  CalendarHeadingAsHookContract
>({ name: 'as-calendar-heading', setup: setupHeading });
export const calendarGrid = definePrototype({ name: 'base-calendar-grid', setup: setupGrid });
export const calendarRow = definePrototype({ name: 'base-calendar-row', setup: setupRow });
export const calendarHeading = definePrototype({
  name: 'base-calendar-heading',
  setup: setupHeading,
});
function navigationSetup(direction: -1 | 1) {
  return (def: DefHandle<CalendarPreviousProps, CalendarPreviousExposes>) => {
    const button = asButton();
    def.props.define({ a11yLabel: { type: 'string' } });
    const defaultLabel = direction < 0 ? 'Previous month' : 'Next month';
    def.props.setDefaults({ a11yLabel: defaultLabel });
    const label = def.state.string('a11yLabel', defaultLabel);
    asAccessible().name(label);
    const focus = asFocusable();
    def.anatomy.claim(CALENDAR_FAMILY, { role: direction < 0 ? 'previous' : 'next' });
    const sync = (run: RunHandle<any>) => {
      label.set(run.props.get().a11yLabel ?? defaultLabel, 'calendar navigation name');
      const disabled = run.context.read(CALENDAR_CONTEXT).disabled || !!run.props.get().disabled;
      button.stateHandles?.disabled.set(disabled, 'calendar navigation disabled');
      focus.setDisabled(disabled);
      if (disabled) {
        button.stateHandles?.hovered.set(false, 'calendar disabled reset');
        button.stateHandles?.pressed.set(false, 'calendar disabled reset');
      }
    };
    def.context.subscribe(CALENDAR_CONTEXT, sync);
    def.lifecycle.onCreated(sync);
    def.lifecycle.onMounted(sync);
    def.props.watchAll(sync);
    def.event.on('press.commit', (run) => {
      if (button.stateHandles?.disabled.get()) return;
      const c = run.context.read(CALENDAR_CONTEXT);
      callOwner(
        run,
        CALENDAR_FAMILY,
        'requestMonth',
        addMonths(`${c.month}-01`, direction).slice(0, 7)
      );
    });
  };
}
export const asCalendarPrevious = defineAsHook<
  CalendarPreviousProps,
  CalendarPreviousExposes,
  CalendarNavigationAsHookContract
>({
  name: 'as-calendar-previous',
  setup: navigationSetup(-1),
});
export const asCalendarNext = defineAsHook<
  CalendarPreviousProps,
  CalendarPreviousExposes,
  CalendarNavigationAsHookContract
>({ name: 'as-calendar-next', setup: navigationSetup(1) });
export const calendarPrevious = definePrototype({
  name: 'base-calendar-previous',
  setup: navigationSetup(-1),
});
export const calendarNext = definePrototype({
  name: 'base-calendar-next',
  setup: navigationSetup(1),
});

function setupCaption(def: DefHandle<CalendarCaptionProps, CalendarCaptionExposes>) {
  def.anatomy.claim(CALENDAR_FAMILY, { role: 'caption' });
  def.props.define({ a11yLabel: { type: 'string' } });
  def.props.setDefaults({ a11yLabel: 'Calendar navigation' });
  const label = def.state.string('a11yLabel', 'Calendar navigation');
  const a = asAccessible();
  a.role('group');
  a.name(label);
  const sync = (run: RunHandle<CalendarCaptionProps>) =>
    label.set(run.props.get().a11yLabel ?? 'Calendar navigation', 'calendar caption name');
  def.lifecycle.onCreated(sync);
  def.props.watchAll(sync);
}
export const asCalendarCaption = defineAsHook<
  CalendarCaptionProps,
  CalendarCaptionExposes,
  { state: { a11yLabel: import('@proto.ui/core').State<string> } }
>({ name: 'as-calendar-caption', setup: setupCaption });
export const calendarCaption = definePrototype({
  name: 'base-calendar-caption',
  setup: setupCaption,
});
function setupWeekdays(def: DefHandle<CalendarWeekdaysProps, CalendarWeekdaysExposes>) {
  def.anatomy.claim(CALENDAR_FAMILY, { role: 'weekdays' });
  asAccessible().role('row');
}
export const asCalendarWeekdays = defineAsHook({
  name: 'as-calendar-weekdays',
  setup: setupWeekdays,
});
export const calendarWeekdays = definePrototype({
  name: 'base-calendar-weekdays',
  setup: setupWeekdays,
});
function setupWeekday(def: DefHandle<CalendarWeekdayProps, CalendarWeekdayExposes>) {
  def.anatomy.claim(CALENDAR_FAMILY, { role: 'weekday' });
  def.props.define({ offset: { type: 'number' } });
  def.props.setDefaults({ offset: 0 });
  const weekday = def.state.numberDiscrete('weekday', 0),
    label = def.state.string('label', ''),
    description = def.state.string('description', '');
  def.expose.state('weekday', weekday);
  def.expose.state('label', label);
  const a = asAccessible();
  a.role('columnheader');
  a.name(description);
  let mounted = false;
  const sync = (run: RunHandle<CalendarWeekdayProps>) => {
    const c = run.context.read(CALENDAR_CONTEXT),
      next = weekdayInfo(run.props.get().offset ?? 0, c.weekStartsOn, c.locale);
    const changed = next.label !== label.get();
    weekday.set(next.weekday, 'calendar weekday');
    label.set(next.label, 'calendar weekday label');
    description.set(next.description, 'calendar weekday description');
    if (mounted && changed) run.update();
  };
  def.context.subscribe(CALENDAR_CONTEXT, sync);
  def.props.watchAll(sync);
  def.lifecycle.onCreated(sync);
  def.lifecycle.onMounted((run) => {
    mounted = true;
    sync(run);
    run.update();
  });
  def.lifecycle.onUnmounted(() => {
    mounted = false;
  });
  return () => [label.get()];
}
export const asCalendarWeekday = defineAsHook<
  CalendarWeekdayProps,
  CalendarWeekdayExposes,
  CalendarWeekdayAsHookContract
>({ name: 'as-calendar-weekday', setup: setupWeekday });
export const calendarWeekday = definePrototype({
  name: 'base-calendar-weekday',
  setup: setupWeekday,
});
