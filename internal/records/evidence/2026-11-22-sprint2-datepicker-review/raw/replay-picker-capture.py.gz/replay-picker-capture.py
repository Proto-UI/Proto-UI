from pathlib import Path
import hashlib, json, subprocess
base = Path('/workspace/scratch/44c416809288')
e = base / 'evidence'
root = base / 'Proto-UI'
files = ['packages/prototypes/base/src/calendar/calendar.proto.ts', 'packages/prototypes/base/src/calendar/types.ts', 'packages/prototypes/base/src/date-picker/date-picker.proto.ts', 'packages/prototypes/base/src/popover/root.proto.ts', 'packages/prototypes/base/src/popover/shared.ts', 'packages/prototypes/base/test/selection-reset-lifecycle.test.ts', 'spec/contracts/C-CALENDAR-SELECTION-0001.yaml', 'spec/prototypes/P-BASE-POPOVER.yaml', 'spec/tests/T-CALENDAR-SELECTION-0001.yaml']
rows = []
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
for f in files:
    raw = (root/f).read_bytes()
    dest = e / 'datepicker-review-sources/final-request-capture' / f
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and dest.read_bytes() != raw:
        raise RuntimeError('Would overwrite immutable final source snapshot: ' + str(dest))
    dest.write_bytes(raw)
    rows.append({'source': f, 'snapshot': str(dest), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'matchesHeadAtStart': raw == subprocess.check_output(['git', 'show', head + ':' + f], cwd=root)})
results = []
for original in ['compiler-review-picker-request-start', 'compiler-review-picker-context-start', 'compiler-review-picker-context-nested', 'compiler-review-picker-context-oldclose']:
    identifier = original + '-capture-green'
    src = (e / (original + '.mts')).read_text()
    old = str(e / (original + '.json'))
    new = str(e / (identifier + '.json'))
    assert src.count(old) == 1
    script = e / (identifier + '.mts')
    assert not script.exists(), str(script)
    script.write_text(src.replace(old, new))
    log = e / (identifier + '.log')
    with log.open('w') as stream:
        result = subprocess.run(['node', '--import', 'tsx', str(script)], cwd=root, stdout=stream, stderr=subprocess.STDOUT)
    receipt = e / (identifier + '.json')
    results.append({'id': identifier, 'originalProbe': str(e / (original + '.mts')), 'originalProbeSha256': hashlib.sha256((e / (original + '.mts')).read_bytes()).hexdigest(), 'script': str(script), 'scriptSha256': hashlib.sha256(script.read_bytes()).hexdigest(), 'receipt': str(receipt), 'receiptSha256': hashlib.sha256(receipt.read_bytes()).hexdigest() if receipt.exists() else None, 'log': str(log), 'exitCode': result.returncode, 'files': rows, 'baseCommit': head, 'uncommittedSourceDeltaAtExecution': any(not r['matchesHeadAtStart'] for r in rows), 'replayChange': 'Only the JSON output destination changed; all case bodies and assertions remain original.'})
stable = all(hashlib.sha256((root/r['source']).read_bytes()).hexdigest() == r['sha256'] for r in rows)
for r in results:
    r['allSourcesStableBeforeAfterExecution'] = stable
p = e / 'compiler-review-picker-source-bindings.json'
bindings = json.loads(p.read_text())
existing = {r['id'] for r in bindings['runs']}
assert all(r['id'] not in existing for r in results)
bindings['runs'].extend(results)
bindings['clarification'] += ' Final capture replays likewise preserve each original probe verbatim apart from output JSON destination; any reviewedCommit inside a raw receipt is its inherited baseline, while this binding records executed files and hashes.'
p.write_text(json.dumps(bindings, indent=2) + '\n')
summary = {'headAtStart': head, 'sourceStable': stable, 'results': [{'id': r['id'], 'exitCode': r['exitCode'], 'result': json.loads(Path(r['receipt']).read_text()) if Path(r['receipt']).exists() else None} for r in results]}
(e / 'compiler-review-picker-capture-replay-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
if not stable or any(r['exitCode'] for r in results):
    raise SystemExit(1)
