# Proto-UI pinned compiler

Source revision: 4ffc65f2c3d32bcd5d1bd897ab20d9c6f087fb3c

Run `npm ci --ignore-scripts` in this directory, then `node cli.js --build-info` and `node cli.js check <entry.proto.ts> --root <source root> --profile <profile>`. The only compiler runtime package is TypeScript 5.9.3; Node 24 built-ins supply the remaining imports. No Proto-UI public-package build or Floating UI installation is needed for the compiler. Generated consumers must install the exact dependencies in their own provenance.

Keep this directory immutable. Generated output is consumer-owned and editable; compile uses a new destination, diff is read-only, and watch keeps immutable revisions. Create the parent directory yourself; existing output is never overwritten. The source SHA and profiles.json digest are the support pin. These private experimental profiles are not registry releases or broader semantic admission. JavaScript API exports are available through index.js; this artifact does not provide a declaration-file release.
