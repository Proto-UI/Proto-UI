// Editable generated Vue 2.6.14 component options. Profile: vue2-source-v1.
// Inline native-lowering helpers: logical owner, prop resolution, state, semantic templates.
// No Proto-UI Core, Runtime, Hooks or Adapter dependency; optional native helpers are emitted artifacts.
// Source graph SHA-256: 84930a478b4294c89672872bb3fe8bc42783fe0080f864762cd2a4491bce9e72
import { releaseNativeMeta as __pui_ReleaseMeta } from './.proto-ui/meta/subscription-v1';
import { readNativeWebMeta as __pui_ReadMeta } from './.proto-ui/meta/web-snapshot-v1';
import { subscribeNativeColorScheme as __pui_SubscribeColorScheme } from './.proto-ui/meta/color-scheme-source-v1';


import { createNativeAuthoredHooks as __pui_CreateAuthored } from './.proto-ui/owner/authored-hooks-v1';
import { normalizeVue2InstanceAssociations as __pui_NormalizeAssociations } from './.proto-ui/interaction/vue2-associations-v1';
import { createNativeStyle as __pui_CreateNativeStyle, templateStyleTokens as __pui_TemplateStyleTokens } from './.proto-ui/style/native-v1';
import { createNativeInteraction as __pui_CreateNativeInteraction } from './.proto-ui/interaction/native-e6807d4f71af1465-v2';
/** @template Run @typedef {import('./.proto-ui/interaction/native-e6807d4f71af1465-v2').NativeInteraction<Run>} __pui_NativeInteraction */
/** @typedef {import('./.proto-ui/interaction/native-e6807d4f71af1465-v2').NativeFocus} __pui_NativeFocus */
/** @typedef {import('./.proto-ui/interaction/native-e6807d4f71af1465-v2').NativeAccessible} __pui_NativeAccessible */
/** @template T @typedef {import('./.proto-ui/interaction/native-e6807d4f71af1465-v2').NativeObservedState<T>} __pui_NativeObservedState */
/** @typedef {import('./.proto-ui/interaction/native-e6807d4f71af1465-v2').NativeInput} __pui_NativeInput */
/** @typedef {import('./.proto-ui/interaction/native-e6807d4f71af1465-v2').NativeFocusOptions} __pui_NativeFocusOptions */
import { createContextScope as __pui_CreateContextScope, scopeKey as __pui_ScopeKey, acceptsContextValue as __pui_AcceptsContextValue } from './.proto-ui/context/scope-v1';
import { key as __pui_ContextKey0 } from './.proto-ui/context/key-3b78218c16abf6ec58c87de2ca3750964b015dc709f9d123d79d8ddb43fc57f9';

// Source "packages/prototypes/shadcn/src/style-scope/context.ts":4:33
const __puiModule0 = ["vega", "nova", "maia", "lyra", "mira", "luma", "sera", "rhea", "new-york-v4"];
// Source "packages/prototypes/shadcn/src/style-scope/context.ts":23:1
const __puiModule3 = /** @param {unknown} value @returns {"vega" | "nova" | "maia" | "lyra" | "mira" | "luma" | "sera" | "rhea" | "new-york-v4" | null} */ (value) => {
  // Source "packages/prototypes/shadcn/src/style-scope/context.ts":24:3
  if ((((value === (void 0)) || (value === null)) || (value === "inherit"))) {
    // Source "packages/prototypes/shadcn/src/style-scope/context.ts":24:69
    return null;
  }
  // Source "packages/prototypes/shadcn/src/style-scope/context.ts":25:3
  if ((value === "new-york")) {
    // Source "packages/prototypes/shadcn/src/style-scope/context.ts":25:29
    return "new-york-v4";
  }
  // Source "packages/prototypes/shadcn/src/style-scope/context.ts":26:3
  if ((/** @type {readonly unknown[]} */ (__puiModule0)).includes(value)) {
    // Source "packages/prototypes/shadcn/src/style-scope/context.ts":26:58
    return /** @type {"vega" | "nova" | "maia" | "lyra" | "mira" | "luma" | "sera" | "rhea" | "new-york-v4"} */ (value);
  }
  // Source "packages/prototypes/shadcn/src/style-scope/context.ts":27:3
  throw new Error(("[shadcn-style-scope] Unknown style: " + String(value)));
};


/** @typedef {{
  "variant"?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link" | null;
  "size"?: "default" | "sm" | "lg" | "icon" | "icon-compact" | null;
  "disabled"?: boolean | null;
  "wrap"?: boolean | null;
  "styleProfile"?: "vega" | "nova" | "maia" | "lyra" | "mira" | "luma" | "sera" | "rhea" | "new-york-v4" | "new-york" | "inherit" | null;
}} GeneratedProps */
/** @typedef {Readonly<{
  readonly "variant": "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
  readonly "size": "default" | "sm" | "lg" | "icon" | "icon-compact";
  readonly "disabled": boolean;
  readonly "wrap": boolean;
  readonly "styleProfile"?: "vega" | "nova" | "maia" | "lyra" | "mira" | "luma" | "sera" | "rhea" | "new-york-v4" | "new-york" | "inherit" | null;
} & Record<string, unknown>>} __pui_ResolvedProps */
/** @typedef {{
  "disabled": __pui_ExternalState<boolean>;
  "hovered": __pui_ExternalState<boolean>;
  "focused": __pui_ExternalState<boolean>;
  "focusVisible": __pui_ExternalState<boolean>;
  "focusSelf": (options?: { "reason"?: "programmatic" | "keyboard" | "pointer"; "preventScroll"?: boolean }) => void;
  "pressed": __pui_ExternalState<boolean>;
}} GeneratedExposes */
/** @typedef {Array<import('vue').VNode | string>} __pui_NativeChildren */
/** @typedef {{ used: boolean }} __pui_NativeSlotFrame */
/** @typedef {(h: import('vue').CreateElement, vm: import('vue').default, slots: __pui_NativeSlotFrame) => __pui_NativeChildren} __pui_NativePaint */
/** @typedef {{
 * slot: () => __pui_NativePaint,
 * read: {
 *   props: {
 *     get: () => __pui_ResolvedProps,
 *     getRaw: () => Readonly<Record<string, unknown>>,
 *     isProvided: (key: PropertyKey) => boolean
 *   },
 *   context: {
 *     read: (key: object) => ReturnType<import('./.proto-ui/context/scope-v1').ContextScope['read']>,
 *     tryRead: (key: object) => ReturnType<import('./.proto-ui/context/scope-v1').ContextScope['tryRead']>
 *   }
 * }
 * }} __pui_NativeRenderer */
/** @typedef {import('./.proto-ui/style/native-v1').NativeStyleHandle} __pui_NativeStyleHandle */

/**
 * @template T
 * @typedef {{ get: () => T, subscribe: (callback: (event: { type: 'next', prev: T, next: T, reason?: unknown } | { type: 'disconnect', reason: 'unmount' }) => void) => (() => void), unsubscribe: (off: () => void) => void, spec: Readonly<Record<string, unknown>> }} __pui_ExternalState
 */
/** @template T @typedef {{ type: 'next', prev: T, next: T, reason?: unknown } | { type: 'disconnect', reason: 'unmount' }} __pui_StateEvent */
/** @template T @typedef {{ get: () => T, setDefault: (value: T) => void, set: (value: T, reason?: unknown) => void, external: __pui_ExternalState<T>, dispose: () => void }} __pui_OwnedState */
/** @typedef {'boolean' | 'number' | 'string' | 'null' | 'void' | { kind: 'literal', value: string | number | boolean | null } | { kind: 'array', element: __pui_DataType } | { kind: 'union', members: readonly __pui_DataType[] } | { kind: 'record', fields: readonly { name: string, type: __pui_DataType, optional?: boolean }[] }} __pui_DataType */
/** @typedef {Readonly<Record<string, unknown>>} __pui_RawProps */
/** @typedef {{ type: 'boolean' | 'number' | 'string' | 'object' | 'any' | 'enum', empty?: 'accept' | 'fallback' | 'error', default?: unknown, options?: readonly string[], range?: { min?: number, max?: number } }} __pui_PropSpec */
/** @typedef {{ options?: readonly (boolean | string | number)[], min?: unknown, max?: unknown, step?: unknown, clamp?: boolean } & Record<string, unknown>} __pui_StateConfiguration */
/** @typedef {'bool' | 'string' | 'enum' | 'number.discrete' | 'number.range'} __pui_StateKind */
/** @typedef {ReturnType<typeof __pui_CreateOwner>} __pui_Owner */
/** @typedef {Parameters<Parameters<__pui_Owner['def']['props']['watch']>[1]>[0]} __pui_Run */
/** @typedef {import('vue').default & { readonly instanceAssociations?: Readonly<{controlLabel?: object | null}>; readonly __pui_ParentScope?: import('./.proto-ui/context/scope-v1').ContextScope | null }} __pui_OwnerInstance */
/** @typedef {(renderer: __pui_NativeRenderer) => __pui_NativePaint} __pui_RenderFunction */
/** @typedef {{ changedKeysAll: string[], changedKeysMatched: string[] }} __pui_PropsWatchInfo */
/** @template Run @template Snapshot @typedef {(run: Run, next: Snapshot, previous: Snapshot, info: __pui_PropsWatchInfo) => void} __pui_PropsWatchCallback */
/** @template Run @typedef {{ kind: 'resolved' | 'resolved-all', keys: readonly string[] | null, fn: __pui_PropsWatchCallback<Run, __pui_ResolvedProps> } | { kind: 'raw' | 'raw-all', keys: readonly string[] | null, fn: __pui_PropsWatchCallback<Run, __pui_RawProps> }} __pui_PropsWatchRegistration */
/** @typedef {"created" | "mounted" | "updated" | "unmounted" | "beforeDispose"} __pui_LifecycleKind */
/** @template Run @typedef {(run: Run) => void} __pui_LifecycleCallback */
/** @template Run @typedef {__pui_PropsWatchRegistration<Run> & { active: boolean }} __pui_PropsWatcher */
/** @typedef {{ epoch: number, revision: number, kind: 'update' }} __pui_PendingCommit */
/** @typedef {{ epoch: number, version: number, present: boolean, vnode: import('vue').VNode, kind: 'mount' | 'update' | 'none' | 'detach', revision?: number | null }} __pui_RenderedCommit */
/** @param {unknown} value @param {PropertyKey} key */
const __pui_Own = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
// Keep native relational coercion in all three open-schema comparisons.
/** @template T @param {T} left @param {T} right */
const __pui_Before = (left, right) => left < right;

/** @param {__pui_DataType} type @param {unknown} value @returns {boolean} */
function __pui_Accepts(type, value) {
  if (typeof type === 'string') return type === 'null' ? value === null : typeof value === type && (type !== 'number' || Number.isFinite(value));
  if (type.kind === 'literal') return Object.is(value, type.value);
  if (type.kind === 'union') return type.members.some((member) => __pui_Accepts(member, value));
  if (type.kind === 'array') return Array.isArray(value) && value.every((item) => __pui_Accepts(type.element, item));
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false;
  const record = /** @type {Record<string, unknown>} */ (value);
  return type.fields.every((field) =>
    __pui_Own(record, field.name) ? __pui_Accepts(field.type, record[field.name]) : field.optional === true);
}
/** @param {unknown} value @param {Set<object>} [seen] @returns {boolean} */
function __pui_Json(value, seen = new Set()) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return true;
  if (typeof value === 'number') return Number.isFinite(value);
  if (typeof value !== 'object' || seen.has(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  if (!Array.isArray(value) && prototype !== Object.prototype && prototype !== null) return false;
  if (Array.isArray(value) && (Object.keys(value).length !== value.length || !Object.keys(value).every((key) => /^(0|[1-9]\d*)$/.test(key) && Number(key) < value.length))) return false;
  seen.add(value);
  const valid = Object.values(value).every((item) => __pui_Json(item, seen));
  seen.delete(value);
  return valid;
}

/** @param {Readonly<Record<string, string | number | boolean | null>>} properties @param {Record<string, string | null>} attrs @param {boolean} initial */
function __pui_RootData(properties, attrs, initial) {
  /** @type {import('vue').VNodeData & { pre: true, attrs: Record<string, string | number | null> }} */
  const result = { pre: true, attrs: { ...attrs } };
  for (const [key, value] of Object.entries(properties)) {
    if (key === 'value') { if (initial) result.domProps = { value }; }
    else if (key === 'style') { if (typeof value === 'string') result.style = value; }
    else result.attrs[key] = value === false ? null : value === true ? '' : value;
  }
  return result;
}
/** @param {__pui_OwnerInstance} vm @param {(owner: __pui_Owner) => __pui_RenderFunction | void} setup @param {Record<string, __pui_DataType>} types @param {string} rootTag @param {boolean} autoUpdate */
function __pui_CreateOwner(vm, setup, types, rootTag, autoUpdate) {
  
  let phase = 'setup';
  let terminal = false;
  let disposed = false;
  let hydrated = false;
  let nativeMounted = false;
  let hostActive = true;
  let present = true;
  let viewActive = false;
  let epoch = 0;
  let revision = 0;
  let commitVersion = 0;
  let queued = false;
  /** @type {__pui_PendingCommit | null} */
  let pending = null;
  /** @type {__pui_RenderedCommit | null} */
  let renderedCommit = null;
  /** @type {HTMLElement | null} */ let activeRoot = null;
  let activeEpoch = -1;
  /** @type {__pui_NativePaint | null} */
  let template = null;
  /** @type {__pui_RenderFunction | null | void} */
  let renderFunction;
  /** @type {(() => void) | undefined} */
  let unwatch;
  /** @type {__pui_RawProps} */
  let raw = Object.freeze({});
  /** @type {__pui_ResolvedProps} */
  let resolved = /** @type {__pui_ResolvedProps} */ (Object.freeze({}));
  /** @type {Record<string, unknown>} */
  let previousValid = Object.create(null);
  /** @type {Record<string, __pui_PropSpec>} */
  let specs = Object.create(null);
  /** @type {__pui_RawProps[]} */
  const defaults = [];
  /** @type {Array<__pui_PropsWatcher<typeof run>>} */
  const watchers = [];
  /** @type {Array<{ dispose: () => void }>} */
  const states = [];
  /** @type {Record<string, unknown>} */
  const exposed = Object.create(null);
  /** @type {Record<string, unknown>} */
  const eventDeclarations = Object.create(null);
  /** @type {Record<__pui_LifecycleKind, Array<__pui_LifecycleCallback<typeof run>>>} */
  const lifecycle = { "created": [], "mounted": [], "updated": [], "unmounted": [], "beforeDispose": [] };
  /** @type {Array<() => void>} */
  const notifications = [];
  /** @type {WeakMap<object, __pui_ExternalState<unknown>>} */
  const observedExternals = new WeakMap();
  /** @template T @param {{ get: () => T }} state @returns {__pui_ExternalState<T>} */
  function externalState(state) {
    const external = observedExternals.get(state);
    if (!external) throw new Error('[State] handle does not belong to this generated owner.');
    // Registration binds this exact handle to its same-value external view.
    return /** @type {__pui_ExternalState<T>} */ (external);
  }
  let notifying = false;
  let dispatchingProps = false;
  /** @type {{raw: __pui_RawProps; resolved: __pui_ResolvedProps} | null} */
  let propsWindow = null;
  const alive = () => { if (disposed) throw new Error('[Vue2 native] logical instance has been disposed.'); };
  const publicAlive = () => { if (terminal) throw new Error('[Vue2 native] exposed target has been terminally invalidated.'); };
  const callback = () => { alive(); if (phase !== 'callback') throw new Error('[Vue2 native] mutation requires callback scope.'); };
  const setupOnly = () => { alive(); if (phase !== 'setup') throw new Error('[Vue2 native] declaration requires setup scope.'); };
  const style = __pui_CreateNativeStyle({
    getMeta: /** @param {string} key */ (key) => __pui_ReadMeta(activeRoot?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), key), subscribeMeta: /** @param {() => void} notify */ (notify) => { /** @type {(() => void)[]} */ const leases = []; try { leases.push(__pui_SubscribeColorScheme(activeRoot?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), notify)); } catch (error) { __pui_ReleaseMeta([() => { throw error; }, ...leases]); } return () => __pui_ReleaseMeta(leases); },
    ensureSetup: setupOnly,
    ensureRuntime: callback,
    isAlive: () => !terminal && !disposed,
    project: (tokens) => {
      if (!activeRoot) return;
      if (tokens.length) activeRoot.setAttribute('data-pui-style', tokens.join(' '));
      else activeRoot.removeAttribute('data-pui-style');
    },
  });
  /** @returns {__pui_RawProps} */
  const hostRaw = () => {
    
    // Full snapshots preserve omission and explicit undefined. Vue Boolean casting and
    // default materialization never participate in the semantic prop contract.
    const out = Object.create(null);
    /** @type {Record<string, unknown>} */
    const input = { ...(vm.$attrs || {}), ...((vm.$options && vm.$options.propsData) || {}) };
    /** @type {Readonly<Record<string, unknown>>} */
    const provided = /** @type {Readonly<Record<string, unknown>>} */ ((vm.$options && vm.$options.propsData) || {});
    for (const key of Object.keys(types)) {
      const hostKey = key.replace(/-(\w)/g, (_match, letter) => letter.toUpperCase());
      // Track native prop notifications, but keep values/presence from the raw snapshot.
      if (vm.$props) void (/** @type {Readonly<Record<string, unknown>>} */ (vm.$props))[hostKey];
      if (__pui_Own(provided, hostKey)) input[key] = provided[hostKey];
    }
    for (const key of Object.keys(input)) if (key !== 'instanceAssociations' && key !== 'instance-associations') out[key] = input[key];
    return Object.freeze(out);
  };
  /** @param {__pui_RawProps} a @param {__pui_RawProps} b */
  const same = (a, b) => {
    const keys = Object.keys(a);
    return keys.length === Object.keys(b).length && keys.every((key) => __pui_Own(b, key) && Object.is(a[key], b[key]));
  };
  /** @param {string} key @param {unknown} value */
  const validValue = (key, value) => {
    const spec = specs[key];
    if (!__pui_Json(value) || !__pui_Accepts(types[key], value)) return false;
    if (spec.type === 'enum' && (typeof value !== 'string' || !spec.options?.includes(value))) return false;
    return !spec.range || typeof value === 'number' && value >= (spec.range.min ?? -Infinity) && value <= (spec.range.max ?? Infinity);
  };
  /** @param {__pui_RawProps} input @param {boolean} strict */
  const resolveProps = (input, strict) => {
    /** @type {Record<string, unknown>} */
    const out = Object.create(null);
    const nextValid = { ...previousValid };
    /** @type {{ providedKeys: string[], emptyKeys: string[], invalidKeys: string[], usedFallbackKeys: string[], acceptedEmptyKeys: string[] }} */
    const meta = { providedKeys: [], emptyKeys: [], invalidKeys: [], usedFallbackKeys: [], acceptedEmptyKeys: [] };
    for (const key of Object.keys(specs)) {
      const spec = specs[key];
      const provided = __pui_Own(input, key);
      const value = input[key] === undefined ? null : input[key];
      const empty = spec.empty ?? 'fallback';
      if (provided) meta.providedKeys.push(key);
      if (provided && value !== null && validValue(key, value)) {
        out[key] = value; nextValid[key] = value; continue;
      }
      if (provided && value === null) {
        meta.emptyKeys.push(key);
        if (empty === 'accept') { out[key] = null; meta.acceptedEmptyKeys.push(key); continue; }
      } else if (provided) meta.invalidKeys.push(key);
      let found = false;
      /** @type {unknown} */
      let selected = null;
      let usedDefault = true;
      /** @param {unknown} candidate @param {boolean} fromDefault */
      const take = (candidate, fromDefault) => {
        if (found || candidate === undefined || strict && empty === 'error' && candidate === null) return;
        if (candidate !== null && !validValue(key, candidate)) return;
        found = true; selected = candidate; usedDefault = fromDefault;
      };
      if (provided && __pui_Own(previousValid, key)) take(previousValid[key], false);
      for (const layer of defaults) if (__pui_Own(layer, key)) take(layer[key], true);
      if (__pui_Own(spec, 'default')) take(spec.default, true);
      if (!found && strict && empty === 'error') throw new Error('[Vue2 native] prop ' + key + ' requires a non-empty valid value or fallback.');
      out[key] = selected;
      if (usedDefault) meta.usedFallbackKeys.push(key);
      if (provided && selected !== null) nextValid[key] = selected;
    }
    previousValid = nextValid;
    /** @type {__pui_ResolvedProps} */
    const snapshot = /** @type {__pui_ResolvedProps} */ (Object.freeze(out));
    return { snapshot, meta };
  };
  /** @template T @param {() => T} fn @param {boolean} [sync] @returns {T} */
  const invoke = (fn, sync = true) => {
    alive();
    const previousPhase = phase;
    phase = 'callback';
    try { if (sync && !terminal ) syncHost(false); return fn(); }
    finally { phase = previousPhase; }
  };
  /** @param {boolean} request */
  const syncHost = (request) => {
    if (terminal) return;
    interaction.refresh();
    const nextRaw = hostRaw();
    if (hydrated && same(raw, nextRaw)) return;
    const previousRaw = raw;
    const previous = resolved;
    const next = resolveProps(nextRaw, true);
    raw = nextRaw; resolved = next.snapshot;
    if (!hydrated) { hydrated = true; style.refresh(); interaction.refresh(); return; }
    const changedKeys = Object.keys(specs).filter((key) => !Object.is(previous[key], resolved[key]));
    const changedRawKeys = watchers.some((watch) => watch.active && (watch.kind === 'raw' || watch.kind === 'raw-all'))
      ? [...new Set([...Object.keys(previousRaw), ...Object.keys(raw)])].filter((key) => !Object.is(previousRaw[key], raw[key])) : [];
    if (changedKeys.length) { style.refresh(); interaction.refresh(); }
    if ((changedKeys.length || changedRawKeys.length) && !dispatchingProps) {
      dispatchingProps = true;
      const previousWindow = propsWindow; propsWindow = {raw: nextRaw, resolved: next.snapshot};
      try {
        invoke(() => {
          // Raw-all precedes raw-keyed; resolved-all and keyed share declaration order.
          const snapshot = watchers.slice();
          for (let group = 0; group < 3; ++group) {
            for (const watch of snapshot) {
              if (!watch.active || (watch.kind === 'raw-all' ? 0 : watch.kind === 'raw' ? 1 : 2) !== group) continue;
              const isRaw = group < 2;
              const changedKeysAll = isRaw ? changedRawKeys : changedKeys;
              const changedKeysMatched = watch.keys === null ? changedKeysAll : watch.keys.filter((key) => changedKeysAll.includes(key));
              if (changedKeysMatched.length) {
                const info = { changedKeysAll: [...changedKeysAll], changedKeysMatched: [...changedKeysMatched] };
                // The registration discriminant preserves the raw/resolved callback
                // relation; the host group order and snapshot copies stay unchanged.
                if (watch.kind === 'raw' || watch.kind === 'raw-all') {
                  console.warn('[Props] raw watchers are an adapter-snapshot escape hatch; avoid in official prototypes.');
                  watch.fn(run, nextRaw, previousRaw, info);
                }
                else watch.fn(run, next.snapshot, previous, info);
              }
            }
          }
        }, false);
      } finally { propsWindow = previousWindow; dispatchingProps = false; }
    }
    if (request && autoUpdate) update();
  };
  const renderSemantic = () => {
    if (!renderFunction) throw new Error('[Vue2 native] renderer is unavailable outside the initialized instance lifetime.');
    const previousPhase = phase;
    phase = 'render';
    try { template = renderFunction(renderer); }
    finally { phase = previousPhase; }
  };
  const force = () => { if (!terminal && nativeMounted) vm.$forceUpdate(); };
  const update = () => {
    if (terminal) return;
    invoke(() => {}, true);
    if (!nativeMounted || !hostActive || !present || !viewActive) return;
    if (pending) { queued = true; return; }
    renderSemantic();
    pending = { epoch, revision: ++revision, kind: 'update' };
    force();
  };
  /** @param {boolean} next */
  const setPresent = (next) => {
    callback();
    if (terminal) throw new Error('[Vue2 native] presence is locked for terminal disposal.');
    if (present === next) return;
    present = next; ++epoch; pending = null; renderedCommit = null; queued = false;
    const requestedEpoch = epoch, failures = [];
    // Vue must patch at the owned anchor, not leave its replacement comment
    // in the Portal host and later resurrect the already-removed Root.
    
    if (!terminal && epoch === requestedEpoch && present === next) {
      if (!next) { try { interaction.unmount(); } catch (error) { failures.push(error); } }
      if (!terminal && epoch === requestedEpoch && present === next) {
        // A newer presence request or terminal disposal always wins reentry.
        try {
          if (next && nativeMounted && hostActive && viewActive) renderSemantic();
          force();
        } catch (error) { failures.push(error); }
      }
    }
    if (failures.length) throw failures.length === 1 ? failures[0]
      : new AggregateError(failures, '[Vue2 native] presence withdrawal failed.');
  };

  /** @type {Map<object, (value: unknown) => boolean>} */
  const contextChecks = new Map([
    [__pui_ContextKey0, (/** @param {unknown} value */ (value) => __pui_AcceptsContextValue({"kind":"record","fields":[{"name":"style","type":{"kind":"union","members":[{"kind":"literal","value":"vega"},{"kind":"literal","value":"nova"},{"kind":"literal","value":"maia"},{"kind":"literal","value":"lyra"},{"kind":"literal","value":"mira"},{"kind":"literal","value":"luma"},{"kind":"literal","value":"sera"},{"kind":"literal","value":"rhea"},{"kind":"literal","value":"new-york-v4"},"null"]}}]}, value))],
  ]);
  const contextScope = __pui_CreateContextScope({
    getParent: () => vm["__pui_ParentScope"] || null,
    isAlive: () => !disposed,
    invoke: (fn) => invoke(fn, false),
    validate: (key, value) => contextChecks.get(key)?.(value) === true,
  });
  const contextRead = Object.freeze({ read: (/** @param {object} key */ (key) => { alive(); return contextScope.read(key); }), tryRead: (/** @param {object} key */ (key) => { alive(); return contextScope.tryRead(key); }) });

  const __pui_Meta = /** @param {string} key */ (key) => __pui_ReadMeta(vm.$el?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), key);
  /** @type {(() => void)[]} */ const __pui_AuthoredWatchCleanups = [];
  const __pui_Authored = __pui_CreateAuthored({setup: setupOnly, borrow(/** @type {unknown} */ value) {
    
    const state = /** @type {__pui_OwnedState<unknown>} */ (value);
    const borrowed = Object.freeze({get: () => state.get(), setDefault: (/** @type {unknown} */ value) => state.setDefault(value), set: (/** @param {unknown} value @param {unknown} [reason] */ (value, reason) => state.set(value, reason)), watch: (/** @type {(run: __pui_Run, event: __pui_StateEvent<unknown>) => void} */ fn) => { setupOnly(); const off = state.external.subscribe(event => invoke(() => fn(run, event), false)); __pui_AuthoredWatchCleanups.push(off); return off; }});
    
    return borrowed;
    
  }});
  
  const run = {
    context: { ...contextRead, update: (/** @param {object} key @param {unknown} value */ (key, value) => { callback(); contextScope.update(key, value); }), tryUpdate: (/** @param {object} key @param {unknown} value */ (key, value) => { callback(); return contextScope.tryUpdate(key, value); }) },
    feedback: { style },
    update: () => { callback(); update(); },
    props: {
      get: () => { alive(); return propsWindow?.resolved ?? resolved; },
      getRaw: () => { alive(); return propsWindow?.raw ?? raw; },
      isProvided: (/** @param {PropertyKey} key */ (key) => { alive(); return __pui_Own(propsWindow?.raw ?? raw, key); }),
    },
    lifecycle: { setPresent },
    expose: { emit: (/** @param {string} key @param {unknown} [payload] @param {unknown} [options] */ (key, payload, options) => {
      callback();
      if (!__pui_Own(eventDeclarations, key)) throw new Error('[Vue2 native] undeclared expose event: ' + key);
      const listener = vm.$attrs && (/** @type {Readonly<Record<string, unknown>>} */ (vm.$attrs))['on' + key[0].toUpperCase() + key.slice(1)];
      // Host sink failures do not re-enter authored callbacks, matching the Vue2 sink.
      try { if (typeof listener === 'function') listener(payload, options); } catch {}
      try { vm.$emit(key, payload, options); } catch {}
    }) },
  };
  /** @type {__pui_NativeInteraction<typeof run>} */
  const interaction = __pui_CreateNativeInteraction({
    ensureSetup: setupOnly,
    ensureRuntime: callback,
    ensureEvent: callback,
    isAlive: () => !terminal && !disposed,
    isSetupComplete: () => phase !== 'setup',
    isReady: () => phase !== 'setup' && viewActive && present && hostActive && !terminal,
    invoke: (fn) => invoke(fn),
    getRun: () => run,
    getResolvedProps: () => resolved,
    getAssociations: () => __pui_NormalizeAssociations(vm.instanceAssociations, (/** @type {{_base?: {observable?: (value: object) => object}}} */ (vm.$options))._base?.observable),

    subscribeState: (state, fn) => externalState(state).subscribe(fn),
    getRoot: () => viewActive && present && hostActive && activeEpoch === epoch ? activeRoot : null,
    identity: contextScope, getLogicalParent: () => vm["__pui_ParentScope"] || null,
    declarations: [], tableFamily: undefined,
    getExposes: () => exposed,
    registerExpose: (key, value) => {
      setupOnly(); if (__pui_Own(exposed, key)) throw new Error('[Expose] duplicate declaration: ' + key);
      if (value !== null && typeof value === 'object' && observedExternals.has(value)) exposed[key] = observedExternals.get(value);
      else if (typeof value === 'function') exposed[key] = (/** @param {unknown[]} args */ (...args) => { publicAlive(); return invoke(() => value(...args)); });
      else exposed[key] = value;
    },
    createOwnedState: (name, value, spec) => createState(spec?.kind ?? (typeof value === 'boolean' ? 'bool' : typeof value === 'number' ? 'number.discrete' : 'string'), name, value, spec),
    watchState: (state, fn) => { setupOnly(); return externalState(state).subscribe(event => invoke(() => fn(run, event))); },
    isPropProvided: key => __pui_Own(raw, key),
    setPresent, requestHostUpdate: force,
    emit: (key) => run.expose.emit(key),
    registerGenericObservedState: (handle) => {
      /** @type {Set<(event: __pui_StateEvent<ReturnType<typeof handle.get>>) => void>} */
      const subscribers = new Set();
      const off = handle.subscribe((event) => {
        style.refresh(); interaction.refresh();
        for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(notifications, notifications.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!notifying) {
  notifying = true;
  /** @type {unknown[]} */ const notificationFailures = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < notifications.length) {
      try { notifications[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { notifications.length = 0; notifying = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
      });
      /** @type {__pui_ExternalState<ReturnType<typeof handle.get>>} */
      const external = Object.freeze({
        get: () => { publicAlive(); return handle.get(); },
        subscribe: (fn) => { publicAlive(); /** @type {typeof fn} */ const registration = (/** @type {Parameters<typeof fn>[0]} */ event) => fn(event); subscribers.add(registration); return () => subscribers.delete(registration); },
        unsubscribe: (unsubscribe) => { publicAlive(); if (typeof unsubscribe === 'function') unsubscribe(); },
        spec: Object.freeze({ kind: typeof handle.get() === 'boolean' ? 'bool' : typeof handle.get() === 'number' ? 'number.discrete' : 'string', observed: true }),
      });
      observedExternals.set(handle, external);
      
      states.push({ dispose: () => {
        off();
        try { for (const fn of Array.from(subscribers)) fn({ type: 'disconnect', reason: 'unmount' }); }
        finally { subscribers.clear(); }
      } });
    },
  });
  /** @type {__pui_NativeRenderer} */
  const renderer = { 
    slot: () => /** @type {__pui_NativePaint} */ ((_h, nativeVm, slots) => {
      if (slots.used) throw new Error('[Vue2 native] only one default slot is supported.');
      slots.used = true;
      const scoped = nativeVm.$scopedSlots.default;
      return (scoped ? scoped({}) : nativeVm.$slots.default) || [];
    }),
    read: Object.freeze({ props: Object.freeze({ get: () => { alive(); return resolved; }, getRaw: () => { alive(); return raw; }, isProvided: (/** @param {PropertyKey} key */ (key) => { alive(); return __pui_Own(raw, key); }) }) , context: contextRead }) };
  /**
   * @template T
   * @param {T} initial
   * @param {Readonly<Record<string, unknown>>} spec
   * @param {(value: T, initialValue?: boolean) => T} check
   * @returns {__pui_OwnedState<T>}
   */
  const createStateCell = (initial, spec, check) => {
    let value = check(initial, true);
    /** @type {Set<(event: __pui_StateEvent<T>) => void>} */
    const subscribers = new Set();
    /** @type {__pui_OwnedState<T>} */
    const handle = {
      get: () => { alive(); return value; },
      setDefault: next => { setupOnly(); value = check(next, true); },
      set: (next, reason) => {
        callback();
        next = check(next);
        if (Object.is(value, next)) return;
        const previous = value; value = next;
        style.refresh(); interaction.refresh();
        /** @type {__pui_StateEvent<T>} */
        const event = { type: 'next', prev: previous, next, reason };
        for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(notifications, notifications.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!notifying) {
  notifying = true;
  /** @type {unknown[]} */ const notificationFailures = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < notifications.length) {
      try { notifications[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { notifications.length = 0; notifying = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
      },
      external: {
        get: () => { publicAlive(); return handle.get(); },
        subscribe: (fn) => { publicAlive(); /** @type {typeof fn} */ const registration = (/** @type {Parameters<typeof fn>[0]} */ event) => fn(event); subscribers.add(registration); return () => subscribers.delete(registration); },
        unsubscribe: (off) => { publicAlive(); if (typeof off === 'function') off(); },
        spec,
      },
      dispose: () => {
        try { for (const fn of Array.from(subscribers)) fn({ type: 'disconnect', reason: 'unmount' }); }
        finally { subscribers.clear(); }
      },
    };
    observedExternals.set(handle, handle.external);
    states.push(handle);
    
    return handle;
  };
  /** @template {boolean | string | number} T @param {__pui_StateKind} kind @param {string} key @param {T} initial @param {__pui_StateConfiguration} [configuration] @returns {__pui_OwnedState<T>} */
  const createState = (kind, key, initial, configuration = {}) => {
    setupOnly();
    const spec = Object.freeze({ ...configuration, kind });
    /** @param {T} value @param {boolean} [initialValue] @returns {T} */
    const check = (value, initialValue = false) => {
      const expected = kind === 'bool' ? 'boolean' : kind === 'string' || kind === 'enum' ? 'string' : 'number';
      if (typeof value !== expected || expected === 'number' && !Number.isFinite(value)) throw new TypeError('[Vue2 native] invalid state value: ' + key);
      if (spec.options && spec.options.length && !spec.options.includes(value)) throw new Error('[Vue2 native] state value not in options: ' + key);
      // Numeric-family schemas prove these numeric views. Other families keep
      // their structurally admitted extra fields and native relational coercion.
      if (kind === 'number.range' && initialValue && spec.clamp) value = /** @type {T} */ (Math.min(/** @type {number} */ (spec.max), Math.max(/** @type {number} */ (spec.min), /** @type {number} */ (value))));
      if (!(kind === 'number.discrete' && spec.options && spec.options.length) && (spec.min !== undefined && __pui_Before(value, spec.min) || spec.max !== undefined && __pui_Before(spec.max, value))) throw new Error('[Vue2 native] state value out of range: ' + key);
      if (kind === 'number.discrete' && !(spec.options && spec.options.length) && __pui_Before(0, spec.step) && !Number.isInteger((/** @type {number} */ (value) - /** @type {number} */ (spec.min ?? 0)) / /** @type {number} */ (spec.step))) throw new Error('[Vue2 native] state value violates step: ' + key);
      return value;
    };
    __pui_Authored.claimState(key);
    const handle = createStateCell(initial, spec, check);
    __pui_Authored.state(key, handle);
    return handle;
  };
  /** @param {Record<string, __pui_PropSpec>} input */
  const defineProps = (input) => {
    setupOnly();
    const next = { ...specs };
    const rank = { accept: 0, fallback: 1, error: 2 };
    for (const key of Object.keys(input)) {
      const spec = input[key];
      if (!spec || !['boolean', 'number', 'string', 'object', 'any', 'enum'].includes(spec.type)) throw new Error('[Vue2 native] invalid prop declaration: ' + key);
      if (spec.empty !== undefined && !__pui_Own(rank, spec.empty)) throw new Error('[Vue2 native] invalid empty behavior: ' + key);
      if (spec.type === 'enum' && (!Array.isArray(spec.options) || !spec.options.length || !spec.options.every((value) => typeof value === 'string'))) throw new Error('[Vue2 native] invalid enum options: ' + key);
      if (spec.type !== 'enum' && __pui_Own(spec, 'options')) throw new Error('[Vue2 native] only enum props accept options: ' + key);
      if (__pui_Own(spec, 'default') && !__pui_Json(spec.default)) throw new Error('[Vue2 native] non-JSON prop default: ' + key);
      const prior = next[key];
      if (prior) {
        if (prior.type !== spec.type || __pui_Own(spec, 'empty') && spec.empty !== undefined && rank[spec.empty] > rank[prior.empty ?? 'fallback']) throw new Error('[Vue2 native] conflicting prop declaration: ' + key);
        if (prior.options && !prior.options.every((value) => spec.options && spec.options.includes(value))) throw new Error('[Vue2 native] prop options cannot narrow: ' + key);
        if (prior.range && spec.range && ((spec.range.min ?? -Infinity) > (prior.range.min ?? -Infinity) || (spec.range.max ?? Infinity) < (prior.range.max ?? Infinity))) throw new Error('[Vue2 native] prop range cannot narrow: ' + key);
        next[key] = { ...prior, ...spec, empty: prior.empty ?? 'fallback', range: spec.range ?? prior.range };
        if (__pui_Own(prior, 'default')) next[key].default = prior.default;
      } else next[key] = { ...spec };
    }
    specs = next; resolved = resolveProps(raw, false).snapshot;
  };
  /** @param {__pui_PropsWatcher<typeof run>} watch */
  const registerPropsWatch = (watch) => {
    setupOnly();
    const { kind, keys } = watch;
    if (keys !== null && (!keys.length || keys.some((key) => typeof key !== 'string'
      || kind === 'resolved' && !__pui_Own(specs, key)))) throw new Error('[Vue2 native] watch requires non-empty valid prop keys.');
    watch.keys = keys === null ? null : [...keys];
    watchers.push(watch);
    return () => { watch.active = false; };
  };
  /** @type {readonly __pui_LifecycleKind[]} */
  const lifecycleKeys = ["created","mounted","updated","unmounted","beforeDispose"];
  const def = {
    context: { provide: (/** @param {object} key @param {unknown} value */ (key, value) => { setupOnly(); contextScope.provide(key, value); }), subscribe: (/** @param {object} key @param {(run: __pui_Run, next: unknown, previous: unknown) => void} [fn] */ (key, fn) => { setupOnly(); return contextScope.subscribe(key, 'required', fn ? (next, prev) => fn(run, next, prev) : undefined); }), trySubscribe: (/** @param {object} key @param {(run: __pui_Run, next: unknown, previous: unknown) => void} [fn] */ (key, fn) => { setupOnly(); return contextScope.subscribe(key, 'optional', fn ? (next, prev) => fn(run, next, prev) : undefined); }) },
    feedback: { style },
    event: interaction.event,
    props: {
      define: defineProps,
      setDefaults: (/** @param {__pui_RawProps} layer */ (layer) => {
        setupOnly();
        for (const key of Object.keys(layer)) if (!__pui_Own(specs, key) || !__pui_Json(layer[key])) throw new Error('[Vue2 native] invalid prop default: ' + key);
        defaults.unshift({ ...layer }); resolved = resolveProps(raw, false).snapshot;
      }),
      /** @param {readonly string[]} keys @param {__pui_PropsWatchCallback<typeof run, __pui_ResolvedProps>} fn */
      watch: (keys, fn) => registerPropsWatch({ kind: 'resolved', keys, fn, active: true }),
      /** @param {__pui_PropsWatchCallback<typeof run, __pui_ResolvedProps>} fn */
      watchAll: (fn) => registerPropsWatch({ kind: 'resolved-all', keys: null, fn, active: true }),
      /** @param {readonly string[]} keys @param {__pui_PropsWatchCallback<typeof run, __pui_RawProps>} fn */
      watchRaw: (keys, fn) => registerPropsWatch({ kind: 'raw', keys, fn, active: true }),
      /** @param {__pui_PropsWatchCallback<typeof run, __pui_RawProps>} fn */
      watchRawAll: (fn) => registerPropsWatch({ kind: 'raw-all', keys: null, fn, active: true }),
    },
    state: {
      /** @param {string} key @param {boolean} value */
      bool: (key, value) => createState('bool', key, value),
      /** @param {string} key @param {string} value @param {__pui_StateConfiguration} [spec] */
      string: (key, value, spec) => createState('string', key, value, spec),
      /** @param {string} key @param {string} value @param {__pui_StateConfiguration} [spec] */
      enum: (key, value, spec) => createState('enum', key, value, spec),
      /** @param {string} key @param {number} value @param {__pui_StateConfiguration} [spec] */
      numberDiscrete: (key, value, spec) => createState('number.discrete', key, value, spec),
      /** @param {string} key @param {number} value @param {__pui_StateConfiguration} spec */
      numberRange: (key, value, spec) => createState('number.range', key, value, spec),
    },
    expose: {
      /** @param {string} key @param {unknown} value */
      value: (key, value) => { setupOnly(); if (__pui_Own(exposed, key)) throw new Error('[Expose] duplicate declaration'); exposed[key] = value; },
      /** @template T @param {string} key @param {{get(): T}} handle */
      state: (key, handle) => { setupOnly(); exposed[key] = externalState(handle); __pui_Authored.introduceObserved(handle); },
      /** @template {unknown[]} Args @template Result @param {string} key @param {(...args: Args) => Result} fn @param {(value: Result) => Result} [project] */
      method: (key, fn, project) => { setupOnly();  exposed[key] = (/** @param {Args} args */ (...args) => { publicAlive(); const result = invoke(() => fn(...args)); return project ? project(result) : result; }); },
      /** @param {string} key @param {unknown} [spec] */
      event: (key, spec) => { setupOnly(); eventDeclarations[key] = spec; },
    },
    lifecycle: Object.fromEntries(lifecycleKeys.map((key) => {
      /** @type {[string, (fn: __pui_LifecycleCallback<typeof run>) => void]} */
      const entry = ['on' + key[0].toUpperCase() + key.slice(1), (fn) => { setupOnly(); lifecycle[key].push(fn); }];
      return entry;
    })),
  };
  /** @param {__pui_LifecycleKind} kind */
  const fire = (kind) => invoke(() => { if (kind === 'unmounted') {  } try { for (const fn of lifecycle[kind]) fn(run); } finally { if (kind === 'unmounted') {  } } }, !terminal);
  const detach = () => {
    if (!viewActive) return;
    viewActive = false; pending = null; queued = false;
    
    interaction.unmount();
    style.unmount();
    if (activeRoot) activeRoot.removeAttribute('data-pui-style');
    activeRoot = null;
    fire('unmounted');
  };
  const afterCommit = () => {
    if (terminal) return;
    syncHost(true);
    const commit = renderedCommit;
    if (!commit) return;
    renderedCommit = null;
    const target = vm.$el;
    // Removal has already committed when Vue calls updated. Do not postpone its
    // unmount notification into a tick which may belong to a replacement view.
    if (!commit.present && commit.vnode.elm === target) { detach(); return; }
    vm.$nextTick(() => {
      if (terminal || commit.epoch !== epoch || commit.version !== commitVersion || vm.$el !== target || commit.vnode.elm !== target) return;
      if (!present || !hostActive) return;
      const elementType = target.ownerDocument.defaultView?.HTMLElement;
      if (!elementType || !(target instanceof elementType)) throw new Error('[Vue2 native] interaction Root must be an HTML element.');
      
      const kind = commit.kind;
      if (kind === 'mount' && !viewActive) {
        viewActive = true;
        activeRoot = target;
        activeEpoch = epoch;
        
        interaction.mount();
        // The native editor now owns value and composition for this view lease.
        // Vue clears an old domProp when the next VNode omits it; retire the
        // initial transport property before any ordinary host repaint.
        if (commit.vnode.data?.domProps) delete commit.vnode.data.domProps.value;
        if (terminal || commit.epoch !== epoch || !present || !hostActive) return;
        style.mount();
        
        fire('mounted');
        
      } else if (viewActive) {
        
        if (activeRoot !== target || activeEpoch !== epoch) {
          activeRoot = target; activeEpoch = epoch;
          interaction.mount();
        }
        if (terminal || commit.epoch !== epoch || !present || !hostActive) return;
        if (kind !== 'update' || !pending || pending.revision !== commit.revision) return;
        pending = null;
        const again = queued; queued = false;
        fire('updated');
        if (again && present && viewActive && !terminal && !pending) update();
      }
    });
  };
  const owner = {
    
    authored: __pui_Authored,
    meta: __pui_Meta,
    contextScope,
    host() { return viewActive && present && hostActive && !terminal ? vm.$el : null; },
    interaction,
    def,
    get resolvedProps() { return resolved; },
    
    initialize() {
      
      try {
        renderFunction = setup(owner);
        if (typeof renderFunction !== 'function') renderFunction = (renderer) => renderer.slot();
        phase = 'idle';
        syncHost(false);
        fire('created');
         unwatch = vm.$watch(() => ({ props: hostRaw(), associations: __pui_NormalizeAssociations(vm.instanceAssociations, (/** @type {{_base?: {observable?: (value: object) => object}}} */ (vm.$options))._base?.observable) }), () => syncHost(true), { deep: true });
      } catch (error) {
        
        terminal = true;
        try { interaction.dispose(); } catch {}
        for (const state of states) { try { state.dispose(); } catch {} }
        try { style.dispose(); } catch {}
        try { contextScope.dispose(); } catch {}
        disposed = true;
        phase = 'idle';
        throw error;
      }
    },
    hostMounted() {  nativeMounted = true; afterCommit(); },
    afterCommit,
    /** @param {import('vue').CreateElement} h */
    render(h) {
      
      if (terminal || !present || !hostActive) {
        const vnode = h();
        renderedCommit = { epoch, version: ++commitVersion, present: false, vnode, kind: 'detach' };
        return vnode;
      }
      if (!viewActive) renderSemantic();
      const tag = interaction.rootTag() || rootTag;
      const children = template ? template(h, vm, { used: false }) : [];
      if (['input', 'textarea', 'img'].includes(tag) && children.length) throw new Error('[Template] physical control Root requires empty children.');
      const vnode = h(tag, __pui_RootData(interaction.rootProperties(), { 'data-pui-root': '' }, !viewActive), children);
      renderedCommit = { epoch, version: ++commitVersion, present: true, vnode, kind: !viewActive ? 'mount' : pending ? 'update' : 'none', revision: pending && pending.revision };
      return vnode;
    },
    update,
    getExposes() { if (terminal) return {}; return { ...exposed }; },
    /** @template T @param {() => T} fn @returns {T} */
    invokePublic(fn) { publicAlive(); return invoke(fn); },
    deactivate() {
      if (terminal || !hostActive) return;
      hostActive = false; ++epoch; renderedCommit = null; pending = null; queued = false;
      detach();
    },
    activate() {
      if (terminal || hostActive) return;
      hostActive = true; ++epoch; pending = null; renderedCommit = null;
      vm.$forceUpdate();
    },
    dispose() {
      if (terminal) return;
      terminal = true; ++epoch; renderedCommit = null; pending = null; queued = false;
      for (const off of __pui_AuthoredWatchCleanups.splice(0)) off();
      unwatch?.(); unwatch = undefined;
      /** @type {{ error: unknown } | undefined} */ let failure;
      try { detach(); } catch (error) { failure = { error }; }
       try {
        fire('beforeDispose');
      } catch (error) { failure ??= { error }; }
      for (const state of states) {
        try { state.dispose(); } catch (error) { failure ??= { error }; }
      }
      try { contextScope.dispose(); } catch (error) { failure ??= { error }; }
      try { interaction.dispose(); } catch (error) { failure ??= { error }; }
      try { style.dispose(); } catch (error) { failure ??= { error }; }
      const target = vm.$el;
      if (target && target.nodeType === 1 && target.hasAttribute('data-pui-root')) target.removeAttribute('data-pui-style');
      __pui_Authored.dispose();
      disposed = true; phase = 'idle';
      watchers.length = 0; notifications.length = 0; states.length = 0; defaults.length = 0;
      for (const callbacks of Object.values(lifecycle)) callbacks.length = 0;
      for (const key of Object.keys(exposed)) delete exposed[key];
      for (const key of Object.keys(eventDeclarations)) delete eventDeclarations[key];
      specs = Object.create(null); previousValid = Object.create(null); raw = Object.freeze({}); resolved = /** @type {__pui_ResolvedProps} */ (Object.freeze({})); template = renderFunction = null;
      
      if (failure) throw failure.error;
    },
  };
  return owner;
}


/** @param {__pui_Owner} __pui_Owner */
function __pui_Setup(__pui_Owner) {

  const __pui_Authored = __pui_Owner.authored;
  const __pui_Meta = __pui_Owner.meta;
  // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":26:1
  const __puiModule1 = /** @param {__pui_Owner['def']} def @param {"vega" | "nova" | "maia" | "lyra" | "mira" | "luma" | "sera" | "rhea" | "new-york-v4"} compatibilityStyle @param {{ "supportedStyles"?: ReadonlyArray<"vega" | "nova" | "maia" | "lyra" | "mira" | "luma" | "sera" | "rhea" | "new-york-v4"> }} options @returns {__pui_OwnedState<string>} */ (def, compatibilityStyle, options = {  }) => {
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":34:3
    __puiModule2(def);
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":35:9
    const selected = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "shadcnStyleSelection";
const __pui_CaptureArg1 = compatibilityStyle;
/** @type {{ "options": ReadonlyArray<"vega" | "nova" | "maia" | "lyra" | "mira" | "luma" | "sera" | "rhea" | "new-york-v4"> }} */ const __pui_CaptureArg2 = { ["options"]: __puiModule0 };
const __pui_CaptureResult = __pui_CaptureReceiver.state.enum(__pui_CaptureArg0, __pui_CaptureArg1, __pui_CaptureArg2); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":38:9
    const sync = /** @param {__pui_Run} run @returns {void} */ (run) => {
      // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":39:11
      const explicit = __puiModule3((run.props.getRaw())["styleProfile"]);
      // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":40:11
      const inherited = ((run.context.tryRead(__pui_ContextKey0))?.["style"] ?? null);
      // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":41:11
      const next = ((explicit ?? inherited) ?? compatibilityStyle);
      // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":42:5
      if (((options)["supportedStyles"] && (!(/** @type {readonly unknown[]} */ ((/** @type {{ "supportedStyles": ReadonlyArray<"vega" | "nova" | "maia" | "lyra" | "mira" | "luma" | "sera" | "rhea" | "new-york-v4"> }} */ (options))["supportedStyles"])).includes(next)))) {
        // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":43:7
        throw new Error(("[shadcn-style-scope] Unsupported style for this consumer: " + next));
      }
      // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":45:5
      selected.set(next, "reason: shadcn style selection");
    };
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":47:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = __pui_ContextKey0;
const __pui_CaptureArg1 = sync;
const __pui_CaptureResult = __pui_CaptureReceiver.context.trySubscribe(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "trySubscribe", "key": __pui_CaptureArg0, "off": __pui_CaptureResult}); __pui_Authored.disposer("context", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":48:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = ["styleProfile"];
const __pui_CaptureArg1 = sync;
const __pui_CaptureResult = __pui_CaptureReceiver.props.watchRaw(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("props", {"op": "watchRaw", "keys": __pui_CaptureArg0, "off": __pui_CaptureResult}); __pui_Authored.disposer("props", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":49:3
    def.lifecycle.onCreated(sync);
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":50:3
    def.lifecycle.onMounted(sync);
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":53:3
    def.lifecycle.onUpdated(sync);
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":54:3
    return selected;
  };
  // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":10:1
  const __puiModule2 = /** @param {__pui_Owner['def']} def @returns {void} */ (def) => {
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":13:9
    const cdef = def;
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":14:3
    (() => {
const __pui_CaptureReceiver = cdef;
/** @type {Parameters<typeof __pui_CaptureReceiver.props.define>[0]} */ const __pui_CaptureArg0 = { ["styleProfile"]: { ["type"]: "enum", ["options"]: ["vega", "nova", "maia", "lyra", "mira", "luma", "sera", "rhea", "new-york-v4", "new-york", "inherit"], ["empty"]: "fallback" } };
const __pui_CaptureResult = __pui_CaptureReceiver.props.define(__pui_CaptureArg0); __pui_Authored.effect("props", {"op": "define", "specMap": __pui_CaptureArg0}); return __pui_CaptureResult; })();
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":22:3
    (() => {
const __pui_CaptureReceiver = cdef;
/** @type {{ "styleProfile": string }} */ const __pui_CaptureArg0 = { ["styleProfile"]: "inherit" };
const __pui_CaptureResult = __pui_CaptureReceiver.props.setDefaults(__pui_CaptureArg0); __pui_Authored.effect("props", {"op": "setDefaults", "partial": __pui_CaptureArg0}); return __pui_CaptureResult; })();
  };
  const __pui_Hook0 = /** @param {unknown} [options] */ (options) => /** @type {{ readonly stateHandles?: Readonly<Record<string, unknown>>; readonly getState?: (name: string) => unknown; readonly getMethod?: (name: string) => unknown; readonly getAsHook?: (name: string) => unknown; readonly getAsHookHandle?: (name: string) => unknown; readonly render?: unknown }} */ (__pui_Authored.install({name: "as-button", mode: "once", setup: (options, api) => (/** @param {__pui_Owner['def']} def */ (def) => {
    // Source "packages/prototypes/base/src/button/button.proto.ts":12:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = {"kind":"tw","tokens":["select-none"],"groups":["content-selection affordance"]};
const __pui_CaptureResult = __pui_CaptureReceiver.feedback.style.use(__pui_CaptureArg0); __pui_Authored.effect("feedback", __pui_CaptureResult); __pui_Authored.disposer("feedback", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":13:9
    const accessible = __pui_Authored.privileged("asAccessible", () => __pui_Owner.interaction.asAccessible());
    // Source "packages/prototypes/base/src/button/button.proto.ts":15:3
    __pui_Authored.privileged("asTrigger", () => __pui_Owner.interaction.asTrigger());
    // Source "packages/prototypes/base/src/button/button.proto.ts":18:3
    (() => {
const __pui_CaptureReceiver = def;
/** @type {Parameters<typeof __pui_CaptureReceiver.props.define>[0]} */ const __pui_CaptureArg0 = { ["disabled"]: { ["type"]: "boolean", ["empty"]: "fallback" } };
const __pui_CaptureResult = __pui_CaptureReceiver.props.define(__pui_CaptureArg0); __pui_Authored.effect("props", {"op": "define", "specMap": __pui_CaptureArg0}); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":21:3
    (() => {
const __pui_CaptureReceiver = def;
/** @type {{ "disabled": boolean }} */ const __pui_CaptureArg0 = { ["disabled"]: false };
const __pui_CaptureResult = __pui_CaptureReceiver.props.setDefaults(__pui_CaptureArg0); __pui_Authored.effect("props", {"op": "setDefaults", "partial": __pui_CaptureArg0}); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":26:9
    const disabled = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "disabled";
const __pui_CaptureArg1 = false;
const __pui_CaptureResult = __pui_CaptureReceiver.state.bool(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":27:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "disabled";
const __pui_CaptureArg1 = disabled;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.state(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", {"op": "expose.state", "key": __pui_CaptureArg0, "handle": __pui_CaptureArg1}); __pui_Authored.introduceObserved(__pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":28:3
    (() => {
const __pui_CaptureReceiver = accessible;
const __pui_CaptureArg0 = "disabled";
const __pui_CaptureArg1 = disabled;
const __pui_CaptureResult = __pui_CaptureReceiver.state(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", {"op": "a11y.state", "key": __pui_CaptureArg0, "handle": __pui_CaptureArg1, "options": undefined}); __pui_Authored.introduceObserved(__pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":31:9
    const hovered = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "hovered";
const __pui_CaptureArg1 = false;
const __pui_CaptureResult = __pui_CaptureReceiver.state.bool(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":32:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "hovered";
const __pui_CaptureArg1 = hovered;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.state(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", {"op": "expose.state", "key": __pui_CaptureArg0, "handle": __pui_CaptureArg1}); __pui_Authored.introduceObserved(__pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":35:9
    const focusable = __pui_Authored.privileged("asFocusable", () => __pui_Owner.interaction.asFocusable(), ["focused","focusVisible","focusable"]);
    // Source "packages/prototypes/base/src/button/button.proto.ts":36:3
    focusable.configure({ ["disabled"]: false });
    // Source "packages/prototypes/base/src/button/button.proto.ts":38:9
    const focused = (focusable)["focused"];
    // Source "packages/prototypes/base/src/button/button.proto.ts":39:9
    const focusVisible = (focusable)["focusVisible"];
    // Source "packages/prototypes/base/src/button/button.proto.ts":42:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "focused";
const __pui_CaptureArg1 = focused;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.state(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", {"op": "expose.state", "key": __pui_CaptureArg0, "handle": __pui_CaptureArg1}); __pui_Authored.introduceObserved(__pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":43:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "focusVisible";
const __pui_CaptureArg1 = focusVisible;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.state(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", {"op": "expose.state", "key": __pui_CaptureArg0, "handle": __pui_CaptureArg1}); __pui_Authored.introduceObserved(__pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":46:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "focusSelf";
const __pui_CaptureArg1 = /** @param {{ "reason"?: "programmatic" | "keyboard" | "pointer"; "preventScroll"?: boolean }} [options] @returns {void} */ (options) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":47:5
      if (/** @type {boolean} */ (disabled.get())) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":47:25
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":48:5
      focusable.focusSelf(options);
    };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":52:9
    const pressed = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "pressed";
const __pui_CaptureArg1 = false;
const __pui_CaptureResult = __pui_CaptureReceiver.state.bool(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":53:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "pressed";
const __pui_CaptureArg1 = pressed;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.state(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", {"op": "expose.state", "key": __pui_CaptureArg0, "handle": __pui_CaptureArg1}); __pui_Authored.introduceObserved(__pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":55:9
    const clearTransientInteraction = /** @param {string} reason @returns {void} */ (reason) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":56:5
      hovered.set(false, reason);
      // Source "packages/prototypes/base/src/button/button.proto.ts":57:5
      pressed.set(false, reason);
    };
    // Source "packages/prototypes/base/src/button/button.proto.ts":61:3
    def.lifecycle.onUnmounted(() => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":62:5
      (clearTransientInteraction)("reason: button view unmounted => reset transient interaction");
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":66:9
    const syncDisabled = /** @param {boolean} nextDisabled @returns {void} */ (nextDisabled) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":67:5
      disabled.set(nextDisabled, "reason: sync disabled");
      // Source "packages/prototypes/base/src/button/button.proto.ts":68:5
      focusable.setDisabled(nextDisabled);
      // Source "packages/prototypes/base/src/button/button.proto.ts":69:5
      if (nextDisabled) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":70:7
        (clearTransientInteraction)("reason: button disabled => reset transient interaction");
      }
    };
    // Source "packages/prototypes/base/src/button/button.proto.ts":73:3
    def.lifecycle.onCreated(/** @param {__pui_Run} run */ (run) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":74:5
      (syncDisabled)((run.props.get())["disabled"]);
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":76:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = ["disabled"];
const __pui_CaptureArg1 = /** @param {__pui_Run} _run @param {__pui_ResolvedProps} next */ (_run, next) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":77:5
      (syncDisabled)((next)["disabled"]);
    };
const __pui_CaptureResult = __pui_CaptureReceiver.props.watch(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("props", {"op": "watch", "keys": __pui_CaptureArg0, "off": __pui_CaptureResult}); __pui_Authored.disposer("props", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":81:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "click";
/** @type {{ "payload": string }} */ const __pui_CaptureArg1 = { ["payload"]: "void" };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.event(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("event", {"op": "expose.event", "key": __pui_CaptureArg0, "spec": __pui_CaptureArg1}); __pui_Authored.eventKey(__pui_CaptureArg0); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":83:3
    accessible.action("activate", { ["event"]: "click" });
    // Source "packages/prototypes/base/src/button/button.proto.ts":86:3
    accessible.role("button");
    // Source "packages/prototypes/base/src/button/button.proto.ts":89:3
    accessible.nameFromContent();
    // Source "packages/prototypes/base/src/button/button.proto.ts":91:9
    const activate = /** @param {__pui_Run} run @param {() => boolean} isCurrent @returns {void} */ (run, isCurrent = /**  @returns {boolean} */ () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":91:83
      return true;
    }) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":92:5
      if ((/** @type {boolean} */ (disabled.get()) || (!(isCurrent)()))) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":92:41
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":93:5
      pressed.set(false, "reason: button activation => pressed");
      // Source "packages/prototypes/base/src/button/button.proto.ts":94:5
      if ((/** @type {boolean} */ (disabled.get()) || (!(isCurrent)()))) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":94:41
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":95:5
      run.expose.emit("click");
    };
    // Source "packages/prototypes/base/src/button/button.proto.ts":97:3
    __pui_Authored.privileged("asControlLabel", () => __pui_Owner.interaction.asControlLabel()).target(/** @param {__pui_Run} run @param {import("./.proto-ui/interaction/modules-e6807d4f71af1465-v2").NativeModuleCapability<"control-label-request", __pui_Run>} request */ (run, request) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":98:11
      const isCurrent = /**  @returns {boolean} */ () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":98:29
        return ((!/** @type {boolean} */ (disabled.get())) && request.isCurrent());
      };
      // Source "packages/prototypes/base/src/button/button.proto.ts":99:5
      if ((!(isCurrent)())) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":99:23
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":100:5
      focusable.focusSelf({ ["reason"]: (((request)["source"] === "pointer") ? "pointer" : "programmatic") });
      // Source "packages/prototypes/base/src/button/button.proto.ts":101:5
      if ((isCurrent)()) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":101:22
        (activate)(run, isCurrent);
      }
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":107:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "key.down";
const __pui_CaptureArg1 = /** @param {__pui_Run} _run @param {__pui_NativeInput} ev */ (_run, ev) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":108:11
      const detail = ev;
      // Source "packages/prototypes/base/src/button/button.proto.ts":109:5
      if (/** @type {boolean} */ (disabled.get())) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":109:25
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":110:5
      if ((!/** @type {boolean} */ (focused.get()))) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":110:25
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":111:5
      if (((detail)?.["key"] !== " ")) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":111:30
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":112:5
      ev.control.requestDefaultActionPrevention({ ["reason"]: "button.space-activation", ["source"]: "base-button" });
    };
const __pui_CaptureResult = __pui_CaptureReceiver.event.onGlobal(__pui_CaptureArg0, __pui_CaptureArg1); const __pui_CaptureOff = () => __pui_Owner.interaction.releaseListener(__pui_CaptureResult); __pui_Authored.effect("event", {token: __pui_CaptureResult, off: __pui_CaptureOff}); __pui_Authored.disposer("event", __pui_CaptureOff); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":119:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "pointer.enter";
const __pui_CaptureArg1 = () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":120:5
      if (/** @type {boolean} */ (disabled.get())) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":120:25
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":121:5
      hovered.set(true, "reason: button pointer.enter => hovered");
    };
const __pui_CaptureResult = __pui_CaptureReceiver.event.on(__pui_CaptureArg0, __pui_CaptureArg1); const __pui_CaptureOff = () => __pui_Owner.interaction.releaseListener(__pui_CaptureResult); __pui_Authored.effect("event", {token: __pui_CaptureResult, off: __pui_CaptureOff}); __pui_Authored.disposer("event", __pui_CaptureOff); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":123:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "pointer.leave";
const __pui_CaptureArg1 = () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":124:5
      hovered.set(false, "reason: button pointer.leave => hovered");
      // Source "packages/prototypes/base/src/button/button.proto.ts":125:5
      pressed.set(false, "reason: button pointer.leave => pressed");
    };
const __pui_CaptureResult = __pui_CaptureReceiver.event.on(__pui_CaptureArg0, __pui_CaptureArg1); const __pui_CaptureOff = () => __pui_Owner.interaction.releaseListener(__pui_CaptureResult); __pui_Authored.effect("event", {token: __pui_CaptureResult, off: __pui_CaptureOff}); __pui_Authored.disposer("event", __pui_CaptureOff); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":127:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "pointer.cancel";
const __pui_CaptureArg1 = () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":128:5
      hovered.set(false, "reason: button pointer.cancel => hovered");
      // Source "packages/prototypes/base/src/button/button.proto.ts":129:5
      pressed.set(false, "reason: button pointer.cancel => pressed");
    };
const __pui_CaptureResult = __pui_CaptureReceiver.event.on(__pui_CaptureArg0, __pui_CaptureArg1); const __pui_CaptureOff = () => __pui_Owner.interaction.releaseListener(__pui_CaptureResult); __pui_Authored.effect("event", {token: __pui_CaptureResult, off: __pui_CaptureOff}); __pui_Authored.disposer("event", __pui_CaptureOff); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":132:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "press.cancel";
const __pui_CaptureArg1 = () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":133:5
      (clearTransientInteraction)("reason: button press.cancel => reset transient interaction");
    };
const __pui_CaptureResult = __pui_CaptureReceiver.event.on(__pui_CaptureArg0, __pui_CaptureArg1); const __pui_CaptureOff = () => __pui_Owner.interaction.releaseListener(__pui_CaptureResult); __pui_Authored.effect("event", {token: __pui_CaptureResult, off: __pui_CaptureOff}); __pui_Authored.disposer("event", __pui_CaptureOff); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":137:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "pointer.down";
const __pui_CaptureArg1 = () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":138:5
      if (/** @type {boolean} */ (disabled.get())) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":138:25
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":139:5
      pressed.set(true, "reason: button pointer.down => pressed");
    };
const __pui_CaptureResult = __pui_CaptureReceiver.event.on(__pui_CaptureArg0, __pui_CaptureArg1); const __pui_CaptureOff = () => __pui_Owner.interaction.releaseListener(__pui_CaptureResult); __pui_Authored.effect("event", {token: __pui_CaptureResult, off: __pui_CaptureOff}); __pui_Authored.disposer("event", __pui_CaptureOff); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":141:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "pointer.up";
const __pui_CaptureArg1 = () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":142:5
      pressed.set(false, "reason: button pointer.up => pressed");
    };
const __pui_CaptureResult = __pui_CaptureReceiver.event.on(__pui_CaptureArg0, __pui_CaptureArg1); const __pui_CaptureOff = () => __pui_Owner.interaction.releaseListener(__pui_CaptureResult); __pui_Authored.effect("event", {token: __pui_CaptureResult, off: __pui_CaptureOff}); __pui_Authored.disposer("event", __pui_CaptureOff); return __pui_CaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":146:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "press.commit";
const __pui_CaptureArg1 = /** @param {__pui_Run} run */ (run) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":147:5
      pressed.set(false, "reason: button press.commit => pressed");
      // Source "packages/prototypes/base/src/button/button.proto.ts":148:5
      (activate)(run);
    };
const __pui_CaptureResult = __pui_CaptureReceiver.event.on(__pui_CaptureArg0, __pui_CaptureArg1); const __pui_CaptureOff = () => __pui_Owner.interaction.releaseListener(__pui_CaptureResult); __pui_Authored.effect("event", {token: __pui_CaptureResult, off: __pui_CaptureOff}); __pui_Authored.disposer("event", __pui_CaptureOff); return __pui_CaptureResult; })();
  })(__pui_Owner.def)}, options));
  (/** @param {__pui_Owner['def']} def */ (def) => {
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":38:5
    (() => {
const __pui_CaptureReceiver = def;
/** @type {Parameters<typeof __pui_CaptureReceiver.props.define>[0]} */ const __pui_CaptureArg0 = { ["variant"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["default", "destructive", "outline", "secondary", "ghost", "link"] }, ["size"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["default", "sm", "lg", "icon", "icon-compact"] }, ["disabled"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["wrap"]: { ["type"]: "boolean", ["empty"]: "fallback" } };
const __pui_CaptureResult = __pui_CaptureReceiver.props.define(__pui_CaptureArg0); __pui_Authored.effect("props", {"op": "define", "specMap": __pui_CaptureArg0}); return __pui_CaptureResult; })();
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":52:5
    (() => {
const __pui_CaptureReceiver = def;
/** @type {{ "variant": string; "size": string; "disabled": boolean; "wrap": boolean }} */ const __pui_CaptureArg0 = { ["variant"]: "default", ["size"]: "default", ["disabled"]: false, ["wrap"]: false };
const __pui_CaptureResult = __pui_CaptureReceiver.props.setDefaults(__pui_CaptureArg0); __pui_Authored.effect("props", {"op": "setDefaults", "partial": __pui_CaptureArg0}); return __pui_CaptureResult; })();
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":55:11
    const buttonState = /** @type {{ readonly "disabled": __pui_OwnedState<boolean> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void}; readonly "hovered": __pui_OwnedState<boolean> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void}; readonly "focused": __pui_NativeObservedState<boolean>; readonly "focusVisible": __pui_NativeObservedState<boolean>; readonly "pressed": __pui_OwnedState<boolean> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void} }} */ ((__pui_Hook0())["stateHandles"]);
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":56:5
    if ((!buttonState)) {
      // Source "packages/prototypes/shadcn/src/button/button.proto.ts":57:7
      throw new Error("[shadcn-button] asButton must project Button state handles.");
    }
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":59:13
    const disabled = (buttonState)["disabled"];
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":59:23
    const hovered = (buttonState)["hovered"];
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":59:32
    const focusVisible = (buttonState)["focusVisible"];
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":59:46
    const pressed = (buttonState)["pressed"];
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":61:11
    const style = __puiModule1(def, "rhea", { ["supportedStyles"]: __puiModule0 });
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":63:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => !((style.get() === "new-york-v4")), [{"kind":"tw","tokens":["inline-flex","box-border","shrink-0","items-center","justify-center","border","border-transparent","bg-clip-padding","py-0","transition-all","outline-none"],"groups":["display","box sizing","shrink-0","items-","justify-","border-width","border-color","bg-clip-","py-","transition-","outline-none"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":70:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (!((style.get() === "new-york-v4")) && (__pui_Owner.resolvedProps["variant"] === "default")), [{"kind":"tw","tokens":["bg-primary","text-primary-foreground"],"groups":["bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":70:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (!((style.get() === "new-york-v4")) && (__pui_Owner.resolvedProps["variant"] === "destructive")), [{"kind":"tw","tokens":["border-transparent","bg-destructive/10","text-destructive"],"groups":["border-color","bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":70:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (!((style.get() === "new-york-v4")) && (__pui_Owner.resolvedProps["variant"] === "secondary")), [{"kind":"tw","tokens":["border-transparent","bg-secondary","text-secondary-foreground"],"groups":["border-color","bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":70:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (!((style.get() === "new-york-v4")) && (__pui_Owner.resolvedProps["variant"] === "ghost")), [{"kind":"tw","tokens":["border-transparent","bg-transparent","text-foreground"],"groups":["border-color","bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":70:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (!((style.get() === "new-york-v4")) && (__pui_Owner.resolvedProps["variant"] === "link")), [{"kind":"tw","tokens":["border-transparent","bg-transparent","text-primary","underline-offset-4"],"groups":["border-color","bg-","text-color","underline-offset-4"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":76:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (style.get() === "vega"), [{"kind":"tw","tokens":["text-sm","leading-5","font-medium"],"groups":["text-size","leading-5","font weight"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":80:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "vega") && !((__pui_Owner.resolvedProps["size"] === "icon-compact"))), [{"kind":"tw","tokens":["rounded-md"],"groups":["rounded"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":84:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "vega") && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["border-border","bg-background","text-foreground","shadow-xs"],"groups":["border-color","bg-","text-color","shadow-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "vega") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-9","gap-1.5","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "vega") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-9","h-auto","gap-1.5","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "vega") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-8","gap-1","rounded-[min(var(--radius-md),10px)]","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1","rounded","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "vega") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-8","h-auto","gap-1","rounded-[min(var(--radius-md),10px)]","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","rounded","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "vega") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-10","gap-1.5","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "vega") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-10","h-auto","gap-1.5","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "vega") && (__pui_Owner.resolvedProps["size"] === "icon")), [{"kind":"tw","tokens":["size-9","whitespace-nowrap"],"groups":["size-9","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "vega") && (__pui_Owner.resolvedProps["size"] === "icon-compact")), [{"kind":"tw","tokens":["size-7","gap-2","rounded-md","whitespace-nowrap"],"groups":["size-7","gap-2","rounded","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":107:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "vega") && (focusVisible.get() === true)), [{"kind":"tw","tokens":["border-ring","ring-3","ring-ring/50"],"groups":["border-color","ring-3","ring-ring/50"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":111:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "vega") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-muted","text-foreground"],"groups":["bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":76:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (style.get() === "nova"), [{"kind":"tw","tokens":["text-sm","leading-5","font-medium"],"groups":["text-size","leading-5","font weight"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":80:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "nova") && !((__pui_Owner.resolvedProps["size"] === "icon-compact"))), [{"kind":"tw","tokens":["rounded-lg"],"groups":["rounded"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":84:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "nova") && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["border-border","bg-background","text-foreground"],"groups":["border-color","bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "nova") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-8","gap-1.5","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "nova") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-8","h-auto","gap-1.5","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "nova") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-7","gap-1","rounded-[min(var(--radius-md),12px)]","px-2.5","text-[0.8rem]","whitespace-nowrap"],"groups":["h-","gap-1","rounded","px-","text-size","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "nova") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-7","h-auto","gap-1","rounded-[min(var(--radius-md),12px)]","px-2.5","py-1","text-[0.8rem]","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","rounded","px-","py-","text-size","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "nova") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-9","gap-1.5","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "nova") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-9","h-auto","gap-1.5","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "nova") && (__pui_Owner.resolvedProps["size"] === "icon")), [{"kind":"tw","tokens":["size-8","whitespace-nowrap"],"groups":["size-8","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "nova") && (__pui_Owner.resolvedProps["size"] === "icon-compact")), [{"kind":"tw","tokens":["size-7","gap-2","rounded-md","whitespace-nowrap"],"groups":["size-7","gap-2","rounded","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":107:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "nova") && (focusVisible.get() === true)), [{"kind":"tw","tokens":["border-ring","ring-3","ring-ring/50"],"groups":["border-color","ring-3","ring-ring/50"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":111:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "nova") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-muted","text-foreground"],"groups":["bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":76:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (style.get() === "maia"), [{"kind":"tw","tokens":["text-sm","leading-5","font-medium"],"groups":["text-size","leading-5","font weight"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":80:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "maia") && !((__pui_Owner.resolvedProps["size"] === "icon-compact"))), [{"kind":"tw","tokens":["rounded-[var(--pui-radius-4xl)]"],"groups":["rounded"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":84:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "maia") && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["border-border","bg-input/30","text-foreground"],"groups":["border-color","bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "maia") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-9","gap-1.5","px-3","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "maia") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-9","h-auto","gap-1.5","px-3","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "maia") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-8","gap-1","px-3","whitespace-nowrap"],"groups":["h-","gap-1","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "maia") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-8","h-auto","gap-1","px-3","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "maia") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-10","gap-1.5","px-4","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "maia") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-10","h-auto","gap-1.5","px-4","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "maia") && (__pui_Owner.resolvedProps["size"] === "icon")), [{"kind":"tw","tokens":["size-9","whitespace-nowrap"],"groups":["size-9","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "maia") && (__pui_Owner.resolvedProps["size"] === "icon-compact")), [{"kind":"tw","tokens":["size-7","gap-2","rounded-md","whitespace-nowrap"],"groups":["size-7","gap-2","rounded","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":107:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "maia") && (focusVisible.get() === true)), [{"kind":"tw","tokens":["border-ring","ring-3","ring-ring/50"],"groups":["border-color","ring-3","ring-ring/50"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":111:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "maia") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-input/50","text-foreground"],"groups":["bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":76:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (style.get() === "lyra"), [{"kind":"tw","tokens":["text-xs","font-medium"],"groups":["text-size","font weight"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":80:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "lyra") && !((__pui_Owner.resolvedProps["size"] === "icon-compact"))), [{"kind":"tw","tokens":["rounded-none"],"groups":["rounded"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":84:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "lyra") && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["border-border","bg-background","text-foreground"],"groups":["border-color","bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "lyra") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-8","gap-1.5","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "lyra") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-8","h-auto","gap-1.5","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "lyra") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-7","gap-1","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "lyra") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-7","h-auto","gap-1","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "lyra") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-9","gap-1.5","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "lyra") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-9","h-auto","gap-1.5","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "lyra") && (__pui_Owner.resolvedProps["size"] === "icon")), [{"kind":"tw","tokens":["size-8","whitespace-nowrap"],"groups":["size-8","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "lyra") && (__pui_Owner.resolvedProps["size"] === "icon-compact")), [{"kind":"tw","tokens":["size-7","gap-2","rounded-md","whitespace-nowrap"],"groups":["size-7","gap-2","rounded","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":107:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "lyra") && (focusVisible.get() === true)), [{"kind":"tw","tokens":["border-ring","ring-1","ring-ring/50"],"groups":["border-color","ring-1","ring-ring/50"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":111:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "lyra") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-muted","text-foreground"],"groups":["bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":76:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (style.get() === "mira"), [{"kind":"tw","tokens":["text-xs","leading-relaxed","font-medium"],"groups":["text-size","leading-relaxed","font weight"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":80:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "mira") && !((__pui_Owner.resolvedProps["size"] === "icon-compact"))), [{"kind":"tw","tokens":["rounded-md"],"groups":["rounded"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":84:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "mira") && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["border-border","bg-transparent","text-foreground"],"groups":["border-color","bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "mira") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-7","gap-1","px-2","whitespace-nowrap"],"groups":["h-","gap-1","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "mira") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-7","h-auto","gap-1","px-2","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "mira") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-6","gap-1","px-2","whitespace-nowrap"],"groups":["h-","gap-1","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "mira") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-6","h-auto","gap-1","px-2","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "mira") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-8","gap-1","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "mira") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-8","h-auto","gap-1","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "mira") && (__pui_Owner.resolvedProps["size"] === "icon")), [{"kind":"tw","tokens":["size-7","whitespace-nowrap"],"groups":["size-7","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "mira") && (__pui_Owner.resolvedProps["size"] === "icon-compact")), [{"kind":"tw","tokens":["size-7","gap-2","rounded-md","whitespace-nowrap"],"groups":["size-7","gap-2","rounded","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":107:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "mira") && (focusVisible.get() === true)), [{"kind":"tw","tokens":["border-ring","ring-2","ring-ring/30"],"groups":["border-color","ring-2","ring-ring/30"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":111:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "mira") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-input/50","text-foreground"],"groups":["bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":76:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (style.get() === "luma"), [{"kind":"tw","tokens":["text-sm","leading-5","font-medium"],"groups":["text-size","leading-5","font weight"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":80:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "luma") && !((__pui_Owner.resolvedProps["size"] === "icon-compact"))), [{"kind":"tw","tokens":["rounded-[var(--pui-radius-4xl)]"],"groups":["rounded"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":84:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "luma") && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["border-border","bg-background","text-foreground"],"groups":["border-color","bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "luma") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-9","gap-1.5","px-3","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "luma") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-9","h-auto","gap-1.5","px-3","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "luma") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-8","gap-1","px-3","whitespace-nowrap"],"groups":["h-","gap-1","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "luma") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-8","h-auto","gap-1","px-3","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "luma") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-10","gap-1.5","px-4","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "luma") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-10","h-auto","gap-1.5","px-4","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "luma") && (__pui_Owner.resolvedProps["size"] === "icon")), [{"kind":"tw","tokens":["size-9","whitespace-nowrap"],"groups":["size-9","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "luma") && (__pui_Owner.resolvedProps["size"] === "icon-compact")), [{"kind":"tw","tokens":["size-7","gap-2","rounded-md","whitespace-nowrap"],"groups":["size-7","gap-2","rounded","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":107:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "luma") && (focusVisible.get() === true)), [{"kind":"tw","tokens":["border-ring","ring-3","ring-ring/30"],"groups":["border-color","ring-3","ring-ring/30"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":111:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "luma") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-muted","text-foreground"],"groups":["bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":76:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (style.get() === "sera"), [{"kind":"tw","tokens":["text-xs","font-semibold","uppercase","tracking-widest"],"groups":["text-size","font weight","uppercase","tracking-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":80:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "sera") && !((__pui_Owner.resolvedProps["size"] === "icon-compact"))), [{"kind":"tw","tokens":["rounded-none"],"groups":["rounded"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":84:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "sera") && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["border-border","bg-transparent","text-foreground"],"groups":["border-color","bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "sera") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-10","gap-1.5","px-6","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "sera") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-10","h-auto","gap-1.5","px-6","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "sera") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-9","gap-1","px-4","whitespace-nowrap"],"groups":["h-","gap-1","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "sera") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-9","h-auto","gap-1","px-4","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "sera") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-11","gap-1.5","px-8","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "sera") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-11","h-auto","gap-1.5","px-8","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "sera") && (__pui_Owner.resolvedProps["size"] === "icon")), [{"kind":"tw","tokens":["size-10","whitespace-nowrap"],"groups":["size-10","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "sera") && (__pui_Owner.resolvedProps["size"] === "icon-compact")), [{"kind":"tw","tokens":["size-7","gap-2","rounded-md","whitespace-nowrap"],"groups":["size-7","gap-2","rounded","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":107:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "sera") && (focusVisible.get() === true)), [{"kind":"tw","tokens":["border-ring","ring-2","ring-ring/30"],"groups":["border-color","ring-2","ring-ring/30"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":111:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "sera") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-muted","text-foreground"],"groups":["bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":76:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (style.get() === "rhea"), [{"kind":"tw","tokens":["text-sm","leading-5","font-medium"],"groups":["text-size","leading-5","font weight"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":80:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "rhea") && !((__pui_Owner.resolvedProps["size"] === "icon-compact"))), [{"kind":"tw","tokens":["rounded-[var(--pui-radius-2xl)]"],"groups":["rounded"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":84:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "rhea") && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["border-border","bg-background","text-foreground"],"groups":["border-color","bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "rhea") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-8","gap-1.5","px-3","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "rhea") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-8","h-auto","gap-1.5","px-3","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "rhea") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-7","gap-1","px-3","whitespace-nowrap"],"groups":["h-","gap-1","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "rhea") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-7","h-auto","gap-1","px-3","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "rhea") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-9","gap-1.5","px-4","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "rhea") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-9","h-auto","gap-1.5","px-4","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "rhea") && (__pui_Owner.resolvedProps["size"] === "icon")), [{"kind":"tw","tokens":["size-8","whitespace-nowrap"],"groups":["size-8","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "rhea") && (__pui_Owner.resolvedProps["size"] === "icon-compact")), [{"kind":"tw","tokens":["size-7","gap-2","rounded-md","whitespace-nowrap"],"groups":["size-7","gap-2","rounded","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":107:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "rhea") && (focusVisible.get() === true)), [{"kind":"tw","tokens":["border-ring","ring-3","ring-ring/30"],"groups":["border-color","ring-3","ring-ring/30"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":111:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "rhea") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-muted","text-foreground"],"groups":["bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":121:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "sera") && (__pui_Owner.resolvedProps["variant"] === "link")), [{"kind":"tw","tokens":["underline"],"groups":["underline"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":125:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (!((style.get() === "new-york-v4")) && (focusVisible.get() === true) && (__pui_Owner.resolvedProps["variant"] === "destructive")), [{"kind":"tw","tokens":["border-destructive/40","ring-destructive/20"],"groups":["border-color","ring-destructive/20"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":134:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (!((style.get() === "new-york-v4")) && (pressed.get() === true)), [{"kind":"tw","tokens":["translate-y-px"],"groups":["translate-y-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":138:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (!((style.get() === "new-york-v4")) && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "default")), [{"kind":"tw","tokens":["bg-primary/80"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":147:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (!((style.get() === "new-york-v4")) && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "secondary")), [{"kind":"tw","tokens":["bg-[color-mix(in_oklch,var(--secondary),var(--foreground)_5%)]"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":156:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (!((style.get() === "new-york-v4")) && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "ghost")), [{"kind":"tw","tokens":["bg-muted","text-foreground"],"groups":["bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":165:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (!((style.get() === "new-york-v4")) && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "link")), [{"kind":"tw","tokens":["underline"],"groups":["underline"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":174:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (!((style.get() === "new-york-v4")) && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "destructive")), [{"kind":"tw","tokens":["bg-destructive/20"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":186:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "vega") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["border-input","bg-input/30"],"groups":["border-color","bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":195:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "vega") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-input/50"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":186:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "nova") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["border-input","bg-input/30"],"groups":["border-color","bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":195:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "nova") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-input/50"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":186:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "lyra") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["border-input","bg-input/30"],"groups":["border-color","bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":195:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "lyra") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-input/50"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":207:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "luma") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-transparent"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":216:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "luma") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-input/30"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":207:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "rhea") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-transparent"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":216:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "rhea") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-input/30"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":227:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "mira") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-input/30"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":236:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "mira") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-input/50"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":246:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "sera") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-input/30"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":256:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (!((style.get() === "new-york-v4")) && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (__pui_Owner.resolvedProps["variant"] === "destructive")), [{"kind":"tw","tokens":["bg-destructive/20"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":265:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (!((style.get() === "new-york-v4")) && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "destructive")), [{"kind":"tw","tokens":["bg-destructive/30"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":275:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (!((style.get() === "new-york-v4")) && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (focusVisible.get() === true) && (__pui_Owner.resolvedProps["variant"] === "destructive")), [{"kind":"tw","tokens":["ring-destructive/40"],"groups":["ring-destructive/40"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":285:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (!((style.get() === "new-york-v4")) && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "ghost")), [{"kind":"tw","tokens":["bg-muted/50"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":297:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (style.get() === "new-york-v4"), [{"kind":"tw","tokens":["inline-flex","box-border","shrink-0","items-center","justify-center","rounded-md","text-sm","leading-5","font-medium","transition-all","outline-none"],"groups":["display","box sizing","shrink-0","items-","justify-","rounded","text-size","leading-5","font weight","transition-","outline-none"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":302:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.resolvedProps["variant"] === "default")), [{"kind":"tw","tokens":["bg-primary","text-primary-foreground"],"groups":["bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":302:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.resolvedProps["variant"] === "destructive")), [{"kind":"tw","tokens":["bg-destructive","text-white"],"groups":["bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":302:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["border","border-border","bg-background","text-foreground","shadow-xs"],"groups":["border-width","border-color","bg-","text-color","shadow-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":302:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.resolvedProps["variant"] === "secondary")), [{"kind":"tw","tokens":["bg-secondary","text-secondary-foreground"],"groups":["bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":302:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.resolvedProps["variant"] === "ghost")), [{"kind":"tw","tokens":["bg-transparent","text-foreground"],"groups":["bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":302:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.resolvedProps["variant"] === "link")), [{"kind":"tw","tokens":["bg-transparent","text-primary","underline-offset-4"],"groups":["bg-","text-color","underline-offset-4"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":314:9
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-9","gap-2","px-4","py-2","whitespace-nowrap"],"groups":["h-","gap-2","px-","py-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":323:9
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.resolvedProps["size"] === "default") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-9","h-auto","gap-2","px-4","py-1","min-w-0","max-w-full","whitespace-normal","break-words"],"groups":["min-h-","h-","gap-2","px-","py-","min-w-","max-w-","whitespace-normal","break-words"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":314:9
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-8","gap-1.5","px-3","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":323:9
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.resolvedProps["size"] === "sm") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-8","h-auto","gap-1.5","px-3","py-1","min-w-0","max-w-full","whitespace-normal","break-words"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","break-words"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":314:9
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-10","gap-2","px-6","whitespace-nowrap"],"groups":["h-","gap-2","px-","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":323:9
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.resolvedProps["size"] === "lg") && (__pui_Owner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-10","h-auto","gap-2","px-6","py-1","min-w-0","max-w-full","whitespace-normal","break-words"],"groups":["min-h-","h-","gap-2","px-","py-","min-w-","max-w-","whitespace-normal","break-words"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":309:9
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.resolvedProps["size"] === "icon")), [{"kind":"tw","tokens":["size-9","gap-2","whitespace-nowrap"],"groups":["size-9","gap-2","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":309:9
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.resolvedProps["size"] === "icon-compact")), [{"kind":"tw","tokens":["size-7","gap-2","whitespace-nowrap"],"groups":["size-7","gap-2","whitespace-nowrap"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":334:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (focusVisible.get() === true)), [{"kind":"tw","tokens":["border-ring","ring-3","ring-ring/50"],"groups":["border-color","ring-3","ring-ring/50"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":338:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (focusVisible.get() === true) && (__pui_Owner.resolvedProps["variant"] === "destructive")), [{"kind":"tw","tokens":["ring-destructive/20"],"groups":["ring-destructive/20"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":356:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "default")), [{"kind":"tw","tokens":["bg-primary/90"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":356:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "destructive")), [{"kind":"tw","tokens":["bg-destructive/90"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":356:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-accent","text-accent-foreground"],"groups":["bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":356:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "secondary")), [{"kind":"tw","tokens":["bg-secondary/80"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":356:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "ghost")), [{"kind":"tw","tokens":["bg-accent","text-accent-foreground"],"groups":["bg-","text-color"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":356:7
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "link")), [{"kind":"tw","tokens":["underline"],"groups":["underline"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":366:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["border-input","bg-input/30"],"groups":["border-color","bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":375:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "outline")), [{"kind":"tw","tokens":["bg-input/50"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":385:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (__pui_Owner.resolvedProps["variant"] === "destructive")), [{"kind":"tw","tokens":["bg-destructive/60"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":394:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (focusVisible.get() === true) && (__pui_Owner.resolvedProps["variant"] === "destructive")), [{"kind":"tw","tokens":["ring-destructive/40"],"groups":["ring-destructive/40"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":404:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => ((style.get() === "new-york-v4") && (__pui_Owner.def.feedback.style.meta("colorScheme") === "dark") && (hovered.get() === true) && (__pui_Owner.resolvedProps["variant"] === "ghost")), [{"kind":"tw","tokens":["bg-accent/50"],"groups":["bg-"]}]));
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":414:5
    __pui_Authored.rule(__pui_Owner.def.feedback.style.rule(() => (disabled.get() === true), [{"kind":"tw","tokens":["pointer-events-none","opacity-50"],"groups":["pointer-events-none","opacity-"]}]));
  })(__pui_Owner.def); return;
}

/** @typedef {import('vue').default & { readonly "__pui_Owner": ReturnType<typeof __pui_CreateOwner>; readonly "__pui_ParentScope"?: ReturnType<typeof __pui_CreateContextScope> | null }} __pui_NativeInstance */
export const ShadcnButton = {
  name: "shadcn-button",
  inheritAttrs: false,
  props: { instanceAssociations: { type: Object, default: undefined }, ["variant"]: {}, ["size"]: {}, ["disabled"]: {}, ["wrap"]: {}, ["styleProfile"]: {} },
  inject: { ["__pui_ParentScope"]: { from: __pui_ScopeKey, default: null } },
  /** @this {__pui_NativeInstance} */
  provide() { return { [__pui_ScopeKey]: this["__pui_Owner"].contextScope }; },
  /** @this {__pui_NativeInstance} */
  beforeCreate() {
    Object.defineProperty(this, "__pui_Owner", { value: __pui_CreateOwner(this, __pui_Setup, {"variant":{"kind":"union","members":[{"kind":"literal","value":"default"},{"kind":"literal","value":"destructive"},{"kind":"literal","value":"outline"},{"kind":"literal","value":"secondary"},{"kind":"literal","value":"ghost"},{"kind":"literal","value":"link"}]},"size":{"kind":"union","members":[{"kind":"literal","value":"default"},{"kind":"literal","value":"sm"},{"kind":"literal","value":"lg"},{"kind":"literal","value":"icon"},{"kind":"literal","value":"icon-compact"}]},"disabled":"boolean","wrap":"boolean","styleProfile":{"kind":"union","members":[{"kind":"literal","value":"vega"},{"kind":"literal","value":"nova"},{"kind":"literal","value":"maia"},{"kind":"literal","value":"lyra"},{"kind":"literal","value":"mira"},{"kind":"literal","value":"luma"},{"kind":"literal","value":"sera"},{"kind":"literal","value":"rhea"},{"kind":"literal","value":"new-york-v4"},{"kind":"literal","value":"new-york"},{"kind":"literal","value":"inherit"}]}}, "div", true) });
    
  },
  /** @this {__pui_NativeInstance} */
  created() { this["__pui_Owner"].initialize(); },
  /** @this {__pui_NativeInstance} */
  mounted() { this["__pui_Owner"].hostMounted(); },
  /** @this {__pui_NativeInstance} */
  updated() { this["__pui_Owner"].afterCommit(); },
  /** @this {__pui_NativeInstance} */
  activated() { this["__pui_Owner"].activate(); },
  /** @this {__pui_NativeInstance} */
  deactivated() { this["__pui_Owner"].deactivate(); },
  /** @this {__pui_NativeInstance} */
  beforeDestroy() { this["__pui_Owner"].dispose(); },
  methods: {
    /** @this {__pui_NativeInstance} */
    update() { this["__pui_Owner"].update(); },
    /** @this {__pui_NativeInstance} */
    getExposes() { return this["__pui_Owner"].getExposes(); },
    /** @this {__pui_NativeInstance} @template T @param {() => T} callback */
    invokeInCallbackScope(callback) { return this["__pui_Owner"].invokePublic(callback); },
  },
  /** @this {__pui_NativeInstance} @param {import('vue').CreateElement} h */
  render(h) { return this["__pui_Owner"].render(h); },
};
export default ShadcnButton;


//# sourceMappingURL=ShadcnButton.js.map
