// Editable generated Vue 2.6.14 component options. Profile: vue2-source-v1.
// Inline native-lowering helpers: logical owner, prop resolution, state, semantic templates.
// No Proto-UI Core, Runtime, Hooks or Adapter dependency; optional native helpers are emitted artifacts.
// Source graph SHA-256: b73c3bc9ba9778927c557752ba5a485793ae406eef1ffc0097945232bc9335d1
import { releaseNativeMeta as __puiReleaseMeta } from './.proto-ui/meta/subscription-v1';
import { readNativeWebMeta as __puiReadMeta } from './.proto-ui/meta/web-snapshot-v1';
import { subscribeNativeRulePreferences as __puiSubscribePreferences, readNativeRulePreference as __puiReadPreference } from './.proto-ui/meta/preference-source-v1';


import { createNativeAuthoredHooks as __puiCreateAuthored } from './.proto-ui/owner/authored-hooks-v1';
import { normalizeVue2InstanceAssociations as __puiNormalizeAssociations } from './.proto-ui/interaction/vue2-associations-v1';
import { createNativeStyle as __puiCreateNativeStyle, templateStyleTokens as __puiTemplateStyleTokens } from './.proto-ui/style/native-v1';
import { createNativeInteraction as __puiCreateNativeInteraction } from './.proto-ui/interaction/native-e6807d4f71af1465-v2';
/** @template Run @typedef {import('./.proto-ui/interaction/native-e6807d4f71af1465-v2').NativeInteraction<Run>} __puiNativeInteraction */
/** @typedef {import('./.proto-ui/interaction/native-e6807d4f71af1465-v2').NativeFocus} __puiNativeFocus */
/** @typedef {import('./.proto-ui/interaction/native-e6807d4f71af1465-v2').NativeAccessible} __puiNativeAccessible */
/** @template T @typedef {import('./.proto-ui/interaction/native-e6807d4f71af1465-v2').NativeObservedState<T>} __puiNativeObservedState */
/** @typedef {import('./.proto-ui/interaction/native-e6807d4f71af1465-v2').NativeInput} __puiNativeInput */
/** @typedef {import('./.proto-ui/interaction/native-e6807d4f71af1465-v2').NativeFocusOptions} __puiNativeFocusOptions */
import { createContextScope as __puiCreateContextScope, scopeKey as __puiScopeKey, acceptsContextValue as __puiAcceptsContextValue } from './.proto-ui/context/scope-v1';




/** @typedef {{
  "variant"?: "solid" | "surface" | "destructive" | null;
  "color"?: "main" | "mint" | "lavender" | "coral" | "sky" | null;
  "size"?: "default" | "sm" | "lg" | "icon" | null;
  "wrap"?: boolean | null;
  "disabled"?: boolean | null;
}} GeneratedProps */
/** @typedef {Readonly<{
  readonly "variant": "solid" | "surface" | "destructive";
  readonly "color": "main" | "mint" | "lavender" | "coral" | "sky";
  readonly "size": "default" | "sm" | "lg" | "icon";
  readonly "wrap": boolean;
  readonly "disabled": boolean;
} & Record<string, unknown>>} __puiResolvedProps */
/** @typedef {{
  "disabled": __puiExternalState<boolean>;
  "hovered": __puiExternalState<boolean>;
  "focused": __puiExternalState<boolean>;
  "focusVisible": __puiExternalState<boolean>;
  "focusSelf": (options?: { "reason"?: "programmatic" | "keyboard" | "pointer"; "preventScroll"?: boolean }) => void;
  "pressed": __puiExternalState<boolean>;
}} GeneratedExposes */
/** @typedef {Array<import('vue').VNode | string>} __puiNativeChildren */
/** @typedef {{ used: boolean }} __puiNativeSlotFrame */
/** @typedef {(h: import('vue').CreateElement, vm: import('vue').default, slots: __puiNativeSlotFrame) => __puiNativeChildren} __puiNativePaint */
/** @typedef {{
 * slot: () => __puiNativePaint,
 * read: {
 *   props: {
 *     get: () => __puiResolvedProps,
 *     getRaw: () => Readonly<Record<string, unknown>>,
 *     isProvided: (key: PropertyKey) => boolean
 *   },
 *   context: {
 *     read: (key: object) => ReturnType<import('./.proto-ui/context/scope-v1').ContextScope['read']>,
 *     tryRead: (key: object) => ReturnType<import('./.proto-ui/context/scope-v1').ContextScope['tryRead']>
 *   }
 * }
 * }} __puiNativeRenderer */
/** @typedef {import('./.proto-ui/style/native-v1').NativeStyleHandle} __puiNativeStyleHandle */

/**
 * @template T
 * @typedef {{ get: () => T, subscribe: (callback: (event: { type: 'next', prev: T, next: T, reason?: unknown } | { type: 'disconnect', reason: 'unmount' }) => void) => (() => void), unsubscribe: (off: () => void) => void, spec: Readonly<Record<string, unknown>> }} __puiExternalState
 */
/** @template T @typedef {{ type: 'next', prev: T, next: T, reason?: unknown } | { type: 'disconnect', reason: 'unmount' }} __puiStateEvent */
/** @template T @typedef {{ get: () => T, setDefault: (value: T) => void, set: (value: T, reason?: unknown) => void, external: __puiExternalState<T>, dispose: () => void }} __puiOwnedState */
/** @typedef {'boolean' | 'number' | 'string' | 'null' | 'void' | { kind: 'literal', value: string | number | boolean | null } | { kind: 'array', element: __puiDataType } | { kind: 'union', members: readonly __puiDataType[] } | { kind: 'record', fields: readonly { name: string, type: __puiDataType, optional?: boolean }[] }} __puiDataType */
/** @typedef {Readonly<Record<string, unknown>>} __puiRawProps */
/** @typedef {{ type: 'boolean' | 'number' | 'string' | 'object' | 'any' | 'enum', empty?: 'accept' | 'fallback' | 'error', default?: unknown, options?: readonly string[], range?: { min?: number, max?: number } }} __puiPropSpec */
/** @typedef {{ options?: readonly (boolean | string | number)[], min?: unknown, max?: unknown, step?: unknown, clamp?: boolean } & Record<string, unknown>} __puiStateConfiguration */
/** @typedef {'bool' | 'string' | 'enum' | 'number.discrete' | 'number.range'} __puiStateKind */
/** @typedef {ReturnType<typeof __puiCreateOwner>} __puiOwner */
/** @typedef {Parameters<Parameters<__puiOwner['def']['props']['watch']>[1]>[0]} __puiRun */
/** @typedef {import('vue').default & { readonly instanceAssociations?: Readonly<{controlLabel?: object | null}>; readonly __puiParentScope?: import('./.proto-ui/context/scope-v1').ContextScope | null }} __puiOwnerInstance */
/** @typedef {(renderer: __puiNativeRenderer) => __puiNativePaint} __puiRenderFunction */
/** @typedef {{ changedKeysAll: string[], changedKeysMatched: string[] }} __puiPropsWatchInfo */
/** @template Run @template Snapshot @typedef {(run: Run, next: Snapshot, previous: Snapshot, info: __puiPropsWatchInfo) => void} __puiPropsWatchCallback */
/** @template Run @typedef {{ kind: 'resolved' | 'resolved-all', keys: readonly string[] | null, fn: __puiPropsWatchCallback<Run, __puiResolvedProps> } | { kind: 'raw' | 'raw-all', keys: readonly string[] | null, fn: __puiPropsWatchCallback<Run, __puiRawProps> }} __puiPropsWatchRegistration */
/** @typedef {"created" | "mounted" | "updated" | "unmounted" | "beforeDispose"} __puiLifecycleKind */
/** @template Run @typedef {(run: Run) => void} __puiLifecycleCallback */
/** @template Run @typedef {__puiPropsWatchRegistration<Run> & { active: boolean }} __puiPropsWatcher */
/** @typedef {{ epoch: number, revision: number, kind: 'update' }} __puiPendingCommit */
/** @typedef {{ epoch: number, version: number, present: boolean, vnode: import('vue').VNode, kind: 'mount' | 'update' | 'none' | 'detach', revision?: number | null }} __puiRenderedCommit */
/** @param {unknown} value @param {PropertyKey} key */
const __puiOwn = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
// Keep native relational coercion in all three open-schema comparisons.
/** @template T @param {T} left @param {T} right */
const __puiBefore = (left, right) => left < right;

/** @param {__puiDataType} type @param {unknown} value @returns {boolean} */
function __puiAccepts(type, value) {
  if (typeof type === 'string') return type === 'null' ? value === null : typeof value === type && (type !== 'number' || Number.isFinite(value));
  if (type.kind === 'literal') return Object.is(value, type.value);
  if (type.kind === 'union') return type.members.some((member) => __puiAccepts(member, value));
  if (type.kind === 'array') return Array.isArray(value) && value.every((item) => __puiAccepts(type.element, item));
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false;
  const record = /** @type {Record<string, unknown>} */ (value);
  return type.fields.every((field) =>
    __puiOwn(record, field.name) ? __puiAccepts(field.type, record[field.name]) : field.optional === true);
}
/** @param {unknown} value @param {Set<object>} [seen] @returns {boolean} */
function __puiJson(value, seen = new Set()) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return true;
  if (typeof value === 'number') return Number.isFinite(value);
  if (typeof value !== 'object' || seen.has(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  if (!Array.isArray(value) && prototype !== Object.prototype && prototype !== null) return false;
  if (Array.isArray(value) && (Object.keys(value).length !== value.length || !Object.keys(value).every((key) => /^(0|[1-9]\d*)$/.test(key) && Number(key) < value.length))) return false;
  seen.add(value);
  const valid = Object.values(value).every((item) => __puiJson(item, seen));
  seen.delete(value);
  return valid;
}

/** @param {Readonly<Record<string, string | number | boolean | null>>} properties @param {Record<string, string | null>} attrs @param {boolean} initial */
function __puiRootData(properties, attrs, initial) {
  /** @type {import('vue').VNodeData & { pre: true, attrs: Record<string, string | number | null> }} */
  const result = { pre: true, attrs: { ...attrs } };
  for (const [key, value] of Object.entries(properties)) {
    if (key === 'value') { if (initial) result.domProps = { value }; }
    else if (key === 'style') { if (typeof value === 'string') result.style = value; }
    else result.attrs[key] = value === false ? null : value === true ? '' : value;
  }
  return result;
}
/** @param {__puiOwnerInstance} vm @param {(owner: __puiOwner) => __puiRenderFunction | void} setup @param {Record<string, __puiDataType>} types @param {string} rootTag @param {boolean} autoUpdate */
function __puiCreateOwner(vm, setup, types, rootTag, autoUpdate) {
  
  let phase = 'setup';
  let terminal = false;
  let disposed = false;
  let hydrated = false;
  let nativeMounted = false;
  let hostActive = true;
  let present = true;
  let viewActive = false;
  let epoch = 0;
  let revision = 0;
  let commitVersion = 0;
  let queued = false;
  /** @type {__puiPendingCommit | null} */
  let pending = null;
  /** @type {__puiRenderedCommit | null} */
  let renderedCommit = null;
  /** @type {HTMLElement | null} */ let activeRoot = null;
  let activeEpoch = -1;
  /** @type {__puiNativePaint | null} */
  let template = null;
  /** @type {__puiRenderFunction | null | void} */
  let renderFunction;
  /** @type {(() => void) | undefined} */
  let unwatch;
  /** @type {__puiRawProps} */
  let raw = Object.freeze({});
  /** @type {__puiResolvedProps} */
  let resolved = /** @type {__puiResolvedProps} */ (Object.freeze({}));
  /** @type {Record<string, unknown>} */
  let previousValid = Object.create(null);
  /** @type {Record<string, __puiPropSpec>} */
  let specs = Object.create(null);
  /** @type {__puiRawProps[]} */
  const defaults = [];
  /** @type {Array<__puiPropsWatcher<typeof run>>} */
  const watchers = [];
  /** @type {Array<{ dispose: () => void }>} */
  const states = [];
  /** @type {Record<string, unknown>} */
  const exposed = Object.create(null);
  /** @type {Record<string, unknown>} */
  const eventDeclarations = Object.create(null);
  /** @type {Record<__puiLifecycleKind, Array<__puiLifecycleCallback<typeof run>>>} */
  const lifecycle = { "created": [], "mounted": [], "updated": [], "unmounted": [], "beforeDispose": [] };
  /** @type {Array<() => void>} */
  const notifications = [];
  /** @type {WeakMap<object, __puiExternalState<unknown>>} */
  const observedExternals = new WeakMap();
  /** @template T @param {{ get: () => T }} state @returns {__puiExternalState<T>} */
  function externalState(state) {
    const external = observedExternals.get(state);
    if (!external) throw new Error('[State] handle does not belong to this generated owner.');
    // Registration binds this exact handle to its same-value external view.
    return /** @type {__puiExternalState<T>} */ (external);
  }
  let notifying = false;
  let dispatchingProps = false;
  /** @type {{raw: __puiRawProps; resolved: __puiResolvedProps} | null} */
  let propsWindow = null;
  const alive = () => { if (disposed) throw new Error('[Vue2 native] logical instance has been disposed.'); };
  const publicAlive = () => { if (terminal) throw new Error('[Vue2 native] exposed target has been terminally invalidated.'); };
  const callback = () => { alive(); if (phase !== 'callback') throw new Error('[Vue2 native] mutation requires callback scope.'); };
  const setupOnly = () => { alive(); if (phase !== 'setup') throw new Error('[Vue2 native] declaration requires setup scope.'); };
  const style = __puiCreateNativeStyle({
    getMeta: /** @param {string} key */ (key) => key.startsWith('preference.') ? __puiReadPreference(activeRoot?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), key) : __puiReadMeta(activeRoot?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), key), subscribeMeta: /** @param {() => void} notify */ (notify) => { /** @type {(() => void)[]} */ const leases = []; try { leases.push(__puiSubscribePreferences(activeRoot?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), ["preference.reducedMotion"], notify)); } catch (error) { __puiReleaseMeta([() => { throw error; }, ...leases]); } return () => __puiReleaseMeta(leases); },
    ensureSetup: setupOnly,
    ensureRuntime: callback,
    isAlive: () => !terminal && !disposed,
    project: (tokens) => {
      if (!activeRoot) return;
      if (tokens.length) activeRoot.setAttribute('data-pui-style', tokens.join(' '));
      else activeRoot.removeAttribute('data-pui-style');
    },
  });
  /** @returns {__puiRawProps} */
  const hostRaw = () => {
    
    // Full snapshots preserve omission and explicit undefined. Vue Boolean casting and
    // default materialization never participate in the semantic prop contract.
    const out = Object.create(null);
    /** @type {Record<string, unknown>} */
    const input = { ...(vm.$attrs || {}), ...((vm.$options && vm.$options.propsData) || {}) };
    /** @type {Readonly<Record<string, unknown>>} */
    const provided = /** @type {Readonly<Record<string, unknown>>} */ ((vm.$options && vm.$options.propsData) || {});
    for (const key of Object.keys(types)) {
      const hostKey = key.replace(/-(\w)/g, (_match, letter) => letter.toUpperCase());
      // Track native prop notifications, but keep values/presence from the raw snapshot.
      if (vm.$props) void (/** @type {Readonly<Record<string, unknown>>} */ (vm.$props))[hostKey];
      if (__puiOwn(provided, hostKey)) input[key] = provided[hostKey];
    }
    for (const key of Object.keys(input)) if (key !== 'instanceAssociations' && key !== 'instance-associations') out[key] = input[key];
    return Object.freeze(out);
  };
  /** @param {__puiRawProps} a @param {__puiRawProps} b */
  const same = (a, b) => {
    const keys = Object.keys(a);
    return keys.length === Object.keys(b).length && keys.every((key) => __puiOwn(b, key) && Object.is(a[key], b[key]));
  };
  /** @param {string} key @param {unknown} value */
  const validValue = (key, value) => {
    const spec = specs[key];
    if (!__puiJson(value) || !__puiAccepts(types[key], value)) return false;
    if (spec.type === 'enum' && (typeof value !== 'string' || !spec.options?.includes(value))) return false;
    return !spec.range || typeof value === 'number' && value >= (spec.range.min ?? -Infinity) && value <= (spec.range.max ?? Infinity);
  };
  /** @param {__puiRawProps} input @param {boolean} strict */
  const resolveProps = (input, strict) => {
    /** @type {Record<string, unknown>} */
    const out = Object.create(null);
    const nextValid = { ...previousValid };
    /** @type {{ providedKeys: string[], emptyKeys: string[], invalidKeys: string[], usedFallbackKeys: string[], acceptedEmptyKeys: string[] }} */
    const meta = { providedKeys: [], emptyKeys: [], invalidKeys: [], usedFallbackKeys: [], acceptedEmptyKeys: [] };
    for (const key of Object.keys(specs)) {
      const spec = specs[key];
      const provided = __puiOwn(input, key);
      const value = input[key] === undefined ? null : input[key];
      const empty = spec.empty ?? 'fallback';
      if (provided) meta.providedKeys.push(key);
      if (provided && value !== null && validValue(key, value)) {
        out[key] = value; nextValid[key] = value; continue;
      }
      if (provided && value === null) {
        meta.emptyKeys.push(key);
        if (empty === 'accept') { out[key] = null; meta.acceptedEmptyKeys.push(key); continue; }
      } else if (provided) meta.invalidKeys.push(key);
      let found = false;
      /** @type {unknown} */
      let selected = null;
      let usedDefault = true;
      /** @param {unknown} candidate @param {boolean} fromDefault */
      const take = (candidate, fromDefault) => {
        if (found || candidate === undefined || strict && empty === 'error' && candidate === null) return;
        if (candidate !== null && !validValue(key, candidate)) return;
        found = true; selected = candidate; usedDefault = fromDefault;
      };
      if (provided && __puiOwn(previousValid, key)) take(previousValid[key], false);
      for (const layer of defaults) if (__puiOwn(layer, key)) take(layer[key], true);
      if (__puiOwn(spec, 'default')) take(spec.default, true);
      if (!found && strict && empty === 'error') throw new Error('[Vue2 native] prop ' + key + ' requires a non-empty valid value or fallback.');
      out[key] = selected;
      if (usedDefault) meta.usedFallbackKeys.push(key);
      if (provided && selected !== null) nextValid[key] = selected;
    }
    previousValid = nextValid;
    /** @type {__puiResolvedProps} */
    const snapshot = /** @type {__puiResolvedProps} */ (Object.freeze(out));
    return { snapshot, meta };
  };
  /** @template T @param {() => T} fn @param {boolean} [sync] @returns {T} */
  const invoke = (fn, sync = true) => {
    alive();
    const previousPhase = phase;
    phase = 'callback';
    try { if (sync && !terminal ) syncHost(false); return fn(); }
    finally { phase = previousPhase; }
  };
  /** @param {boolean} request */
  const syncHost = (request) => {
    if (terminal) return;
    interaction.refresh();
    const nextRaw = hostRaw();
    if (hydrated && same(raw, nextRaw)) return;
    const previousRaw = raw;
    const previous = resolved;
    const next = resolveProps(nextRaw, true);
    raw = nextRaw; resolved = next.snapshot;
    if (!hydrated) { hydrated = true; style.refresh(); interaction.refresh(); return; }
    const changedKeys = Object.keys(specs).filter((key) => !Object.is(previous[key], resolved[key]));
    const changedRawKeys = watchers.some((watch) => watch.active && (watch.kind === 'raw' || watch.kind === 'raw-all'))
      ? [...new Set([...Object.keys(previousRaw), ...Object.keys(raw)])].filter((key) => !Object.is(previousRaw[key], raw[key])) : [];
    if (changedKeys.length) { style.refresh(); interaction.refresh(); }
    if ((changedKeys.length || changedRawKeys.length) && !dispatchingProps) {
      dispatchingProps = true;
      const previousWindow = propsWindow; propsWindow = {raw: nextRaw, resolved: next.snapshot};
      try {
        invoke(() => {
          // Raw-all precedes raw-keyed; resolved-all and keyed share declaration order.
          const snapshot = watchers.slice();
          for (let group = 0; group < 3; ++group) {
            for (const watch of snapshot) {
              if (!watch.active || (watch.kind === 'raw-all' ? 0 : watch.kind === 'raw' ? 1 : 2) !== group) continue;
              const isRaw = group < 2;
              const changedKeysAll = isRaw ? changedRawKeys : changedKeys;
              const changedKeysMatched = watch.keys === null ? changedKeysAll : watch.keys.filter((key) => changedKeysAll.includes(key));
              if (changedKeysMatched.length) {
                const info = { changedKeysAll: [...changedKeysAll], changedKeysMatched: [...changedKeysMatched] };
                // The registration discriminant preserves the raw/resolved callback
                // relation; the host group order and snapshot copies stay unchanged.
                if (watch.kind === 'raw' || watch.kind === 'raw-all') {
                  console.warn('[Props] raw watchers are an adapter-snapshot escape hatch; avoid in official prototypes.');
                  watch.fn(run, nextRaw, previousRaw, info);
                }
                else watch.fn(run, next.snapshot, previous, info);
              }
            }
          }
        }, false);
      } finally { propsWindow = previousWindow; dispatchingProps = false; }
    }
    if (request && autoUpdate) update();
  };
  const renderSemantic = () => {
    if (!renderFunction) throw new Error('[Vue2 native] renderer is unavailable outside the initialized instance lifetime.');
    const previousPhase = phase;
    phase = 'render';
    try { template = renderFunction(renderer); }
    finally { phase = previousPhase; }
  };
  const force = () => { if (!terminal && nativeMounted) vm.$forceUpdate(); };
  const update = () => {
    if (terminal) return;
    invoke(() => {}, true);
    if (!nativeMounted || !hostActive || !present || !viewActive) return;
    if (pending) { queued = true; return; }
    renderSemantic();
    pending = { epoch, revision: ++revision, kind: 'update' };
    force();
  };
  /** @param {boolean} next */
  const setPresent = (next) => {
    callback();
    if (terminal) throw new Error('[Vue2 native] presence is locked for terminal disposal.');
    if (present === next) return;
    present = next; ++epoch; pending = null; renderedCommit = null; queued = false;
    const requestedEpoch = epoch, failures = [];
    // Vue must patch at the owned anchor, not leave its replacement comment
    // in the Portal host and later resurrect the already-removed Root.
    
    if (!terminal && epoch === requestedEpoch && present === next) {
      if (!next) { try { interaction.unmount(); } catch (error) { failures.push(error); } }
      if (!terminal && epoch === requestedEpoch && present === next) {
        // A newer presence request or terminal disposal always wins reentry.
        try {
          if (next && nativeMounted && hostActive && viewActive) renderSemantic();
          force();
        } catch (error) { failures.push(error); }
      }
    }
    if (failures.length) throw failures.length === 1 ? failures[0]
      : new AggregateError(failures, '[Vue2 native] presence withdrawal failed.');
  };

  /** @type {Map<object, (value: unknown) => boolean>} */
  const contextChecks = new Map([

  ]);
  const contextScope = __puiCreateContextScope({
    getParent: () => vm["__puiParentScope"] || null,
    isAlive: () => !disposed,
    invoke: (fn) => invoke(fn, false),
    validate: (key, value) => contextChecks.get(key)?.(value) === true,
  });
  const contextRead = Object.freeze({ read: (/** @param {object} key */ (key) => { alive(); return contextScope.read(key); }), tryRead: (/** @param {object} key */ (key) => { alive(); return contextScope.tryRead(key); }) });

  const __puiMeta = /** @param {string} key */ (key) => __puiReadMeta(vm.$el?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), key);
  /** @type {(() => void)[]} */ const __puiAuthoredWatchCleanups = [];
  const __puiAuthored = __puiCreateAuthored({setup: setupOnly, borrow(/** @type {unknown} */ value) {
    
    const state = /** @type {__puiOwnedState<unknown>} */ (value);
    const borrowed = Object.freeze({get: () => state.get(), setDefault: (/** @type {unknown} */ value) => state.setDefault(value), set: (/** @param {unknown} value @param {unknown} [reason] */ (value, reason) => state.set(value, reason)), watch: (/** @type {(run: __puiRun, event: __puiStateEvent<unknown>) => void} */ fn) => { setupOnly(); const off = state.external.subscribe(event => invoke(() => fn(run, event), false)); __puiAuthoredWatchCleanups.push(off); return off; }});
    
    return borrowed;
    
  }});
  
  const run = {
    context: { ...contextRead, update: (/** @param {object} key @param {unknown} value */ (key, value) => { callback(); contextScope.update(key, value); }), tryUpdate: (/** @param {object} key @param {unknown} value */ (key, value) => { callback(); return contextScope.tryUpdate(key, value); }) },
    feedback: { style },
    update: () => { callback(); update(); },
    props: {
      get: () => { alive(); return propsWindow?.resolved ?? resolved; },
      getRaw: () => { alive(); return propsWindow?.raw ?? raw; },
      isProvided: (/** @param {PropertyKey} key */ (key) => { alive(); return __puiOwn(propsWindow?.raw ?? raw, key); }),
    },
    lifecycle: { setPresent },
    expose: { emit: (/** @param {string} key @param {unknown} [payload] @param {unknown} [options] */ (key, payload, options) => {
      callback();
      if (!__puiOwn(eventDeclarations, key)) throw new Error('[Vue2 native] undeclared expose event: ' + key);
      const listener = vm.$attrs && (/** @type {Readonly<Record<string, unknown>>} */ (vm.$attrs))['on' + key[0].toUpperCase() + key.slice(1)];
      // Host sink failures do not re-enter authored callbacks, matching the Vue2 sink.
      try { if (typeof listener === 'function') listener(payload, options); } catch {}
      try { vm.$emit(key, payload, options); } catch {}
    }) },
  };
  /** @type {__puiNativeInteraction<typeof run>} */
  const interaction = __puiCreateNativeInteraction({
    ensureSetup: setupOnly,
    ensureRuntime: callback,
    ensureEvent: callback,
    isAlive: () => !terminal && !disposed,
    isSetupComplete: () => phase !== 'setup',
    isReady: () => phase !== 'setup' && viewActive && present && hostActive && !terminal,
    invoke: (fn) => invoke(fn),
    getRun: () => run,
    getResolvedProps: () => resolved,
    getAssociations: () => __puiNormalizeAssociations(vm.instanceAssociations, (/** @type {{_base?: {observable?: (value: object) => object}}} */ (vm.$options))._base?.observable),

    subscribeState: (state, fn) => externalState(state).subscribe(fn),
    getRoot: () => viewActive && present && hostActive && activeEpoch === epoch ? activeRoot : null,
    identity: contextScope, getLogicalParent: () => vm["__puiParentScope"] || null,
    declarations: [], tableFamily: undefined,
    getExposes: () => exposed,
    registerExpose: (key, value) => {
      setupOnly(); if (__puiOwn(exposed, key)) throw new Error('[Expose] duplicate declaration: ' + key);
      if (value !== null && typeof value === 'object' && observedExternals.has(value)) exposed[key] = observedExternals.get(value);
      else if (typeof value === 'function') exposed[key] = (/** @param {unknown[]} args */ (...args) => { publicAlive(); return invoke(() => value(...args)); });
      else exposed[key] = value;
    },
    createOwnedState: (name, value, spec) => createState(spec?.kind ?? (typeof value === 'boolean' ? 'bool' : typeof value === 'number' ? 'number.discrete' : 'string'), name, value, spec),
    watchState: (state, fn) => { setupOnly(); return externalState(state).subscribe(event => invoke(() => fn(run, event))); },
    isPropProvided: key => __puiOwn(raw, key),
    setPresent, requestHostUpdate: force,
    emit: (key) => run.expose.emit(key),
    registerGenericObservedState: (handle) => {
      /** @type {Set<(event: __puiStateEvent<ReturnType<typeof handle.get>>) => void>} */
      const subscribers = new Set();
      const off = handle.subscribe((event) => {
        style.refresh(); interaction.refresh();
        for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(notifications, notifications.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!notifying) {
  notifying = true;
  /** @type {unknown[]} */ const notificationFailures = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < notifications.length) {
      try { notifications[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { notifications.length = 0; notifying = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
      });
      /** @type {__puiExternalState<ReturnType<typeof handle.get>>} */
      const external = Object.freeze({
        get: () => { publicAlive(); return handle.get(); },
        subscribe: (fn) => { publicAlive(); /** @type {typeof fn} */ const registration = (/** @type {Parameters<typeof fn>[0]} */ event) => fn(event); subscribers.add(registration); return () => subscribers.delete(registration); },
        unsubscribe: (unsubscribe) => { publicAlive(); if (typeof unsubscribe === 'function') unsubscribe(); },
        spec: Object.freeze({ kind: typeof handle.get() === 'boolean' ? 'bool' : typeof handle.get() === 'number' ? 'number.discrete' : 'string', observed: true }),
      });
      observedExternals.set(handle, external);
      
      states.push({ dispose: () => {
        off();
        try { for (const fn of Array.from(subscribers)) fn({ type: 'disconnect', reason: 'unmount' }); }
        finally { subscribers.clear(); }
      } });
    },
  });
  /** @type {__puiNativeRenderer} */
  const renderer = { 
    slot: () => /** @type {__puiNativePaint} */ ((_h, nativeVm, slots) => {
      if (slots.used) throw new Error('[Vue2 native] only one default slot is supported.');
      slots.used = true;
      const scoped = nativeVm.$scopedSlots.default;
      return (scoped ? scoped({}) : nativeVm.$slots.default) || [];
    }),
    read: Object.freeze({ props: Object.freeze({ get: () => { alive(); return resolved; }, getRaw: () => { alive(); return raw; }, isProvided: (/** @param {PropertyKey} key */ (key) => { alive(); return __puiOwn(raw, key); }) }) , context: contextRead }) };
  /**
   * @template T
   * @param {T} initial
   * @param {Readonly<Record<string, unknown>>} spec
   * @param {(value: T, initialValue?: boolean) => T} check
   * @returns {__puiOwnedState<T>}
   */
  const createStateCell = (initial, spec, check) => {
    let value = check(initial, true);
    /** @type {Set<(event: __puiStateEvent<T>) => void>} */
    const subscribers = new Set();
    /** @type {__puiOwnedState<T>} */
    const handle = {
      get: () => { alive(); return value; },
      setDefault: next => { setupOnly(); value = check(next, true); },
      set: (next, reason) => {
        callback();
        next = check(next);
        if (Object.is(value, next)) return;
        const previous = value; value = next;
        style.refresh(); interaction.refresh();
        /** @type {__puiStateEvent<T>} */
        const event = { type: 'next', prev: previous, next, reason };
        for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(notifications, notifications.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!notifying) {
  notifying = true;
  /** @type {unknown[]} */ const notificationFailures = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < notifications.length) {
      try { notifications[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { notifications.length = 0; notifying = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
      },
      external: {
        get: () => { publicAlive(); return handle.get(); },
        subscribe: (fn) => { publicAlive(); /** @type {typeof fn} */ const registration = (/** @type {Parameters<typeof fn>[0]} */ event) => fn(event); subscribers.add(registration); return () => subscribers.delete(registration); },
        unsubscribe: (off) => { publicAlive(); if (typeof off === 'function') off(); },
        spec,
      },
      dispose: () => {
        try { for (const fn of Array.from(subscribers)) fn({ type: 'disconnect', reason: 'unmount' }); }
        finally { subscribers.clear(); }
      },
    };
    observedExternals.set(handle, handle.external);
    states.push(handle);
    
    return handle;
  };
  /** @template {boolean | string | number} T @param {__puiStateKind} kind @param {string} key @param {T} initial @param {__puiStateConfiguration} [configuration] @returns {__puiOwnedState<T>} */
  const createState = (kind, key, initial, configuration = {}) => {
    setupOnly();
    const spec = Object.freeze({ ...configuration, kind });
    /** @param {T} value @param {boolean} [initialValue] @returns {T} */
    const check = (value, initialValue = false) => {
      const expected = kind === 'bool' ? 'boolean' : kind === 'string' || kind === 'enum' ? 'string' : 'number';
      if (typeof value !== expected || expected === 'number' && !Number.isFinite(value)) throw new TypeError('[Vue2 native] invalid state value: ' + key);
      if (spec.options && spec.options.length && !spec.options.includes(value)) throw new Error('[Vue2 native] state value not in options: ' + key);
      // Numeric-family schemas prove these numeric views. Other families keep
      // their structurally admitted extra fields and native relational coercion.
      if (kind === 'number.range' && initialValue && spec.clamp) value = /** @type {T} */ (Math.min(/** @type {number} */ (spec.max), Math.max(/** @type {number} */ (spec.min), /** @type {number} */ (value))));
      if (!(kind === 'number.discrete' && spec.options && spec.options.length) && (spec.min !== undefined && __puiBefore(value, spec.min) || spec.max !== undefined && __puiBefore(spec.max, value))) throw new Error('[Vue2 native] state value out of range: ' + key);
      if (kind === 'number.discrete' && !(spec.options && spec.options.length) && __puiBefore(0, spec.step) && !Number.isInteger((/** @type {number} */ (value) - /** @type {number} */ (spec.min ?? 0)) / /** @type {number} */ (spec.step))) throw new Error('[Vue2 native] state value violates step: ' + key);
      return value;
    };
    __puiAuthored.claimState(key);
    const handle = createStateCell(initial, spec, check);
    __puiAuthored.state(key, handle);
    return handle;
  };
  /** @param {Record<string, __puiPropSpec>} input */
  const defineProps = (input) => {
    setupOnly();
    const next = { ...specs };
    const rank = { accept: 0, fallback: 1, error: 2 };
    for (const key of Object.keys(input)) {
      const spec = input[key];
      if (!spec || !['boolean', 'number', 'string', 'object', 'any', 'enum'].includes(spec.type)) throw new Error('[Vue2 native] invalid prop declaration: ' + key);
      if (spec.empty !== undefined && !__puiOwn(rank, spec.empty)) throw new Error('[Vue2 native] invalid empty behavior: ' + key);
      if (spec.type === 'enum' && (!Array.isArray(spec.options) || !spec.options.length || !spec.options.every((value) => typeof value === 'string'))) throw new Error('[Vue2 native] invalid enum options: ' + key);
      if (spec.type !== 'enum' && __puiOwn(spec, 'options')) throw new Error('[Vue2 native] only enum props accept options: ' + key);
      if (__puiOwn(spec, 'default') && !__puiJson(spec.default)) throw new Error('[Vue2 native] non-JSON prop default: ' + key);
      const prior = next[key];
      if (prior) {
        if (prior.type !== spec.type || __puiOwn(spec, 'empty') && spec.empty !== undefined && rank[spec.empty] > rank[prior.empty ?? 'fallback']) throw new Error('[Vue2 native] conflicting prop declaration: ' + key);
        if (prior.options && !prior.options.every((value) => spec.options && spec.options.includes(value))) throw new Error('[Vue2 native] prop options cannot narrow: ' + key);
        if (prior.range && spec.range && ((spec.range.min ?? -Infinity) > (prior.range.min ?? -Infinity) || (spec.range.max ?? Infinity) < (prior.range.max ?? Infinity))) throw new Error('[Vue2 native] prop range cannot narrow: ' + key);
        next[key] = { ...prior, ...spec, empty: prior.empty ?? 'fallback', range: spec.range ?? prior.range };
        if (__puiOwn(prior, 'default')) next[key].default = prior.default;
      } else next[key] = { ...spec };
    }
    specs = next; resolved = resolveProps(raw, false).snapshot;
  };
  /** @param {__puiPropsWatcher<typeof run>} watch */
  const registerPropsWatch = (watch) => {
    setupOnly();
    const { kind, keys } = watch;
    if (keys !== null && (!keys.length || keys.some((key) => typeof key !== 'string'
      || kind === 'resolved' && !__puiOwn(specs, key)))) throw new Error('[Vue2 native] watch requires non-empty valid prop keys.');
    watch.keys = keys === null ? null : [...keys];
    watchers.push(watch);
    return () => { watch.active = false; };
  };
  /** @type {readonly __puiLifecycleKind[]} */
  const lifecycleKeys = ["created","mounted","updated","unmounted","beforeDispose"];
  const def = {
    context: { provide: (/** @param {object} key @param {unknown} value */ (key, value) => { setupOnly(); contextScope.provide(key, value); }), subscribe: (/** @param {object} key @param {(run: __puiRun, next: unknown, previous: unknown) => void} [fn] */ (key, fn) => { setupOnly(); return contextScope.subscribe(key, 'required', fn ? (next, prev) => fn(run, next, prev) : undefined); }), trySubscribe: (/** @param {object} key @param {(run: __puiRun, next: unknown, previous: unknown) => void} [fn] */ (key, fn) => { setupOnly(); return contextScope.subscribe(key, 'optional', fn ? (next, prev) => fn(run, next, prev) : undefined); }) },
    feedback: { style },
    event: interaction.event,
    props: {
      define: defineProps,
      setDefaults: (/** @param {__puiRawProps} layer */ (layer) => {
        setupOnly();
        for (const key of Object.keys(layer)) if (!__puiOwn(specs, key) || !__puiJson(layer[key])) throw new Error('[Vue2 native] invalid prop default: ' + key);
        defaults.unshift({ ...layer }); resolved = resolveProps(raw, false).snapshot;
      }),
      /** @param {readonly string[]} keys @param {__puiPropsWatchCallback<typeof run, __puiResolvedProps>} fn */
      watch: (keys, fn) => registerPropsWatch({ kind: 'resolved', keys, fn, active: true }),
      /** @param {__puiPropsWatchCallback<typeof run, __puiResolvedProps>} fn */
      watchAll: (fn) => registerPropsWatch({ kind: 'resolved-all', keys: null, fn, active: true }),
      /** @param {readonly string[]} keys @param {__puiPropsWatchCallback<typeof run, __puiRawProps>} fn */
      watchRaw: (keys, fn) => registerPropsWatch({ kind: 'raw', keys, fn, active: true }),
      /** @param {__puiPropsWatchCallback<typeof run, __puiRawProps>} fn */
      watchRawAll: (fn) => registerPropsWatch({ kind: 'raw-all', keys: null, fn, active: true }),
    },
    state: {
      /** @param {string} key @param {boolean} value */
      bool: (key, value) => createState('bool', key, value),
      /** @param {string} key @param {string} value @param {__puiStateConfiguration} [spec] */
      string: (key, value, spec) => createState('string', key, value, spec),
      /** @param {string} key @param {string} value @param {__puiStateConfiguration} [spec] */
      enum: (key, value, spec) => createState('enum', key, value, spec),
      /** @param {string} key @param {number} value @param {__puiStateConfiguration} [spec] */
      numberDiscrete: (key, value, spec) => createState('number.discrete', key, value, spec),
      /** @param {string} key @param {number} value @param {__puiStateConfiguration} spec */
      numberRange: (key, value, spec) => createState('number.range', key, value, spec),
    },
    expose: {
      /** @param {string} key @param {unknown} value */
      value: (key, value) => { setupOnly(); if (__puiOwn(exposed, key)) throw new Error('[Expose] duplicate declaration'); exposed[key] = value; },
      /** @template T @param {string} key @param {{get(): T}} handle */
      state: (key, handle) => { setupOnly(); exposed[key] = externalState(handle); __puiAuthored.introduceObserved(handle); },
      /** @template {unknown[]} Args @template Result @param {string} key @param {(...args: Args) => Result} fn @param {(value: Result) => Result} [project] */
      method: (key, fn, project) => { setupOnly();  exposed[key] = (/** @param {Args} args */ (...args) => { publicAlive(); const result = invoke(() => fn(...args)); return project ? project(result) : result; }); },
      /** @param {string} key @param {unknown} [spec] */
      event: (key, spec) => { setupOnly(); eventDeclarations[key] = spec; },
    },
    lifecycle: Object.fromEntries(lifecycleKeys.map((key) => {
      /** @type {[string, (fn: __puiLifecycleCallback<typeof run>) => void]} */
      const entry = ['on' + key[0].toUpperCase() + key.slice(1), (fn) => { setupOnly(); lifecycle[key].push(fn); }];
      return entry;
    })),
  };
  /** @param {__puiLifecycleKind} kind */
  const fire = (kind) => invoke(() => { if (kind === 'unmounted') {  } try { for (const fn of lifecycle[kind]) fn(run); } finally { if (kind === 'unmounted') {  } } }, !terminal);
  const detach = () => {
    if (!viewActive) return;
    viewActive = false; pending = null; queued = false;
    
    interaction.unmount();
    style.unmount();
    if (activeRoot) activeRoot.removeAttribute('data-pui-style');
    activeRoot = null;
    fire('unmounted');
  };
  const afterCommit = () => {
    if (terminal) return;
    syncHost(true);
    const commit = renderedCommit;
    if (!commit) return;
    renderedCommit = null;
    const target = vm.$el;
    // Removal has already committed when Vue calls updated. Do not postpone its
    // unmount notification into a tick which may belong to a replacement view.
    if (!commit.present && commit.vnode.elm === target) { detach(); return; }
    vm.$nextTick(() => {
      if (terminal || commit.epoch !== epoch || commit.version !== commitVersion || vm.$el !== target || commit.vnode.elm !== target) return;
      if (!present || !hostActive) return;
      const elementType = target.ownerDocument.defaultView?.HTMLElement;
      if (!elementType || !(target instanceof elementType)) throw new Error('[Vue2 native] interaction Root must be an HTML element.');
      
      const kind = commit.kind;
      if (kind === 'mount' && !viewActive) {
        viewActive = true;
        activeRoot = target;
        activeEpoch = epoch;
        
        interaction.mount();
        // The native editor now owns value and composition for this view lease.
        // Vue clears an old domProp when the next VNode omits it; retire the
        // initial transport property before any ordinary host repaint.
        if (commit.vnode.data?.domProps) delete commit.vnode.data.domProps.value;
        if (terminal || commit.epoch !== epoch || !present || !hostActive) return;
        style.mount();
        
        fire('mounted');
        
      } else if (viewActive) {
        
        if (activeRoot !== target || activeEpoch !== epoch) {
          activeRoot = target; activeEpoch = epoch;
          interaction.mount();
        }
        if (terminal || commit.epoch !== epoch || !present || !hostActive) return;
        if (kind !== 'update' || !pending || pending.revision !== commit.revision) return;
        pending = null;
        const again = queued; queued = false;
        fire('updated');
        if (again && present && viewActive && !terminal && !pending) update();
      }
    });
  };
  const owner = {
    
    authored: __puiAuthored,
    meta: __puiMeta,
    contextScope,
    host() { return viewActive && present && hostActive && !terminal ? vm.$el : null; },
    interaction,
    def,
    get resolvedProps() { return resolved; },
    
    initialize() {
      
      try {
        renderFunction = setup(owner);
        if (typeof renderFunction !== 'function') renderFunction = (renderer) => renderer.slot();
        phase = 'idle';
        syncHost(false);
        fire('created');
         unwatch = vm.$watch(() => ({ props: hostRaw(), associations: __puiNormalizeAssociations(vm.instanceAssociations, (/** @type {{_base?: {observable?: (value: object) => object}}} */ (vm.$options))._base?.observable) }), () => syncHost(true), { deep: true });
      } catch (error) {
        
        terminal = true;
        try { interaction.dispose(); } catch {}
        for (const state of states) { try { state.dispose(); } catch {} }
        try { style.dispose(); } catch {}
        try { contextScope.dispose(); } catch {}
        disposed = true;
        phase = 'idle';
        throw error;
      }
    },
    hostMounted() {  nativeMounted = true; afterCommit(); },
    afterCommit,
    /** @param {import('vue').CreateElement} h */
    render(h) {
      
      if (terminal || !present || !hostActive) {
        const vnode = h();
        renderedCommit = { epoch, version: ++commitVersion, present: false, vnode, kind: 'detach' };
        return vnode;
      }
      if (!viewActive) renderSemantic();
      const tag = interaction.rootTag() || rootTag;
      const children = template ? template(h, vm, { used: false }) : [];
      if (['input', 'textarea', 'img'].includes(tag) && children.length) throw new Error('[Template] physical control Root requires empty children.');
      const vnode = h(tag, __puiRootData(interaction.rootProperties(), { 'data-pui-root': '' }, !viewActive), children);
      renderedCommit = { epoch, version: ++commitVersion, present: true, vnode, kind: !viewActive ? 'mount' : pending ? 'update' : 'none', revision: pending && pending.revision };
      return vnode;
    },
    update,
    getExposes() { if (terminal) return {}; return { ...exposed }; },
    /** @template T @param {() => T} fn @returns {T} */
    invokePublic(fn) { publicAlive(); return invoke(fn); },
    deactivate() {
      if (terminal || !hostActive) return;
      hostActive = false; ++epoch; renderedCommit = null; pending = null; queued = false;
      detach();
    },
    activate() {
      if (terminal || hostActive) return;
      hostActive = true; ++epoch; pending = null; renderedCommit = null;
      vm.$forceUpdate();
    },
    dispose() {
      if (terminal) return;
      terminal = true; ++epoch; renderedCommit = null; pending = null; queued = false;
      for (const off of __puiAuthoredWatchCleanups.splice(0)) off();
      unwatch?.(); unwatch = undefined;
      /** @type {{ error: unknown } | undefined} */ let failure;
      try { detach(); } catch (error) { failure = { error }; }
       try {
        fire('beforeDispose');
      } catch (error) { failure ??= { error }; }
      for (const state of states) {
        try { state.dispose(); } catch (error) { failure ??= { error }; }
      }
      try { contextScope.dispose(); } catch (error) { failure ??= { error }; }
      try { interaction.dispose(); } catch (error) { failure ??= { error }; }
      try { style.dispose(); } catch (error) { failure ??= { error }; }
      const target = vm.$el;
      if (target && target.nodeType === 1 && target.hasAttribute('data-pui-root')) target.removeAttribute('data-pui-style');
      __puiAuthored.dispose();
      disposed = true; phase = 'idle';
      watchers.length = 0; notifications.length = 0; states.length = 0; defaults.length = 0;
      for (const callbacks of Object.values(lifecycle)) callbacks.length = 0;
      for (const key of Object.keys(exposed)) delete exposed[key];
      for (const key of Object.keys(eventDeclarations)) delete eventDeclarations[key];
      specs = Object.create(null); previousValid = Object.create(null); raw = Object.freeze({}); resolved = /** @type {__puiResolvedProps} */ (Object.freeze({})); template = renderFunction = null;
      
      if (failure) throw failure.error;
    },
  };
  return owner;
}


/** @param {__puiOwner} __puiOwner */
function __puiSetup(__puiOwner) {

  const __puiAuthored = __puiOwner.authored;
  const __puiMeta = __puiOwner.meta;
  const __puiHook0 = /** @param {unknown} [options] */ (options) => /** @type {{ readonly stateHandles?: Readonly<Record<string, unknown>>; readonly getState?: (name: string) => unknown; readonly getMethod?: (name: string) => unknown; readonly getAsHook?: (name: string) => unknown; readonly getAsHookHandle?: (name: string) => unknown; readonly render?: unknown }} */ (__puiAuthored.install({name: "as-button", mode: "once", setup: (options, api) => (/** @param {__puiOwner['def']} def */ (def) => {
    // Source "packages/prototypes/base/src/button/button.proto.ts":12:3
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = {"kind":"tw","tokens":["select-none"],"groups":["content-selection affordance"]};
const __puiCaptureResult = __puiCaptureReceiver.feedback.style.use(__puiCaptureArg0); __puiAuthored.effect("feedback", __puiCaptureResult); __puiAuthored.disposer("feedback", __puiCaptureResult); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":13:9
    const accessible = __puiAuthored.privileged("asAccessible", () => __puiOwner.interaction.asAccessible());
    // Source "packages/prototypes/base/src/button/button.proto.ts":15:3
    __puiAuthored.privileged("asTrigger", () => __puiOwner.interaction.asTrigger());
    // Source "packages/prototypes/base/src/button/button.proto.ts":18:3
    (() => {
const __puiCaptureReceiver = def;
/** @type {Parameters<typeof __puiCaptureReceiver.props.define>[0]} */ const __puiCaptureArg0 = { ["disabled"]: { ["type"]: "boolean", ["empty"]: "fallback" } };
const __puiCaptureResult = __puiCaptureReceiver.props.define(__puiCaptureArg0); __puiAuthored.effect("props", {"op": "define", "specMap": __puiCaptureArg0}); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":21:3
    (() => {
const __puiCaptureReceiver = def;
/** @type {{ "disabled": boolean }} */ const __puiCaptureArg0 = { ["disabled"]: false };
const __puiCaptureResult = __puiCaptureReceiver.props.setDefaults(__puiCaptureArg0); __puiAuthored.effect("props", {"op": "setDefaults", "partial": __puiCaptureArg0}); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":26:9
    const disabled = (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "disabled";
const __puiCaptureArg1 = false;
const __puiCaptureResult = __puiCaptureReceiver.state.bool(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", __puiCaptureResult); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":27:3
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "disabled";
const __puiCaptureArg1 = disabled;
const __puiCaptureResult = __puiCaptureReceiver.expose.state(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", {"op": "expose.state", "key": __puiCaptureArg0, "handle": __puiCaptureArg1}); __puiAuthored.introduceObserved(__puiCaptureArg1); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":28:3
    (() => {
const __puiCaptureReceiver = accessible;
const __puiCaptureArg0 = "disabled";
const __puiCaptureArg1 = disabled;
const __puiCaptureResult = __puiCaptureReceiver.state(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", {"op": "a11y.state", "key": __puiCaptureArg0, "handle": __puiCaptureArg1, "options": undefined}); __puiAuthored.introduceObserved(__puiCaptureArg1); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":31:9
    const hovered = (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "hovered";
const __puiCaptureArg1 = false;
const __puiCaptureResult = __puiCaptureReceiver.state.bool(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", __puiCaptureResult); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":32:3
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "hovered";
const __puiCaptureArg1 = hovered;
const __puiCaptureResult = __puiCaptureReceiver.expose.state(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", {"op": "expose.state", "key": __puiCaptureArg0, "handle": __puiCaptureArg1}); __puiAuthored.introduceObserved(__puiCaptureArg1); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":35:9
    const focusable = __puiAuthored.privileged("asFocusable", () => __puiOwner.interaction.asFocusable(), ["focused","focusVisible","focusable"]);
    // Source "packages/prototypes/base/src/button/button.proto.ts":36:3
    focusable.configure({ ["disabled"]: false });
    // Source "packages/prototypes/base/src/button/button.proto.ts":38:9
    const focused = (focusable)["focused"];
    // Source "packages/prototypes/base/src/button/button.proto.ts":39:9
    const focusVisible = (focusable)["focusVisible"];
    // Source "packages/prototypes/base/src/button/button.proto.ts":42:3
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "focused";
const __puiCaptureArg1 = focused;
const __puiCaptureResult = __puiCaptureReceiver.expose.state(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", {"op": "expose.state", "key": __puiCaptureArg0, "handle": __puiCaptureArg1}); __puiAuthored.introduceObserved(__puiCaptureArg1); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":43:3
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "focusVisible";
const __puiCaptureArg1 = focusVisible;
const __puiCaptureResult = __puiCaptureReceiver.expose.state(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", {"op": "expose.state", "key": __puiCaptureArg0, "handle": __puiCaptureArg1}); __puiAuthored.introduceObserved(__puiCaptureArg1); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":46:3
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "focusSelf";
const __puiCaptureArg1 = /** @param {{ "reason"?: "programmatic" | "keyboard" | "pointer"; "preventScroll"?: boolean }} [options] @returns {void} */ (options) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":47:5
      if (/** @type {boolean} */ (disabled.get())) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":47:25
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":48:5
      focusable.focusSelf(options);
    };
const __puiCaptureResult = __puiCaptureReceiver.expose.method(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("context", {"op": "expose.method", "key": __puiCaptureArg0, "fn": __puiCaptureArg1}); __puiAuthored.method(__puiCaptureArg0, __puiCaptureArg1); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":52:9
    const pressed = (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "pressed";
const __puiCaptureArg1 = false;
const __puiCaptureResult = __puiCaptureReceiver.state.bool(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", __puiCaptureResult); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":53:3
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "pressed";
const __puiCaptureArg1 = pressed;
const __puiCaptureResult = __puiCaptureReceiver.expose.state(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", {"op": "expose.state", "key": __puiCaptureArg0, "handle": __puiCaptureArg1}); __puiAuthored.introduceObserved(__puiCaptureArg1); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":55:9
    const clearTransientInteraction = /** @param {string} reason @returns {void} */ (reason) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":56:5
      hovered.set(false, reason);
      // Source "packages/prototypes/base/src/button/button.proto.ts":57:5
      pressed.set(false, reason);
    };
    // Source "packages/prototypes/base/src/button/button.proto.ts":61:3
    def.lifecycle.onUnmounted(() => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":62:5
      (clearTransientInteraction)("reason: button view unmounted => reset transient interaction");
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":66:9
    const syncDisabled = /** @param {boolean} nextDisabled @returns {void} */ (nextDisabled) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":67:5
      disabled.set(nextDisabled, "reason: sync disabled");
      // Source "packages/prototypes/base/src/button/button.proto.ts":68:5
      focusable.setDisabled(nextDisabled);
      // Source "packages/prototypes/base/src/button/button.proto.ts":69:5
      if (nextDisabled) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":70:7
        (clearTransientInteraction)("reason: button disabled => reset transient interaction");
      }
    };
    // Source "packages/prototypes/base/src/button/button.proto.ts":73:3
    def.lifecycle.onCreated(/** @param {__puiRun} run */ (run) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":74:5
      (syncDisabled)((run.props.get())["disabled"]);
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":76:3
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = ["disabled"];
const __puiCaptureArg1 = /** @param {__puiRun} _run @param {__puiResolvedProps} next */ (_run, next) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":77:5
      (syncDisabled)((next)["disabled"]);
    };
const __puiCaptureResult = __puiCaptureReceiver.props.watch(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("props", {"op": "watch", "keys": __puiCaptureArg0, "off": __puiCaptureResult}); __puiAuthored.disposer("props", __puiCaptureResult); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":81:3
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "click";
/** @type {{ "payload": string }} */ const __puiCaptureArg1 = { ["payload"]: "void" };
const __puiCaptureResult = __puiCaptureReceiver.expose.event(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("event", {"op": "expose.event", "key": __puiCaptureArg0, "spec": __puiCaptureArg1}); __puiAuthored.eventKey(__puiCaptureArg0); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":83:3
    accessible.action("activate", { ["event"]: "click" });
    // Source "packages/prototypes/base/src/button/button.proto.ts":86:3
    accessible.role("button");
    // Source "packages/prototypes/base/src/button/button.proto.ts":89:3
    accessible.nameFromContent();
    // Source "packages/prototypes/base/src/button/button.proto.ts":91:9
    const activate = /** @param {__puiRun} run @param {() => boolean} isCurrent @returns {void} */ (run, isCurrent = /**  @returns {boolean} */ () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":91:83
      return true;
    }) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":92:5
      if ((/** @type {boolean} */ (disabled.get()) || (!(isCurrent)()))) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":92:41
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":93:5
      pressed.set(false, "reason: button activation => pressed");
      // Source "packages/prototypes/base/src/button/button.proto.ts":94:5
      if ((/** @type {boolean} */ (disabled.get()) || (!(isCurrent)()))) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":94:41
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":95:5
      run.expose.emit("click");
    };
    // Source "packages/prototypes/base/src/button/button.proto.ts":97:3
    __puiAuthored.privileged("asControlLabel", () => __puiOwner.interaction.asControlLabel()).target(/** @param {__puiRun} run @param {import("./.proto-ui/interaction/modules-e6807d4f71af1465-v2").NativeModuleCapability<"control-label-request", __puiRun>} request */ (run, request) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":98:11
      const isCurrent = /**  @returns {boolean} */ () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":98:29
        return ((!/** @type {boolean} */ (disabled.get())) && request.isCurrent());
      };
      // Source "packages/prototypes/base/src/button/button.proto.ts":99:5
      if ((!(isCurrent)())) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":99:23
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":100:5
      focusable.focusSelf({ ["reason"]: (((request)["source"] === "pointer") ? "pointer" : "programmatic") });
      // Source "packages/prototypes/base/src/button/button.proto.ts":101:5
      if ((isCurrent)()) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":101:22
        (activate)(run, isCurrent);
      }
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":107:3
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "key.down";
const __puiCaptureArg1 = /** @param {__puiRun} _run @param {__puiNativeInput} ev */ (_run, ev) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":108:11
      const detail = ev;
      // Source "packages/prototypes/base/src/button/button.proto.ts":109:5
      if (/** @type {boolean} */ (disabled.get())) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":109:25
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":110:5
      if ((!/** @type {boolean} */ (focused.get()))) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":110:25
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":111:5
      if (((detail)?.["key"] !== " ")) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":111:30
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":112:5
      ev.control.requestDefaultActionPrevention({ ["reason"]: "button.space-activation", ["source"]: "base-button" });
    };
const __puiCaptureResult = __puiCaptureReceiver.event.onGlobal(__puiCaptureArg0, __puiCaptureArg1); const __puiCaptureOff = () => __puiOwner.interaction.releaseListener(__puiCaptureResult); __puiAuthored.effect("event", {token: __puiCaptureResult, off: __puiCaptureOff}); __puiAuthored.disposer("event", __puiCaptureOff); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":119:3
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "pointer.enter";
const __puiCaptureArg1 = () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":120:5
      if (/** @type {boolean} */ (disabled.get())) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":120:25
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":121:5
      hovered.set(true, "reason: button pointer.enter => hovered");
    };
const __puiCaptureResult = __puiCaptureReceiver.event.on(__puiCaptureArg0, __puiCaptureArg1); const __puiCaptureOff = () => __puiOwner.interaction.releaseListener(__puiCaptureResult); __puiAuthored.effect("event", {token: __puiCaptureResult, off: __puiCaptureOff}); __puiAuthored.disposer("event", __puiCaptureOff); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":123:3
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "pointer.leave";
const __puiCaptureArg1 = () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":124:5
      hovered.set(false, "reason: button pointer.leave => hovered");
      // Source "packages/prototypes/base/src/button/button.proto.ts":125:5
      pressed.set(false, "reason: button pointer.leave => pressed");
    };
const __puiCaptureResult = __puiCaptureReceiver.event.on(__puiCaptureArg0, __puiCaptureArg1); const __puiCaptureOff = () => __puiOwner.interaction.releaseListener(__puiCaptureResult); __puiAuthored.effect("event", {token: __puiCaptureResult, off: __puiCaptureOff}); __puiAuthored.disposer("event", __puiCaptureOff); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":127:3
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "pointer.cancel";
const __puiCaptureArg1 = () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":128:5
      hovered.set(false, "reason: button pointer.cancel => hovered");
      // Source "packages/prototypes/base/src/button/button.proto.ts":129:5
      pressed.set(false, "reason: button pointer.cancel => pressed");
    };
const __puiCaptureResult = __puiCaptureReceiver.event.on(__puiCaptureArg0, __puiCaptureArg1); const __puiCaptureOff = () => __puiOwner.interaction.releaseListener(__puiCaptureResult); __puiAuthored.effect("event", {token: __puiCaptureResult, off: __puiCaptureOff}); __puiAuthored.disposer("event", __puiCaptureOff); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":132:3
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "press.cancel";
const __puiCaptureArg1 = () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":133:5
      (clearTransientInteraction)("reason: button press.cancel => reset transient interaction");
    };
const __puiCaptureResult = __puiCaptureReceiver.event.on(__puiCaptureArg0, __puiCaptureArg1); const __puiCaptureOff = () => __puiOwner.interaction.releaseListener(__puiCaptureResult); __puiAuthored.effect("event", {token: __puiCaptureResult, off: __puiCaptureOff}); __puiAuthored.disposer("event", __puiCaptureOff); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":137:3
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "pointer.down";
const __puiCaptureArg1 = () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":138:5
      if (/** @type {boolean} */ (disabled.get())) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":138:25
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":139:5
      pressed.set(true, "reason: button pointer.down => pressed");
    };
const __puiCaptureResult = __puiCaptureReceiver.event.on(__puiCaptureArg0, __puiCaptureArg1); const __puiCaptureOff = () => __puiOwner.interaction.releaseListener(__puiCaptureResult); __puiAuthored.effect("event", {token: __puiCaptureResult, off: __puiCaptureOff}); __puiAuthored.disposer("event", __puiCaptureOff); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":141:3
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "pointer.up";
const __puiCaptureArg1 = () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":142:5
      pressed.set(false, "reason: button pointer.up => pressed");
    };
const __puiCaptureResult = __puiCaptureReceiver.event.on(__puiCaptureArg0, __puiCaptureArg1); const __puiCaptureOff = () => __puiOwner.interaction.releaseListener(__puiCaptureResult); __puiAuthored.effect("event", {token: __puiCaptureResult, off: __puiCaptureOff}); __puiAuthored.disposer("event", __puiCaptureOff); return __puiCaptureResult; })();
    // Source "packages/prototypes/base/src/button/button.proto.ts":146:3
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "press.commit";
const __puiCaptureArg1 = /** @param {__puiRun} run */ (run) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":147:5
      pressed.set(false, "reason: button press.commit => pressed");
      // Source "packages/prototypes/base/src/button/button.proto.ts":148:5
      (activate)(run);
    };
const __puiCaptureResult = __puiCaptureReceiver.event.on(__puiCaptureArg0, __puiCaptureArg1); const __puiCaptureOff = () => __puiOwner.interaction.releaseListener(__puiCaptureResult); __puiAuthored.effect("event", {token: __puiCaptureResult, off: __puiCaptureOff}); __puiAuthored.disposer("event", __puiCaptureOff); return __puiCaptureResult; })();
  })(__puiOwner.def)}, options));
  (/** @param {__puiOwner['def']} def */ (def) => {
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":77:5
    (() => {
const __puiCaptureReceiver = def;
/** @type {Parameters<typeof __puiCaptureReceiver.props.define>[0]} */ const __puiCaptureArg0 = { ["variant"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["solid", "surface", "destructive"] }, ["color"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["main", "mint", "lavender", "coral", "sky"] }, ["size"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["default", "sm", "lg", "icon"] }, ["wrap"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["disabled"]: { ["type"]: "boolean", ["empty"]: "fallback" } };
const __puiCaptureResult = __puiCaptureReceiver.props.define(__puiCaptureArg0); __puiAuthored.effect("props", {"op": "define", "specMap": __puiCaptureArg0}); return __puiCaptureResult; })();
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":94:5
    (() => {
const __puiCaptureReceiver = def;
/** @type {{ "variant": string; "color": string; "size": string; "wrap": boolean; "disabled": boolean }} */ const __puiCaptureArg0 = { ["variant"]: "solid", ["color"]: "main", ["size"]: "default", ["wrap"]: false, ["disabled"]: false };
const __puiCaptureResult = __puiCaptureReceiver.props.setDefaults(__puiCaptureArg0); __puiAuthored.effect("props", {"op": "setDefaults", "partial": __puiCaptureArg0}); return __puiCaptureResult; })();
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":103:11
    const buttonState = /** @type {{ readonly "disabled": __puiOwnedState<boolean> & {watch(callback: (run: __puiRun, event: __puiStateEvent<boolean>) => void): () => void}; readonly "hovered": __puiOwnedState<boolean> & {watch(callback: (run: __puiRun, event: __puiStateEvent<boolean>) => void): () => void}; readonly "focused": __puiNativeObservedState<boolean>; readonly "focusVisible": __puiNativeObservedState<boolean>; readonly "pressed": __puiOwnedState<boolean> & {watch(callback: (run: __puiRun, event: __puiStateEvent<boolean>) => void): () => void} }} */ ((__puiHook0())["stateHandles"]);
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":104:5
    if ((!buttonState)) {
      // Source "packages/prototypes/brutalist/src/button/button.proto.ts":105:7
      throw new Error("[brutalist-button] asButton must project Button state handles.");
    }
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":107:13
    const disabled = (buttonState)["disabled"];
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":107:23
    const hovered = (buttonState)["hovered"];
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":107:32
    const focusVisible = (buttonState)["focusVisible"];
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":107:46
    const pressed = (buttonState)["pressed"];
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":109:5
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = {"kind":"tw","tokens":["group/brutalist-button","inline-flex","shrink-0","items-center","justify-center","gap-2","font-sans","font-medium","rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium"],"groups":["group/brutalist-button","display","shrink-0","items-","justify-","gap-2","font-sans","font weight","rounded","border-width","border-color","shadow-","font-sans","font weight"]};
const __puiCaptureResult = __puiCaptureReceiver.feedback.style.use(__puiCaptureArg0); __puiAuthored.effect("feedback", __puiCaptureResult); __puiAuthored.disposer("feedback", __puiCaptureResult); return __puiCaptureResult; })();
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":114:5
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => (__puiOwner.def.feedback.style.meta("preference.reducedMotion") === "no-preference"), [{"kind":"tw","tokens":["transition-all"],"groups":["transition-"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":118:5
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => !((__puiOwner.def.feedback.style.meta("preference.reducedMotion") === "no-preference")), [{"kind":"tw","tokens":["transition-none"],"groups":["transition-"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => ((__puiOwner.resolvedProps["variant"] === "solid") && (__puiOwner.resolvedProps["color"] === "main")), [{"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-main","text-main-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => ((__puiOwner.resolvedProps["variant"] === "solid") && (__puiOwner.resolvedProps["color"] === "mint")), [{"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-mint","text-mint-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => ((__puiOwner.resolvedProps["variant"] === "solid") && (__puiOwner.resolvedProps["color"] === "lavender")), [{"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-lavender","text-lavender-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => ((__puiOwner.resolvedProps["variant"] === "solid") && (__puiOwner.resolvedProps["color"] === "coral")), [{"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-coral","text-coral-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => ((__puiOwner.resolvedProps["variant"] === "solid") && (__puiOwner.resolvedProps["color"] === "sky")), [{"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-sky","text-sky-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":134:9
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => (__puiOwner.resolvedProps["variant"] === "surface"), [{"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-secondary-background","text-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":134:9
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => (__puiOwner.resolvedProps["variant"] === "destructive"), [{"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-destructive","text-destructive-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":143:7
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => ((__puiOwner.resolvedProps["size"] === "default") && (__puiOwner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-10","px-4","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":143:7
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => ((__puiOwner.resolvedProps["size"] === "sm") && (__puiOwner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-9","px-3","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":143:7
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => ((__puiOwner.resolvedProps["size"] === "lg") && (__puiOwner.resolvedProps["wrap"] === false)), [{"kind":"tw","tokens":["h-11","px-8","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":143:7
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => (__puiOwner.resolvedProps["size"] === "icon"), [{"kind":"tw","tokens":["size-10","whitespace-nowrap"],"groups":["size-10","whitespace-nowrap"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":154:7
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => ((__puiOwner.resolvedProps["size"] === "default") && (__puiOwner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-10","h-auto","px-4","py-1","text-sm","whitespace-normal","min-w-0","max-w-full","wrap-anywhere","text-center"],"groups":["min-h-","h-","px-","py-","text-size","whitespace-normal","min-w-","max-w-","wrap-anywhere","text-align"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":154:7
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => ((__puiOwner.resolvedProps["size"] === "sm") && (__puiOwner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-9","h-auto","px-3","py-1","text-sm","whitespace-normal","min-w-0","max-w-full","wrap-anywhere","text-center"],"groups":["min-h-","h-","px-","py-","text-size","whitespace-normal","min-w-","max-w-","wrap-anywhere","text-align"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":154:7
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => ((__puiOwner.resolvedProps["size"] === "lg") && (__puiOwner.resolvedProps["wrap"] === true)), [{"kind":"tw","tokens":["min-h-11","h-auto","px-8","py-1","text-sm","whitespace-normal","min-w-0","max-w-full","wrap-anywhere","text-center"],"groups":["min-h-","h-","px-","py-","text-size","whitespace-normal","min-w-","max-w-","wrap-anywhere","text-align"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":161:5
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => (hovered.get() === true), [{"kind":"tw","tokens":["translate-x-1","translate-y-1","shadow-none","relative","hit-envelope-translate-1"],"groups":["translate-x-","translate-y-","shadow-","relative","hit-envelope-translate-1"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":167:5
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => (pressed.get() === true), [{"kind":"tw","tokens":["translate-x-1","translate-y-1","shadow-none","relative","hit-envelope-translate-1"],"groups":["translate-x-","translate-y-","shadow-","relative","hit-envelope-translate-1"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":173:5
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => (focusVisible.get() === true), [{"kind":"tw","tokens":["outline-none","ring-2","ring-ring","ring-offset-2","ring-offset-background"],"groups":["outline-none","ring-2","ring-ring","ring-offset-2","ring-offset-background"]}]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":178:5
    __puiAuthored.rule(__puiOwner.def.feedback.style.rule(() => (disabled.get() === true), [{"kind":"tw","tokens":["pointer-events-none","opacity-50"],"groups":["pointer-events-none","opacity-"]}]));
  })(__puiOwner.def); return;
}

/** @typedef {import('vue').default & { readonly "__puiOwner": ReturnType<typeof __puiCreateOwner>; readonly "__puiParentScope"?: ReturnType<typeof __puiCreateContextScope> | null }} __puiNativeInstance */
export const BrutalistButton = {
  name: "brutalist-button",
  inheritAttrs: false,
  props: { instanceAssociations: { type: Object, default: undefined }, ["variant"]: {}, ["color"]: {}, ["size"]: {}, ["wrap"]: {}, ["disabled"]: {} },
  inject: { ["__puiParentScope"]: { from: __puiScopeKey, default: null } },
  /** @this {__puiNativeInstance} */
  provide() { return { [__puiScopeKey]: this["__puiOwner"].contextScope }; },
  /** @this {__puiNativeInstance} */
  beforeCreate() {
    Object.defineProperty(this, "__puiOwner", { value: __puiCreateOwner(this, __puiSetup, {"variant":{"kind":"union","members":[{"kind":"literal","value":"solid"},{"kind":"literal","value":"surface"},{"kind":"literal","value":"destructive"}]},"color":{"kind":"union","members":[{"kind":"literal","value":"main"},{"kind":"literal","value":"mint"},{"kind":"literal","value":"lavender"},{"kind":"literal","value":"coral"},{"kind":"literal","value":"sky"}]},"size":{"kind":"union","members":[{"kind":"literal","value":"default"},{"kind":"literal","value":"sm"},{"kind":"literal","value":"lg"},{"kind":"literal","value":"icon"}]},"wrap":"boolean","disabled":"boolean"}, "div", true) });
    
  },
  /** @this {__puiNativeInstance} */
  created() { this["__puiOwner"].initialize(); },
  /** @this {__puiNativeInstance} */
  mounted() { this["__puiOwner"].hostMounted(); },
  /** @this {__puiNativeInstance} */
  updated() { this["__puiOwner"].afterCommit(); },
  /** @this {__puiNativeInstance} */
  activated() { this["__puiOwner"].activate(); },
  /** @this {__puiNativeInstance} */
  deactivated() { this["__puiOwner"].deactivate(); },
  /** @this {__puiNativeInstance} */
  beforeDestroy() { this["__puiOwner"].dispose(); },
  methods: {
    /** @this {__puiNativeInstance} */
    update() { this["__puiOwner"].update(); },
    /** @this {__puiNativeInstance} */
    getExposes() { return this["__puiOwner"].getExposes(); },
    /** @this {__puiNativeInstance} @template T @param {() => T} callback */
    invokeInCallbackScope(callback) { return this["__puiOwner"].invokePublic(callback); },
  },
  /** @this {__puiNativeInstance} @param {import('vue').CreateElement} h */
  render(h) { return this["__puiOwner"].render(h); },
};
export default BrutalistButton;


//# sourceMappingURL=BrutalistButton.js.map
