/** Native invalidation registration; acquire/release always use one captured complete API pair. */
export function nativeMediaBinding(query: MediaQueryList | undefined, notify: () => void): { attach(): void; release(): void } | undefined {
  if (!query) return;
  const add = query.addEventListener, remove = query.removeEventListener;
  if (typeof add === 'function' && typeof remove === 'function') return {
    attach: () => add.call(query, 'change', notify), release: () => remove.call(query, 'change', notify),
  };
  const legacyAdd = query.addListener, legacyRemove = query.removeListener;
  if (typeof legacyAdd === 'function' && typeof legacyRemove === 'function') return {
    attach: () => legacyAdd.call(query, notify), release: () => legacyRemove.call(query, notify),
  };
}
export function releaseNativeMeta(releases: readonly (() => void)[]): void {
  const failures: unknown[] = [];
  for (const release of releases) { try { release(); } catch (error) { failures.push(error); } }
  if (failures.length === 1) throw failures[0];
  if (failures.length) throw new AggregateError(failures, 'Native Meta cleanup failed.');
}
