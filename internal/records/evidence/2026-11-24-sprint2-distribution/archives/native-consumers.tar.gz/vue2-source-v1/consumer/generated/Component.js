// Editable generated Vue 2.6.14 component options. Profile: vue2-source-v1.
// Inline native-lowering helpers: logical owner, prop resolution, state, semantic templates.
// No Proto-UI Core, Runtime, Hooks or Adapter dependency; optional native helpers are emitted artifacts.
// Source graph SHA-256: 8ed275a3b6f73ef96e34a9933a1ec6b8d79fcba7f5dc6631cc751fbd53769408




import { createNativeStyle as __puiCreateNativeStyle, templateStyleTokens as __puiTemplateStyleTokens } from './.proto-ui/style/native-v1';
import { createContextScope as __puiCreateContextScope, scopeKey as __puiScopeKey, acceptsContextValue as __puiAcceptsContextValue } from './.proto-ui/context/scope-v1';




/** @typedef {{
  "seed"?: number | null;
  "visible"?: boolean | null;
  "active"?: boolean | null;
  "patch"?: number | null;
}} GeneratedProps */
/** @typedef {Readonly<{
  readonly "seed": number;
  readonly "visible": boolean;
  readonly "active": boolean;
  readonly "patch": number;
} & Record<string, unknown>>} __puiResolvedProps */
/** @typedef {{
  "count": __puiExternalState<number>;
  "write": (next: number) => void;
  "read": () => number;
}} GeneratedExposes */
/** @typedef {Array<import('vue').VNode | string>} __puiNativeChildren */
/** @typedef {{ used: boolean }} __puiNativeSlotFrame */
/** @typedef {(h: import('vue').CreateElement, vm: import('vue').default, slots: __puiNativeSlotFrame) => __puiNativeChildren} __puiNativePaint */
/** @typedef {{
 * slot: () => __puiNativePaint,
 * read: {
 *   props: {
 *     get: () => __puiResolvedProps,
 *     getRaw: () => Readonly<Record<string, unknown>>,
 *     isProvided: (key: PropertyKey) => boolean
 *   },
 *   context: {
 *     read: (key: object) => ReturnType<import('./.proto-ui/context/scope-v1').ContextScope['read']>,
 *     tryRead: (key: object) => ReturnType<import('./.proto-ui/context/scope-v1').ContextScope['tryRead']>
 *   }
 * }
 * }} __puiNativeRenderer */
/** @typedef {import('./.proto-ui/style/native-v1').NativeStyleHandle} __puiNativeStyleHandle */

/**
 * @template T
 * @typedef {{ get: () => T, subscribe: (callback: (event: { type: 'next', prev: T, next: T, reason?: unknown } | { type: 'disconnect', reason: 'unmount' }) => void) => (() => void), unsubscribe: (off: () => void) => void, spec: Readonly<Record<string, unknown>> }} __puiExternalState
 */
/** @template T @typedef {{ type: 'next', prev: T, next: T, reason?: unknown } | { type: 'disconnect', reason: 'unmount' }} __puiStateEvent */
/** @template T @typedef {{ get: () => T, setDefault: (value: T) => void, set: (value: T, reason?: unknown) => void, external: __puiExternalState<T>, dispose: () => void }} __puiOwnedState */
/** @typedef {'boolean' | 'number' | 'string' | 'null' | 'void' | { kind: 'literal', value: string | number | boolean | null } | { kind: 'array', element: __puiDataType } | { kind: 'union', members: readonly __puiDataType[] } | { kind: 'record', fields: readonly { name: string, type: __puiDataType, optional?: boolean }[] }} __puiDataType */
/** @typedef {Readonly<Record<string, unknown>>} __puiRawProps */
/** @typedef {{ type: 'boolean' | 'number' | 'string' | 'object' | 'any' | 'enum', empty?: 'accept' | 'fallback' | 'error', default?: unknown, options?: readonly string[], range?: { min?: number, max?: number } }} __puiPropSpec */
/** @typedef {{ options?: readonly (boolean | string | number)[], min?: unknown, max?: unknown, step?: unknown, clamp?: boolean } & Record<string, unknown>} __puiStateConfiguration */
/** @typedef {'bool' | 'string' | 'enum' | 'number.discrete' | 'number.range'} __puiStateKind */
/** @typedef {ReturnType<typeof __puiCreateOwner>} __puiOwner */
/** @typedef {Parameters<Parameters<__puiOwner['def']['props']['watch']>[1]>[0]} __puiRun */
/** @typedef {import('vue').default & { readonly instanceAssociations?: Readonly<{controlLabel?: object | null}>; readonly __puiParentScope?: import('./.proto-ui/context/scope-v1').ContextScope | null }} __puiOwnerInstance */
/** @typedef {(renderer: __puiNativeRenderer) => __puiNativePaint} __puiRenderFunction */
/** @typedef {{ changedKeysAll: string[], changedKeysMatched: string[] }} __puiPropsWatchInfo */
/** @template Run @template Snapshot @typedef {(run: Run, next: Snapshot, previous: Snapshot, info: __puiPropsWatchInfo) => void} __puiPropsWatchCallback */
/** @template Run @typedef {{ kind: 'resolved' | 'resolved-all', keys: readonly string[] | null, fn: __puiPropsWatchCallback<Run, __puiResolvedProps> } | { kind: 'raw' | 'raw-all', keys: readonly string[] | null, fn: __puiPropsWatchCallback<Run, __puiRawProps> }} __puiPropsWatchRegistration */
/** @typedef {"created" | "mounted" | "updated" | "unmounted" | "beforeDispose"} __puiLifecycleKind */
/** @template Run @typedef {(run: Run) => void} __puiLifecycleCallback */
/** @template Run @typedef {__puiPropsWatchRegistration<Run> & { active: boolean }} __puiPropsWatcher */
/** @typedef {{ epoch: number, revision: number, kind: 'update' }} __puiPendingCommit */
/** @typedef {{ epoch: number, version: number, present: boolean, vnode: import('vue').VNode, kind: 'mount' | 'update' | 'none' | 'detach', revision?: number | null }} __puiRenderedCommit */
/** @param {unknown} value @param {PropertyKey} key */
const __puiOwn = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
// Keep native relational coercion in all three open-schema comparisons.
/** @template T @param {T} left @param {T} right */
const __puiBefore = (left, right) => left < right;

/** @param {__puiDataType} type @param {unknown} value @returns {boolean} */
function __puiAccepts(type, value) {
  if (typeof type === 'string') return type === 'null' ? value === null : typeof value === type && (type !== 'number' || Number.isFinite(value));
  if (type.kind === 'literal') return Object.is(value, type.value);
  if (type.kind === 'union') return type.members.some((member) => __puiAccepts(member, value));
  if (type.kind === 'array') return Array.isArray(value) && value.every((item) => __puiAccepts(type.element, item));
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false;
  const record = /** @type {Record<string, unknown>} */ (value);
  return type.fields.every((field) =>
    __puiOwn(record, field.name) ? __puiAccepts(field.type, record[field.name]) : field.optional === true);
}
/** @param {unknown} value @param {Set<object>} [seen] @returns {boolean} */
function __puiJson(value, seen = new Set()) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return true;
  if (typeof value === 'number') return Number.isFinite(value);
  if (typeof value !== 'object' || seen.has(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  if (!Array.isArray(value) && prototype !== Object.prototype && prototype !== null) return false;
  if (Array.isArray(value) && (Object.keys(value).length !== value.length || !Object.keys(value).every((key) => /^(0|[1-9]\d*)$/.test(key) && Number(key) < value.length))) return false;
  seen.add(value);
  const valid = Object.values(value).every((item) => __puiJson(item, seen));
  seen.delete(value);
  return valid;
}


/** @param {__puiOwnerInstance} vm @param {(owner: __puiOwner) => __puiRenderFunction | void} setup @param {Record<string, __puiDataType>} types @param {string} rootTag @param {boolean} autoUpdate */
function __puiCreateOwner(vm, setup, types, rootTag, autoUpdate) {
  
  let phase = 'setup';
  let terminal = false;
  let disposed = false;
  let hydrated = false;
  let nativeMounted = false;
  let hostActive = true;
  let present = true;
  let viewActive = false;
  let epoch = 0;
  let revision = 0;
  let commitVersion = 0;
  let queued = false;
  /** @type {__puiPendingCommit | null} */
  let pending = null;
  /** @type {__puiRenderedCommit | null} */
  let renderedCommit = null;
  /** @type {Element | null} */ let activeRoot = null;
  
  /** @type {__puiNativePaint | null} */
  let template = null;
  /** @type {__puiRenderFunction | null | void} */
  let renderFunction;
  /** @type {(() => void) | undefined} */
  let unwatch;
  /** @type {__puiRawProps} */
  let raw = Object.freeze({});
  /** @type {__puiResolvedProps} */
  let resolved = /** @type {__puiResolvedProps} */ (Object.freeze({}));
  /** @type {Record<string, unknown>} */
  let previousValid = Object.create(null);
  /** @type {Record<string, __puiPropSpec>} */
  let specs = Object.create(null);
  /** @type {__puiRawProps[]} */
  const defaults = [];
  /** @type {Array<__puiPropsWatcher<typeof run>>} */
  const watchers = [];
  /** @type {Array<{ dispose: () => void }>} */
  const states = [];
  /** @type {Record<string, unknown>} */
  const exposed = Object.create(null);
  /** @type {Record<string, unknown>} */
  const eventDeclarations = Object.create(null);
  /** @type {Record<__puiLifecycleKind, Array<__puiLifecycleCallback<typeof run>>>} */
  const lifecycle = { "created": [], "mounted": [], "updated": [], "unmounted": [], "beforeDispose": [] };
  /** @type {Array<() => void>} */
  const notifications = [];
  
  let notifying = false;
  let dispatchingProps = false;
  /** @type {{raw: __puiRawProps; resolved: __puiResolvedProps} | null} */
  let propsWindow = null;
  const alive = () => { if (disposed) throw new Error('[Vue2 native] logical instance has been disposed.'); };
  const publicAlive = () => { if (terminal) throw new Error('[Vue2 native] exposed target has been terminally invalidated.'); };
  const callback = () => { alive(); if (phase !== 'callback') throw new Error('[Vue2 native] mutation requires callback scope.'); };
  const setupOnly = () => { alive(); if (phase !== 'setup') throw new Error('[Vue2 native] declaration requires setup scope.'); };
  const style = __puiCreateNativeStyle({
    
    ensureSetup: setupOnly,
    ensureRuntime: callback,
    isAlive: () => !terminal && !disposed,
    project: (tokens) => {
      if (!activeRoot) return;
      if (tokens.length) activeRoot.setAttribute('data-pui-style', tokens.join(' '));
      else activeRoot.removeAttribute('data-pui-style');
    },
  });
  /** @returns {__puiRawProps} */
  const hostRaw = () => {
    
    // Full snapshots preserve omission and explicit undefined. Vue Boolean casting and
    // default materialization never participate in the semantic prop contract.
    const out = Object.create(null);
    /** @type {Record<string, unknown>} */
    const input = { ...(vm.$attrs || {}), ...((vm.$options && vm.$options.propsData) || {}) };
    /** @type {Readonly<Record<string, unknown>>} */
    const provided = /** @type {Readonly<Record<string, unknown>>} */ ((vm.$options && vm.$options.propsData) || {});
    for (const key of Object.keys(types)) {
      const hostKey = key.replace(/-(\w)/g, (_match, letter) => letter.toUpperCase());
      // Track native prop notifications, but keep values/presence from the raw snapshot.
      if (vm.$props) void (/** @type {Readonly<Record<string, unknown>>} */ (vm.$props))[hostKey];
      if (__puiOwn(provided, hostKey)) input[key] = provided[hostKey];
    }
    for (const key of Object.keys(input)) if (key !== 'instanceAssociations' && key !== 'instance-associations') out[key] = input[key];
    return Object.freeze(out);
  };
  /** @param {__puiRawProps} a @param {__puiRawProps} b */
  const same = (a, b) => {
    const keys = Object.keys(a);
    return keys.length === Object.keys(b).length && keys.every((key) => __puiOwn(b, key) && Object.is(a[key], b[key]));
  };
  /** @param {string} key @param {unknown} value */
  const validValue = (key, value) => {
    const spec = specs[key];
    if (!__puiJson(value) || !__puiAccepts(types[key], value)) return false;
    if (spec.type === 'enum' && (typeof value !== 'string' || !spec.options?.includes(value))) return false;
    return !spec.range || typeof value === 'number' && value >= (spec.range.min ?? -Infinity) && value <= (spec.range.max ?? Infinity);
  };
  /** @param {__puiRawProps} input @param {boolean} strict */
  const resolveProps = (input, strict) => {
    /** @type {Record<string, unknown>} */
    const out = Object.create(null);
    const nextValid = { ...previousValid };
    /** @type {{ providedKeys: string[], emptyKeys: string[], invalidKeys: string[], usedFallbackKeys: string[], acceptedEmptyKeys: string[] }} */
    const meta = { providedKeys: [], emptyKeys: [], invalidKeys: [], usedFallbackKeys: [], acceptedEmptyKeys: [] };
    for (const key of Object.keys(specs)) {
      const spec = specs[key];
      const provided = __puiOwn(input, key);
      const value = input[key] === undefined ? null : input[key];
      const empty = spec.empty ?? 'fallback';
      if (provided) meta.providedKeys.push(key);
      if (provided && value !== null && validValue(key, value)) {
        out[key] = value; nextValid[key] = value; continue;
      }
      if (provided && value === null) {
        meta.emptyKeys.push(key);
        if (empty === 'accept') { out[key] = null; meta.acceptedEmptyKeys.push(key); continue; }
      } else if (provided) meta.invalidKeys.push(key);
      let found = false;
      /** @type {unknown} */
      let selected = null;
      let usedDefault = true;
      /** @param {unknown} candidate @param {boolean} fromDefault */
      const take = (candidate, fromDefault) => {
        if (found || candidate === undefined || strict && empty === 'error' && candidate === null) return;
        if (candidate !== null && !validValue(key, candidate)) return;
        found = true; selected = candidate; usedDefault = fromDefault;
      };
      if (provided && __puiOwn(previousValid, key)) take(previousValid[key], false);
      for (const layer of defaults) if (__puiOwn(layer, key)) take(layer[key], true);
      if (__puiOwn(spec, 'default')) take(spec.default, true);
      if (!found && strict && empty === 'error') throw new Error('[Vue2 native] prop ' + key + ' requires a non-empty valid value or fallback.');
      out[key] = selected;
      if (usedDefault) meta.usedFallbackKeys.push(key);
      if (provided && selected !== null) nextValid[key] = selected;
    }
    previousValid = nextValid;
    /** @type {__puiResolvedProps} */
    const snapshot = /** @type {__puiResolvedProps} */ (Object.freeze(out));
    return { snapshot, meta };
  };
  /** @template T @param {() => T} fn @param {boolean} [sync] @returns {T} */
  const invoke = (fn, sync = true) => {
    alive();
    const previousPhase = phase;
    phase = 'callback';
    try { if (sync && !terminal ) syncHost(false); return fn(); }
    finally { phase = previousPhase; }
  };
  /** @param {boolean} request */
  const syncHost = (request) => {
    if (terminal) return;
{ const __puiAssociations = vm.instanceAssociations;
    if (__puiAssociations !== undefined) {
      if (__puiAssociations === null || typeof __puiAssociations !== 'object' || Object.getPrototypeOf(__puiAssociations) !== Object.prototype)
        throw new TypeError('[InstanceAssociations] expected a plain record');
      for (const key of Reflect.ownKeys(__puiAssociations)) if (key !== 'controlLabel')
        throw new TypeError('[InstanceAssociations] unknown association key');
      if (Object.prototype.hasOwnProperty.call(__puiAssociations, 'controlLabel') && Reflect.get(__puiAssociations, 'controlLabel') != null)
        throw new Error('[ControlLabel] this Prototype has not declared Label or target participation');
    }
  }
    const nextRaw = hostRaw();
    if (hydrated && same(raw, nextRaw)) return;
    const previousRaw = raw;
    const previous = resolved;
    const next = resolveProps(nextRaw, true);
    raw = nextRaw; resolved = next.snapshot;
    if (!hydrated) { hydrated = true; style.refresh(); return; }
    const changedKeys = Object.keys(specs).filter((key) => !Object.is(previous[key], resolved[key]));
    const changedRawKeys = watchers.some((watch) => watch.active && (watch.kind === 'raw' || watch.kind === 'raw-all'))
      ? [...new Set([...Object.keys(previousRaw), ...Object.keys(raw)])].filter((key) => !Object.is(previousRaw[key], raw[key])) : [];
    if (changedKeys.length) { style.refresh(); }
    if ((changedKeys.length || changedRawKeys.length) && !dispatchingProps) {
      dispatchingProps = true;
      const previousWindow = propsWindow; propsWindow = {raw: nextRaw, resolved: next.snapshot};
      try {
        invoke(() => {
          // Raw-all precedes raw-keyed; resolved-all and keyed share declaration order.
          const snapshot = watchers.slice();
          for (let group = 0; group < 3; ++group) {
            for (const watch of snapshot) {
              if (!watch.active || (watch.kind === 'raw-all' ? 0 : watch.kind === 'raw' ? 1 : 2) !== group) continue;
              const isRaw = group < 2;
              const changedKeysAll = isRaw ? changedRawKeys : changedKeys;
              const changedKeysMatched = watch.keys === null ? changedKeysAll : watch.keys.filter((key) => changedKeysAll.includes(key));
              if (changedKeysMatched.length) {
                const info = { changedKeysAll: [...changedKeysAll], changedKeysMatched: [...changedKeysMatched] };
                // The registration discriminant preserves the raw/resolved callback
                // relation; the host group order and snapshot copies stay unchanged.
                if (watch.kind === 'raw' || watch.kind === 'raw-all') {
                  console.warn('[Props] raw watchers are an adapter-snapshot escape hatch; avoid in official prototypes.');
                  watch.fn(run, nextRaw, previousRaw, info);
                }
                else watch.fn(run, next.snapshot, previous, info);
              }
            }
          }
        }, false);
      } finally { propsWindow = previousWindow; dispatchingProps = false; }
    }
    if (request && autoUpdate) update();
  };
  const renderSemantic = () => {
    if (!renderFunction) throw new Error('[Vue2 native] renderer is unavailable outside the initialized instance lifetime.');
    const previousPhase = phase;
    phase = 'render';
    try { template = renderFunction(renderer); }
    finally { phase = previousPhase; }
  };
  const force = () => { if (!terminal && nativeMounted) vm.$forceUpdate(); };
  const update = () => {
    if (terminal) return;
    invoke(() => {}, true);
    if (!nativeMounted || !hostActive || !present || !viewActive) return;
    if (pending) { queued = true; return; }
    renderSemantic();
    pending = { epoch, revision: ++revision, kind: 'update' };
    force();
  };
  /** @param {boolean} next */
  const setPresent = (next) => {
    callback();
    if (terminal) throw new Error('[Vue2 native] presence is locked for terminal disposal.');
    if (present === next) return;
    present = next; ++epoch; pending = null; renderedCommit = null; queued = false;
    const requestedEpoch = epoch, failures = [];
    // Vue must patch at the owned anchor, not leave its replacement comment
    // in the Portal host and later resurrect the already-removed Root.
    
    if (!terminal && epoch === requestedEpoch && present === next) {
      
      if (!terminal && epoch === requestedEpoch && present === next) {
        // A newer presence request or terminal disposal always wins reentry.
        try {
          if (next && nativeMounted && hostActive && viewActive) renderSemantic();
          force();
        } catch (error) { failures.push(error); }
      }
    }
    if (failures.length) throw failures.length === 1 ? failures[0]
      : new AggregateError(failures, '[Vue2 native] presence withdrawal failed.');
  };

  /** @type {Map<object, (value: unknown) => boolean>} */
  const contextChecks = new Map([

  ]);
  const contextScope = __puiCreateContextScope({
    getParent: () => vm["__puiParentScope"] || null,
    isAlive: () => !disposed,
    invoke: (fn) => invoke(fn, false),
    validate: (key, value) => contextChecks.get(key)?.(value) === true,
  });
  const contextRead = Object.freeze({ read: (/** @param {object} key */ (key) => { alive(); return contextScope.read(key); }), tryRead: (/** @param {object} key */ (key) => { alive(); return contextScope.tryRead(key); }) });

  

  
  const run = {
    context: { ...contextRead, update: (/** @param {object} key @param {unknown} value */ (key, value) => { callback(); contextScope.update(key, value); }), tryUpdate: (/** @param {object} key @param {unknown} value */ (key, value) => { callback(); return contextScope.tryUpdate(key, value); }) },
    feedback: { style },
    update: () => { callback(); update(); },
    props: {
      get: () => { alive(); return propsWindow?.resolved ?? resolved; },
      getRaw: () => { alive(); return propsWindow?.raw ?? raw; },
      isProvided: (/** @param {PropertyKey} key */ (key) => { alive(); return __puiOwn(propsWindow?.raw ?? raw, key); }),
    },
    lifecycle: { setPresent },
    expose: { emit: (/** @param {string} key @param {unknown} [payload] @param {unknown} [options] */ (key, payload, options) => {
      callback();
      if (!__puiOwn(eventDeclarations, key)) throw new Error('[Vue2 native] undeclared expose event: ' + key);
      const listener = vm.$attrs && (/** @type {Readonly<Record<string, unknown>>} */ (vm.$attrs))['on' + key[0].toUpperCase() + key.slice(1)];
      // Host sink failures do not re-enter authored callbacks, matching the Vue2 sink.
      try { if (typeof listener === 'function') listener(payload, options); } catch {}
      try { vm.$emit(key, payload, options); } catch {}
    }) },
  };
  
  /** @type {__puiNativeRenderer} */
  const renderer = { 
    slot: () => /** @type {__puiNativePaint} */ ((_h, nativeVm, slots) => {
      if (slots.used) throw new Error('[Vue2 native] only one default slot is supported.');
      slots.used = true;
      const scoped = nativeVm.$scopedSlots.default;
      return (scoped ? scoped({}) : nativeVm.$slots.default) || [];
    }),
    read: Object.freeze({ props: Object.freeze({ get: () => { alive(); return resolved; }, getRaw: () => { alive(); return raw; }, isProvided: (/** @param {PropertyKey} key */ (key) => { alive(); return __puiOwn(raw, key); }) }) , context: contextRead }) };
  /**
   * @template T
   * @param {T} initial
   * @param {Readonly<Record<string, unknown>>} spec
   * @param {(value: T, initialValue?: boolean) => T} check
   * @returns {__puiOwnedState<T>}
   */
  const createStateCell = (initial, spec, check) => {
    let value = check(initial, true);
    /** @type {Set<(event: __puiStateEvent<T>) => void>} */
    const subscribers = new Set();
    /** @type {__puiOwnedState<T>} */
    const handle = {
      get: () => { alive(); return value; },
      setDefault: next => { setupOnly(); value = check(next, true); },
      set: (next, reason) => {
        callback();
        next = check(next);
        if (Object.is(value, next)) return;
        const previous = value; value = next;
        style.refresh();
        /** @type {__puiStateEvent<T>} */
        const event = { type: 'next', prev: previous, next, reason };
        for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(notifications, notifications.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!notifying) {
  notifying = true;
  /** @type {unknown[]} */ const notificationFailures = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < notifications.length) {
      try { notifications[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { notifications.length = 0; notifying = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
      },
      external: {
        get: () => { publicAlive(); return handle.get(); },
        subscribe: (fn) => { publicAlive(); /** @type {typeof fn} */ const registration = (/** @type {Parameters<typeof fn>[0]} */ event) => fn(event); subscribers.add(registration); return () => subscribers.delete(registration); },
        unsubscribe: (off) => { publicAlive(); if (typeof off === 'function') off(); },
        spec,
      },
      dispose: () => {
        try { for (const fn of Array.from(subscribers)) fn({ type: 'disconnect', reason: 'unmount' }); }
        finally { subscribers.clear(); }
      },
    };
    
    states.push(handle);
    
    return handle;
  };
  /** @template {boolean | string | number} T @param {__puiStateKind} kind @param {string} key @param {T} initial @param {__puiStateConfiguration} [configuration] @returns {__puiOwnedState<T>} */
  const createState = (kind, key, initial, configuration = {}) => {
    setupOnly();
    const spec = Object.freeze({ ...configuration, kind });
    /** @param {T} value @param {boolean} [initialValue] @returns {T} */
    const check = (value, initialValue = false) => {
      const expected = kind === 'bool' ? 'boolean' : kind === 'string' || kind === 'enum' ? 'string' : 'number';
      if (typeof value !== expected || expected === 'number' && !Number.isFinite(value)) throw new TypeError('[Vue2 native] invalid state value: ' + key);
      if (spec.options && spec.options.length && !spec.options.includes(value)) throw new Error('[Vue2 native] state value not in options: ' + key);
      // Numeric-family schemas prove these numeric views. Other families keep
      // their structurally admitted extra fields and native relational coercion.
      if (kind === 'number.range' && initialValue && spec.clamp) value = /** @type {T} */ (Math.min(/** @type {number} */ (spec.max), Math.max(/** @type {number} */ (spec.min), /** @type {number} */ (value))));
      if (!(kind === 'number.discrete' && spec.options && spec.options.length) && (spec.min !== undefined && __puiBefore(value, spec.min) || spec.max !== undefined && __puiBefore(spec.max, value))) throw new Error('[Vue2 native] state value out of range: ' + key);
      if (kind === 'number.discrete' && !(spec.options && spec.options.length) && __puiBefore(0, spec.step) && !Number.isInteger((/** @type {number} */ (value) - /** @type {number} */ (spec.min ?? 0)) / /** @type {number} */ (spec.step))) throw new Error('[Vue2 native] state value violates step: ' + key);
      return value;
    };
    
    const handle = createStateCell(initial, spec, check);
    
    return handle;
  };
  /** @param {Record<string, __puiPropSpec>} input */
  const defineProps = (input) => {
    setupOnly();
    const next = { ...specs };
    const rank = { accept: 0, fallback: 1, error: 2 };
    for (const key of Object.keys(input)) {
      const spec = input[key];
      if (!spec || !['boolean', 'number', 'string', 'object', 'any', 'enum'].includes(spec.type)) throw new Error('[Vue2 native] invalid prop declaration: ' + key);
      if (spec.empty !== undefined && !__puiOwn(rank, spec.empty)) throw new Error('[Vue2 native] invalid empty behavior: ' + key);
      if (spec.type === 'enum' && (!Array.isArray(spec.options) || !spec.options.length || !spec.options.every((value) => typeof value === 'string'))) throw new Error('[Vue2 native] invalid enum options: ' + key);
      if (spec.type !== 'enum' && __puiOwn(spec, 'options')) throw new Error('[Vue2 native] only enum props accept options: ' + key);
      if (__puiOwn(spec, 'default') && !__puiJson(spec.default)) throw new Error('[Vue2 native] non-JSON prop default: ' + key);
      const prior = next[key];
      if (prior) {
        if (prior.type !== spec.type || __puiOwn(spec, 'empty') && spec.empty !== undefined && rank[spec.empty] > rank[prior.empty ?? 'fallback']) throw new Error('[Vue2 native] conflicting prop declaration: ' + key);
        if (prior.options && !prior.options.every((value) => spec.options && spec.options.includes(value))) throw new Error('[Vue2 native] prop options cannot narrow: ' + key);
        if (prior.range && spec.range && ((spec.range.min ?? -Infinity) > (prior.range.min ?? -Infinity) || (spec.range.max ?? Infinity) < (prior.range.max ?? Infinity))) throw new Error('[Vue2 native] prop range cannot narrow: ' + key);
        next[key] = { ...prior, ...spec, empty: prior.empty ?? 'fallback', range: spec.range ?? prior.range };
        if (__puiOwn(prior, 'default')) next[key].default = prior.default;
      } else next[key] = { ...spec };
    }
    specs = next; resolved = resolveProps(raw, false).snapshot;
  };
  /** @param {__puiPropsWatcher<typeof run>} watch */
  const registerPropsWatch = (watch) => {
    setupOnly();
    const { kind, keys } = watch;
    if (keys !== null && (!keys.length || keys.some((key) => typeof key !== 'string'
      || kind === 'resolved' && !__puiOwn(specs, key)))) throw new Error('[Vue2 native] watch requires non-empty valid prop keys.');
    watch.keys = keys === null ? null : [...keys];
    watchers.push(watch);
    return () => { watch.active = false; };
  };
  /** @type {readonly __puiLifecycleKind[]} */
  const lifecycleKeys = ["created","mounted","updated","unmounted","beforeDispose"];
  const def = {
    context: { provide: (/** @param {object} key @param {unknown} value */ (key, value) => { setupOnly(); contextScope.provide(key, value); }), subscribe: (/** @param {object} key @param {(run: __puiRun, next: unknown, previous: unknown) => void} [fn] */ (key, fn) => { setupOnly(); return contextScope.subscribe(key, 'required', fn ? (next, prev) => fn(run, next, prev) : undefined); }), trySubscribe: (/** @param {object} key @param {(run: __puiRun, next: unknown, previous: unknown) => void} [fn] */ (key, fn) => { setupOnly(); return contextScope.subscribe(key, 'optional', fn ? (next, prev) => fn(run, next, prev) : undefined); }) },
    feedback: { style },
    
    props: {
      define: defineProps,
      setDefaults: (/** @param {__puiRawProps} layer */ (layer) => {
        setupOnly();
        for (const key of Object.keys(layer)) if (!__puiOwn(specs, key) || !__puiJson(layer[key])) throw new Error('[Vue2 native] invalid prop default: ' + key);
        defaults.unshift({ ...layer }); resolved = resolveProps(raw, false).snapshot;
      }),
      /** @param {readonly string[]} keys @param {__puiPropsWatchCallback<typeof run, __puiResolvedProps>} fn */
      watch: (keys, fn) => registerPropsWatch({ kind: 'resolved', keys, fn, active: true }),
      /** @param {__puiPropsWatchCallback<typeof run, __puiResolvedProps>} fn */
      watchAll: (fn) => registerPropsWatch({ kind: 'resolved-all', keys: null, fn, active: true }),
      /** @param {readonly string[]} keys @param {__puiPropsWatchCallback<typeof run, __puiRawProps>} fn */
      watchRaw: (keys, fn) => registerPropsWatch({ kind: 'raw', keys, fn, active: true }),
      /** @param {__puiPropsWatchCallback<typeof run, __puiRawProps>} fn */
      watchRawAll: (fn) => registerPropsWatch({ kind: 'raw-all', keys: null, fn, active: true }),
    },
    state: {
      /** @param {string} key @param {boolean} value */
      bool: (key, value) => createState('bool', key, value),
      /** @param {string} key @param {string} value @param {__puiStateConfiguration} [spec] */
      string: (key, value, spec) => createState('string', key, value, spec),
      /** @param {string} key @param {string} value @param {__puiStateConfiguration} [spec] */
      enum: (key, value, spec) => createState('enum', key, value, spec),
      /** @param {string} key @param {number} value @param {__puiStateConfiguration} [spec] */
      numberDiscrete: (key, value, spec) => createState('number.discrete', key, value, spec),
      /** @param {string} key @param {number} value @param {__puiStateConfiguration} spec */
      numberRange: (key, value, spec) => createState('number.range', key, value, spec),
    },
    expose: {
      /** @param {string} key @param {unknown} value */
      value: (key, value) => { setupOnly(); if (__puiOwn(exposed, key)) throw new Error('[Expose] duplicate declaration'); exposed[key] = value; },
      /** @template T @param {string} key @param {{ external: __puiExternalState<T> }} handle */
      state: (key, handle) => { setupOnly(); exposed[key] = handle.external;  },
      /** @template {unknown[]} Args @template Result @param {string} key @param {(...args: Args) => Result} fn @param {(value: Result) => Result} [project] */
      method: (key, fn, project) => { setupOnly();  exposed[key] = (/** @param {Args} args */ (...args) => { publicAlive(); const result = invoke(() => fn(...args)); return project ? project(result) : result; }); },
      /** @param {string} key @param {unknown} [spec] */
      event: (key, spec) => { setupOnly(); eventDeclarations[key] = spec; },
    },
    lifecycle: Object.fromEntries(lifecycleKeys.map((key) => {
      /** @type {[string, (fn: __puiLifecycleCallback<typeof run>) => void]} */
      const entry = ['on' + key[0].toUpperCase() + key.slice(1), (fn) => { setupOnly(); lifecycle[key].push(fn); }];
      return entry;
    })),
  };
  /** @param {__puiLifecycleKind} kind */
  const fire = (kind) => invoke(() => { if (kind === 'unmounted') {  } try { for (const fn of lifecycle[kind]) fn(run); } finally { if (kind === 'unmounted') {  } } }, !terminal);
  const detach = () => {
    if (!viewActive) return;
    viewActive = false; pending = null; queued = false;
    
    
    style.unmount();
    if (activeRoot) activeRoot.removeAttribute('data-pui-style');
    activeRoot = null;
    fire('unmounted');
  };
  const afterCommit = () => {
    if (terminal) return;
    syncHost(true);
    const commit = renderedCommit;
    if (!commit) return;
    renderedCommit = null;
    const target = vm.$el;
    // Removal has already committed when Vue calls updated. Do not postpone its
    // unmount notification into a tick which may belong to a replacement view.
    if (!commit.present && commit.vnode.elm === target) { detach(); return; }
    vm.$nextTick(() => {
      if (terminal || commit.epoch !== epoch || commit.version !== commitVersion || vm.$el !== target || commit.vnode.elm !== target) return;
      if (!present || !hostActive) return;
      
      
      const kind = commit.kind;
      if (kind === 'mount' && !viewActive) {
        viewActive = true;
        activeRoot = target;
        
        
        style.mount();
        
        fire('mounted');
        
      } else if (viewActive) {
        
        
        if (kind !== 'update' || !pending || pending.revision !== commit.revision) return;
        pending = null;
        const again = queued; queued = false;
        fire('updated');
        if (again && present && viewActive && !terminal && !pending) update();
      }
    });
  };
  const owner = {
    
    
    
    contextScope,
    host() { return viewActive && present && hostActive && !terminal ? vm.$el : null; },
    
    def,
    get resolvedProps() { return resolved; },
    
    initialize() {
      
      try {
        renderFunction = setup(owner);
        if (typeof renderFunction !== 'function') renderFunction = (renderer) => renderer.slot();
        phase = 'idle';
        syncHost(false);
        fire('created');
         unwatch = vm.$watch(() => hostRaw(), () => syncHost(true), { deep: true });
      } catch (error) {
        
        terminal = true;
        
        try { style.dispose(); } catch {}
        try { contextScope.dispose(); } catch {}
        disposed = true;
        phase = 'idle';
        throw error;
      }
    },
    hostMounted() {  nativeMounted = true; afterCommit(); },
    afterCommit,
    /** @param {import('vue').CreateElement} h */
    render(h) {
      
      if (terminal || !present || !hostActive) {
        const vnode = h();
        renderedCommit = { epoch, version: ++commitVersion, present: false, vnode, kind: 'detach' };
        return vnode;
      }
      if (!viewActive) renderSemantic();
      const tag = rootTag;
      const children = template ? template(h, vm, { used: false }) : [];
      if (['input', 'textarea', 'img'].includes(tag) && children.length) throw new Error('[Template] physical control Root requires empty children.');
      const rootData = { pre: true, attrs: { 'data-pui-root': '' } };
      const vnode = h(tag, rootData, children);
      renderedCommit = { epoch, version: ++commitVersion, present: true, vnode, kind: !viewActive ? 'mount' : pending ? 'update' : 'none', revision: pending && pending.revision };
      return vnode;
    },
    update,
    getExposes() { if (terminal) return {}; return { ...exposed }; },
    /** @template T @param {() => T} fn @returns {T} */
    invokePublic(fn) { publicAlive(); return invoke(fn); },
    deactivate() {
      if (terminal || !hostActive) return;
      hostActive = false; ++epoch; renderedCommit = null; pending = null; queued = false;
      detach();
    },
    activate() {
      if (terminal || hostActive) return;
      hostActive = true; ++epoch; pending = null; renderedCommit = null;
      vm.$forceUpdate();
    },
    dispose() {
      if (terminal) return;
      terminal = true; ++epoch; renderedCommit = null; pending = null; queued = false;
      
      unwatch?.(); unwatch = undefined;
      /** @type {{ error: unknown } | undefined} */ let failure;
      try { detach(); } catch (error) { failure = { error }; }
       try {
        fire('beforeDispose');
      } catch (error) { failure ??= { error }; }
      for (const state of states) {
        try { state.dispose(); } catch (error) { failure ??= { error }; }
      }
      try { contextScope.dispose(); } catch (error) { failure ??= { error }; }
      
      try { style.dispose(); } catch (error) { failure ??= { error }; }
      const target = vm.$el;
      if (target && target.nodeType === 1 && target.hasAttribute('data-pui-root')) target.removeAttribute('data-pui-style');
      
      disposed = true; phase = 'idle';
      watchers.length = 0; notifications.length = 0; states.length = 0; defaults.length = 0;
      for (const callbacks of Object.values(lifecycle)) callbacks.length = 0;
      for (const key of Object.keys(exposed)) delete exposed[key];
      for (const key of Object.keys(eventDeclarations)) delete eventDeclarations[key];
      specs = Object.create(null); previousValid = Object.create(null); raw = Object.freeze({}); resolved = /** @type {__puiResolvedProps} */ (Object.freeze({})); template = renderFunction = null;
      
      if (failure) throw failure.error;
    },
  };
  return owner;
}


/** @param {__puiOwner} __puiOwner */
function __puiSetup(__puiOwner) {




  /** @type {((renderer: __puiNativeRenderer) => ((__puiNativePaint))) | void} */
  const __puiAuthoredRenderer = (/** @param {__puiOwner['def']} def */ (def) => {
    // Source "entry.proto.ts":3:3
    def.props.define({ ["seed"]: { ["type"]: "number", ["default"]: 2 }, ["visible"]: { ["type"]: "boolean", ["default"]: true }, ["active"]: { ["type"]: "boolean", ["default"]: false }, ["patch"]: { ["type"]: "number", ["default"]: 0 } });
    // Source "entry.proto.ts":4:9
    const count = def.state.numberDiscrete("consumerCount", 0, { ["min"]: 0, ["max"]: 100, ["step"]: 1 });
    // Source "entry.proto.ts":5:9
    const base = {"kind":"tw","tokens":["bg-white","opacity-100"],"groups":["bg-","opacity-"]};
    // Source "entry.proto.ts":6:77
    const patched = {"kind":"tw","tokens":["bg-blue"],"groups":["bg-"]};
    // Source "entry.proto.ts":7:9
    const template = {"kind":"tw","tokens":["text-white"],"groups":["text-color"]};
    // Source "entry.proto.ts":8:3
    def.feedback.style.use(base);
    // Source "entry.proto.ts":9:3
    __puiOwner.def.feedback.style.rule(() => (count.get() === 7), [{"kind":"tw","tokens":["bg-red"],"groups":["bg-"]}]);
    // Source "entry.proto.ts":10:3
    __puiOwner.def.feedback.style.rule(() => (__puiOwner.resolvedProps["active"] === true), [{"kind":"tw","tokens":["bg-black","opacity-40"],"groups":["bg-","opacity-"]}]);
    // Source "entry.proto.ts":11:3
    def.props.watch(["patch"], /** @param {__puiRun} run @param {__puiResolvedProps} next */ (run, next) => {
      // Source "entry.proto.ts":12:5
      if (((next)["patch"] === 1)) {
        // Source "entry.proto.ts":12:24
        run.feedback.style.patch(patched);
      }
      // Source "entry.proto.ts":13:5
      if (((next)["patch"] === 2)) {
        // Source "entry.proto.ts":13:24
        run.feedback.style.suppress(patched);
      }
      // Source "entry.proto.ts":14:5
      if (((next)["patch"] === 0)) {
        // Source "entry.proto.ts":14:24
        run.feedback.style.clearPatch();
      }
    });
    // Source "entry.proto.ts":16:3
    def.expose.state("count", count);
    // Source "entry.proto.ts":17:3
    def.expose.method("write", /** @param {number} next @returns {void} */ (next) => {
      // Source "entry.proto.ts":17:45
      count.set(next, "consumer-write");
    });
    // Source "entry.proto.ts":18:3
    def.expose.method("read", /**  @returns {number} */ () => {
      // Source "entry.proto.ts":18:32
      return /** @type {number} */ (count.get());
    });
    // Source "entry.proto.ts":19:3
    def.expose.event("phase", { ["payload"]: "json" });
    // Source "entry.proto.ts":20:3
    def.props.watch(["seed"], /** @param {__puiRun} run @param {__puiResolvedProps} next */ (run, next) => {
      // Source "entry.proto.ts":20:41
      count.set(((next)["seed"] ?? 0));
      // Source "entry.proto.ts":20:67
      run.update();
    });
    // Source "entry.proto.ts":21:3
    def.props.watch(["visible"], /** @param {__puiRun} run @param {__puiResolvedProps} next */ (run, next) => {
      // Source "entry.proto.ts":21:44
      run.lifecycle.setPresent(((next)["visible"] ?? false));
    });
    // Source "entry.proto.ts":22:3
    def.lifecycle.onCreated(/** @param {__puiRun} run */ (run) => {
      // Source "entry.proto.ts":23:5
      count.set(((run.props.get())["seed"] ?? 0));
      // Source "entry.proto.ts":24:5
      run.lifecycle.setPresent(((run.props.get())["visible"] ?? false));
      // Source "entry.proto.ts":25:5
      run.expose.emit("phase", "created");
    });
    // Source "entry.proto.ts":27:3
    def.lifecycle.onMounted(/** @param {__puiRun} run */ (run) => {
      // Source "entry.proto.ts":27:35
      run.expose.emit("phase", "mounted");
    });
    // Source "entry.proto.ts":28:3
    def.lifecycle.onUpdated(/** @param {__puiRun} run */ (run) => {
      // Source "entry.proto.ts":28:35
      run.expose.emit("phase", "updated");
    });
    // Source "entry.proto.ts":29:3
    def.lifecycle.onUnmounted(/** @param {__puiRun} run */ (run) => {
      // Source "entry.proto.ts":29:37
      run.expose.emit("phase", "unmounted");
    });
    // Source "entry.proto.ts":30:3
    def.lifecycle.onBeforeDispose(/** @param {__puiRun} run */ (run) => {
      // Source "entry.proto.ts":30:41
      run.expose.emit("phase", "disposed");
    });
    // Source "entry.proto.ts":31:3
    return /** @param {__puiNativeRenderer} render */ (render) => {
      // Source "entry.proto.ts":31:20
      return (/** @param {unknown} __puiReceiver0 @param {string} __puiTag1 @param {{ style: __puiNativeStyleHandle }} __puiArg2 @param {(string | number)} __puiArg3 */ (__puiReceiver0, __puiTag1, __puiArg2, __puiArg3) => {
      const __puiTokens4 = __puiTemplateStyleTokens(__puiArg2.style);
      return /** @type {__puiNativePaint} */ ((__puiH5, __puiVm6, __puiSlots7) => {
        /** @type {__puiNativeChildren} */ const __puiChildren8 = [];
        __puiChildren8.push('' + (__puiArg3));
        /** @type {import('vue').VNodeData & { pre: true }} */ const __puiData9 = { pre: true, attrs: { 'data-pui-style': __puiTokens4 } };
        return [__puiH5(__puiTag1, __puiData9, __puiChildren8)];
      });
    })(render, "article", { ["style"]: template }, /** @type {number} */ (count.get()));
    };
  })(__puiOwner.def);
  if (typeof __puiAuthoredRenderer !== 'function') return __puiAuthoredRenderer;
  return (/** @param {__puiNativeRenderer} __puiRenderer */ (__puiRenderer) => (/** @param {((__puiNativePaint))} __puiCommitted10 */ (__puiCommitted10) => /** @type {__puiNativePaint} */ ((__puiH11, __puiVm12, __puiSlots13) => {
      /** @type {__puiNativeChildren} */ const __puiChildren14 = [];
      if (typeof __puiCommitted10 === 'function') { __puiChildren14.push(.../** @type {__puiNativePaint} */ (__puiCommitted10)(__puiH11, __puiVm12, __puiSlots13)); } else { throw new TypeError('[Vue2 native] invalid template child.'); }
      return __puiChildren14;
    }))(__puiAuthoredRenderer(__puiRenderer)));
}

/** @typedef {import('vue').default & { readonly "__puiOwner": ReturnType<typeof __puiCreateOwner>; readonly "__puiParentScope"?: ReturnType<typeof __puiCreateContextScope> | null }} __puiNativeInstance */
export const CompiledComponent = {
  name: "native-consumer-counter",
  inheritAttrs: false,
  props: { instanceAssociations: { type: Object, default: undefined }, ["seed"]: {}, ["visible"]: {}, ["active"]: {}, ["patch"]: {} },
  inject: { ["__puiParentScope"]: { from: __puiScopeKey, default: null } },
  /** @this {__puiNativeInstance} */
  provide() { return { [__puiScopeKey]: this["__puiOwner"].contextScope }; },
  /** @this {__puiNativeInstance} */
  beforeCreate() {
    Object.defineProperty(this, "__puiOwner", { value: __puiCreateOwner(this, __puiSetup, {"seed":"number","visible":"boolean","active":"boolean","patch":"number"}, "div", true) });
    
  },
  /** @this {__puiNativeInstance} */
  created() { this["__puiOwner"].initialize(); },
  /** @this {__puiNativeInstance} */
  mounted() { this["__puiOwner"].hostMounted(); },
  /** @this {__puiNativeInstance} */
  updated() { this["__puiOwner"].afterCommit(); },
  /** @this {__puiNativeInstance} */
  activated() { this["__puiOwner"].activate(); },
  /** @this {__puiNativeInstance} */
  deactivated() { this["__puiOwner"].deactivate(); },
  /** @this {__puiNativeInstance} */
  beforeDestroy() { this["__puiOwner"].dispose(); },
  methods: {
    /** @this {__puiNativeInstance} */
    update() { this["__puiOwner"].update(); },
    /** @this {__puiNativeInstance} */
    getExposes() { return this["__puiOwner"].getExposes(); },
    /** @this {__puiNativeInstance} @template T @param {() => T} callback */
    invokeInCallbackScope(callback) { return this["__puiOwner"].invokePublic(callback); },
  },
  /** @this {__puiNativeInstance} @param {import('vue').CreateElement} h */
  render(h) { return this["__puiOwner"].render(h); },
};
export default CompiledComponent;


//# sourceMappingURL=Component.js.map
