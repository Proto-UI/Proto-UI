// Editable Vue 3 source. Profile: vue-source-v1; no Proto Runtime or Adapter dependency.
// Inline native costs: owner/update queue, constrained state subscriptions, prop resolution/watchers,
// public boundary guards, view commit lifecycle and native element/slot composition.
// Source graph SHA-256: 3d57dccc660e4eb5220d5e663b353d71b74049db3091664d29b20b00ee784918




import * as __puiVueVue from 'vue';




import { createContextScope as __puiVueCreateContextScope, scopeKey as __puiVueScopeKey, acceptsContextValue as __puiVueAcceptsContextValue, type ContextScope as __puiVueContextScope } from './.proto-ui/context/scope-v1';
import { key as __puiVueContextKey0 } from './.proto-ui/context/key-dc2ed9b5eb8fa03a6d9398eb816a7773a181f41061354a359f30bf77a1a9897c';
import { key as __puiVueContextKey1 } from './.proto-ui/context/key-9d04ced5dd68c3cb55e4ef35a024e79c2127e19d2a1c2de10b3188a87a10c4c8';




type __puiVueRun = Readonly<{ readonly owner: symbol }>;
type __puiVueStateEvent<T> = { type: 'next'; prev: T; next: T; reason?: unknown } | {type:'disconnect';reason:'unmount'};
type __puiVueSpec = Readonly<{ kind: 'bool' | 'enum' | 'string' | 'number.range' | 'number.discrete'; options?: readonly (string | number)[]; min?: number; max?: number; step?: number; clamp?: boolean }>;
type __puiVuePropSpec = { type: unknown; default?: unknown; empty?: 'accept' | 'fallback' | 'error'; range?: { min?: number; max?: number }; options?: readonly unknown[] };
type __puiVueWatchInfo = { changedKeysAll: string[]; changedKeysMatched: string[] };
export type __puiVuePublicState<T> = { get(): T; subscribe(callback: (event: __puiVueStateEvent<T>) => void): () => void; unsubscribe(off: () => void): void; readonly spec: __puiVueSpec };
type __puiVueState<T> = __puiVuePublicState<T> & { setDefault(next: T): void; set(next: T, reason?: unknown): void };
type __puiVueEpoch = { id: number; active: boolean; committed: boolean };
type __puiVueFrame = { epoch: __puiVueEpoch; slotUsed: boolean };
export type GeneratedProps = {

};
export type GeneratedResolvedProps = {

};
export type GeneratedExposes = {
  readonly "value": __puiVuePublicState<number>;
  readonly "missing": __puiVuePublicState<boolean>;
};
export type GeneratedHandle = { update(): void; getExposes(): GeneratedExposes };

// The slot is a real Vue child render, so authored Vue children retain native ownership.
const __puiVueSlotView = __puiVueVue.defineComponent({
  name: 'CompiledSlot', inheritAttrs: false,
  props: { read: { type: Function as __puiVueVue.PropType<() => __puiVueVue.VNodeChild>, required: true } },
  setup(props) { return () => props.read!(); },
});

export const ContextConsumer = __puiVueVue.defineComponent({
  name: "native-consumer-context", inheritAttrs: false,
  props: { instanceAssociations: { type: Object as __puiVueVue.PropType<Readonly<{controlLabel?: object | null}>>, default: undefined } },
  emits: [],
  setup(_props, __puiVueContext) {
    // Protocol values intentionally do not enter Vue's reactive state graph.
    const __puiVueInstance = __puiVueVue.getCurrentInstance()!;

    const __puiVueRevision = __puiVueVue.shallowRef(0);
    const __puiVueHostRevision = __puiVueVue.shallowRef(0);
    let __puiVueHostScheduled = false;
    const __puiVuePresent = __puiVueVue.shallowRef(true);
    const __puiVueSlotRevision = __puiVueVue.shallowRef(0);
    let __puiVueDisposed = false, __puiVueDisposing = false, __puiVueInternalTeardown = false;
    let __puiVueQueued = false, __puiVueRequested = false, __puiVueQueueTicket = 0;
    let __puiVueEpochId = 0;
    let __puiVueCurrentEpoch: __puiVueEpoch | undefined;

    const __puiVueLife: Record<'created' | 'mounted' | 'updated' | 'unmounted' | 'beforeDispose', Array<(run: __puiVueRun) => void>> = { created: [], mounted: [], updated: [], unmounted: [], beforeDispose: [] };
    const __puiVueExposes: Record<string, unknown> = Object.create(null);
    const __puiVueStates = new Set<object>();
    const __puiVuePublicStates = new WeakMap<object, object>();
    const __puiVueInternalSubscriptions = new WeakMap<object, (callback: (event: __puiVueStateEvent<unknown>) => void) => () => void>();
    const __puiVueStateCleanup: Array<() => void> = [];
    const __puiVueEvents = new Set<string>();
    const __puiVuePropChecks: Record<string, (value: unknown) => boolean> = {

    };
    const __puiVueMethodChecks: Record<string, { args(args: unknown[]): boolean; result(value: unknown): boolean }> = {

    };
    const __puiVueEventChecks: Record<string, (value: unknown) => boolean> = {

    };
    const __puiVuePropSpecs: Record<string, __puiVuePropSpec> = Object.create(null);
    const __puiVueDefaults: Array<Record<string, unknown>> = [];
    const __puiVuePreviousValid: Record<string, unknown> = Object.create(null);
    // Setup declarations precede hydration; the final snapshot is validated before created.
    let __puiVueProps: Readonly<GeneratedResolvedProps>;
    let __puiVueRawProps: Record<string, unknown> = Object.create(null);
    let __puiVuePropsWindow: {raw: Readonly<Record<string, unknown>>; resolved: Readonly<GeneratedResolvedProps>} | null = null;
    const __puiVueWatchers: Array<{ keys: readonly string[] | null; active: boolean; callback: (run: __puiVueRun, next: Readonly<GeneratedResolvedProps>, previous: Readonly<GeneratedResolvedProps>, info: __puiVueWatchInfo) => void }> = [];

    const __puiVueStateQueue: Array<() => void> = [];
    let __puiVueEmittingState = false;
    let __puiVueSetup = true;
    let __puiVueRootElement: HTMLElement | null = null;
    let __puiVueRootEpoch: __puiVueEpoch | undefined;

    const __puiVueParentScope = __puiVueVue.inject<__puiVueContextScope | null>(__puiVueScopeKey, null);
    const __puiVueContextChecks = new Map<object, (value: unknown) => boolean>([
      [__puiVueContextKey0, (value: unknown) => __puiVueAcceptsContextValue({"kind":"record","fields":[{"name":"value","type":"number"}]}, value)],
      [__puiVueContextKey1, (value: unknown) => __puiVueAcceptsContextValue({"kind":"record","fields":[{"name":"value","type":"number"}]}, value)],
    ]);
    const __puiVueScope = __puiVueCreateContextScope({
      getParent: () => __puiVueParentScope, isAlive: () => !__puiVueDisposed,
      invoke: (callback) => { __puiVueAlive(); return callback(); },
      validate: (key, value) => __puiVueContextChecks.get(key)?.(value) === true,
    });
    __puiVueVue.provide(__puiVueScopeKey, __puiVueScope);
    function __puiVueReadContext(run: __puiVueRun, key: object, optional: boolean): unknown {
      __puiVueRequireRun(run); return optional ? __puiVueScope.tryRead(key) : __puiVueScope.read(key);
    }
    function __puiVueUpdateContext(run: __puiVueRun, key: object, value: unknown, optional: boolean): void | boolean {
      __puiVueRequireRun(run); return optional ? __puiVueScope.tryUpdate(key, value) : __puiVueScope.update(key, value);
    }
    function __puiVueReadFrameContext(frame: __puiVueFrame, key: object, optional: boolean): unknown {
      __puiVueActiveFrame(frame); return optional ? __puiVueScope.tryRead(key) : __puiVueScope.read(key);
    }




    

    
    const __puiVueRunValue: __puiVueRun = Object.freeze({ owner: Symbol("native-consumer-context") });

    function __puiVueIsRecord(value: unknown): value is Record<string, unknown> {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
      const prototype = Object.getPrototypeOf(value);
      return (prototype === Object.prototype || prototype === null) && Reflect.ownKeys(value).every((key) => {
        const descriptor = Object.getOwnPropertyDescriptor(value, key)!;
        return typeof key === 'string' && descriptor.enumerable && Object.hasOwn(descriptor, 'value');
      });
    }
    function __puiVueIsArray(value: unknown): value is unknown[] {
      if (!Array.isArray(value) || Object.keys(value).length !== value.length) return false;
      const prototype = Object.getPrototypeOf(value);
      if (prototype !== Array.prototype && prototype !== null) return false;
      return Reflect.ownKeys(value).every((key) => {
        if (key === 'length') return true;
        const descriptor = Object.getOwnPropertyDescriptor(value, key)!;
        return typeof key === 'string' && /^(0|[1-9]\d*)$/.test(key) && Number(key) < value.length && descriptor.enumerable && Object.hasOwn(descriptor, 'value');
      });
    }

    function __puiVueAlive(): void {
      if (__puiVueDisposed || (__puiVueDisposing && !__puiVueInternalTeardown)) throw new Error('[Vue source] owner is disposed');
    }
    function __puiVuePublicAlive(): void {
      if (__puiVueDisposed || __puiVueDisposing) throw new Error('[Vue source] owner is disposed');
    }
    function __puiVueSubscribeInternal<T>(state: {get(): T}, callback: (event: __puiVueStateEvent<T>) => void): () => void {
      __puiVueAlive();
      const subscribe = __puiVueInternalSubscriptions.get(state);
      if (!subscribe) throw new Error('[State] unknown owner subscription target');
      return subscribe(event => callback(event as __puiVueStateEvent<T>));
    }
    function __puiVueRequireRun(run: __puiVueRun): void {
      __puiVueAlive();
      if (run !== __puiVueRunValue) throw new Error('[Vue source] foreign run handle');
    }
    function __puiVueRequestUpdate(run: __puiVueRun): void {
      __puiVueRequireRun(run);
      if (__puiVueDisposing) return;
      __puiVueRequested = true;

      if (__puiVueQueued) return;
      __puiVueQueued = true;
      const ticket = __puiVueQueueTicket;
      queueMicrotask(() => {
        if (ticket !== __puiVueQueueTicket || __puiVueDisposed || __puiVueDisposing) return;
        __puiVueQueued = false;
        if (!__puiVueRequested) return;
        __puiVueRequested = false;
        if (__puiVuePresent.value) __puiVueRevision.value += 1;
      });
    }
    function __puiVueSetPresent(run: __puiVueRun, present: boolean): void {
      __puiVueRequireRun(run);
      if (__puiVueDisposing) throw new Error('[Vue source] terminal presence is locked');
      if (typeof present !== 'boolean') throw new TypeError('[Vue source] presence must be boolean');
      __puiVuePresent.value = present;
    }
    function __puiVueInvokeLife(kind: keyof typeof __puiVueLife): void {
      if (kind === 'unmounted') {  }
      try { for (const callback of __puiVueLife[kind]) callback(__puiVueRunValue); }
      finally { if (kind === 'unmounted') {  } }
    }
    function __puiVueUnbindRoot(epoch: __puiVueEpoch): void {
      if (__puiVueRootEpoch !== epoch) return;

      
      __puiVueRootElement = null; __puiVueRootEpoch = undefined;

    }
    function __puiVueCommitUnmount(epoch: __puiVueEpoch): void {
      epoch.active = false;
      __puiVueUnbindRoot(epoch);
      if (!epoch.committed) return;
      epoch.committed = false;
      const previous = __puiVueInternalTeardown;
      __puiVueInternalTeardown = __puiVueDisposing;
      try { __puiVueInvokeLife('unmounted'); } finally { __puiVueInternalTeardown = previous; }
    }
    function __puiVueCreateState(kind: 'bool', semantic: string, initial: boolean): __puiVueState<boolean>;
    function __puiVueCreateState(kind: 'string' | 'enum', semantic: string, initial: string, options?: Omit<__puiVueSpec, 'kind'>): __puiVueState<string>;
    function __puiVueCreateState(kind: 'number.range' | 'number.discrete', semantic: string, initial: number, options?: Omit<__puiVueSpec, 'kind'>): __puiVueState<number>;
    function __puiVueCreateState(kind: __puiVueSpec['kind'], semantic: string, initial: boolean | number | string, options?: Omit<__puiVueSpec, 'kind'>): __puiVueState<boolean | number | string>;
    function __puiVueCreateState(kind: __puiVueSpec['kind'], semantic: string, initial: boolean | number | string, options: Omit<__puiVueSpec, 'kind'> = {}): unknown {

      if (typeof semantic !== 'string' || semantic.length === 0) throw new Error('[Vue source] invalid state semantic');
      const spec: __puiVueSpec = Object.freeze({ ...options, ...(options.options ? { options: Object.freeze([...options.options]) } : {}), kind });
      function validate(value: boolean | number | string): void {
        if (kind === 'bool' ? typeof value !== 'boolean' : kind === 'string' || kind === 'enum' ? typeof value !== 'string' : typeof value !== 'number' || !Number.isFinite(value)) throw new TypeError('[Vue source] invalid state value');
        if (spec.options?.length && (typeof value === 'boolean' || !spec.options.includes(value))) throw new RangeError('[Vue source] state value not in options');
        if (typeof value === 'number' && (kind === 'number.range' || (kind === 'number.discrete' && !spec.options?.length)) && (spec.min !== undefined && value < spec.min || spec.max !== undefined && value > spec.max)) throw new RangeError('[Vue source] state value out of range');
        if (typeof value === 'number' && kind === 'number.discrete' && !spec.options?.length && spec.step !== undefined && spec.step > 0 && !Number.isInteger((value - (spec.min ?? 0)) / spec.step)) throw new RangeError('[Vue source] state value violates step');
      }
      if (kind === 'number.range' && (typeof spec.min !== 'number' || typeof spec.max !== 'number' || Number.isNaN(spec.min) || Number.isNaN(spec.max) || spec.min > spec.max)) throw new RangeError('[Vue source] invalid state range');
      let value = initial;
      if (kind === 'number.range' && spec.clamp && typeof value === 'number') value = Math.min(spec.max!, Math.max(spec.min!, value));
      validate(value);
      const subscribers = new Set<(event: __puiVueStateEvent<boolean | number | string>) => void>();
      const handle: __puiVueState<boolean | number | string> = {
        spec,
        get() { __puiVueAlive(); return value; },
        setDefault(next) { __puiVueAlive(); if (!__puiVueSetup) throw new Error('[State] setDefault requires setup'); validate(next); value = next; },
        set(next, reason) {
          __puiVueAlive(); validate(next);
          if (Object.is(value, next)) return;
          const event: __puiVueStateEvent<boolean | number | string> = { type: 'next', prev: value, next, reason };
          value = next;

          

          for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(__puiVueStateQueue, __puiVueStateQueue.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!__puiVueEmittingState) {
  __puiVueEmittingState = true;
  const notificationFailures: unknown[] = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < __puiVueStateQueue.length) {
      try { __puiVueStateQueue[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { __puiVueStateQueue.length = 0; __puiVueEmittingState = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
        },
        subscribe(callback) { __puiVuePublicAlive(); const registration: typeof callback = event => callback(event); subscribers.add(registration); return () => { if (!__puiVueDisposed && !__puiVueDisposing) subscribers.delete(registration); }; },
        unsubscribe(off) { __puiVuePublicAlive(); off(); },
      };
      __puiVueStates.add(handle);
      
      __puiVueInternalSubscriptions.set(handle, callback => {
        const registration: typeof callback = event => callback(event); subscribers.add(registration);
        return () => { subscribers.delete(registration); };
      });
      __puiVueStateCleanup.push(() => subscribers.clear());

      return handle;
    }
    function __puiVueDeclare(key: string, value: unknown): void {
      if (Object.hasOwn(__puiVueExposes, key)) throw new Error('[Vue source] duplicate exposure: ' + key);
      Object.defineProperty(__puiVueExposes, key, { value, enumerable: true });
    }
    function __puiVueExposeState<T>(key: string, handle: __puiVuePublicState<T>): void {
      if (!__puiVueStates.has(handle)) throw new Error('[Vue source] foreign state handle');
      let projection = __puiVuePublicStates.get(handle);
      if (!projection) {

        projection = Object.freeze({ get() { __puiVuePublicAlive(); return handle.get(); }, subscribe: handle.subscribe, unsubscribe: handle.unsubscribe, spec: handle.spec });
        __puiVuePublicStates.set(handle, projection);
      }
      __puiVueDeclare(key, projection);

    }
    function __puiVueExposeMethod<Args extends unknown[], Result>(key: string, callback: (...args: Args) => Result, project?: (value: Result) => Result): void {

      const boundary = __puiVueMethodChecks[key];
      __puiVueDeclare(key, (...args: unknown[]) => {
        __puiVuePublicAlive();
        if (!boundary.args(args)) throw new TypeError('[Vue source] invalid method arguments: ' + key);
        // The specialized predicate just checked the concrete declared argument tuple.
        const checkedArgs = args as Args;
        const result = callback(...checkedArgs);
        if (!boundary.result(result)) throw new TypeError('[Vue source] invalid method result: ' + key);
        return project ? project(result) : result;
      });
    }
    function __puiVueExposeEvent(key: string, _spec?: unknown): void {
      __puiVueEvents.add(key);
      __puiVueDeclare(key, Object.freeze({ kind: 'event' as const }));
    }
    function __puiVueEmit(run: __puiVueRun, key: string, payload?: unknown, options?: unknown): void {
      __puiVueRequireRun(run);
      if (!__puiVueEvents.has(key) || !__puiVueEventChecks[key](payload)) throw new TypeError('[Vue source] undeclared event or invalid payload: ' + key);
      __puiVueContext.emit(key as never, payload, options);
    }
    function __puiVueValidProp(key: string, value: unknown): boolean {
      const spec = __puiVuePropSpecs[key];
      return __puiVuePropChecks[key](value) && (!spec.options || spec.options.includes(value)) && (!spec.range || typeof value === 'number' && value >= (spec.range.min ?? -Infinity) && value <= (spec.range.max ?? Infinity));
    }
    function __puiVueResolveProps(raw: Record<string, unknown>, strict: boolean): Readonly<GeneratedResolvedProps> {
      const next: Record<string, unknown> = Object.create(null);
      for (const key of Object.keys(__puiVuePropSpecs)) {
        const spec = __puiVuePropSpecs[key], provided = Object.hasOwn(raw, key), candidate = raw[key];
        const empty = spec.empty ?? 'fallback';
        if (provided && candidate != null && __puiVueValidProp(key, candidate)) {
          next[key] = candidate; __puiVuePreviousValid[key] = candidate; continue;
        }
        if (provided && candidate == null && empty === 'accept') { next[key] = null; continue; }
        const required = strict && empty === 'error';
        let found = false;
        function take(value: unknown): void {
          if (found || value === undefined || required && value === null || value !== null && !__puiVueValidProp(key, value)) return;
          next[key] = value; found = true;
        }
        if (provided && Object.hasOwn(__puiVuePreviousValid, key)) take(__puiVuePreviousValid[key]);
        for (const layer of __puiVueDefaults) if (Object.hasOwn(layer, key)) take(layer[key]);
        if (Object.hasOwn(spec, 'default')) take(spec.default);
        if (!found && required) throw new TypeError('[Vue source] missing/invalid required prop: ' + key);
        if (!found) next[key] = null;
        if (provided && next[key] !== null) __puiVuePreviousValid[key] = next[key];
      }
      // Every declared key above passed its specialized predicate or canonical null fallback.
      const snapshot = Object.freeze(next) as Readonly<GeneratedResolvedProps>;
      return snapshot;
    }
    function __puiVueDefineProps(declarations: Record<string, __puiVuePropSpec>): void {
      for (const key of Object.keys(declarations)) {
        const incoming = declarations[key], previous = __puiVuePropSpecs[key];
        if (!Object.hasOwn(__puiVuePropChecks, key)) throw new Error('[Vue source] undeclared prop schema');
        const rank = (empty: string) => empty === 'accept' ? 0 : empty === 'error' ? 2 : 1;
        if (previous && incoming.empty && rank(incoming.empty) > rank(previous.empty ?? 'fallback')) throw new Error('[Vue source] props cannot become stricter');
        if (previous?.options && (!incoming.options || previous.options.some((value) => !incoming.options!.includes(value)))) throw new Error('[Vue source] prop options cannot narrow');
        if (previous?.range && ((incoming.range?.min ?? -Infinity) > (previous.range.min ?? -Infinity) || (incoming.range?.max ?? Infinity) < (previous.range.max ?? Infinity))) throw new Error('[Vue source] prop range cannot narrow');
        __puiVuePropSpecs[key] = { ...previous, ...incoming, ...(previous ? { empty: previous.empty ?? 'fallback' } : {}), ...(previous && Object.hasOwn(previous, 'default') ? { default: previous.default } : {}) };
      }
      __puiVueProps = __puiVueResolveProps(__puiVueRawProps, false);


    }
    function __puiVueSetDefaults(defaults: Record<string, unknown>): void {
      for (const key of Object.keys(defaults)) if (!Object.hasOwn(__puiVuePropSpecs, key)) throw new Error('[Vue source] defaults require a declared prop');
      __puiVueDefaults.unshift({ ...defaults });
      __puiVueProps = __puiVueResolveProps(__puiVueRawProps, false);


    }
    function __puiVueWatchProps(keys: readonly string[] | null, callback: (run: __puiVueRun, next: Readonly<GeneratedResolvedProps>, previous: Readonly<GeneratedResolvedProps>, info: __puiVueWatchInfo) => void): () => void {
      if (keys && (!keys.length || keys.some((key) => !Object.hasOwn(__puiVuePropSpecs, key)))) throw new Error('[Vue source] watch requires declared prop keys');
      const entry = { keys: keys && [...keys], callback, active: true };
      __puiVueWatchers.push(entry);
      return () => { __puiVueAlive(); entry.active = false; };
    }

    function __puiVueReadProps(run: __puiVueRun): Readonly<GeneratedResolvedProps> { __puiVueRequireRun(run); return __puiVuePropsWindow?.resolved ?? __puiVueProps; }
    function __puiVueReadRawProps(run: __puiVueRun): Readonly<Record<string, unknown>> { __puiVueRequireRun(run); return __puiVuePropsWindow?.raw ?? Object.freeze({ ...__puiVueRawProps }); }
    function __puiVueIsProvided(run: __puiVueRun, key: string): boolean { __puiVueRequireRun(run); return Object.hasOwn(__puiVuePropsWindow?.raw ?? __puiVueRawProps, key); }
    function __puiVueGetHostProps(): Record<string, unknown> {
{ const __puiVueInitialAssociations = _props.instanceAssociations;
    if (__puiVueInitialAssociations !== undefined) {
      if (__puiVueInitialAssociations === null || typeof __puiVueInitialAssociations !== 'object' || Object.getPrototypeOf(__puiVueInitialAssociations) !== Object.prototype)
        throw new TypeError('[InstanceAssociations] expected a plain record');
      for (const key of Reflect.ownKeys(__puiVueInitialAssociations)) if (key !== 'controlLabel')
        throw new TypeError('[InstanceAssociations] unknown association key');
      if (Object.prototype.hasOwnProperty.call(__puiVueInitialAssociations, 'controlLabel') && Reflect.get(__puiVueInitialAssociations, 'controlLabel') != null)
        throw new Error('[ControlLabel] this Prototype has not declared Label or target participation');
    }
  }
      // Read the authored host snapshot, bypassing Vue Boolean casts and camelization.
      const raw: Record<string, unknown> = Object.create(null);
      for (const key of Object.keys(__puiVueInstance.vnode.props ?? {})) {
        const value = __puiVueInstance.vnode.props![key];
        if (['key', 'ref', 'ref_for', 'ref_key', 'instanceAssociations', 'instance-associations'].includes(key) || key.startsWith('onVnode')) continue;
        if (!Object.hasOwn(__puiVuePropChecks, key) && (
          ['class', 'hostClass', 'surfaceClass', 'style', 'hostStyle', 'surfaceStyle'].includes(key) ||
          /^on[A-Z]/.test(key) && typeof value === 'function'
        )) continue;
        raw[key] = value;
      }
      return raw;
    }
    function __puiVueNotifyProps(): void {
      if (__puiVueDisposed || __puiVueDisposing) return;
{ const __puiVueAssociations = _props.instanceAssociations;
    if (__puiVueAssociations !== undefined) {
      if (__puiVueAssociations === null || typeof __puiVueAssociations !== 'object' || Object.getPrototypeOf(__puiVueAssociations) !== Object.prototype)
        throw new TypeError('[InstanceAssociations] expected a plain record');
      for (const key of Reflect.ownKeys(__puiVueAssociations)) if (key !== 'controlLabel')
        throw new TypeError('[InstanceAssociations] unknown association key');
      if (Object.prototype.hasOwnProperty.call(__puiVueAssociations, 'controlLabel') && Reflect.get(__puiVueAssociations, 'controlLabel') != null)
        throw new Error('[ControlLabel] this Prototype has not declared Label or target participation');
    }
  }
      const raw = __puiVueGetHostProps();
      const changed = Object.keys({ ...__puiVueRawProps, ...raw }).some((key) => Object.hasOwn(raw, key) !== Object.hasOwn(__puiVueRawProps, key) || !Object.is(raw[key], __puiVueRawProps[key]));
      if (!changed) return;

      const previous = __puiVueProps;
      const next = __puiVueResolveProps(raw, true);
      __puiVueRawProps = raw; __puiVueProps = next;


      const previousWindow = __puiVuePropsWindow;
      __puiVuePropsWindow = {raw: Object.freeze({...raw}), resolved: next};
      try {
      const all = Object.keys(__puiVuePropSpecs).filter((key) => !Object.is(Reflect.get(previous, key), Reflect.get(next, key)));

      for (const watcher of __puiVueWatchers) {
        if (!watcher.active) continue;
        const matched = watcher.keys ? watcher.keys.filter((key) => all.includes(key)) : all;
        if (matched.length) watcher.callback(__puiVueRunValue, next, previous, { changedKeysAll: all, changedKeysMatched: matched });
      }

      } finally { __puiVuePropsWindow = previousWindow; }
    }
    function __puiVueActiveFrame(frame: __puiVueFrame): void {
      __puiVueAlive();
      if (!frame.epoch.active || frame.epoch !== __puiVueCurrentEpoch || !__puiVuePresent.value) throw new Error('[Vue source] stale view work');
    }
    function __puiVueReadFrameProps(frame: __puiVueFrame): Readonly<GeneratedResolvedProps> { __puiVueActiveFrame(frame); return __puiVueProps; }
    function __puiVueReadFrameRawProps(frame: __puiVueFrame): Readonly<Record<string, unknown>> { __puiVueActiveFrame(frame); return Object.freeze({ ...__puiVueRawProps }); }
    function __puiVueFrameProvided(frame: __puiVueFrame, key: string): boolean { __puiVueActiveFrame(frame); return Object.hasOwn(__puiVueRawProps, key); }
    function __puiVueChildren(input: unknown): __puiVueVue.VNode | string | number | null | __puiVueVue.VNodeArrayChildren {
      if (input === null) return null;
      if (Array.isArray(input)) return input.map(__puiVueChildren);
      if (typeof input === 'string' || typeof input === 'number' || __puiVueVue.isVNode(input)) return input;
      throw new TypeError('[Vue source] invalid template child');
    }
    function __puiVueElement(frame: __puiVueFrame, tag: string, ...args: unknown[]): __puiVueVue.VNode {
      __puiVueActiveFrame(frame);
      let children: unknown = null;
      let attributes: Record<string, string> | null = null;
      if (args.length > 1 || args.length === 1 && args[0] !== null && typeof args[0] === 'object' && !Array.isArray(args[0]) && !__puiVueVue.isVNode(args[0])) {
        if (!__puiVueIsRecord(args[0])) throw new Error('[Vue source] unsupported template props');
        const keys = Object.keys(args[0]);
        if (keys.length) throw new Error('[Vue source] unsupported template props');
        children = args.length > 1 ? args[1] : null;
      } else if (args.length) children = args[0];
      const normalized = __puiVueChildren(children);
      return __puiVueVue.h(tag, attributes, normalized ?? undefined);
    }
    function __puiVueSlot(frame: __puiVueFrame): __puiVueVue.VNode {
      __puiVueActiveFrame(frame);
      if (frame.slotUsed) throw new Error('[Vue source] multiple slots are not supported');
      frame.slotUsed = true;
      return __puiVueVue.h(__puiVueSlotView, { read: () => {
        __puiVueSlotRevision.value;
        if (__puiVueDisposed || __puiVueDisposing || !frame.epoch.active || frame.epoch !== __puiVueCurrentEpoch || !__puiVuePresent.value) return null;
        return __puiVueContext.slots.default?.() ?? null;
      } });
    }


    const __puiVueRenderer = ((): ((frame: __puiVueFrame) => __puiVueVue.VNodeChild) | void => {
      try {
        const renderer = ((def: void) => {
        // Source "context.proto.ts":3:9
        const value = __puiVueCreateState('number.discrete', "value", 0);
        // Source "context.proto.ts":4:9
        const missing = __puiVueCreateState('bool', "missing", false);
        // Source "context.proto.ts":5:3
        __puiVueExposeState("value", value);
        // Source "context.proto.ts":5:35
        __puiVueExposeState("missing", missing);
        // Source "context.proto.ts":6:3
        __puiVueScope.subscribe(__puiVueContextKey0, 'required', (next, prev) => ((run: __puiVueRun, next: { "value": number }) => {
          // Source "context.proto.ts":6:42
          value.set((next)["value"]);
          // Source "context.proto.ts":6:64
          __puiVueRequestUpdate(run);
        })(__puiVueRunValue, next as { "value": number; }));
        // Source "context.proto.ts":7:3
        __puiVueScope.subscribe(__puiVueContextKey1, 'optional');
        // Source "context.proto.ts":8:3
        __puiVueLife.created.push((run: __puiVueRun) => {
          // Source "context.proto.ts":8:33
          value.set(((__puiVueReadContext(run, __puiVueContextKey0, false) as { "value": number }))["value"]);
          // Source "context.proto.ts":8:72
          missing.set(((__puiVueReadContext(run, __puiVueContextKey1, true) as { "value": number } | null) === null));
        });
        // Source "context.proto.ts":9:3
        return (render: __puiVueFrame) => {
          // Source "context.proto.ts":9:18
          return __puiVueElement(render, "output", {  }, ((__puiVueReadFrameContext(render, __puiVueContextKey0, false) as { "value": number }))["value"]);
        };
      })(undefined);
        __puiVueSetup = false;
        __puiVueRawProps = __puiVueGetHostProps();

        __puiVueProps = __puiVueResolveProps(__puiVueRawProps, true);

        

        __puiVueInvokeLife('created');
        return renderer;
      } catch (error) {
        __puiVueDisposing = true;
        try {  }
        finally {
          try {  }
          finally {
            try { __puiVueScope.dispose(); }
            finally {
              __puiVueDisposed = true; 
              for (const cleanup of __puiVueStateCleanup) cleanup();
              __puiVueStateQueue.length = 0; __puiVueWatchers.length = 0;
            }
          }
        }
        throw error;
      }
    })();

    const __puiVueHandle: GeneratedHandle = Object.freeze({
      update() { __puiVuePublicAlive(); __puiVueRequestUpdate(__puiVueRunValue); },
      getExposes() { __puiVuePublicAlive(); return __puiVueExposes as GeneratedExposes; },
    });
    __puiVueContext.expose(__puiVueHandle);

    const __puiVueView = __puiVueVue.defineComponent({
      name: 'CompiledView', inheritAttrs: false,
      props: { revision: { type: Number, required: true } },
      setup(viewProps) {
        let epoch: __puiVueEpoch = { id: ++__puiVueEpochId, active: true, committed: false };
        __puiVueCurrentEpoch = epoch;
        const activation = __puiVueVue.shallowRef(0);
        let deactivated = false;

        let drawnRevision = -1, drawnActivation = -1, committedRevision = -1;
        let cached: __puiVueVue.VNodeArrayChildren = [];
        let root: HTMLElement | null = null;
        function bindRoot(element: Element | __puiVueVue.ComponentPublicInstance | null): void {
          if (!element) { __puiVueUnbindRoot(epoch); return; }
          if (!(element instanceof HTMLElement)) throw new TypeError('[Vue source] Root must be an HTMLElement');
          root = element;
          if (epoch !== __puiVueCurrentEpoch || !epoch.active) return;
          if (__puiVueRootEpoch && (__puiVueRootElement !== root || __puiVueRootEpoch !== epoch)) __puiVueUnbindRoot(__puiVueRootEpoch);
          __puiVueRootElement = root; __puiVueRootEpoch = root ? epoch : undefined;
          if (epoch.committed) {

            

          }
        }
        function commit(): void {

          if (__puiVueDisposed || __puiVueDisposing || deactivated || !epoch.active || epoch !== __puiVueCurrentEpoch || !__puiVuePresent.value) return;
          if (!epoch.committed) {

            epoch.committed = true;
            committedRevision = drawnRevision;

            


            __puiVueInvokeLife('mounted');

          }
          else if (committedRevision !== drawnRevision) { committedRevision = drawnRevision; __puiVueInvokeLife('updated'); }
        }
        __puiVueVue.onMounted(commit);
        __puiVueVue.onUpdated(commit);
        __puiVueVue.onBeforeUnmount(() => { epoch.active = false; __puiVueUnbindRoot(epoch); });
        __puiVueVue.onUnmounted(() => { __puiVueCommitUnmount(epoch); });
        __puiVueVue.onDeactivated(() => { deactivated = true; __puiVueCommitUnmount(epoch); });
        __puiVueVue.onActivated(() => {
          if (!deactivated || __puiVueDisposed || __puiVueDisposing) return;
          deactivated = false;
          epoch = { id: ++__puiVueEpochId, active: true, committed: false };
          __puiVueCurrentEpoch = epoch;
          __puiVueRootElement = root; __puiVueRootEpoch = root ? epoch : undefined;
          activation.value += 1;
        });
        return () => {
          __puiVueHostRevision.value;
          const revision = viewProps.revision!, active = activation.value;
          if (__puiVueDisposed || __puiVueDisposing || deactivated || !epoch.active || epoch !== __puiVueCurrentEpoch || !__puiVuePresent.value) return null;
          if (drawnRevision !== revision || drawnActivation !== active) {
            drawnRevision = revision; drawnActivation = active;
            __puiVueRequested = false;
            const frame: __puiVueFrame = { epoch, slotUsed: false };
            const children = typeof __puiVueRenderer === 'function' ? __puiVueChildren(__puiVueRenderer(frame)) : __puiVueSlot(frame);
            cached = children == null ? [] : Array.isArray(children) ? children : [children];
          }
          const tag = 'div';
          if (['input', 'textarea', 'img'].includes(tag) && cached.length) throw new Error('[Template] physical control Root requires empty children');
          const physical = __puiVueVue.h(tag, { 'data-pui-root': '', ref: bindRoot }, cached.length ? cached : undefined);
          return physical;
        };
      },
    });
    __puiVueVue.onBeforeUpdate(() => { __puiVueNotifyProps(); __puiVueSlotRevision.value += 1; });
    __puiVueVue.onBeforeUnmount(() => {
      __puiVueDisposing = true;
      __puiVueQueueTicket += 1;
      __puiVueRequested = false;
      if (__puiVueCurrentEpoch) __puiVueUnbindRoot(__puiVueCurrentEpoch);
      if (__puiVueCurrentEpoch) __puiVueCurrentEpoch.active = false;
    });
    __puiVueVue.onUnmounted(() => {
      __puiVueInternalTeardown = true;
      try { __puiVueInvokeLife('beforeDispose'); }

      finally {
        try { __puiVueScope.dispose(); }

        finally {
          try {  }

          finally {
            try {  }

            finally {
              __puiVueInternalTeardown = false; __puiVueDisposed = true;
              
              for (const cleanup of __puiVueStateCleanup) cleanup();
              __puiVueStateQueue.length = 0; __puiVueWatchers.length = 0;
            }
          }
        }
      }
    });
    return () => __puiVuePresent.value && !__puiVueDisposing ? __puiVueVue.h(__puiVueView, { revision: __puiVueRevision.value }) : null;
  },
});

export default ContextConsumer;

//# sourceMappingURL=ContextConsumer.ts.map
