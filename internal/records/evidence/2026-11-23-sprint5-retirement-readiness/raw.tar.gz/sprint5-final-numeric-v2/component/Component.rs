// Direct checked-source GPUI component. Supporting files are ordinary editable Rust.
  
  pub use proto_ui_gpui_native as native;
  pub use native::gpui_native_owner::{ControlLabelRef, InstanceAssociations};
  use gpui::{prelude::*, App, Context, FocusHandle, Subscription, Window};
  use std::rc::Rc;
  use serde_json::Value as Json;
  use native::gpui_native_owner::*;
  
  
  fn style_vocabulary() -> &'static native::gpui_native_style::StyleVocabulary {
      static VOCABULARY: std::sync::OnceLock<native::gpui_native_style::StyleVocabulary> = std::sync::OnceLock::new();
      VOCABULARY.get_or_init(|| native::gpui_native_style::StyleVocabulary::from_json(include_str!(".proto-ui/fixtures/style-tokens.json")).expect("compiler-produced style vocabulary"))
  }
  fn accepts_context(key: &str, value: &Json) -> bool {
      match key {
          
          _ => false,
      }
  }
  fn accepts_props(value: &Json) -> bool { value.is_object() && value.get("disabled").map_or(true, |prop| prop.is_null() || prop.is_boolean()) }
  fn prop_valid(key: &str, value: &Json) -> bool { match key { "disabled" => value.is_boolean(), _ => false } }
  fn check_method(name: &str, arguments: &[Value]) { match name {
          "accept" => if !(arguments.len() <= 1 && arguments.get(0).map_or(false, |value| (value).try_data().is_some_and(|data| data.as_f64().is_some_and(f64::is_finite)))) { value_type_error("invalid exposed method arguments") },
        "setDisabled" => if !(arguments.len() <= 1 && arguments.get(0).map_or(false, |value| (value).try_data().is_some_and(|data| data.is_boolean()))) { value_type_error("invalid exposed method arguments") },
        "setReadOnly" => if !(arguments.len() <= 1 && arguments.get(0).map_or(false, |value| (value).try_data().is_some_and(|data| data.is_boolean()))) { value_type_error("invalid exposed method arguments") },
          _ => value_error("unknown exposed method"),
  } }
  
  #[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData0 {
    #[serde(rename = "disabled", default, skip_serializing_if = "Option::is_none")]
    pub field_0: Option<bool>,
}
  
  pub type GeneratedProps = GeneratedData0;
  
  #[derive(Clone)]
  pub struct CompiledComponentHandle { pub owner: OwnerRef }
  impl CompiledComponentHandle {
      pub fn state_0(&self) -> Result<f64, Value> { self.state("value").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_1(&self) -> Result<f64, Value> { self.state("calls").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_2(&self) -> Result<f64, Value> { self.state("once").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_3(&self) -> Result<f64, Value> { self.state("onceZero").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_4(&self) -> Result<f64, Value> { self.state("onceOne").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_5(&self) -> Result<f64, Value> { self.state("prunedZero").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_6(&self) -> Result<f64, Value> { self.state("prunedOne").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_7(&self) -> Result<f64, Value> { self.state("prunedTwo").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_8(&self) -> Result<f64, Value> { self.state("beforeDeclaration").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_9(&self) -> Result<f64, Value> { self.state("afterDeclaration").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_10(&self) -> Result<f64, Value> { self.state("obsolete").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn method_12(&self, argument_0: f64, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![Value::json(serde_json::to_value(argument_0).expect("portable argument"))];
        let callback = self.owner.borrow().exposes.get("accept").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("accept", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_13(&self, argument_0: bool, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![Value::json(serde_json::to_value(argument_0).expect("portable argument"))];
        let callback = self.owner.borrow().exposes.get("setDisabled").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("setDisabled", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_14(&self, argument_0: bool, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![Value::json(serde_json::to_value(argument_0).expect("portable argument"))];
        let callback = self.owner.borrow().exposes.get("setReadOnly").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("setReadOnly", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
      pub fn owner(&self) -> OwnerWeak { Rc::downgrade(&self.owner) }
      pub fn state(&self, name: &str) -> Result<Json, Value> { catch_authored(|| { let state=self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed State")); state.get().data() }) }
      pub fn call(&self, name: &str, arguments: Vec<Json>, window: &mut Window, cx: &mut App) -> Result<Json, Value> {
          let outcome = catch_authored(|| {
          refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
          let callback = self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed method"));
          let arguments: Vec<Value> = arguments.into_iter().map(Value::json).collect(); check_method(name, &arguments);
          let result = invoke(&self.owner, "expose-method", &callback, arguments);
          let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
          if matches!(result, Value::Undefined) { Json::Null } else { result.data() }
          });
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome
      }
      pub fn host_target(&self) -> Result<Value, Value> { catch_authored(|| { ensure(&self.owner()); Value::HostTarget(self.owner()) }) }
      pub fn take_events(&self) -> Vec<(String, Json)> { std::mem::take(&mut self.owner.borrow_mut().emitted) }
      pub fn take_failures(&self) -> Vec<NativeFailure> { take_native_failures(&self.owner) }
      pub fn dispose(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
          catch_authored(|| {
          let drive = self.owner.borrow().native_drive.clone();
          let failure = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| Owner::dispose(&self.owner)));
          let driven = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| { if let Some(drive) = drive { drive(window, cx); } }));
          if let Err(failure) = failure { std::panic::resume_unwind(failure); }
          if let Err(failure) = driven { std::panic::resume_unwind(failure); }
          })
      }
  }
  pub struct CompiledComponent { pub owner: OwnerRef, focus: FocusHandle, window_input: Option<FocusHandle>, _focus_subscriptions: Vec<Subscription>, _window_activation: Option<(gpui::WindowId, Subscription)>, _focus_lost: Option<Subscription>, _global_key_capture: Option<Subscription>, _entry_readiness: Option<(gpui::WindowId, Subscription)> }
  impl CompiledComponent {
      pub fn create_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> { Self::create(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn create(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          Self::create_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn create_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          let mut failure = None;
          let entity = cx.new(|cx| Self::new_with_associations(raw_props, parent, associations, window, cx).unwrap_or_else(|error| {
              failure = Some(error);
              // A failed construction still returns normally through GPUI's
              // entity insertion. This inert temporary is dropped immediately
              // below; it is never published or mounted as a native component.
              let owner = Owner::new(Json::Object(Default::default()), Default::default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
              { let mut owner = owner.borrow_mut(); owner.disposed = true; owner.present = false; }
              Self { owner, focus: cx.focus_handle(), window_input: None, _focus_subscriptions: Vec::new(), _window_activation: None, _focus_lost: None, _global_key_capture: None, _entry_readiness: None }
          }));
          match failure { Some(error) => Err(error), None => Ok(entity) }
      }
      pub fn new_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> { Self::new(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn new(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          Self::new_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn new_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          catch_authored(|| {
          let owner_ref = Owner::new(raw_props, parent.unwrap_or_default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
          initialize_instance_associations(&owner_ref, associations);
          let owner = Rc::downgrade(&owner_ref);
          let focus = cx.focus_handle();
          let view = cx.entity().downgrade();
          let drive_owner=owner.clone(); let drive_focus=focus.clone();
          let driving = Rc::new(std::cell::Cell::new(false));
          let drive_pending = Rc::new(std::cell::Cell::new(false));
          let drive: Drive = Rc::new(move |window, cx| {
              // Platform effects need owner storage and its real FocusHandle,
              // not another lease of the generated component. Preserve their
              // synchronous effect (notably physical focus) under public calls.
              if !driving.replace(true) {
                  if let Some(owner)=drive_owner.upgrade() {
                      native_host_callback(&owner, "drive", || { modules_drive(&owner, &drive_focus, window, cx); drive_queued_focus(&owner, window, cx); });
                  }
                  driving.set(false);
              }
              if drive_pending.replace(true) { return; }
              let view=view.clone(); let pending=drive_pending.clone();
              // A public handle can be called from Entity::update. Return the
              // current host lease before requesting another component update.
              // Authored calls, State writes and platform commands remain
              // synchronous; component refresh is coalesced at the host boundary.
              window.defer(cx, move |window, cx| {
                  pending.set(false);
                  let _ = view.update(cx, |view, cx| { if let Err(error) = view.drive(window, cx) { report_native_failure(&view.owner, "drive", error); } });
              });
          });
          { let mut owner = owner_ref.borrow_mut(); owner.native_drive = Some(drive); owner.window_id = Some(window.window_handle().window_id()); }
  
          configure_native_atoms(&owner_ref, false, false);
          refresh_native_atoms(&owner_ref, window, cx);
          let _lexical_owner = enter_lexical_owner(&owner);
          let renderer = { let owner = owner.clone();  Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_646566: Value = arg(&arguments, 0);
            let v_76616c7565: LexicalBinding<Value> = lexical_binding();
            let v_64697361626c6564: LexicalBinding<Value> = lexical_binding();
            let v_726561644f6e6c79: LexicalBinding<Value> = lexical_binding();
            let v_63616c6c73: LexicalBinding<Value> = lexical_binding();
            let v_6f6e6365: LexicalBinding<Value> = lexical_binding();
            let v_6f6e63655a65726f: LexicalBinding<Value> = lexical_binding();
            let v_6f6e63654f6e65: LexicalBinding<Value> = lexical_binding();
            let v_7072756e65645a65726f: LexicalBinding<Value> = lexical_binding();
            let v_7072756e65644f6e65: LexicalBinding<Value> = lexical_binding();
            let v_7072756e656454776f: LexicalBinding<Value> = lexical_binding();
            let v_6265666f72654465636c61726174696f6e: LexicalBinding<Value> = lexical_binding();
            let v_61667465724465636c61726174696f6e: LexicalBinding<Value> = lexical_binding();
            let v_6f62736f6c657465: LexicalBinding<Value> = lexical_binding();
            let v_61636365737369626c65: LexicalBinding<Value> = lexical_binding();
            // Source "value.proto.ts":48:5
            let v_6465636c6172654f7264657265644e756d65726963 = {  let v_61636365737369626c65 = v_61636365737369626c65.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "value.proto.ts":49:7
                { let v_7075695f6e61746976655f30 = v_61636365737369626c65.read(); accessible_action_spec(&(v_7075695f6e61746976655f30.clone()).owner(), Value::string("setValue"), record(vec![("event", Value::string("host:ordered-numeric"))])) };
                Value::Undefined
            })) };
            // Source "value.proto.ts":7:5
            { let v_7075695f6e61746976655f31 = v_646566.clone(); props_define(&owner, record(vec![("disabled", record(vec![("type", Value::string("boolean")), ("default", Value::boolean(false))]))])) };
            // Source "value.proto.ts":8:11
            v_76616c7565.initialize({ let v_7075695f6e61746976655f32 = v_646566.clone(); create_state(&owner, "range", Value::string("value"), Value::number(0.5_f64), record(vec![("min", Value::number(0.0_f64)), ("max", Value::number(1.0_f64))])) });
            // Source "value.proto.ts":9:11
            let v_6d696e696d756d = { let v_7075695f6e61746976655f33 = v_646566.clone(); create_state(&owner, "discrete", Value::string("minimum"), Value::number(0.0_f64), Value::Undefined) };
            // Source "value.proto.ts":10:11
            let v_6d6178696d756d = { let v_7075695f6e61746976655f34 = v_646566.clone(); create_state(&owner, "discrete", Value::string("maximum"), Value::number(1.0_f64), Value::Undefined) };
            // Source "value.proto.ts":11:11
            v_64697361626c6564.initialize({ let v_7075695f6e61746976655f35 = v_646566.clone(); create_state(&owner, "bool", Value::string("disabled"), Value::boolean(false), Value::Undefined) });
            // Source "value.proto.ts":12:11
            v_726561644f6e6c79.initialize({ let v_7075695f6e61746976655f36 = v_646566.clone(); create_state(&owner, "bool", Value::string("readOnly"), Value::boolean(false), Value::Undefined) });
            // Source "value.proto.ts":13:11
            let v_76616c756554657874 = { let v_7075695f6e61746976655f37 = v_646566.clone(); create_state(&owner, "string", Value::string("valueText"), Value::string("Half"), Value::Undefined) };
            // Source "value.proto.ts":14:11
            v_63616c6c73.initialize({ let v_7075695f6e61746976655f38 = v_646566.clone(); create_state(&owner, "discrete", Value::string("calls"), Value::number(0.0_f64), Value::Undefined) });
            // Source "value.proto.ts":15:11
            v_6f6e6365.initialize({ let v_7075695f6e61746976655f39 = v_646566.clone(); create_state(&owner, "discrete", Value::string("once"), Value::number(0.0_f64), Value::Undefined) });
            // Source "value.proto.ts":16:11
            v_6f6e63655a65726f.initialize({ let v_7075695f6e61746976655f3130 = v_646566.clone(); create_state(&owner, "discrete", Value::string("onceZero"), Value::number(0.0_f64), Value::Undefined) });
            // Source "value.proto.ts":17:11
            v_6f6e63654f6e65.initialize({ let v_7075695f6e61746976655f3131 = v_646566.clone(); create_state(&owner, "discrete", Value::string("onceOne"), Value::number(0.0_f64), Value::Undefined) });
            // Source "value.proto.ts":18:11
            v_7072756e65645a65726f.initialize({ let v_7075695f6e61746976655f3132 = v_646566.clone(); create_state(&owner, "discrete", Value::string("prunedZero"), Value::number(0.0_f64), Value::Undefined) });
            // Source "value.proto.ts":19:11
            v_7072756e65644f6e65.initialize({ let v_7075695f6e61746976655f3133 = v_646566.clone(); create_state(&owner, "discrete", Value::string("prunedOne"), Value::number(0.0_f64), Value::Undefined) });
            // Source "value.proto.ts":20:11
            v_7072756e656454776f.initialize({ let v_7075695f6e61746976655f3134 = v_646566.clone(); create_state(&owner, "discrete", Value::string("prunedTwo"), Value::number(0.0_f64), Value::Undefined) });
            // Source "value.proto.ts":21:11
            v_6265666f72654465636c61726174696f6e.initialize({ let v_7075695f6e61746976655f3135 = v_646566.clone(); create_state(&owner, "discrete", Value::string("beforeDeclaration"), Value::number(0.0_f64), Value::Undefined) });
            // Source "value.proto.ts":22:11
            v_61667465724465636c61726174696f6e.initialize({ let v_7075695f6e61746976655f3136 = v_646566.clone(); create_state(&owner, "discrete", Value::string("afterDeclaration"), Value::number(0.0_f64), Value::Undefined) });
            // Source "value.proto.ts":23:11
            v_6f62736f6c657465.initialize({ let v_7075695f6e61746976655f3137 = v_646566.clone(); create_state(&owner, "discrete", Value::string("obsolete"), Value::number(0.0_f64), Value::Undefined) });
            // Source "value.proto.ts":24:11
            v_61636365737369626c65.initialize(native_builtin_hook(&owner, "asAccessible", || as_accessible(&owner)));
            // Source "value.proto.ts":25:5
            { let v_7075695f6e61746976655f3138 = v_61636365737369626c65.read(); accessible_role(&(v_7075695f6e61746976655f3138.clone()).owner(), Value::string("slider")) };
            // Source "value.proto.ts":26:5
            { let v_7075695f6e61746976655f3139 = v_61636365737369626c65.read(); accessible_text(&(v_7075695f6e61746976655f3139.clone()).owner(), "name", Value::string("Native value request")) };
            // Source "value.proto.ts":27:5
            { let v_7075695f6e61746976655f3230 = v_61636365737369626c65.read(); accessible_state(&(v_7075695f6e61746976655f3230.clone()).owner(), Value::string("valueNow"), v_76616c7565.read(), Value::Undefined) };
            // Source "value.proto.ts":28:5
            { let v_7075695f6e61746976655f3231 = v_61636365737369626c65.read(); accessible_state(&(v_7075695f6e61746976655f3231.clone()).owner(), Value::string("valueMin"), v_6d696e696d756d.clone(), Value::Undefined) };
            // Source "value.proto.ts":29:5
            { let v_7075695f6e61746976655f3232 = v_61636365737369626c65.read(); accessible_state(&(v_7075695f6e61746976655f3232.clone()).owner(), Value::string("valueMax"), v_6d6178696d756d.clone(), Value::Undefined) };
            // Source "value.proto.ts":30:5
            { let v_7075695f6e61746976655f3233 = v_61636365737369626c65.read(); accessible_state(&(v_7075695f6e61746976655f3233.clone()).owner(), Value::string("valueText"), v_76616c756554657874.clone(), Value::Undefined) };
            // Source "value.proto.ts":31:5
            { let v_7075695f6e61746976655f3234 = v_61636365737369626c65.read(); accessible_state(&(v_7075695f6e61746976655f3234.clone()).owner(), Value::string("disabled"), v_64697361626c6564.read(), Value::Undefined) };
            // Source "value.proto.ts":32:5
            { let v_7075695f6e61746976655f3235 = v_61636365737369626c65.read(); accessible_state(&(v_7075695f6e61746976655f3235.clone()).owner(), Value::string("readOnly"), v_726561644f6e6c79.read(), Value::Undefined) };
            // Source "value.proto.ts":33:5
            { let v_7075695f6e61746976655f3236 = v_646566.clone(); register_life(&owner, "created", {  let v_64697361626c6564 = v_64697361626c6564.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f35373062316564373864303130366237: Value = arg(&arguments, 0);
                // Source "value.proto.ts":33:38
                return { let v_7075695f6e61746976655f3237 = v_64697361626c6564.read(); state_set(v_7075695f6e61746976655f3237.clone(), Value::boolean((({ let v_7075695f6e61746976655f3238 = v_72756e5f5f35373062316564373864303130366237.clone(); read_props(&(v_7075695f6e61746976655f3238.clone()).owner(), false) }).member("disabled", false)).bool()), Value::Undefined) };
            })) }) };
            // Source "value.proto.ts":36:5
            if false {
                // Source "value.proto.ts":36:16
                { let v_7075695f6e61746976655f3239 = v_61636365737369626c65.read(); accessible_action_spec(&(v_7075695f6e61746976655f3239.clone()).owner(), Value::string("setValue"), record(vec![("event", Value::string("host:pruned-numeric"))])) };
            }
            // Source "value.proto.ts":37:5
            { let v_7075695f6e61746976655f3330 = v_646566.clone(); listen_numeric_value(&owner, Value::string("host:pruned-numeric"), false, {  let v_7072756e65645a65726f = v_7072756e65645a65726f.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "value.proto.ts":37:47
                return { let v_7075695f6e61746976655f3331 = v_7072756e65645a65726f.read(); state_set(v_7075695f6e61746976655f3331.clone(), Value::number({ let pui_native_32:f64=({ let v_7075695f6e61746976655f3334 = v_7072756e65645a65726f.read(); Value::number(((v_7075695f6e61746976655f3334.clone()).get()).num()) }).num(); let pui_native_33:f64=1.0_f64; pui_native_32 + pui_native_33 }), Value::Undefined) };
            })) }, record(vec![("once", Value::boolean(true))])) };
            // Source "value.proto.ts":38:5
            { let v_7075695f6e61746976655f3335 = v_646566.clone(); listen_numeric_value(&owner, Value::string("host:pruned-numeric"), false, {  let v_7072756e65644f6e65 = v_7072756e65644f6e65.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_5f72756e5f5f31626139626161653935383731323663: Value = arg(&arguments, 0);
                // Source "value.proto.ts":38:51
                return { let v_7075695f6e61746976655f3336 = v_7072756e65644f6e65.read(); state_set(v_7075695f6e61746976655f3336.clone(), Value::number({ let pui_native_37:f64=({ let v_7075695f6e61746976655f3339 = v_7072756e65644f6e65.read(); Value::number(((v_7075695f6e61746976655f3339.clone()).get()).num()) }).num(); let pui_native_38:f64=1.0_f64; pui_native_37 + pui_native_38 }), Value::Undefined) };
            })) }, record(vec![("once", Value::boolean(true))])) };
            // Source "value.proto.ts":41:5
            { let v_7075695f6e61746976655f3430 = v_646566.clone(); listen_numeric_value(&owner, Value::string("host:pruned-numeric"), false, {  let v_7072756e656454776f = v_7072756e656454776f.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_5f72756e5f5f30346537396638303363653461653233: Value = arg(&arguments, 0);
                let v_5f6576656e74: Value = arg(&arguments, 1);
                // Source "value.proto.ts":41:59
                return { let v_7075695f6e61746976655f3431 = v_7072756e656454776f.read(); state_set(v_7075695f6e61746976655f3431.clone(), Value::number({ let pui_native_42:f64=({ let v_7075695f6e61746976655f3434 = v_7072756e656454776f.read(); Value::number(((v_7075695f6e61746976655f3434.clone()).get()).num()) }).num(); let pui_native_43:f64=1.0_f64; pui_native_42 + pui_native_43 }), Value::Undefined) };
            })) }, record(vec![("once", Value::boolean(true))])) };
            // Source "value.proto.ts":45:5
            { let v_7075695f6e61746976655f3435 = v_646566.clone(); listen(&owner, Value::string("host:ordered-numeric"), false, {  let v_6265666f72654465636c61726174696f6e = v_6265666f72654465636c61726174696f6e.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "value.proto.ts":45:48
                return { let v_7075695f6e61746976655f3436 = v_6265666f72654465636c61726174696f6e.read(); state_set(v_7075695f6e61746976655f3436.clone(), Value::number({ let pui_native_47:f64=({ let v_7075695f6e61746976655f3439 = v_6265666f72654465636c61726174696f6e.read(); Value::number(((v_7075695f6e61746976655f3439.clone()).get()).num()) }).num(); let pui_native_48:f64=1.0_f64; pui_native_47 + pui_native_48 }), Value::Undefined) };
            })) }, record(vec![("once", Value::boolean(true))])) };
            // Source "value.proto.ts":51:5
            v_6465636c6172654f7264657265644e756d65726963.call_authored(vec![]);
            // Source "value.proto.ts":52:5
            { let v_7075695f6e61746976655f3530 = v_646566.clone(); listen_numeric_value(&owner, Value::string("host:ordered-numeric"), false, {  let v_61667465724465636c61726174696f6e = v_61667465724465636c61726174696f6e.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "value.proto.ts":52:48
                return { let v_7075695f6e61746976655f3531 = v_61667465724465636c61726174696f6e.read(); state_set(v_7075695f6e61746976655f3531.clone(), Value::number({ let pui_native_52:f64=({ let v_7075695f6e61746976655f3534 = v_61667465724465636c61726174696f6e.read(); Value::number(((v_7075695f6e61746976655f3534.clone()).get()).num()) }).num(); let pui_native_53:f64=1.0_f64; pui_native_52 + pui_native_53 }), Value::Undefined) };
            })) }, record(vec![("once", Value::boolean(true))])) };
            // Source "value.proto.ts":55:5
            { let v_7075695f6e61746976655f3535 = v_61636365737369626c65.read(); accessible_action_spec(&(v_7075695f6e61746976655f3535.clone()).owner(), Value::string("setValue"), record(vec![("event", Value::string("host:obsolete-value"))])) };
            // Source "value.proto.ts":56:5
            { let v_7075695f6e61746976655f3536 = v_61636365737369626c65.read(); accessible_action_spec(&(v_7075695f6e61746976655f3536.clone()).owner(), Value::string("setValue"), record(vec![("event", Value::string("host:numeric-request"))])) };
            // Source "value.proto.ts":57:5
            { let v_7075695f6e61746976655f3537 = v_646566.clone(); expose_state(&owner, Value::string("value"), v_76616c7565.read()) };
            // Source "value.proto.ts":58:5
            { let v_7075695f6e61746976655f3538 = v_646566.clone(); expose_state(&owner, Value::string("calls"), v_63616c6c73.read()) };
            // Source "value.proto.ts":59:5
            { let v_7075695f6e61746976655f3539 = v_646566.clone(); expose_state(&owner, Value::string("once"), v_6f6e6365.read()) };
            // Source "value.proto.ts":60:5
            { let v_7075695f6e61746976655f3630 = v_646566.clone(); expose_state(&owner, Value::string("onceZero"), v_6f6e63655a65726f.read()) };
            // Source "value.proto.ts":61:5
            { let v_7075695f6e61746976655f3631 = v_646566.clone(); expose_state(&owner, Value::string("onceOne"), v_6f6e63654f6e65.read()) };
            // Source "value.proto.ts":62:5
            { let v_7075695f6e61746976655f3632 = v_646566.clone(); expose_state(&owner, Value::string("prunedZero"), v_7072756e65645a65726f.read()) };
            // Source "value.proto.ts":63:5
            { let v_7075695f6e61746976655f3633 = v_646566.clone(); expose_state(&owner, Value::string("prunedOne"), v_7072756e65644f6e65.read()) };
            // Source "value.proto.ts":64:5
            { let v_7075695f6e61746976655f3634 = v_646566.clone(); expose_state(&owner, Value::string("prunedTwo"), v_7072756e656454776f.read()) };
            // Source "value.proto.ts":65:5
            { let v_7075695f6e61746976655f3635 = v_646566.clone(); expose_state(&owner, Value::string("beforeDeclaration"), v_6265666f72654465636c61726174696f6e.read()) };
            // Source "value.proto.ts":66:5
            { let v_7075695f6e61746976655f3636 = v_646566.clone(); expose_state(&owner, Value::string("afterDeclaration"), v_61667465724465636c61726174696f6e.read()) };
            // Source "value.proto.ts":67:5
            { let v_7075695f6e61746976655f3637 = v_646566.clone(); expose_state(&owner, Value::string("obsolete"), v_6f62736f6c657465.read()) };
            // Source "value.proto.ts":68:5
            { let v_7075695f6e61746976655f3638 = v_646566.clone(); expose_event(&owner, Value::string("requested")) };
            // Source "value.proto.ts":69:5
            { let v_7075695f6e61746976655f3639 = v_646566.clone(); expose_method(&owner, Value::string("accept"), ({  let v_76616c7565 = v_76616c7565.clone(); let call:Rc<dyn Fn(f64)->Value>=Rc::new(move |argument_0: f64| -> Value {
                let v_6e6578745f5f62366230306637666262636564333834: f64 = argument_0;
                // Source "value.proto.ts":69:51
                return { let v_7075695f6e61746976655f3730 = v_76616c7565.read(); state_set(v_7075695f6e61746976655f3730.clone(), Value::number(v_6e6578745f5f62366230306637666262636564333834.clone()), Value::Undefined) };
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).num())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")) };
            // Source "value.proto.ts":70:5
            { let v_7075695f6e61746976655f3731 = v_646566.clone(); expose_method(&owner, Value::string("setDisabled"), ({  let v_64697361626c6564 = v_64697361626c6564.clone(); let call:Rc<dyn Fn(bool)->Value>=Rc::new(move |argument_0: bool| -> Value {
                let v_6e6578745f5f63303030346464343261666639373262: bool = argument_0;
                // Source "value.proto.ts":70:57
                return { let v_7075695f6e61746976655f3732 = v_64697361626c6564.read(); state_set(v_7075695f6e61746976655f3732.clone(), Value::boolean(v_6e6578745f5f63303030346464343261666639373262.clone()), Value::Undefined) };
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).bool())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")) };
            // Source "value.proto.ts":71:5
            { let v_7075695f6e61746976655f3733 = v_646566.clone(); expose_method(&owner, Value::string("setReadOnly"), ({  let v_726561644f6e6c79 = v_726561644f6e6c79.clone(); let call:Rc<dyn Fn(bool)->Value>=Rc::new(move |argument_0: bool| -> Value {
                let v_6e6578745f5f39623634333839353030393635663633: bool = argument_0;
                // Source "value.proto.ts":71:57
                return { let v_7075695f6e61746976655f3734 = v_726561644f6e6c79.read(); state_set(v_7075695f6e61746976655f3734.clone(), Value::boolean(v_6e6578745f5f39623634333839353030393635663633.clone()), Value::Undefined) };
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).bool())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")) };
            // Source "value.proto.ts":72:5
            { let v_7075695f6e61746976655f3735 = v_646566.clone(); listen_numeric_value(&owner, Value::string("host:obsolete-value"), false, {  let v_6f62736f6c657465 = v_6f62736f6c657465.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "value.proto.ts":72:47
                return { let v_7075695f6e61746976655f3736 = v_6f62736f6c657465.read(); state_set(v_7075695f6e61746976655f3736.clone(), Value::number({ let pui_native_77:f64=({ let v_7075695f6e61746976655f3739 = v_6f62736f6c657465.read(); Value::number(((v_7075695f6e61746976655f3739.clone()).get()).num()) }).num(); let pui_native_78:f64=1.0_f64; pui_native_77 + pui_native_78 }), Value::Undefined) };
            })) }, Value::Undefined) };
            // Source "value.proto.ts":73:5
            { let v_7075695f6e61746976655f3830 = v_646566.clone(); listen_numeric_value(&owner, Value::string("host:numeric-request"), false, {  let v_63616c6c73 = v_63616c6c73.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f30653735663166653263316666643133: Value = arg(&arguments, 0);
                let v_6f70617175655f5f30346433326531303164643861653533: Value = arg(&arguments, 1);
                // Source "value.proto.ts":74:13
                let v_6576656e745f5f66613338303238333364366535643032 = v_6f70617175655f5f30346433326531303164643861653533.clone();
                // Source "value.proto.ts":75:7
                if (({ let v_7075695f6e61746976655f3831 = v_72756e5f5f30653735663166653263316666643133.clone(); read_props(&(v_7075695f6e61746976655f3831.clone()).owner(), false) }).member("disabled", false)).bool() {
                    // Source "value.proto.ts":75:37
                    return Value::Undefined;
                }
                // Source "value.proto.ts":76:7
                { let v_7075695f6e61746976655f3832 = v_63616c6c73.read(); state_set(v_7075695f6e61746976655f3832.clone(), Value::number({ let pui_native_83:f64=({ let v_7075695f6e61746976655f3835 = v_63616c6c73.read(); Value::number(((v_7075695f6e61746976655f3835.clone()).get()).num()) }).num(); let pui_native_84:f64=1.0_f64; pui_native_83 + pui_native_84 }), Value::Undefined) };
                // Source "value.proto.ts":77:7
                { let v_7075695f6e61746976655f3836 = v_72756e5f5f30653735663166653263316666643133.clone(); emit(&(v_7075695f6e61746976655f3836.clone()).owner(), Value::string("requested"), record(vec![("type", (v_6576656e745f5f66613338303238333364366535643032.clone()).member("type", false)), ("value", Value::number(((v_6576656e745f5f66613338303238333364366535643032.clone()).member("value", false)).num()))])) };
                // Source "value.proto.ts":78:13
                let v_636f6e74726f6c = (v_6576656e745f5f66613338303238333364366535643032.clone()).member("control", false);
                // Source "value.proto.ts":79:7
                { let v_7075695f6e61746976655f3837 = v_636f6e74726f6c.clone(); prevent(v_7075695f6e61746976655f3837.clone()) };
                Value::Undefined
            })) }, Value::Undefined) };
            // Source "value.proto.ts":81:5
            { let v_7075695f6e61746976655f3838 = v_646566.clone(); listen_numeric_value(&owner, Value::string("host:numeric-request"), false, {  let v_6f6e6365 = v_6f6e6365.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_5f72756e5f5f33383362323230653062363130646335: Value = arg(&arguments, 0);
                let v_6f70617175655f5f66643363326462336232323338373265: Value = arg(&arguments, 1);
                // Source "value.proto.ts":84:15
                let v_6576656e745f5f37633365653537623832383364396664 = v_6f70617175655f5f66643363326462336232323338373265.clone();
                // Source "value.proto.ts":85:9
                if (((v_6576656e745f5f37633365653537623832383364396664.clone()).member("value", false)).num()).is_finite() {
                    // Source "value.proto.ts":85:43
                    { let v_7075695f6e61746976655f3839 = v_6f6e6365.read(); state_set(v_7075695f6e61746976655f3839.clone(), Value::number({ let pui_native_90:f64=({ let v_7075695f6e61746976655f3932 = v_6f6e6365.read(); Value::number(((v_7075695f6e61746976655f3932.clone()).get()).num()) }).num(); let pui_native_91:f64=1.0_f64; pui_native_90 + pui_native_91 }), Value::Undefined) };
                }
                Value::Undefined
            })) }, record(vec![("once", Value::boolean(true))])) };
            // Source "value.proto.ts":89:5
            { let v_7075695f6e61746976655f3933 = v_646566.clone(); listen_numeric_value(&owner, Value::string("host:numeric-request"), false, {  let v_6f6e63655a65726f = v_6f6e63655a65726f.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "value.proto.ts":89:48
                return { let v_7075695f6e61746976655f3934 = v_6f6e63655a65726f.read(); state_set(v_7075695f6e61746976655f3934.clone(), Value::number({ let pui_native_95:f64=({ let v_7075695f6e61746976655f3937 = v_6f6e63655a65726f.read(); Value::number(((v_7075695f6e61746976655f3937.clone()).get()).num()) }).num(); let pui_native_96:f64=1.0_f64; pui_native_95 + pui_native_96 }), Value::Undefined) };
            })) }, record(vec![("once", Value::boolean(true))])) };
            // Source "value.proto.ts":90:5
            { let v_7075695f6e61746976655f3938 = v_646566.clone(); listen_numeric_value(&owner, Value::string("host:numeric-request"), false, {  let v_6f6e63654f6e65 = v_6f6e63654f6e65.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_5f72756e5f5f61383535303539616334343432626535: Value = arg(&arguments, 0);
                // Source "value.proto.ts":90:52
                return { let v_7075695f6e61746976655f3939 = v_6f6e63654f6e65.read(); state_set(v_7075695f6e61746976655f3939.clone(), Value::number({ let pui_native_100:f64=({ let v_7075695f6e61746976655f313032 = v_6f6e63654f6e65.read(); Value::number(((v_7075695f6e61746976655f313032.clone()).get()).num()) }).num(); let pui_native_101:f64=1.0_f64; pui_native_100 + pui_native_101 }), Value::Undefined) };
            })) }, record(vec![("once", Value::boolean(true))])) };
            // Source "value.proto.ts":91:5
            return { let callable={ let pui_native_103={   let call:Rc<dyn Fn(Value)->native::gpui_native_owner::NativeSnapshot>=Rc::new(move |argument_0: Value| -> native::gpui_native_owner::NativeSnapshot {
                let v_72: Value = argument_0;
                // Source "value.proto.ts":91:19
                return { let v_7075695f6e61746976655f313034 = v_72.clone(); native::gpui_native_owner::NativeSnapshot::slot() };
            }); native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:None } }; Value::NativeFunction{identity:pui_native_103.identity.clone(),render:Rc::new(move |arguments:Vec<Value>| {(pui_native_103.call)(arg(&arguments,0))})} }; match callable {
      Value::NativeFunction{identity,render} => capture_renderer(Value::NativeFunction{identity,render:render.clone()},render),
      Value::Renderer(adapter) => Value::Renderer(adapter),
      Value::Function(callback) => capture_renderer(Value::Function(callback.clone()),Rc::new(move |arguments:Vec<Value>| { panic!("checked native renderer entry has no scalar callback alternative") })),
      _ => panic!("checked setup result must be a callable")
    } };
        })) }.call_authored(vec![definition_capability(&owner)]);
          Owner::finish(&owner_ref, renderer);
          let focus_subscriptions = if native_focus_observation_needed(&owner_ref) {
          let focus_owner = owner_ref.clone();
          let on_focus = cx.on_focus(&focus, window, move |view, window, cx| {
              native_host_callback(&focus_owner, "focus", || {
              let epoch = focus_owner.borrow().epoch;
              if !ready(&focus_owner) || focus_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&focus_owner, window);
              native_focus_fact(&focus_owner, view.focus.is_focused(window));
              if !ready(&focus_owner) || focus_owner.borrow().epoch != epoch { return; }
              dispatch(&focus_owner, "host:focus", false, event_fields("host:focus"));
              if ready(&focus_owner) && focus_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          let blur_owner = owner_ref.clone();
          let on_blur = cx.on_blur(&focus, window, move |view, window, cx| {
              native_host_callback(&blur_owner, "blur", || {
              let epoch = blur_owner.borrow().epoch;
              if !ready(&blur_owner) || blur_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&blur_owner, window);
              native_focus_fact(&blur_owner, view.focus.is_focused(window));
              if !ready(&blur_owner) || blur_owner.borrow().epoch != epoch { return; }
              text_blur(&blur_owner, window, cx);
              dispatch(&blur_owner, "host:blur", false, event_fields("host:blur"));
              if ready(&blur_owner) && blur_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          vec![on_focus, on_blur]
          } else { Vec::new() };
          let global_key_capture = subscribe_global_key_capture(&owner_ref, cx);
          let window_input = window_input_needed(&owner_ref).then(|| cx.focus_handle().tab_stop(false));
          let focus_lost = window_input.as_ref().map(|_| cx.on_focus_lost(window, |view, window, cx| { let owner=view.owner.clone(); native_host_callback(&owner, "focus-lost", || { if view.owner.borrow().window_id == Some(window.window_handle().window_id()) { if let Some(focus) = &view.window_input { restore_window_input(&view.owner, focus, window, cx); } } }); }));
          let mut view = Self { owner: owner_ref, focus, window_input, _focus_subscriptions: focus_subscriptions, _window_activation: None, _focus_lost: focus_lost, _global_key_capture: global_key_capture, _entry_readiness: None };
          view.bind_window_activation(window, cx);
          view
          })
      }
      #[cfg(feature="test-support")]
      pub fn native_resource_counts(&self) -> Json { let mut counts=native::gpui_native_owner::native_resource_counts(&self.owner); counts["nativeSubscriptions"] = Json::from(self._focus_subscriptions.len() + usize::from(self._window_activation.is_some()) + usize::from(self._focus_lost.is_some()) + usize::from(self._global_key_capture.is_some()) + usize::from(self._entry_readiness.is_some())); counts }
      pub fn handle(&self) -> CompiledComponentHandle { CompiledComponentHandle { owner: self.owner.clone() } }
      pub fn set_props(&mut self, raw: Json, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_props(&self.owner, raw));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; self.drive(window, cx)
      }
      pub fn set_instance_associations(&mut self, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| replace_instance_associations(&self.owner, associations))?; drive_owners(window, cx); self.drive(window, cx) }
      pub fn set_slot(&mut self, slot: Vec<native::gpui_native_owner::NativeSnapshot>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { ensure(&Rc::downgrade(&self.owner)); assert_native_slot_children(&slot); let mut owner = self.owner.borrow_mut(); owner.slot = slot; owner.dirty = true; cx.notify(); }) }
      pub fn set_parent(&mut self, parent: Option<OwnerWeak>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { if let Err(error)=set_native_parent(&self.owner, parent.unwrap_or_default()){throw_error("NATIVE_PARENT_INVALID", error)} cx.notify(); }) }
      fn bind_window_activation(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !native_focus_observation_needed(&self.owner) && !native::gpui_native_move::move_owner_has_binding(&self.owner) && !control_label_is_label(&self.owner) { self._window_activation.take(); return; }
          let id = window.window_handle().window_id();
          if self._window_activation.as_ref().is_some_and(|(bound, _)| *bound == id) { return; }
          self._window_activation.take();
          let owner = self.owner.clone();
          let subscription = cx.observe_window_activation(window, move |view, window, cx| {
              let deactivated = owner.borrow().window_id == Some(window.window_handle().window_id()) && !window.is_window_active();
              native_host_callback(&owner, "window-activation", || {
                  if deactivated {
                      native_window_blur(&owner);
                      view.drive(window, cx).unwrap_or_else(|error| throw_value(error));
                  }
              });
              if deactivated { notify_native_change(cx); }
          });
          self._window_activation = Some((id, subscription));
      }
      #[cfg(feature = "experimental-focus-tree")]
      fn bind_entry_readiness(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !self.owner.borrow().modules.hooks.contains("focus-entry") { return; }
          let window_id = window.window_handle().window_id();
          if self._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window_id) { return; }
          self._entry_readiness.take();
          let view = cx.entity().downgrade();
          let subscription = window.observe_focus_tree(cx, move |_, window, cx| {
              let _ = view.update(cx, |view, cx| {
                  if view._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window.window_handle().window_id()) { if let Err(error)=view.drive(window, cx){report_native_failure(&view.owner,"entry-readiness",error)} }
              });
          });
          self._entry_readiness = Some((window_id, subscription));
      }
      pub fn drive(&mut self, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let mut dirty = false;
          let result = catch_authored(|| {
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); dirty = true; return; }
          modules_drive(&self.owner, &self.focus, window, cx);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); dirty = true; return; }
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          drive_queued_focus(&self.owner, window, cx);
          dirty = std::mem::take(&mut self.owner.borrow_mut().dirty);
          });
          // A render-time prop watcher or a terminal callback may publish an
          // event even after ordinary drawing consumed dirty. Wake observers
          // once after this native lease; do not request an authored render.
          if !notify_native_events(&self.owner, cx) && dirty { cx.notify(); }
          result
      }
  }
  impl Drop for CompiledComponent { fn drop(&mut self) { native_host_callback(&self.owner, "drop", || Owner::dispose(&self.owner)); } }
  impl gpui::Focusable for CompiledComponent { fn focus_handle(&self, _: &App) -> FocusHandle { self.focus.clone() } }
  impl Render for CompiledComponent {
      fn render(&mut self, window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
          let report_owner = self.owner.clone();
          native_host_callback(&report_owner, "render", || {
          refresh_native_atoms(&self.owner, window, cx);
          Owner::project(&self.owner);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); return gpui::div().into_any_element(); }
          if !self.owner.borrow().present { self._window_activation.take(); detach_native_view(&self.owner); return gpui::div().into_any_element(); }
          bind_native_focus_window(&self.owner, window);
          self.bind_window_activation(window, cx);
          #[cfg(feature = "experimental-focus-tree")] self.bind_entry_readiness(window, cx);
          let drive = self.owner.borrow().native_drive.as_ref().expect("live native owner drive").clone();
          self.owner.borrow_mut().dirty = false;
          let snapshot = self.owner.borrow().projection.clone().expect("live native projection");
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          let element = paint_native_root(&snapshot, &self.owner, &self.focus, format!("compiled-root-{}", Rc::as_ptr(&self.owner) as usize), drive);
          if let Some(focus) = &self.window_input { window_input_scope(element, focus, &self.owner) } else { element }
          }).unwrap_or_else(|| gpui::div().into_any_element())
      }
  }
  
//# sourceMappingURL=Component.rs.map
