import pathlib,json,hashlib,os,signal,time,datetime,traceback,difflib
base=pathlib.Path('/tank/shared/projects/proto-ui-agent/compiler-reconcile-cc618');repo=base/'sprint5-current'
payload=json.loads((base/'sprint5-four-file-repair.json').read_text())
entry=next(x for x in payload['files'] if x['path'].endswith('gpui-native-hover.ts'))
loop="            for (owner,path) in [(&self.label,\"hover-label\"),(&self.target,\"hover-target\")] {\n                Owner::project(owner);";loop2="            for (owner,path) in [(&self.label,\"hover-label\"),(&self.target,\"hover-target\")] {\n                // Terminal owners deliberately have no projection to paint.\n                if owner.borrow().disposed { continue; }\n                Owner::project(owner);"
ending="            Owner::dispose(&host.label);Owner::dispose(&host.target);\n        }).unwrap();\n    }\n";ending2="            Owner::dispose(&host.label);Owner::dispose(&host.target);\n        }).unwrap();\n        frames(window,cx);\n        window.update(cx,|host,_,_| {\n            assert!(host.label.borrow().disposed&&host.target.borrow().disposed);\n            assert!(host.label.borrow().projection.is_none()&&host.target.borrow().projection.is_none());\n            assert_eq!(calls.get(),1,\"terminal native frames cannot revive retired label activation\");\n        }).unwrap();\n    }\n"
assert entry['before'].count(loop)==1 and entry['before'].count(ending)==1,'Original authored fixture context changed'
entry['after']=entry['before'].replace(loop,loop2).replace(ending,ending2)
report={'reason':'The layout hypothesis did not fix SDK failure. Exact emitted line 4232 is LabelHost render projection.unwrap after terminal retirement. Supersede v1, retain its 27/28 result and interrupted source run.','at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def state(pid):
 try:return pathlib.Path('/proc/'+str(pid)+'/status').read_text()
 except FileNotFoundError:return ''
try:
 status=json.loads((base/'sprint5-final-validation-status.json').read_text());report['originalStatus']=status
 master=1576459
 cmd=pathlib.Path('/proc/'+str(master)+'/cmdline')
 if cmd.exists():
  assert b'sprint5-final-validation.py' in cmd.read_bytes(),'Unexpected supervisor process'
  os.kill(master,signal.SIGSTOP)
  deadline=time.monotonic()+3
  while state(master) and '\nState:\tT' not in state(master):
   assert time.monotonic()<deadline,'Supervisor did not pause'
   time.sleep(.05)
  status=json.loads((base/'sprint5-final-validation-status.json').read_text());report['originalStatus']=status
  direct=pathlib.Path('/proc/'+str(master)+'/task/'+str(master)+'/children').read_text().split()
  expected=[str(x['pid']) for x in status['steps'] if x['state']=='running' and x.get('pid') and state(x['pid'])]
  assert set(direct)==set(expected),'Validation transitioned during pause; reconcile before source edits'
  for step in status['steps']:
   if step['state']!='running':continue
   pid=step['pid'];raw=state(pid)
   if not raw:continue
   assert ('\nPPid:\t'+str(master)+'\n') in raw and os.getpgid(pid)==pid,'Unexpected active validation process'
   os.killpg(pid,signal.SIGTERM)
   deadline=time.monotonic()+3
   while state(pid) and '\nState:\tZ' not in state(pid) and time.monotonic()<deadline:time.sleep(.05)
   if state(pid) and '\nState:\tZ' not in state(pid):os.killpg(pid,signal.SIGKILL)
  os.kill(master,signal.SIGTERM);os.kill(master,signal.SIGCONT)
  deadline=time.monotonic()+3
  while state(master) and '\nState:\tZ' not in state(master) and time.monotonic()<deadline:time.sleep(.05)
  assert not state(master) or '\nState:\tZ' in state(master),'Supervisor still active'
 report['v1LogHashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (base/'sprint5-final-validation').glob('*.log')}
 old=json.loads((base/'sprint5-four-file-repair.json').read_text())
 assert all((repo/x['path']).read_text()==x['after'] for x in old['files']),'Source changed since v1'
 for row in payload['files']:
  row['sha256']=hashlib.sha256(row['after'].encode()).hexdigest()
  if row['path'].endswith('gpui-native-hover.ts'):(repo/row['path']).write_text(row['after'])
 (base/'sprint5-four-file-repair-v2.json').write_text(json.dumps(payload,indent=2)+'\n')
 patch=''.join(''.join(difflib.unified_diff(r['before'].splitlines(True),r['after'].splitlines(True),'a/'+r['path'],'b/'+r['path'])) for r in payload['files'])
 (base/'sprint5-four-file-repair-v2.patch').write_text(patch)
 report.update(state='applied',files=[{'path':x['path'],'sha256':x['sha256']} for x in payload['files']],patchSha256=hashlib.sha256(patch.encode()).hexdigest())
except BaseException as e:
 report.update(state='failed',error=repr(e),traceback=traceback.format_exc())
 if pathlib.Path('/proc/1576459').exists():
  try:os.kill(1576459,signal.SIGCONT)
  except ProcessLookupError:pass
(base/'sprint5-v1-superseded.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['state','error','files','patchSha256'] if k in report},indent=2))
