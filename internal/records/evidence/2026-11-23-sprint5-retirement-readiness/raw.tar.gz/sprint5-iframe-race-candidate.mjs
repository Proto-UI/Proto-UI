import {createRequire} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
const base='/tank/shared/projects/proto-ui-agent/compiler-reconcile-cc618';
const source=base+'/iframe-race-candidate-sandbox.ts';
const require=createRequire(base+'/sprint5-current/apps/www/package.json');
const {chromium}=require('playwright-core');
const {build}=require('esbuild');
const report={kind:'actual-browser-iframe-retirement-race',sourceParent:'32cf4b2f9c9ca22dd016de2981396df9ba49b626',scope:'Real sandboxed Chromium frame protocol using an explicitly synthetic custom-element fixture; not compiled-control, WASM or native SDK acceptance.',cases:[]};
let browser,server;
try{
 const bytes=await readFile(source);report.sourceSha256=createHash('sha256').update(bytes).digest('hex');
 const built=await build({stdin:{contents:bytes.toString(),loader:'ts',resolveDir:source.slice(0,source.lastIndexOf('/'))},bundle:true,write:false,format:'iife',globalName:'RetirementProbe',platform:'browser',target:'es2024'});
 browser=await chromium.launch({executablePath:'/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/playwright-browsers/chromium-1208/chrome-linux64/chrome',headless:true,chromiumSandbox:true});
 report.browser=browser.version();
 server=createServer((_,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end('<!doctype html><div id="host"></div>');});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const page=await browser.newPage();await page.goto('http://127.0.0.1:'+server.address().port);
 await page.addScriptTag({content:built.outputFiles[0].text});
 for(const immediate of [false,true]){
  const result=await page.evaluate(async(immediate)=>{
   const profile='web-component-source-v1';
   const source={file:'explicit-frame-protocol-fixture.ts',exportName:'default',sha256:'0'.repeat(64)};
   const result={ok:true,revision:'protocol-fixture',requestSha256:'1'.repeat(64),source,output:{code:'',profile,dependencies:[],provenance:{source,irVersion:7,backend:profile}},preview:{format:1,entry:'fixture',modules:{fixture:'export default class extends HTMLElement {setProps(){} dispose(){}}'},events:[],styles:[],executionBudget:'100000-checkpoints-per-task-v1'}};
   const target={format:1,profile,modules:{},versions:{},modulesSha256:'0'.repeat(64)};
   const host=document.getElementById('host');
   const mounted=globalThis.RetirementProbe.mountCompiledPreview(host,result,target,[],()=>{});
   void mounted.ready.catch(()=>{});
   if(!immediate)await mounted.ready;
   const start=performance.now();
   try{await mounted.dispose();return{immediate,status:'resolved',elapsedMs:performance.now()-start,remainingFrames:host.querySelectorAll('iframe').length};}
   catch(error){return{immediate,status:'rejected',message:String(error.message),elapsedMs:performance.now()-start,remainingFrames:host.querySelectorAll('iframe').length};}
  },immediate);
  report.cases.push(result);
 }
 report.state='completed';
}catch(error){report.state='failed';report.error=String(error.stack||error);}
finally{
 if(browser)await browser.close();
 if(server)await new Promise(resolve=>server.close(resolve));
 report.finishedAt=new Date().toISOString();
 await writeFile(base+'/sprint5-iframe-race-candidate.json',JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify(report,null,2));
}
