import os,pathlib,subprocess,json,datetime,traceback,hashlib,signal
base=pathlib.Path('/tank/shared/projects/proto-ui-agent/compiler-reconcile-cc618');repo=base/'sprint5-current';shared=pathlib.Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
logs=base/'sprint5-final-validation-v2';logs.mkdir(exist_ok=True)
payload=json.loads((base/'sprint5-four-file-repair-v2.json').read_text())
status={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':payload['head'],'steps':[],'scope':'Exact published 32cf source plus the guarded four-file candidate; no final-commit or full-portfolio pass is implied.'}
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',ASTRO_TELEMETRY_DISABLED='1',NODE_OPTIONS='--max-old-space-size=4096')
env['PATH']=str(shared/'tools/node-v24.22.3-linux-x64/bin')+':/home/ezra/.cargo/bin:'+env.get('PATH','');env['COREPACK_HOME']=str(shared/'corepack-cache')
env['PROTO_UI_REQUIRE_RUST_DATA_TESTS']='1';env['RUSTUP_TOOLCHAIN']='1.98.1';env['CARGO_TARGET_DIR']=str(base/'scalar-target')
env['TMPDIR']=str(base/'sprint5-final-tmp-v2');(base/'sprint5-final-tmp-v2').mkdir(exist_ok=True)
def save():(base/'sprint5-final-validation-v2-status.json').write_text(json.dumps(status,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.run(['git',*a],cwd=repo,env=env,check=True,capture_output=True,text=True,timeout=90).stdout.strip()
def run(name,args,timeout=300,runenv=None,required=False):
 log=logs/(name+'.log');row={'name':name,'command':args,'cwd':str(repo),'state':'running','log':str(log),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};status['steps'].append(row);save()
 with log.open('wb') as out:
  p=subprocess.Popen(args,cwd=repo,env=runenv or env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
  try:code=p.wait(timeout)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   code=p.returncode;row.update(timedOut=True,timeoutSeconds=timeout)
 row.update(state='passed' if code==0 and not row.get('timedOut') else 'failed',exitCode=code,logSha256=sha(log),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
 if required and row['state']!='passed':raise RuntimeError(name+' did not pass; dependent work not run')
 return row['state']=='passed'
try:
 save()
 assert git('rev-parse','HEAD')==payload['head']
 assert git('diff','--cached','--name-only')=='','Unexpected staged work'
 assert json.loads((base/'sprint5-v1-superseded.json').read_text())['state']=='applied'
 for entry in payload['files']:
  assert (repo/entry['path']).read_text()==entry['after'],'Final source drift: '+entry['path']
 run('format',['corepack','pnpm@10.32.1','exec','prettier','--check',*[x['path'] for x in payload['files']]],required=True)
 status['sourceFilesBefore']={x['path']:sha(repo/x['path']) for x in payload['files']}
 assert all(status['sourceFilesBefore'][x['path']]==x['sha256'] for x in payload['files']),'Formatter changed reviewed candidate'
 save()
 run('numeric-producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-a11y-value/produce.mjs',str(base/'sprint5-final-numeric-v2')],timeout=600,required=True)
 compilerFiles=git('ls-files','--','packages/compiler/src','packages/compiler/test/fixtures/gpui-a11y-value','scripts/gpui').splitlines()
 status['nativeSourceFilesBefore']={p:sha(repo/p) for p in compilerFiles if (repo/p).is_file()}
 status['generatedRustBefore']={str(p.relative_to(base)):sha(p) for p in (base/'sprint5-final-numeric-v2').rglob('*.rs')};save()
 graphenv=dict(env,CARGO_NET_OFFLINE='false')
 run('graph-controls',['node','--test','scripts/gpui/test/cargo-graph.test.mjs'],timeout=300,runenv=graphenv)
 native=dict(env,CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
 prefix=json.loads((shared/'evidence/s5-native-environment/user-prefix/environment.json').read_text());values=prefix.get('environment',prefix.get('env',prefix))
 for key in ['PATH','PKG_CONFIG_PATH','LIBRARY_PATH','LD_LIBRARY_PATH','LIBCLANG_PATH','CPATH','C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','CMAKE_PREFIX_PATH','OPENSSL_DIR']:
  if isinstance(values.get(key),str):native[key]=values[key]
 native['PATH']=str(shared/'tools/node-v24.22.3-linux-x64/bin')+':/home/ezra/.cargo/bin:'+native.get('PATH','');native['CARGO_TARGET_DIR']=str(shared/'cargo-target-s5-control-label-2015')
 manifest=str(base/'sprint5-final-numeric-v2/Cargo.toml')
 run('numeric-lock-prepare',['cargo','+1.98.1','metadata','--offline','--all-features','--format-version','1','--manifest-path',manifest],timeout=300,runenv=native,required=True)
 run('numeric-locked-graph',['node','scripts/gpui/check-cargo-graph.mjs','--manifest-path',manifest,'--git','https://github.com/zed-industries/zed','--rev','62e5991dd0f0c8a3af8d5e7e9c4652490d468db8','--toolchain','1.98.1','--output',str(logs/'numeric-graph.json')],timeout=300,runenv=native,required=True)
 run('native-sdk',['cargo','+1.98.1','test','--offline','--locked','--manifest-path',manifest,'-p','proto-ui-gpui-native','--features','test-support,gpui/test-support','--lib','--','--test-threads=1','--nocapture'],timeout=3600,runenv=native)
 status['nativeSourceFilesAfter']={p:sha(repo/p) for p in compilerFiles if (repo/p).is_file()}
 status['generatedRustAfter']={str(p.relative_to(base)):sha(p) for p in (base/'sprint5-final-numeric-v2').rglob('*.rs')}
 assert status['nativeSourceFilesBefore']==status['nativeSourceFilesAfter'] and status['generatedRustBefore']==status['generatedRustAfter'],'Native source/output changed during run'
 run('source-regressions',['corepack','pnpm@10.32.1','exec','vitest','run',*["packages/compiler/test/browser-client.test.ts","packages/compiler/test/browser-revision-session.test.ts","packages/compiler/test/browser-target-consumer.test.ts","packages/compiler/test/browser-wasm.test.ts","packages/compiler/test/browser-preview-retirement.test.ts","packages/compiler/test/browser-panel-retirement.test.ts","packages/compiler/test/request-owner-ssr.test.ts","packages/compiler/test/button-ssr-server.test.ts","packages/compiler/test/gpui-a11y-value.test.ts","packages/compiler/test/gpui-capabilities.test.ts","packages/compiler/test/gpui-hook-renderer.test.ts","packages/compiler/test/gpui-event-notification.test.ts","packages/compiler/test/gpui-scalar-lowering.test.ts","packages/compiler/test/gpui-style-selection.test.ts","packages/compiler/test/gpui-control-label.test.ts","packages/compiler/test/string-coercion.test.ts","packages/runtime/test/contract/lifecycle.request.contract.test.ts","packages/runtime/test/contract/lifecycle.initial-data.contract.test.ts","packages/runtime/test/contract/lifecycle.module-resources.v1.contract.test.ts","packages/runtime/test/contract/as-hook.v0.contract.test.ts","packages/runtime/test/contract/prototype.render-syntax.v0.contract.test.ts","packages/runtime/test/contract/lifecycle.same-checkpoint-order.contract.test.ts"],'--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(logs/'source-regressions.json')],timeout=300)
 run('workspace-types',['corepack','pnpm@10.32.1','-s','check:types:workspace'],timeout=1200)
 browserenv=dict(env,PUI_CHROME_EXECUTABLE=str(shared/'tools/playwright-browsers/chromium-1208/chrome-linux64/chrome'),PUI_BROWSER_PORT='4335',PUI_EVIDENCE_DIR=str(logs/'browser'))
 run('canonical-browser',['node','--import','tsx','scripts/analysis/browser-compiler-browser.mts'],timeout=1200,runenv=browserenv)
 status['sourceFilesAfter']={x['path']:sha(repo/x['path']) for x in payload['files']};assert status['sourceFilesBefore']==status['sourceFilesAfter'],'Candidate changed during validation'
 status['state']='passed' if all(s['state']=='passed' for s in status['steps']) else 'completed-with-failures'
except BaseException as e:status.update(state='failed',error=repr(e),traceback=traceback.format_exc())
status['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
