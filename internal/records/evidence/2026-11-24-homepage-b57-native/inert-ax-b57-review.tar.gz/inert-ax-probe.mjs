import { createRequire } from 'node:module';
import { mkdirSync, writeFileSync, existsSync, readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const root='/var/tmp/pui-release-40da-web';
const evidence='/var/tmp/pui-40da-web-evidence/inert-ax-b57';
const require=createRequire(`${root}/apps/www/package.json`);
const {chromium}=require('playwright-core');
const playwrightVersion=require('playwright-core/package.json').version;
mkdirSync(evidence,{recursive:true});
const sourceSha=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
assert.equal(sourceSha,'b57e7af30b97a087ae0c3ec9fa75e10c7ca268d8');
const executablePath=['/usr/bin/google-chrome','/bin/google-chrome','/usr/bin/google-chrome-stable','/usr/bin/chromium','/usr/bin/chromium-browser'].find(existsSync);
assert.ok(executablePath);
const receipt={sourceSha,sourceKind:'Independent owned HTML probe; no application code changed or loaded',node:process.version,playwrightVersion,executablePath,startedAt:new Date().toISOString(),probeSha256:createHash('sha256').update(readFileSync(new URL(import.meta.url))).digest('hex'),chromiumSandbox:true};
let browser;
try{
 browser=await chromium.launch({executablePath,headless:true,chromiumSandbox:true,args:['--disable-dev-shm-usage']});
 receipt.browserVersion=browser.version();const context=await browser.newContext();const page=await context.newPage();
 const html='<!doctype html><meta charset="utf-8"><button id="before">Before</button><div id="stage" inert><button id="probe">probe</button></div><button id="after">After</button>';
 writeFileSync(`${evidence}/probe.html`,html);
 await page.setContent(html);
 await page.evaluate(()=>{window.__probe=document.getElementById('probe');window.__activations={before:0,probe:0,after:0};for(const id of Object.keys(window.__activations))document.getElementById(id).addEventListener('click',()=>window.__activations[id]++);});
 const cdp=await context.newCDPSession(page);await cdp.send('Accessibility.enable');
 const ax=async()=>{const {root:doc}=await cdp.send('DOM.getDocument');const {nodeId}=await cdp.send('DOM.querySelector',{nodeId:doc.nodeId,selector:'#probe'});const {node}=await cdp.send('DOM.describeNode',{nodeId});const partial=await cdp.send('Accessibility.getPartialAXTree',{backendNodeId:node.backendNodeId,fetchRelatives:true});const full=await cdp.send('Accessibility.getFullAXTree');return{backendNodeId:node.backendNodeId,target:partial.nodes.find(x=>x.backendDOMNodeId===node.backendNodeId),partial,full};};
 const initial={inert:await page.locator('#stage').evaluate(e=>e.inert),roleCount:await page.getByRole('button',{name:'probe',exact:true}).count(),ax:await ax()};
 await page.locator('#before').focus();await page.keyboard.press('Tab');initial.focusAfterTab=await page.evaluate(()=>document.activeElement?.id);await page.keyboard.press('Enter');initial.activations=await page.evaluate(()=>({...window.__activations}));
 await page.locator('#probe').evaluate(e=>e.focus());initial.focusAfterInertProgrammaticFocus=await page.evaluate(()=>document.activeElement?.id);
 receipt.inert=initial;
 await page.locator('#stage').evaluate(e=>{e.inert=false;});
 const enabled={inert:await page.locator('#stage').evaluate(e=>e.inert),sameElement:await page.evaluate(()=>window.__probe===document.getElementById('probe')),roleCount:await page.getByRole('button',{name:'probe',exact:true}).count(),ax:await ax()};
 await page.locator('#before').focus();await page.keyboard.press('Tab');enabled.focusAfterTab=await page.evaluate(()=>document.activeElement?.id);await page.keyboard.press('Enter');enabled.activations=await page.evaluate(()=>({...window.__activations}));receipt.enabled=enabled;
 assert.equal(initial.inert,true);assert.equal(initial.roleCount,1);assert.equal(initial.focusAfterTab,'after');assert.equal(initial.activations.probe,0);assert.equal(initial.activations.after,1);assert.equal(initial.focusAfterInertProgrammaticFocus,'after');assert.equal(initial.ax.target?.ignored,true);assert.ok(!initial.ax.full.nodes.some(n=>!n.ignored&&n.role?.value==='button'&&n.name?.value==='probe'));
 assert.equal(enabled.inert,false);assert.equal(enabled.sameElement,true);assert.equal(enabled.roleCount,1);assert.equal(enabled.focusAfterTab,'probe');assert.equal(enabled.activations.probe,1);assert.equal(enabled.ax.target?.ignored,false);assert.ok(enabled.ax.full.nodes.some(n=>!n.ignored&&n.role?.value==='button'&&n.name?.value==='probe'));
 receipt.verdict='pass';
 await cdp.detach();await context.close();
}catch(error){receipt.verdict='fail';receipt.error=String(error.stack??error);process.exitCode=1;}
finally{if(browser)await browser.close();receipt.finishedAt=new Date().toISOString();writeFileSync(`${evidence}/receipt.json`,JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({sourceSha,verdict:receipt.verdict,node:receipt.node,playwrightVersion,browserVersion:receipt.browserVersion,inert:receipt.inert&&{roleCount:receipt.inert.roleCount,focusAfterTab:receipt.inert.focusAfterTab,activations:receipt.inert.activations,axTarget:receipt.inert.ax.target},enabled:receipt.enabled&&{roleCount:receipt.enabled.roleCount,focusAfterTab:receipt.enabled.focusAfterTab,activations:receipt.enabled.activations,axTarget:receipt.enabled.ax.target},error:receipt.error,evidence}));}
