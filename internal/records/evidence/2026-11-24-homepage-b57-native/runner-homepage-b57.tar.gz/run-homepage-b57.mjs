import {spawn, execFileSync} from 'node:child_process';
import {mkdirSync,openSync,writeFileSync,readFileSync,appendFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const root=process.env.PUI_WEB_REPO??'/var/tmp/pui-release-40da-web';
const evidence=process.env.PUI_WEB_EVIDENCE??'/var/tmp/pui-40da-web-evidence/homepage-b57';
const expected=process.env.PUI_EXPECTED_SHA;
const sourceSha=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
if(!expected||sourceSha!==expected)throw new Error(`Expected source ${expected}; observed ${sourceSha}`);
mkdirSync(evidence,{recursive:true});mkdirSync(`${evidence}/temp`,{recursive:true});
const receipts=[];const groups=new Set();let interrupted=false;
const readProcesses=()=>execFileSync('ps',['-eo','pid=,ppid=,pgid=,rss=,stat=,comm='],{encoding:'utf8'}).trim().split('\n').map(line=>{const [pid,ppid,pgid,rss,stat,...command]=line.trim().split(/\s+/);return{pid:+pid,ppid:+ppid,pgid:+pgid,rssKiB:+rss,stat,command:command.join(' ')};});
function sample(){try{const all=readProcesses();const own=all.filter(p=>groups.has(p.pgid));appendFileSync(`${evidence}/process-rss.jsonl`,JSON.stringify({at:new Date().toISOString(),sourceSha,processes:own,summedRssKiB:own.reduce((a,p)=>a+p.rssKiB,0),note:'Per-process RSS sum includes shared pages; not unique memory or OOM evidence.'})+'\n');}catch(error){appendFileSync(`${evidence}/monitor-errors.log`,String(error)+'\n');}}
const timer=setInterval(sample,5000);
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function stopGroup(pgid){if(!pgid)return;let term='not-present',kill='not-needed';try{process.kill(-pgid,'SIGTERM');term='sent';}catch(error){if(error.code!=='ESRCH')term=String(error);}for(let n=0;n<20;n++){if(!readProcesses().some(p=>p.pgid===pgid&&p.stat[0]!=='Z'))break;await pause(250);}const beforeKill=readProcesses().filter(p=>p.pgid===pgid&&p.stat[0]!=='Z');if(beforeKill.length){try{process.kill(-pgid,'SIGKILL');kill='sent';}catch(error){kill=String(error);}await pause(250);}const remaining=readProcesses().filter(p=>p.pgid===pgid);appendFileSync(`${evidence}/process-cleanup.jsonl`,JSON.stringify({at:new Date().toISOString(),pgid,term,kill,beforeKill,remaining})+'\n');groups.delete(pgid);}
const env={...process.env,PROTO_UI_BROWSER_TEST:'1',PROTO_UI_HOMEPAGE_PROFILE:'0',RUNNER_TEMP:`${evidence}/temp`,PROTO_UI_EXPECTED_REVISION:sourceSha,CANDIDATE_SHA:sourceSha,PROTO_UI_RUNTIME_EVIDENCE_DIR:`${evidence}/browser`,PROTO_UI_BROWSER_BASE_URL:'http://127.0.0.1:44195'};
async function run(name,args,extraEnv={},timeoutMs=900000){if(interrupted)throw new Error('Validation interrupted.');const output=openSync(`${evidence}/${name}.log`,'w');const startedAt=new Date().toISOString();const child=spawn('corepack',['pnpm@10.32.1',...args],{cwd:root,env:{...env,...extraEnv},detached:true,stdio:['ignore',output,output]});groups.add(child.pid);let timedOut=false;const deadline=setTimeout(()=>{timedOut=true;try{process.kill(-child.pid,'SIGTERM');}catch{}setTimeout(()=>{try{process.kill(-child.pid,'SIGKILL');}catch{}},5000).unref();},timeoutMs);const result=await new Promise(resolve=>{child.once('error',error=>resolve({error:String(error)}));child.once('exit',(code,signal)=>resolve({code,signal}));});clearTimeout(deadline);sample();await stopGroup(child.pid);const receipt={name,sourceSha,command:['corepack','pnpm@10.32.1',...args],startedAt,finishedAt:new Date().toISOString(),timedOut,...result};receipts.push(receipt);writeFileSync(`${evidence}/commands.json`,JSON.stringify(receipts,null,2)+'\n');console.log(JSON.stringify(receipt));return receipt;}
for(const [signal,code] of [['SIGINT',130],['SIGTERM',143]])process.once(signal,()=>{interrupted=true;process.exitCode=code;Promise.all([...groups].map(stopGroup)).finally(()=>process.exit(code));});
let server;
try{
 const initialStatus=execFileSync('git',['status','--porcelain=v1','--untracked-files=no'],{cwd:root,encoding:'utf8'});if(initialStatus)throw new Error(`Tracked source dirty before validation: ${initialStatus}`);
 const previousPath='/var/tmp/pui-40da-web-evidence/matrix-fde/source.json';
 const previous=JSON.parse(readFileSync(previousPath,'utf8'));
 const producerSha='fde59e8517b52f4c0a3fd19453a5d586e9fe7f3f';
 if(previous.sourceSha!==producerSha)throw new Error('Unexpected original style producer source.');
 const git=(args)=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim();
 const producerScopes=['pnpm-lock.yaml','apps/www/package.json','apps/www/scripts/generate-cli-init-docs.mjs','apps/www/scripts/generate-website-prototype-tokens.mjs','apps/www/src/prototypes','apps/www/src/styles','packages/cli','packages/core','packages/runtime','packages/modules','packages/adapters','packages/hooks','packages/types','packages/host-protocol',':(glob)packages/prototypes/**/src/**',':(glob)packages/**/package.json','scripts/build'];
 const producerDelta=git(['diff','--name-only',producerSha,sourceSha,'--',...producerScopes]);
 if(producerDelta)throw new Error(`Generated asset producer inputs changed: ${producerDelta}`);
 const oldPackage=JSON.parse(git(['show',`${producerSha}:package.json`]));
 const nowPackage=JSON.parse(readFileSync(`${root}/package.json`,'utf8'));
 const dependencyFields=['dependencies','devDependencies','optionalDependencies','peerDependencies','packageManager','pnpm','engines'];
 for(const field of dependencyFields)if(JSON.stringify(oldPackage[field])!==JSON.stringify(nowPackage[field]))throw new Error(`Dependency field changed: ${field}`);
 const styles=previous.styles.map(item=>{const actual=createHash('sha256').update(readFileSync(`${root}/${item.path}`)).digest('hex');if(actual!==item.sha256)throw new Error(`Generated asset drift: ${item.path}`);return item;});
 const boundFiles=['apps/www/src/content/docs/zh-cn/homepage-dogfood.browser.test.ts','apps/www/src/content/docs/zh-cn/contents-wheel-evidence.ts','apps/www/src/components/PrototypePreviewer/runtime-preview-surface.ts','apps/www/astro.config.mjs','apps/www/scripts/client-chunk-isolation.mjs'];
 const currentInputs=boundFiles.map(path=>({path,sha256:createHash('sha256').update(readFileSync(`${root}/${path}`)).digest('hex')}));
 const source={...previous,sourceSha,node:process.version,trackedStatus:initialStatus,styles,currentInputs,generatedAssetsReusedFrom:previousPath,generationReceiptSourceSha:producerSha,generationRerun:false,producerScopes,producerDelta,dependencyFieldsUnchanged:dependencyFields,sourceDeltaFiles:git(['diff','--name-only',producerSha,sourceSha]).split('\n'),testOracle:'Current strengthened homepage input readiness and surface-center coordinates from 6eb/b57; original 1000 ms post-input deadlines unchanged. This is not token-identical to the original fde wheel schedule.',cpuProfilerEnabled:false,recordedAt:new Date().toISOString()};
 writeFileSync(`${evidence}/source.json`,JSON.stringify(source,null,2)+'\n');
 const serverLog=openSync(`${evidence}/astro.log`,'w');server=spawn('corepack',['pnpm@10.32.1','--filter','apps-www','exec','astro','dev','--host','127.0.0.1','--port','44195','--strictPort'],{cwd:root,env,detached:true,stdio:['ignore',serverLog,serverLog]});groups.add(server.pid);
 const started=Date.now();let ready=false;while(Date.now()-started<120000){try{const response=await fetch(`${env.PROTO_UI_BROWSER_BASE_URL}/zh-cn/`);if(response.ok){ready=true;break;}}catch{}await pause(250);}if(!ready)throw new Error('Astro did not serve the Homepage route within existing readiness budget.');
 const testArgs=(name,file,pattern)=>['exec','vitest','run',`apps/www/src/content/docs/zh-cn/${file}`,...(pattern?['-t',pattern]:[]),'--maxWorkers','1','--minWorkers','1','--reporter','default','--reporter','json',`--outputFile.json=${evidence}/${name}.json`];
 await run('homepage-two',testArgs('homepage-two','homepage-dogfood.browser.test.ts','uses real family Popover Triggers|retains brutalist preference owners and portals'));
 await run('homepage-article-handback',testArgs('homepage-article-handback','homepage-dogfood.browser.test.ts','reveals current articles through native shadow slots and preserves viewport handback'));
}catch(error){writeFileSync(`${evidence}/runner-error.txt`,String(error.stack??error)+'\n');console.error(error);process.exitCode=1;}finally{clearInterval(timer);for(const pgid of [...groups])await stopGroup(pgid);if(receipts.some(r=>r.code!==0||r.timedOut||r.error))process.exitCode=1;writeFileSync(`${evidence}/completed.json`,JSON.stringify({sourceSha,finishedAt:new Date().toISOString(),exitCode:process.exitCode??0,receipts},null,2)+'\n');}
