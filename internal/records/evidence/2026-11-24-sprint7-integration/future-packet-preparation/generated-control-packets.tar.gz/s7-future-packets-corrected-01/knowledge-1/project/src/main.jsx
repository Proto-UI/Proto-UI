// Implement the supplied task here.
