import fs from "node:fs";
import path from "node:path";
import {createHash} from "node:crypto";
import {createRequire} from "node:module";
const root="/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono";
const sharp=createRequire(root+"/integration-20261123-0320/apps/www/package.json")("sharp");
const directory=root+"/shadow-replays-4deb-02/s4-diagnostic-attempt-07/raw-paint-failure";
const bytes=fs.readFileSync(path.join(directory,"index.json"));
const d=JSON.parse(bytes);
for(const frame of d.frames){
 const png=fs.readFileSync(path.join(directory,frame.file));
 if(createHash("sha256").update(png).digest("hex")!==frame.sha256)throw Error("frame hash "+frame.file);
 const {data,info}=await sharp(png).resize({width:550}).removeAlpha().raw().toBuffer({resolveWithObject:true});
 let pixels=0;for(let i=0;i<data.length;i+=info.channels)if(data[i]>200&&data[i+1]<80&&data[i+2]>200)pixels++;
 frame.markerPixels=pixels;frame.visible=pixels>=4;
}
const report={kind:"offline-analysis-after-original-failure",measuredGateStillFailed:true,indexSha256:createHash("sha256").update(bytes).digest("hex"),framesVerified:d.frames.length,paths:d.paths.map(p=>{
 const samples=d.frames.filter(f=>f.path===p.path);let faded=false;const flashes=[];
 const trace=samples.map((f,i)=>{const event=d.events.filter(e=>e.profile===p.profile&&e.time<=f.time).at(-1);const item={file:f.file,elapsed:f.time-p.start,markerPixels:f.markerPixels,visible:f.visible,detached:event?.detached,open:event?.open};if(faded&&f.visible)flashes.push(i);if(!f.visible)faded=true;return item;});
 return {path:p.path,count:samples.length,meetsOriginalMinimum:samples.length>=5,observedFade:faded,flashFrames:flashes,trace};
})};
const output=path.join(directory,"offline-analysis.json");fs.writeFileSync(output,JSON.stringify(report,null,2)+"\n");
console.log(JSON.stringify({output,framesVerified:report.framesVerified,paths:report.paths.map(({path,count,meetsOriginalMinimum,observedFade,flashFrames,trace})=>({path,count,meetsOriginalMinimum,observedFade,flashFrames,first:trace[0],last:trace.at(-1)}))}));
