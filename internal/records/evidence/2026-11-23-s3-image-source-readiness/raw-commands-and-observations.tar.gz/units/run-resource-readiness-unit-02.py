import hashlib,json,pathlib,subprocess,time,os,traceback,datetime
B=pathlib.Path("/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono")
R=B/'continuation-s3-image-4deb'
E=B/'evidence/continuation-s3-image-4deb'
payload=json.loads((E/'resource-readiness-candidate-01.json').read_text())
FILES=['apps/www/src/components/documentation-image-preview.test.ts','apps/www/src/components/documentation-image-source.test.ts','apps/www/src/components/documentation-image-zoom.test.ts','apps/www/src/components/documentation-image-geometry.test.ts','apps/www/src/components/documentation-image-trigger-readiness.test.ts']
receipt={'schemaVersion':1,'baseCommit':payload['baseCommit'],'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':payload['scope'],'sourceFiles':[],'commands':[],'priorAttempt':'resource-readiness-unit-01.json','runnerCorrection':'Set minWorkers and maxWorkers to one together; original five test files, per-case budgets and assertions unchanged.'}
env=dict(os.environ)
env['PATH']=str(B/'tools/node-v24.22.3-linux-x64/bin')+':'+env.get('PATH','')
env['COREPACK_HOME']=str(B/'corepack-cache')
def save(): (E/'resource-readiness-unit-02.json').write_text(json.dumps(receipt,indent=2)+'\n')
def check_source():
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
 if head!=payload['baseCommit']:raise RuntimeError('Unexpected baseline '+head)
 for f in payload['files']:
  data=(R/f['path']).read_bytes()
  expected=f['content'].encode()
  if data!=expected:raise RuntimeError('Source drift '+f['path'])
 return [{'path':f['path'],'sha256':hashlib.sha256((R/f['path']).read_bytes()).hexdigest()} for f in payload['files']]
try:
 receipt['sourceFiles']=check_source();save()
 args=['node','node_modules/vitest/vitest.mjs','run',*FILES,'--minWorkers=1','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(E/'resource-readiness-vitest-02.json')]
 start=time.monotonic()
 with (E/'resource-readiness-unit-02.log').open('wb') as log:
  result=subprocess.run(args,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt['commands'].append({'command':args,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-start,'logSha256':hashlib.sha256((E/'resource-readiness-unit-02.log').read_bytes()).hexdigest()})
 report=E/'resource-readiness-vitest-02.json'
 if report.exists():
  data=json.loads(report.read_text())
  receipt['testSummary']={k:data.get(k) for k in ['success','numTotalTests','numPassedTests','numFailedTests','numPendingTests','numRuntimeErrorTestSuites']}
  receipt['jsonSha256']=hashlib.sha256(report.read_bytes()).hexdigest()
  names=[r['name'] for r in data.get('testResults',[])]
  if not all(any(n.endswith(f) for n in names) for f in FILES):raise RuntimeError('Expected test file was not executed')
  if data.get('numTotalTests',0)==0:raise RuntimeError('Zero executed tests cannot pass')
  if data.get('numFailedTests',0) or data.get('numRuntimeErrorTestSuites',0):raise RuntimeError('Original test gate failed')
 else:raise RuntimeError('Missing Vitest report')
 if result.returncode:raise RuntimeError('Original Vitest command exit '+str(result.returncode))
 receipt['sourceFilesAfter']=check_source()
 receipt['passed']=True
except BaseException as e:
 receipt['failure']=str(e);receipt['passed']=False;traceback.print_exc()
finally:
 receipt['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
