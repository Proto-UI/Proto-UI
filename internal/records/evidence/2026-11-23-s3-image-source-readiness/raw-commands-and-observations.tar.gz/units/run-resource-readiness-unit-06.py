from pathlib import Path
import json, subprocess, os, time, hashlib, datetime, traceback
B=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
R=B/'continuation-s3-image-4deb'
E=B/'evidence/continuation-s3-image-4deb'
receipt=E/'resource-readiness-unit-06.json'
if receipt.exists(): raise RuntimeError('Existing receipt: reconcile instead of repeating')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
env=os.environ.copy()
env['PATH']=str(B/'tools/node-v24.22.3-linux-x64/bin')+':'+env['PATH']
env['COREPACK_HOME']=str(B/'corepack-cache')
env['TMPDIR']=str(E/'tmp')
Path(env['TMPDIR']).mkdir(exist_ok=True)
state={'schemaVersion':1,'baseCommit':'d0392fb31513b12f55b9e99b1fcf26a6338569c9','startedAt':now(),'kind':'picture-declaration-identity-original-suite','commands':[],'scope':'Preserve the actual red in attempt 05; correct only the new control to assert the pre-existing idle image remains unchanged. Original 89 assertions and budgets remain unchanged.'}
def save(): receipt.write_text(json.dumps(state,indent=2)+'\n')
def run(name,args,check=True):
 c={'name':name,'command':args,'startedAt':now()};state['commands'].append(c);save()
 out=E/(name+'.log');start=time.monotonic()
 with out.open('wb') as f:
  p=subprocess.Popen(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT);c['pid']=p.pid;save();code=p.wait()
 c.update(exitCode=code,elapsedSeconds=time.monotonic()-start,output=str(out),sha256=sha(out.read_bytes()));save()
 if check and code:raise RuntimeError(name+' failed '+str(code))
 return code
def summary(p):
 d=json.loads(p.read_text())
 return {k:d.get(k) for k in ['success','numTotalTests','numPassedTests','numFailedTests','numPendingTests']}
save()
prereq=R/'apps/www/src/components/documentation-image-trigger-readiness.test.ts'
prereq_before=prereq.read_bytes()
restored=False
try:
 source=R/'apps/www/src/components/documentation-image-preview.ts'
 test=R/'apps/www/src/components/documentation-image-preview.test.ts'
 css=R/'apps/www/src/styles/documentation-image-preview.css'
 assert sha(source.read_bytes())=='20cd7b233e7d585eb905f2cff2f73b5acb3c0191938b983efabd602ba6d60969'
 assert sha(test.read_bytes())=='4f51879b7af44623c812cbd976cfda52b6d8edd08fc9cf3dec3696c3aeeeac4d'
 s=test.read_text()
 begin=s.index("  it('retires a pending request when the picture node changes but its old markup is preserved'")
 end=s.index("  it('keeps HTML style changes",begin)
 block=s[begin:end]
 before="    const { trigger, root } = await fixture();"
 after="""    const { trigger, root } = await fixture();
    const idleImage = document.querySelector<HTMLImageElement>('.docs-image-full')!;
    expect(idleImage).not.toBeNull();
    const idleMarkup = idleImage.outerHTML;"""
 assert block.count(before)==1
 block=block.replace(before,after)
 before="    expect(document.querySelector('.docs-image-full')).toBeNull();"
 after="""    expect(document.querySelector('.docs-image-full')).toBe(idleImage);
    expect(idleImage.outerHTML).toBe(idleMarkup);"""
 assert block.count(before)==1
 block=block.replace(before,after);test.write_text(s[:begin]+block+s[end:])
 run('resource-readiness-format-identity-06',['corepack','pnpm@10.32.1','exec','prettier','--write',str(test.relative_to(R))])
 pre=json.loads((E/'trigger-readiness-root-prerequisite.json').read_text())
 assert subprocess.run(['git','hash-object',str(prereq)],cwd=R,check=True,capture_output=True,text=True).stdout.strip()==pre['expectedBeforeBlob']
 assert sha(pre['content'].encode())==pre['sha256']
 prereq.write_text(pre['content'])
 state['testPrerequisite']={k:v for k,v in pre.items() if k!='content'};state['testPrerequisiteApplied']=True
 state['sourceFiles']=[{'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes())} for p in [source,test,css]]
 payload=json.loads((E/'resource-readiness-candidate-03.json').read_text())
 for entry in payload['files']:
  p=R/entry['path']
  for key in ['content','text']:
   if key in entry:entry[key]=p.read_text()
  for key in ['sha256','afterSha256']:
   if key in entry:entry[key]=sha(p.read_bytes())
 payload['newControlFixtureCorrection']='The original viewer pre-creates its idle image. Preserve exact object and markup after retiring the request; do not assert an absent node.'
 (E/'resource-readiness-candidate-04.json').write_text(json.dumps(payload,indent=2)+'\n');save()
 files=['documentation-image-preview.test.ts','documentation-image-source.test.ts','documentation-image-zoom.test.ts','documentation-image-geometry.test.ts','documentation-image-trigger-readiness.test.ts']
 output=E/'resource-readiness-vitest-06.json'
 command=['node','node_modules/vitest/vitest.mjs','run',*['apps/www/src/components/'+f for f in files],'--minWorkers=1','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(output)]
 code=run('resource-readiness-unit-06',command,False)
 state['testSummary']=summary(output);state['jsonSha256']=sha(output.read_bytes())
 state['sourceFilesAfter']=[{'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes())} for p in [source,test,css]]
 assert state['sourceFilesAfter']==state['sourceFiles']
 assert code==0 and state['testSummary']['numPassedTests']==90 and state['testSummary']['numFailedTests']==0 and state['testSummary']['numPendingTests']==0
 state['passed']=True
except BaseException as ex:
 state['passed']=False;state['error']=repr(ex);state['traceback']=traceback.format_exc()
finally:
 if state.get('testPrerequisiteApplied'):
  if sha(prereq.read_bytes())==state['testPrerequisite']['sha256']:
   prereq.write_bytes(prereq_before);state['testPrerequisiteRestored']=True
  else:state['testPrerequisiteRestored']=False;state['passed']=False
 state['finishedAt']=now();save()
