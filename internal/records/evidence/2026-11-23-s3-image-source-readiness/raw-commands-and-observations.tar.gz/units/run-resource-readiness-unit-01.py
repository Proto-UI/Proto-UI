import hashlib,json,pathlib,subprocess,time,os,traceback,datetime
B=pathlib.Path("/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono")
R=B/'continuation-s3-image-4deb'
E=B/'evidence/continuation-s3-image-4deb'
payload=json.loads((E/'resource-readiness-candidate-01.json').read_text())
receipt={'schemaVersion':1,'baseCommit':payload['baseCommit'],'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':payload['scope'],'sourceFiles':[],'commands':[]}
env=dict(os.environ)
env['PATH']=str(B/'tools/node-v24.22.3-linux-x64/bin')+':'+env.get('PATH','')
env['COREPACK_HOME']=str(B/'corepack-cache')
def save(): (E/'resource-readiness-unit-01.json').write_text(json.dumps(receipt,indent=2)+'\n')
def cmd(name,args):
 t=time.monotonic()
 with (E/(name+'.log')).open('wb') as log: result=subprocess.run(args,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':args,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-t,'logSha256':hashlib.sha256((E/(name+'.log')).read_bytes()).hexdigest()}
 receipt['commands'].append(row);save()
 if result.returncode: raise RuntimeError(name+' exit '+str(result.returncode))
try:
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
 if head!=payload['baseCommit']:raise RuntimeError('Unexpected baseline '+head)
 for f in payload['files']:
  data=(R/f['path']).read_bytes()
  blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  if blob!=f['expectedBlobSha']:raise RuntimeError('Source drift '+f['path']+' '+blob)
  receipt['sourceFiles'].append({'path':f['path'],'beforeSha256':hashlib.sha256(data).hexdigest(),'expectedBlobSha':blob,'afterSha256':hashlib.sha256(f['content'].encode()).hexdigest()})
 cmd('resource-readiness-branch-01',['git','switch','-c','fix/s3-image-resource-readiness-4deb'])
 for f in payload['files']: (R/f['path']).write_text(f['content'])
 receipt['applied']=True;save()
 cmd('resource-readiness-unit-01',['node','node_modules/vitest/vitest.mjs','run','apps/www/src/components/documentation-image-preview.test.ts','apps/www/src/components/documentation-image-source.test.ts','apps/www/src/components/documentation-image-zoom.test.ts','apps/www/src/components/documentation-image-geometry.test.ts','apps/www/src/components/documentation-image-trigger-readiness.test.ts','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(E/'resource-readiness-vitest-01.json')])
 receipt['passed']=True
except BaseException as e:
 receipt['failure']=str(e);receipt['passed']=False;traceback.print_exc()
finally:
 receipt['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
