import hashlib,json,pathlib,subprocess,time,os,traceback,datetime
B=pathlib.Path("/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono")
R=B/'continuation-s3-image-4deb'
E=B/'evidence/continuation-s3-image-4deb'
payload=json.loads((E/'resource-readiness-candidate-01.json').read_text())
FILES=['apps/www/src/components/documentation-image-preview.test.ts','apps/www/src/components/documentation-image-source.test.ts','apps/www/src/components/documentation-image-zoom.test.ts','apps/www/src/components/documentation-image-geometry.test.ts','apps/www/src/components/documentation-image-trigger-readiness.test.ts']
prerequisite={"path":"apps/www/src/components/documentation-image-trigger-readiness.test.ts","prerequisiteCommit":"3f08c1433971b90203733e824b9ad4fc7f3c7835","expectedBeforeBlob":"d55df6148ee91f7913f6df337b60268369cbdfc2","blob":"b5047b55870623a6e4a758654732ce464cc19d52","sha256":"232bb151f16755f10ed45c99311ba0fae2c3ba1228544efad3dc2910231f6131","content":"import { readFileSync } from 'node:fs';\nimport { runInNewContext } from 'node:vm';\nimport ts from 'typescript';\nimport { afterEach, expect, it } from 'vitest';\n\n// Execute the actual browser admission predicate without importing its hooks,\n// starting a server, or replacing any native interaction assertion.\nconst path = `${process.cwd()}/apps/www/src/components/documentation-image-preview.browser.test.ts`;\nconst source = readFileSync(path, 'utf8');\nconst ast = ts.createSourceFile(path, source, ts.ScriptTarget.Latest, true);\nconst predicates: ts.Expression[] = [];\nconst visit = (node: ts.Node) => {\n  if (ts.isCallExpression(node) && node.expression.getText(ast) === 'page.waitForFunction') {\n    const candidate = node.arguments[0];\n    if (\n      candidate?.getText(ast).includes('docs-preview-${family}') &&\n      candidate.getText(ast).includes('triggers.length === 2')\n    )\n      predicates.push(candidate);\n  }\n  ts.forEachChild(node, visit);\n};\nvisit(ast);\nif (predicates.length !== 1)\n  throw new Error('Missing or ambiguous exact image-trigger browser readiness predicate');\nconst predicate = predicates[0]!;\nconst evaluate = ts.transpileModule(`const ready = ${predicate.getText(ast)}; ready;`, {\n  compilerOptions: { target: ts.ScriptTarget.ES2022 },\n}).outputText;\nconst ready = (family: string) => runInNewContext(evaluate, { document })(family) as boolean;\nafterEach(() => document.body.replaceChildren());\nit.each(['shadcn', 'brutalist'] as const)(\n  'accepts actual %s private trigger identity and rejects obsolete, incomplete or wrong-family controls',\n  (family) => {\n    const triggers = Array.from({ length: 2 }, () => {\n      const node = document.createElement(`docs-preview-${family}-image-trigger`);\n      node.dataset.docsImageTrigger = '';\n      node.dataset.docsPreviewFamily = family;\n      node.setAttribute('role', 'button');\n      node.tabIndex = 0;\n      document.body.append(node);\n      return node;\n    });\n    expect(ready(family)).toBe(true);\n    for (const [attribute, value] of [\n      ['data-docs-preview-family', 'wrong-family'],\n      ['role', 'presentation'],\n      ['tabindex', '-1'],\n      ['aria-disabled', 'true'],\n      ['hidden', ''],\n      ['inert', ''],\n    ]) {\n      const previous = triggers[0].getAttribute(attribute);\n      triggers[0].setAttribute(attribute, value);\n      expect(ready(family), attribute).toBe(false);\n      if (previous === null) triggers[0].removeAttribute(attribute);\n      else triggers[0].setAttribute(attribute, previous);\n    }\n    const obsolete = document.createElement(`docs-preview-${family}-button`);\n    for (const attribute of triggers[0].attributes)\n      obsolete.setAttribute(attribute.name, attribute.value);\n    triggers[0].replaceWith(obsolete);\n    expect(ready(family), 'family Button is no longer the image trigger').toBe(false);\n    obsolete.replaceWith(triggers[0]);\n    triggers[1].remove();\n    expect(ready(family), 'missing trigger').toBe(false);\n  }\n);\n"}
receipt={'schemaVersion':1,'baseCommit':payload['baseCommit'],'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':payload['scope'],'sourceFiles':[],'commands':[],'priorAttempt':'resource-readiness-unit-02.json','runnerCorrection':'minWorkers=maxWorkers=1; original five test files and budgets unchanged.','testPrerequisite':{k:v for k,v in prerequisite.items() if k!='content'}}
env=dict(os.environ)
env['PATH']=str(B/'tools/node-v24.22.3-linux-x64/bin')+':'+env.get('PATH','')
env['COREPACK_HOME']=str(B/'corepack-cache')
def save(): (E/'resource-readiness-unit-03.json').write_text(json.dumps(receipt,indent=2)+'\n')
def check_source():
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
 if head!=payload['baseCommit']:raise RuntimeError('Unexpected baseline '+head)
 for f in payload['files']:
  data=(R/f['path']).read_bytes()
  expected=f['content'].encode()
  if data!=expected:raise RuntimeError('Source drift '+f['path'])
 return [{'path':f['path'],'sha256':hashlib.sha256((R/f['path']).read_bytes()).hexdigest()} for f in payload['files']]
originalPrerequisite=None
try:
 receipt['sourceFiles']=check_source();save()
 p=R/prerequisite['path']
 originalPrerequisite=p.read_bytes()
 blob=hashlib.sha1(b'blob '+str(len(originalPrerequisite)).encode()+b'\0'+originalPrerequisite).hexdigest()
 if blob!=prerequisite['expectedBeforeBlob']:raise RuntimeError('Prerequisite source drift '+blob)
 p.write_text(prerequisite['content'])
 receipt['testPrerequisiteApplied']=True;save()
 args=['node','node_modules/vitest/vitest.mjs','run',*FILES,'--minWorkers=1','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(E/'resource-readiness-vitest-03.json')]
 start=time.monotonic()
 with (E/'resource-readiness-unit-03.log').open('wb') as log:
  result=subprocess.run(args,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt['commands'].append({'command':args,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-start,'logSha256':hashlib.sha256((E/'resource-readiness-unit-03.log').read_bytes()).hexdigest()})
 report=E/'resource-readiness-vitest-03.json'
 if report.exists():
  data=json.loads(report.read_text())
  receipt['testSummary']={k:data.get(k) for k in ['success','numTotalTests','numPassedTests','numFailedTests','numPendingTests','numRuntimeErrorTestSuites']}
  receipt['jsonSha256']=hashlib.sha256(report.read_bytes()).hexdigest()
  names=[r['name'] for r in data.get('testResults',[])]
  if not all(any(n.endswith(f) for n in names) for f in FILES):raise RuntimeError('Expected test file was not executed')
  if data.get('numTotalTests',0)==0:raise RuntimeError('Zero executed tests cannot pass')
  if data.get('numFailedTests',0) or data.get('numRuntimeErrorTestSuites',0):raise RuntimeError('Original test gate failed')
 else:raise RuntimeError('Missing Vitest report')
 if result.returncode:raise RuntimeError('Original Vitest command exit '+str(result.returncode))
 receipt['sourceFilesAfter']=check_source()
 receipt['passed']=True
except BaseException as e:
 receipt['failure']=str(e);receipt['passed']=False;traceback.print_exc()
finally:
 if originalPrerequisite is not None and receipt.get('testPrerequisiteApplied'):
  p=R/prerequisite['path']
  if p.read_text()!=prerequisite['content']:raise RuntimeError('Prerequisite was edited while running; refusing restore')
  p.write_bytes(originalPrerequisite)
  receipt['testPrerequisiteRestored']=True
 receipt['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
