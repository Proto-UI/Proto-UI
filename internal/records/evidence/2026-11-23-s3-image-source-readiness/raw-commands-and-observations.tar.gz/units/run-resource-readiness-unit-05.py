from pathlib import Path
import json, subprocess, os, time, hashlib, datetime, traceback
B=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
R=B/'continuation-s3-image-4deb'
E=B/'evidence/continuation-s3-image-4deb'
receipt=E/'resource-readiness-unit-05.json'
if receipt.exists(): raise RuntimeError('Existing receipt: reconcile instead of repeating')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
env=os.environ.copy()
env['PATH']=str(B/'tools/node-v24.22.3-linux-x64/bin')+':'+env['PATH']
env['COREPACK_HOME']=str(B/'corepack-cache')
env['TMPDIR']=str(E/'tmp')
Path(env['TMPDIR']).mkdir(exist_ok=True)
state={'schemaVersion':1,'baseCommit':'d0392fb31513b12f55b9e99b1fcf26a6338569c9','startedAt':now(),'kind':'picture-declaration-identity-red-green','commands':[],'scope':'Independent review identified a DOM declaration replacement missed by equal old markup. Original 32 browser result remains bound to candidate 02.'}
def save(): receipt.write_text(json.dumps(state,indent=2)+'\n')
def run(name,args,check=True):
 c={'name':name,'command':args,'startedAt':now()};state['commands'].append(c);save()
 out=E/(name+'.log');start=time.monotonic()
 with out.open('wb') as f:
  p=subprocess.Popen(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT);c['pid']=p.pid;save();code=p.wait()
 c.update(exitCode=code,elapsedSeconds=time.monotonic()-start,output=str(out),sha256=sha(out.read_bytes()));save()
 if check and code:raise RuntimeError(name+' failed '+str(code))
 return code
def summary(p):
 d=json.loads(p.read_text())
 return {k:d.get(k) for k in ['success','numTotalTests','numPassedTests','numFailedTests','numPendingTests']}
save()
prereq=R/'apps/www/src/components/documentation-image-trigger-readiness.test.ts'
prereq_before=prereq.read_bytes()
restored=False
try:
 source=R/'apps/www/src/components/documentation-image-preview.ts'
 test=R/'apps/www/src/components/documentation-image-preview.test.ts'
 css=R/'apps/www/src/styles/documentation-image-preview.css'
 assert sha(source.read_bytes())=='198eb90717d3f3948f67b128305262715e5766001346fadd69a73855ecd0b915'
 assert sha(test.read_bytes())=='67de3b04ea6a76f51f583f3ebf7e19dbbd2ab1253f46dab51448094fd2dd4ba4'
 assert sha(css.read_bytes())=='fac46602ca5b894536da107a5fa97d6a3200ac3cf774594ed8cc68e24aa9511b'
 before=source.read_bytes()
 state['sourceBefore']={str(p.relative_to(R)):sha(p.read_bytes()) for p in [source,test,css]};save()
 new_test="""  it('retires a pending request when the picture node changes but its old markup is preserved', async () => {
    const { trigger, root } = await fixture();
    const media = trigger.querySelector('img')!;
    const declaration = document.createElement('picture');
    media.replaceWith(declaration);
    declaration.append(media);
    await settle();
    let ready!: () => void;
    const decoded = new Promise<void>((resolve) => { ready = resolve; });
    vi.spyOn(media, 'currentSrc', 'get').mockReturnValue('');
    Object.defineProperty(media, 'decode', { configurable: true, value: () => decoded });

    trigger.dispatchEvent(new MouseEvent('click', { bubbles: true }));
    await settle();
    expect(root.getExposes?.().open.get()).toBe(false);
    const requestedMarkup = declaration.outerHTML;
    const preservedMedia = media.cloneNode(true);
    const replacement = document.createElement('picture');
    declaration.replaceWith(replacement);
    replacement.append(media);
    declaration.append(preservedMedia);
    expect(declaration.outerHTML).toBe(requestedMarkup);
    expect(trigger.contains(media)).toBe(true);
    expect(media.closest('picture')).toBe(replacement);

    ready();
    await settle();
    expect(root.getExposes?.().open.get()).toBe(false);
    expect(document.querySelector('.docs-image-full')).toBeNull();
  });

"""
 anchor="  it('keeps HTML style changes out of the media inventory scan', async () => {"
 content=test.read_text();assert content.count(anchor)==1
 test.write_text(content.replace(anchor,new_test+anchor))
 run('resource-readiness-format-identity-05',['corepack','pnpm@10.32.1','exec','prettier','--write',str(test.relative_to(R))])
 # The exact already-committed independent trigger-readiness fixture is a prerequisite.
 prerequisite=json.loads((E/'resource-readiness-unit-04.json').read_text())['testPrerequisite']
 blob=subprocess.run(['git','hash-object',str(prereq)],cwd=R,check=True,capture_output=True,text=True).stdout.strip()
 assert blob==prerequisite['expectedBeforeBlob']
 # The earlier runner kept its explicit prerequisite content in a local payload.
 payload_path=E/'trigger-readiness-root-prerequisite.json'
 if payload_path.exists():
  payload=json.loads(payload_path.read_text());replacement_content=payload.get('content') or payload.get('text')
 else:
  # Saved exact prerequisite is embedded in the previous validated runner.
  import ast
  tree=ast.parse((E/'run-resource-readiness-unit-04.py').read_text())
  replacement_content=None
  for node in ast.walk(tree):
   if isinstance(node,ast.Constant) and isinstance(node.value,str) and sha(node.value.encode())==prerequisite['sha256']:
    replacement_content=node.value;break
  if replacement_content is None: raise RuntimeError('Exact prerequisite bytes unavailable')
 assert sha(replacement_content.encode())==prerequisite['sha256']
 prereq.write_text(replacement_content)
 state['testPrerequisite']=prerequisite;state['testPrerequisiteApplied']=True;save()
 red_json=E/'resource-readiness-identity-red-05.json'
 red_command=['node','node_modules/vitest/vitest.mjs','run',str(test.relative_to(R)),'--minWorkers=1','--maxWorkers=1','--testNamePattern=retires a pending request when the picture node changes','--reporter=default','--reporter=json','--outputFile='+str(red_json)]
 code=run('resource-readiness-identity-red-05',red_command,False)
 state['redSummary']=summary(red_json);state['redJsonSha256']=sha(red_json.read_bytes());save()
 assert code!=0 and state['redSummary']['numFailedTests']==1 and state['redSummary']['numPassedTests']==0, 'Negative control did not detect the missing declaration identity guard'
 assert source.read_bytes()==before
 old='      if (declaration.outerHTML !== requestedDeclaration) return;'
 new="""      if (
        (item.media.closest('picture') ?? item.media) !== declaration ||
        declaration.outerHTML !== requestedDeclaration
      )
        return;"""
 content=source.read_text();assert content.count(old)==1;source.write_text(content.replace(old,new))
 run('resource-readiness-format-source-05',['corepack','pnpm@10.32.1','exec','prettier','--write',str(source.relative_to(R)),str(test.relative_to(R))])
 payload=json.loads((E/'resource-readiness-candidate-02.json').read_text())
 for entry in payload['files']:
  p=R/entry['path']
  if 'content' in entry:entry['content']=p.read_text()
  if 'text' in entry:entry['text']=p.read_text()
  if 'sha256' in entry:entry['sha256']=sha(p.read_bytes())
  if 'afterSha256' in entry:entry['afterSha256']=sha(p.read_bytes())
 payload['independentReviewFollowup']='Exact picture node identity after decode; same-markup reparenting negative control failed before source change.'
 (E/'resource-readiness-candidate-03.json').write_text(json.dumps(payload,indent=2)+'\n')
 state['sourceFiles']=[{'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes())} for p in [source,test,css]];save()
 files=['documentation-image-preview.test.ts','documentation-image-source.test.ts','documentation-image-zoom.test.ts','documentation-image-geometry.test.ts','documentation-image-trigger-readiness.test.ts']
 green_json=E/'resource-readiness-vitest-05.json'
 command=['node','node_modules/vitest/vitest.mjs','run',*['apps/www/src/components/'+f for f in files],'--minWorkers=1','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(green_json)]
 run('resource-readiness-unit-05',command)
 state['testSummary']=summary(green_json);state['jsonSha256']=sha(green_json.read_bytes())
 state['sourceFilesAfter']=[{'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes())} for p in [source,test,css]]
 assert state['sourceFilesAfter']==state['sourceFiles']
 assert state['testSummary']['numPassedTests']==90 and state['testSummary']['numFailedTests']==0 and state['testSummary']['numPendingTests']==0
 state['passed']=True
except BaseException as ex:
 state['passed']=False;state['error']=repr(ex);state['traceback']=traceback.format_exc()
finally:
 if state.get('testPrerequisiteApplied'):
  if sha(prereq.read_bytes())==state['testPrerequisite']['sha256']:
   prereq.write_bytes(prereq_before);state['testPrerequisiteRestored']=True
  else:state['testPrerequisiteRestored']=False;state['passed']=False
 state['finishedAt']=now();save()
