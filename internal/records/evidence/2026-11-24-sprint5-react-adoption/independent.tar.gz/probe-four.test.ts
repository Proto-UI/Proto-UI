// @vitest-environment happy-dom
// Independent reviewer controls. Generated-artifact loader reused from the author fixture; the oracles below are new.
import { createRequire } from 'node:module';
import { mkdir, mkdtemp, rm } from 'node:fs/promises';
import { join, posix } from 'node:path';
import { URL as NodeURL } from 'node:url';
import ts from 'typescript';
import * as React from 'react';
import * as ReactDOM from 'react-dom';
import * as ReactDOMClient from 'react-dom/client';
import * as ReactDOMServer from 'react-dom/server';
import * as ReactJSX from 'react/jsx-runtime';
import { describe, expect, it } from 'vitest';
import { parsePrototype } from '/workspace/scratch/f7b299133482/s5-owner/packages/compiler/src/parser';
import { emitReactSource } from '/workspace/scratch/f7b299133482/s5-owner/packages/compiler/src/react-source';
import { writeCompilation } from '/workspace/scratch/f7b299133482/s5-owner/packages/compiler/src/compile';
import { generatedSourcePath } from '/workspace/scratch/f7b299133482/s5-owner/packages/compiler/src/emitter-map';

(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT =
  true;
const floatingRequire = createRequire(
  new NodeURL('../../modules/positioning/package.json', import.meta.url)
);
const source = `import {definePrototype} from '@proto.ui/core';
export default definePrototype({name:'adoption-owner',setup(def){
  def.props.define({seed:{type:'number',default:3}});
  const value=def.state.numberDiscrete('value',0);
  def.expose.state('value',value);
  def.expose.event('phase',{payload:'json'});
  def.lifecycle.onCreated(run=>{value.set(run.props.get().seed);run.expose.emit('phase','created');});
  def.lifecycle.onBeforeDispose(run=>run.expose.emit('phase','disposed'));
  return r=>r.el('section',{},[r.el('output',value.get()),r.slot()]);
}});`;

interface GeneratedRoot {
  root: ReactDOMClient.Root;
  diagnostics: unknown[];
  getHandle(): { getExposes(): { value: { get(): number } } };
  render(props: Record<string, unknown>): void;
  unmount(): void;
}
interface GeneratedModule {
  renderGeneratedToString(props?: Record<string, unknown>): { html: string; carrier: unknown };
  hydrateGeneratedRoot(
    container: Element,
    props: Record<string, unknown>,
    carrier: unknown,
    options?: ReactDOMClient.HydrationOptions
  ): GeneratedRoot;
}

function compileGenerated(prototypeSource = source) {
  const parsed = parsePrototype(prototypeSource, { fileName: 'react-adoption-owner.proto.ts' });
  if (!parsed.ok) throw new Error(JSON.stringify(parsed.diagnostics));
  const emitted = emitReactSource(parsed.value, { ssr: true });
  if (!emitted.ok) throw new Error(JSON.stringify(emitted.diagnostics));
  return { ir: parsed.value, output: emitted.value };
}

function generated(prototypeSource = source): GeneratedModule {
  const { output } = compileGenerated(prototypeSource);
  const sources = new Map((output.supportingFiles ?? []).map((file) => [file.path, file.contents]));
  sources.set('Component.tsx', output.code);
  const cache = new Map<string, Record<string, unknown>>();
  function load(path: string): Record<string, unknown> {
    const previous = cache.get(path);
    if (previous) return previous;
    const input = sources.get(path);
    if (input === undefined) throw new Error(`Missing actual emitted module: ${path}`);
    const exports: Record<string, unknown> = {};
    cache.set(path, exports);
    const javascript = ts.transpileModule(input, {
      fileName: path,
      compilerOptions: {
        target: ts.ScriptTarget.ES2022,
        module: ts.ModuleKind.CommonJS,
        jsx: ts.JsxEmit.ReactJSX,
      },
    }).outputText;
    new Function('exports', 'require', javascript)(exports, (specifier: string) => {
      if (specifier === 'react') return React;
      if (specifier === 'react-dom') return ReactDOM;
      if (specifier === 'react-dom/client') return ReactDOMClient;
      if (specifier === 'react-dom/server') return ReactDOMServer;
      if (specifier === 'react/jsx-runtime') return ReactJSX;
      if (specifier === '@floating-ui/dom') return floatingRequire(specifier);
      if (!specifier.startsWith('.'))
        throw new Error(`Unexpected emitted dependency: ${specifier}`);
      const relative = posix.normalize(posix.join(posix.dirname(path), specifier));
      return load(sources.has(relative) ? relative : `${relative}.ts`);
    });
    return exports;
  }
  return load('Component.tsx') as unknown as GeneratedModule;
}

describe('independent review: React rejection lifetime', () => {
  it.each([false, undefined])('preserves the primary authored startup value %j through secondary cleanup failure', (primary) => {
    const input = `import {definePrototype} from '@proto.ui/core';
export default definePrototype({name:'review-primary-owner',setup(def){
 def.lifecycle.onCreated(()=>{throw ${primary === undefined ? 'undefined' : 'false'};});
 def.lifecycle.onBeforeDispose(()=>{throw 'secondary cleanup';});
 return r=>r.el('output','unreached');
}});`;
    const module = generated(input);
    let didThrow=false;let thrown:unknown;
    try {module.renderGeneratedToString();}catch(error){didThrow=true;thrown=error;}
    expect(didThrow).toBe(true);expect(thrown).toBe(primary);
  });

  it('refuses wrapper work in the recoverable callback before retirement and native render after retirement', async () => {
    const module = generated();
    const server = module.renderGeneratedToString({ children: React.createElement(React.Suspense, {fallback:null}, React.createElement('button', null, 'server')) });
    const host=document.createElement('div');host.innerHTML=server.html;document.body.append(host);
    let active=0,retired=0;
    function Child(){React.useEffect(()=>{active++;return()=>{active--;retired++;};},[]);return React.createElement('button',null,'client');}
    let app:GeneratedRoot|undefined;const callbacks:unknown[]=[];
    try {
      await React.act(async()=>{app=module.hydrateGeneratedRoot(host,{children:React.createElement(React.Suspense,{fallback:null},React.createElement(Child))},server.carrier,{onRecoverableError(error){
        expect(app).toBeDefined();
        expect(()=>app!.render({seed:7})).toThrow(/rejected or disposed/);
        expect(()=>app!.getHandle()).toThrow(/adoption did not succeed/);
        callbacks.push(error);
      }});});
      expect(callbacks).toHaveLength(1);expect(app!.diagnostics[0]).toBe(callbacks[0]);
      expect({active,retired}).toEqual({active:0,retired:1});
      expect(()=>app!.root.render(React.createElement('button',null,'late'))).toThrow(/unmounted root/i);
      expect(host.querySelector('button')).toBeNull();
    } finally {await React.act(async()=>{app?.unmount();});host.remove();}
  });

  it('keeps a fresh adopted owner alive when the old deferred retirement runs later', async()=>{
    const module=generated();
    const oldProps={children:React.createElement(React.Suspense,{fallback:null},React.createElement('button',null,'server'))};
    const server=module.renderGeneratedToString(oldProps);
    const host=document.createElement('div');host.innerHTML=server.html;document.body.append(host);
    let active=0,retired=0;
    function Child(){React.useEffect(()=>{active++;return()=>{active--;retired++;};},[]);return React.createElement('button',null,'client');}
    const originalQueue=globalThis.queueMicrotask;
    const held:VoidFunction[]=[];
    let old:GeneratedRoot|undefined,next:GeneratedRoot|undefined;
    try {
      globalThis.queueMicrotask=(callback)=>{held.push(callback);};
      await React.act(async()=>{old=module.hydrateGeneratedRoot(host,{children:React.createElement(React.Suspense,{fallback:null},React.createElement(Child))},server.carrier,{onRecoverableError(){}});});
      expect(()=>old!.getHandle()).toThrow(/adoption did not succeed/);
      expect(active).toBe(1);expect(held.length).toBeGreaterThan(0);
      await React.act(async()=>{old!.unmount();});
      expect({active,retired}).toEqual({active:0,retired:1});
      globalThis.queueMicrotask=originalQueue;
      host.innerHTML=server.html;
      const phases:unknown[]=[];
      await React.act(async()=>{next=module.hydrateGeneratedRoot(host,{...oldProps,onPhase:(phase:unknown)=>phases.push(phase)},server.carrier);});
      const state=next!.getHandle().getExposes().value;
      expect(state.get()).toBe(3);expect(phases).toEqual(['created']);
      await React.act(async()=>{for(const callback of held.splice(0))callback();});
      expect(next!.getHandle().getExposes().value).toBe(state);
      expect(state.get()).toBe(3);expect(phases).toEqual(['created']);
      expect(host.querySelector('button')?.textContent).toBe('server');
      expect({active,retired}).toEqual({active:0,retired:1});
    } finally {globalThis.queueMicrotask=originalQueue;await React.act(async()=>{old?.unmount();next?.unmount();for(const callback of held.splice(0))callback();});host.remove();}
  });
});
