# Independent React adoption retirement review

**The bounded five-file correction is adequately supported for integration. No new defect was established.** This is an independent local source review by `/root/browser` of `/root/ssr_owner`’s change, bound to tree `95576086dfad30c721b95dff5e97d4d103ba6be8` relative to Vue tree `6d91b2393c52d61adddf6d134552814dd48f214e`. It is external review evidence, not a GitHub approval or a whole-Sprint acceptance.

The applicable draft `C-LIFECYCLE-OWNER-INITIALIZATION-0001` A/D/E requires distinct fresh ownership, retirement before replacement and cleanup after rejected adoption. The patch implements the reproduced React recovery path without promoting that draft.

## Reviewed transition

React can recover a mismatching child within native Suspense and install the recovered child’s effect/listener while the generated API refuses adoption. The retained original red shows `active: 1` after refusal. The correction marks that generated owner terminal before delivering the recoverable-error callback, schedules retirement after the current native commit stack, and unmounts the actual React root. The closure holds that particular root. The retired flag is set before the call, so an explicit unmount followed by the queued callback cannot retire twice or redirect cleanup to a later owner.

`getHandle()` continues to reject diagnostics and replacement of the initial source-bound root; terminal owners cannot update. Diagnostic presence is determined by array length, not error truthiness. The empty-style `readonly string[]` annotation matches the established `serverTokens()` type and does not change runtime behavior.

## Evidence read and independent falsification

I read the full five-file delta, the draft criteria, emitted helper and owner cleanup code, original Suspense resource-leak failure, final 17/17 consumer report, strict source 454-file/zero-diagnostic result, catalog check and actual source hashes. The fixture’s real generated server/client modules and React effects are relevant to the reported leak; happy-dom is disclosed correctly.

I then executed four independent controls against the exact two reviewed emitter blobs, using the actual parser, emitted artifacts and React 18.3.1 modules. All four passed, zero skipped, exit 0:

1. The actual native recovery callback immediately observes refusal from generated `render` and `getHandle`, before the queued cleanup. After cleanup, the raw native React `root.render` rejects as an unmounted root; no native child resource remains.
2. A held old retirement callback runs after explicit old unmount and successful fresh adoption. The fresh State identity, value, visible child and one `created` event remain intact. This deliberately controls the microtask queue to exercise the late-callback boundary; it is not a physical scheduling observation.
3. A real emitted SSR consumer with authored `throw false` during created retains `false` despite a secondary beforeDispose throw.
4. The corresponding `throw undefined` consumer retains `undefined`; a separate `didThrow` flag proves it was thrown rather than treated as success.

The loader is reused from the author’s real-artifact fixture, and the controls/oracles are independent additions. Authored prototype source is parsed, never evaluated as JavaScript. `probe-four.test.ts`, `probe-four.json` and `probe-four.log` preserve the exact controls and results. The source contains the actual scratch import paths used in this run; a replay must point those imports at a checkout containing the recorded emitter blobs.

## Boundaries

This review supports the reproduced development correction. Physical React/Vue adoption, complete per-target State/Context/request/controlled-input/trust acceptance, public SSR admission and draft activation remain separate. No GitHub review, comment or push was performed. Exact source/log hashes, evidence classifications and file inventory are in `review.json`.
