import os,json,subprocess,hashlib,traceback,datetime,difflib
from pathlib import Path
E=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/integration-20261123-0320')
R=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
D=Path(__file__).resolve().parent
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def save():
 p=D/'status.tmp';p.write_text(json.dumps(S,ensure_ascii=False,indent=2)+'\n');os.replace(p,D/'status.json')
env=dict(os.environ)
env['PATH']=str(R/'tools/node-v24.22.3-linux-x64/bin')+':'+env.get('PATH','')
env['COREPACK_HOME']=str(R/'corepack-cache')
env['ASTRO_TELEMETRY_DISABLED']='1'
env['GIT_OPTIONAL_LOCKS']='0';env['GIT_NO_LAZY_FETCH']='1'
def run(name,argv,timeout=120,allowed=(0,)):
 S['stage']=name;save();beg=now()
 with (D/(name+'.stdout')).open('wb') as out,(D/(name+'.stderr')).open('wb') as err:
  p=subprocess.Popen(argv,cwd=C,env=env,stdout=out,stderr=err);S['child']={'pid':p.pid,'argv':argv};save();expired=False
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   expired=True;p.terminate()
   try:code=p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();code=p.wait()
 S.pop('child',None);S['steps'].append({'name':name,'argv':argv,'started':beg,'finished':now(),'exit':code,'timedOut':expired});save()
 assert not expired and code in allowed,name+' exit='+str(code)
 return (D/(name+'.stdout')).read_text()
def failure(e):
 S['status']='failed';S['error']=repr(e);S['traceback']=traceback.format_exc();S['finished']=now();save()
def source(rel): 
 b=(C/rel).read_bytes();return {'sha256':sha(b),'bytes':len(b)}


C=Path('/var/tmp/proto-ui-s4-scene-c18-20261123-2141')
assert isinstance(str(C),str) and str(C).startswith('/var/tmp/proto-ui-') and str(C)!='undefined' and C.is_dir()
env['TMPDIR']='/var/tmp/proto-ui-s4-scene-c18-temp-20261123-2141'
S={'status':'running','pid':os.getpid(),'started':now(),'checkout':str(C),'head':'c18bf8f8c35a4ec1f69791468a5952c4cb460f41','steps':[],'productApplied':False}
save()
try:
 M=json.loads((E/'current-s1-411a-cssom-getter-matrix-01/status.json').read_text())
 assert M['status']=='matrix-failed' and M.get('finished') and all(not x['result']['survivors'] for x in M['matrix']['steps'])
 assert not Path('/proc/3671059').exists()
 L=json.loads((E/'current-s4-c18-lifecycle-regression-01/status.json').read_text())
 T=json.loads((E/'current-s4-c18-types-fix-01/status.json').read_text());assert T['status']=='passed'
 U=json.loads((E/'current-s4-c18-cleanup-reentry-regression-v2-01/status.json').read_text())
 assert U['status']=='reproduced-52-pass-2-assertion-fail'
 bound={**L['greenSource'],**T['after']}
 test='packages/compiler/test/shader-scene-capability.test.ts'
 bound[test]=U['after']
 assert bound[test]['sha256']=='67ae3d717773c07a6d3d5f443bd24374fa65591a4e3bf547b945392797eaa77f'
 for rel,item in bound.items():assert source(rel)==item,rel
 assert run('head',['git','rev-parse','HEAD']).strip()==S['head']
 assert run('index',['git','diff','--cached','--name-only']).strip()==''
 assert set(run('changed-before',['git','diff','--name-only']).splitlines())==set(bound)
 P=E/'current-s4-c18-cleanup-reentry-product-candidate-01'
 manifest=json.loads((P/'manifest.json').read_text())
 patch=(P/'candidate.patch').read_bytes()
 assert len(patch)==13772 and sha(patch)=='a1d1184791edb4b75a2bbbcb516bc962117cd3337ff4aa033a87b92b44eacb2e'
 assert manifest['sourcePeer']['status']=='passed-for-validation'
 paths=[x['path'] for x in manifest['paths']]
 for item in manifest['paths']:assert source(item['path'])['sha256']==item['beforeSha256']
 (D/'candidate.patch').write_bytes(patch)
 (D/'source-peer.json').write_bytes((P/'manifest.json').read_bytes())
 S['before']=bound;S['patchSha256']=sha(patch);S['sourcePeer']=manifest['sourcePeer'];S['author']=manifest['author']
 S['originalRed']={'directory':str(E/'current-s4-c18-cleanup-reentry-regression-v2-01'),'counts':U['counts'],'testAfter':U['after']}
 for rel in paths:
  dest=D/'before'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((C/rel).read_bytes())
 run('patch-check',['git','apply','--check',str(D/'candidate.patch')])
 run('patch-apply',['git','apply',str(D/'candidate.patch')]);S['productApplied']=True;save()
 for item in manifest['paths']:
  assert source(item['path'])['sha256']==item['afterSha256'],item['path']
 run('normal-format',['node','node_modules/prettier/bin/prettier.cjs','--write',*paths])
 run('normal-format-check',['node','node_modules/prettier/bin/prettier.cjs','--check',*paths])
 run('canonical-shader-generator',['node','scripts/compiler/generate-shader-host.mjs'])
 run('canonical-shader-generator-check',['node','scripts/compiler/generate-shader-host.mjs','--check'])
 run('diff-check',['git','diff','--check'])
 generated='packages/compiler/src/native-shader-host.generated.ts'
 S['after']={rel:source(rel) for rel in bound}
 for rel,item in bound.items():
  if rel not in paths+[generated]:assert source(rel)==item,rel
 for rel in paths+[generated]:
  dest=D/'after'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((C/rel).read_bytes())
 save()
 run('full-54-controls',['node','node_modules/vitest/vitest.mjs','run','--no-file-parallelism','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(D/'vitest.json'),'packages/adapters/base/test/shader-scene-host.test.ts',test],120,(0,1))
 j=json.loads((D/'vitest.json').read_text())
 S['counts']={k:j.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests','success']}
 S['failed']=[{k:a.get(k) for k in ['fullName','failureMessages']} for f in j['testResults'] for a in f['assertionResults'] if a['status']=='failed'];save()
 assert j['success'] and j['numTotalTests']==54 and j['numPassedTests']==54 and j['numFailedTests']==0 and j['numPendingTests']==0 and j.get('numTodoTests',0)==0,'54 controls not all green'
 assert source(test)==bound[test],'54 test bytes changed'
 run('full-workspace-types',['node','node_modules/typescript/bin/tsc','-p','tsconfig.workspace.json','--noEmit'],600)
 S['styleGenerationEvidence']=T['styleGenerationEvidence']
 for rel,item in S['after'].items():assert source(rel)==item,rel
 S['changed']=run('changed',['git','diff','--name-only']).splitlines();assert set(S['changed'])==set(bound)
 S['diffSha256']=sha(run('final-diff',['git','diff','--binary']).encode())
 S['status']='passed-54-and-workspace-types';S['finished']=now();save()
except BaseException as e:failure(e);raise
