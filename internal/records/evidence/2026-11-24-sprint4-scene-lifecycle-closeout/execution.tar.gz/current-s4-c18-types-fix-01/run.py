import os,json,subprocess,hashlib,traceback,datetime,difflib
from pathlib import Path
E=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/integration-20261123-0320')
R=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
D=Path(__file__).resolve().parent
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b): return hashlib.sha256(b).hexdigest()
def save():
 t=D/'status.tmp';t.write_text(json.dumps(S,ensure_ascii=False,indent=2)+'\n');os.replace(t,D/'status.json')
env=dict(os.environ)
env['PATH']=str(R/'tools/node-v24.22.3-linux-x64/bin')+':'+env.get('PATH','')
env['COREPACK_HOME']=str(R/'corepack-cache')
env['ASTRO_TELEMETRY_DISABLED']='1'
env['GIT_OPTIONAL_LOCKS']='0'
env['GIT_NO_LAZY_FETCH']='1'
def run(name,argv,timeout=120,allowed=(0,)):
 S['stage']=name;save();beg=now()
 with (D/(name+'.stdout')).open('wb') as out,(D/(name+'.stderr')).open('wb') as err:
  p=subprocess.Popen(argv,cwd=C,env=env,stdout=out,stderr=err)
  S['child']={'pid':p.pid,'argv':argv};save();expired=False
  try: code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   expired=True;p.terminate()
   try:code=p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();code=p.wait()
 S.pop('child',None);S['steps'].append({'name':name,'argv':argv,'started':beg,'finished':now(),'exit':code,'timedOut':expired});save()
 assert not expired and code in allowed, name+' exit='+str(code)
 return (D/(name+'.stdout')).read_text()

C=Path('/var/tmp/proto-ui-s4-scene-c18-20261123-2141')
assert isinstance(str(C),str) and str(C).startswith('/var/tmp/proto-ui-') and str(C)!='undefined' and C.is_dir()
env['TMPDIR']='/var/tmp/proto-ui-s4-scene-c18-temp-20261123-2141'
S={'status':'running','started':now(),'pid':os.getpid(),'checkout':str(C),'head':'c18bf8f8c35a4ec1f69791468a5952c4cb460f41','steps':[],'sourceMutated':False}
save()
try:
 B=E/'current-s4-c18-types-baseline-02';comparison=json.loads((B/'status.json').read_text())
 assert comparison['status'] not in ['running','failed'] and comparison.get('candidateRestored') is True, comparison.get('status')
 beforeErrors=(B/'baseline-types.stdout').read_bytes();candidateErrors=(B/'candidate-types.stdout').read_bytes()
 assert beforeErrors==candidateErrors and beforeErrors.count(b': error TS')==10
 assert all(next(x for x in comparison['steps'] if x['name']==n)['exit']==2 for n in ['baseline-types','candidate-types'])
 assert all(next(x for x in comparison['steps'] if x['name']==n)['exit']==0 for n in ['baseline-official-style','candidate-official-style'])
 S['baselineEvidence']={'directory':str(B),'statusSha256':sha((B/'status.json').read_bytes()),'errors':10,'identicalDiagnostics':True,'diagnosticsSha256':sha(beforeErrors)}
 L=json.loads((E/'current-s4-c18-lifecycle-regression-01/status.json').read_text())
 for rel,item in L['greenSource'].items(): assert sha((C/rel).read_bytes())==item['sha256'],rel
 assert run('head',['git','rev-parse','HEAD']).strip()==S['head']
 assert run('index',['git','diff','--cached','--name-only']).strip()==''
 S['node']=run('node-version',['node','--version']).strip();assert S['node']=='v24.22.3'
 specs=[
 ('packages/compiler/test/shader-browser-consumer.ts','8d9dd0c494d620b03c1c478014d4400f214d3dc1',[
 ('  let sourceControl: {','  type SourceControl = {'),
 ("  } | null = null;\n  let retiredSource: ReturnType<NonNullable<typeof sourceControl>['state']> | null = null;","  };\n  let sourceControl: SourceControl | null = null;\n  let retiredSource: ReturnType<SourceControl['state']> | null = null;")]),
 ('packages/compiler/test/shader-native.test.ts','b852e6d591eb137137856c162909bf1f345a01f2',[
 (') : ShaderPresentationDeclaration {',') {')]),
 ('packages/modules/feedback/test/shader-presentation.test.ts','5081903f6fa8d562874ec41323a92bfbbdbbee09',[
 ('function declaration(): ShaderPresentationDeclaration {','function declaration() {'),
 ('    fallback: [0, 0, 0, 1],\n  };','    fallback: [0, 0, 0, 1],\n  } satisfies ShaderPresentationDeclaration;'),
 ("    const owned = f.frames.at(-1)!.declaration;\n    expect(owned.source.pixels)","    const owned = f.frames.at(-1)!.declaration;\n    if (owned.source.kind !== 'owned-pixels')\n      throw new Error('Expected the published owned-pixels declaration');\n    expect(owned.source.pixels)")])]
 specs[1]=(specs[1][0],specs[1][1],[
 ("): ShaderPresentationDeclaration {",") {"),
 ('    fallback: [0.1, 0.2, 0.3, 1],\n  };','    fallback: [0.1, 0.2, 0.3, 1],\n  } satisfies ShaderPresentationDeclaration;'),
 ("    pixels[0] = 128;\n    tint[0] = 1;\n    expect(copied.source.pixels)","    pixels[0] = 128;\n    tint[0] = 1;\n    if (copied.source.kind !== 'owned-pixels')\n      throw new Error('Expected the copied owned-pixels declaration');\n    expect(copied.source.pixels)")])
 patches=[];S['before']={}
 for i,(rel,blob,replacements) in enumerate(specs):
  assert run('blob-'+str(i),['git','hash-object','--',rel]).strip()==blob
  raw=(C/rel).read_bytes();text=raw.decode();after=text
  for old,new in replacements:
   assert after.count(old)==1,(rel,'non-unique anchor',old)
   after=after.replace(old,new,1)
  p=D/'before'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
  p=D/'unformatted-after'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(after)
  S['before'][rel]={'gitBlob':blob,'sha256':sha(raw),'bytes':len(raw)}
  patches.append(''.join(difflib.unified_diff(text.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
 patch=''.join(patches);(D/'candidate.patch').write_text(patch);S['patchSha256']=sha(patch.encode())
 (D/'source-peer.json').write_text(json.dumps({'reviewers':['root','remote_native_validation'],'fixedHead':S['head'],'scope':'Three fixture types only; 8 unique anchors, existing assertions retained, no new any or public API casts. Source review is not execution evidence.','before':S['before']},indent=2)+'\n')
 run('apply-check',['git','apply','--check',str(D/'candidate.patch')])
 for rel,item in S['before'].items():assert sha((C/rel).read_bytes())==item['sha256']
 run('apply',['git','apply',str(D/'candidate.patch')]);S['sourceMutated']=True;save()
 paths=[s[0] for s in specs]
 run('normal-format',['node','node_modules/prettier/bin/prettier.cjs','--write',*paths])
 S['after']={}
 for rel in paths:
  b=(C/rel).read_bytes();S['after'][rel]={'sha256':sha(b),'bytes':len(b)}
  p=D/'after'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 run('normal-format-check',['node','node_modules/prettier/bin/prettier.cjs','--check',*paths])
 run('diff-check',['git','diff','--check'])
 (D/'tests').mkdir()
 tests=['packages/compiler/test/shader-native.test.ts','packages/modules/feedback/test/shader-presentation.test.ts']
 run('original-two-tests',['node','node_modules/vitest/vitest.mjs','run','--no-file-parallelism','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(D/'tests/vitest.json'),*tests],120)
 result=json.loads((D/'tests/vitest.json').read_text())
 assert result['success'] and result['numFailedTests']==0 and result['numPendingTests']==0 and result.get('numTodoTests',0)==0
 S['tests']={k:result.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests','success']}
 run('full-workspace-types',['node','node_modules/typescript/bin/tsc','-p','tsconfig.workspace.json','--noEmit'],600)
 S['styleGenerationEvidence']=S['baselineEvidence']
 for rel,item in L['greenSource'].items(): assert sha((C/rel).read_bytes())==item['sha256'],rel
 S['changed']=run('changed',['git','diff','--name-only']).splitlines()
 assert set(S['changed'])==set(L['greenSource'])|set(paths),S['changed']
 S['diffSha256']=sha(run('final-diff',['git','diff','--binary']).encode())
 S['status']='passed';S['finished']=now();save()
except BaseException as e:
 S['status']='failed';S['error']=repr(e);S['traceback']=traceback.format_exc();S['finished']=now();save();raise
