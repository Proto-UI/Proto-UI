import os,json,subprocess,hashlib,traceback,datetime,difflib
from pathlib import Path
E=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/integration-20261123-0320')
R=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
D=Path(__file__).resolve().parent
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def save():
 p=D/'status.tmp';p.write_text(json.dumps(S,ensure_ascii=False,indent=2)+'\n');os.replace(p,D/'status.json')
env=dict(os.environ)
env['PATH']=str(R/'tools/node-v24.22.3-linux-x64/bin')+':'+env.get('PATH','')
env['COREPACK_HOME']=str(R/'corepack-cache')
env['ASTRO_TELEMETRY_DISABLED']='1'
env['GIT_OPTIONAL_LOCKS']='0';env['GIT_NO_LAZY_FETCH']='1'
def run(name,argv,timeout=120,allowed=(0,)):
 S['stage']=name;save();beg=now()
 with (D/(name+'.stdout')).open('wb') as out,(D/(name+'.stderr')).open('wb') as err:
  p=subprocess.Popen(argv,cwd=C,env=env,stdout=out,stderr=err);S['child']={'pid':p.pid,'argv':argv};save();expired=False
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   expired=True;p.terminate()
   try:code=p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();code=p.wait()
 S.pop('child',None);S['steps'].append({'name':name,'argv':argv,'started':beg,'finished':now(),'exit':code,'timedOut':expired});save()
 assert not expired and code in allowed,name+' exit='+str(code)
 return (D/(name+'.stdout')).read_text()
def failure(e):
 S['status']='failed';S['error']=repr(e);S['traceback']=traceback.format_exc();S['finished']=now();save()
def source(rel): 
 b=(C/rel).read_bytes();return {'sha256':sha(b),'bytes':len(b)}

C=Path('/var/tmp/proto-ui-s4-scene-c18-20261123-2141')
assert str(C).startswith('/var/tmp/proto-ui-') and C.is_dir() and str(C)!='undefined'
env['TMPDIR']='/var/tmp/proto-ui-s4-scene-c18-temp-20261123-2141'
S={'status':'running','pid':os.getpid(),'started':now(),'checkout':str(C),'steps':[],'productChanged':False}
save()
try:
 T=json.loads((E/'current-s4-c18-types-fix-01/status.json').read_text());assert T['status']=='passed'
 L=json.loads((E/'current-s4-c18-lifecycle-regression-01/status.json').read_text())
 bound={**L['greenSource'],**T['after']}
 for rel,item in bound.items():assert source(rel)==item,rel
 assert run('head',['git','rev-parse','HEAD']).strip()=='c18bf8f8c35a4ec1f69791468a5952c4cb460f41'
 assert run('index',['git','diff','--cached','--name-only']).strip()==''
 rel='packages/compiler/test/shader-scene-capability.test.ts'
 b=(C/rel).read_bytes();assert sha(b)=='49a1bc138b2abb4f2f33b74d4bef42a1911b843faf02ea20063456d9d36411a5'
 (D/'before.test.ts').write_bytes(b);S['before']=source(rel)
 S['patchSha256']=sha((D/'test-only.patch').read_bytes())
 run('patch-check',['git','apply','--check',str(D/'test-only.patch')])
 run('patch-apply',['git','apply',str(D/'test-only.patch')])
 run('normal-format',['node','node_modules/prettier/bin/prettier.cjs','--write',rel])
 run('diff-check',['git','diff','--check'])
 S['after']=source(rel);(D/'after.test.ts').write_bytes((C/rel).read_bytes());save()
 run('full-54-controls',['node','node_modules/vitest/vitest.mjs','run','--no-file-parallelism','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(D/'vitest.json'),'packages/adapters/base/test/shader-scene-host.test.ts',rel],120,(0,1))
 j=json.loads((D/'vitest.json').read_text());S['counts']={k:j.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests','success']}
 failed=[a for f in j['testResults'] for a in f['assertionResults'] if a['status']=='failed']
 S['failed']=[{k:a.get(k) for k in ['fullName','title','failureMessages']} for a in failed]
 assert j['numTotalTests']==54 and j['numPendingTests']==0 and j.get('numTodoTests',0)==0
 if j['numPassedTests']==52 and len(failed)==2 and all(a['title'].endswith('physical fallback cleanup reentry cannot overwrite the current scene paint') for a in failed):
  S['status']='reproduced-52-pass-2-assertion-fail'
 elif j['numPassedTests']==54 and not failed:S['status']='not-reproduced-54-pass'
 else:raise AssertionError('Unexpected failure set; do not alter oracle or deadlines')
 for rel,item in bound.items():
  if rel!='packages/compiler/test/shader-scene-capability.test.ts':assert source(rel)==item,rel
 S['finished']=now();save()
except BaseException as e:failure(e);raise
