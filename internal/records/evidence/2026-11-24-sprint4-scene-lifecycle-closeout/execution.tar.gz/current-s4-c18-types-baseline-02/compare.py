import pathlib,subprocess,os,json,datetime,hashlib,traceback,re
C=pathlib.Path('/var/tmp/proto-ui-s4-scene-c18-20261123-2141');E=pathlib.Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/integration-20261123-0320');D=pathlib.Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/integration-20261123-0320/current-s4-c18-types-baseline-02')
S=json.loads((E/'current-s4-c18-lifecycle-regression-01/status.json').read_text())
assert S['green']['passed']==52 and S['red']['failed']==4 and S['stage']=='workspace-types'
paths=S['changed'];assert len(paths)==6
env=os.environ.copy();env['PATH']=str(E.parents[1]/'tools/node-v24.22.3-linux-x64/bin')+os.pathsep+env.get('PATH','')
env['COREPACK_HOME']=str(E.parents[1]/'corepack-cache');env['TMPDIR']='/var/tmp/proto-ui-s4-scene-c18-temp-20261123-2141'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
state={'status':'running','started':now(),'pid':os.getpid(),'head':S['head'],'checkout':str(C),'steps':[],'candidateRestored':False,'meaning':'Compare the unchanged full workspace type command on exact clean c18 and the saved six-file lifecycle candidate after the official style-generation prerequisite. Original failed attempts are retained.'}
def save():
 p=D/'status.tmp';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(D/'status.json')
def run(name,args,budget=900,allowed=(0,)):
 state['stage']=name;save();start=now()
 with (D/(name+'.stdout')).open('xb') as so,(D/(name+'.stderr')).open('xb') as se:
  p=subprocess.Popen(args,cwd=C,env=env,stdout=so,stderr=se);state['child']={'pid':p.pid,'argv':args};save()
  try:rc=p.wait(timeout=budget)
  except subprocess.TimeoutExpired:
   p.terminate()
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();p.wait()
   state['steps'].append({'name':name,'exit':p.returncode,'timedOut':True,'started':start,'finished':now()});save();raise
 state.pop('child',None);state['steps'].append({'name':name,'argv':args,'exit':rc,'timedOut':False,'started':start,'finished':now()});save()
 if rc not in allowed:raise RuntimeError(name+' exit '+str(rc))
 return rc,(D/(name+'.stdout')).read_text()
def guards(facts):
 for rel,row in facts.items():assert sha((C/rel).read_bytes())==row['sha256'],rel
def diagnostics(text):
 return [m.group(0) for m in re.finditer(r'^[^\n]+\(\d+,\d+\): error TS\d+:[^\n]*(?:\n  [^\n]+)*',text,re.M)]
reverted=False
try:
 guards(S['greenSource'])
 assert run('head',['git','rev-parse','HEAD'],30)[1].strip()==S['head']
 assert not run('index',['git','diff','--cached','--name-only'],30)[1].strip()
 for rel in paths:
  b=(C/rel).read_bytes();p=D/'candidate'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 _,diff=run('candidate-diff',['git','diff','--binary','--',*paths],30)
 patch=D/'candidate.patch';patch.write_text(diff);state['patchSha256']=sha(patch.read_bytes())
 run('reverse-check',['git','apply','-R','--check',str(patch)],30)
 run('reverse-candidate',['git','apply','-R',str(patch)],30);reverted=True
 assert not run('baseline-clean',['git','status','--porcelain=v1','--untracked-files=all'],600)[1].strip()
 for rel in paths:
  expected=(E/'current-s4-c18-lifecycle-regression-01/before'/rel).read_bytes()
  assert (C/rel).read_bytes()==expected,rel
 run('baseline-official-style',['corepack','pnpm@10.32.1','--filter','apps-www','generate:proto-ui-style'])
 code,text=run('baseline-types',['node','node_modules/typescript/bin/tsc','-p','tsconfig.workspace.json','--noEmit'],900,(0,2))
 state['baseline']={'exit':code,'diagnostics':diagnostics(text),'stdoutSha256':sha(text.encode())};save()
 run('restore-check',['git','apply','--check',str(patch)],30)
 run('restore-candidate',['git','apply',str(patch)],30);reverted=False
 guards(S['greenSource']);state['candidateRestored']=True;save()
 run('candidate-official-style',['corepack','pnpm@10.32.1','--filter','apps-www','generate:proto-ui-style'])
 code,text=run('candidate-types',['node','node_modules/typescript/bin/tsc','-p','tsconfig.workspace.json','--noEmit'],900,(0,2))
 state['candidate']={'exit':code,'diagnostics':diagnostics(text),'stdoutSha256':sha(text.encode())}
 guards(S['greenSource'])
 state['candidateOnlyDiagnostics']=[d for d in state['candidate']['diagnostics'] if d not in state['baseline']['diagnostics']]
 state['baselineOnlyDiagnostics']=[d for d in state['baseline']['diagnostics'] if d not in state['candidate']['diagnostics']]
 state['status']='completed-comparison-not-passing' if state['candidate']['exit'] else 'candidate-types-passed'
except BaseException as e:state['status']='failed';state['error']=repr(e);state['traceback']=traceback.format_exc()
finally:
 if reverted:
  try:
   for rel in paths:
    expected=(E/'current-s4-c18-lifecycle-regression-01/before'/rel).read_bytes();assert (C/rel).read_bytes()==expected,rel
   run('finally-restore-check',['git','apply','--check',str(D/'candidate.patch')],30)
   run('finally-restore',['git','apply',str(D/'candidate.patch')],30)
   guards(S['greenSource']);state['candidateRestored']=True
  except BaseException as e:state['restoreError']=repr(e)
 state['finished']=now();save()
