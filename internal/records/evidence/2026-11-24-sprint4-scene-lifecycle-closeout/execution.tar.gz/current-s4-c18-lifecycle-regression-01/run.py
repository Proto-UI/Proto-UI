import pathlib,os,json,datetime,subprocess,hashlib,traceback,difflib
C=pathlib.Path('/var/tmp/proto-ui-s4-scene-c18-20261123-2141');E=pathlib.Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/integration-20261123-0320');D=pathlib.Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/integration-20261123-0320/current-s4-c18-lifecycle-regression-01')
R=pathlib.Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
HEAD='c18bf8f8c35a4ec1f69791468a5952c4cb460f41'
ROOT_TEST="  it(`${kind}: recovery from a failed scene factory retires its fallback paint before publication`, () => {\n    let attempts = 0;\n    let active: ReturnType<typeof owner>;\n    active = owner(kind, {\n      createScenePresenter(options) {\n        if (++attempts === 1) throw new Error('temporary scene factory failure');\n        const physical = createWebShaderPresenter(options);\n        const recovered: WebShaderScenePresenter = {\n          commit(frame, _program, prepare) {\n            expect(active.root.style.backgroundImage).toBe(original);\n            physical.commit(frame, null, prepare);\n          },\n          release: (view) => physical.release(view),\n          dispose: () => physical.dispose(),\n          diagnostics: () => physical.diagnostics(),\n        };\n        return recovered;\n      },\n    });\n    active.root.style.backgroundImage = 'linear-gradient(red, blue)';\n    const original = active.root.style.backgroundImage;\n    try {\n      active.start();\n      expect(active.root.style.backgroundImage).toBe('none');\n      active.refresh();\n      expect(attempts).toBe(2);\n      expect(active.root.style.backgroundImage).toBe('none');\n    } finally {\n      active.dispose();\n    }\n    expect(active.root.style.backgroundImage).toBe(original);\n  });\n"
ROOT_ANCHOR="  it(`${kind}: an unselected owner never calls the source capability factory`, () => {"
RUNTIME_NEW="          // Retire an earlier factory-failure fallback before the scene prepares.\n          if (acquired) {\n            const fallback = presenter;\n            presenter = createWebShaderPresenter(capabilities);\n            for (const reason of fallback.diagnostics()) reasons.add(reason);\n            fallback.dispose();\n            if (operation !== turn) {\n              retireScene(acquired);\n              return;\n            }\n          }\n          scene = acquired;"
NATIVE_NEW="        if (acquired) {\n          const fallback = presenter;\n          presenter = createWebShaderPresenter({root:options.root, prepare:options.prepare});\n          fallback.dispose();\n          if (disposed || !mounted || turn !== operation || declaration !== selected || !options.alive()) { acquired.dispose(); return; }\n        }\n        scene = acquired;"
NATIVE_DECLARATION="  ${scenes ? 'let' : 'const'} presenter = createWebShaderPresenter({root:options.root, prepare:options.prepare});"
env=os.environ.copy();env['PATH']=str(R/'tools/node-v24.22.3-linux-x64/bin')+os.pathsep+env.get('PATH','');env['COREPACK_HOME']=str(R/'corepack-cache');env['TMPDIR']='/var/tmp/proto-ui-s4-scene-c18-temp-20261123-2141'
host='packages/adapters/base/src/material/shader-scene-host.ts'
hosttest='packages/adapters/base/test/shader-scene-host.test.ts'
sink='packages/adapters/base/src/material/shader-webgl2.ts'
native='packages/compiler/src/native-shader.ts'
cap='packages/compiler/test/shader-scene-capability.test.ts'
generated='packages/compiler/src/native-shader-host.generated.ts'
tests=[hosttest,cap];products=[host,sink,native]
expected={host:'ddd4bf1e5b49e7fae03768f0c009fbcff67011ff637ef24cc0158adc8d82945b',hosttest:'09829d8a56c3ad29142cb4fabcb814c063eb6560579493df5f8ed7f9fb3f4857',sink:'fd2b2b31aa2cb6f19451b9666d176a91e40fb6c418f4527c593da1b6140d1024',native:'c311d0386519b84924746d8c500700069aa16a1ffff1af648e2a4ff4e02ae39c',cap:'ef6caa8bff2f368ee6e0f08e348f2fecb557aa5fa60ea6713219765f25509fc2'}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
state={'status':'running','started':now(),'pid':os.getpid(),'head':HEAD,'checkout':str(C),'steps':[],'scope':'Four reviewed lifecycle regressions: two root-getter reentry cases and runtime/generated factory-recovery handoff. Preserve original 48 tests, original default Vitest case deadlines, canonical generator and c18 numeric transaction. This is local bounded evidence, not hosted or full acceptance.','executionMode':'human-assisted','modeSource':'current-user'}
def save():
 p=D/'status.tmp';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(D/'status.json')
def run(name,args,budget=120,allowed=(0,),extra=None):
 state['stage']=name;save();start=now();ev=env|dict(extra or {})
 with (D/(name+'.stdout')).open('xb') as so,(D/(name+'.stderr')).open('xb') as se:
  p=subprocess.Popen(args,cwd=C,env=ev,stdout=so,stderr=se)
  state['child']={'pid':p.pid,'argv':args,'budgetSeconds':budget};save()
  try:rc=p.wait(timeout=budget)
  except subprocess.TimeoutExpired:
   p.terminate()
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();p.wait()
   state['steps'].append({'name':name,'argv':args,'started':start,'finished':now(),'timedOut':True,'exit':p.returncode});save();raise
 state['steps'].append({'name':name,'argv':args,'started':start,'finished':now(),'timedOut':False,'exit':rc});state.pop('child',None);save()
 if rc not in allowed:raise RuntimeError(name+' exit '+str(rc))
 return rc,(D/(name+'.stdout')).read_text()
def guard(mapping):
 facts={}
 for p,h in mapping.items():
  b=(C/p).read_bytes();actual=sha(b);assert actual==h,(p,h,actual);facts[p]={'sha256':actual,'bytes':len(b)}
 return facts
def snap(paths,folder):
 facts={}
 for rel in paths:
  b=(C/rel).read_bytes();f=D/folder/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b);facts[rel]={'sha256':sha(b),'bytes':len(b)}
 return facts
def patch(name,rel,before,after):
 assert before!=after;txt=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 p=D/name;p.write_text(txt);return p
def apply(name,p):
 run(name+'-check',['git','apply','--check',str(p)],30);run(name,['git','apply',str(p)],30)
def parse_report(name):
 p=D/name/'vitest.json';b=p.read_bytes();j=json.loads(b);rows=[r for f in j.get('testResults',[]) for r in f.get('assertionResults',[])]
 out={'sha256':sha(b),'bytes':len(b),'total':j.get('numTotalTests'),'passed':j.get('numPassedTests'),'failed':j.get('numFailedTests'),'pending':j.get('numPendingTests'),'todo':j.get('numTodoTests'),'rows':len(rows),'failures':[{'name':r.get('fullName') or r.get('title'),'title':r.get('title'),'status':r.get('status'),'failureMessages':r.get('failureMessages')} for r in rows if r.get('status')=='failed']}
 (D/name/'summary.json').write_text(json.dumps(out,indent=2)+'\n');return out,rows
try:
 setup=json.loads((E/'current-s4-c18-setup-01/status.json').read_text());assert setup['status']=='prepared' and setup['head']==HEAD
 assert run('head',['git','rev-parse','HEAD'],30)[1].strip()==HEAD
 assert not run('clean-before',['git','status','--porcelain=v1','--untracked-files=all'],600)[1].strip()
 state['before']=guard(expected);state['originalGenerated']=sha((C/generated).read_bytes());state['lockBefore']=sha((C/'pnpm-lock.yaml').read_bytes())
 snap(list(expected)+[generated],'before')
 PD=E/'current-s4-c18-scene-host-candidates-01'
 for fn,n,h in [('test-only.patch',3800,'ca744d60096f36d72968d9956febacffccc3b6691b0f66a26e86697041968ddb'),('product.patch',968,'4d808a82d76bc41c70865e7cdb23a8221e2a04ca4a59e3876a2caf6d6d99f4fe')]:
  b=(PD/fn).read_bytes();assert len(b)==n and sha(b)==h
  (D/fn).write_bytes(b)
 old=(C/cap).read_text();assert old.count(ROOT_ANCHOR)==1
 changed=old.replace(ROOT_ANCHOR,ROOT_TEST+ROOT_ANCHOR)
 rootPatch=patch('capability-tests.patch',cap,old,changed)
 # Normal apply of tests only. Product bytes remain exact c18 through the red run.
 apply('host-tests',D/'test-only.patch');assert sha((C/hosttest).read_bytes())=='aca888dd01c60dfb5babee768d3a680c7af33643ba40b0c7fbb3820902e2f37f'
 apply('capability-tests',rootPatch)
 run('tests-normal-format',['node','node_modules/prettier/bin/prettier.cjs','--write',*tests],60)
 state['redSource']=snap(list(expected)+[generated],'red-source')
 guard({p:expected[p] for p in products});assert sha((C/generated).read_bytes())==state['originalGenerated']
 run('diff-check-tests',['git','diff','--check'],30)
 (D/'red').mkdir()
 redcmd=['node','node_modules/vitest/vitest.mjs','run',*tests,'--no-file-parallelism','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(D/'red/vitest.json')]
 code,_=run('red',redcmd,120,(0,1))
 red,rows=parse_report('red');state['red']=red;save()
 expectedFailures={
 'does not install source observers after root lookup retires the presenter',
 'does not let a root lookup replace the current source publication with retired work',
 'runtime: recovery from a failed scene factory retires its fallback paint before publication',
 'generated: recovery from a failed scene factory retires its fallback paint before publication'}
 actual={r.get('title') for r in rows if r.get('status')=='failed'}
 assert code==1 and red['total']==52 and red['rows']==52 and red['passed']==48 and red['failed']==4 and red['pending']==0 and red.get('todo',0) in (None,0) and actual==expectedFailures,red
 assert all(r.get('failureMessages') and any('AssertionError' in m for m in r['failureMessages']) for r in rows if r.get('status')=='failed'),red
 guard({p:state['redSource'][p]['sha256'] for p in state['redSource']})
 state['redGate']='Exactly all original 48 passed and the four new reviewed assertions failed; no pending or setup failure. Product mutation may now proceed.';save()
 # Prepare root product changes from the verified original bytes, then normal apply.
 old=(C/sink).read_text();anchor='          scene = acquired;';assert old.count(anchor)==1
 after=old.replace(anchor,RUNTIME_NEW);assert sha(after.encode())=='83012823a6ca837cd480766a87b3b2f06dd8926ff9b8b8207c58e742ee2fad94'
 sinkPatch=patch('runtime-factory-recovery.patch',sink,old,after)
 old=(C/native).read_text();decl='  const presenter = createWebShaderPresenter({root:options.root, prepare:options.prepare});';anchor='        scene = acquired;'
 assert old.count(decl)==1 and old.count(anchor)==1
 after=old.replace(decl,NATIVE_DECLARATION).replace(anchor,NATIVE_NEW)
 assert sha(after.encode())=='9129169f126408d467b590546a4c0b130dd71817452c9e1ee4a751ed86c980cc'
 nativePatch=patch('generated-factory-recovery.patch',native,old,after)
 apply('host-product',D/'product.patch');assert sha((C/host).read_bytes())=='606d26b36dedf9c0a44762c3f72b7a852e697b267505b4d14e3ab24caddc5047'
 apply('runtime-factory-recovery',sinkPatch);apply('generated-factory-recovery',nativePatch)
 run('product-normal-format',['node','node_modules/prettier/bin/prettier.cjs','--write',*products],60)
 run('canonical-generator',['node','scripts/compiler/generate-shader-host.mjs'],120)
 run('canonical-generator-check',['node','scripts/compiler/generate-shader-host.mjs','--check'],120)
 run('all-normal-format-check',['node','node_modules/prettier/bin/prettier.cjs','--check',*products,*tests,generated],60)
 run('diff-check-final',['git','diff','--check'],30)
 state['greenSource']=snap(list(expected)+[generated],'green-source')
 (D/'green').mkdir();greencmd=redcmd.copy();greencmd[-1]='--outputFile='+str(D/'green/vitest.json')
 run('green',greencmd,120)
 green,rows=parse_report('green');state['green']=green;save()
 assert green['total']==52 and green['rows']==52 and green['passed']==52 and green['failed']==0 and green['pending']==0 and green.get('todo',0) in (None,0),green
 guard({p:state['greenSource'][p]['sha256'] for p in state['greenSource']})
 assert sha((C/'pnpm-lock.yaml').read_bytes())==state['lockBefore']
 names=run('final-changed',['git','diff','--name-only'],60)[1].splitlines()
 assert set(names)==set(products+tests+[generated]),names
 state['changed']=names
 # Existing workspace semantic type configuration; no custom exclusions or heap override.
 run('workspace-types',['node','node_modules/typescript/bin/tsc','-p','tsconfig.workspace.json','--noEmit'],900)
 guard({p:state['greenSource'][p]['sha256'] for p in state['greenSource']})
 state['status']='passed'
except BaseException as e:
 state['status']='failed';state['error']=repr(e);state['traceback']=traceback.format_exc()
finally:state['finished']=now();save()
