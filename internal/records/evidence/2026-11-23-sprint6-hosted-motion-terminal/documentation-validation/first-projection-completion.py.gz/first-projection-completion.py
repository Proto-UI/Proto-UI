from pathlib import Path
import datetime, fcntl, hashlib, json, os, subprocess, time, traceback

root = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
ops = Path(str(root) + '-ops/final-23122/union-ee2379')
out = ops / 'dce-evidence-projection'
out.mkdir(exist_ok=True)
status = out / 'status.json'
lock = (out / 'worker.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not status.exists(), 'Reconcile this first-time projection completion before another launch.'
env = dict(os.environ, TMPDIR='/var/tmp/s6-75d5-modal', GIT_OPTIONAL_LOCKS='0')
env['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:' + env['PATH']
state = {'phase': 'starting', 'pid': os.getpid(), 'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'scope': 'Only previously unexecuted projection generation/check and review-rule route; no Agent controls rerun.', 'runs': []}

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def read(p):
    return json.loads(p.read_text())

def save():
    t = status.with_suffix('.tmp'); t.write_text(json.dumps(state, indent=2) + '\n'); os.replace(t, status)

def git(*args):
    return subprocess.check_output(['git', '-c', 'core.fsmonitor=false', '-c', 'submodule.recurse=false', *args], cwd=root, env=env, text=True, timeout=120).strip()

def run(args, name, seconds=300):
    state['phase'] = name; save(); log = out / (name + '.log'); started = time.monotonic()
    with log.open('x') as stream:
        p = subprocess.Popen(args, cwd=root, env=env, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        state['childPid'] = p.pid; save()
        try:
            code = p.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            state['pendingChild'] = {'pid': p.pid, 'name': name, 'seconds': seconds}; save(); raise
    state.pop('childPid', None)
    state['runs'].append({'name': name, 'command': args, 'exit': code, 'seconds': round(time.monotonic() - started, 3), 'logSha256': sha(log)})
    save(); assert code == 0, name

try:
    save()
    previous = read(ops / 'dce-evidence-validation/status.json')
    reconciliation = read(ops / 'dce-evidence-validation/child-reconciliation-r1.json')
    assert previous['phase'] == 'pending-child' and previous['pendingChild']['seconds'] == 900
    assert reconciliation['processes'] == [] and reconciliation['rootPsExit'] == 1
    for pid in (3494356, 3494794):
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            pass
        else:
            raise AssertionError('Previously owned PID still exists; reconcile first.')
    assert sha(ops / 'dce-evidence-validation/status.json') == reconciliation['statusSha256']
    assert sha(ops / 'dce-evidence-validation/agent-operations.log') == reconciliation['logSha256']
    prep = read(ops / 'dce-evidence-archive/status.json')
    assert git('rev-parse', 'HEAD') == prep['head'] and git('write-tree') == prep['tree']
    assert not git('diff', '--name-only')
    closure = read(ops / 'dce-ci-terminal/source-closure-readback.json')
    def verify():
        assert sha(root / prep['record']) == prep['recordSha256'] and sha(root / prep['manifest']) == prep['manifestSha256']
        for group in closure['maps']:
            for item in group['files']:
                assert sha(root / item['path']) == item['expectedSha256']
    verify()
    run(['corepack', 'pnpm@10.32.1', 'spec:docs:agent'], 'agent-projection-generate')
    run(['corepack', 'pnpm@10.32.1', 'check:agent-doc'], 'agent-projection-check')
    run(['corepack', 'pnpm@10.32.1', 'agent:skill', '--', 'pui-review', '--mode', 'human-assisted', '--mode-source', 'current-user'], 'review-rule-route')
    verify()
    assert git('rev-parse', 'HEAD') == prep['head'] and git('write-tree') == prep['tree']
    assert not git('diff', '--name-only') and not git('ls-files', '--others', '--exclude-standard')
    state.update(phase='completed', sourceStable=True, tree=prep['tree'], head=prep['head'],
                 previousControlLimitation={'outerResult': 'timeout', 'outerSeconds': 900, 'shellExitCode': None,
                                            'lateNodeReport': {'tests': 1549, 'pass': 1549, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0, 'durationMs': 900635.67921},
                                            'originalsUnchanged': True, 'rerun': False},
                 finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
except BaseException as exc:
    state.update(phase='pending-child' if 'pendingChild' in state else 'failed', error=repr(exc), traceback=traceback.format_exc())
save()
