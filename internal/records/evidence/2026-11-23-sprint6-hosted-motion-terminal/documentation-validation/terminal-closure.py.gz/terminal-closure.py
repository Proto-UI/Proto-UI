from pathlib import Path
import copy, datetime, fcntl, gzip, hashlib, json, os, subprocess, time, traceback

ROOT = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
OPS = Path(str(ROOT) + '-ops/final-23122/union-ee2379')
PREVIOUS = OPS / 'dce-evidence-validation-closure'
OUT = OPS / 'dce-evidence-final-validation'
OUT.mkdir(exist_ok=True)
STATUS = OUT / 'status.json'
lock = (OUT / 'worker.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not STATUS.exists(), 'Reconcile the existing terminal closure before another writer.'
HEAD = 'dce198cb7ba6361da8a7bb50972463d92a792ec2'
env = dict(os.environ, TMPDIR='/var/tmp/s6-75d5-modal', GIT_OPTIONAL_LOCKS='0')
env['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:' + env['PATH']
state = {'phase': 'starting', 'pid': os.getpid(), 'head': HEAD, 'runs': [],
         'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'scope': 'Preserve rejected formal review route and return honest terminal partial validation; no review verdict or test rerun.'}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def file_sha(path):
    return sha(path.read_bytes())

def read(path):
    return json.loads(path.read_text())

def write(path, value):
    assert not path.exists()
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def save():
    temporary = STATUS.with_suffix('.tmp')
    temporary.write_text(json.dumps(state, indent=2) + '\n')
    os.replace(temporary, STATUS)

def git(*args):
    return subprocess.check_output(['git', '-c', 'core.fsmonitor=false', '-c', 'submodule.recurse=false', *args], cwd=ROOT, env=env, text=True, timeout=120).strip()

def run(args, name, limit=300):
    state['phase'] = name
    save()
    output = OUT / (name + '.log')
    start = time.monotonic()
    with output.open('x') as stream:
        child = subprocess.Popen(args, cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        state['childPid'] = child.pid
        save()
        try:
            code = child.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            state['pendingChild'] = {'pid': child.pid, 'name': name, 'seconds': limit}
            save()
            raise
    state.pop('childPid', None)
    state['runs'].append({'name': name, 'command': args, 'exit': code, 'seconds': round(time.monotonic() - start, 3), 'logSha256': file_sha(output)})
    save()
    assert code == 0, name
    return output

def route(path):
    text = path.read_text()
    return json.loads(text[text.index('{'):])

try:
    save()
    before = read(PREVIOUS / 'status.json')
    assert before['phase'] == 'failed' and before['error'] == "AssertionError('partial-review-route')"
    assert file_sha(PREVIOUS / 'status.json') == '1039cc520ac991a62499b6564b1e6d8988613597806ae99239aec6344fa0f4bc'
    assert before['runs'][-1]['exit'] == 1 and all(item['exit'] == 0 for item in before['runs'][:-1])
    denied = PREVIOUS / 'partial-review-route.log'
    assert file_sha(denied) == before['runs'][-1]['logSha256']
    assert 'handoff lacks artifact required by pui-review: review-input' in denied.read_text()
    try:
        os.kill(before['pid'], 0)
    except ProcessLookupError:
        pass
    else:
        raise AssertionError('Prior closure process still exists; reconcile.')
    assert not (OPS / 'dce-evidence-publication/status.json').exists()
    candidate_before = read(PREVIOUS / 'candidate-change.json')
    assert git('rev-parse', 'HEAD') == HEAD and git('write-tree') == candidate_before['tree'] == '69d420d140d51e37e98774c9fec2213a0f89f834'
    assert not git('diff', '--name-only') and not git('ls-files', '--others', '--exclude-standard')
    record = ROOT / candidate_before['record']
    manifest_path = ROOT / candidate_before['manifest']
    assert file_sha(record) == '17383c2a7510065b55523fd581df909d128592882575bf1d41c95820938545fd'
    assert file_sha(manifest_path) == '56a813dc11300bfd1703f595eb6124f14e210a2cb2fab4e88cb330e4f8a78a88'
    manifest = read(manifest_path)
    evidence = manifest_path.parent
    earlier_artifacts = copy.deepcopy(manifest['artifacts'])
    assert len(earlier_artifacts) == 44
    closure = read(OPS / 'dce-ci-terminal/source-closure-readback.json')
    reconciliation = read(OPS / 'dce-evidence-validation/child-reconciliation-r1.json')

    def verify():
        for group in closure['maps']:
            for item in group['files']:
                assert file_sha(ROOT / item['path']) == item['expectedSha256']
        for item in manifest['preservedExistingCustody']:
            assert file_sha(ROOT / item['path']) == item['sha256']
        for item in manifest['artifacts']:
            stored = (evidence / item['file']).read_bytes()
            raw = stored if item['encoding'] == 'identity' else gzip.decompress(stored)
            assert len(stored) == item['storedBytes'] and sha(stored) == item['storedSha256']
            assert len(raw) == item['rawBytes'] and sha(raw) == item['rawSha256']
        assert file_sha(OPS / 'dce-evidence-validation/status.json') == reconciliation['statusSha256']
        assert file_sha(OPS / 'dce-evidence-validation/agent-operations.log') == reconciliation['logSha256']

    verify()
    def archive(path, name):
        raw = path.read_bytes()
        stored = gzip.compress(raw, mtime=0)
        relative = 'documentation-validation/' + name + '.gz'
        target = evidence / relative
        assert not target.exists()
        target.write_bytes(stored)
        manifest['artifacts'].append({'file': relative, 'source': str(path), 'rawBytes': len(raw), 'rawSha256': sha(raw),
                                      'storedBytes': len(stored), 'storedSha256': sha(stored), 'encoding': 'gzip'})
    archive(PREVIOUS / 'status.json', 'formal-review-route-rejected-status.json')
    archive(denied, 'formal-review-route-rejected.log')
    archive(PREVIOUS / 'validation-handoff.json', 'formal-review-route-rejected-handoff.json')
    archive(PREVIOUS / 'evidence-report.json', 'partial-validation-before-terminal-route.json')
    archive(Path(__file__), 'terminal-closure.py')
    review_boundary = {
        'attemptedTransition': 'pui-validate -> pui-review', 'result': 'rejected', 'exit': 1,
        'reason': 'handoff lacks artifact required by pui-review: review-input', 'logSha256': file_sha(denied),
        'disposition': 'No independent review input, approval packet or GitHub review was manufactured. Validation returns a terminal partial handoff with nextSkillId null; ordinary evidence publication remains separately authorized.',
    }
    manifest['documentationValidation']['formalReviewBoundary'] = review_boundary
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    original_text = record.read_text()
    table_lines = original_text.splitlines()
    route_rows = [index for index, line in enumerate(table_lines) if line.startswith('| Review-rule routing')]
    assert len(route_rows) == 1
    row = route_rows[0]
    table_lines[row] = table_lines[row].replace('Review-rule routing', 'Initial review-rule loading', 1)
    table_lines.insert(row + 1, '| Formal validation-to-review handoff | Exit 1: missing canonical `review-input` | Review was not entered; terminal partial handoff follows |')
    original_text = '\n'.join(table_lines) + '\n'
    anchor = '## Evidence-only successor and follow-up\n'
    assert original_text.count(anchor) == 1
    paragraph = 'A later attempt to route the partial validation directly into formal independent review was rejected with exit 1 because the handoff had no canonical `review-input`. The original rejection, input handoff and partial report are retained. No review input, approval or successful review transition is invented. This documentation task instead returns an honest terminal partial validation handoff with no next skill. That terminal handoff does not satisfy or bypass formal review or integration requirements; the ordinary evidence commit and owned-branch push use their separately existing authorization.\n\n'
    record.write_text(original_text.replace(anchor, paragraph + anchor, 1))
    run(['corepack', 'pnpm@10.32.1', 'exec', 'prettier', '--write', candidate_before['record'], candidate_before['manifest']], 'final-format')
    run(['corepack', 'pnpm@10.32.1', 'exec', 'prettier', '--check', candidate_before['record'], candidate_before['manifest']], 'final-format-check')
    run(['corepack', 'pnpm@10.32.1', 'check:public-docs'], 'final-public-and-repository-docs')
    manifest = read(manifest_path)
    assert manifest['artifacts'][:44] == earlier_artifacts
    verify()
    run(['git', 'add', '--', candidate_before['record'], str(evidence.relative_to(ROOT))], 'stage-terminal-evidence')
    paths = git('diff', '--cached', '--name-only', HEAD).splitlines()
    assert paths and all(p == candidate_before['record'] or p.startswith(str(evidence.relative_to(ROOT)) + '/') for p in paths)
    assert set(git('diff', '--cached', '--name-status', HEAD).splitlines()) == {'A\t' + p for p in paths}
    assert not git('diff', '--name-only') and not git('ls-files', '--others', '--exclude-standard')
    run(['git', 'diff', '--cached', '--check'], 'final-whitespace-check')
    tree = git('write-tree')
    candidate = copy.deepcopy(candidate_before)
    candidate.update(tree=tree, paths=paths, priorCandidateTree=candidate_before['tree'])
    write(OUT / 'candidate-change.json', candidate)
    handoff = read(PREVIOUS / 'docs-handoff.json')
    entry = next(item for item in handoff['artifacts'] if item['type'] == 'candidate-change')
    entry.update(reference=str(OUT / 'candidate-change.json'), digest='sha256:' + file_sha(OUT / 'candidate-change.json'), revision=HEAD)
    handoff['notes'] = ['Final evidence amendment retains the rejected formal review transition and all original failures; no source change, control rerun or review verdict.']
    write(OUT / 'docs-handoff.json', handoff)
    resolved = route(run(['corepack', 'pnpm@10.32.1', 'agent:skill', '--', '--handoff', str(OUT / 'docs-handoff.json')], 'final-validation-intake'))
    assert not resolved['blocked']
    report = read(PREVIOUS / 'evidence-report.json')
    report.update(preparedTree=tree, result='partial', documentationValidation=manifest['documentationValidation'],
                  commands=copy.deepcopy(state['runs']), originalsVerified=len(manifest['artifacts']),
                  originalDocumentationPreparationTree='727f6a3cdd2b24e8f8694fd950f82852fac27246',
                  formalReviewBoundary=review_boundary)
    write(OUT / 'evidence-report.json', report)
    terminal = copy.deepcopy(handoff)
    terminal.update(fromId='pui-validate', nextSkillId=None,
                    notes=['Terminal partial validation only. Original 900-second timeout and unknown shell exit remain verification debt; late 1549/1549 Node controls are separate. Formal review was not admitted because canonical review-input is absent. No approval, successful review route, integration or repeated testing is claimed.'])
    terminal['artifacts'].append({'type': 'evidence-report', 'reference': str(OUT / 'evidence-report.json'),
                                  'digest': 'sha256:' + file_sha(OUT / 'evidence-report.json'), 'revision': HEAD, 'result': 'partial'})
    write(OUT / 'terminal-validation-handoff.json', terminal)
    terminal_route = route(run(['corepack', 'pnpm@10.32.1', 'agent:skill', '--', '--handoff', str(OUT / 'terminal-validation-handoff.json'),
                                '--prior-handoff', str(OUT / 'docs-handoff.json')], 'terminal-partial-route'))
    assert terminal_route['terminal'] and not terminal_route['blocked']
    verify()
    assert git('rev-parse', 'HEAD') == HEAD and git('write-tree') == tree
    assert not git('diff', '--name-only') and not git('ls-files', '--others', '--exclude-standard')
    old_prep = read(OPS / 'dce-evidence-archive/status.json')
    (OUT / 'record-manifest-increment.patch').write_bytes(subprocess.check_output(['git', 'diff', old_prep['tree'], tree, '--', candidate['record'], candidate['manifest']], cwd=ROOT, env=env, timeout=120))
    state.update(phase='prepared-with-validation-limitation', result='partial', sourceStable=True, tree=tree,
                 record=candidate['record'], manifest=candidate['manifest'], addedPaths=paths,
                 recordSha256=file_sha(record), manifestSha256=file_sha(manifest_path),
                 artifacts=len(manifest['artifacts']), rawBytes=sum(item['rawBytes'] for item in manifest['artifacts']),
                 storedBytes=sum(item['storedBytes'] for item in manifest['artifacts']), preservedHostedArtifacts=23,
                 preservedCustodyPaths=len(manifest['preservedExistingCustody']),
                 sourceClosureCounts=[group['count'] for group in closure['maps']],
                 evidenceReportSha256=file_sha(OUT / 'evidence-report.json'),
                 terminalPartialRouteSha256=file_sha(OUT / 'terminal-partial-route.log'),
                 incrementPatchSha256=file_sha(OUT / 'record-manifest-increment.patch'),
                 previousControlLimitation=manifest['documentationValidation'],
                 previousClosurePid=before['pid'], finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
except BaseException as exc:
    state.update(phase='pending-child' if 'pendingChild' in state else 'failed', error=repr(exc), traceback=traceback.format_exc())
save()

