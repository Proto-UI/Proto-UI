from pathlib import Path
import copy
import datetime
import fcntl
import gzip
import hashlib
import json
import os
import re
import subprocess
import time
import traceback

ROOT = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
OPS = Path(str(ROOT) + '-ops/final-23122/union-ee2379')
OUT = OPS / 'dce-evidence-validation-closure'
OUT.mkdir(exist_ok=True)
STATUS = OUT / 'status.json'
lock = (OUT / 'worker.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not STATUS.exists(), 'Reconcile this one documentation closure before another writer.'
HEAD = 'dce198cb7ba6361da8a7bb50972463d92a792ec2'
env = dict(os.environ, TMPDIR='/var/tmp/s6-75d5-modal', GIT_OPTIONAL_LOCKS='0')
env['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:' + env['PATH']
state = {'phase': 'starting', 'pid': os.getpid(), 'head': HEAD, 'runs': [],
         'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'scope': 'Append truthful documentation validation limitation and original receipts; no control, product or browser rerun.'}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def file_sha(path):
    return sha(path.read_bytes())


def read(path):
    return json.loads(path.read_text())


def read_route(path):
    text = path.read_text()
    return json.loads(text[text.index('{'):])


def write(path, value):
    assert not path.exists(), str(path)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def save():
    temporary = STATUS.with_suffix('.tmp')
    temporary.write_text(json.dumps(state, indent=2) + '\n')
    os.replace(temporary, STATUS)


def git(*args):
    return subprocess.check_output(['git', '-c', 'core.fsmonitor=false', '-c', 'submodule.recurse=false', *args],
                                   cwd=ROOT, env=env, text=True, timeout=120).strip()


def run(args, name, limit=300):
    state['phase'] = name
    save()
    target = OUT / (name + '.log')
    started = time.monotonic()
    with target.open('x') as stream:
        child = subprocess.Popen(args, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                 stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        state['childPid'] = child.pid
        save()
        try:
            code = child.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            state['pendingChild'] = {'pid': child.pid, 'name': name, 'seconds': limit}
            save()
            raise
    state.pop('childPid', None)
    state['runs'].append({'name': name, 'command': args, 'exit': code,
                          'seconds': round(time.monotonic() - started, 3), 'logSha256': file_sha(target)})
    save()
    assert code == 0, name
    return target


try:
    save()
    old_prep_path = OPS / 'dce-evidence-archive/status.json'
    old_prep = read(old_prep_path)
    previous_path = OPS / 'dce-evidence-validation/status.json'
    previous = read(previous_path)
    reconciliation_path = OPS / 'dce-evidence-validation/child-reconciliation-r1.json'
    reconciliation = read(reconciliation_path)
    projection_path = OPS / 'dce-evidence-projection/status.json'
    projection = read(projection_path)
    assert previous['phase'] == 'pending-child' and previous['pendingChild']['seconds'] == 900
    assert previous['pid'] == 3494356 and previous['pendingChild']['pid'] == 3494794
    assert file_sha(previous_path) == reconciliation['statusSha256'] == '05354554bd6d545b4f61b263dd4761572791c70c62ea0de434012a0aa1f8d1d9'
    original_log = OPS / 'dce-evidence-validation/agent-operations.log'
    assert file_sha(original_log) == reconciliation['logSha256'] == 'd3c7b1257f880fb4be107851c70f573f0e706dcdf8f9dacd1730b39966a38830'
    assert original_log.stat().st_size == reconciliation['logBytes'] == 136923
    assert reconciliation['processes'] == [] and reconciliation['rootPsExit'] == 1
    assert projection['phase'] == 'completed' and projection['sourceStable'] and projection['head'] == HEAD
    assert len(projection['runs']) == 3 and all(item['exit'] == 0 for item in projection['runs'])
    for pid in (3494356, 3494794, projection['pid']):
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            pass
        else:
            raise AssertionError('Previously owned process exists; reconcile without a second worker: ' + str(pid))
    assert not (OPS / 'dce-evidence-publication/status.json').exists()
    assert not (OPS / 'dce-terminal-body/status.json').exists()
    assert git('rev-parse', 'HEAD') == old_prep['head'] == HEAD
    assert git('write-tree') == old_prep['tree'] == projection['tree'] == '727f6a3cdd2b24e8f8694fd950f82852fac27246'
    assert not git('diff', '--name-only') and not git('ls-files', '--others', '--exclude-standard')
    record = ROOT / old_prep['record']
    manifest_path = ROOT / old_prep['manifest']
    evidence = manifest_path.parent
    assert file_sha(record) == old_prep['recordSha256'] == '3ece03793a053b524a588a9d6a7af99f6cc80e3b7d7f33cb33e19c7558b26a9e'
    assert file_sha(manifest_path) == old_prep['manifestSha256'] == '9ca0cf4b4e086bfa083ab310f0387c64a11a64bcfcb745de87454a409b387574'
    before_record = record.read_bytes()
    before_manifest = manifest_path.read_bytes()
    (OUT / 'before-record.md').write_bytes(before_record)
    (OUT / 'before-manifest.json').write_bytes(before_manifest)
    manifest = json.loads(before_manifest)
    original_artifacts = copy.deepcopy(manifest['artifacts'])
    assert len(original_artifacts) == 23
    closure = read(OPS / 'dce-ci-terminal/source-closure-readback.json')

    def verify_sources_and_originals():
        for group in closure['maps']:
            assert group['allMatch']
            for item in group['files']:
                assert file_sha(ROOT / item['path']) == item['expectedSha256'] == item['actualSha256']
        for item in manifest['preservedExistingCustody']:
            assert file_sha(ROOT / item['path']) == item['sha256'], item['path']
        for item in manifest['artifacts']:
            stored = (evidence / item['file']).read_bytes()
            raw = stored if item['encoding'] == 'identity' else gzip.decompress(stored)
            assert len(stored) == item['storedBytes'] and sha(stored) == item['storedSha256']
            assert len(raw) == item['rawBytes'] and sha(raw) == item['rawSha256']
        assert file_sha(previous_path) == reconciliation['statusSha256']
        assert file_sha(original_log) == reconciliation['logSha256']

    verify_sources_and_originals()
    summary = {}
    text = original_log.read_text()
    for key in ('tests', 'pass', 'fail', 'cancelled', 'skipped', 'todo'):
        found = re.findall(r'^\u2139 ' + key + r' (\d+)$', text, re.M)
        assert len(found) == 1, key
        summary[key] = int(found[0])
    duration = re.findall(r'^\u2139 duration_ms ([\d.]+)$', text, re.M)
    assert len(duration) == 1
    summary['durationMs'] = float(duration[0])
    assert summary == {'tests': 1549, 'pass': 1549, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0, 'durationMs': 900635.67921}
    policy_snippets = {
        'pui-validate': ['A fresh report may record `passed`, `failed`, `partial` or `not-run`; freshness is not a green result.',
                         'Passing checks establish technical evidence, not product correctness, review approval, merge permission, or release authorization.'],
        'pui-review': ['Partial or blocked visual evidence is valid: disclose it without manufacturing a capture or imposing human intake requirements.',
                       'Runtime blocks `REQUEST_CHANGES`, `APPROVE` and merge on unresolved verification debt, while an authorized `COMMENT` can disclose it.'],
        'pui-integrate': ['Require the validated `pui-review` handoff with all four registered artifacts: canonical `review-input`, clean `APPROVE` `review-packet`, the distinct original `published-review-packet`, and exact `mutation-authorization`.'],
        'pui-dev': ['Local edits, tests, commits, authorized branch pushes, own-PR updates, and review responses remain ordinary contributor work in `human-assisted` mode.',
                    'Treat a request to implement, advance, or finish the bounded work as authorization for its normal local edits, signed-off commits, and owned or explicitly authorized branch updates; re-read the live target before each external write.'],
    }
    policy = {'head': HEAD, 'role': 'Read-only rule interpretation; not a new policy exception, approval, or merge authorization.', 'sources': []}
    for skill, snippets in policy_snippets.items():
        rel = '.agents/skills/' + skill + '/SKILL.md'
        raw = (ROOT / rel).read_bytes()
        committed = subprocess.check_output(['git', 'show', HEAD + ':' + rel], cwd=ROOT, env=env, timeout=120)
        assert raw == committed
        for snippet in snippets:
            assert snippet in raw.decode(), (skill, snippet)
        policy['sources'].append({'path': rel, 'sha256': sha(raw), 'url': 'https://github.com/Proto-UI/Proto-UI/blob/' + HEAD + '/' + rel, 'exactExcerpts': snippets})
    policy['conclusion'] = 'Encode this documentation validation as partial with verification debt. An authorized ordinary evidence-only commit/push is neither an independent APPROVE nor a PR merge; their separate requirements remain intact.'
    write(OUT / 'policy-readback.json', policy)
    root_message = 'root已实际完整读exact-dce .agents/skills/pui-dev/SKILL.md，确认普通local edits/commit/owned push/own-PR属现有human-assisted授权，未把partial=green或review/merge。接受你拟定诚实result=partial、原900s/null shell exit+晚1549controls终态编码。完成增补与最后轻检查、455+11/旧custody/fresh remote guard后，继续正常signoff commit/nonforce push、新head标准CI/DCO及仅自有body块；不需再等我许可。记录仍叫verification limitation，不降成publication-only、不出GitHubAPPROVE、不merge。给revised record路径/sha我并行读即可。'
    write(OUT / 'root-continuation-message.json', {'kind': 'Actual parent message retained by recipient; not GitHub approval', 'from': '/root', 'message': root_message})

    def archive(path, name):
        raw = path.read_bytes()
        relative = 'documentation-validation/' + name + '.gz'
        target = evidence / relative
        assert not target.exists()
        target.parent.mkdir(exist_ok=True)
        stored = gzip.compress(raw, mtime=0)
        target.write_bytes(stored)
        manifest['artifacts'].append({'file': relative, 'source': str(path), 'rawBytes': len(raw), 'rawSha256': sha(raw),
                                      'storedBytes': len(stored), 'storedSha256': sha(stored), 'encoding': 'gzip'})

    archive(previous_path, 'original-supervisor-status.json')
    archive(original_log, 'original-agent-operations-late-terminal.log')
    archive(reconciliation_path, 'owned-child-natural-exit-reconciliation.json')
    archive(OPS / 'dce-evidence-validate.py', 'original-validator.py')
    archive(OPS / 'dce-evidence-validate-launch.json', 'original-validator-launch.json')
    archive(OPS / 'dce-evidence-validate-launch.log', 'original-validator-launch.log')
    for name in ('evidence-format-check', 'public-and-repository-docs'):
        source = OPS / 'dce-evidence-validation' / (name + '.log')
        expected = next(x['logSha256'] for x in previous['runs'] if x['name'] == name)
        assert file_sha(source) == expected
        archive(source, 'original-' + name + '.log')
    archive(projection_path, 'first-projection-completion-status.json')
    for item in projection['runs']:
        source = OPS / 'dce-evidence-projection' / (item['name'] + '.log')
        assert file_sha(source) == item['logSha256']
        archive(source, 'first-' + item['name'] + '.log')
    archive(OPS / 'dce-evidence-projection.py', 'first-projection-completion.py')
    archive(OPS / 'dce-evidence-projection-launch.json', 'first-projection-launch.json')
    archive(old_prep_path, 'original-preparation-status.json')
    archive(OPS / 'dce-evidence-root-review.json', 'original-root-peer-message.json')
    archive(OUT / 'before-record.md', 'before-record.md')
    archive(OUT / 'before-manifest.json', 'before-manifest.json')
    archive(OUT / 'policy-readback.json', 'policy-readback.json')
    archive(OUT / 'root-continuation-message.json', 'root-continuation-message.json')
    archive(Path(__file__), 'closure.py')
    limitation = {
        'result': 'partial', 'kind': 'verification',
        'scope': 'Proportional documentation checks; Node Agent-operation controls are not browser/native execution.',
        'inputHead': HEAD, 'inputPreparedTree': old_prep['tree'],
        'originalCommand': ['corepack', 'pnpm@10.32.1', 'check:agent-operations'],
        'supervision': {'result': 'timeout', 'limitSeconds': 900, 'shellExitCode': None,
                        'rawStatusSha256': reconciliation['statusSha256'],
                        'originalStatePreserved': 'pending-child'},
        'lateNodeReport': summary,
        'lateLogSha256': reconciliation['logSha256'],
        'naturalExitReadback': {'observedAt': reconciliation['observedAt'], 'ownedPids': [3494356, 3494794],
                               'processes': [], 'signalsSent': False, 'shellExitRecovered': False},
        'controlRerun': False,
        'completedCommands': previous['runs'] + projection['runs'],
        'remainingLimitation': 'The original 900-second supervision failed before a shell exit code was collected. The late complete 1549/1549 Node summary does not change that command into an observed exit-zero result. No cause or missing exit code is inferred.',
        'nextAction': 'Retain this verification limitation in the ordinary evidence-only successor and PR disclosure; obtain a separately observed successful command if a later review/integration gate requires it. No rerun or broader timeout is performed for this archive.',
        'ruleInterpretation': 'Ordinary authorized commit/push remains distinct from review approval, merge permission and acceptance; none is manufactured.'
    }
    manifest['documentationValidation'] = limitation
    assert manifest['artifacts'][:len(original_artifacts)] == original_artifacts
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    section = '''## Documentation validation limitation

The proportional documentation validation is **partial**, with an explicit **verification limitation**. On the evidence preparation at tree `727f6a3cdd2b24e8f8694fd950f82852fac27246`, `check:agent-operations` ran once under its original 900-second supervisor. That supervisor recorded `TimeoutExpired` and `pending-child`; it did not collect the command's shell exit code. The original status is retained unchanged, and `shellExitCode` remains `null`.

The same original Node process subsequently printed its complete summary: **1549 tests, 1549 passed, 0 failed/cancelled/skipped/todo**, with `duration_ms=900635.67921`. At 2026-11-23 22:41:13 UTC, a read-only owned-process reconciliation found the wrapper and child absent. No signal was sent, no child was restarted, and no second Agent-operation test run was performed. Natural process absence does not recover an unobserved shell exit. These are Node controls, not browser or native evidence, and their late summary does not turn the failed 900-second supervision into a successful command result. The cause of the excessive duration remains unconfirmed.

| Documentation operation | Actual observation | Boundary |
| --- | --- | --- |
| Original record/manifest formatting check | Exit 0 | Original preparation before this limitation was appended |
| Original public-docs and repository-link checks | Exit 0 | Original preparation |
| `check:agent-operations` | Supervisor timeout at 900 seconds; shell exit unknown | Late complete Node summary is 1549/1549, kept separately |
| `spec:docs:agent` | Exit 0 | First execution of the previously unreached projection step; no generated diff |
| `check:agent-doc` | Exit 0 | First execution following that generator |
| Review-rule routing | Exit 0 | Structural routing only; no independent approval |

The lossless validation originals include the original supervisor status, complete late log, launch/driver, natural-exit reconciliation, first projection completion, and their SHA-256 digests. The earlier 23 hosted evidence artifacts are unchanged. The current record and manifest receive fresh formatting and repository-link checks after this addition; their actual candidate-bound receipts are retained separately from the original command and its limitation.

Exact-dce `pui-validate` explicitly permits a fresh `partial` result and states that freshness is not a green result. `pui-review` retains unresolved verification debt as such; it cannot become publication-only debt or an approval. `pui-dev` treats an authorized ordinary signed-off commit and owned-branch push as contributor work, separate from `pui-integrate`'s approval, trusted CI/DCO and exact-head merge conditions. This record uses those ordinary operations only. It does not claim clean review, waive the unknown exit, authorize a PR merge, or change any timeout or assertion.

'''
    marker = '## Evidence-only successor and follow-up\n'
    original_text = before_record.decode()
    assert original_text.count(marker) == 1 and '## Documentation validation limitation' not in original_text
    record.write_text(original_text.replace(marker, section + marker, 1))
    run(['corepack', 'pnpm@10.32.1', 'exec', 'prettier', '--write', old_prep['record'], old_prep['manifest']], 'final-format')
    run(['corepack', 'pnpm@10.32.1', 'exec', 'prettier', '--check', old_prep['record'], old_prep['manifest']], 'final-format-check')
    run(['corepack', 'pnpm@10.32.1', 'check:public-docs'], 'final-public-and-repository-docs')
    manifest = read(manifest_path)
    assert manifest['documentationValidation'] == limitation
    assert manifest['artifacts'][:len(original_artifacts)] == original_artifacts
    verify_sources_and_originals()
    assert git('rev-parse', 'HEAD') == HEAD
    run(['git', 'add', '--', old_prep['record'], str(evidence.relative_to(ROOT))], 'stage-evidence-closure')
    paths = git('diff', '--cached', '--name-only', HEAD).splitlines()
    assert paths and all(p == old_prep['record'] or p.startswith(str(evidence.relative_to(ROOT)) + '/') for p in paths)
    assert set(git('diff', '--cached', '--name-status', HEAD).splitlines()) == {'A\t' + p for p in paths}
    assert not git('diff', '--name-only') and not git('ls-files', '--others', '--exclude-standard')
    run(['git', 'diff', '--cached', '--check'], 'final-whitespace-check')
    tree = git('write-tree')
    patch = subprocess.check_output(['git', 'diff', old_prep['tree'], tree, '--', old_prep['record'], old_prep['manifest']], cwd=ROOT, env=env, timeout=120)
    (OUT / 'record-manifest-increment.patch').write_bytes(patch)
    candidate = {'head': HEAD, 'tree': tree, 'paths': paths, 'kind': 'evidence-only documentation with partial validation',
                 'testedHead': HEAD, 'record': old_prep['record'], 'manifest': old_prep['manifest'],
                 'priorCandidateTree': old_prep['tree'], 'originalArtifactsPreserved': 23}
    write(OUT / 'candidate-change.json', candidate)
    old_handoff = read(OPS / 'dce-evidence-archive/docs-handoff.json')
    handoff = copy.deepcopy(old_handoff)
    candidate_artifact = next(item for item in handoff['artifacts'] if item['type'] == 'candidate-change')
    candidate_artifact.update(reference=str(OUT / 'candidate-change.json'), digest='sha256:' + file_sha(OUT / 'candidate-change.json'), revision=HEAD)
    handoff['notes'] = ['Documentation amendment preserves prior preparation and all 23 hosted artifacts, appends the truthful original timeout/unknown-exit verification limitation. New current candidate; no source change, control rerun or merge.']
    write(OUT / 'docs-handoff.json', handoff)
    route = read_route(run(['corepack', 'pnpm@10.32.1', 'agent:skill', '--', '--handoff', str(OUT / 'docs-handoff.json')], 'amended-validation-route'))
    assert not route['blocked']
    report = {
        'repositoryId': 'github.com:Proto-UI/Proto-UI', 'scopeId': 'sprint6-main-sync-75d5e28a',
        'head': HEAD, 'preparedTree': tree, 'result': 'partial',
        'scope': 'Evidence-only record/manifest/raw originals; no new product or native execution',
        'commands': copy.deepcopy(state['runs']), 'documentationValidation': limitation,
        'sourceStable': True, 'sourceClosureCounts': [group['count'] for group in closure['maps']],
        'originalsVerified': len(manifest['artifacts']), 'unchangedHostedArtifacts': 23,
        'unchangedCustody': len(manifest['preservedExistingCustody']),
        'actualHostedRun': {'head': HEAD, 'run': 45272391854, 'conclusion': 'failure', 'motion': '137/137', 'budget': '5/9 failed'},
        'debt': [{'kind': 'verification', 'missing': 'Observed shell exit code within the original Agent-controls supervision',
                  'reason': limitation['remainingLimitation'], 'nextAction': limitation['nextAction']}],
        'omitted': ['No repeated Agent controls, product, browser/native or full manual workflow for this documentation-only successor.'],
        'visualEvidence': {'kind': 'Existing original GitHub-hosted artifacts; no new capture',
                           'nativePacketSha256': '97cee74b8252a18defd36014f4e3845d1b7cec0f04b5a6c82b884a8edc365c9c',
                           'actuallyViewed': 3, 'boundary': 'No exhaustive visual or AT acceptance.'},
    }
    write(OUT / 'evidence-report.json', report)
    validation_handoff = copy.deepcopy(handoff)
    validation_handoff['fromId'] = 'pui-validate'
    validation_handoff['nextSkillId'] = 'pui-review'
    validation_handoff['artifacts'].append({'type': 'evidence-report', 'reference': str(OUT / 'evidence-report.json'),
                                            'digest': 'sha256:' + file_sha(OUT / 'evidence-report.json'), 'revision': HEAD, 'result': 'partial'})
    validation_handoff['notes'] = ['Fresh partial validation: original 900-second timeout and unknown shell exit remain verification debt. Late 1549/1549 Node summary is separate. This routing does not establish approval or integration eligibility.']
    write(OUT / 'validation-handoff.json', validation_handoff)
    review_route = read_route(run(['corepack', 'pnpm@10.32.1', 'agent:skill', '--', '--handoff', str(OUT / 'validation-handoff.json'),
                            '--prior-handoff', str(OUT / 'docs-handoff.json')], 'partial-review-route'))
    assert not review_route['blocked']
    verify_sources_and_originals()
    assert git('rev-parse', 'HEAD') == HEAD and git('write-tree') == tree
    assert not git('diff', '--name-only') and not git('ls-files', '--others', '--exclude-standard')
    state.update(phase='prepared-with-validation-limitation', result='partial', sourceStable=True, tree=tree,
                 record=old_prep['record'], manifest=old_prep['manifest'], addedPaths=paths,
                 recordSha256=file_sha(record), manifestSha256=file_sha(manifest_path),
                 artifacts=len(manifest['artifacts']), rawBytes=sum(x['rawBytes'] for x in manifest['artifacts']),
                 storedBytes=sum(x['storedBytes'] for x in manifest['artifacts']), preservedHostedArtifacts=23,
                 preservedCustodyPaths=len(manifest['preservedExistingCustody']),
                 sourceClosureCounts=[group['count'] for group in closure['maps']],
                 evidenceReportSha256=file_sha(OUT / 'evidence-report.json'),
                 partialReviewRouteSha256=file_sha(OUT / 'partial-review-route.log'),
                 incrementPatchSha256=file_sha(OUT / 'record-manifest-increment.patch'),
                 previousControlLimitation=limitation,
                 finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
except BaseException as exc:
    state.update(phase='pending-child' if 'pendingChild' in state else 'failed', error=repr(exc), traceback=traceback.format_exc())
save()

