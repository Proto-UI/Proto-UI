from pathlib import Path
import datetime
import fcntl
import gzip
import hashlib
import json
import os
import subprocess
import time
import traceback

ROOT = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
OPS = Path(str(ROOT) + '-ops/final-23122/union-ee2379')
OUT = OPS / 'dce-evidence-validation'
OUT.mkdir(exist_ok=True)
STATUS = OUT / 'status.json'
lock = (OUT / 'worker.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not STATUS.exists(), 'Reconcile the existing validator before starting another.'
HEAD = 'dce198cb7ba6361da8a7bb50972463d92a792ec2'
env = dict(os.environ, TMPDIR='/var/tmp/s6-75d5-modal', GIT_OPTIONAL_LOCKS='0')
env['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:' + env['PATH']
state = {'phase': 'starting', 'pid': os.getpid(), 'head': HEAD, 'runs': []}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def save():
    temp = STATUS.with_suffix('.tmp')
    temp.write_text(json.dumps(state, indent=2) + '\n')
    os.replace(temp, STATUS)


def git(*args):
    return subprocess.check_output(['git', '-c', 'core.fsmonitor=false', '-c', 'submodule.recurse=false', *args],
                                   cwd=ROOT, env=env, text=True, timeout=120).strip()


def command(args, name, limit=300):
    state['phase'] = name
    save()
    target = OUT / (name + '.log')
    started = time.monotonic()
    with target.open('x') as log:
        child = subprocess.Popen(args, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        state['childPid'] = child.pid
        save()
        try:
            code = child.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            state['pendingChild'] = {'pid': child.pid, 'name': name, 'seconds': limit}
            save()
            raise
    state.pop('childPid', None)
    state['runs'].append({'name': name, 'command': args, 'exit': code, 'seconds': round(time.monotonic() - started, 3),
                          'logSha256': sha(target)})
    save()
    return code


try:
    save()
    prep = read(OPS / 'dce-evidence-archive/status.json')
    assert prep['phase'] == 'prepared-for-validation' and prep['sourceStable']
    assert git('rev-parse', 'HEAD') == HEAD and git('write-tree') == prep['tree']
    assert not git('diff', '--name-only') and not git('ls-files', '--others', '--exclude-standard')
    manifest = read(ROOT / prep['manifest'])
    evidence_dir = (ROOT / prep['manifest']).parent
    closure = read(OPS / 'dce-ci-terminal/source-closure-readback.json')

    def verify_bytes():
        assert sha(ROOT / prep['record']) == prep['recordSha256']
        assert sha(ROOT / prep['manifest']) == prep['manifestSha256']
        for item in manifest['artifacts']:
            data = (evidence_dir / item['file']).read_bytes()
            raw = data if item['encoding'] == 'identity' else gzip.decompress(data)
            assert len(data) == item['storedBytes'] and hashlib.sha256(data).hexdigest() == item['storedSha256']
            assert len(raw) == item['rawBytes'] and hashlib.sha256(raw).hexdigest() == item['rawSha256']
        for group in closure['maps']:
            for item in group['files']:
                assert sha(ROOT / item['path']) == item['expectedSha256']
        for item in manifest['preservedExistingCustody']:
            assert sha(ROOT / item['path']) == item['sha256']

    verify_bytes()
    command(['corepack', 'pnpm@10.32.1', 'exec', 'prettier', '--check', prep['record'], prep['manifest']], 'evidence-format-check')
    command(['corepack', 'pnpm@10.32.1', 'check:public-docs'], 'public-and-repository-docs')
    command(['corepack', 'pnpm@10.32.1', 'check:agent-operations'], 'agent-operations', 900)
    generated = command(['corepack', 'pnpm@10.32.1', 'spec:docs:agent'], 'agent-projection-generate', 300)
    if generated == 0:
        command(['corepack', 'pnpm@10.32.1', 'check:agent-doc'], 'agent-projection-check', 300)
    verify_bytes()
    assert git('rev-parse', 'HEAD') == HEAD and git('write-tree') == prep['tree']
    assert not git('diff', '--name-only') and not git('ls-files', '--others', '--exclude-standard')
    passed = len(state['runs']) == 5 and all(r['exit'] == 0 for r in state['runs'])
    evidence_report = {
        'repositoryId': 'github.com:Proto-UI/Proto-UI', 'scopeId': 'sprint6-main-sync-75d5e28a',
        'head': HEAD, 'preparedTree': prep['tree'], 'result': 'passed' if passed else 'failed',
        'scope': 'Evidence-only record/manifest/immutable originals; not a new product or native execution',
        'commands': state['runs'], 'sourceStable': True, 'originalsVerified': len(manifest['artifacts']),
        'sourceClosureCounts': [g['count'] for g in closure['maps']],
        'unchangedCustody': len(manifest['preservedExistingCustody']),
        'actualHostedRun': {'head': HEAD, 'run': 45272391854, 'conclusion': 'failure', 'native': '137/137', 'budget': '5/9 failed'},
        'omitted': ['No repeated product, browser, native or full manual workflow for a documentation-only successor.'],
        'visualEvidence': {'kind': 'Existing uploaded original GitHub artifacts, no new capture',
                           'nativePacket': '97cee74b8252a18defd36014f4e3845d1b7cec0f04b5a6c82b884a8edc365c9c',
                           'actuallyViewed': 3, 'boundary': 'No exhaustive visual or AT acceptance.'},
    }
    report_path = OUT / 'evidence-report.json'
    report_path.write_text(json.dumps(evidence_report, indent=2) + '\n')
    prior_path = OPS / 'dce-evidence-archive/docs-handoff.json'
    handoff = read(prior_path)
    handoff['fromId'] = 'pui-validate'
    handoff['nextSkillId'] = 'pui-review' if passed else None
    handoff['artifacts'].append({'type': 'evidence-report', 'reference': str(report_path),
                                 'digest': 'sha256:' + sha(report_path), 'revision': HEAD,
                                 'result': 'passed' if passed else 'failed'})
    handoff['notes'] = ['New proportional documentation validation only. Existing dce overall workflow failure and five strict budget excesses remain explicit. No review approval or PR merge claimed.']
    handoff_path = OUT / 'validation-handoff.json'
    handoff_path.write_text(json.dumps(handoff, indent=2) + '\n')
    code = command(['corepack', 'pnpm@10.32.1', 'agent:skill', '--', '--handoff', str(handoff_path),
                    '--prior-handoff', str(prior_path)], 'review-route')
    assert code == 0
    state.update(phase='completed' if passed else 'completed-with-failures', sourceStable=True,
                 tree=prep['tree'], evidenceReportSha256=sha(report_path),
                 finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
except BaseException as exc:
    state.update(phase='pending-child' if 'pendingChild' in state else 'failed', error=repr(exc), traceback=traceback.format_exc())
save()
