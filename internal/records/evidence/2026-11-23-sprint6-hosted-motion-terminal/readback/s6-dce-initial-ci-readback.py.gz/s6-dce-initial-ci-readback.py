from pathlib import Path
import json,hashlib,zipfile,re,datetime

head='dce198cb7ba6361da8a7bb50972463d92a792ec2'
tree='7227b3e4215cc0071cac9f179005cca796622424'
run=45272391854
defs=[('source',14865892575,11994,'5d3d475eeb13017ca9ad13761f3ac38702a16d7564b05ee16b074217d1ce12ef'),('cli',14866476390,73663,'52493b27d0b0b44fadd470f92617e03e0922b6c97b2dae2483eff93201e8aa2f'),('react',14864224426,11122,'f98369ed40454c732974e53d435b6e841efe6052cc8f20b481f80995c98af59d'),('public-build',14865772422,318023,'782ca2d6fd92d31e97b6fbf2f6a948b5a0d42d207a869701fdc01b2581a306e1')]
def digest(b):return hashlib.sha256(b).hexdigest()
result={'schemaVersion':1,'readAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'tree':tree,'run':run,'url':f'https://github.com/Proto-UI/Proto-UI/actions/runs/{run}','scope':'Initial exact-head readback of four terminal jobs. Browser job remains independent and pending. No rerun, threshold change, or combining old native attempts.','jobs':[]}
for kind,artifact_id,size,h in defs:
 p=Path('s6-dce-'+kind+'.zip');b=p.read_bytes();assert len(b)==size and digest(b)==h
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  files={name:{'bytes':len(z.read(name)),'sha256':digest(z.read(name))} for name in z.namelist()}
  manifest=json.loads(z.read('manifest.json'));assert manifest['expectedHead']==manifest['eventSha']==head and str(manifest['runId'])==str(run) and str(manifest['runAttempt'])=='1'
  item={'kind':kind,'artifact':{'id':artifact_id,'path':str(p.resolve()),'bytes':size,'sha256':h,'url':f'https://github.com/Proto-UI/Proto-UI/actions/runs/{run}/artifacts/{artifact_id}'},'manifest':manifest,'archiveFiles':files}
  if kind=='source':
   assert manifest['status']=='passed' and manifest['failures']==[]
   for key in ('before','after'):
    v=manifest['source'][key];assert v['head'].strip()==head and v['tree'].strip()==tree and v['status']==''
   assert all(x['outcome']=='success' and x['commandExit']==x['logExit']==0 for x in manifest['stages'])
   graph=json.loads(z.read('spec-graph.json'));assert graph['numTotalTests']==graph['numPassedTests']==40 and graph['numFailedTests']==graph['numPendingTests']==graph['numTodoTests']==0
   assert len(graph['testResults'])==len(manifest['specGraph']['files'])==11
   assert all(a['status']=='passed' for f in graph['testResults'] for a in f['assertionResults'])
   tail=z.read('draft-consumer.log').decode();counts={k:int(re.findall(r'^# '+k+r' (\d+)$',tail,re.M)[-1]) for k in ('tests','pass','fail','cancelled','skipped','todo')};assert counts=={'tests':6,'pass':6,'fail':0,'cancelled':0,'skipped':0,'todo':0}
   item['graph']={k:graph[k] for k in ('numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests')};item['draftConsumer']=counts
  else:
   execution=json.loads(z.read('execution.json'));assert execution==manifest['execution'];assert execution['status']=='completed'
   for key in ('sourceBefore','sourceAfter'):
    v=execution[key];assert v['head']==head and v['tree']==tree and v['clean'] and v['status']==''
   assert execution['expectedHead']==execution['eventSha']==head and len(execution['commands'])==len(execution['plan'])
   assert [x['id'] for x in execution['commands']]==[x['id'] for x in execution['plan']]
   commands=[]
   for c in execution['commands']:
    for channel in ('stdout','stderr'):
     e=c[channel+'Evidence'];assert files[e['file']]=={'bytes':e['bytes'],'sha256':e['sha256']}
    assert c['teeExit']==0 and c['signal'] is None and c['errors']==[]
    expected=1 if kind=='public-build' and c['id']=='strict-budgets' else 0
    assert c['commandExit']==c['pipelineExit']==expected
    commands.append({'id':c['id'],'argv':c['argv'],'commandExit':c['commandExit'],'teeExit':c['teeExit'],'pipelineExit':c['pipelineExit']})
   item['commands']=commands
   if kind=='public-build':
    assert manifest['status']=='failed'
    report=json.loads(z.read('package-budgets.json'));assert report['source']['head']==head and report['source']['tree']==tree
    assert report['source']['workingTreeClean'] and report['source']['stableDuringMeasurement'] and report['source']['measuredSourceMatchesHead']
    old=json.loads(Path('readiness1738-review/budget-report/report.json').read_text());oldrows={x['name']:x for x in old['results']}
    assert report['environment']==old['environment'] and report['policy']==old['policy'] and report['measurement']==old['measurement']
    vectors=[]
    for x in report['results']:
     prior=oldrows[x['name']];before={v['path']:v for v in prior['closure']['inputs']};after={v['path']:v for v in x['closure']['inputs']}
     deltas=[{'path':p,'before':before.get(p),'after':after.get(p)} for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)]
     vectors.append({k:v for k,v in x.items() if k!='closure'}|{'deltaGzipFromEe':x['gzipBytes']-prior['gzipBytes'],'deltaMinifiedFromEe':x['minifiedBytes']-prior['minifiedBytes'],'sourceInputChangesFromEe':deltas})
    assert len(vectors)==9 and sum(not x['pass'] for x in vectors)==5
    item['budget']={'passed':4,'failed':5,'source':report['source'],'reportSha256':digest(z.read('package-budgets.json')),'equalEnvironmentPolicyMeasurementToEe':True,'entries':vectors}
   else:
    assert manifest['status']=='passed' and manifest['failures']==[] and execution['errors']==[]
    raw=z.read('smoke-'+kind+'.stdout.log').decode();message='release consumer smoke: '+kind+' ok ('+('42' if kind=='react' else '44')+'/47 packed packages consumed)';assert message in raw;item['smokeMessage']=message
  result['jobs'].append(item)
p=Path('s6-dce-initial-ci-readback.json');assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':digest(p.read_bytes()),'jobs':[{k:x[k] for k in ('kind','artifact')} for x in result['jobs']]},indent=2))
