from pathlib import Path
import datetime
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
HEAD = 'dce198cb7ba6361da8a7bb50972463d92a792ec2'
RUN = 45272391854
ARTIFACTS = {
    'motion': (14866223968, 1397713, '55b96e1b4021e6ad1167a8636b5c4752467aebc2be929a62f2a25f6fb9827e03'),
    'controls': (14866234070, 1961001, 'a7c648bb6e771310ba4a1389c32bac08cc0c1c0eed4127e10ea93d35ad8c5c2a'),
    'navbar': (14864854730, 15442505, '564da161dbff938218a7d890bda54e12de1234f44df39708e74c9baa4d0f395a'),
    'button': (14865154305, 186154, 'bdb6989002745b6bfde119174208f1f4d722106327a87f68fe880f6f3b9ca8c2'),
}


def digest(value):
    return hashlib.sha256(value).hexdigest()


def identity(path):
    data = path.read_bytes()
    return {'file': path.name, 'bytes': len(data), 'sha256': digest(data)}


def read_json(z, name):
    return json.loads(z.read(name))


def part(value):
    keys = ('phase', 'present', 'connected', 'portaled', 'detached', 'owner',
            'viewEpoch', 'created', 'mounted', 'unmounted', 'concealed', 'inert')
    return {key: value[key] for key in keys}


def root_manifest(m):
    assert m['status'] == 'passed'
    assert m['expectedSha'] == HEAD
    assert str(m['runId']) == str(RUN) and str(m['runAttempt']) == '1'


api = json.loads((ROOT / 's6-dce-terminal-api.json').read_text())
run = api['run']
assert run['id'] == RUN and run['head_sha'] == HEAD and run['run_attempt'] == 1
assert run['status'] == 'completed' and run['conclusion'] == 'failure'
assert run['event'] == 'workflow_dispatch'
expected_jobs = {
    'browser-evidence': 'success',
    'Source generation, types and spec validation': 'success',
    'Public packages (cli)': 'success',
    'Public packages (build)': 'failure',
    'Public packages (react)': 'success',
}
assert len(api['jobs']) == len(expected_jobs)
for job in api['jobs']:
    assert job['status'] == 'completed'
    assert job['conclusion'] == expected_jobs[job['name']]
    assert job['run_id'] == RUN

out = {
    'schemaVersion': 1,
    'observedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'kind': 'read-only validation of original hosted artifacts; no new test execution',
    'head': HEAD,
    'run': {key: run[key] for key in ('id', 'html_url', 'event', 'path', 'head_sha',
                                    'run_attempt', 'status', 'conclusion', 'updated_at')},
    'dispatchInputs': {'validate_public_packages': 'true'},
    'dispatchInputsAuthority': 'original completed publisher receipt; API run does not expose inputs',
    'jobs': [{**{key: job[key] for key in ('id', 'name', 'run_id', 'status', 'conclusion')},
              'url': f'https://github.com/Proto-UI/Proto-UI/actions/runs/{RUN}/job/{job["id"]}'}
             for job in api['jobs']],
    'apiReadback': identity(ROOT / 's6-dce-terminal-api.json'),
    'artifacts': {},
    'boundaries': [
        'Current dce source and one hosted run only; no aggregation of two older 8882 5/6 attempts.',
        '137 consists of 124 source/DOM cases, 12 actual browser positive cases and one explicit split refusal.',
        'Headless Chromium source-Web coverage is not physical 120 Hz, frame-budget, OS, non-Web or AT conformance.',
        'The overall run failed because current strict package budgets failed in the separate public-build job.',
        'The historical ee Liquid representative four-host failure and font setup timeout are separate runs; not rerun here.',
        'Original local graph 5000 ms timeout remains a historical failure; current hosted graph has its own successful source receipt.',
        'Source closure hashes below are from the original hosted bundle. Device file comparison is a separately recorded step.',
    ],
}
zips = {}
for kind, (artifact_id, byte_count, expected) in ARTIFACTS.items():
    path = ROOT / ('s6-dce-' + kind + '.zip')
    actual = identity(path)
    assert actual['bytes'] == byte_count and actual['sha256'] == expected
    remote = next(a for a in api['artifacts'] if a['id'] == artifact_id)
    assert remote['size_in_bytes'] == byte_count and remote['digest'] == 'sha256:' + expected
    assert remote['workflow_run']['head_sha'] == HEAD
    z = zipfile.ZipFile(path)
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist()))
    zips[kind] = z
    out['artifacts'][kind] = {
        **actual, 'id': artifact_id, 'name': remote['name'],
        'serverDigest': remote['digest'], 'crcVerified': True,
        'files': [{'path': name, 'bytes': len(z.read(name)), 'sha256': digest(z.read(name))}
                  for name in z.namelist() if not name.endswith('/')],
    }

z = zips['motion']
m = read_json(z, 'manifest.json')
root_manifest(m)
assert m['stepOutcome'] == 'success' and m['failures'] == []
assert m['sourceBefore'] == m['sourceAfter']
before = m['sourceBefore']
assert before['expectedSha'] == before['checkoutSha'] == HEAD and before['dirty'] is False
assert before['runId'] == str(RUN) and before['runAttempt'] == '1'
assert len(before['inputs']) == 11
assert m['reportSha256'] == digest(z.read('vitest.json'))
report = read_json(z, 'vitest.json')
assert report['success'] is True
assert report['numTotalTests'] == report['numPassedTests'] == 137
assert report['numFailedTests'] == report['numPendingTests'] == report['numTodoTests'] == 0
assert len(report['testResults']) == 11
execution = m['execution']
assert execution['passed'] is True and execution['failures'] == []
assert execution['requiredFiles'] == 11 and execution['requiredAssertions'] == 137
assert execution['nativePositiveCases'] == {'modalDocument': 6, 'progressDocument': 3, 'progressDirectShadow': 3}
assert execution['negativeAdmissionCases'] == {'progressExperimentalSplit': 1}
assert execution['hostRegressionCases'] == {'portalAttributeReentry': 1}
case_counts = {}
for suite in execution['suites']:
    assert suite['occurrences'] == 1 and suite['cases'] == suite['actualCases']
    rows = [item for item in report['testResults'] if item['name'].endswith('/' + suite['file'])]
    assert len(rows) == 1 and rows[0]['status'] == 'passed'
    assertions = rows[0]['assertionResults']
    assert len(assertions) == suite['cases'] and all(a['status'] == 'passed' for a in assertions)
    assert len({a['fullName'] for a in assertions}) == len(assertions)
    case_counts[suite['file']] = len(assertions)
    if suite['file'].endswith('portal-conceal.test.ts'):
        title = 'WC portal conceal rendering barrier retains the reopened event gate after native detached attribute reentry'
        assert sum(a['fullName'] == title for a in assertions) == 1

modal_source = read_json(z, 'bootstrap-modal-presence/source.json')
assert len(modal_source['sourceSha256']) == 455
assert modal_source['scope'] == 'document'
for family, folder in [('modal', 'bootstrap-modal-presence'), ('progress', 'bootstrap-progress-width')]:
    source = read_json(z, folder + '/source.json')
    for key, file in [('bundleSha256', 'consumer.js'), ('cssSha256', 'tokens.css')]:
        assert source[key] == digest(z.read(folder + '/' + file))
        assert source[key] == m['artifacts']['source'][family][key]

modal_rows = []
for metadata in m['artifacts']['modal']:
    filename = 'bootstrap-modal-presence/' + metadata['file'] + '.json'
    d = read_json(z, filename)
    assert d['status'] == 'passed' and d['scope'] == 'document' and d['errors'] == []
    assert d['family'] == metadata['family'] and d['name'] == metadata['name']
    assert d['sourceSha256'] == modal_source['sourceSha256']
    assert d['bundleSha256'] == modal_source['bundleSha256'] and d['cssSha256'] == modal_source['cssSha256']
    disposal = {k: v for k, v in d['disposal'].items() if k != 'lifecycle'}
    assert disposal == {'rootConnected': False, 'contentConnected': False, 'maskConnected': False,
                        'contentStyle': '', 'maskStyle': '', 'contentInert': False, 'maskInert': False}
    row = {'file': filename, 'family': d['family'], 'name': d['name'], 'status': d['status'],
           'browserVersion': d['browserVersion'], 'disposal': disposal, 'limits': d['limits']}
    for image in metadata['images']:
        raw = z.read('bootstrap-modal-presence/' + image['file'])
        assert len(raw) == image['bytes'] and digest(raw) == image['sha256']
        assert raw.startswith(b'\x89PNG\r\n\x1a\n')
        originals = [item for item in d['images'] if item['file'] == image['file']]
        assert len(originals) == 1 and originals[0]['sha256'] == image['sha256']
    row['images'] = metadata['images']
    if d['name'] == 'enter-close':
        row['physicalRetirement'] = {}
        samples = d['leaving']['samples']
        for name in ('content', 'mask'):
            entered = d['entering']['samples'][-1][name]
            retained = [s[name] for s in samples if s[name]['phase'] == 'closed' and s[name]['portaled']]
            assert len(retained) >= 2
            for sample in samples:
                p = sample[name]
                if p['phase'] == 'closed':
                    assert p['detached'] is True and p['concealed'] is True
            for p in retained:
                assert p['connected'] and p['inert'] and p['detached'] and p['concealed']
                assert p['present'] is False
                for key in ('owner', 'viewEpoch', 'created', 'mounted', 'unmounted'):
                    assert p[key] == entered[key]
            final = samples[-1][name]
            assert final['connected'] and final['portaled'] is False and final['unmounted'] == entered['unmounted'] + 1
            for key in ('owner', 'viewEpoch', 'created', 'mounted'):
                assert final[key] == entered[key]
            row['physicalRetirement'][name] = {'samples': len(samples), 'retainedClosedSamples': len(retained),
                                               'retained': [part(p) for p in retained], 'final': part(final)}
    else:
        rev = d['reversal']
        a, b, final = rev['before']['content'], rev['after']['content'], rev['returning']['samples'][-1]['content']
        expected_phase = 'closed' if d['name'] == 'barrier-reopen' else 'leaving'
        assert a['phase'] == expected_phase and a['detached'] == (d['name'] == 'barrier-reopen')
        assert a['connected'] and a['portaled'] and a['unmounted'] == 0
        assert b['phase'] == 'entering' and b['present'] and b['connected'] and b['portaled'] and b['detached'] is False
        assert final['phase'] == 'entered' and final['concealed'] is False
        for key in ('owner', 'viewEpoch', 'created', 'mounted', 'unmounted'):
            assert a[key] == b[key] == final[key]
        row['sameContentViewReversal'] = {'before': part(a), 'after': part(b), 'settled': part(final)}
        row['maskReversal'] = {name: part(rev[name]['mask']) for name in ('before', 'after')}
        row['maskScope'] = 'Mask may have completed its shorter physical retirement before Content barrier reversal; its actual epoch is retained here, not claimed unchanged.'
    modal_rows.append(row)
assert len(modal_rows) == 6

progress_rows = []
for metadata in m['artifacts']['progress']:
    folder = 'bootstrap-progress-width/'
    filename = folder + metadata['file'] + '.json'
    d = read_json(z, filename)
    assert d['scope'] == metadata['scope'] and d['name'] == metadata['name'] and d['errors'] == []
    assert d['bundleSha256'] == m['artifacts']['source']['progress']['bundleSha256']
    assert d['cssSha256'] == m['artifacts']['source']['progress']['cssSha256']
    image = metadata['image']
    raw = z.read(folder + image['file'])
    assert len(raw) == image['bytes'] and digest(raw) == image['sha256']
    final = d['final']['sample']
    assert final['diagnostics'] == [] and final['inlineWidth'] == '' and final['inlinePriority'] == ''
    progress_rows.append({'file': filename, 'scope': d['scope'], 'name': d['name'], 'image': image,
                          'finalSample': final, 'historicalDiagnosticsPreserved': len(d['final']['diagnostics']),
                          'limit': d['limit']})
assert len(progress_rows) == 6
split = read_json(z, 'bootstrap-progress-width/shadow-split-unsupported.json')
assert split['disposition'] == 'unsupported' and split['countsAsVisualAcceptance'] is False
assert split['scope'] == 'shadow-split'
assert split['reason'] == '[bootstrap-2-3-2-progress-track]setup token "overflow-hidden":unresolved-role; fix: companion or change/remove token'
assert split['errors'] == ['Error: ' + split['reason']]
for sample in split['rejected'].values():
    assert sample['trackSurfaceExists'] is False and sample['allInlineWidthLeases'] == []
    assert sample['runtimeErrors'] == ['Error: ' + split['reason']]
split_image = m['artifacts']['splitNegative']['image']
raw = z.read('bootstrap-progress-width/' + split_image['file'])
assert len(raw) == split_image['bytes'] and digest(raw) == split_image['sha256']
out['motion'] = {'manifestSha256': digest(z.read('manifest.json')), 'reportSha256': m['reportSha256'],
                 'sourceBeforeEqualsAfter': True, 'sourceBefore': before,
                 'execution': execution, 'actualFileCounts': case_counts,
                 'total': 137, 'passed': 137, 'failed': 0, 'pending': 0, 'todo': 0,
                 'modalSource': modal_source, 'modal': modal_rows, 'progress': progress_rows,
                 'splitRefusal': {key: split[key] for key in ('disposition', 'countsAsVisualAcceptance', 'reason', 'boundary', 'errors')},
                 'pngCount': sum(n.endswith('.png') for n in z.namelist())}

for kind, counts in [('controls', (31, None, 64)), ('navbar', (12, 38, 298)), ('button', (8, 96, 112))]:
    zz = zips[kind]
    mm = read_json(zz, 'manifest.json')
    root_manifest(mm)
    assert mm['sourceSha'] == HEAD and mm['pageErrors'] == []
    assert mm['node'] == 'v24.22.3'
    assert len(mm['results']) == counts[0] and all(r['status'] == 'pass' and not r.get('errors') for r in mm['results'])
    if counts[1] is not None:
        assert len(mm['cases']) == counts[1] and all(c['status'] == 'passed' for c in mm['cases'])
        assert mm['protocolErrors'] == mm['cleanupErrors'] == [] and mm['stepStatus'] == 'success'
    assert len(mm['screenshots']) == counts[2] == sum(n.endswith('.png') for n in zz.namelist())
    assert len(set(mm['screenshots'])) == len(mm['screenshots'])
    for screenshot in mm['screenshots']:
        assert zz.read(screenshot).startswith(b'\x89PNG\r\n\x1a\n')
    out[kind] = {'manifestSha256': digest(zz.read('manifest.json')),
                 'results': mm['results'], 'cases': mm.get('cases'), 'screenshots': counts[2],
                 'sourceSha': mm['sourceSha'], 'browser': mm['browser'], 'node': mm['node'],
                 'pageErrors': mm['pageErrors'], 'scope': mm['scope']}
    if kind == 'controls':
        v = read_json(zz, 'vitest.json')
        assert v['success'] and v['numTotalTests'] == v['numPassedTests'] == 83
        assert v['numFailedTests'] == v['numPendingTests'] == v['numTodoTests'] == 0
        validation = read_json(zz, 'validation.json')
        assert validation['ok'] is True
        out[kind]['validation'] = validation
        out[kind]['vitest'] = {k: v[k] for k in ('numTotalTests', 'numPassedTests', 'numFailedTests', 'numPendingTests', 'numTodoTests')}
    else:
        out[kind]['protocolErrors'] = mm['protocolErrors']
        out[kind]['cleanupErrors'] = mm['cleanupErrors']

out['visualInspection'] = {
    'method': 'Assistant viewed these three original dce PNGs using view_image; all other image bytes are integrity checked only.',
    'findings': [
        'Dialog entered: visible titled panel and text over a dark full-page backdrop.',
        'AlertDialog entered: visible confirmation panel over a dark full-page backdrop.',
        'Dialog enter-close terminal: underlying page visible with no residual dialog or backdrop.',
    ],
    'images': [identity(ROOT / 's6-dce-visual/bootstrap-modal-presence' / name)
               for name in ('dialog-entered.png', 'alert-dialog-entered.png', 'dialog-enter-close-terminal.png')],
    'boundary': 'No claim of exhaustive visual inspection, accessibility audit or physical display timing.',
}
out['publicAndSourceReadback'] = identity(ROOT / 's6-dce-initial-ci-readback.json')
out['budgetRawReport'] = identity(ROOT / 's6-dce-package-budgets.json')
out['currentBudgetFailures'] = [
    {'entry': 'Core', 'gzip': 12868, 'cap': 12800, 'over': 68},
    {'entry': 'Runtime', 'gzip': 106768, 'cap': 104300, 'over': 2468},
    {'entry': 'React', 'gzip': 178328, 'cap': 172600, 'over': 5728},
    {'entry': 'Vue', 'gzip': 177109, 'cap': 171400, 'over': 5709},
    {'entry': 'WebComponent', 'gzip': 213824, 'cap': 207200, 'over': 6624},
]
out['script'] = identity(Path(__file__))
target = ROOT / 's6-dce-native-terminal-readback.json'
assert not target.exists(), 'Preserve the original readback; do not overwrite it.'
target.write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'result': 'verified', **identity(target), 'motion': '137/137',
                  'nativePositive': 12, 'splitRefusal': 1, 'modalSources': 455,
                  'browserJob': 'success', 'runConclusion': 'failure',
                  'budgetFailures': 5}, ensure_ascii=False))
