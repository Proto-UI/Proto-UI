from pathlib import Path
import datetime
import fcntl
import gzip
import hashlib
import json
import os
import re
import subprocess
import time
import traceback
import zipfile

ROOT = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
OPS = Path(str(ROOT) + '-ops/final-23122/union-ee2379')
OUT = OPS / 'dce-evidence-archive'
OUT.mkdir(exist_ok=True)
STATUS = OUT / 'status.json'
lock = (OUT / 'worker.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not STATUS.exists(), 'Reconcile this archive before starting a second writer.'
HEAD = 'dce198cb7ba6361da8a7bb50972463d92a792ec2'
NAME = '2026-11-23-sprint6-hosted-motion-terminal'
RECORD = ROOT / 'internal/records' / (NAME + '.md')
EVIDENCE = ROOT / 'internal/records/evidence' / NAME
env = dict(os.environ, TMPDIR='/var/tmp/s6-75d5-modal', GIT_OPTIONAL_LOCKS='0')
env['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:' + env['PATH']
state = {'phase': 'starting', 'pid': os.getpid(), 'head': HEAD, 'runs': []}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def file_sha(path):
    return sha(path.read_bytes())


def read(path):
    return json.loads(path.read_text())


def save():
    temp = STATUS.with_suffix('.tmp')
    temp.write_text(json.dumps(state, indent=2) + '\n')
    os.replace(temp, STATUS)


def command(args, name, limit=180):
    state['phase'] = name
    save()
    target = OUT / (name + '.log')
    start = time.monotonic()
    with target.open('x') as log:
        child = subprocess.Popen(args, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        state['childPid'] = child.pid
        save()
        try:
            code = child.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            state['pendingChild'] = {'pid': child.pid, 'name': name, 'seconds': limit}
            save()
            raise
    state.pop('childPid', None)
    state['runs'].append({'name': name, 'command': args, 'exit': code, 'seconds': round(time.monotonic() - start, 3),
                          'logSha256': file_sha(target)})
    save()
    assert code == 0, name
    return target


def git(*args):
    return subprocess.check_output(['git', '-c', 'core.fsmonitor=false', '-c', 'submodule.recurse=false', *args],
                                   cwd=ROOT, env=env, text=True, timeout=120).strip()


def write_json(path, value):
    assert not path.exists()
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


try:
    save()
    assert git('rev-parse', 'HEAD') == HEAD
    assert not git('status', '--porcelain=v1', '--untracked-files=all')
    assert git('symbolic-ref', '--short', 'HEAD') == 'work/sprint6-main-sync-75d5e28a-20261123'
    pr = read(command(['gh', 'api', 'repos/Proto-UI/Proto-UI/pulls/1712'], 'fresh-pr'))
    assert pr['state'] == 'open' and not pr['draft'] and not pr['merged'] and pr['head']['sha'] == HEAD
    custody = read(OPS / 'dce-ci-terminal/status.json')
    assert custody['phase'] == 'completed' and custody['trackedClean'] and custody['sourceStable']
    terminal = OPS / 'dce-ci-terminal'
    initial = OPS / 'dce-ci-initial'
    packet = read(terminal / 's6-dce-native-terminal-readback.json')
    assert file_sha(terminal / 's6-dce-native-terminal-readback.json') == '97cee74b8252a18defd36014f4e3845d1b7cec0f04b5a6c82b884a8edc365c9c'
    public = read(initial / 's6-dce-initial-ci-readback.json')
    assert file_sha(initial / 's6-dce-initial-ci-readback.json') == '2c421b9f7a25508dcaeb2c19865a0ecaa1d7dd88ba9e14e1e6a5caf674fea851'
    closure = read(terminal / 'source-closure-readback.json')
    for group in closure['maps']:
        assert group['allMatch']
        for item in group['files']:
            assert file_sha(ROOT / item['path']) == item['expectedSha256'] == item['actualSha256']
    old_custody = read(OPS / 'publication/status.json')['mergePreview']['custody']
    for item in old_custody:
        assert file_sha(ROOT / item['path']) == item['sha256']
    assert not RECORD.exists() and not EVIDENCE.exists()
    EVIDENCE.mkdir(parents=True)
    artifacts = []

    def archive(path, relative, original_zip=False):
        raw = path.read_bytes()
        target = EVIDENCE / relative
        assert not target.exists()
        target.parent.mkdir(parents=True, exist_ok=True)
        stored = raw if original_zip else gzip.compress(raw, mtime=0)
        target.write_bytes(stored)
        artifacts.append({'file': relative, 'source': str(path), 'rawBytes': len(raw), 'rawSha256': sha(raw),
                          'storedBytes': len(stored), 'storedSha256': sha(stored),
                          'encoding': 'identity' if original_zip else 'gzip'})

    for kind, meta in packet['artifacts'].items():
        path = terminal / meta['file']
        assert file_sha(path) == meta['sha256'] and path.stat().st_size == meta['bytes']
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None
            for item in meta['files']:
                raw = z.read(item['path'])
                assert sha(raw) == item['sha256'] and len(raw) == item['bytes']
        archive(path, 'original-artifacts/' + path.name, True)
    for lane in public['jobs']:
        meta = lane['artifact']
        path = initial / Path(meta['path']).name
        assert file_sha(path) == meta['sha256'] and path.stat().st_size == meta['bytes']
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None
            for filename, expected in lane['archiveFiles'].items():
                raw = z.read(filename)
                assert sha(raw) == expected['sha256'] and len(raw) == expected['bytes']
        archive(path, 'original-artifacts/' + path.name, True)
    for filename in ['s6-dce-native-terminal-readback.json', 's6-dce-native-readback.py', 's6-dce-terminal-api.json',
                     's6-dce-motion-gate-source.mjs', 'source-closure-readback.json', 'status.json']:
        archive(terminal / filename, 'readback/' + filename + '.gz')
    for filename in ['s6-dce-initial-ci-readback.json', 's6-dce-initial-ci-readback.py']:
        archive(initial / filename, 'readback/' + filename + '.gz')
    for filename in ['status.json', 'dispatch-request.json', 'commit-object.txt']:
        archive(OPS / 'publication' / filename, 'original-publication/' + filename + '.gz')
    archive(Path(__file__), 'execution/archive.py.gz')
    authority = {
        'repositoryId': 'github.com:Proto-UI/Proto-UI', 'scopeId': 'sprint6-main-sync-75d5e28a', 'head': HEAD,
        'role': 'Dated non-normative observation; no implementation, lifecycle, policy or acceptance threshold change.',
        'priorTrace': str(OPS.parent / 'repair-authority-map-v3.json'),
        'correctionToHistoricalTrace': 'Current main retains distinct HC-CONTROL-LABEL-0001-GPUI and GPUI-PROVIDER IDs. This archive does not reuse the obsolete one-ID conjunction.',
        'owners': [
            {'claim': 'Actual 137 inventory and all terminal states', 'source': '.github/workflows/bootstrap-state-controls-evidence.yml', 'evidence': packet['apiReadback']},
            {'claim': 'Source-bound Modal retirement observations, not a new guarantee', 'source': 'packages/prototypes/bootstrap-2-3-2/test/modal-presence.browser.test.ts', 'evidence': packet['artifacts']['motion']['sha256']},
            {'claim': 'Unchanged strict budgets with five actual excesses', 'source': 'scripts/analysis/package-budgets.mjs', 'evidence': packet['budgetRawReport']},
            {'claim': 'Historical placement and preserved failures', 'source': 'internal/records/README.md'},
        ],
    }
    scope = {'role': 'historical engineering record', 'head': HEAD,
             'addedRecord': str(RECORD.relative_to(ROOT)), 'addedEvidenceDirectory': str(EVIDENCE.relative_to(ROOT)),
             'purpose': 'Preserve complete hosted dce native/source/public artifacts and current budget failure with exact source equivalence.',
             'nonGoals': ['no source or test change', 'no previous record rewrite', 'no changed budget', 'no new hand-run workflow', 'no PR merge']}
    authorization = {'executionMode': 'human-assisted', 'executionModeSource': 'current-user',
                     'source': 'Current-user-directed continuation relayed by root; explicit normal evidence commit/non-force push request.',
                     'target': 'Proto-UI/Proto-UI#1712', 'branch': 'sprint6/bootstrap-liquid-delivery-20261122',
                     'authorized': ['add dated record and original evidence', 'normal signed-off commit', 'non-force branch push', 'own marked body update'],
                     'excluded': ['PR merge', 'force push', 'ruleset changes', 'rerun original manual workflow']}
    for filename, obj in [('authority-map.json', authority), ('documentation-scope.json', scope), ('implementation-authorization.json', authorization)]:
        write_json(OUT / filename, obj)
        archive(OUT / filename, 'scope/' + filename + '.gz')
    manifest = {
        'schemaVersion': 1, 'role': 'immutable original hosted evidence', 'testedHead': HEAD,
        'testedTree': '7227b3e4215cc0071cac9f179005cca796622424', 'run': packet['run'],
        'dispatchInputs': packet['dispatchInputs'], 'jobs': packet['jobs'],
        'motion': {'total': 137, 'passed': 137, 'failed': 0, 'pending': 0, 'todo': 0,
                   'sourceCases': 124, 'nativePositive': 12, 'splitRefusal': 1,
                   'sourceClosureFiles': 455, 'testInputs': 11, 'execution': packet['motion']['execution']},
        'nativeSourceClosureReadbackSha256': file_sha(terminal / 'source-closure-readback.json'),
        'nativeReadbackSha256': file_sha(terminal / 's6-dce-native-terminal-readback.json'),
        'publicReadbackSha256': file_sha(initial / 's6-dce-initial-ci-readback.json'),
        'currentBudgetFailures': packet['currentBudgetFailures'],
        'equivalenceBoundary': 'This evidence-only successor does not rerun the workflow. Product, tests, dependencies, workflow, generator and budget source remain identical to tested dce; commit custody verifies the entire changed-path set.',
        'visualInspection': packet['visualInspection'], 'preservedExistingCustody': old_custody,
        'historicalBoundaries': packet['boundaries'], 'artifacts': artifacts,
    }
    manifest_path = EVIDENCE / 'manifest.json'
    write_json(manifest_path, manifest)
    RECORD.write_text(f'''# Sprint 6 hosted motion terminal evidence

## Context and exact tested source

This dated record preserves the completed hosted validation of PR #1712 at `{HEAD}` (tree `7227b3e4215cc0071cac9f179005cca796622424`). It follows the [concurrent motion integration record](2026-11-23-sprint6-concurrent-motion-union.md), whose pre-run observations remain unchanged. The successor commit containing this record adds evidence only. It is not a second native execution at that later commit, an approval, a PR merge, or a promotion of draft contracts.

[Bootstrap workflow 45272391854](https://github.com/Proto-UI/Proto-UI/actions/runs/45272391854), attempt 1, was dispatched once with `validate_public_packages=true`. Its final overall conclusion is **failure**: browser evidence, source validation, CLI and React jobs passed, while the public-build job failed the original strict package budgets. The browser job, including historical capture and finalizers, completed successfully.

## Actual native and source evidence

| Original lane | Actual execution | Evidence boundary |
| --- | --- | --- |
| Strict motion inventory | **137/137**, 0 failed/pending/todo, 11 exact files | 124 source/DOM cases, 12 native positives and one split refusal |
| Dialog and AlertDialog | **6/6** positive document cases | Enter/close, leaving reversal and physical-barrier reversal for both families |
| Progress | **6/6** positive cases | Three document and three direct-shadow cases |
| Experimental Progress split | **1/1** strict refusal | Exact unresolved `overflow-hidden` role; does not count as visual acceptance |
| Four-runtime controls | **31** real browser cases; **83/83** full suite | WC, React, Vue and Vue2; 64 original PNGs |
| Navbar | **12** journeys and **38** cells, all passed | 298 original PNGs |
| Button native motion | **8** journeys and **96** cells, all passed | 112 original PNGs |
| Source generation/types/spec | **40/40** graph/spec and **6/6** draft consumers | Official companions, public and workspace types passed on dce |
| Canonical CLI and React public groups | Passed | CLI consumed 44/47 packed packages; React 42/47; these package smokes are not OS/native acceptance |

The complete inventory retains all 31 Portal cases, the exact native detached-attribute reentry fixture, and all seven externally added motion cases. The protocol false-total negative remains 138. The hosted JSON and original gate agree on all 137 unique passed assertions. They are kept as raw bytes inside the original motion ZIP.

For each family, Content and Mask each have two actual closed-retained samples: connected, portaled, detached, concealed and inert, with the same owner, epoch, created count and 1 mount / 0 unmount. The settled closed sample remains connected, withdraws physical projection, and records 1 mount / 1 unmount. Every closed sample independently retains detached and concealed assertions. Content barrier reversal reopens the same retained view. Mask may already have retired after its shorter 150 ms transition and can legitimately acquire a new epoch; this record does not claim unchanged Mask epochs in that journey. All six disposals restore empty owned style and non-inert state after removing the root and authored parts.

Original capture retains the 12 ms timing bound, 1000 ms watchdog, two trailing frames, native actions and cleanup checks. Positive native and four-runtime error arrays are empty. Navbar/Button page, protocol and cleanup errors are empty. The experimental split's one expected unresolved-role error is preserved as refusal evidence, not suppressed or called a successful visual journey.

The original motion source-before and source-after identities are equal and clean at dce. A subsequent read-only comparison on the clean device worktree checked all **455** Modal bundle source files and all **11** executed test inputs against the hosted hashes. All matched both before and after copying the ZIPs. The entire successor diff is constrained to the new record and its evidence directory; no source, test, dependency, generator, workflow or budget is changed.

The runner used Node v24.22.3 and Chromium 157.0.8103.78. Native RAF/performance observations establish this source-Web scope only. They do not establish physical 120 Hz refresh, frame-budget performance, OS/non-Web behavior, assistive-technology conformance, full-family release acceptance or blanket acceptance of external material work.

## Current strict package-budget failure

The canonical public-build job completed all 47 builds, manifest checks and budget policy controls before the strict whole-entry gate failed. Its exact-dce report is clean and binds 7855 stable source files. Five of nine entries exceed unchanged gzip caps:

| Entry | Gzip bytes | Cap | Excess |
| --- | ---: | ---: | ---: |
| Core | 12,868 | 12,800 | +68 |
| Runtime | 106,768 | 104,300 | +2,468 |
| React | 178,328 | 172,600 | +5,728 |
| Vue | 177,109 | 171,400 | +5,709 |
| Web Component | 213,824 | 207,200 | +6,624 |

Environment, policy and measurement parameters equal the incoming ee report. Eight roots retain identical minified/gzip output and source vectors. Only the Web Component root changes, by +25 minified / +6 gzip bytes, corresponding to the bounded `adapt.ts` repair. No threshold, dependency boundary or measurement was changed. The five failed comparisons remain failed, and this record does not claim the whole workflow is green. Product growth and any governed budget decision remain separate owner work.

## Preserved history and separate scopes

The two older 8882 local native attempts each remain **5/6**. The first failed a cold Dialog acknowledgement at 13.400062476158382 ms against 12 ms. The single controlled fresh recheck failed later Dialog visual-enter capture at 1000 ms, with zero samples inside its original interval. They are never combined. The new dce result belongs to a changed source combination and an independent hosted run, not a third unchanged-input local retry.

The original local graph 5000 ms timeout, four incoming fixture type diagnostics, earlier base-authoring failure and ENOSPC publication failure remain in their original archives. Current hosted graph/types successes are distinct executions. The incoming ee Liquid representative run's four real material assertions and its independent font-install timeout remain separate historical scopes, already preserved in the prior record. This Bootstrap run does not claim those Liquid checks were rerun or repaired.

## Preservation and visual review

The [manifest](evidence/{NAME}/manifest.json) retains the eight original exact-dce ZIPs: motion, controls, Navbar, Button, source, CLI, React and public build. Every ZIP matches GitHub's original digest and byte length and passes CRC. Every member was compared to the independent primary readback. The motion ZIP includes all 13 native JSONs, source/bundle/CSS receipts and 23 PNGs; the other ZIPs retain their complete original outputs and the real budget failure. JSON, scripts, run/job metadata, source-closure readback and original publication/dispatch receipts are compressed losslessly with stored and decompressed hashes. The additional pinned historical-navbar capture has a different source and is described by the original workflow metadata, not counted as exact-dce acceptance. Existing records and their raw originals are untouched.

Three current original PNGs were actually viewed: Dialog entered, AlertDialog entered and Dialog enter-close terminal. The two entered images show their titled panels over the backdrop; the closed terminal shows the underlying page without a residual panel or backdrop. The remaining 494 image files were integrity checked, not visually re-reviewed. The raw native packet SHA-256 is `97cee74b8252a18defd36014f4e3845d1b7cec0f04b5a6c82b884a8edc365c9c`; the device source-closure packet SHA-256 is `7b0528345634f3134bea72c50e1bf4d814c2fc0fed58d527c15988efb1567a6a`.

## Evidence-only successor and follow-up

The parent is the tested dce commit. The successor is limited to this record and its original-evidence directory, with 455+11 input byte equivalence and unchanged older evidence checked before commit. Its prepared tree must match the normally signed commit, hooks remain enabled, and the owned branch is pushed normally after fresh remote/main guards. Standard CI/DCO belongs to that later evidence-only head; the manual run remains attributed to dce. No second full manual workflow is needed merely to restate the same source in a new record.

Documentation checks and actual publication custody are recorded in the successor's ops receipts and live PR. The next product acceptance work is the independently owned package-budget/material scope; this archive does not alter those assertions or authorize merging the PR.
''')
    command(['corepack', 'pnpm@10.32.1', 'exec', 'prettier', '--write', str(RECORD.relative_to(ROOT)), str(manifest_path.relative_to(ROOT))], 'format-record-manifest')
    for item in artifacts:
        stored = (EVIDENCE / item['file']).read_bytes()
        raw = stored if item['encoding'] == 'identity' else gzip.decompress(stored)
        assert sha(stored) == item['storedSha256'] and len(stored) == item['storedBytes']
        assert sha(raw) == item['rawSha256'] and len(raw) == item['rawBytes']
    command(['git', 'add', '--', str(RECORD.relative_to(ROOT)), str(EVIDENCE.relative_to(ROOT))], 'stage-evidence')
    changed = git('diff', '--cached', '--name-only', HEAD).splitlines()
    assert changed and all(p == str(RECORD.relative_to(ROOT)) or p.startswith(str(EVIDENCE.relative_to(ROOT)) + '/') for p in changed)
    assert set(git('diff', '--cached', '--name-status', HEAD).splitlines()) == {'A\t' + p for p in changed}
    assert not git('diff', '--name-only') and not git('ls-files', '--others', '--exclude-standard')
    command(['git', 'diff', '--cached', '--check'], 'whitespace-check')
    tree = git('write-tree')
    candidate = {'head': HEAD, 'tree': tree, 'paths': changed, 'kind': 'evidence-only additive documentation',
                 'testedHead': HEAD, 'record': str(RECORD.relative_to(ROOT)), 'manifest': str(manifest_path.relative_to(ROOT))}
    write_json(OUT / 'candidate-change.json', candidate)
    artifacts_for_handoff = []
    for kind, name in [('authority-map', 'authority-map.json'), ('documentation-scope', 'documentation-scope.json'),
                       ('implementation-authorization', 'implementation-authorization.json'), ('candidate-change', 'candidate-change.json')]:
        p = OUT / name
        artifacts_for_handoff.append({'type': kind, 'reference': str(p), 'digest': 'sha256:' + file_sha(p)})
    inherited = Path(str(ROOT) + '-ops/capability-envelope.json')
    artifacts_for_handoff.append({'type': 'capability-envelope', 'reference': str(inherited), 'digest': 'sha256:' + file_sha(inherited)})
    handoff = {'schemaVersion': 2, 'kind': 'proto-ui.skill-handoff', 'entrypoint': 'development',
               'executionMode': 'human-assisted', 'executionModeSource': 'current-user', 'fromId': 'pui-docs',
               'nextSkillId': 'pui-validate', 'artifacts': artifacts_for_handoff, 'humanGates': [],
               'notes': ['Evidence-only successor. The original dce hosted run remains failed overall because strict budgets failed. No rerun or merge authorization.'],
               'outcome': 'completed', 'binding': {'repositoryId': 'github.com:Proto-UI/Proto-UI',
                   'scopeId': 'sprint6-main-sync-75d5e28a', 'headSha': HEAD, 'reviewInputDigest': None}}
    write_json(OUT / 'docs-handoff.json', handoff)
    command(['corepack', 'pnpm@10.32.1', 'agent:skill', '--', '--handoff', str(OUT / 'docs-handoff.json')], 'validation-route')
    state.update(phase='prepared-for-validation', tree=tree, record=candidate['record'], manifest=candidate['manifest'],
                 recordSha256=file_sha(RECORD), manifestSha256=file_sha(manifest_path), sourceStable=True,
                 addedPaths=changed, artifacts=len(artifacts), rawBytes=sum(x['rawBytes'] for x in artifacts),
                 storedBytes=sum(x['storedBytes'] for x in artifacts), preservedCustodyPaths=len(old_custody),
                 sourceClosures=custody['sourceClosures'], finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
except BaseException as exc:
    state.update(phase='pending-child' if 'pendingChild' in state else 'failed', error=repr(exc), traceback=traceback.format_exc())
save()
