import os,pathlib,subprocess,hashlib,json,datetime,time,signal,traceback,shutil
C=pathlib.Path('/var/tmp/proto-ui-native-scroll-direct-0b7b-20261123-2010')
R=pathlib.Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
E=R/'evidence/integration-20261123-0320/current-1738-sibling-reader-green-01'
F=pathlib.Path('/var/tmp/proto-ui-native-scroll-sibling-green-0b7b-20261123-2044')
G=F/'generated'
HEAD='3d69ba8b3ca877e4b36227e4f8f3c53649f30a49'
TARGET='packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs'
env=os.environ.copy()
env.update({'PATH':str(R/'tools/node-v24.22.3-linux-x64/bin')+':/home/ezra/.cargo/bin:'+env['PATH'],'COREPACK_HOME':str(R/'corepack-cache'),'TMPDIR':'/var/tmp/proto-ui-native-scroll-direct-temp-20261123-2010','CARGO_TARGET_DIR':'/var/tmp/proto-ui-native-scroll-validation-0b7b-20261123-2027/cargo-target','CARGO_BUILD_JOBS':'1','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','GIT_OPTIONAL_LOCKS':'0','GIT_NO_LAZY_FETCH':'1'})
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(name,obj):
 p=E/name;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(obj,indent=2)+'\n');os.replace(t,p)
def command(argv,timeout=60):
 r=subprocess.run(argv,cwd=C,env=env,capture_output=True,text=True,timeout=timeout)
 if r.returncode: raise RuntimeError(json.dumps({'argv':argv,'returncode':r.returncode,'stderr':r.stderr[-4000:]}))
 return r.stdout.strip()
required={
 TARGET:'5685e8f276312e2e195226fa770ee238c3ef3604f70a0804c09f92a86391357e',
 'packages/compiler/test/fixtures/gpui-ordinary-values/Cargo.lock':'a237377fcd0f62c6121102ab048e90dbf751ded989f29241bfde2a13c42992ec',
 'packages/compiler/test/fixtures/gpui-ordinary-values/consumer.rs':'1369d202b40994acd265e7e047f821d0477db765a8bffe769d437000255c06fb',
 'packages/compiler/test/fixtures/gpui-ordinary-values/scroll-reader-consumer.rs':'8e8ed8d5f994163f491fcd9ae91062667d4c5622553e2f87898ead8c6512fd21',
 'packages/compiler/src/gpui-native-owner.ts':'41c7ad5a4bc33882e2c88b1db02d1f8dd2dce0e3c480ac2f7a93bfa6e2e538ce'}
def source_guard():
 h=command(['git','rev-parse','HEAD'],10);assert h==HEAD,('HEAD',h)
 changed=command(['git','diff','--name-only','HEAD','--'],30).splitlines();assert sorted(changed)==sorted(['packages/compiler/src/gpui-native-owner.ts','packages/compiler/test/fixtures/gpui-ordinary-values/scroll-reader-consumer.rs']),changed
 sha={p:digest(C/p) for p in required};assert sha==required,sha
 return {'head':h,'tree':command(['git','rev-parse','HEAD^{tree}'],10),'changedPaths':changed,'sha256':sha}
state={'status':'running','started':now(),'pid':os.getpid(),'checkout':str(C),'evidence':str(E),'fastEvidence':str(F),'budgetSeconds':2700,'stages':[],'scope':'Dynamic tail-prepaint builtin binding guard after actual 4-pass 1-fail reader regression; original full reader and ordinary targets'}
start=time.monotonic();deadline=start+2700;save('status.json',state)
try:
 import difflib
 red=R/'evidence/integration-20261123-0320/current-1738-sibling-reader-red-01'
 rs=json.loads((red/'status.json').read_text());assert rs['status']=='failed' and rs['sourceStable']
 raw=(red/'scroll-reader.log').read_text()
 assert 'test result: FAILED. 4 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out;' in raw
 assert 'an earlier owner prepaint cannot turn raw overscroll into reader arrival' in raw
 assert command(['git','rev-parse','HEAD'],10)==HEAD
 assert not command(['git','diff','--cached','--name-only'],10)
 assert command(['git','diff','--name-only','HEAD','--'],30).splitlines()==['packages/compiler/test/fixtures/gpui-ordinary-values/scroll-reader-consumer.rs']
 ownerpath='packages/compiler/src/gpui-native-owner.ts'
 assert digest(C/ownerpath)=='41c7ad5a4bc33882e2c88b1db02d1f8dd2dce0e3c480ac2f7a93bfa6e2e538ce'
 before=(C/ownerpath).read_text()
 old="// External virtual surfaces establish their real extents while prepainting the\n// slot. Observe and apply deferred requests after those children, not before.\nif owner.borrow().modules.hooks.contains(\"scroll\"){let scrolled=owner.clone();element=element.child(canvas(move|_,window,_|scroll_frame(&scrolled,window),|_,_,_,_|{}).absolute().size_full());}"
 new="// Built-in slot extents settle after their children. An external viewport may\n// be a later sibling; its observation belongs to the paint callback above.\nif owner.borrow().modules.hooks.contains(\"scroll\"){let scrolled=owner.clone();element=element.child(canvas(move|_,window,_|{let builtin=scrolled.borrow().modules.scroll.builtin_projection();if builtin{scroll_frame(&scrolled,window);}},|_,_,_,_|{}).absolute().size_full());}"
 assert before.count(old)==1
 after=before.replace(old,new)
 patch=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+ownerpath,tofile='b/'+ownerpath))
 (E/'owner.before.ts').write_text(before);(E/'owner.after.ts').write_text(after);(E/'product.patch').write_text(patch)
 expected=hashlib.sha256(after.encode()).hexdigest()
 state['application']={'started':now(),'beforeSHA256':digest(C/ownerpath),'expectedAfterSHA256':expected,'patchSHA256':digest(E/'product.patch'),'status':'checking'};save('status.json',state)
 command(['git','apply','--check',str(E/'product.patch')],30)
 state['application']['status']='applying';save('status.json',state)
 command(['git','apply',str(E/'product.patch')],30)
 assert digest(C/ownerpath)==expected
 formatted=command(['corepack','pnpm@10.32.1','exec','prettier','--write',ownerpath],60);(E/'prettier.log').write_text(formatted+'\n')
 assert digest(C/ownerpath)==expected,'formatter changed reviewed source bytes'
 command(['git','diff','--check'],30)
 required[ownerpath]=expected
 state['application'].update({'status':'applied','finished':now(),'afterSHA256':expected,'normalFormatterStable':True})
 save('status.json',state)
 state['sourceBefore']=source_guard();state['versions']={'node':command(['node','--version'],10),'cargo':command(['cargo','+1.98.1','--version'],20)}
 assert state['versions']['node']=='v24.22.3'
 assert state['versions']['cargo'].startswith('cargo 1.98.1 ')
 state['environment']={k:env[k] for k in ['TMPDIR','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG']}
 save('status.json',state)
 steps=[
 ('producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs',str(G)]),
 ('locked-graph',['node','scripts/gpui/check-cargo-graph.mjs','--manifest-path',str(G/'transition/Cargo.toml'),'--git','https://github.com/zed-industries/zed','--rev','62e5991dd0f0c8a3af8d5e7e9c4652490d468db8','--toolchain','1.98.1','--output',str(F/'graph.json')]),
 ('default-sdk-check',['cargo','+1.98.1','check','--locked','--manifest-path',str(G/'transition/Cargo.toml'),'--lib']),
 ('scroll-reader',['cargo','+1.98.1','test','--locked','--manifest-path',str(G/'transition/Cargo.toml'),'--features','test-support','--test','scroll_reader','--','--test-threads=1','--nocapture']),
 ('ordinary',['cargo','+1.98.1','test','--locked','--manifest-path',str(G/'transition/Cargo.toml'),'--features','test-support','--test','ordinary','--','--test-threads=1','--nocapture'])
 ]
 for name,argv in steps:
  source_guard()
  remain=deadline-time.monotonic()
  if remain<=0:raise TimeoutError('Original 45 minute aggregate budget expired before '+name)
  log=F/(name+'.log')
  stage={'name':name,'argv':argv,'started':now(),'status':'running','log':str(log),'remainingBudgetSeconds':remain}
  state['stages'].append(stage);state['currentStage']=name
  with log.open('xb') as out:
   proc=subprocess.Popen(argv,cwd=C,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
   stage['pid']=proc.pid;stage['pgid']=proc.pid;save('status.json',state)
   try:rc=proc.wait(timeout=remain)
   except subprocess.TimeoutExpired:
    stage['timedOut']=True
    os.killpg(proc.pid,signal.SIGTERM)
    try:proc.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=10)
    rc=proc.returncode
  stage.update({'finished':now(),'exitCode':rc,'status':'passed' if rc==0 and not stage.get('timedOut') else 'failed','logSHA256':digest(log),'logBytes':log.stat().st_size})
  shutil.copyfile(log,E/(name+'.log'))
  save('status.json',state)
  if stage['status']!='passed':raise RuntimeError('Stage failed: '+name)
 state['sourceAfter']=source_guard();assert state['sourceBefore']==state['sourceAfter']
 graph=F/'graph.json'
 if graph.exists():shutil.copyfile(graph,E/'graph.json');state['graphSHA256']=digest(graph)
 state['status']='passed';state['sourceStable']=True
except BaseException as ex:
 state['status']='failed';state['error']=repr(ex);state['traceback']=traceback.format_exc()
 try:state['sourceAfter']=source_guard();state['sourceStable']=state.get('sourceBefore')==state['sourceAfter']
 except BaseException as guard:state['sourceGuardError']=repr(guard)
finally:
 state['finished']=now();state['elapsedSeconds']=time.monotonic()-start;state.pop('currentStage',None);save('status.json',state)
 print(json.dumps(state),flush=True)
