import subprocess,json,time
from pathlib import Path
b=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence')
results=[]
for directory,script,log in [('continuation-s5-shenko-4deb','run-browser.py','run-browser-v2.log'),('continuation-s3-image-4deb','run-diagnostic-baseline.py','run-diagnostic-baseline-v2.log')]:
 e=b/directory
 print('RUN',directory,time.time(),flush=True)
 with (e/log).open('w') as f: p=subprocess.run(['python3','-u',str(e/script)],stdout=f,stderr=subprocess.STDOUT)
 results.append({'directory':directory,'exitCode':p.returncode,'at':time.time()})
 print(results[-1],flush=True)
 (b/'continuation-s5-shenko-4deb'/'serial-v2-results.json').write_text(json.dumps(results,indent=2)+'\n')
