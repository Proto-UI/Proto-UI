from pathlib import Path
import subprocess,os,json,time,fcntl,hashlib,traceback
b=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono');w=b/'continuation-s4-4deb';a=b/'continuation-s5-shenko-full-4deb';e=b/'evidence/continuation-s5-shenko-4deb';o=e/'browser';o.mkdir(exist_ok=True);tmp=e/'tmp';tmp.mkdir(exist_ok=True); short_tmp=Path('/tmp/pui-s345-4deb'); short_tmp.symlink_to(tmp) if not short_tmp.exists() else None; assert short_tmp.resolve()==tmp.resolve(); tmp=short_tmp
env=os.environ.copy();env.update(PATH=str(b/'tools/node-v24.22.3-linux-x64/bin')+':'+env['PATH'],COREPACK_HOME=str(b/'corepack-cache'),TMPDIR=str(tmp),PUI_SHENKO_SOURCE=str(a),PUI_EVIDENCE_DIR=str(o),PUI_CHROME_EXECUTABLE=str(b/'tools/playwright-browsers/chromium-1208/chrome-linux64/chrome'))
r={'kind':'sprint5-shenko-original-observer-command','compiler':'f329d98d1d34fe426ff88db1f6175c72a92e4019','application':'f3fa6f4d8bf22cfd2baf490d9c3a08bd39af4d42','command':['node','--import','tsx','scripts/analysis/shenko-consumer-browser.mts'],'cwd':str(w),'temporaryDirectory':str(tmp)}
try:
 locks=[]
 for name in ['proto-ui-heavy-acceptance.lock','proto-ui-heavy-validation.lock']:
  f=open('/tmp/'+name,'a');locks.append(f);print('WAIT LOCK',name,flush=True);fcntl.flock(f,fcntl.LOCK_EX)
 print('RUN BROWSER',flush=True);t=time.time()
 with (e/'browser.stdout.log').open('wb') as out,(e/'browser.stderr.log').open('wb') as err:p=subprocess.run(r['command'],cwd=w,env=env,stdout=out,stderr=err)
 r.update(exitCode=p.returncode,seconds=round(time.time()-t,3))
 r['stdoutSha256']=hashlib.sha256((e/'browser.stdout.log').read_bytes()).hexdigest();r['stderrSha256']=hashlib.sha256((e/'browser.stderr.log').read_bytes()).hexdigest()
except Exception as ex:r['failure']=str(ex);traceback.print_exc()
finally:(e/'browser-command.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
