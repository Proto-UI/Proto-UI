from pathlib import Path
import json,subprocess,os,hashlib,time,datetime,traceback
B=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
E=B/'evidence/continuation-s5-shenko-4deb/navigation-paint-03'
R=B/'continuation-s4-4deb'
E.mkdir(exist_ok=True)
receipt=E/'command.json'
if receipt.exists():raise RuntimeError('Existing receipt; reconcile rather than repeat')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
env=os.environ.copy();env['PATH']=str(B/'tools/node-v24.22.3-linux-x64/bin')+':'+env['PATH'];env['COREPACK_HOME']=str(B/'corepack-cache')
tmp=B/'evidence/continuation-s5-shenko-4deb/tmp';tmp.mkdir(exist_ok=True)
link=Path('/tmp/pui-s345-shenko-4deb')
if link.is_symlink():assert link.resolve()==tmp
elif link.exists():raise RuntimeError('Owned temporary symlink path unexpectedly occupied')
else:link.symlink_to(tmp,target_is_directory=True)
env['TMPDIR']=str(link);env['PUI_COMPILER_SOURCE']=str(R);env['PUI_SHENKO_SOURCE']=str(B/'continuation-s5-shenko-full-4deb');env['PUI_EVIDENCE_DIR']=str(E)
env['PUI_CHROME_EXECUTABLE']=str(B/'tools/playwright-browsers/chromium-1208/chrome-linux64/chrome')
script=E.parent/'shenko-navigation-paint-diagnostic.mts'
command=['node','--import','tsx',str(script)]
state={'schemaVersion':1,'startedAt':now(),'kind':'original-five-journeys-with-additional-six-frame-navigation-paint-diagnostic','command':command,'cwd':str(R),'observerSha256':hashlib.sha256(script.read_bytes()).hexdigest(),'scope':'Frozen compiler f329d98 and App f3fa6f4. Do not equate this with current App main or PR389.'}
receipt.write_text(json.dumps(state,indent=2)+'\n')
try:
 start=time.monotonic()
 with (E/'stdout.log').open('wb') as f:
  p=subprocess.Popen(command,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT);state['pid']=p.pid;receipt.write_text(json.dumps(state,indent=2)+'\n');code=p.wait()
 state.update(exitCode=code,elapsedSeconds=time.monotonic()-start,logSha256=hashlib.sha256((E/'stdout.log').read_bytes()).hexdigest())
 if (E/'receipt.json').is_file():state['observerReceiptSha256']=hashlib.sha256((E/'receipt.json').read_bytes()).hexdigest()
except BaseException as ex:state['error']=repr(ex);state['traceback']=traceback.format_exc()
finally:state['finishedAt']=now();receipt.write_text(json.dumps(state,indent=2)+'\n')
