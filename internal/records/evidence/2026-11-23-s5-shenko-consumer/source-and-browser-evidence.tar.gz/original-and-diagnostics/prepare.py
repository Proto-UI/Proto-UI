from pathlib import Path
import subprocess,os,json,time,datetime,hashlib,fcntl
base=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
work=base/'continuation-s4-4deb';app=base/'continuation-s5-shenko-4deb';out=base/'evidence/continuation-s5-shenko-4deb'
env=os.environ.copy();env.update({'PATH':str(base/'tools/node-v24.22.3-linux-x64/bin')+':/home/ezra/.cargo/bin:'+env['PATH'],'COREPACK_HOME':str(base/'corepack-cache'),'NODE_OPTIONS':'','NODE_PATH':''})
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(cwd,*args):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
report={'kind':'sprint5-shenko-original-consumer-preparation-v1','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compilerHead':git(work,'rev-parse','HEAD'),'compilerTree':git(work,'rev-parse','HEAD^{tree}'),'compilerLockSha256':sha(work/'pnpm-lock.yaml'),'applicationHead':'f3fa6f4d8bf22cfd2baf490d9c3a08bd39af4d42','commands':[],'scope':'Frozen real Shenko app with explicit temporary compiler pin; no application main adoption or live model/backend journey.'}
def write(): (out/'pre-browser.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,args,cwd,extra=None,timeout=1800):
 print('RUN',name,args,flush=True);start=time.monotonic();e=env.copy();e.update(extra or {})
 with (out/(name+'.stdout.log')).open('w') as stdout,(out/(name+'.stderr.log')).open('w') as stderr:
  p=subprocess.run(args,cwd=cwd,env=e,stdout=stdout,stderr=stderr,timeout=timeout)
 row={'name':name,'command':args,'cwd':str(cwd),'exitCode':p.returncode,'seconds':round(time.monotonic()-start,3),'stdoutSha256':sha(out/(name+'.stdout.log')),'stderrSha256':sha(out/(name+'.stderr.log'))}
 report['commands'].append(row);write();print(json.dumps(row),flush=True);return p.returncode
assert report['compilerHead']=='f329d98d1d34fe426ff88db1f6175c72a92e4019'
assert git(work,'status','--porcelain')==''
assert not app.exists()
assert run('clone',['git','clone','--shared','--no-checkout',str(base/'shenko'),str(app)],base)==0
assert run('checkout',['git','checkout','--detach',report['applicationHead']],app)==0
assert git(app,'status','--porcelain')==''
web=app/'crates/shenko-ui/web'
files=git(app,'ls-files','crates/shenko-ui/web').splitlines()
authored=[f for f in files if not f.endswith('/upstream-pin.json')]
report['authoredSources']=[{'path':f,'sha256':sha(app/f)} for f in authored]
report['originalPin']=json.loads((web/'upstream-pin.json').read_text());(out/'upstream-pin.original.json').write_bytes((web/'upstream-pin.json').read_bytes());write()
install=run('app-frozen-offline-install',['corepack','pnpm@10.32.1','install','--offline','--frozen-lockfile','--ignore-scripts'],web)
if install!=0: assert run('app-frozen-online-install',['corepack','pnpm@10.32.1','install','--frozen-lockfile','--ignore-scripts'],web)==0
locks=[]
for name in ['proto-ui-heavy-acceptance.lock','proto-ui-heavy-validation.lock']:
 f=open('/tmp/'+name,'a+');print('WAIT LOCK',name,flush=True);fcntl.flock(f,fcntl.LOCK_EX);locks.append(f)
report['locks']=[f.name for f in locks];write()
try:
 assert run('upstream-style-generator',['corepack','pnpm@10.32.1','styles:variant-order:generate'],work)==0
 assert run('upstream-public-build',['node','scripts/build/public-packages.mjs','--package','@proto.ui/adapter-react','--package','@proto.ui/prototypes-shadcn','--package','@proto.ui/cli','--json'],work)==0
 public=json.loads((out/'upstream-public-build.stdout.log').read_text());report['publicBuild']={'packageCount':public['packageCount'],'selectedCount':public['selectedCount'],'resultsCount':len(public['results'])}
 pin=dict(report['originalPin']);pin['commit']=report['compilerHead'];pin['lock_sha256']=report['compilerLockSha256'];(web/'upstream-pin.json').write_text(json.dumps(pin,indent=2)+'\n');report['candidatePin']=pin;(out/'upstream-pin.candidate.json').write_bytes((web/'upstream-pin.json').read_bytes());write()
 appenv={'PROTO_UI_SOURCE':str(work)}
 if public['selectedCount']==42 and len(public['results'])==42:appenv['PROTO_UI_BUILD_RECEIPT']=str(out/'upstream-public-build.stdout.log')
 assert run('original-app-producer',['node','build.mjs'],web,appenv)==0
 assert run('original-app-types',['corepack','pnpm@10.32.1','exec','tsc','--noEmit'],web,appenv)==0
 tests=sorted('tests/'+p.name for p in (web/'tests').glob('*.test.mjs'))
 assert run('original-app-tests',['node','--test',*tests],web,appenv)==0
 for f in report['authoredSources']:assert sha(app/f['path'])==f['sha256'],f['path']
 assert git(work,'status','--porcelain')==''
 assert git(work,'rev-parse','HEAD')==report['compilerHead']
 report['applicationDiffSha256']=hashlib.sha256(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=app)).hexdigest()
 report['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();report['result']='ready for unchanged final browser observer';write()
 print('READY_BROWSER',flush=True)
finally:
 for f in reversed(locks):fcntl.flock(f,fcntl.LOCK_UN);f.close()
