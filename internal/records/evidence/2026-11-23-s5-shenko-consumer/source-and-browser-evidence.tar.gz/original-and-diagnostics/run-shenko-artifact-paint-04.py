from pathlib import Path
import json,subprocess,os,hashlib,time,datetime,traceback,signal
B=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
E=B/'evidence/continuation-s5-shenko-4deb/navigation-paint-artifact-04'
R=B/'continuation-s4-4deb'
E.mkdir(exist_ok=True)
receipt=E/'command.json'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
with (E/'start.json').open('x') as f:f.write(json.dumps({'startedAt':now(),'pid':os.getpid(),'kind':'artifact-only-frozen-build-diagnostic'})+'\n')
env=os.environ.copy();env['PATH']=str(B/'tools/node-v24.22.3-linux-x64/bin')+':'+env['PATH'];env['COREPACK_HOME']=str(B/'corepack-cache')
tmp=B/'evidence/continuation-s5-shenko-4deb/tmp';tmp.mkdir(exist_ok=True)
link=Path('/tmp/pui-s345-shenko-4deb')
if link.is_symlink():assert link.resolve()==tmp
elif link.exists():raise RuntimeError('Owned temporary symlink path unexpectedly occupied')
else:link.symlink_to(tmp,target_is_directory=True)
env['TMPDIR']=str(link);env['PUI_COMPILER_SOURCE']=str(R);env['PUI_SHENKO_SOURCE']=str(B/'continuation-s5-shenko-full-4deb');env['PUI_EVIDENCE_DIR']=str(E)
env['PUI_CHROME_EXECUTABLE']=str(B/'tools/playwright-browsers/chromium-1208/chrome-linux64/chrome')
script=E.parent/'shenko-artifact-paint-observer-04.mts'
command=[str(B/'tools/node-v24.22.3-linux-x64/bin/node'),'--experimental-strip-types',str(script)]
state={'schemaVersion':1,'startedAt':now(),'kind':'retained-source-bound-artifact-five-journeys-additional-six-frame-paint-observer','command':command,'cwd':str(R),'observerSha256':hashlib.sha256(script.read_bytes()).hexdigest(),'scope':'Exact retained build-manifest and all memory-served bytes from actual original compiler f329d98 / App f3fa6f4 five-case pass. Original receipt rechecked. No fresh source checkout validation or build; no current-main/PR389 claim. Original diagnostic03 git30s timeout preserved. Native browser actions/default 15000ms unchanged. Node24 builtin type erasure only.','outerDiagnosticBudgetSeconds':900}
receipt.write_text(json.dumps(state,indent=2)+'\n')
p=None
try:
 start=time.monotonic()
 with (E/'stdout.log').open('wb') as f:
  p=subprocess.Popen(command,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);state['pid']=p.pid;receipt.write_text(json.dumps(state,indent=2)+'\n')
  try:code=p.wait(timeout=900)
  except subprocess.TimeoutExpired:
   state['outerDiagnosticTimeout']=True
   os.killpg(p.pid,signal.SIGTERM)
   try:code=p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
 state.update(exitCode=code,elapsedSeconds=time.monotonic()-start,logSha256=hashlib.sha256((E/'stdout.log').read_bytes()).hexdigest())
 if (E/'receipt.json').is_file():state['observerReceiptSha256']=hashlib.sha256((E/'receipt.json').read_bytes()).hexdigest()
except BaseException as ex:state['error']=repr(ex);state['traceback']=traceback.format_exc()
finally:state['finishedAt']=now();receipt.write_text(json.dumps(state,indent=2)+'\n')
