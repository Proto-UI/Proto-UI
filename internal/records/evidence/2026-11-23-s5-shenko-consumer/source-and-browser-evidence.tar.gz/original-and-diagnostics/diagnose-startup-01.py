from pathlib import Path
import subprocess,os,time,json,hashlib
b=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono');w=b/'continuation-s4-4deb';a=b/'continuation-s5-shenko-full-4deb';e=b/'evidence/continuation-s5-shenko-4deb'
env=os.environ.copy();env.update(PATH=str(b/'tools/node-v24.22.3-linux-x64/bin')+':'+env['PATH'],COREPACK_HOME=str(b/'corepack-cache'))
commands=[(w,['node','--version']),(w,['corepack','pnpm@10.32.1','--version']),(w,['git','diff','--name-only','-z','HEAD']),(w,['git','ls-files','--others','--exclude-standard','-z','--','packages','scripts/compiler']),(a,['git','diff','--name-only','-z','HEAD']),(a,['git','ls-files','--others','--exclude-standard','-z']),(a,['git','diff','--binary','HEAD']),(w,['df','-h','/tmp','/home/ezra','/dev/shm'])]
results=[]
for cwd,cmd in commands:
 t=time.time();r={'cwd':str(cwd),'command':cmd}
 print('RUN',cmd,flush=True)
 try:
  p=subprocess.run(cmd,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
  r.update(exitCode=p.returncode,stdoutBytes=len(p.stdout),stdoutSha256=hashlib.sha256(p.stdout).hexdigest(),stderr=p.stderr.decode(errors='replace')[-1000:])
  if cmd[0]!='git':r['stdout']=p.stdout.decode(errors='replace')
 except subprocess.TimeoutExpired as ex:r.update(timeoutSeconds=30,stderr=str(ex))
 r['seconds']=time.time()-t;results.append(r);print(json.dumps(r),flush=True)
 (e/'diagnose-startup-01.json').write_text(json.dumps(results,indent=2))
