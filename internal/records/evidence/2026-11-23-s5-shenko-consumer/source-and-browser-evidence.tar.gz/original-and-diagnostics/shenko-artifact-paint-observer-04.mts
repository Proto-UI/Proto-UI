import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createServer } from 'node:http';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(process.env.PUI_COMPILER_SOURCE!);
const application = path.resolve(process.env.PUI_SHENKO_SOURCE!);
const evidence = path.resolve(process.env.PUI_EVIDENCE_DIR!);
const assets = path.join(application, 'crates/shenko-ui/src/static');
const sha256 = (bytes: string | Uint8Array) => createHash('sha256').update(bytes).digest('hex');
await mkdir(evidence, { recursive: true });
const expectedIndex = "<!DOCTYPE html>\n<html lang=\"zh\" class=\"dark\" data-theme=\"dark\">\n<head>\n  <meta charset=\"UTF-8\">\n  <meta name=\"viewport\" content=\"width=device-width,initial-scale=1,viewport-fit=cover\">\n  <meta name=\"theme-color\" content=\"#15171f\">\n  <meta name=\"description\" content=\"Shenko Web 界面\">\n  <title>Shenko</title>\n  <!-- The theme is decided BEFORE the first paint: a reader who prefers the\n       light scheme must not see a dark frame flash by. The rules are the\n       shell's own (query, stored choice, then the system preference), so the\n       bootstrap and the controller agree on the first frame. -->\n  <script id=\"theme-bootstrap\" src=\"/assets/theme-bootstrap.js\"></script>\n  <link rel=\"stylesheet\" href=\"/assets/proto-ui-style.css\">\n  <link rel=\"stylesheet\" href=\"/assets/app.css\">\n  <script type=\"module\" src=\"/assets/app.js\"></script>\n</head>\n<body>\n  <div id=\"app\"></div>\n  <noscript><p style=\"padding:2rem;font-family:sans-serif\">Shenko 的正式界面需要启用 JavaScript。数据与恢复接口仍可由同一 Rust 服务访问。</p></noscript>\n</body>\n</html>\n";
const expectedManifest = '1a00e0a2e2fd7b910f508bf2fe22d11f05ecd00b6ff2387be3908dec4e79acc2';
const frozenAssets = new Map<string, Buffer>();
const served = new Map<string, number>();
const report: any = {
  kind: 'shenko-retained-build-navigation-paint-diagnostic-v2',
  capturedAt: new Date().toISOString(),
  originCompilerHead: 'f329d98d1d34fe426ff88db1f6175c72a92e4019',
  originCompilerTree: '9a713e073590429a4f930f9ca6c9d7ffaa0e3eb4',
  originApplicationHead: 'f3fa6f4d8bf22cfd2baf490d9c3a08bd39af4d42',
  originalFullSourceBrowserReceiptSha256: 'a1c5b3475160c68561b1ba2d3ac576c37920c1ba279b4f59528e62ed435df1a7',
  originalSourceGuardDiagnostic03: {exitCode:1,cases:0,error:'Error: spawnSync git ETIMEDOUT'},
  sourceCheckoutRevalidated: false,
  originalObserverSha256: '6cf516419c662ac04f7565a155f84ec5d13ca8e72bd426b6693be7dc38e208e7',
  paintDiagnostic03Sha256: 'c4250563b681e77e9f23d0251243fd92ad4cc8d4b66696b5fea5e2b0253d2660',
  observerSha256: sha256(await readFile(fileURLToPath(import.meta.url))),
  boundary: 'Replays only exact in-memory build assets matching the original successful source-bound receipt. Frozen f3fa6f4 application index is independently read at its pinned Git blob f347cef0dc1e0575064730f42c16ecd3b35dc3c8. Does not revalidate the working source checkout, publish a new build, validate current App main/PR389, or replace the original five-case receipt. Explicit demo-controller data; no live backend/model, OS hardware, or assistive technology.',
  cases: [],
};
let browser: any;
let page: any;
const errors: string[] = [];
const sockets: string[] = [];
const phase = async (value: string) => writeFile(path.join(evidence, 'phase.json'), JSON.stringify({phase:value,at:new Date().toISOString()})+'\n');
const server = createServer((request, response) => {
  try {
    const pathname = decodeURIComponent(new URL(request.url!, 'http://127.0.0.1').pathname);
    const file = frozenAssets.get(pathname);
    if (!file) {response.writeHead(404).end();return;}
    served.set(pathname,(served.get(pathname)??0)+1);
    const mime: Record<string,string> = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.svg':'image/svg+xml'};
    response.writeHead(200, {'Content-Type':mime[path.extname(pathname==='/'?'index.html':pathname)]??'application/octet-stream'});
    response.end(file);
  } catch { if (!response.headersSent) response.writeHead(404);response.end(); }
});
async function step(name: string, run: () => Promise<void>) {
  const started = performance.now();
  try {
    await run();
    report.cases.push({
      name,
      status: 'passed',
      elapsedMs: Math.round(performance.now() - started),
    });
  } catch (error) {
    report.cases.push({ name, status: 'failed', error: String(error) });
    await page?.screenshot({ path: path.join(evidence, `${name}-failure.png`) }).catch(() => {});
  }
}

try {
  await phase('verifying-retained-artifacts');
  const originalReceiptBytes=await readFile(path.join(path.dirname(evidence),'browser-attempt-02/receipt.json'));
  assert.equal(sha256(originalReceiptBytes),report.originalFullSourceBrowserReceiptSha256,'original full-source five-case evidence identity');
  const originalReceipt=JSON.parse(originalReceiptBytes.toString('utf8'));
  assert.equal(originalReceipt.passed,true);
  assert.equal(originalReceipt.cases.length,5);
  assert.ok(originalReceipt.cases.every((item:any)=>item.status==='passed'));
  assert.equal(originalReceipt.compilerHead,report.originCompilerHead);
  assert.equal(originalReceipt.compilerTree,report.originCompilerTree);
  assert.equal(originalReceipt.applicationHead,report.originApplicationHead);
  assert.equal(originalReceipt.buildManifestSha256,expectedManifest);
  await writeFile(path.join(evidence,'original-browser-02-receipt.json'),originalReceiptBytes);
  const manifestBytes = await readFile(path.join(assets, 'build-manifest.json'));
  assert.equal(sha256(manifestBytes),expectedManifest,'the served build manifest must be the original verified one');
  const manifest = JSON.parse(manifestBytes.toString('utf8'));
  assert.equal(manifest.upstream.commit,report.originCompilerHead);
  assert.deepEqual(manifest.realisation.compiled,['transport-badge','message-bubble']);
  assert.equal(manifest.realisation.adapter.length,9);
  assert.equal(manifest.compiler.runtime_imported,false);
  const indexBytes = await readFile(path.join(application,'crates/shenko-ui/src/index.html'));
  assert.equal(indexBytes.toString('utf8'),expectedIndex,'actual app index must equal pinned f3 source bytes');
  frozenAssets.set('/',indexBytes);
  report.indexSha256=sha256(indexBytes);
  report.buildManifestSha256=sha256(manifestBytes);
  report.assetHashes={};
  for(const [file,artifact] of Object.entries(manifest.artifacts) as [string,any][]) {
    const absolute=path.resolve(assets,file);
    const relative=path.relative(assets,absolute);
    assert.ok(!relative.startsWith('..')&&!path.isAbsolute(relative),'artifact path stays inside static root');
    const bytes=await readFile(absolute);
    assert.equal(sha256(bytes),artifact.sha256,file);
    frozenAssets.set('/assets/'+file,bytes);
    report.assetHashes['/assets/'+file]={bytes:bytes.length,sha256:sha256(bytes)};
  }
  await writeFile(path.join(evidence,'build-manifest.json'),manifestBytes);
  await phase('loading-browser-driver');
  const require = createRequire(path.join(root,'apps/www/package.json'));
  const {chromium}=require('playwright-core');
  await phase('starting-browser');
  await new Promise<void>((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  const address = server.address();
  assert.ok(address && typeof address === 'object');
  const url = `http://127.0.0.1:${address.port}/?demo=1&theme=light`;
  browser = await chromium.launch({
    executablePath: process.env.PUI_CHROME_EXECUTABLE ?? '/usr/bin/chromium',
    headless: true,
    chromiumSandbox: true,
  });
  report.browser = browser.version();
  page = await browser.newPage({ viewport: { width: 1280, height: 900 }, locale: 'zh-CN' });
  page.on('pageerror', (error: Error) => errors.push(error.message));
  page.on('websocket', (socket: any) => sockets.push(socket.url()));
  page.setDefaultTimeout(15_000);
  await page.goto(url, { waitUntil: 'networkidle' });
  await step('compiled-badge-and-native-react-slot-content', async () => {
    await page.locator('.shell[data-source="demo"]').waitFor();
    await page.locator('[data-pui-style~="shenko-status-chip"]').waitFor();
    assert.equal(
      await page.locator('[data-pui-style~="shenko-status-chip"]').innerText(),
      '本地模拟'
    );
    await page.locator('[data-pui-style~="shenko-bubble"]').first().waitFor();
    assert.ok((await page.locator('[data-pui-style~="shenko-bubble"]').count()) > 1);
    assert.ok(
      (await page.locator('[data-pui-style~="shenko-bubble"]').first().innerText()).trim().length >
        0
    );
    assert.ok(
      (await page
        .locator(
          '[data-pui-style~="shenko-bubble"] .bubble-text, [data-pui-style~="shenko-bubble"] .md'
        )
        .count()) > 0
    );
    await page.screenshot({ path: path.join(evidence, 'shenko-chat-light.png') });
  });
  await step('real-adapter-theme-action-retains-compiled-root-node', async () => {
    const badge = await page.locator('[data-pui-style~="shenko-status-chip"]').elementHandle();
    assert.ok(badge);
    await page.getByRole('button', { name: '切换到深色', exact: true }).click();
    await page.waitForFunction(() => document.documentElement.dataset.theme === 'dark');
    assert.equal(await badge.evaluate((element: HTMLElement) => element.isConnected), true);
    assert.equal(
      await page.locator('[data-pui-style~="shenko-status-chip"]').innerText(),
      '本地模拟'
    );
    await page.screenshot({ path: path.join(evidence, 'shenko-chat-dark.png') });
  });
  await step('real-thread-selection-replaces-bubbles-and-keeps-native-children', async () => {
    const old = await page.locator('[data-pui-style~="shenko-bubble"]').first().elementHandle();
    const title = await page.locator('.im-thread').getAttribute('aria-label');
    assert.ok((await page.locator('.im-list .im-row').count()) > 1);
    await page.locator('.im-list .im-row').nth(1).click();
    await page.waitForFunction(
      (previous: string) =>
        document.querySelector('.im-thread')?.getAttribute('aria-label') !== previous,
      title
    );
    assert.equal(await old.evaluate((element: HTMLElement) => element.isConnected), false);
    await page.locator('[data-pui-style~="shenko-bubble"]').first().waitFor();
    assert.ok(
      (await page.locator('[data-pui-style~="shenko-bubble"]').first().innerText()).trim().length >
        0
    );
  });
  await step('real-view-navigation-removes-and-restores-compiled-roots', async () => {
    const old = await page.locator('[data-pui-style~="shenko-bubble"]').first().elementHandle();
    const badge = await page.locator('[data-pui-style~="shenko-status-chip"]').elementHandle();
    await page.locator('.topbar .tabs').getByText('Inspect', { exact: true }).click();
    await page.locator('.stream[data-tab="inspect"]').waitFor();
    assert.equal(await old.evaluate((element: HTMLElement) => element.isConnected), false);
    assert.equal(await badge.evaluate((element: HTMLElement) => element.isConnected), true);
    await page.locator('.topbar .tabs').getByText('对话', { exact: true }).click();
    await page
      .locator('.stream[data-tab="im"] [data-pui-style~="shenko-bubble"]')
      .first()
      .waitFor();
    report.navigationPaintSamples = await page.evaluate(`new Promise((resolve) => {
      const rows = [];
      const sample = (time) => {
        const tabs = [...document.querySelectorAll('.topbar .tab-item')].map((element) => {
          const style = getComputedStyle(element);
          const exposed = element.getExposes?.();
          return {
            text: element.textContent.trim(),
            active: element.hasAttribute('data-active'),
            activeValue: element.getAttribute('data-active'),
            pressed: element.getAttribute('aria-pressed'),
            selected: element.getAttribute('aria-selected'),
            tokens: element.getAttribute('data-pui-style'),
            background: style.backgroundColor,
            color: style.color,
            shadow: style.boxShadow,
            exposeActive: exposed?.active?.get?.() ?? null,
            revealing: element.getAttribute('data-pui-view-revealing'),
            pending: element.hasAttribute('data-pui-view-pending')
          };
        });
        rows.push({time, view: document.querySelector('.stream')?.getAttribute('data-tab'), tabs});
        if(rows.length === 6) resolve(rows);
        else requestAnimationFrame(sample);
      };
      requestAnimationFrame(sample);
    })`);
    const settledPaint = report.navigationPaintSamples.at(-1);
    assert.equal(settledPaint.view, 'im');
    assert.deepEqual(
      settledPaint.tabs.filter((tab: any) => tab.active).map((tab: any) => tab.text),
      ['对话'],
      'the selected navigation projection must agree with the visible conversation after real frames'
    );
    assert.deepEqual(
      settledPaint.tabs.filter((tab: any) => tab.pressed === 'true').map((tab: any) => tab.text),
      ['对话'],
      'the native pressed projection must agree with the selected navigation item'
    );
    await page.screenshot({ path: path.join(evidence, 'shenko-returned-chat.png') });
  });
  await step('synthetic-pagehide-invokes-actual-application-disposal', async () => {
    await page.evaluate(() => window.dispatchEvent(new Event('pagehide')));
    await page.waitForFunction(() => document.querySelector('#app')?.childElementCount === 0);
  });
  assert.deepEqual(sockets, [], 'the explicit demo route must not start the live controller');
  assert.deepEqual(errors, [], 'the actual application must not raise browser exceptions');

  for (const [route,bytes] of frozenAssets) {
    assert.equal(sha256(bytes),route==='/'?report.indexSha256:report.assetHashes[route].sha256,'served memory bytes changed: '+route);
  }
  report.served=Object.fromEntries(served);
} catch (error) {
  report.failure = String(error);
  await page
    ?.screenshot({ path: path.join(evidence, 'startup-or-terminal-failure.png') })
    .catch(() => {});
} finally {
  report.pageErrors = errors;
  report.webSockets = sockets;
  const cleanupErrors: string[] = [];
  try {
    await browser?.close();
  } catch (error) {
    cleanupErrors.push(`browser: ${String(error)}`);
  }
  try {
    if (server.listening)
      await new Promise<void>((resolve, reject) =>
        server.close((error) => (error ? reject(error) : resolve()))
      );
  } catch (error) {
    cleanupErrors.push(`server: ${String(error)}`);
  }
  report.cleanupErrors = cleanupErrors;
  report.passed =
    !report.failure &&
    errors.length === 0 &&
    sockets.length === 0 &&
    cleanupErrors.length === 0 &&
    report.cases.length === 5 &&
    report.cases.every((item: any) => item.status === 'passed');
  await writeFile(path.join(evidence, 'receipt.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(
    JSON.stringify(
      {
        originCompilerHead: report.originCompilerHead,
        originApplicationHead: report.originApplicationHead,
        passed: report.passed,
        cases: report.cases,
        failure: report.failure,
      },
      null,
      2
    )
  );
  if (!report.passed) process.exitCode = 1;
}
