from pathlib import Path
import os,json,hashlib,subprocess,time,datetime,traceback
B=Path("/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono");R=Path("/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/continuation-s3-image-4deb");E=Path("/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/continuation-s3-image-4deb");O=E/'portal-native-13';O.mkdir(exist_ok=False)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
with (O/'start.json').open('x') as f:f.write(json.dumps({'pid':os.getpid(),'at':now()})+'\n')
pre=json.loads("{\"path\":\"apps/www/src/components/documentation-image-reading-viewport.proto.ts\",\"prerequisiteCommit\":\"424a78e560bd9878da1ca4a7e1ae44b0fa3740b7\",\"expectedBeforeBlob\":\"77c2d12ddd3c66dcc41b0efa961652d48fc37bc6\",\"blob\":\"78e758dba432fa3a8022adeead6d25bc12a6cd20\",\"sha256\":\"38c40b79ba99dc444a43376052de3c39798f99db7eb965eb990eadc4d6cc77ec\",\"content\":\"import { definePrototype, tw } from '@proto.ui/core';\\nimport { asAccessible, asScrollSurface } from '@proto.ui/hooks';\\nimport {\\n  asScrollAreaViewport,\\n  type ScrollAreaViewportExposes,\\n  type ScrollAreaViewportProps,\\n} from '@proto.ui/prototypes-base/scroll-area';\\n\\nexport interface DocumentationImageReadingViewportProps extends ScrollAreaViewportProps {\\n  a11yLabel?: string;\\n}\\n\\nconst DEFAULT_LABEL = 'Illustration reading viewport';\\n\\n/** App presentation of the public ScrollArea Viewport, composed inside its\\n * public Root. Base geometry owns sequential navigation; the native scroll\\n * projection owns wheel and keyboard scrolling on the same surface lease. */\\nexport default definePrototype<DocumentationImageReadingViewportProps, ScrollAreaViewportExposes>({\\n  name: 'docs-image-reading-viewport',\\n  modules: asScrollAreaViewport.modules,\\n  setup(def) {\\n    def.props.define({ a11yLabel: { type: 'string', empty: 'fallback' } });\\n    def.props.setDefaults({ a11yLabel: DEFAULT_LABEL });\\n\\n    const inherited = asScrollAreaViewport();\\n    const state = inherited.stateHandles;\\n    if (!state) throw new Error('[docs-image-reading-viewport] Missing Base scroll facts.');\\n    asScrollSurface().configure({ projection: 'system' });\\n\\n    const accessible = asAccessible();\\n    const label = def.state.string('readingViewportLabel', DEFAULT_LABEL);\\n    accessible.role('region');\\n    accessible.name(label);\\n    def.lifecycle.onCreated((run) => {\\n      label.set(run.props.get().a11yLabel ?? DEFAULT_LABEL, 'reading viewport label');\\n    });\\n    def.props.watch(['a11yLabel'], (_run, next) => {\\n      label.set(next.a11yLabel ?? DEFAULT_LABEL, 'reading viewport label');\\n    });\\n\\n    def.feedback.style.use(tw('block min-h-0 min-w-0 h-full w-full outline-none'));\\n    def.rule({\\n      when: (w) => w.state(state.focusVisible).eq(true),\\n      intent: (i) => i.feedback.style.use(tw('outline-2 outline-ring forced-colors-focus-outline')),\\n    });\\n    return inherited.render;\\n  },\\n});\\n\"}")
state={'kind':'candidate03-complete-original-image32-S4-24-theme9','startedAt':now(),'pid':os.getpid(),'head':'19f783750878fbd555409d6520f73a48bc7df0b3','commands':[],'budgetsAndAssertionsChanged':False,'selectors':[],'historicalUnresolvedWheelFailure':'../portal-native-10/receipt.json: zh-cn/1280/light line999 scrollLeft618 unchanged; not claimed fixed by epoch binding'}
save=lambda:(O/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
env=dict(os.environ);env['PATH']=str(B/'tools/node-v24.22.3-linux-x64/bin')+':'+env['PATH'];env['COREPACK_HOME']=str(B/'corepack-cache');env['TMPDIR']='/tmp/pui-s345-image-4deb';env['CHROME_PATH']=str(B/'tools/playwright-browsers/chromium-1208/chrome-linux64/chrome');env['PUI_CHROME_EXECUTABLE']=env['CHROME_PATH'];env['PROTO_UI_BROWSER_BASE_URL']='http://127.0.0.1:38027';env['IMAGE_PREVIEW_EVIDENCE_DIR']=str(O/'image32');env['PROTO_UI_RUNTIME_EVIDENCE_DIR']=str(O/'theme9');env.pop('CANDIDATE_SHA',None)
def fact(p):
 b=p.read_bytes();return {'path':str(p.relative_to(R)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def command(name,args):
 row={'name':name,'command':args,'startedAt':now()};state['commands'].append(row);save();start=time.monotonic()
 with (O/(name+'.log')).open('wb') as log:
  p=subprocess.Popen(args,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT);row['pid']=p.pid;save();rc=p.wait()
 row.update(exitCode=rc,elapsedSeconds=time.monotonic()-start,finishedAt=now(),logSha256=hashlib.sha256((O/(name+'.log')).read_bytes()).hexdigest());save();return rc
def verify():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True,timeout=30).strip()==state['head']
 for f in state['sourceFiles']+state['publicDistFiles']+state['originalObservers']:
  assert fact(R/f['path'])==f,'source/dist/observer drift '+f['path']
original=None;helper=R/'scripts/analysis/shadow-s4-portal-first-render-diagnostic.mjs';diagnostic=None
try:
 producer=E/'portal-first-render-03/receipt.json';r=json.loads(producer.read_text());assert r.get('passed') is True and r.get('sourceStable') is True
 state['producerReceiptSha256']=hashlib.sha256(producer.read_bytes()).hexdigest();state['sourceFiles']=r['sourceFiles'];state['publicDistFiles']=r['publicDistFiles']
 prior=json.loads((E/'portal-native-10/receipt.json').read_text());state['originalObservers']=prior['observerAndFixtureFiles']
 s4=R/'scripts/analysis/shadow-s4-paint-browser.mjs';assert s4.read_text()==(E/'portal-native-09/original-s4-observer.mjs').read_text()
 state['originalObservers'].append(fact(s4));verify()
 state['browserSha256']=hashlib.sha256(Path(env['CHROME_PATH']).read_bytes()).hexdigest();assert state['browserSha256']=='481fea1516a1f2b76454664272f12cd9dd1f20117b21e1f1498e08bc7f872c00'
 (O/'image32').mkdir();(O/'theme9').mkdir()
 diagnostic=(E/'portal-native-09/failure-capture-observer.mjs').read_text();assert not helper.exists();helper.write_text(diagnostic)
 (O/'run-s4.mjs').write_bytes((E/'portal-native-09/run-s4.mjs').read_bytes());state['s4DiagnosticObserver']=fact(helper);state['s4CaptureControlsReceiptSha256']=hashlib.sha256((E/'portal-native-09/failure-capture-controls.log').read_bytes()).hexdigest()
 p=R/pre['path'];original=p.read_bytes();blob=hashlib.sha1(b'blob '+str(len(original)).encode()+b'\0'+original).hexdigest();assert blob==pre['expectedBeforeBlob']
 p.write_text(pre['content']);state['prerequisiteApplied']=True;state['prerequisite']={k:v for k,v in pre.items() if k!='content'};save()
 for name,test,expected in [('image32','apps/www/src/components/documentation-image-preview.browser.test.ts',32),('S4',None,24),('theme9','apps/www/test/color-scheme.browser.test.ts',9)]:
  verify()
  if test is None:
   rc=command('original-S4-24',['node',str(O/'run-s4.mjs'),str(O/'s4-24')])
   if (O/'s4-24/report.json').exists():
    report=json.loads((O/'s4-24/report.json').read_text());state['S4Report']={k:report.get(k) for k in ['outcome','journey','failure','failureCapture','errors']};state['S4Passed']=rc==0 and report.get('outcome')=='passed' and report.get('journey',{}).get('paths')==24
  else:
   target=O/name/'vitest.json';rc=command('original-'+name,['node','node_modules/vitest/vitest.mjs','run',test,'--minWorkers=1','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(target)])
   if target.exists():
    report=json.loads(target.read_text());state[name+'Summary']={k:report.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numRuntimeErrorTestSuites']}
    state[name+'Failures']=[{'name':a.get('fullName'),'messages':a.get('failureMessages',[])} for t in report.get('testResults',[]) for a in t.get('assertionResults',[]) if a.get('status')=='failed']
    state[name+'Passed']=rc==0 and report.get('numTotalTests')==expected and report.get('numPassedTests')==expected and not report.get('numPendingTests') and not report.get('numRuntimeErrorTestSuites');state[name+'ReportSha256']=hashlib.sha256(target.read_bytes()).hexdigest()
  save()
 verify();state['sourceStable']=True;state['passed']=bool(state.get('image32Passed') and state.get('S4Passed') and state.get('theme9Passed'))
except BaseException as e:
 state['passed']=False;state['failure']=repr(e);state['traceback']=traceback.format_exc()
finally:
 if original is not None and state.get('prerequisiteApplied'):
  p=R/pre['path']
  if p.read_text()==pre['content']:p.write_bytes(original);state['prerequisiteRestored']=True
  else:state['restorationFailure']='prerequisite changed; refused overwrite';state['passed']=False
 if helper.exists() and helper.read_text()==diagnostic:helper.unlink()
 state['finishedAt']=now();save()
