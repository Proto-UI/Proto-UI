import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
const require=createRequire("/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/continuation-s3-image-4deb/apps/www/package.json");
const { chromium }=require('playwright-core');
const out=process.argv[2];fs.mkdirSync(out,{recursive:false});
const report={kind:'ordinary-DOM-keyboard-and-horizontal-wheel-counterfactual',startedAt:new Date().toISOString(),productImported:false,launch:{headless:true,chromiumSandbox:true,args:['--disable-dev-shm-usage'],executablePath:process.env.CHROME_PATH},rows:[]};
const save=()=>fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
const browser=await chromium.launch(report.launch);report.browser={version:browser.version(),sha256:createHash('sha256').update(fs.readFileSync(process.env.CHROME_PATH)).digest('hex')};save();
const waitFor=async(read,budget=1000)=>{const start=performance.now();while(true){const value=await read();if(value)return {succeeded:true,elapsed:performance.now()-start};if(performance.now()-start>=budget)return {succeeded:false,elapsed:performance.now()-start};await new Promise(resolve=>setTimeout(resolve,50));}};
try {
 for(const mode of ['first-keyboard-movement','keyboard-scrollend'])for(let round=0;round<3;round++){
  const page=await browser.newPage({viewport:{width:1280,height:900}});
  const row={mode,round,errors:[]};report.rows.push(row);page.on('pageerror',error=>row.errors.push(String(error)));
  try {
   await page.setContent('<!doctype html><meta charset="utf-8"><style>html,body{margin:0;width:100%;height:100%;overflow:hidden}#viewport{position:absolute;left:22px;top:84px;width:1236px;height:778px;overflow:auto;overscroll-behavior:contain;scrollbar-width:none;outline:2px solid #888}#media{width:1920px;height:1692px;background:linear-gradient(135deg,#ddd,#aaa)}</style><div id="viewport" tabindex="0"><div id="media"></div></div>');
   const viewport=page.locator('#viewport');
   await viewport.evaluate(async el=>{el.focus({preventScroll:true});el.scrollLeft=618;el.scrollTop=405;await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));});
   await page.evaluate(()=>{
    const el=document.querySelector('#viewport');window.events=[];
    const read=()=>({x:el.scrollLeft,y:el.scrollTop});
    for(const type of ['keydown','wheel','scroll','scrollend'])el.addEventListener(type,event=>{
     const row={type,time:performance.now(),...read()};
     if(event instanceof WheelEvent)Object.assign(row,{deltaX:event.deltaX,deltaY:event.deltaY,trusted:event.isTrusted});
     if(event instanceof KeyboardEvent)row.key=event.key;
     window.events.push(row);queueMicrotask(()=>{row.defaultPrevented=event.defaultPrevented;});
    },{passive:true});
    window.keyboardEnded=false;el.addEventListener('scrollend',()=>{window.keyboardEnded=true;},{once:true});
   });
   row.before=await viewport.evaluate(el=>({x:el.scrollLeft,y:el.scrollTop,maxX:el.scrollWidth-el.clientWidth,maxY:el.scrollHeight-el.clientHeight}));
   await page.keyboard.press('PageDown');
   row.keyboardMoved=await waitFor(()=>viewport.evaluate((el,y)=>el.scrollTop>y,row.before.y));
   if(mode==='keyboard-scrollend')await page.waitForFunction(()=>window.keyboardEnded,undefined,{timeout:1000});
   row.wheelBefore=await viewport.evaluate(el=>({x:el.scrollLeft,y:el.scrollTop}));
   await viewport.hover();
   await page.mouse.wheel(row.before.maxX*2,0);
   row.horizontal=await waitFor(()=>viewport.evaluate((el,x)=>el.scrollLeft>x,row.wheelBefore.x));
   row.after=await viewport.evaluate(el=>({x:el.scrollLeft,y:el.scrollTop}));
   row.events=await page.evaluate(()=>window.events);
  } catch(error){row.failure={message:String(error),stack:error?.stack};}
  finally{await page.close();save();}
 }
} finally{await browser.close();report.finishedAt=new Date().toISOString();save();}
console.log(JSON.stringify({rows:report.rows.map(r=>({mode:r.mode,round:r.round,horizontal:r.horizontal,before:r.wheelBefore,after:r.after,failure:r.failure}))}));
