from pathlib import Path
import os,subprocess,json,datetime,time,hashlib
B=Path("/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono");R=Path("/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/continuation-s3-image-4deb");O=Path("/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/continuation-s3-image-4deb")/'portal-reentry-negative-03';O.mkdir(exist_ok=False)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
env=dict(os.environ);env['PATH']=str(B/'tools/node-v24.22.3-linux-x64/bin')+':'+env['PATH'];env['COREPACK_HOME']=str(B/'corepack-cache');env['TMPDIR']='/tmp/pui-s345-image-4deb'
test='packages/adapters/web-component/test/portal-first-render-reentry.test.ts'
source=['packages/adapters/web-component/src/adapt.ts','packages/adapters/web-component/src/host-display.ts','packages/adapters/web-component/src/portal-mount.ts',test]
files=[{'path':f,'sha256':hashlib.sha256((R/f).read_bytes()).hexdigest()} for f in source]
(O/'fixture.test.ts').write_bytes((R/test).read_bytes())
args=['node','node_modules/vitest/vitest.mjs','run',test,'--minWorkers=1','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(O/'vitest.json')]
state={'startedAt':now(),'files':files,'command':args,'pid':os.getpid()}
(O/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
t=time.monotonic()
with (O/'stdout.log').open('wb') as log:
 p=subprocess.Popen(args,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT);state['childPid']=p.pid;(O/'receipt.json').write_text(json.dumps(state,indent=2)+'\n');state['exitCode']=p.wait()
state['elapsedSeconds']=time.monotonic()-t;state['finishedAt']=now();state['logSha256']=hashlib.sha256((O/'stdout.log').read_bytes()).hexdigest()
if (O/'vitest.json').exists():
 r=json.loads((O/'vitest.json').read_text());state['summary']={k:r.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numRuntimeErrorTestSuites']};state['failures']=[{'name':a.get('fullName'),'messages':a.get('failureMessages',[])} for t in r.get('testResults',[]) for a in t.get('assertionResults',[]) if a.get('status')=='failed']
state['sourceStable']=all(hashlib.sha256((R/f['path']).read_bytes()).hexdigest()==f['sha256'] for f in files);(O/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
