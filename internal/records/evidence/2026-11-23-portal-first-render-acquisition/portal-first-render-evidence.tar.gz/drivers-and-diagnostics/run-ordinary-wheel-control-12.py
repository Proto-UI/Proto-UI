from pathlib import Path
import subprocess,os,json,datetime,hashlib,time
B=Path("/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono");E=Path("/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/continuation-s3-image-4deb");script=E/'ordinary-wheel-control-12.mjs';O=E/'ordinary-wheel-control-12'
env=dict(os.environ);env['PATH']=str(B/'tools/node-v24.22.3-linux-x64/bin')+':'+env['PATH'];env['TMPDIR']='/tmp/pui-s345-image-4deb';env['CHROME_PATH']=str(B/'tools/playwright-browsers/chromium-1208/chrome-linux64/chrome')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
state={'startedAt':now(),'pid':os.getpid(),'sourceSha256':hashlib.sha256(script.read_bytes()).hexdigest()}
receipt=E/'ordinary-wheel-control-12-execution.json'
with receipt.open('x') as f:f.write(json.dumps(state,indent=2)+'\n')
t=time.monotonic()
with (E/'ordinary-wheel-control-12.log').open('xb') as log:
 p=subprocess.Popen(['node',str(script),str(O)],env=env,stdout=log,stderr=subprocess.STDOUT);state['childPid']=p.pid;receipt.write_text(json.dumps(state,indent=2)+'\n');state['exitCode']=p.wait()
state['elapsedSeconds']=time.monotonic()-t;state['finishedAt']=now();state['sourceStable']=hashlib.sha256(script.read_bytes()).hexdigest()==state['sourceSha256'];receipt.write_text(json.dumps(state,indent=2)+'\n')
