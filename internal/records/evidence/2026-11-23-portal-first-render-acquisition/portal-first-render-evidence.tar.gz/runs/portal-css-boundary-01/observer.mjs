import { createRequire } from 'node:module';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const B='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono';
const E=B+'/evidence/continuation-s3-image-4deb/portal-css-boundary-01';
const require=createRequire(B+'/continuation-s3-image-4deb/apps/www/package.json');
const { chromium }=require('playwright-core');
await mkdir(E,{recursive:true});
const report={kind:'native-css-first-render-boundary-diagnostic',startedAt:new Date().toISOString(),sourceSha256:createHash('sha256').update(await readFile(new URL(import.meta.url))).digest('hex'),cases:[],productMutation:false,originalAcceptance:false};
let browser;
try {
 browser=await chromium.launch({headless:true,executablePath:B+'/tools/playwright-browsers/chromium-1208/chrome-linux64/chrome',args:['--no-sandbox']});
 for (const variant of ['original','display-none','visibility-hidden','content-visibility-hidden','content-visibility-hidden-no-transition-guard','visibility-hidden-no-transition-guard']) {
  const page=await browser.newPage({viewport:{width:600,height:400}});
  const result=await page.evaluate(async variant=>{
   const rules={
    'original':'',
    'display-none':'display:none!important;',
    'visibility-hidden':'visibility:hidden!important;',
    'content-visibility-hidden':'content-visibility:hidden!important;',
    'content-visibility-hidden-no-transition-guard':'content-visibility:hidden!important;',
    'visibility-hidden-no-transition-guard':'visibility:hidden!important;',
   };
   const style=document.createElement('style');
   style.textContent='.root{width:200px;height:100px;background:white;transform:translateX(0);transition:transform 220ms linear}.child{width:100px;height:50px;background:black;opacity:1;transition:opacity 220ms linear}.root.guarded{'+rules[variant]+'}'+(variant.includes('no-transition-guard')?'':'.guarded,.guarded *{transition:none!important}')+'@starting-style{.root{transform:translateX(100px)}.child{opacity:0}}';
   document.head.append(style);
   const root=document.createElement('div');root.className='root guarded';
   const child=document.createElement('div');child.className='child';root.append(child);document.body.append(root);
   const frames=[];
   const capture=stage=>{
    const r=root.getBoundingClientRect(),c=child.getBoundingClientRect(),cs=getComputedStyle(child),rs=getComputedStyle(root);
    frames.push({stage,at:performance.now(),rootX:r.x,rootWidth:r.width,childX:c.x,childWidth:c.width,opacity:Number(cs.opacity),transition:cs.transition,rootTransform:rs.transform,rootContentVisibility:rs.contentVisibility,childVisibility:cs.visibility});
   };
   capture('insert-force-layout');
   for(let i=0;i<2;i++){await new Promise(requestAnimationFrame);capture('guard-'+i);}
   root.classList.remove('guarded');capture('released');
   for(let i=0;i<20;i++){await new Promise(requestAnimationFrame);capture('released-'+i);}
   return {variant,frames};
  },variant);
  report.cases.push(result);
  await page.close();
 }
 report.finishedAt=new Date().toISOString();report.passed=true;
} catch(error){report.error=String(error?.stack||error);report.passed=false;report.finishedAt=new Date().toISOString();}
finally {if(browser)await browser.close();await writeFile(E+'/report.json',JSON.stringify(report,null,2)+'\n');}
