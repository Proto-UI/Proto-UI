import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
const root="/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/continuation-s3-image-4deb";
const out=process.argv[2];
const require=createRequire(path.join(root,'apps/www/package.json'));
const { chromium }=require('playwright-core');
const { runS4PaintJourney }=await import(pathToFileURL(path.join(root,'scripts/analysis/shadow-s4-portal-first-render-diagnostic.mjs')));
fs.mkdirSync(out,{recursive:false});
const sha256=bytes=>createHash('sha256').update(bytes).digest('hex');
const report={startedAt:new Date().toISOString(),outcome:'running',errors:[],launch:{headless:true,executablePath:process.env.PUI_CHROME_EXECUTABLE},originalGate:{caseBudgetMs:150000,rounds:2,profiles:['light','split','mixed'],settings:['default','switch','checkbox','both'],closeObservationMs:380,minFrames:5,markerPixels:4,cleanupBudgetMs:2000}};
let browser,page,timer,failureCapture=null;
const save=()=>fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
try {
  browser=await chromium.launch(report.launch);
  report.browser={version:browser.version(),sha256:sha256(fs.readFileSync(report.launch.executablePath))};
  page=await browser.newPage({viewport:{width:1100,height:900},colorScheme:'light'});
  page.on('pageerror',error=>report.errors.push(error.message));
  await page.goto(process.env.PROTO_UI_BROWSER_BASE_URL+'/zh-cn/internal/demo-matrix/#shadow-split-s4');
  await page.locator('[data-shadow-s4][data-ready=true]').waitFor();
  report.readyAt=new Date().toISOString();save();
  report.journey=await Promise.race([
    runS4PaintJourney(page,{outputDir:path.join(out,'paint'),onFailureCapture:c=>{failureCapture=c;}}),
    new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Original case timeout 150000ms')),150000);}),
  ]);
  assert.equal(report.journey.paths,24);
  assert.deepEqual(report.errors,[]);
  report.outcome='passed';
} catch(error) {
  report.outcome='failed';report.failure={message:String(error?.message??error),stack:error?.stack};clearTimeout(timer);
  if(failureCapture) {
    try {
      const directory=path.join(out,'raw-paint-failure');fs.mkdirSync(directory);
      const {paths,events,activePath,frames,ownerToken}=failureCapture;
      const index={ownerToken,activePath,paths,events,originalErrorPreserved:failureCapture.error===error,frames:frames.map((frame,i)=>({path:frame.path,time:frame.time,file:i+'.png',bytes:frame.png.length,sha256:sha256(frame.png)}))};
      for(let i=0;i<frames.length;i++)fs.writeFileSync(path.join(directory,i+'.png'),frames[i].png);
      fs.writeFileSync(path.join(directory,'index.json'),JSON.stringify(index,null,2)+'\n');
      report.failureCapture={path:'raw-paint-failure/index.json',frames:frames.length,originalErrorPreserved:index.originalErrorPreserved,counts:paths.map(p=>({path:p.path,frames:frames.filter(f=>f.path===p.path).length}))};
    } catch(error) {report.captureError=String(error);}
  }
  if(page) {
    try {
      report.failureFacts=await page.evaluate(()=>({activeElement:document.activeElement?.outerHTML.slice(0,1800),parts:Array.from(document.querySelectorAll('[data-s4-part]')).map(part=>({profile:part.dataset.s4Profile,part:part.dataset.s4Part,attributes:Object.fromEntries(Array.from(part.attributes).map(a=>[a.name,a.value])),animations:part.getAnimations().map(a=>({playState:a.playState,currentTime:a.currentTime}))}))}));
      await page.screenshot({path:path.join(out,'failure.png'),fullPage:true});
    } catch(error) {report.diagnosticError=String(error);}
  }
} finally {
  clearTimeout(timer);
  if(browser)await browser.close();
  report.finishedAt=new Date().toISOString();save();
}
console.log(JSON.stringify({outcome:report.outcome,journey:report.journey,failure:report.failure,errors:report.errors,failureCapture:report.failureCapture}));
process.exitCode=report.outcome==='passed'?0:1;
