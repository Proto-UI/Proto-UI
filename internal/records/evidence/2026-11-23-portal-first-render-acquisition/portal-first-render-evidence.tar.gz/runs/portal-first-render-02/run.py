from pathlib import Path
import os,json,hashlib,subprocess,time,datetime,traceback
B=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
R=B/'continuation-s3-image-4deb'
E=B/'evidence/continuation-s3-image-4deb/portal-first-render-02'
E.mkdir(exist_ok=True)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
with (E/'start.json').open('x') as f:f.write(json.dumps({'at':now(),'pid':os.getpid()})+'\n')
ops=json.loads((E/'operations.json').read_text())
state={'kind':'isolated-portal-first-render-candidate-original-tests','startedAt':now(),'baseHead':'b569b092b8c760b86f05887bb932ba1c189131af','sourceFiles':[],'commands':[],'lifecycleSchedulingChanged':False,'scheduleTaskTimingChanged':False,'retirementFinallyOnly':True,'originalBaselineRed':'../portal-first-render-01/unmodified-baseline/receipt.json','originalTestsChanged':False}
env=os.environ.copy();env['PATH']=str(B/'tools/node-v24.22.3-linux-x64/bin')+':'+env['PATH'];env['COREPACK_HOME']=str(B/'corepack-cache');env['TMPDIR']='/tmp/pui-s345-image-4deb'
def save():(E/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
def fact(p):
 b=p.read_bytes();return {'path':str(p.relative_to(R)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def command(name,args):
 row={'name':name,'command':args,'startedAt':now()};state['commands'].append(row);save();start=time.monotonic()
 with (E/(name+'.log')).open('wb') as f:
  p=subprocess.Popen(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT);row['pid']=p.pid;save();code=p.wait()
 row.update(exitCode=code,elapsedSeconds=time.monotonic()-start,finishedAt=now(),logSha256=hashlib.sha256((E/(name+'.log')).read_bytes()).hexdigest());save()
 if code:raise RuntimeError(name+' failed '+str(code))
 return row
try:
 actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True,timeout=30).strip()
 assert actual==state['baseHead'],'unexpected head '+actual
 changes=[]
 for item in ops:
  p=R/item['path'];raw=p.read_bytes();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
  assert hashlib.sha256(raw).hexdigest()==item['beforeSha256'],'candidate01 source changed '+item['path']
  before=raw.decode();assert before.count(item['old'])==1,'ambiguous source operation '+item['path']
  after=before.replace(item['old'],item['replacement'])
  changes.append({'path':item['path'],'baseBlob':blob,'before':before,'after':after})
 (E/'candidate-source.json').write_text(json.dumps({'baseHead':actual,'files':changes},indent=2)+'\n')
 for item in changes:(R/item['path']).write_text(item['after'])
 state['sourceFiles']=[fact(R/item['path']) for item in changes];save()
 files=[
 'packages/adapters/web-component/test/portal-conceal.test.ts',
 'packages/adapters/web-component/test/portal-owned-relocation.test.ts',
 'packages/adapters/web-component/test/portal-mount-ownership.test.ts',
 'packages/adapters/web-component/test/portal-adoption-review.test.ts',
 'packages/adapters/web-component/test/color-scheme.integration.test.ts',
 'packages/adapters/web-component/test/color-scheme-source.test.ts',
 'packages/adapters/web-component/test/lifecycle-view-intent.test.ts',
 'packages/adapters/web-component/test/focus-portal-parent-release.integration.test.ts']
 state['originalObserverHashes']=[fact(R/p) for p in files]
 command('original-unit-files',['node','node_modules/vitest/vitest.mjs','run',*files,'--minWorkers=1','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(E/'vitest.json')])
 report=json.loads((E/'vitest.json').read_text())
 state['testSummary']={k:report.get(k) for k in ['success','numTotalTests','numPassedTests','numFailedTests','numPendingTests','numRuntimeErrorTestSuites']}
 assert report.get('numTotalTests',0)>0 and not report.get('numFailedTests') and not report.get('numPendingTests') and not report.get('numRuntimeErrorTestSuites')
 assert all(any(t['name'].endswith(f) for t in report.get('testResults',[])) for f in files),'missing original unit file'
 state['unitPassed']=True;save()
 command('official-web-component-producer',['node','scripts/build/public-packages.mjs','--package','@proto.ui/adapter-web-component','--json'])
 state['publicDistFiles']=[fact(p) for p in sorted((R/'packages/adapters/web-component/dist').rglob('*')) if p.is_file()]
 state['sourceFilesAfter']=[fact(R/item['path']) for item in changes]
 assert state['sourceFilesAfter']==state['sourceFiles'],'source changed while validating'
 assert [fact(R/p) for p in files]==state['originalObserverHashes'],'original tests changed'
 state['passed']=True
except BaseException as error:
 state['passed']=False;state['failure']=repr(error);state['traceback']=traceback.format_exc()
 if (E/'vitest.json').exists():
  report=json.loads((E/'vitest.json').read_text());state['testSummary']={k:report.get(k) for k in ['success','numTotalTests','numPassedTests','numFailedTests','numPendingTests','numRuntimeErrorTestSuites']}
  state['failures']=[{'name':a.get('fullName'),'messages':a.get('failureMessages',[])} for t in report.get('testResults',[]) for a in t.get('assertionResults',[]) if a.get('status')=='failed']
finally:state['finishedAt']=now();save()
