from pathlib import Path
import json,hashlib,os,subprocess,time,datetime,traceback
B=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
R=B/'continuation-s3-image-4deb'
E=B/'evidence/continuation-s3-image-4deb/portal-first-render-01'
O=E/'unmodified-baseline';O.mkdir(exist_ok=True)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
with (O/'start.json').open('x') as f:f.write(json.dumps({'at':now(),'pid':os.getpid()})+'\n')
changes=json.loads((E/'candidate-source.json').read_text())['files']
state={'startedAt':now(),'kind':'original-d039-three-product-files-and-unchanged-full-portal-conceal-test','candidateRestored':False}
env=os.environ.copy();env['PATH']=str(B/'tools/node-v24.22.3-linux-x64/bin')+':'+env['PATH'];env['COREPACK_HOME']=str(B/'corepack-cache');env['TMPDIR']='/tmp/pui-s345-image-4deb'
def save():(O/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
restored=[]
try:
 for row in changes:assert (R/row['path']).read_text()==row['after'],'candidate drift '+row['path']
 state['sourceBefore']=[{'path':r['path'],'sha256':hashlib.sha256((R/r['path']).read_bytes()).hexdigest()} for r in changes]
 for row in changes:(R/row['path']).write_text(row['before']);restored.append(row)
 args=['node','node_modules/vitest/vitest.mjs','run','packages/adapters/web-component/test/portal-conceal.test.ts','--minWorkers=1','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(O/'vitest.json')]
 state['command']=args;save();start=time.monotonic()
 with (O/'stdout.log').open('wb') as log:
  p=subprocess.Popen(args,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT);state['pid']=p.pid;save();code=p.wait()
 state.update(exitCode=code,elapsedSeconds=time.monotonic()-start,logSha256=hashlib.sha256((O/'stdout.log').read_bytes()).hexdigest())
 report=json.loads((O/'vitest.json').read_text());state['testSummary']={k:report.get(k) for k in ['success','numTotalTests','numPassedTests','numFailedTests','numPendingTests']}
 state['failures']=[{'name':a['fullName'],'messages':a.get('failureMessages',[])} for t in report['testResults'] for a in t.get('assertionResults',[]) if a['status']=='failed']
except BaseException as error:state['failure']=repr(error);state['traceback']=traceback.format_exc()
finally:
 for row in restored:
  p=R/row['path'];assert p.read_text()==row['before'],'baseline source drift; refuse restore '+row['path'];p.write_text(row['after'])
 state['candidateRestored']=len(restored)==len(changes);state['finishedAt']=now();save()
