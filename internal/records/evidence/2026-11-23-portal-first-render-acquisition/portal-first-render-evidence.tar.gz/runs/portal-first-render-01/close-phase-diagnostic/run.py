from pathlib import Path
import json,hashlib,os,subprocess,time,datetime,traceback
B=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono');R=B/'continuation-s3-image-4deb';E=B/'evidence/continuation-s3-image-4deb/portal-first-render-01/close-phase-diagnostic';E.mkdir(exist_ok=True)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
with (E/'start.json').open('x') as f:f.write(json.dumps({'at':now(),'pid':os.getpid()})+'\n')
source=(E/'observer.test.ts').read_text();test=R/'packages/adapters/web-component/test/portal-close-phase-diagnostic.test.ts'
state={'startedAt':now(),'kind':'passive-original-close-phase-observer-original-assertion-preserved','observerSha256':hashlib.sha256(source.encode()).hexdigest()}
def save():(E/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
env=os.environ.copy();env['PATH']=str(B/'tools/node-v24.22.3-linux-x64/bin')+':'+env['PATH'];env['COREPACK_HOME']=str(B/'corepack-cache');env['TMPDIR']='/tmp/pui-s345-image-4deb'
created=False
try:
 with test.open('x') as f:f.write(source)
 created=True
 args=['node','node_modules/vitest/vitest.mjs','run',str(test.relative_to(R)),'--minWorkers=1','--maxWorkers=1','--testNamePattern=a newer open retains the epoch','--reporter=default','--reporter=json','--outputFile='+str(E/'vitest.json')]
 state['command']=args;save();start=time.monotonic()
 with (E/'stdout.log').open('wb') as log:
  p=subprocess.Popen(args,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT);state['pid']=p.pid;save();code=p.wait()
 state.update(exitCode=code,elapsedSeconds=time.monotonic()-start,logSha256=hashlib.sha256((E/'stdout.log').read_bytes()).hexdigest())
 data=json.loads((E/'vitest.json').read_text());state['summary']={k:data.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']}
except BaseException as error:state['failure']=repr(error);state['traceback']=traceback.format_exc()
finally:
 if created:
  assert test.read_text()==source,'diagnostic source drift';test.unlink()
 state['finishedAt']=now();save()
