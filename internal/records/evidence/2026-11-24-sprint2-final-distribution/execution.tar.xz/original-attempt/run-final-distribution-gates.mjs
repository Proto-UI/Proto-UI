import assert from 'node:assert/strict';
import {spawn,execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {existsSync,mkdirSync,readFileSync,writeFileSync,openSync,closeSync,readdirSync,statSync,realpathSync} from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';

const [sourceInput,revision,workInput,selected='all']=process.argv.slice(2);
assert.ok(sourceInput&&/^[a-f0-9]{40}$/.test(revision??'')&&workInput,'source full-revision work [group|all]');
const source=realpathSync(sourceInput),work=path.resolve(workInput),node=process.execPath;
assert.ok(!work.startsWith(source+path.sep),'Evidence must be outside the source tree');
const names=['workspace','focused','pin','artifact-install','cli','native','family','pack','packed','cost'];
const selectedGroups=selected==='all'?names:selected.split(',');
assert.ok(selectedGroups.length&&new Set(selectedGroups).size===selectedGroups.length&&selectedGroups.every(name=>names.includes(name)),'Unknown or duplicate group');
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const read=file=>JSON.parse(readFileSync(file,'utf8'));
const save=(file,value)=>writeFileSync(file,JSON.stringify(value,null,2)+'\n');
const git=(...args)=>execFileSync('git',args,{cwd:source,encoding:'utf8'}).trim();
const cleanSource=()=>({revision:git('rev-parse','HEAD'),status:git('status','--porcelain','--untracked-files=normal'),lockSha256:hash(readFileSync(path.join(source,'pnpm-lock.yaml')))});
function requireSource(){const state=cleanSource();assert.equal(state.revision,revision,'Source revision changed');assert.equal(state.status,'','Source is dirty');return state;}
mkdirSync(work,{recursive:true});
const tmp=path.join(work,'tmp');mkdirSync(tmp,{recursive:true});
const compiler=path.join(work,'compiler');
const registryEnv={NATIVE_CONSUMER_COMPILER:path.join(compiler,'index.js'),NATIVE_CONSUMER_DEPENDENCIES:'registry'};
const env={...process.env,TMPDIR:tmp,NODE_OPTIONS:'--max-old-space-size=1024',NODE_PATH:''};
delete env.TSX_TSCONFIG_PATH;
const contextFile=path.join(work,'context.json');
if(existsSync(contextFile)){const previous=read(contextFile);assert.equal(previous.source,source);assert.equal(previous.revision,revision);}
else{
 const ancestors=[];let current=work;for(;;){const candidate=path.join(current,'node_modules');if(existsSync(candidate))ancestors.push(realpathSync(candidate));const parent=path.dirname(current);if(parent===current)break;current=parent;}
 assert.deepEqual(ancestors,[],'A clean consumer parent must not provide incidental node_modules');
 save(contextFile,{schema:'sprint2.final-distribution.execution.v1',source,revision,createdAt:new Date().toISOString(),node:process.version,execPath:node,sourceSnapshot:requireSource(),temporaryRoot:tmp,ancestorNodeModules:ancestors,heapPolicy:'Coordinator and source build commands use 1024MB. Existing consumer scripts clear NODE_OPTIONS for ordinary child processes; no all-process 1024MB claim.',groups:names});
}
function status(name){const file=path.join(work,name,'receipt.json');return existsSync(file)?read(file):null;}
function receiptState(name){return status(name)?.status??'UNTESTED';}
function summarize(){const rows=names.map(name=>({name,status:receiptState(name),receipt:path.join(work,name,'receipt.json')}));save(path.join(work,'summary.json'),{revision,source,results:rows,ok:rows.every(row=>row.status==='PASS'),updatedAt:new Date().toISOString()});return rows;}
async function group(name,dependencies,body){
 if(!selectedGroups.includes(name))return;
 const existing=status(name);if(existing){console.log('PRESERVED_GROUP',name,existing.status);return;}
 const directory=path.join(work,name);mkdirSync(directory,{recursive:false});
 const receipt={name,revision,source,directory,status:'RUNNING',startedAt:new Date().toISOString(),steps:[],dependencies:dependencies.map(name=>({name,status:receiptState(name)}))};
 const checkpoint=()=>{save(path.join(directory,'receipt.json'),receipt);summarize();};checkpoint();
 const execute=(step,command,args,{cwd=source,timeoutMs=900000,extraEnv={},clean=false}={})=>new Promise(resolve=>{
  const output=path.join(directory,step+'.stdout.log'),error=path.join(directory,step+'.stderr.log');
  const stdout=openSync(output,'wx'),stderr=openSync(error,'wx');
  const result={name:step,command,args,cwd,stdout:output,stderr:error,timeoutMs,status:'RUNNING',startedAt:new Date().toISOString()};receipt.steps.push(result);checkpoint();
  const childEnv={...env,...extraEnv};if(clean){childEnv.NODE_OPTIONS='';childEnv.NODE_PATH='';delete childEnv.TSX_TSCONFIG_PATH;}
  const start=performance.now();let child;
  try{child=spawn(command,args,{cwd,env:childEnv,stdio:['ignore',stdout,stderr],detached:true});}catch(caught){closeSync(stdout);closeSync(stderr);Object.assign(result,{status:'FAIL',error:String(caught),elapsedMs:performance.now()-start});checkpoint();resolve(false);return;}
  let timedOut=false,spawnError=null,killTimer;
  const timer=setTimeout(()=>{timedOut=true;try{process.kill(-child.pid,'SIGTERM');}catch{}killTimer=setTimeout(()=>{try{process.kill(-child.pid,'SIGKILL');}catch{}},5000);},timeoutMs);
  child.on('error',error=>{spawnError=String(error);});
  child.on('close',(code,signal)=>{clearTimeout(timer);clearTimeout(killTimer);closeSync(stdout);closeSync(stderr);Object.assign(result,{status:code===0&&!signal&&!timedOut&&!spawnError?'PASS':'FAIL',exitCode:code,signal,timedOut,error:spawnError,elapsedMs:performance.now()-start,finishedAt:new Date().toISOString()});checkpoint();console.log('GATE_STEP',name,step,result.status,'exit='+code,'signal='+signal);resolve(result.status==='PASS');});
 });
 const must=async(...args)=>assert.equal(await execute(...args),true,'Step failed: '+args[0]);
 try{
  receipt.sourceBefore=requireSource();
  const blocked=receipt.dependencies.filter(row=>row.status!=='PASS');
  if(blocked.length){receipt.status='BLOCKED';receipt.blockedBy=blocked;}
  else{await body({directory,receipt,execute,must,checkpoint});receipt.sourceAfter=requireSource();receipt.status='PASS';}
 }catch(error){receipt.status='FAIL';receipt.error=error.stack??String(error);try{receipt.sourceAfter=cleanSource();}catch{}}
 finally{receipt.finishedAt=new Date().toISOString();checkpoint();console.log('GATE_GROUP',name,receipt.status);}
}

await group('workspace',[],async({must})=>{await must('frozen-offline-install','corepack',['pnpm@10.32.1','install','--frozen-lockfile','--ignore-scripts','--offline']);});
await group('focused',['workspace'],async({must})=>{await must('delivery-files',node,['--max-old-space-size=1024',path.join(source,'node_modules/vitest/vitest.mjs'),'run','packages/compiler/test/targets.test.ts','packages/compiler/test/cli.test.ts','packages/compiler/src/artifact-output.test.ts','packages/compiler/src/watch.test.ts','packages/compiler/test/output.test.ts','--maxWorkers=1','--minWorkers=1','--no-file-parallelism']);});
await group('pin',['workspace'],async({execute,receipt,checkpoint})=>{
 const first=await execute('first',node,['--max-old-space-size=1024','--import','tsx','scripts/compiler/build-pinned.ts','--revision',revision,'--output',compiler]);
 const secondDir=path.join(work,'compiler-repeat');
 const second=await execute('repeat',node,['--max-old-space-size=1024','--import','tsx','scripts/compiler/build-pinned.ts','--revision',revision,'--output',secondDir]);
 assert.ok(first&&second,'Both independent builds must finish');
 function inventory(root){const result=[];const visit=(directory,prefix='')=>{for(const name of readdirSync(directory).sort()){const file=path.join(directory,name),logical=prefix+name;if(statSync(file).isDirectory())visit(file,logical+'/');else{const bytes=readFileSync(file);result.push({file:logical,bytes:bytes.length,sha256:hash(bytes)});}}};visit(root);return result;}
 receipt.firstArtifacts=inventory(compiler);receipt.repeatArtifacts=inventory(secondDir);checkpoint();assert.deepEqual(receipt.firstArtifacts,receipt.repeatArtifacts,'Pinned artifacts are not byte identical');assert.equal(read(path.join(compiler,'compiler-build.json')).revision,revision);
});
await group('artifact-install',['pin'],async({directory,must,receipt})=>{
 const npmCli=(process.env.PATH??'').split(path.delimiter).map(directory=>path.join(directory,'npm')).find(file=>existsSync(file));assert.ok(npmCli,'npm executable missing');
 const config=path.join(directory,'npmrc'),cache=path.join(directory,'npm-cache');writeFileSync(config,'registry=https://registry.npmjs.org/\naudit=false\nfund=false\n');
 assert.ok(!existsSync(path.join(compiler,'node_modules')),'Pinned artifact must start without installed dependencies');
 await must('npm-ci',node,[realpathSync(npmCli),'ci','--ignore-scripts','--no-audit','--no-fund','--registry','https://registry.npmjs.org/','--cache',cache,'--userconfig',config],{cwd:compiler,timeoutMs:300000,clean:true});
 await must('build-info',node,['cli.js','--build-info'],{cwd:compiler,clean:true});
 receipt.package=read(path.join(compiler,'package.json'));receipt.lock=read(path.join(compiler,'package-lock.json'));receipt.installedTypescript=read(path.join(compiler,'node_modules/typescript/package.json')).version;
});
await group('cli',['artifact-install'],async({must})=>{await must('cli',node,['--max-old-space-size=1024','scripts/compiler/pinned-cli-smoke.mjs'],{extraEnv:registryEnv,timeoutMs:900000});});
await group('native',['artifact-install'],async({must})=>{await must('four-profiles',node,['--max-old-space-size=1024','scripts/compiler/native-consumer-smoke.mjs'],{extraEnv:registryEnv,timeoutMs:1800000});});
await group('family',['artifact-install'],async({must})=>{await must('three-families-four-profiles',node,['--max-old-space-size=1024','scripts/compiler/release-family-smoke.mjs'],{extraEnv:registryEnv,timeoutMs:1800000});});
await group('pack',['workspace'],async({directory,must,receipt,checkpoint})=>{
 const {getAllPackages}=await import(pathToFileURL(path.join(source,'scripts/release/lib.mjs')));
 const all=new Map(getAllPackages().map(pkg=>[pkg.name,pkg]));const queue=['@proto.ui/core','@proto.ui/hooks','@proto.ui/adapter-react','@proto.ui/prototypes-base'],selected=new Set();
 while(queue.length){const name=queue.shift();if(selected.has(name))continue;const pkg=all.get(name);assert.ok(pkg&&!pkg.isReleaseExcluded&&!pkg.manifest.private,name);selected.add(name);for(const field of ['dependencies','peerDependencies','optionalDependencies'])for(const dependency of Object.keys(pkg.manifest[field]??{}))if(dependency.startsWith('@proto.ui/'))queue.push(dependency);}
 receipt.packages=[...selected].sort();save(path.join(directory,'closure.json'),{revision,packages:receipt.packages});checkpoint();
 await must('canonical-pack',node,['--max-old-space-size=1024','scripts/release/publish.mjs','--pack','--only',receipt.packages.join(','),'--out-dir',path.join(work,'release')],{timeoutMs:2400000});
 const manifest=read(path.join(work,'release/pack-manifest.json'));assert.deepEqual(manifest.packages.map(pkg=>pkg.name).sort(),receipt.packages);receipt.manifestSha256=hash(readFileSync(path.join(work,'release/pack-manifest.json')));
});
await group('packed',['artifact-install','pack'],async({must})=>{await must('paired-clean-consumer',node,['--max-old-space-size=1024','scripts/compiler/packed-generated-smoke.mjs'],{extraEnv:{...registryEnv,PACKED_DIR:path.join(work,'release/tarballs'),KEEP_PACKED_CONSUMER:'1'},timeoutMs:1200000});});
await group('cost',['family'],async({must,receipt})=>{
 const log=readFileSync(path.join(work,'family/three-families-four-profiles.stdout.log'),'utf8');const match=log.match(/^RELEASE_FAMILY_EVIDENCE (.+)$/m);assert.ok(match,'Family evidence directory missing');const summaryFile=path.join(match[1],'summary.json');assert.equal(read(summaryFile).ok,true);receipt.familySummary=summaryFile;
 await must('observer-calibration',node,['--test','scripts/compiler/host-cost-observer.test.mjs']);
 await must('production-costs',node,['--max-old-space-size=1024','scripts/compiler/release-family-costs.mjs',summaryFile],{timeoutMs:900000});
 receipt.costReport=path.join(match[1],'production-costs.json');assert.equal(read(receipt.costReport).ok,true);
});
const rows=summarize();console.log('DISTRIBUTION_GATE_EVIDENCE',work);console.log(JSON.stringify(rows));
if(rows.some(row=>selectedGroups.includes(row.name)&&row.status!=='PASS'))process.exitCode=1;
