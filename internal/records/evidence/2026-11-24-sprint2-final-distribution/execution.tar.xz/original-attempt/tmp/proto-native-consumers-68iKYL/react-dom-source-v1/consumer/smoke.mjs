import assert from 'node:assert/strict';
import {writeFileSync,realpathSync,readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import path from 'node:path';
const require=createRequire(import.meta.url);
const profile=process.argv[2];
const templateTag=process.argv[3]==='edited'?'article':'section';
const trace={profile,sourceOwnership:process.argv[3]??'original',surface:'Real framework/custom-element mount in Happy DOM, not a native browser',comparison:'native-only / one-sided',steps:[],phases:[],transitions:[],resolutions:[],errors:[],measurements:{scope:'Single performance.now observations including target scheduling/Happy DOM; not browser latency, throughput or a speed comparison. Memory is separately scoped whole-process sampling, not per-operation allocations.',updates:[]}};
trace.measurements.memory={platform:process.platform,snapshotUnit:'bytes',scope:'Coarse process.memoryUsage snapshots for this isolated Node runtime, including framework imports, Happy DOM and evidence bookkeeping. No forced GC, exact heap allocation counts, per-component attribution, reclamation or native-browser/layout claim. Held owner/state/method/DOM references are intentionally retained by the harness; arrayBuffers is included in external.',snapshots:[]};
const save=()=>writeFileSync('runtime-trace.json',JSON.stringify(trace,null,2)+'\n');
const memorySnapshot=stage=>trace.measurements.memory.snapshots.push({stage,...process.memoryUsage()});
memorySnapshot('runtime-initialized-before-happy-dom-import');save();
const root=realpathSync(process.cwd());
const inside=file=>{const rel=path.relative(root,realpathSync(file));return !path.isAbsolute(rel)&&rel!=='..'&&!rel.startsWith('..'+path.sep);};
function resolution(name){const resolved=require.resolve(name);assert.ok(inside(resolved),'Runtime import escaped isolated consumer: '+name);trace.resolutions.push({name,resolved});return resolved;}
resolution('happy-dom');
const {Window}=await import('happy-dom');
const window=new Window({url:'http://native-consumer.invalid/'});
for(const key of ['window','self','document','navigator','Node','Element','HTMLElement','SVGElement','ShadowRoot','Text','Comment','Event','CustomEvent','MouseEvent','MutationObserver','DOMParser','customElements']){
  Object.defineProperty(globalThis,key,{value:key==='window'||key==='self'?window:window[key],configurable:true,writable:true});
}
for(const key of ['getComputedStyle','requestAnimationFrame','cancelAnimationFrame'])globalThis[key]=window[key].bind(window);
window.addEventListener('error',event=>{trace.errors.push(String(event.error??event.message));save();});
let driver;
let module;
let state;
const microtasks=async()=>{for(let i=0;i<8;i++)await Promise.resolve();};
const recordPhase=kind=>{trace.phases.push({kind,text:driver?.query()?.textContent??null});save();};
const outer=document.createElement('div');document.body.append(outer);
try{
  memorySnapshot('happy-dom-initialized-before-component-import');
  const initializationStart=performance.now();
  module=await import('./dist/Component.js');
  const Generated=module.CompiledComponent??module.default;
  const initial={seed:2,visible:true};
  if(profile==='react-dom-source-v1'){
    resolution('react');resolution('react-dom/client');
    globalThis.IS_REACT_ACT_ENVIRONMENT=true;
    const React=await import('react');const {createRoot}=await import('react-dom/client');
    const ref=React.createRef();const root=createRoot(outer);
    const transact=async callback=>React.act(async()=>{callback();await microtasks();});
    driver={query:()=>outer.querySelector('section'),handle:()=>ref.current,transact,
      change:props=>transact(()=>root.render(React.createElement(Generated,{...props,ref,onPhase:recordPhase}))),
      destroy:()=>root.unmount()};
    await driver.change(initial);
  }else if(profile==='vue-source-v1'){
    resolution('vue');const Vue=await import('vue');
    const input=Vue.shallowRef(initial);const ref=Vue.shallowRef();
    const transact=async callback=>{callback();await microtasks();await Vue.nextTick();await microtasks();await Vue.nextTick();};
    const app=Vue.createApp({setup(){return()=>Vue.h(Generated,{...input.value,ref,onPhase:recordPhase});}});
    app.config.errorHandler=error=>{trace.errors.push(String(error));save();};
    driver={query:()=>outer.querySelector('section'),handle:()=>ref.value,transact,
      change:props=>transact(()=>{input.value=props;}),destroy:()=>app.unmount()};
    app.mount(outer);await transact(()=>{});
  }else if(profile==='vue2-source-v1'){
    resolution('vue');const Vue=(await import('vue')).default;Vue.config.productionTip=false;Vue.config.devtools=false;
    Vue.config.errorHandler=error=>{trace.errors.push(String(error));save();};
    const mount=document.createElement('div');outer.append(mount);
    const vm=new Vue({data(){return{input:initial};},render(h){return h(Generated,{ref:'generated',props:this.input,on:{phase:recordPhase}});}});
    const transact=async callback=>{callback();await microtasks();await Vue.nextTick();await microtasks();await Vue.nextTick();};
    driver={query:()=>outer.querySelector('section'),handle:()=>vm.$refs.generated,transact,
      change:props=>transact(()=>{vm.input=props;}),destroy:()=>{vm.$destroy();vm.$el.remove();}};
    vm.$mount(mount);await transact(()=>{});
  }else if(profile==='web-component-source-v1'){
    module.register('native-consumer-counter');
    const element=document.createElement('native-consumer-counter');
    element.addEventListener('phase',event=>recordPhase(event.detail));
    const transact=async callback=>{callback();await microtasks();};
    driver={query:()=>element.querySelector('section'),handle:()=>element,
      transact,
      change:props=>transact(()=>element.setProps(props)),
      destroy:()=>{element.dispose();element.remove();},
      move:()=>transact(()=>{const other=document.createElement('div');document.body.append(other);other.append(element);})};
    element.setProps(initial);outer.append(element);await microtasks();
    assert.equal(element.shadowRoot,null,'Ordinary WC profile uses the native light-DOM surface');
  }else throw new Error('Unsupported runtime profile '+profile);
  trace.measurements.initializationMs=performance.now()-initializationStart;
  driver.query=()=>profile==='web-component-source-v1'?driver.handle().querySelector(templateTag):outer.querySelector(templateTag);
  driver.host=()=>profile==='web-component-source-v1'?driver.handle():outer.querySelector('[data-pui-root]');
  const transact=driver.transact;
  driver.transact=async callback=>{const start=performance.now();await transact(callback);trace.measurements.updates.push({operation:'owner transaction (including framework flush)',ms:performance.now()-start});};
  const change=driver.change;
  driver.change=async props=>{const start=performance.now();await change(props);trace.measurements.updates.push({operation:'raw props change (including framework flush)',ms:performance.now()-start});};
  const owner=driver.handle();assert.ok(owner,'Mount did not publish its public owner');
  const exposed=owner.getExposes();state=exposed.count;const write=exposed.write;
  const initialRoot=driver.host();const observedRoots=new Set();
  trace.resources={scope:'Numeric component only: observed public owner/held-handle identities, DOM Root connectivity and authored lifecycle callbacks. Framework Root means [data-pui-root] wrapper; custom-element Root means its host, which can remain connected while its view is detached. Live Root counts cover observed nodes that remain connected, not all process resources. The reattach replacement count compares the final reattached Root with the mounted Root; transient unobserved replacements are unavailable. Distinct observed Root identities are not allocation counts; retained disconnected DOM references are not live Roots or GC evidence. Published handle absence is not owner disposal; held-handle identities are reported separately. Epoch/instance counts derive from mounted/unmounted/created/disposed callbacks, not internal instrumentation. Context components are not included.',observations:[]};
  const observeResources=(step,terminal=false)=>{
    const currentRoot=driver.host();if(currentRoot)observedRoots.add(currentRoot);
    if(profile!=='web-component-source-v1')for(const node of outer.querySelectorAll('[data-pui-root]'))observedRoots.add(node);
    const observation={step,liveRootCount:[...observedRoots].filter(node=>node.isConnected).length,distinctObservedRootCount:observedRoots.size,initialRootConnected:initialRoot?.isConnected??false,viewPresent:driver.query()!==null};
    if(!terminal){const published=driver.handle();observation.ownerIdentity={publishedHandleAvailable:published!=null,publishedHandleMatchesMountedOwner:published===owner,heldStateMatchesMountedState:owner.getExposes().count===state,heldMethodMatchesMountedMethod:owner.getExposes().write===write};}
    trace.resources.lifecycle={createdInstanceCount:trace.phases.filter(item=>item.kind==='created').length,mountedEpochCount:trace.phases.filter(item=>item.kind==='mounted').length,unmountedEpochCount:trace.phases.filter(item=>item.kind==='unmounted').length,disposedInstanceCount:trace.phases.filter(item=>item.kind==='disposed').length,updatedCallbackCount:trace.phases.filter(item=>item.kind==='updated').length};
    if(step==='rebind-view')trace.resources.replacementRootCountAcrossReattach=currentRoot===null?null:Number(currentRoot!==initialRoot);
    if(terminal)trace.resources.terminalLiveRootCount=observation.liveRootCount;
    trace.resources.observations.push(observation);
  };
  const tokens=()=>driver.host()?.getAttribute('data-pui-style')?.split(' ').filter(Boolean)??[];
  const styled=expected=>assert.deepEqual([...tokens()].sort(),[...expected].sort());
  const observe=step=>{const measurement=trace.measurements.updates.at(-1);if(measurement)measurement.step=step;trace.steps.push({step,text:driver.query()?.textContent??null,value:state.get(),style:tokens(),phases:trace.phases.map(item=>item.kind)});memorySnapshot(step);observeResources(step);save();};
  const visible=(text)=>assert.equal(driver.query()?.textContent,text);
  observe('mount');visible('2');assert.equal(state.get(),2);
  styled(['bg-white','opacity-100']);assert.equal(driver.query().getAttribute('data-pui-style'),'text-white');
  assert.equal(driver.query().parentElement,driver.host(),'Template must be inside the single native Root');
  assert.deepEqual(trace.phases.map(item=>item.kind),['created','mounted']);
  const off=state.subscribe(event=>{trace.transitions.push({prev:event.prev,next:event.next,reason:event.reason??null});save();});
  const stableRoot=driver.host();
  await driver.transact(()=>{write(7);styled(['bg-red','opacity-100']);});observe('write-without-update');visible('2');assert.equal(state.get(),7);assert.equal(exposed.read(),7);
  assert.equal(driver.host(),stableRoot);assert.deepEqual(trace.phases.map(item=>item.kind),['created','mounted']);
  assert.deepEqual(trace.transitions.map(item=>[item.prev,item.next]),[[2,7]]);
  const styleUpdates=trace.phases.filter(item=>item.kind==='updated').length;
  const hostPropsUpdate=profile==='vue2-source-v1';
  trace.hostPropsPolicy=hostPropsUpdate?'Host props replacement explicitly requests semantic update':'Only authored run.update requests semantic update';
  const propsText=hostPropsUpdate?'7':'2';
  await driver.change({seed:2,visible:true,active:true});observe('later-rule-wins');styled(['bg-black','opacity-40']);visible(propsText);
  await driver.change({seed:2,visible:true,active:true,patch:1});observe('patch-over-rule');styled(['bg-blue','opacity-40']);
  await driver.change({seed:2,visible:true,active:true,patch:2});observe('suppress-group');styled(['opacity-40']);
  await driver.change({seed:2,visible:true,active:true,patch:0});observe('clear-patch-restores-rule');styled(['bg-black','opacity-40']);
  await driver.change({seed:2,visible:true,active:false});observe('withdraw-later-rule');styled(['bg-red','opacity-100']);visible(propsText);
  assert.equal(trace.phases.filter(item=>item.kind==='updated').length-styleUpdates,hostPropsUpdate?5:0,'Host props update policy produced the wrong completed update count');assert.equal(driver.host(),stableRoot);
  await driver.transact(()=>owner.update());observe('explicit-update');visible('7');assert.equal(trace.phases.at(-1).kind,'updated');
  await driver.change({seed:2,visible:false,active:true,patch:1});observe('detach-view');assert.equal(driver.query(),null);
  assert.equal(owner.getExposes().count,state);assert.equal(trace.phases.at(-1).kind,'unmounted');
  await driver.transact(()=>{write(9);owner.update();});observe('write-and-update-while-detached');assert.equal(driver.query(),null);assert.equal(state.get(),9);
  assert.deepEqual(trace.transitions.map(item=>[item.prev,item.next]),[[2,7],[7,9]]);
  await driver.change({seed:2,visible:true,active:true,patch:1});observe('rebind-view');visible('9');
  styled(['bg-blue','opacity-40']);assert.equal(driver.query().getAttribute('data-pui-style'),'text-white');
  assert.equal(owner.getExposes().count,state);assert.equal(owner.getExposes().write,write);assert.equal(trace.phases.at(-1).kind,'mounted');
  await driver.change({seed:2,visible:true,active:true,patch:0});observe('replayed-patch-clear');styled(['bg-black','opacity-40']);
  await driver.change({seed:2,visible:true,active:false,patch:0});observe('replayed-rule-withdraw');styled(['bg-white','opacity-100']);
  if(driver.move){await driver.move();observe('synchronous-native-dom-move');visible('9');assert.equal(driver.handle().getExposes().count,state);}
  off();await driver.transact(()=>write(11));observe('unsubscribed-write');visible('9');assert.equal(trace.transitions.length,2);
  await driver.transact(()=>owner.update());observe('second-explicit-update');visible('11');
  await driver.change({seed:6,visible:true});observe('props-watch-update');visible('6');assert.equal(state.get(),6);
  await driver.change({visible:true});observe('withdraw-prop-to-default');visible('2');assert.equal(state.get(),2);
  const updatesBeforeDisposal=trace.phases.filter(item=>item.kind==='updated').length;
  const terminalRoot=driver.host();const teardownStart=performance.now();
  // A queued update cannot outlive terminal disposal, regardless of target scheduling.
  await transact(()=>{write(12);owner.update();driver.destroy();});await microtasks();
  trace.measurements.teardownMs=performance.now()-teardownStart;
  memorySnapshot('terminal-dispose');observeResources('terminal-dispose',true);save();
  assert.equal(terminalRoot.hasAttribute('data-pui-style'),false,'Disposal left helper-owned projection');
  assert.equal(driver.query(),null);
  assert.equal(trace.phases.filter(item=>item.kind==='updated').length,updatesBeforeDisposal,'Queued update committed after disposal');
  assert.throws(()=>write(1));assert.throws(()=>state.get());assert.throws(()=>state.subscribe(()=>{}));
  trace.steps.push({step:'terminal-dispose',text:null,heldMethodInvalid:true,heldStateInvalid:true,heldSubscriptionInvalid:true});save();
  assert.equal(trace.phases.filter(item=>item.kind==='created').length,1);
  assert.equal(trace.phases.filter(item=>item.kind==='mounted').length,2);
  assert.equal(trace.phases.filter(item=>item.kind==='unmounted').length,2);
  assert.equal(trace.phases.filter(item=>item.kind==='disposed').length,1);
  // Framework composition is authored here in the clean consumer, not encoded as
  // a PrototypeRef or evaluated portable source. Both modules import the same key.
  const providerModule=await import('./dist/Provider.js');
  const consumerModule=await import('./dist/ContextConsumer.js');
  const Provider=providerModule.Provider??providerModule.default;
  const Consumer=consumerModule.ContextConsumer??consumerModule.default;
  const contextHost=document.createElement('div');document.body.append(contextHost);
  let contextDriver;
  const contextStart=performance.now();
  if(profile==='react-dom-source-v1'){
    const React=await import('react');const {createRoot}=await import('react-dom/client');
    const ref=React.createRef();const contextRoot=createRoot(contextHost);
    const change=seed=>React.act(async()=>{contextRoot.render(React.createElement(Provider,{seed},React.createElement(Consumer,{ref})));await microtasks();});
    contextDriver={change,handle:()=>ref.current,query:()=>contextHost.querySelector('output'),destroy:()=>React.act(async()=>{contextRoot.unmount();await microtasks();})};
    await change(31);
  }else if(profile==='vue-source-v1'){
    const Vue=await import('vue');const seed=Vue.shallowRef(31);const ref=Vue.shallowRef();
    const app=Vue.createApp({setup(){return()=>Vue.h(Provider,{seed:seed.value},{default:()=>Vue.h(Consumer,{ref})});}});
    app.config.errorHandler=error=>{trace.errors.push(String(error));save();};
    const flush=async()=>{await microtasks();await Vue.nextTick();await microtasks();await Vue.nextTick();};
    contextDriver={change:async next=>{seed.value=next;await flush();},handle:()=>ref.value,query:()=>contextHost.querySelector('output'),destroy:async()=>{app.unmount();await flush();}};
    app.mount(contextHost);await flush();
  }else if(profile==='vue2-source-v1'){
    const Vue=(await import('vue')).default;
    const mount=document.createElement('div');contextHost.append(mount);
    const vm=new Vue({data(){return{seed:31};},render(h){return h(Provider,{props:{seed:this.seed}},[h(Consumer,{ref:'context'})]);}});
    const flush=async()=>{await microtasks();await Vue.nextTick();await microtasks();await Vue.nextTick();};
    contextDriver={change:async next=>{vm.seed=next;await flush();},handle:()=>vm.$refs.context,query:()=>contextHost.querySelector('output'),destroy:async()=>{vm.$destroy();vm.$el.remove();await flush();}};
    vm.$mount(mount);await flush();
  }else{
    providerModule.register('native-consumer-provider');consumerModule.register('native-consumer-context');
    const parent=document.createElement('native-consumer-provider');const child=document.createElement('native-consumer-context');
    parent.setProps({seed:31});parent.append(child);contextHost.append(parent);await microtasks();
    assert.equal(parent.shadowRoot,null);assert.equal(child.shadowRoot,null);
    contextDriver={change:async next=>{parent.setProps({seed:next});await microtasks();},handle:()=>child,query:()=>child.querySelector('output'),destroy:async()=>{child.dispose();parent.dispose();parent.remove();await microtasks();}};
  }
  trace.context={initializationMs:performance.now()-contextStart,steps:[]};
  memorySnapshot('context-mount');
  const contextOwner=contextDriver.handle();assert.ok(contextOwner);
  const heldValue=contextOwner.getExposes().value;const heldMissing=contextOwner.getExposes().missing;
  const contextObserve=step=>{const value=heldValue.get();const missing=heldMissing.get();const text=contextDriver.query()?.textContent;trace.context.steps.push({step,value,missing,text});save();return{value,missing,text};};
  assert.deepEqual(contextObserve('shared-key-mount'),{value:31,missing:true,text:'31'});
  const contextUpdateStart=performance.now();await contextDriver.change(47);
  trace.context.updateMs=performance.now()-contextUpdateStart;
  memorySnapshot('context-provider-update');
  assert.deepEqual(contextObserve('provider-update-crosses-module-boundary'),{value:47,missing:true,text:'47'});
  assert.equal(contextDriver.handle(),contextOwner);assert.equal(contextOwner.getExposes().value,heldValue);
  const contextTeardownStart=performance.now();await contextDriver.destroy();trace.context.teardownMs=performance.now()-contextTeardownStart;
  memorySnapshot('context-dispose');
  assert.equal(contextDriver.query(),null);assert.throws(()=>heldValue.get());assert.throws(()=>heldMissing.get());
  assert.equal(trace.errors.length,0,'Framework/DOM reported runtime errors');
  trace.queuedDisposal={updatesBeforeDisposal,updatesAfterDisposal:trace.phases.filter(item=>item.kind==='updated').length};
  trace.ok=true;save();console.log('NATIVE_RUNTIME_OK',profile,JSON.stringify(trace.steps));
}catch(error){trace.ok=false;trace.failure={message:error.message,stack:error.stack};memorySnapshot('runtime-failure');save();throw error;}
finally{await window.happyDOM.abort();window.close();memorySnapshot('happy-dom-disposed');save();}