import {definePrototype,tw} from '@proto.ui/core';
export default definePrototype({name:'native-consumer-counter',setup(def){
  def.props.define({seed:{type:'number',default:2},visible:{type:'boolean',default:true},active:{type:'boolean',default:false},patch:{type:'number',default:0}});
  const count=def.state.numberDiscrete('consumerCount',0,{min:0,max:100,step:1});
  const base=tw('bg-white','opacity-100');
  const counted=tw('bg-red');const active=tw('bg-black','opacity-40');const patched=tw('bg-blue');
  const template=tw('text-white');
  def.feedback.style.use(base);
  def.rule({when:w=>w.state(count).eq(7),intent:i=>i.feedback.style.use(counted)});
  def.rule({when:w=>w.prop('active').eq(true),intent:i=>i.feedback.style.use(active)});
  def.props.watch(['patch'],(run,next)=>{
    if(next.patch===1){run.feedback.style.patch(patched);}
    if(next.patch===2){run.feedback.style.suppress(patched);}
    if(next.patch===0){run.feedback.style.clearPatch();}
  });
  def.expose.state('count',count);
  def.expose.method('write',(next:number)=>{count.set(next,'consumer-write');});
  def.expose.method('read',()=>count.get());
  def.expose.event('phase',{payload:'json'});
  def.props.watch(['seed'],(run,next)=>{count.set(next.seed ?? 0);run.update();});
  def.props.watch(['visible'],(run,next)=>{run.lifecycle.setPresent(next.visible ?? false);});
  def.lifecycle.onCreated((run)=>{
    count.set(run.props.get().seed ?? 0);
    run.lifecycle.setPresent(run.props.get().visible ?? false);
    run.expose.emit('phase','created');
  });
  def.lifecycle.onMounted((run)=>{run.expose.emit('phase','mounted');});
  def.lifecycle.onUpdated((run)=>{run.expose.emit('phase','updated');});
  def.lifecycle.onUnmounted((run)=>{run.expose.emit('phase','unmounted');});
  def.lifecycle.onBeforeDispose((run)=>{run.expose.emit('phase','disposed');});
  return (render)=>render.el('section',{style:template},count.get());
}});