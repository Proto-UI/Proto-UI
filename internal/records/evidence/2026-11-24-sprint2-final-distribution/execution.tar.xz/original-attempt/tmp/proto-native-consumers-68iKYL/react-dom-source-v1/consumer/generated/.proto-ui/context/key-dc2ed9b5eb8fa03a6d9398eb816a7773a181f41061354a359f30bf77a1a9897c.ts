// Source declaration "keys.ts#KEY"
// Checked value schema {"kind":"record","fields":[{"name":"value","type":"number"}]}
export const key = Object.freeze({ __brand: 'ContextKey' as const, debugName: "consumer-shared-name" });
