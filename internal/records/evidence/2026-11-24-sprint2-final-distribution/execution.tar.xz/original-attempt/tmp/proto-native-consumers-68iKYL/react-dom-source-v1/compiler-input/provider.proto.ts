import {definePrototype} from '@proto.ui/core';import {KEY} from './keys';
export default definePrototype({name:'native-consumer-provider',setup(def){
  def.props.define({seed:{type:'number',default:31}});
  def.context.provide(KEY,{value:31});
  def.props.watch(['seed'],(run,next)=>{run.context.update(KEY,{value:next.seed ?? 31});});
  return render=>render.el('section',{},render.slot());
}});