import {definePrototype} from '@proto.ui/core';import {KEY,OTHER} from './keys';
export default definePrototype({name:'native-consumer-context',setup(def){
  const value=def.state.numberDiscrete('value',0);
  const missing=def.state.bool('missing',false);
  def.expose.state('value',value);def.expose.state('missing',missing);
  def.context.subscribe(KEY,(run,next)=>{value.set(next.value);run.update();});
  def.context.trySubscribe(OTHER);
  def.lifecycle.onCreated(run=>{value.set(run.context.read(KEY).value);missing.set(run.context.tryRead(OTHER)===null);});
  return render=>render.el('output',{},render.read.context.read(KEY).value);
}});