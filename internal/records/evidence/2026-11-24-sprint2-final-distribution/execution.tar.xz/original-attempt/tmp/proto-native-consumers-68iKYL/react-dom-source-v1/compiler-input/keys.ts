import {createContextKey} from '@proto.ui/core';
export const KEY=createContextKey<{value:number}>('consumer-shared-name');
export const OTHER=createContextKey<{value:number}>('consumer-shared-name');