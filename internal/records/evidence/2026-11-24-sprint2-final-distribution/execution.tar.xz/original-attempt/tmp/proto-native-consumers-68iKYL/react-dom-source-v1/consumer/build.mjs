import {mkdirSync,readFileSync,writeFileSync} from 'node:fs';
import path from 'node:path';
import ts from 'typescript';
const provenance=JSON.parse(readFileSync('generated/provenance.json','utf8'));
const sources=provenance.artifacts.filter(file=>file.kind==='source');
const checked=ts.createProgram(sources.map(file=>path.join('generated',file.path)),{
  noEmit:true,strict:true,skipLibCheck:true,allowJs:true,checkJs:false,
  target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,moduleResolution:ts.ModuleResolutionKind.Bundler,jsx:ts.JsxEmit.ReactJSX,
});
const typeErrors=ts.getPreEmitDiagnostics(checked).filter(item=>item.category===ts.DiagnosticCategory.Error);
writeFileSync('typecheck-diagnostics.json',JSON.stringify(typeErrors.map(item=>({file:item.file?.fileName,start:item.start,length:item.length,code:item.code,message:ts.flattenDiagnosticMessageText(item.messageText,'\n')})),null,2)+'\n');
if(typeErrors.length)throw new Error(ts.formatDiagnosticsWithColorAndContext(typeErrors,{getCurrentDirectory:()=>process.cwd(),getCanonicalFileName:file=>file,getNewLine:()=> '\n'}));
const built=[];
const sourcePaths=new Set(sources.map(file=>file.path));
for(const file of sources){
  if(!/\.(?:[cm]?tsx?|jsx?)$/.test(file.path))throw new Error('Unbuildable generated source '+file.path);
  const source=readFileSync(path.join('generated',file.path),'utf8');
  const executableImports=context=>{
    const visit=node=>{
      if((ts.isImportDeclaration(node)||ts.isExportDeclaration(node))&&node.moduleSpecifier&&ts.isStringLiteral(node.moduleSpecifier)&&/^\.\.?\//.test(node.moduleSpecifier.text)){
        const target=path.posix.normalize(path.posix.join(path.posix.dirname(file.path),node.moduleSpecifier.text));
        const resolved=sourcePaths.has(target)?target:['.ts','.tsx','.js','.jsx'].map(extension=>target+extension).find(candidate=>sourcePaths.has(candidate));
        if(!resolved)throw new Error('Generated helper import is not in the delivered artifact closure: '+file.path+' -> '+node.moduleSpecifier.text);
        let specifier=path.posix.relative(path.posix.dirname(file.path),resolved.replace(/\.(?:[cm]?tsx?|jsx?)$/,'.js'));
        if(!specifier.startsWith('./')&&!specifier.startsWith('../'))specifier='./'+specifier;
        const literal=ts.setTextRange(ts.factory.createStringLiteral(specifier),node.moduleSpecifier);
        return ts.isImportDeclaration(node)?ts.factory.updateImportDeclaration(node,node.modifiers,node.importClause,literal,node.attributes):ts.factory.updateExportDeclaration(node,node.modifiers,node.isTypeOnly,node.exportClause,literal,node.attributes);
      }
      return ts.visitEachChild(node,visit,context);
    };
    return tree=>ts.visitNode(tree,visit);
  };
  const result=ts.transpileModule(source,{fileName:file.path,reportDiagnostics:true,transformers:{before:[executableImports]},compilerOptions:{
    target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX,
    rewriteRelativeImportExtensions:true,sourceMap:true,inlineSources:true,removeComments:false,
  }});
  const errors=(result.diagnostics??[]).filter(item=>item.category===ts.DiagnosticCategory.Error);
  writeFileSync('build-diagnostics.json',JSON.stringify({source:file.path,diagnostics:(result.diagnostics??[]).map(item=>({code:item.code,category:item.category,start:item.start,length:item.length,message:ts.flattenDiagnosticMessageText(item.messageText,'\n')}))},null,2)+'\n');
  if(errors.length)throw new Error(ts.formatDiagnosticsWithColorAndContext(errors,{getCurrentDirectory:()=>process.cwd(),getCanonicalFileName:file=>file,getNewLine:()=> '\n'}));
  const output=path.join('dist',file.path.replace(/\.(?:[cm]?tsx?|jsx?)$/,'.js'));
  mkdirSync(path.dirname(output),{recursive:true});writeFileSync(output,result.outputText);
  if(!result.sourceMapText)throw new Error('Missing executable source map '+file.path);
  const map=JSON.parse(result.sourceMapText);
  const emitted=ts.createSourceFile(output,result.outputText,ts.ScriptTarget.ESNext,true,ts.ScriptKind.JS);
  const erasedOnly=emitted.statements.every(node=>ts.isExportDeclaration(node)&&!node.moduleSpecifier&&node.exportClause&&ts.isNamedExports(node.exportClause)&&node.exportClause.elements.length===0);
  if((!map.mappings&&!erasedOnly)||!map.sourcesContent?.includes(source))throw new Error('Executable map lost generated source '+file.path);
  writeFileSync(output+'.map',result.sourceMapText);
  built.push({source:file.path,output,bytes:Buffer.byteLength(result.outputText),map:output+'.map',mapBytes:Buffer.byteLength(result.sourceMapText),erasedOnly});
}
writeFileSync('build-report.json',JSON.stringify({typescript:ts.version,mode:'Strict target/helper TypeScript check followed by executable ESM emission; JavaScript component bodies are not checkJs-validated',typecheck:{errors:typeErrors.length,checkJs:false},files:built},null,2)+'\n');
console.log('NATIVE_BUILD_OK',JSON.stringify(built));