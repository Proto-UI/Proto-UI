import assert from 'node:assert/strict';import {Window} from 'happy-dom';
const window=new Window({url:'http://ordinary.invalid'});
for(const key of ['window','self','document','navigator','Node','Element','HTMLElement','SVGElement','Text','Comment','Event','CustomEvent','MutationObserver'])Object.defineProperty(globalThis,key,{value:key==='window'||key==='self'?window:window[key],configurable:true});
globalThis.IS_REACT_ACT_ENVIRONMENT=true;const React=await import('react');const {createRoot}=await import('react-dom/client');
const {CompiledComponent:Component}=await import('./dist/Component.js');const host=document.createElement('div');document.body.append(host);const root=createRoot(host);
try {await React.act(async()=>root.render(React.createElement(Component)));assert.equal(host.querySelector(process.argv[2]).textContent,'first');await React.act(async()=>root.unmount());assert.equal(host.childNodes.length,0);}finally{await window.happyDOM.abort();window.close();}
console.log('EDITABLE_CONSUMER_PASS',process.argv[2]);