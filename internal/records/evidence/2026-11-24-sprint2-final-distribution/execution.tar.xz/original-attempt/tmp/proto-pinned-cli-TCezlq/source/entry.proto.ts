import {definePrototype} from '@proto.ui/core';import {label} from './label';
export default definePrototype({name:'editable-consumer',setup(def){return r=>r.el('section',label);}});