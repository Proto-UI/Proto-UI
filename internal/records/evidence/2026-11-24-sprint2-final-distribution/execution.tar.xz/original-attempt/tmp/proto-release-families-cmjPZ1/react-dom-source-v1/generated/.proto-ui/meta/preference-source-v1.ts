import { nativeMediaBinding, releaseNativeMeta } from './subscription-v1';
// C-RULE-PREFERENCES-0001: only reached fixed-key MQLs, shared per document/key.
const definitions: Record<string, readonly [string, readonly string[]]> = {
  'preference.reducedMotion': ['prefers-reduced-motion', ['no-preference', 'reduce']],
  'preference.reducedTransparency': ['prefers-reduced-transparency', ['no-preference', 'reduce']],
  'preference.contrast': ['prefers-contrast', ['no-preference', 'less', 'more', 'custom']],
  'preference.forcedColors': ['forced-colors', ['none', 'active']],
};
type Source = { callbacks: Set<() => void>; read(): unknown; stop(): void };
const documents = new WeakMap<Document, Map<string, Source>>();
export function readNativeRulePreference(doc: Document | undefined, key: string): unknown {
  return doc ? documents.get(doc)?.get(key)?.read() ?? 'unknown' : 'unknown';
}
export function subscribeNativeRulePreferences(doc: Document | undefined, keys: readonly string[], notify: () => void): () => void {
  const view = doc?.defaultView;
  if (!doc || typeof view?.matchMedia !== 'function') return () => {};
  let active = true, queued = false;
  const changed = () => { if (!active || queued) return; queued = true; queueMicrotask(() => { queued = false; if (active) notify(); }); };
  const releases: (() => void)[] = [];
  let sources = documents.get(doc); if (!sources) { sources = new Map(); documents.set(doc, sources); }
  try { for (const key of keys) {
    if (!Object.hasOwn(definitions, key)) throw new Error('Unknown generated Rule preference.');
    let source = sources.get(key);
    if (!source) {
      const [feature, values] = definitions[key], getter = view.matchMedia; let queries: MediaQueryList[];
      try { queries = values.map(value => view.matchMedia('(' + feature + ': ' + value + ')')); } catch { continue; }
      const callbacks = new Set<() => void>(); let live = true, ready = false, pending = false;
      const read = () => {
        if (!live || !ready || doc.defaultView !== view || view.matchMedia !== getter) return 'unknown';
        try { const matches = values.filter((_value, index) => queries[index].matches); return matches.length === 1 ? matches[0] : 'unknown'; } catch { return 'unknown'; }
      };
      let previous = read();
      const invalidate = () => { if (!live || pending) return; pending = true; queueMicrotask(() => {
        pending = false; if (!live) return; const next = read();
        if (next === previous) return; previous = next;
        for (const callback of [...callbacks]) if (live && callbacks.has(callback)) callback();
      }); };
      let bindings: ReturnType<typeof nativeMediaBinding>[];
      try { bindings = queries.map(query => typeof query?.matches === 'boolean' ? nativeMediaBinding(query, invalidate) : undefined); } catch { continue; }
      if (bindings.some(binding => !binding)) continue;
      const attached: (() => void)[] = [];
      source = { callbacks, read, stop() { if (!live) return; live = false;
        callbacks.clear(); if (sources!.get(key) === source) sources!.delete(key);
        if (!sources!.size && documents.get(doc) === sources) documents.delete(doc);
        releaseNativeMeta(attached);
      } }; sources.set(key, source);
      try { for (const binding of bindings) { attached.push(binding!.release); binding!.attach(); } ready = true; previous = read(); }
      catch (error) { releaseNativeMeta([() => { throw error; }, () => source!.stop()]); }
    }
    source.callbacks.add(changed); const current = source;
    releases.push(() => { current.callbacks.delete(changed); if (!current.callbacks.size) current.stop(); });
  } } catch (error) { active = false; releaseNativeMeta([() => { throw error; }, ...releases]); }
  return () => { if (!active) return; active = false; releaseNativeMeta(releases); };
}
