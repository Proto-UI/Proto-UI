import { readNativeWebMeta } from './web-snapshot-v1';
import { nativeMediaBinding, releaseNativeMeta } from './subscription-v1';
// C-RULE-COLOR-SCHEME-0001: one document invalidation source, no value bus or author callbacks.
type Service = { callbacks: Set<() => void>; stop(): void };
const services = new WeakMap<Document, Service>();
export function subscribeNativeColorScheme(doc: Document | undefined, notify: () => void): () => void {
  const view = doc?.defaultView;
  if (!doc?.documentElement || !view?.MutationObserver) return () => {};
  let service = services.get(doc);
  if (!service) {
    const callbacks = new Set<() => void>();
    let active = true, queued = false, previous = readNativeWebMeta(doc, 'colorScheme');
    const invalidate = () => {
      if (!active || queued) return;
      queued = true;
      queueMicrotask(() => {
        queued = false; if (!active) return;
        const next = readNativeWebMeta(doc, 'colorScheme');
        if (next === previous) return; previous = next;
        for (const callback of [...callbacks]) if (active && callbacks.has(callback)) callback();
      });
    };
    let query: MediaQueryList | undefined;
    try { query = view.matchMedia?.('(prefers-color-scheme: dark)'); } catch {}
    const observer = new view.MutationObserver(invalidate), binding = nativeMediaBinding(query, invalidate);
    const releases: (() => void)[] = [];
    service = { callbacks, stop() {
      if (!active) return; active = false;
      callbacks.clear(); if (services.get(doc) === service) services.delete(doc);
      releaseNativeMeta(releases);
    } };
    services.set(doc, service);
    try {
      releases.push(() => observer.disconnect());
      observer.observe(doc.documentElement, { attributes: true, attributeFilter: ['class', 'data-theme'] });
      if (binding) { releases.push(binding.release); binding.attach(); }
    } catch (error) { releaseNativeMeta([() => { throw error; }, () => service!.stop()]); }
  }
  // A registration identity allows the same callback to hold independent leases.
  const callback = () => notify(); service.callbacks.add(callback);
  const current = service; let released = false;
  return () => { if (released) return; released = true; current.callbacks.delete(callback); if (!current.callbacks.size) current.stop(); };
}
