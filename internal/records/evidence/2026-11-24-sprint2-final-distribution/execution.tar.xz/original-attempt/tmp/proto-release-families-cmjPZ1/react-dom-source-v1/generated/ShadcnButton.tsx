// Editable generated React DOM source. Profile: react-dom-source-v1.
// Inline owner lowering and emitted shared checked-data/Context helpers v1; no Proto-UI Runtime/Core/Adapter dependencies.
// Source graph SHA-256: 613045c92bd296c60cc58b22780e2885c10f54bd449cd44a899dd58bcabf7502
import * as __pui_React from 'react';
import { releaseNativeMeta as __pui_ReleaseMeta } from './.proto-ui/meta/subscription-v1';
import { readNativeWebMeta as __pui_ReadMeta } from './.proto-ui/meta/web-snapshot-v1';
import { subscribeNativeColorScheme as __pui_SubscribeColorScheme } from './.proto-ui/meta/color-scheme-source-v1';


import { createNativeAuthoredHooks as __pui_CreateAuthored } from './.proto-ui/owner/authored-hooks-v1';
import { createPortal as __pui_CreatePortal } from 'react-dom';



import { createContextScope as __pui_CreateContextScope, acceptsContextValue as __pui_Accepts } from "./.proto-ui/context/scope-v1";
import type { ContextScope as __pui_ContextScope } from "./.proto-ui/context/scope-v1";
import { ContextTransport as __pui_ContextTransport } from './.proto-ui/context/react-v1';
import { createNativeStyle as __pui_CreateNativeStyle, templateStyleTokens as __pui_TemplateStyleTokens, type NativeStyle as __pui_NativeStyle, type NativeStyleHandle as __pui_NativeStyleHandle, type NativeRuleHandle as __pui_NativeRuleHandle } from './.proto-ui/style/native-v1';


import { createNativeInteraction as __pui_CreateNativeInteraction, type NativeInteraction as __pui_NativeInteraction, type NativeFocus as __pui_NativeFocus, type NativeAccessible as __pui_NativeAccessible, type NativeObservedState as __pui_NativeObservedState, type NativeInput as __pui_NativeInput, type NativeFocusOptions as __pui_NativeFocusOptions } from './.proto-ui/interaction/native-e6807d4f71af1465-v2';
import type { NativeModuleCapability as __pui_NativeModuleCapability } from './.proto-ui/interaction/modules-e6807d4f71af1465-v2';
import { key as __pui_ContextKey0 } from "./.proto-ui/context/key-3b78218c16abf6ec58c87de2ca3750964b015dc709f9d123d79d8ddb43fc57f9";

// Source "packages/prototypes/shadcn/src/style-scope/context.ts":4:33
const __puiModule0: ReadonlyArray<"vega" | "nova" | "maia" | "lyra" | "mira" | "luma" | "sera" | "rhea" | "new-york-v4"> = ["vega", "nova", "maia", "lyra", "mira", "luma", "sera", "rhea", "new-york-v4"];
// Source "packages/prototypes/shadcn/src/style-scope/context.ts":23:1
const __puiModule3 = (value: unknown): "vega" | "nova" | "maia" | "lyra" | "mira" | "luma" | "sera" | "rhea" | "new-york-v4" | null => {
  // Source "packages/prototypes/shadcn/src/style-scope/context.ts":24:3
  if ((((value === (void 0)) || (value === null)) || (value === "inherit"))) {
    // Source "packages/prototypes/shadcn/src/style-scope/context.ts":24:69
    return null;
  }
  // Source "packages/prototypes/shadcn/src/style-scope/context.ts":25:3
  if ((value === "new-york")) {
    // Source "packages/prototypes/shadcn/src/style-scope/context.ts":25:29
    return "new-york-v4";
  }
  // Source "packages/prototypes/shadcn/src/style-scope/context.ts":26:3
  if ((__puiModule0 as readonly unknown[]).includes(value)) {
    // Source "packages/prototypes/shadcn/src/style-scope/context.ts":26:58
    return (value as "vega" | "nova" | "maia" | "lyra" | "mira" | "luma" | "sera" | "rhea" | "new-york-v4");
  }
  // Source "packages/prototypes/shadcn/src/style-scope/context.ts":27:3
  throw new Error(("[shadcn-style-scope] Unknown style: " + String(value)));
};


export type GeneratedProps = {
  "variant"?: "default" | "destructive" | "ghost" | "link" | "outline" | "secondary" | null;
  "size"?: "default" | "icon" | "icon-compact" | "lg" | "sm" | null;
  "disabled"?: boolean | null;
  "wrap"?: boolean | null;
  "styleProfile"?: "inherit" | "luma" | "lyra" | "maia" | "mira" | "new-york" | "new-york-v4" | "nova" | "rhea" | "sera" | "vega" | null;
};
export type GeneratedExposes = {
  "disabled": __pui_ExternalState<boolean>;
  "hovered": __pui_ExternalState<boolean>;
  "focused": __pui_ExternalState<boolean>;
  "focusVisible": __pui_ExternalState<boolean>;
  "focusSelf": (options?: { "reason"?: "programmatic" | "keyboard" | "pointer"; "preventScroll"?: boolean }) => void;
  "pressed": __pui_ExternalState<boolean>;
  "click": { readonly kind: 'event'; readonly payload: "void" };
};
export type GeneratedComponentProps = GeneratedProps & Omit<__pui_React.HTMLAttributes<HTMLElement>, keyof GeneratedProps | 'dangerouslySetInnerHTML' | "onClick"> & {
  children?: __pui_React.ReactNode;
  /** The physical element is a target affordance, never a portable Proto expose. */
  hostRef?: __pui_React.Ref<HTMLElement>;
  hostProps?: Omit<__pui_React.AllHTMLAttributes<HTMLElement> & __pui_React.AnchorHTMLAttributes<HTMLElement>, 'children' | 'dangerouslySetInnerHTML'>;
  instanceAssociations?: Readonly<{ controlLabel?: object | null }>;
  "onClick"?: () => void;
  [event: `on${string}`]: unknown;
};
export interface GeneratedHandle {
  update(): void;
  getElement(): HTMLElement | null;
  getExposes(): GeneratedExposes;
  invokeInCallbackScope<T>(callback: () => T): T;
}
type __pui_ResolvedProps = Readonly<{ "variant": "default" | "destructive" | "outline" | "secondary" | "ghost" | "link"; "size": "default" | "sm" | "lg" | "icon" | "icon-compact"; "disabled": boolean; "wrap": boolean; "styleProfile": "vega" | "nova" | "maia" | "lyra" | "mira" | "luma" | "sera" | "rhea" | "new-york-v4" | "new-york" | "inherit" }>;
type __pui_StateEvent<T> = { type: 'next'; prev: T; next: T; reason?: unknown } | { type: 'disconnect'; reason: 'unmount' };
type __pui_ExternalState<T> = {
  get(): T;
  subscribe(callback: (event: __pui_StateEvent<T>) => void): () => void;
  unsubscribe(off: () => void): void;
  readonly spec: Readonly<__pui_StateSpec>;
};
type __pui_State<T> = { get(): T; setDefault(value: T): void; set(value: T, reason?: unknown): void };
type __pui_StateSpec = { kind: 'bool' | 'enum' | 'string' | 'number.discrete' | 'number.range'; options?: readonly (string | number)[]; min?: number; max?: number; step?: number; clamp?: boolean };
type __pui_DataSchema = string | { kind: string; fields?: readonly { name: string; type: __pui_DataSchema; optional?: boolean }[]; element?: __pui_DataSchema; members?: readonly __pui_DataSchema[]; value?: unknown };
type __pui_PropSpec = { type: __pui_DataSchema; default?: unknown; empty?: 'accept' | 'fallback' | 'error'; options?: readonly string[]; range?: { min?: number; max?: number }; validator?: (value: never) => boolean };
type __pui_Run = {
  update(): void;
  feedback: { style: Pick<__pui_NativeStyle, 'patch' | 'suppress' | 'clearPatch'> };
  props: { get(): __pui_ResolvedProps; getRaw(): Readonly<Record<string, unknown>>; isProvided(key: string): boolean };
  context: {
    read<T>(key: object): T;
    tryRead<T>(key: object): T | null;
    tryReadAncestor<T>(key: object): T | null;
    update<T>(key: object, next: T | ((prev: T) => T)): void;
    tryUpdate<T>(key: object, next: T | ((prev: T) => T)): boolean;
  };
  expose: { emit(key: string, payload?: unknown, options?: Record<string, unknown>): void };
  lifecycle: { setPresent(present: boolean): void };
};
type __pui_Frame = { revision: number; epoch: number; kind: 'mount' | 'update' | 'detach'; node: __pui_React.ReactNode };
type __pui_Owner = {
  handle: GeneratedHandle;
  scope: __pui_ContextScope;
  getHostProjection(): { tag: string; properties: Readonly<Record<string, string | number | boolean | null>>; portalTarget: HTMLElement | null };
  bindRoot(root: HTMLElement | null): void;
  connect(): void;
  connectView(): void;
  disconnectView(): void;
  commitHost(): void;
  start(): void;
  applyProps(props: GeneratedComponentProps): void;
  accept(frame: __pui_Frame): boolean;
  disconnect(): void;

};

const __pui_Slots = new WeakSet<object>();
const __pui_PortablePropNames = new Set<string>(["variant","size","disabled","wrap","styleProfile"]);
const __pui_OutwardEventNames = new Set<string>(["onClick"]);
function __pui_HostProperties(props: GeneratedComponentProps): Record<string, unknown> {
  const result: Record<string, unknown> = { ...props.hostProps };
  for (const [key, value] of Object.entries(props)) {
    if (__pui_PortablePropNames.has(key) || __pui_OutwardEventNames.has(key)
      || ['children', 'hostRef', 'hostProps', 'instanceAssociations', 'key', 'ref', 'dangerouslySetInnerHTML'].includes(key)) continue;
    result[key] = value;
  }
  // Explicit native host fields cannot create a second subscriber to an outward
  // Proto signal, replace the slot tree, or steal the compiler's physical ref.
  for (const key of [...__pui_OutwardEventNames, 'children', 'ref', 'key', 'dangerouslySetInnerHTML']) delete result[key];
  return result;
}
function __pui_AssignHostRef(ref: __pui_React.Ref<HTMLElement> | undefined, element: HTMLElement | null): void {
  if (typeof ref === 'function') ref(element);
  else if (ref) (ref as __pui_React.MutableRefObject<HTMLElement | null>).current = element;
}
function __pui_BindSlots(node: __pui_React.ReactNode, slot: __pui_React.ReactNode): __pui_React.ReactNode {
  if (Array.isArray(node)) {
    let result: __pui_React.ReactNode[] | null = null;
    for (let index = 0; index < node.length; index++) {
      const child = __pui_BindSlots(node[index], slot);
      if (child !== node[index]) { result ??= node.slice(); result[index] = child; }
    }
    return result ?? node;
  }
  if (!__pui_React.isValidElement(node)) return node;
  const element = node as __pui_React.ReactElement<{ children?: __pui_React.ReactNode }>;
  if (__pui_Slots.has(element)) return __pui_React.createElement(__pui_React.Fragment, { key: element.key }, slot);
  const previous = element.props.children, next = __pui_BindSlots(previous, slot);
  return previous === next ? node : __pui_React.cloneElement(element, undefined, next);
}
function __pui_RootProperties(properties: Readonly<Record<string, unknown>>, initial = false): Record<string, unknown> {
  const result: Record<string, unknown> = { ...properties };
  // Only server/initial hydration markup projects the canonical value through
  // defaultValue. A live native TextControl owns editing and its reset default;
  // its commit hook restores those fields after React's host reconciliation.
  if (Object.hasOwn(result, 'value')) { result.defaultValue = initial ? result.value : undefined; delete result.value; }
  if (typeof result.style === 'string') {
    const style: Record<string, string> = {};
    for (const declaration of result.style.split(';')) {
      const colon = declaration.indexOf(':');
      if (colon < 1) continue;
      const name = declaration.slice(0, colon).trim();
      style[name.startsWith('--') ? name : name.replace(/-([a-z])/g, (_match, letter: string) => letter.toUpperCase())] = declaration.slice(colon + 1).trim();
    }
    result.style = style;
  }
  return result;
}
function __pui_HasRootContent(node: __pui_React.ReactNode): boolean {
  if (node === null || node === undefined || typeof node === 'boolean' || node === '') return false;
  if (Array.isArray(node)) return node.some(__pui_HasRootContent);
  if (__pui_React.isValidElement(node) && node.type === __pui_React.Fragment)
    return __pui_HasRootContent((node.props as { children?: __pui_React.ReactNode }).children);
  return true;
}
function __pui_RenderRoot(tag: string, attributes: Record<string, unknown>, children: __pui_React.ReactNode): __pui_React.ReactElement {
  if (['input', 'textarea', 'img', 'area', 'base', 'br', 'col', 'embed', 'hr', 'link', 'meta', 'param', 'source', 'track', 'wbr'].includes(tag)) {
    if (__pui_HasRootContent(children)) throw new TypeError('[Template] this physical control Root cannot contain semantic children.');
    return __pui_React.createElement(tag, attributes);
  }
  return __pui_React.createElement(tag, attributes, children);
}

function __pui_ResolveProps(
  specs: Readonly<Record<string, __pui_PropSpec>>,
  defaults: readonly Readonly<Record<string, unknown>>[],
  previousValid: Record<string, unknown>,
  raw: Readonly<Record<string, unknown>>,
  strict: boolean
): __pui_ResolvedProps {
  const next: Record<string, unknown> = Object.create(null);
  for (const key of Object.keys(specs)) {
    const spec = specs[key];
    const provided = Object.hasOwn(raw, key);
    const value = raw[key];
    const empty = value === null || value === undefined;
    const valid = (candidate: unknown) => {
      if (!__pui_Accepts(spec.type, candidate) || spec.range && !(typeof candidate === 'number'
        && candidate >= (spec.range.min ?? -Infinity) && candidate <= (spec.range.max ?? Infinity))) return false;
      // The checked schema establishes the validator's declared argument domain.
      // A throwing validator rejects this candidate, as in ordinary Props.
      try { return spec.validator ? !!spec.validator(candidate as never) : true; }
      catch { return false; }
    };
    if (provided && !empty && valid(value)) {
      next[key] = value;
      previousValid[key] = value;
      continue;
    }
    if (provided && empty && spec.empty === 'accept') { next[key] = null; continue; }
    const nonEmpty = strict && spec.empty === 'error';
    let found = false;
    const take = (candidate: unknown) => {
      if (candidate === undefined || nonEmpty && candidate === null) return false;
      if (candidate !== null && !valid(candidate)) return false;
      next[key] = candidate;
      found = true;
      return true;
    };
    if (provided && Object.hasOwn(previousValid, key)) take(previousValid[key]);
    if (!found) for (const layer of defaults) if (Object.hasOwn(layer, key) && take(layer[key])) break;
    if (!found && Object.hasOwn(spec, 'default')) take(spec.default);
    if (!found) {
      if (nonEmpty) throw new Error('[Props] missing, empty or invalid prop without non-empty fallback: ' + key);
      next[key] = null;
    }
    if (provided && next[key] !== null) previousValid[key] = next[key];
  }
  return Object.freeze(next) as __pui_ResolvedProps;
}

function __pui_CompleteSteps(steps: readonly (() => void)[]): void {
  let failure: { error: unknown } | undefined;
  for (const step of steps) { try { step(); } catch (error) { failure ??= { error }; } }
  if (failure) throw failure.error;
}

function __pui_CreateOwner(initial: GeneratedComponentProps, publish: (frame: __pui_Frame) => void, getParent: () => __pui_ContextScope | null, publishHost: () => void): __pui_Owner {
  let phase: 'setup' | 'callback' | 'render' | 'idle' = 'setup';
  let lifetime: 'alive' | 'disposing' | 'disposed' = 'alive';
  let connected = true;
  let cleanupVersion = 0;
  let desiredPresent = true;
  let mounted = false;
  let viewConnected = false;
  let epoch = 0;
  let revision = 0;
  let acceptedRevision = 0;
  let latest: __pui_Frame | null = null;
  let dirty = false;
  let updateQueued = false;
  let scheduled = false;
  let hostScheduled = false;
  let callbackDepth = 0;
  let slotUsed = false;
  let elementSequence = 0;
  let hostProps = initial;
  let root: HTMLElement | null = null;
  let rootGeneration = 0;
  let rootBinding: 'retiring' | 'binding' | null = null;
  let pendingRoot: { value: HTMLElement | null } | undefined;
  function consumePendingRoot(): { value: HTMLElement | null } | undefined {
    const request = pendingRoot; pendingRoot = undefined; return request;
  }

  let raw: Readonly<Record<string, unknown>> = Object.freeze({});
  let resolved: __pui_ResolvedProps;
  let hydrated = false;
  let propsWindow: { raw: Readonly<Record<string, unknown>>; resolved: __pui_ResolvedProps } | null = null;
  const specs: Record<string, __pui_PropSpec> = Object.create(null);
  const defaults: Readonly<Record<string, unknown>>[] = [];
  const previousValid: Record<string, unknown> = Object.create(null);
  const stateNames = new Set<string>();
  // Reserve before setup; only successful setup publishes a reusable opaque result.

  const stateSubscribers = new Set<Set<(event: __pui_StateEvent<unknown>) => void>>();
  const pendingStateEvents: (() => void)[] = [];
  const authorStateWatchCleanups: (() => void)[] = [];
  let emittingState = false;
  type __pui_ResolvedWatcher = { active: boolean; keys: readonly string[] | null; callback: (run: __pui_Run, next: __pui_ResolvedProps, prev: __pui_ResolvedProps, info: Readonly<Record<string, unknown>>) => void };
  type __pui_RawWatcher = { active: boolean; keys: readonly string[] | null; callback: (run: __pui_Run, next: Readonly<Record<string, unknown>>, prev: Readonly<Record<string, unknown>>, info: Readonly<Record<string, unknown>>) => void };
  const watchers: __pui_ResolvedWatcher[] = [];
  const rawWatchers: __pui_RawWatcher[] = [], rawAllWatchers: __pui_RawWatcher[] = [];
  const exposes: Record<string, unknown> = Object.create(null);
  const methodSchemas: Record<string, { args(args: unknown[]): boolean; result(value: unknown): boolean }> = {
    "focusSelf": { args: (args: unknown[]) => args.length <= 1 && (args[0] === undefined || __pui_Accepts({"kind":"record","fields":[{"name":"reason","optional":true,"type":{"kind":"union","members":[{"kind":"literal","value":"programmatic"},{"kind":"literal","value":"keyboard"},{"kind":"literal","value":"pointer"}]}},{"name":"preventScroll","optional":true,"type":"boolean"}]}, args[0])), result: (result: unknown) => __pui_Accepts("void", result) },
  };
  const eventSchemas: Record<string, __pui_DataSchema> = {
    "click": "void",
  };
  const propSchemas: Record<string, __pui_DataSchema> = {
    "variant": {"kind":"union","members":[{"kind":"literal","value":"default"},{"kind":"literal","value":"destructive"},{"kind":"literal","value":"outline"},{"kind":"literal","value":"secondary"},{"kind":"literal","value":"ghost"},{"kind":"literal","value":"link"}]},
    "size": {"kind":"union","members":[{"kind":"literal","value":"default"},{"kind":"literal","value":"sm"},{"kind":"literal","value":"lg"},{"kind":"literal","value":"icon"},{"kind":"literal","value":"icon-compact"}]},
    "disabled": "boolean",
    "wrap": "boolean",
    "styleProfile": {"kind":"union","members":[{"kind":"literal","value":"vega"},{"kind":"literal","value":"nova"},{"kind":"literal","value":"maia"},{"kind":"literal","value":"lyra"},{"kind":"literal","value":"mira"},{"kind":"literal","value":"luma"},{"kind":"literal","value":"sera"},{"kind":"literal","value":"rhea"},{"kind":"literal","value":"new-york-v4"},{"kind":"literal","value":"new-york"},{"kind":"literal","value":"inherit"}]},
  };
  const callbacks = {
    created: [] as ((run: __pui_Run) => void)[], mounted: [] as ((run: __pui_Run) => void)[],
    updated: [] as ((run: __pui_Run) => void)[], unmounted: [] as ((run: __pui_Run) => void)[],
    beforeDispose: [] as ((run: __pui_Run) => void)[],
  };
  function ensureAlive() {
    if (lifetime === 'disposed' || !connected && phase !== 'callback')
      throw new Error('Generated handle is invalid after terminal disposal.');
  }
  function ensurePhase(expected: typeof phase) {
    ensureAlive();
    if (phase !== expected) throw new Error('Illegal generated operation phase: ' + phase + '; expected ' + expected);
  }
  function ensureExternal() {
    if (!connected || lifetime !== 'alive') throw new Error('Generated handle is invalid after terminal disposal begins.');
  }
  function invoke<T>(callback: () => T): T {
    ensureAlive();
    if (phase === 'render' || phase === 'setup') throw new Error('Cannot enter callback scope from ' + phase);
    const previous = phase;
    phase = 'callback';
    ++callbackDepth;
    try { return callback(); }
    finally { phase = previous; --callbackDepth; if (!callbackDepth) schedule(); }
  }
  const __pui_Meta = (key: string) => __pui_ReadMeta(root?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), key);
  const __pui_Authored = __pui_CreateAuthored({setup: () => ensurePhase('setup'), borrow(value) {
    const state = value as __pui_State<unknown>, external = externalStates.get(state) as __pui_ExternalState<unknown> | undefined;
    if (!external) throw new Error('[State] borrowed state must belong to this instance.');
    const borrowed = Object.freeze({ get: () => state.get(), setDefault: (value: unknown) => state.setDefault(value), set: (value: unknown, reason?: unknown) => state.set(value, reason), watch(callback: (run: __pui_Run, event: __pui_StateEvent<unknown>) => void) { ensurePhase('setup'); const off = external.subscribe(event => invoke(() => callback(__pui_RunHandle, event))); authorStateWatchCleanups.push(off); return off; } });
    // A capture borrows the same owner State; native modules must retain its provenance.
    externalStates.set(borrowed, external);

    return borrowed;
  } });
  
  const context = __pui_CreateContextScope({
    getParent, isAlive: () => lifetime !== 'disposed', invoke,
    validate: (key: object, value: unknown): boolean => key === __pui_ContextKey0 ? __pui_Accepts({"kind":"record","fields":[{"name":"style","type":{"kind":"union","members":[{"kind":"literal","value":"vega"},{"kind":"literal","value":"nova"},{"kind":"literal","value":"maia"},{"kind":"literal","value":"lyra"},{"kind":"literal","value":"mira"},{"kind":"literal","value":"luma"},{"kind":"literal","value":"sera"},{"kind":"literal","value":"rhea"},{"kind":"literal","value":"new-york-v4"},"null"]}}]}, value) : false,
  });
  function projectStyle(tokens: readonly string[]) {
    if (!root) return;
    if (tokens.length) root.setAttribute('data-pui-style', tokens.join(' '));
    else root.removeAttribute('data-pui-style');
  }
  const __pui_Style = __pui_CreateNativeStyle({
    ensureSetup: () => ensurePhase('setup'),
    ensureRuntime: () => ensurePhase('callback'),
    isAlive: () => lifetime !== 'disposed',
    project: tokens => { projectStyle(tokens);  },
    getMeta: (key: string) => key === 'colorScheme' ? __pui_ReadMeta(root?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), key) : undefined, subscribeMeta: (notify: () => void) => { const leases: (() => void)[] = []; try { leases.push(__pui_SubscribeColorScheme(root?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), notify)); } catch (error) { __pui_ReleaseMeta([() => { throw error; }, ...leases]); } return () => __pui_ReleaseMeta(leases); },
  });
  function dispatch(list: readonly ((run: __pui_Run) => void)[]) {
    invoke(() => { for (const callback of list) callback(__pui_RunHandle); });
  }
  function detachView() {
    const wasMounted = mounted; mounted = false;
    __pui_CompleteSteps([
      () => __pui_Interaction.unmount(),
      () => __pui_Style.unmount(),
      () => { if (wasMounted) dispatch(callbacks.unmounted); },
    ]);
  }
  function schedule() {
    if (scheduled || callbackDepth || !connected || lifetime !== 'alive') return;
    if (!updateQueued && desiredPresent === mounted && !(!desiredPresent && root) && !(latest && latest.revision > acceptedRevision)) return;
    scheduled = true;
    queueMicrotask(() => {
      scheduled = false;
      if (!connected || lifetime !== 'alive') return;
      if (latest && latest.revision > acceptedRevision) return;
      if (!desiredPresent) {
        if (mounted || root) deliver('detach');
        else { dirty = dirty || updateQueued; updateQueued = false; }
      } else if (!mounted) deliver('mount');
      else if (updateQueued) deliver('update');
    });
  }
  function deliver(kind: __pui_Frame['kind']) {
    updateQueued = false;
    let node: __pui_React.ReactNode = null;
    if (kind === 'mount') ++epoch;
    if (kind !== 'detach') {
      slotUsed = false;
      elementSequence = 0;
      phase = 'render';
      try { node = normalize(render(__pui_Renderer));  }
      finally { phase = 'idle'; }
      dirty = false;
    }
    latest = { revision: ++revision, epoch, kind, node };
    publish(latest);
  }
  function normalize(value: unknown): __pui_React.ReactNode {
    if (value === null) return null;
    if (Array.isArray(value)) return value.flatMap((item) => {
      const child = normalize(item);
      return child === null ? [] : [child];
    });
    if (typeof value === 'string' || typeof value === 'number' && Number.isFinite(value) || __pui_React.isValidElement(value)) return value;
    throw new Error('[Template] child must be null, text, a finite number or an authored element/slot.');
  }
  function __pui_Element(tag: string, ...args: unknown[]) {
    ensurePhase('render');
    if (!tag || typeof tag !== 'string') throw new Error('[Template] native elements require a tag string.');
    let children: unknown = null;
    let props: Record<string, unknown> = {};
    if (args.length === 1) {
      const argument = args[0];
      if (argument !== null && typeof argument === 'object' && !Array.isArray(argument) && !__pui_React.isValidElement(argument)) {
        props = argument as Record<string, unknown>;
      } else children = argument;
    } else if (args.length === 2) {
      if (!args[0] || typeof args[0] !== 'object' || Array.isArray(args[0]))
        throw new Error('[Template] native template props must be a record.');
      props = args[0] as Record<string, unknown>;
      children = args[1];
    }
    if (Object.keys(props).some((key) => key !== 'style'))
      throw new Error('[Template] native template props support only style.');
    const tokens = Object.hasOwn(props, 'style') ? __pui_TemplateStyleTokens(props.style as __pui_NativeStyleHandle) : '';
    const normalized = normalize(children);
    return __pui_React.createElement(tag, { key: elementSequence++, ...(tokens ? { 'data-pui-style': tokens } : {}) }, ...(Array.isArray(normalized) ? normalized : [normalized]));
  }
  const __pui_Renderer = {
    read: Object.freeze({
      props: Object.freeze({
        get() { ensurePhase('render'); return resolved; },
        getRaw() { ensurePhase('render'); return raw; },
        isProvided(key: string) { ensurePhase('render'); return Object.hasOwn(raw, key); },
      }),
      context: Object.freeze({
        read<T>(key: object): T { ensurePhase('render'); return context.read<T>(key); },
        tryRead<T>(key: object): T | null { ensurePhase('render'); return context.tryRead<T>(key); },
      }),
    }),
    el: __pui_Element,


    slot: () => {
      ensurePhase('render');
      if (slotUsed) throw new Error('[Template] multiple anonymous slots are not supported.');
      slotUsed = true;
      const slot = __pui_React.createElement(__pui_React.Fragment, { key: elementSequence++ });
      __pui_Slots.add(slot);
      return slot;
    },
  };
  function __pui_CreateState<T extends boolean | string | number>(name: string, initialValue: T, spec: __pui_StateSpec): __pui_State<T> {
    ensurePhase('setup');
    __pui_Authored.claimState(name);
    spec = Object.freeze({ ...spec, ...(spec.options ? { options: Object.freeze([...spec.options]) } : {}) });
    const type = spec.kind === 'bool' ? 'boolean' : spec.kind === 'string' || spec.kind === 'enum' ? 'string' : 'number';
    if (spec.options?.some((option) => typeof option !== type || typeof option === 'number' && !Number.isFinite(option)))
      throw new Error('[State] invalid state options: ' + name);
    if (spec.kind === 'number.range' && (!Number.isFinite(spec.min) || !Number.isFinite(spec.max))
      || spec.min !== undefined && !Number.isFinite(spec.min) || spec.max !== undefined && !Number.isFinite(spec.max)
      || spec.min !== undefined && spec.max !== undefined && spec.min > spec.max
      || spec.step !== undefined && !Number.isFinite(spec.step))
      throw new Error('[State] invalid numeric domain: ' + name);
    function validate(next: T) {
      if (typeof next !== type || typeof next === 'number' && !Number.isFinite(next))
        throw new TypeError('[State] invalid state value: ' + name);
      if (spec.kind === 'enum' && !spec.options?.includes(next as string)) throw new Error('[State] enum value outside options: ' + name);
      if (spec.options?.length && (spec.kind === 'enum' || spec.kind === 'string' || spec.kind === 'number.discrete')) {
        if (!spec.options.includes(next as string | number)) throw new Error('[State] state value outside options: ' + name);
        return;
      }
      if (typeof next !== 'number') return;
      if (next < (spec.min ?? -Infinity) || next > (spec.max ?? Infinity))
        throw new Error('[State] state value outside range: ' + name);
      if (spec.kind === 'number.discrete' && spec.step !== undefined && spec.step > 0
        && !Number.isInteger((next - (spec.min ?? 0)) / spec.step))
        throw new Error('[State] state value violates step: ' + name);
    }
    let value = initialValue;
    // Core range clamping normalizes definition defaults only, never callback writes.
    if (spec.kind === 'number.range' && spec.clamp && typeof value === 'number' && Number.isFinite(value))
      value = Math.min(spec.max!, Math.max(spec.min!, value)) as T;
    validate(value);
    stateNames.add(name);
    const subscribers = new Set<(event: __pui_StateEvent<T>) => void>();
    stateSubscribers.add(subscribers as Set<(event: __pui_StateEvent<unknown>) => void>);
    const state = {
      get() { ensureAlive(); return value; },
      setDefault(next: T) { ensurePhase('setup'); validate(next); value = next; },
      set(next: T, reason?: unknown) {
        ensurePhase('callback');
        validate(next);
        if (Object.is(value, next)) return;
        const event: __pui_StateEvent<T> = { type: 'next', prev: value, next, reason };
        value = next;
        __pui_Style.refresh();
        
        __pui_Interaction.refresh();
        for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(pendingStateEvents, pendingStateEvents.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!emittingState) {
  emittingState = true;
  const notificationFailures: unknown[] = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < pendingStateEvents.length) {
      try { pendingStateEvents[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { pendingStateEvents.length = 0; emittingState = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
      },
    };
    const external: __pui_ExternalState<T> = Object.freeze({
      get() { ensureExternal(); return state.get(); },
      subscribe(callback: (event: __pui_StateEvent<T>) => void) {
        ensureExternal(); const registration: typeof callback = event => callback(event); subscribers.add(registration); return () => { subscribers.delete(registration); };
      },
      unsubscribe(off: () => void) { off(); },
      spec: Object.freeze(spec),
    });
    externalStates.set(state, external);
    
    __pui_Authored.state(name, state);
    return state;
  }
  const externalStates = new WeakMap<object, unknown>();
  const observedStateCleanups: (() => void)[] = [];
  function registerObservedState<T extends boolean | string | number>(state: __pui_NativeObservedState<T>) {
    const subscribers = new Set<(event: __pui_StateEvent<T>) => void>();
    stateSubscribers.add(subscribers as Set<(event: __pui_StateEvent<unknown>) => void>);
    observedStateCleanups.push(state.subscribe((event) => {
      __pui_Style.refresh();
      
      __pui_Interaction.refresh();
      for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(pendingStateEvents, pendingStateEvents.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!emittingState) {
  emittingState = true;
  const notificationFailures: unknown[] = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < pendingStateEvents.length) {
      try { pendingStateEvents[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { pendingStateEvents.length = 0; emittingState = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
    }));
    const kind = typeof state.get();
    const external: __pui_ExternalState<T> = Object.freeze({
      get() { ensureExternal(); return state.get(); },
      subscribe(callback: (event: __pui_StateEvent<T>) => void) {
        ensureExternal(); const registration: typeof callback = event => callback(event); subscribers.add(registration); return () => { subscribers.delete(registration); };
      },
      unsubscribe(off: () => void) { off(); },
      spec: Object.freeze({ kind: kind === 'boolean' ? 'bool' as const : kind === 'number' ? 'number.discrete' as const : 'string' as const }),
    });
    externalStates.set(state, external);
    
  }
  const __pui_Interaction: __pui_NativeInteraction<__pui_Run> = __pui_CreateNativeInteraction<__pui_Run>({
    ensureSetup: () => ensurePhase('setup'),
    ensureRuntime: () => ensurePhase('callback'),
    ensureEvent: () => ensurePhase('callback'),
    isAlive: () => lifetime !== 'disposed',
    isSetupComplete: () => phase !== 'setup',
    isReady: () => phase !== 'setup' && mounted && viewConnected && desiredPresent && connected && lifetime === 'alive',
    invoke,
    getRun: () => __pui_RunHandle,
    getResolvedProps: () => resolved,
    getAssociations: () => hostProps.instanceAssociations,

    subscribeState(state, callback) { return (externalStates.get(state) as __pui_ExternalState<unknown> | undefined)?.subscribe(callback) ?? (state as __pui_NativeObservedState<unknown>).subscribe(callback); },
    getRoot: () => viewConnected ? root : null,
    identity: context,
    getLogicalParent: getParent,
    declarations: [],
    tableFamily: undefined,
    getExposes: () => connected && lifetime === 'alive' ? exposes : {},
    registerExpose(key, value) {
      const state = value && typeof value === 'object' ? externalStates.get(value) : undefined;
      if (state) registerExpose(key, state);
      else if (typeof value === 'function') registerExpose(key, (...args: unknown[]) => { ensureExternal(); return invoke(() => value(...args)); });
      else registerExpose(key, value);
    },
    createOwnedState: <T extends boolean | string | number>(name: string, value: T, spec?: __pui_StateSpec) => __pui_CreateState(name, value, spec ?? { kind: typeof value === 'boolean' ? 'bool' : typeof value === 'number' ? 'number.discrete' : 'string' }),
    watchState<T>(state: {get(): T}, callback: (run: __pui_Run, event: __pui_StateEvent<T>) => void) {
      ensurePhase('setup');
      const external = externalStates.get(state) as __pui_ExternalState<T>;
      if (!external) throw new Error('[State] foreign watch target');
      const off = external.subscribe(event => invoke(() => callback(__pui_RunHandle, event)));
      authorStateWatchCleanups.push(off); return off;
    },
    isPropProvided: key => Object.hasOwn(raw, key),
    setPresent: value => __pui_RunHandle.lifecycle.setPresent(value),
    requestHostUpdate() {
      if (hostScheduled || lifetime !== 'alive') return;
      hostScheduled = true;
      queueMicrotask(() => { hostScheduled = false; if (connected && lifetime === 'alive') publishHost(); });
    },
    registerGenericObservedState: registerObservedState,
    emit: key => __pui_RunHandle.expose.emit(key),
  });
  function disposeInteraction() {
    __pui_CompleteSteps([() => __pui_Interaction.dispose(), ...observedStateCleanups.splice(0), ...authorStateWatchCleanups.splice(0)]);
  }
  const __pui_RunHandle: __pui_Run = {
    feedback: { style: __pui_Style },
    update() {
      ensurePhase('callback');
      if (lifetime !== 'alive') return;
      dirty = true;
      if (desiredPresent && mounted) updateQueued = true;
      schedule();
    },
    props: {
      get() { ensureAlive(); return propsWindow?.resolved ?? resolved; },
      getRaw() { ensureAlive(); return propsWindow?.raw ?? raw; },
      isProvided(key: string) { ensureAlive(); return Object.hasOwn(propsWindow?.raw ?? raw, key); },
    },
    context: Object.freeze({
      read<T>(key: object): T { ensurePhase('callback'); return context.read<T>(key); },
      tryRead<T>(key: object): T | null { ensurePhase('callback'); return context.tryRead<T>(key); },
      tryReadAncestor<T>(key: object): T | null { ensurePhase('callback'); return context.tryReadAncestor<T>(key); },
      update<T>(key: object, next: T | ((prev: T) => T)) { ensurePhase('callback'); context.update(key, next); },
      tryUpdate<T>(key: object, next: T | ((prev: T) => T)) { ensurePhase('callback'); return context.tryUpdate(key, next); },
    }),
    expose: { emit(key, payload, options) {
      ensurePhase('callback');
      const declaration = exposes[key] as { kind?: string; payload: __pui_DataSchema } | undefined;
      if (declaration?.kind !== 'event') throw new Error('[Expose] event was not declared: ' + key);
      if (!__pui_Accepts(declaration.payload, payload)) throw new TypeError('[Expose] invalid event payload: ' + key);
      const sink = (hostProps as Record<string, unknown>)['on' + key.charAt(0).toUpperCase() + key.slice(1)];
      if (typeof sink === 'function') { try { sink(payload, options); } catch { /* Host sink failures do not re-enter prototype execution. */ } }
    } },
    lifecycle: { setPresent(present) {
      ensurePhase('callback');
      if (lifetime !== 'alive') throw new Error('[Lifecycle] cannot update view presence after terminal disposal begins.');
      if (typeof present !== 'boolean') throw new Error('[Lifecycle] view presence must be boolean.');
      if (desiredPresent === present) return;
      desiredPresent = present;
      schedule();
    } },
  };
  function registerExpose(key: string, value: unknown) {
    ensurePhase('setup');
    if (!key || Object.hasOwn(exposes, key)) throw new Error('[Expose] empty or duplicate declaration: ' + key);
    exposes[key] = value;
  }
  const __pui_Def = {
    event: __pui_Interaction.event,
    feedback: { style: { use: __pui_Style.use, declareDecoration: __pui_Style.declareDecoration, to: __pui_Style.to } },
    context: Object.freeze({
      provide<T>(key: object, value: T) { ensurePhase('setup'); context.provide(key, value); },
      subscribe<T>(key: object, callback?: (run: __pui_Run, next: T, prev: T) => void) {
        ensurePhase('setup');
        return context.subscribe<T>(key, 'required', callback ? (next, prev) => callback(__pui_RunHandle, next as T, prev as T) : undefined);
      },
      trySubscribe<T>(key: object, callback?: (run: __pui_Run, next: T | null, prev: T | null) => void) {
        ensurePhase('setup');
        return context.subscribe<T>(key, 'optional', callback ? (next, prev) => callback(__pui_RunHandle, next, prev) : undefined);
      },
      trySubscribeAncestor<T>(key: object, callback?: (run: __pui_Run, next: T | null, prev: T | null) => void) {
        ensurePhase('setup');
        return context.subscribe<T>(key, 'optional', callback ? (next, prev) => callback(__pui_RunHandle, next, prev) : undefined, 'ancestor');
      },
    }),
    props: {
      define(incoming: Record<string, Omit<__pui_PropSpec, 'type'> & { type: __pui_DataSchema | 'enum' | 'object' | 'any' }>) {
        ensurePhase('setup');
        const next = { ...specs };
        for (const [key, authored] of Object.entries(incoming)) {
          const schema = propSchemas[key];
          if (!schema) throw new Error('[Props] missing checked declaration: ' + key);
          const spec: __pui_PropSpec = { ...authored, type: schema };
          const previous = specs[key];
          if (!previous) { next[key] = { ...spec }; continue; }
          if (previous.validator && previous.validator !== spec.validator)
            throw new Error('[Props] validator replacement or removal is disallowed: ' + key);
          const rank = (empty: __pui_PropSpec['empty']) => empty === 'accept' ? 0 : empty === 'error' ? 2 : 1;
          if (JSON.stringify(previous.type) !== JSON.stringify(spec.type) || Object.hasOwn(spec, 'empty') && rank(spec.empty) > rank(previous.empty)
            || previous.range && spec.range && ((spec.range.min ?? -Infinity) > (previous.range.min ?? -Infinity)
              || (spec.range.max ?? Infinity) < (previous.range.max ?? Infinity)))
            throw new Error('[Props] conflicting or stricter prop definition: ' + key);
          next[key] = { ...previous, ...spec, empty: previous.empty ?? 'fallback', range: spec.range ?? previous.range };
          if (Object.hasOwn(previous, 'default')) next[key].default = previous.default;
        }
        Object.assign(specs, next);
        resolved = __pui_ResolveProps(specs, defaults, previousValid, raw, false);
        __pui_Interaction.refresh();
      },
      setDefaults(partial: Record<string, unknown>) {
        ensurePhase('setup');
        for (const key of Object.keys(partial)) if (!Object.hasOwn(specs, key)) throw new Error('[Props] undeclared default key: ' + key);
        defaults.unshift({ ...partial });
        resolved = __pui_ResolveProps(specs, defaults, previousValid, raw, false);
        __pui_Interaction.refresh();
      },
      watch(keys: readonly string[], callback: (run: __pui_Run, next: __pui_ResolvedProps, prev: __pui_ResolvedProps, info: Readonly<Record<string, unknown>>) => void) {
        ensurePhase('setup');
        if (!keys.length || keys.some((key) => !Object.hasOwn(specs, key))) throw new Error('[Props] watchers require declared keys.');
        const watcher = { keys: [...keys], callback, active: true };
        watchers.push(watcher);
        return () => { watcher.active = false; };
      },
      watchAll(callback: __pui_ResolvedWatcher['callback']) {
        ensurePhase('setup');
        const watcher: __pui_ResolvedWatcher = { keys: null, callback, active: true };
        watchers.push(watcher);
        return () => { watcher.active = false; };
      },
      watchRaw(keys: readonly string[], callback: __pui_RawWatcher['callback']) {
        ensurePhase('setup');
        if (!keys.length || keys.some(key => typeof key !== 'string' || !key.length)) throw new Error('[Props] raw watchers require nonempty keys.');
        const watcher: __pui_RawWatcher = { keys: [...keys], callback, active: true };
        rawWatchers.push(watcher);
        return () => { watcher.active = false; };
      },
      watchRawAll(callback: __pui_RawWatcher['callback']) {
        ensurePhase('setup');
        const watcher: __pui_RawWatcher = { keys: null, callback, active: true };
        rawAllWatchers.push(watcher);
        return () => { watcher.active = false; };
      },
    },
    state: {
      bool: (name: string, value: boolean) => __pui_CreateState(name, value, { kind: 'bool' }),
      string: (name: string, value: string, spec: Omit<__pui_StateSpec, 'kind'> = {}) => __pui_CreateState(name, value, { kind: 'string', ...spec }),
      enum: (name: string, value: string, spec: { options: readonly string[] }) => __pui_CreateState(name, value, { kind: 'enum', ...spec }),
      numberDiscrete: (name: string, value: number, spec: Omit<__pui_StateSpec, 'kind'> = {}) => __pui_CreateState(name, value, { kind: 'number.discrete', ...spec }),
      numberRange: (name: string, value: number, spec: Omit<__pui_StateSpec, 'kind'>) => __pui_CreateState(name, value, { kind: 'number.range', ...spec }),
    },
    expose: {
      value: registerExpose,
      state(key: string, state: object) {
        const external = externalStates.get(state);
        if (!external) throw new Error('[Expose] state must belong to this instance.');
        registerExpose(key, external);
        __pui_Authored.introduceObserved(state);
      },
      event(key: string, _spec: { payload?: 'void' | 'any' | 'json'; options?: Readonly<Record<string, unknown>> } = {}) {
        if (!Object.hasOwn(eventSchemas, key)) throw new Error('[Expose] missing checked event schema: ' + key);
        registerExpose(key, Object.freeze({ kind: 'event', payload: eventSchemas[key] }));
      },
      method<A extends unknown[], R>(key: string, callback: (...args: A) => R, project?: (value: R) => R) {

        registerExpose(key, (...args: A): R => {
          ensureExternal();
          return invoke(() => {
          const schema = methodSchemas[key];
          if (!schema || !schema.args(args))
            throw new TypeError('[Expose] invalid method arguments: ' + key);
          const result = callback(...args);
          if (!schema.result(result)) throw new TypeError('[Expose] invalid method result: ' + key);
          return project ? project(result) : result;
          });
        });
      },
    },
    lifecycle: {
      onCreated(callback: (run: __pui_Run) => void) { ensurePhase('setup'); callbacks.created.push(callback); },
      onMounted(callback: (run: __pui_Run) => void) { ensurePhase('setup'); callbacks.mounted.push(callback); },
      onUpdated(callback: (run: __pui_Run) => void) { ensurePhase('setup'); callbacks.updated.push(callback); },
      onUnmounted(callback: (run: __pui_Run) => void) { ensurePhase('setup'); callbacks.unmounted.push(callback); },
      onBeforeDispose(callback: (run: __pui_Run) => void) { ensurePhase('setup'); callbacks.beforeDispose.push(callback); },
    },
  };
  // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":26:1
  const __puiModule1 = (def: typeof __pui_Def, compatibilityStyle: "rhea", options: { "supportedStyles"?: ReadonlyArray<"vega" | "nova" | "maia" | "lyra" | "mira" | "luma" | "sera" | "rhea" | "new-york-v4"> | undefined } = {  }): __pui_State<string> => {
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":34:3
    __puiModule2(def);
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":35:9
    const selected = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "shadcnStyleSelection";
const __pui_CaptureArg1 = compatibilityStyle;
const __pui_CaptureArg2 = { ["options"]: __puiModule0 };
const __pui_CaptureResult = __pui_CaptureReceiver.state.enum(__pui_CaptureArg0, __pui_CaptureArg1, __pui_CaptureArg2); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":38:9
    const sync = (run: __pui_Run): void => {
      // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":39:11
      const explicit = __puiModule3((run.props.getRaw())["styleProfile"]);
      // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":40:11
      const inherited = ((run.context.tryRead<{ "style": "vega" | "nova" | "maia" | "lyra" | "mira" | "luma" | "sera" | "rhea" | "new-york-v4" | null } | null>(__pui_ContextKey0))?.["style"] ?? null);
      // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":41:11
      const next = ((explicit ?? inherited) ?? compatibilityStyle);
      // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":42:5
      if (((options)["supportedStyles"] && (!(((options as { "supportedStyles": ReadonlyArray<"vega" | "nova" | "maia" | "lyra" | "mira" | "luma" | "sera" | "rhea" | "new-york-v4"> }))["supportedStyles"] as readonly unknown[]).includes(next)))) {
        // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":43:7
        throw new Error(("[shadcn-style-scope] Unsupported style for this consumer: " + next));
      }
      // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":45:5
      selected.set(next, "reason: shadcn style selection");
    };
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":47:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = __pui_ContextKey0;
const __pui_CaptureArg1 = sync;
const __pui_CaptureResult = __pui_CaptureReceiver.context.trySubscribe(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "trySubscribe", "key": __pui_CaptureArg0, "off": __pui_CaptureResult}); __pui_Authored.disposer("context", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":48:3
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = ["styleProfile"];
const __pui_CaptureArg1 = sync;
const __pui_CaptureResult = __pui_CaptureReceiver.props.watchRaw(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("props", {"op": "watchRaw", "keys": __pui_CaptureArg0, "off": __pui_CaptureResult}); __pui_Authored.disposer("props", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":49:3
    def.lifecycle.onCreated(sync);
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":50:3
    def.lifecycle.onMounted(sync);
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":53:3
    def.lifecycle.onUpdated(sync);
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":54:3
    return selected;
  };
  // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":10:1
  const __puiModule2 = (def: typeof __pui_Def): void => {
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":13:9
    const cdef = def;
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":14:3
    (() => {
const __pui_CaptureReceiver = cdef;
const __pui_CaptureArg0: Parameters<typeof __pui_CaptureReceiver.props.define>[0] = { ["styleProfile"]: { ["type"]: "enum", ["options"]: ["vega", "nova", "maia", "lyra", "mira", "luma", "sera", "rhea", "new-york-v4", "new-york", "inherit"], ["empty"]: "fallback" } };
const __pui_CaptureResult = __pui_CaptureReceiver.props.define(__pui_CaptureArg0); __pui_Authored.effect("props", {"op": "define", "specMap": __pui_CaptureArg0}); return __pui_CaptureResult; })();
    // Source "packages/prototypes/shadcn/src/style-scope/selection.ts":22:3
    (() => {
const __pui_CaptureReceiver = cdef;
const __pui_CaptureArg0 = { ["styleProfile"]: "inherit" };
const __pui_CaptureResult = __pui_CaptureReceiver.props.setDefaults(__pui_CaptureArg0); __pui_Authored.effect("props", {"op": "setDefaults", "partial": __pui_CaptureArg0}); return __pui_CaptureResult; })();
  };
  const __pui_Hook0 = (options?: unknown) => (__pui_Authored.install({name: "as-button", mode: "once", setup: (options, api) => ((def: typeof __pui_Def) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":12:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = ({"kind":"tw","tokens":["select-none"],"groups":["content-selection affordance"]} as const);
const __pui_CaptureResult = __pui_CaptureReceiver.feedback.style.use(__pui_CaptureArg0); __pui_Authored.effect("feedback", __pui_CaptureResult); __pui_Authored.disposer("feedback", __pui_CaptureResult); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":13:9
      const accessible = __pui_Authored.privileged("asAccessible", () => __pui_Interaction.asAccessible());
      // Source "packages/prototypes/base/src/button/button.proto.ts":15:3
      __pui_Authored.privileged("asTrigger", () => __pui_Interaction.asTrigger());
      // Source "packages/prototypes/base/src/button/button.proto.ts":18:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0: Parameters<typeof __pui_CaptureReceiver.props.define>[0] = { ["disabled"]: { ["type"]: "boolean", ["empty"]: "fallback" } };
const __pui_CaptureResult = __pui_CaptureReceiver.props.define(__pui_CaptureArg0); __pui_Authored.effect("props", {"op": "define", "specMap": __pui_CaptureArg0}); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":21:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = { ["disabled"]: false };
const __pui_CaptureResult = __pui_CaptureReceiver.props.setDefaults(__pui_CaptureArg0); __pui_Authored.effect("props", {"op": "setDefaults", "partial": __pui_CaptureArg0}); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":26:9
      const disabled = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "disabled";
const __pui_CaptureArg1 = false;
const __pui_CaptureResult = __pui_CaptureReceiver.state.bool(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":27:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "disabled";
const __pui_CaptureArg1 = disabled;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.state(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", {"op": "expose.state", "key": __pui_CaptureArg0, "handle": __pui_CaptureArg1}); __pui_Authored.introduceObserved(__pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":28:3
      (() => {
const __pui_CaptureReceiver = accessible;
const __pui_CaptureArg0 = "disabled";
const __pui_CaptureArg1 = disabled;
const __pui_CaptureResult = __pui_CaptureReceiver.state(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", {"op": "a11y.state", "key": __pui_CaptureArg0, "handle": __pui_CaptureArg1, "options": undefined}); __pui_Authored.introduceObserved(__pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":31:9
      const hovered = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "hovered";
const __pui_CaptureArg1 = false;
const __pui_CaptureResult = __pui_CaptureReceiver.state.bool(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":32:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "hovered";
const __pui_CaptureArg1 = hovered;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.state(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", {"op": "expose.state", "key": __pui_CaptureArg0, "handle": __pui_CaptureArg1}); __pui_Authored.introduceObserved(__pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":35:9
      const focusable = __pui_Authored.privileged("asFocusable", () => __pui_Interaction.asFocusable(), ["focused","focusVisible","focusable"]);
      // Source "packages/prototypes/base/src/button/button.proto.ts":36:3
      focusable.configure({ ["disabled"]: false });
      // Source "packages/prototypes/base/src/button/button.proto.ts":38:9
      const focused = (focusable)["focused"];
      // Source "packages/prototypes/base/src/button/button.proto.ts":39:9
      const focusVisible = (focusable)["focusVisible"];
      // Source "packages/prototypes/base/src/button/button.proto.ts":42:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "focused";
const __pui_CaptureArg1 = focused;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.state(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", {"op": "expose.state", "key": __pui_CaptureArg0, "handle": __pui_CaptureArg1}); __pui_Authored.introduceObserved(__pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":43:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "focusVisible";
const __pui_CaptureArg1 = focusVisible;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.state(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", {"op": "expose.state", "key": __pui_CaptureArg0, "handle": __pui_CaptureArg1}); __pui_Authored.introduceObserved(__pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":46:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "focusSelf";
const __pui_CaptureArg1 = (options?: { "reason"?: "programmatic" | "keyboard" | "pointer"; "preventScroll"?: boolean }): void => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":47:5
        if ((disabled.get() as boolean)) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":47:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":48:5
        focusable.focusSelf(options);
      };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":52:9
      const pressed = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "pressed";
const __pui_CaptureArg1 = false;
const __pui_CaptureResult = __pui_CaptureReceiver.state.bool(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":53:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "pressed";
const __pui_CaptureArg1 = pressed;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.state(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", {"op": "expose.state", "key": __pui_CaptureArg0, "handle": __pui_CaptureArg1}); __pui_Authored.introduceObserved(__pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":55:9
      const clearTransientInteraction = (reason: string): void => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":56:5
        hovered.set(false, reason);
        // Source "packages/prototypes/base/src/button/button.proto.ts":57:5
        pressed.set(false, reason);
      };
      // Source "packages/prototypes/base/src/button/button.proto.ts":61:3
      def.lifecycle.onUnmounted(() => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":62:5
        (clearTransientInteraction)("reason: button view unmounted => reset transient interaction");
      });
      // Source "packages/prototypes/base/src/button/button.proto.ts":66:9
      const syncDisabled = (nextDisabled: boolean): void => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":67:5
        disabled.set(nextDisabled, "reason: sync disabled");
        // Source "packages/prototypes/base/src/button/button.proto.ts":68:5
        focusable.setDisabled(nextDisabled);
        // Source "packages/prototypes/base/src/button/button.proto.ts":69:5
        if (nextDisabled) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":70:7
          (clearTransientInteraction)("reason: button disabled => reset transient interaction");
        }
      };
      // Source "packages/prototypes/base/src/button/button.proto.ts":73:3
      def.lifecycle.onCreated((run: __pui_Run) => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":74:5
        (syncDisabled)((run.props.get())["disabled"]);
      });
      // Source "packages/prototypes/base/src/button/button.proto.ts":76:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = ["disabled"];
const __pui_CaptureArg1 = (_run: __pui_Run, next: __pui_ResolvedProps) => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":77:5
        (syncDisabled)((next)["disabled"]);
      };
const __pui_CaptureResult = __pui_CaptureReceiver.props.watch(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("props", {"op": "watch", "keys": __pui_CaptureArg0, "off": __pui_CaptureResult}); __pui_Authored.disposer("props", __pui_CaptureResult); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":81:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "click";
const __pui_CaptureArg1: Parameters<typeof __pui_CaptureReceiver.expose.event>[1] = { ["payload"]: "void" };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.event(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("event", {"op": "expose.event", "key": __pui_CaptureArg0, "spec": __pui_CaptureArg1}); __pui_Authored.eventKey(__pui_CaptureArg0); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":83:3
      accessible.action("activate", { ["event"]: "click" });
      // Source "packages/prototypes/base/src/button/button.proto.ts":86:3
      accessible.role("button");
      // Source "packages/prototypes/base/src/button/button.proto.ts":89:3
      accessible.nameFromContent();
      // Source "packages/prototypes/base/src/button/button.proto.ts":91:9
      const activate = (run: __pui_Run, isCurrent: () => boolean = (): boolean => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":91:83
        return true;
      }): void => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":92:5
        if (((disabled.get() as boolean) || (!(isCurrent)()))) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":92:41
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":93:5
        pressed.set(false, "reason: button activation => pressed");
        // Source "packages/prototypes/base/src/button/button.proto.ts":94:5
        if (((disabled.get() as boolean) || (!(isCurrent)()))) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":94:41
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":95:5
        run.expose.emit("click");
      };
      // Source "packages/prototypes/base/src/button/button.proto.ts":97:3
      __pui_Authored.privileged("asControlLabel", () => __pui_Interaction.asControlLabel()).target((run: __pui_Run, request: __pui_NativeModuleCapability<"control-label-request", __pui_Run>) => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":98:11
        const isCurrent = (): boolean => {
          // Source "packages/prototypes/base/src/button/button.proto.ts":98:29
          return ((!(disabled.get() as boolean)) && request.isCurrent());
        };
        // Source "packages/prototypes/base/src/button/button.proto.ts":99:5
        if ((!(isCurrent)())) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":99:23
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":100:5
        focusable.focusSelf({ ["reason"]: (((request)["source"] === "pointer") ? "pointer" : "programmatic") });
        // Source "packages/prototypes/base/src/button/button.proto.ts":101:5
        if ((isCurrent)()) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":101:22
          (activate)(run, isCurrent);
        }
      });
      // Source "packages/prototypes/base/src/button/button.proto.ts":107:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "key.down";
const __pui_CaptureArg1 = (_run: __pui_Run, ev: __pui_NativeInput) => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":108:11
        const detail = ev;
        // Source "packages/prototypes/base/src/button/button.proto.ts":109:5
        if ((disabled.get() as boolean)) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":109:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":110:5
        if ((!(focused.get() as boolean))) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":110:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":111:5
        if (((detail)?.["key"] !== " ")) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":111:30
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":112:5
        ev.control.requestDefaultActionPrevention({ ["reason"]: "button.space-activation", ["source"]: "base-button" });
      };
const __pui_CaptureResult = __pui_CaptureReceiver.event.onGlobal(__pui_CaptureArg0, __pui_CaptureArg1); const __pui_CaptureOff = () => __pui_Interaction.releaseListener(__pui_CaptureResult); __pui_Authored.effect("event", {token: __pui_CaptureResult, off: __pui_CaptureOff}); __pui_Authored.disposer("event", __pui_CaptureOff); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":119:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "pointer.enter";
const __pui_CaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":120:5
        if ((disabled.get() as boolean)) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":120:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":121:5
        hovered.set(true, "reason: button pointer.enter => hovered");
      };
const __pui_CaptureResult = __pui_CaptureReceiver.event.on(__pui_CaptureArg0, __pui_CaptureArg1); const __pui_CaptureOff = () => __pui_Interaction.releaseListener(__pui_CaptureResult); __pui_Authored.effect("event", {token: __pui_CaptureResult, off: __pui_CaptureOff}); __pui_Authored.disposer("event", __pui_CaptureOff); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":123:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "pointer.leave";
const __pui_CaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":124:5
        hovered.set(false, "reason: button pointer.leave => hovered");
        // Source "packages/prototypes/base/src/button/button.proto.ts":125:5
        pressed.set(false, "reason: button pointer.leave => pressed");
      };
const __pui_CaptureResult = __pui_CaptureReceiver.event.on(__pui_CaptureArg0, __pui_CaptureArg1); const __pui_CaptureOff = () => __pui_Interaction.releaseListener(__pui_CaptureResult); __pui_Authored.effect("event", {token: __pui_CaptureResult, off: __pui_CaptureOff}); __pui_Authored.disposer("event", __pui_CaptureOff); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":127:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "pointer.cancel";
const __pui_CaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":128:5
        hovered.set(false, "reason: button pointer.cancel => hovered");
        // Source "packages/prototypes/base/src/button/button.proto.ts":129:5
        pressed.set(false, "reason: button pointer.cancel => pressed");
      };
const __pui_CaptureResult = __pui_CaptureReceiver.event.on(__pui_CaptureArg0, __pui_CaptureArg1); const __pui_CaptureOff = () => __pui_Interaction.releaseListener(__pui_CaptureResult); __pui_Authored.effect("event", {token: __pui_CaptureResult, off: __pui_CaptureOff}); __pui_Authored.disposer("event", __pui_CaptureOff); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":132:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "press.cancel";
const __pui_CaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":133:5
        (clearTransientInteraction)("reason: button press.cancel => reset transient interaction");
      };
const __pui_CaptureResult = __pui_CaptureReceiver.event.on(__pui_CaptureArg0, __pui_CaptureArg1); const __pui_CaptureOff = () => __pui_Interaction.releaseListener(__pui_CaptureResult); __pui_Authored.effect("event", {token: __pui_CaptureResult, off: __pui_CaptureOff}); __pui_Authored.disposer("event", __pui_CaptureOff); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":137:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "pointer.down";
const __pui_CaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":138:5
        if ((disabled.get() as boolean)) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":138:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":139:5
        pressed.set(true, "reason: button pointer.down => pressed");
      };
const __pui_CaptureResult = __pui_CaptureReceiver.event.on(__pui_CaptureArg0, __pui_CaptureArg1); const __pui_CaptureOff = () => __pui_Interaction.releaseListener(__pui_CaptureResult); __pui_Authored.effect("event", {token: __pui_CaptureResult, off: __pui_CaptureOff}); __pui_Authored.disposer("event", __pui_CaptureOff); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":141:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "pointer.up";
const __pui_CaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":142:5
        pressed.set(false, "reason: button pointer.up => pressed");
      };
const __pui_CaptureResult = __pui_CaptureReceiver.event.on(__pui_CaptureArg0, __pui_CaptureArg1); const __pui_CaptureOff = () => __pui_Interaction.releaseListener(__pui_CaptureResult); __pui_Authored.effect("event", {token: __pui_CaptureResult, off: __pui_CaptureOff}); __pui_Authored.disposer("event", __pui_CaptureOff); return __pui_CaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":146:3
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "press.commit";
const __pui_CaptureArg1 = (run: __pui_Run) => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":147:5
        pressed.set(false, "reason: button press.commit => pressed");
        // Source "packages/prototypes/base/src/button/button.proto.ts":148:5
        (activate)(run);
      };
const __pui_CaptureResult = __pui_CaptureReceiver.event.on(__pui_CaptureArg0, __pui_CaptureArg1); const __pui_CaptureOff = () => __pui_Interaction.releaseListener(__pui_CaptureResult); __pui_Authored.effect("event", {token: __pui_CaptureResult, off: __pui_CaptureOff}); __pui_Authored.disposer("event", __pui_CaptureOff); return __pui_CaptureResult; })();
    })(__pui_Def)}, options) as { readonly stateHandles?: Readonly<Record<string, unknown>>; readonly getState?: (name: string) => unknown; readonly getMethod?: (name: string) => unknown; readonly getAsHook?: (name: string) => unknown; readonly getAsHookHandle?: (name: string) => unknown; readonly render?: unknown });
  let render: (renderer: typeof __pui_Renderer) => unknown;
  try {
    render = ((def: typeof __pui_Def) => {
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":38:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0: Parameters<typeof __pui_CaptureReceiver.props.define>[0] = { ["variant"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["default", "destructive", "outline", "secondary", "ghost", "link"] }, ["size"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["default", "sm", "lg", "icon", "icon-compact"] }, ["disabled"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["wrap"]: { ["type"]: "boolean", ["empty"]: "fallback" } };
const __pui_CaptureResult = __pui_CaptureReceiver.props.define(__pui_CaptureArg0); __pui_Authored.effect("props", {"op": "define", "specMap": __pui_CaptureArg0}); return __pui_CaptureResult; })();
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":52:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = { ["variant"]: "default", ["size"]: "default", ["disabled"]: false, ["wrap"]: false };
const __pui_CaptureResult = __pui_CaptureReceiver.props.setDefaults(__pui_CaptureArg0); __pui_Authored.effect("props", {"op": "setDefaults", "partial": __pui_CaptureArg0}); return __pui_CaptureResult; })();
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":55:11
    const buttonState = ((__pui_Hook0())["stateHandles"] as { readonly "disabled": __pui_State<boolean> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void }; readonly "hovered": __pui_State<boolean> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void }; readonly "focused": __pui_NativeObservedState<boolean>; readonly "focusVisible": __pui_NativeObservedState<boolean>; readonly "pressed": __pui_State<boolean> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void } });
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":56:5
    if ((!buttonState)) {
      // Source "packages/prototypes/shadcn/src/button/button.proto.ts":57:7
      throw new Error("[shadcn-button] asButton must project Button state handles.");
    }
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":59:13
    const disabled = (buttonState)["disabled"];
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":59:23
    const hovered = (buttonState)["hovered"];
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":59:32
    const focusVisible = (buttonState)["focusVisible"];
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":59:46
    const pressed = (buttonState)["pressed"];
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":61:11
    const style = __puiModule1(def, "rhea", { ["supportedStyles"]: __puiModule0 });
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":63:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => !((__puiRuleState0.get() === "new-york-v4")), [({"kind":"tw","tokens":["inline-flex","box-border","shrink-0","items-center","justify-center","border","border-transparent","bg-clip-padding","py-0","transition-all","outline-none"],"groups":["display","box sizing","shrink-0","items-","justify-","border-width","border-color","bg-clip-","py-","transition-","outline-none"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":70:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => (!((__puiRuleState0.get() === "new-york-v4")) && (resolved["variant"] === "default")), [({"kind":"tw","tokens":["bg-primary","text-primary-foreground"],"groups":["bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":70:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => (!((__puiRuleState0.get() === "new-york-v4")) && (resolved["variant"] === "destructive")), [({"kind":"tw","tokens":["border-transparent","bg-destructive/10","text-destructive"],"groups":["border-color","bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":70:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => (!((__puiRuleState0.get() === "new-york-v4")) && (resolved["variant"] === "secondary")), [({"kind":"tw","tokens":["border-transparent","bg-secondary","text-secondary-foreground"],"groups":["border-color","bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":70:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => (!((__puiRuleState0.get() === "new-york-v4")) && (resolved["variant"] === "ghost")), [({"kind":"tw","tokens":["border-transparent","bg-transparent","text-foreground"],"groups":["border-color","bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":70:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => (!((__puiRuleState0.get() === "new-york-v4")) && (resolved["variant"] === "link")), [({"kind":"tw","tokens":["border-transparent","bg-transparent","text-primary","underline-offset-4"],"groups":["border-color","bg-","text-color","underline-offset-4"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":76:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => (__puiRuleState0.get() === "vega"), [({"kind":"tw","tokens":["text-sm","leading-5","font-medium"],"groups":["text-size","leading-5","font weight"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":80:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "vega") && !((resolved["size"] === "icon-compact"))), [({"kind":"tw","tokens":["rounded-md"],"groups":["rounded"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":84:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "vega") && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["border-border","bg-background","text-foreground","shadow-xs"],"groups":["border-color","bg-","text-color","shadow-"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "vega") && (resolved["size"] === "default") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-9","gap-1.5","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "vega") && (resolved["size"] === "default") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-9","h-auto","gap-1.5","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "vega") && (resolved["size"] === "sm") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-8","gap-1","rounded-[min(var(--radius-md),10px)]","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1","rounded","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "vega") && (resolved["size"] === "sm") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-8","h-auto","gap-1","rounded-[min(var(--radius-md),10px)]","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","rounded","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "vega") && (resolved["size"] === "lg") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-10","gap-1.5","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "vega") && (resolved["size"] === "lg") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-10","h-auto","gap-1.5","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "vega") && (resolved["size"] === "icon")), [({"kind":"tw","tokens":["size-9","whitespace-nowrap"],"groups":["size-9","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "vega") && (resolved["size"] === "icon-compact")), [({"kind":"tw","tokens":["size-7","gap-2","rounded-md","whitespace-nowrap"],"groups":["size-7","gap-2","rounded","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":107:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = focusVisible; return __pui_Style.rule(() => ((__puiRuleState0.get() === "vega") && (__puiRuleState1.get() === true)), [({"kind":"tw","tokens":["border-ring","ring-3","ring-ring/50"],"groups":["border-color","ring-3","ring-ring/50"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":111:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "vega") && (__puiRuleState1.get() === true) && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-muted","text-foreground"],"groups":["bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":76:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => (__puiRuleState0.get() === "nova"), [({"kind":"tw","tokens":["text-sm","leading-5","font-medium"],"groups":["text-size","leading-5","font weight"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":80:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "nova") && !((resolved["size"] === "icon-compact"))), [({"kind":"tw","tokens":["rounded-lg"],"groups":["rounded"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":84:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "nova") && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["border-border","bg-background","text-foreground"],"groups":["border-color","bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "nova") && (resolved["size"] === "default") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-8","gap-1.5","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "nova") && (resolved["size"] === "default") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-8","h-auto","gap-1.5","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "nova") && (resolved["size"] === "sm") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-7","gap-1","rounded-[min(var(--radius-md),12px)]","px-2.5","text-[0.8rem]","whitespace-nowrap"],"groups":["h-","gap-1","rounded","px-","text-size","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "nova") && (resolved["size"] === "sm") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-7","h-auto","gap-1","rounded-[min(var(--radius-md),12px)]","px-2.5","py-1","text-[0.8rem]","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","rounded","px-","py-","text-size","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "nova") && (resolved["size"] === "lg") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-9","gap-1.5","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "nova") && (resolved["size"] === "lg") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-9","h-auto","gap-1.5","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "nova") && (resolved["size"] === "icon")), [({"kind":"tw","tokens":["size-8","whitespace-nowrap"],"groups":["size-8","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "nova") && (resolved["size"] === "icon-compact")), [({"kind":"tw","tokens":["size-7","gap-2","rounded-md","whitespace-nowrap"],"groups":["size-7","gap-2","rounded","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":107:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = focusVisible; return __pui_Style.rule(() => ((__puiRuleState0.get() === "nova") && (__puiRuleState1.get() === true)), [({"kind":"tw","tokens":["border-ring","ring-3","ring-ring/50"],"groups":["border-color","ring-3","ring-ring/50"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":111:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "nova") && (__puiRuleState1.get() === true) && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-muted","text-foreground"],"groups":["bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":76:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => (__puiRuleState0.get() === "maia"), [({"kind":"tw","tokens":["text-sm","leading-5","font-medium"],"groups":["text-size","leading-5","font weight"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":80:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "maia") && !((resolved["size"] === "icon-compact"))), [({"kind":"tw","tokens":["rounded-[var(--pui-radius-4xl)]"],"groups":["rounded"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":84:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "maia") && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["border-border","bg-input/30","text-foreground"],"groups":["border-color","bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "maia") && (resolved["size"] === "default") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-9","gap-1.5","px-3","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "maia") && (resolved["size"] === "default") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-9","h-auto","gap-1.5","px-3","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "maia") && (resolved["size"] === "sm") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-8","gap-1","px-3","whitespace-nowrap"],"groups":["h-","gap-1","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "maia") && (resolved["size"] === "sm") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-8","h-auto","gap-1","px-3","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "maia") && (resolved["size"] === "lg") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-10","gap-1.5","px-4","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "maia") && (resolved["size"] === "lg") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-10","h-auto","gap-1.5","px-4","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "maia") && (resolved["size"] === "icon")), [({"kind":"tw","tokens":["size-9","whitespace-nowrap"],"groups":["size-9","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "maia") && (resolved["size"] === "icon-compact")), [({"kind":"tw","tokens":["size-7","gap-2","rounded-md","whitespace-nowrap"],"groups":["size-7","gap-2","rounded","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":107:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = focusVisible; return __pui_Style.rule(() => ((__puiRuleState0.get() === "maia") && (__puiRuleState1.get() === true)), [({"kind":"tw","tokens":["border-ring","ring-3","ring-ring/50"],"groups":["border-color","ring-3","ring-ring/50"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":111:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "maia") && (__puiRuleState1.get() === true) && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-input/50","text-foreground"],"groups":["bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":76:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => (__puiRuleState0.get() === "lyra"), [({"kind":"tw","tokens":["text-xs","font-medium"],"groups":["text-size","font weight"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":80:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "lyra") && !((resolved["size"] === "icon-compact"))), [({"kind":"tw","tokens":["rounded-none"],"groups":["rounded"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":84:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "lyra") && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["border-border","bg-background","text-foreground"],"groups":["border-color","bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "lyra") && (resolved["size"] === "default") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-8","gap-1.5","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "lyra") && (resolved["size"] === "default") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-8","h-auto","gap-1.5","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "lyra") && (resolved["size"] === "sm") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-7","gap-1","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "lyra") && (resolved["size"] === "sm") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-7","h-auto","gap-1","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "lyra") && (resolved["size"] === "lg") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-9","gap-1.5","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "lyra") && (resolved["size"] === "lg") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-9","h-auto","gap-1.5","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "lyra") && (resolved["size"] === "icon")), [({"kind":"tw","tokens":["size-8","whitespace-nowrap"],"groups":["size-8","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "lyra") && (resolved["size"] === "icon-compact")), [({"kind":"tw","tokens":["size-7","gap-2","rounded-md","whitespace-nowrap"],"groups":["size-7","gap-2","rounded","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":107:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = focusVisible; return __pui_Style.rule(() => ((__puiRuleState0.get() === "lyra") && (__puiRuleState1.get() === true)), [({"kind":"tw","tokens":["border-ring","ring-1","ring-ring/50"],"groups":["border-color","ring-1","ring-ring/50"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":111:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "lyra") && (__puiRuleState1.get() === true) && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-muted","text-foreground"],"groups":["bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":76:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => (__puiRuleState0.get() === "mira"), [({"kind":"tw","tokens":["text-xs","leading-relaxed","font-medium"],"groups":["text-size","leading-relaxed","font weight"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":80:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "mira") && !((resolved["size"] === "icon-compact"))), [({"kind":"tw","tokens":["rounded-md"],"groups":["rounded"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":84:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "mira") && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["border-border","bg-transparent","text-foreground"],"groups":["border-color","bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "mira") && (resolved["size"] === "default") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-7","gap-1","px-2","whitespace-nowrap"],"groups":["h-","gap-1","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "mira") && (resolved["size"] === "default") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-7","h-auto","gap-1","px-2","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "mira") && (resolved["size"] === "sm") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-6","gap-1","px-2","whitespace-nowrap"],"groups":["h-","gap-1","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "mira") && (resolved["size"] === "sm") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-6","h-auto","gap-1","px-2","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "mira") && (resolved["size"] === "lg") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-8","gap-1","px-2.5","whitespace-nowrap"],"groups":["h-","gap-1","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "mira") && (resolved["size"] === "lg") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-8","h-auto","gap-1","px-2.5","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "mira") && (resolved["size"] === "icon")), [({"kind":"tw","tokens":["size-7","whitespace-nowrap"],"groups":["size-7","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "mira") && (resolved["size"] === "icon-compact")), [({"kind":"tw","tokens":["size-7","gap-2","rounded-md","whitespace-nowrap"],"groups":["size-7","gap-2","rounded","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":107:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = focusVisible; return __pui_Style.rule(() => ((__puiRuleState0.get() === "mira") && (__puiRuleState1.get() === true)), [({"kind":"tw","tokens":["border-ring","ring-2","ring-ring/30"],"groups":["border-color","ring-2","ring-ring/30"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":111:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "mira") && (__puiRuleState1.get() === true) && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-input/50","text-foreground"],"groups":["bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":76:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => (__puiRuleState0.get() === "luma"), [({"kind":"tw","tokens":["text-sm","leading-5","font-medium"],"groups":["text-size","leading-5","font weight"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":80:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "luma") && !((resolved["size"] === "icon-compact"))), [({"kind":"tw","tokens":["rounded-[var(--pui-radius-4xl)]"],"groups":["rounded"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":84:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "luma") && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["border-border","bg-background","text-foreground"],"groups":["border-color","bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "luma") && (resolved["size"] === "default") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-9","gap-1.5","px-3","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "luma") && (resolved["size"] === "default") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-9","h-auto","gap-1.5","px-3","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "luma") && (resolved["size"] === "sm") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-8","gap-1","px-3","whitespace-nowrap"],"groups":["h-","gap-1","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "luma") && (resolved["size"] === "sm") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-8","h-auto","gap-1","px-3","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "luma") && (resolved["size"] === "lg") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-10","gap-1.5","px-4","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "luma") && (resolved["size"] === "lg") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-10","h-auto","gap-1.5","px-4","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "luma") && (resolved["size"] === "icon")), [({"kind":"tw","tokens":["size-9","whitespace-nowrap"],"groups":["size-9","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "luma") && (resolved["size"] === "icon-compact")), [({"kind":"tw","tokens":["size-7","gap-2","rounded-md","whitespace-nowrap"],"groups":["size-7","gap-2","rounded","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":107:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = focusVisible; return __pui_Style.rule(() => ((__puiRuleState0.get() === "luma") && (__puiRuleState1.get() === true)), [({"kind":"tw","tokens":["border-ring","ring-3","ring-ring/30"],"groups":["border-color","ring-3","ring-ring/30"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":111:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "luma") && (__puiRuleState1.get() === true) && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-muted","text-foreground"],"groups":["bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":76:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => (__puiRuleState0.get() === "sera"), [({"kind":"tw","tokens":["text-xs","font-semibold","uppercase","tracking-widest"],"groups":["text-size","font weight","uppercase","tracking-"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":80:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "sera") && !((resolved["size"] === "icon-compact"))), [({"kind":"tw","tokens":["rounded-none"],"groups":["rounded"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":84:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "sera") && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["border-border","bg-transparent","text-foreground"],"groups":["border-color","bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "sera") && (resolved["size"] === "default") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-10","gap-1.5","px-6","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "sera") && (resolved["size"] === "default") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-10","h-auto","gap-1.5","px-6","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "sera") && (resolved["size"] === "sm") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-9","gap-1","px-4","whitespace-nowrap"],"groups":["h-","gap-1","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "sera") && (resolved["size"] === "sm") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-9","h-auto","gap-1","px-4","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "sera") && (resolved["size"] === "lg") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-11","gap-1.5","px-8","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "sera") && (resolved["size"] === "lg") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-11","h-auto","gap-1.5","px-8","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "sera") && (resolved["size"] === "icon")), [({"kind":"tw","tokens":["size-10","whitespace-nowrap"],"groups":["size-10","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "sera") && (resolved["size"] === "icon-compact")), [({"kind":"tw","tokens":["size-7","gap-2","rounded-md","whitespace-nowrap"],"groups":["size-7","gap-2","rounded","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":107:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = focusVisible; return __pui_Style.rule(() => ((__puiRuleState0.get() === "sera") && (__puiRuleState1.get() === true)), [({"kind":"tw","tokens":["border-ring","ring-2","ring-ring/30"],"groups":["border-color","ring-2","ring-ring/30"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":111:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "sera") && (__puiRuleState1.get() === true) && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-muted","text-foreground"],"groups":["bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":76:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => (__puiRuleState0.get() === "rhea"), [({"kind":"tw","tokens":["text-sm","leading-5","font-medium"],"groups":["text-size","leading-5","font weight"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":80:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "rhea") && !((resolved["size"] === "icon-compact"))), [({"kind":"tw","tokens":["rounded-[var(--pui-radius-2xl)]"],"groups":["rounded"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":84:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "rhea") && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["border-border","bg-background","text-foreground"],"groups":["border-color","bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "rhea") && (resolved["size"] === "default") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-8","gap-1.5","px-3","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "rhea") && (resolved["size"] === "default") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-8","h-auto","gap-1.5","px-3","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "rhea") && (resolved["size"] === "sm") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-7","gap-1","px-3","whitespace-nowrap"],"groups":["h-","gap-1","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "rhea") && (resolved["size"] === "sm") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-7","h-auto","gap-1","px-3","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":95:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "rhea") && (resolved["size"] === "lg") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-9","gap-1.5","px-4","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":100:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "rhea") && (resolved["size"] === "lg") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-9","h-auto","gap-1.5","px-4","py-1","min-w-0","max-w-full","whitespace-normal","wrap-anywhere"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","wrap-anywhere"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "rhea") && (resolved["size"] === "icon")), [({"kind":"tw","tokens":["size-8","whitespace-nowrap"],"groups":["size-8","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":90:11
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "rhea") && (resolved["size"] === "icon-compact")), [({"kind":"tw","tokens":["size-7","gap-2","rounded-md","whitespace-nowrap"],"groups":["size-7","gap-2","rounded","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":107:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = focusVisible; return __pui_Style.rule(() => ((__puiRuleState0.get() === "rhea") && (__puiRuleState1.get() === true)), [({"kind":"tw","tokens":["border-ring","ring-3","ring-ring/30"],"groups":["border-color","ring-3","ring-ring/30"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":111:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "rhea") && (__puiRuleState1.get() === true) && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-muted","text-foreground"],"groups":["bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":121:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "sera") && (resolved["variant"] === "link")), [({"kind":"tw","tokens":["underline"],"groups":["underline"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":125:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = focusVisible; return __pui_Style.rule(() => (!((__puiRuleState0.get() === "new-york-v4")) && (__puiRuleState1.get() === true) && (resolved["variant"] === "destructive")), [({"kind":"tw","tokens":["border-destructive/40","ring-destructive/20"],"groups":["border-color","ring-destructive/20"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":134:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = pressed; return __pui_Style.rule(() => (!((__puiRuleState0.get() === "new-york-v4")) && (__puiRuleState1.get() === true)), [({"kind":"tw","tokens":["translate-y-px"],"groups":["translate-y-"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":138:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => (!((__puiRuleState0.get() === "new-york-v4")) && (__puiRuleState1.get() === true) && (resolved["variant"] === "default")), [({"kind":"tw","tokens":["bg-primary/80"],"groups":["bg-"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":147:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => (!((__puiRuleState0.get() === "new-york-v4")) && (__puiRuleState1.get() === true) && (resolved["variant"] === "secondary")), [({"kind":"tw","tokens":["bg-[color-mix(in_oklch,var(--secondary),var(--foreground)_5%)]"],"groups":["bg-"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":156:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => (!((__puiRuleState0.get() === "new-york-v4")) && (__puiRuleState1.get() === true) && (resolved["variant"] === "ghost")), [({"kind":"tw","tokens":["bg-muted","text-foreground"],"groups":["bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":165:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => (!((__puiRuleState0.get() === "new-york-v4")) && (__puiRuleState1.get() === true) && (resolved["variant"] === "link")), [({"kind":"tw","tokens":["underline"],"groups":["underline"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":174:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => (!((__puiRuleState0.get() === "new-york-v4")) && (__puiRuleState1.get() === true) && (resolved["variant"] === "destructive")), [({"kind":"tw","tokens":["bg-destructive/20"],"groups":["bg-"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":186:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "vega") && (__pui_Style.meta("colorScheme") === "dark") && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["border-input","bg-input/30"],"groups":["border-color","bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":195:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "vega") && (__pui_Style.meta("colorScheme") === "dark") && (__puiRuleState1.get() === true) && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-input/50"],"groups":["bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":186:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "nova") && (__pui_Style.meta("colorScheme") === "dark") && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["border-input","bg-input/30"],"groups":["border-color","bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":195:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "nova") && (__pui_Style.meta("colorScheme") === "dark") && (__puiRuleState1.get() === true) && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-input/50"],"groups":["bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":186:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "lyra") && (__pui_Style.meta("colorScheme") === "dark") && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["border-input","bg-input/30"],"groups":["border-color","bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":195:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "lyra") && (__pui_Style.meta("colorScheme") === "dark") && (__puiRuleState1.get() === true) && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-input/50"],"groups":["bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":207:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "luma") && (__pui_Style.meta("colorScheme") === "dark") && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-transparent"],"groups":["bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":216:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "luma") && (__pui_Style.meta("colorScheme") === "dark") && (__puiRuleState1.get() === true) && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-input/30"],"groups":["bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":207:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "rhea") && (__pui_Style.meta("colorScheme") === "dark") && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-transparent"],"groups":["bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":216:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "rhea") && (__pui_Style.meta("colorScheme") === "dark") && (__puiRuleState1.get() === true) && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-input/30"],"groups":["bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":227:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "mira") && (__pui_Style.meta("colorScheme") === "dark") && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-input/30"],"groups":["bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":236:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "mira") && (__pui_Style.meta("colorScheme") === "dark") && (__puiRuleState1.get() === true) && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-input/50"],"groups":["bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":246:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "sera") && (__pui_Style.meta("colorScheme") === "dark") && (__puiRuleState1.get() === true) && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-input/30"],"groups":["bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":256:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => (!((__puiRuleState0.get() === "new-york-v4")) && (__pui_Style.meta("colorScheme") === "dark") && (resolved["variant"] === "destructive")), [({"kind":"tw","tokens":["bg-destructive/20"],"groups":["bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":265:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => (!((__puiRuleState0.get() === "new-york-v4")) && (__pui_Style.meta("colorScheme") === "dark") && (__puiRuleState1.get() === true) && (resolved["variant"] === "destructive")), [({"kind":"tw","tokens":["bg-destructive/30"],"groups":["bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":275:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = focusVisible; return __pui_Style.rule(() => (!((__puiRuleState0.get() === "new-york-v4")) && (__pui_Style.meta("colorScheme") === "dark") && (__puiRuleState1.get() === true) && (resolved["variant"] === "destructive")), [({"kind":"tw","tokens":["ring-destructive/40"],"groups":["ring-destructive/40"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":285:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => (!((__puiRuleState0.get() === "new-york-v4")) && (__pui_Style.meta("colorScheme") === "dark") && (__puiRuleState1.get() === true) && (resolved["variant"] === "ghost")), [({"kind":"tw","tokens":["bg-muted/50"],"groups":["bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":297:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => (__puiRuleState0.get() === "new-york-v4"), [({"kind":"tw","tokens":["inline-flex","box-border","shrink-0","items-center","justify-center","rounded-md","text-sm","leading-5","font-medium","transition-all","outline-none"],"groups":["display","box sizing","shrink-0","items-","justify-","rounded","text-size","leading-5","font weight","transition-","outline-none"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":302:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (resolved["variant"] === "default")), [({"kind":"tw","tokens":["bg-primary","text-primary-foreground"],"groups":["bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":302:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (resolved["variant"] === "destructive")), [({"kind":"tw","tokens":["bg-destructive","text-white"],"groups":["bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":302:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["border","border-border","bg-background","text-foreground","shadow-xs"],"groups":["border-width","border-color","bg-","text-color","shadow-"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":302:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (resolved["variant"] === "secondary")), [({"kind":"tw","tokens":["bg-secondary","text-secondary-foreground"],"groups":["bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":302:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (resolved["variant"] === "ghost")), [({"kind":"tw","tokens":["bg-transparent","text-foreground"],"groups":["bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":302:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (resolved["variant"] === "link")), [({"kind":"tw","tokens":["bg-transparent","text-primary","underline-offset-4"],"groups":["bg-","text-color","underline-offset-4"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":314:9
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (resolved["size"] === "default") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-9","gap-2","px-4","py-2","whitespace-nowrap"],"groups":["h-","gap-2","px-","py-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":323:9
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (resolved["size"] === "default") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-9","h-auto","gap-2","px-4","py-1","min-w-0","max-w-full","whitespace-normal","break-words"],"groups":["min-h-","h-","gap-2","px-","py-","min-w-","max-w-","whitespace-normal","break-words"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":314:9
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (resolved["size"] === "sm") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-8","gap-1.5","px-3","whitespace-nowrap"],"groups":["h-","gap-1.5","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":323:9
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (resolved["size"] === "sm") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-8","h-auto","gap-1.5","px-3","py-1","min-w-0","max-w-full","whitespace-normal","break-words"],"groups":["min-h-","h-","gap-1.5","px-","py-","min-w-","max-w-","whitespace-normal","break-words"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":314:9
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (resolved["size"] === "lg") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-10","gap-2","px-6","whitespace-nowrap"],"groups":["h-","gap-2","px-","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":323:9
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (resolved["size"] === "lg") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-10","h-auto","gap-2","px-6","py-1","min-w-0","max-w-full","whitespace-normal","break-words"],"groups":["min-h-","h-","gap-2","px-","py-","min-w-","max-w-","whitespace-normal","break-words"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":309:9
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (resolved["size"] === "icon")), [({"kind":"tw","tokens":["size-9","gap-2","whitespace-nowrap"],"groups":["size-9","gap-2","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":309:9
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (resolved["size"] === "icon-compact")), [({"kind":"tw","tokens":["size-7","gap-2","whitespace-nowrap"],"groups":["size-7","gap-2","whitespace-nowrap"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":334:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = focusVisible; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (__puiRuleState1.get() === true)), [({"kind":"tw","tokens":["border-ring","ring-3","ring-ring/50"],"groups":["border-color","ring-3","ring-ring/50"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":338:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = focusVisible; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (__puiRuleState1.get() === true) && (resolved["variant"] === "destructive")), [({"kind":"tw","tokens":["ring-destructive/20"],"groups":["ring-destructive/20"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":356:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (__puiRuleState1.get() === true) && (resolved["variant"] === "default")), [({"kind":"tw","tokens":["bg-primary/90"],"groups":["bg-"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":356:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (__puiRuleState1.get() === true) && (resolved["variant"] === "destructive")), [({"kind":"tw","tokens":["bg-destructive/90"],"groups":["bg-"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":356:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (__puiRuleState1.get() === true) && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-accent","text-accent-foreground"],"groups":["bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":356:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (__puiRuleState1.get() === true) && (resolved["variant"] === "secondary")), [({"kind":"tw","tokens":["bg-secondary/80"],"groups":["bg-"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":356:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (__puiRuleState1.get() === true) && (resolved["variant"] === "ghost")), [({"kind":"tw","tokens":["bg-accent","text-accent-foreground"],"groups":["bg-","text-color"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":356:7
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (__puiRuleState1.get() === true) && (resolved["variant"] === "link")), [({"kind":"tw","tokens":["underline"],"groups":["underline"]} as const)]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":366:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (__pui_Style.meta("colorScheme") === "dark") && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["border-input","bg-input/30"],"groups":["border-color","bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":375:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (__pui_Style.meta("colorScheme") === "dark") && (__puiRuleState1.get() === true) && (resolved["variant"] === "outline")), [({"kind":"tw","tokens":["bg-input/50"],"groups":["bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":385:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (__pui_Style.meta("colorScheme") === "dark") && (resolved["variant"] === "destructive")), [({"kind":"tw","tokens":["bg-destructive/60"],"groups":["bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":394:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = focusVisible; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (__pui_Style.meta("colorScheme") === "dark") && (__puiRuleState1.get() === true) && (resolved["variant"] === "destructive")), [({"kind":"tw","tokens":["ring-destructive/40"],"groups":["ring-destructive/40"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":404:5
    __pui_Authored.rule((() => { const __puiRuleState0 = style; const __puiRuleState1 = hovered; return __pui_Style.rule(() => ((__puiRuleState0.get() === "new-york-v4") && (__pui_Style.meta("colorScheme") === "dark") && (__puiRuleState1.get() === true) && (resolved["variant"] === "ghost")), [({"kind":"tw","tokens":["bg-accent/50"],"groups":["bg-"]} as const)], ["colorScheme"]); })());
    // Source "packages/prototypes/shadcn/src/button/button.proto.ts":414:5
    __pui_Authored.rule((() => { const __puiRuleState0 = disabled; return __pui_Style.rule(() => (__puiRuleState0.get() === true), [({"kind":"tw","tokens":["pointer-events-none","opacity-50"],"groups":["pointer-events-none","opacity-"]} as const)]); })());
  })(__pui_Def) ?? (() => __pui_Renderer.slot());
    if (typeof render !== 'function') throw new Error('[Prototype] setup must return a render function or void.');
  } catch (error) { try { disposeNow(false, false); } catch {} throw error; }
  phase = 'idle';
  function applyProps(nextHost: GeneratedComponentProps) {
    ensureAlive();
    hostProps = nextHost;
    __pui_Interaction.refresh();
    const nextRaw: Record<string, unknown> = Object.create(null);
    for (const [key, value] of Object.entries(nextHost)) {
      if (key === 'children' || key === 'instanceAssociations' || key === 'hostRef' || key === 'hostProps' || !Object.hasOwn(specs, key) && (['class', 'className', 'hostClass', 'surfaceClass', 'style', 'hostStyle', 'surfaceStyle'].includes(key) || /^on[A-Z]/.test(key) && typeof value === 'function')) continue;
      nextRaw[key] = value;
    }
    if (hydrated && Object.keys(raw).length === Object.keys(nextRaw).length
      && Object.keys(nextRaw).every((key) => Object.hasOwn(raw, key) && Object.is(raw[key], nextRaw[key]))) return false;
    const previous = resolved;
    const previousRaw = raw;
    raw = Object.freeze(nextRaw);
    resolved = __pui_ResolveProps(specs, defaults, previousValid, raw, true);
    __pui_Style.refresh();
    __pui_Interaction.refresh();
    if (!hydrated) { hydrated = true; return false; }
    const nextResolved = resolved, nextRawSnapshot = raw;
    invoke(() => {
      const previousWindow = propsWindow;
      propsWindow = { raw: nextRawSnapshot, resolved: nextResolved };
      try {
      if (rawAllWatchers.length || rawWatchers.length) {
        const changedRaw = [...new Set([...Object.keys(previousRaw), ...Object.keys(nextRawSnapshot)])].filter(key => !Object.is(previousRaw[key], nextRawSnapshot[key]));
        if (changedRaw.length) for (let groupIndex = 0; groupIndex < 2; ++groupIndex) for (const watcher of groupIndex === 0 ? rawAllWatchers : rawWatchers) {
          if (!watcher.active) continue;
          const changedKeysMatched = watcher.keys ? watcher.keys.filter(key => changedRaw.includes(key)) : changedRaw;
          if (!changedKeysMatched.length) continue;
          console.warn('[Props] raw watchers are an adapter-snapshot escape hatch; avoid in official prototypes.');
          watcher.callback(__pui_RunHandle, nextRawSnapshot, previousRaw, { changedKeysAll: changedRaw, changedKeysMatched });
        }
      }
      const changedKeysAll = Object.keys(specs).filter((key) => !Object.is(previous[key as keyof GeneratedProps], nextResolved[key as keyof GeneratedProps]));
      for (const watcher of watchers) {
        if (!watcher.active) continue;
        const changedKeysMatched = watcher.keys ? watcher.keys.filter((key) => changedKeysAll.includes(key)) : changedKeysAll;
        if (changedKeysMatched.length) watcher.callback(__pui_RunHandle, nextResolved, previous, { changedKeysAll, changedKeysMatched });
      }
      } finally { propsWindow = previousWindow; }
    });
    return true;
  }
  const handle: GeneratedHandle = Object.freeze({
    update() { ensureExternal(); invoke(() => __pui_RunHandle.update()); },
    getElement() { return lifetime === 'alive' && connected ? root : null; },
    getExposes() { ensureExternal(); return { ...exposes } as GeneratedExposes; },
    invokeInCallbackScope<T>(callback: () => T): T { ensureExternal(); return invoke(callback); },
  });
  function disposeNow(exhaustive = false, authored = true) {
    if (lifetime !== 'alive') return;
    lifetime = 'disposing'; connected = false; ++cleanupVersion; ++rootGeneration; phase = 'callback';
    __pui_CompleteSteps([
      ...authorStateWatchCleanups.splice(0),
      () => detachView(),
      () => {
        if (!authored) return;
        if (exhaustive) __pui_CompleteSteps(callbacks.beforeDispose.map(callback => () => invoke(() => callback(__pui_RunHandle))));
        else dispatch(callbacks.beforeDispose);
      },
      () => disposeInteraction(),
      () => root?.removeAttribute('data-pui-style'),
      () => __pui_Style.dispose(),
      () => context.dispose(),
      () => __pui_Authored.dispose(),
      () => {
        root = null; lifetime = 'disposed'; phase = 'idle';
        for (const subscribers of stateSubscribers) subscribers.clear();
        pendingStateEvents.length = 0; watchers.length = 0; rawWatchers.length = 0; rawAllWatchers.length = 0;
        for (const list of Object.values(callbacks)) list.length = 0;
        for (const key of Object.keys(exposes)) delete exposes[key];
      },
    ]);
  }
  return {
    handle,
    scope: context,
    getHostProjection() { return { tag: __pui_Interaction.rootTag() ?? "div", properties: __pui_Interaction.rootProperties(), portalTarget: __pui_Interaction.portalTarget() }; },

    bindRoot(nextRoot) {
      if (lifetime !== 'alive') return;
      if (rootBinding) {
        if (rootBinding === 'binding' && root === nextRoot && !pendingRoot) return;
        pendingRoot = { value: nextRoot }; ++rootGeneration;
        return;
      }
      if (root === nextRoot) return;
      let next = nextRoot;
      let failure: { error: unknown } | undefined;
      try {
        for (;;) {
          // Cleanup owns the previous Root and all of its reached resources.
          // Reentrant requests coalesce until that complete transaction returns.
          rootBinding = 'retiring'; ++rootGeneration;
          const previousRoot = root;
          try { __pui_CompleteSteps([
            () => __pui_Interaction.unmount(),
            () => previousRoot?.removeAttribute('data-pui-style'),
          ]); } catch (error) { failure ??= { error }; }
          if (lifetime !== 'alive') break;
          const replacement = consumePendingRoot();
          if (replacement) next = replacement.value;
          root = next; rootBinding = 'binding';
          const generation = ++rootGeneration;
          const current = () => generation === rootGeneration && lifetime === 'alive';
          try { __pui_CompleteSteps([
            () => { if (current() && mounted) projectStyle(__pui_Style.tokens()); },
            () => { if (current() && mounted && desiredPresent && viewConnected) __pui_Interaction.mount(); },
          ]); } catch (error) { failure ??= { error }; }
          const queued = consumePendingRoot();
          if (lifetime !== 'alive' || !queued) break;
          next = queued.value;
        }
      } finally { rootBinding = null; pendingRoot = undefined; }
      if (failure) throw failure.error;
    },
    connect() { connected = true; ++cleanupVersion; },
    connectView() {
      viewConnected = true;
      if (mounted && desiredPresent) __pui_Interaction.mount();
    },
    disconnectView() { viewConnected = false; __pui_Interaction.unmount(); },
    commitHost() { if (connected && mounted && viewConnected && desiredPresent && lifetime === 'alive') __pui_Interaction.commitHost(); },
    start() {
      try {
        applyProps(initial); dispatch(callbacks.created);
        schedule();
      }
      catch (error) { try { disposeNow(true); } catch {} throw error; }
    },
    applyProps,
    accept(frame: __pui_Frame) {
      if (!connected || lifetime !== 'alive' || frame.revision <= acceptedRevision || frame !== latest) return false;
      acceptedRevision = frame.revision;
      if (frame.kind === 'detach') {
        try { detachView(); } finally { schedule(); }
      } else if (!desiredPresent) {
        // Physical materialization is not a published mount. Remove the obsolete
        // Root without manufacturing mounted/unmounted for a never-mounted epoch.
        schedule();
        return false;
      } else if (frame.kind === 'mount') {
        mounted = true;

        // The published mount may predate an explicit update intent. Only
        // after its acknowledgement may that dirty intent enter update flow.
        if (dirty) updateQueued = true;
        __pui_Style.mount();
        
        __pui_Interaction.mount();
        dispatch(callbacks.mounted);
      } else if (mounted && frame.epoch === epoch) {   dispatch(callbacks.updated); }
      schedule();
      return true;
    },
    disconnect() {
      connected = false;
      const version = ++cleanupVersion;
      queueMicrotask(() => {
        if (connected || cleanupVersion !== version || lifetime !== 'alive') return;
        disposeNow();
      });
    },
  };
}


export const ShadcnButton = __pui_React.forwardRef<GeneratedHandle, GeneratedComponentProps>(function ShadcnButton(props, ref) {
  const ownerRef = __pui_React.useRef<__pui_Owner | null>(null);
  const parentScope = __pui_React.useContext(__pui_ContextTransport);
  const parentRef = __pui_React.useRef<__pui_ContextScope | null>(null);
  const [frame, setFrame] = __pui_React.useState<__pui_Frame | null>(null);
  const [, publishHost] = __pui_React.useReducer((version: number) => version + 1, 0);
  const rootRef = __pui_React.useRef<HTMLElement | null>(null);

  const pendingHostRef = __pui_React.useRef(props.hostRef);
  pendingHostRef.current = props.hostRef;
  const boundHostRef = __pui_React.useRef<__pui_React.Ref<HTMLElement> | undefined>(undefined);
  const bindRoot = __pui_React.useCallback((root: HTMLElement | null) => {
    if (boundHostRef.current !== pendingHostRef.current) __pui_AssignHostRef(boundHostRef.current, null);
    boundHostRef.current = pendingHostRef.current;
    rootRef.current = root;
    ownerRef.current?.bindRoot(root);
    __pui_AssignHostRef(boundHostRef.current, root);
  }, []);
  __pui_React.useLayoutEffect(() => {
    if (boundHostRef.current === props.hostRef) return;
    __pui_AssignHostRef(boundHostRef.current, null);
    boundHostRef.current = props.hostRef;
    __pui_AssignHostRef(boundHostRef.current, rootRef.current);
  }, [props.hostRef]);
  // All irreversible work begins after an accepted shell commit, never during React render.
  __pui_React.useLayoutEffect(() => {
    parentRef.current = parentScope;
    let owner = ownerRef.current;
    if (!owner) {
      owner = __pui_CreateOwner(props, setFrame, () => parentRef.current, publishHost);
      ownerRef.current = owner;
      owner.start();

    } else owner.connect();
    owner.connectView();
    return () => { owner.disconnectView(); };
  }, []);
  __pui_React.useLayoutEffect(() => { parentRef.current = parentScope; }, [parentScope]);
  // Suspense can disconnect layout effects without unmounting the owner shell.
  // Passive cleanup identifies shell unmount; same-turn StrictMode replay cancels disposal.
  __pui_React.useEffect(() => {
    const owner = ownerRef.current;
    if (!owner) return;
    owner.connect();
    return () => { owner.disconnect(); };
  }, []);
  __pui_React.useLayoutEffect(() => { const owner = ownerRef.current; owner?.applyProps(props); }, [props]);
  __pui_React.useLayoutEffect(() => { if (frame) ownerRef.current!.accept(frame); }, [frame]);
  __pui_React.useLayoutEffect(() => { ownerRef.current?.commitHost(); });

  __pui_React.useImperativeHandle(ref, () => ownerRef.current!.handle, []);
  const template = __pui_React.useMemo(() => __pui_BindSlots(frame?.node, props.children), [frame?.node, props.children]);
  const host = ownerRef.current?.getHostProjection();
  const rootView = frame && frame.kind !== 'detach'
    ? __pui_RenderRoot(host!.tag, { ...__pui_HostProperties(props), ...__pui_RootProperties(host!.properties), 'data-pui-root': '', ref: bindRoot }, template) : null;
  const view = rootView && host?.portalTarget ? __pui_CreatePortal(rootView, host.portalTarget) : rootView;
  return __pui_React.createElement(__pui_ContextTransport.Provider, { value: ownerRef.current?.scope ?? null }, view);

});
ShadcnButton.displayName = "shadcn-button";

//# sourceMappingURL=ShadcnButton.tsx.map
