// Editable generated React DOM source. Profile: react-dom-source-v1.
// Inline owner lowering and emitted shared checked-data/Context helpers v1; no Proto-UI Runtime/Core/Adapter dependencies.
// Source graph SHA-256: f50124e47db682c24b7de6553c8f0dba9a3fda3fc79c3a9b41aa1c1676fe0ec3
import * as __puiReact from 'react';
import { releaseNativeMeta as __puiReleaseMeta } from './.proto-ui/meta/subscription-v1';
import { readNativeWebMeta as __puiReadMeta } from './.proto-ui/meta/web-snapshot-v1';
import { subscribeNativeRulePreferences as __puiSubscribePreferences, readNativeRulePreference as __puiReadPreference } from './.proto-ui/meta/preference-source-v1';


import { createNativeAuthoredHooks as __puiCreateAuthored } from './.proto-ui/owner/authored-hooks-v1';
import { createPortal as __puiCreatePortal } from 'react-dom';



import { createContextScope as __puiCreateContextScope, acceptsContextValue as __puiAccepts } from "./.proto-ui/context/scope-v1";
import type { ContextScope as __puiContextScope } from "./.proto-ui/context/scope-v1";
import { ContextTransport as __puiContextTransport } from './.proto-ui/context/react-v1';
import { createNativeStyle as __puiCreateNativeStyle, templateStyleTokens as __puiTemplateStyleTokens, type NativeStyle as __puiNativeStyle, type NativeStyleHandle as __puiNativeStyleHandle, type NativeRuleHandle as __puiNativeRuleHandle } from './.proto-ui/style/native-v1';


import { createNativeInteraction as __puiCreateNativeInteraction, type NativeInteraction as __puiNativeInteraction, type NativeFocus as __puiNativeFocus, type NativeAccessible as __puiNativeAccessible, type NativeObservedState as __puiNativeObservedState, type NativeInput as __puiNativeInput, type NativeFocusOptions as __puiNativeFocusOptions } from './.proto-ui/interaction/native-e6807d4f71af1465-v2';
import type { NativeModuleCapability as __puiNativeModuleCapability } from './.proto-ui/interaction/modules-e6807d4f71af1465-v2';




export type GeneratedProps = {
  "variant"?: "destructive" | "solid" | "surface" | null;
  "color"?: "coral" | "lavender" | "main" | "mint" | "sky" | null;
  "size"?: "default" | "icon" | "lg" | "sm" | null;
  "wrap"?: boolean | null;
  "disabled"?: boolean | null;
};
export type GeneratedExposes = {
  "disabled": __puiExternalState<boolean>;
  "hovered": __puiExternalState<boolean>;
  "focused": __puiExternalState<boolean>;
  "focusVisible": __puiExternalState<boolean>;
  "focusSelf": (options?: { "reason"?: "programmatic" | "keyboard" | "pointer"; "preventScroll"?: boolean }) => void;
  "pressed": __puiExternalState<boolean>;
  "click": { readonly kind: 'event'; readonly payload: "void" };
};
export type GeneratedComponentProps = GeneratedProps & Omit<__puiReact.HTMLAttributes<HTMLElement>, keyof GeneratedProps | 'dangerouslySetInnerHTML' | "onClick"> & {
  children?: __puiReact.ReactNode;
  /** The physical element is a target affordance, never a portable Proto expose. */
  hostRef?: __puiReact.Ref<HTMLElement>;
  hostProps?: Omit<__puiReact.AllHTMLAttributes<HTMLElement> & __puiReact.AnchorHTMLAttributes<HTMLElement>, 'children' | 'dangerouslySetInnerHTML'>;
  instanceAssociations?: Readonly<{ controlLabel?: object | null }>;
  "onClick"?: () => void;
  [event: `on${string}`]: unknown;
};
export interface GeneratedHandle {
  update(): void;
  getElement(): HTMLElement | null;
  getExposes(): GeneratedExposes;
  invokeInCallbackScope<T>(callback: () => T): T;
}
type __puiResolvedProps = Readonly<{ "variant": "solid" | "surface" | "destructive"; "color": "main" | "mint" | "lavender" | "coral" | "sky"; "size": "default" | "sm" | "lg" | "icon"; "wrap": boolean; "disabled": boolean }>;
type __puiStateEvent<T> = { type: 'next'; prev: T; next: T; reason?: unknown } | { type: 'disconnect'; reason: 'unmount' };
type __puiExternalState<T> = {
  get(): T;
  subscribe(callback: (event: __puiStateEvent<T>) => void): () => void;
  unsubscribe(off: () => void): void;
  readonly spec: Readonly<__puiStateSpec>;
};
type __puiState<T> = { get(): T; setDefault(value: T): void; set(value: T, reason?: unknown): void };
type __puiStateSpec = { kind: 'bool' | 'enum' | 'string' | 'number.discrete' | 'number.range'; options?: readonly (string | number)[]; min?: number; max?: number; step?: number; clamp?: boolean };
type __puiDataSchema = string | { kind: string; fields?: readonly { name: string; type: __puiDataSchema; optional?: boolean }[]; element?: __puiDataSchema; members?: readonly __puiDataSchema[]; value?: unknown };
type __puiPropSpec = { type: __puiDataSchema; default?: unknown; empty?: 'accept' | 'fallback' | 'error'; options?: readonly string[]; range?: { min?: number; max?: number }; validator?: (value: never) => boolean };
type __puiRun = {
  update(): void;
  feedback: { style: Pick<__puiNativeStyle, 'patch' | 'suppress' | 'clearPatch'> };
  props: { get(): __puiResolvedProps; getRaw(): Readonly<Record<string, unknown>>; isProvided(key: string): boolean };
  context: {
    read<T>(key: object): T;
    tryRead<T>(key: object): T | null;
    tryReadAncestor<T>(key: object): T | null;
    update<T>(key: object, next: T | ((prev: T) => T)): void;
    tryUpdate<T>(key: object, next: T | ((prev: T) => T)): boolean;
  };
  expose: { emit(key: string, payload?: unknown, options?: Record<string, unknown>): void };
  lifecycle: { setPresent(present: boolean): void };
};
type __puiFrame = { revision: number; epoch: number; kind: 'mount' | 'update' | 'detach'; node: __puiReact.ReactNode };
type __puiOwner = {
  handle: GeneratedHandle;
  scope: __puiContextScope;
  getHostProjection(): { tag: string; properties: Readonly<Record<string, string | number | boolean | null>>; portalTarget: HTMLElement | null };
  bindRoot(root: HTMLElement | null): void;
  connect(): void;
  connectView(): void;
  disconnectView(): void;
  commitHost(): void;
  start(): void;
  applyProps(props: GeneratedComponentProps): void;
  accept(frame: __puiFrame): boolean;
  disconnect(): void;

};

const __puiSlots = new WeakSet<object>();
const __puiPortablePropNames = new Set<string>(["variant","color","size","wrap","disabled"]);
const __puiOutwardEventNames = new Set<string>(["onClick"]);
function __puiHostProperties(props: GeneratedComponentProps): Record<string, unknown> {
  const result: Record<string, unknown> = { ...props.hostProps };
  for (const [key, value] of Object.entries(props)) {
    if (__puiPortablePropNames.has(key) || __puiOutwardEventNames.has(key)
      || ['children', 'hostRef', 'hostProps', 'instanceAssociations', 'key', 'ref', 'dangerouslySetInnerHTML'].includes(key)) continue;
    result[key] = value;
  }
  // Explicit native host fields cannot create a second subscriber to an outward
  // Proto signal, replace the slot tree, or steal the compiler's physical ref.
  for (const key of [...__puiOutwardEventNames, 'children', 'ref', 'key', 'dangerouslySetInnerHTML']) delete result[key];
  return result;
}
function __puiAssignHostRef(ref: __puiReact.Ref<HTMLElement> | undefined, element: HTMLElement | null): void {
  if (typeof ref === 'function') ref(element);
  else if (ref) (ref as __puiReact.MutableRefObject<HTMLElement | null>).current = element;
}
function __puiBindSlots(node: __puiReact.ReactNode, slot: __puiReact.ReactNode): __puiReact.ReactNode {
  if (Array.isArray(node)) {
    let result: __puiReact.ReactNode[] | null = null;
    for (let index = 0; index < node.length; index++) {
      const child = __puiBindSlots(node[index], slot);
      if (child !== node[index]) { result ??= node.slice(); result[index] = child; }
    }
    return result ?? node;
  }
  if (!__puiReact.isValidElement(node)) return node;
  const element = node as __puiReact.ReactElement<{ children?: __puiReact.ReactNode }>;
  if (__puiSlots.has(element)) return __puiReact.createElement(__puiReact.Fragment, { key: element.key }, slot);
  const previous = element.props.children, next = __puiBindSlots(previous, slot);
  return previous === next ? node : __puiReact.cloneElement(element, undefined, next);
}
function __puiRootProperties(properties: Readonly<Record<string, unknown>>, initial = false): Record<string, unknown> {
  const result: Record<string, unknown> = { ...properties };
  // Only server/initial hydration markup projects the canonical value through
  // defaultValue. A live native TextControl owns editing and its reset default;
  // its commit hook restores those fields after React's host reconciliation.
  if (Object.hasOwn(result, 'value')) { result.defaultValue = initial ? result.value : undefined; delete result.value; }
  if (typeof result.style === 'string') {
    const style: Record<string, string> = {};
    for (const declaration of result.style.split(';')) {
      const colon = declaration.indexOf(':');
      if (colon < 1) continue;
      const name = declaration.slice(0, colon).trim();
      style[name.startsWith('--') ? name : name.replace(/-([a-z])/g, (_match, letter: string) => letter.toUpperCase())] = declaration.slice(colon + 1).trim();
    }
    result.style = style;
  }
  return result;
}
function __puiHasRootContent(node: __puiReact.ReactNode): boolean {
  if (node === null || node === undefined || typeof node === 'boolean' || node === '') return false;
  if (Array.isArray(node)) return node.some(__puiHasRootContent);
  if (__puiReact.isValidElement(node) && node.type === __puiReact.Fragment)
    return __puiHasRootContent((node.props as { children?: __puiReact.ReactNode }).children);
  return true;
}
function __puiRenderRoot(tag: string, attributes: Record<string, unknown>, children: __puiReact.ReactNode): __puiReact.ReactElement {
  if (['input', 'textarea', 'img', 'area', 'base', 'br', 'col', 'embed', 'hr', 'link', 'meta', 'param', 'source', 'track', 'wbr'].includes(tag)) {
    if (__puiHasRootContent(children)) throw new TypeError('[Template] this physical control Root cannot contain semantic children.');
    return __puiReact.createElement(tag, attributes);
  }
  return __puiReact.createElement(tag, attributes, children);
}

function __puiResolveProps(
  specs: Readonly<Record<string, __puiPropSpec>>,
  defaults: readonly Readonly<Record<string, unknown>>[],
  previousValid: Record<string, unknown>,
  raw: Readonly<Record<string, unknown>>,
  strict: boolean
): __puiResolvedProps {
  const next: Record<string, unknown> = Object.create(null);
  for (const key of Object.keys(specs)) {
    const spec = specs[key];
    const provided = Object.hasOwn(raw, key);
    const value = raw[key];
    const empty = value === null || value === undefined;
    const valid = (candidate: unknown) => {
      if (!__puiAccepts(spec.type, candidate) || spec.range && !(typeof candidate === 'number'
        && candidate >= (spec.range.min ?? -Infinity) && candidate <= (spec.range.max ?? Infinity))) return false;
      // The checked schema establishes the validator's declared argument domain.
      // A throwing validator rejects this candidate, as in ordinary Props.
      try { return spec.validator ? !!spec.validator(candidate as never) : true; }
      catch { return false; }
    };
    if (provided && !empty && valid(value)) {
      next[key] = value;
      previousValid[key] = value;
      continue;
    }
    if (provided && empty && spec.empty === 'accept') { next[key] = null; continue; }
    const nonEmpty = strict && spec.empty === 'error';
    let found = false;
    const take = (candidate: unknown) => {
      if (candidate === undefined || nonEmpty && candidate === null) return false;
      if (candidate !== null && !valid(candidate)) return false;
      next[key] = candidate;
      found = true;
      return true;
    };
    if (provided && Object.hasOwn(previousValid, key)) take(previousValid[key]);
    if (!found) for (const layer of defaults) if (Object.hasOwn(layer, key) && take(layer[key])) break;
    if (!found && Object.hasOwn(spec, 'default')) take(spec.default);
    if (!found) {
      if (nonEmpty) throw new Error('[Props] missing, empty or invalid prop without non-empty fallback: ' + key);
      next[key] = null;
    }
    if (provided && next[key] !== null) previousValid[key] = next[key];
  }
  return Object.freeze(next) as __puiResolvedProps;
}

function __puiCompleteSteps(steps: readonly (() => void)[]): void {
  let failure: { error: unknown } | undefined;
  for (const step of steps) { try { step(); } catch (error) { failure ??= { error }; } }
  if (failure) throw failure.error;
}

function __puiCreateOwner(initial: GeneratedComponentProps, publish: (frame: __puiFrame) => void, getParent: () => __puiContextScope | null, publishHost: () => void): __puiOwner {
  let phase: 'setup' | 'callback' | 'render' | 'idle' = 'setup';
  let lifetime: 'alive' | 'disposing' | 'disposed' = 'alive';
  let connected = true;
  let cleanupVersion = 0;
  let desiredPresent = true;
  let mounted = false;
  let viewConnected = false;
  let epoch = 0;
  let revision = 0;
  let acceptedRevision = 0;
  let latest: __puiFrame | null = null;
  let dirty = false;
  let updateQueued = false;
  let scheduled = false;
  let hostScheduled = false;
  let callbackDepth = 0;
  let slotUsed = false;
  let elementSequence = 0;
  let hostProps = initial;
  let root: HTMLElement | null = null;
  let rootGeneration = 0;
  let rootBinding: 'retiring' | 'binding' | null = null;
  let pendingRoot: { value: HTMLElement | null } | undefined;
  function consumePendingRoot(): { value: HTMLElement | null } | undefined {
    const request = pendingRoot; pendingRoot = undefined; return request;
  }

  let raw: Readonly<Record<string, unknown>> = Object.freeze({});
  let resolved: __puiResolvedProps;
  let hydrated = false;
  let propsWindow: { raw: Readonly<Record<string, unknown>>; resolved: __puiResolvedProps } | null = null;
  const specs: Record<string, __puiPropSpec> = Object.create(null);
  const defaults: Readonly<Record<string, unknown>>[] = [];
  const previousValid: Record<string, unknown> = Object.create(null);
  const stateNames = new Set<string>();
  // Reserve before setup; only successful setup publishes a reusable opaque result.

  const stateSubscribers = new Set<Set<(event: __puiStateEvent<unknown>) => void>>();
  const pendingStateEvents: (() => void)[] = [];
  const authorStateWatchCleanups: (() => void)[] = [];
  let emittingState = false;
  type __puiResolvedWatcher = { active: boolean; keys: readonly string[] | null; callback: (run: __puiRun, next: __puiResolvedProps, prev: __puiResolvedProps, info: Readonly<Record<string, unknown>>) => void };
  type __puiRawWatcher = { active: boolean; keys: readonly string[] | null; callback: (run: __puiRun, next: Readonly<Record<string, unknown>>, prev: Readonly<Record<string, unknown>>, info: Readonly<Record<string, unknown>>) => void };
  const watchers: __puiResolvedWatcher[] = [];
  const rawWatchers: __puiRawWatcher[] = [], rawAllWatchers: __puiRawWatcher[] = [];
  const exposes: Record<string, unknown> = Object.create(null);
  const methodSchemas: Record<string, { args(args: unknown[]): boolean; result(value: unknown): boolean }> = {
    "focusSelf": { args: (args: unknown[]) => args.length <= 1 && (args[0] === undefined || __puiAccepts({"kind":"record","fields":[{"name":"reason","optional":true,"type":{"kind":"union","members":[{"kind":"literal","value":"programmatic"},{"kind":"literal","value":"keyboard"},{"kind":"literal","value":"pointer"}]}},{"name":"preventScroll","optional":true,"type":"boolean"}]}, args[0])), result: (result: unknown) => __puiAccepts("void", result) },
  };
  const eventSchemas: Record<string, __puiDataSchema> = {
    "click": "void",
  };
  const propSchemas: Record<string, __puiDataSchema> = {
    "variant": {"kind":"union","members":[{"kind":"literal","value":"solid"},{"kind":"literal","value":"surface"},{"kind":"literal","value":"destructive"}]},
    "color": {"kind":"union","members":[{"kind":"literal","value":"main"},{"kind":"literal","value":"mint"},{"kind":"literal","value":"lavender"},{"kind":"literal","value":"coral"},{"kind":"literal","value":"sky"}]},
    "size": {"kind":"union","members":[{"kind":"literal","value":"default"},{"kind":"literal","value":"sm"},{"kind":"literal","value":"lg"},{"kind":"literal","value":"icon"}]},
    "wrap": "boolean",
    "disabled": "boolean",
  };
  const callbacks = {
    created: [] as ((run: __puiRun) => void)[], mounted: [] as ((run: __puiRun) => void)[],
    updated: [] as ((run: __puiRun) => void)[], unmounted: [] as ((run: __puiRun) => void)[],
    beforeDispose: [] as ((run: __puiRun) => void)[],
  };
  function ensureAlive() {
    if (lifetime === 'disposed' || !connected && phase !== 'callback')
      throw new Error('Generated handle is invalid after terminal disposal.');
  }
  function ensurePhase(expected: typeof phase) {
    ensureAlive();
    if (phase !== expected) throw new Error('Illegal generated operation phase: ' + phase + '; expected ' + expected);
  }
  function ensureExternal() {
    if (!connected || lifetime !== 'alive') throw new Error('Generated handle is invalid after terminal disposal begins.');
  }
  function invoke<T>(callback: () => T): T {
    ensureAlive();
    if (phase === 'render' || phase === 'setup') throw new Error('Cannot enter callback scope from ' + phase);
    const previous = phase;
    phase = 'callback';
    ++callbackDepth;
    try { return callback(); }
    finally { phase = previous; --callbackDepth; if (!callbackDepth) schedule(); }
  }
  const __puiMeta = (key: string) => __puiReadMeta(root?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), key);
  const __puiAuthored = __puiCreateAuthored({setup: () => ensurePhase('setup'), borrow(value) {
    const state = value as __puiState<unknown>, external = externalStates.get(state) as __puiExternalState<unknown> | undefined;
    if (!external) throw new Error('[State] borrowed state must belong to this instance.');
    const borrowed = Object.freeze({ get: () => state.get(), setDefault: (value: unknown) => state.setDefault(value), set: (value: unknown, reason?: unknown) => state.set(value, reason), watch(callback: (run: __puiRun, event: __puiStateEvent<unknown>) => void) { ensurePhase('setup'); const off = external.subscribe(event => invoke(() => callback(__puiRunHandle, event))); authorStateWatchCleanups.push(off); return off; } });
    // A capture borrows the same owner State; native modules must retain its provenance.
    externalStates.set(borrowed, external);

    return borrowed;
  } });
  
  const context = __puiCreateContextScope({
    getParent, isAlive: () => lifetime !== 'disposed', invoke,
    validate: (key: object, value: unknown): boolean => false,
  });
  function projectStyle(tokens: readonly string[]) {
    if (!root) return;
    if (tokens.length) root.setAttribute('data-pui-style', tokens.join(' '));
    else root.removeAttribute('data-pui-style');
  }
  const __puiStyle = __puiCreateNativeStyle({
    ensureSetup: () => ensurePhase('setup'),
    ensureRuntime: () => ensurePhase('callback'),
    isAlive: () => lifetime !== 'disposed',
    project: tokens => { projectStyle(tokens);  },
    getMeta: (key: string) => key.startsWith('preference.') ? __puiReadPreference(root?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), key) : undefined, subscribeMeta: (notify: () => void) => { const leases: (() => void)[] = []; try { leases.push(__puiSubscribePreferences(root?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), ["preference.reducedMotion"], notify)); } catch (error) { __puiReleaseMeta([() => { throw error; }, ...leases]); } return () => __puiReleaseMeta(leases); },
  });
  function dispatch(list: readonly ((run: __puiRun) => void)[]) {
    invoke(() => { for (const callback of list) callback(__puiRunHandle); });
  }
  function detachView() {
    const wasMounted = mounted; mounted = false;
    __puiCompleteSteps([
      () => __puiInteraction.unmount(),
      () => __puiStyle.unmount(),
      () => { if (wasMounted) dispatch(callbacks.unmounted); },
    ]);
  }
  function schedule() {
    if (scheduled || callbackDepth || !connected || lifetime !== 'alive') return;
    if (!updateQueued && desiredPresent === mounted && !(!desiredPresent && root) && !(latest && latest.revision > acceptedRevision)) return;
    scheduled = true;
    queueMicrotask(() => {
      scheduled = false;
      if (!connected || lifetime !== 'alive') return;
      if (latest && latest.revision > acceptedRevision) return;
      if (!desiredPresent) {
        if (mounted || root) deliver('detach');
        else { dirty = dirty || updateQueued; updateQueued = false; }
      } else if (!mounted) deliver('mount');
      else if (updateQueued) deliver('update');
    });
  }
  function deliver(kind: __puiFrame['kind']) {
    updateQueued = false;
    let node: __puiReact.ReactNode = null;
    if (kind === 'mount') ++epoch;
    if (kind !== 'detach') {
      slotUsed = false;
      elementSequence = 0;
      phase = 'render';
      try { node = normalize(render(__puiRenderer));  }
      finally { phase = 'idle'; }
      dirty = false;
    }
    latest = { revision: ++revision, epoch, kind, node };
    publish(latest);
  }
  function normalize(value: unknown): __puiReact.ReactNode {
    if (value === null) return null;
    if (Array.isArray(value)) return value.flatMap((item) => {
      const child = normalize(item);
      return child === null ? [] : [child];
    });
    if (typeof value === 'string' || typeof value === 'number' && Number.isFinite(value) || __puiReact.isValidElement(value)) return value;
    throw new Error('[Template] child must be null, text, a finite number or an authored element/slot.');
  }
  function __puiElement(tag: string, ...args: unknown[]) {
    ensurePhase('render');
    if (!tag || typeof tag !== 'string') throw new Error('[Template] native elements require a tag string.');
    let children: unknown = null;
    let props: Record<string, unknown> = {};
    if (args.length === 1) {
      const argument = args[0];
      if (argument !== null && typeof argument === 'object' && !Array.isArray(argument) && !__puiReact.isValidElement(argument)) {
        props = argument as Record<string, unknown>;
      } else children = argument;
    } else if (args.length === 2) {
      if (!args[0] || typeof args[0] !== 'object' || Array.isArray(args[0]))
        throw new Error('[Template] native template props must be a record.');
      props = args[0] as Record<string, unknown>;
      children = args[1];
    }
    if (Object.keys(props).some((key) => key !== 'style'))
      throw new Error('[Template] native template props support only style.');
    const tokens = Object.hasOwn(props, 'style') ? __puiTemplateStyleTokens(props.style as __puiNativeStyleHandle) : '';
    const normalized = normalize(children);
    return __puiReact.createElement(tag, { key: elementSequence++, ...(tokens ? { 'data-pui-style': tokens } : {}) }, ...(Array.isArray(normalized) ? normalized : [normalized]));
  }
  const __puiRenderer = {
    read: Object.freeze({
      props: Object.freeze({
        get() { ensurePhase('render'); return resolved; },
        getRaw() { ensurePhase('render'); return raw; },
        isProvided(key: string) { ensurePhase('render'); return Object.hasOwn(raw, key); },
      }),
      context: Object.freeze({
        read<T>(key: object): T { ensurePhase('render'); return context.read<T>(key); },
        tryRead<T>(key: object): T | null { ensurePhase('render'); return context.tryRead<T>(key); },
      }),
    }),
    el: __puiElement,


    slot: () => {
      ensurePhase('render');
      if (slotUsed) throw new Error('[Template] multiple anonymous slots are not supported.');
      slotUsed = true;
      const slot = __puiReact.createElement(__puiReact.Fragment, { key: elementSequence++ });
      __puiSlots.add(slot);
      return slot;
    },
  };
  function __puiCreateState<T extends boolean | string | number>(name: string, initialValue: T, spec: __puiStateSpec): __puiState<T> {
    ensurePhase('setup');
    __puiAuthored.claimState(name);
    spec = Object.freeze({ ...spec, ...(spec.options ? { options: Object.freeze([...spec.options]) } : {}) });
    const type = spec.kind === 'bool' ? 'boolean' : spec.kind === 'string' || spec.kind === 'enum' ? 'string' : 'number';
    if (spec.options?.some((option) => typeof option !== type || typeof option === 'number' && !Number.isFinite(option)))
      throw new Error('[State] invalid state options: ' + name);
    if (spec.kind === 'number.range' && (!Number.isFinite(spec.min) || !Number.isFinite(spec.max))
      || spec.min !== undefined && !Number.isFinite(spec.min) || spec.max !== undefined && !Number.isFinite(spec.max)
      || spec.min !== undefined && spec.max !== undefined && spec.min > spec.max
      || spec.step !== undefined && !Number.isFinite(spec.step))
      throw new Error('[State] invalid numeric domain: ' + name);
    function validate(next: T) {
      if (typeof next !== type || typeof next === 'number' && !Number.isFinite(next))
        throw new TypeError('[State] invalid state value: ' + name);
      if (spec.kind === 'enum' && !spec.options?.includes(next as string)) throw new Error('[State] enum value outside options: ' + name);
      if (spec.options?.length && (spec.kind === 'enum' || spec.kind === 'string' || spec.kind === 'number.discrete')) {
        if (!spec.options.includes(next as string | number)) throw new Error('[State] state value outside options: ' + name);
        return;
      }
      if (typeof next !== 'number') return;
      if (next < (spec.min ?? -Infinity) || next > (spec.max ?? Infinity))
        throw new Error('[State] state value outside range: ' + name);
      if (spec.kind === 'number.discrete' && spec.step !== undefined && spec.step > 0
        && !Number.isInteger((next - (spec.min ?? 0)) / spec.step))
        throw new Error('[State] state value violates step: ' + name);
    }
    let value = initialValue;
    // Core range clamping normalizes definition defaults only, never callback writes.
    if (spec.kind === 'number.range' && spec.clamp && typeof value === 'number' && Number.isFinite(value))
      value = Math.min(spec.max!, Math.max(spec.min!, value)) as T;
    validate(value);
    stateNames.add(name);
    const subscribers = new Set<(event: __puiStateEvent<T>) => void>();
    stateSubscribers.add(subscribers as Set<(event: __puiStateEvent<unknown>) => void>);
    const state = {
      get() { ensureAlive(); return value; },
      setDefault(next: T) { ensurePhase('setup'); validate(next); value = next; },
      set(next: T, reason?: unknown) {
        ensurePhase('callback');
        validate(next);
        if (Object.is(value, next)) return;
        const event: __puiStateEvent<T> = { type: 'next', prev: value, next, reason };
        value = next;
        __puiStyle.refresh();
        
        __puiInteraction.refresh();
        for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(pendingStateEvents, pendingStateEvents.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!emittingState) {
  emittingState = true;
  const notificationFailures: unknown[] = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < pendingStateEvents.length) {
      try { pendingStateEvents[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { pendingStateEvents.length = 0; emittingState = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
      },
    };
    const external: __puiExternalState<T> = Object.freeze({
      get() { ensureExternal(); return state.get(); },
      subscribe(callback: (event: __puiStateEvent<T>) => void) {
        ensureExternal(); const registration: typeof callback = event => callback(event); subscribers.add(registration); return () => { subscribers.delete(registration); };
      },
      unsubscribe(off: () => void) { off(); },
      spec: Object.freeze(spec),
    });
    externalStates.set(state, external);
    
    __puiAuthored.state(name, state);
    return state;
  }
  const externalStates = new WeakMap<object, unknown>();
  const observedStateCleanups: (() => void)[] = [];
  function registerObservedState<T extends boolean | string | number>(state: __puiNativeObservedState<T>) {
    const subscribers = new Set<(event: __puiStateEvent<T>) => void>();
    stateSubscribers.add(subscribers as Set<(event: __puiStateEvent<unknown>) => void>);
    observedStateCleanups.push(state.subscribe((event) => {
      __puiStyle.refresh();
      
      __puiInteraction.refresh();
      for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(pendingStateEvents, pendingStateEvents.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!emittingState) {
  emittingState = true;
  const notificationFailures: unknown[] = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < pendingStateEvents.length) {
      try { pendingStateEvents[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { pendingStateEvents.length = 0; emittingState = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
    }));
    const kind = typeof state.get();
    const external: __puiExternalState<T> = Object.freeze({
      get() { ensureExternal(); return state.get(); },
      subscribe(callback: (event: __puiStateEvent<T>) => void) {
        ensureExternal(); const registration: typeof callback = event => callback(event); subscribers.add(registration); return () => { subscribers.delete(registration); };
      },
      unsubscribe(off: () => void) { off(); },
      spec: Object.freeze({ kind: kind === 'boolean' ? 'bool' as const : kind === 'number' ? 'number.discrete' as const : 'string' as const }),
    });
    externalStates.set(state, external);
    
  }
  const __puiInteraction: __puiNativeInteraction<__puiRun> = __puiCreateNativeInteraction<__puiRun>({
    ensureSetup: () => ensurePhase('setup'),
    ensureRuntime: () => ensurePhase('callback'),
    ensureEvent: () => ensurePhase('callback'),
    isAlive: () => lifetime !== 'disposed',
    isSetupComplete: () => phase !== 'setup',
    isReady: () => phase !== 'setup' && mounted && viewConnected && desiredPresent && connected && lifetime === 'alive',
    invoke,
    getRun: () => __puiRunHandle,
    getResolvedProps: () => resolved,
    getAssociations: () => hostProps.instanceAssociations,

    subscribeState(state, callback) { return (externalStates.get(state) as __puiExternalState<unknown> | undefined)?.subscribe(callback) ?? (state as __puiNativeObservedState<unknown>).subscribe(callback); },
    getRoot: () => viewConnected ? root : null,
    identity: context,
    getLogicalParent: getParent,
    declarations: [],
    tableFamily: undefined,
    getExposes: () => connected && lifetime === 'alive' ? exposes : {},
    registerExpose(key, value) {
      const state = value && typeof value === 'object' ? externalStates.get(value) : undefined;
      if (state) registerExpose(key, state);
      else if (typeof value === 'function') registerExpose(key, (...args: unknown[]) => { ensureExternal(); return invoke(() => value(...args)); });
      else registerExpose(key, value);
    },
    createOwnedState: <T extends boolean | string | number>(name: string, value: T, spec?: __puiStateSpec) => __puiCreateState(name, value, spec ?? { kind: typeof value === 'boolean' ? 'bool' : typeof value === 'number' ? 'number.discrete' : 'string' }),
    watchState<T>(state: {get(): T}, callback: (run: __puiRun, event: __puiStateEvent<T>) => void) {
      ensurePhase('setup');
      const external = externalStates.get(state) as __puiExternalState<T>;
      if (!external) throw new Error('[State] foreign watch target');
      const off = external.subscribe(event => invoke(() => callback(__puiRunHandle, event)));
      authorStateWatchCleanups.push(off); return off;
    },
    isPropProvided: key => Object.hasOwn(raw, key),
    setPresent: value => __puiRunHandle.lifecycle.setPresent(value),
    requestHostUpdate() {
      if (hostScheduled || lifetime !== 'alive') return;
      hostScheduled = true;
      queueMicrotask(() => { hostScheduled = false; if (connected && lifetime === 'alive') publishHost(); });
    },
    registerGenericObservedState: registerObservedState,
    emit: key => __puiRunHandle.expose.emit(key),
  });
  function disposeInteraction() {
    __puiCompleteSteps([() => __puiInteraction.dispose(), ...observedStateCleanups.splice(0), ...authorStateWatchCleanups.splice(0)]);
  }
  const __puiRunHandle: __puiRun = {
    feedback: { style: __puiStyle },
    update() {
      ensurePhase('callback');
      if (lifetime !== 'alive') return;
      dirty = true;
      if (desiredPresent && mounted) updateQueued = true;
      schedule();
    },
    props: {
      get() { ensureAlive(); return propsWindow?.resolved ?? resolved; },
      getRaw() { ensureAlive(); return propsWindow?.raw ?? raw; },
      isProvided(key: string) { ensureAlive(); return Object.hasOwn(propsWindow?.raw ?? raw, key); },
    },
    context: Object.freeze({
      read<T>(key: object): T { ensurePhase('callback'); return context.read<T>(key); },
      tryRead<T>(key: object): T | null { ensurePhase('callback'); return context.tryRead<T>(key); },
      tryReadAncestor<T>(key: object): T | null { ensurePhase('callback'); return context.tryReadAncestor<T>(key); },
      update<T>(key: object, next: T | ((prev: T) => T)) { ensurePhase('callback'); context.update(key, next); },
      tryUpdate<T>(key: object, next: T | ((prev: T) => T)) { ensurePhase('callback'); return context.tryUpdate(key, next); },
    }),
    expose: { emit(key, payload, options) {
      ensurePhase('callback');
      const declaration = exposes[key] as { kind?: string; payload: __puiDataSchema } | undefined;
      if (declaration?.kind !== 'event') throw new Error('[Expose] event was not declared: ' + key);
      if (!__puiAccepts(declaration.payload, payload)) throw new TypeError('[Expose] invalid event payload: ' + key);
      const sink = (hostProps as Record<string, unknown>)['on' + key.charAt(0).toUpperCase() + key.slice(1)];
      if (typeof sink === 'function') { try { sink(payload, options); } catch { /* Host sink failures do not re-enter prototype execution. */ } }
    } },
    lifecycle: { setPresent(present) {
      ensurePhase('callback');
      if (lifetime !== 'alive') throw new Error('[Lifecycle] cannot update view presence after terminal disposal begins.');
      if (typeof present !== 'boolean') throw new Error('[Lifecycle] view presence must be boolean.');
      if (desiredPresent === present) return;
      desiredPresent = present;
      schedule();
    } },
  };
  function registerExpose(key: string, value: unknown) {
    ensurePhase('setup');
    if (!key || Object.hasOwn(exposes, key)) throw new Error('[Expose] empty or duplicate declaration: ' + key);
    exposes[key] = value;
  }
  const __puiDef = {
    event: __puiInteraction.event,
    feedback: { style: { use: __puiStyle.use, declareDecoration: __puiStyle.declareDecoration, to: __puiStyle.to } },
    context: Object.freeze({
      provide<T>(key: object, value: T) { ensurePhase('setup'); context.provide(key, value); },
      subscribe<T>(key: object, callback?: (run: __puiRun, next: T, prev: T) => void) {
        ensurePhase('setup');
        return context.subscribe<T>(key, 'required', callback ? (next, prev) => callback(__puiRunHandle, next as T, prev as T) : undefined);
      },
      trySubscribe<T>(key: object, callback?: (run: __puiRun, next: T | null, prev: T | null) => void) {
        ensurePhase('setup');
        return context.subscribe<T>(key, 'optional', callback ? (next, prev) => callback(__puiRunHandle, next, prev) : undefined);
      },
      trySubscribeAncestor<T>(key: object, callback?: (run: __puiRun, next: T | null, prev: T | null) => void) {
        ensurePhase('setup');
        return context.subscribe<T>(key, 'optional', callback ? (next, prev) => callback(__puiRunHandle, next, prev) : undefined, 'ancestor');
      },
    }),
    props: {
      define(incoming: Record<string, Omit<__puiPropSpec, 'type'> & { type: __puiDataSchema | 'enum' | 'object' | 'any' }>) {
        ensurePhase('setup');
        const next = { ...specs };
        for (const [key, authored] of Object.entries(incoming)) {
          const schema = propSchemas[key];
          if (!schema) throw new Error('[Props] missing checked declaration: ' + key);
          const spec: __puiPropSpec = { ...authored, type: schema };
          const previous = specs[key];
          if (!previous) { next[key] = { ...spec }; continue; }
          if (previous.validator && previous.validator !== spec.validator)
            throw new Error('[Props] validator replacement or removal is disallowed: ' + key);
          const rank = (empty: __puiPropSpec['empty']) => empty === 'accept' ? 0 : empty === 'error' ? 2 : 1;
          if (JSON.stringify(previous.type) !== JSON.stringify(spec.type) || Object.hasOwn(spec, 'empty') && rank(spec.empty) > rank(previous.empty)
            || previous.range && spec.range && ((spec.range.min ?? -Infinity) > (previous.range.min ?? -Infinity)
              || (spec.range.max ?? Infinity) < (previous.range.max ?? Infinity)))
            throw new Error('[Props] conflicting or stricter prop definition: ' + key);
          next[key] = { ...previous, ...spec, empty: previous.empty ?? 'fallback', range: spec.range ?? previous.range };
          if (Object.hasOwn(previous, 'default')) next[key].default = previous.default;
        }
        Object.assign(specs, next);
        resolved = __puiResolveProps(specs, defaults, previousValid, raw, false);
        __puiInteraction.refresh();
      },
      setDefaults(partial: Record<string, unknown>) {
        ensurePhase('setup');
        for (const key of Object.keys(partial)) if (!Object.hasOwn(specs, key)) throw new Error('[Props] undeclared default key: ' + key);
        defaults.unshift({ ...partial });
        resolved = __puiResolveProps(specs, defaults, previousValid, raw, false);
        __puiInteraction.refresh();
      },
      watch(keys: readonly string[], callback: (run: __puiRun, next: __puiResolvedProps, prev: __puiResolvedProps, info: Readonly<Record<string, unknown>>) => void) {
        ensurePhase('setup');
        if (!keys.length || keys.some((key) => !Object.hasOwn(specs, key))) throw new Error('[Props] watchers require declared keys.');
        const watcher = { keys: [...keys], callback, active: true };
        watchers.push(watcher);
        return () => { watcher.active = false; };
      },
      watchAll(callback: __puiResolvedWatcher['callback']) {
        ensurePhase('setup');
        const watcher: __puiResolvedWatcher = { keys: null, callback, active: true };
        watchers.push(watcher);
        return () => { watcher.active = false; };
      },
      watchRaw(keys: readonly string[], callback: __puiRawWatcher['callback']) {
        ensurePhase('setup');
        if (!keys.length || keys.some(key => typeof key !== 'string' || !key.length)) throw new Error('[Props] raw watchers require nonempty keys.');
        const watcher: __puiRawWatcher = { keys: [...keys], callback, active: true };
        rawWatchers.push(watcher);
        return () => { watcher.active = false; };
      },
      watchRawAll(callback: __puiRawWatcher['callback']) {
        ensurePhase('setup');
        const watcher: __puiRawWatcher = { keys: null, callback, active: true };
        rawAllWatchers.push(watcher);
        return () => { watcher.active = false; };
      },
    },
    state: {
      bool: (name: string, value: boolean) => __puiCreateState(name, value, { kind: 'bool' }),
      string: (name: string, value: string, spec: Omit<__puiStateSpec, 'kind'> = {}) => __puiCreateState(name, value, { kind: 'string', ...spec }),
      enum: (name: string, value: string, spec: { options: readonly string[] }) => __puiCreateState(name, value, { kind: 'enum', ...spec }),
      numberDiscrete: (name: string, value: number, spec: Omit<__puiStateSpec, 'kind'> = {}) => __puiCreateState(name, value, { kind: 'number.discrete', ...spec }),
      numberRange: (name: string, value: number, spec: Omit<__puiStateSpec, 'kind'>) => __puiCreateState(name, value, { kind: 'number.range', ...spec }),
    },
    expose: {
      value: registerExpose,
      state(key: string, state: object) {
        const external = externalStates.get(state);
        if (!external) throw new Error('[Expose] state must belong to this instance.');
        registerExpose(key, external);
        __puiAuthored.introduceObserved(state);
      },
      event(key: string, _spec: { payload?: 'void' | 'any' | 'json'; options?: Readonly<Record<string, unknown>> } = {}) {
        if (!Object.hasOwn(eventSchemas, key)) throw new Error('[Expose] missing checked event schema: ' + key);
        registerExpose(key, Object.freeze({ kind: 'event', payload: eventSchemas[key] }));
      },
      method<A extends unknown[], R>(key: string, callback: (...args: A) => R, project?: (value: R) => R) {

        registerExpose(key, (...args: A): R => {
          ensureExternal();
          return invoke(() => {
          const schema = methodSchemas[key];
          if (!schema || !schema.args(args))
            throw new TypeError('[Expose] invalid method arguments: ' + key);
          const result = callback(...args);
          if (!schema.result(result)) throw new TypeError('[Expose] invalid method result: ' + key);
          return project ? project(result) : result;
          });
        });
      },
    },
    lifecycle: {
      onCreated(callback: (run: __puiRun) => void) { ensurePhase('setup'); callbacks.created.push(callback); },
      onMounted(callback: (run: __puiRun) => void) { ensurePhase('setup'); callbacks.mounted.push(callback); },
      onUpdated(callback: (run: __puiRun) => void) { ensurePhase('setup'); callbacks.updated.push(callback); },
      onUnmounted(callback: (run: __puiRun) => void) { ensurePhase('setup'); callbacks.unmounted.push(callback); },
      onBeforeDispose(callback: (run: __puiRun) => void) { ensurePhase('setup'); callbacks.beforeDispose.push(callback); },
    },
  };
  const __puiHook0 = (options?: unknown) => (__puiAuthored.install({name: "as-button", mode: "once", setup: (options, api) => ((def: typeof __puiDef) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":12:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = ({"kind":"tw","tokens":["select-none"],"groups":["content-selection affordance"]} as const);
const __puiCaptureResult = __puiCaptureReceiver.feedback.style.use(__puiCaptureArg0); __puiAuthored.effect("feedback", __puiCaptureResult); __puiAuthored.disposer("feedback", __puiCaptureResult); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":13:9
      const accessible = __puiAuthored.privileged("asAccessible", () => __puiInteraction.asAccessible());
      // Source "packages/prototypes/base/src/button/button.proto.ts":15:3
      __puiAuthored.privileged("asTrigger", () => __puiInteraction.asTrigger());
      // Source "packages/prototypes/base/src/button/button.proto.ts":18:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0: Parameters<typeof __puiCaptureReceiver.props.define>[0] = { ["disabled"]: { ["type"]: "boolean", ["empty"]: "fallback" } };
const __puiCaptureResult = __puiCaptureReceiver.props.define(__puiCaptureArg0); __puiAuthored.effect("props", {"op": "define", "specMap": __puiCaptureArg0}); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":21:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = { ["disabled"]: false };
const __puiCaptureResult = __puiCaptureReceiver.props.setDefaults(__puiCaptureArg0); __puiAuthored.effect("props", {"op": "setDefaults", "partial": __puiCaptureArg0}); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":26:9
      const disabled = (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "disabled";
const __puiCaptureArg1 = false;
const __puiCaptureResult = __puiCaptureReceiver.state.bool(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", __puiCaptureResult); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":27:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "disabled";
const __puiCaptureArg1 = disabled;
const __puiCaptureResult = __puiCaptureReceiver.expose.state(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", {"op": "expose.state", "key": __puiCaptureArg0, "handle": __puiCaptureArg1}); __puiAuthored.introduceObserved(__puiCaptureArg1); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":28:3
      (() => {
const __puiCaptureReceiver = accessible;
const __puiCaptureArg0 = "disabled";
const __puiCaptureArg1 = disabled;
const __puiCaptureResult = __puiCaptureReceiver.state(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", {"op": "a11y.state", "key": __puiCaptureArg0, "handle": __puiCaptureArg1, "options": undefined}); __puiAuthored.introduceObserved(__puiCaptureArg1); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":31:9
      const hovered = (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "hovered";
const __puiCaptureArg1 = false;
const __puiCaptureResult = __puiCaptureReceiver.state.bool(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", __puiCaptureResult); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":32:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "hovered";
const __puiCaptureArg1 = hovered;
const __puiCaptureResult = __puiCaptureReceiver.expose.state(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", {"op": "expose.state", "key": __puiCaptureArg0, "handle": __puiCaptureArg1}); __puiAuthored.introduceObserved(__puiCaptureArg1); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":35:9
      const focusable = __puiAuthored.privileged("asFocusable", () => __puiInteraction.asFocusable(), ["focused","focusVisible","focusable"]);
      // Source "packages/prototypes/base/src/button/button.proto.ts":36:3
      focusable.configure({ ["disabled"]: false });
      // Source "packages/prototypes/base/src/button/button.proto.ts":38:9
      const focused = (focusable)["focused"];
      // Source "packages/prototypes/base/src/button/button.proto.ts":39:9
      const focusVisible = (focusable)["focusVisible"];
      // Source "packages/prototypes/base/src/button/button.proto.ts":42:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "focused";
const __puiCaptureArg1 = focused;
const __puiCaptureResult = __puiCaptureReceiver.expose.state(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", {"op": "expose.state", "key": __puiCaptureArg0, "handle": __puiCaptureArg1}); __puiAuthored.introduceObserved(__puiCaptureArg1); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":43:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "focusVisible";
const __puiCaptureArg1 = focusVisible;
const __puiCaptureResult = __puiCaptureReceiver.expose.state(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", {"op": "expose.state", "key": __puiCaptureArg0, "handle": __puiCaptureArg1}); __puiAuthored.introduceObserved(__puiCaptureArg1); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":46:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "focusSelf";
const __puiCaptureArg1 = (options?: { "reason"?: "programmatic" | "keyboard" | "pointer"; "preventScroll"?: boolean }): void => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":47:5
        if ((disabled.get() as boolean)) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":47:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":48:5
        focusable.focusSelf(options);
      };
const __puiCaptureResult = __puiCaptureReceiver.expose.method(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("context", {"op": "expose.method", "key": __puiCaptureArg0, "fn": __puiCaptureArg1}); __puiAuthored.method(__puiCaptureArg0, __puiCaptureArg1); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":52:9
      const pressed = (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "pressed";
const __puiCaptureArg1 = false;
const __puiCaptureResult = __puiCaptureReceiver.state.bool(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", __puiCaptureResult); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":53:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "pressed";
const __puiCaptureArg1 = pressed;
const __puiCaptureResult = __puiCaptureReceiver.expose.state(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("state", {"op": "expose.state", "key": __puiCaptureArg0, "handle": __puiCaptureArg1}); __puiAuthored.introduceObserved(__puiCaptureArg1); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":55:9
      const clearTransientInteraction = (reason: string): void => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":56:5
        hovered.set(false, reason);
        // Source "packages/prototypes/base/src/button/button.proto.ts":57:5
        pressed.set(false, reason);
      };
      // Source "packages/prototypes/base/src/button/button.proto.ts":61:3
      def.lifecycle.onUnmounted(() => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":62:5
        (clearTransientInteraction)("reason: button view unmounted => reset transient interaction");
      });
      // Source "packages/prototypes/base/src/button/button.proto.ts":66:9
      const syncDisabled = (nextDisabled: boolean): void => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":67:5
        disabled.set(nextDisabled, "reason: sync disabled");
        // Source "packages/prototypes/base/src/button/button.proto.ts":68:5
        focusable.setDisabled(nextDisabled);
        // Source "packages/prototypes/base/src/button/button.proto.ts":69:5
        if (nextDisabled) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":70:7
          (clearTransientInteraction)("reason: button disabled => reset transient interaction");
        }
      };
      // Source "packages/prototypes/base/src/button/button.proto.ts":73:3
      def.lifecycle.onCreated((run: __puiRun) => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":74:5
        (syncDisabled)((run.props.get())["disabled"]);
      });
      // Source "packages/prototypes/base/src/button/button.proto.ts":76:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = ["disabled"];
const __puiCaptureArg1 = (_run: __puiRun, next: __puiResolvedProps) => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":77:5
        (syncDisabled)((next)["disabled"]);
      };
const __puiCaptureResult = __puiCaptureReceiver.props.watch(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("props", {"op": "watch", "keys": __puiCaptureArg0, "off": __puiCaptureResult}); __puiAuthored.disposer("props", __puiCaptureResult); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":81:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "click";
const __puiCaptureArg1: Parameters<typeof __puiCaptureReceiver.expose.event>[1] = { ["payload"]: "void" };
const __puiCaptureResult = __puiCaptureReceiver.expose.event(__puiCaptureArg0, __puiCaptureArg1); __puiAuthored.effect("event", {"op": "expose.event", "key": __puiCaptureArg0, "spec": __puiCaptureArg1}); __puiAuthored.eventKey(__puiCaptureArg0); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":83:3
      accessible.action("activate", { ["event"]: "click" });
      // Source "packages/prototypes/base/src/button/button.proto.ts":86:3
      accessible.role("button");
      // Source "packages/prototypes/base/src/button/button.proto.ts":89:3
      accessible.nameFromContent();
      // Source "packages/prototypes/base/src/button/button.proto.ts":91:9
      const activate = (run: __puiRun, isCurrent: () => boolean = (): boolean => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":91:83
        return true;
      }): void => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":92:5
        if (((disabled.get() as boolean) || (!(isCurrent)()))) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":92:41
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":93:5
        pressed.set(false, "reason: button activation => pressed");
        // Source "packages/prototypes/base/src/button/button.proto.ts":94:5
        if (((disabled.get() as boolean) || (!(isCurrent)()))) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":94:41
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":95:5
        run.expose.emit("click");
      };
      // Source "packages/prototypes/base/src/button/button.proto.ts":97:3
      __puiAuthored.privileged("asControlLabel", () => __puiInteraction.asControlLabel()).target((run: __puiRun, request: __puiNativeModuleCapability<"control-label-request", __puiRun>) => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":98:11
        const isCurrent = (): boolean => {
          // Source "packages/prototypes/base/src/button/button.proto.ts":98:29
          return ((!(disabled.get() as boolean)) && request.isCurrent());
        };
        // Source "packages/prototypes/base/src/button/button.proto.ts":99:5
        if ((!(isCurrent)())) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":99:23
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":100:5
        focusable.focusSelf({ ["reason"]: (((request)["source"] === "pointer") ? "pointer" : "programmatic") });
        // Source "packages/prototypes/base/src/button/button.proto.ts":101:5
        if ((isCurrent)()) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":101:22
          (activate)(run, isCurrent);
        }
      });
      // Source "packages/prototypes/base/src/button/button.proto.ts":107:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "key.down";
const __puiCaptureArg1 = (_run: __puiRun, ev: __puiNativeInput) => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":108:11
        const detail = ev;
        // Source "packages/prototypes/base/src/button/button.proto.ts":109:5
        if ((disabled.get() as boolean)) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":109:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":110:5
        if ((!(focused.get() as boolean))) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":110:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":111:5
        if (((detail)?.["key"] !== " ")) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":111:30
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":112:5
        ev.control.requestDefaultActionPrevention({ ["reason"]: "button.space-activation", ["source"]: "base-button" });
      };
const __puiCaptureResult = __puiCaptureReceiver.event.onGlobal(__puiCaptureArg0, __puiCaptureArg1); const __puiCaptureOff = () => __puiInteraction.releaseListener(__puiCaptureResult); __puiAuthored.effect("event", {token: __puiCaptureResult, off: __puiCaptureOff}); __puiAuthored.disposer("event", __puiCaptureOff); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":119:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "pointer.enter";
const __puiCaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":120:5
        if ((disabled.get() as boolean)) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":120:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":121:5
        hovered.set(true, "reason: button pointer.enter => hovered");
      };
const __puiCaptureResult = __puiCaptureReceiver.event.on(__puiCaptureArg0, __puiCaptureArg1); const __puiCaptureOff = () => __puiInteraction.releaseListener(__puiCaptureResult); __puiAuthored.effect("event", {token: __puiCaptureResult, off: __puiCaptureOff}); __puiAuthored.disposer("event", __puiCaptureOff); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":123:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "pointer.leave";
const __puiCaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":124:5
        hovered.set(false, "reason: button pointer.leave => hovered");
        // Source "packages/prototypes/base/src/button/button.proto.ts":125:5
        pressed.set(false, "reason: button pointer.leave => pressed");
      };
const __puiCaptureResult = __puiCaptureReceiver.event.on(__puiCaptureArg0, __puiCaptureArg1); const __puiCaptureOff = () => __puiInteraction.releaseListener(__puiCaptureResult); __puiAuthored.effect("event", {token: __puiCaptureResult, off: __puiCaptureOff}); __puiAuthored.disposer("event", __puiCaptureOff); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":127:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "pointer.cancel";
const __puiCaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":128:5
        hovered.set(false, "reason: button pointer.cancel => hovered");
        // Source "packages/prototypes/base/src/button/button.proto.ts":129:5
        pressed.set(false, "reason: button pointer.cancel => pressed");
      };
const __puiCaptureResult = __puiCaptureReceiver.event.on(__puiCaptureArg0, __puiCaptureArg1); const __puiCaptureOff = () => __puiInteraction.releaseListener(__puiCaptureResult); __puiAuthored.effect("event", {token: __puiCaptureResult, off: __puiCaptureOff}); __puiAuthored.disposer("event", __puiCaptureOff); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":132:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "press.cancel";
const __puiCaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":133:5
        (clearTransientInteraction)("reason: button press.cancel => reset transient interaction");
      };
const __puiCaptureResult = __puiCaptureReceiver.event.on(__puiCaptureArg0, __puiCaptureArg1); const __puiCaptureOff = () => __puiInteraction.releaseListener(__puiCaptureResult); __puiAuthored.effect("event", {token: __puiCaptureResult, off: __puiCaptureOff}); __puiAuthored.disposer("event", __puiCaptureOff); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":137:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "pointer.down";
const __puiCaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":138:5
        if ((disabled.get() as boolean)) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":138:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":139:5
        pressed.set(true, "reason: button pointer.down => pressed");
      };
const __puiCaptureResult = __puiCaptureReceiver.event.on(__puiCaptureArg0, __puiCaptureArg1); const __puiCaptureOff = () => __puiInteraction.releaseListener(__puiCaptureResult); __puiAuthored.effect("event", {token: __puiCaptureResult, off: __puiCaptureOff}); __puiAuthored.disposer("event", __puiCaptureOff); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":141:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "pointer.up";
const __puiCaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":142:5
        pressed.set(false, "reason: button pointer.up => pressed");
      };
const __puiCaptureResult = __puiCaptureReceiver.event.on(__puiCaptureArg0, __puiCaptureArg1); const __puiCaptureOff = () => __puiInteraction.releaseListener(__puiCaptureResult); __puiAuthored.effect("event", {token: __puiCaptureResult, off: __puiCaptureOff}); __puiAuthored.disposer("event", __puiCaptureOff); return __puiCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":146:3
      (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = "press.commit";
const __puiCaptureArg1 = (run: __puiRun) => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":147:5
        pressed.set(false, "reason: button press.commit => pressed");
        // Source "packages/prototypes/base/src/button/button.proto.ts":148:5
        (activate)(run);
      };
const __puiCaptureResult = __puiCaptureReceiver.event.on(__puiCaptureArg0, __puiCaptureArg1); const __puiCaptureOff = () => __puiInteraction.releaseListener(__puiCaptureResult); __puiAuthored.effect("event", {token: __puiCaptureResult, off: __puiCaptureOff}); __puiAuthored.disposer("event", __puiCaptureOff); return __puiCaptureResult; })();
    })(__puiDef)}, options) as { readonly stateHandles?: Readonly<Record<string, unknown>>; readonly getState?: (name: string) => unknown; readonly getMethod?: (name: string) => unknown; readonly getAsHook?: (name: string) => unknown; readonly getAsHookHandle?: (name: string) => unknown; readonly render?: unknown });
  let render: (renderer: typeof __puiRenderer) => unknown;
  try {
    render = ((def: typeof __puiDef) => {
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":77:5
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0: Parameters<typeof __puiCaptureReceiver.props.define>[0] = { ["variant"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["solid", "surface", "destructive"] }, ["color"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["main", "mint", "lavender", "coral", "sky"] }, ["size"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["default", "sm", "lg", "icon"] }, ["wrap"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["disabled"]: { ["type"]: "boolean", ["empty"]: "fallback" } };
const __puiCaptureResult = __puiCaptureReceiver.props.define(__puiCaptureArg0); __puiAuthored.effect("props", {"op": "define", "specMap": __puiCaptureArg0}); return __puiCaptureResult; })();
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":94:5
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = { ["variant"]: "solid", ["color"]: "main", ["size"]: "default", ["wrap"]: false, ["disabled"]: false };
const __puiCaptureResult = __puiCaptureReceiver.props.setDefaults(__puiCaptureArg0); __puiAuthored.effect("props", {"op": "setDefaults", "partial": __puiCaptureArg0}); return __puiCaptureResult; })();
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":103:11
    const buttonState = ((__puiHook0())["stateHandles"] as { readonly "disabled": __puiState<boolean> & { watch(callback: (run: __puiRun, event: __puiStateEvent<boolean>) => void): () => void }; readonly "hovered": __puiState<boolean> & { watch(callback: (run: __puiRun, event: __puiStateEvent<boolean>) => void): () => void }; readonly "focused": __puiNativeObservedState<boolean>; readonly "focusVisible": __puiNativeObservedState<boolean>; readonly "pressed": __puiState<boolean> & { watch(callback: (run: __puiRun, event: __puiStateEvent<boolean>) => void): () => void } });
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":104:5
    if ((!buttonState)) {
      // Source "packages/prototypes/brutalist/src/button/button.proto.ts":105:7
      throw new Error("[brutalist-button] asButton must project Button state handles.");
    }
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":107:13
    const disabled = (buttonState)["disabled"];
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":107:23
    const hovered = (buttonState)["hovered"];
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":107:32
    const focusVisible = (buttonState)["focusVisible"];
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":107:46
    const pressed = (buttonState)["pressed"];
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":109:5
    (() => {
const __puiCaptureReceiver = def;
const __puiCaptureArg0 = ({"kind":"tw","tokens":["group/brutalist-button","inline-flex","shrink-0","items-center","justify-center","gap-2","font-sans","font-medium","rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium"],"groups":["group/brutalist-button","display","shrink-0","items-","justify-","gap-2","font-sans","font weight","rounded","border-width","border-color","shadow-","font-sans","font weight"]} as const);
const __puiCaptureResult = __puiCaptureReceiver.feedback.style.use(__puiCaptureArg0); __puiAuthored.effect("feedback", __puiCaptureResult); __puiAuthored.disposer("feedback", __puiCaptureResult); return __puiCaptureResult; })();
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":114:5
    __puiAuthored.rule(__puiStyle.rule(() => (__puiStyle.meta("preference.reducedMotion") === "no-preference"), [({"kind":"tw","tokens":["transition-all"],"groups":["transition-"]} as const)], ["preference.reducedMotion"]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":118:5
    __puiAuthored.rule(__puiStyle.rule(() => !((__puiStyle.meta("preference.reducedMotion") === "no-preference")), [({"kind":"tw","tokens":["transition-none"],"groups":["transition-"]} as const)], ["preference.reducedMotion"]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
    __puiAuthored.rule(__puiStyle.rule(() => ((resolved["variant"] === "solid") && (resolved["color"] === "main")), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-main","text-main-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
    __puiAuthored.rule(__puiStyle.rule(() => ((resolved["variant"] === "solid") && (resolved["color"] === "mint")), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-mint","text-mint-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
    __puiAuthored.rule(__puiStyle.rule(() => ((resolved["variant"] === "solid") && (resolved["color"] === "lavender")), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-lavender","text-lavender-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
    __puiAuthored.rule(__puiStyle.rule(() => ((resolved["variant"] === "solid") && (resolved["color"] === "coral")), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-coral","text-coral-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
    __puiAuthored.rule(__puiStyle.rule(() => ((resolved["variant"] === "solid") && (resolved["color"] === "sky")), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-sky","text-sky-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":134:9
    __puiAuthored.rule(__puiStyle.rule(() => (resolved["variant"] === "surface"), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-secondary-background","text-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":134:9
    __puiAuthored.rule(__puiStyle.rule(() => (resolved["variant"] === "destructive"), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-destructive","text-destructive-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":143:7
    (false ? __puiAuthored.rule(__puiStyle.rule(() => (resolved["size"] === "default"), [({"kind":"tw","tokens":["h-10","px-4","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]} as const)])) : __puiAuthored.rule(__puiStyle.rule(() => ((resolved["size"] === "default") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-10","px-4","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]} as const)])));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":143:7
    (false ? __puiAuthored.rule(__puiStyle.rule(() => (resolved["size"] === "sm"), [({"kind":"tw","tokens":["h-9","px-3","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]} as const)])) : __puiAuthored.rule(__puiStyle.rule(() => ((resolved["size"] === "sm") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-9","px-3","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]} as const)])));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":143:7
    (false ? __puiAuthored.rule(__puiStyle.rule(() => (resolved["size"] === "lg"), [({"kind":"tw","tokens":["h-11","px-8","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]} as const)])) : __puiAuthored.rule(__puiStyle.rule(() => ((resolved["size"] === "lg") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["h-11","px-8","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]} as const)])));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":143:7
    (true ? __puiAuthored.rule(__puiStyle.rule(() => (resolved["size"] === "icon"), [({"kind":"tw","tokens":["size-10","whitespace-nowrap"],"groups":["size-10","whitespace-nowrap"]} as const)])) : __puiAuthored.rule(__puiStyle.rule(() => ((resolved["size"] === "icon") && (resolved["wrap"] === false)), [({"kind":"tw","tokens":["size-10","whitespace-nowrap"],"groups":["size-10","whitespace-nowrap"]} as const)])));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":154:7
    __puiAuthored.rule(__puiStyle.rule(() => ((resolved["size"] === "default") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-10","h-auto","px-4","py-1","text-sm","whitespace-normal","min-w-0","max-w-full","wrap-anywhere","text-center"],"groups":["min-h-","h-","px-","py-","text-size","whitespace-normal","min-w-","max-w-","wrap-anywhere","text-align"]} as const)]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":154:7
    __puiAuthored.rule(__puiStyle.rule(() => ((resolved["size"] === "sm") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-9","h-auto","px-3","py-1","text-sm","whitespace-normal","min-w-0","max-w-full","wrap-anywhere","text-center"],"groups":["min-h-","h-","px-","py-","text-size","whitespace-normal","min-w-","max-w-","wrap-anywhere","text-align"]} as const)]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":154:7
    __puiAuthored.rule(__puiStyle.rule(() => ((resolved["size"] === "lg") && (resolved["wrap"] === true)), [({"kind":"tw","tokens":["min-h-11","h-auto","px-8","py-1","text-sm","whitespace-normal","min-w-0","max-w-full","wrap-anywhere","text-center"],"groups":["min-h-","h-","px-","py-","text-size","whitespace-normal","min-w-","max-w-","wrap-anywhere","text-align"]} as const)]));
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":161:5
    __puiAuthored.rule((() => { const __puiRuleState0 = hovered; return __puiStyle.rule(() => (__puiRuleState0.get() === true), [({"kind":"tw","tokens":["translate-x-1","translate-y-1","shadow-none","relative","hit-envelope-translate-1"],"groups":["translate-x-","translate-y-","shadow-","relative","hit-envelope-translate-1"]} as const)]); })());
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":167:5
    __puiAuthored.rule((() => { const __puiRuleState0 = pressed; return __puiStyle.rule(() => (__puiRuleState0.get() === true), [({"kind":"tw","tokens":["translate-x-1","translate-y-1","shadow-none","relative","hit-envelope-translate-1"],"groups":["translate-x-","translate-y-","shadow-","relative","hit-envelope-translate-1"]} as const)]); })());
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":173:5
    __puiAuthored.rule((() => { const __puiRuleState0 = focusVisible; return __puiStyle.rule(() => (__puiRuleState0.get() === true), [({"kind":"tw","tokens":["outline-none","ring-2","ring-ring","ring-offset-2","ring-offset-background"],"groups":["outline-none","ring-2","ring-ring","ring-offset-2","ring-offset-background"]} as const)]); })());
    // Source "packages/prototypes/brutalist/src/button/button.proto.ts":178:5
    __puiAuthored.rule((() => { const __puiRuleState0 = disabled; return __puiStyle.rule(() => (__puiRuleState0.get() === true), [({"kind":"tw","tokens":["pointer-events-none","opacity-50"],"groups":["pointer-events-none","opacity-"]} as const)]); })());
  })(__puiDef) ?? (() => __puiRenderer.slot());
    if (typeof render !== 'function') throw new Error('[Prototype] setup must return a render function or void.');
  } catch (error) { try { disposeNow(false, false); } catch {} throw error; }
  phase = 'idle';
  function applyProps(nextHost: GeneratedComponentProps) {
    ensureAlive();
    hostProps = nextHost;
    __puiInteraction.refresh();
    const nextRaw: Record<string, unknown> = Object.create(null);
    for (const [key, value] of Object.entries(nextHost)) {
      if (key === 'children' || key === 'instanceAssociations' || key === 'hostRef' || key === 'hostProps' || !Object.hasOwn(specs, key) && (['class', 'className', 'hostClass', 'surfaceClass', 'style', 'hostStyle', 'surfaceStyle'].includes(key) || /^on[A-Z]/.test(key) && typeof value === 'function')) continue;
      nextRaw[key] = value;
    }
    if (hydrated && Object.keys(raw).length === Object.keys(nextRaw).length
      && Object.keys(nextRaw).every((key) => Object.hasOwn(raw, key) && Object.is(raw[key], nextRaw[key]))) return false;
    const previous = resolved;
    const previousRaw = raw;
    raw = Object.freeze(nextRaw);
    resolved = __puiResolveProps(specs, defaults, previousValid, raw, true);
    __puiStyle.refresh();
    __puiInteraction.refresh();
    if (!hydrated) { hydrated = true; return false; }
    const nextResolved = resolved, nextRawSnapshot = raw;
    invoke(() => {
      const previousWindow = propsWindow;
      propsWindow = { raw: nextRawSnapshot, resolved: nextResolved };
      try {
      if (rawAllWatchers.length || rawWatchers.length) {
        const changedRaw = [...new Set([...Object.keys(previousRaw), ...Object.keys(nextRawSnapshot)])].filter(key => !Object.is(previousRaw[key], nextRawSnapshot[key]));
        if (changedRaw.length) for (let groupIndex = 0; groupIndex < 2; ++groupIndex) for (const watcher of groupIndex === 0 ? rawAllWatchers : rawWatchers) {
          if (!watcher.active) continue;
          const changedKeysMatched = watcher.keys ? watcher.keys.filter(key => changedRaw.includes(key)) : changedRaw;
          if (!changedKeysMatched.length) continue;
          console.warn('[Props] raw watchers are an adapter-snapshot escape hatch; avoid in official prototypes.');
          watcher.callback(__puiRunHandle, nextRawSnapshot, previousRaw, { changedKeysAll: changedRaw, changedKeysMatched });
        }
      }
      const changedKeysAll = Object.keys(specs).filter((key) => !Object.is(previous[key as keyof GeneratedProps], nextResolved[key as keyof GeneratedProps]));
      for (const watcher of watchers) {
        if (!watcher.active) continue;
        const changedKeysMatched = watcher.keys ? watcher.keys.filter((key) => changedKeysAll.includes(key)) : changedKeysAll;
        if (changedKeysMatched.length) watcher.callback(__puiRunHandle, nextResolved, previous, { changedKeysAll, changedKeysMatched });
      }
      } finally { propsWindow = previousWindow; }
    });
    return true;
  }
  const handle: GeneratedHandle = Object.freeze({
    update() { ensureExternal(); invoke(() => __puiRunHandle.update()); },
    getElement() { return lifetime === 'alive' && connected ? root : null; },
    getExposes() { ensureExternal(); return { ...exposes } as GeneratedExposes; },
    invokeInCallbackScope<T>(callback: () => T): T { ensureExternal(); return invoke(callback); },
  });
  function disposeNow(exhaustive = false, authored = true) {
    if (lifetime !== 'alive') return;
    lifetime = 'disposing'; connected = false; ++cleanupVersion; ++rootGeneration; phase = 'callback';
    __puiCompleteSteps([
      ...authorStateWatchCleanups.splice(0),
      () => detachView(),
      () => {
        if (!authored) return;
        if (exhaustive) __puiCompleteSteps(callbacks.beforeDispose.map(callback => () => invoke(() => callback(__puiRunHandle))));
        else dispatch(callbacks.beforeDispose);
      },
      () => disposeInteraction(),
      () => root?.removeAttribute('data-pui-style'),
      () => __puiStyle.dispose(),
      () => context.dispose(),
      () => __puiAuthored.dispose(),
      () => {
        root = null; lifetime = 'disposed'; phase = 'idle';
        for (const subscribers of stateSubscribers) subscribers.clear();
        pendingStateEvents.length = 0; watchers.length = 0; rawWatchers.length = 0; rawAllWatchers.length = 0;
        for (const list of Object.values(callbacks)) list.length = 0;
        for (const key of Object.keys(exposes)) delete exposes[key];
      },
    ]);
  }
  return {
    handle,
    scope: context,
    getHostProjection() { return { tag: __puiInteraction.rootTag() ?? "div", properties: __puiInteraction.rootProperties(), portalTarget: __puiInteraction.portalTarget() }; },

    bindRoot(nextRoot) {
      if (lifetime !== 'alive') return;
      if (rootBinding) {
        if (rootBinding === 'binding' && root === nextRoot && !pendingRoot) return;
        pendingRoot = { value: nextRoot }; ++rootGeneration;
        return;
      }
      if (root === nextRoot) return;
      let next = nextRoot;
      let failure: { error: unknown } | undefined;
      try {
        for (;;) {
          // Cleanup owns the previous Root and all of its reached resources.
          // Reentrant requests coalesce until that complete transaction returns.
          rootBinding = 'retiring'; ++rootGeneration;
          const previousRoot = root;
          try { __puiCompleteSteps([
            () => __puiInteraction.unmount(),
            () => previousRoot?.removeAttribute('data-pui-style'),
          ]); } catch (error) { failure ??= { error }; }
          if (lifetime !== 'alive') break;
          const replacement = consumePendingRoot();
          if (replacement) next = replacement.value;
          root = next; rootBinding = 'binding';
          const generation = ++rootGeneration;
          const current = () => generation === rootGeneration && lifetime === 'alive';
          try { __puiCompleteSteps([
            () => { if (current() && mounted) projectStyle(__puiStyle.tokens()); },
            () => { if (current() && mounted && desiredPresent && viewConnected) __puiInteraction.mount(); },
          ]); } catch (error) { failure ??= { error }; }
          const queued = consumePendingRoot();
          if (lifetime !== 'alive' || !queued) break;
          next = queued.value;
        }
      } finally { rootBinding = null; pendingRoot = undefined; }
      if (failure) throw failure.error;
    },
    connect() { connected = true; ++cleanupVersion; },
    connectView() {
      viewConnected = true;
      if (mounted && desiredPresent) __puiInteraction.mount();
    },
    disconnectView() { viewConnected = false; __puiInteraction.unmount(); },
    commitHost() { if (connected && mounted && viewConnected && desiredPresent && lifetime === 'alive') __puiInteraction.commitHost(); },
    start() {
      try {
        applyProps(initial); dispatch(callbacks.created);
        schedule();
      }
      catch (error) { try { disposeNow(true); } catch {} throw error; }
    },
    applyProps,
    accept(frame: __puiFrame) {
      if (!connected || lifetime !== 'alive' || frame.revision <= acceptedRevision || frame !== latest) return false;
      acceptedRevision = frame.revision;
      if (frame.kind === 'detach') {
        try { detachView(); } finally { schedule(); }
      } else if (!desiredPresent) {
        // Physical materialization is not a published mount. Remove the obsolete
        // Root without manufacturing mounted/unmounted for a never-mounted epoch.
        schedule();
        return false;
      } else if (frame.kind === 'mount') {
        mounted = true;

        // The published mount may predate an explicit update intent. Only
        // after its acknowledgement may that dirty intent enter update flow.
        if (dirty) updateQueued = true;
        __puiStyle.mount();
        
        __puiInteraction.mount();
        dispatch(callbacks.mounted);
      } else if (mounted && frame.epoch === epoch) {   dispatch(callbacks.updated); }
      schedule();
      return true;
    },
    disconnect() {
      connected = false;
      const version = ++cleanupVersion;
      queueMicrotask(() => {
        if (connected || cleanupVersion !== version || lifetime !== 'alive') return;
        disposeNow();
      });
    },
  };
}


export const BrutalistButton = __puiReact.forwardRef<GeneratedHandle, GeneratedComponentProps>(function BrutalistButton(props, ref) {
  const ownerRef = __puiReact.useRef<__puiOwner | null>(null);
  const parentScope = __puiReact.useContext(__puiContextTransport);
  const parentRef = __puiReact.useRef<__puiContextScope | null>(null);
  const [frame, setFrame] = __puiReact.useState<__puiFrame | null>(null);
  const [, publishHost] = __puiReact.useReducer((version: number) => version + 1, 0);
  const rootRef = __puiReact.useRef<HTMLElement | null>(null);

  const pendingHostRef = __puiReact.useRef(props.hostRef);
  pendingHostRef.current = props.hostRef;
  const boundHostRef = __puiReact.useRef<__puiReact.Ref<HTMLElement> | undefined>(undefined);
  const bindRoot = __puiReact.useCallback((root: HTMLElement | null) => {
    if (boundHostRef.current !== pendingHostRef.current) __puiAssignHostRef(boundHostRef.current, null);
    boundHostRef.current = pendingHostRef.current;
    rootRef.current = root;
    ownerRef.current?.bindRoot(root);
    __puiAssignHostRef(boundHostRef.current, root);
  }, []);
  __puiReact.useLayoutEffect(() => {
    if (boundHostRef.current === props.hostRef) return;
    __puiAssignHostRef(boundHostRef.current, null);
    boundHostRef.current = props.hostRef;
    __puiAssignHostRef(boundHostRef.current, rootRef.current);
  }, [props.hostRef]);
  // All irreversible work begins after an accepted shell commit, never during React render.
  __puiReact.useLayoutEffect(() => {
    parentRef.current = parentScope;
    let owner = ownerRef.current;
    if (!owner) {
      owner = __puiCreateOwner(props, setFrame, () => parentRef.current, publishHost);
      ownerRef.current = owner;
      owner.start();

    } else owner.connect();
    owner.connectView();
    return () => { owner.disconnectView(); };
  }, []);
  __puiReact.useLayoutEffect(() => { parentRef.current = parentScope; }, [parentScope]);
  // Suspense can disconnect layout effects without unmounting the owner shell.
  // Passive cleanup identifies shell unmount; same-turn StrictMode replay cancels disposal.
  __puiReact.useEffect(() => {
    const owner = ownerRef.current;
    if (!owner) return;
    owner.connect();
    return () => { owner.disconnect(); };
  }, []);
  __puiReact.useLayoutEffect(() => { const owner = ownerRef.current; owner?.applyProps(props); }, [props]);
  __puiReact.useLayoutEffect(() => { if (frame) ownerRef.current!.accept(frame); }, [frame]);
  __puiReact.useLayoutEffect(() => { ownerRef.current?.commitHost(); });

  __puiReact.useImperativeHandle(ref, () => ownerRef.current!.handle, []);
  const template = __puiReact.useMemo(() => __puiBindSlots(frame?.node, props.children), [frame?.node, props.children]);
  const host = ownerRef.current?.getHostProjection();
  const rootView = frame && frame.kind !== 'detach'
    ? __puiRenderRoot(host!.tag, { ...__puiHostProperties(props), ...__puiRootProperties(host!.properties), 'data-pui-root': '', ref: bindRoot }, template) : null;
  const view = rootView && host?.portalTarget ? __puiCreatePortal(rootView, host.portalTarget) : rootView;
  return __puiReact.createElement(__puiContextTransport.Provider, { value: ownerRef.current?.scope ?? null }, view);

});
BrutalistButton.displayName = "brutalist-button";

//# sourceMappingURL=BrutalistButton.tsx.map
