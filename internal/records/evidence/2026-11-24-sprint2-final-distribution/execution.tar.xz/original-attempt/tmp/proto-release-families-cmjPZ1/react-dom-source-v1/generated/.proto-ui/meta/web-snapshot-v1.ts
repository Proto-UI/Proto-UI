/** Sample native inputs without installing an observer or claiming rendering fidelity. */
export function readNativeWebMeta(doc: Document | undefined, key: string): unknown {
  const view = doc?.defaultView;
  const media = (query: string) => { try { return typeof view?.matchMedia === 'function' ? view.matchMedia(query).matches : false; } catch { return false; } };
  if (key === 'reducedMotion') return media('(prefers-reduced-motion: reduce)') ? 'reduce' : 'no-preference';
  if (key === 'colorScheme') {
    const root = doc?.documentElement, theme = root?.dataset.theme;
    if (theme === 'dark' || root?.classList.contains('dark')) return 'dark';
    if (theme === 'light' || root?.classList.contains('light')) return 'light';
    return media('(prefers-color-scheme: dark)') ? 'dark' : 'light';
  }
  const preferences: Record<string, readonly [string, readonly string[]]> = {
    'preference.reducedMotion': ['prefers-reduced-motion', ['no-preference', 'reduce']],
    'preference.reducedTransparency': ['prefers-reduced-transparency', ['no-preference', 'reduce']],
    'preference.contrast': ['prefers-contrast', ['no-preference', 'less', 'more', 'custom']],
    'preference.forcedColors': ['forced-colors', ['none', 'active']],
  };
  if (Object.hasOwn(preferences, key)) {
    const [feature, values] = preferences[key], matches = values.filter(value => media('(' + feature + ': ' + value + ')'));
    return matches.length === 1 ? matches[0] : 'unknown';
  }
  if (key === 'viewport.width') { const width = view?.innerWidth; return typeof width === 'number' && Number.isFinite(width) && width >= 0 ? width : 'unknown'; }
  if (key === 'styleSupport.alphaFill' || key === 'styleSupport.backdropBlur4px') {
    const css = view?.CSS;
    if (typeof css?.supports !== 'function') return 'unknown';
    try { return key === 'styleSupport.alphaFill'
      ? css.supports('background-color', 'color-mix(in oklab, rgb(44 44 46) 80%, transparent)') && css.supports('background-color', 'color-mix(in oklab, var(--pui-secondary) 80%, transparent)')
      : css.supports('backdrop-filter', 'blur(4px)'); } catch { return 'unknown'; }
  }
  return undefined;
}
