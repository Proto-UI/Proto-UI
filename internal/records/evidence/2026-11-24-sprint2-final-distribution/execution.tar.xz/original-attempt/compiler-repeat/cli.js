#!/usr/bin/env node
import { runCompilerCli, compilerBuildIdentity } from './index.js';
if (process.argv.length === 3 && process.argv[2] === '--build-info') console.log(JSON.stringify(compilerBuildIdentity, null, 2));
else process.exitCode = await runCompilerCli(process.argv.slice(2));
