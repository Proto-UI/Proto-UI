import type { RunHandle } from '@proto.ui/core';
import { defineAsHook, definePrototype, type DefHandle, type ExposeMethod } from '@proto.ui/core';
import { asAccessible, asCollectionItem, asFocusable } from '@proto.ui/hooks';
import { setupSelectCommand } from './command';
import {
  notifySelectItemSnapshotChanged,
  recordSelectFocusHandoff,
  requestSelectOpen,
  requestSelectValue,
  SELECT_CONTEXT,
  SELECT_FAMILY,
  type SelectContextValue,
  type SelectFocusReason,
} from './shared';
import type { SelectItemAsHookContract, SelectItemExposes, SelectItemProps } from './types';

function setupSelectItem(def: DefHandle<SelectItemProps, SelectItemExposes>): void {
  const accessible = asAccessible();
  const command = setupSelectCommand(def, 'select item');
  const focusable = asFocusable<SelectItemProps>();
  const active = def.state.bool('active', false);
  const selected = def.state.bool('selected', false);
  const collectionItem = asCollectionItem();
  collectionItem.configure({
    family: SELECT_FAMILY,
    getMeta: (run) => {
      const props = run.props.get();
      return {
        value: props.value ?? '',
        textValue: props.textValue ?? props.value ?? '',
        disabled: !!props.disabled,
      };
    },
  });

  def.props.define({
    disabled: { type: 'boolean', empty: 'fallback' },
    value: { type: 'string', empty: 'fallback' },
    textValue: { type: 'string', empty: 'fallback' },
    closeOnSelect: { type: 'boolean', empty: 'fallback' },
  });
  def.props.setDefaults({ disabled: false, value: '', textValue: '' });

  def.expose.state('active', active);
  def.expose.state('selected', selected);
  def.expose.event('select', { payload: 'json' });
  accessible.role('option');
  accessible.nameFromContent();
  accessible.state('selected', selected);
  accessible.state('disabled', command.disabled);
  accessible.action('activate', { event: 'select' });

  const readContext = (run: RunHandle<SelectItemProps>): SelectContextValue | null => {
    try {
      return run.context.read(SELECT_CONTEXT);
    } catch (error) {
      if ((error as { code?: string })?.code === 'CONTEXT_DISCONNECTED') return null;
      throw error;
    }
  };

  const sync = (run: RunHandle<SelectItemProps>, ctx: SelectContextValue) => {
    const ownValue = run.props.get().value ?? '';
    const nextDisabled = !!run.props.get().disabled || ctx.disabled;
    command.syncDisabled(nextDisabled);
    if (!ctx.open && !ctx.pendingOpen) {
      command.resetInteraction('reason: select popup close => reset item interaction', {
        blur: true,
      });
    }
    const nextSelected = !!ownValue && ownValue === ctx.value;
    const nextActive =
      ctx.open &&
      !nextDisabled &&
      (command.focused.get() || (!!ownValue && ownValue === ctx.activeValue));
    selected.set(nextSelected, 'reason: select item selected sync');
    active.set(nextActive, 'reason: select item active sync');
    command.setRovingStatus({ selected: nextSelected, active: nextActive });
  };

  def.context.subscribe(SELECT_CONTEXT, (run, next) => sync(run, next));
  def.lifecycle.onMounted((run) => {
    const ctx = readContext(run);
    if (ctx) sync(run, ctx);
    notifySelectItemSnapshotChanged(run);
  });
  let disposed = false;
  def.lifecycle.onBeforeDispose(() => {
    disposed = true;
  });
  def.props.watch(['value', 'textValue', 'disabled'], (run) => {
    const nextOwnDisabled = !!run.props.get().disabled;
    // Disabling publishes while old focus ownership remains observable.
    // Re-enabling must restore focus eligibility before admission can focus it.
    if (nextOwnDisabled) notifySelectItemSnapshotChanged(run);
    if (disposed) return;
    const ctx = readContext(run);
    if (ctx) sync(run, ctx);
    if (!nextOwnDisabled && !disposed) notifySelectItemSnapshotChanged(run);
  });

  const updateActiveValue = (run: RunHandle<SelectItemProps>, focused = false) => {
    if (command.disabled.get()) return;
    const ownValue = run.props.get().value ?? '';
    if (!ownValue) return;
    active.set(true, 'reason: select item interaction => active');
    command.setRovingStatus({ active: true, selected: selected.get() });
    run.context.update(SELECT_CONTEXT, (prev: SelectContextValue) => {
      const next = prev.activeValue === ownValue ? prev : { ...prev, activeValue: ownValue };
      return focused ? recordSelectFocusHandoff(next) : next;
    });
  };

  const clearTransientActive = (run: RunHandle<SelectItemProps>, reason: string) => {
    const ctx = readContext(run);
    const ownValue = run.props.get().value ?? '';
    active.set(false, reason);
    command.setRovingStatus({ active: false, selected: selected.get() });
    if (!ctx?.open || !ownValue || ctx.activeValue !== ownValue) return;
    run.context.update(SELECT_CONTEXT, (prev: SelectContextValue) =>
      prev.activeValue === ownValue ? { ...prev, activeValue: '' } : prev
    );
  };

  // This private port shares the Item's expose registry without adding public API.
  const entryFocusDef = def as DefHandle<
    SelectItemProps,
    SelectItemExposes & { __cancelPendingEntryFocus: ExposeMethod<() => void> }
  >;
  entryFocusDef.expose.method('__cancelPendingEntryFocus', () => {
    focusable.blur();
  });

  def.event.on('key.down', (run, ev) => {
    if (ev.key !== 'Tab' || command.disabled.get() || !command.focused.get()) return;
    if (!readContext(run)?.open) return;
    requestSelectOpen(run, { open: false, reason: 'tab', focusReason: 'keyboard' });
  });

  def.event.on('press.commit', (run, ev) => {
    if (command.disabled.get()) return;
    const ctx = readContext(run);
    if (!ctx) return;
    const reason: SelectFocusReason = ev?.key ? 'keyboard' : 'pointer';
    const ownValue = run.props.get().value ?? '';
    const ownTextValue = run.props.get().textValue || ownValue;
    updateActiveValue(run);
    run.expose.emit('select', { value: ownValue, reason });
    requestSelectValue(run, { value: ownValue, textValue: ownTextValue, reason });

    const closeOnSelect = run.props.isProvided('closeOnSelect')
      ? !!run.props.get().closeOnSelect
      : ctx.closeOnSelect;
    if (closeOnSelect) {
      requestSelectOpen(run, { open: false, reason: 'item.select', focusReason: reason });
    }
  });

  command.focused.watch((run, event) => {
    if (event.type !== 'next') return;
    if (event.next) {
      updateActiveValue(run, true);
      return;
    }
    if (!command.hovered.get()) {
      clearTransientActive(run, 'reason: select item blur => clear transient active');
      return;
    }
    const ctx = readContext(run);
    if (ctx) sync(run, ctx);
  });
  def.event.on('pointer.move', (run, ev) => {
    const ctx = readContext(run);
    if (!ctx?.open || ctx.disabled || run.props.get().disabled || command.disabled.get()) return;
    // Only an admitted mouse-hover sample may request the shared Focus owner.
    // Unknown, pen, touch and pressed movement never imply navigation intent.
    if (ev.pointerType !== 'mouse' || ev.pointerButtons !== 'none') return;
    command.focusSelf({ reason: 'pointer', preventScroll: true });
  });
  def.event.on('pointer.leave', (run) => {
    if (command.focused.get()) return;
    clearTransientActive(run, 'reason: select item pointer.leave => clear pointer active');
  });
}

export const asSelectItem = defineAsHook<
  SelectItemProps,
  SelectItemExposes,
  SelectItemAsHookContract
>({
  name: 'as-select-item',
  setup: setupSelectItem,
});

const selectItem = definePrototype({ name: 'base-select-item', setup: setupSelectItem });

export default selectItem;
