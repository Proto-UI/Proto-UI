import type { useOpenState } from '../tools/use-open-state';
import type {
  ObservedStateHandle,
  BorrowedStateHandle,
  AvailableLayoutLength,
  ExposeEvent,
  ExposeMethod,
  ExposeState,
  State,
  Unsubscribe,
} from '@proto.ui/core';
import type { DrawerOpenFocusReason } from './shared';
import type { TransitionExposes, TransitionHandles, TransitionProps } from '../transition/types';

export interface DrawerRootProps {
  open?: boolean;
  defaultOpen?: boolean;
  disabled?: boolean;
  a11yLabel?: string;
}

export type DrawerRootExposes = {
  __admitContent: ExposeMethod<(instanceId: string) => number>;
  __releaseContent: ExposeMethod<(instanceId: string, generation: number) => void>;
  open: ExposeState<boolean>;
  openDrawer: ExposeMethod<(reason?: string) => void>;
  close: ExposeMethod<(reason?: string) => void>;
  toggle: ExposeMethod<(reason?: string) => void>;

  openChange: ExposeEvent<{
    open: boolean;
    reason: string | null;
    focusReason: DrawerOpenFocusReason | null;
  }>;
};

export type DrawerRootStateHandles = {
  open: State<boolean>;
};

/** Open is owned by the authored helper child, not this Root capture frame. */
export type DrawerRootAsHookContract = {
  asHooks: {
    useOpenState: ReturnType<typeof useOpenState>;
  };
};

export interface DrawerTriggerProps {
  disabled?: boolean;
}

export type DrawerTriggerExposes = {
  disabled: ExposeState<boolean>;
  hovered: ExposeState<boolean>;
  focused: ExposeState<boolean>;
  focusVisible: ExposeState<boolean>;
  pressed: ExposeState<boolean>;
  focusSelf: ExposeMethod<(options?: { reason?: 'programmatic' | 'keyboard' | 'pointer' }) => void>;
};

export type DrawerTriggerAsHookContract = {
  state: DrawerCommandStateHandles;
};

export type DrawerCommandStateHandles = {
  disabled: State<boolean>;
  hovered: State<boolean>;
  focused: ObservedStateHandle<boolean, DrawerTriggerProps>;
  focusVisible: ObservedStateHandle<boolean, DrawerTriggerProps>;
  pressed: State<boolean>;
};

export type DrawerMaskProps = TransitionProps & {
  passthrough?: boolean;
};

export type DrawerMaskExposes = TransitionExposes;

export type DrawerMaskStateHandles = {
  open: State<boolean>;
};

export type DrawerMaskAsHookContract = {
  state: DrawerMaskStateHandles;
  asHooks: {
    asTransition: TransitionHandles;
  };
};

export type DrawerMaskHandles = {
  stateHandles: {
    open: BorrowedStateHandle<boolean, DrawerMaskProps>;
  };
  asTransition: TransitionHandles;
};

export type DrawerContentProps = TransitionProps & {
  side?: 'top' | 'right' | 'bottom' | 'left';
  /** Vertical: absent/empty points fit content. Horizontal: absent/empty points use [1]. Explicit points are fractions of the capped full extent. */
  snapPoints?: number[];
  /** Validated on every edge; ignored in fractional mode. */
  minExtent?: AvailableLayoutLength;
  /** Neutral extent cap, shared by sizing, edge attachment and drag. Horizontal default: 20 root-text units. */
  maxExtent?: AvailableLayoutLength;
  snapPoint?: number;
  defaultSnapPoint?: number;
  dragDismissible?: boolean;
  /** Visible fraction below which a completed drag requests close. Default 0.25. */
  dragDismissThreshold?: number;
};

export type DrawerContentExposes = TransitionExposes & {
  open: ExposeState<boolean>;
  snapPoint: ExposeState<number>;
  dragging: ExposeState<boolean>;
  dragProgress: ExposeState<number>;
  offsetPercentage: ExposeState<number>;
  extentValid: ExposeState<boolean>;
  requestSnapPoint: ExposeMethod<(value: number, reason?: string) => void>;
  snapPointChange: ExposeEvent<{ snapPoint: number; reason: string }>;
  __onAxisInput: ExposeMethod<(sample: import('@proto.ui/core').AxisInputSample) => void>;
};

export type DrawerSide = 'top' | 'right' | 'bottom' | 'left';

/** Read-only observation, not a Rule State token. observe is setup-only. */
export interface DrawerAcceptedSideObservation {
  read(): DrawerSide | null;
  observe(listener: (side: DrawerSide | null) => void): Unsubscribe;
}

export type DrawerContentStateHandles = {
  drawerSide: State<string>;
  open: State<boolean>;
  snapPoint: State<number>;
  dragging: State<boolean>;
  dragProgress: State<number>;
  offsetPercentage: State<number>;
  extentValid: State<boolean>;
};

export type DrawerContentAsHookContract = {
  state: DrawerContentStateHandles;
  asHooks: {
    asTransition: TransitionHandles;
  };
};

export type DrawerContentHandles = {
  acceptedSide: DrawerAcceptedSideObservation;
  stateHandles: {
    open: BorrowedStateHandle<boolean, DrawerContentProps>;
    snapPoint: BorrowedStateHandle<number, DrawerContentProps>;
    dragging: BorrowedStateHandle<boolean, DrawerContentProps>;
    dragProgress: BorrowedStateHandle<number, DrawerContentProps>;
    offsetPercentage: BorrowedStateHandle<number, DrawerContentProps>;
    extentValid: BorrowedStateHandle<boolean, DrawerContentProps>;
  };
  asTransition: TransitionHandles;
};

export interface DrawerTitleProps {}

export type DrawerTitleExposes = {};

export type DrawerTitleAsHookContract = {};

export interface DrawerDescriptionProps {}

export type DrawerDescriptionExposes = {};

export type DrawerDescriptionAsHookContract = {};

export interface DrawerCloseProps {
  disabled?: boolean;
}

export type DrawerCloseExposes = {
  disabled: ExposeState<boolean>;
  hovered: ExposeState<boolean>;
  focused: ExposeState<boolean>;
  focusVisible: ExposeState<boolean>;
  pressed: ExposeState<boolean>;
  focusSelf: ExposeMethod<(options?: { reason?: 'programmatic' | 'keyboard' | 'pointer' }) => void>;
};

export type DrawerCloseAsHookContract = {
  state: DrawerCommandStateHandles;
};

export interface DrawerHandleProps {
  disabled?: boolean;
  a11yLabel?: string;
}
export type DrawerHandleExposes = {
  disabled: ExposeState<boolean>;
  focused: ExposeState<boolean>;
  focusVisible: ExposeState<boolean>;
  focusSelf: ExposeMethod<(options?: { reason?: 'programmatic' | 'keyboard' | 'pointer' }) => void>;
};
export type DrawerHandleAsHookContract = {
  state: {
    /** Read-only captured accepted side for optional family presentation. */
    side: State<string>;
    disabled: State<boolean>;
    focused: ObservedStateHandle<boolean, DrawerHandleProps>;
    focusVisible: ObservedStateHandle<boolean, DrawerHandleProps>;
  };
};

export interface DrawerHeaderProps {}
export type DrawerHeaderExposes = {};
export type DrawerHeaderAsHookContract = {};

export interface DrawerFooterProps {}
export type DrawerFooterExposes = {};
export type DrawerFooterAsHookContract = {};
