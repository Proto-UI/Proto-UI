import type {
  ExposeEvent,
  ExposeMethod,
  ExposeState,
  State,
  TextControlSelection,
} from '@proto.ui/core';
export interface InputOtpRootProps {
  value?: string;
  defaultValue?: string;
  length?: number;
  pattern?: 'numeric' | 'alphanumeric';
  disabled?: boolean;
  readOnly?: boolean;
  name?: string;
  ariaLabel?: string;
}
export interface InputOtpInputProps {
  placeholder?: string;
}
export interface InputOtpSlotProps {
  index?: number;
}
export type InputOtpRootExposes = {
  value: ExposeState<string>;
  complete: ExposeState<boolean>;
  disabled: ExposeState<boolean>;
  readOnly: ExposeState<boolean>;
  focused: ExposeState<boolean>;
  resetValue: ExposeMethod<() => boolean>;
  requestValue: ExposeMethod<(value: string) => boolean>;
  clear: ExposeMethod<() => boolean>;
  focusInput: ExposeMethod<() => boolean>;
  __focus: ExposeMethod<(focused: boolean) => void>;
  __selection: ExposeMethod<(selection: TextControlSelection | null, editorValue: string) => void>;
  valueChange: ExposeEvent<{ value: string }>;
  completed: ExposeEvent<{ value: string }>;
};
export type InputOtpRootAsHookContract = {
  state: {
    value: State<string>;
    complete: State<boolean>;
    disabled: State<boolean>;
    readOnly: State<boolean>;
    focused: State<boolean>;
  };
};

export type InputOtpInputExposes = {
  disabled: ExposeState<boolean>;
  focusVisible: ExposeState<boolean>;
  focusSelf: ExposeMethod<() => void>;
  resetValue: ExposeMethod<() => boolean>;
  __implicitSubmitEligible: ExposeMethod<() => boolean>;
  __resetEditor: ExposeMethod<() => boolean>;
};
export type InputOtpControlExposes = InputOtpInputExposes & {
  [K in keyof import('../field').FieldControlBindingStates]: ExposeState<boolean>;
};
export type InputOtpSlotExposes = {
  character: ExposeState<string>;
  active: ExposeState<boolean>;
  filled: ExposeState<boolean>;
};
export type InputOtpSeparatorExposes = {};
