export * from './resizable.proto';
