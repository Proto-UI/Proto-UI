export * from './carousel.proto';
