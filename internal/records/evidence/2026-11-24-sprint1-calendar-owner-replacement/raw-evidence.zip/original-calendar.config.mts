import base from '/workspace/scratch/62ffef219b8e/proto-ui-sprint1/vitest.config.ts';
import { readFileSync } from 'node:fs';
export default {
  ...base,
  plugins: [
    ...(base.plugins ?? []),
    {
      name: 'original-calendar-sync',
      enforce: 'pre',
      transform(code, id) {
        if (id.split('?')[0] !== '/workspace/scratch/62ffef219b8e/proto-ui-sprint1/packages/prototypes/base/src/calendar/calendar.proto.ts') return;
        const original = readFileSync('/workspace/scratch/62ffef219b8e/date-otp-followup/baseline/packages/prototypes/base/src/calendar/calendar.proto.ts', 'utf8');
        return { code: original, map: null };
      },
    },
  ],
};
