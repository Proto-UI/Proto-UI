import { afterEach, describe, expect, it } from 'vitest';
import { AdaptToWebComponent, setElementProps } from '@proto.ui/adapter-web-component';
import { calendarRoot, calendarDay } from '../src/calendar';
import { datePickerRoot, datePickerDay, datePickerValue } from '../src/date-picker';

for (const prototype of [calendarRoot, calendarDay, datePickerRoot, datePickerDay, datePickerValue])
  AdaptToWebComponent(prototype);
const flush = async () => {
  for (let index = 0; index < 30; index++) await Promise.resolve();
};
afterEach(async () => {
  document.body.replaceChildren();
  await flush();
});

async function fixture(kind: 'calendar' | 'date-picker') {
  const root = document.createElement(`base-${kind}-root`) as any;
  setElementProps(root, { value: '2026-10-01', month: '2026-10', open: true });
  const days = ['2026-10-03', '2026-10-04', '2026-10-05'].map((date) => {
    const day = document.createElement(`base-${kind}-day`) as any;
    setElementProps(day, { date });
    root.append(day);
    return day;
  });
  const display = kind === 'date-picker' ? document.createElement('base-date-picker-value') : null;
  if (display) root.append(display);
  document.body.append(root);
  await flush();
  return { root, days, display, api: root.getExposes() };
}

describe.each(['calendar', 'date-picker'] as const)('%s owner replacement', (kind) => {
  it.each(['multiple', 'range'] as const)(
    'retains the new %s selection when a value observer replaces the controlled mode',
    async (mode) => {
      // C-CALENDAR-SELECTION-0001-MODES / CONTROLLED: the supplied prop for
      // the new mode owns its selection; the interrupted old snapshot cannot erase it.
      const f = await fixture(kind);
      let replaced = false;
      const off = f.api.value.subscribe((event: any) => {
        if (event.type !== 'next' || replaced) return;
        replaced = true;
        setElementProps(f.root, {
          mode,
          month: '2026-10',
          open: true,
          ...(mode === 'multiple'
            ? { values: ['2026-10-03', '2026-10-05'] }
            : { range: { from: '2026-10-03', to: '2026-10-05' } }),
        });
      });
      try {
        setElementProps(f.root, { value: '2026-10-02', month: '2026-10', open: true });
        await flush();
        expect(replaced).toBe(true);
        expect(f.api.mode.get()).toBe(mode);
        if (mode === 'multiple') {
          expect(f.api.getValues()).toEqual(['2026-10-03', '2026-10-05']);
          expect(f.api.selectedCount.get()).toBe(2);
          expect(f.days.map((day) => day.getExposes().selected.get())).toEqual([true, false, true]);
        } else {
          expect(f.api.getRange()).toEqual({ from: '2026-10-03', to: '2026-10-05' });
          expect(f.api.rangeComplete.get()).toBe(true);
          expect(f.days.map((day) => day.getExposes().selected.get())).toEqual([true, true, true]);
          expect(f.days[1].getExposes().rangeMiddle.get()).toBe(true);
        }
        if (kind === 'date-picker') {
          expect(f.api.open.get()).toBe(true);
          expect(f.display?.textContent).toBe(
            mode === 'multiple' ? '2026-10-03, 2026-10-05' : '2026-10-03 – 2026-10-05'
          );
        }
      } finally {
        off();
      }
    }
  );
});
