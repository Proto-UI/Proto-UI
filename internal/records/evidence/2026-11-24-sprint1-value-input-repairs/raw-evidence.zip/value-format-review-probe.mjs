// Run from the Proto-UI repository root:
// node --import tsx --input-type=module < /path/to/value-format-review-probe.mjs
import { createNumberFieldFormat } from './packages/prototypes/base/src/number-field/format.ts';
const failures = [];
let checked = 0;
for (const locale of ['de-AT', 'fr-CH', 'en-CH', 'bn-BD', 'hi-IN', 'mr-IN', 'en-IN', 'ar-EG', 'fa-IR', 'ar-BH-u-nu-latn', 'zh-CN-u-nu-hanidec', 'ja-JP']) {
  for (const options of [
    { style: 'decimal', maximumFractionDigits: 4 },
    { style: 'percent', maximumFractionDigits: 4 },
    { style: 'currency', currency: 'EUR', maximumFractionDigits: 4 },
    { style: 'currency', currency: 'EUR', currencyDisplay: 'name', maximumFractionDigits: 4 },
    { style: 'currency', currency: 'EUR', currencySign: 'accounting', maximumFractionDigits: 4 },
  ]) {
    const format = createNumberFieldFormat(locale, options);
    for (const value of [0, 1, -1, 12.25, -1234.5, 1234567.75]) {
      checked++;
      const displayed = format.format(value), result = format.parse(displayed);
      if (format.invalid || result.kind !== 'number' || result.value !== value)
        failures.push({ locale, options, value, displayed, result, invalid: format.invalid });
    }
  }
}
process.stdout.write(JSON.stringify({
  scope: 'Independent locale roundtrip probe of actual product formatter; no browser/AT claim',
  checked,
  failures,
}, null, 2) + '\n');
if (failures.length) process.exitCode = 1;
