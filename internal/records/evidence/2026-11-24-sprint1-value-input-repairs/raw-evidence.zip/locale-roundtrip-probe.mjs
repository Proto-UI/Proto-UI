import { pathToFileURL } from 'node:url';
const { createNumberFieldFormat } = await import(pathToFileURL(process.argv[2]));
const observations = [];
for (const locale of ['en-US', 'de-DE', 'ar-EG', 'bn-BD']) {
  const value = 1234567.875;
  const format = createNumberFieldFormat(locale, { style: 'percent', maximumFractionDigits: 2 });
  const displayed = format.format(value);
  const parsed = format.parse(displayed);
  observations.push({locale, value, displayed, parsed, passed: parsed.kind === 'number' && parsed.value === value});
}
console.log(JSON.stringify({observations}, null, 2));
if (observations.some((entry) => !entry.passed)) process.exitCode = 1;
