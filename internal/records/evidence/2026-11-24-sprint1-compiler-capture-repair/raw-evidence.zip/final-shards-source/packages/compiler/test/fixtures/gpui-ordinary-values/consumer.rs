//! Real generated components with the immutable published GPUI dependency.
//! TestAppContext is a native framework consumer, not an OS input/paint claim.
use generated_gpui_component::CompiledComponent;
use gpui::{
    prelude::*, px, size, Context, Entity, Focusable, InputEvent, Render, TestAppContext, Window, WindowHandle,
};
use proto_ui_gpui_native::gpui_native_owner::{
    catch_authored, detach_native_view, dispatch, event_fields, expose_event, expose_method,
    expose_value, focus_setup, focus_setup_config, invoke, native_owner_allocation_count,
    native_resource_counts, record, scroll_frame, scroll_request, strict_equal, NativeSnapshot, Owner, OwnerRef, Value,
    TABLE_STRUCTURE_FAMILY, attach_scroll_surface, NativeScrollTarget, scroll_snapshot,
};
use serde_json::{json, Value as Json};
use std::{
    cell::{Cell, RefCell},
    panic::{catch_unwind, AssertUnwindSafe},
    rc::Rc,
    time::Duration,
};

use proto_ui_gpui_native::gpui_native_move::{
    attach_move_gesture, MoveGestureBinding, MoveGestureCancelContext,
    MoveGestureCancelReason, MoveGestureInput, MoveGestureSample,
};

#[derive(Clone, Default)]
struct MoveLog {
    refuse: Rc<Cell<bool>>,
    events: Rc<RefCell<Vec<&'static str>>>,
    samples: Rc<RefCell<Vec<MoveGestureSample>>>,
    cancels: Rc<RefCell<Vec<MoveGestureCancelReason>>>,
}
impl MoveGestureBinding for MoveLog {
    fn should_start(&self, _: &MoveGestureSample, _: &mut Window, _: &mut gpui::App) -> bool {
        !self.refuse.get()
    }
    fn on_start(&self, sample: &MoveGestureSample, _: &mut Window, _: &mut gpui::App) {
        self.events.borrow_mut().push("start");
        self.samples.borrow_mut().push(*sample);
    }
    fn on_move(&self, sample: &MoveGestureSample, _: &mut Window, _: &mut gpui::App) {
        self.events.borrow_mut().push("move");
        self.samples.borrow_mut().push(*sample);
    }
    fn on_end(&self, sample: &MoveGestureSample, _: &mut Window, _: &mut gpui::App) {
        self.events.borrow_mut().push("end");
        self.samples.borrow_mut().push(*sample);
    }
    fn on_cancel(&self, reason: MoveGestureCancelReason, _: Option<MoveGestureCancelContext<'_>>) {
        self.events.borrow_mut().push("cancel");
        self.cancels.borrow_mut().push(reason);
    }
}

struct MoveHarness {
    target: Entity<plain::CompiledComponent>,
    stop_up: Rc<Cell<bool>>,
    stopped: Rc<Cell<bool>>,
    scroll_steps: Rc<RefCell<Vec<gpui::ScrollDelta>>>,
}
impl Render for MoveHarness {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        let stop = self.stop_up.clone();
        let stopped = self.stopped.clone();
        let scroll_steps = self.scroll_steps.clone();
        gpui::div().size_full().child(self.target.clone()).child(
            gpui::canvas(|_, _, _| (), move |_, _, window, _| {
                window.on_mouse_event::<gpui::ScrollWheelEvent>(move |event, phase, _, _| {
                    if phase.bubble() { scroll_steps.borrow_mut().push(event.delta); }
                });
                let touch_stop = stop.clone();
                let touch_stopped = stopped.clone();
                window.on_mouse_event::<gpui::TouchDragEvent>(move |event, phase, _, cx| {
                    if phase.bubble() && event.phase == gpui::TouchPhase::Ended && touch_stop.get() {
                        touch_stopped.set(true);
                        cx.stop_propagation();
                    }
                });
                window.on_mouse_event::<gpui::MouseUpEvent>(move |_, phase, _, cx| {
                    if phase.bubble() && stop.get() {
                        stopped.set(true);
                        cx.stop_propagation();
                    }
                });
            }).absolute().size_full()
        )
    }
}
fn move_frames(window: WindowHandle<MoveHarness>, cx: &mut TestAppContext) {
    for _ in 0..3 {
        cx.update_window(window.into(), |_, window, cx| {
            window.refresh();
            window.draw(cx).clear(cx);
        }).unwrap();
        cx.run_until_parked();
    }
}
fn move_window(cx: &mut TestAppContext, log: Rc<MoveLog>) -> (WindowHandle<MoveHarness>, proto_ui_gpui_native::gpui_native_move::MoveGestureLease) {
    let mut lease = None;
    let window = cx.open_window(size(px(600.), px(400.)), |window, cx| {
        let target = plain::CompiledComponent::create(json!({}), None, window, cx).unwrap();
        let owner = target.read(cx).owner.clone();
        assert!(!owner.borrow().mounted, "attachment precedes first committed mount");
        lease = Some(attach_move_gesture(Rc::downgrade(&owner), Box::new(log.as_ref().clone())).unwrap());
        MoveHarness {
            target,
            stop_up: Rc::new(Cell::new(false)),
            stopped: Rc::new(Cell::new(false)),
            scroll_steps: Rc::new(RefCell::new(Vec::new())),
        }
    });
    window.update(cx, |_, window, _| window.activate_window()).unwrap();
    move_frames(window, cx);
    (window, lease.unwrap())
}
fn move_down(window: WindowHandle<MoveHarness>, cx: &mut TestAppContext) -> gpui::Point<gpui::Pixels> {
    window.update(cx, |host, window, cx| {
        let bounds = host.target.read(cx).owner.borrow().bounds.unwrap();
        let position = bounds.origin + gpui::point(px(2.), px(2.));
        window.dispatch_event(gpui::PlatformInput::MouseDown(gpui::MouseDownEvent {
            position, button: gpui::MouseButton::Left, ..Default::default()
        }), cx);
        position
    }).unwrap()
}

fn move_touch(window: &mut Window, cx: &mut gpui::App, id: u64, phase: gpui::TouchPhase, position: gpui::Point<gpui::Pixels>) {
    // Exercise GPUI's own arena and prevent_default claim, not a fabricated drag.
    window.dispatch_event(gpui::PlatformInput::Touch(gpui::TouchEvent {
        id: gpui::TouchId(id), phase, position, ..Default::default()
    }), cx);
}

#[gpui::test]
fn move_gesture_leaves_independent_scroll_input_available(cx: &mut TestAppContext) {
    let log = Rc::new(MoveLog::default());
    let (window, lease) = move_window(cx, log.clone());
    window.update(cx, |host, window, cx| {
        let start = host.target.read(cx).owner.borrow().bounds.unwrap().origin + gpui::point(px(2.), px(2.));
        let displacement = gpui::point(px(60.), px(0.));
        log.refuse.set(true);
        move_touch(window, cx, 40, gpui::TouchPhase::Started, start);
        move_touch(window, cx, 40, gpui::TouchPhase::Moved, start + displacement);
        assert!(!lease.is_active());
        assert!(host.scroll_steps.borrow().iter().any(|delta| {
            matches!(delta, gpui::ScrollDelta::Pixels(p) if p.x != px(0.))
        }), "an unclaimed touch remains available for native scrolling");
        move_touch(window, cx, 40, gpui::TouchPhase::Cancelled, start + displacement);
        host.scroll_steps.borrow_mut().clear();

        log.refuse.set(false);
        move_touch(window, cx, 41, gpui::TouchPhase::Started, start);
        assert!(lease.is_active());
        window.dispatch_event(gpui::ScrollWheelEvent {
            position: start,
            delta: gpui::ScrollDelta::Pixels(displacement),
            ..Default::default()
        }.to_platform_input(), cx);
        assert!(matches!(host.scroll_steps.borrow().as_slice(), [gpui::ScrollDelta::Pixels(delta)] if *delta == displacement));
        assert!(lease.is_active());
        move_touch(window, cx, 41, gpui::TouchPhase::Ended, start);
        assert_eq!(*log.events.borrow(), ["start", "end"]);
    }).unwrap();
}

#[gpui::test]
fn move_gesture_touch_claim_retains_origin_and_ignores_rival_input(cx: &mut TestAppContext) {
    let log = Rc::new(MoveLog::default());
    let (window, lease) = move_window(cx, log.clone());
    let (start, origin) = window.update(cx, |host, window, cx| {
        let bounds = host.target.read(cx).owner.borrow().bounds.unwrap();
        let start = bounds.origin + gpui::point(px(2.), px(2.));
        move_touch(window, cx, 1, gpui::TouchPhase::Started, start);
        (start, bounds.origin)
    }).unwrap();
    assert!(lease.is_active());
    let outside = gpui::point(px(500.), px(300.));
    let released = gpui::point(px(520.), px(290.));
    window.update(cx, |host, window, cx| {
        assert!(!host.target.read(cx).owner.borrow().bounds.unwrap().contains(&outside));
        // Rival finger input stays with GPUI's original logical contact.
        move_touch(window, cx, 2, gpui::TouchPhase::Started, start);
        move_touch(window, cx, 2, gpui::TouchPhase::Moved, outside);
        move_touch(window, cx, 2, gpui::TouchPhase::Cancelled, outside);
        // Hover, primary release and exit from a mouse cannot consume the touch.
        window.dispatch_event(gpui::PlatformInput::MouseDown(gpui::MouseDownEvent {
            position: start, button: gpui::MouseButton::Left, ..Default::default()
        }), cx);
        window.dispatch_event(gpui::PlatformInput::MouseMove(gpui::MouseMoveEvent {
            position: outside, pressed_button: None, ..Default::default()
        }), cx);
        window.dispatch_event(gpui::PlatformInput::MouseUp(gpui::MouseUpEvent {
            position: outside, button: gpui::MouseButton::Left, ..Default::default()
        }), cx);
        window.dispatch_event(gpui::PlatformInput::MouseExited(gpui::MouseExitEvent::default()), cx);
        assert!(lease.is_active());
        assert_eq!(*log.events.borrow(), ["start"]);
        move_touch(window, cx, 1, gpui::TouchPhase::Moved, outside);
        host.stop_up.set(true);
        // The terminal sample is observable even without a final Moved event.
        move_touch(window, cx, 1, gpui::TouchPhase::Ended, released);
        assert!(host.stopped.get(), "touch release completes before a stopped child bubble");
    }).unwrap();
    assert!(!lease.is_active());
    assert_eq!(*log.events.borrow(), ["start", "move", "end"]);
    let samples = log.samples.borrow();
    assert!(samples.iter().all(|sample| sample.input == MoveGestureInput::Touch));
    assert_eq!((samples[0].position.x, samples[0].position.y), (2., 2.));
    assert_eq!(samples[1].position.x, f64::from(f32::from(outside.x)) - f64::from(f32::from(origin.x)));
    assert_eq!(samples[1].position.y, f64::from(f32::from(outside.y)) - f64::from(f32::from(origin.y)));
    assert_eq!(samples[1].total_delta.x, f64::from(f32::from(outside.x)) - f64::from(f32::from(start.x)));
    assert_eq!(samples[1].total_delta.y, f64::from(f32::from(outside.y)) - f64::from(f32::from(start.y)));
    assert_eq!(samples[2].delta.x, 20.);
    assert_eq!(samples[2].delta.y, -10.);
    assert_eq!(samples[2].position.x, f64::from(f32::from(released.x)) - f64::from(f32::from(origin.x)));
    assert_eq!(samples[2].position.y, f64::from(f32::from(released.y)) - f64::from(f32::from(origin.y)));
    assert_eq!(samples[2].total_delta.x, f64::from(f32::from(released.x)) - f64::from(f32::from(start.x)));
    assert_eq!(samples[2].total_delta.y, f64::from(f32::from(released.y)) - f64::from(f32::from(start.y)));
    assert!(log.cancels.borrow().is_empty());
}

#[gpui::test]
fn move_gesture_touch_refusal_cancel_detach_replacement_and_reuse(cx: &mut TestAppContext) {
    let log = Rc::new(MoveLog::default());
    let (window, lease) = move_window(cx, log.clone());
    let start = window.update(cx, |host, _, cx| {
        host.target.read(cx).owner.borrow().bounds.unwrap().origin + gpui::point(px(2.), px(2.))
    }).unwrap();
    window.update(cx, |_, window, cx| {
        move_touch(window, cx, 10, gpui::TouchPhase::Started, gpui::point(px(500.), px(300.)));
        assert!(!lease.is_active(), "touch must hit the attached target");
        move_touch(window, cx, 10, gpui::TouchPhase::Cancelled, start);
        log.refuse.set(true);
        move_touch(window, cx, 11, gpui::TouchPhase::Started, start);
        assert!(!lease.is_active(), "should_start refusal must leave the arena unclaimed");
        move_touch(window, cx, 11, gpui::TouchPhase::Cancelled, start);
        assert!(log.events.borrow().is_empty());
        log.refuse.set(false);
        move_touch(window, cx, 12, gpui::TouchPhase::Started, start);
        assert!(lease.is_active());
        move_touch(window, cx, 12, gpui::TouchPhase::Cancelled, start);
        move_touch(window, cx, 12, gpui::TouchPhase::Cancelled, start);
        assert!(!lease.is_active());
        move_touch(window, cx, 13, gpui::TouchPhase::Started, start);
        assert!(lease.is_active(), "the same lease admits a new contact after host cancellation");
    }).unwrap();
    window.update(cx, |host, window, cx| {
        detach_native_view(&host.target.read(cx).owner);
        move_touch(window, cx, 13, gpui::TouchPhase::Cancelled, start);
        host.target.update(cx, |_, cx| cx.notify());
    }).unwrap();
    move_frames(window, cx);
    window.update(cx, |_, window, cx| {
        move_touch(window, cx, 14, gpui::TouchPhase::Started, start);
        assert!(lease.is_active());
        let replacement = plain::CompiledComponent::create(json!({}), None, window, cx).unwrap();
        let owner = replacement.read(cx).owner.clone();
        lease.update(Rc::downgrade(&owner), Box::new(MoveLog::default()), window, cx).unwrap();
        move_touch(window, cx, 14, gpui::TouchPhase::Cancelled, start);
    }).unwrap();
    lease.dispose();
    assert_eq!(*log.events.borrow(), ["start", "cancel", "start", "cancel", "start", "cancel"]);
    assert_eq!(*log.cancels.borrow(), [MoveGestureCancelReason::HostCancel, MoveGestureCancelReason::TargetDetached, MoveGestureCancelReason::TargetReplaced]);
}

#[gpui::test]
fn move_gesture_touch_cannot_modify_a_live_mouse_session(cx: &mut TestAppContext) {
    let log = Rc::new(MoveLog::default());
    let (window, lease) = move_window(cx, log.clone());
    let start = move_down(window, cx);
    window.update(cx, |_, window, cx| {
        move_touch(window, cx, 20, gpui::TouchPhase::Started, start);
        move_touch(window, cx, 20, gpui::TouchPhase::Moved, gpui::point(px(500.), px(300.)));
        move_touch(window, cx, 20, gpui::TouchPhase::Cancelled, start);
        assert!(lease.is_active());
        assert_eq!(*log.events.borrow(), ["start"]);
        window.dispatch_event(gpui::PlatformInput::MouseUp(gpui::MouseUpEvent {
            position: start, button: gpui::MouseButton::Left, ..Default::default()
        }), cx);
    }).unwrap();
    assert!(!lease.is_active());
    assert_eq!(*log.events.borrow(), ["start", "end"]);
    assert!(log.samples.borrow().iter().all(|sample| sample.input == MoveGestureInput::Mouse));
    assert!(log.cancels.borrow().is_empty());
}

#[gpui::test]
fn move_gesture_retains_window_contact_and_release_precedes_child_bubble(cx: &mut TestAppContext) {
    let log = Rc::new(MoveLog::default());
    let (window, lease) = move_window(cx, log.clone());
    let start = move_down(window, cx);
    assert!(lease.is_active());
    let outside = gpui::point(px(500.), px(300.));
    let released = gpui::point(px(510.), px(325.));
    window.update(cx, |host, window, cx| {
        let bounds = host.target.read(cx).owner.borrow().bounds.unwrap();
        assert!(!bounds.contains(&outside));
        window.dispatch_event(gpui::PlatformInput::MouseMove(gpui::MouseMoveEvent {
            position: outside, pressed_button: Some(gpui::MouseButton::Left),
            modifiers: gpui::Modifiers { shift: true, alt: true, ..Default::default() },
        }), cx);
        host.stop_up.set(true);
        window.dispatch_event(gpui::PlatformInput::MouseUp(gpui::MouseUpEvent {
            position: released, button: gpui::MouseButton::Left, ..Default::default()
        }), cx);
        assert!(host.stopped.get(), "downstream native child stopped the bubble release");
    }).unwrap();
    assert!(!lease.is_active());
    assert_eq!(*log.events.borrow(), ["start", "move", "end"]);
    let samples = log.samples.borrow();
    assert_eq!((samples[0].position.x, samples[0].position.y), (2., 2.));
    assert_eq!(samples[1].total_delta.x, f64::from(f32::from(outside.x - start.x)));
    assert!(samples[1].modifiers.shift && samples[1].modifiers.alt);
    assert_eq!((samples[2].delta.x, samples[2].delta.y), (10., 25.));
    assert_eq!(samples[2].total_delta.x, f64::from(f32::from(released.x - start.x)));
    assert_eq!(samples[2].total_delta.y, f64::from(f32::from(released.y - start.y)));
    assert!(log.cancels.borrow().is_empty());
}

#[gpui::test]
fn move_gesture_cancellation_is_terminal_and_lease_can_restart(cx: &mut TestAppContext) {
    let log = Rc::new(MoveLog::default());
    let (window, lease) = move_window(cx, log.clone());
    move_down(window, cx);
    window.update(cx, |_, window, cx| lease.cancel(MoveGestureCancelReason::HostCancel, window, cx)).unwrap();
    assert!(!lease.is_active());
    move_down(window, cx);
    window.update(cx, |host, _, cx| {
        detach_native_view(&host.target.read(cx).owner);
        host.target.update(cx, |_, cx| cx.notify());
    }).unwrap();
    assert!(!lease.is_active());
    move_frames(window, cx);
    move_down(window, cx);
    assert!(lease.is_active());
    lease.dispose();
    lease.dispose();
    assert!(!lease.is_active());
    assert_eq!(*log.events.borrow(), ["start", "cancel", "start", "cancel", "start", "cancel"]);
    assert_eq!(*log.cancels.borrow(), [MoveGestureCancelReason::HostCancel, MoveGestureCancelReason::TargetDetached, MoveGestureCancelReason::Disposed]);
}

#[gpui::test]
fn move_gesture_ignores_foreign_window_samples_and_cancels_window_loss(cx: &mut TestAppContext) {
    let first_log = Rc::new(MoveLog::default());
    let (first, lease) = move_window(cx, first_log.clone());
    let (second, other_lease) = move_window(cx, Rc::new(MoveLog::default()));
    first.update(cx, |_, window, _| window.activate_window()).unwrap();
    move_frames(first, cx);
    move_down(first, cx);
    assert!(lease.is_active());
    second.update(cx, |_, window, cx| {
        window.dispatch_event(gpui::PlatformInput::MouseMove(gpui::MouseMoveEvent {
            position: gpui::point(px(10.), px(10.)), pressed_button: None, ..Default::default()
        }), cx);
        window.dispatch_event(gpui::PlatformInput::MouseUp(gpui::MouseUpEvent::default()), cx);
    }).unwrap();
    assert!(lease.is_active(), "foreign hover and up cannot consume contact ownership");
    assert!(!other_lease.is_active());
    first.update(cx, |_, window, cx| {
        window.dispatch_event(gpui::PlatformInput::MouseExited(gpui::MouseExitEvent::default()), cx);
    }).unwrap();
    assert!(!lease.is_active());
    assert_eq!(*first_log.cancels.borrow(), [MoveGestureCancelReason::LostOwnership]);
}

#[gpui::test]
fn move_gesture_plain_target_observes_deactivation_and_releases_subscription(cx: &mut TestAppContext) {
    let log = Rc::new(MoveLog::default());
    let (first, lease) = move_window(cx, log.clone());
    first.update(cx, |host, _, cx| {
        assert_eq!(host.target.read(cx).native_resource_counts()["nativeSubscriptions"], json!(1));
    }).unwrap();
    move_down(first, cx);
    assert!(lease.is_active());
    let (_other, _other_lease) = move_window(cx, Rc::new(MoveLog::default()));
    cx.run_until_parked();
    assert!(!lease.is_active());
    assert_eq!(*log.cancels.borrow(), [MoveGestureCancelReason::LostOwnership]);
    lease.dispose();
    first.update(cx, |host, _, cx| host.target.update(cx, |_, cx| cx.notify())).unwrap();
    move_frames(first, cx);
    first.update(cx, |host, _, cx| {
        assert_eq!(host.target.read(cx).native_resource_counts()["nativeSubscriptions"], json!(0));
    }).unwrap();
}

#[gpui::test]
fn move_gesture_refuses_duplicate_ownership_and_replacement_cancels_old_session(cx: &mut TestAppContext) {
    let log = Rc::new(MoveLog::default());
    let (window, lease) = move_window(cx, log.clone());
    assert!(attach_move_gesture(lease.target(), Box::new(MoveLog::default())).is_err());
    window.update(cx, |_, window, cx| {
        window.dispatch_event(gpui::PlatformInput::MouseDown(gpui::MouseDownEvent {
            position: gpui::point(px(2.), px(2.)), button: gpui::MouseButton::Right, ..Default::default()
        }), cx);
    }).unwrap();
    assert!(!lease.is_active());
    move_down(window, cx);
    assert!(lease.is_active());
    window.update(cx, |_, window, cx| {
        let replacement = plain::CompiledComponent::create(json!({}), None, window, cx).unwrap();
        let owner = replacement.read(cx).owner.clone();
        lease.update(Rc::downgrade(&owner), Box::new(MoveLog::default()), window, cx).unwrap();
        assert!(!lease.is_active());
    }).unwrap();
    assert_eq!(*log.events.borrow(), ["start", "cancel"]);
    assert_eq!(*log.cancels.borrow(), [MoveGestureCancelReason::TargetReplaced]);
}

#[gpui::test]
fn move_gesture_should_start_refusal_and_owner_disposal_are_bounded(cx: &mut TestAppContext) {
    let log = Rc::new(MoveLog::default());
    log.refuse.set(true);
    let (window, lease) = move_window(cx, log.clone());
    move_down(window, cx);
    assert!(!lease.is_active());
    assert!(log.events.borrow().is_empty());
    log.refuse.set(false);
    move_down(window, cx);
    assert!(lease.is_active());
    window.update(cx, |host, _, cx| Owner::dispose(&host.target.read(cx).owner)).unwrap();
    assert!(!lease.is_active());
    lease.dispose();
    assert_eq!(*log.events.borrow(), ["start", "cancel"]);
    assert_eq!(*log.cancels.borrow(), [MoveGestureCancelReason::Disposed]);
}

struct Harness {
    transition: Entity<CompiledComponent>,
    ordinary: Entity<ordinary::CompiledComponent>,
    other: Entity<ordinary::CompiledComponent>,
    plain: Entity<plain::CompiledComponent>,
    scope: Entity<focus_scope::CompiledComponent>,
    first: Entity<focus_target::CompiledComponent>,
    second: Entity<focus_target::CompiledComponent>,
    cold: Entity<cold::CompiledComponent>,
    mutant: Entity<mutant::CompiledComponent>,
    context_a: Entity<context_a::CompiledComponent>,
    context_other: Entity<context_a::CompiledComponent>,
    context_b: Entity<context_b::PrivateContext>,
    context_child: Entity<context_child::CompiledComponent>,
}
impl Render for Harness {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        gpui::div()
            .size_full()
            .child(self.transition.clone())
            .child(self.ordinary.clone())
            .child(self.other.clone())
            .child(self.plain.clone())
            .child(self.scope.clone())
            .child(self.cold.clone())
            .child(self.mutant.clone())
            .child(self.context_a.clone())
            .child(self.context_other.clone())
            .child(self.context_b.clone())
    }
}
fn open(cx: &mut TestAppContext, props: Json) -> WindowHandle<Harness> {
    let handle = cx.open_window(size(px(600.), px(400.)), |window, cx| {
        let transition = CompiledComponent::create(props.clone(), None, window, cx)
            .expect("native construction");
        let ordinary = ordinary::CompiledComponent::create(json!({}), None, window, cx)
            .expect("native construction");
        let other = ordinary::CompiledComponent::create(json!({}), None, window, cx)
            .expect("native construction");
        let plain = plain::CompiledComponent::create(json!({}), None, window, cx)
            .expect("native construction");
        let scope = focus_scope::CompiledComponent::create(json!({}), None, window, cx)
            .expect("native construction");
        let parent = Rc::downgrade(&scope.read(cx).owner);
        let first =
            focus_target::CompiledComponent::create(json!({}), Some(parent.clone()), window, cx)
                .expect("native construction");
        let second = focus_target::CompiledComponent::create(json!({}), Some(parent), window, cx)
            .expect("native construction");
        scope.update(cx, |scope, cx| {
            scope
                .set_slot(
                    vec![
                        NativeSnapshot::native_view(first.clone().into()),
                        NativeSnapshot::native_view(second.clone().into()),
                    ],
                    cx,
                )
                .expect("native slot update")
        });
        let cold = cold::CompiledComponent::create(
            json!({"enterDuration":50,"leaveDuration":50}),
            None,
            window,
            cx,
        )
        .expect("native construction");
        let mutant = mutant::CompiledComponent::create(props, None, window, cx)
            .expect("native construction");
        let context_a = context_a::CompiledComponent::create(json!({}), None, window, cx)
            .expect("native construction");
        let context_other = context_a::CompiledComponent::create(json!({}), None, window, cx)
            .expect("native construction");
        let context_b = context_b::PrivateContext::create(json!({}), None, window, cx)
            .expect("native construction");
        let context_parent = Rc::downgrade(&context_a.read(cx).owner);
        let context_child =
            context_child::CompiledComponent::create(json!({}), Some(context_parent), window, cx)
                .expect("native construction");
        context_a.update(cx, |view, cx| {
            view.set_slot(
                vec![NativeSnapshot::native_view(context_child.clone().into())],
                cx,
            )
            .expect("native slot update")
        });
        Harness {
            transition,
            ordinary,
            other,
            plain,
            scope,
            first,
            second,
            cold,
            mutant,
            context_a,
            context_other,
            context_b,
            context_child,
        }
    });
    handle
        .update(cx, |_, window, _| window.activate_window())
        .unwrap();
    frames(handle, cx);
    handle
}
fn frames<T: Render + 'static>(window: WindowHandle<T>, cx: &mut TestAppContext) {
    for _ in 0..3 {
        cx.update_window(window.into(), |_, window, cx| {
            window.refresh();
            window.draw(cx).clear(cx);
        })
        .unwrap();
        cx.run_until_parked();
    }
}
fn exposed(owner: &OwnerRef, name: &str) -> Value {
    owner.borrow().exposes.get(name).unwrap().clone()
}
fn event_names(owner: &OwnerRef) -> Vec<String> {
    owner
        .borrow()
        .emitted
        .iter()
        .map(|(name, _)| name.clone())
        .collect()
}

struct PhysicalScroll {
    handle: gpui::ScrollHandle,
    rows: usize,
}
impl Render for PhysicalScroll {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        gpui::div().id("physical-scroll").w(px(160.)).h(px(80.))
            .overflow_y_scroll().track_scroll(&self.handle).flex().flex_col()
            .children((0..self.rows).map(|index| gpui::div().flex_none().h(px(20.)).child(format!("Row {index}"))))
    }
}

#[gpui::test]
fn native_scroll_target_shares_real_geometry_and_retires_only_its_lease(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    let (component, first_handle, first_target, first_lease) = window.update(cx, |host, window, cx| {
        let component = external_scroll::CompiledComponent::create(json!({}), None, window, cx).unwrap();
        let owner = component.read(cx).owner.clone();
        let handle = gpui::ScrollHandle::default();
        let target = NativeScrollTarget::new(handle.clone());
        let lease = attach_scroll_surface(&Rc::downgrade(&owner), target.clone(), window).unwrap();
        let content = cx.new(|_| PhysicalScroll { handle: handle.clone(), rows: 30 });
        component.update(cx, |view, cx| view.set_slot(vec![NativeSnapshot::native_view(content.into())], cx).unwrap());
        host.scope.update(cx, |view, cx| view.set_slot(vec![NativeSnapshot::native_view(component.clone().into())], cx).unwrap());
        (component, handle, target, lease)
    }).unwrap();
    frames(window, cx);
    let (second_handle, second_lease) = window.update(cx, |_, window, cx| {
        let owner = component.read(cx).owner.clone();
        assert!(first_lease.is_current());
        assert!(first_handle.max_offset().y > px(100.), "real child layout establishes overflow");
        assert_eq!(owner.borrow().modules.scroll.handle.as_ref().unwrap().max_offset().y, px(0.), "compiler root did not create a second scroll box");
        assert_eq!(exposed(&owner, "middle").call(vec![]).unwrap().member("kind", false).text(), "dispatched");
        assert!((first_handle.offset().y + first_handle.max_offset().y / 2.).abs() < px(0.01));
        let snapshot = exposed(&owner, "snapshot").call(vec![]).unwrap();
        assert_eq!(snapshot.member("projection", false).text(), "system");
        assert!((snapshot.member("vertical", false).member("position", false).num() - 0.5).abs() < 0.001);
        // A rival acquisition has no authority over the existing physical box.
        let rival = external_scroll::CompiledComponent::create(json!({}), None, window, cx).unwrap();
        assert!(attach_scroll_surface(&Rc::downgrade(&rival.read(cx).owner), first_target.clone(), window).is_err());
        assert!(first_lease.is_current());
        exposed(&owner, "end").call(vec![]).unwrap();
        exposed(&owner, "sameAxis").call(vec![]).unwrap();
        assert!(owner.borrow().modules.scroll.pending_end.is_some());
        exposed(&owner, "extraFields").call(vec![]).unwrap();
        assert!(owner.borrow().modules.scroll.pending_end.is_none());
        assert_eq!(owner.borrow().modules.scroll.request_status, "rejected");
        assert_eq!(owner.borrow().modules.scroll.config["projection"].text(), "system");
        assert_eq!(exposed(&owner, "middle").call(vec![]).unwrap().member("reason", false).text(), "unavailable");
        exposed(&owner, "vertical").call(vec![]).unwrap();
        exposed(&owner, "end").call(vec![]).unwrap();
        let offset = first_handle.offset();
        let handle = gpui::ScrollHandle::default();
        let lease = attach_scroll_surface(&Rc::downgrade(&owner), NativeScrollTarget::new(handle.clone()), window).unwrap();
        assert!(!first_lease.is_current());
        assert!(owner.borrow().modules.scroll.pending_end.is_none());
        assert_eq!(first_handle.offset(), offset, "release never moves the old physical target");
        let content = cx.new(|_| PhysicalScroll { handle: handle.clone(), rows: 45 });
        component.update(cx, |view, cx| view.set_slot(vec![NativeSnapshot::native_view(content.into())], cx).unwrap());
        (handle, lease)
    }).unwrap();
    drop(first_lease);
    frames(window, cx);
    window.update(cx, |_, window, cx| {
        let owner = component.read(cx).owner.clone();
        assert!(second_lease.is_current(), "late old lease cleanup preserves replacement");
        assert!(second_handle.max_offset().y > px(100.));
        assert_eq!(second_handle.offset().y, px(0.), "old pending end was not replayed into the replacement");
        exposed(&owner, "middle").call(vec![]).unwrap();
        let offset = second_handle.offset();
        detach_native_view(&owner);
        assert!(!second_lease.is_current());
        assert!(!second_lease.note_input(window));
        assert_eq!(second_handle.offset(), offset);
        assert_eq!(scroll_snapshot(&Rc::downgrade(&owner)).member("projection", false).text(), "unresolved");
        assert_eq!(exposed(&owner, "middle").call(vec![]).unwrap().member("reason", false).text(), "not-mounted");
    }).unwrap();
}

#[gpui::test]
fn native_scroll_axis_sync_suspends_following_without_replaying_disabled_growth(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    let (component, content, handle, lease) = window.update(cx, |host, window, cx| {
        let component = validation::CompiledComponent::create(json!({}), None, window, cx).unwrap();
        let owner = component.read(cx).owner.clone();
        let handle = gpui::ScrollHandle::default();
        let lease = attach_scroll_surface(&Rc::downgrade(&owner), NativeScrollTarget::new(handle.clone()), window).unwrap();
        let content = cx.new(|_| PhysicalScroll { handle: handle.clone(), rows: 30 });
        host.scope.update(cx, |view, cx| view.set_slot(vec![
            NativeSnapshot::native_view(component.clone().into()),
            NativeSnapshot::native_view(content.clone().into()),
        ], cx).unwrap());
        (component, content, handle, lease)
    }).unwrap();
    frames(window, cx);
    let (before, extent) = window.update(cx, |_, _, cx| {
        let owner = component.read(cx).owner.clone();
        assert!(lease.is_current());
        assert!(handle.max_offset().y > px(100.), "physical content has genuine overflow");
        assert_eq!(handle.offset().y, -handle.max_offset().y, "the configured policy follows the initial end");
        exposed(&owner, "scrollEnd").call(vec![]).unwrap();
        exposed(&owner, "scrollAxesHorizontal").call(vec![]).unwrap();
        assert_eq!(owner.borrow().modules.scroll.request_status, "rejected", "switching axes retires a pending unavailable-axis request");
        let before = handle.offset();
        let extent = handle.max_offset();
        content.update(cx, |content, cx| { content.rows = 45; cx.notify(); });
        (before, extent)
    }).unwrap();
    frames(window, cx);
    window.update(cx, |_, _, cx| {
        let owner = component.read(cx).owner.clone();
        assert!(handle.max_offset().y > extent.y);
        assert_eq!(handle.offset(), before, "automatic end following cannot write an axis disabled by sync");
        let follow = owner.borrow().modules.scroll.config["endFollow"].clone();
        assert_eq!(follow.member("mode", false).text(), "while-at-end");
        assert_eq!(follow.member("axis", false).text(), "vertical", "sync preserves the authored follow policy");
        assert!(owner.borrow().modules.scroll.following, "the policy remains eligible when its axis returns");
        assert_eq!(owner.borrow().modules.scroll.request_status, "rejected", "ineligible growth cannot report an applied request");
        exposed(&owner, "scrollAxesVertical").call(vec![]).unwrap();
    }).unwrap();
    frames(window, cx);
    window.update(cx, |_, _, cx| {
        assert_eq!(handle.offset(), before, "returning the axis does not replay growth observed while it was disabled");
        content.update(cx, |content, cx| { content.rows = 60; cx.notify(); });
    }).unwrap();
    frames(window, cx);
    window.update(cx, |_, _, cx| {
        let owner = component.read(cx).owner.clone();
        assert_eq!(handle.offset().y, -handle.max_offset().y, "new eligible growth follows normally");
        assert_eq!(owner.borrow().modules.scroll.request_status, "applied");
    }).unwrap();
}

#[gpui::test]
fn generated_scroll_request_outcomes_and_retired_end_work(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    let component = window.update(cx, |host, window, cx| {
        let component = validation::CompiledComponent::create(json!({}), None, window, cx)
            .expect("native scroll consumer construction");
        let owner = component.read(cx).owner.clone();
        let before = exposed(&owner, "scrollTo").call(vec![]).expect("unmounted outcome");
        assert_eq!(before.member("kind", false).text(), "rejected");
        assert_eq!(before.member("reason", false).text(), "not-mounted");
        assert!(owner.borrow().modules.scroll.request_status.is_empty());
        for malformed in [record(vec![]), Value::Undefined] {
            let refused = catch_authored(|| scroll_request(&Rc::downgrade(&owner), malformed))
                .expect("unmounted refusal precedes kind validation");
            assert_eq!(refused.member("reason", false).text(), "not-mounted");
        }
        assert!(owner.borrow().modules.scroll.request_status.is_empty());
        assert_eq!(exposed(&owner, "scrollEnd").call(vec![]).unwrap().text(), "rejected");
        assert_eq!(owner.borrow().modules.scroll.request_status, "rejected");
        let plain = host.plain.read(cx).owner.clone();
        let undeclared = scroll_request(&Rc::downgrade(&plain), record(vec![]));
        assert_eq!(undeclared.member("reason", false).text(), "not-declared");
        let undeclared_end = scroll_request(&Rc::downgrade(&plain), record(vec![("kind", Value::string("to-end"))]));
        assert_eq!(undeclared_end.member("reason", false).text(), "not-declared");
        assert!(plain.borrow().modules.scroll.request_status.is_empty());
        host.scope.update(cx, |scope, cx| {
            scope.set_slot(vec![NativeSnapshot::native_view(component.clone().into())], cx)
                .expect("mount native scroll consumer");
        });
        component
    }).unwrap();
    frames(window, cx);
    window.update(cx, |_, native_window, cx| {
        let owner = component.read(cx).owner.clone();
        assert!(owner.borrow().mounted);
        let missing_kind = record(vec![("axis", Value::string("vertical"))]);
        assert!(catch_authored(|| scroll_request(&Rc::downgrade(&owner), missing_kind)).is_err());
        for method in ["scrollToKind", "scrollBy", "scrollPage", "scrollDrag", "scrollEnd"] {
            assert_eq!(exposed(&owner, method).call(vec![]).expect("structured outcome member").text(), "dispatched");
        }
        let wrong_axis = exposed(&owner, "scrollWrongAxis").call(vec![]).expect("axis rejection");
        assert_eq!(wrong_axis.member("kind", false).text(), "rejected");
        assert_eq!(wrong_axis.member("reason", false).text(), "unavailable");
        assert_eq!(owner.borrow().modules.scroll.request_status, "pending");
        assert_eq!(exposed(&owner, "scrollEndWrongAxis").call(vec![]).unwrap().member("reason", false).text(), "unavailable");
        assert_eq!(owner.borrow().modules.scroll.request_status, "rejected");

        // A declared, mounted view can still be unavailable. Restore presence
        // before any host frame so this is an isolated readiness refusal.
        assert_eq!(exposed(&owner, "scrollEnd").call(vec![]).unwrap().text(), "dispatched");
        let was_present = owner.borrow().present;
        owner.borrow_mut().present = false;
        let unavailable_position = exposed(&owner, "scrollTo").call(vec![]);
        let position_status = owner.borrow().modules.scroll.request_status.clone();
        let missing_kind = catch_authored(|| scroll_request(&Rc::downgrade(&owner), record(vec![])));
        let nullish_request = catch_authored(|| scroll_request(&Rc::downgrade(&owner), Value::Undefined));
        let unavailable_end = exposed(&owner, "scrollEnd").call(vec![]);
        let end_status = owner.borrow().modules.scroll.request_status.clone();
        owner.borrow_mut().present = was_present;
        let unavailable_position = unavailable_position.expect("not-present position refusal");
        let unavailable_end = unavailable_end.expect("not-present end refusal");
        assert_eq!(missing_kind.expect("not-ready refusal precedes kind validation").member("reason", false).text(), "unavailable");
        assert_eq!(nullish_request.expect("not-ready refusal precedes property access").member("reason", false).text(), "unavailable");
        assert_eq!(unavailable_position.member("kind", false).text(), "rejected");
        assert_eq!(unavailable_position.member("reason", false).text(), "unavailable");
        assert_eq!(position_status, "pending");
        assert_eq!(unavailable_end.text(), "rejected");
        assert_eq!(end_status, "rejected");

        // A missing handle refuses end delivery without allowing a position
        // refusal to overwrite the pending end status. Restore the real handle.
        assert_eq!(exposed(&owner, "scrollEnd").call(vec![]).unwrap().text(), "dispatched");
        let handle = owner.borrow_mut().modules.scroll.handle.take();
        let unavailable_position = exposed(&owner, "scrollTo").call(vec![]);
        let position_status = owner.borrow().modules.scroll.request_status.clone();
        let unavailable_end = exposed(&owner, "scrollEnd").call(vec![]);
        let end_status = owner.borrow().modules.scroll.request_status.clone();
        owner.borrow_mut().modules.scroll.handle = handle;
        let unavailable_position = unavailable_position.expect("missing-handle position refusal");
        let unavailable_end = unavailable_end.expect("missing-handle end refusal");
        assert_eq!(unavailable_position.member("reason", false).text(), "unavailable");
        assert_eq!(position_status, "pending");
        assert_eq!(unavailable_end.text(), "rejected");
        assert_eq!(end_status, "rejected");
        // An accepted end request belongs to this view epoch. Detaching before
        // its next layout must not apply that work to the replacement view.
        assert_eq!(exposed(&owner, "scrollEnd").call(vec![]).unwrap().text(), "dispatched");
        assert!(owner.borrow().modules.scroll.pending_end.is_some());
        detach_native_view(&owner);
        let detached = exposed(&owner, "scrollTo").call(vec![]).expect("detached outcome");
        assert_eq!(detached.member("reason", false).text(), "not-mounted");
        assert_eq!(owner.borrow().modules.scroll.request_status, "pending");
        // Keep while-at-end configured and following, and control only the
        // historical max observation. The current max/offset come from the
        // real ScrollHandle; this does not claim nonzero physical overflow.
        let offset_before = {
            let mut o = owner.borrow_mut();
            let s = &mut o.modules.scroll;
            let handle = s.handle.as_ref().unwrap();
            let max = handle.max_offset();
            let offset = handle.offset();
            s.following = true;
            s.previous_max = gpui::point(max.x + px(1.), max.y + px(1.));
            assert_ne!(max, s.previous_max);
            offset
        };
        scroll_frame(&owner, native_window);
        assert!(owner.borrow().modules.scroll.pending_end.is_none());
        // On this no-overflow surface, rejected status distinguishes stale-work
        // suppression from fallback application; offset equality alone cannot.
        assert_eq!(owner.borrow().modules.scroll.request_status, "rejected");
        assert_eq!(owner.borrow().modules.scroll.handle.as_ref().unwrap().offset(), offset_before);
    }).unwrap();
    frames(window, cx);
    window.update(cx, |_, _, cx| {
        let owner = component.read(cx).owner.clone();
        assert!(owner.borrow().mounted);
        assert!(owner.borrow().modules.scroll.pending_end.is_none());
        assert_eq!(owner.borrow().modules.scroll.request_status, "rejected");
        assert_eq!(exposed(&owner, "scrollToKind").call(vec![]).unwrap().text(), "dispatched");
        let retained = exposed(&owner, "scrollToKind");
        Owner::dispose(&owner);
        assert!(retained.call(vec![]).is_err());
    }).unwrap();
}

#[gpui::test]
fn data_methods_preserve_argument_presence_registration_and_terminal_lifetime(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    frames(window, cx);
    window.update(cx, |host, native_window, cx| {
        let one = host.ordinary.read(cx).handle();
        let two = host.other.read(cx).handle();
        for handle in [&one, &two] {
            assert_eq!(handle.call_data_method("decide", vec![None, Some(json!(3))]).unwrap(), json!(10.0));
            assert_eq!(handle.call_data_method("decide", vec![Some(json!(2)), Some(json!(3))]).unwrap(), json!(5.0));
            assert!(handle.call_data_method("decide", vec![Some(Json::Null), Some(json!(3))]).is_err());
            assert!(handle.call_data_method("decide", vec![Some(json!(2))]).is_err());
            assert!(handle.call_data_method("decide", vec![None, Some(json!(3)), Some(json!(4))]).is_err());
            assert!(handle.call_data_method("unknown", vec![]).is_err());
            let registered = exposed(&handle.owner, "dataRegistered").data().as_bool().unwrap();
            let conditional = handle.call_data_method("conditionalDecide", vec![None, Some(json!(3))]);
            if registered {
                assert_eq!(conditional.unwrap(), json!(10.0));
            } else {
                assert!(conditional.is_err());
            }
        }
        assert_ne!(exposed(&one.owner, "dataRegistered").data(), exposed(&two.owner, "dataRegistered").data());
        // A registry substitution distinguishes the actual callback from its
        // statically eligible module function. Restore it before lifecycle work.
        let original = one.owner.borrow_mut().exposes.insert(
            "decide".into(), Value::Function(Rc::new(|_| Value::json(json!(99)))),
        ).unwrap();
        assert_eq!(one.call_data_method("decide", vec![None, Some(json!(3))]).unwrap(), json!(99.0));
        one.owner.borrow_mut().exposes.insert("decide".into(), original);
        detach_native_view(&one.owner);
        assert_eq!(one.call_data_method("decide", vec![None, Some(json!(3))]).unwrap(), json!(10.0));
        one.dispose(native_window, cx).unwrap();
        assert!(one.call_data_method("decide", vec![None, Some(json!(3))]).is_err());
        assert!(one.call_data_method("unknown", vec![]).is_err());
        // Retirement of one owner cannot retire another instance's registration.
        assert_eq!(two.call_data_method("decide", vec![None, Some(json!(3))]).unwrap(), json!(10.0));
    }).unwrap();
}

#[gpui::test]
fn ordinary_source_aliases_captures_defaults_exceptions_and_public_values(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    frames(window, cx);
    window
        .update(cx, |host, window, cx| {
            let one = host.ordinary.read(cx).handle();
            let two = host.other.read(cx).handle();
            assert_eq!(
                one.call("same", vec![], window, cx)
                    .expect("authored host call"),
                json!(true)
            );
            assert_eq!(
                one.call("increment", vec![], window, cx)
                    .expect("authored host call"),
                json!(1.0)
            );
            assert_eq!(
                one.call("read", vec![], window, cx)
                    .expect("authored host call"),
                json!(1.0)
            );
            assert_eq!(
                two.call("read", vec![], window, cx)
                    .expect("authored host call"),
                json!(0.0)
            );
            assert_eq!(
                one.call("forward", vec![], window, cx)
                    .expect("authored host call"),
                json!("later")
            );
            assert_eq!(
                one.call("even", vec![json!(12)], window, cx)
                    .expect("authored host call"),
                json!(true)
            );
            assert_eq!(
                one.call("even", vec![json!(11)], window, cx)
                    .expect("authored host call"),
                json!(false)
            );
            assert_eq!(
                one.call("defaults", vec![], window, cx)
                    .expect("authored host call"),
                json!(12.0)
            );
            assert_eq!(
                one.call("explicitDefault", vec![json!(8)], window, cx)
                    .expect("authored host call"),
                json!(89.0)
            );
            assert_eq!(
                one.call("defaults", vec![], window, cx)
                    .expect("authored host call"),
                json!(23.0)
            );
            assert_eq!(
                one.call("defaultCapture", vec![], window, cx)
                    .expect("authored host call"),
                json!(7.0)
            );
            assert_eq!(
                one.call("freezeAlias", vec![], window, cx)
                    .expect("authored host call"),
                json!(true)
            );
            assert_eq!(
                one.call("caughtIdentity", vec![], window, cx)
                    .expect("authored host call"),
                json!(true)
            );
            assert_eq!(
                one.call("optional", vec![json!(true)], window, cx)
                    .expect("authored host call"),
                json!({"calls":0.0,"value":-1.0})
            );
            assert_eq!(
                one.call("optional", vec![json!(false)], window, cx)
                    .expect("authored host call"),
                json!({"calls":1.0,"value":42.0})
            );
            assert_eq!(
                one.call("spread", vec![], window, cx)
                    .expect("authored host call"),
                json!({"independent":true,"overwrite":true,"own":true,"finite":true})
            );
            let first = one
                .call("shared", vec![], window, cx)
                .expect("authored host call")
                .as_f64()
                .unwrap();
            assert_eq!(
                two.call("shared", vec![], window, cx)
                    .expect("authored host call"),
                json!(first + 1.)
            );
            let controls = exposed(&one.owner, "controls");
            assert_eq!(
                controls
                    .member("increment", false)
                    .call(vec![])
                    .expect("public callable result")
                    .num(),
                2.
            );
            assert_eq!(
                controls
                    .member("read", false)
                    .call(vec![])
                    .expect("public callable result")
                    .num(),
                2.
            );
            assert!(strict_equal(
                &exposed(&host.transition.read(cx).owner, "sameHandle"),
                &Value::boolean(true)
            ));
        })
        .unwrap();
}

#[gpui::test]
fn no_unrelated_capability_state_handles_listeners_or_metadata_are_initialized(
    cx: &mut TestAppContext,
) {
    let window = open(cx, json!({}));
    frames(window, cx);
    window
        .update(cx, |host, _, cx| {
            assert_eq!(
                exposed(&host.plain.read(cx).owner, "demand").data(),
                json!({"observedCalls":1.0,"tag":7.0,"same":true,"distinct":true})
            );
            let plain = host.plain.read(cx).native_resource_counts();
            for key in [
                "states",
                "hooks",
                "listeners",
                "stateWatchers",
                "propsWatchers",
                "contextSubscriptions",
                "anatomySubscriptions",
                "collectionStates",
                "scrollHandles",
                "boundaryRegions",
                "boundaryCallbacks",
                "metadataKeys",
                "schedulerBindings",
                "delays",
                "presenceOwners",
                "nativeSubscriptions",
            ] {
                assert_eq!(plain[key], json!(0), "unrelated {key}: {plain}");
            }
            for key in [
                "pointerInput",
                "keyInput",
                "boundaryInput",
                "focusObservation",
            ] {
                assert_eq!(plain[key], json!(false), "{key}");
            }
            let ordinary = host.ordinary.read(cx).native_resource_counts();
            assert_eq!(ordinary["schedulerBindings"], json!(1));
            assert_eq!(ordinary["metadataKeys"], json!(0));
            assert_eq!(ordinary["nativeSubscriptions"], json!(0));
            let focus = host.first.read(cx).native_resource_counts();
            // Focus observation now owns the subtree-exit subscription too.
            assert_eq!(focus["nativeSubscriptions"], json!(4));
            assert_eq!(focus["scrollHandles"], json!(0));
            println!(
                "native-resource-evidence {}",
                json!({"plain":plain,"ordinary":ordinary,"focus":focus})
            );
        })
        .unwrap();
}

#[gpui::test]
fn zero_delay_is_async_cancel_and_dispose_release_pending_work(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    frames(window, cx);
    window
        .update(cx, |host, window, cx| {
            let handle = host.ordinary.read(cx).handle();
            handle
                .call("schedule", vec![json!(0)], window, cx)
                .expect("authored host call");
            assert_eq!(
                handle
                    .call("completed", vec![], window, cx)
                    .expect("authored host call"),
                json!(0.0)
            );
        })
        .unwrap();
    frames(window, cx);
    window
        .update(cx, |host, window, cx| {
            let handle = host.ordinary.read(cx).handle();
            assert_eq!(
                handle
                    .call("completed", vec![], window, cx)
                    .expect("authored host call"),
                json!(1.0)
            );
            handle
                .call("schedule", vec![json!(5)], window, cx)
                .expect("authored host call");
            handle
                .call("cancel", vec![], window, cx)
                .expect("authored host call");
        })
        .unwrap();
    cx.background_executor
        .advance_clock(Duration::from_millis(10));
    frames(window, cx);
    window
        .update(cx, |host, window, cx| {
            let handle = host.ordinary.read(cx).handle();
            assert_eq!(
                handle
                    .call("completed", vec![], window, cx)
                    .expect("authored host call"),
                json!(1.0)
            );
            handle
                .call("schedule", vec![json!(1.0e30)], window, cx)
                .expect("authored host call");
            assert_eq!(native_resource_counts(&handle.owner)["delays"], json!(1));
            handle.dispose(window, cx).expect("authored host dispose");
            assert_eq!(native_resource_counts(&handle.owner)["delays"], json!(0));
        })
        .unwrap();
    cx.background_executor
        .advance_clock(Duration::from_secs(10));
    frames(window, cx);
}

#[gpui::test]
fn actual_transition_timer_phase_events_and_zero_duration(cx: &mut TestAppContext) {
    let window = open(
        cx,
        json!({"defaultOpen":true,"enterDuration":0,"leaveDuration":0}),
    );
    frames(window, cx);
    window
        .update(cx, |host, window, cx| {
            let handle = host.transition.read(cx).handle();
            assert_eq!(
                handle.state("transitionState").expect("native State read"),
                json!("entered")
            );
            handle
                .call("leave", vec![], window, cx)
                .expect("authored host call");
            assert_eq!(
                handle.state("transitionState").expect("native State read"),
                json!("leaving")
            );
            assert_eq!(event_names(&handle.owner), vec!["beforeLeave"]);
        })
        .unwrap();
    frames(window, cx);
    window
        .update(cx, |host, window, cx| {
            let handle = host.transition.read(cx).handle();
            assert_eq!(
                handle.state("transitionState").expect("native State read"),
                json!("closed")
            );
            assert_eq!(
                handle.state("isPresent").expect("native State read"),
                json!(false)
            );
            handle
                .call("enter", vec![], window, cx)
                .expect("authored host call");
        })
        .unwrap();
    frames(window, cx);
    window
        .update(cx, |host, _, cx| {
            let handle = host.transition.read(cx).handle();
            assert_eq!(
                handle.state("transitionState").expect("native State read"),
                json!("entered")
            );
            assert_eq!(
                event_names(&handle.owner),
                vec!["beforeLeave", "afterLeave", "beforeEnter", "afterEnter"]
            );
        })
        .unwrap();
}

#[gpui::test]
fn source_mutation_changes_actual_generated_machine_behavior(cx: &mut TestAppContext) {
    let window = open(
        cx,
        json!({"defaultOpen":true,"enterDuration":100,"leaveDuration":100}),
    );
    frames(window, cx);
    window
        .update(cx, |host, window, cx| {
            let original = host.transition.read(cx).handle();
            let mutant = host.mutant.read(cx).handle();
            for name in ["leave", "complete", "enter"] {
                original
                    .call(name, vec![], window, cx)
                    .expect("authored host call");
                mutant
                    .call(name, vec![], window, cx)
                    .expect("authored host call");
            }
        })
        .unwrap();
    frames(window, cx);
    window
        .update(cx, |host, window, cx| {
            let original = host.transition.read(cx).handle();
            let mutant = host.mutant.read(cx).handle();
            original
                .call("complete", vec![], window, cx)
                .expect("authored host call");
            mutant
                .call("complete", vec![], window, cx)
                .expect("authored host call");
            assert_eq!(
                original
                    .state("transitionState")
                    .expect("native State read"),
                json!("entered")
            );
            assert_eq!(
                mutant.state("transitionState").expect("native State read"),
                json!("entered")
            );
            assert_eq!(event_names(&original.owner).last().unwrap(), "afterEnter");
            assert_eq!(event_names(&mutant.owner).last().unwrap(), "beforeLeave");
        })
        .unwrap();
}

#[gpui::test]
fn actual_transition_interrupt_policies_and_cold_preparation(cx: &mut TestAppContext) {
    let window = open(
        cx,
        json!({"defaultOpen":true,"enterDuration":50,"leaveDuration":50,"interrupt":"wait"}),
    );
    frames(window, cx);
    window
        .update(cx, |host, window, cx| {
            let handle = host.transition.read(cx).handle();
            handle
                .call("leave", vec![], window, cx)
                .expect("authored host call");
            handle
                .call("enter", vec![], window, cx)
                .expect("authored host call");
            assert_eq!(
                handle.state("transitionState").expect("native State read"),
                json!("leaving")
            );
            handle
                .call("complete", vec![], window, cx)
                .expect("authored host call");
            let cold = host.cold.read(cx).handle();
            cold.call("enter", vec![], window, cx)
                .expect("authored host call");
            assert_eq!(
                cold.state("transitionState").expect("native State read"),
                json!("preparing")
            );
        })
        .unwrap();
    frames(window, cx);
    window
        .update(cx, |host, window, cx| {
            let handle = host.transition.read(cx).handle();
            assert_eq!(
                handle.state("transitionState").expect("native State read"),
                json!("entering")
            );
            let cold = host.cold.read(cx).handle();
            let release = invoke(
                &cold.owner,
                "expose-method",
                &exposed(&cold.owner, "capturePreparation"),
                vec![],
            );
            assert!(!release.nullish());
            release.call(vec![]).expect("public callable result");
            assert_eq!(
                cold.state("transitionState").expect("native State read"),
                json!("entering")
            );
            cold.call("complete", vec![], window, cx)
                .expect("authored host call");
            assert_eq!(
                cold.state("transitionState").expect("native State read"),
                json!("entered")
            );
            cold.call("leave", vec![], window, cx)
                .expect("authored host call");
            cold.call("complete", vec![], window, cx)
                .expect("authored host call");
            release.call(vec![]).expect("public callable result");
            assert_eq!(
                cold.state("transitionState").expect("native State read"),
                json!("closed")
            );
        })
        .unwrap();
}

#[gpui::test]
fn authored_capture_records_privileged_children_and_shared_registration_order(
    cx: &mut TestAppContext,
) {
    let window = open(cx, json!({}));
    frames(window, cx);
    window.update(cx,|host,_,cx|{
        let proof=exposed(&host.scope.read(cx).owner,"builtinCaptureProof").data();
        assert_eq!(proof,json!({"name":"asFocusable","privileged":true,"mode":"once","order":0.0,"afterOrder":2.0,"afterPrivileged":false,"sameRaw":true,"sameHandle":true,"sameGetter":true,"initiallyFocused":false}));
    }).unwrap();
}

#[gpui::test]
fn default_native_focus_scope_and_roving_use_real_handles(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    frames(window, cx);
    for (method, expected_first) in [("first", true), ("next", false), ("next", true)] {
        window
            .update(cx, |host, window, cx| {
                host.scope
                    .read(cx)
                    .handle()
                    .call(method, vec![], window, cx)
                    .expect("authored host call");
                assert_eq!(
                    host.first.focus_handle(cx).is_focused(window),
                    expected_first,
                    "physical focus after {method}"
                );
                assert_eq!(
                    host.second.focus_handle(cx).is_focused(window),
                    !expected_first,
                    "physical focus after {method}"
                );
            })
            .unwrap();
        frames(window, cx);
        window
            .update(cx, |host, _, cx| {
                assert_eq!(
                    host.first
                        .read(cx)
                        .handle()
                        .state("focused")
                        .expect("native State read"),
                    json!(expected_first),
                    "observed focus after {method}"
                );
                assert_eq!(
                    host.second
                        .read(cx)
                        .handle()
                        .state("focused")
                        .expect("native State read"),
                    json!(!expected_first),
                    "observed focus after {method}"
                );
            })
            .unwrap();
    }
    window
        .update(cx, |host, window, cx| {
            host.second
                .read(cx)
                .handle()
                .call("disable", vec![json!(true)], window, cx)
                .expect("authored host call");
            host.scope
                .read(cx)
                .handle()
                .call("last", vec![], window, cx)
                .expect("authored host call");
            assert!(host.first.focus_handle(cx).is_focused(window));
        })
        .unwrap();
}

#[gpui::test]
fn native_focus_draw_notifications_reach_entity_observers(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    let noticed = Rc::new(RefCell::new(Vec::<Json>::new()));
    let observation = window.update(cx, |host, window, cx| {
        let noticed = noticed.clone();
        window.observe(&host.first, cx, move |target, _, cx| {
            noticed.borrow_mut().push(target.read(cx).handle().state("focused").unwrap());
        })
    }).unwrap();
    window.update(cx, |host, window, cx| window.focus(&host.first.focus_handle(cx), cx)).unwrap();
    frames(window, cx);
    window.update(cx, |host, window, cx| {
        assert_eq!(host.first.read(cx).handle().state("focused").unwrap(), json!(true));
        assert_eq!(noticed.borrow().last(), Some(&json!(true)), "native focus is authored state and an observable generated entity change");
        noticed.borrow_mut().clear();
        window.focus(&host.second.focus_handle(cx), cx);
    }).unwrap();
    frames(window, cx);
    window.update(cx, |host, _, cx| {
        assert_eq!(host.first.read(cx).handle().state("focused").unwrap(), json!(false));
        assert_eq!(noticed.borrow().last(), Some(&json!(false)), "a blur in DrawPhase::Focus must wake native output consumers after drawing");
    }).unwrap();
    drop(observation);
}

// This fixture mounts the actual emitted component. It does not recreate
// generated focus subscriptions or call native_press_blur from the host.
struct FocusSubtreeContent {
    first: gpui::FocusHandle,
    second: gpui::FocusHandle,
}
impl Render for FocusSubtreeContent {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        gpui::div().flex().flex_col()
            .child(gpui::div().id("focus-subtree-first").track_focus(&self.first).w(px(96.)).h(px(36.)))
            .child(gpui::div().id("focus-subtree-second").track_focus(&self.second).w(px(96.)).h(px(36.)))
    }
}
struct FocusSubtreeHarness {
    component: Entity<focus_scope::CompiledComponent>,
    first: gpui::FocusHandle,
    second: gpui::FocusHandle,
    outside: gpui::FocusHandle,
    observed: Rc<RefCell<Vec<Json>>>,
    _content: Entity<FocusSubtreeContent>,
    _observation: gpui::Subscription,
}
impl Render for FocusSubtreeHarness {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        gpui::div().size_full().flex()
            .child(self.component.clone())
            .child(gpui::div().id("focus-subtree-outside").track_focus(&self.outside).size(px(40.)))
    }
}
fn focus_subtree_key(window: WindowHandle<FocusSubtreeHarness>, down: bool, cx: &mut TestAppContext) {
    cx.update_window(window.into(), |_, window, cx| {
        let keystroke = gpui::Keystroke::parse("enter").unwrap();
        window.dispatch_event(if down {
            gpui::PlatformInput::KeyDown(gpui::KeyDownEvent {
                keystroke, is_held: false, prefer_character_input: false,
            })
        } else { gpui::PlatformInput::KeyUp(gpui::KeyUpEvent { keystroke }) }, cx);
    }).unwrap();
    cx.run_until_parked();
}

#[gpui::test]
fn generated_root_cancels_a_native_child_press_on_subtree_exit_once(cx: &mut TestAppContext) {
    let window = cx.open_window(size(px(260.), px(120.)), |window, cx| {
        let component = focus_scope::CompiledComponent::create(json!({}), None, window, cx).unwrap();
        let first = cx.focus_handle();
        let second = cx.focus_handle();
        let content = cx.new(|_| FocusSubtreeContent { first: first.clone(), second: second.clone() });
        component.update(cx, |component, cx| {
            component.set_slot(vec![NativeSnapshot::native_view(content.clone().into())], cx).unwrap();
        });
        let observed = Rc::new(RefCell::new(Vec::new()));
        let output = observed.clone();
        let observation = window.observe(&component, cx, move |component, _, cx| {
            output.borrow_mut().push(component.read(cx).handle().state("pressed").unwrap());
        });
        FocusSubtreeHarness {
            component, first, second, outside: cx.focus_handle(), observed,
            _content: content, _observation: observation,
        }
    });
    window.update(cx, |_, window, _| window.activate_window()).unwrap();
    frames(window, cx);
    window.update(cx, |host, window, cx| window.focus(&host.first, cx)).unwrap();
    frames(window, cx);
    window.update(cx, |host, window, cx| {
        let root_focus = host.component.focus_handle(cx);
        assert!(host.first.is_focused(window));
        assert!(root_focus.contains(&host.first, window));
        assert!(!root_focus.is_focused(window), "the generated root never owned direct focus for this gesture");
        host.observed.borrow_mut().clear();
    }).unwrap();
    focus_subtree_key(window, true, cx);
    frames(window, cx);
    window.update(cx, |host, window, cx| {
        let handle = host.component.read(cx).handle();
        assert!(host.first.is_focused(window));
        assert_eq!(handle.state("pressed").unwrap(), json!(true));
        assert_eq!(handle.state("pressStarts").unwrap().as_f64(), Some(1.));
        assert_eq!(handle.state("pressCommits").unwrap().as_f64(), Some(1.));
        assert_eq!(handle.state("pressCancels").unwrap().as_f64(), Some(0.));
        window.focus(&host.second, cx);
    }).unwrap();
    frames(window, cx);
    window.update(cx, |host, window, cx| {
        let handle = host.component.read(cx).handle();
        assert!(host.second.is_focused(window));
        assert_eq!(handle.state("pressed").unwrap(), json!(true), "moving between native descendants stays inside the root");
        assert_eq!(handle.state("pressCancels").unwrap().as_f64(), Some(0.));
        assert_eq!(handle.state("hostBlurs").unwrap().as_f64(), Some(0.));
        host.observed.borrow_mut().clear();
        window.focus(&host.outside, cx);
    }).unwrap();
    frames(window, cx);
    window.update(cx, |host, window, cx| {
        let handle = host.component.read(cx).handle();
        assert!(host.outside.is_focused(window));
        assert!(!host.component.focus_handle(cx).contains_focused(window, cx));
        assert_eq!(handle.state("pressed").unwrap(), json!(false), "leaving the native subtree retires the ancestor press before key-up");
        assert_eq!(handle.state("pressCancels").unwrap().as_f64(), Some(1.));
        assert_eq!(handle.state("pressEnds").unwrap().as_f64(), Some(0.));
        assert_eq!(handle.state("hostBlurs").unwrap().as_f64(), Some(0.), "subtree exit must not invent a direct root blur");
        assert_eq!(host.observed.borrow().last(), Some(&json!(false)), "draw-phase retirement reaches generated-entity observers");
    }).unwrap();
    focus_subtree_key(window, false, cx);
    frames(window, cx);
    window.update(cx, |host, window, cx| {
        let handle = host.component.read(cx).handle();
        assert_eq!(handle.state("pressed").unwrap(), json!(false));
        assert_eq!(handle.state("pressCommits").unwrap().as_f64(), Some(1.));
        assert_eq!(handle.state("pressCancels").unwrap().as_f64(), Some(1.));
        window.focus(&host.component.focus_handle(cx), cx);
    }).unwrap();
    frames(window, cx);
    // Direct root blur and subtree exit now describe the same transition.
    // Both subscriptions may run, but the held lease is consumed only once.
    focus_subtree_key(window, true, cx);
    window.update(cx, |host, window, cx| {
        assert!(host.component.focus_handle(cx).is_focused(window));
        assert_eq!(host.component.read(cx).handle().state("pressed").unwrap(), json!(true));
        window.focus(&host.outside, cx);
    }).unwrap();
    frames(window, cx);
    window.update(cx, |host, _, cx| {
        let handle = host.component.read(cx).handle();
        assert_eq!(handle.state("pressed").unwrap(), json!(false));
        assert_eq!(handle.state("pressCancels").unwrap().as_f64(), Some(2.), "root blur and focus-out cannot cancel the same lease twice");
        assert_eq!(handle.state("hostBlurs").unwrap().as_f64(), Some(1.), "the actual direct root blur remains observable exactly once");
    }).unwrap();
    focus_subtree_key(window, false, cx);
    window.update(cx, |host, _, cx| {
        let handle = host.component.read(cx).handle();
        assert_eq!(handle.state("pressCommits").unwrap().as_f64(), Some(2.));
        assert_eq!(handle.state("pressCancels").unwrap().as_f64(), Some(2.));
    }).unwrap();
}


struct RenderOutputHarness {
    component: Entity<validation::CompiledComponent>,
    pending: Option<u32>,
    observed: Rc<RefCell<Vec<(String, Json)>>>,
    _observation: gpui::Subscription,
}
impl Render for RenderOutputHarness {
    fn render(&mut self, window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
        if let Some(value) = self.pending.take() {
            self.component.read(cx).handle().call("emitOnly", vec![json!(value)], window, cx).unwrap();
        }
        gpui::div().size_full().child(self.component.clone())
    }
}
#[gpui::test]
fn native_rendering_cannot_consume_pending_authored_output_notifications(cx: &mut TestAppContext) {
    let window = cx.open_window(size(px(240.), px(80.)), |window, cx| {
        let component = validation::CompiledComponent::create(json!({}), None, window, cx).unwrap();
        let observed = Rc::new(RefCell::new(Vec::new()));
        let received = observed.clone();
        let observation = cx.observe(&component, move |_: &mut RenderOutputHarness, component, cx| {
            received.borrow_mut().extend(component.read(cx).handle().take_events());
        });
        RenderOutputHarness { component, pending: None, observed, _observation: observation }
    });
    frames(window, cx);
    for next in [1, 2] {
        window.update(cx, |host, _, cx| { host.pending = Some(next); cx.notify(); }).unwrap();
        frames(window, cx);
        window.update(cx, |host, _, cx| {
            let expected: Vec<_> = (1..=next).map(|value| ("renderRequest".into(), json!({"value": f64::from(value)}))).collect();
            assert_eq!(*host.observed.borrow(), expected, "drawing the generated child cannot swallow a pending event-only change from its native parent");
            assert!(host.component.read(cx).handle().take_events().is_empty(), "the observer drains each output once");
        }).unwrap();
    }
    frames(window, cx);
    window.update(cx, |host, _, _| assert_eq!(host.observed.borrow().len(), 2, "later renders cannot replay delivered output")).unwrap();
}

struct CommitOutputHarness {
    component: Entity<validation::CompiledComponent>,
    notifications: usize,
    raw_notifications: usize,
    observed: Vec<(String, Json)>,
    failures: Vec<proto_ui_gpui_native::gpui_native_owner::NativeFailure>,
    _observation: gpui::Subscription,
}
impl Render for CommitOutputHarness {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        gpui::div().size_full().child(self.component.clone())
    }
}
fn commit_output_window(cx: &mut TestAppContext, phase: &str) -> WindowHandle<CommitOutputHarness> {
    cx.open_window(size(px(240.), px(80.)), |window, cx| {
        let component = validation::CompiledComponent::create(
            json!({"notificationPhase": phase}), None, window, cx,
        ).unwrap();
        let observation = cx.observe(&component, |host: &mut CommitOutputHarness, component, cx| {
            host.raw_notifications += 1;
            let handle = component.read(cx).handle();
            let events = handle.take_events();
            let failures = handle.take_failures();
            // Props may produce an independent notification before painting.
            // Count deliveries that actually carry authored output.
            if !events.is_empty() || !failures.is_empty() { host.notifications += 1; }
            host.observed.extend(events);
            host.failures.extend(failures);
        });
        CommitOutputHarness {
            component, notifications: 0, raw_notifications: 0, observed: Vec::new(), failures: Vec::new(),
            _observation: observation,
        }
    })
}
fn assert_commit_output(
    window: WindowHandle<CommitOutputHarness>, cx: &mut TestAppContext,
    phase: &str, previous_notifications: usize,
) {
    let (revision, raw_notifications) = window.update(cx, |host, _, cx| {
        assert_eq!(host.notifications, previous_notifications + 1,
            "the failing commit must itself wake the retained parent without another frame or input");
        assert_eq!(host.observed, vec![("renderRequest".into(), json!({"phase": phase}))],
            "the published event is delivered once and later lifecycle callbacks remain stopped");
        assert_eq!(host.failures.len(), 1);
        assert_eq!(host.failures[0].phase, "commit");
        assert!(strict_equal(&host.failures[0].error, &Value::boolean(false)),
            "notification preserves the exact falsy lifecycle error");
        let component = host.component.read(cx);
        let owner = component.owner.borrow();
        assert!(owner.mounted && owner.present && !owner.disposed);
        assert!(!owner.pending_native_events && !owner.update_requested);
        assert_eq!(owner.committed_revision, owner.projection_revision);
        assert!(owner.emitted.is_empty(), "the real parent observer consumed the event");
        let revision = owner.projection_revision;
        drop(owner);
        assert!(component.handle().take_failures().is_empty(),
            "the real parent observer consumed the failure through the public handle");
        (revision, host.raw_notifications)
    }).unwrap();
    // Subsequent ordinary frames must neither retry the failed lifecycle list
    // nor keep notifying from its now-drained event queue.
    frames(window, cx);
    window.update(cx, |host, _, cx| {
        assert_eq!(host.notifications, previous_notifications + 1);
        assert_eq!(host.raw_notifications, raw_notifications,
            "later paints cannot keep waking the parent with empty notifications");
        assert_eq!(host.observed.len(), 1);
        assert_eq!(host.failures.len(), 1);
        let component = host.component.read(cx);
        let owner = component.owner.borrow();
        assert_eq!(owner.projection_revision, revision,
            "event delivery does not request an authored projection");
        assert!(!owner.pending_native_events && !owner.update_requested);
        assert!(owner.emitted.is_empty());
        drop(owner);
        assert!(component.handle().take_failures().is_empty());
    }).unwrap();
}

#[gpui::test]
fn native_mounted_emit_then_throw_false_notifies_parent_without_another_input(cx: &mut TestAppContext) {
    // TestAppContext opens and paints the initial window itself. Do not add
    // another manual draw that could mask a missing post-commit wakeup.
    let window = commit_output_window(cx, "mounted");
    cx.run_until_parked();
    assert_commit_output(window, cx, "mounted", 0);
}

#[gpui::test]
fn native_updated_emit_then_throw_false_notifies_parent_without_another_input(cx: &mut TestAppContext) {
    let window = commit_output_window(cx, "");
    cx.run_until_parked();
    let before = window.update(cx, |host, window, cx| {
        assert!(host.component.read(cx).owner.borrow().mounted);
        assert!(host.observed.is_empty() && host.failures.is_empty());
        let before = host.notifications;
        host.component.update(cx, |component, cx| {
            component.set_props(
                json!({"notificationPhase": "updated", "notificationRevision": 1}), window, cx,
            ).unwrap();
        });
        before
    }).unwrap();
    // The scheduled native frame owns the update. Observe its completed
    // notification cycle before requesting any extra frame or physical input.
    cx.run_until_parked();
    assert_commit_output(window, cx, "updated", before);
}

#[gpui::test]
fn public_callable_results_preserve_alias_scope_and_terminal_lifetime(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    frames(window, cx);
    window
        .update(cx, |host, window, cx| {
            let handle = host.ordinary.read(cx).handle();
            assert!(strict_equal(
                &exposed(&handle.owner, "controls"),
                &exposed(&handle.owner, "controlsAlias")
            ));
            let callback = exposed(&handle.owner, "returnFunction")
                .call(vec![])
                .expect("public callable result");
            let returned = exposed(&handle.owner, "returnControls")
                .call(vec![])
                .expect("public callable result");
            assert!(strict_equal(
                &returned,
                &exposed(&handle.owner, "returnControls")
                    .call(vec![])
                    .expect("public callable result")
            ));
            assert_eq!(
                callback.call(vec![]).expect("public callable result").num(),
                1.
            );
            assert_eq!(
                returned
                    .member("increment", false)
                    .call(vec![])
                    .expect("public callable result")
                    .num(),
                2.
            );
            let refreshed = exposed(&handle.owner, "returnControls")
                .call(vec![])
                .expect("public callable result");
            assert!(strict_equal(&returned, &refreshed));
            assert!(strict_equal(
                &returned.member("increment", false),
                &refreshed.member("increment", false)
            ));
            assert_eq!(refreshed.member("value", false).num(), 2.);
            let pure = exposed(&handle.owner, "returnPure")
                .call(vec![])
                .expect("public callable result");
            assert_eq!(
                pure.call(vec![]).expect("public callable result").num(),
                42.
            );
            handle.dispose(window, cx).expect("authored host dispose");
            for callback in [callback, pure, returned.member("increment", false)] {
                assert_eq!(
                    callback
                        .call(vec![])
                        .unwrap_err()
                        .member("code", false)
                        .text(),
                    "OWNER_DISPOSED"
                );
            }
        })
        .unwrap();
}

#[gpui::test]
fn borrowed_state_notifications_snapshot_registrations_and_drain_after_falsy_failure(
    cx: &mut TestAppContext,
) {
    let window = open(cx, json!({}));
    frames(window, cx);
    window
        .update(cx, |host, window, cx| {
            let handle = host.ordinary.read(cx).handle();
            let failure = handle
                .call("write", vec![json!(1)], window, cx)
                .unwrap_err();
            assert_eq!(failure.num(), 0.);
            assert_eq!(
                handle.state("watched").expect("native State read"),
                json!(2.0)
            );
            assert_eq!(
                handle
                    .call("watchTrace", vec![], window, cx)
                    .expect("authored host call"),
                json!("a1,b1,a2,b2,")
            );
            handle
                .call("write", vec![json!(3)], window, cx)
                .expect("authored host call");
            assert_eq!(
                handle
                    .call("watchTrace", vec![], window, cx)
                    .expect("authored host call"),
                json!("a1,b1,a2,b2,a3,b3,")
            );
            // The typed public entry uses the same default Result boundary.
            let typed = host.other.read(cx).handle();
            assert_eq!(typed.method_0(1., window, cx).unwrap_err().num(), 0.);
            assert_eq!(
                typed.state("watched").expect("native State read"),
                json!(2.0)
            );
        })
        .unwrap();
}

#[gpui::test]
fn context_channels_preserve_nested_order_cancellation_and_aggregate_failures(
    cx: &mut TestAppContext,
) {
    let window = open(cx, json!({}));
    frames(window, cx);
    window
        .update(cx, |host, window, cx| {
            let handle = host.ordinary.read(cx).handle();
            // No caller-owned unwind guard: the default public API returns its
            // authored Result before crossing GPUI's Entity lease boundary.
            let failure = host
                .ordinary
                .update(cx, |view, cx| {
                    view.set_props(json!({"contextWrite":1}), window, cx)
                })
                .unwrap_err();
            assert_eq!(failure.num(), 0.);
            assert!(!host.ordinary.read(cx).owner.borrow().disposed);
            assert_eq!(
                handle
                    .call("contextTrace", vec![], window, cx)
                    .expect("authored host call"),
                json!("a1,x1,b1,a2,b2,")
            );
            let failure = host
                .ordinary
                .update(cx, |view, cx| {
                    view.set_props(json!({"contextWrite":5}), window, cx)
                })
                .unwrap_err();
            assert_eq!(failure.member("name", false).text(), "AggregateError");
            let errors = failure.member("errors", false).items();
            assert_eq!(errors.len(), 2);
            assert_eq!(errors[0].num(), 0.);
            assert!(!errors[1].bool());
            host.ordinary.update(cx, |view, cx| {
                view.set_props(json!({"contextWrite":3}), window, cx)
                    .expect("authored host set_props")
            });
            host.ordinary.update(cx, |view, cx| {
                view.set_props(json!({"contextWrite":4}), window, cx)
                    .expect("authored host set_props")
            });
            assert_eq!(
                handle
                    .call("contextTrace", vec![], window, cx)
                    .expect("authored host call"),
                json!("a1,x1,b1,a2,b2,a5,b5,a3,a4,")
            );
        })
        .unwrap();
}

#[gpui::test]
fn unmounted_callbacks_cannot_rearm_delay_even_when_they_throw(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    frames(window, cx);
    let mut retained = Vec::new();
    window
        .update(cx, |host, window, cx| {
            host.ordinary.update(cx, |view, cx| {
                view.set_props(json!({"present":false,"rearmOnUnmount":true}), window, cx)
                    .expect("authored host set_props")
            });
            host.other.update(cx, |view, cx| {
                view.set_props(
                    json!({"rearmOnUnmount":true,"throwUnmount":true}),
                    window,
                    cx,
                )
                .expect("authored host set_props")
            });
            let throwing = host.other.read(cx).owner.clone();
            let thrown = catch_authored(|| detach_native_view(&throwing)).unwrap_err();
            assert_eq!(thrown.num(), 0.);
            for owner in [&host.ordinary.read(cx).owner, &throwing] {
                retained.push(exposed(owner, "lifecycle"));
            }
            assert_eq!(native_resource_counts(&throwing)["delays"], json!(0));
            host.other.update(cx, |view, cx| {
                view.set_props(json!({"present":false}), window, cx)
                    .expect("authored host set_props")
            });
        })
        .unwrap();
    frames(window, cx);
    cx.background_executor
        .advance_clock(Duration::from_millis(10));
    frames(window, cx);
    for value in retained {
        assert_eq!(value.member("delayed", false).num(), 0.);
    }
}

#[gpui::test]
fn throwing_before_dispose_retires_resources_and_preserves_falsy_failure(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    frames(window, cx);
    window
        .update(cx, |host, window, cx| {
            host.ordinary.update(cx, |view, cx| {
                view.set_props(json!({"failDispose":true}), window, cx)
                    .expect("authored host set_props")
            });
            let handle = host.ordinary.read(cx).handle();
            let observations = exposed(&handle.owner, "lifecycle");
            let pure = exposed(&handle.owner, "returnPure")
                .call(vec![])
                .expect("public callable result");
            handle
                .call("schedule", vec![json!(100)], window, cx)
                .expect("authored host call");
            let failure = handle.dispose(window, cx).unwrap_err();
            assert_eq!(failure.num(), 0.);
            assert!(handle.owner.borrow().disposed);
            assert_eq!(
                handle.call_data_method("decide", vec![None, Some(json!(3))])
                    .unwrap_err().member("code", false).text(),
                "OWNER_DISPOSED"
            );
            assert_eq!(observations.member("first", false).num(), 1.);
            assert_eq!(observations.member("second", false).num(), 0.);
            let resources = host.ordinary.read(cx).native_resource_counts();
            for key in [
                "states",
                "hooks",
                "listeners",
                "stateWatchers",
                "contextSubscriptions",
                "delays",
                "metadataKeys",
                "schedulerBindings",
                "presenceOwners",
                "nativeSubscriptions",
            ] {
                assert_eq!(resources[key], json!(0), "{key}");
            }
            assert_eq!(
                pure.call(vec![]).unwrap_err().member("code", false).text(),
                "OWNER_DISPOSED"
            );
        })
        .unwrap();
}

#[gpui::test]
fn independent_crates_with_identical_context_source_ids_remain_private(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    frames(window, cx);
    window
        .update(cx, |host, _, cx| {
            let key = |owner: &OwnerRef| {
                Value::ContextKey(owner.borrow().providers.keys().next().unwrap().clone())
            };
            let first = key(&host.context_a.read(cx).owner);
            let same_module = key(&host.context_other.read(cx).owner);
            let independent = key(&host.context_b.read(cx).owner);
            assert!(strict_equal(&first, &same_module));
            assert!(!strict_equal(&first, &independent));
            let family = |owner: &OwnerRef| {
                Value::StaticCapability(
                    owner
                        .borrow()
                        .modules
                        .topology
                        .claims
                        .values()
                        .find(|claim| claim.family.id != TABLE_STRUCTURE_FAMILY.id)
                        .unwrap()
                        .family,
                )
            };
            let first = family(&host.context_a.read(cx).owner);
            assert!(strict_equal(
                &first,
                &family(&host.context_other.read(cx).owner)
            ));
            assert!(!strict_equal(
                &first,
                &family(&host.context_b.read(cx).owner)
            ));
            assert!(!strict_equal(
                &first,
                &family(&host.context_child.read(cx).owner)
            ));
            let shared = Value::StaticCapability(&TABLE_STRUCTURE_FAMILY);
            for owner in [
                &host.context_a.read(cx).owner,
                &host.context_b.read(cx).owner,
                &host.context_child.read(cx).owner,
            ] {
                let bound = Value::StaticCapability(
                    owner
                        .borrow()
                        .modules
                        .topology
                        .claims
                        .values()
                        .find(|claim| claim.family.id == TABLE_STRUCTURE_FAMILY.id)
                        .unwrap()
                        .family,
                );
                assert!(strict_equal(&shared, &bound));
            }
            assert_eq!(
                host.context_child
                    .read(cx)
                    .handle()
                    .state("value")
                    .expect("native State read"),
                json!(-1.0)
            );
        })
        .unwrap();
}

#[gpui::test]
fn unsupported_physical_focus_cannot_be_enabled_through_manual_sdk(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    frames(window, cx);
    window
        .update(cx, |host, _, cx| {
            let owner = host.plain.read(cx).owner.clone();
            let weak = Rc::downgrade(&owner);
            owner.borrow_mut().phase = "setup";
            assert!(catch_unwind(AssertUnwindSafe(|| focus_setup(&weak, "focus-entry"))).is_err());
            assert!(catch_unwind(AssertUnwindSafe(|| focus_setup_config(
                &weak,
                "focus-scope",
                record(vec![("entryFallback", Value::string("entry"))])
            )))
            .is_err());
            owner.borrow_mut().phase = "idle";
            assert!(owner.borrow().modules.hooks.is_empty());
            // Disposal is an ordinary native ownership operation and does not need
            // the unavailable physical focus-tree interface.
            Owner::dispose(&owner);
            assert!(owner.borrow().disposed);
            assert!(
                catch_authored(|| exposed(&host.ordinary.read(cx).owner, "caughtIdentity")
                    .call(vec![])
                    .expect("public callable result"))
                .is_ok()
            );
        })
        .unwrap();
}

#[gpui::test]
fn duplicate_expose_keys_fail_during_actual_generated_setup_and_manual_sdk(
    cx: &mut TestAppContext,
) {
    let window = open(cx, json!({}));
    frames(window, cx);
    let before = window
        .update(cx, |host, window, cx| {
            let before = native_owner_allocation_count();
            let failure = duplicate::CompiledComponent::create(json!({}), None, window, cx)
                .err()
                .expect("duplicate setup must fail");
            assert_eq!(failure.member("code", false).text(), "EXPOSE_DUPLICATE");
            let failure = created_failure::CompiledComponent::create(json!({}), None, window, cx)
                .err()
                .expect("created callback must fail");
            assert_eq!(failure.num(), 0.);
            let next = plain::CompiledComponent::create(json!({}), None, window, cx)
                .expect("host can create another entity after both failures");
            assert!(!next.read(cx).owner.borrow().disposed);
            assert_eq!(
                host.ordinary
                    .read(cx)
                    .handle()
                    .call("forward", vec![], window, cx)
                    .expect("prior entity remains usable"),
                json!("later")
            );
            let vocabulary = host.plain.read(cx).owner.borrow().style_vocabulary;
            let owner = Owner::new(
                json!({}),
                Default::default(),
                |_, _| true,
                |_| true,
                |_, _| true,
                vocabulary,
            );
            let weak = Rc::downgrade(&owner);
            expose_value(&weak, Value::string("same"), Value::number(1.));
            for operation in [0, 1, 2] {
                let failure = catch_authored(|| match operation {
                    0 => expose_value(&weak, Value::string("same"), Value::number(2.)),
                    1 => expose_method(
                        &weak,
                        Value::string("same"),
                        Value::Function(Rc::new(|_| Value::Undefined)),
                    ),
                    _ => expose_event(&weak, Value::string("same")),
                })
                .err()
                .expect("duplicate registration must fail");
                assert_eq!(failure.member("code", false).text(), "EXPOSE_DUPLICATE");
            }
            let failure =
                catch_authored(|| expose_value(&weak, Value::string(""), Value::number(1.)))
                    .err()
                    .expect("empty expose key must fail");
            assert_eq!(failure.member("code", false).text(), "EXPOSE_KEY_INVALID");
            Owner::dispose(&owner);
            before
        })
        .unwrap();
    frames(window, cx);
    // GPUI releases the rejected insertion and the successful temporary entity
    // at its host turn boundary. None may retain a native owner after that turn.
    assert_eq!(native_owner_allocation_count(), before);
}

#[gpui::test]
fn input_control_expires_at_callback_return_and_unwind(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    frames(window, cx);
    window
        .update(cx, |host, window, cx| {
            for (target, throws) in [(&host.first, false), (&host.second, true)] {
                let handle = target.read(cx).handle();
                let mut fields = event_fields("key.down");
                fields.insert("key".into(), json!(if throws { "throw" } else { "normal" }));
                assert!(dispatch(&handle.owner, "key.down", false, fields));
                let failures = handle.take_failures();
                assert_eq!(failures.len(), usize::from(throws));
                if throws {
                    assert_eq!(failures[0].error.num(), 0.);
                }
                assert!(!target.read(cx).owner.borrow().disposed);
                dispatch(&handle.owner, "key.up", false, event_fields("key.up"));
                assert_eq!(
                    handle
                        .call("expiredInputRejected", vec![], window, cx)
                        .expect("authored host call"),
                    json!(true)
                );
            }
        })
        .unwrap();
}

#[gpui::test]
fn actual_host_keyboard_failure_reports_exact_value_without_retiring_entity(
    cx: &mut TestAppContext,
) {
    let window = open(cx, json!({}));
    window
        .update(cx, |host, window, cx| {
            host.first
                .read(cx)
                .handle()
                .call("focus", vec![], window, cx)
                .expect("focus native target");
        })
        .unwrap();
    frames(window, cx);
    // Real GPUI key routing runs the generated native callback under its own
    // host lease, with no test-owned catch_authored or manually dispatched event.
    cx.simulate_keystrokes(window.into(), "t");
    window
        .update(cx, |host, window, cx| {
            window.dispatch_event(
                gpui::PlatformInput::KeyUp(gpui::KeyUpEvent {
                    keystroke: gpui::Keystroke::parse("t").unwrap(),
                }),
                cx,
            );
            let handle = host.first.read(cx).handle();
            let failures = handle.take_failures();
            assert_eq!(failures.len(), 1);
            assert_eq!(failures[0].phase, "key.down");
            assert_eq!(failures[0].error.num(), 0.);
            assert!(!handle.owner.borrow().disposed);
            assert_eq!(
                handle
                    .call("expiredInputRejected", vec![], window, cx)
                    .expect("next key callback"),
                json!(true)
            );
        })
        .unwrap();
    cx.simulate_keystrokes(window.into(), "n");
    window
        .update(cx, |host, window, cx| {
            let handle = host.first.read(cx).handle();
            assert!(handle.take_failures().is_empty());
            assert_eq!(
                handle
                    .call("expiredInputRejected", vec![], window, cx)
                    .expect("entity remains callable"),
                json!(true)
            );
        })
        .unwrap();
}

#[gpui::test]
fn state_validation_uses_authored_errors_without_unwinding_native_entities(
    cx: &mut TestAppContext,
) {
    let window = open(cx, json!({}));
    window
        .update(cx, |_, window, cx| {
            let entity = validation::CompiledComponent::create(json!({}), None, window, cx)
                .expect("validation fixture construction");
            let attempt = entity.update(cx, |view, cx| {
                view.handle().call("attempt", vec![], window, cx)
            });
            assert_eq!(
                attempt.expect("source try/catch catches State validation"),
                json!(true)
            );
            let handle = entity.read(cx).handle();
            assert_eq!(handle.call("read", vec![], window, cx).unwrap(), json!(0.0));
            let failure = entity
                .update(cx, |view, cx| {
                    view.handle().call("invalid", vec![], window, cx)
                })
                .expect_err("uncaught validation reaches the native Result boundary");
            assert_eq!(failure.member("name", false).text(), "Error");
            assert_eq!(handle.call("read", vec![], window, cx).unwrap(), json!(0.0));
            assert_eq!(
                handle.call("valid", vec![], window, cx).unwrap(),
                json!(1.0)
            );
            assert!(!entity.read(cx).owner.borrow().disposed);
            let retry = validation_retry::CompiledComponent::create(json!({}), None, window, cx)
                .expect("failed validation cannot reserve the State name");
            let retry_handle = retry.read(cx).handle();
            assert_eq!(retry_handle.value_0().unwrap().data(), json!(true));
            assert_eq!(retry_handle.state_1().unwrap(), 0.);
        })
        .unwrap();
}

#[gpui::test]
fn invalid_native_inputs_return_errors_and_leave_entities_usable(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    window
        .update(cx, |host, window, cx| {
            let failure = plain::CompiledComponent::create(json!([]), None, window, cx)
                .err()
                .expect("invalid raw construction props must return an error");
            assert_eq!(failure.member("name", false).text(), "TypeError");
            let entity =
                validation::CompiledComponent::create(json!({}), None, window, cx).unwrap();
            let handle = entity.read(cx).handle();
            let bad_arguments = entity.update(cx, |view, cx| {
                view.handle().call("valid", vec![json!(1)], window, cx)
            });
            assert_eq!(
                bad_arguments.unwrap_err().member("name", false).text(),
                "TypeError"
            );
            assert_eq!(handle.call("read", vec![], window, cx).unwrap(), json!(0.0));
            let unknown = entity.update(cx, |view, cx| {
                view.handle().call("absent", vec![], window, cx)
            });
            assert_eq!(unknown.unwrap_err().member("name", false).text(), "Error");
            assert_eq!(
                handle
                    .state("absent")
                    .unwrap_err()
                    .member("name", false)
                    .text(),
                "Error"
            );
            let bad_props = entity.update(cx, |view, cx| view.set_props(json!([]), window, cx));
            assert_eq!(
                bad_props.unwrap_err().member("name", false).text(),
                "TypeError"
            );
            let bad_slot = entity.update(cx, |view, cx| {
                view.set_slot(vec![NativeSnapshot::slot()], cx)
            });
            assert_eq!(bad_slot.unwrap_err().member("name", false).text(), "Error");
            assert!(entity.read(cx).owner.borrow().slot.is_empty());
            assert_eq!(
                handle.call("valid", vec![], window, cx).unwrap(),
                json!(1.0)
            );
            assert!(!entity.read(cx).owner.borrow().disposed);
            assert!(handle.host_target().is_ok());
            handle.dispose(window, cx).unwrap();
            assert_eq!(
                handle
                    .host_target()
                    .unwrap_err()
                    .member("code", false)
                    .text(),
                "OWNER_DISPOSED"
            );
            let plain = host.plain.read(cx).handle();
            assert_eq!(plain.value_0().unwrap().member("tag", false).num(), 7.);
            plain.dispose(window, cx).unwrap();
            assert_eq!(
                plain.value_0().unwrap_err().member("code", false).text(),
                "OWNER_DISPOSED"
            );
        })
        .unwrap();
}

#[gpui::test]
fn public_values_keep_identity_when_returned_through_the_same_owner(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    window
        .update(cx, |_, window, cx| {
            let entity = roundtrip::CompiledComponent::create(json!({}), None, window, cx).unwrap();
            let handle = entity.read(cx).handle();
            let record = entity
                .update(cx, |view, cx| view.handle().method_0(window, cx))
                .unwrap();
            let echoed = entity
                .update(cx, |view, cx| {
                    view.handle().method_1(record.clone(), window, cx)
                })
                .unwrap();
            assert!(
                strict_equal(&record, &echoed),
                "public record echo must keep its identity"
            );
            let action = record.member("action", false);
            assert!(strict_equal(&action, &echoed.member("action", false)));
            assert_eq!(action.call(vec![]).unwrap().num(), 7.);
            let callback = handle.method_2(window, cx).unwrap();
            let echoed_callback = handle.method_3(callback.clone(), window, cx).unwrap();
            assert!(
                strict_equal(&callback, &echoed_callback),
                "public callable echo must keep its identity"
            );
            assert_eq!(echoed_callback.call(vec![]).unwrap().num(), 7.);
            handle.dispose(window, cx).unwrap();
            for callback in [action, callback, echoed_callback] {
                assert_eq!(
                    callback
                        .call(vec![])
                        .unwrap_err()
                        .member("code", false)
                        .text(),
                    "OWNER_DISPOSED"
                );
            }
        })
        .unwrap();
}

#[gpui::test]
fn replaced_members_of_public_records_receive_the_owner_lifetime_guard(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    window
        .update(cx, |_, window, cx| {
            let entity =
                public_mutation::CompiledComponent::create(json!({}), None, window, cx).unwrap();
            let handle = entity.read(cx).handle();
            let record = handle.method_0(window, cx).unwrap();
            let first_action = record.member("action", false);
            let returned = handle.method_1(record.clone(), window, cx).unwrap();
            assert!(strict_equal(&record, &returned));
            let action = returned.member("action", false);
            assert!(!strict_equal(&first_action, &action));
            assert_eq!(action.call(vec![]).unwrap().num(), 9.);
            handle.dispose(window, cx).unwrap();
            assert_eq!(
                action
                    .call(vec![])
                    .unwrap_err()
                    .member("code", false)
                    .text(),
                "OWNER_DISPOSED"
            );
            assert_eq!(
                first_action
                    .call(vec![])
                    .unwrap_err()
                    .member("code", false)
                    .text(),
                "OWNER_DISPOSED"
            );
        })
        .unwrap();
}

#[gpui::test]
fn scalar_conversion_matches_the_ecmascript_operator_reference(cx: &mut TestAppContext) {
    // JavaScript has one Number domain. serde_json's integer-versus-float
    // storage tag is not an authored distinction; compare Node's exact bits.
    fn matches_reference(actual: &Json, expected: &Json, bits: &Json) -> bool {
        match expected {
            Json::Number(_) => actual.as_f64().is_some_and(|value| {
                bits.as_str().and_then(|bits| u64::from_str_radix(bits, 16).ok()) == Some(value.to_bits())
            }),
            Json::Array(items) => actual.as_array().is_some_and(|values| {
                values.len() == items.len() && values.iter().zip(items).enumerate()
                    .all(|(index, (value, item))| matches_reference(value, item, &bits[index]))
            }),
            Json::Object(fields) => actual.as_object().is_some_and(|values| {
                values.len() == fields.len() && fields.iter().all(|(key, value)| {
                    values.get(key).is_some_and(|actual| matches_reference(actual, value, &bits[key]))
                })
            }),
            _ => actual == expected,
        }
    }
    assert!(matches_reference(&json!(1.0), &json!(1), &json!("3ff0000000000000")));
    assert!(!matches_reference(&json!(1.5), &json!(1), &json!("3ff0000000000000")));
    assert!(!matches_reference(&json!(0.0), &json!(0), &json!("8000000000000000")));
    let reference: Json = serde_json::from_str(include_str!("scalar-reference.json")).unwrap();
    let window = open(cx, json!({}));
    window
        .update(cx, |_, window, cx| {
            let entity = scalars::CompiledComponent::create(json!({}), None, window, cx).unwrap();
            let handle = entity.read(cx).handle();
            let mut failures = Vec::new();
            for case in reference["strings"].as_array().unwrap() {
                let input = case["input"].clone();
                let actual = handle
                    .call("probe", vec![input.clone()], window, cx)
                    .unwrap();
                let expected = &case["expected"];
                let numeric_equal = if expected["number"].is_null() {
                    actual["number"].is_null()
                } else {
                    actual["number"].as_f64().unwrap().to_bits()
                        == u64::from_str_radix(case["numberBits"].as_str().unwrap(), 16).unwrap()
                };
                if !numeric_equal
                    || ["finite", "nan", "negativeZero", "text"]
                        .iter()
                        .any(|key| actual[key] != expected[key])
                {
                    failures.push(format!("{input}: expected {expected}, actual {actual}"));
                }
            }
            let texts = handle.call("arithmeticTexts", vec![], window, cx).unwrap();
            if texts != reference["arithmeticTexts"] {
                failures.push(format!(
                    "arithmetic text: expected {}, actual {texts}",
                    reference["arithmeticTexts"]
                ));
            }
            for case in reference["nativeCases"].as_array().unwrap() {
                let method = case["method"].as_str().unwrap();
                let actual = handle.call(method, vec![], window, cx).unwrap();
                if !matches_reference(&actual, &case["expected"], &case["numberBits"]) {
                    failures.push(format!("{method}: expected {}, actual {actual}", case["expected"]));
                }
            }
            assert!(failures.is_empty(), "{}", failures.join("\n"));
        })
        .unwrap();
}

#[gpui::test]
fn pending_and_failed_once_hooks_preserve_the_core_registration_result(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    window
        .update(cx, |_, window, cx| {
            let pending = hook_pending::CompiledComponent::create(json!({}), None, window, cx)
                .expect(
                    "same-name pending installation returns fallback without rerunning a loser",
                );
            for key in [
                "initialDistinct",
                "initialTruthy",
                "nestedSame",
                "completeSame",
                "postShadowSame",
                "postShadowWinner",
                "childInstalled",
            ] {
                assert!(
                    exposed(&pending.read(cx).owner, key).bool(),
                    "pending proof {key}"
                );
            }
            assert!(!pending
                .read(cx)
                .owner
                .borrow()
                .exposes
                .contains_key("loser"));
            let failed =
                hook_failed::CompiledComponent::create(json!({}), None, window, cx).unwrap();
            for key in ["attempted", "caught", "freshFallback", "truthyFallback"] {
                assert!(
                    exposed(&failed.read(cx).owner, key).bool(),
                    "failed proof {key}"
                );
            }
            let undefined =
                hook_undefined::CompiledComponent::create(json!({}), None, window, cx).unwrap();
            for key in ["undefinedFirst", "undefinedAgain"] {
                assert!(
                    exposed(&undefined.read(cx).owner, key).bool(),
                    "undefined projection proof {key}"
                );
            }
            let projected =
                hook_project_failed::CompiledComponent::create(json!({}), None, window, cx)
                    .unwrap();
            for key in ["caught", "retainedRawCapture", "truthyCapture"] {
                assert!(
                    exposed(&projected.read(cx).owner, key).bool(),
                    "failed projection proof {key}"
                );
            }
        })
        .unwrap();
}

#[gpui::test]
fn callable_hook_options_capture_the_current_installation_frame(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    window
        .update(cx, |_, window, cx| {
            let direct =
                hook_options::CompiledComponent::create(json!({}), None, window, cx).unwrap();
            assert!(exposed(&direct.read(cx).owner, "flagValue").bool());
            let handle = direct.read(cx).handle();
            assert_eq!(
                handle.call("readFlag", vec![], window, cx).unwrap(),
                json!(true)
            );
            let factory =
                hook_options_factory::CompiledComponent::create(json!({}), None, window, cx)
                    .unwrap();
            assert!(exposed(&factory.read(cx).owner, "flagValue").bool());
            let handle = factory.read(cx).handle();
            assert_eq!(
                handle.call("readFlag", vec![], window, cx).unwrap(),
                json!(true)
            );
            let multiple =
                hook_options_multiple::CompiledComponent::create(json!({}), None, window, cx)
                    .unwrap();
            let owner = &multiple.read(cx).owner;
            assert!(exposed(owner, "first").bool());
            assert_eq!(exposed(owner, "second").num(), 2.);
            assert!(!exposed(owner, "firstLeaksSecond").bool());
            assert!(!exposed(owner, "secondLeaksFirst").bool());
            let nested =
                hook_options_nested::CompiledComponent::create(json!({}), None, window, cx)
                    .unwrap();
            let owner = &nested.read(cx).owner;
            assert!(!exposed(owner, "outerLeaksState").bool());
            assert!(exposed(owner, "innerState").bool());
        })
        .unwrap();
}

#[gpui::test]
fn conditional_hook_installation_keeps_each_possible_first_callback(cx: &mut TestAppContext) {
    let window = open(cx, json!({}));
    window
        .update(cx, |_, window, cx| {
            let skipped =
                hook_conditional::CompiledComponent::create(json!({}), None, window, cx).unwrap();
            let handle = skipped.read(cx).handle();
            assert_eq!(
                handle.call("read", vec![], window, cx).unwrap().as_f64(),
                Some(1.)
            );
            let taken =
                hook_conditional_taken::CompiledComponent::create(json!({}), None, window, cx)
                    .unwrap();
            let handle = taken.read(cx).handle();
            assert_eq!(
                handle.call("read", vec![], window, cx).unwrap().as_f64(),
                Some(0.)
            );
            let entity =
                hook_conditional_multiple::CompiledComponent::create(json!({}), None, window, cx)
                    .unwrap();
            let handle = entity.read(cx).handle();
            assert_eq!(
                handle.call("read", vec![], window, cx).unwrap().as_f64(),
                Some(1.)
            );
        })
        .unwrap();
}

#[gpui::test]
fn later_public_mutation_reaches_the_next_native_render(cx: &mut TestAppContext) {
    let window = cx.open_window(size(px(600.), px(400.)), |window, cx| {
        render_mutation::CompiledComponent::new(json!({}), None, window, cx).unwrap()
    });
    for _ in 0..3 {
        cx.update_window(window.into(), |_, window, cx| {
            window.refresh();
            window.draw(cx).clear(cx);
        })
        .unwrap();
        cx.run_until_parked();
    }
    window
        .update(cx, |view, window, cx| {
            {
                let owner = view.owner.borrow();
                assert_eq!(
                    proto_ui_gpui_native::gpui_native_owner::text_content(
                        &owner.projection,
                        &owner.slot
                    ),
                    "1"
                );
            }
            view.handle().call("replace", vec![], window, cx).unwrap();
            // This profile uses explicit updates. The authored Props watcher requests
            // the next render through run.update; the consumer changes normal Props.
            view.set_props(json!({"tick":1}), window, cx).unwrap();
        })
        .unwrap();
    for _ in 0..3 {
        cx.update_window(window.into(), |_, window, cx| {
            window.refresh();
            window.draw(cx).clear(cx);
        })
        .unwrap();
        cx.run_until_parked();
    }
    window
        .update(cx, |view, _, _| {
            {
                let owner = view.owner.borrow();
                assert_eq!(
                    proto_ui_gpui_native::gpui_native_owner::text_content(
                        &owner.projection,
                        &owner.slot
                    ),
                    "9"
                );
            }
            assert!(view.handle().take_failures().is_empty());
        })
        .unwrap();
}
