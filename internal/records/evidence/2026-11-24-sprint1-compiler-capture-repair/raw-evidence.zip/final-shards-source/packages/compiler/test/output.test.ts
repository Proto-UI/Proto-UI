// @vitest-environment node
import { mkdtemp, mkdir, open, readFile, readdir, rm, stat, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { tmpdir } from 'node:os';
import { afterEach, describe, expect, it } from 'vitest';
import { compileFile, compilePrototype, writeCompilation } from '../src/compile';

const temporary: string[] = [];
const source = `import {definePrototype} from '@proto.ui/core'; export default definePrototype({name:'fixture',setup(def){ const flag=def.state.bool('flag',false); def.expose.state('flag',flag); }});`;

async function fixture() {
  const root = await mkdtemp(path.join(tmpdir(), 'proto-compiler-delivery-'));
  temporary.push(root);
  const compilation = compilePrototype(source);
  if (!compilation.ok) throw new Error(JSON.stringify(compilation.diagnostics));
  return { directory: path.join(root, 'fresh'), compilation: compilation.value };
}

afterEach(async () => {
  for (const directory of temporary.splice(0))
    await rm(directory, { recursive: true, force: true });
});

describe('transactional create-only compiler delivery', () => {
  it.each(['Component.tsx', 'provenance.json'])(
    'rolls back owned partial %s bytes and permits a clean retry',
    async (failingName) => {
      const { directory, compilation } = await fixture();
      const result = await writeCompilation(compilation, directory, async (filename) => {
        const handle = await open(filename, 'wx');
        return {
          stat: () => handle.stat(),
          async writeFile(contents) {
            if (path.basename(filename) === failingName) {
              await handle.writeFile(contents.slice(0, 16));
              throw Object.assign(new Error('Injected partial write: no space'), {
                code: 'ENOSPC',
              });
            }
            await handle.writeFile(contents);
          },
          async close() {
            await handle.close();
          },
        };
      });
      expect(result).toMatchObject({ ok: false, diagnostics: [{ code: 'PUI3003' }] });
      await expect(stat(directory)).rejects.toMatchObject({ code: 'ENOENT' });
      const retry = await writeCompilation(compilation, directory);
      expect(retry.ok).toBe(true);
      expect(await readFile(path.join(directory, 'Component.tsx'), 'utf8')).toBe(
        compilation.output.code + '\n//# sourceMappingURL=Component.tsx.map\n'
      );
      expect(
        JSON.parse(await readFile(path.join(directory, 'Component.tsx.map'), 'utf8')).version
      ).toBe(3);
      expect(
        JSON.parse(await readFile(path.join(directory, 'provenance.json'), 'utf8')).profile
      ).toBe('react-runtime-v1');
    }
  );

  it('never overwrites or removes a pre-existing destination', async () => {
    const { directory, compilation } = await fixture();
    await mkdir(directory);
    await writeFile(path.join(directory, 'Component.tsx'), 'consumer edits');
    const result = await writeCompilation(compilation, directory);
    expect(result.ok).toBe(false);
    expect(await readFile(path.join(directory, 'Component.tsx'), 'utf8')).toBe('consumer edits');
    expect(await readdir(directory)).toEqual(['Component.tsx']);
  });

  it('requires the caller to create the parent directory without creating ancestors', async () => {
    const { directory, compilation } = await fixture();
    const nested = path.join(directory, 'consumer', 'generated');
    const rejected = await writeCompilation(compilation, nested);
    expect(rejected).toMatchObject({ ok: false, diagnostics: [{ code: 'PUI3003' }] });
    await expect(stat(directory)).rejects.toMatchObject({ code: 'ENOENT' });
    await mkdir(path.dirname(nested), { recursive: true });
    expect(await writeCompilation(compilation, nested)).toMatchObject({ ok: true });
    expect(await readFile(path.join(nested, 'Component.tsx'), 'utf8')).toContain(
      compilation.output.code
    );
  });

  it('does not unlink a file whose exclusive creation failed after directory reservation', async () => {
    const { directory, compilation } = await fixture();
    const result = await writeCompilation(compilation, directory, async (filename) => {
      await writeFile(filename, 'foreign collision', { flag: 'wx' });
      return open(filename, 'wx');
    });
    expect(result.ok).toBe(false);
    expect(await readFile(path.join(directory, 'Component.tsx'), 'utf8')).toBe('foreign collision');
    expect(await readdir(directory)).toEqual(['Component.tsx']);
  });

  it('rejects unsupported source before a caller has any artifact to deliver', () => {
    const rejected = compilePrototype(
      source.replace('const flag=', "fetch('https://example.invalid'); const flag=")
    );
    expect(rejected).toMatchObject({ ok: false, diagnostics: [{ code: 'PUI1004' }] });
    expect('value' in rejected).toBe(false);
  });

  it('does not require a runtime source for a type-only re-export', async () => {
    const root = await mkdtemp(path.join(tmpdir(), 'proto-compiler-type-only-'));
    temporary.push(root);
    const entry = path.join(root, 'entry.proto.ts');
    await writeFile(entry, `${source}\nexport { type TypeOnly } from './absent';`);
    expect(await compileFile(entry, { root })).toMatchObject({ ok: true });
  });

  it.each([
    "export type {Used} from './used'; export type {Unused} from './absent';",
    "import type {Used as Present} from './used'; import type {Missing} from './absent'; export type Used=Present; export type Unused=Missing;",
  ])(
    'follows the requested type without requiring an unrelated missing type: %s',
    async (barrel) => {
      const root = await mkdtemp(path.join(tmpdir(), 'proto-compiler-type-barrel-'));
      temporary.push(root);
      const entry = path.join(root, 'entry.proto.ts');
      await writeFile(path.join(root, 'barrel.ts'), barrel);
      await writeFile(path.join(root, 'used.ts'), 'export interface Used {value:number}');
      await writeFile(
        entry,
        "import {definePrototype} from '@proto.ui/core';import type {Used} from './barrel';export default definePrototype({name:'type-barrel',setup(def){def.expose.method('read',(value:Used)=>value.value);}});"
      );
      expect(await compileFile(entry, { root })).toMatchObject({ ok: true });
      await writeFile(
        entry,
        "import {definePrototype} from '@proto.ui/core';import type {Unused} from './barrel';export default definePrototype({name:'type-barrel',setup(def){def.expose.method('read',(value:Unused)=>value.value);}});"
      );
      expect(await compileFile(entry, { root })).toMatchObject({
        ok: false,
        diagnostics: expect.arrayContaining([expect.objectContaining({ code: 'PUI1020' })]),
      });
    }
  );
});
