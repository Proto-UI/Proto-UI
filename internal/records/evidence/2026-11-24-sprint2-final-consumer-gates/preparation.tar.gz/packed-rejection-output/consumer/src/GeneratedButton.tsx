// Editable generated source. Profile: react-runtime-v1.
// Retains Proto-UI Runtime and React Adapter; NOT zero-runtime output.
// Source graph SHA-256: eeb0132d1bca3d00a25c35d79edc6f691262060910b171276ededb24b8f7f335
import * as __puiReact from 'react';
import * as __puiCore from '@proto.ui/core';
import * as __puiHooks from '@proto.ui/hooks';
import { createReactAdapter as __puiCreateAdapter } from '@proto.ui/adapter-react';
import type { ReactAdapterOptions as __puiOptions } from '@proto.ui/adapter-react';


export type GeneratedProps = {
  "disabled"?: boolean;
};
export type GeneratedExposes = {
  "disabled": __puiCore.ExposeState<boolean>;
  "hovered": __puiCore.ExposeState<boolean>;
  "focused": __puiCore.ExposeState<boolean>;
  "focusVisible": __puiCore.ExposeState<boolean>;
  "focusSelf": __puiCore.ExposeMethod<(options?: { "reason"?: "programmatic" | "keyboard" | "pointer"; "preventScroll"?: boolean }) => void>;
  "pressed": __puiCore.ExposeState<boolean>;
  "click": __puiCore.ExposeEvent<void>;
};


export const prototype = __puiCore.definePrototype<GeneratedProps, GeneratedExposes>({
  name: "base-button",
  setup: (def: __puiCore.DefHandle<GeneratedProps, GeneratedExposes>) => {
    // Source "packages/prototypes/base/src/button/button.proto.ts":12:3
    def.feedback.style.use(__puiCore.tw("select-none"));
    // Source "packages/prototypes/base/src/button/button.proto.ts":13:9
    const accessible = __puiHooks.asAccessible();
    // Source "packages/prototypes/base/src/button/button.proto.ts":15:3
    __puiHooks.asTrigger();
    // Source "packages/prototypes/base/src/button/button.proto.ts":18:3
    def.props.define({ ["disabled"]: { ["type"]: "boolean", ["empty"]: "fallback" } });
    // Source "packages/prototypes/base/src/button/button.proto.ts":21:3
    def.props.setDefaults({ ["disabled"]: false });
    // Source "packages/prototypes/base/src/button/button.proto.ts":26:9
    const disabled = def.state.bool("disabled", false);
    // Source "packages/prototypes/base/src/button/button.proto.ts":27:3
    def.expose.state("disabled", disabled);
    // Source "packages/prototypes/base/src/button/button.proto.ts":28:3
    accessible.state("disabled", disabled);
    // Source "packages/prototypes/base/src/button/button.proto.ts":31:9
    const hovered = def.state.bool("hovered", false);
    // Source "packages/prototypes/base/src/button/button.proto.ts":32:3
    def.expose.state("hovered", hovered);
    // Source "packages/prototypes/base/src/button/button.proto.ts":35:9
    const focusable = __puiHooks.asFocusable();
    // Source "packages/prototypes/base/src/button/button.proto.ts":36:3
    focusable.configure({ ["disabled"]: false });
    // Source "packages/prototypes/base/src/button/button.proto.ts":38:9
    const focused = (focusable)["focused"];
    // Source "packages/prototypes/base/src/button/button.proto.ts":39:9
    const focusVisible = (focusable)["focusVisible"];
    // Source "packages/prototypes/base/src/button/button.proto.ts":42:3
    def.expose.state("focused", focused);
    // Source "packages/prototypes/base/src/button/button.proto.ts":43:3
    def.expose.state("focusVisible", focusVisible);
    // Source "packages/prototypes/base/src/button/button.proto.ts":46:3
    def.expose.method("focusSelf", (options?: { "reason"?: "programmatic" | "keyboard" | "pointer"; "preventScroll"?: boolean }): void => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":47:5
      if ((disabled.get() as boolean)) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":47:25
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":48:5
      focusable.focusSelf(options);
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":52:9
    const pressed = def.state.bool("pressed", false);
    // Source "packages/prototypes/base/src/button/button.proto.ts":53:3
    def.expose.state("pressed", pressed);
    // Source "packages/prototypes/base/src/button/button.proto.ts":55:9
    const clearTransientInteraction = (reason: string): void => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":56:5
      hovered.set(false, reason);
      // Source "packages/prototypes/base/src/button/button.proto.ts":57:5
      pressed.set(false, reason);
    };
    // Source "packages/prototypes/base/src/button/button.proto.ts":61:3
    def.lifecycle.onUnmounted(() => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":62:5
      (clearTransientInteraction)("reason: button view unmounted => reset transient interaction");
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":66:9
    const syncDisabled = (nextDisabled: boolean): void => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":67:5
      disabled.set(nextDisabled, "reason: sync disabled");
      // Source "packages/prototypes/base/src/button/button.proto.ts":68:5
      focusable.setDisabled(nextDisabled);
      // Source "packages/prototypes/base/src/button/button.proto.ts":69:5
      if (nextDisabled) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":70:7
        (clearTransientInteraction)("reason: button disabled => reset transient interaction");
      }
    };
    // Source "packages/prototypes/base/src/button/button.proto.ts":73:3
    def.lifecycle.onCreated((run: __puiCore.RunHandle<GeneratedProps>) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":74:5
      (syncDisabled)((run.props.get())["disabled"]);
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":76:3
    def.props.watch(["disabled"], (_run: __puiCore.RunHandle<GeneratedProps>, next: __puiCore.PropsSnapshot<GeneratedProps>) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":77:5
      (syncDisabled)((next)["disabled"]);
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":81:3
    def.expose.event("click", { ["payload"]: "void" });
    // Source "packages/prototypes/base/src/button/button.proto.ts":83:3
    accessible.action("activate", { ["event"]: "click" });
    // Source "packages/prototypes/base/src/button/button.proto.ts":86:3
    accessible.role("button");
    // Source "packages/prototypes/base/src/button/button.proto.ts":89:3
    accessible.nameFromContent();
    // Source "packages/prototypes/base/src/button/button.proto.ts":91:9
    const activate = (run: __puiCore.RunHandle<GeneratedProps>, isCurrent: () => boolean = (): boolean => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":91:83
      return true;
    }): void => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":92:5
      if (((disabled.get() as boolean) || (!(isCurrent)()))) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":92:41
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":93:5
      pressed.set(false, "reason: button activation => pressed");
      // Source "packages/prototypes/base/src/button/button.proto.ts":94:5
      if (((disabled.get() as boolean) || (!(isCurrent)()))) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":94:41
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":95:5
      run.expose.emit("click");
    };
    // Source "packages/prototypes/base/src/button/button.proto.ts":97:3
    __puiHooks.asControlLabel().target((run: __puiCore.RunHandle<GeneratedProps>, request: __puiCore.ControlLabelRequest) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":98:11
      const isCurrent = (): boolean => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":98:29
        return ((!(disabled.get() as boolean)) && request.isCurrent());
      };
      // Source "packages/prototypes/base/src/button/button.proto.ts":99:5
      if ((!(isCurrent)())) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":99:23
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":100:5
      focusable.focusSelf({ ["reason"]: (((request)["source"] === "pointer") ? "pointer" : "programmatic") });
      // Source "packages/prototypes/base/src/button/button.proto.ts":101:5
      if ((isCurrent)()) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":101:22
        (activate)(run, isCurrent);
      }
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":107:3
    def.event.onGlobal("key.down", (_run: __puiCore.RunHandle<GeneratedProps>, ev: Parameters<__puiCore.ProtoEventCallback<GeneratedProps>>[1]) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":108:11
      const detail = ev;
      // Source "packages/prototypes/base/src/button/button.proto.ts":109:5
      if ((disabled.get() as boolean)) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":109:25
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":110:5
      if ((!(focused.get() as boolean))) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":110:25
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":111:5
      if (((detail)?.["key"] !== " ")) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":111:30
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":112:5
      ev.control.requestDefaultActionPrevention({ ["reason"]: "button.space-activation", ["source"]: "base-button" });
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":119:3
    def.event.on("pointer.enter", () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":120:5
      if ((disabled.get() as boolean)) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":120:25
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":121:5
      hovered.set(true, "reason: button pointer.enter => hovered");
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":123:3
    def.event.on("pointer.leave", () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":124:5
      hovered.set(false, "reason: button pointer.leave => hovered");
      // Source "packages/prototypes/base/src/button/button.proto.ts":125:5
      pressed.set(false, "reason: button pointer.leave => pressed");
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":127:3
    def.event.on("pointer.cancel", () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":128:5
      hovered.set(false, "reason: button pointer.cancel => hovered");
      // Source "packages/prototypes/base/src/button/button.proto.ts":129:5
      pressed.set(false, "reason: button pointer.cancel => pressed");
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":132:3
    def.event.on("press.cancel", () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":133:5
      (clearTransientInteraction)("reason: button press.cancel => reset transient interaction");
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":137:3
    def.event.on("pointer.down", () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":138:5
      if ((disabled.get() as boolean)) {
        // Source "packages/prototypes/base/src/button/button.proto.ts":138:25
        return;
      }
      // Source "packages/prototypes/base/src/button/button.proto.ts":139:5
      pressed.set(true, "reason: button pointer.down => pressed");
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":141:3
    def.event.on("pointer.up", () => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":142:5
      pressed.set(false, "reason: button pointer.up => pressed");
    });
    // Source "packages/prototypes/base/src/button/button.proto.ts":146:3
    def.event.on("press.commit", (run: __puiCore.RunHandle<GeneratedProps>) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":147:5
      pressed.set(false, "reason: button press.commit => pressed");
      // Source "packages/prototypes/base/src/button/button.proto.ts":148:5
      (activate)(run);
    });
  },
});
const __puiAdapt = __puiCreateAdapter(__puiReact);
export function createComponent(options?: __puiOptions<GeneratedProps>) {
  return __puiAdapt(prototype, { autoUpdateOnPropsChange: true, ...options });
}
export const GeneratedButton = createComponent();
export default GeneratedButton;

//# sourceMappingURL=GeneratedButton.tsx.map
