# Native Adapter screenshot correction — source-bound handoff

## Frozen source

- Base commit: `ecf057b681e8b2eeaa43ef36bf6d2c5a060a4d81`.
- Isolated worktree: `/workspace/scratch/3c698ea06f1e/s5-adapter-capture`.
- Patch: `gpui-adapter-capture-fix.patch`, 35,246 bytes.
- Patch SHA256: `9e318512771c7a3ccb91e1fed3bb435e6c9a7a77bde68c494aef9c0972f453ce`.
- Staged tree: `6b86f2b0c9059ba45b28722235a27b0d4ec1a79d`.
- All five file hashes: `gpui-adapter-capture-fix-manifest.json`.
- Clean `ecf057b6` apply-check succeeded; root reports it applied this exact patch to its index. No new commit or publication was performed by this lane.

## Failure retained

The first and second actual macOS CI runs produced two PNGs whose 300×300 content area was black. The retained second-run PNG identity is `9804d40e9eb8b5ac0405f983d8822b6e698135abdd9d966a13a8e50367517453`; both phases and both runs shared it. The second run is `45018300613`, artifact `14753430846`, archive SHA256 `cd7e68e68daa76ef66546645739a4f839c399565acc4c2b6bd3329e76e8cbd07`.

Its command-level success and 23-count harness result established 21 AX assertions plus two file writes. They did not establish visible native captions. These original artifacts/logs remain unchanged in `adapter-first-artifacts`, `adapter-second-artifacts` and the parent capture records.

## Correction

Only native test support, the macOS test fixture and its acceptance workflow change. The production Adapter/host protocol, peer recordings and component semantics are unchanged. Independent review compared all 21 original `run.check` descriptions and their order; they are unchanged.

The two Label fixtures now receive an explicit light background, dark text, 300×64 point boxes and 16 point padding through the existing host `SessionConfig.root_style`. Real Labels still come from the same recorded peer plans. The foreground window waits across two ordinary platform frame callbacks, with timeout/cancellation retirement and actual visibility recorded. This is not described as a GPU fence.

The existing ScreenCaptureKit path still selects only the current process's exact window ID, owner and measured dimensions. The raw GPUI NSView's measured bounds are converted to window coordinates; titlebar offset and backing scale determine the content ROI. `isFlipped` is diagnostic only. No titlebar height is hardcoded in the capture path. No offscreen render or synthetic pixels substitute for the OS image.

The original CGImage is saved as PNG. A separate CoreGraphics bitmap normalizes captured bytes to RGBA8 for classification. Each Label's content ROI must independently contain a sufficient light background and dark caption strokes across rows/columns and multiple separated segments. Black frames, background-only images, transparency, titlebar content, borders, single-row absence and solid dark blocks are rejected. A failed pixel/frame gate retains the original PNG and `.pixels.json` counts before returning failure. Existing late/duplicate capture protection and fresh-file creation remain intact.

The workflow additionally rejects absent/malformed frame counts, invisible/timed-out frames and either failed/missing Label receipt. Existing AX assertions continue even when capture evidence fails.

## Executed validation

- Independent source review: no unresolved finding in this five-file correction; root's separate reviewer did not implement it.
- Independent Rust classifier: 7/7 passed, including each missing Label, black/background/transparent/titlebar-only images, borders, solid blocks, changed titlebar heights, scales 1/2/3, nonzero origin/fractional geometry and invalid bounds/byte lengths.
- Independent original capture state: 3/3 passed, including timeout retirement and failure preservation.
- Actual retained OS PNG: decoded without altering the original; both ROI reports are false, background=0, ink=8576 and segmentedRows=0. Author checked both phase files; reviewer independently decoded the second-run image.
- Actual workflow JavaScript extracted from the YAML: 15/15 expected outcomes, including missing/string/fractional/null/one callback, occlusion, timeout, failed pixel result and either missing/failed Label.
- `rustfmt`, Prettier YAML check and `git diff --cached --check`: passed.
- Full real `aarch64-apple-darwin` Cargo check: exit 101 at upstream `gpui_apple/src/metal_renderer.rs:36`, because its Linux-host build script does not produce `stitched_shaders.metal`. Original failure retained; no upstream file, SDK, generated shader or platform API was fabricated.
- First bounded type check: exit 101 because rustc compiling actual `gpui` core received SIGKILL 9, without a source diagnostic. This was not a passing type check.
- The bounded retry passed (exit 0, 16.68 seconds) after declaring the real macOS suite's CoreFoundation/CoreVideo feature union. Actual GPUI core, ProtoHostView crates, the original native capture helper and exact source slices of the changed fixture/frame/capture methods were checked for `aarch64-apple-darwin`. No backend stub was supplied. The existing `block v0.1.6` dependency emitted a future-incompatibility warning; no new source type diagnostic occurred.
- Final dependency comparison found one disclosed probe difference: the scratch resolver selected transitive `objc2 0.6.5` while the native repository lock has `0.6.4`, after the narrowed initial lock pruned the 0.6 branch. The helper's direct `objc2` remains exactly `0.5.2`; all other real dependency package identities/checksums match. The producer repository lock was unchanged. Therefore this is a real bounded type probe with a recorded dependency delta, not a pass of the canonical locked full suite. Parent explicitly authorized one further exact-lock bounded retry to resolve that observed binding gap; the earlier 0.6.5 probe remains separate evidence.

- The final exact-lock bounded retry passed (exit 0, 17.87 seconds). A separate scratch checker starts with the canonical native lock and constrains `objc2 0.6.4`. Its driver resolves offline, checks every real dependency identity/version/checksum against the canonical lock **before** compilation, then runs `cargo check --offline --locked --target aarch64-apple-darwin`. Only the local probe root is new; there are zero real dependency or checksum differences. Original source hashes are checked before and after. The frozen five-file patch did not change. This establishes bounded source typing with canonical dependency versions; full native rendering, linking and OS capture remain unexecuted.

## Evidence paths

All paths are relative to `/workspace/scratch/3c698ea06f1e/`:

- `adapter-capture-independent-review.log` — independent 10/10, source hashes and actual black-image regression.
- `adapter-capture-workflow-negative-controls.log` and `.py` — original workflow guard, positive and 14 negative controls.
- `adapter-black-capture-regression.log` — both retained phase PNGs rejected by the actual classifier.
- `adapter-capture-macos-crosscheck.log` — original full macOS-target dependency failure.
- `adapter-capture-bounded-typecheck.log` — original SIGKILL resource failure.
- `adapter-capture-bounded-typecheck-aligned.log` — bounded real macOS-target type probe, exit 0 in 16.68 seconds; dependency delta is recorded.
- `gpui-adapter-capture-validation.json` — exact commands, terminal outcomes and log hashes.
- `adapter-capture-typecheck/dependency-lock-comparison.json` — exact remaining dependency difference against the native lockfile.
- `adapter-capture-typecheck/source-binding.json` — retained earlier probe hashes and its disclosed transitive difference.
- `adapter-capture-bounded-typecheck-exact.log` — final canonical-dependency bounded check, exit 0 in 17.87 seconds.
- `adapter-capture-typecheck-exact/source-binding.json`, `terminal.json`, `dependency-lock-comparison.json`, `run.py`, `Cargo.toml`, `Cargo.lock` and `Cargo.canonical-seed.lock` — complete exact-lock probe commands, inputs and terminal records.

## Required continuation

Publish through the supported authenticated writer, then run the existing native Adapter workflow against that actual new commit on macOS with a functioning WindowServer and the current-process ScreenCaptureKit API (macOS 14.4+). Read both original PNGs and their per-Label JSON receipts, not just suite exit codes. Verify actual CGImage normalization channel/row direction against these OS PNGs. Both captured caption ROIs, two frame callbacks and visibility must pass; retain any original failures.

This correction has not yet produced new macOS window pixels. Linux classifier success and a bounded type check cannot certify actual macOS presentation, capture permissions, normalization orientation, VoiceOver or physical input. Enabled/disabled screenshots may look identical because the changed property is the native Label action; the retained AX action assertions independently verify that behavior.
