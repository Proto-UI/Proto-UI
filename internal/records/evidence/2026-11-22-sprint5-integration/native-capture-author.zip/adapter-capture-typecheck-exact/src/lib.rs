#![allow(dead_code, unused_imports)]
// Bounded type check of unchanged source slices and the actual helper.
// Real GPUI core/ProtoHostView types; no platform/backend stub is supplied.
#[path = "/workspace/scratch/3c698ea06f1e/s5-adapter-capture/native/gpui/crates/proto-ui-gpui/tests/support/native_capture.rs"]
mod native_capture;
mod macos {
    use std::cell::{Cell, RefCell};
    use std::collections::HashMap;
    use std::ffi::CStr;
    use std::fs;
    use std::os::raw::c_char;
    use std::path::Path;
    use std::process;
    use std::rc::Rc;
    use std::thread;
    use std::time::{Duration, Instant};

    use gpui::{
        div, px, rgb, size, AnyWindowHandle, App, AppContext, AsyncApp, Bounds, KeyDownEvent,
        KeyUpEvent, Keystroke, PlatformInput, StyleRefinement, Styled, WindowBounds, WindowHandle,
        WindowOptions,
    };
    use objc2::msg_send;
    use objc2::runtime::AnyObject;
    use proto_ui_gpui::host::{
        FocusAction, InputBridge, ProtoHostView, SurfaceChild, FOCUS_ROOT_REF,
    };
    use proto_ui_gpui::hub::SessionConfig;
    use proto_ui_host_protocol::messages::{HostToPeerMessage, PeerToHostMessage, WireRecord};
    use raw_window_handle::{HasWindowHandle, RawWindowHandle};
    use serde_json::{json, Value};

    fn config(session: &str, prototype_key: &str, label: &str) -> SessionConfig {
        composed(
            session,
            prototype_key,
            vec![SurfaceChild::Text(label.to_string().into())],
            None,
        )
    }

    /// Host-app fixture styling, independent of the Label's semantics and peer
    /// projection. Each caption has a known content box and readable contrast.
    fn capture_label_config(session: &str, label: &str, index: usize) -> SessionConfig {
        use super::native_capture::capture_pixels::{
            LABEL_FONT_SIZE, LABEL_HEIGHT, LABEL_PADDING, LABEL_WIDTH,
        };
        let mut config = config(session, "base-label-root", label);
        let mut subject = div()
            .absolute()
            .left(px(0.0))
            .top(px((index as f64 * LABEL_HEIGHT) as f32))
            .w(px(LABEL_WIDTH as f32))
            .h(px(LABEL_HEIGHT as f32))
            .px(px(LABEL_PADDING as f32))
            .py(px(LABEL_PADDING as f32))
            .text_size(px(LABEL_FONT_SIZE as f32))
            .line_height(px(24.0))
            .bg(rgb(0xf4f7fa))
            .text_color(rgb(0x142237));
        config.root_style = subject.style().clone();
        config
    }

    /// An instance whose default slot holds `content`, opened inside `parent`.
    fn composed(
        session: &str,
        prototype_key: &str,
        content: Vec<SurfaceChild>,
        parent: Option<&str>,
    ) -> SessionConfig {
        SessionConfig {
            instance_id: format!("{session}:instance"),
            prototype_key: prototype_key.into(),
            props: WireRecord::new(),
            slots: HashMap::from([("slot-default".to_string(), content)]),
            root_style: StyleRefinement::default(),
            theme: None,
            parent: parent.map(Into::into),
        }
    }

    /// GPUI's actual drawing view; its measured rect determines image ROIs.
    fn native_view(window: &gpui::Window) -> *mut AnyObject {
        match HasWindowHandle::window_handle(window)
            .expect("a window handle")
            .as_raw()
        {
            RawWindowHandle::AppKit(handle) => handle.ns_view.as_ptr().cast(),
            other => panic!("not an AppKit window: {other:?}"),
        }
    }

    struct Run {
        window: WindowHandle<ProtoHostView>,
        passed: usize,
        capture_failures: Vec<String>,
    }

    /// Retire queued frame callbacks even if the async waiter is cancelled.
    struct RetireFrameCallbacks(Rc<Cell<bool>>);

    impl Drop for RetireFrameCallbacks {
        fn drop(&mut self) {
            self.0.set(true);
        }
    }

    impl Run {
        fn any(&self) -> AnyWindowHandle {
            self.window.into()
        }

        /// Draws a frame, which is when GPUI builds the accessibility tree
        /// and hands it to AccessKit.
        fn draw(&self, cx: &mut AsyncApp) {
            cx.update_window(self.any(), |_, window, cx| window.draw(cx).clear(cx))
                .expect("the window draws");
        }

        /// The second normal frame callback follows the first platform
        /// draw/present invocation. This is not a GPU fence: the subsequent
        /// ScreenCaptureKit pixel gate is the final evidence of visible text.
        async fn capture_frames(&self, cx: &mut AsyncApp) -> super::native_capture::FrameWitness {
            let callbacks = Rc::new(Cell::new(0usize));
            let retired = Rc::new(Cell::new(false));
            let _retire_on_drop = RetireFrameCallbacks(retired.clone());
            let observed = callbacks.clone();
            let terminal = retired.clone();
            let scheduled = cx.update_window(self.any(), move |_, window, cx| {
                cx.activate(true);
                window.activate_window();
                window.refresh();
                window.on_next_frame(move |window, _| {
                    if terminal.get() {
                        return;
                    }
                    observed.set(1);
                    window.on_next_frame(move |_, _| {
                        if !terminal.get() {
                            observed.set(2);
                        }
                    });
                });
            });
            let mut error = scheduled.err().map(|error| error.to_string());
            let deadline = Instant::now() + Duration::from_secs(5);
            while error.is_none() && callbacks.get() < 2 {
                if Instant::now() >= deadline {
                    error = Some("normal platform frame callbacks timed out after 5 s".into());
                    break;
                }
                cx.background_executor()
                    .timer(Duration::from_millis(20))
                    .await;
            }
            retired.set(true);
            let visible = cx.update_window(self.any(), |_, window, _| window.is_visible());
            let visible = match visible {
                Ok(visible) => visible,
                Err(failure) => {
                    error.get_or_insert_with(|| failure.to_string());
                    false
                }
            };
            super::native_capture::FrameWitness {
                callbacks: callbacks.get(),
                visible,
                error,
            }
        }

        /// Capture only this test's own window, at the named current phase.
        /// Node presence, a drawn Scene and PNG file creation are insufficient:
        /// both actual caption ROIs must contain ink on the fixture background.
        async fn capture(&mut self, phase: &str, cx: &mut AsyncApp) {
            let Ok(directory) = std::env::var("PROTO_GPUI_EVIDENCE_DIR") else {
                return;
            };
            let path = Path::new(&directory).join(format!("control-label-{phase}.png"));
            let result = async {
                fs::create_dir_all(&directory).map_err(|error| error.to_string())?;
                let frames = self.capture_frames(cx).await;
                println!("native capture platform frames: {frames:?}");
                let target = cx
                    .update_window(self.any(), |_, window, _| {
                        // SAFETY: this is the main-thread, live view of our own
                        // test window. No external window identifier is accepted.
                        unsafe { super::native_capture::Target::from_view(native_view(window)) }
                    })
                    .map_err(|error| error.to_string())??;
                println!("native capture target: {target:?}");
                // Still try to retain real pixels on a frame timeout. Neither
                // a timed-out wait nor a blank image can become a passing gate.
                let pixels = super::native_capture::capture(target, &path, frames, cx).await?;
                println!("native capture content pixels: {pixels:?}");
                Ok::<(), String>(())
            }
            .await;
            match result {
                Ok(()) => {
                    self.passed += 1;
                    println!("native pixel evidence: {}", path.display());
                }
                Err(error) => {
                    // Preserve the failure, but still exercise the actions
                    // below. A missing screenshot must not erase AT evidence.
                    let failure = format!("{phase}: {error}");
                    println!("FAILED native pixel evidence: {failure}");
                    self.capture_failures.push(failure);
                }
            }
        }

    }
}
