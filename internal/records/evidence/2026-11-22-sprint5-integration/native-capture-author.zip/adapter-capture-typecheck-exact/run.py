from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import sys
import tomllib

check = Path(__file__).resolve().parent
repo = check.parent / "s5-adapter-capture"
cargo = "/home/agent/.cargo/bin/cargo"
target = "aarch64-apple-darwin"
binding = json.loads((check / "source-binding.json").read_text())


def verify_inputs():
    for entry in binding["files"]:
        actual = hashlib.sha256(Path(entry["path"]).read_bytes()).hexdigest()
        if actual != entry["sha256"]:
            raise RuntimeError(f"source binding changed: {entry['path']}")
    if (repo / "native/gpui/Cargo.lock").read_bytes() != (check / "Cargo.canonical-seed.lock").read_bytes():
        raise RuntimeError("canonical native lock differs from the retained exact seed")


def identity(package):
    return package["name"], package["version"], package.get("source")


verify_inputs()
metadata_command = [cargo, "+1.98.1", "metadata", "--manifest-path", str(check / "Cargo.toml"), "--offline", "--format-version", "1", "--filter-platform", target]
print("$ " + shlex.join(metadata_command), flush=True)
with (check / "metadata.json").open("w") as metadata:
    resolution = subprocess.run(metadata_command, stdout=metadata, cwd=repo)
print(f"metadata exit={resolution.returncode}", flush=True)
if resolution.returncode:
    raise SystemExit(resolution.returncode)

baseline = tomllib.loads((check / "Cargo.canonical-seed.lock").read_text())["package"]
resolved = tomllib.loads((check / "Cargo.lock").read_text())["package"]
original = {identity(package): package for package in baseline}
new = [package for package in resolved if identity(package) not in original]
changed = [package for package in resolved if identity(package) in original and package.get("checksum") != original[identity(package)].get("checksum")]
comparison = {
    "baselinePackages": len(baseline),
    "checkerPackages": len(resolved),
    "newPackageIdentities": [list(identity(package)) for package in new],
    "checksumChanges": [list(identity(package)) for package in changed],
    "objc2Versions": [package["version"] for package in resolved if package["name"] == "objc2"],
}
matched = all(package["name"] == "proto-ui-capture-exact-source-typecheck" and package.get("source") is None for package in new) and not changed
comparison["matchesCanonicalDependencies"] = matched
(check / "dependency-lock-comparison.json").write_text(json.dumps(comparison, indent=2) + "\n")
print(json.dumps(comparison, indent=2), flush=True)
if not matched:
    raise SystemExit("resolved dependency identity/checksum differs from canonical native lock; no type check executed")
verify_inputs()

command = [cargo, "+1.98.1", "check", "--manifest-path", str(check / "Cargo.toml"), "--offline", "--locked", "--target", target]
print("$ " + shlex.join(command), flush=True)
result = subprocess.run(command, cwd=repo)
print(f"canonical-dependency bounded target check exit={result.returncode}", flush=True)
verify_inputs()
(check / "terminal.json").write_text(json.dumps({"exit": result.returncode, "target": target, "metadataCommand": metadata_command, "checkCommand": command, "dependencyLockComparison": comparison, "sourceBindingsUnchanged": True}, indent=2) + "\n")
raise SystemExit(result.returncode)
