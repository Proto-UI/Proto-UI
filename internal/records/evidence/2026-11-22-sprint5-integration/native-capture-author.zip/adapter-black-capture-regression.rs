#[path = "/workspace/scratch/3c698ea06f1e/s5-adapter-capture/native/gpui/crates/proto-ui-gpui/tests/support/capture_pixels.rs"]
mod capture_pixels;

fn main() {
    for path in std::env::args().skip(1) {
        let rgba = std::fs::read(&path).unwrap();
        // Dimensions/content offset measured from the retained original OS
        // capture. The product capture path obtains these from its live view.
        let content = capture_pixels::content_rect(300, 329, 1.0, [0.0, 0.0, 300.0, 300.0]).unwrap();
        let report = capture_pixels::inspect(300, 329, &rgba, content, 1.0).unwrap();
        assert!(!report.passed(), "old black OS capture must be rejected");
        assert!(report.labels.iter().all(|label| !label.passed && label.background == 0));
        println!("rejected original screenshot {path}: {report:?}");
    }
}
