'use strict';
const fs = require('node:fs');
const cp = require('node:child_process');
const { syncBuiltinESMExports } = require('node:module');
const file = '/workspace/scratch/3c698ea06f1e/native-support-plan-low-heap/process-events.jsonl';
function emit(kind, detail = {}) {
  try { fs.appendFileSync(file, JSON.stringify({at:new Date().toISOString(),kind,pid:process.pid,parent:process.ppid,...detail})+'\n'); } catch {}
}
emit('node-start', {node:process.version,rss:process.memoryUsage().rss,heapUsed:process.memoryUsage().heapUsed});
const seen = new WeakSet();
function observe(child, method) {
  if (!child || typeof child.on !== 'function' || seen.has(child)) return child;
  seen.add(child);
  emit('child-start', {method,child:child.pid ?? null});
  child.on('exit', (code, signal) => emit('child-exit', {method,child:child.pid ?? null,code,signal}));
  child.on('error', error => emit('child-error', {method,child:child.pid ?? null,errorName:error.name,errorCode:error.code ?? null}));
  return child;
}
for (const method of ['fork','spawn','execFile']) {
  const original = cp[method];
  cp[method] = function(...args) { return observe(Reflect.apply(original,this,args),method); };
}
syncBuiltinESMExports();
process.on('exit', code => emit('node-exit',{code,usage:process.resourceUsage(),memory:process.memoryUsage()}));
