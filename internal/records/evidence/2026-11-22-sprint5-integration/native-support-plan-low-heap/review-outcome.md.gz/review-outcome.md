# native-support-plan 最终重验与 74-case 聚焦汇总

## 最终结果

按 root 的明确限定，再执行一次 512MiB V8 old-space、单 worker、完整原文件重验后，native-support-plan.test.ts 的 **25 个原 case 全部通过**，没有 name filter、skip 或断言改动。parent exit 0，18.204 秒，非 timeout；完整源清单在运行前后均无变化。

这补齐了同一冻结 source manifest 下已通过的其余 49 个 case。因此最终聚焦覆盖为 6 个文件、74 个唯一 case 全部通过。该结论由各次真实终态合并，**不把之前失败的单次 gate 改写为成功**。它也不建立真实浏览器、平台 APPROVED、PR ready、发布或合并状态。

## 两次独立运行均保留

| 项目 | 2048MiB 诊断重放 | 最后 512MiB 重验 |
|---|---:|---:|
| 原文件选中 case | 25 | 25 |
| parent exit | 1 | 0 |
| timeout | false | false |
| 时长 | 10.082s | 18.204s |
| case 终态 | 无完整结果 | 25 passed / 25 |
| 真正测试 worker | SIGKILL | 结果完成后的 SIGTERM pool 收尾 |
| kernel oom_kill | 35 → 36 | 40 → 40 |
| OOM delta | 1 | 0 |
| 采样 group RSS 峰 | 735,024 KiB | 827,072 KiB |
| 运行前 / 后源变化 | [] / [] | [] / [] |
| 结束后自有进程 | [] | [] |

2048MiB 运行中 worker SIGKILL 与 oom_kill 增加落在同一约 52ms 采样窗口，支持资源 / OOM 中断的诊断。512MiB 运行证明当前原断言在该受限配置下能完整结束。两次全局环境不是受控恒定实验，采样 RSS 也只是观察下界；本报告不声称某个具体 cgroup 限额、内存下降幅度、确切分配栈或 512MiB 是通用最优值。cgroup counters 在当前 namespace 不可读取，限制继续保留。

没有继续增加 heap，没有再执行第三次独立 replay，也没有改变测试为更弱的替代品。

## 全部 25-case 的实际覆盖

最后的 verbose log 有 25 个唯一通过条目：

- Native support dependency plans：19，包括完整 strict native TypeScript consumer、资源/依赖闭包、13 个功能裁剪项、4 个 target emitter。
- Production retained support evidence：1，包括 Floating UI 保留的正控与各 feature 生产大小比较。
- Initialization, registration and cleanup evidence：5，包括 a11y、trigger、Text/Boundary、FIFO reentrant focus 与跨 closure owner identity 清理。

其中首条 strict TypeScript consumer 实际用时 13.2 秒，生产测量 1.081 秒；它们没有被移出、mock 或跳过。早先诊断报告提出的 1 + 18 + 1 + 5 分组只是候选定位方案，本次没有使用分组。原报告及分组说明保持原样，供追溯。

## 原 source binding 与聚焦汇总

共 12,336 项的原始 source map：
/workspace/scratch/3c698ea06f1e/final-browser-gates/source-files.json.gz

解压后 SHA-256：
41c77548751799aee9e5b2890cff1ccff2b18a9ab6a3d41972cdce2b81b8d56d

最终 case 统计由各真实日志读取：

| 文件 | case |
|---|---:|
| browser-target-consumer.test.ts | 16 |
| vue-source.test.ts | 15 |
| browser-wasm.test.ts | 5 |
| browser-revision-session.test.ts | 4 |
| browser-client.test.ts | 9 |
| native-support-plan.test.ts | 25 |
| 合计 | 74 |

前 5 份由 root 的原始 1536MiB、单文件/单 worker gate 执行；最后一份由本 reviewer 的 512MiB 重验执行。原 1536MiB 整合 gate、2048MiB root recheck、2048MiB 独立带信号诊断的失败原文全部保留，新的通过只是追加证据。

本地 ESM / DOM / TypeScript / 5-case WASM 断言与真实 OS browser sandbox 验收是不同证据。真实 iframe/CSP/blob import-map/Worker 的联合旅程仍缺第三次实际浏览器 receipt，full website migration inventory 仍开放。

## 冻结证据目录

- /workspace/scratch/3c698ea06f1e/native-support-plan-diagnostic/：首个独立 SIGKILL/OOM 诊断、原测试日志、子进程事件、采样、两个实际 driver 源文件、原分组说明。
- /workspace/scratch/3c698ea06f1e/native-support-plan-low-heap/：最后 25-pass 运行的同类证据与 derived case list。
- /workspace/scratch/3c698ea06f1e/native-support-plan-final-review-files.json：以上原文件、原 root gate、最终 outcome 的统一 SHA-256 清单及 74-case 汇总。

本次所有测试进程都已终态，共享锁释放。没有修改实现、原测试、manifest、lockfile 或外部状态。本报告为本地独立执行证据。
