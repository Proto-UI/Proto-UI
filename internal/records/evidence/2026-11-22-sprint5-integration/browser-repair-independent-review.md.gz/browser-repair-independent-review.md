# Sprint 5 浏览器修复：本地独立复审

## 结论与边界

**冻结增量范围内没有剩余的具体代码 finding。原先提前设置 closed 导致 framework cleanup 错误被吞掉的问题，本地源码与真实框架 DOM 控制已解决。**

这是 reviewer `/root/review_request_adapter` 的只读独立源码评审和限定执行证据。reviewer 没有编写本次实现、没有修改被审代码、没有提交 GitHub review，也没有把本地结论转换成平台 `APPROVED`。第三次真实浏览器验收仍然缺失；最终整合 74 条聚焦断言正在由 root 单独运行，本报告不预先记为通过。

## 精确绑定

- 工作树：`/workspace/scratch/3c698ea06f1e/s5-browser`
- 工作树 HEAD：`24b8b7e8c0315066c1a73b39aef5266e97f5ebb5`
- 基线包含已 staged 的前序 773 / 791 / 3f920 补丁；本次只审相对该 index 的修复增量。
- 基线 staged diff SHA-256：`3efbc36fe8bdeb8ba4d1925b00fb52ca1fb0898655ed1e804960c7a1aadf58af`
- 冻结补丁：`/workspace/scratch/3c698ea06f1e/s5-browser-product-repair.patch`
- 补丁字节：38,455；11 个文件，503 additions / 31 deletions。
- 补丁 SHA-256：`e98cf71f990dd487a8dc3bc71a83ea279106635a6c4507af60f98663f27d29be`
- 独立检查前后，当前 `git diff --binary` 均与该补丁字节 SHA 完全一致。
- `git diff --check` 成功。root 报告已将同一增量整合到 ecf 基线；本报告不自行替换为未提供的整合后 commit SHA。

## 评审覆盖与判断

### React vendor 的真实 ESM 边界

`scripts/compiler/browser-assets.ts` 以实际 compiler 声明的 React、ReactDOM 和 client 依赖路径作为 esbuild alias，把三个 CommonJS package 形成单一共享 bundle；四个 `scripts/compiler/browser-targets/*.mjs` 文件提供显式的 ESM entry / facades。原生 linker 检查直接消费这个实际 builder 返回的模块字节，没有再用 esbuild 把消费链重打包。

检查确认 `createContext`、`useState`、`createElement`、`flushSync`、`createRoot` 都是原生 ESM 可链接的函数；三个 default facade 与共享 runtime exports，以及四项关键函数 identity，共 7 项相等。独立 VM realm 中 `require`、`module`、`exports`、`process` 全部不存在。旧的 standalone React entry 按原 bundling 方式构建，原生 linker 正确拒绝它没有 `createContext` named export，故该控制能区分原始故障与修复。

这里的执行结论限定为 **React facade 链**。它没有测试所有 vendor API、全部 prototype 或定位等其他组件组合，也不是浏览器 import-map / blob transport 的验收。

### mount-ready、主错误与清理错误

`compiled-preview-sandbox.ts` 的 `error()` 先处理 `retiring`，再判断 `closed`。dispose 将两者设为 true，等待 native framework retire，在清理 stage 和逐项回收 object URL 后，先发 `cleanup-error`，再发 `disposed`。该顺序保留了原先丢失的 framework error-hook 和 React owner queueMicrotask 清理异常。

React 初始 render 使用原生 `flushSync`，并接入 `onUncaughtError`；Vue 3 / Vue 2 使用各自普通 error handler。发生首个 mount 错误后设置 `failed`，后续 ready 和组件 event 被抑制。首个 preview error 保持为主错误，额外 mount / 自动清理异常保存在 secondary 通道，不覆盖主错误。

我追读了三个生成器的 teardown：React 的 shell disconnect 延迟微任务、Vue 的 finally 清理、Vue 2 的 owner terminal 清理，以及 WC 逐 owner try/catch disposal。当前 sandbox 的等待窗口与这些普通生成路径一致。新增 DOM 控制覆盖三框架的双 owner mount 错误、每个 owner 的 onUnmounted / onBeforeDispose 错误、primary mount + secondary cleanup，以及 cleanup-error 早于 disposed。WC 正常消费和退休在四目标正控中覆盖；没有声称此新增 suite 穷尽 WC 的全部异常清理路径。

### Vue void setup 的 slot 权威与兼容边界

`packages/compiler/src/vue-source.ts` 第 1535 行把 client void setup 的 null fallback 改为现有 Slot(frame) 操作，保持显式 renderer 返回 null 的空输出语义，不按组件名特殊处理。

这与 draft `C-CORE-SYNTAX-0004-C` 和 `C-TEMPLATE-0005` 的匿名单一 slot 方向相符；修复没有改变这两项的 draft 生命周期。新增 oracle 用一般 caller fixture 对照 void setup 与显式 empty renderer，检查 caller 文本、child node identity、input value / focus，以及 unmount。现有 SlotView 仍由 Vue 子 render 持有 caller 内容的原生所有权。

### 输入清单与开发服务

新的 `react-runtime.mjs` 经真实 esbuild metafile 加入 targetInputs；三个 facade 通过 hashInputFiles 显式加入。保守 repository snapshot 也枚举 scripts 下 tracked / 非忽略 untracked 输入。独立 probe 逐个确认四文件的 manifest 哈希与冻结源字节相等，并末次重 hash 实际 React target 的依赖输入。

Astro 的 optimizer exclusion 只加入已观测导致第一次 Worker load 触发 reload 的 QuickJS native ESM closure。现装 core 与 ffi-types 包有 native ESM import entry。排除设置的冷启动真实行为仍需下一次实际浏览器运行验证。

## 执行证据

### reviewer 独立执行：通过

- Node `v24.22.3`，`vm.SourceTextModule` 原生 ECMAScript linker / evaluator；使用 `--experimental-vm-modules`。
- 共享锁：`flock --close /tmp/proto-ui-heavy-acceptance.lock`，按 browser → GPUI → reviewer → root 的队列执行。
- session 58470 终态 exit 0；没有遗留进程或持锁 gate。
- React ESM 正控通过，旧 standalone React named-export 负控按预期失败。
- 四个新 .mjs 输入绑定、实际 target dependency 末次哈希和 11 个变更文件前后稳定检查全部通过。
- 实际 React target modules SHA-256：`1fe8a8ae62e39df31a19148546058beb0fe73251755592c2d93d15761c3636ba`
- 旧 standalone React bundle SHA-256：`9e3f5e8efa71b487c8bc53882df47753624446add2504ee2e26dbb00f83327d1`

原始日志：
`/workspace/scratch/3c698ea06f1e/browser-repair-independent-esm.log`

实际执行脚本原文：
`/workspace/scratch/3c698ea06f1e/browser-repair-independent-esm.mjs`

脚本经 stdin 执行，因此从上述 s5-browser cwd 重放，保持相同 frozen patch 环境变量：

```sh
PUI_REVIEW_PATCH=/workspace/scratch/3c698ea06f1e/s5-browser-product-repair.patch \
PUI_REVIEW_PATCH_SHA=e98cf71f990dd487a8dc3bc71a83ea279106635a6c4507af60f98663f27d29be \
flock --close /tmp/proto-ui-heavy-acceptance.lock \
node --experimental-vm-modules --import tsx --input-type=module \
< /workspace/scratch/3c698ea06f1e/browser-repair-independent-esm.mjs
```

### 作者执行、reviewer 读回

- `s5-browser/.cache/sprint5/browser-target-consumer-16.log`：明确 1 file / 16 tests passed。该 suite 使用实际 trusted launcher、framework bundles 和 canonical generated code，但以 esbuild closed-graph linker 替代 import-map transport，属于 DOM host 证据。
- 最终 scoped tsc 的 exit 0 由作者与 root 的实际 session 终态确认，`browser-repair-types-final.log` 无诊断；reviewer 未独立重跑此类型 gate。
- 作者合并运行被 SIGKILL / exit 137 终止的记录仍保留。最终这一轮 `vue-source-15.log` 我读到 Worker exited unexpectedly、15 cases 尚无测试结果；没有把这一轮计为 15 passed。更早 22-case 日志包含 15 Vue oracle + 当时 7 consumer passed，但不能替代最终整合后的 74-case gate。
- root 已另行启动整合后六文件、74-case 串行 gate；本报告生成时结果待定。

## 未完成的验收与后续

1. 新修复后的真实 Chrome / iframe / CSP / blob import-map / Worker / WASM 联合运行尚未完成，尤其需要冷启动 English first-open。第二次 ecf 真机浏览器 receipt 中 English reload、React named-export、Vue caller-content 故障仍是失败记录，没有被本报告改写。
2. 本地 ESM probe 不能代替 OS browser sandbox。未调用已暂停的 provider，也未降低浏览器 sandbox 来取得通过。
3. Full website migration inventory 与未执行的 target / prototype journeys 仍开放；这份 bounded source repair review 没有扩张成全站或全 vendor 的通过结论。
4. root 最终整合测试及之后 exact-head review / 发布条件独立存在。本地无剩余 finding 不产生 GitHub APPROVED、CI success、发布或合并结论。

本轮只创建 reviewer 的报告、日志与 probe 原文；没有修改被审实现或外部状态。
