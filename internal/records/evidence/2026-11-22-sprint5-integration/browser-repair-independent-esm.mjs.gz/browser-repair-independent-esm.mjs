import assert from 'node:assert/strict';
import { build } from 'esbuild';
import { readFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { createContext, SourceTextModule } from 'node:vm';
import { buildBrowserTargets } from './scripts/compiler/browser-assets.ts';

const paths = [
  'internal/records/2026-11-22-sprint5-browser-delivery.md',
  'apps/www/astro.config.mjs',
  'apps/www/src/components/PrototypePreviewer/compiled-preview-sandbox.ts',
  'packages/compiler/src/vue-source.ts',
  'packages/compiler/test/vue-source.test.ts',
  'packages/compiler/test/browser-target-consumer.test.ts',
  'scripts/compiler/browser-assets.ts',
  'scripts/compiler/browser-targets/react-runtime.mjs',
  'scripts/compiler/browser-targets/react.mjs',
  'scripts/compiler/browser-targets/react-dom.mjs',
  'scripts/compiler/browser-targets/react-client.mjs',
];
const hash = value => createHash('sha256').update(value).digest('hex');
const snapshot = async () => Object.fromEntries(await Promise.all(paths.map(async file => [file, hash(await readFile(file))])));
const before = await snapshot();
const patchPath = process.env.PUI_REVIEW_PATCH;
assert.ok(patchPath, 'explicit frozen patch path is required');
const patchSha256 = hash(await readFile(patchPath));
assert.equal(patchSha256, process.env.PUI_REVIEW_PATCH_SHA, 'frozen patch sha256');
const gitHead = execFileSync('git', ['rev-parse', 'HEAD'], {encoding:'utf8'}).trim();
assert.equal(hash(execFileSync('git', ['diff', '--binary'], {maxBuffer:16*1024*1024})), patchSha256, 'current unstaged repair bytes match frozen patch');
const stagedDiffSha256 = hash(execFileSync('git', ['diff', '--cached', '--binary'], {maxBuffer:16*1024*1024}));
const { assets, targetInputs } = await buildBrowserTargets();
const target = JSON.parse(assets.get('targets/react-dom-source-v1.json'));
const actual = target.modules;
assert.equal(hash(JSON.stringify(actual)), target.modulesSha256, 'module payload digest');
for (const name of paths.filter(name => name.startsWith('scripts/compiler/browser-targets/'))) {
  assert.equal(targetInputs['react-dom-source-v1'][name], before[name], 'target input binding: ' + name);
}
const context = createContext({ setTimeout, clearTimeout, queueMicrotask, performance, console });
const modules = new Map(Object.entries(actual).map(([name, source]) => [name, new SourceTextModule(source, { context, identifier: name })]));
const consumer = new SourceTextModule(`
import React, { createContext, useState, createElement } from 'react';
import ReactDOM, { flushSync } from 'react-dom';
import ReactClient, { createRoot } from 'react-dom/client';
import { React as SharedReact, ReactDOM as SharedDOM, ReactClient as SharedClient } from 'pui:target/react-runtime';
export const scope = [typeof require, typeof module, typeof exports, typeof process];
export const same = [React === SharedReact, ReactDOM === SharedDOM, ReactClient === SharedClient, createContext === SharedReact.createContext, useState === SharedReact.useState, flushSync === SharedDOM.flushSync, createRoot === SharedClient.createRoot];
export const types = [createContext, useState, createElement, flushSync, createRoot].map(value => typeof value);
export const contextValue = createContext('native ESM context')._currentValue;
`, { context, identifier: 'native-consumer' });
await consumer.link(name => {
  assert.ok(modules.has(name), 'closed ESM import: ' + name);
  return modules.get(name);
});
await consumer.evaluate();
assert.deepEqual(Array.from(consumer.namespace.scope), Array(4).fill('undefined'));
assert.deepEqual(Array.from(consumer.namespace.same), Array(7).fill(true));
assert.deepEqual(Array.from(consumer.namespace.types), Array(5).fill('function'));
assert.equal(consumer.namespace.contextValue, 'native ESM context');

const compilerRequire = createRequire(new URL('./packages/compiler/package.json', import.meta.url));
const original = await build({absWorkingDir:process.cwd(),entryPoints:[compilerRequire.resolve('react')],bundle:true,write:false,format:'esm',platform:'browser',target:'es2022',minify:true,metafile:true,external:[],define:{'process.env.NODE_ENV':'"production"','__VUE_OPTIONS_API__':'true','__VUE_PROD_DEVTOOLS__':'false','__VUE_PROD_HYDRATION_MISMATCH_DETAILS__':'false'}});
const oldModule = new SourceTextModule(original.outputFiles[0].text, {context,identifier:'old-standalone-react'});
const oldConsumer = new SourceTextModule("import {createContext} from 'react'; export {createContext};", {context,identifier:'old-native-consumer'});
await assert.rejects(() => oldConsumer.link(() => oldModule), /does not provide an export named 'createContext'/);
for (const [file, digest] of Object.entries(targetInputs['react-dom-source-v1'])) assert.equal(hash(await readFile(file)), digest, 'final target dependency binding: ' + file);
const after = await snapshot();
assert.equal(hash(execFileSync('git', ['diff', '--binary'], {maxBuffer:16*1024*1024})), patchSha256, 'repair patch remains frozen');
assert.deepEqual(after,before);
console.log(JSON.stringify({
 kind:'independent-native-esm-review-v1',
 patchPath, patchSha256, gitHead, stagedDiffSha256, nodeVersion:process.version,
 scope:'Node native ECMAScript linker over exact target module bytes; not browser iframe, CSP, WASM or OS sandbox acceptance',
 nativeEsm:'passed',
 sharedModuleIdentity:Array.from(consumer.namespace.same),
 nodeGlobals:Array.from(consumer.namespace.scope),
 originalStandaloneReactNegative:'rejected missing createContext',
 originalStandaloneReactSha256:hash(original.outputFiles[0].text),
 reactTargetInputs:targetInputs['react-dom-source-v1'],
 targetFilesBound:true,
 targetInputsRehashed:true,
 sourcesStable:true,
 sourceFiles:before,
 targetModulesSha256:target.modulesSha256,
},null,2));
