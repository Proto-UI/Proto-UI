import datetime,gzip,hashlib,json,os,pathlib,signal,subprocess,sys,time,resource
ROOT=pathlib.Path('/workspace/scratch/3c698ea06f1e/Proto-UI')
OUT=pathlib.Path('/workspace/scratch/3c698ea06f1e/native-support-plan-diagnostic')
MANIFEST=pathlib.Path('/workspace/scratch/3c698ea06f1e/final-browser-gates/source-files.json.gz')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
recorded=json.loads(gzip.decompress(MANIFEST.read_bytes()))
def source_changes():
 changes=[]
 for name,expected in recorded.items():
  try: observed=sha(ROOT/name)
  except OSError: observed=None
  if observed!=expected: changes.append({'path':name,'expected':expected,'observed':observed})
 return changes
def counters():
 data={}
 p=pathlib.Path('/proc/meminfo')
 try:
  for line in p.read_text().splitlines():
   key,value=line.split(':',1)
   if key in ['MemTotal','MemAvailable','SwapTotal','SwapFree']: data[key+'KiB']=int(value.split()[0])
 except OSError: pass
 p=pathlib.Path('/proc/vmstat')
 try:
  for line in p.read_text().splitlines():
   key,value=line.split()
   if key in ['oom_kill','pgmajfault','pswpin','pswpout']: data[key]=int(value)
 except OSError: pass
 for name in ['memory.current','memory.max','memory.peak','memory.events']:
  p=pathlib.Path('/sys/fs/cgroup')/name
  try: data['cgroup/'+name]=p.read_text().strip()
  except OSError: pass
 return data
def processes(group):
 rows=[]
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit(): continue
  try:
   stat=(p/'stat').read_text().rsplit(')',1)[1].split()
   if int(stat[2])!=group: continue
   data={k:v.strip() for k,v in (l.split(':',1) for l in (p/'status').read_text().splitlines() if ':' in l)}
   rows.append({'pid':int(p.name),'parent':int(data['PPid']),'name':data['Name'],'state':data['State'],'rssKiB':int(data.get('VmRSS','0 kB').split()[0]),'hwmKiB':int(data.get('VmHWM','0 kB').split()[0]),'vmSizeKiB':int(data.get('VmSize','0 kB').split()[0])})
  except (OSError,ValueError,KeyError,IndexError): pass
 return rows
OUT.mkdir(exist_ok=True)
(OUT/'process-events.jsonl').write_text('')
before_changes=source_changes()
critical=[x for x in before_changes if x['path'].startswith(('packages/','apps/www/','scripts/','native/')) or x['path'] in ['package.json','pnpm-lock.yaml','pnpm-workspace.yaml','vitest.config.ts','tsconfig.json']]
if critical:
 (OUT/'preflight-source-drift.json').write_text(json.dumps(critical,indent=2))
 raise SystemExit('Frozen test/implementation source changed before diagnostic replay')
command=['node','node_modules/vitest/vitest.mjs','run','packages/compiler/test/native-support-plan.test.ts','--minWorkers=1','--maxWorkers=1','--reporter=verbose']
env=dict(os.environ)
env['NODE_OPTIONS']='--max-old-space-size=2048 --require=/workspace/scratch/3c698ea06f1e/native-support-plan-diagnostic/observe-child-exits.cjs'
start=time.monotonic()
before=counters()
metadata={'kind':'read-only-native-support-plan-process-diagnostic-v1','startedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'heapCapMiB':2048,'timeoutSeconds':120,'sourceManifestUncompressedSha256':hashlib.sha256(gzip.decompress(MANIFEST.read_bytes())).hexdigest(),'sourceChangesBefore':before_changes,'preloadPolicy':'observe child exits/signals and own process resourceUsage only; no argument changes, no assertion/implementation edits, no environment dump','globalCountersBefore':before,'cgroupCountersAvailable':any(k.startswith('cgroup/') for k in before)}
peak_rss=0;min_available=before.get('MemAvailableKiB');per_pid={};timedout=False
with (OUT/'test.log').open('w') as log,(OUT/'memory-samples.jsonl').open('w') as samples:
 child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 metadata['runnerPid']=child.pid
 while True:
  now=time.monotonic(); rows=processes(child.pid); counts=counters(); total=sum(r['rssKiB'] for r in rows)
  peak_rss=max(peak_rss,total)
  if counts.get('MemAvailableKiB') is not None: min_available=min(min_available if min_available is not None else counts['MemAvailableKiB'],counts['MemAvailableKiB'])
  for row in rows:
   previous=per_pid.get(row['pid'],{'peakObservedRssKiB':0,'peakObservedHwmKiB':0})
   per_pid[row['pid']]={**row,'peakObservedRssKiB':max(previous['peakObservedRssKiB'],row['rssKiB']),'peakObservedHwmKiB':max(previous['peakObservedHwmKiB'],row['hwmKiB'])}
  samples.write(json.dumps({'elapsedSeconds':round(now-start,3),'groupRssKiB':total,'counters':counts,'processes':rows})+'\n');samples.flush()
  code=child.poll()
  if code is not None: break
  if now-start>120:
   timedout=True;os.killpg(child.pid,signal.SIGTERM)
   try: child.wait(timeout=5)
   except subprocess.TimeoutExpired: os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
   code=child.returncode;break
  time.sleep(0.05)
after=counters()
metadata.update({'exitCode':code,'timeout':timedout,'seconds':round(time.monotonic()-start,3),'globalCountersAfter':after,'oomKillDelta':after.get('oom_kill',0)-before.get('oom_kill',0),'peakObservedGroupRssKiB':peak_rss,'minimumObservedMemAvailableKiB':min_available,'processes':list(per_pid.values()),'sourceChangesAfter':source_changes(),'completedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ownRemainingGroupProcesses':processes(child.pid)})
metadata['files']={name:{'sha256':sha(OUT/name),'bytes':(OUT/name).stat().st_size} for name in ['observe-child-exits.cjs','diagnostic.py','test.log','process-events.jsonl','memory-samples.jsonl']}
(OUT/'result.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata,indent=2))
print('PROCESS_EVENTS')
print((OUT/'process-events.jsonl').read_text())
print('TEST_LOG_TAIL')
print('\n'.join((OUT/'test.log').read_text().splitlines()[-45:]))
sys.exit(code)
