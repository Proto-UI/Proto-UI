# native-support-plan.test.ts：一次有界独立进程诊断

## 诊断结论

本次完整 25-case 重放捕获了真正的测试 worker SIGKILL，同时内核 oom_kill 计数增加 1。两者出现在同一约 52ms 采样窗口，worker 消失、RSS 降低，随后 Vitest 报告 Worker exited unexpectedly。证据强烈支持 OOM / 执行环境资源中断，而非已观测到的产品断言失败。

**25 条测试仍然没有取得通过终态。** 没有把资源失败转换为测试成功，也不能据此证明其中所有产品行为正确。没有可读的 cgroup memory counters / kernel victim report，因此不宣称具体内存限额或精确的 kernel OOM 约束层。

## 实际执行

- 路径：/workspace/scratch/3c698ea06f1e/Proto-UI
- 日期：2026-11-22 UTC。
- 仅执行一次诊断重放，session 52256；复用原 2GiB V8 old-space 上限、原文件、单 worker，增加 verbose reporter。
- 由外置 Node preload 监听 child_process 的真实 start / exit / signal；不改变参数、实现或断言。外置 Python 每约 50ms 读取自有 process group 的 /proc RSS/HWM 与全局内存计数。
- 未输出环境变量清单、凭据、任意子进程参数或 source 内容。
- 通过共享 flock --close 锁执行，120 秒上限；实际 10.082 秒，exit 1，timeout false。
- 完成后无剩余自有 process-group 进程；没有再执行其他重放。

命令：

```text
node node_modules/vitest/vitest.mjs run packages/compiler/test/native-support-plan.test.ts --minWorkers=1 --maxWorkers=1 --reporter=verbose
```

诊断环境只有显式记录的 2048MiB heap cap 与外置 observer preload；没有降低断言强度。

## 真实观察

| 观察 | 值 |
|---|---|
| Vitest parent PID | 6 |
| 实际 test worker PID | 40 |
| worker 退出 | code=null, signal=SIGKILL |
| worker 退出 UTC | 2026-11-22T12:32:59.909Z |
| kernel oom_kill | 35 → 36 |
| 第一个增加后的采样 | elapsed 10.030s；前一采样 9.978s |
| parent 终态 | exit 1 |
| 采样到的 group RSS 峰值 | 735,024 KiB，约 717.8 MiB |
| 采样到的 worker RSS/HWM 峰值 | 414,360 KiB，约 404.6 MiB |
| 采样到的 parent RSS/HWM 峰值 | 305,308 KiB，约 298.2 MiB |
| 最低采样 MemAvailable | 1,427,060 KiB |
| cgroup counters | 该 namespace 未挂载，不可读取 |
| V8 heap-limit / assertion 诊断 | 未观察到 |
| Vitest summary | collected 25、tests 0ms、1 unhandled worker-exit error |

RSS 只是本次采样下界，不能从它反推硬配额。全局 MemAvailable 不等于此 execution 的可用 cgroup 预算。也不能把 --max-old-space-size=2048 解释为 OS 为进程保留 2GiB。

worker 40 退出后，Tinypool 尝试创建 PID 62，然后 runner 收尾使其收到 SIGTERM。这是替换 worker 的关闭记录，没有第二条产品异常或第二次 OOM 计数。

## 源码绑定

完整 12,336 项 source manifest 在执行前后均无变化：

- /workspace/scratch/3c698ea06f1e/final-browser-gates/source-files.json.gz
- 解压后 SHA-256：41c77548751799aee9e5b2890cff1ccff2b18a9ab6a3d41972cdce2b81b8d56d
- sourceChangesBefore=[]
- sourceChangesAfter=[]

本次没有实现、测试、package manifest、lockfile 或源码修订。原先 1.5GiB 与 2GiB 的两份失败日志继续保留，当前诊断没有覆盖它们。

## 测试结构与可行下一步

文件按声明顺序首先执行 strict native TypeScript consumer：遍历所有 nativeSupportFeatures，合并 supportClosure 的文件，调用 typecheckSupport 创建完整 strict TypeScript Program。后续是其他 dependency / IR 控制、生产保留产物测量与资源清理控制。

日志没有首条已完成测试，也没有额外插入 test-start instrumentation，因此将首条 strict Program 视为优先隔离点是根据顺序的推断；本报告没有声称捕获到具体 TypeScript 分配栈。

继续增加 V8 heap cap 没有证据依据。可以先由 root 对原完整 25-case 命令进行一次较低 heap cap（例如 512MiB）的受限重验，以促使 V8 更早回收；这不会删除断言，但必须以实际终态为准，若出现 heap exhaustion 仍应保留真实失败。reviewer 没有自行执行这一步。

若需要定位和控制进程生命周期，可将原文件按 testNamePattern 分成以下互不重叠的四组；**分组不解决第一条自身的峰值，不能用其余 24 条通过替代 strict 1 条**：

| 组 | testNamePattern | 原断言 case 数 |
|---|---|---:|
| Strict native TSC | covers every host unit with a strict native TypeScript consumer and explicit imports | 1 |
| 其余 dependency / IR | native support dependency plans(?!.*covers every host unit) | 18 |
| 生产产物测量 | production retained support evidence | 1 |
| 初始化与清理 | initialization, registration and cleanup evidence | 5 |

每组仍运行同一原 test file，仅使用 Vitest -t 选择；应保留每个实际执行命令、终态、选中数量与逐项名称，验证最终唯一 case 集合的并集恰好为 25。各次过滤显示的 skipped complements 不能被偷偷当作通过。若 strict 1 条仍被资源终止，它继续是开放的验证项。

## 原始证据

本目录保留：

- result.json：命令、完整 source binding、全局计数前后、process RSS 峰值、退出结果。
- process-events.jsonl：Node / child_process 的真实事件，含 SIGKILL / SIGTERM 区分。
- memory-samples.jsonl：逐次 /proc 采样。
- test.log：完整原始 Vitest 输出。
- observe-child-exits.cjs：实际 observer 原文。
- diagnostic.py：实际有界采样 runner 原文。

这是本地独立诊断，不是平台 review approval、CI success 或 25-case 验收通过。
