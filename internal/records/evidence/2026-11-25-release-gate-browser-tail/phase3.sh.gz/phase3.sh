#!/usr/bin/env bash
set -uo pipefail
export PATH=/home/ezra/proto-ui-release-gate-cb5d-control/tools/node_modules/node/bin:/home/ezra/proto-ui-release-gate-cb5d-control/tools/node_modules/.bin:$PATH
cd /home/ezra/proto-ui-browser-tail-cb5d
pnpm --filter apps-www generate:proto-ui-style > /home/ezra/proto-ui-browser-tail-cb5d-control/style-generation-phase3.log 2>&1
PUI_STYLE_STATUS=$?
printf '%s\n' "$PUI_STYLE_STATUS" > /home/ezra/proto-ui-browser-tail-cb5d-control/style-generation-phase3.exit
if [ "$PUI_STYLE_STATUS" != 0 ]; then exit "$PUI_STYLE_STATUS"; fi
setsid pnpm --filter apps-www exec astro dev --host 127.0.0.1 --port 4351 > /home/ezra/proto-ui-browser-tail-cb5d-control/server-phase3.log 2>&1 &
printf '%s\n' "$!" > /home/ezra/proto-ui-browser-tail-cb5d-control/server.pid
export PROTO_UI_BROWSER_BASE_URL=http://127.0.0.1:4351
export PROTO_UI_BROWSER_TEST=1
export PROTO_UI_RUNTIME_EVIDENCE_DIR=/home/ezra/proto-ui-browser-tail-cb5d-control/phase3-evidence
export PROTO_UI_COLLAPSIBLE_SCREENSHOT_DIR=/home/ezra/proto-ui-browser-tail-cb5d-control/phase3-collapsible-evidence
run_browser () {
  local label="$1" testfile="$2" pattern="$3"
  pnpm exec vitest run "$testfile" --maxWorkers=1 --minWorkers=1 --no-file-parallelism -t "$pattern" --reporter=json --outputFile="/home/ezra/proto-ui-browser-tail-cb5d-control/$label.json" > "/home/ezra/proto-ui-browser-tail-cb5d-control/$label.log" 2>&1
  printf '%s\n' "$?" > "/home/ezra/proto-ui-browser-tail-cb5d-control/$label.exit"
}
run_browser radio-full-candidate apps/www/src/content/docs/zh-cn/demo-shadcn-radio-group.browser.test.ts ".*"
run_browser collapsible-full-candidate apps/www/src/content/docs/zh-cn/demo-collapsible-projections.browser.test.ts ".*"
run_browser docs-reading-nav-candidate apps/www/test/release-docs-reading.browser.test.ts "keyboard"
run_browser code-scroll-fresh-candidate apps/www/src/content/docs/zh-cn/code-scroll-chain.browser.test.ts "compares fresh static auto"
run_browser columns-brutalist-baseline apps/www/src/content/docs/zh-cn/site-docs-columns.browser.test.ts "brutalist"
run_browser composed-press-baseline apps/www/src/content/docs/zh-cn/demo-composed-style-isolation.browser.test.ts "pressed Root"

