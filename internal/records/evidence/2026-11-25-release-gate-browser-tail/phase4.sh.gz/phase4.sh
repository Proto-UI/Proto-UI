#!/usr/bin/env bash
set -uo pipefail
export PATH=/home/ezra/proto-ui-release-gate-cb5d-control/tools/node_modules/node/bin:/home/ezra/proto-ui-release-gate-cb5d-control/tools/node_modules/.bin:$PATH
cd /home/ezra/proto-ui-browser-tail-cb5d
export PROTO_UI_BROWSER_BASE_URL=http://127.0.0.1:4351
export PROTO_UI_BROWSER_TEST=1
export PROTO_UI_RUNTIME_EVIDENCE_DIR=/home/ezra/proto-ui-browser-tail-cb5d-control/phase4-evidence
run_browser () {
 local label="$1" testfile="$2" pattern="$3"
 pnpm exec vitest run "$testfile" --maxWorkers=1 --minWorkers=1 --no-file-parallelism -t "$pattern" --reporter=json --outputFile="/home/ezra/proto-ui-browser-tail-cb5d-control/$label.json" > "/home/ezra/proto-ui-browser-tail-cb5d-control/$label.log" 2>&1
 printf '%s\n' "$?" > "/home/ezra/proto-ui-browser-tail-cb5d-control/$label.exit"
}
run_browser columns-brutalist-candidate apps/www/src/content/docs/zh-cn/site-docs-columns.browser.test.ts "brutalist"
run_browser composed-full-candidate apps/www/src/content/docs/zh-cn/demo-composed-style-isolation.browser.test.ts ".*"

