#!/usr/bin/env bash
set -uo pipefail
export PATH=/home/ezra/proto-ui-release-gate-cb5d-control/tools/node_modules/node/bin:/home/ezra/proto-ui-release-gate-cb5d-control/tools/node_modules/.bin:$PATH
cd /home/ezra/proto-ui-browser-tail-cb5d
export PROTO_UI_BROWSER_BASE_URL=http://127.0.0.1:4351
export PROTO_UI_BROWSER_TEST=1
export PROTO_UI_RUNTIME_EVIDENCE_DIR=/home/ezra/proto-ui-browser-tail-cb5d-control/phase1-evidence
python3 - <<'PY'
from pathlib import Path
import os,signal
p=Path('/home/ezra/proto-ui-browser-tail-cb5d-control/server.pid')
if p.exists():
 try:os.killpg(int(p.read_text()),signal.SIGTERM)
 except ProcessLookupError:pass
PY
setsid pnpm --filter apps-www exec astro dev --host 127.0.0.1 --port 4351 > /home/ezra/proto-ui-browser-tail-cb5d-control/server-phase1.log 2>&1 &
PUI_TAIL_SERVER_PID=$!
printf '%s\n' "$PUI_TAIL_SERVER_PID" > /home/ezra/proto-ui-browser-tail-cb5d-control/server.pid
run_browser () {
  local label="$1" testfile="$2" pattern="$3"
  pnpm exec vitest run "$testfile" --maxWorkers=1 --minWorkers=1 --no-file-parallelism -t "$pattern" --reporter=json --outputFile="/home/ezra/proto-ui-browser-tail-cb5d-control/$label.json" > "/home/ezra/proto-ui-browser-tail-cb5d-control/$label.log" 2>&1
  printf '%s\n' "$?" > "/home/ezra/proto-ui-browser-tail-cb5d-control/$label.exit"
}
run_browser radio-wc-candidate apps/www/src/content/docs/zh-cn/demo-shadcn-radio-group.browser.test.ts 'wc'
run_browser sprint-baseline-ready apps/www/src/content/docs/zh-cn/sprint2-site.browser.test.ts 'B: en/wc'
run_browser collapsible-wc-baseline apps/www/src/content/docs/zh-cn/demo-collapsible-projections.browser.test.ts 'wc preserves'
