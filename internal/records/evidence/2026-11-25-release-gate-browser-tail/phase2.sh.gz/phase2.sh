#!/usr/bin/env bash
set -uo pipefail
export PATH=/home/ezra/proto-ui-release-gate-cb5d-control/tools/node_modules/node/bin:/home/ezra/proto-ui-release-gate-cb5d-control/tools/node_modules/.bin:$PATH
cd /home/ezra/proto-ui-browser-tail-cb5d
export PROTO_UI_BROWSER_BASE_URL=http://127.0.0.1:4351
export PROTO_UI_BROWSER_TEST=1
export PROTO_UI_RUNTIME_EVIDENCE_DIR=/home/ezra/proto-ui-browser-tail-cb5d-control/phase2-evidence
export PROTO_UI_SPRINT2_SITE_EVIDENCE_DIR=/home/ezra/proto-ui-browser-tail-cb5d-control/phase2-sprint-evidence
export PROTO_UI_DOCS_READING_EVIDENCE_DIR=/home/ezra/proto-ui-browser-tail-cb5d-control/phase2-docs-evidence
run_browser () {
  local label="$1" testfile="$2" pattern="$3"
  pnpm exec vitest run "$testfile" --maxWorkers=1 --minWorkers=1 --no-file-parallelism -t "$pattern" --reporter=json --outputFile="/home/ezra/proto-ui-browser-tail-cb5d-control/$label.json" > "/home/ezra/proto-ui-browser-tail-cb5d-control/$label.log" 2>&1
  printf '%s\n' "$?" > "/home/ezra/proto-ui-browser-tail-cb5d-control/$label.exit"
}
run_browser radio-wc-interaction-candidate apps/www/src/content/docs/zh-cn/demo-shadcn-radio-group.browser.test.ts "wc.*interaction"
run_browser controls-candidate apps/www/src/content/docs/zh-cn/demo-shadcn-controls.browser.test.ts ".*"
run_browser sprint-profile-candidate apps/www/src/content/docs/zh-cn/sprint2-site.browser.test.ts "B:"
run_browser docs-reading-nav-baseline apps/www/test/release-docs-reading.browser.test.ts "keyboard"
run_browser code-scroll-fresh-baseline apps/www/src/content/docs/zh-cn/code-scroll-chain.browser.test.ts "compares fresh static auto"

