from pathlib import Path
import os, json, subprocess, traceback, hashlib, fcntl, time, signal, re

root = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
base = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123-ops/final-23122')
parent = base / 'final-current'
out = parent / 'light-final'
out.mkdir(exist_ok=True)
status = out / 'status.json'
lock = open(out / 'continuation.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not status.exists(), 'Reconcile the existing continuation before another invocation.'
env = dict(os.environ)
env['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:' + env['PATH']
env['TMPDIR'] = '/var/tmp/s6-75d5-modal'
env['GIT_OPTIONAL_LOCKS'] = '0'
state = {'phase': 'starting', 'pid': os.getpid(), 'runs': []}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save():
    temp = status.with_suffix('.tmp')
    temp.write_text(json.dumps(state, indent=2) + '\n')
    os.replace(temp, status)

def git(*args):
    return subprocess.check_output(['git', '-c', 'core.fsmonitor=false', '-c', 'submodule.recurse=false', *args], cwd=root, env=env, text=True, timeout=120).strip()

def run(args, name, timeout=300):
    state['phase'] = name
    save()
    log = out / (name + '.log')
    started = time.monotonic()
    with log.open('w') as stream:
        proc = subprocess.Popen(args, cwd=root, env=env, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        state['childPid'] = proc.pid
        save()
        try:
            code = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                try:
                    proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    state['pendingChild'] = proc.pid
            state['timedOutCommand'] = {'name': name, 'outerSeconds': timeout}
            raise
    state.pop('childPid', None)
    state['runs'].append({'name': name, 'command': args, 'exit': code, 'seconds': round(time.monotonic() - started, 3), 'logSha256': sha(log)})
    save()
    assert code == 0, {'command': name, 'exit': code, 'tail': log.read_text()[-3000:]}

try:
    save()
    prep = json.loads((parent / 'preparation-r3-status.json').read_text())
    previous_path = parent / 'light-r3' / 'light-status.json'
    previous = json.loads(previous_path.read_text())
    assert prep['phase'] == 'prepared-not-committed'
    assert previous['phase'] == 'failed' and previous['error'] == 'AttributeError("\'NoneType\' object has no attribute \'group\'")'
    assert not previous.get('pendingChild')
    assert not (Path('/proc') / str(previous['pid'])).exists()
    assert [r['name'] for r in previous['runs']] == ['portal-counterfactual', 'combined-dom', 'strict-node-controls']
    assert [r['exit'] for r in previous['runs']] == [1, 0, 0]
    assert git('rev-parse', 'HEAD') == prep['head']
    assert git('write-tree') == prep['tree']
    assert not git('diff', '--name-only')
    sources = prep['sourceSha256']
    assert all(sha(root / file) == digest for file, digest in sources.items())

    old_path = parent / 'light-r3' / 'portal-counterfactual.json'
    old_report = json.loads(old_path.read_text())
    assert sha(old_path) == '4fa598975c6d0f31421168498c5ead72caa0ae5d399b22941ed3a69839b757cf'
    failures = [row for file in old_report['testResults'] for row in file['assertionResults'] if row['status'] == 'failed']
    assert len(failures) == 1 and 'expected 1 to be 2' in '\n'.join(failures[0]['failureMessages'])
    assert (old_report['numPassedTests'], old_report['numFailedTests'], old_report['numPendingTests']) == (0, 1, 30)
    green_path = parent / 'light-r3' / 'combined-dom.json'
    green = json.loads(green_path.read_text())
    assert sha(green_path) == 'ce8895e5260b25f168f8b44552a87cc65c841e8f26583bc99d2ce33c31c0791f'
    assert (green['numPassedTests'], green['numFailedTests'], green['numPendingTests'], green['numTotalTests']) == (59, 0, 0, 59)
    assert len(green['testResults']) == 4 and all(row['status'] == 'passed' for file in green['testResults'] for row in file['assertionResults'])

    node_log = parent / 'light-r3' / 'strict-node-controls.log'
    assert sha(node_log) == '565fa1d6bc14a8e6d93bee69265cb62ff25680026f0b0e54b96fc92f9ca0c7fb'
    raw = node_log.read_text()
    counts = {}
    identities = []
    for line in raw.splitlines():
        match = re.fullmatch(r'(?:#|ℹ) (tests|pass|fail|cancelled|skipped|todo) (\d+)', line)
        if match:
            assert match[1] not in counts
            counts[match[1]] = int(match[2])
        if line.startswith('✔ '):
            identities.append(re.sub(r' \([0-9.]+ms\)$', '', line[2:]))
    assert counts == {'tests': 88, 'pass': 88, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}, counts
    assert len(identities) == len(set(identities)) == counts['pass']
    critical = ['requires eleven exact files and 130 executed cases while separating positive and rejected profiles', 'rejects green extra case replacing the Portal reentry', 'rejects duplicate Portal reentry with distinct generic identities', 'Modal observation waits for physical withdrawal and acknowledged unmount', 'Modal observation rejects replaced lifetimes and missing conceal ownership']
    assert all(name in identities for name in critical)
    node_source = {file: sources[file] for file in ['scripts/test/check-bootstrap-motion-evidence.test.mjs', 'scripts/test/bootstrap-state-controls-evidence.test.mjs']}
    node_readback = {'log': str(node_log), 'logSha256': sha(node_log), 'command': previous['runs'][-1]['command'], 'exit': previous['runs'][-1]['exit'], 'seconds': previous['runs'][-1]['seconds'], 'counts': counts, 'identities': identities, 'sourceSha256': node_source, 'boundary': 'Readback of the actual complete two-file Node24 spec-reporter execution. The prior wrapper wrongly expected TAP text and omitted the third original file, run-bootstrap-public-validation.test.mjs. These 88 passes do not represent the full intended selection. The failed collector is retained; these 88 tests are not rerun or changed. The missing third file is executed separately below.'}
    (out / 'node-readback.json').write_text(json.dumps(node_readback, indent=2) + '\n')
    state.update(head=prep['head'], remote=prep['remote'], main=prep['main'], preparedTree=prep['tree'], sourceBefore=sources, priorCollectorFailureSha256=sha(previous_path), oldHelperFailure={'passed': 0, 'failed': 1, 'filterExcluded': 30, 'reportSha256': sha(old_path)}, dom={'passed': 59, 'failed': 0, 'pending': 0, 'reportSha256': sha(green_path)}, reusedCliExecution=previous['reusedCliExecution'], nodeReadbackSha256=sha(out / 'node-readback.json'), nodeCounts=counts)
    save()
    supplemental = {file: sha(root / file) for file in ['scripts/test/run-bootstrap-public-validation.test.mjs', 'scripts/test/run-bootstrap-public-validation.mjs']}
    run(['node', '--test', '--test-reporter=tap', 'scripts/test/run-bootstrap-public-validation.test.mjs'], 'missing-public-validation-controls', 180)
    missing_log = out / 'missing-public-validation-controls.log'
    missing_raw = missing_log.read_text()
    missing_counts = {key: int(re.findall(r'^# ' + key + r' (\d+)$', missing_raw, re.M)[-1]) for key in ['tests', 'pass', 'fail', 'cancelled', 'skipped', 'todo']}
    missing_names = re.findall(r'^# Subtest: (.*)$', missing_raw, re.M)
    assert missing_counts == {'tests': 10, 'pass': 10, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}
    assert len(missing_names) == len(set(missing_names)) == 10
    assert all(sha(root / file) == digest for file, digest in supplemental.items())
    old_node_log = base / 'physical-reviewed-green.log'
    assert sha(old_node_log) == 'd84cfe1c1f2960dbb6e36c1bc0d499e96b517c8ec9f66b5e594bacae0f779de8'
    old_names = re.findall(r'^# Subtest: (.*)$', old_node_log.read_text(), re.M)
    assert len(old_names) == len(set(old_names)) == 81
    current_names = identities + missing_names
    assert len(current_names) == len(set(current_names)) == 98
    composition_added = [name for name in current_names if name.startswith('composition receipt rejects a missing combination: ') or name == 'the old fifteen-case green receipt cannot admit unexecuted composition journeys']
    assert len(composition_added) == 17 and not (set(composition_added) & set(old_names))
    inventory = {'oldCommandSource': str(base / 'physical-review.py'), 'oldCommandSourceSha256': sha(base / 'physical-review.py'), 'oldLogSha256': sha(old_node_log), 'oldCount': 81, 'currentTwoFileCounts': counts, 'missingFileCounts': missing_counts, 'missingFileCommand': state['runs'][-1]['command'], 'missingLogSha256': sha(missing_log), 'combinedExecutedCount': 98, 'compositionAdded': composition_added, 'otherAddedNames': sorted(set(current_names) - set(old_names) - set(composition_added)), 'oldNamesAbsent': sorted(set(old_names) - set(current_names)), 'supplementalSourceSha256': supplemental, 'boundary': 'Actual 88 + 10 in two executions complete the original three-file selection, with 17 new composition refusals. No tests were dropped to repair the parser or match a predicted total.'}
    (out / 'node-inventory-reconciliation.json').write_text(json.dumps(inventory, indent=2) + '\n')
    state.update(nodeInventoryReconciliationSha256=sha(out / 'node-inventory-reconciliation.json'), nodeFullSelection={'executed': 98, 'passed': 98, 'failed': 0, 'pendingOrSkipped': 0, 'executionGroups': [88, 10]}, supplementalSourceSha256=supplemental)
    save()
    run(['corepack', 'pnpm@10.32.1', 'check:spec-authoring', '--', '--base', prep['main']], 'current-base-authoring')
    run(['corepack', 'pnpm@10.32.1', 'check:prototype-catalog'], 'current-catalog')
    loader = out / 'current-spec-loader.mjs'
    loader.write_text("import assert from 'node:assert/strict';\nimport {writeFileSync} from 'node:fs';\nimport {loadSpecWorkspaceFromDirectory} from '" + str(root / 'packages/spec/engine/src/node.ts') + "';\nconst start=performance.now();\nconst w=await loadSpecWorkspaceFromDirectory(" + json.dumps(str(root / 'spec')) + ");\nconst result={entityCount:w.entities.length,issues:w.issues,elapsedMs:performance.now()-start};\nwriteFileSync(" + json.dumps(str(out / 'current-spec-loader.json')) + ",JSON.stringify(result,null,2)+'\\n');\nconsole.log(JSON.stringify(result));assert.deepEqual(result.issues,[]);\n")
    run(['node', '--import', 'tsx', str(loader)], 'current-spec-loader')
    assert all(sha(root / file) == digest for file, digest in sources.items())
    assert all(sha(root / file) == digest for file, digest in supplemental.items())
    assert not git('diff', '--name-only')
    assert git('write-tree') == prep['tree']
    state.update(phase='completed', sourceStable=True)
except BaseException as exc:
    state.update(phase='pending-child' if 'pendingChild' in state else 'failed', error=repr(exc), traceback=traceback.format_exc())
save()
