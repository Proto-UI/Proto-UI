from pathlib import Path
import os, json, hashlib, gzip, subprocess, traceback, fcntl, time

root = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
base = Path(str(root) + '-ops/final-23122')
ops = base / 'final-current'
status = ops / 'checkpoint-archive-status.json'
lock = open(ops / 'checkpoint-archive.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not status.exists(), 'Reconcile the existing archive attempt before any new writer.'
env = dict(os.environ)
env['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:' + env['PATH']
env['GIT_OPTIONAL_LOCKS'] = '0'
name = '2026-11-23-sprint6-current-main-reentry'
record = root / 'internal/records' / (name + '.md')
evidence = root / 'internal/records/evidence' / name
state = {'phase': 'starting', 'pid': os.getpid(), 'runs': [], 'purpose': 'Immutable partial checkpoint before preserving a newer external branch; not a full native acceptance.'}

def digest(value):
    return hashlib.sha256(value).hexdigest()

def sha(path):
    return digest(path.read_bytes())

def read(path):
    return json.loads(path.read_text())

def save():
    tmp = status.with_suffix('.tmp')
    tmp.write_text(json.dumps(state, indent=2) + '\n')
    os.replace(tmp, status)

def git(*args):
    return subprocess.check_output(['git', '-c', 'core.fsmonitor=false', '-c', 'submodule.recurse=false', *args], cwd=root, env=env, text=True, timeout=120).strip()

def run(args, label, timeout=240):
    state['phase'] = label
    save()
    started = time.monotonic()
    log = ops / (label + '.log')
    with log.open('w') as stream:
        proc = subprocess.Popen(args, cwd=root, env=env, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        state['childPid'] = proc.pid
        save()
        try:
            code = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            state['pendingChild'] = {'pid': proc.pid, 'label': label, 'outerSeconds': timeout}
            save()
            raise
    state.pop('childPid', None)
    state['runs'].append({'name': label, 'command': args, 'exit': code, 'seconds': round(time.monotonic() - started, 3), 'logSha256': sha(log)})
    save()
    assert code == 0, {'label': label, 'exit': code}

try:
    save()
    prep = read(ops / 'preparation-r3-status.json')
    light = read(ops / 'light-final/status.json')
    first = read(ops / 'native-status.json')
    second = read(ops / 'native-recheck/status.json')
    assert prep['phase'] == 'prepared-not-committed'
    assert light['phase'] == 'completed' and light['sourceStable']
    failed_counts = {'numPassedTests': 5, 'numFailedTests': 1, 'numPendingTests': 0, 'numTotalTests': 6}
    assert first['phase'] == second['phase'] == 'failed'
    assert first['sourceStable'] and second['sourceStable']
    assert first['result'] == second['result'] == failed_counts
    for pid in [first['pid'], second['pid'], 3058142]:
        assert not Path('/proc/' + str(pid)).exists(), {'liveOwnedPid': pid}
    assert git('rev-parse', 'HEAD') == prep['head'] == '366a38112bd0ba994f2ef6a7743ffc981a051bfe'
    assert git('write-tree') == prep['tree'] == '8882ea51f4ce4ce99f37dbdc5df75d5975efa3fc'
    assert not git('diff', '--name-only')
    merge_heads = Path(git('rev-parse', '--git-path', 'MERGE_HEAD')).read_text().splitlines()
    assert merge_heads == ['84ef7893e732a316388aeb730af1758b96f703e8', '0fbb52ef832cc27c78e24c28c59a55a16f51d7fe']
    assert all(sha(root / path) == expected for path, expected in prep['sourceSha256'].items())
    assert all(sha(root / path) == expected for path, expected in light['supplementalSourceSha256'].items())
    for item in prep['restored16']:
        assert sha(root / item['path']) == item['sha256'], item['path']
    historical_record = 'internal/records/2026-11-23-sprint6-main-view-retirement.md'
    historical_manifest = 'internal/records/evidence/2026-11-23-sprint6-main-view-retirement/manifest.json'
    assert sha(root / historical_record) == 'f1428997800d8bfde7ca305b73feeb7a8799c5fec3e70f3fdb16c8b0d5272050'
    assert sha(root / historical_manifest) == '975227b6f1bdd43b1ea8d0b1d5ef481c7d2b1c76dfad3e32c943d66a4f17295c'
    peers = {'root-source-review.md': '335785da76e60a8e5f186b830972b77d5d1634bbd8f73438040aafe1bdc4cd42', 'root-retained-present-review.md': '1546bae4ec72e270125ecfae55e0eb1d1e4868a73262496ade2fdab4ab213fce'}
    assert all(sha(ops / path) == expected for path, expected in peers.items())
    first_dir = ops / 'native-evidence/bootstrap-modal-presence'
    second_dir = ops / 'native-recheck/native-evidence/bootstrap-modal-presence'
    first_source = read(first_dir / 'source.json')
    second_source = read(second_dir / 'source.json')
    assert first_source['sourceSha256'] == second_source['sourceSha256']
    assert len(first_source['sourceSha256']) == 451
    assert all(sha(root / path) == expected for path, expected in first_source['sourceSha256'].items())
    assert first['bundleSha256'] == second['bundleSha256']
    assert first['cssSha256'] == second['cssSha256']
    first_case = read(first_dir / 'dialog-enter-close.json')
    second_case = read(second_dir / 'dialog-enter-close.json')
    assert first_case['family'] == second_case['family'] == 'dialog'
    assert first_case['name'] == second_case['name'] == 'enter-close'
    assert 'cold start acknowledgement' in first_case['failure']
    assert 'captureInterior' in second_case['failure'] and 'Timeout 1000ms' in second_case['failure']
    assert first_case['errors'] == second_case['errors'] == []
    visual = next(t for t in second_case['history']['traces'] if t['stage'] == 'visual-enter')
    interior = [s for s in visual['samples'] if s['content']['phase'] != 'closed' and .55 <= s['content']['opacity'] <= .85]
    assert len(visual['samples']) == 15 and not interior
    gaps = [(b['time'] - a['time'], a, b) for a, b in zip(visual['samples'], visual['samples'][1:])]
    gap, before, after = max(gaps, key=lambda row: row[0])
    assert before['content']['opacity'] < .55 and after['content']['opacity'] > .85
    def sample(s):
        return {key: s.get(key) for key in ['time', 'elapsed', 'frameTimestamp']} | {'contentPhase': s['content']['phase'], 'contentOpacity': s['content']['opacity']}
    analysis = {
        'source': str(second_dir / 'dialog-enter-close.json'), 'rawSha256': sha(second_dir / 'dialog-enter-close.json'),
        'reportSha256': sha(ops / 'native-recheck/native.json'), 'preparedSourceTree': prep['tree'],
        'family': 'dialog', 'case': 'enter-close', 'stage': 'visual-enter', 'samples': len(visual['samples']),
        'matchingOriginalInteriorSamples': len(interior), 'largestGapMs': gap, 'beforeGap': sample(before), 'afterGap': sample(after),
        'afterGapCallbackSampleLatenessMs': after['time'] - after['frameTimestamp'], 'errors': second_case['errors'],
        'disposal': {k: v for k, v in second_case['disposal'].items() if k != 'lifecycle'},
        'interpretation': 'The page-local trace itself has no sample in the unchanged 0.55-0.85 opacity interval. This does not prove that merely arming waitForFunction earlier would fix the observation. Retain the actual timeout; do not relax the interval or merge two partial runs into a pass.',
        'nextBoundary': 'Do not repeat the same 8882 input again. Preserve the newer external branch, then obtain evidence bound to the actual combined source, preferably through the original hosted workflow.'
    }
    (ops / 'native-recheck/visual-capture-analysis.json').write_text(json.dumps(analysis, indent=2) + '\n')
    assert not record.exists() and not evidence.exists()
    evidence.mkdir(parents=True)
    entries = []
    def archive(source, relative, compress=True):
        raw = source.read_bytes()
        destination = evidence / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        stored = gzip.compress(raw, mtime=0) if compress else raw
        destination.write_bytes(stored)
        entries.append({'file': relative, 'source': str(source), 'rawBytes': len(raw), 'rawSha256': digest(raw), 'storedBytes': len(stored), 'storedSha256': digest(stored), 'encoding': 'gzip' if compress else 'identity'})
    raw_files = [
        'preparation-status.json', 'preparation-r3-status.json', 'retained-present-actual.patch',
        'review-source-patch.log', 'review-custody-patch.log', 'root-source-review.md', 'root-retained-present-review.md',
        'light-status.json', 'portal-counterfactual.json', 'portal-counterfactual.log',
        'light-r2/light-status.json', 'light-r2/combined-dom.json', 'light-r2/combined-dom.log',
        'light-r3/light-status.json', 'light-r3/portal-counterfactual.json', 'light-r3/portal-counterfactual.log',
        'light-r3/combined-dom.json', 'light-r3/combined-dom.log', 'light-r3/strict-node-controls.log',
        'light-final/status.json', 'light-final/node-readback.json', 'light-final/node-inventory-reconciliation.json',
        'light-final/missing-public-validation-controls.log', 'light-final/current-base-authoring.log',
        'light-final/current-catalog.log', 'light-final/current-spec-loader.log', 'light-final/current-spec-loader.json',
        'native-launch.json', 'native-status.json', 'native.json', 'native.log',
        'native-recheck-launch.json', 'native-recheck/status.json', 'native-recheck/native.json', 'native-recheck/native.log',
        'native-recheck/cold-start-analysis.json', 'native-recheck/visual-capture-analysis.json',
    ]
    for relative in raw_files:
        archive(ops / relative, 'raw/' + relative + '.gz')
    for script in ['final-current-prepare.py', 'reentrant-present-prepare.py', 'final-light.py', 'final-light-r2.py', 'final-light-r3.py', 'final-validation-continuation.py', 'final-native-current.py', 'final-native-recheck-exec.py', 'checkpoint-archive.py']:
        archive(base / script, 'execution/' + script + '.gz')
    archive(base / 'physical-review.py', 'historical-inventory/physical-review.py.gz')
    archive(base / 'physical-reviewed-green.log', 'historical-inventory/physical-reviewed-green.log.gz')
    for label, directory in [('native-first', first_dir), ('native-recheck', second_dir)]:
        for source in sorted(directory.rglob('*')):
            if source.is_file():
                relative = source.relative_to(directory).as_posix()
                archive(source, label + '/' + relative + ('' if source.suffix == '.png' else '.gz'), source.suffix != '.png')
    harness = root / 'apps/www/src/content/docs/zh-cn/browser-harness.ts'
    archive(harness, 'execution/browser-harness.ts.gz')
    source_manifest = {
        'schemaVersion': 1, 'scope': 'Immutable partial checkpoint of the prepared 8882 source combination before a newer external branch merge. Neither native run passed all six cases.',
        'headBeforeCommit': prep['head'], 'normalMergeHeads': merge_heads, 'remoteParent': prep['remote'], 'mainParent': prep['main'],
        'preparedSourceTree': prep['tree'], 'priorPreparedSourceTree': prep['priorPreparedTree'],
        'sourceSha256': prep['sourceSha256'], 'supplementalSourceSha256': light['supplementalSourceSha256'],
        'nativeSourceSha256': first_source['sourceSha256'], 'nativeBundleSha256': first['bundleSha256'], 'nativeCssSha256': first['cssSha256'],
        'browserVersion': first['browserVersion'], 'browserHarnessSha256': sha(harness),
        'nativeResults': [{'attempt': 'first', 'counts': first['result'], 'reportSha256': first['reportSha256'], 'failureStage': 'Dialog enter-close cold start acknowledgement: 13.400062476158382ms is not below 12ms'}, {'attempt': 'one-controlled-recheck', 'counts': second['result'], 'reportSha256': second['reportSha256'], 'failureStage': 'Dialog enter-close later visual-enter captureInterior: original 1000ms timeout; zero interior samples'}],
        'lightResults': {'DOM': '59/59 full four files after the retained-present repair', 'CLI': '14/14 in the preserved current-main pre-repair execution', 'Node': '88+10=98/98 in two actual executions', 'authoring': 'exit 0 against actual main0fbb', 'catalog': 'exit 0', 'loader': '0 issues'},
        'notExecutedOnThisCheckpoint': ['draft-family generator check', 'CLI build', 'website token generation', 'public/workspace types', 'original-deadline graph/schema'],
        'historicalPreserved': {'record': historical_record, 'recordSha256': sha(root / historical_record), 'manifest': historical_manifest, 'manifestSha256': sha(root / historical_manifest), 'restored16': prep['restored16']},
        'localPeerReviews': peers, 'artifacts': entries,
    }
    manifest = evidence / 'manifest.json'
    manifest.write_text(json.dumps(source_manifest, indent=2) + '\n')
    record.write_text(f'''# Sprint 6 current-main union and retained-present reentry checkpoint

This is a bounded, partial development checkpoint before preserving a newer external Sprint 6 branch. It does not merge PR #1712, promote a draft contract, or claim full native acceptance.

## Source and preserved history

- Existing local HEAD: `{prep['head']}`.
- Normal pending merge parents: `{merge_heads[0]}` and `{merge_heads[1]}`.
- Prepared source tree before this evidence-only addition: `{prep['tree']}`.
- The current main's distinct `HC-CONTROL-LABEL-0001-GPUI` and `HC-CONTROL-LABEL-0001-GPUI-PROVIDER` IDs are retained. The historical single-ID conjunction is not reapplied.

The sixteen designated historical originals remain byte-for-byte restored from concurrent commit `24e553961e7a898b74b959792d35f49364f35efc` after main integration. The earlier 93-artifact record is unchanged. External Dialog/Focus/Vue2 lifetime work, composition journeys, held-image reuse and main CLI/token changes retain their own historical evidence attribution.

An earlier publication wrapper stopped after 900 seconds while its Git child was pending. Later direct readback proved normal signed-off commit `366a38112bd0ba994f2ef6a7743ffc981a051bfe` completed with tree `e2683714e4aae455bd05e73073975dfd14f88197`, both expected parents and a clean worktree. The pending wrapper and the later actual completion are distinct preserved receipts; no duplicate commit or force push resolved that uncertainty.

## Retained-present reentry repair

The current marker-first close sequence exposes synchronous attribute reentry before concealment starts. The unchanged public-Props fixture initially failed at its immediate detached-marker assertion. A complete fixed-helper baseline executed 73 tests: 72 passed, and that same marker assertion failed. The fourteen CLI cases passed in that actual current-main run.

`C-HOST-VIEW-ATTACHMENT-0001` remains draft. Its criterion B binds the detached marker to not-present intent. The narrow repair lets a newer present intent clear the marker when the same owner already retains a view, including reentry before concealment starts. Main's marker → version/owner guard → conceal → guard order, fresh-acquisition behavior and first-render guards remain intact.

With that retained-present condition held constant, the final old-helper counterfactual fails with press count 1 instead of 2: one selected failure and thirty filter-excluded cases. Restoring disable-before-native-toggle passes all 59 cases in four complete DOM files with no pending cases. The fixture retains both presses and exact mount/unmount/dispose counts. These are Happy DOM and synthetic MouseEvent regressions, not OS input. The CLI's fourteen passing cases are reused from the preserved current-main run because this later repair changes only WC reconciliation, not their generator inputs.

## Strict controls and current light evidence

The initial Node continuation omitted one of the original three files and parsed TAP markers despite an actual Node 24 spec reporter. Its two selected files really passed 88/88; the collector failure remains preserved. Reading the original driver identified the missing ten-case public-validation file, which then separately passed 10/10. The actual complete selection is 88 + 10 = 98/98, with no skipped, cancelled or todo cases. The identity reconciliation explains the seventeen new composition refusals and one renamed positive case; no original check was deleted.

Actual current-base authoring against `{prep['main']}`, prototype catalog and the real SpecGraph loader all exited 0; the loader reported no issues. The earlier invalid-main457 authoring failure is still historical. At this checkpoint the motion gate still requires eleven files, 130 assertions including the Portal reentry title exactly once, twelve native positives and one unsupported split refusal. A later external motion commit adds seven cases; this checkpoint does not claim that future inventory has already been executed.

## Two distinct native failures on the same frozen input

Both executions used fresh Chromium processes and fresh per-case pages, the same source tree, identical 451 input hashes, bundle/CSS bytes and browser `{first['browserVersion']}`. The original sandbox setting, 12ms bound, 1000ms observer watchdog, frame waits and case deadlines were unchanged.

| Actual execution | Passed | Failed | Pending | Real first error |
| --- | --- | --- | --- | --- |
| First native run | 5 | 1 | 0 | Dialog enter-close cold-start mask acknowledgement: 13.400062476158382ms is not below 12ms |
| One controlled fresh recheck | 5 | 1 | 0 | The same Dialog case, later visual-enter screenshot sampling: `captureInterior` timed out after the original 1000ms |

The first run's first RAF callback was sampled about 285ms after its frame timestamp. Its later fitted linear residuals remained below 12ms, but the actual acknowledgement assertion failed. Source inspection established that the new retained-view branch is not taken by this initial cold attachment. These facts justified one controlled repeat; they do not prove an external cause or turn that first result green.

In the second run, the measured entry and close assertions completed before a separate screenshot journey. That later visual-enter trace has fifteen samples and zero samples in the unchanged opacity interval 0.55–0.85. The trace jumps from opacity {before['content']['opacity']} to {after['content']['opacity']} over {gap:.3f}ms; the latter callback was sampled {after['time'] - after['frameTimestamp']:.3f}ms after its RAF timestamp. Therefore the evidence does not support blaming only late installation of `waitForFunction`. All three AlertDialog cases passed in this run. Errors arrays are empty and final disposal disconnected all three nodes, restored owned styles and cleared inert state in both failed cases.

The two partial runs are not combined into 6/6. No third same-input retry is authorized by this record. Preserve the newer external branch, then obtain actual combined-source evidence, preferably through the original hosted workflow. The historical earlier 6/6 run belongs to its older source and is not reused as this checkpoint's native result.

## Archive and review boundary

[The manifest](evidence/{name}/manifest.json) binds raw/stored hashes, source hashes, all execution logs, both native reports, both complete native artifact sets and the actual scripts. Raw evidence is compressed losslessly; it is not reformatted. The two root peer receipts remain unchanged and are local source reviews, not GitHub APPROVED dispositions.

Draft-family generation, CLI build, website token generation, public/workspace types and original-deadline graph/schema were not executed on this checkpoint; they remain work for the final combined source. The old graph/schema failures and old type passes remain attributed to their original source. The original strict hosted Bootstrap/public workflow still owns final combination and browser acceptance. Physical refresh-rate/input-to-photon, assistive technology, non-Web and umbrella release acceptance are outside these local receipts.

![Second run: actual entered Dialog before the later screenshot-sampling timeout](evidence/{name}/native-recheck/dialog-entered.png)
''')
    run(['corepack', 'pnpm@10.32.1', 'exec', 'prettier', '--write', str(record.relative_to(root)), str(manifest.relative_to(root))], 'checkpoint-evidence-format')
    for entry in entries:
        stored = (evidence / entry['file']).read_bytes()
        raw = gzip.decompress(stored) if entry['encoding'] == 'gzip' else stored
        assert len(stored) == entry['storedBytes'] and digest(stored) == entry['storedSha256']
        assert len(raw) == entry['rawBytes'] and digest(raw) == entry['rawSha256']
    assert all(sha(root / path) == expected for path, expected in prep['sourceSha256'].items())
    assert all(sha(root / item['path']) == item['sha256'] for item in prep['restored16'])
    assert sha(root / historical_record) == source_manifest['historicalPreserved']['recordSha256']
    assert sha(root / historical_manifest) == source_manifest['historicalPreserved']['manifestSha256']
    run(['git', '-c', 'core.fsmonitor=false', '-c', 'submodule.recurse=false', 'add', '--', str(record.relative_to(root)), str(evidence.relative_to(root))], 'checkpoint-evidence-stage')
    added = git('diff', '--cached', '--name-only', prep['tree']).splitlines()
    assert all(path == str(record.relative_to(root)) or path.startswith(str(evidence.relative_to(root)) + '/') for path in added)
    assert not git('diff', '--name-only')
    run(['git', 'diff', '--cached', '--check'], 'checkpoint-evidence-whitespace')
    state.update(phase='prepared-not-committed', head=prep['head'], mergeHeads=merge_heads, sourceTree=prep['tree'], tree=git('write-tree'), record=str(record.relative_to(root)), recordSha256=sha(record), manifest=str(manifest.relative_to(root)), manifestSha256=sha(manifest), files=len(entries), rawBytes=sum(e['rawBytes'] for e in entries), storedBytes=sum(e['storedBytes'] for e in entries), evidenceOnlyAddedPaths=added, nativeResults=[first['result'], second['result']], sourceStable=True)
except BaseException as exc:
    state.update(phase='pending-child' if 'pendingChild' in state else 'failed', error=repr(exc), traceback=traceback.format_exc())
save()
