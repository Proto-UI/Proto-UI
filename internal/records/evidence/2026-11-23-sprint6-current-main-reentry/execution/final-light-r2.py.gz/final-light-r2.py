from pathlib import Path
import os, json, subprocess, traceback, hashlib, fcntl, time, signal, re

root = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
base = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123-ops/final-23122')
out = base / 'final-current' / 'light-r2'
out.mkdir(exist_ok=True)
lock = open(out / 'light.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
status = out / 'light-status.json'
assert not status.exists(), 'Reconcile the existing one-shot receipt.'
env = dict(os.environ)
env['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:' + env['PATH']
env['TMPDIR'] = '/var/tmp/s6-75d5-modal'
env['GIT_OPTIONAL_LOCKS'] = '0'
state = {'phase': 'starting', 'pid': os.getpid(), 'runs': []}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save():
    temp = status.with_suffix('.tmp')
    temp.write_text(json.dumps(state, indent=2) + '\n')
    os.replace(temp, status)

def run(args, name, timeout=180, allowed=(0,)):
    state['phase'] = name
    save()
    log = out / (name + '.log')
    started = time.monotonic()
    with log.open('w') as stream:
        proc = subprocess.Popen(args, cwd=root, env=env, stdin=subprocess.DEVNULL,
                                stdout=stream, stderr=subprocess.STDOUT, text=True,
                                start_new_session=True)
        state['childPid'] = proc.pid
        save()
        try:
            code = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            # This group is this command's own finite test/validation process.
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                try:
                    proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    state['pendingChild'] = {'name': name, 'pid': proc.pid,
                                             'reason': 'Own process group has not returned after termination; reconcile before source restoration or another writer.'}
                    save()
                    raise
            state['timedOutCommand'] = {'name': name, 'pid': proc.pid, 'outerSeconds': timeout}
            raise
    state.pop('childPid', None)
    state['runs'].append({'name': name, 'command': args, 'exit': code,
                          'seconds': round(time.monotonic() - started, 3),
                          'logSha256': sha(log)})
    save()
    assert code in allowed, {'command': name, 'exit': code, 'tail': log.read_text()[-2500:]}
    return code

def git(*args):
    return subprocess.check_output(['git', '-c', 'core.fsmonitor=false',
                                    '-c', 'submodule.recurse=false', *args],
                                   cwd=root, env=env, text=True, timeout=120).strip()

def report(name):
    path = out / (name + '.json')
    value = json.loads(path.read_text())
    state[name] = {key: value[key] for key in ['numPassedTests', 'numFailedTests',
                                              'numPendingTests', 'numTotalTests']}
    state[name]['reportSha256'] = sha(path)
    save()
    return value

def vitest(files, name, extra=(), timeout=300, allowed=(0,)):
    return run(['corepack', 'pnpm@10.32.1', 'exec', 'vitest', 'run', *files, *extra,
                '--maxWorkers=1', '--no-file-parallelism', '--reporter=json',
                '--outputFile=' + str(out / (name + '.json'))], name, timeout, allowed)

try:
    save()
    prep = json.loads((base / 'final-current' / 'preparation-status.json').read_text())
    assert prep['phase'] == 'prepared-not-committed'
    assert git('rev-parse', 'HEAD') == prep['head']
    merge_state = Path(git('rev-parse', '--git-path', 'MERGE_HEAD'))
    if not merge_state.is_absolute():
        merge_state = root / merge_state
    assert merge_state.read_text().splitlines() == prep['mergeHeads']
    assert git('write-tree') == prep['tree']
    sources = prep['sourceSha256']
    assert all(sha(root / path) == digest for path, digest in sources.items())
    state.update(sourceBefore=sources, preparedTree=prep['tree'], head=prep['head'], main=prep['main'])
    save()

    prior = base / 'final-current' / 'portal-counterfactual.json'
    assert sha(prior) == '953c697b03d3811f8b0aaf7848e449982ba6064eb33836547a77cda9488ae6e9'
    state['priorCounterfactual'] = {'file': str(prior), 'reportSha256': sha(prior), 'passed': 0, 'failed': 1, 'filterExcluded': 30, 'actualFailure': 'expected true to be false at portal-conceal.test.ts:546 (detached marker)', 'boundary': 'Current source old-helper negative failed earlier than the historical press-count failure. Do not relabel it as the historical press1-to2 reproduction. This continuation runs every current fixed-candidate assertion unchanged.'}
    save()
    portal = 'packages/adapters/web-component/test/portal-conceal.test.ts'
    title = 'retains the reopened event gate after native detached attribute reentry'

    selected = [portal,
                'packages/adapters/web-component/test/portal-first-render-reentry.test.ts',
                'packages/adapters/web-component/test/dialog-overlay.test.ts',
                'packages/prototypes/bootstrap-2-3-2/test/modal-presence-presentation.test.ts',
                'packages/cli/test/text-prototype.test.ts']
    vitest(selected, 'combined-dom', timeout=600)
    green = report('combined-dom')
    assert green['numFailedTests'] == 0 and green['numPendingTests'] == 0
    assert {str(Path(f['name']).relative_to(root)) for f in green['testResults']} == set(selected)
    portal_rows = next(f['assertionResults'] for f in green['testResults'] if f['name'].endswith(portal))
    assert len(portal_rows) == 31 and sum(a['title'] == title and a['status'] == 'passed' for a in portal_rows) == 1
    assert all(a['status'] == 'passed' for f in green['testResults'] for a in f['assertionResults'])

    run(['node', '--test', 'scripts/test/check-bootstrap-motion-evidence.test.mjs',
         'scripts/test/bootstrap-state-controls-evidence.test.mjs'], 'strict-node-controls', 240)
    tap = (out / 'strict-node-controls.log').read_text()
    counts = {key: int(re.search(r'^# ' + key + r' (\d+)$', tap, re.M).group(1))
              for key in ['tests', 'pass', 'fail', 'skipped', 'todo']}
    state['nodeCounts'] = counts
    save()
    assert counts == {'tests': 98, 'pass': 98, 'fail': 0, 'skipped': 0, 'todo': 0}, counts

    run(['corepack', 'pnpm@10.32.1', 'check:spec-authoring', '--', '--base', prep['main']],
        'current-base-authoring', 300)
    run(['corepack', 'pnpm@10.32.1', 'check:prototype-catalog'], 'current-catalog', 300)
    loader = out / 'current-spec-loader.mjs'
    loader.write_text("import assert from 'node:assert/strict';\n"
                      "import { writeFileSync } from 'node:fs';\n"
                      "import { loadSpecWorkspaceFromDirectory } from '" + str(root / 'packages/spec/engine/src/node.ts') + "';\n"
                      "const start=performance.now();\n"
                      "const workspace=await loadSpecWorkspaceFromDirectory(" + json.dumps(str(root / 'spec')) + ");\n"
                      "const result={entityCount:workspace.entities.length,issues:workspace.issues,elapsedMs:performance.now()-start};\n"
                      "writeFileSync(" + json.dumps(str(out / 'current-spec-loader.json')) + ",JSON.stringify(result,null,2)+'\\n');\n"
                      "console.log(JSON.stringify(result));assert.deepEqual(result.issues,[]);\n")
    run(['node', '--import', 'tsx', str(loader)], 'current-spec-loader', 300)

    assert all(sha(root / path) == digest for path, digest in sources.items())
    assert not git('diff', '--name-only')
    state.update(phase='completed', sourceStable=True)
except BaseException as exc:
    state.update(phase='pending-child' if 'pendingChild' in state else 'failed',
                 error=repr(exc), traceback=traceback.format_exc())
save()
