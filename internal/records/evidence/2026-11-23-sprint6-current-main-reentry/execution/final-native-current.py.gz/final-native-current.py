from pathlib import Path
import os, json, hashlib, subprocess, traceback, fcntl, time, signal

root = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
base = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123-ops/final-23122')
out = base / 'final-current'
status = out / 'native-status.json'
lock = open(out / 'native.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not status.exists(), 'Reconcile the existing native receipt before another invocation.'
env = dict(os.environ)
env['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:' + env['PATH']
env['TMPDIR'] = '/var/tmp/s6-75d5-modal'
env['CHROME_PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/playwright-browsers/chromium-1208/chrome-linux64/chrome'
env['LC_ALL'] = 'C'
env['GIT_OPTIONAL_LOCKS'] = '0'
env['PUI_FINF_FEATURE_EVIDENCE_DIR'] = str(out / 'native-evidence')
state = {'phase': 'starting', 'pid': os.getpid(), 'scope': 'Current combined source in actual sandboxed headless Chromium, Web/document Modal six cases. Prepared dirty merge; not canonical hosted Bootstrap acceptance or physical/AT/performance acceptance.'}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save():
    tmp = status.with_suffix('.tmp')
    tmp.write_text(json.dumps(state, indent=2) + '\n')
    os.replace(tmp, status)

def git(*args):
    return subprocess.check_output(['git', '-c', 'core.fsmonitor=false', '-c', 'submodule.recurse=false', *args], cwd=root, env=env, text=True, timeout=120).strip()

try:
    save()
    prep = json.loads((out / 'preparation-r3-status.json').read_text())
    light = json.loads((out / 'light-final' / 'status.json').read_text())
    assert prep['phase'] == 'prepared-not-committed'
    assert light['phase'] == 'completed' and light['sourceStable']
    assert git('rev-parse', 'HEAD') == prep['head']
    assert git('write-tree') == prep['tree']
    assert not git('diff', '--name-only')
    sources = prep['sourceSha256']
    assert all(sha(root / file) == digest for file, digest in sources.items())
    assert Path(env['CHROME_PATH']).is_file() and os.access(env['CHROME_PATH'], os.X_OK)
    tmp = Path(env['TMPDIR'])
    assert tmp.is_dir() and tmp.stat().st_uid == os.getuid()
    state.update(head=prep['head'], remote=prep['remote'], main=prep['main'], preparedTree=prep['tree'], sourceBefore=sources, chromePath=env['CHROME_PATH'], TMPDIR=env['TMPDIR'])
    test = 'packages/prototypes/bootstrap-2-3-2/test/modal-presence.browser.test.ts'
    command = ['corepack', 'pnpm@10.32.1', 'exec', 'vitest', 'run', test, '--pool=forks', '--maxWorkers=1', '--minWorkers=1', '--no-file-parallelism', '--reporter=json', '--outputFile=' + str(out / 'native.json')]
    state.update(phase='running', command=command)
    save()
    started = time.monotonic()
    with (out / 'native.log').open('w') as log:
        proc = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True)
        state['childPid'] = proc.pid
        save()
        try:
            code = proc.wait(timeout=360)
        except subprocess.TimeoutExpired:
            state['outerTimeout'] = 360
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                try:
                    proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    state['pendingChild'] = proc.pid
            raise
    state.pop('childPid', None)
    state.update(exit=code, seconds=round(time.monotonic() - started, 3), logSha256=sha(out / 'native.log'))
    report = json.loads((out / 'native.json').read_text())
    assert len(report['testResults']) == 1
    assert Path(report['testResults'][0]['name']).relative_to(root).as_posix() == test
    state['result'] = {key: report[key] for key in ['numPassedTests', 'numFailedTests', 'numPendingTests', 'numTotalTests']}
    state['reportSha256'] = sha(out / 'native.json')
    assert all(sha(root / file) == digest for file, digest in sources.items())
    native = out / 'native-evidence' / 'bootstrap-modal-presence'
    if (native / 'source.json').exists():
        source = json.loads((native / 'source.json').read_text())
        assert all(sha(root / file) == digest for file, digest in source['sourceSha256'].items())
        state.update(fullSourceClosureStable=len(source['sourceSha256']), browserVersion=source.get('browserVersion'), bundleSha256=source.get('bundleSha256'), cssSha256=source.get('cssSha256'), sourceManifestSha256=sha(native / 'source.json'))
    if native.exists():
        state['artifacts'] = [{'file': f.relative_to(out).as_posix(), 'bytes': f.stat().st_size, 'sha256': sha(f)} for f in sorted(native.rglob('*')) if f.is_file()]
    state['sourceStable'] = True
    assert code == 0 and state['result'] == {'numPassedTests': 6, 'numFailedTests': 0, 'numPendingTests': 0, 'numTotalTests': 6}
    assert all(row['status'] == 'passed' for row in report['testResults'][0]['assertionResults'])
    state['phase'] = 'completed'
except BaseException as exc:
    state.update(phase='pending-child' if 'pendingChild' in state else 'failed', error=repr(exc), traceback=traceback.format_exc())
save()
