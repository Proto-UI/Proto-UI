from pathlib import Path
import os, json, hashlib, subprocess, traceback, fcntl, time

root = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
base = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123-ops/final-23122')
out = base / 'final-current'
status = out / 'preparation-r3-status.json'
lock = open(out / 'preparation-r3.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not status.exists(), 'Reconcile the existing repair-preparation receipt first.'
env = dict(os.environ)
env['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:' + env['PATH']
env['GIT_OPTIONAL_LOCKS'] = '0'
state = {'phase': 'starting', 'pid': os.getpid(), 'runs': []}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save():
    temp = status.with_suffix('.tmp')
    temp.write_text(json.dumps(state, indent=2) + '\n')
    os.replace(temp, status)

def git(*args):
    return subprocess.check_output(['git', '-c', 'core.fsmonitor=false', '-c', 'submodule.recurse=false', *args], cwd=root, env=env, text=True, timeout=120).strip()

def run(args, name, timeout=180):
    state['phase'] = name
    save()
    started = time.monotonic()
    log = out / (name + '.log')
    with log.open('w') as stream:
        proc = subprocess.Popen(args, cwd=root, env=env, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        state['childPid'] = proc.pid
        save()
        try:
            code = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            # Mutating commands may still be completing real Git I/O.
            state['pendingChild'] = {'pid': proc.pid, 'command': name, 'outerSeconds': timeout}
            save()
            raise
    state.pop('childPid', None)
    state['runs'].append({'name': name, 'command': args, 'exit': code, 'seconds': round(time.monotonic() - started, 3), 'logSha256': sha(log)})
    save()
    assert code == 0, {'command': name, 'exit': code}

try:
    save()
    prep = json.loads((out / 'preparation-status.json').read_text())
    failed = json.loads((out / 'light-r2' / 'light-status.json').read_text())
    report_path = out / 'light-r2' / 'combined-dom.json'
    report = json.loads(report_path.read_text())
    assert prep['phase'] == 'prepared-not-committed'
    assert failed['phase'] == 'failed' and not failed.get('pendingChild')
    for pid in (failed['pid'], failed.get('childPid')):
        if pid is not None:
            assert not (Path('/proc') / str(pid)).exists(), pid
    failures = [(f, row) for f in report['testResults'] for row in f['assertionResults'] if row['status'] == 'failed']
    assert len(failures) == 1, 'Do not apply this narrow repair to an unexplained additional failure.'
    file, row = failures[0]
    assert row['title'] == 'retains the reopened event gate after native detached attribute reentry'
    assert 'expected true to be false' in '\n'.join(row['failureMessages'])
    assert 'portal-conceal.test.ts:546:' in '\n'.join(row['failureMessages'])
    assert report['numPendingTests'] == 0 and len(report['testResults']) == 5
    assert git('rev-parse', 'HEAD') == prep['head']
    assert git('write-tree') == prep['tree']
    assert not git('diff', '--name-only')
    assert all(sha(root / file) == digest for file, digest in prep['sourceSha256'].items())

    adapter = root / 'packages/adapters/web-component/src/adapt.ts'
    before = adapter.read_text()
    assert sha(adapter) == '86d813cec00052790caee8b031d1ee123a30320a00d4d811219046323f6edc89'
    old = '''        if (snapshot.present && wasConcealing && owner.hasView) {
          // The retained epoch never unmounted. Reveal it immediately so a
          // newer open/focus request is not queued behind the canceled barrier.
'''
    new = '''        if (
          snapshot.present &&
          owner.hasView &&
          (wasConcealing || thisEl.hasAttribute(PUI_VIEW_DETACHED_ATTR))
        ) {
          // Marker-first close can reenter before concealment starts. The
          // retained epoch never unmounted, so project the newer present intent
          // immediately instead of queuing it behind the old retirement.
'''
    assert before.count(old) == 1
    after = before.replace(old, new)
    assert hashlib.sha256(after.encode()).hexdigest() == '1c88a9be882a70d672006c9a4450b2125bf30b22b9a92ca4f87c1028aea70ee8'
    state.update(phase='applying-narrow-repair', priorPreparedTree=prep['tree'], rawFixedCandidateFailure=str(report_path), rawFixedCandidateFailureSha256=sha(report_path), baselineCounts={key: report[key] for key in ('numPassedTests', 'numFailedTests', 'numPendingTests', 'numTotalTests')})
    save()
    adapter.write_text(after)
    run(['corepack', 'pnpm@10.32.1', 'exec', 'prettier', '--check', 'packages/adapters/web-component/src/adapt.ts'], 'retained-present-format-check', 180)
    assert sha(adapter) == '1c88a9be882a70d672006c9a4450b2125bf30b22b9a92ca4f87c1028aea70ee8'
    run(['git', '-c', 'core.fsmonitor=false', '-c', 'submodule.recurse=false', 'add', '--', 'packages/adapters/web-component/src/adapt.ts'], 'retained-present-stage', 180)
    assert not git('diff', '--name-only')
    sources = dict(prep['sourceSha256'])
    sources['packages/adapters/web-component/src/adapt.ts'] = sha(adapter)
    assert all(sha(root / file) == digest for file, digest in sources.items())
    tree = git('write-tree')
    patch = subprocess.check_output(['git', 'diff', '--cached', '--binary', prep['tree'], '--', 'packages/adapters/web-component/src/adapt.ts'], cwd=root, env=env)
    (out / 'retained-present-actual.patch').write_bytes(patch)
    assert git('diff', '--cached', '--name-only', prep['tree']) == 'packages/adapters/web-component/src/adapt.ts'
    for key in ('head', 'remote', 'main', 'mergeHeads', 'manualSourcePaths', 'restored16', 'mainLastIncrement', 'mainHcSha256', 'dependencyLockUnchanged'):
        state[key] = prep[key]
    state.update(phase='prepared-not-committed', tree=tree, sourceSha256=sources, patchSha256=sha(out / 'retained-present-actual.patch'), scope='Only the already-owned retained-view present branch now also handles marker-first reentry before concealment starts. All original test assertions, deadlines, new-acquisition path and main close order remain unchanged.')
except BaseException as exc:
    state.update(phase='pending-child' if 'pendingChild' in state else 'failed', error=repr(exc), traceback=traceback.format_exc())
save()
