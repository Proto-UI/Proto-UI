from pathlib import Path
import os,json,subprocess,traceback,hashlib,fcntl,time,datetime
root=Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123');base=Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123-ops/final-23122');out=base/'final-current';out.mkdir(exist_ok=True)
lock=open(out/'prepare.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
status=out/'preparation-status.json';assert not status.exists(),'Reconcile the existing one-shot receipt.'
env=dict(os.environ);env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env['PATH'];env['TMPDIR']='/var/tmp/s6-75d5-modal';env['GIT_OPTIONAL_LOCKS']='0'
state={'phase':'starting','pid':os.getpid(),'runs':[],'pushMutations':0,'dispatchMutations':0}
head='366a38112bd0ba994f2ef6a7743ffc981a051bfe';remote='84ef7893e732a316388aeb730af1758b96f703e8';main='0fbb52ef832cc27c78e24c28c59a55a16f51d7fe';priorTree='e2683714e4aae455bd05e73073975dfd14f88197'
def save():
 tmp=status.with_suffix('.tmp');tmp.write_text(json.dumps(state,indent=2)+'\n');os.replace(tmp,status)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def command(args,name,timeout=180,allowed=(0,)):
 state['phase']=name;save();start=time.monotonic();log=out/(name+'.log')
 with log.open('w') as stream:
  proc=subprocess.Popen(args,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,text=True)
  state['childPid']=proc.pid;save()
  try:code=proc.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   state['pendingChild']={'pid':proc.pid,'command':args,'reason':'Still running; reconcile before another writer.'};save();raise
 state.pop('childPid',None);value=log.read_text()
 state['runs'].append({'name':name,'command':args,'exit':code,'seconds':round(time.monotonic()-start,3),'logSha256':sha(log)});save()
 assert code in allowed,{'command':name,'exit':code,'tail':value[-2500:]}
 return value.strip()
def git(*args,name,timeout=180,allowed=(0,)):return command(['git','-c','core.fsmonitor=false','-c','submodule.recurse=false',*args],name,timeout,allowed)
try:
 save()
 assert not Path('/proc/2757872').exists() and not Path('/proc/2758892').exists()
 old=json.loads((base/'integration24/prepare-status.json').read_text());assert old['phase']=='pending-child'
 publication=json.loads((base/'integration24/normal-signed-24-commit.log').read_text());assert publication['status']=='published' and publication['head']==head
 assert git('rev-parse','HEAD',name='recovered-head')==head
 assert git('rev-parse','HEAD^{tree}',name='recovered-tree')==priorTree
 assert git('rev-list','--parents','-n','1','HEAD',name='recovered-parents').split()==[head,'db4181f75d2b033fc90b4599c44d66d57e3ffc20','24e553961e7a898b74b959792d35f49364f35efc']
 body=git('log','-1','--format=%B',name='recovered-message')
 identity=git('log','-1','--format=%cn%x00%ce',name='recovered-committer').split('\0')
 assert 'Signed-off-by: '+identity[0]+' <'+identity[1]+'>' in body.splitlines()
 assert not git('status','--porcelain=v1','--untracked-files=all',name='recovered-clean')
 state['reconciliation']={'originalWrapper':'pending-child after 900s','actualPublishedHead':head,'actualTree':priorTree,'exactParentsAndSignoff':True,'clean':True,'originalWrapperExitIsNotRewritten':True};save()
 live=json.loads(command(['gh','api','repos/Proto-UI/Proto-UI/pulls/1712'],'fresh-pr',90));assert live['state']=='open' and not live['merged'] and live['head']['sha']==remote,live['head']['sha']
 liveMain=json.loads(command(['gh','api','repos/Proto-UI/Proto-UI/git/ref/heads/main'],'fresh-main',90));assert liveMain['object']['sha']==main,liveMain['object']['sha']
 git('fetch','--no-tags','origin','refs/heads/sprint6/bootstrap-liquid-delivery-20261122:refs/remotes/sprint6-publish-75d5/head','refs/heads/main:refs/remotes/sprint6-publish-75d5/main',name='fetch-current',timeout=300)
 assert git('rev-parse','refs/remotes/sprint6-publish-75d5/head',name='fetched-pr')==remote
 assert git('rev-parse','refs/remotes/sprint6-publish-75d5/main',name='fetched-main')==main
 git('merge','--no-ff','--no-commit',remote,main,name='normal-current-union',timeout=600,allowed=(0,1,2))
 mergePath=Path(git('rev-parse','--git-path','MERGE_HEAD',name='merge-state-path'))
 if not mergePath.is_absolute():mergePath=root/mergePath
 assert mergePath.exists(),'Read actual merge outcome before any retry.'
 mergeHeads=mergePath.read_text().splitlines();assert set(mergeHeads)=={remote,main},mergeHeads
 conflicts=git('diff','--name-only','--diff-filter=U',name='union-conflicts').splitlines()
 state.update(head=head,remote=remote,main=main,mergeHeads=mergeHeads,conflicts=conflicts);save()
 git('diff','--cc',name='union-conflict-patch')
 assert not conflicts,conflicts
 resolved=json.loads((base/'integration8f6/resolve-status.json').read_text());expected=dict(resolved['sourceAfterPreflight'])
 native='packages/prototypes/bootstrap-2-3-2/test/modal-presence.browser.test.ts';expected[native]='40a9416b4a5e5e340a48d0ee245b34b66609e1679005a30c1d16827dbd5727fc'
 for path,h in expected.items():assert sha(root/path)==h,{'sourceUnionDrift':path}
 raw=resolved['restored16'];assert len(raw)==16
 assert all(r['path'] in (root/'.prettierignore').read_text().splitlines() for r in raw)
 git('restore','--source=24e553961e7a898b74b959792d35f49364f35efc','--staged','--worktree','--',*[r['path'] for r in raw],name='restore-original16-after-main')
 for row in raw:assert sha(root/row['path'])==row['sha256'],row['path']
 hc='spec/host-caps/HC-CONTROL-LABEL-0001.yaml'
 mainHc=subprocess.check_output(['git','show',main+':'+hc],cwd=root,env=env,timeout=120)
 assert (root/hc).read_bytes()==mainHc,'Keep current main complete two-ID entity.'
 assert mainHc.count(b'  - id: HC-CONTROL-LABEL-0001-GPUI\n')==1 and mainHc.count(b'  - id: HC-CONTROL-LABEL-0001-GPUI-PROVIDER\n')==1
 archive='internal/records/evidence/2026-11-23-sprint6-main-view-retirement';record='internal/records/2026-11-23-sprint6-main-view-retirement.md'
 assert not git('diff','66ebd33e0dfc3465c6547d552095d0d4a104f12f','--name-only','--',archive,record,name='prior93-preserved')
 material=json.loads((root/'internal/records/artifacts/2026-11-24-sprint6-held-image-decode-reuse/manifest.json').read_text())
 for row in material['sourceFiles']:assert sha(root/row['path'])==row['sha256'],row['path']
 state['treeBeforePreflight']=git('write-tree',name='tree-before-preflight');save()
 command(['corepack','pnpm@10.32.1','lint-staged'],'normal-hook-preflight',900)
 tree=git('write-tree',name='tree-after-preflight')
 drift=git('diff','--name-only',state['treeBeforePreflight'],tree,name='preflight-drift').splitlines();state['preflightChangedPaths']=drift;save();assert not drift,drift
 assert not git('diff','--name-only',name='no-unstaged')
 for path,h in expected.items():assert sha(root/path)==h,path
 for row in raw:assert sha(root/row['path'])==row['sha256'],row['path']
 assert not git('diff','66ebd33e0dfc3465c6547d552095d0d4a104f12f','--name-only','--',archive,record,name='prior93-after-preflight')
 original=json.loads((base/'source-validation-final-status.json').read_text())['sourceBefore']
 for path,h in original.items():
  if path not in expected and path!=hc:assert sha(root/path)==h,path
 delta=git('diff','--name-only','0adde15d1e5dacb112cdad4d8d7811e015cc4456',main,name='main-last-increment-paths').splitlines();assert len(delta)==4,delta
 extra=['.prettierignore','package.json','pnpm-lock.yaml','pnpm-workspace.yaml','tsconfig.workspace.json','.github/workflows/ci.yml','scripts/test/bootstrap-state-controls-receipt.mjs','apps/www/src/content/docs/zh-cn/demo-bootstrap-state-controls.browser.test.ts','apps/www/src/pages/en/test/bootstrap-state-controls.astro','packages/adapters/web-component/test/portal-first-render-reentry.test.ts','packages/adapters/web-component/test/dialog-overlay.test.ts','packages/core/src/spec/owned-template-blueprint.ts','packages/core/src/spec/template.ts','packages/core/src/spec/svg-tags.ts']
 paths=sorted(set(original)|set(expected)|set(delta)|set(extra)|{r['path'] for r in material['sourceFiles']})
 sources={path:sha(root/path) for path in paths}
 previousLock=subprocess.check_output(['git','show',head+':pnpm-lock.yaml'],cwd=root,env=env,timeout=120)
 assert (root/'pnpm-lock.yaml').read_bytes()==previousLock,'New dependency installation must be reconciled.'
 git('diff','--cached',remote,'--',*sorted(set(expected)|set(delta)|{hc}),name='review-source-patch')
 git('diff','--cached',remote,'--','.prettierignore',*[r['path'] for r in raw],name='review-custody-patch')
 git('diff','--cached','--stat',name='review-combined-stat')
 state.update(phase='prepared-not-committed',tree=tree,sourceSha256=sources,manualSourcePaths=list(expected),restored16=raw,mainLastIncrement=delta,mainHcSha256=sha(root/hc),dependencyLockUnchanged=True,scope='Actual standard octopus union of concurrent84 and current main0fbb. Current main two GPUI IDs and CLI/token changes retained. Source/native validation not yet executed.')
except BaseException as exc:state.update(phase='pending-child' if 'pendingChild' in state else 'failed',error=repr(exc),traceback=traceback.format_exc())
save()
