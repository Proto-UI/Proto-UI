from pathlib import Path
import os, json, hashlib, subprocess, traceback, fcntl, time, signal

root = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
base = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123-ops/final-23122')
parent = base / 'final-current'
out = parent / 'native-recheck'
out.mkdir(exist_ok=True)
status = out / 'status.json'
lock = open(out / 'native.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not status.exists(), 'Reconcile the existing native receipt before another invocation.'
env = dict(os.environ)
env['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:' + env['PATH']
env['TMPDIR'] = '/var/tmp/s6-75d5-modal'
env['CHROME_PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/playwright-browsers/chromium-1208/chrome-linux64/chrome'
env['LC_ALL'] = 'C'
env['GIT_OPTIONAL_LOCKS'] = '0'
env['PUI_FINF_FEATURE_EVIDENCE_DIR'] = str(out / 'native-evidence')
state = {'phase': 'starting', 'pid': os.getpid(), 'scope': 'Current combined source in actual sandboxed headless Chromium, Web/document Modal six cases. Prepared dirty merge; not canonical hosted Bootstrap acceptance or physical/AT/performance acceptance.'}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save():
    tmp = status.with_suffix('.tmp')
    tmp.write_text(json.dumps(state, indent=2) + '\n')
    os.replace(tmp, status)

def git(*args):
    return subprocess.check_output(['git', '-c', 'core.fsmonitor=false', '-c', 'submodule.recurse=false', *args], cwd=root, env=env, text=True, timeout=120).strip()

try:
    save()
    prep = json.loads((parent / 'preparation-r3-status.json').read_text())
    light = json.loads((parent / 'light-final' / 'status.json').read_text())
    assert prep['phase'] == 'prepared-not-committed'
    assert light['phase'] == 'completed' and light['sourceStable']
    assert git('rev-parse', 'HEAD') == prep['head']
    assert git('write-tree') == prep['tree']
    assert not git('diff', '--name-only')
    sources = prep['sourceSha256']
    assert all(sha(root / file) == digest for file, digest in sources.items())
    assert Path(env['CHROME_PATH']).is_file() and os.access(env['CHROME_PATH'], os.X_OK)
    tmp = Path(env['TMPDIR'])
    assert tmp.is_dir() and tmp.stat().st_uid == os.getuid()
    state.update(head=prep['head'], remote=prep['remote'], main=prep['main'], preparedTree=prep['tree'], sourceBefore=sources, chromePath=env['CHROME_PATH'], TMPDIR=env['TMPDIR'])
    prior = json.loads((parent / 'native-status.json').read_text())
    assert prior['phase'] == 'failed' and prior['sourceStable']
    assert prior['result'] == {'numPassedTests': 5, 'numFailedTests': 1, 'numPendingTests': 0, 'numTotalTests': 6}
    first_manifest = parent / 'native-evidence/bootstrap-modal-presence/source.json'
    first_source = json.loads(first_manifest.read_text())
    assert all(sha(root / file) == digest for file, digest in first_source['sourceSha256'].items())
    first_case_path = parent / 'native-evidence/bootstrap-modal-presence/dialog-enter-close.json'
    first_case = json.loads(first_case_path.read_text())
    assert first_case['status'] == 'failed' and 'cold start acknowledgement' in first_case['failure']
    assert first_case['errors'] == []
    trace = first_case['entering']
    first_frame = next(sample for sample in trace['samples'] if sample['frameTimestamp'] is not None)
    timing = {}
    for part, target, duration in [('content', 1, 300), ('mask', .8, 150)]:
        points = [sample for sample in trace['samples'] if sample[part]['phase'] == 'entering' and .05 < sample[part]['opacity'] / target < .95]
        starts = sorted(sample['time'] - sample[part]['opacity'] / target * duration for sample in points)
        origin = starts[len(starts) // 2]
        timing[part] = {'interiorCount': len(points), 'inferredOrigin': origin, 'linearResidualMs': max(starts) - min(starts), 'originMinusFirstFrameSampleMs': origin - first_frame['time']}
    analysis = {'input': str(first_case_path), 'inputSha256': sha(first_case_path), 'sourceManifestSha256': sha(first_manifest), 'firstFrameTimestamp': first_frame['frameTimestamp'], 'firstFrameSampleTime': first_frame['time'], 'callbackSampleLatenessMs': first_frame['time'] - first_frame['frameTimestamp'], 'timing': timing, 'initial': first_case['initial'], 'errors': first_case['errors'], 'reasonForSingleRepeat': 'The first cold sample was observed 285ms after its RAF timestamp, while later linear residuals remained below the original 12ms bound. Source inspection confirms the new branch requires an existing view and the runtime does not publish unchanged present intents; this initial false-to-true attachment follows the unchanged cold path. This supports one controlled repeat but does not prove an external cause. The original 5/6 result is retained.', 'repeatBoundary': 'Fresh Vitest process, fresh Chromium browser and fresh per-case pages; exactly the same six cases, Chrome parameters, cold actions, original 12ms bound, observer watchdog and frame waits. No retry loop or warm-page reuse.'}
    (out / 'cold-start-analysis.json').write_text(json.dumps(analysis, indent=2) + '\n')
    state.update(priorNativeReportSha256=prior['reportSha256'], priorNativeSourceManifestSha256=sha(first_manifest), coldStartAnalysisSha256=sha(out / 'cold-start-analysis.json'), singleControlledRepeat=True)
    test = 'packages/prototypes/bootstrap-2-3-2/test/modal-presence.browser.test.ts'
    command = ['corepack', 'pnpm@10.32.1', 'exec', 'vitest', 'run', test, '--pool=forks', '--maxWorkers=1', '--minWorkers=1', '--no-file-parallelism', '--reporter=json', '--outputFile=' + str(out / 'native.json')]
    state.update(phase='running', command=command)
    save()
    started = time.monotonic()
    with (out / 'native.log').open('w') as log:
        proc = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True)
        state['childPid'] = proc.pid
        save()
        try:
            code = proc.wait(timeout=360)
        except subprocess.TimeoutExpired:
            state['outerTimeout'] = 360
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                try:
                    proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    state['pendingChild'] = proc.pid
            raise
    state.pop('childPid', None)
    state.update(exit=code, seconds=round(time.monotonic() - started, 3), logSha256=sha(out / 'native.log'))
    report = json.loads((out / 'native.json').read_text())
    assert len(report['testResults']) == 1
    assert Path(report['testResults'][0]['name']).relative_to(root).as_posix() == test
    state['result'] = {key: report[key] for key in ['numPassedTests', 'numFailedTests', 'numPendingTests', 'numTotalTests']}
    state['reportSha256'] = sha(out / 'native.json')
    assert all(sha(root / file) == digest for file, digest in sources.items())
    native = out / 'native-evidence' / 'bootstrap-modal-presence'
    if (native / 'source.json').exists():
        source = json.loads((native / 'source.json').read_text())
        assert all(sha(root / file) == digest for file, digest in source['sourceSha256'].items())
        assert source['sourceSha256'] == first_source['sourceSha256']
        assert source['bundleSha256'] == prior['bundleSha256'] and source['cssSha256'] == prior['cssSha256']
        state.update(fullSourceClosureStable=len(source['sourceSha256']), browserVersion=source.get('browserVersion'), bundleSha256=source.get('bundleSha256'), cssSha256=source.get('cssSha256'), sourceManifestSha256=sha(native / 'source.json'))
    if native.exists():
        state['artifacts'] = [{'file': f.relative_to(out).as_posix(), 'bytes': f.stat().st_size, 'sha256': sha(f)} for f in sorted(native.rglob('*')) if f.is_file()]
    state['sourceStable'] = True
    assert code == 0 and state['result'] == {'numPassedTests': 6, 'numFailedTests': 0, 'numPendingTests': 0, 'numTotalTests': 6}
    assert all(row['status'] == 'passed' for row in report['testResults'][0]['assertionResults'])
    state['phase'] = 'completed'
except BaseException as exc:
    state.update(phase='pending-child' if 'pendingChild' in state else 'failed', error=repr(exc), traceback=traceback.format_exc())
save()
