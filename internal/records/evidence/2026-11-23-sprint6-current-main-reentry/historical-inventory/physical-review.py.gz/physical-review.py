from pathlib import Path
import os,json,subprocess,traceback,hashlib,fcntl,time,difflib,re,shutil
p=Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123-ops/final-23122');root=Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
lock=open(p/'physical-review.lock','w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
env=dict(os.environ);env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env['PATH'];env['TMPDIR']='/tank/shared/projects/proto-ui-agent/s6t-75d5';env['LC_ALL']='C'
state={'phase':'starting','runs':[]}
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def save():(p/'physical-review-status.json').write_text(json.dumps(state,indent=2)+'\n')
def run(args,name,timeout=90):
 state['phase']=name;save();t=time.monotonic()
 with (p/(name+'.log')).open('w') as out:r=subprocess.run(args,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,text=True,timeout=timeout)
 state['runs'].append({'name':name,'exit':r.returncode,'seconds':round(time.monotonic()-t,3),'logSha256':sha(p/(name+'.log'))});save()
 return r.returncode
def tap(name):
 t=(p/(name+'.log')).read_text()
 return {k:int(re.findall(r'^# '+k+r' (\d+)$',t,re.M)[-1]) for k in ['tests','pass','fail','cancelled','skipped','todo']}
try:
 save()
 prior=json.loads((p/'repair-r3-status.json').read_text());assert prior['phase']=='completed-with-failures' and prior['nodeAfter']['pass']==81
 for rel,digest in prior['sourceAfter'].items():assert sha(root/rel)==digest,rel
 helper=root/'scripts/test/bootstrap-modal-observation.ts';test=root/'scripts/test/check-bootstrap-motion-evidence.test.mjs'
 (p/'physical-helper-before.ts').write_bytes(helper.read_bytes())
 original=test.read_text();marker='  const retired = { ...barrier, portaled: false, unmounted: 3 };'
 a,b=original.rsplit(marker,1);assert b.count('    { detached: false },')==1
 b=b.replace('    { detached: false },','    { connected: false },\n    { detached: false },')
 needle='assert.equal(isPhysicallyRetiredPortal({ ...retired, ...changes }, entered), false);'
 assert b.count(needle)==1
 b=b.replace(needle,'assert.equal(isPhysicallyRetiredPortal({ ...retired, ...changes }, entered), false, JSON.stringify(changes));')
 test.write_text(a+marker+b)
 assert run(['corepack','pnpm@10.32.1','exec','prettier','--write','scripts/test/check-bootstrap-motion-evidence.test.mjs'],'physical-test-format')==0
 state['sameFixtureSha256']=sha(test);state['oldHelperSha256']=sha(helper);save()
 suites=['scripts/test/bootstrap-state-controls-evidence.test.mjs','scripts/test/check-bootstrap-motion-evidence.test.mjs','scripts/test/run-bootstrap-public-validation.test.mjs']
 assert run(['node','--test','--test-reporter=tap',*suites],'physical-counterfactual')==1
 state['counterfactual']=tap('physical-counterfactual')
 assert state['counterfactual']=={'tests':81,'pass':80,'fail':1,'cancelled':0,'skipped':0,'todo':0}
 raw=(p/'physical-counterfactual.log').read_text();assert '{"connected":false}' in raw
 old=helper.read_text();needle="    value.detached === true &&\n    value.portaled === false &&"
 assert old.count(needle)==1
 helper.write_text(old.replace(needle,"    value.detached === true &&\n    value.connected === true &&\n    value.portaled === false &&"))
 assert run(['corepack','pnpm@10.32.1','exec','prettier','--write','scripts/test/bootstrap-modal-observation.ts'],'physical-helper-format')==0
 assert sha(test)==state['sameFixtureSha256']
 state['newHelperSha256']=sha(helper);save()
 assert run(['node','--test','--test-reporter=tap',*suites],'physical-reviewed-green')==0
 state['green']=tap('physical-reviewed-green');assert state['green']=={'tests':81,'pass':81,'fail':0,'cancelled':0,'skipped':0,'todo':0}
 assert sha(test)==state['sameFixtureSha256']
 changes=json.loads((p/'repair-candidate.json').read_text())['changes']
 patch=''.join(''.join(difflib.unified_diff((c['before'] or '').splitlines(True),(root/c['path']).read_text().splitlines(True),fromfile='a/'+c['path'],tofile='b/'+c['path'])) for c in changes)
 (p/'repair-physical-reviewed.patch').write_text(patch)
 state['sourceAfter']={c['path']:sha(root/c['path']) for c in changes}
 state['phase']='completed'
except BaseException as exc:state.update(phase='failed',error=repr(exc),traceback=traceback.format_exc())
save()
