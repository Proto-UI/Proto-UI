# Root source review of the final S6 union

Reviewed at 2026-11-23 20:17 UTC. This is a source peer review, not GitHub approval and not a new browser/test execution.

The prepared tree is 03581c286b2d5f34bbbb83502386e85beffe072b, formed by the normal merge of 84ef7893e732a316388aeb730af1758b96f703e8 and main 0fbb52ef832cc27c78e24c28c59a55a16f51d7fe onto recovered 366a38112bd0ba994f2ef6a7743ffc981a051bfe. Root read the saved source patch in full (review-source-patch.log, SHA-256 735b578cd5a2418c371057045a6f931b0fd918e2e82b6d104d58cf100e9c9fbd) and the preparation receipt. The live worktree was not used as a fixed source during the active counterfactual test.

No remaining source blocker found within the fourteen-file review patch:

- The Web Component change disables the old event gate before a synchronous native attribute reaction can reopen the retained view. The native Custom Element reentry control uses the actual public Props and event paths, verifies the second press, and retains the mounted/unmounted/disposed assertions.
- Modal observation distinguishes a retained closed Portal from physically retired projection. Both predicates bind owner, view epoch, created/mounted counts and the entered reference; the retired predicate requires the acknowledged extra unmount and absence of Portal projection. Concealment, host connection, detached marker and lifetime checks are retained. The predicates only observe captured facts.
- Browser and DOM assertions continue to check retained ownership, projection placement and cancellation/reopen behavior. The existing deadline/frame budgets are not widened. The changes do not treat the detached marker alone as proof of physical withdrawal.
- The motion evidence count increases by exactly the additional Portal control. The gate also requires that specific reentry title exactly once; synthetic refusals cover substitution and duplicate reentry. The upload checks require one owned always-upload artifact with missing-file errors.
- The four current-main CLI/token changes match the already reviewed main increment; unobserved projection members remain uncertain. The Text expectation retains text-muted-foreground and adds the Bootstrap text-inherit token rather than dropping the inherited token.
- The preparation receipt records the entire ControlLabel host-capability file equal to current main, including both distinct acceptance IDs. This review does not alter capability lifecycle or claim new native acceptance.

Root separately processed the five saved custody-diff sections. In each, the concatenated removed and added content is identical after whitespace normalization. That check does not replace byte custody: the preparation receipt records restoration of the sixteen designated originals from 24e553961e7a898b74b959792d35f49364f35efc and preservation of the earlier 93 artifacts. The 267-path combined-main stat was not treated as a fresh review of every historical artifact.

New source/native validation was still running at review time. Its actual results and before/after source hashes must be bound separately before publication; prior successful runs are not represented as execution of this prepared tree.

