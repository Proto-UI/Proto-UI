# Root source review: retained present view during native marker reentry

Reviewed 2026-11-23 20:30 UTC. Source review only; execution of the repaired candidate is still pending.

Root read the complete saved one-file patch d35878c376d0162c65ede06db3620f8431be1ac6eea931ff28e264db24cdb3e5 and the prepared-source receipt. The new prepared tree is 8882ea51f4ce4ce99f37dbdc5df75d5975efa3fc; Web Component adapt.ts has SHA-256 1c88a9be882a70d672006c9a4450b2125bf30b22b9a92ca4f87c1028aea70ee8. The prior 03581c tree's actual 72-pass/1-fail result remains separate evidence.

No source blocker found in this narrow change. It extends the existing immediate reveal path only when the current snapshot is present and the owner already has a view. A native detached marker can identify the interval before concealment begins; the private existing-view requirement remains necessary. No marker alone acquires a new view. New acquisition still follows the original asynchronous path.

The change preserves main's marker-before-conceal ordering and its reentry guards, as well as disabling old event delivery before the native attribute reaction. It avoids carrying an obsolete not-present marker through the newer present intent. It does not add an await, relax a deadline, change the fixture, or bypass the normal acquisition path.

The repaired condition must be identical on both sides of the next old-helper counterfactual. Only the helper ordering should differ. The complete affected DOM assertions, the eventual real Modal browser result, and unchanged-input reuse for the already successful CLI cases must be recorded with their actual source bindings. This peer review is not a GitHub approval or a replacement for those results.

