import * as react from "/home/runner/work/_temp/shader-presentation/browser/shader-presentation-inline-onBiMz/generated/react/Component.tsx";
import * as vue from "/home/runner/work/_temp/shader-presentation/browser/shader-presentation-inline-onBiMz/generated/vue/Component.ts";
import * as vue2 from "/home/runner/work/_temp/shader-presentation/browser/shader-presentation-inline-onBiMz/generated/vue2/Component.js";
import * as wc from "/home/runner/work/_temp/shader-presentation/browser/shader-presentation-inline-onBiMz/generated/wc/Component.ts";
import prototype from "/home/runner/work/Proto-UI/Proto-UI/packages/compiler/test/fixtures/shader-presentation-owner.proto.ts";
import {createShaderBrowserFixture} from "/home/runner/work/Proto-UI/Proto-UI/packages/compiler/test/shader-browser-consumer.ts";
export const fixture=createShaderBrowserFixture({react,vue,vue2,wc}, prototype);
