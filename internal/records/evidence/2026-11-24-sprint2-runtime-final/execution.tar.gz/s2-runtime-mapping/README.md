# Sprint 2 现存完整 runtime / Adapter 回归文件映射

固定源：`5cb80eb937f20982dd7dc8cbc93a90e91d665c31`。冻结工作树干净。**这是文件与原条件的映射，不是执行通过报告。**

去重后 **462 个普通完整测试文件**；另列 **38 个浏览器/原生 runner** 和 **13 个类型配置**。Compiler 全套由独立执行通道承担，不重复计入。原 Issue 分母保持。

## 普通完整文件组

| 组 | 文件数 | 层级和选择原因 |
|---|---:|---|
| `base-controls` | 18 | Base 七类输入与选择控制：完整七类控件、共享选择 owner、真实编辑入口的既有文件；不选取单个新增 case。 |
| `base-forms` | 24 | Base Form / Field / Fieldset / Label 组合：包括异步、嵌套、受控、reset、invalid、error/description、复合控件和所有已有家族投影文件。 |
| `base-collections` | 33 | Base 几何与层级集合：Tree、Resizable、Carousel、Message Scroller、Virtual List、Data Table 及实际通用 collection owner 的完整文件。Finf 混合文件按整个文件执行，附带 Date Picker case 不扩大本次范围。 |
| `base-disclosure` | 13 | Base Disclosure / Transition / Presence 绑定：Accordion、Collapsible、共享 open-state 和 Transition 的完整现存源消费者；Bootstrap 几何运动仍另需真实浏览器。 |
| `base-pointer-consumers` | 7 | Base Select pointer / keyboard / owner 消费：保留完整 Select 文件及 pointer owner、退休、metadata cleanup、结构和滚动焦点交互；不是有限 pointer 字段单测的替代。 |
| `family-consumers` | 79 | 四设计家族完整控件 / 组合 / 偏好消费者：文件有 WC+Happy DOM 行为、Runtime fixture、style/source 断言等多种层级。逐文件记录 imported adapters / source reads，不能统称四宿主原生浏览器。 |
| `input-modules` | 19 | Label / 文本编辑 / Axis / Event / A11y 模块：完整相关模块测试目录；A11y 检查语义投影，不等于真实读屏。 |
| `collection-modules` | 22 | Scroll / Collection / Table / Context 模块：包含 scroll anchor/end-follow/target lease、表结构身份、跨 Context 与重入的完整模块文件。 |
| `presence-owner-runtime` | 40 | 共享 Presence / 物理 view / Runtime 退休与重入：本次 Transition / owner 基础改动的直接回归面。保留 web-presence-adoption 的唯一 native repeated-adoption TODO；该 TODO 不能因其余 case 通过而完成。 |
| `preferences-fallback` | 28 | 偏好、材质支持、fallback 与来源 lease：保留 preference 和 style-support 的不同来源；覆盖失源/晚回调/held decode/重入的现有完整文件。不把整个 Liquid 光学/性能系统加入本 Issue。 |
| `web-input-ingress` | 18 | Web input ingress / pointer / axis / Portal：完整有限 pointer facts、nested/Shadow routing、blur、axis 和 Portal 边界文件；合成 PointerEvent 不宣称物理触笔/触摸。 |
| `adapter-web-component` | 42 | 完整 web-component Adapter 消费文件：各 host 实际调用共用 conformance fixtures；列出完整文件、不把 fixture 单独记为测试，不补造不存在的文件。额外 owner/Context/props/target 文件用于实际共享基础变动。 |
| `adapter-react` | 47 | 完整 react Adapter 消费文件：各 host 实际调用共用 conformance fixtures；列出完整文件、不把 fixture 单独记为测试，不补造不存在的文件。额外 owner/Context/props/target 文件用于实际共享基础变动。 |
| `adapter-vue` | 35 | 完整 vue Adapter 消费文件：各 host 实际调用共用 conformance fixtures；列出完整文件、不把 fixture 单独记为测试，不补造不存在的文件。额外 owner/Context/props/target 文件用于实际共享基础变动。 |
| `adapter-vue2` | 29 | 完整 vue2 Adapter 消费文件：各 host 实际调用共用 conformance fixtures；列出完整文件、不把 fixture 单独记为测试，不补造不存在的文件。额外 owner/Context/props/target 文件用于实际共享基础变动。 |
| `docs-consumer-composition` | 8 | 文档真实 recipe / Preview 组合单元：这是页面 recipe/组合测试，非整个生产页面或截图验收。 |

普通文件默认配置是 Happy DOM。`mapping.json` 每个文件记录真实环境 pragma、adapter import、source-read 标志和 TODO/skip 声明；source-read 标志仅标识该文件含源码读取，不等于整文件只有静态检查。四个 Adapter 目录实际跑各自 integration/conformance，family 文件常只调用 WC。测试名或 `aria-*` 断言不提供读屏证据。

## 执行方法

使用 `python run-files.py --repo <冻结 checkout> --mapping mapping.json --group <组名> --output <新目录>`。默认每文件单独 Vitest 子进程、单 worker、1 GB heap，完整文件不带 `-t`。每文件独立 JSON/stdout/stderr，失败继续保留并令总进程失败；中断/skip/TODO 单独统计，不填为通过。开始前、每文件后和结束核对源 SHA/干净状态。

执行前应取得共享重任务窗口。这个映射生成没有启动测试、TypeScript Program、build 或浏览器。

现有浏览器 `.browser.test.ts` 使用项目 runner `node scripts/test/run-runtime-tests.mjs <具体完整文件>`；analysis `.mjs` 按各脚本既有环境运行，涉及 TS import 的脚本需 `node --import tsx`。浏览器源、字体、样式 producer 与浏览器 sandbox 保持原约束。单独列出这些候选，不把其未执行结果混进普通单元。

## 原条件未由此 inventory 完成

### #1160

全 variant/size/theme/字体缩放命中、失效/图标/换行；Button hover90 最终应用源；全部适用 Form/readOnly；真实编辑选择/取消重挂、平台 IME、group/toolbar 和 AT。现有文件可给明确子集，不能证明每个家族×四宿主×全部条件。

相关组：`base-controls`, `base-forms`, `family-consumers`, `input-modules`, `presence-owner-runtime`, `web-input-ingress`, `adapter-web-component`, `adapter-react`, `adapter-vue`, `adapter-vue2`, `docs-consumer-composition`。

### #1099

完整 Message Scroller 初始位置/anchor/prepend/resize/公告；可移植 Virtual List owner 与适用目标；Data Table 复合切换/table AT；Carousel/Resizable 全输入几何、取消和家族；Tree 全受控与未物化关系。真实物理输入/AT/native/Compiler 不由 Happy DOM 获得。

相关组：`base-collections`, `family-consumers`, `collection-modules`, `presence-owner-runtime`, `adapter-web-component`, `adapter-react`, `adapter-vue`, `adapter-vue2`, `docs-consumer-composition`。

### #1096

Bootstrap 原生高度运动；全 single/multiple/allowEmpty/orientation/RTL、受控拒绝、反转、动态增删卸载；家族特定动画/keepMounted；未选中实验家族/视觉/AT/非 Web。固定 Shadcn/Neo 配方不新增高度动画义务。

相关组：`base-disclosure`, `family-consumers`, `presence-owner-runtime`, `adapter-web-component`, `adapter-react`, `adapter-vue`, `adapter-vue2`。

### #1094

其他完整嵌套/复合组合、受控恢复、validator 失败/重入、各家族 invalid/error/description；Label 跨控命名/激活与真实读屏；CheckboxGroup parent/All/mixed/readOnly + Form 全组合。

相关组：`base-controls`, `base-forms`, `family-consumers`, `input-modules`, `collection-modules`, `presence-owner-runtime`, `adapter-web-component`, `adapter-react`, `adapter-vue`, `adapter-vue2`, `docs-consumer-composition`。

### #793

四宿主所有普通/减弱透明/对比/减弱运动/forced-colors 组合及失源未知回调；GPUI 版本化环境 wire 和材质映射、Compiler 差分/适用后端必须分开接受。光学性能不属于本次单元门。

相关组：`family-consumers`, `preferences-fallback`, `adapter-web-component`, `adapter-react`, `adapter-vue`, `adapter-vue2`。

### #523

#678 初切片/current nodeKey-parentKey 对账、unknown expanded/selected 与拒绝、mode/prop 变化、disabled、未物化 Group 关系、完整动态生命周期；跨宿主/zoom/AT；Shenko Tasks/Playground 的实际消费整合另有原应用门。

相关组：`base-collections`, `family-consumers`, `collection-modules`, `adapter-web-component`, `adapter-react`, `adapter-vue`, `adapter-vue2`, `docs-consumer-composition`。

### #522

原 13 格 adjustment 表全套受控/初始/idle-active更新、采样/commit/cancel、大小步/minmax、resize-reflow/orientation/disabled/readOnly、目标更替/旧回调；separator value/action/announcement/AT，#495 draft 决定及实际 Inspector 采用。

相关组：`base-collections`, `family-consumers`, `input-modules`, `collection-modules`, `web-input-ingress`, `adapter-web-component`, `adapter-react`, `adapter-vue`, `adapter-vue2`, `docs-consumer-composition`。

### #1132

全部 nested/Portal、A-down→B、enter-only、touch cancel/late、pen、invalid/missing事实、keyboard/value/selected保持、blur/reconnect/replacement；物理触摸/笔与合成输入分开；Compiler 四目标完整源对账与原 Vue2 11 诊断 retained red/工具链。

相关组：`base-pointer-consumers`, `family-consumers`, `input-modules`, `presence-owner-runtime`, `web-input-ingress`, `adapter-web-component`, `adapter-react`, `adapter-vue`, `adapter-vue2`。

## 原生 repeated-adoption 义务

`packages/adapters/base/test/web-presence-adoption.test.ts` 保留唯一 TODO：Happy DOM 第二次原生 adoptNode 在 host 代码前失败。普通文件可以报告其余具体 case，但不将 TODO 算成功。另准备真实 Chromium Document A → iframe B → cancel 清理内同步 adopt 回 A 的外置 probe；不修改被冻结的生产源与 TODO。

## 完整列表

### base-controls (18)

```text
packages/prototypes/base/test/as-button.test.ts
packages/prototypes/base/test/button-selection.test.ts
packages/prototypes/base/test/button-view-lifetime.test.ts
packages/prototypes/base/test/checkbox-group-row-paint.test.ts
packages/prototypes/base/test/checkbox.test.ts
packages/prototypes/base/test/input-editor.test.ts
packages/prototypes/base/test/input-reset-lease.test.ts
packages/prototypes/base/test/input-reset.test.ts
packages/prototypes/base/test/input.test.ts
packages/prototypes/base/test/radio-group.test.ts
packages/prototypes/base/test/selection-activate.test.ts
packages/prototypes/base/test/selection-reset-lifecycle.test.ts
packages/prototypes/base/test/switch.test.ts
packages/prototypes/base/test/text-control-composition-lifecycle.test.ts
packages/prototypes/base/test/textarea.test.ts
packages/prototypes/base/test/toggle-group-orientation.test.ts
packages/prototypes/base/test/toggle.test.ts
packages/prototypes/base/test/toolbar-separator-lifecycle.test.ts
```

### base-forms (24)

```text
packages/prototypes/base/test/control-label.projections.test.ts
packages/prototypes/base/test/field-choices.test.ts
packages/prototypes/base/test/field-current-value-admission-review.test.ts
packages/prototypes/base/test/field-nested-consumer.test.ts
packages/prototypes/base/test/field-public-boundaries.test.ts
packages/prototypes/base/test/field-review-regressions.test.ts
packages/prototypes/base/test/field-select-report-order.test.ts
packages/prototypes/base/test/field-select-trigger.test.ts
packages/prototypes/base/test/field-switch-report-order.test.ts
packages/prototypes/base/test/field-switch.test.ts
packages/prototypes/base/test/field-textarea.test.ts
packages/prototypes/base/test/field-validation-interruptions.test.ts
packages/prototypes/base/test/field.test.ts
packages/prototypes/base/test/fieldset-boundaries.test.ts
packages/prototypes/base/test/form-actions-material.test.ts
packages/prototypes/base/test/form-actions-quality.test.ts
packages/prototypes/base/test/form-composite-controls.test.ts
packages/prototypes/base/test/form-composite-family-projections.test.ts
packages/prototypes/base/test/form-family-projections.test.ts
packages/prototypes/base/test/form-field-invalid-feedback.test.ts
packages/prototypes/base/test/form-primitives.test.ts
packages/prototypes/base/test/form-toast-reentry.test.ts
packages/prototypes/base/test/form-upstream-paint.test.ts
packages/prototypes/base/test/select-field-policy.test.ts
```

### base-collections (33)

```text
packages/prototypes/base/test/carousel-continuous.test.ts
packages/prototypes/base/test/carousel-resizable-public-handles.test.ts
packages/prototypes/base/test/collection-control-requests.test.ts
packages/prototypes/base/test/collection-initialization-guards.test.ts
packages/prototypes/base/test/collection-key-list-props.test.ts
packages/prototypes/base/test/collection-nested-audit.test.ts
packages/prototypes/base/test/collection-nested-captures.test.ts
packages/prototypes/base/test/collection-nested-feedback.test.ts
packages/prototypes/base/test/data-table-header-row.test.ts
packages/prototypes/base/test/data-table-page-disabled.test.ts
packages/prototypes/base/test/data-table-recipes.test.ts
packages/prototypes/base/test/finf-collection-compositions.test.ts
packages/prototypes/base/test/finf-collection-hook-contracts.test.ts
packages/prototypes/base/test/finf-collection-projections.test.ts
packages/prototypes/base/test/message-scroller-anchor.test.ts
packages/prototypes/base/test/message-scroller-capture.test.ts
packages/prototypes/base/test/message-scroller.test.ts
packages/prototypes/base/test/resizable-group.test.ts
packages/prototypes/base/test/resizable-model.test.ts
packages/prototypes/base/test/resizable-request-lifetime.test.ts
packages/prototypes/base/test/review-toast-resizable.test.ts
packages/prototypes/base/test/scroll-area.test.ts
packages/prototypes/base/test/table.test.ts
packages/prototypes/base/test/tree-activation.test.ts
packages/prototypes/base/test/tree-controlled-owner.test.ts
packages/prototypes/base/test/tree-hierarchy.test.ts
packages/prototypes/base/test/tree-navigation.test.ts
packages/prototypes/base/test/tree.test.ts
packages/prototypes/base/test/use-collection.test.ts
packages/prototypes/base/test/virtual-list-generation.test.ts
packages/prototypes/base/test/virtual-list-owner.test.ts
packages/prototypes/base/test/virtual-list-resize.test.ts
packages/prototypes/base/test/virtual-list.test.ts
```

### base-disclosure (13)

```text
packages/prototypes/base/test/accordion.test.ts
packages/prototypes/base/test/as-transition.test.ts
packages/prototypes/base/test/collapsible.test.ts
packages/prototypes/base/test/disclosure-presence-binding.test.ts
packages/prototypes/base/test/transition-cold-hook.test.ts
packages/prototypes/base/test/transition-cold-preparation.test.ts
packages/prototypes/base/test/transition-initial-context.test.ts
packages/prototypes/base/test/transition-presentation.test.ts
packages/prototypes/base/test/transition-reentrant.test.ts
packages/prototypes/base/test/transition-timing-matrix.test.ts
packages/prototypes/base/test/use-open-state.test.ts
packages/prototypes/test-utils/test/accordion-recipes.test.ts
packages/prototypes/test-utils/test/collapsible-projections.test.ts
```

### base-pointer-consumers (7)

```text
packages/prototypes/base/test/dropdown-pointer-focus.test.ts
packages/prototypes/base/test/select-drawer-retirement.test.ts
packages/prototypes/base/test/select-metadata-disposal.test.ts
packages/prototypes/base/test/select-pointer-owner.test.ts
packages/prototypes/base/test/select-popper-focus-scroll.test.ts
packages/prototypes/base/test/select-structural-parts.test.ts
packages/prototypes/base/test/select.test.ts
```

### family-consumers (79)

```text
packages/prototypes/bootstrap-2-3-2/test/action-appearance.test.ts
packages/prototypes/bootstrap-2-3-2/test/button.test.ts
packages/prototypes/bootstrap-2-3-2/test/controls.test.ts
packages/prototypes/bootstrap-2-3-2/test/draft-control-projections.test.ts
packages/prototypes/bootstrap-2-3-2/test/historical-overlays-collections-r91.test.ts
packages/prototypes/bootstrap-2-3-2/test/invalid-control-contrast.test.ts
packages/prototypes/bootstrap-2-3-2/test/label-control-consumers-r94.test.ts
packages/prototypes/bootstrap-2-3-2/test/select-complete-projection.test.ts
packages/prototypes/bootstrap-2-3-2/test/toggle.test.ts
packages/prototypes/brutalist/test/action-control-motion.test.ts
packages/prototypes/brutalist/test/button-live-theme.test.ts
packages/prototypes/brutalist/test/button-select-style-closure.test.ts
packages/prototypes/brutalist/test/button.test.ts
packages/prototypes/brutalist/test/checkbox.test.ts
packages/prototypes/brutalist/test/form-action-motion.test.ts
packages/prototypes/brutalist/test/input.test.ts
packages/prototypes/brutalist/test/radio-group.test.ts
packages/prototypes/brutalist/test/scroll-area.test.ts
packages/prototypes/brutalist/test/select-current-recipe.test.ts
packages/prototypes/brutalist/test/select-item-motion.test.ts
packages/prototypes/brutalist/test/select.test.ts
packages/prototypes/brutalist/test/switch-resident-source.test.ts
packages/prototypes/brutalist/test/switch-resident.test.ts
packages/prototypes/brutalist/test/switch-shadow-admission.test.ts
packages/prototypes/brutalist/test/switch.test.ts
packages/prototypes/brutalist/test/table.test.ts
packages/prototypes/brutalist/test/textarea.test.ts
packages/prototypes/brutalist/test/toggle.test.ts
packages/prototypes/brutalist/test/transition.test.ts
packages/prototypes/liquid-glass/test/accordion-material.test.ts
packages/prototypes/liquid-glass/test/button.test.ts
packages/prototypes/liquid-glass/test/collapsible-material.test.ts
packages/prototypes/liquid-glass/test/draft-control-projections.test.ts
packages/prototypes/liquid-glass/test/field-material.test.ts
packages/prototypes/liquid-glass/test/interactive-surface.test.ts
packages/prototypes/liquid-glass/test/liquid-surface-fieldset-r91.test.ts
packages/prototypes/liquid-glass/test/material.test.ts
packages/prototypes/liquid-glass/test/select-complete-projection.test.ts
packages/prototypes/liquid-glass/test/select-material.test.ts
packages/prototypes/liquid-glass/test/toggle.test.ts
packages/prototypes/shadcn/test/binary-profile-transitions.test.ts
packages/prototypes/shadcn/test/button-consumer-style.test.ts
packages/prototypes/shadcn/test/button-ghost-style.test.ts
packages/prototypes/shadcn/test/button-ghost.test.ts
packages/prototypes/shadcn/test/button-new-york-profile.test.ts
packages/prototypes/shadcn/test/button-passive-consumer-closure.test.ts
packages/prototypes/shadcn/test/button-size-style-dom.test.ts
packages/prototypes/shadcn/test/button.test.ts
packages/prototypes/shadcn/test/checkbox-label-composition.test.ts
packages/prototypes/shadcn/test/checkbox.test.ts
packages/prototypes/shadcn/test/collection-profiles-r91.test.ts
packages/prototypes/shadcn/test/dropdown-pointer-foreground.test.ts
packages/prototypes/shadcn/test/form-policy-profile-consumers-r90.test.ts
packages/prototypes/shadcn/test/input-shell-binding.test.ts
packages/prototypes/shadcn/test/input.test.ts
packages/prototypes/shadcn/test/radio-group.test.ts
packages/prototypes/shadcn/test/select-alignment-owner.test.ts
packages/prototypes/shadcn/test/select-dark.test.ts
packages/prototypes/shadcn/test/select-evidence-app-probe.test.ts
packages/prototypes/shadcn/test/select-profile-transitions.test.ts
packages/prototypes/shadcn/test/select-structural-parts.test.ts
packages/prototypes/shadcn/test/select-style-popup.test.ts
packages/prototypes/shadcn/test/select-style-trigger.test.ts
packages/prototypes/shadcn/test/select-surface-style-prop.test.ts
packages/prototypes/shadcn/test/select.test.ts
packages/prototypes/shadcn/test/switch-directional-projection.test.ts
packages/prototypes/shadcn/test/switch-evidence-app-probe.test.ts
packages/prototypes/shadcn/test/switch-hit-lease.test.ts
packages/prototypes/shadcn/test/switch-native-input-evidence.test.ts
packages/prototypes/shadcn/test/switch-size-lifecycle.test.ts
packages/prototypes/shadcn/test/switch-size-preset.test.ts
packages/prototypes/shadcn/test/switch-style-profile.test.ts
packages/prototypes/shadcn/test/switch.test.ts
packages/prototypes/shadcn/test/textarea-evidence-app-probe.test.ts
packages/prototypes/shadcn/test/textarea-style-projection.test.ts
packages/prototypes/shadcn/test/textarea.test.ts
packages/prototypes/shadcn/test/toggle-new-york.test.ts
packages/prototypes/shadcn/test/toggle.test.ts
packages/prototypes/shadcn/test/tree-embedded.test.ts
```

### input-modules (19)

```text
packages/core/test/control-label.test.ts
packages/modules/a11y/test/control-label-source.test.ts
packages/modules/a11y/test/part-relationships.test.ts
packages/modules/a11y/test/web-range.test.ts
packages/modules/a11y/test/web-reference.test.ts
packages/modules/a11y/test/web.test.ts
packages/modules/axis-input/test/axis-input.test.ts
packages/modules/control-label/test/activation-projection.test.ts
packages/modules/control-label/test/anatomy-pair.test.ts
packages/modules/control-label/test/failure-recovery.test.ts
packages/modules/control-label/test/registry.test.ts
packages/modules/control-label/test/web-lifecycle.test.ts
packages/modules/control-label/test/web.test.ts
packages/modules/event/test/contract/event-module.v0.contract.test.ts
packages/modules/event/test/contract/pointer-facts.v0.contract.test.ts
packages/modules/event/test/impl-spec.test.ts
packages/modules/text-control/test/impl-spec.test.ts
packages/modules/text-control/test/selection.test.ts
packages/modules/text-control/test/web.test.ts
```

### collection-modules (22)

```text
packages/modules/collection/test/catalog-boundary.test.ts
packages/modules/context/test/ancestor-compiler-boundary.test.ts
packages/modules/context/test/ancestor.test.ts
packages/modules/context/test/catalog-boundary.test.ts
packages/modules/context/test/contract/context.with-tree.v0.contract.test.ts
packages/modules/context/test/reentrancy.test.ts
packages/modules/scroll/test/anchor.test.ts
packages/modules/scroll/test/availability.test.ts
packages/modules/scroll/test/context-scope.test.ts
packages/modules/scroll/test/end-follow.test.ts
packages/modules/scroll/test/impl-spec.test.ts
packages/modules/scroll/test/projection.test.ts
packages/modules/scroll/test/reader-contact-session.test.ts
packages/modules/scroll/test/session-lifetime.test.ts
packages/modules/scroll/test/target-reveal.test.ts
packages/modules/scroll/test/web-bound-scroll-host.test.ts
packages/modules/scroll/test/web-scroll-axis-direction.test.ts
packages/modules/scroll/test/web-scroll-corner.test.ts
packages/modules/scroll/test/web-scroll-host.test.ts
packages/modules/scroll/test/web-target-reveal.test.ts
packages/modules/table-structure/test/impl-spec.test.ts
packages/modules/table-structure/test/projection-stability.test.ts
```

### presence-owner-runtime (40)

```text
packages/adapters/base/test/adapter-host-delay.test.ts
packages/adapters/base/test/resident-motion-ownership.test.ts
packages/adapters/base/test/resident-motion-palette-lifecycle.test.ts
packages/adapters/base/test/resident-motion-runtime.test.ts
packages/adapters/base/test/resident-motion-trace.test.ts
packages/adapters/base/test/teardown.test.ts
packages/adapters/base/test/view-epoch-owner.test.ts
packages/adapters/base/test/view-operation-owner.test.ts
packages/adapters/base/test/view-visibility.test.ts
packages/adapters/base/test/web-presence-adoption.test.ts
packages/adapters/base/test/web-presence-block-size.test.ts
packages/adapters/base/test/web-presence-presentation.test.ts
packages/adapters/base/test/web-resident-motion.test.ts
packages/modules/feedback/test/deferred-view-sink.test.ts
packages/modules/feedback/test/final-style-sink.test.ts
packages/modules/feedback/test/presence-block-size.test.ts
packages/modules/feedback/test/presence-controller.test.ts
packages/modules/feedback/test/presence-projector.test.ts
packages/modules/feedback/test/presence-semantic-style.test.ts
packages/modules/feedback/test/resident-motion-projector.test.ts
packages/modules/feedback/test/resident-motion.test.ts
packages/modules/feedback/test/root-provenance-sinks.test.ts
packages/modules/feedback/test/sink-kind-retirement.test.ts
packages/modules/presence/test/impl.test.ts
packages/runtime/test/contract/context-lifecycle.v1.contract.test.ts
packages/runtime/test/contract/control-label.cleanup.contract.test.ts
packages/runtime/test/contract/expose-lifecycle.v1.contract.test.ts
packages/runtime/test/contract/lifecycle-with-host.v0.contract.test.ts
packages/runtime/test/contract/lifecycle.checkpoints.v0.contract.test.ts
packages/runtime/test/contract/lifecycle.module-resources.v1.contract.test.ts
packages/runtime/test/contract/lifecycle.registration.v0.contract.test.ts
packages/runtime/test/contract/lifecycle.same-checkpoint-order.contract.test.ts
packages/runtime/test/contract/lifecycle.session.transitions.v1.contract.test.ts
packages/runtime/test/contract/lifecycle.session.update-epoch.v1.contract.test.ts
packages/runtime/test/contract/lifecycle.update-order.strict.v0.contract.test.ts
packages/runtime/test/contract/lifecycle.view-intent.v1.contract.test.ts
packages/runtime/test/contract/lifecycle.view-operation.contract.test.ts
packages/runtime/test/contract/state-lifecycle.v1.contract.test.ts
packages/runtime/test/module-teardown-errors.test.ts
packages/runtime/test/with-host-presence.test.ts
```

### preferences-fallback (28)

```text
packages/adapters/base/test/initial-paint-media-session.test.ts
packages/adapters/base/test/material-sink-wiring.test.ts
packages/adapters/base/test/web-color-scheme-source.test.ts
packages/adapters/base/test/web-material-adoption.test.ts
packages/adapters/base/test/web-material-image.test.ts
packages/adapters/base/test/web-material-independent-review.test.ts
packages/adapters/base/test/web-material-initial-binding.test.ts
packages/adapters/base/test/web-material-initial-paint.test.ts
packages/adapters/base/test/web-material-preferences-ownership.test.ts
packages/adapters/base/test/web-material-preferences-sequence.test.ts
packages/adapters/base/test/web-material-program.test.ts
packages/adapters/base/test/web-material-sink.test.ts
packages/adapters/base/test/web-material-source-independent-review.test.ts
packages/adapters/base/test/web-material-source-refresh-task.test.ts
packages/adapters/base/test/web-material-source.test.ts
packages/adapters/base/test/web-preference-source.test.ts
packages/adapters/base/test/web-preferences.test.ts
packages/adapters/base/test/web-style-support-source.test.ts
packages/modules/feedback/test/material-observer-fault.test.ts
packages/modules/feedback/test/material-visual-result.test.ts
packages/modules/feedback/test/shared-material-policy.test.ts
packages/modules/rule-meta/test/keyed-lease.test.ts
packages/runtime/test/contract/material-intent.runtime.test.ts
packages/runtime/test/contract/rule.color-scheme-lifecycle.contract.test.ts
packages/runtime/test/contract/rule.color-scheme.contract.test.ts
packages/runtime/test/contract/rule.preferences-lifecycle.contract.test.ts
packages/runtime/test/contract/rule.style-support-lifecycle.contract.test.ts
packages/runtime/test/contract/rule.viewport-width-lifecycle.contract.test.ts
```

### web-input-ingress (18)

```text
packages/adapters/base/test/contract/event-default-action.v0.contract.test.ts
packages/adapters/base/test/contract/event-target-requirements.v0.contract.test.ts
packages/adapters/base/test/contract/pointer-root-ownership.v0.contract.test.ts
packages/adapters/base/test/event-gate.test.ts
packages/adapters/base/test/event-router-work.test.ts
packages/adapters/base/test/keyboard-repeat-payload.test.ts
packages/adapters/base/test/native-focus-event-router.test.ts
packages/adapters/base/test/pointer-contact.test.ts
packages/adapters/base/test/pointer-facts-router.test.ts
packages/adapters/base/test/pointer-sample-readers.test.ts
packages/adapters/base/test/portal-destination-deferred.test.ts
packages/adapters/base/test/portal-destination.test.ts
packages/adapters/base/test/shadow-retarget-routing.test.ts
packages/adapters/base/test/web-axis-delta-basis.test.ts
packages/adapters/base/test/web-axis-input-host.test.ts
packages/adapters/base/test/web-directional-input.test.ts
packages/adapters/base/test/web-move-gesture-host.test.ts
packages/adapters/base/test/window-blur-activation.test.ts
```

### adapter-web-component (42)

```text
packages/adapters/web-component/test/accordion.test.ts
packages/adapters/web-component/test/anatomy-reparent-rollback.test.ts
packages/adapters/web-component/test/axis-input.integration.test.ts
packages/adapters/web-component/test/collapsible.test.ts
packages/adapters/web-component/test/collection.integration.test.ts
packages/adapters/web-component/test/color-scheme-source.test.ts
packages/adapters/web-component/test/color-scheme.integration.test.ts
packages/adapters/web-component/test/context-ancestor.test.ts
packages/adapters/web-component/test/context-reentrancy.test.ts
packages/adapters/web-component/test/context.integration.test.ts
packages/adapters/web-component/test/control-label.integration.test.ts
packages/adapters/web-component/test/event-gate.effectiveness.test.ts
packages/adapters/web-component/test/event-gate.order.strict.test.ts
packages/adapters/web-component/test/field-sizing.integration.test.ts
packages/adapters/web-component/test/field.test.ts
packages/adapters/web-component/test/hit.integration.test.ts
packages/adapters/web-component/test/lifecycle-view-intent.test.ts
packages/adapters/web-component/test/material-release-reentry.test.ts
packages/adapters/web-component/test/pointer-facts.integration.test.ts
packages/adapters/web-component/test/presence-adoption.test.ts
packages/adapters/web-component/test/props-reprovide.test.ts
packages/adapters/web-component/test/radio-group.test.ts
packages/adapters/web-component/test/reconnect-move.test.ts
packages/adapters/web-component/test/router.spec.test.ts
packages/adapters/web-component/test/scroll-catalog.integration.test.ts
packages/adapters/web-component/test/scroll-target-subscription.test.ts
packages/adapters/web-component/test/scroll.test.ts
packages/adapters/web-component/test/shadcn-textarea-style.test.ts
packages/adapters/web-component/test/shadow-color-scheme-environment.test.ts
packages/adapters/web-component/test/shadow-s2-admission.test.ts
packages/adapters/web-component/test/shadow-split-meta.test.ts
packages/adapters/web-component/test/shadow-split-resource-generation.test.ts
packages/adapters/web-component/test/shadow-split-resources.test.ts
packages/adapters/web-component/test/shadow-text-control.test.ts
packages/adapters/web-component/test/table-reentrant-projection.test.ts
packages/adapters/web-component/test/table-retained-membership.test.ts
packages/adapters/web-component/test/table.test.ts
packages/adapters/web-component/test/text-control-selection.integration.test.ts
packages/adapters/web-component/test/text-control.integration.test.ts
packages/adapters/web-component/test/translucent-surface.integration.test.ts
packages/adapters/web-component/test/trigger.integration.test.ts
packages/adapters/web-component/test/view-operation-receipt.test.ts
```

### adapter-react (47)

```text
packages/adapters/react/test/accordion-keyboard.integration.test.ts
packages/adapters/react/test/accordion.test.ts
packages/adapters/react/test/axis-input.integration.test.ts
packages/adapters/react/test/collapsible.test.ts
packages/adapters/react/test/collection.integration.test.ts
packages/adapters/react/test/color-scheme.integration.test.ts
packages/adapters/react/test/context-ancestor.test.ts
packages/adapters/react/test/context-reentrancy.test.ts
packages/adapters/react/test/context.integration.test.ts
packages/adapters/react/test/control-label.integration.test.ts
packages/adapters/react/test/event-routing.test.ts
packages/adapters/react/test/event.test.ts
packages/adapters/react/test/field-sizing.integration.test.ts
packages/adapters/react/test/field.test.ts
packages/adapters/react/test/hit.integration.test.ts
packages/adapters/react/test/lifecycle-repeatable-mount.test.ts
packages/adapters/react/test/lifecycle-strict-replay.test.ts
packages/adapters/react/test/lifecycle-view-intent.test.ts
packages/adapters/react/test/lifecycle.test.ts
packages/adapters/react/test/material-fallback-provenance.integration.test.ts
packages/adapters/react/test/material-provider.integration.test.ts
packages/adapters/react/test/material-provider.review.test.ts
packages/adapters/react/test/material-style-commit.integration.test.ts
packages/adapters/react/test/material-style-reentrant.integration.test.ts
packages/adapters/react/test/nested-trigger.integration.test.ts
packages/adapters/react/test/pointer-facts.integration.test.ts
packages/adapters/react/test/portal-destination-material-reentry.integration.test.ts
packages/adapters/react/test/portal-direction.integration.test.ts
packages/adapters/react/test/radio-group.test.ts
packages/adapters/react/test/raw-props-commit.integration.test.ts
packages/adapters/react/test/ref-props-stability.integration.test.ts
packages/adapters/react/test/scroll-catalog.integration.test.ts
packages/adapters/react/test/scroll.test.ts
packages/adapters/react/test/select-keyboard.integration.test.ts
packages/adapters/react/test/select-presence-remount.integration.test.ts
packages/adapters/react/test/select-structural.integration.test.ts
packages/adapters/react/test/select.test.ts
packages/adapters/react/test/shadcn-textarea-style.test.ts
packages/adapters/react/test/table.test.ts
packages/adapters/react/test/text-control-selection.integration.test.ts
packages/adapters/react/test/text-control.integration.test.ts
packages/adapters/react/test/transition-command-closed-enter.test.ts
packages/adapters/react/test/transition-controlled-demo-remount.test.ts
packages/adapters/react/test/translucent-surface.integration.test.ts
packages/adapters/react/test/trigger.integration.test.ts
packages/adapters/react/test/view-operation-withdrawal.test.ts
packages/adapters/react/test/view-reveal-style.integration.test.ts
```

### adapter-vue (35)

```text
packages/adapters/vue/test/accordion.test.ts
packages/adapters/vue/test/axis-input.integration.test.ts
packages/adapters/vue/test/collapsible.test.ts
packages/adapters/vue/test/collection.integration.test.ts
packages/adapters/vue/test/color-scheme.integration.test.ts
packages/adapters/vue/test/context-ancestor.test.ts
packages/adapters/vue/test/context-reentrancy.test.ts
packages/adapters/vue/test/context.integration.test.ts
packages/adapters/vue/test/control-label.integration.test.ts
packages/adapters/vue/test/event-routing.test.ts
packages/adapters/vue/test/event.test.ts
packages/adapters/vue/test/field-sizing.integration.test.ts
packages/adapters/vue/test/field.test.ts
packages/adapters/vue/test/hit.integration.test.ts
packages/adapters/vue/test/lifecycle-keep-alive.test.ts
packages/adapters/vue/test/lifecycle-view-intent.test.ts
packages/adapters/vue/test/lifecycle.test.ts
packages/adapters/vue/test/nested-trigger.integration.test.ts
packages/adapters/vue/test/pointer-facts.integration.test.ts
packages/adapters/vue/test/portal-direction.integration.test.ts
packages/adapters/vue/test/previewer-textarea.demo.test.ts
packages/adapters/vue/test/radio-group.test.ts
packages/adapters/vue/test/scroll-catalog.integration.test.ts
packages/adapters/vue/test/scroll.test.ts
packages/adapters/vue/test/select-structural.test.ts
packages/adapters/vue/test/select.test.ts
packages/adapters/vue/test/shadcn-textarea-style.test.ts
packages/adapters/vue/test/table.test.ts
packages/adapters/vue/test/text-control-selection.integration.test.ts
packages/adapters/vue/test/text-control.integration.test.ts
packages/adapters/vue/test/transition-command-closed-enter.test.ts
packages/adapters/vue/test/translucent-surface.integration.test.ts
packages/adapters/vue/test/trigger.integration.test.ts
packages/adapters/vue/test/view-operation-withdrawal.test.ts
packages/adapters/vue/test/view-reveal-style.integration.test.ts
```

### adapter-vue2 (29)

```text
packages/adapters/vue2/test/accordion.test.ts
packages/adapters/vue2/test/axis-input.integration.test.ts
packages/adapters/vue2/test/collapsible.test.ts
packages/adapters/vue2/test/collection.integration.test.ts
packages/adapters/vue2/test/color-scheme.integration.test.ts
packages/adapters/vue2/test/context-ancestor.test.ts
packages/adapters/vue2/test/context-reentrancy.test.ts
packages/adapters/vue2/test/context.integration.test.ts
packages/adapters/vue2/test/control-label.integration.test.ts
packages/adapters/vue2/test/event.test.ts
packages/adapters/vue2/test/field-sizing.integration.test.ts
packages/adapters/vue2/test/field.test.ts
packages/adapters/vue2/test/hit.integration.test.ts
packages/adapters/vue2/test/host-direction.integration.test.ts
packages/adapters/vue2/test/lifecycle.test.ts
packages/adapters/vue2/test/pointer-facts.integration.test.ts
packages/adapters/vue2/test/props-update.test.ts
packages/adapters/vue2/test/scroll-area.test.ts
packages/adapters/vue2/test/scroll-catalog.integration.test.ts
packages/adapters/vue2/test/select-structural.test.ts
packages/adapters/vue2/test/select.test.ts
packages/adapters/vue2/test/shadcn-textarea-style.test.ts
packages/adapters/vue2/test/table.test.ts
packages/adapters/vue2/test/text-control-selection.integration.test.ts
packages/adapters/vue2/test/textarea.integration.test.ts
packages/adapters/vue2/test/translucent-surface.integration.test.ts
packages/adapters/vue2/test/trigger.integration.test.ts
packages/adapters/vue2/test/view-operation-withdrawal.test.ts
packages/adapters/vue2/test/view-ready-reopen.test.ts
```

### docs-consumer-composition (8)

```text
apps/www/src/components/PrototypePreviewer/collection-recipes.test.ts
apps/www/src/components/PrototypePreviewer/data-table-recipes.test.ts
apps/www/src/components/PrototypePreviewer/field-choices-recipes.test.ts
apps/www/src/components/PrototypePreviewer/field-registration.test.ts
apps/www/src/components/PrototypePreviewer/fieldset-registration.test.ts
apps/www/src/components/PrototypePreviewer/form-validation-recipes.test.ts
apps/www/src/components/PrototypePreviewer/input-registration.test.ts
apps/www/src/components/PrototypePreviewer/projection-composition.test.ts
```

## 真实浏览器 / 原生 runner（独立门）

```text
scripts/analysis/sprint2-input-browser.mjs
scripts/analysis/form-select-recipes-browser.mjs
scripts/analysis/collections-recipes-browser.mjs
scripts/analysis/component-capabilities-browser.mjs
scripts/analysis/bootstrap-collapse-browser.mjs
scripts/analysis/shenko-consumer-browser.mts
apps/www/test/preferences.browser.test.ts
apps/www/test/color-scheme.browser.test.ts
apps/www/test/tree-navigation.browser.test.ts
apps/www/test/virtual-list-resize.browser.test.ts
apps/www/test/message-composition.browser.test.ts
apps/www/test/component-consumer-repairs.browser.test.ts
apps/www/test/button-view-lifetime.browser.test.ts
apps/www/test/radio-group-entry.browser.test.ts
packages/prototypes/shadcn/test/switch-motion.browser.test.ts
packages/prototypes/brutalist/test/switch-motion.browser.test.ts
packages/adapters/base/test/resident-motion.browser.test.ts
packages/adapters/web-component/test/view-operation-withdrawal.browser.test.ts
apps/www/src/content/docs/zh-cn/demo-field-family.browser.test.ts
apps/www/src/content/docs/zh-cn/demo-accordion-family.browser.test.ts
apps/www/src/content/docs/zh-cn/demo-collapsible-projections.browser.test.ts
apps/www/src/content/docs/zh-cn/demo-base-collapsible.browser.test.ts
apps/www/src/content/docs/zh-cn/demo-base-controls.browser.test.ts
apps/www/src/content/docs/zh-cn/demo-base-input.browser.test.ts
apps/www/src/content/docs/zh-cn/demo-base-table.browser.test.ts
apps/www/src/content/docs/zh-cn/table-react19.browser.test.ts
apps/www/src/content/docs/zh-cn/demo-control-label.browser.test.ts
apps/www/src/content/docs/zh-cn/demo-shadcn-controls.browser.test.ts
apps/www/src/content/docs/zh-cn/demo-shadcn-input.browser.test.ts
apps/www/src/content/docs/zh-cn/demo-shadcn-radio-group.browser.test.ts
apps/www/src/content/docs/zh-cn/demo-brutalist-controls.browser.test.ts
apps/www/src/content/docs/zh-cn/demo-brutalist-input.browser.test.ts
apps/www/src/content/docs/zh-cn/demo-brutalist-checkbox.browser.test.ts
apps/www/src/content/docs/zh-cn/button-boundaries.browser.test.ts
apps/www/src/content/docs/zh-cn/scroll-area-corner.browser.test.ts
apps/www/src/content/docs/zh-cn/scroll-end-follow.browser.test.ts
apps/www/src/content/docs/zh-cn/overlay-portal-direction.browser.test.ts
apps/www/src/content/docs/zh-cn/base-accordion-layout-parity.browser.test.ts
```

## 独立类型配置

```text
packages/prototypes/base/test/tsconfig.carousel-resizable-public.json
packages/prototypes/base/test/tsconfig.collection-control-requests.json
packages/prototypes/base/test/tsconfig.collection-key-list-props.json
packages/prototypes/base/test/tsconfig.collection-nested-feedback.json
packages/prototypes/base/test/tsconfig.data-table-header-row.json
packages/prototypes/base/test/tsconfig.field-choices.json
packages/prototypes/base/test/tsconfig.field-projection.json
packages/prototypes/base/test/tsconfig.form-projection.json
packages/prototypes/base/test/tsconfig.message-scroller-capture.json
packages/prototypes/base/test/tsconfig.sprint2-collections.json
packages/prototypes/base/test/tsconfig.toggle-group-orientation.json
packages/prototypes/base/test/tsconfig.virtual-list-generation.json
internal/contracts/types/tsconfig.json
```

