#!/usr/bin/env python3
"""Execute the selected existing files, retaining one real process/report per file.

No suite is started by importing this script or building mapping.json.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

def now():
    return datetime.now(timezone.utc).isoformat()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--mapping', type=Path, default=Path(__file__).with_name('mapping.json'))
    parser.add_argument('--group', action='append', default=[])
    parser.add_argument('--files-from', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--heap-mb', type=int, default=1024)
    args = parser.parse_args()
    root, output = args.repo.resolve(), args.output.resolve()
    mapping_bytes = args.mapping.read_bytes()
    mapping = json.loads(mapping_bytes)
    groups = {g['id']: g for g in mapping['groups']}
    if set(args.group)-groups.keys():
        parser.error('Unknown group: '+str(sorted(set(args.group)-groups.keys())))
    selected_groups = args.group or list(groups)
    files = sorted({f for g in selected_groups for f in groups[g]['files']})
    requested = None
    if args.files_from:
        requested = args.files_from.read_bytes()
        subset = [line for line in requested.decode().splitlines() if line]
        if len(set(subset)) != len(subset) or set(subset)-set(files):
            parser.error('files-from must contain unique paths from the selected mapping')
        files = sorted(subset)
    hashes = {r['path']:r['sha256'] for r in mapping['files']}
    def sha(path):
        return hashlib.sha256(path.read_bytes()).hexdigest()
    def source():
        head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
        dirty = subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
        return dict(head=head,trackedOrUntrackedStatus=dirty)
    def check_source():
        observed=source()
        if observed['head'] != mapping['sourceCommit'] or observed['trackedOrUntrackedStatus']:
            raise RuntimeError('Source is not the frozen clean candidate: '+json.dumps(observed))
        for file in files:
            if sha(root/file) != hashes[file]:
                raise RuntimeError('Selected test changed: '+file)
        return observed
    before=check_source()
    output.mkdir(parents=True,exist_ok=False)
    driver=Path(__file__).read_bytes()
    (output/'runner.py').write_bytes(driver)
    summary=dict(kind='existing-whole-file-runtime-execution',startedAt=now(),sourceCommit=mapping['sourceCommit'],sourceBefore=before,mappingSha256=hashlib.sha256(mapping_bytes).hexdigest(),driverSha256=hashlib.sha256(driver).hexdigest(),groups=selected_groups,selectedFiles=files,heapMB=args.heap_mb,rows=[],status='running')
    if requested is not None:
        (output/'selected-files.txt').write_bytes(requested)
        summary['filesFromSha256']=hashlib.sha256(requested).hexdigest()
    def write():
        (output/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
    write()
    interrupted = None
    try:
        for index,file in enumerate(files,1):
            # External marker allows resource coordination at a real file
            # boundary without signalling or interrupting a running child.
            if (output/'pause').exists():
                summary['pauseAtFileBoundary']={'at':now(),'nextFile':file}
                write()
                while (output/'pause').exists():
                    time.sleep(1)
                summary.setdefault('pauses',[]).append({**summary.pop('pauseAtFileBoundary'),'resumedAt':now()})
                write()
            stem=f'{index:03d}-'+file.replace('/','__')
            report=output/(stem+'.json')
            command=['node',str(root/'node_modules/vitest/vitest.mjs'),'run',file,'--pool=forks','--maxWorkers=1','--minWorkers=1','--reporter=json','--outputFile='+str(report)]
            row=dict(file=file,sha256=hashes[file],command=command,cwd=str(root),startedAt=now(),status='running')
            summary['rows'].append(row)
            write()
            env=dict(os.environ,NODE_OPTIONS=f'--max-old-space-size={args.heap_mb}')
            started=time.monotonic()
            with (output/(stem+'.stdout.log')).open('wb') as stdout,(output/(stem+'.stderr.log')).open('wb') as stderr:
                child=subprocess.run(command,cwd=root,env=env,stdout=stdout,stderr=stderr)
            row.update(exitCode=child.returncode,finishedAt=now(),durationSeconds=time.monotonic()-started)
            row['stdoutSha256']=sha(output/(stem+'.stdout.log'))
            row['stderrSha256']=sha(output/(stem+'.stderr.log'))
            row['sourceAfter']=check_source()
            try:
                data=json.loads(report.read_text())
                row['reportSha256']=sha(report)
                suites=data.get('testResults',[])
                row['observedFiles']=[str(Path(r['name']).resolve().relative_to(root)) for r in suites]
                row['assertionStatusCounts']=dict(Counter(a.get('status','unknown') for r in suites for a in r.get('assertionResults',[])))
                row['summaryCounts']={k:data.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests']}
                counts=row['assertionStatusCounts']
                same_inventory=row['observedFiles']==[file]
                if child.returncode==0 and data.get('success') and same_inventory and counts.get('passed',0)>0 and set(counts)<= {'passed'}:
                    row['status']='passed'
                elif child.returncode==0 and data.get('success') and same_inventory and (counts.get('pending',0) or counts.get('todo',0) or counts.get('skipped',0)):
                    row['status']='completed-with-unaccepted-pending-or-todo'
                else:
                    row['status']='failed-or-incomplete'
            except Exception as error:
                row['status']='report-unavailable-or-invalid'
                row['reportError']=str(error)
            write()
            print(json.dumps(dict(index=index,total=len(files),file=file,status=row['status'],exitCode=row['exitCode'],assertionStatusCounts=row.get('assertionStatusCounts')),ensure_ascii=False),flush=True)
    except BaseException as error:
        interrupted=error
        summary['executionError']=repr(error)
    finally:
        try:
            summary['sourceAfter']=check_source()
        except Exception as error:
            summary['sourceError']=str(error)
        summary['finishedAt']=now()
        summary['fileStatusCounts']=dict(Counter(r['status'] for r in summary['rows']))
        summary['unstartedFiles']=files[len(summary['rows']):]
        summary['status']='passed' if not interrupted and not summary.get('sourceError') and len(summary['rows'])==len(files) and all(r['status']=='passed' for r in summary['rows']) else 'incomplete-or-failed'
        write()
    return 0 if summary['status']=='passed' else 1

if __name__=='__main__':
    sys.exit(main())
