#!/usr/bin/env python3
"""Read-only inventory of existing whole-file S2 regression candidates."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/workspace/scratch/b2027510c911/s2-compiler')
OUT = Path(__file__).resolve().parent
EXPECTED = '5cb80eb937f20982dd7dc8cbc93a90e91d665c31'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
assert git('rev-parse', 'HEAD') == EXPECTED
assert not git('status', '--porcelain')
inventory = subprocess.check_output(['rg', '--files', 'packages', 'apps/www', 'internal/contracts', 'scripts/analysis'], cwd=ROOT, text=True).splitlines()
tests = sorted(p for p in inventory if p.endswith('.test.ts') and '.browser.test.' not in p)
def directory(prefix, pattern='.*'):
    rx = re.compile(pattern)
    return [p for p in tests if p.startswith(prefix + '/') and rx.fullmatch(Path(p).name)]
def exact(*paths):
    for p in paths:
        assert p in tests, p
    return list(paths)
def group(key, title, issues, reason, files):
    files = sorted(set(files))
    assert files, key
    return dict(id=key, title=title, issues=issues, selectionReason=reason, status='not-run-by-this-inventory', files=files, fileCount=len(files))
base = 'packages/prototypes/base/test'
groups = [
    group('base-controls', 'Base 七类输入与选择控制', [1160,1094], '完整七类控件、共享选择 owner、真实编辑入口的既有文件；不选取单个新增 case。', directory(base, r'(?:as-button|button(?:-.*)?|checkbox(?:-.*)?|input(?:-(?:editor|reset|reset-lease))?|radio-group|switch|textarea|text-control-composition-lifecycle|toggle(?:-.*)?|toolbar-separator-lifecycle|selection-activate|selection-reset-lifecycle)\.test\.ts')),
    group('base-forms', 'Base Form / Field / Fieldset / Label 组合', [1094,1160], '包括异步、嵌套、受控、reset、invalid、error/description、复合控件和所有已有家族投影文件。', directory(base, r'(?:field.*|form.*|control-label\.projections|select-field-policy)\.test\.ts')),
    group('base-collections', 'Base 几何与层级集合', [1099,523,522], 'Tree、Resizable、Carousel、Message Scroller、Virtual List、Data Table 及实际通用 collection owner 的完整文件。Finf 混合文件按整个文件执行，附带 Date Picker case 不扩大本次范围。', directory(base, r'(?:carousel.*|resizable.*|review-toast-resizable|message-scroller.*|virtual-list.*|data-table.*|table|tree.*|collection.*|finf-collection.*|use-collection|scroll-area)\.test\.ts')),
    group('base-disclosure', 'Base Disclosure / Transition / Presence 绑定', [1096], 'Accordion、Collapsible、共享 open-state 和 Transition 的完整现存源消费者；Bootstrap 几何运动仍另需真实浏览器。', directory(base, r'(?:accordion|collapsible|disclosure-presence-binding|as-transition|transition.*|use-open-state)\.test\.ts') + directory('packages/prototypes/test-utils/test', r'(?:accordion-recipes|collapsible-projections)\.test\.ts')),
    group('base-pointer-consumers', 'Base Select pointer / keyboard / owner 消费', [1132], '保留完整 Select 文件及 pointer owner、退休、metadata cleanup、结构和滚动焦点交互；不是有限 pointer 字段单测的替代。', directory(base, r'(?:select|select-(?:pointer-owner|metadata-disposal|drawer-retirement|structural-parts|popper-focus-scroll)|dropdown-pointer-focus)\.test\.ts')),
]

family_files = []
family_files += directory('packages/prototypes/shadcn/test', r'(?:button.*|checkbox.*|radio-group|input.*|textarea.*|switch.*|toggle.*|binary-profile-transitions|form-policy-profile-consumers-r90|tree-embedded|collection-profiles-r91|select.*|dropdown-pointer-foreground)\.test\.ts')
family_files += directory('packages/prototypes/brutalist/test', r'(?:button.*|checkbox|radio-group|input|textarea|switch.*|toggle|form-action-motion|action-control-motion|table|scroll-area|transition|select.*)\.test\.ts')
family_files += directory('packages/prototypes/bootstrap-2-3-2/test', r'(?:button|controls|toggle|label-control-consumers-r94|draft-control-projections|invalid-control-contrast|action-appearance|historical-overlays-collections-r91|select-complete-projection)\.test\.ts')
family_files += directory('packages/prototypes/liquid-glass/test', r'(?:button|toggle|draft-control-projections|liquid-surface-fieldset-r91|field-material|collapsible-material|accordion-material|material|interactive-surface|select-material|select-complete-projection)\.test\.ts')
groups.append(group('family-consumers', '四设计家族完整控件 / 组合 / 偏好消费者', [1160,1099,1096,1094,793,523,522,1132], '文件有 WC+Happy DOM 行为、Runtime fixture、style/source 断言等多种层级。逐文件记录 imported adapters / source reads，不能统称四宿主原生浏览器。', family_files))

input_modules = []
for module in ['control-label','text-control','axis-input','event','a11y']:
    input_modules += directory(f'packages/modules/{module}/test', r'.*\.test\.ts')
input_modules += exact('packages/core/test/control-label.test.ts')
groups.append(group('input-modules', 'Label / 文本编辑 / Axis / Event / A11y 模块', [1160,1094,522,1132], '完整相关模块测试目录；A11y 检查语义投影，不等于真实读屏。', input_modules))
collection_modules = []
for module in ['scroll','collection','table-structure','context']:
    collection_modules += directory(f'packages/modules/{module}/test', r'.*\.test\.ts')
groups.append(group('collection-modules', 'Scroll / Collection / Table / Context 模块', [1099,523,522,1094], '包含 scroll anchor/end-follow/target lease、表结构身份、跨 Context 与重入的完整模块文件。', collection_modules))

shared_presence = directory('packages/modules/presence/test', r'.*\.test\.ts')
shared_presence += directory('packages/modules/feedback/test', r'(?:presence.*|resident-motion.*|root-provenance-sinks|sink-kind-retirement|deferred-view-sink|final-style-sink)\.test\.ts')
shared_presence += directory('packages/adapters/base/test', r'(?:web-presence.*|resident-motion.*|web-resident-motion|view-epoch-owner|view-operation-owner|view-visibility|teardown|adapter-host-delay)\.test\.ts')
shared_presence += exact('packages/runtime/test/with-host-presence.test.ts','packages/runtime/test/module-teardown-errors.test.ts')
shared_presence += directory('packages/runtime/test/contract', r'(?:lifecycle\.(?:view-intent\.v1|view-operation|module-resources\.v1|registration\.v0|checkpoints\.v0|session\.transitions\.v1|session\.update-epoch\.v1|same-checkpoint-order|update-order\.strict\.v0)|lifecycle-with-host\.v0|context-lifecycle\.v1|expose-lifecycle\.v1|state-lifecycle\.v1|control-label\.cleanup)\.contract\.test\.ts')
groups.append(group('presence-owner-runtime', '共享 Presence / 物理 view / Runtime 退休与重入', [1096,1099,1094,1160,1132], '本次 Transition / owner 基础改动的直接回归面。保留 web-presence-adoption 的唯一 native repeated-adoption TODO；该 TODO 不能因其余 case 通过而完成。', shared_presence))

preferences = directory('packages/adapters/base/test', r'(?:web-preference-source|web-preferences|web-style-support-source|web-color-scheme-source|web-material-(?:preferences-ownership|preferences-sequence|adoption|source|source-independent-review|source-refresh-task|independent-review|initial-binding|initial-paint|sink|image|program)|material-sink-wiring|initial-paint-media-session)\.test\.ts')
preferences += directory('packages/modules/feedback/test', r'(?:shared-material-policy|material-observer-fault|material-visual-result)\.test\.ts')
preferences += directory('packages/runtime/test/contract', r'(?:rule\.(?:preferences-lifecycle|style-support-lifecycle|color-scheme-lifecycle|color-scheme|viewport-width-lifecycle)\.contract|material-intent\.runtime)\.test\.ts')
preferences += directory('packages/modules/rule-meta/test', r'.*\.test\.ts')
groups.append(group('preferences-fallback', '偏好、材质支持、fallback 与来源 lease', [793], '保留 preference 和 style-support 的不同来源；覆盖失源/晚回调/held decode/重入的现有完整文件。不把整个 Liquid 光学/性能系统加入本 Issue。', preferences))

host_ingress = directory('packages/adapters/base/test', r'(?:pointer.*|shadow-retarget-routing|window-blur-activation|keyboard-repeat-payload|event-gate|event-router-work|native-focus-event-router|web-axis-delta-basis|web-axis-input-host|web-directional-input|web-move-gesture-host|portal-destination|portal-destination-deferred)\.test\.ts')
host_ingress += directory('packages/adapters/base/test/contract', r'(?:pointer-root-ownership|event-default-action|event-target-requirements)\.v0\.contract\.test\.ts')
groups.append(group('web-input-ingress', 'Web input ingress / pointer / axis / Portal', [1132,522,1160], '完整有限 pointer facts、nested/Shadow routing、blur、axis 和 Portal 边界文件；合成 PointerEvent 不宣称物理触笔/触摸。', host_ingress))

adapter_names = r'(?:accordion(?:-keyboard\.integration)?|collapsible|field|field-sizing\.integration|control-label\.integration|axis-input\.integration|pointer-facts\.integration|collection\.integration|scroll-catalog\.integration|scroll-area|scroll|scroll-target-subscription|table(?:-.*)?|radio-group|text-control(?:-selection)?\.integration|textarea\.integration|shadcn-textarea-style|previewer-textarea\.demo|context-reentrancy|context-ancestor|context\.integration|event(?:-routing)?|event-gate\..*|router\.spec|hit\.integration|trigger\.integration|nested-trigger\.integration|select(?:-.*)?|color-scheme(?:-source|\.integration)|translucent-surface\.integration|material-(?:fallback-provenance\.integration|style-commit\.integration|style-reentrant\.integration|provider\.review|provider\.integration|release-reentry)|portal-destination-material-reentry\.integration|presence-adoption|view-operation-withdrawal|lifecycle-view-intent|view-operation-receipt|view-ready-reopen|reconnect-move|host-direction\.integration|portal-direction\.integration|lifecycle(?:-repeatable-mount|-strict-replay|-keep-alive)?|transition-command-closed-enter|transition-controlled-demo-remount|view-reveal-style\.integration|props-update|props-reprovide|raw-props-commit\.integration|ref-props-stability\.integration|anatomy-reparent-rollback|shadow-s2-admission|shadow-text-control|shadow-split-meta|shadow-split-resources|shadow-split-resource-generation|shadow-color-scheme-environment)\.test\.ts'
for host in ['web-component','react','vue','vue2']:
    groups.append(group('adapter-'+host, '完整 '+host+' Adapter 消费文件', [1160,1099,1096,1094,793,523,522,1132], '各 host 实际调用共用 conformance fixtures；列出完整文件、不把 fixture 单独记为测试，不补造不存在的文件。额外 owner/Context/props/target 文件用于实际共享基础变动。', directory(f'packages/adapters/{host}/test', adapter_names)))

previewer = directory('apps/www/src/components/PrototypePreviewer', r'(?:collection-recipes|data-table-recipes|form.*|field.*|projection-composition|prototype-control-labels|text-control.*|input.*)\.test\.ts')
if previewer:
    groups.append(group('docs-consumer-composition', '文档真实 recipe / Preview 组合单元', [1160,1094,1099,523,522], '这是页面 recipe/组合测试，非整个生产页面或截图验收。', previewer))

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
all_files = sorted({f for g in groups for f in g['files']})
assert len(all_files) == sum(g['fileCount'] for g in groups), 'Primary groups must be disjoint'
file_rows = []
for file in all_files:
    text = (ROOT/file).read_text()
    env = re.search(r'@vitest-environment\s+(\S+)', text)
    file_rows.append(dict(path=file, sha256=sha(ROOT/file), environment=env.group(1) if env else 'happy-dom (default config)', adapterImports=sorted(set(re.findall(r'@proto\.ui/adapter-[\w-]+', text))), sourceReadAssertions=bool(re.search(r'\breadFile(?:Sync)?\b',text)), todoDeclarations=[l.strip() for l in text.splitlines() if re.search(r'\b(?:it|test)\.todo\(',l)], skipDeclarations=[l.strip() for l in text.splitlines() if re.search(r'\b(?:it|test|describe)\.skip\(',l)]))

browser_paths = [
    'scripts/analysis/sprint2-input-browser.mjs',
    'scripts/analysis/form-select-recipes-browser.mjs',
    'scripts/analysis/collections-recipes-browser.mjs',
    'scripts/analysis/component-capabilities-browser.mjs',
    'scripts/analysis/bootstrap-collapse-browser.mjs',
    'scripts/analysis/shenko-consumer-browser.mts',
    'apps/www/test/preferences.browser.test.ts',
    'apps/www/test/color-scheme.browser.test.ts',
    'apps/www/test/tree-navigation.browser.test.ts',
    'apps/www/test/virtual-list-resize.browser.test.ts',
    'apps/www/test/message-composition.browser.test.ts',
    'apps/www/test/component-consumer-repairs.browser.test.ts',
    'apps/www/test/button-view-lifetime.browser.test.ts',
    'apps/www/test/radio-group-entry.browser.test.ts',
    'packages/prototypes/shadcn/test/switch-motion.browser.test.ts',
    'packages/prototypes/brutalist/test/switch-motion.browser.test.ts',
    'packages/adapters/base/test/resident-motion.browser.test.ts',
    'packages/adapters/web-component/test/view-operation-withdrawal.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/demo-field-family.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/demo-accordion-family.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/demo-collapsible-projections.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/demo-base-collapsible.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/demo-base-controls.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/demo-base-input.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/demo-base-table.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/table-react19.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/demo-control-label.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/demo-shadcn-controls.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/demo-shadcn-input.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/demo-shadcn-radio-group.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/demo-brutalist-controls.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/demo-brutalist-input.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/demo-brutalist-checkbox.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/button-boundaries.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/scroll-area-corner.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/scroll-end-follow.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/overlay-portal-direction.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/base-accordion-layout-parity.browser.test.ts',
]
for p in browser_paths:
    assert (ROOT/p).is_file(),p
type_configs = sorted(str(p.relative_to(ROOT)) for p in (ROOT/base).glob('tsconfig.*.json') if re.search(r'(?:carousel-resizable|collection|data-table|field|form|message-scroller|sprint2|toggle|virtual-list)',p.name))
type_configs += ['internal/contracts/types/tsconfig.json']
remaining = {
  '1160': '全 variant/size/theme/字体缩放命中、失效/图标/换行；Button hover90 最终应用源；全部适用 Form/readOnly；真实编辑选择/取消重挂、平台 IME、group/toolbar 和 AT。现有文件可给明确子集，不能证明每个家族×四宿主×全部条件。',
  '1099': '完整 Message Scroller 初始位置/anchor/prepend/resize/公告；可移植 Virtual List owner 与适用目标；Data Table 复合切换/table AT；Carousel/Resizable 全输入几何、取消和家族；Tree 全受控与未物化关系。真实物理输入/AT/native/Compiler 不由 Happy DOM 获得。',
  '1096': 'Bootstrap 原生高度运动；全 single/multiple/allowEmpty/orientation/RTL、受控拒绝、反转、动态增删卸载；家族特定动画/keepMounted；未选中实验家族/视觉/AT/非 Web。固定 Shadcn/Neo 配方不新增高度动画义务。',
  '1094': '其他完整嵌套/复合组合、受控恢复、validator 失败/重入、各家族 invalid/error/description；Label 跨控命名/激活与真实读屏；CheckboxGroup parent/All/mixed/readOnly + Form 全组合。',
  '793': '四宿主所有普通/减弱透明/对比/减弱运动/forced-colors 组合及失源未知回调；GPUI 版本化环境 wire 和材质映射、Compiler 差分/适用后端必须分开接受。光学性能不属于本次单元门。',
  '523': '#678 初切片/current nodeKey-parentKey 对账、unknown expanded/selected 与拒绝、mode/prop 变化、disabled、未物化 Group 关系、完整动态生命周期；跨宿主/zoom/AT；Shenko Tasks/Playground 的实际消费整合另有原应用门。',
  '522': '原 13 格 adjustment 表全套受控/初始/idle-active更新、采样/commit/cancel、大小步/minmax、resize-reflow/orientation/disabled/readOnly、目标更替/旧回调；separator value/action/announcement/AT，#495 draft 决定及实际 Inspector 采用。',
  '1132': '全部 nested/Portal、A-down→B、enter-only、touch cancel/late、pen、invalid/missing事实、keyboard/value/selected保持、blur/reconnect/replacement；物理触摸/笔与合成输入分开；Compiler 四目标完整源对账与原 Vue2 11 诊断 retained red/工具链。',
}
issues=[]
for num in [1160,1099,1096,1094,793,523,522,1132]:
    source=ROOT.parent/'intake'/f'issue-{num}.md'
    selected=[g for g in groups if num in g['issues']]
    issues.append(dict(issue=num, originalSnapshot=str(source), originalSha256=sha(source), groups=[g['id'] for g in selected], candidateFiles=sorted({f for g in selected for f in g['files']}), remainingOriginalAcceptance=remaining[str(num)]))
report=dict(kind='sprint2-existing-whole-file-runtime-map',sourceCommit=EXPECTED,sourceClean=True,status='inventory-only-no-execution',groups=groups,files=file_rows,totalUniqueRuntimeFiles=len(all_files),issues=issues,browserAndNativeCandidates=[dict(path=p,sha256=sha(ROOT/p),status='not-run-by-this-inventory') for p in browser_paths],typeConfigs=[dict(path=p,sha256=sha(ROOT/p),status='not-run-by-this-inventory') for p in type_configs],exclusions=['Compiler full suite: parent has separate execution lane; no duplicate totals here.','Fixture helper files are dependencies, not runnable test files.','No native hardware/IME/AT inference from synthetic DOM.','No original full-library/profile denominator replaced by these selected regression files.'])
OUT.mkdir(exist_ok=True)
(OUT/'mapping.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(OUT/'runtime-files.txt').write_text('\n'.join(all_files)+'\n')
for g in groups:
    (OUT/(g['id']+'.txt')).write_text('\n'.join(g['files'])+'\n')
lines=['# Sprint 2 现存完整 runtime / Adapter 回归文件映射','',f'固定源：`{EXPECTED}`。冻结工作树干净。**这是文件与原条件的映射，不是执行通过报告。**','',f'去重后 **{len(all_files)} 个普通完整测试文件**；另列 **{len(browser_paths)} 个浏览器/原生 runner** 和 **{len(type_configs)} 个类型配置**。Compiler 全套由独立执行通道承担，不重复计入。原 Issue 分母保持。','','## 普通完整文件组','','| 组 | 文件数 | 层级和选择原因 |','|---|---:|---|']
for g in groups:
    lines.append(f"| `{g['id']}` | {g['fileCount']} | {g['title']}：{g['selectionReason']} |")
lines += ['', '普通文件默认配置是 Happy DOM。`mapping.json` 每个文件记录真实环境 pragma、adapter import、source-read 标志和 TODO/skip 声明；source-read 标志仅标识该文件含源码读取，不等于整文件只有静态检查。四个 Adapter 目录实际跑各自 integration/conformance，family 文件常只调用 WC。测试名或 `aria-*` 断言不提供读屏证据。', '', '## 执行方法', '', '使用 `python run-files.py --repo <冻结 checkout> --mapping mapping.json --group <组名> --output <新目录>`。默认每文件单独 Vitest 子进程、单 worker、1 GB heap，完整文件不带 `-t`。每文件独立 JSON/stdout/stderr，失败继续保留并令总进程失败；中断/skip/TODO 单独统计，不填为通过。开始前、每文件后和结束核对源 SHA/干净状态。', '', '执行前应取得共享重任务窗口。这个映射生成没有启动测试、TypeScript Program、build 或浏览器。', '', '现有浏览器 `.browser.test.ts` 使用项目 runner `node scripts/test/run-runtime-tests.mjs <具体完整文件>`；analysis `.mjs` 按各脚本既有环境运行，涉及 TS import 的脚本需 `node --import tsx`。浏览器源、字体、样式 producer 与浏览器 sandbox 保持原约束。单独列出这些候选，不把其未执行结果混进普通单元。', '', '## 原条件未由此 inventory 完成', '']
for issue in issues:
    lines += [f"### #{issue['issue']}", '', issue['remainingOriginalAcceptance'], '', f"相关组：{', '.join('`'+x+'`' for x in issue['groups'])}。", '']
lines += ['## 原生 repeated-adoption 义务','','`packages/adapters/base/test/web-presence-adoption.test.ts` 保留唯一 TODO：Happy DOM 第二次原生 adoptNode 在 host 代码前失败。普通文件可以报告其余具体 case，但不将 TODO 算成功。另准备真实 Chromium Document A → iframe B → cancel 清理内同步 adopt 回 A 的外置 probe；不修改被冻结的生产源与 TODO。','','## 完整列表','']
for g in groups:
    lines += [f"### {g['id']} ({g['fileCount']})",'','```text',*g['files'],'```','']
lines += ['## 真实浏览器 / 原生 runner（独立门）','','```text',*browser_paths,'```','','## 独立类型配置','','```text',*type_configs,'```','']
(OUT/'README.md').write_text('\n'.join(lines)+'\n')
assert git('rev-parse','HEAD')==EXPECTED and not git('status','--porcelain')
print(json.dumps(dict(uniqueFiles=len(all_files), groups=[dict(id=g['id'],files=g['fileCount']) for g in groups],browserCandidates=len(browser_paths),typeConfigs=len(type_configs),todos=[dict(path=r['path'],todos=r['todoDeclarations']) for r in file_rows if r['todoDeclarations']],mappingSha256=sha(OUT/'mapping.json')),ensure_ascii=False,indent=2))
