from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import resource
import shutil
import signal
import subprocess

root = Path(__file__).resolve().parent.parent
evidence = root.parent / 'cli-inventory-evidence'
inputs = sorted(set(json.loads((evidence / 'package-inputs.before.json').read_text())) | {
    'packages/cli/test/lowered-canonical-setup-registration.test.ts',
})

def snapshot():
    return {file: hashlib.sha256((root / file).read_bytes()).hexdigest() for file in inputs}

def now():
    return datetime.now(timezone.utc).isoformat()

before = snapshot()
(evidence / 'candidate-package-inputs.before.json').write_text(json.dumps(before, indent=2) + '\n')
command = [
    'corepack', 'pnpm@10.32.1', 'exec', 'vitest', 'run',
    '--config', '.diagnostics/inventory.config.ts', '--no-cache',
    '--maxWorkers=1', '--no-file-parallelism',
    'packages/cli/test/lowered-hook-coverage.test.ts',
    '--testNamePattern', 'resolves every hook state a shipped rule condition reads',
    '--reporter=json', '--outputFile=' + str(evidence / 'candidate-case.actual.json'),
]
receipt = {
    'startedAt': now(), 'command': command,
    'nodeOptions': '--max-old-space-size=768', 'sourceInputs': len(before),
    'scope': 'Original final test case after bounded setup-reference classifier repair; original test assertions and scanner return object unchanged',
}
environment = {**os.environ, 'NODE_OPTIONS': receipt['nodeOptions']}
with (evidence / 'candidate-case.log').open('w') as log:
    process = subprocess.Popen(command, cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    (evidence / 'candidate-case.running.json').write_text(json.dumps({**receipt, 'pid': process.pid}, indent=2) + '\n')
    try:
        code = process.wait(timeout=360)
        receipt['outerTimedOut'] = False
    except subprocess.TimeoutExpired:
        receipt['outerTimedOut'] = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=8)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        code = 124
after = snapshot()
(evidence / 'candidate-package-inputs.after.json').write_text(json.dumps(after, indent=2) + '\n')
receipt.update({
    'finishedAt': now(), 'exitCode': code,
    'changedInputs': [file for file in inputs if before[file] != after[file]],
    'maxRssKiB': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
})
inventory = root / '.diagnostics/whole-inventory.json'
if inventory.exists():
    payload = json.loads(inventory.read_text())
    if payload.get('startedAt', '') >= receipt['startedAt'][:19]:
        target = evidence / 'candidate-whole-inventory.json'
        shutil.copyfile(inventory, target)
        receipt['inventorySha256'] = hashlib.sha256(target.read_bytes()).hexdigest()
(evidence / 'candidate-case.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
raise SystemExit(code)
