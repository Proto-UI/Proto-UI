import { vi } from 'vitest';
vi.mock('../packages/cli/src/services/lowered-hook-coverage.ts', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../packages/cli/src/services/lowered-hook-coverage.ts')>();
  const fs = await import('node:fs');
  const path = await import('node:path');
  const crypto = await import('node:crypto');
  return {
    ...actual,
    scanRuleStateReadInventory: (...args: Parameters<typeof actual.scanRuleStateReadInventory>) => {
      const startedAt = new Date().toISOString();
      const before = process.resourceUsage();
      const result = actual.scanRuleStateReadInventory(...args);
      const root = process.cwd();
      const relative = (file: string) => path.relative(root,file).split(path.sep).join('/');
      const observation = (row: (typeof result.observations)[number]) => ({
        ...row,
        entryFile: relative(row.entryFile),
        rule: {...row.rule,file:relative(row.rule.file)},
        function: row.function?{...row.function,file:relative(row.function.file)}:undefined,
        callPath:row.callPath.map(ref=>({...ref,file:relative(ref.file)})),
        usages:row.usages.map(usage=>({...usage,provenance:usage.provenance})),
      });
      const record = {
        scope:'Read-only wrapper around original scanRuleStateReadInventory; original test assertions and returned object unchanged',
        startedAt,
        finishedAt:new Date().toISOString(),
        resourceBefore:before,
        resourceAfter:process.resourceUsage(),
        files:result.files.map(file=>({file:relative(file),sha256:crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')})),
        observations:result.observations.map(observation),
        evaluated:result.evaluated.map(observation),
      };
      fs.writeFileSync(path.join(root,'.diagnostics/whole-inventory.json'),JSON.stringify(record,null,2)+'\n');
      return result;
    },
  };
});
