import { mergeConfig } from 'vitest/config';
import original from '../vitest.config';
import path from 'node:path';
export default mergeConfig(original, {test:{setupFiles:[path.resolve('.diagnostics/inventory.setup.ts')]}});
