import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import ts from 'typescript';
import { scanRuleStateReadInventory, scanRuleStateReadsWithSites } from '../packages/cli/src/services/lowered-hook-coverage.ts';
import { createHookSourceSummaryContext, projectStandardRuntimeRootStyleTokens } from '../packages/cli/src/services/hook-source-summary.ts';
const root=process.cwd();
const files=process.argv.slice(2);
const outputs=[];
for(const relative of files){
  const file=path.resolve(relative);
  const text=fs.readFileSync(file,'utf8');
  const source=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true);
  const calls:ts.CallExpression[]=[];
  const visit=(n:ts.Node)=>{if(ts.isCallExpression(n)&&ts.isIdentifier(n.expression)&&n.expression.text.startsWith('as'))calls.push(n);ts.forEachChild(n,visit);};visit(source);
  const ordinary=createHookSourceSummaryContext();ordinary.registerSource(source);
  const proofs=(summary:ReturnType<typeof createHookSourceSummaryContext>)=>calls.map(call=>{const result=summary.resolveCall(call,source);return {expression:call.getText(source),start:call.getStart(source),kind:result.value.kind,reason:result.value.kind==='unknown'?result.value.reason:undefined};});
  const before=proofs(ordinary);
  let projected:any=null;
  await projectStandardRuntimeRootStyleTokens(source,async ({summary})=>{projected=proofs(summary);return [];});
  const sites=scanRuleStateReadsWithSites(text,file);
  const inventory=scanRuleStateReadInventory([file]);
  const record={file:relative,sha256:crypto.createHash('sha256').update(text).digest('hex'),before,projected,after:proofs(ordinary),syntacticSites:sites.sites.length,raw:sites.raw,scan:sites.scan,inventory:{files:inventory.files.map(f=>path.relative(root,f)),observations:inventory.observations,evaluated:inventory.evaluated}};
  outputs.push(record);
  fs.writeFileSync(path.join(root,'.diagnostics/sample.json'),JSON.stringify(outputs,null,2)+'\n');
  process.stdout.write(JSON.stringify({file:relative,ordinary:before,projected,sites:sites.sites.length,unresolved:inventory.evaluated.flatMap(r=>r.unresolved),usageCount:inventory.evaluated.flatMap(r=>r.usages).length})+'\n');
}
