from collections import Counter
from pathlib import Path
import hashlib
import json

directory = Path(__file__).resolve().parents[2] / 'cli-inventory-evidence'
baseline = json.loads((directory / 'whole-inventory.json').read_text())
candidate = json.loads((directory / 'candidate-whole-inventory.json').read_text())

def row_key(row):
    return json.dumps(row, sort_keys=True, separators=(',', ':'))

def opaque_marker(row):
    return (
        len(row['unresolved']) == 1
        and row['unresolved'][0]['reason'] == 'subject'
        and row['unresolved'][0]['expression'].startswith('unverified helper value: ')
        and not row['usages'] and not row['exposedLocals']
        and not row['callPath'] and not row['declarationOnly']
    )

def family(file):
    pieces = file.split('/')
    return pieces[2] if pieces[:2] == ['packages', 'prototypes'] else '(other)'

def classify(record):
    unresolved = [dict(entryFile=row['entryFile'], rule=row['rule'],
                       function=row.get('function'), callPath=row['callPath'],
                       declarationOnly=row['declarationOnly'], **miss)
                  for row in record['evaluated'] for miss in row['unresolved']]
    return {
        'files': len(record['files']),
        'observations': len(record['observations']),
        'evaluated': len(record['evaluated']),
        'evaluatedZeroOutcomeRows': sum(not row['usages'] and not row['unresolved']
                                        and not row['exposedLocals'] for row in record['evaluated']),
        'usages': sum(len(row['usages']) for row in record['evaluated']),
        'unresolvedOccurrences': len(unresolved),
        'uniqueRuleReadShapes': len({(miss['rule']['file'], miss['rule']['start'],
                                     miss['reason'], miss['expression']) for miss in unresolved}),
        'unresolvedByReason': dict(sorted(Counter(miss['reason'] for miss in unresolved).items())),
        'byFamily': dict(sorted(Counter(family(miss['entryFile']) for miss in unresolved).items())),
        'byReasonAndFamily': {
            reason: dict(sorted(Counter(family(miss['entryFile']) for miss in unresolved
                                        if miss['reason'] == reason).items()))
            for reason in sorted({miss['reason'] for miss in unresolved})
        },
        'affectedEntryFiles': len({miss['entryFile'] for miss in unresolved}),
        'topFiles': Counter(miss['entryFile'] for miss in unresolved).most_common(25),
        'byExpression': Counter((miss['reason'], miss['expression']) for miss in unresolved).most_common(40),
        'unresolved': unresolved,
    }

report = {
    'scope': 'Byte-preserving comparison of all retained observations before and after the setup-reference classifier repair',
    'sameInputFilesAndHashes': baseline['files'] == candidate['files'],
    'baselineInventorySha256': hashlib.sha256((directory / 'whole-inventory.json').read_bytes()).hexdigest(),
    'candidateInventorySha256': hashlib.sha256((directory / 'candidate-whole-inventory.json').read_bytes()).hexdigest(),
}
for group in ['observations', 'evaluated']:
    before = Counter(row_key(row) for row in baseline[group])
    after = Counter(row_key(row) for row in candidate[group])
    removed = [json.loads(row) for row, count in (before - after).items() for _ in range(count)]
    added = [json.loads(row) for row, count in (after - before).items() for _ in range(count)]
    report[group] = {
        'baselineCount': len(baseline[group]), 'candidateCount': len(candidate[group]),
        'removedCount': len(removed), 'addedCount': len(added),
        'onlyRemovedOpaqueReferenceMarkers': all(opaque_marker(row) for row in removed),
        'removed': removed, 'added': added,
    }
classification = classify(candidate)
(directory / 'candidate-whole-inventory.unresolved.json').write_text(
    json.dumps(classification.pop('unresolved'), indent=2) + '\n')
(directory / 'candidate-whole-inventory.classification.json').write_text(
    json.dumps(classification, indent=2) + '\n')
(directory / 'inventory-observation-diff.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({
    'sameInputFilesAndHashes': report['sameInputFilesAndHashes'],
    'classification': classification,
    'changes': {group: {key: value for key, value in report[group].items()
                       if key not in ['removed', 'added']} for group in ['observations', 'evaluated']},
}, indent=2))
assert report['sameInputFilesAndHashes'], 'The canonical source-file denominator changed.'
assert all(not report[group]['addedCount'] and report[group]['onlyRemovedOpaqueReferenceMarkers']
           for group in ['observations', 'evaluated']), 'Non-marker observation changes require investigation.'
