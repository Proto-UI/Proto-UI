from pathlib import Path
import subprocess,json,os,datetime
root=Path('/home/ezra/proto-ui-sprint1-postmerge-20261124-56f6684');out=Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation');node='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/node/bin/node'
name='main457-coverage-source-reconciled';old='final-coverage-source'
expected=json.loads((out/'main457-final-source-tree-v2.json').read_text())['sourceTreeBeforeNewEvidence'];assert subprocess.check_output(['git','write-tree'],cwd=root,text=True).strip()==expected
args=json.loads((out/(old+'.receipt.json')).read_text())['args'];env=os.environ.copy();env.update({'PATH':str(Path(node).parent)+os.pathsep+'/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/.bin'+os.pathsep+env['PATH'],'NODE_OPTIONS':'--max-old-space-size=768','TMPDIR':str(out/'task-temp')});start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/(name+'.log')).open('x') as log:p=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'args':args,'exit':p.returncode,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':'52f60128dbc0f34029ad849fad8d86e54e5614f1','mergeHead':'457d27f7fe554f398970a836ee9c95edb4846f47','sourceTreeBefore':expected,'sourceTreeAfter':subprocess.check_output(['git','write-tree'],cwd=root,text=True).strip(),'unstagedAfter':subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True)};(out/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(name,p.returncode,flush=True)
