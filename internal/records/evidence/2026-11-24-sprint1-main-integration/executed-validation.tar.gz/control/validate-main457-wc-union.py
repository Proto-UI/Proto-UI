from pathlib import Path
import subprocess,json,os,datetime,hashlib
root=Path('/home/ezra/proto-ui-sprint1-postmerge-20261124-56f6684');out=Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation');node='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/node/bin/node';pnpm='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/pnpm/bin/pnpm.cjs'
env=os.environ.copy();env.update({'PATH':str(Path(node).parent)+os.pathsep+'/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/.bin'+os.pathsep+env['PATH'],'NODE_OPTIONS':'--max-old-space-size=768','TMPDIR':str(out/'task-temp')})
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='52f60128dbc0f34029ad849fad8d86e54e5614f1'
assert subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=root,text=True).strip()=='457d27f7fe554f398970a836ee9c95edb4846f47'
files=['packages/adapters/web-component/test/'+x for x in ['dialog-overlay.test.ts','portal-conceal.test.ts','portal-first-render-reentry.test.ts','shadow-intrinsic-recipe.test.ts','shadow-percentage-translation.test.ts','shadow-s2-admission.test.ts','shadow-split-prototype-admission.test.ts','shadow-style-artifact.test.ts','shadow-split-effects.test.ts']]
sources=['packages/adapters/web-component/src/shadow-style-artifact.ts','packages/adapters/web-component/src/shadow-split-effects.ts']
for name,cmd in [('main457-wc-format',[node,pnpm,'exec','prettier','--write',*sources]),('main457-wc-union',[node,'node_modules/vitest/vitest.mjs','run',*files,'--no-file-parallelism','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/'main457-wc-union-vitest.json')])]:
 args=['systemd-run','--user','--scope','--property=MemoryMax=1536M','--property=MemorySwapMax=0','--','/home/ezra/.omp/agent/bin/agent-heavy','timeout','--signal=TERM','--kill-after=5s','90s',*cmd];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 before={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sources+files}
 with (out/(name+'.log')).open('x') as log:p=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt={'args':args,'exit':p.returncode,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':'52f60128dbc0f34029ad849fad8d86e54e5614f1','mergeHead':'457d27f7fe554f398970a836ee9c95edb4846f47','mergeInProgress':True,'beforeSha256':before,'afterSha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sources+files}}
 (out/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
subprocess.run(['git','add','--',*sources],cwd=root,check=True)
