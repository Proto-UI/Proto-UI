from pathlib import Path
import subprocess,json,os,datetime,hashlib
root=Path('/home/ezra/proto-ui-sprint1-postmerge-20261124-56f6684');out=Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation');node='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/node/bin/node';pnpm='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/pnpm/bin/pnpm.cjs'
env=os.environ.copy();env.update({'PATH':str(Path(node).parent)+os.pathsep+'/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/.bin'+os.pathsep+env['PATH'],'NODE_OPTIONS':'--max-old-space-size=768','TMPDIR':str(out/'task-temp')})
def execute(name,cmd,deadline):
 args=['systemd-run','--user','--scope','--property=MemoryMax=1536M','--property=MemorySwapMax=0','--','/home/ezra/.omp/agent/bin/agent-heavy','timeout','--signal=TERM','--kill-after=5s',str(deadline)+'s',*cmd];start=datetime.datetime.now(datetime.timezone.utc).isoformat();before=subprocess.check_output(['git','write-tree'],cwd=root,text=True).strip()
 with (out/(name+'.log')).open('x') as log:p=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt={'args':args,'exit':p.returncode,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'mergeHead':'457d27f7fe554f398970a836ee9c95edb4846f47','stagedTreeBefore':before,'stagedTreeAfter':subprocess.check_output(['git','write-tree'],cwd=root,text=True).strip(),'statusAfter':subprocess.check_output(['git','status','--short'],cwd=root,text=True)}
 (out/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(name,p.returncode,flush=True);return p.returncode
files=['scripts/ci/test/ci-scheduling-policy.test.mjs','scripts/coverage-matrices/browser-compiler-imports.mjs']
assert execute('main457-ci-format',[node,pnpm,'exec','prettier','--write',*files],90)==0
subprocess.run(['git','add','--',*files],cwd=root,check=True)
def clone_command(old,new):
 args=json.loads((out/(old+'.receipt.json')).read_text())['args'];cmd=args[args.index(node):];return [x.replace(old+'-vitest.json',new+'-vitest.json') for x in cmd]
for new,old,deadline in [('main457-matrix-controls','matrix-diagnostic-controls',90),('main457-sprint1-node','sprint1-node-with-diagnostics',90),('main457-source-boundaries','compiler-source-boundaries-green',120)]:execute(new,clone_command(old,new),deadline)
execute('main457-lowered-corpus',[node,'node_modules/vitest/vitest.mjs','run','packages/cli/test/lowered-hook-coverage.test.ts','--no-file-parallelism','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/'main457-lowered-corpus-vitest.json')],300)
execute('main457-styles-generate',clone_command('postmerge-styles-generate','main457-styles-generate'),600)
print('GENERATION_PHASE_DONE',flush=True)
