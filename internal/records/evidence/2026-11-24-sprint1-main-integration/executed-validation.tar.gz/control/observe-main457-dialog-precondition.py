from pathlib import Path
import subprocess,json,os,datetime,hashlib
root=Path('/home/ezra/proto-ui-main457-diagnostic-56f6684');out=Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation');node='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/node/bin/node';file='packages/adapters/web-component/test/dialog-overlay.test.ts';target=root/file
original=target.read_bytes();probe=(out/'main457-dialog-probe-candidate.ts').read_bytes()
def blob(data):return hashlib.sha1(('blob '+str(len(data))+'\0').encode()+data).hexdigest()
assert blob(original)=='3e4289ba3e4feabfba009df72e438777ed8ce535' and blob(probe)=='5a870a056f37537ad828782defe33a2cb1e3f033'
assert subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)==''
env=os.environ.copy();env.update({'PATH':str(Path(node).parent)+os.pathsep+'/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/.bin'+os.pathsep+env['PATH'],'NODE_OPTIONS':'--max-old-space-size=768','TMPDIR':str(out/'task-temp')})
args=['systemd-run','--user','--scope','--property=MemoryMax=1536M','--property=MemorySwapMax=0','--','/home/ezra/.omp/agent/bin/agent-heavy','timeout','--signal=TERM','--kill-after=5s','90s',node,'node_modules/vitest/vitest.mjs','run',file,'--no-file-parallelism','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/'main457-dialog-observation-vitest.json')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat();target.write_bytes(probe)
try:
 with (out/'main457-dialog-observation.log').open('x') as log:run=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
finally:target.write_bytes(original)
receipt={'args':args,'exit':run.returncode,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main':'457d27f7fe554f398970a836ee9c95edb4846f47','originalTestBlob':blob(original),'temporaryProbeBlob':blob(probe),'restoredTestBlob':blob(target.read_bytes()),'statusAfterRestore':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),'diagnosticOnly':True,'addedAwaitCount':0,'changedAssertions':0};(out/'main457-dialog-observation.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('dialog observation',run.returncode,flush=True)
