from pathlib import Path
import subprocess,json,os,datetime,hashlib
root=Path('/home/ezra/proto-ui-sprint1-postmerge-20261124-56f6684');out=Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation');node='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/node/bin/node';pnpm='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/pnpm/bin/pnpm.cjs'
env=os.environ.copy();env.update({'PATH':str(Path(node).parent)+os.pathsep+'/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/.bin'+os.pathsep+env['PATH'],'NODE_OPTIONS':'--max-old-space-size=768','TMPDIR':str(out/'task-temp')})
assert subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=root,text=True)==''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='52f60128dbc0f34029ad849fad8d86e54e5614f1'
assert subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=root,text=True).strip()=='457d27f7fe554f398970a836ee9c95edb4846f47'
def execute(name,cmd,deadline):
 args=['systemd-run','--user','--scope','--property=MemoryMax=1536M','--property=MemorySwapMax=0','--','/home/ezra/.omp/agent/bin/agent-heavy','timeout','--signal=TERM','--kill-after=5s',str(deadline)+'s',*cmd];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(name+'.log')).open('x') as log:p=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt={'args':args,'exit':p.returncode,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':'52f60128dbc0f34029ad849fad8d86e54e5614f1','mergeHead':'457d27f7fe554f398970a836ee9c95edb4846f47','sourceTree':subprocess.check_output(['git','write-tree'],cwd=root,text=True).strip(),'mergeInProgress':True}
 (out/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(name,p.returncode,flush=True);return p.returncode
formatted=['packages/cli/src/services/hook-source-module.ts','packages/cli/test/hook-source-lexical-index.test.ts','packages/cli/test/lowered-hook-coverage.test.ts']
assert execute('main457-cli-format',[node,pnpm,'exec','prettier','--write',*formatted],90)==0
subprocess.run(['git','add','--',*formatted],cwd=root,check=True)
paths=json.loads((out/'followup-main457-complete-diff-paths.json').read_text())['ownPaths'];before={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
(out/'main457-core-before.json').write_text(json.dumps({'head':'52f60128dbc0f34029ad849fad8d86e54e5614f1','mergeHead':'457d27f7fe554f398970a836ee9c95edb4846f47','sourceTree':subprocess.check_output(['git','write-tree'],cwd=root,text=True).strip(),'sha256':before},indent=2)+'\n')
def original_paths(receipt):
 a=json.loads((out/receipt).read_text())['args'];return a[a.index('run')+1:a.index('--no-file-parallelism')]
cli=original_paths('postmerge-cli-related.receipt.json')+['packages/cli/test/lowered-token-map-coverage.test.ts'];integration=original_paths('postmerge-integration-isolated-tmp.receipt.json')
wc=['packages/adapters/web-component/test/'+x for x in ['dialog-overlay.test.ts','portal-conceal.test.ts','portal-first-render-reentry.test.ts','shadow-intrinsic-recipe.test.ts','shadow-percentage-translation.test.ts','shadow-s2-admission.test.ts','shadow-split-prototype-admission.test.ts','shadow-style-artifact.test.ts','shadow-split-effects.test.ts']]
matrix=['apps/www/src/content/docs/zh-cn/demo-matrix-startup-diagnostic.test.ts','apps/www/src/content/docs/zh-cn/demo-matrix-startup-observation.test.ts']
for name,files,deadline in [('main457-cli-controls',cli,90),('main457-wc-complete',wc,90),('main457-integration',integration,90),('main457-matrix-controls',matrix,90),('main457-lowered-corpus',['packages/cli/test/lowered-hook-coverage.test.ts'],180)]:
 for file in files:assert (root/file).exists(),file
 cmd=[node,'node_modules/vitest/vitest.mjs','run',*files,'--no-file-parallelism','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/(name+'-vitest.json'))]
 execute(name,cmd,deadline)
after={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths};(out/'main457-core-after.json').write_text(json.dumps({'sha256':after,'changedDuringExecution':[p for p in paths if before[p]!=after[p]]},indent=2)+'\n')
