from pathlib import Path
import os,json,gzip,hashlib,subprocess,datetime,traceback
root=Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
ops=root.with_name(root.name+'-ops')
source=Path('/tank/shared/projects/proto-ui-agent/root-browser-retirement-75d5e28a-ops')
stem='2026-11-23-sprint5-browser-retirement-diagnostic'
evidence=root/'internal/records/evidence'/stem
record=root/'internal/records'/f'{stem}.md'
sourceHead='d9958d163436ea08d4a19b325d9e7f5dad3dc951'
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def sha(b):return hashlib.sha256(b).hexdigest()
state={'state':'running','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save():(ops/'browser-diagnostic-archive-status.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,env=env,text=True).strip()
 assert parent=='691f31462159af32882b65e0f3630c5ce04475d7'
 assert not evidence.exists() and not record.exists()
 groups=['astro-startup-4396-75d5','observed-browser-v2-d9958d163436','observed-browser-v3-d9958d163436','single-fill-probe-d995','single-fill-profile-d995']
 statuses={}
 for group in groups:
  s=json.loads((source/group/'status.json').read_text());statuses[group]=s
  assert s.get('head',s.get('headBefore',s.get('expectedHead')))==sourceHead,(group,'head')
  assert s.get('headAfter')==sourceHead,(group,'after head')
  before=s.get('sourceSha256Before',s.get('sourceBefore'));after=s.get('sourceSha256After',s.get('sourceAfter'))
  assert before and before==after,(group,'source')
  cleanBefore=s.get('statusBefore',s.get('trackedStatusBefore',s.get('gitBefore')))
  cleanAfter=s.get('statusAfter',s.get('trackedStatusAfter',s.get('gitAfter')))
  assert cleanBefore=='' and cleanAfter=='',(group,'git')
  assert s.get('finishedAt'),group
 v3=statuses[groups[2]]
 assert v3['state']=='failed' and v3['receipt']['caseCount']==19 and v3['receipt']['passed']==17
 assert [x['name'] for x in v3['receipt']['failed']]==['edit-reject-recover-same-revision-source-and-preview','cancel-running-edit-and-reopen-fresh-owner']
 assert '250-millisecond' in v3['receipt']['failed'][0]['error']
 assert '30000ms' in v3['receipt']['failed'][1]['error']
 profile=json.loads((source/'single-fill-profile-d995/probe.json').read_text())
 assert profile['state']=='failed' and profile['cases']==[] and profile['canonicalAcceptance'] is False
 probe=json.loads((source/'single-fill-probe-d995/probe.json').read_text())
 assert probe['state']=='completed' and len(probe['cases'])==3 and probe['canonicalAcceptance'] is False
 expected={
  '2026-11-23-d995-input-retirement-diagnostic.md':'8bf884492782602251928ac3954a74bd9d96625262a93940322600da0d4b2291',
  'observed-browser-v3-d9958d163436/browser/receipt.json':'900040b5c5a5f966cad2eb2ad38e0e335578581926bdd294587bf64c6d2d7303',
  'observed-browser-v3-d9958d163436/trace.jsonl':'e10e00477c9df8dd37dadc34877681238f52dc5dcf07676020d25d1b8ef0d6d9',
  'observed-browser-v3-d9958d163436/analysis.json':'a64d71be27ee2ac1d735b1a4fe8a5e91e4547523fbcb739df70b5b0339ef831c',
  'single-fill-probe-d995/probe.json':'7c0ddab4dd4cd9ce503766a546c3b8e738822dd2f24a3f15d5e179514badcc58',
  'single-fill-profile-d995/probe.json':'8431bb05dee4cd91b385a764835490a7067a3294eee1e499b45773674bcc7690'
 }
 for p,digest in expected.items():assert sha((source/p).read_bytes())==digest,p
 drivers=['astro-startup-4396-worker.py','run-observed-v2.py','observer-v2.cjs','observer-v2-browser.js','run-observed-v3.py','observer-v3.cjs','observer-v3-browser.js','observer-v3-browser.patch','observer-v3-driver.patch','single-fill-probe.mjs','single-fill-probe-worker.py','single-fill-profile.mjs','single-fill-profile-worker.py','single-fill-profile-worker.log']
 for group,s in statuses.items():
  if group.startswith('observed-browser-'):
   version='v3' if '-v3-' in group else 'v2'
   assert sha((source/f'run-observed-{version}.py').read_bytes())==s['driverSha256']
   assert sha((source/f'observer-{version}.cjs').read_bytes())==s['observerSha256']
  elif group.startswith('single-fill-'):
   prefix='single-fill-profile' if 'profile' in group else 'single-fill-probe'
   assert sha((source/(prefix+'.mjs')).read_bytes())==s['probeSha256']
   assert sha((source/(prefix+'-worker.py')).read_bytes())==s['workerSha256']
 evidence.mkdir(parents=True)
 manifest={'schemaVersion':1,'kind':'source-bound-diagnostic-archive','archiveParent':parent,'observedHead':sourceHead,'observedTree':v3['tree'],'canonicalAcceptance':False,'productDeadlineMilliseconds':250,'observedReceipt':{'cases':19,'passed':17,'failed':v3['receipt']['failed']},'profileExecutedFill':False,'files':[],'currentSourceComparison':{}}
 def add(relative,data,origin):
  out=evidence/(relative+'.gz');out.parent.mkdir(parents=True,exist_ok=True)
  compressed=gzip.compress(data,compresslevel=9,mtime=0);assert gzip.decompress(compressed)==data;out.write_bytes(compressed)
  manifest['files'].append({'path':str(out.relative_to(evidence)),'origin':origin,'rawBytes':len(data),'rawSha256':sha(data),'gzipBytes':len(compressed),'gzipSha256':sha(compressed)})
 files=[source/'2026-11-23-d995-input-retirement-diagnostic.md']+[source/p for p in drivers]
 for group in groups:files.extend(p for p in sorted((source/group).rglob('*')) if p.is_file() and p.name!='worker.lock')
 for p in files:
  data=p.read_bytes();add('raw/'+str(p.relative_to(source)),data,str(p.relative_to(source)));assert sha(p.read_bytes())==sha(data)
 for path,digest in v3['sourceSha256Before'].items():
  old=subprocess.check_output(['git','show',sourceHead+':'+path],cwd=root,env=env);assert sha(old)==digest,path
  add('source-d995/'+path,old,sourceHead+':'+path)
  current=sha((root/path).read_bytes());manifest['currentSourceComparison'][path]={'observedSha256':digest,'archiveWorktreeSha256':current,'equal':digest==current}
 add('archive-driver.py',Path(__file__).read_bytes(),'archive driver')
 (evidence/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 text=(source/'2026-11-23-d995-input-retirement-diagnostic.md').read_text()
 text+='\n## Repository archive binding\n\nThis diagnostic packet is retained with its complete raw receipts, passive observers, finite probe drivers, failure screenshots, and the eleven source snapshots in the [immutable evidence manifest](evidence/'+stem+'/manifest.json). Every gzip file round-trips to its recorded raw SHA-256. Per-file comparisons to the archive worktree are provenance information, not execution on that newer head.\n\nThe observed 17/19 result remains a failed, instrumented diagnostic. The later CPU/layout-profile attempt contains zero cases and no executed fill or captured CPU profile. Neither result is an unobserved canonical acceptance receipt. The separate public db747 browser job stopped before its journey at font setup; this archive does not convert it or the earlier cleanup failure into a pass. The original 250-millisecond acknowledgement requirement remains intact.\n'
 record.write_text(text)
 state.update({'state':'archived','archiveParent':parent,'observedHead':sourceHead,'archiveCount':len(manifest['files']),'record':str(record.relative_to(root)),'manifest':str((evidence/'manifest.json').relative_to(root)),'runtimeSourceComparisons':{k:v for k,v in manifest['currentSourceComparison'].items() if 'PrototypePreviewer/' in k},'recordSha256':sha(record.read_bytes())})
except Exception as e:state.update({'state':'failed','error':str(e),'trace':traceback.format_exc()})
state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
