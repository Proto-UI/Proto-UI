import { createRequire } from 'node:module';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
const root = process.env.PUI_PROBE_ROOT;
const out = process.env.PUI_PROBE_OUTPUT;
const require = createRequire(path.join(root, 'apps/www/package.json'));
const { chromium } = require('playwright-core');
const trace = (await readFile(process.env.PUI_PROBE_SOURCE_TRACE, 'utf8')).trim().split('\n').map(line => JSON.parse(line));
const valueRows = trace.flatMap(row => row.batch ?? []).filter(event => event.kind === 'source-value');
const source = valueRows.find(event => event.id === 1).value;
const bad = valueRows.find(event => event.id === 2).value;
const sha = value => createHash('sha256').update(value).digest('hex');
const report = { kind: 'single-fill-native-input-comparison', sourceHead: process.env.PUI_PROBE_HEAD, startedAt: new Date().toISOString(), canonicalAcceptance: false, originalDeadlineUnchanged: true, playwright: require('playwright-core/package.json').version, inputs: { source: { bytes: Buffer.byteLength(source), sha256: sha(source) }, bad: { bytes: Buffer.byteLength(bad), sha256: sha(bad), newlines: bad.split('\n').length - 1, nonemptySegments: bad.split('\n').filter(Boolean).length } }, cases: [] };
async function save() { await writeFile(path.join(out,'probe.json'), JSON.stringify(report,null,2)+'\n'); }
let browser;
function summarize(events) {
  const intervals = events.slice(1).map((event,index) => event.time - events[index].time);
  const sorted = intervals.slice().sort((a,b)=>a-b);
  return { inputCount: events.length, trusted: events.filter(x=>x.isTrusted).length, fullValueEqual: events.filter(x=>x.expectedEqual).length, firstLastDurationMs: events.length ? events.at(-1).time-events[0].time : 0, intervalsMs: { min: sorted[0] ?? 0, median: sorted[Math.floor(sorted.length/2)] ?? 0, max: sorted.at(-1) ?? 0, sum: intervals.reduce((a,b)=>a+b,0) }, revisions: [...new Set(events.map(x=>x.revision))] };
}
async function instrument(page, selector) {
  await page.evaluate(({selector,expected}) => {
    const textarea = document.querySelector(selector);
    if (!(textarea instanceof HTMLTextAreaElement)) throw new Error('Probe requires actual textarea');
    const panel = textarea.closest('pui-browser-compiler');
    const probe = window.__nativeInputProbe = { started:performance.now(), events:[], messages:[], longtasks:[] };
    textarea.addEventListener('input', event => {
      probe.events.push({
        time:performance.now(), type:event.type, constructor:event.constructor.name,
        isTrusted:event.isTrusted, inputType:event.inputType, isComposing:event.isComposing,
        data:event.data, valueLength:textarea.value.length, expectedEqual:textarea.value===expected,
        revision:panel?.dataset.compilerRevision ?? null, phase:panel?.dataset.compilerPhase ?? null,
        targetTag:event.target?.tagName
      });
    }, {capture:true,passive:true});
    window.addEventListener('message', event => {
      const data=event.data;
      if (data && typeof data==='object' && ['dispose','disposed','cleanup-error','preview-listener-ready','preview-ready'].includes(data.type)) {
        probe.messages.push({time:performance.now(),type:data.type,revision:data.revision,token:data.token,origin:event.origin});
      }
    },{capture:true,passive:true});
    try {
      const observer=new PerformanceObserver(list=>{
        for (const entry of list.getEntries()) probe.longtasks.push({start:entry.startTime,duration:entry.duration});
      });
      observer.observe({type:'longtask',buffered:false});
    } catch(error) { probe.observerError=String(error); }
  }, {selector,expected:bad});
}
async function fillOnce(page, selector, name) {
  const entry={name, fillCalls:0, startedAt:new Date().toISOString()};
  report.cases.push(entry); await save();
  await instrument(page,selector);
  entry.fillCalls++;
  const start=performance.now();
  await page.locator(selector).fill(bad);
  entry.fillDurationMs=performance.now()-start;
  await page.waitForTimeout(800);
  const result=await page.evaluate(()=>({
    ...window.__nativeInputProbe,
    panel: (()=>{const p=document.querySelector('pui-browser-compiler');return p?{phase:p.dataset.compilerPhase,revision:p.dataset.compilerRevision,diagnostic:p.querySelector('[data-compiler-diagnostics]')?.textContent,frames:p.querySelectorAll('iframe').length}:null})()
  }));
  Object.assign(entry,result,{summary:summarize(result.events),finishedAt:new Date().toISOString()});
  await save();
}
try {
  browser=await chromium.launch({executablePath:process.env.PUI_CHROME_EXECUTABLE,headless:true,chromiumSandbox:true});
  report.browser=browser.version();
  const bare=await browser.newPage({viewport:{width:1280,height:1000}});
  await bare.setContent('<!doctype html><meta charset="utf-8"><textarea id="source" style="width:900px;height:500px"></textarea>');
  await bare.locator('#source').evaluate((textarea,value)=>textarea.value=value,source);
  await fillOnce(bare,'#source','bare-textarea-no-product-listeners');
  await bare.close();
  const actual=await browser.newPage({viewport:{width:1280,height:1000}});
  actual.setDefaultTimeout(30000);
  await actual.goto(process.env.PUI_PROBE_URL+'/en/ui-libraries/base/button/',{waitUntil:'networkidle',timeout:45000});
  const panel=actual.locator('pui-browser-compiler');
  await panel.locator('[data-compiler-panel] > summary').click();
  await actual.waitForFunction(()=>['ready','failed'].includes(document.querySelector('pui-browser-compiler')?.dataset.compilerPhase),undefined,{timeout:45000});
  const ready=await panel.getAttribute('data-compiler-phase');
  if (ready!=='ready') throw new Error('Actual panel was not ready: '+await panel.locator('[data-compiler-diagnostics]').textContent());
  await panel.locator('[data-source-editor] > summary').click();
  const actualSource=await panel.locator('[data-source-text]').inputValue();
  if (actualSource!==source) throw new Error('Source differs from frozen v3 input');
  const computed=await panel.locator('[data-source-text]').evaluate(textarea=>{
    const cs=getComputedStyle(textarea); const props=['box-sizing','width','height','font-family','font-size','line-height','font-weight','white-space','overflow-wrap','word-break','padding','border-width','resize'];
    return {css:Object.fromEntries(props.map(prop=>[prop,cs.getPropertyValue(prop)])),rows:textarea.rows,cols:textarea.cols,wrap:textarea.wrap};
  });
  report.actualTextarea=computed; await save();
  const matched=await browser.newPage({viewport:{width:1280,height:1000}});
  await matched.setContent('<!doctype html><meta charset="utf-8"><textarea id="source"></textarea>');
  await matched.locator('#source').evaluate((textarea,{value,computed})=>{
    textarea.value=value; textarea.rows=computed.rows;textarea.cols=computed.cols;textarea.wrap=computed.wrap;
    for(const [property,value] of Object.entries(computed.css)) textarea.style.setProperty(property,value);
  },{value:source,computed});
  await fillOnce(matched,'#source','bare-textarea-matching-computed-style');
  await matched.close();
  await fillOnce(actual,'[data-source-text]','actual-d995-compiler-panel');
  await actual.waitForTimeout(1500);
  report.finalActualPanel=await panel.evaluate(p=>({phase:p.dataset.compilerPhase,revision:p.dataset.compilerRevision,diagnostic:p.querySelector('[data-compiler-diagnostics]')?.textContent,frames:p.querySelectorAll('iframe').length}));
  await actual.close();
  report.state='completed';
} catch(error) {
  report.state='failed'; report.error=String(error?.stack??error);
} finally {
  if(browser) {await browser.close();report.browserClosed=true;}
  report.finishedAt=new Date().toISOString();await save();
}
process.exitCode=report.state==='completed'?0:1;
