from pathlib import Path
import os, subprocess, json, hashlib, time, traceback, tempfile, socket, signal, re, shutil
from datetime import datetime, timezone
root=Path('/tank/shared/projects/proto-ui-agent/root-browser-retirement-75d5e28a')
ops=root.with_name(root.name+'-ops')
dest=ops/'astro-startup-4396-75d5'
dest.mkdir(exist_ok=False)
with (dest/'worker.lock').open('x') as f:f.write(str(os.getpid()))
began=time.monotonic()
limit=600
node='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin/node'
expected='d9958d163436ea08d4a19b325d9e7f5dad3dc951'
original=json.loads((ops/'observed-browser-v2-d9958d163436/status.json').read_text())
watch=list(original['sourceSha256Before'])+['scripts/compiler/browser-service.mjs','apps/www/astro.config.mjs','apps/www/package.json']
status={'kind':'owned-standalone-astro-startup-diagnostic','scope':'Exact Astro CLI startup only. No generator, canonical rerun, application edit, browser acceptance, timeout change, or retirement claim.','expectedHead':expected,'budgetSeconds':600,'startedAt':datetime.now(timezone.utc).isoformat(),'stage':'preflight','workerPid':os.getpid(),'snapshots':[]}
child=None; tracer=None; tracefile=None; tmp=None
def elapsed():return round(time.monotonic()-began,3)
def save():
 status['elapsedSeconds']=elapsed()
 p=dest/'status.json.tmp';p.write_text(json.dumps(status,indent=2)+'\n');p.replace(dest/'status.json')
def git(args,seconds=25):
 return subprocess.check_output(['git','--no-optional-locks',*args],cwd=root,text=True,timeout=seconds).strip()
def hashes():
 return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in watch}
def free(path):
 s=os.statvfs(path);return {'availableBytes':s.f_bavail*s.f_frsize,'availableInodes':s.f_favail}
def connectable():
 with socket.socket() as s:
  s.settimeout(.3);return s.connect_ex(('127.0.0.1',4396))==0
def proc(pid):
 d={'pid':pid}
 p=Path('/proc')/str(pid)
 try:
  t=(p/'stat').read_text();r=t[t.rfind(')')+2:].split()
  d.update(state=r[0],parentPid=int(r[1]),pgrp=int(r[2]),userTicks=int(r[11]),systemTicks=int(r[12]),majorFaults=int(r[9]),rssPages=int(r[21]),threads=int(r[17]),wchan=(p/'wchan').read_text().strip())
  d['io']={a:int(b) for a,b in (line.split(':',1) for line in (p/'io').read_text().splitlines())}
  d['children']=[int(n) for n in (p/'task'/str(pid)/'children').read_text().split()]
  d['cwd']=os.readlink(p/'cwd')
  d['stdio']={str(i):os.readlink(p/'fd'/str(i)) for i in range(3) if (p/'fd'/str(i)).exists()}
 except (OSError,ValueError) as e:d['observationError']=str(e)
 return d
def snapshot():
 s={'atSeconds':elapsed(),'load':os.getloadavg(),'stdoutBytes':(dest/'stdout.log').stat().st_size,'stderrBytes':(dest/'stderr.log').stat().st_size,'portListening':connectable()}
 s['process']=proc(child.pid)
 s['children']=[proc(p) for p in s['process'].get('children',[])][:8]
 for f in ['io','memory','cpu']:
  try:s['pressure-'+f]=(Path('/proc/pressure')/f).read_text().strip()
  except OSError:pass
 mem={}
 for line in Path('/proc/meminfo').read_text().splitlines():
  if line.split(':')[0] in ['MemAvailable','SwapTotal','SwapFree','Dirty','Writeback']:mem[line.split(':')[0]]=line.split(':',1)[1].strip()
 s['memory']=mem
 status['snapshots'].append(s);save()
def stop(p,kind,seconds=4):
 if p is None:return
 try:
  if p.poll() is None:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=seconds)
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=seconds)
  status[kind+'ExitCode']=p.returncode
 except ProcessLookupError:status[kind+'ExitCode']=p.poll()
save()
try:
 status['headBefore']=git(['rev-parse','HEAD'])
 assert status['headBefore']==expected
 status['treeBefore']=git(['rev-parse','HEAD^{tree}'])
 status['trackedStatusBefore']=git(['status','--porcelain=v1','--untracked-files=no'])
 assert status['trackedStatusBefore']==''
 status['sourceSha256Before']=hashes()
 assert all(status['sourceSha256Before'][p]==v for p,v in original['sourceSha256Before'].items())
 status['nodeVersion']=subprocess.check_output([node,'--version'],text=True,timeout=10).strip()
 tmp=Path(tempfile.mkdtemp(prefix='s3a75-',dir='/tank/shared/projects/proto-ui-agent'))
 status['tempDirectory']=str(tmp)
 status['spaceBefore']={'systemTmp':free('/tmp'),'privateTmp':free(tmp),'repo':free(root)}
 cli=root/'apps/www/node_modules/astro/astro.js'
 status['astroCli']={'path':str(cli),'realpath':str(cli.resolve()),'sha256':hashlib.sha256(cli.read_bytes()).hexdigest()}
 env=os.environ.copy()
 env.update(TMPDIR=str(tmp),CI='1',COREPACK_ENABLE_DOWNLOAD_PROMPT='0',ASTRO_TELEMETRY_DISABLED='1',NODE_OPTIONS='--max-old-space-size=4096',PUI_BROWSER_PORT='4396')
 env['PATH']=str(Path(node).parent)+':'+env['PATH']
 env['COREPACK_HOME']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/corepack-cache'
 status['configuredEnvironment']={k:env[k] for k in ['TMPDIR','CI','COREPACK_ENABLE_DOWNLOAD_PROMPT','ASTRO_TELEMETRY_DISABLED','NODE_OPTIONS','PUI_BROWSER_PORT']}
 with socket.socket() as s:s.bind(('127.0.0.1',4396))
 status['portAvailableBeforeSpawn']=True
 argv=[node,'node_modules/astro/astro.js','dev','--host','127.0.0.1','--port','4396']
 status['command']=argv;status['cwd']=str(root/'apps/www')
 status['stage']='starting-exact-cli';save()
 with (dest/'stdout.log').open('wb',buffering=0) as stdout,(dest/'stderr.log').open('wb',buffering=0) as stderr:
  child=subprocess.Popen(argv,cwd=root/'apps/www',env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
  status['childPid']=child.pid;status['childProcessGroup']=os.getpgid(child.pid);status['spawnAtSeconds']=elapsed();status['straceAvailable']=shutil.which('strace')
  nextsample=0; trace_started=False; tracedeadline=0
  while elapsed()<540:
   if elapsed()>=nextsample:
    snapshot();nextsample=elapsed()+10
   stdoutText=(dest/'stdout.log').read_text(errors='replace')
   stderrText=(dest/'stderr.log').read_text(errors='replace')
   clean=re.sub(r'\x1b\[[0-9;]*[a-zA-Z]','',stdoutText+'\n'+stderrText)
   if clean.strip() and 'firstLogAtSeconds' not in status:
    status['firstLogAtSeconds']=elapsed();status['firstLogTail']=clean[-2500:];save()
   if re.search(r'\bLocal[ \t]+http://127\.0\.0\.1:4396/[ \t]*\r?\n',clean):
    status['stage']='local-url-observed'
    status['localUrlAtSeconds']=elapsed();status['aliveAtLocalUrl']=child.poll() is None;status['listeningAtLocalUrl']=connectable()
    status['withinOriginal90SecondStartupBoundary']=elapsed()-status['spawnAtSeconds']<90
    save();break
   if child.poll() is not None:
    status['stage']='child-exited-before-local-url';status['childExitCode']=child.returncode;save();break
   if elapsed()-status['spawnAtSeconds']>=90 and not trace_started:
    status['atOriginal90Seconds']={'localUrlObserved':False,'stdoutBytes':len(stdoutText.encode()),'stderrBytes':len(stderrText.encode())};trace_started=True
    if status['straceAvailable']:
     tracefile=(dest/'strace-stderr.log').open('wb')
     traceargs=[status['straceAvailable'],'-f','-tt','-T','-s','180','-e','trace=openat,newfstatat,statx,readlink,readlinkat','-p',str(child.pid),'-o',str(dest/'startup-file-syscalls.log')]
     tracer=subprocess.Popen(traceargs,cwd=dest,stdout=tracefile,stderr=tracefile,start_new_session=True)
     tracedeadline=elapsed()+20;status['trace']={'argv':traceargs,'pid':tracer.pid,'startedAtSeconds':elapsed(),'purpose':'20-second file-resolution syscall observation of owned PID only; no read-buffer/environment capture'};save()
   if tracer is not None and tracer.poll() is None:
    tracepath=dest/'startup-file-syscalls.log'
    if elapsed()>=tracedeadline or (tracepath.exists() and tracepath.stat().st_size>3_000_000):
     stop(tracer,'strace',2);status['trace']['finishedAtSeconds']=elapsed();save()
   time.sleep(.5)
  else:status['stage']='bounded-observation-budget-exhausted';save()
  snapshot()
except BaseException as e:
 status['stage']='diagnostic-error';status['error']=str(e);status['traceback']=traceback.format_exc();save()
finally:
 terminal= status['stage']
 stop(tracer,'strace',2)
 if tracefile:tracefile.close()
 stop(child,'astro',4)
 status['terminalObservation']=terminal;status['stage']='verifying-cleanup';save()
 status['portListeningAfterOwnShutdown']=connectable()
 try:
  status['headAfter']=git(['rev-parse','HEAD'],15)
  status['trackedStatusAfter']=git(['status','--porcelain=v1','--untracked-files=no'],20)
  status['sourceSha256After']=hashes()
  status['sourceStable']=status.get('sourceSha256Before')==status['sourceSha256After'] and status['headAfter']==expected and status['trackedStatusAfter']==''
 except BaseException as e:status['finalSourceCheckError']=str(e)
 status['logDigests']={}
 for name in ['stdout.log','stderr.log','strace-stderr.log','startup-file-syscalls.log']:
  p=dest/name
  if p.exists():status['logDigests'][name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 if tmp is not None:
  status['privateTmpSpaceAfter']=free(tmp)
  status['privateTmpEntries']=[p.name for p in tmp.iterdir()][:20]
  shutil.rmtree(tmp)
  status['privateTmpRemoved']=not tmp.exists()
 status['stage']='completed-diagnostic'
 status['finishedAt']=datetime.now(timezone.utc).isoformat();save()
