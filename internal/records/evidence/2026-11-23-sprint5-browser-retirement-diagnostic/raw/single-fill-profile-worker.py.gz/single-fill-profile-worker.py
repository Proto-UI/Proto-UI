import os,json,pathlib,hashlib,subprocess,tempfile,datetime,time,socket,signal,shutil
root=pathlib.Path('/tank/shared/projects/proto-ui-agent/root-browser-retirement-75d5e28a')
ops=pathlib.Path(str(root)+'-ops')
out=ops/'single-fill-profile-d995'
out.mkdir(exist_ok=False)
node=pathlib.Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin')
tmp=pathlib.Path(tempfile.mkdtemp(prefix='pui-fill-',dir='/var/tmp'))
env=os.environ.copy()
env.update(PATH=str(node)+':'+env['PATH'],COREPACK_HOME='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/corepack-cache',COREPACK_ENABLE_DOWNLOAD_PROMPT='0',CI='1',ASTRO_TELEMETRY_DISABLED='1',NODE_OPTIONS='--max-old-space-size=4096',TMPDIR=str(tmp),PUI_PROBE_ROOT=str(root),PUI_PROBE_OUTPUT=str(out),PUI_PROBE_SOURCE_TRACE=str(ops/'observed-browser-v3-d9958d163436/trace.jsonl'),PUI_PROBE_HEAD='d9958d163436ea08d4a19b325d9e7f5dad3dc951',PUI_PROBE_URL='http://127.0.0.1:4396',PUI_CHROME_EXECUTABLE='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/playwright-browsers/chromium-1208/chrome-linux64/chrome')
status={'kind':'single-fill-profile-supervisor','diagnosticOnly':True,'port':4396,'canonicalUnchanged':True,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'temporary':str(tmp)}
source_names=list(json.loads((ops/'observed-browser-v3-d9958d163436/status.json').read_text())['sourceSha256Before'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sources():return {name:sha(root/name) for name in source_names}
def git(*args):return subprocess.check_output(['git',*args],cwd=root,env=env,text=True,timeout=60).strip()
def save():(out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def listening():
 s=socket.socket();s.settimeout(.25);r=s.connect_ex(('127.0.0.1',4396))==0;s.close();return r
def retire(process):
 if process is None:return
 if process.poll() is None:
  try:os.killpg(process.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:process.wait(10)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGKILL);process.wait(10)
server=None;browser=None;started=time.monotonic()
try:
 status.update(headBefore=git('rev-parse','HEAD'),treeBefore=git('rev-parse','HEAD^{tree}'),gitBefore=git('status','--porcelain'),sourceBefore=sources(),probeSha256=sha(ops/'single-fill-profile.mjs'),workerSha256=sha(pathlib.Path(__file__)))
 assert status['headBefore']==env['PUI_PROBE_HEAD'] and not status['gitBefore']
 assert not listening(),'Port4396 already in use'
 server_command=[str(node/'node'),'node_modules/astro/astro.js','dev','--host','127.0.0.1','--port','4396']
 with (out/'astro.log').open('wb') as log:
  server=subprocess.Popen(server_command,cwd=root/'apps/www',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 status.update(serverPid=server.pid,serverCommand=server_command,stage='astro-startup');save()
 deadline=time.monotonic()+90
 while True:
  if server.poll() is not None:raise RuntimeError('Owned Astro exited before ready')
  text=(out/'astro.log').read_text(errors='replace')
  if 'http://127.0.0.1:4396/' in text and listening():break
  if time.monotonic()>deadline:raise TimeoutError('Original90s Astro readiness exceeded')
  time.sleep(.2)
 status.update(serverReadySeconds=time.monotonic()-started,stage='browser-comparison');save()
 with (out/'node.log').open('wb') as log:
  browser=subprocess.Popen([str(node/'node'),str(ops/'single-fill-profile.mjs')],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  status['probePid']=browser.pid;save()
  try:code=browser.wait(150)
  except subprocess.TimeoutExpired:
   status['probeTimedOut']=True;retire(browser);code=browser.returncode
 status.update(probeExitCode=code,state='completed' if code==0 else 'failed')
except Exception as error:status.update(state='failed',error=repr(error))
finally:
 retire(browser);retire(server)
 status.update(serverRetired=server is None or server.poll() is not None,probeRetired=browser is None or browser.poll() is not None,portListeningAfter=listening())
 try:status.update(headAfter=git('rev-parse','HEAD'),gitAfter=git('status','--porcelain'),sourceAfter=sources())
 except Exception as error:status['sourceReadbackError']=repr(error)
 status['sourceStable']=status.get('sourceBefore')==status.get('sourceAfter') and status.get('headBefore')==status.get('headAfter') and status.get('gitBefore')==status.get('gitAfter')==''
 shutil.rmtree(tmp);status.update(temporaryRemoved=not tmp.exists(),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-started)
 for name in ['probe.json','node.log','astro.log','single-fill.cpuprofile']:
  p=out/name
  if p.exists():status[name]={'bytes':p.stat().st_size,'sha256':sha(p)}
 save();print(json.dumps({k:v for k,v in status.items() if k not in ['sourceBefore','sourceAfter']},indent=2),flush=True)
