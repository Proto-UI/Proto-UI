(() => {
  const outer = window === window.top;
  const documentId = String(performance.timeOrigin);
  const pending = [];
  const values = new Map();
  let nextValue = 0, timer, lastState = '';
  const ids = new WeakMap(); let nextFrame = 0;
  let untrustedInputStacks = 0;
  const targetLabel = target => {
    if (target === window) return 'window';
    if (target === document) return 'document';
    if (target instanceof Element) {
      let label = target.localName;
      if (target.id) label += '#' + target.id.slice(0, 80);
      for (const attribute of ['data-source-text', 'data-source-file', 'data-compiler-panel', 'data-pui-root']) {
        if (target.hasAttribute(attribute)) label += '[' + attribute + ']';
      }
      return label;
    }
    return target?.nodeName ?? target?.constructor?.name ?? typeof target;
  };
  const id = frame => { if (!ids.has(frame)) ids.set(frame, ++nextFrame); return ids.get(frame); };
  const flush = () => {
    clearTimeout(timer); timer = undefined;
    if (!pending.length) return;
    const batch = pending.splice(0);
    try { globalThis.__puiRetirementObserve({ documentId, outer, url: location.href, batch })?.catch(() => {}); } catch {}
  };
  const emit = record => {
    pending.push({ time: performance.timeOrigin + performance.now(), ...record });
    if (timer === undefined) timer = setTimeout(flush, 200);
  };
  const valueId = value => {
    if (typeof value !== 'string') return null;
    if (!values.has(value)) { values.set(value, ++nextValue); emit({kind:'source-value', id:nextValue, value}); }
    return values.get(value);
  };
  const snapshot = () => {
    if (!outer) return;
    const panel = document.querySelector('pui-browser-compiler');
    if (!panel) return;
    const state = {phase:panel.dataset.compilerPhase, revision:panel.dataset.compilerRevision,
      eventCount:panel.dataset.eventCount, scrollY, visibility:document.visibilityState,
      diagnostic:panel.querySelector('[data-compiler-diagnostics]')?.textContent?.slice(0,2000),
      frames:[...panel.querySelectorAll('iframe')].map(frame=>({id:id(frame),title:frame.title,hidden:frame.hidden,style:frame.getAttribute('style'),connected:frame.isConnected}))};
    const current = JSON.stringify(state);
    if(current!==lastState) {lastState=current;emit({kind:'panel-state',...state});}
  };
  emit({kind:'document-init'});
  addEventListener('message', event => {
    const data=event.data;
    if(!data || typeof data.type!=='string' || !/^(preview-|dispose|disposed|cleanup-error)/.test(data.type))return;
    const sourceFrame=outer?[...document.querySelectorAll('pui-browser-compiler iframe')].find(frame=>frame.contentWindow===event.source):null;
    emit({kind:'message',type:data.type,revision:data.revision,token:data.token,profile:data.profile,origin:event.origin,fromParent:event.source===parent,sourceFrame:sourceFrame?id(sourceFrame):null,message:data.message});
    if(!outer)flush();
  },true);
  for(const kind of ['pagehide','unload','visibilitychange'])addEventListener(kind,()=>{emit({kind,visibility:document.visibilityState});flush();});
  try { new PerformanceObserver(list=>{for(const entry of list.getEntries())emit({kind:'long-task',start:performance.timeOrigin+entry.startTime,duration:entry.duration});}).observe({type:'longtask',buffered:true}); } catch {}
  if(outer){
    for(const event of ['beforeinput','input','change','click','toggle'])addEventListener(event,entry=>{
      const el=entry.target instanceof Element?entry.target.closest('[data-compiler-run],[data-compiler-cancel],[data-compiler-target],[data-source-text],[data-source-file],[data-source-editor],[data-compiler-panel]'):null;
      if(!el)return;
      const panel=el.closest('pui-browser-compiler'),file=panel?.querySelector('[data-source-file]')?.value;
      const source=el.matches('[data-source-text]')?el.value:undefined;
      const bound=typeof file==='string'?panel?.files?.[file]:undefined;
      const rawTarget = entry.target;
      const eventPath = typeof entry.composedPath === 'function' ? entry.composedPath() : [];
      const identity = {
        eventConstructor: entry.constructor?.name,
        rawTargetLocalName: rawTarget instanceof Element ? rawTarget.localName : null,
        rawTargetTagName: rawTarget instanceof Element ? rawTarget.tagName : null,
        rawTargetConstructor: rawTarget?.constructor?.name,
        rawTargetLabel: targetLabel(rawTarget),
        currentTargetLabel: targetLabel(entry.currentTarget),
        matchedControlLabel: targetLabel(el),
        composedPath: eventPath.slice(0, 12).map(targetLabel),
        composedPathLength: eventPath.length,
      };
      // At most six stacks per outer document; later repeated inputs stay cheap.
      if (event === 'input' && entry.isTrusted === false && untrustedInputStacks < 6) {
        identity.untrustedInputStackIndex = ++untrustedInputStacks;
        identity.untrustedInputStack = String(new Error('passive untrusted input origin').stack ?? '').slice(0, 4000);
      }
      emit({kind:'action',event,...identity,target:el.tagName,attributes:Object.keys(el.dataset),isTrusted:entry.isTrusted,inputType:entry.inputType,isComposing:entry.isComposing,phase:panel?.dataset.compilerPhase,revision:panel?.dataset.compilerRevision,file,valueId:valueId(source),boundValueId:valueId(bound),byteEqual:typeof source==='string'&&source===bound,focused:document.activeElement===el,scrollY,visibility:document.visibilityState});
      queueMicrotask(snapshot);
    },true);
    new MutationObserver(snapshot).observe(document,{childList:true,subtree:true,attributes:true,attributeFilter:['data-compiler-phase','data-compiler-revision','hidden','style']});
    addEventListener('scroll',snapshot,{passive:true});
    snapshot();
  }
  globalThis.__puiRetirementObserverFlush=flush;
})();