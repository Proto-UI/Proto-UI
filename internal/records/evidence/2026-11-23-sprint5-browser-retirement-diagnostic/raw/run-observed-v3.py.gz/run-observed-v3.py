import datetime, hashlib, json, os, re, signal, subprocess, sys, tempfile, shutil
from pathlib import Path

root = Path('/tank/shared/projects/proto-ui-agent/root-browser-retirement-75d5e28a')
operations = Path('/tank/shared/projects/proto-ui-agent/root-browser-retirement-75d5e28a-ops')
expected = sys.argv[1] if len(sys.argv) == 2 else ''
if not re.fullmatch(r'[0-9a-f]{40}', expected):
    raise SystemExit('Supply one exact combined source SHA.')
out = operations / ('observed-browser-v3-' + expected[:12])
out.mkdir(parents=True, exist_ok=False)
temporary_parent = '/var/tmp'
if os.statvfs(temporary_parent).f_bavail * os.statvfs(temporary_parent).f_frsize < 512 * 1024 * 1024:
    temporary_parent = '/tank/shared/projects/proto-ui-agent'
temporary = Path(tempfile.mkdtemp(prefix='pui-v3-', dir=temporary_parent))
node_directory = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin'
chrome = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/playwright-browsers/chromium-1208/chrome-linux64/chrome'
configured = {
    'TMPDIR': str(temporary),
    'CI': '1',
    'COREPACK_ENABLE_DOWNLOAD_PROMPT': '0',
    'ASTRO_TELEMETRY_DISABLED': '1',
    'NODE_OPTIONS': '--max-old-space-size=4096',
    'PUI_CHROME_EXECUTABLE': chrome,
    'PUI_BROWSER_PORT': '4386',
    'PUI_BROWSER_MODE': 'development',
    'PUI_EVIDENCE_DIR': str(out / 'browser'),
}
environment = dict(os.environ, **configured)
environment['PATH'] = node_directory + ':' + os.environ['PATH']
environment['PUI_OBSERVER_TRACE'] = str(out / 'trace.jsonl')
status_path = out / 'status.json'
files = [
    'apps/www/src/components/PrototypePreviewer/browser-compiler-panel.ts',
    'apps/www/src/components/PrototypePreviewer/compiled-preview-sandbox.ts',
    'packages/compiler/test/browser-source-input.test.ts',
    'scripts/coverage-matrices/check-website-production-bundle.mjs',
    'scripts/coverage-matrices/test/check-website-production-bundle.test.mjs',
    '.github/workflows/compiler-browser-acceptance.yml',
    'scripts/analysis/browser-compiler-browser.mts',
    'apps/www/src/components/PrototypePreviewer/compiled-revision-session.ts',
    'scripts/compiler/browser-production.mjs',
    'package.json',
    'pnpm-lock.yaml',
]
status = {
    'kind': 'passively-observed-browser-diagnostic-v3',
    'expectedHead': expected,
    'root': str(root),
    'output': str(out),
    'configuredEnvironment': configured,
    'nodeDirectory': node_directory,
    'scope': 'Diagnostic-only passive batched observer of unchanged runner and application; Chromium OS sandbox, original 1200-second supervisor and 250-millisecond retirement deadline. Not unobserved acceptance.',
    'steps': [],
    'observerChange': 'Passive event target/constructor/composedPath labels and the first six untrusted input stacks per outer document, capped at 4000 characters; original value IDs, byte equality, batching and longtask observer retained.',
    'temporaryDirectoryOwned': True,
    'temporaryAvailableBytesBefore': os.statvfs(temporary).f_bavail * os.statvfs(temporary).f_frsize,
}
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save():
    status_path.write_text(json.dumps(status, indent=2) + '\n')
def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=root, env=environment, text=True, timeout=90).strip()
def sources():
    return {name: digest(root / name) for name in files}
process = None
try:
    assert 'PUI_BROWSER_URL' not in environment, 'An externally supplied browser URL is not valid for owned-service acceptance.'
    status.update(startedAt=now(), head=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'), statusBefore=git('status', '--porcelain'))
    assert status['head'] == expected, 'The checked-out source differs from the requested combined SHA.'
    assert not status['statusBefore'], 'The combined source checkout must be clean.'
    status['sourceSha256Before'] = sources()
    status['driverSha256'] = digest(Path(__file__))
    status['observerSha256'] = digest(operations / 'observer-v3.cjs')
    status['nodeVersion'] = subprocess.check_output([node_directory + '/node', '--version'], env=environment, text=True, timeout=30).strip()
    save()
    command = [node_directory + '/node', '--require', str(operations / 'observer-v3.cjs'), '--import', 'tsx', 'scripts/analysis/browser-compiler-browser.mts']
    log = out / 'canonical-browser.log'
    row = {'name': 'canonical-browser', 'command': command, 'timeoutSeconds': 1200, 'startedAt': now(), 'state': 'running', 'log': str(log)}
    status['steps'].append(row)
    print('Starting canonical browser at ' + expected, flush=True)
    with log.open('wb') as output:
        process = subprocess.Popen(command, cwd=root, env=environment, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        row['pid'] = process.pid
        save()
        try:
            code = process.wait(1200)
        except subprocess.TimeoutExpired:
            row['timedOut'] = True
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                code = process.wait(10)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                code = process.wait()
    row.update(exitCode=code, state='passed' if code == 0 and not row.get('timedOut') else 'failed', finishedAt=now(), logSha256=digest(log))
    status.update(headAfter=git('rev-parse', 'HEAD'), statusAfter=git('status', '--porcelain'), sourceSha256After=sources())
    receipt_path = out / 'browser/receipt.json'
    if receipt_path.exists():
        receipt = json.loads(receipt_path.read_text())
        cases = receipt.get('cases', [])
        status['receipt'] = {
            'path': str(receipt_path),
            'sha256': digest(receipt_path),
            'head': receipt.get('head'),
            'browser': receipt.get('browser'),
            'caseCount': len(cases),
            'passed': sum(case.get('status') == 'passed' for case in cases),
            'failed': [case for case in cases if case.get('status') != 'passed'],
        }
    status['state'] = 'passed' if (
        row['state'] == 'passed'
        and status['headAfter'] == expected
        and not status['statusAfter']
        and status['sourceSha256Before'] == status['sourceSha256After']
        and status.get('receipt', {}).get('head') == expected
        and status.get('receipt', {}).get('caseCount', 0) > 0
        and not status.get('receipt', {}).get('failed', [])
    ) else 'failed'
except Exception as error:
    status.update(state='failed', error=repr(error))
finally:
    if process is not None and process.poll() is None:
        status['unexpectedLiveChildCleanup'] = True
        try:
            os.killpg(process.pid, signal.SIGTERM)
            process.wait(10)
        except ProcessLookupError:
            pass
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(10)
    status['supervisorChildRetired'] = process is None or process.poll() is not None
    status['temporaryEntriesAtExit'] = [entry.name for entry in temporary.iterdir()][:20] if temporary.exists() else []
    shutil.rmtree(temporary)
    status['temporaryDirectoryRemoved'] = not temporary.exists()
    status['finishedAt'] = now()
    save()
    print(json.dumps({key: value for key, value in status.items() if key not in ['sourceSha256Before', 'sourceSha256After', 'configuredEnvironment']}, indent=2), flush=True)
raise SystemExit(0 if status.get('state') == 'passed' else 1)