import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';

const root = process.cwd();
const require = createRequire(path.join(root, 'package.json'));
const ts = require('typescript');
const roots = [
  'packages/compiler/src/parser.ts',
  'packages/compiler/src/callable-effects.ts',
  'packages/compiler/src/operations.ts',
  'packages/compiler/src/native-value-lowering.ts',
  'packages/compiler/src/vue2-source.ts',
  'packages/compiler/src/web-component-source.ts',
  'packages/compiler/test/local-nominal-helper-fixture.ts',
  'packages/compiler/test/local-nominal-helper.test.ts',
  'packages/compiler/test/local-nominal-helper-types.test.ts',
  'packages/compiler/test/local-tabs-artifact.ts',
  'packages/compiler/test/local-tabs-consumer.test.ts',
  'packages/compiler/test/fixtures/local-tabs-provider.proto.ts',
  'packages/compiler/test/lifecycle-module-fixture.ts',
  'packages/compiler/test/lifecycle-module.test.ts',
  'packages/compiler/test/lifecycle-module-types.test.ts',
];
const config = ts.readConfigFile(path.join(root, 'tsconfig.json'), ts.sys.readFile);
const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root);
const program = ts.createProgram(roots.map((file) => path.join(root, file)), {
  ...parsed.options,
  noEmit: true,
});
const diagnostics = [...(config.error ? [config.error] : []), ...parsed.errors, ...ts.getPreEmitDiagnostics(program)]
  .map((diagnostic) => {
    const position = diagnostic.file && diagnostic.start !== undefined
      ? diagnostic.file.getLineAndCharacterOfPosition(diagnostic.start) : undefined;
    return {
      code: diagnostic.code,
      file: diagnostic.file ? path.relative(root, diagnostic.file.fileName) : undefined,
      line: position ? position.line + 1 : undefined,
      character: position ? position.character + 1 : undefined,
      message: ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'),
    };
  });
const report = { roots, count: diagnostics.length, diagnostics };
fs.writeFileSync(process.argv[2], JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
process.exitCode = diagnostics.length ? 1 : 0;
