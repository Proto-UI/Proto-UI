import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,symlinkSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
const root='/workspace/scratch/b2027510c911/s2-compiler';
const req=createRequire(path.join(root,'packages/compiler/package.json'));
const {Window}=req('happy-dom');
const win=new Window({url:'http://lifecycle-review.invalid'});
for(const key of ['window','self','document','navigator','Node','Element','HTMLElement','SVGElement','Text','Comment','Event','CustomEvent','MouseEvent','KeyboardEvent','MutationObserver','ResizeObserver','customElements']) Object.defineProperty(globalThis,key,{value:key==='window'||key==='self'?win:win[key],configurable:true});
globalThis.IS_REACT_ACT_ENVIRONMENT=true;
const compiler=await import(pathToFileURL(path.join(root,'packages/compiler/src/compile.ts')));
const directory=mkdtempSync(path.join(tmpdir(),'s2-lifecycle-review-'));
writeFileSync(path.join(directory,'package.json'),JSON.stringify({type:'module'}));
symlinkSync(path.join(root,'packages/compiler/node_modules'),path.join(directory,'node_modules'),'dir');
const source=`import{definePrototype,type RunHandle}from'@proto.ui/core';
export default definePrototype({name:'lifecycle-cross-callback',setup(def){
 let saved:RunHandle<{}>['lifecycle']|null=null;let mounts=0;
 const same=def.state.bool('same',true);
 def.lifecycle.onCreated(run=>{saved=run.lifecycle;});
 def.lifecycle.onMounted(run=>{mounts++;same.set(saved===run.lifecycle);});
 def.expose.method('read',()=>({same:same.get(),mounts}));
 return r=>r.el('output','identity');
}});`;
writeFileSync(path.join(directory,'input.proto.ts'),source);
const hashes={};for(const file of ['packages/compiler/src/web-component-source.ts','packages/compiler/src/vue-source.ts','packages/compiler/src/vue2-source.ts','packages/compiler/src/react-source.ts','packages/runtime/src/kernel/kernel.ts','packages/runtime/src/kernel/handles/run.ts'])hashes[file]=createHash('sha256').update(readFileSync(path.join(root,file))).digest('hex');
console.log('REVIEW_MODULES_LOADED',directory);
const report={scope:'Independent readonly review, actual Core session and native generated consumers in Happy DOM; not clean install acceptance',root,hashes,source,results:[]};
const save=()=>writeFileSync(path.join(directory,'report.json'),JSON.stringify(report,null,2)+'\n');save();
try{
 try{
  const {createRuntimeSession}=await import(pathToFileURL(path.join(root,'packages/runtime/src/index.ts')));
  const {default:proto}=await import(pathToFileURL(path.join(directory,'input.proto.ts')));
  const session=createRuntimeSession(proto,{prototypeName:'lifecycle-cross-callback',getRawProps:()=>({}),commit(_children,signal){signal?.done();},schedule(task){task();}});
  await session.mount();let observed;session.invokeInCallbackScope(()=>{observed=session.caps.getPort('expose').get('read')();});
  report.results.push({profile:'actual-runtime-session',observed});await session.dispose();
 }catch(error){report.results.push({profile:'actual-runtime-session',error:error.stack});}save();
 for(const profile of ['react-dom-source-v1','vue-source-v1','vue2-source-v1','web-component-source-v1']){
  let cleanup=async()=>{};
  try{
   const result=compiler.compilePrototype(source,{profile});if(!result.ok)throw Error(JSON.stringify(result.diagnostics));
   const folder=path.join(directory,profile);mkdirSync(folder);const output=path.join(folder,'output');const written=await compiler.writeCompilation(result.value,output);if(!written.ok)throw Error(JSON.stringify(written.diagnostics));
   const extension=profile==='react-dom-source-v1'?'tsx':profile==='vue2-source-v1'?'js':'ts';
   const generated=await import(pathToFileURL(path.join(output,'Component.'+extension)));
   const host=document.createElement('div');document.body.appendChild(host);let handle;
   if(profile==='react-dom-source-v1'){
    const React=req('react');const {createRoot}=req('react-dom/client');const reactRoot=createRoot(host);const ref=React.createRef();
    await React.act(async()=>reactRoot.render(React.createElement(generated.CompiledComponent,{ref})));handle=ref.current;
    cleanup=async()=>{await React.act(async()=>reactRoot.unmount());host.remove();};
   }else if(profile==='vue-source-v1'){
    const Vue=req('vue');const ref=Vue.ref();const app=Vue.createApp({render:()=>Vue.h(generated.CompiledComponent,{ref})});app.mount(host);await Vue.nextTick();await Vue.nextTick();handle=ref.value;
    cleanup=async()=>{app.unmount();await Vue.nextTick();host.remove();};
   }else if(profile==='vue2-source-v1'){
    const Vue2=req(path.join(root,'packages/adapters/vue2/node_modules/vue'));Vue2.config.productionTip=false;Vue2.config.devtools=false;
    const vm=new Vue2({render(h){return h(generated.CompiledComponent,{ref:'compiled'});}});vm.$mount();host.append(vm.$el);await Vue2.nextTick();handle=vm.$refs.compiled;
    cleanup=async()=>{vm.$destroy();await Vue2.nextTick();host.remove();};
   }else{
    const tag='pui-cross-callback-review';generated.register(tag);const element=document.createElement(tag);host.appendChild(element);for(let i=0;i<8;i++)await Promise.resolve();handle=element;
    cleanup=async()=>{element.dispose();await Promise.resolve();host.remove();};
   }
   const observed=handle.getExposes().read();report.results.push({profile,observed});
  }catch(error){report.results.push({profile,error:error.stack});}finally{await cleanup();save();}
 }
}finally{await win.happyDOM.abort();win.close();}
console.log(JSON.stringify({directory,results:report.results},null,2));
