import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
const root='/workspace/scratch/b2027510c911/s2-compiler';
const {parsePrototype}=await import(pathToFileURL(path.join(root,'packages/compiler/src/parser.ts')));
const {validateIR}=await import(pathToFileURL(path.join(root,'packages/compiler/src/ir-validation.ts')));
const {compilePrototype}=await import(pathToFileURL(path.join(root,'packages/compiler/src/memory.ts')));
const moduleType='{setPresent(next:boolean):void}';
const cases=[
  ['closed-bound-public-wrapper',true,`def.expose.method('hide',()=>{if(saved)apply(saved,false);});`],
  ['closed-returned-bound-closure',true,`def.expose.method('get',()=>()=>{if(saved)apply(saved,false);});`],
  ['open-public-wrapper',false,`def.expose.method('use',(owner:${moduleType})=>apply(owner,false));`],
  ['escaped-helper-via-getter',false,`const box={get invoke(){return apply;}};def.expose.method('get',()=>box.invoke);`],
  ['escaped-helper-via-array',false,`const aliases=[apply];def.expose.method('get',()=>aliases);`],
  ['escaped-helper-via-later-write',false,`const box={invoke:(owner:${moduleType},next:boolean)=>owner.setPresent(next)};box.invoke=apply;def.expose.method('get',()=>box);`],
  ['open-returned-wrapper',false,`def.expose.method('get',()=>({invoke:(owner:${moduleType})=>apply(owner,false)}));`],
  ['external-callback-receives-helper',false,`def.expose.method('send',(accept:(fn:(owner:${moduleType},next:boolean)=>void)=>void)=>accept(apply));`],
  ['nominal-public-input',null,`def.expose.method('use',(owner:RunHandle<{}>['lifecycle'])=>owner.setPresent(false));`],
];
const report={scope:'Independent bounded source/cold-IR review; no final distribution or public target acceptance',root,hashes:{},results:[]};
for(const file of ['packages/compiler/src/parser.ts','packages/compiler/src/callable-effects.ts','packages/compiler/src/ir-validation.ts','packages/compiler/src/native-value-lowering.ts'])report.hashes[file]=createHash('sha256').update(readFileSync(path.join(root,file))).digest('hex');
for(const [name,expected,body] of cases){
 const source=`import{definePrototype,type RunHandle}from'@proto.ui/core';export default definePrototype({name:'local-boundary-review',setup(def){let saved:RunHandle<{}>['lifecycle']|null=null;const apply=(owner:${moduleType},next:boolean)=>owner.setPresent(next);def.lifecycle.onCreated(run=>{saved=run.lifecycle;apply(run.lifecycle,true);});${body}return r=>r.el('div','review');}});`;
 const parsed=parsePrototype(source);const row={name,expected,source,ok:parsed.ok};
 if(parsed.ok){const cold=validateIR(JSON.parse(JSON.stringify(parsed.value)));row.cold={ok:cold.ok,...(!cold.ok?{diagnostics:cold.diagnostics}:{})};}
 else row.diagnostics=parsed.diagnostics;
 if(name==='nominal-public-input')row.targets=['react-dom-source-v1','vue-source-v1','vue2-source-v1','web-component-source-v1'].map(profile=>{const value=compilePrototype(source,{profile});return{profile,ok:value.ok,...(!value.ok?{diagnostics:value.diagnostics}:{})};});
 report.results.push(row);
}
report.unexpected=report.results.filter(row=>row.expected!==null&&row.ok!==row.expected).map(row=>row.name);
writeFileSync('/workspace/scratch/b2027510c911/s2-compiler-workflow/review-local-nominal-boundaries.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({results:report.results.map(({source,...row})=>row),unexpected:report.unexpected},null,2));
if(report.unexpected.length)process.exitCode=1;
