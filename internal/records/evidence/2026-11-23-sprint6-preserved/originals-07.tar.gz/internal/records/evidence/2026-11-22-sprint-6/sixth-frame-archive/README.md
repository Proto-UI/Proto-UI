# sixth-frame-archive

This archive preserves original report bytes from [run 45030247951](https://github.com/Proto-UI/Proto-UI/actions/runs/45030247951) and [its native job](https://github.com/Proto-UI/Proto-UI/actions/runs/45030247951/job/137232057824). Executed head: `7871a8da3967ae4bb29cd50c655860cf87d374c0`. Tree: `1a08b265b1062dd2a44ccf9c2fcaa8bc1aaa9bdb`. The original workflow conclusion is **failure**; the original readback conclusion is `passed-readback`. A successful readback verifies the recorded observations and does not convert a failed workflow into product acceptance.

All 27 JSON/log/text/Markdown reports in the original 239-member artifact and all 6 local readback/GitHub report files are stored as deterministic gzip files. Each decompressed byte string was compared to the complete original file. JSON and text bodies were not normalized, edited or reserialized. The [archive index](archive-index.json) records each original and compressed byte count and SHA-256, the exact source/run/job identity and the original readback digest. The [complete artifact inventory](artifact-inventory.json) retains all 239 original member paths, sizes, SHA-256 and ZIP CRC32 values; every extracted member was compared to the verified original ZIP.

Exactly two original PNGs are copied under `images/`:

- `candidate-release/quality-timeout-12-self-optical.png` — SHA-256 `724e7cc1dc8c3c81f0852d9591ea27a42057f662778f451a3e6c771bdd67b767`.
- `candidate-release/quality-timeout-6-self-optical.png` — SHA-256 `f98e77d8f28696f2f6aaed428771f9abc7a85c2a84e912e22abb99c1fc8c2ef3`.

The other 210 PNGs are inventoried but their image bytes are not stored in this Git archive. The original ZIP is not copied here. Those remaining images are available only from the [Actions artifact](https://github.com/Proto-UI/Proto-UI/actions/runs/45030247951/artifacts/14757847071) under its 30-day retention, with recorded expiry `2026-12-22T14:10:09Z`. No permanent retention of those images is claimed. Download-temporary metadata and signed download URLs are excluded.

The parent readback's original limitations are retained verbatim in its gzip copy and in the index. This archival operation runs no tests, build, browser, physical display/input measurement or new visual review. It does not relabel either execution as a later source head or alter the unmet 120 Hz / 10 ms and full Sprint acceptance conditions.
