# Sixth Liquid exact original gzip archive

Executed source: `7871a8da3967ae4bb29cd50c655860cf87d374c0`, tree `1a08b265b1062dd2a44ccf9c2fcaa8bc1aaa9bdb`.

[Run 45030339064](https://github.com/Proto-UI/Proto-UI/actions/runs/45030339064) failed its main browser job. This archive preserves the original outcomes; it is not a rerun or acceptance for a later commit.

- **42 existing gzip files, 2,634,480 bytes.** No recompression or rewriting of raw JSON/log text was performed during copying.
- [archive-index.json](archive-index.json) maps all 42 compressed files to original source paths, original byte counts / SHA-256 and repository paths. Every decompression was compared against the actual original file.
- [raw-archive/manifest.json](raw-archive/manifest.json) is the unchanged earlier 20-file manifest for the eight optical/hover lanes. Its narrower inventory is preserved as an original; the new archive index supplies the complete 42-file mapping.
- The other 22 gzip files are the 11 main/controls JSON records and 11 original job logs. Both DPR timeout snapshots and the failed main job log remain included.

Original absolute paths inside frozen receipts identify where the files were originally read. They are not public download URLs. Repository file locations are explicit in the new index and [copy map](../sixth-liquid-readback/copy-map.json). Original artifact/job/API URLs and expiration metadata are retained. The selected archive does not contain all source PNGs, raw diagnostic frames or other members of the original 12 artifact ZIPs.

Read [the accompanying readback](../sixth-liquid-readback/README.md) for the exact 958/960 main failure, 94/94 controls result, eight dark Button pair limitations, historical diagnostics and separate Finf Accordion failure. No physical refresh-rate, latency target, OS IME, Apple appearance or non-Web completion is established by these files.
