import collections
import hashlib
import json
from pathlib import Path
import sys

runtime, job_id = sys.argv[1], int(sys.argv[2])
root = Path('/workspace/scratch/cd1b397ad8e7/liquid-work/material-run-45030339064')
directory = root / ('hover-' + runtime) / 'hover'
plan = json.loads((directory / 'plan.json').read_text())
progress = json.loads((directory / 'progress.json').read_text())
results = json.loads((directory / 'results.json').read_text())
sha = '7871a8da3967ae4bb29cd50c655860cf87d374c0'
tree = '1a08b265b1062dd2a44ccf9c2fcaa8bc1aaa9bdb'
empty = hashlib.sha256(b'').hexdigest()
errors = []

def check(ok, message):
    if not ok:
        errors.append(message)

def source(value, name):
    check(value.get('sourceSha') == sha and value.get('candidateSha') == sha, name + ': head')
    check(value.get('sourceTree') == tree and value.get('patchSha256') == empty, name + ': tree/patch')

source(plan['source'], 'plan')
source(progress['source'], 'progress')
source(results, 'results')
check(progress['planSha256'] == hashlib.sha256((directory / 'plan.json').read_bytes()).hexdigest(), 'plan digest')
expected_cases = {runtime + '/' + theme + '/' + journey for theme in ['light', 'dark'] for journey in ['interaction', 'policy-and-boundaries']}
check({case['id'] for case in plan['cases']} == expected_cases and len(plan['cases']) == 4, 'plan case identities')
check({case['id'] for case in progress['cases']} == expected_cases and len(progress['cases']) == 4, 'progress case identities')
check(progress['setup'].get('state') == 'completed', 'setup not completed')
expected_captures = {capture['name']: capture for case in plan['cases'] for part in case['parts'] for capture in part['captures']}
observed_captures = {capture['name']: capture for case in progress['cases'] for part in case['parts'] for capture in part['captures']}
check(set(observed_captures) == set(expected_captures) and len(expected_captures) == 720, 'capture identities/count')
parts = 0
for case in progress['cases']:
    check(case.get('state') == 'completed' and not case.get('failure'), case['id'] + ': case terminal')
    for part in case['parts']:
        parts += 1
        check(part.get('state') == 'completed' and not part.get('failure') and not part.get('cleanupErrors'), case['id'] + '/' + part['part'] + ': part terminal/cleanup')
        for capture in part['captures']:
            check(capture.get('state') == 'completed' and not capture.get('failure'), capture['name'] + ': capture terminal')
hashes = collections.Counter()
for name, entry in expected_captures.items():
    record_path = directory / entry['record']
    if not record_path.is_file():
        errors.append(name + ': missing record')
        continue
    record = json.loads(record_path.read_text())
    source(record, name)
    check(record.get('observationError') is None and record.get('screenshotError') is None, name + ': capture errors')
    check(all(not item.get('errors') for item in record.get('screenshotGeometryChecks', [])), name + ': geometry errors')
    for key, field in [('root', 'screenshotSha256'), ('context', 'contextScreenshotSha256'), ('materialIfPresent', 'materialSha256')]:
        expected_hash = record.get(field)
        if key == 'materialIfPresent' and not expected_hash:
            continue
        path = directory / entry[key]
        if not path.is_file():
            errors.append(name + ': missing ' + key)
            continue
        check(hashlib.sha256(path.read_bytes()).hexdigest() == expected_hash, name + ': ' + key + ' digest')
        hashes[key] += 1
for row in results['results']:
    check(not row.get('failure') and not row.get('cleanupErrors'), 'results failure/cleanup')
report = {
    'runtime': runtime, 'runId': 45030339064, 'jobId': job_id,
    'jobConclusion': 'success', 'sourceSha': sha, 'sourceTree': tree,
    'cleanPatch': True, 'cases': len(expected_cases), 'parts': parts,
    'captures': len(expected_captures), 'hashesVerified': dict(hashes),
    'readbackErrors': errors, 'visuallyInspected': [],
    'scope': 'Complete real runtime interaction/policy partition; screenshots and conditional material bytes verified. Synthetic cancellation remains labelled; no physical120Hz/10ms or whole-family optical acceptance.'
}
(root / ('hover-' + runtime + '-readback.json')).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))

if errors:
    sys.exit(1)
