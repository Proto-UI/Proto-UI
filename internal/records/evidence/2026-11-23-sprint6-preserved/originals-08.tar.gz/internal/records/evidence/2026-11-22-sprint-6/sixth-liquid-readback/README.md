# Sixth Liquid readback: executed source 7871a8d

These records describe the actual native execution of `7871a8da3967ae4bb29cd50c655860cf87d374c0`, tree `1a08b265b1062dd2a44ccf9c2fcaa8bc1aaa9bdb`. Copying them into a later evidence commit does not change their executed source or make them acceptance evidence for that later source.

## Native results retained

- [Liquid material run 45030339064](https://github.com/Proto-UI/Proto-UI/actions/runs/45030339064): all 11 jobs reached a terminal state, 10 success and one failed main job. The main material selection executed 960 assertions: 958 passed and two original 20-second DPR transition assertions failed. The six required DPR phases have only two recorded initial phases; later DPR 2 and restored phases were not reached.
- The separate controls selection passed 94 assertions and all 31 native cases. Its 16 plain/component composition comparisons, actual synthetic-end negative controls and owner acceptance records are retained. Chromium CDP composition is not physical OS IME acceptance.
- Four prominent-tint shards each executed 14 cases / 422 captures. Each still contains two inconclusive dark compact Button pairs. Four hover shards each executed four cases / 44 parts / 720 captures. These selected successes do not establish whole-family optical completion.
- The two diagnostic jobs remain diagnostics: visible refraction includes 38 insufficient-signal, 20 unresolved and six resolved captures; historical profile 4 replay on the current profile 6 host retains its rejection. Eight old interpretation strings saying “profile 5” are recorded as stale labels, not the actual host identity.
- [Full CI Finf disclosure job 137238435748](https://github.com/Proto-UI/Proto-UI/actions/runs/45030540222/job/137238435748): seven of eight cases passed. Liquid Accordion retains the original 1000 ms self-optical failure with `source-overlapping-content`. Later interaction assertions were not reached. Its actual source geometry is DPR 1 and is distinct from the material suite's DPR failure.

No physical 120 Hz / 10 ms target, physical OS IME, Apple appearance acceptance, assistive-technology or non-Web completion is claimed by this archive.

## Entry points

| Record | Purpose |
| --- | --- |
| [Complete Liquid readback](material-run-45030339064/sixth-full-liquid-readback.json) | All 11 terminal jobs, 12 artifact identities, raw-log provenance, main failures, selected lanes and limitations |
| [Main readback](material-run-45030339064/main-material-readback.json) | Original main/controls counts, exact event traces, portal/lifecycle checks and failed DPR inventory |
| [Eight-lane manifest](material-run-45030339064/selected-eight-lanes-manifest.json) | Per-host optical/hover inventory, actual inconclusive cases and original artifact hashes |
| [Independent diagnostics](review-reference/sixth-liquid-diagnostics-readback.json) | Refraction and historical tint replay remain separate from product acceptance |
| [Finf native cause](ci45030540222-finf-disclosure/readback-and-cause.json) | Actual source and target rectangles, real paint overlap and retained failure |
| [Finf decision boundary](finf-accordion-geometry-review/decision-boundary.md) | Draft reservation contract, unchanged and changed source layers, and two unselected implementation options |
| [Finf source delta](finf-accordion-geometry-review/reached-source-delta.json) | Exact base/current source hashes and selected reached-path comparison; not a baseline native verdict |
| [Copy map](copy-map.json) | Every original file's original path, repository destination, bytes and SHA-256 |
| [Raw archive map](../sixth-liquid-archive/archive-index.json) | All 42 existing gzip files, decompressed original bytes/hashes, and original provenance |

## Original-byte and path policy

The copied receipts, raw observations, verification scripts and original manifests are byte-for-byte copies. Their original absolute workspace paths, relative `raw-archive` paths and execution labels have deliberately not been rewritten. `copy-map.json` translates selected original files to repository paths; `archive-index.json` maps each compressed original to its repository location and decompressed identity. The sibling Finf directories preserve the original decision record's relative evidence links.

All 42 existing gzip files were copied without recompression and decompressed again to compare them byte-for-byte with the still-available originals. The archive is 2,634,480 compressed bytes. It contains the selected eight-lane original results and inventories, main/controls raw JSON, both DPR failure snapshots and all 11 original job logs. It is not a complete embedding of every PNG and diagnostic frame in the 12 GitHub artifacts.

The selected Finf artifact members include all eight original case JSONs and the Liquid failure's three PNGs, DOM, accessibility snapshot and environment/source records. The unchanged 65-member artifact index preserves the full original inventory; unembedded PNGs remain identified by that index and the original artifact. GitHub artifact links are subject to their recorded expiration dates; a permanent run/job URL does not extend binary retention.

No product files, test assertions, thresholds or definitions were changed by this archival operation. The original Accordion investigation remains unimplemented. Its source comparison does not establish that the baseline native run has the same failure.
