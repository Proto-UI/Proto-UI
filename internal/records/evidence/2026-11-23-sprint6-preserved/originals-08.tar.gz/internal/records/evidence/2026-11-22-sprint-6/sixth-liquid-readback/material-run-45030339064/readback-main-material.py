"""Read archived native artifacts only. Never starts a browser or a test runner."""
import collections
import hashlib
import json
import math
from pathlib import Path
import sys

root = Path(sys.argv[1])
head, tree, run_id, job_id, job_conclusion = sys.argv[2:7]
plan_path = Path(__file__).with_name('sixth-main-readback-plan.json')
plan = json.loads(plan_path.read_text())
errors = []
raw = []

def check(ok, message):
    if not ok:
        errors.append(message)

candidate = plan.get('candidate', {})
check(candidate.get('sha') == head and candidate.get('tree') == tree,
      'Readback invocation differs from the independently frozen candidate source')
check(str(candidate.get('runId')) == run_id and str(candidate.get('jobId')) == job_id,
      'Readback invocation differs from the independently observed workflow/job')

def read(relative):
    path = root / relative
    if not path.is_file():
        errors.append('Missing raw artifact: ' + relative)
        return {}
    payload = path.read_bytes()
    raw.append({'path': str(path), 'sha256': hashlib.sha256(payload).hexdigest(), 'bytes': len(payload)})
    return json.loads(payload)

def canonical(name):
    for prefix in ['apps/', 'packages/']:
        marker = '/' + prefix
        if marker in name:
            return prefix + name.split(marker, 1)[1]
    return name

def exact_keys(rows, key, expected, label):
    actual = [key(row) for row in rows]
    check(len(actual) == len(expected) and collections.Counter(actual) == collections.Counter(expected), label + ': incomplete/duplicate/unexpected inventory')

def source(identity, label, required=('sourceSha',), inventory=None):
    check(all(key in identity for key in required), label + ': required source identity field missing')
    check(identity.get('sourceSha', identity.get('head')) == head, label + ': wrong executed SHA')
    if 'sourceTree' in identity or 'tree' in identity:
        check(identity.get('sourceTree', identity.get('tree')) == tree, label + ': wrong tree')
    if 'trackedDiff' in identity:
        check(identity['trackedDiff'] == '', label + ': tracked edits present')
    if 'head' in identity and 'status' in identity:
        check(identity['status'] == '', label + ': dirty source status')
    if 'patchSha256' in identity:
        check(identity['patchSha256'] == hashlib.sha256(b'').hexdigest(), label + ': nonempty patch')
    if inventory is not None:
        actual = identity.get(inventory['field'], {})
        check(isinstance(actual, dict) and set(actual) == set(inventory['paths']), label + ': source hash inventory missing/changed')
    for name, digest in identity.get('hashes', identity.get('selectedSourceHashes', {})).items():
        check(plan['sourceFiles'].get(name) == digest, label + ': source file mismatch: ' + name)

def inspect_vitest(kind):
    report = read(kind + '/vitest.json')
    expected = plan['files'][kind]
    check(report.get('success') is True, kind + ': Vitest unsuccessful')
    for field in ['numFailedTests', 'numFailedTestSuites', 'numPendingTests', 'numTodoTests', 'numPendingTestSuites']:
        check(report.get(field) == 0, kind + ': nonzero/missing ' + field)
    if 'numRuntimeErrorTestSuites' in report:
        check(report['numRuntimeErrorTestSuites'] == 0, kind + ': runtime errors')
    check(report.get('numTotalTests') == plan['totalAssertions'][kind], kind + ': total assertion count changed')
    check(report.get('numPassedTests') == plan['totalAssertions'][kind], kind + ': not every assertion passed')
    files = report.get('testResults', [])
    exact_keys(files, lambda entry: canonical(entry['name']), list(expected), kind + ' files')
    summary = []
    for entry in files:
        name = canonical(entry['name'])
        assertions = entry.get('assertionResults', [])
        check(entry.get('status') == 'passed', name + ': file not passed')
        check(all(row.get('status') == 'passed' and not row.get('failureMessages') for row in assertions), name + ': nonpassing assertion')
        frozen = expected.get(name)
        if frozen:
            check(len(assertions) == frozen['count'], name + ': assertion count changed')
            if 'originalTitleOccurrences' in frozen:
                check(dict(collections.Counter(row['fullName'] for row in assertions)) == frozen['originalTitleOccurrences'], name + ': original assertion identities changed')
        summary.append({'file': name, 'count': len(assertions), 'passed': sum(row.get('status') == 'passed' for row in assertions)})
    return {'files': summary, 'totalAssertions': report.get('numTotalTests'), 'passedAssertions': report.get('numPassedTests')}

def input_sequence(native, emitted, label):
    check(len(native) == len(emitted), label + ': input/request count differs')
    for index, (event, request) in enumerate(zip(native, emitted)):
        check(event.get('isTrusted') is True and event.get('type') == 'input', label + ': untrusted/non-input event')
        expected = {'value': event.get('value'), 'composing': event.get('composing'), 'data': event.get('data'), 'inputType': event.get('inputType')}
        check(request.get('detail') == expected, label + ': native detail/order mismatch at ' + str(index))

def composition_sequence(events, kind, initial, label):
    check(len(events) >= 3, label + ': lifecycle missing')
    if len(events) < 3:
        return
    check(len({event.get('objectId') for event in events}) == len(events), label + ': reused native event object')
    check(events[0].get('type') == 'compositionstart' and events[0].get('value') == initial, label + ': initial event/value')
    check(events[-1].get('type') == 'compositionend' and events[-1].get('value') == '你好' and events[-1].get('data') == '你好', label + ': committed event/value/data')
    updates = events[1:-1]
    unique_candidates = [event.get('data') for index, event in enumerate(updates) if index == 0 or event.get('data') != updates[index - 1].get('data')]
    check(unique_candidates == ['ni', '你好'], label + ': candidate sequence')
    previous = initial
    for event in updates:
        check(event.get('type') == 'compositionupdate' and event.get('value') == previous, label + ': update ordering')
        previous = event.get('data')
    for event in events:
        expected = {'constructorName': 'CompositionEvent', 'isCompositionEvent': True,
                    'targetTag': kind.upper(), 'targetIsEditor': True, 'originIsEditor': True,
                    'eventPhase': 2, 'isComposing': None,
                    'scriptDispatched': False, 'dispatchObserverActive': True}
        check(all(event.get(key) == value for key, value in expected.items()), label + ': native provenance/target/phase')
        check(type(event.get('isTrusted')) is bool, label + ': missing actual trust flag')
        if event.get('type') != 'compositionend':
            check(event.get('isTrusted') is True, label + ': untrusted start/update')

selection = read('material/selection.json')
check(selection.get('sourceSha') == head and str(selection.get('runId')) == run_id, 'selection: source/run mismatch')
selected = ['browser-evidence'] + [f'{kind} ({runtime})' for kind in ['prominent-tint-evidence', 'hover-evidence'] for runtime in plan['runtimes']] + ['tint-stage-diagnostic', 'visible-refraction-diagnostic']
check(selection.get('selection') == 'complete-workflow' and selection.get('selectedJobs') == selected, 'selection: full-workflow partition mismatch')
check(selection.get('notSelectedJobs') == [], 'selection: unexpected unselected partitions')
check(selection.get('workflowSha256') == plan['sourceFiles']['.github/workflows/liquid-material-evidence.yml'], 'selection: workflow source mismatch')
vitest = {kind: inspect_vitest(kind) for kind in ['material', 'state-controls']}
coverage = read('material/coverage.json')
check(coverage.get('scope') == plan['materialCoverage']['scope'] and coverage.get('file') == plan['materialCoverage']['file'], 'material: coverage scope/file mismatch')
exact_keys(coverage.get('cases', []), lambda row: row.get('title'), plan['materialCoverage']['titles'], 'material six-case coverage')
check(coverage.get('passed') is True and coverage.get('reportSuccessful') is True and coverage.get('fileOccurrences') == 1, 'material: required executed-case gate failed')
check(len(coverage.get('cases', [])) == 6 and all(row.get('passed') and row.get('occurrences') == 1 and row.get('statuses') == ['passed'] for row in coverage.get('cases', [])), 'material: six native material cases incomplete')

controls = read('state-controls/manifest.json')
source(controls, 'controls')
check(controls.get('expectedSha') == head and str(controls.get('runId')) == run_id, 'controls: expected SHA/run mismatch')
check(controls.get('status') == 'passed' and controls.get('stepStatus') == 'success', 'controls: suite/workflow terminal failed')
check(controls.get('expectedCases') == plan['stateControlCases'], 'controls: frozen31 names changed')
check(controls.get('runtimes') == plan['runtimes'] and controls.get('parts') == plan['parts'], 'controls: host/part inventory changed')
terminal = controls.get('terminal', {})
check(terminal.get('status') == 'passed', 'controls: terminal not passed')
check(all(not terminal.get(key) for key in ['missing', 'duplicates', 'unexpected', 'failures']), 'controls: incomplete/error terminal')
check(not controls.get('pageErrors') and not controls.get('startupError'), 'controls: native startup/page error')
results = controls.get('results', [])
exact_keys(results, lambda row: row.get('name'), plan['stateControlCases'], 'controls31')
check(all(row.get('status') == 'pass' and not row.get('errors') for row in results), 'controls: failed executed case')
observations = controls.get('observations', [])
check(not any(row.get('caseCleanupError') for row in observations), 'controls: case cleanup failure')
plain = [row for row in observations if row.get('stage') == 'independent-native-composition-control']
components = [row for row in observations if 'nativeComposition' in row and 'controlled' in row]
key = lambda row: (row.get('runtime'), row.get('ref'))
expected_keys = [key(row) for row in plan['compositionControls']]
exact_keys(plain, key, expected_keys, 'plain native controls16')
exact_keys(components, key, expected_keys, 'component composition16')
plain_by_key = {key(row): row for row in plain}
component_by_key = {key(row): row for row in components}
composition_summary = []
for expected in plan['compositionControls']:
    cell = key(expected)
    label = '/'.join(cell)
    control = plain_by_key.get(cell, {})
    component = component_by_key.get(cell, {})
    if not control or not component:
        continue
    composition_sequence(control.get('composition', []), expected['kind'], control.get('initial'), label + '/plain')
    composition_sequence(component.get('nativeComposition', []), expected['kind'], control.get('initial'), label + '/component')
    check(component.get('nativeComposition') == control.get('composition'), label + ': native composition differs from independent control')
    check(component.get('nativeInputs') == control.get('inputs'), label + ': native inputs differ from independent control')
    check(component.get('controlled') is expected['controlled'], label + ': owner mode mismatch')
    check([event.get('value') for event in control.get('inputs', [])] == ['ni', '你好', '你好'], label + ': plain native input values')
    check(all(event.get('isTrusted') is True and event.get('type') == 'input' for event in control.get('inputs', [])), label + ': plain native input trust')
    check(not control.get('cleanupErrors'), label + ': native control cleanup error')
    synthetic = control.get('syntheticEnd', {})
    check(control.get('syntheticEndRejected') is True, label + ': actual script-end negative did not reject')
    check(synthetic.get('scriptDispatched') is True and synthetic.get('isTrusted') is False and synthetic.get('type') == 'compositionend' and synthetic.get('dispatchObserverActive') is True, label + ': script-end attribution missing')
    check(synthetic.get('objectId') not in {event.get('objectId') for event in control.get('composition', [])}, label + ': script end reused native object')
    input_sequence(component.get('nativeInputs', []), component.get('valueChange', []), label)
    ends = [event for event in component.get('nativeComposition', []) if event.get('type') == 'compositionend']
    check([event.get('detail') for event in component.get('compositionEnd', [])] == [{'value': event.get('value'), 'data': event.get('data')} for event in ends], label + ': exposed composition end differs')
    screenshot = f'{cell[0]}-{cell[1]}-composition.png'
    check(screenshot in controls.get('screenshots', []), label + ': post-owner/identity assertion capture missing')
    composition_summary.append({'runtime': cell[0], 'ref': cell[1], 'controlled': expected['controlled'],
                                'nativeInputCount': len(control.get('inputs', [])), 'compositionEventCount': len(control.get('composition', [])),
                                'actualNativeEndTrusted': control['composition'][-1].get('isTrusted') if control.get('composition') else None,
                                'scriptEndRejected': control.get('syntheticEndRejected'), 'postOwnerIdentityCapture': screenshot})
acceptance = [row for row in observations if row.get('stage') == 'controlled-owner-acceptance']
acceptance_keys = [(runtime, kind + 'Controlled') for runtime in plan['runtimes'] for kind in ['input', 'textarea']]
exact_keys(acceptance, key, acceptance_keys, 'ordinary controlled owner acceptance8')
for row in acceptance:
    input_sequence(row.get('nativeInputs', []), row.get('valueChangeRequests', []), '/'.join(key(row)) + '/acceptance')
    check(len(row.get('nativeInputs', [])) == 1 and row['nativeInputs'][0].get('value') == 'Requested', '/'.join(key(row)) + ': owner changed original request trace')
for stage, refs in [('initial-editor-fill-before-count-assertion', ['input', 'textarea']), ('multiline-native-sequence', ['textarea'])]:
    entries = [row for row in observations if row.get('stage') == stage]
    exact_keys(entries, key, [(runtime, ref) for runtime in plan['runtimes'] for ref in refs], stage)
    for row in entries:
        input_sequence(row.get('nativeInputs', []), row.get('valueChangeRequests', []), '/'.join(key(row)) + '/' + stage)
        native = row.get('nativeInputs', [])
        if stage == 'initial-editor-fill-before-count-assertion':
            check(len(native) == 1 and native[0].get('value') == 'Changed', '/'.join(key(row)) + ': first fill is not the required single native input')
        else:
            check(len(native) > 1 and native[-1].get('value') == 'Changed\nSecond line', '/'.join(key(row)) + ': multiline native sequence missing')
screenshots = controls.get('screenshots', [])
check(len(screenshots) == len(set(screenshots)), 'controls: duplicate screenshot identities')
check(all((root / 'state-controls' / name).is_file() for name in screenshots), 'controls: declared screenshot missing')

portal = read('material/portal/docs-shell-containment-handover.json')
source(portal, 'portal', required=('sourceSha', 'sourceTree', 'trackedDiff', 'sourceFiles', 'report'))
exact_keys(portal.get('sourceFiles', []), lambda row: row.get('file'), plan['portalSourceFiles'], 'portal source closure')
for entry in portal.get('sourceFiles', []):
    check(plan['sourceFiles'].get(entry['file']) == entry['sha256'], 'portal: source file mismatch: ' + entry['file'])
portal_report = portal.get('report', {})
check(not portal_report.get('error'), 'portal: diagnostic failed')
exact_keys(portal_report.get('sources', []), lambda row: row.get('file'), plan['portalStylesheetSources'], 'portal actual stylesheet closure')
for entry in portal_report.get('sources', []):
    check(hashlib.sha256(entry['text'].encode()).hexdigest() == entry['sha256'] == plan['sourceFiles'].get(entry['file']), 'portal: actual stylesheet source mismatch')
portal_cases = portal_report.get('cases', [])
exact_keys(portal_cases, lambda row: row.get('control', {}).get('name'), plan['portalControls'], 'portal9')
portal_summary = []
for row in portal_cases:
    name = row['control']['name']
    check(not row.get('error') and not row.get('inaccessibleSheets'), name + ': portal collection error')
    baseline, handover = row.get('baseline', []), row.get('handover', [])
    check(len(baseline) == 3 and len(handover) == 6, name + ': portal frame inventory')
    check(row.get('baselineStability', {}).get('stable') is True, name + ': baseline unstable')
    check(4 <= len(row.get('settling', [])) <= 12, name + ': settling was not bounded')
    check(row.get('restored') == {'rootStyle': row.get('originals', {}).get('rootStyle'), 'shellStyle': row.get('originals', {}).get('shellStyle'), 'injectedStylePresent': False}, name + ': test-owned styles not restored')
    if not baseline:
        continue
    last = baseline[-1]
    check(last.get('css', {}).get('containerType') == 'inline-size', name + ': original containment missing')
    def geometry_delta(a, b):
        return max([abs(a['contentWidth'] - b['contentWidth'])] + [abs(a[box][field] - b[box][field]) for box in ['shell', 'columns', 'toc', 'main'] for field in ['left', 'top', 'width', 'height']])
    check(all(sample['predicate'] == last['predicate'] and geometry_delta(sample, last) <= 1 for sample in baseline), name + ': original baseline tolerance violated')
    if last['predicate']:
        check(last['css']['columnsDisplay'] == 'grid' and len(last['css']['columnsGrid'].split()) == 1 and last['css']['tocDisplay'] == 'none', name + ': wrong actual collapsed product branch')
    if name.startswith('media-'):
        check(last['mediaMatches'] is (name != 'media-below'), name + ': media-edge observation mismatch')
    content_deltas, geometry_deltas = [], []
    for entry in handover[-3:]:
        after = entry['after']
        check(after['css']['containerType'] == 'normal' and entry['appliedPredicate'] == after['predicate'] == last['predicate'], name + ': handover predicate/containment mismatch')
        content_delta = abs(after['contentWidth'] - last['contentWidth'])
        delta = geometry_delta(after, last)
        check(content_delta <= 0.5 and delta <= 1, name + ': original handover tolerance violated')
        content_deltas.append(content_delta); geometry_deltas.append(delta)
    calibration = row.get('boundaryCalibration')
    if name.startswith('boundary-'):
        edge = row['control']['edge']
        check(calibration is not None and calibration.get('calibrated') is True, name + ': actual boundary not calibrated')
        samples = (calibration or {}).get('samples', [])
        check(1 <= len(samples) <= 8, name + ': calibration unbounded/missing')
        for sample in samples:
            check(sample['viewportWidth'] == sample['requestedWidth'] and isinstance(sample['viewportWidth'], int), name + ': requested viewport not observed')
            check(math.isclose(sample['error'], sample['contentWidth'] - sample['threshold'] - edge, rel_tol=0, abs_tol=1e-12), name + ': calibration error attribution')
        check(bool(samples) and abs(samples[-1]['error']) < 0.5, name + ': strict <0.5 calibration gate failed')
        check(abs(last['contentWidth'] - last['threshold'] - edge) < 0.5, name + ': strict original actual boundary assertion failed')
        check(last['predicate'] is (edge != 1), name + ': below/at/above branch mismatch')
    portal_summary.append({'name': name, 'baselineFrames': len(baseline), 'handoverFrames': len(handover),
                           'maxFinalContentDelta': max(content_deltas, default=None), 'maxFinalGeometryDelta': max(geometry_deltas, default=None),
                           'boundaryCalibration': calibration})

lifecycle = {}
for name, inventory, key_name in [('release-lifecycle', plan['releaseCases'], 'cases'), ('theme-ownership', plan['themeCheckpoints'], 'checkpoints')]:
    report = read('material/' + name + '/report.json')
    hash_inventory = plan['sourceIdentityHashInventories'][name]
    for stage in ['Start', 'End']:
        source(report.get('sourceAt' + stage, {}), name + '/' + stage.lower(),
               required=('head', 'tree', 'status', hash_inventory['field']), inventory=hash_inventory)
    check(report.get('sourceStable') is True and report.get('sourceAtStart') == report.get('sourceAtEnd'), name + ': source changed during execution')
    check(not report.get('failures') and not report.get('pageErrors'), name + ': native failures/page errors')
    exact_keys(report.get(key_name, []), lambda row: row.get('name'), inventory, name)
    lifecycle[name] = {'entries': len(report.get(key_name, [])), 'sourceStable': report.get('sourceStable'), 'failures': report.get('failures'), 'pageErrors': report.get('pageErrors')}
for relative, required in [('material/metadata.json', ('sourceSha',)),
                           ('material/portal/metadata.json', ('sourceSha', 'sourceTree', 'trackedDiff')),
                           ('material/toggle/results.json', ('sourceSha', 'sourceTree', 'patchSha256'))]:
    source(read(relative), relative, required=required)

material_metadata = read('material/metadata.json')
dpr_observations = [row for row in material_metadata.get('observations', []) if row.get('kind') == 'dpr-source-raster']
exact_keys(dpr_observations, lambda row: row.get('phase'), [row['phase'] for row in plan['dprRasterPhases']], 'DPR six same-poll raster phases')
dpr_by_phase = {row.get('phase'): row for row in dpr_observations}
dpr_summary = []
previous_by_theme = {}
for expected in plan['dprRasterPhases']:
    phase, theme = expected['phase'], expected['theme']
    row = dpr_by_phase.get(phase)
    if row is None:
        dpr_summary.append({'phase': phase, 'status': 'not-recorded', 'expectedDpr': expected['dpr']})
        continue
    snapshot = row.get('snapshot', {})
    check(row.get('expectedDpr') == snapshot.get('devicePixelRatio') == expected['dpr'], phase + ': actual/requested DPR mismatch')
    timestamp = snapshot.get('observedAtMs')
    check(isinstance(timestamp, (int, float)) and math.isfinite(timestamp) and timestamp >= 0, phase + ': invalid same-poll observation time')
    runtimes = snapshot.get('runtimes', [])
    exact_keys(runtimes, lambda item: item.get('runtime'), plan['runtimes'], phase + ': raster runtime inventory')
    previous = previous_by_theme.get(theme)
    check(row.get('previousRevisions') == previous, phase + ': previous revision binding mismatch')
    revisions = {}
    for item in runtimes:
        runtime = item.get('runtime')
        label = phase + '/' + str(runtime)
        check(all(item.get(key) == 1 for key in ['rootCount', 'regularCount', 'canvasCount']), label + ': root/host/canvas not unique')
        check(item.get('connected') is True and item.get('quality') == 'self-optical' and item.get('source') == 'visible-app-canvas', label + ': source/quality/connection mismatch')
        revision = item.get('sourceRevision')
        check(type(revision) is int and 0 < revision <= 9007199254740991, label + ': invalid committed source revision')
        if previous is not None:
            check(type(revision) is int and type(previous.get(runtime)) is int and revision > previous[runtime], label + ': committed source revision did not advance')
        revisions[runtime] = revision
        geometry = item.get('geometry') or {}
        for axis in ['width', 'height']:
            css = geometry.get(axis)
            valid = isinstance(css, (int, float)) and math.isfinite(css) and css > 0
            check(valid, label + ': invalid CSS ' + axis)
            if valid:
                check(item.get(axis) == math.ceil(css * expected['dpr']), label + ': stale physical source ' + axis)
    previous_by_theme[theme] = revisions
    dpr_summary.append({'phase': phase, 'status': 'recorded', 'expectedDpr': expected['dpr'], 'snapshot': snapshot, 'previousRevisions': row.get('previousRevisions')})
dpr_failures = []
for timeout_path in sorted((root / 'material').glob('quality-timeout-*.json')):
    diagnostic = read(str(timeout_path.relative_to(root)))
    source(diagnostic, timeout_path.name, required=('sourceSha', 'sourceTree'))
    check(diagnostic.get('timeoutMs') == 20000, timeout_path.name + ': original timeout changed')
    dpr_failures.append({'path': str(timeout_path.relative_to(root)), 'rasterExpectation': diagnostic.get('rasterExpectation'), 'originalError': diagnostic.get('originalError'), 'nativeSnapshot': diagnostic.get('nativeSnapshot')})

indexed = []
for directory in ['material', 'state-controls']:
    for path in sorted((root / directory).rglob('*')):
        if path.is_file():
            payload = path.read_bytes()
            indexed.append({'path': str(path.relative_to(root)), 'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()})
index_path = root / 'main-artifact-file-index.json'
index_path.write_text(json.dumps({'head': head, 'runId': run_id, 'files': indexed}, indent=2) + '\n')
check(job_conclusion == 'success', 'GitHub browser-evidence job did not succeed')
report = {
    'runId': run_id, 'jobId': job_id, 'jobConclusion': job_conclusion,
    'executedSha': head, 'tree': tree, 'status': 'passed-readback' if not errors else 'failed-or-incomplete-readback',
    'readbackErrors': errors, 'vitest': vitest, 'materialExecutedCaseGate': coverage,
    'nativeStateControlCases': len(results), 'compositionControls': composition_summary,
    'ordinaryControlledAcceptanceCount': len(acceptance), 'stateControlScreenshots': len(screenshots),
    'portal': portal_summary, 'lifecycle': lifecycle, 'raw': raw,
    'artifactFileIndex': {'path': str(index_path), 'sha256': hashlib.sha256(index_path.read_bytes()).hexdigest(), 'files': len(indexed)},
    'plan': {'path': str(plan_path), 'sha256': hashlib.sha256(plan_path.read_bytes()).hexdigest()},
    'fullWorkflowSelection': selection,
    'dprRaster': {'expectedPhases': 6, 'recordedPhases': len(dpr_observations), 'phases': dpr_summary, 'failureDiagnostics': dpr_failures},
    'visuallyInspected': [],
    'limits': 'Main material/library and eight-part controls only. The other ten selected workflow jobs have independent raw-artifact readbacks at this same source; their job success cannot erase a main-suite failure. Native composition is CDP, not physical OS IME. No physical120Hz/10ms, Apple or whole-family/non-Web/Compiler acceptance follows from these results.',
}
path = root / 'main-material-readback.json'
path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'report': str(path), 'status': report['status'], 'errors': errors,
                  'totalAssertions': {key: value['totalAssertions'] for key, value in vitest.items()},
                  'nativeStateControlCases': len(results), 'compositionControls': len(composition_summary),
                  'portalCases': len(portal_summary), 'indexedFiles': len(indexed)}, ensure_ascii=False))
sys.exit(1 if errors else 0)
