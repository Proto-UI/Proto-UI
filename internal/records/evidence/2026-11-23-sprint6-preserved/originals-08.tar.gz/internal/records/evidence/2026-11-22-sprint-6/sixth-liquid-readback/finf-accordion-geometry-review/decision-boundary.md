# Liquid Accordion: native failure, source delta, and implementation boundary

This is a read-only investigation of the actual Finf disclosure failure. No product, test, definition, source budget, threshold or public API was changed in this investigation. It is not an acceptance of the Accordion optical path, an implementation authorization for a new reservation API, or proof that the native failure is inherited from the Sprint 6 baseline.

## Original native result

- Candidate: `7871a8da3967ae4bb29cd50c655860cf87d374c0`, tree `1a08b265b1062dd2a44ccf9c2fcaa8bc1aaa9bdb`.
- [Full CI run 45030540222](https://github.com/Proto-UI/Proto-UI/actions/runs/45030540222), [Finf disclosure job 137238435748](https://github.com/Proto-UI/Proto-UI/actions/runs/45030540222/job/137238435748).
- Artifact 14758677229: [original Actions artifact](https://github.com/Proto-UI/Proto-UI/actions/runs/45030540222/artifacts/14758677229). ZIP SHA-256 `6d31f398d384dc3d039b9ba5686cca9e128ad2da30cd90dfcf2980f07f48a176`; 4,515,185 bytes. ZIP digest, byte count, CRC, unique members and safe extraction paths were checked.
- Eight planned case receipts: seven pass, Liquid Accordion fails. Forty-three case screenshot hashes were verified. The original `rest` and `failed-previewer` PNGs were actually viewed and have identical bytes.
- Route `/en/ui-libraries/liquid-glass/accordion/`; the real family Runtime Select chose React. Viewport 1365 × 1000; actual DPR 1; light theme; fixed host clock `2026-10-10T12:00:00.000Z`. The receipt has no page errors, capture errors or blocked requests.
- Failure remains the original `expect.poll(...material-quality).toBe('self-optical')` at the 1000 ms limit, immediately after `capture('rest')`. Later painted-Item rejection/recovery, open/close/reopen and controlled owner acceptance were not reached by this case.

The formal original readback is `../ci45030540222-finf-disclosure/readback-and-cause.json`, SHA-256 `9bc9023c9c15e4f28ad019e7033514371a46b27a1139cb7d28792192aeb0b270`. Raw files are retained under `../ci45030540222-finf-disclosure/artifact/` and the original ZIP is retained beside it. These relative paths identify local evidence; the Actions links above are the external artifact/job locations, subject to retention.

## What the native observations prove

The failing trigger reports `opaque-fallback / source-overlapping-content` in the `rest`, `failed` and `failed-previewer` observations. Its source canvas is connected, in the same scope, 512 × 1250 physical pixels, with a 512 × 1250 CSS rectangle at actual DPR 1. This is not the stale-DPR diagnostic reported by the separate material/frame jobs.

The target `single-lifetime-trigger` has rectangle `(364.5, 331.5, 428, 50)`. Its authored candidate includes `deformation.contact = pointer` at rest and pressed. The unchanged sink uses the full supported contact interval, `ceil(max(width, height) × 0.08 + 1)`, which is 36 CSS pixels here. Its complete paint rectangle is therefore left 328.5, top 295.5, right 828.5, bottom 417.5.

The preceding independent sibling `single-overview-item` has rectangle `(363.5, 90.5, 430, 232)`, ending at y=322.5. That rectangle overlaps the complete target footprint by 430 × 27 CSS pixels. The recorded DOM and family definition show a real Item border and opaque open Content; this includes 26 pixels of Content and one pixel of Item border. It is not an unpainted empty wrapper that can safely be ignored. The original source overlap guard correctly rejects the source. The nested overview trigger independently retains the intended `source-painted-ancestor` fallback.

All material observations were taken after screenshots. The record does not establish pre-screenshot material state or the exact notification timeline. No DPR change is authored in this Accordion journey. These observations must not be used to claim either that screenshot capture caused this failure or that the separate DPR race caused it.

## Actual route and source comparison

The comparison is the exact Sprint 6 baseline `dc3b184ba10b0de53e40359c52d012b204b2cd01` against candidate `7871a8da3967ae4bb29cd50c655860cf87d374c0`. `reached-source-delta.json` records a selected 100-file inventory, per-revision byte counts, SHA-256, Git blob IDs and immutable GitHub URLs, plus directory tree identities and unchanged producer code segments. This is an audited selected inventory, not a claim to have resolved every transitive dependency. `reached-source-delta.patch` preserves every changed file in that inventory.

The reached path is:

1. The unchanged Finf disclosure workflow and browser harness run the unchanged representative test, which loads the English public MDX page and selects React through the actual toolbar.
2. `PrototypePreviewer.astro` resolves the exact `demo-liquid-glass-accordion` entry in `projection-families.ts`. The projected previewer materializer loads the unchanged shared recipe and composes the selected Liquid family.
3. `prototype-modules.ts` loads the package's public Accordion source export. The unchanged React Adapter projects the five Liquid atoms and their Base Accordion semantics.
4. The unchanged `renderDemo` automatic-material condition detects the Liquid subtree, finds no preexisting provider and creates the preview scene. This reaches `preview-material-scene.ts` and its actual in-app canvas; it is not a test-only substituted provider.
5. The preview material provider supplies the same shared material sink. `inspectCanvasBackdrop` evaluates the full contact footprint before any optical image preparation/render. The rejected source reaches the existing opaque fallback branch.
6. Normal website startup generates the document stylesheet from the union of package prototypes and website prototypes, then loads it through the normal global CSS entries. There is no independent generated compiler component in this React Adapter case. Generated CSS is still part of the actual consumer input.

| Layer | Base → candidate finding | Consequence |
| --- | --- | --- |
| Original Finf test, capture helper, both language MDX routes and shared Accordion recipe | Exact bytes unchanged | The candidate did not strengthen or move this particular 1000 ms assertion or rearrange this recipe. This is not proof of the baseline's native outcome. |
| Base Accordion directory, all Liquid source, React Adapter source, Core and Feedback module | Exact Git directory trees unchanged | The authored Root `gap-2`, bordered Item, opaque Content and pointer-contact Trigger have the same tracked definitions. |
| Sink, source guard, contact budget and carrier bounds | Exact bytes unchanged | The full contact envelope and foreign-overlap rejection were not introduced or weakened by Sprint 6. |
| Preview source's scope/canvas styles, flow/overlay min-height function and draw function | Exact code segments unchanged; segment hashes are in the inventory | The 32 rem source width, padding, visible source sizing and paint formulas have the same text. |
| Preview scene notifications | Changed | Canvas device-pixel ResizeObserver observation and next-frame media/resize scheduling changed. They are reached by this case; the whole producer cannot be described as unchanged. |
| Projection composition | Changed | Nested theme propagation now updates only renderer-owned entries. The composition is reached. No geometry property was added by this hunk, but source equality for the entire composition is not claimed. |
| Material preferences | Changed | Subscription ownership/rollback/disposal changed. The reported preference values remain explicit in the native observation. |
| Optical preparation/program and private tint profile | Changed | Byte-preserving prefilter/diagnostics and profile 6 are present. This Trigger has no `style-fill` tint request; the observed source rejection returns before image preparation/render, so successful tint lanes do not accept this Accordion case. |
| Stylesheet compiler and global token input | Changed | CLI added background-position transition, its reduced-motion handling and literal `ring-white`; Bootstrap Button/Surface changed their token sets. The Accordion geometry token definitions were not changed by these hunks, but complete generated CSS equality was not measured. |
| Shared document controls/styles | Changed | Header/search/link recipe updates are retained in the comparison. The site-header geometry changes select Bootstrap explicitly; they are not an Accordion spacing patch. No claim is made that the entire document input is identical. |

The canonical stylesheet entry and source collector are unchanged, but the compiler and the union's Bootstrap inputs are changed. The Finf artifact does not contain `proto-ui-tokens.generated.css`, its Shadow companion or `shadcn-theme.css`. No generator was run for this read-only investigation. It would be incorrect to turn the unchanged Accordion token strings into a claim that the full emitted CSS is byte-identical.

The candidate's source geometry and conservative overlap rejection are proven. Whether the baseline exhibits the same native layout and terminal failure remains pending the parent's exact-baseline execution. The baseline comparison should retain its own exact head/tree, workflow selection, browser/font environment, generated styles if available, React/runtime selection, original 1000 ms assertion, canvas/raster rectangles and post-capture material reason. A passing baseline would require further investigation; an unchanged source substring alone cannot override it.

## Contract boundary

`C-MATERIAL-PAINT-FOOTPRINT-0001` and `T-MATERIAL-PAINT-FOOTPRINT-0001` are explicitly draft. Their lifecycle rationale says host association/reservation syntax and native proof have not been implemented. The unresolved `Q-SYNTAX` asks which explicit target/reservation-part declaration realizes the responsibilities. The original definition record is `internal/records/2026-10-30-material-paint-footprint-definition.md`.

The draft requires host-local, generation-bound four-edge facts for the full supported material interval. A reservation must explicitly identify one target and a separate dedicated part in the same owned composition. It cannot search arbitrary ancestors, change consumer padding or the target's border box/input/focus identity, hide foreign blockers, reduce the contact budget, treat unavailable facts as zero, or introduce an idle frame polling loop. Full source bounds, foreign overlap, clipping, freshness and preference safety remain mandatory.

The Accordion definitions separately require Base ownership, a genuinely bordered Item, ordinary opaque Content, shrink/wrap behavior and a pointer-contact Trigger. No already-implemented public reservation API was found in the Core, Adapter or family source. The existing pure `contactPaintOutset` helper is a renderer profile budget, not a portable layout API.

## Two unselected implementation options

| Option | Responsibility and independent definition needed | Required distinguishing proof |
| --- | --- | --- |
| Bounded family presentation | Define supported family geometry and spacing independently, including Trigger/Content separation and the Root's outer neighbors. It must preserve normal flow, focus/input identity, real Item border and opaque Content. Portable prototypes cannot compute host contact coordinates or infer the private profile's pixels. | Same original public route and failure oracle; four Web hosts; narrow layout, 200% text, RTL, open/reopen, adjacent captions/Roots and source-budget limits. Show that the prior presentation fails the original overlap requirement and the selected presentation really reserves the full footprint. A single larger Root gap is insufficient. |
| Explicit generic reservation | Resolve the draft public declaration/host handoff first, then implement one bounded host lease for an explicit target and independently owned reservation part. Preserve revocation, reentry, geometry-generation and owned-cleanup boundaries. | Original geometric blocker plus independent full-interval facts, same-node replacement, missing/invalid geometry, pause/dispose, source loss, unavailable fallback, read/write batching, no polling, and four-host native layout/optical/a11y evidence. This is a separate capability slice, not an existing API that can be assumed. |

No option has been selected or implemented here. Increasing only Root gap cannot clear the Trigger's own adjacent open Content or outside captions. Large fixed gaps also increase the current 1250 px source height; the existing 2048 dimension / 1,048,576 pixel source limits remain in force. No claim is made that a chosen enlarged layout fits those limits, because none was authored or run.

## Current disposition

Keep the Finf case failed and the source-overlap fallback truthful. Do not reinterpret the seven other passing cases, the standalone Button optical lanes, or the source comparison as acceptance of this Accordion path. The parent owns the exact-baseline native comparison and any source-authority decision for the two options. No smaller established responsibility correction was found: the observed blocker has real paint, the contact interval is deliberately complete, and the existing producer does not own the Accordion's inner or outer spacing.
