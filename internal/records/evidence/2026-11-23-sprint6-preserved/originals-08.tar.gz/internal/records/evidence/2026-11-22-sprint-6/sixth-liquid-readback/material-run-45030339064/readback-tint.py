from pathlib import Path
import collections
import hashlib
import json
import sys

runtime, job_id, conclusion = sys.argv[1], int(sys.argv[2]), sys.argv[3]
root = Path('/workspace/scratch/cd1b397ad8e7/liquid-work/material-run-45030339064')
directory = root / ('tint-' + runtime) / 'prominent-tint'
expectations = json.loads(Path('/workspace/scratch/cd1b397ad8e7/liquid-work/tint6-native-expectations.json').read_text())
plan = [entry for entry in expectations['caseRecords'] if entry['runtime'] == runtime]
case_ids = {entry['case'] for entry in plan}
capture_ids = {capture for entry in plan for capture in entry['captures']}
results = json.loads((directory / 'results.json').read_text())
checkpoint = json.loads((directory / 'coverage-checkpoint.json').read_text())
sha = '7871a8da3967ae4bb29cd50c655860cf87d374c0'
tree = '1a08b265b1062dd2a44ccf9c2fcaa8bc1aaa9bdb'
empty = hashlib.sha256(b'').hexdigest()
errors = []

def check(ok, message):
    if not ok:
        errors.append(message)

def source(value, name):
    check(value.get('sha') == sha and value.get('tree') == tree and value.get('patchSha256') == empty, name + ': source binding')

for name, value in [('results', results), ('checkpoint', checkpoint)]:
    source(value, name)
    check(value.get('terminal', {}).get('status') == 'completed', name + ': terminal incomplete')
check(set(results['coverage']) == case_ids, 'case identities differ')
check(set(results['captureCoverage']) == capture_ids, 'capture identities differ')
check(all(v.get('status') == 'completed' and not v.get('error') for v in results['coverage'].values()), 'case failures')
check(all(v.get('status') == 'passed-observation-checks' and not v.get('error') for v in results['captureCoverage'].values()), 'capture failures')
check(checkpoint.get('phase') == 'terminal' and checkpoint.get('partial') is False and checkpoint.get('expectedCases') == 14 and checkpoint.get('expectedCaptures') == 422, 'checkpoint scope')
check(not results.get('nativeErrors') and not results.get('cleanupErrors'), 'page/cleanup errors')
profiles = collections.Counter()
contrasts, fallback = [], []
verified = 0
for name in sorted(capture_ids):
    path = directory / (name + '.json')
    if not path.is_file():
        errors.append(name + ': missing record')
        continue
    record = json.loads(path.read_text())
    source(record, name)
    check(record.get('binding') is True and record.get('screenshotBinding') is True and record.get('readinessError') is None, name + ': binding/readiness')
    snapshot = record['snapshot']
    profile = snapshot.get('receipt', {}).get('profile')
    profiles[str(profile)] += 1
    check(profile not in ['pui-regular-style-tint-5', 'pui-regular-style-tint-contact-5'], name + ': stale live profile')
    contrast = ((snapshot.get('pixels') or {}).get('content') or {}).get('minForegroundContrast')
    if contrast is not None:
        contrasts.append(contrast)
        check(contrast >= 4.5, name + ': foreground contrast')
    contrast = snapshot.get('fallbackContrast')
    if contrast is not None:
        fallback.append(contrast)
    png = directory / (name + '-subject.png')
    context = directory / (name + '-context.png')
    check(png.is_file() and context.is_file(), name + ': missing screenshot')
    if png.is_file():
        check(hashlib.sha256(png.read_bytes()).hexdigest() == record.get('subjectPngSha256'), name + ': PNG digest')
        verified += 1
pairs, constants = [], []
for row in results['results']:
    if 'classification' in row:
        tinted = row['controls']['tinted']
        pairs.append({'case': row['name'], 'source': row['source'], 'classification': row['classification'], 'tintedStatus': tinted['status'], 'tintedFailures': tinted['failures'], 'outputSpans': [frame['outputLumaSpan'] for frame in tinted['frames']], 'deltaRms': tinted['pair']['outputDeltaRms'], 'changedFraction': tinted['pair']['changedCellFraction']})
    elif 'fields' in row:
        constants.append({'case': row['name'], 'fields': row['fields']})
report = {
    'runtime': runtime, 'runId': 45030339064, 'jobId': job_id,
    'jobConclusion': conclusion, 'sha': sha, 'tree': tree,
    'cleanPatch': results['patchSha256'] == empty,
    'cases': len(case_ids), 'captures': len(capture_ids),
    'subjectPngHashesVerified': verified, 'readbackErrors': errors,
    'terminal': results['terminal'], 'opticalClassificationCounts': results['optical'],
    'profiles': dict(profiles),
    'minimumOpticalForegroundContrast': min(contrasts) if contrasts else None,
    'minimumFallbackContrast': min(fallback) if fallback else None,
    'pairs': pairs, 'constantSequences': constants, 'visuallyInspected': [],
    'scope': 'Case/capture execution and original/additive controls are interpreted separately from each optical classification. Inconclusive/diagnostic results remain. No Apple parity, physical120Hz/10ms or whole-family acceptance.'
}
(root / ('tint-' + runtime + '-readback.json')).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key not in ['pairs', 'constantSequences', 'visuallyInspected']}))

if errors:
    sys.exit(1)
