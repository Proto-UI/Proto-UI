# Eighth selected Liquid native evidence

Executed source: `b8ff9c1940723c5fd65c825c4c132628f27494d5`, tree `73e0b49cda1a5b5d22209ac3c6a949e12b4abb8a`.

Actual run: https://github.com/Proto-UI/Proto-UI/actions/runs/45040359902 . The selected `browser-evidence` job, https://github.com/Proto-UI/Proto-UI/actions/runs/45040359902/job/137263205931 , completed successfully. Its material and controls stages are two steps in one job. The GitHub API reports five jobs: one successful selected job and four skipped placeholders. `selection.json` lists ten logical unselected partitions; these were not ten separately executed/skipped matrix jobs.

The original material report has 33 files and 960/960 assertions. The original controls report has five files and 94/94 assertions, including all 31 native cases, 16 independent bare-editor comparisons, 16 actual script-dispatched composition-end negatives, and the original controlled rejection, explicit owner acceptance and editor identity assertions. Every selected assertion has a terminal result. The actual CDP composition-end trust flag is retained as false and matched to independent native controls; script-dispatched negatives are separately attributed and rejected. This is not physical OS IME evidence.

Both light and dark performed the original joint quality/raster/source-revision waits for DPR 1 → 2 → 1. Four source rasters changed 466×172 → 932×344 → 466×172 while retaining the same final CSS geometry, and every committed source revision advanced. The two same-session captures preserve all before/after DPR, viewport, geometry, revision and quality facts. Both metrics cleanup records are empty. This is a CDP metrics clear/set transaction, not evidence of a physical or pure-DPR-only monitor transition.

All nine portal cases retain the original strict boundary, baseline and handover limits. The 11 release cases and six theme checkpoints have stable exact-source identities and no native/page failures. The additional cleanup readback checks the actual live resource counters at immediate cleanup and two RAFs and preserves authored theme values after the renderer-owned stamp is retired.

`main-material-readback.json` is the successful strict offline readback, and `independent-native-readback.json` is the separate review of the original artifacts. `eighth-selected-readback.json` is the compact index. `visual-readback.json` records exactly five original PNGs actually viewed. The 83 source snapshot manifest binds exact Git blobs, raw SHA-256 and lossless gzip copies at the executed source.

## Original and retained evidence

The sibling `eighth-liquid-archive` contains all 265 original non-PNG artifact files, the complete decoded job log and 83 exact-source files as deterministic gzip copies, plus five selected original PNGs. Its index preserves every path, size and hash from all 1,316 ZIP members and the original API artifact digests. No raw artifact JSON was edited.

The other 1,046 PNGs are inventoried and linked to the original Actions artifacts, with their actual 30-day retention. They are not claimed to be permanently stored here. The complete ZIPs were downloaded and CRC/hash checked locally but are not included in Git. A full image-dependent reader replay requires restoring the original artifact PNGs; this selective archive alone does not recreate every original screenshot.

`readback-attempt-1-schema-mismatch` preserves the first offline-reader exit 1 and all original outputs. That reader incorrectly required an optional `cleanupErrors` field to exist on successful bare-control records. The actual test writes that field only when cleanup fails and then throws. The final reader accepts an omitted field or an actual empty array, rejects null/false/nonempty values, and retains all case/hook/terminal gates. The correction changed no raw artifact and did not rerun the native test. It is not a native product failure.

## Historical partitions and scope

The eight prominent/hover partitions were executed earlier at `7871a8da3967ae4bb29cd50c655860cf87d374c0`. The static reached-source review, exact standalone routes, finite runtime recovery map, style-generation roots, commands and independent review permit bounded reuse for b8. Their executed SHA remains 787. The original eight dark Button inconclusive classifications remain. The reuse does not cover the old main-suite failure, historical diagnostics, general CI or a later changed lockfile without a separate delta review.

These results do not close whole Sprint 6, Apple visual parity, physical 120 Hz/10 ms, physical OS IME, non-Web or Compiler conditions, or all 39 public pages. Original 787 DPR failures, Finf Accordion failures, optical insufficiencies and unmet performance targets are retained in their own evidence packages. Publishing this record at a later commit does not change the executed source.
