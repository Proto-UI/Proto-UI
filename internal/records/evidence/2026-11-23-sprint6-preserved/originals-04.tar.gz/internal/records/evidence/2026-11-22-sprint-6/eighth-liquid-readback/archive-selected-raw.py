"""Preserve original selected-run artifacts and exact Git sources losslessly. No test execution."""
from pathlib import Path
import json,gzip,hashlib,io,shutil
root=Path(__file__).parent
out=root.parent/'eighth-selected-publication/eighth-liquid-archive'
if out.exists():raise SystemExit('Refusing to replace a frozen original archive')
out.mkdir(parents=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def meta(p,relative=None):
 b=p.read_bytes();return {'path':str(relative or p),'bytes':len(b),'sha256':sha(b)}
items=[]
for dirname in ['material','state-controls']:
 for p in sorted((root/dirname).rglob('*')):
  if not p.is_file() or p.suffix=='.png':continue
  b=p.read_bytes()
  if p.suffix=='.json':json.loads(b)
  rel=p.relative_to(root).as_posix();target=out/'raw'/(rel+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
  buffer=io.BytesIO()
  with gzip.GzipFile(fileobj=buffer,mode='wb',filename='',mtime=0,compresslevel=6) as f:f.write(b)
  payload=buffer.getvalue();target.write_bytes(payload);assert gzip.decompress(payload)==b
  items.append({'role':'original native artifact file','original':meta(p,rel),'archived':meta(target,target.relative_to(out).as_posix()),'compression':{'format':'gzip','level':6,'mtime':0,'filenameHeader':''},'losslessDecompressionVerified':True})
for name in ['github-job.log']:
 p=root/name;b=p.read_bytes();buffer=io.BytesIO()
 with gzip.GzipFile(fileobj=buffer,mode='wb',filename='',mtime=0,compresslevel=6) as f:f.write(b)
 payload=buffer.getvalue();target=out/'raw'/(name+'.gz');target.write_bytes(payload);assert gzip.decompress(payload)==b
 items.append({'role':'original decoded complete GitHub job log','original':meta(p,name),'archived':meta(target,target.relative_to(out).as_posix()),'compression':{'format':'gzip','level':6,'mtime':0,'filenameHeader':''},'losslessDecompressionVerified':True})
images=json.loads((root/'visual-readback.json').read_text())['images']
for image in images:
 p=root/image['path'];target=out/'png'/image['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);assert target.read_bytes()==p.read_bytes()
 items.append({'role':'selected original PNG actually viewed','original':meta(p,image['path']),'archived':meta(target,target.relative_to(out).as_posix()),'byteEquivalentCopy':True})
source=json.loads((root/'source-snapshot-manifest.json').read_text())
for x in source['files']:
 p=root/x['gzipPath'];target=out/x['gzipPath'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);assert target.read_bytes()==p.read_bytes();assert sha(gzip.decompress(target.read_bytes()))==x['sha256']
 items.append({'role':'exact tested Git source snapshot','repositoryPath':x['repositoryPath'],'sourceUrl':x['sourceUrl'],'gitBlob':x['gitBlob'],'original':{'bytes':x['originalBytes'],'sha256':x['sha256']},'archived':meta(target,target.relative_to(out).as_posix()),'compression':source['compression'],'losslessDecompressionVerified':True})
proofs=[json.loads((root/(kind+'-download-proof.json')).read_text()) for kind in ['material','state-controls']]
manifest={'schemaVersion':1,'executedSha':'b8ff9c1940723c5fd65c825c4c132628f27494d5','tree':'73e0b49cda1a5b5d22209ac3c6a949e12b4abb8a','runId':45040359902,'jobId':137263205931,'runUrl':'https://github.com/Proto-UI/Proto-UI/actions/runs/45040359902','jobUrl':'https://github.com/Proto-UI/Proto-UI/actions/runs/45040359902/job/137263205931','selection':'explicit-manual-browser-only','items':items,'artifacts':[{'metadata':x['artifact'],'zipBytes':x['zipBytes'],'zipSha256':x['zipSha256'],'crcChecked':x['crcChecked'],'uniqueSafePaths':x['uniqueSafePaths'],'exactExtractedBytesVerified':x['exactExtractedBytesVerified'],'members':x['members']} for x in proofs],'totals':{'nativeOriginalNonPngFiles':sum(x['role']=='original native artifact file' for x in items),'nativeOriginalNonPngBytes':sum(x['original']['bytes'] for x in items if x['role']=='original native artifact file'),'completeOriginalJobLogs':1,'sourceSnapshots':83,'preservedOriginalPngs':len(images),'unarchivedPngs':1046,'originalArtifactMembers':1316},'limits':['All265 original non-PNG native artifact files and the complete decoded original job log are retained losslessly; no raw JSON was rewritten.','Exactly5 selected original PNGs are retained here. The remaining1046 PNGs have full original path/byte/hash inventories and original Actions artifact links; they are not claimed permanently stored in Git and retain original30-day expiration.','Complete original ZIPs are verified locally but not included in this archive. Re-running the full image-dependent reader requires retrieving/restoring the original artifact PNGs, not only this selective permanent archive.','83 source snapshots are exact Git bytes at b8; this is not a complete repository or browser-bundle snapshot.','Ten logical optical/diagnostic partitions were not selected by this run. Historical787 eight-lane reuse is separate evidence with the original executedSHA.','The original first offline-reader schema error is separately preserved; it was not a native test failure.','No physical120Hz/10ms, physical OS IME, Apple parity, non-Web/Compiler or whole-family acceptance.','No signed temporary artifact download URL is stored.']}
p=out/'index.json';p.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
files=[meta(p,p.relative_to(out).as_posix()) for p in sorted(out.rglob('*')) if p.is_file()]
publication={'sourceRoot':str(out),'suggestedRepositoryRoot':'internal/records/evidence/2026-11-22-sprint-6/eighth-liquid-archive','files':files,'totals':{'files':len(files),'bytes':sum(x['bytes'] for x in files)},'index':meta(out/'index.json')}
p=out.parent/'archive-publication-manifest.json';p.write_text(json.dumps(publication,indent=2)+'\n')
print(json.dumps({'manifest':meta(p),'index':meta(out/'index.json'),'totals':publication['totals'],'nativeOriginalNonPngFiles':manifest['totals']['nativeOriginalNonPngFiles'],'nativeOriginalNonPngBytes':manifest['totals']['nativeOriginalNonPngBytes']},indent=2))
