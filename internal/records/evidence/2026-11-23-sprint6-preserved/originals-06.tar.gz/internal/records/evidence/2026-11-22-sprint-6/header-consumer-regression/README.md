# Header consumer 回归诊断原件

本目录保存 `header-ghost-appearance.test.ts` 的失败、归因、正向诊断和最终 test-only patch。执行前提是已发布 `050a1ded7726773486fa56211aa1df7820d19919` 加 root 提供的初始私有 theme 槽修复；执行用 `projection-composition.ts` SHA-256 为 `a75d279fb6a2a82dd1ec4fca6ae2a5003efff5475cf171847938d32f1c60cb40`。**这些执行不是 clean 050 的重新测试，也不是原生浏览器结果。**

## 保留的实际终态

- `root-original-attempt1/` 保存 root 首轮 355 tests 的原始 JSON / log：348 pass、7 fail。它包含另外两条 root 新增 expected 遗漏，因此不能把全部 7 fail 归到 Header。
- `receipt.json`、`vitest.json`、`raw/vitest.log.txt.gz` 保留原 Header 八例的诊断：3 pass、5 fail。原断言 / 输入 / awaits 均保留，仅增加 passive logging；227 条观察存于 `raw/observations.json.gz`。
- `ready-diagnostic-receipt.json`、`ready-diagnostic-vitest.json`、`raw/ready-diagnostic-vitest.log.txt.gz` 保留修正 oracle / readiness 前提后的实际 8/8。执行文件另有两条 passive logs，用以观察 Vue owner ready 的真实 false→true。
- `header-appearance-final.patch` 是最终一个 test 文件的修改。最终测试 SHA-256 为 `9ce07fb8ba59af69f801f20ef07a71b3106bde2929cf02b0ee1bb423ce5ceed6`；相比执行过的 positive 版本只删除两条日志，精确差异见 `diagnostic-log-only-removal.diff`。leaf 没有为这一仅删日志后的最终字节版本重复执行；root 的最终整合测试回执由 root 单独补充，本目录不预称结果。

## 归因与边界

四宿主 Shadcn 末态仍有公共 `focusVisible=true`，实际 `border-ring ring-3 ring-ring/50` 与原 family Rule 一致；旧末态比较把键盘回焦误当 rest。修正显式验证 focus state 和 ring，再执行真实 `blur()` 并恢复完整原 ghost/transparent、identity、owner 等断言。

Brutalist/Vue 首个输入前真实 owner readiness 为 false。沿用仓库 Vue adapter 测试的真实 framework flush 顺序，并有界等待 `isNativeFocusTargetReady` 为 true 后，原来的第一次 focus / Enter / Escape / 回焦 / identity 全部通过。没有任意 sleep、输入重试、revealing 标记等待、放宽超时或改动产品 event gate。

`integrated-source-readback.json` 保存 root 已整合最终文件字节及 15 个指定输入 hash 的回读；它不自称完整传递依赖闭包。早期 `readback-and-cause.json`、仅 Shadcn 候选和诊断 patch 按其历史阶段保留，最终结论以 `final-validation.json` 和 actual positive 原回执为准。诊断 patch 含本地产品前提副本，**最终提交 patch 不含该产品变更**。

所有源码快照以 `.ts.txt` 保存，避免成为新测试/类型检查输入；只是扩展名变化，内容字节没有改变。日志使用 `.log.txt.gz`，JSON 大观察文件使用 gzip，解压后均与原件逐字节相等。原路径与归档路径、原始 / 存储 SHA-256 映射见 `archive-manifest.json`。此次归档没有运行任何测试，也没有修改 tracked source。
