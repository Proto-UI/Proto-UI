# Sprint 6 第六候选 Bootstrap 原件归档

执行源码为 `7871a8da3967ae4bb29cd50c655860cf87d374c0`，tree 为 `1a08b265b1062dd2a44ccf9c2fcaa8bc1aaa9bdb`。真实 Actions run [45030435352](https://github.com/Proto-UI/Proto-UI/actions/runs/45030435352)，job `137232630673`。本目录是原件的逐字节副本及压缩副本，归档操作没有运行新的产品测试。

| 原回执范围 | 实际终态 |
| --- | --- |
| 正式 `check:styles:preset` / fixture boundary | 同一执行源码成功；完整原日志保存在 `raw/job.log.txt.gz` |
| Bootstrap 八部件 | 15/15 原生测试，720 个 computed 字段比较、32 条 editor layout 观察 |
| 顶栏 | 38/38 cells、12/12 原生测试，140 条白色 2 px / 0 offset focus 和 30 条普通 Search semantic focus |
| Button motion | 96/96 cells、8/8 原生测试；100 ms transition、实际中间帧及 trusted transition end |
| 同视口历史基线 | 12 cells captured、36 PNG；被测源码是 dc3b184，截图脚本是 787。captured 不表示通过新契约 |

四个 ZIP 的实际 SHA-256、大小、CRC 与完整 498 文件（494 PNG + 4 manifest）库存保存在 `archive-manifest.json`、`downloaded-artifacts.json` 和 `artifact-file-index.json`。归档时再次核对了四 ZIP 的 digest/CRC。**此目录仅保存指定的 3 张原 PNG，不保存全部 494 PNG，也不保存四个 ZIP。** 其他 PNG 仍通过对应 Actions artifact 和原完整库存定位；artifact 有平台保存期限。四份原 manifest 均以无内容改写的 gzip 副本保存。

`final-receipt.json`、`issue-1467-acceptance.json`、`visual-readback.json` 和 `independent-review/sixth-selected-native-readback.json` 保留原执行 / 独立图片审查的结果。早期 `readback.json` 中的阶段性字段按原样保留，由后续 final / visual 原回执承接，未重写历史。#1467 的四条原条件在该执行 SHA 的窄范围内已取得证据；不据此宣称完整家族、物理键盘/OS IME、全部 Tab 顺序、Compiler、非 Web 或外部应用验收完成。

图片为 `images/docs-dark-390-focus.png`、`images/docs-dark-390-theme-restored-focus.png`、`images/docs-light-1440-closed.png`。复制映射、原文件与存储文件的 SHA-256 均在 `archive-manifest.json`；gzip 解压后的字节与原件一致。源响应和原日志可能包含已失效的 scratch 路径，保留其历史含义，实际本地归档位置以复制映射为准。下载时临时签名 URL / 请求载体没有复制。

后续提交不能把这些结果改标为新源码执行。任何后续复用或重验需要单独的实际源码差异判断。
