# Finf Liquid Accordion: actual Sprint baseline comparison

The exact observed Liquid Accordion failure already occurs at Sprint base `dc3b184ba10b0de53e40359c52d012b204b2cd01`. This conclusion is limited to the executed React journey and recorded post-capture observations. Both the base and 787 cases remain failed at the original 1000 ms `self-optical` assertion.

## Original sources and results

| Execution | Head / tree | Native result | Source |
| --- | --- | --- | --- |
| Sprint base | `dc3b184ba10b0de53e40359c52d012b204b2cd01` / `513879bf79a93cc9325f5193fa0559e16ea57108` | Seven case receipts passed; Liquid Accordion failed | [run 45034808725](https://github.com/Proto-UI/Proto-UI/actions/runs/45034808725), [job 137250324478](https://github.com/Proto-UI/Proto-UI/actions/runs/45034808725/job/137250324478), [artifact 14759419984](https://github.com/Proto-UI/Proto-UI/actions/runs/45034808725/artifacts/14759419984) |
| Candidate | `7871a8da3967ae4bb29cd50c655860cf87d374c0` / `1a08b265b1062dd2a44ccf9c2fcaa8bc1aaa9bdb` | The same seven receipts passed; Liquid Accordion failed | [run 45030540222](https://github.com/Proto-UI/Proto-UI/actions/runs/45030540222), [job 137238435748](https://github.com/Proto-UI/Proto-UI/actions/runs/45030540222/job/137238435748), [artifact 14758677229](https://github.com/Proto-UI/Proto-UI/actions/runs/45030540222/artifacts/14758677229) |

The base ZIP is 4,491,066 bytes, SHA-256 `80046f49330e17e604ea8642c7c5c57bba2b98c2574b3c2b3cd19f0f32fdb38b`, matching the fresh GitHub artifact response. CRC and safe extraction were checked for all 65 files. All eight terminal source identities and all 43 declared screenshot hashes were verified separately for each run. The [full comparison](base-vs-787-readback.json) retains both source/receipt hashes, the exact original error, API metadata, and the comparison scope.

## What actually matches

The runs record the same public route `/en/ui-libraries/liquid-glass/accordion/`, React runtime, Chromium `157.0.8103.78`, viewport 1365 × 1000, DPR 1, light theme, locale/font and fixed host clock. For each of `rest`, `failed` and `failed-previewer`, all twelve complete material records are deeply equal across runs, including preferences, visibility, every ancestor record and source-canvas facts. This is 36 full observed records, rather than a comparison of only the error string.

All three original PNGs are byte-identical across runs. `rest` and `failed-previewer` share SHA-256 `abf7b1a9682b5d2be1c7085d3d77b35c18c2ddc01475559847a42d2b865b4522`; the full failure image has SHA-256 `019907c09ee08f4af2bbeb0bba4f3f9601a168043ed632357ca24b468fb2c650`. The two distinct base images were actually opened. Their visible open Overview content, border and following Content-lifetime trigger agree with the recorded geometry. ARIA text is also byte-identical. Raw DOM text is not byte-identical: the observed previewer ID and its derived owner class differ. Only replacing those two explicitly recorded identity strings makes the DOM byte strings equal; the originals remain unchanged and their distinct hashes are retained.

## The same concrete geometric blocker

In both runs, `single-lifetime-trigger` is `(364.5, 331.5, 428, 50)` and reports `opaque-fallback / source-overlapping-content`. Its connected same-scope source is 512 × 1250 physical pixels and 512 × 1250 CSS pixels at DPR 1. There is no stale raster in these observations.

The unchanged full supported contact budget is `ceil(max(428, 50) × 0.08 + 1) = 36`. The target paint rectangle is `(328.5, 295.5)` through `(828.5, 417.5)`. The preceding Item is `(363.5, 90.5, 430, 232)`, so its intersection is **430 × 27 CSS pixels**. Its opaque open Content is `(364.5, 141.5, 428, 180)`, independently overlapping by **428 × 26 CSS pixels**. This remains real foreign paint, not an unpainted wrapper. The nested trigger independently retains the intended `source-painted-ancestor` fallback.

The prior [source and contract review](../finf-accordion-geometry-review/decision-boundary.md) remains unchanged as a historical record. This new actual-baseline evidence resolves its previously pending question only for this bounded observed failure: the same native rejection and geometry were present before Sprint 6. It does not accept the family or authorize a larger gap, a smaller contact budget, a guard exception or an undeclared reservation API.

## Boundaries

Material observations were captured after screenshots; neither run records pre-capture material state or proves that a screenshot caused the fallback. The exact 1000 ms assertion remains unmet. Later painted-Item recovery, disclosure actions and controlled owner acceptance were not reached. Full emitted CSS bytes were not archived, and their equality is not claimed. These original Actions artifacts remain subject to 30-day retention; the local ZIP and raw files are retained here, and no signed download URL was saved. No new test, build, browser or product change was performed for this readback.
