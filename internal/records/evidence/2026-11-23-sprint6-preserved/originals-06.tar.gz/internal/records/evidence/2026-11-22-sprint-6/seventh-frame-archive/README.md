# seventh-frame-archive

This archive preserves original report bytes from [run 45035686872](https://github.com/Proto-UI/Proto-UI/actions/runs/45035686872) and [its native job](https://github.com/Proto-UI/Proto-UI/actions/runs/45035686872/job/137248826732). Executed head: `050a1ded7726773486fa56211aa1df7820d19919`. Tree: `0af7b0a4c0c2fcd0ada506b1a0f5a366ea8236b7`. The original workflow conclusion is **success**; the original readback conclusion is `passed-readback`. A successful readback verifies the recorded observations and does not convert a failed workflow into product acceptance.

All 25 JSON/log/text/Markdown reports in the original 239-member artifact and all 7 local readback/GitHub report files are stored as deterministic gzip files. Each decompressed byte string was compared to the complete original file. JSON and text bodies were not normalized, edited or reserialized. The [archive index](archive-index.json) records each original and compressed byte count and SHA-256, the exact source/run/job identity and the original readback digest. The [complete artifact inventory](artifact-inventory.json) retains all 239 original member paths, sizes, SHA-256 and ZIP CRC32 values; every extracted member was compared to the verified original ZIP.

Exactly two original PNGs are copied under `images/`:

- `candidate-release/dark-dpr-two.png` — SHA-256 `475646e607e8eb91fcb37a25653c7777c37c7dd8b90babe869a8bec6cbbceecd`.
- `candidate-release/light-dpr-two.png` — SHA-256 `41fdad09cf2f32fb3c72265fbf89c597debda4509464f2afa391cef88fddc66f`.

The other 212 PNGs are inventoried but their image bytes are not stored in this Git archive. The original ZIP is not copied here. Those remaining images are available only from the [Actions artifact](https://github.com/Proto-UI/Proto-UI/actions/runs/45035686872/artifacts/14759844272) under its 30-day retention, with recorded expiry `2026-12-22T15:13:41Z`. No permanent retention of those images is claimed. Download-temporary metadata and signed download URLs are excluded.

The parent readback's original limitations are retained verbatim in its gzip copy and in the index. This archival operation runs no tests, build, browser, physical display/input measurement or new visual review. It does not relabel either execution as a later source head or alter the unmet 120 Hz / 10 ms and full Sprint acceptance conditions.
