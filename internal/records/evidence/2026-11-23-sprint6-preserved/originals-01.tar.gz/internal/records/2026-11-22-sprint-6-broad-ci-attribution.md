# Sprint 6：完整 CI 原失败、实际基线对照与归档边界

本记录保留第六候选 `7871a8da3967ae4bb29cd50c655860cf87d374c0` 的真实整仓周期与已完成的基线归因。它不是较新提交的完整 CI 通过记录，不授予 APPROVE、merge、发布或整个 Sprint 6 的接受。

## 完整周期与取消结果

[候选周期 45030540222](https://github.com/Proto-UI/Proto-UI/actions/runs/45030540222) 已于 2026-11-22 15:37:29 UTC 进入 `failure` 终态。完整 API 库存为 **98 个唯一 job：72 success、25 failure、1 cancelled**。全部 job 的名称、ID、URL、起止时间及实际结果保存在 [最终独立回读](evidence/2026-11-22-sprint-6/broad-ci-attribution/reports/ci45030540222-final-independent-readback.json)，没有把失败数量换算为产品缺陷数量。

`test-general` 被取消。其实际留下 361 个失败 test leaf；737 个库存 suite 没有观察，另有尚在运行和 not-run 的记录。取消没有抹掉已经完成的七个失败 stage，也不允许把缺失的断言补成通过。原进度 JSON、原日志和取消回读均按原字节保存；较早报告中的“整个周期仍运行”是当时的观察，当前终态以完整 98-job 库存为准。

| 原失败组 | 实际保留的状态 | 本次归因或后续处置边界 |
| --- | --- | --- |
| type-check | 失败 | 第六候选 quality overload 的 TS2394 已有最小修复；后续完整类型检查的真实 exit 0 另见共享消费者恢复记录，不能改写本次失败。 |
| 11 个 browser shard | 失败 | 原库存和失败原件保留。新 Bootstrap/Liquid suites 的专用 owner 迁移、原 WIP guard 与 unexpected-skip 条件分别验证；其他原条件按用例身份归因，不能仅凭相同 shard 编号或总数作基线结论。 |
| Liquid material production owner | 失败 | 原 DPR 联合谓词真实拦截源 bitmap/revision 不更新。后续单 CDP owner 的 metrics transaction 与第五条 release 条件另有新执行回执；纯 DPR/物理显示通知没有被代验。 |
| Finf disclosure | 失败 | Liquid Accordion 的完整 paint footprint 与相邻不透明 Item 相交，实际基线同因见下文。 |
| Finf Shadcn Drawer、其他共享消费者 | 失败 | 保留原用例和实际边界；本档案不从测试文件未改推断全部历史失败，也不授予范围豁免。 |
| Component capabilities | 失败 | Number Field 的 20 条 uncontrolled 原 trusted-event 断言失败，controlled 分支未到达；与基线完整事件轨迹比较如下。 |
| Home / density / motion / Search | 失败 | Home 四个桌面 locale 失败已有实际关闭菜单的前提证据。其他失败保留原日志与任务责任，不能用 Home 的一个原因代替所有入口。 |
| Language navigation | 失败 | 四例都在初始两个 language root 的断言失败，后续旅程未执行；实际只有一个已初始化 Header root。 |
| Startup candidate / 历史 baseline | 都失败 | 候选 19 pass / 8 fail；历史 `48b80f8` 为 23 pass / 4 fail。历史 baseline 不是 Sprint base `dc3b184`，不能混用。 |
| test 聚合 / cycle-report | 失败 | 聚合的失败保持；没有完整绿周期或红灯恢复结论。 |

## 按实际用例对齐的基线证据

[基线周期 45034808725](https://github.com/Proto-UI/Proto-UI/actions/runs/45034808725) 使用真实 `dc3b184ba10b0de53e40359c52d012b204b2cd01`。本档案的 API 快照截至 **16:01:27 UTC**：93 jobs，Home 已失败，Language 正在运行，后续 Startup 尚未生成。它不是基线完整周期终态。两轮使用相同工作流配置但不同 runner，不能当作同一硬件的性能 A/B。

已经完成的基线 general artifact 具有相同的干净 sourceBefore/sourceAfter，原 Vitest 结果为 **22,710 total、22,166 passed、498 failed、9 pending、37 todo**。这些是完整原报告的真实状态，不是该 PR 的接受数量。关键比较见 [独立逐条件回读](evidence/2026-11-22-sprint-6/broad-ci-attribution/reports/base-vs-787-scoped-general-and-numberfield.json)。

### Header 私有主题槽与两个不同的 Search 套件

基线 Header 八例均在首次主题更新时报 `missing renderer-owned theme state`。基线与第六候选的 `createProjectedProto` 创建函数及其空槽登记条件实际相同。因此，后续私有空槽修复解决的是本轮发现的共享路径缺口；不将它错误归因为本轮新引入。基线没有运行到之后的 focus/rest 或 Vue owner-ready 断言，不能声称那些后置失败也被基线实际复现。

`site-search-commands.test.ts` 的基线 **8/8 passed**、第六候选 **9/9 passed**。原先需要核对的两条失败属于另一文件 **`override/Search.test.ts` 的 97/128 行**；基线实际报告确实包含同名、同行的两个 false/true 源码观察失败。独立报告保留了纠正初步文件归因的历史，不能继续把这两例称为本次合法 Bootstrap enum 修复造成的新失败。

### Number Field

两份原完整 capability 报告均为 100 cases / 80 pass / 20 fail。5 家族 × 4 宿主的 20 份 native 与组件事件轨迹逐项相同：实际 input 为 trusted，`compositionend.isTrusted=false` 原样存在。每条只执行到 uncontrolled 的原 trusted-native-events 失败，随后 controlled 没有执行。该对照证明原失败身份与输入事实，没有接受数值提交、拒绝更新或物理 OS IME 条件；#1098 / #1178 仍须原范围验收。

### Liquid Accordion

基线与候选三阶段 × 12 条完整 material observations 相同，三张原 PNG 字节相同，ARIA 原字节相同。两份完整 DOM 仅有实际 previewer ID 和编码 owner class 的生成标识差异；原 DOM 未被改写。独立审查再次读取两份原 JSON 和原 PNG 验证了这项窄结论，见 [独立基线核对](evidence/2026-11-22-sprint-6/broad-ci-attribution/reports/finf-accordion-base-native-independent-check.json)。

真实 DPR 1、source 512×1250、Trigger 428×50；固定 36 px contact paint 包络与前一 430×232 的不透明 Item 相交 **430×27 px**，两轮都正确拒绝为 `source-overlapping-content`。原 **1,000 ms** self-optical 断言保持失败，后续 open/reopen/owner 阶段未到达。没有 capture 前观察可证明截图因果，也没有完整生成 CSS 相同的推断。公开 paint reservation 的 draft / Q-SYNTAX 边界仍未决；本次没有用任意 gap、缩小包络或删除 guard 掩盖它。

### Home、语言与 Startup 的具体观察边界

Home 四个失败的原 `failureState.page.siteMenuOpen` 均为 `'false'`，runtime/family 已可见，唯一 locale 已找到但可见性失败，`pageErrors=[]`。两个原 PNG 也确实显示菜单关闭。宽屏 `revealHeaderPreferences` 会在 preferences 已可见时返回，而 locale 位于 settings 披露内；这是与实际 dataset/图像一致的测试前提问题。没有完整 failure DOM，不能把 dataset 和图像称为完整 DOM 记录，也不从源码未改直接声称基线已跑出同因。

语言四例的原 HTML 只有一个已初始化 Header language root、没有 Sidebar 副本；原 suite 初始要求两个 root，四例均在此处终止。Header/Sidebar/LanguageSelect/配置与测试的对应源码和基线字节相同，但本档案截止时基线语言执行仍在进行，因此原生基线结论保持 pending。

Startup 候选三例为 **H1 text Range y 位移 +5 CSS px**，原容差 1 px；header 高度不变，不能归因于 Navbar 面板的 +5 px 间隔。另五例在旧 DialogMask blur locator 等待超时；React 原图可见 Rhea 的黑色 0.3 mask、无 blur，其他失败没有完整 failure DOM。旧 `48b80f8` 的五个 scope 与偏好观察不等于 `dc3b184` 的严格 gate。具体来源与仍待基线的推论保存在 [Startup 初始只读记录](evidence/2026-11-22-sprint-6/broad-ci-attribution/reports/startup-triage-787-initial.json)，不提前声称全部历史或全部修复。

### 来源登记与公包

基线的 source checker 留有同样 11 个失败身份：8 个 hover raw imports 与 hover/select-demo/previewer-bootstrap 三个旧 source fingerprint。第八治理补丁后的完整 checker 也保留这 11 项；仅三个矩阵行号发生位移，原日志不是逐字节相同。基线生产 build 后仍有两个旧 diagnostic Adapter reach 失败；新 state-controls 的精确分类修复不能把它们改成通过。

第六候选 `public_package_build` job **137234519984** 实际完成 47/47 公包、原显式 JavaScript entry import smoke、15/15 budget-policy 与 strict budget 步骤。本档案保留完整原 job log。该 builder 明确排除 private 家族包，公包成功和完整类型检查不能代替 private draft 的 pack / 干净消费者检查；后来新增的独立 package 修复与执行须用其自己的回执接受。

## 保存了什么

[归档清单](evidence/2026-11-22-sprint-6/broad-ci-attribution/archive-manifest.json) 逐项列出 109 份复制材料的原路径、原 bytes/SHA-256、归档路径、压缩 bytes/SHA-256 和解压复核结果。95 份使用 gzip 保存，解压字节与原件完全一致；独立报告保留原文。完整 98-job 库存、原 cycle receipt、取消 general 进度/日志、基线 general 报告、两份 Number Field 与 Accordion、语言原 HTML/JSON、Home 原 metrics、Startup 原 observations 和必要 job logs 均可由该清单定位。

此目录没有保存完整原 artifact ZIP 或 PNG。未列入清单的原图、完整 ZIP 与其他 artifact 成员仍依赖 GitHub Actions 的实际 **30 天保留期**，也可能提前删除。清单或 hash 不能重建缺失字节；本记录没有声称所有截图或全部原始 artifact 已永久保存，也没有复制临时签名下载 URL。

较新提交的验证、独立 canonical review、当前平台状态和 Ready 需要各自真实证据。本记录不把第六周期的失败改成第九或后续提交的结果；保留广域未完成条件也不等于放弃其原验收。
