# Broad CI attribution archive

The authoritative inventory is `archive-manifest.json`. It identifies the exact original file and SHA-256 for every stored byte stream. `.gz` members decompress to the original bytes without rewriting logs, source facts, failure messages, HTML or historical status.

This is a **selected evidence archive**, not all CI artifacts. No original ZIP or PNG is stored in this directory. Omitted members and screenshots retain their real external GitHub Actions retention boundary; inventories and hashes do not preserve omitted bytes.

- `reports/`: independent readbacks and source-attribution decisions, with their original timestamps and limits.
- `api/` and `787-cycle/`: complete final candidate job inventory, actual saved API responses and original cycle receipts. The base snapshot is explicitly partial at 16:01:27 UTC.
- `787-general-cancelled/`, `base-general/`: actual cancelled progress and complete baseline reports, including original failures.
- `787-number-field/`, `base-number-field/`, `787-finf/`, `base-finf/`: original reports used for same-case comparisons. No failed or unobserved branch is relabeled successful.
- `787-language/`, `787-home/`, `787-cycle-startup-*`: original observations. The startup baseline is historical `48b80f8`, not Sprint base `dc3b184`.
- `787-job-logs/`, `base-job-logs/`, `artifact-inventories/`: retained actual logs and provenance/member lists. These are not a fresh execution.

The source remains the one named in each original record. Later fixes, final canonical review, Ready, integration and original family/physical/platform acceptance remain separate.
