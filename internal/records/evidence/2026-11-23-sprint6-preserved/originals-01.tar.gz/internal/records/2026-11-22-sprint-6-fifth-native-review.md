# Sprint 6: independent fifth-candidate native readback

This record is an independent readback of actual artifacts, not a new browser run or a canonical final review packet. The observed candidate is `3801353bb6086d11b257dace4f0dc347fea98488`, tree `209d3cb4396bc5a9070d3445bdbaede921d63aa3`. Later candidates must retain this executed SHA when reusing any result.

## Bootstrap www Navbar

[Bootstrap run 45025119696](https://github.com/Proto-UI/Proto-UI/actions/runs/45025119696) has a complete candidate Navbar receipt: 38 cells, 12 tests, 298 screenshots, and empty page, cleanup and protocol error lists. I independently recomputed the inventory and checked every one of the 140 Navbar focus observations: actual `#ffffff`, width 2px, offset 0px, and an actual white 2px layer in the computed box shadow. All 30 ordinary Search observations keep their semantic ring and 2px offset.

I actually viewed the Docs 390px dark/light menu-focus screenshots, dark Theme focus before switching, after switching and after restoration, the dark 1440px navigation focus, and the dark 390px expanded panel. The dark Docs defect found after the earlier automatically successful `afde3097` run is visibly fixed. Theme glyphs remain white on the transparent Navbar purpose; Search retains the rectangular Bootstrap gradient. No new Navbar visual defect was found in these observations.

The same-run historical capture uses measured source `dc3b184ba10b0de53e40359c52d012b204b2cd01`, script source `3801353b`, Chromium 157.0.8103.78, and the same three viewport definitions. Its 12 cells are **captured**, not retrospectively declared compliant with the new density contract; all 36 listed images are present and its actual page-error list is empty. I viewed the 1440px light Home closed-state pair and 390px dark Docs expanded-state pair. The desktop change from the original 72px row to the intended 40px row and 30px controls is clear. Mobile keeps the common 56px row and 44px targets as an explicitly documented adaptation.

The four original #1467 www-specific conditions can be accepted at this candidate:

| Original condition | Independent disposition |
| --- | --- |
| Fixed reference version, distinction between Bootstrap authority and Zhihu/UOJ direction, same-viewport before/after | Accepted: the preserved official Bootstrap 2.3.2 pin/reference material and declared adaptations, plus the actual same-run baseline/candidate pairs. |
| Desktop/narrow navigation, Search, selectors, Theme/settings, no overlap/overflow, anchored panel | Accepted within the declared Home/Docs browser inventory; original geometry and usability assertions completed. |
| Mouse/keyboard focus, Escape and return, light/dark hover/focus/expanded, final-source-bound visuals | Accepted within the actual Chromium input route. The newly added actual-color assertion and manually viewed Theme round trip close the earlier visual defect. |
| Generic prototype/compiler ownership, existing semantic owners, stated remaining boundaries | Accepted by the reviewed source and explicit evidence scope. |

This does not claim continuous physical Tab traversal, OS input, a physical device, every Bootstrap family part, or Compiler/non-Web conformance. Those are separate conditions where originally required; they do not erase the completed #1467 www slice. The separate Liquid DPR failure below is not a Navbar failure.

## Liquid portal and native editor evidence

[Material run 45025270205](https://github.com/Proto-UI/Proto-UI/actions/runs/45025270205) retained the complete main and state-control reports at the same candidate. I independently inspected the actual portal JSON and the state manifest.

All nine portal cases retain three baseline observations and six handover observations. The final three handovers meet the original 0.5px content and 1px geometry conditions, preserve the actual predicate, and restore the exact original styles. The three boundary controls preserve their first, incorrect predictions (errors 2.92, 2.88 and 2.84px). Each converges after two actual viewport measurements, with final errors +0.04, 0 and -0.04px; below/at/above occupy the required actual predicate sides. No threshold was widened.

The Liquid state manifest contains all 31 unique expected native cases, all passed, and no missing, duplicate, unexpected or failing terminal entries. For each of 16 runtime × editor × owner cases, I compared the independently executed bare editor against the component: three native inputs and five composition events per case, matching all event fields except the unrelated cross-object object ID. All 48 input events remain trusted. The native `compositionend` is actually `isTrusted=false`, `scriptDispatched=false`, with the dispatch observer active; the record does not relabel it trusted. Each of the 16 separately dispatched synthetic end events is also untrusted but has `scriptDispatched=true`, and the real negative control is rejected.

The original per-native-input valueChange sequence and final compositionEnd data are preserved. The 31 completed tests reach the downstream controlled owner acceptance and editor identity checks that the old failure stopped before. The separate eight ordinary owner-acceptance records are complete, and final disposal reports 64 → 0 mounted hosts. I viewed the WC controlled Input and Vue2 controlled Textarea screenshots showing `Accepted composition`.

This is the actual Chromium CDP composition route and provider-free Liquid fallback. It is not physical OS IME, optical material acceptance, or a run of shenko/verdant.

## Frame evidence: successful lifecycle control and remaining failure

[Frame run 45025405460](https://github.com/Proto-UI/Proto-UI/actions/runs/45025405460) is still a failed selected workflow. Its separate successful observations remain useful without converting the failure to a pass.

The fixed neutral program-clear control executed old source `19d175f454468fa27364c8283e084f3bb7a1016b` and candidate `3801353b`. I independently checked the shared kernel hashes against both Git objects, the actual candidate probe hash, the frozen black source byte hash, geometry and null tint/contact. Both submitted shader pairs match the frozen neutral control. The old first frame, candidate first frame and candidate post-clear frame share PNG hash `ea322b47e692e63c64bfbf1e1f698da4bc45db84f0afbbebe68a853e802a618a`. The old second render actually fails with GL1282 and a retired-program rebind. The candidate completes its second GPU preparation, has no GL/disposal error or retired rebind, and releases all preparation caches. The independent GPU matrix retains 84 byte-equivalent cases and nine integration steps, with all CPU/GPU live-object and double-delete counts zero at cleanup.

I recalculated repeated fresh-press p95 directly from all 240 actual sample timestamps:

| Executed source | Workload | Resolved | Listener → held commit p95 | Event timestamp → held commit p95 | Listener / event observations above 10ms |
| --- | --- | ---: | ---: | ---: | ---: |
| `49fc3ac3` baseline | Static | 60/60 | 12.200ms | 12.405ms | 24 / 24 |
| `49fc3ac3` baseline | Dynamic | 60/60 | 16.475ms | 20.040ms | 37 / 38 |
| `3801353b` candidate | Static | 60/60 | 12.510ms | 12.810ms | 23 / 23 |
| `3801353b` candidate | Dynamic | 60/60 | 36.690ms | 41.075ms | 41 / 41 |

The recorded renderer is software and rAF cadence is approximately 60Hz. A held material commit follows image decode but precedes compositor presentation. The original 10ms/120Hz condition is not met or measured by these data; candidate dynamic p95 is worse in this matched run. Earlier `afde3097` numbers must not be relabeled as this fifth run, and no general latency improvement is claimed.

The final selected release inventory is four passes and one failure, plus one diagnostic that the original selection never included. The dark case fails the unchanged 20-second self-optical wait immediately after a DPR-only change. The failure snapshot and screenshot hash agree: all four visible source canvases remain 466 × 172 physical pixels while their CSS dimensions are 466 × 172 and the observed DPR is 2, which requires 932 × 344. Every sink correctly rejects the stale source with `source-resize-or-dpr-stale` and uses opaque fallback. The source-refresh counter is a sink repaint counter, so its zero pending count does not prove that the producer's media/resize callbacks were correctly delivered. The producer recovery requires a separate fix and fresh native result; passing the main material run on the same head does not erase this race.

## Reproducible independent receipts

- `review-reference/readback-fifth-selected.py` → `review-reference/fifth-selected-native-readback.json`: actual Navbar/portal/composition assertions and original artifact hashes, no native execution.
- `review-reference/readback-fifth-frame.py` → `review-reference/fifth-frame-independent-readback.json`: actual frozen control, GPU cleanup, timing recomputation and retained DPR failure, no native execution.

Source-clear and this bounded evidence readback are not a canonical final review, platform approval, permission to merge, or closure of the complete Sprint 6 family/platform/hardware scope.
