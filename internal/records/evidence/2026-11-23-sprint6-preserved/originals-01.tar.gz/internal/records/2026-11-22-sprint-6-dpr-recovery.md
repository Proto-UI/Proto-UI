# Sprint 6：第五候选的真实终态与 DPR 恢复

本记录承接[上一轮原生回读](2026-11-22-sprint-6-native-recheck.md)。被测源码为 `3801353bb6086d11b257dace4f0dc347fea98488`，tree 为 `209d3cb4396bc5a9070d3445bdbaede921d63aa3`。三个新运行中两个成功、一个失败；同提交的成功不能覆盖独立工作流暴露的失败。后续修复的原生结果由 PR #1712 按实际执行 SHA 接续。

## Bootstrap：原焦点缺陷的实际反证

[run 45025119696](https://github.com/Proto-UI/Proto-UI/actions/runs/45025119696/job/137216393975) 的完整 job 成功，包含正式 `check:styles:preset`、原四宿主控件、顶栏、Button 运动及同 runner 的历史基线采集。

| 实际库存 | 结果 | 原始图片 |
| --- | --- | ---: |
| 八部分控件 | 15/15 native，720 个原 paint 字段对照，32 个实际 editor layout 前提保留 | 48 |
| 顶栏 | 12/12 native、38/38 cells，page / cleanup / protocol errors 为空 | 298 |
| Button 运动 | 8/8 native、96/96 cells，原进入、退出、取消与 reduced-motion 对照保留 | 112 |
| 同环境基线 | 12 captures；measured source=`dc3b184`、采集 script=`3801353`，不是新候选符合性测试 | 36 |

140 条真实 navbar focus 记录均为白色 2 px、offset 0，完整 computed box-shadow 中存在白色 2 px 层。30 条普通 Search 记录仍使用自身 semantic ring（15 条 `#0055aa`、15 条 `#7abfff`），offset 2 px。实际查看的 Docs 窄屏深色 focus、Theme 切换和恢复图片中，上一轮黑环缺陷已消除。

两名执行者分别检查真实截图和固定 Bootstrap 2.3.2 官方参考，包含两入口的 1440 / 1024 px 浅色、390 px 深色、展开与键盘焦点路径。#1467 的四条原 www 条件在这个执行 SHA 上已具备逐项接受依据。Playwright 键盘 Enter / Escape、焦点返回和绘制事实保持各自边界；这不表示物理键盘、全家族逐 part 或所有辅助技术验收。

![Docs dark focus after the actual correction](evidence/2026-11-22-sprint-6/380-bootstrap-docs-dark-390-focus.png)

另保留[Theme 恢复后的实际焦点](evidence/2026-11-22-sprint-6/380-bootstrap-docs-dark-390-theme-restored-focus.png)和[1440 px Docs 顶栏](evidence/2026-11-22-sprint-6/380-bootstrap-docs-light-1440-closed.png)。三张均是原 artifact 字节；逐条原条件映射见[#1467 回读](evidence/2026-11-22-sprint-6/fifth-native-readback/issue-1467-acceptance.json)。

四条原条件已通过已授权的真实 GitHub body 更新勾选并回读；原文字保持不变，新增依据明确绑定 `3801353`，Issue 保持 open，未替用户合入。[实际跟踪回执](evidence/2026-11-22-sprint-6/fifth-native-readback/issue-1467-connected-receipt.json)与本地请求校验、connector 操作分别记录。后续改动若影响同一消费者，仍须取得新源码的承接结果。

## Liquid 主套件：当前完整选中阶段成功

[run 45025270205](https://github.com/Proto-UI/Proto-UI/actions/runs/45025270205/job/137216821358) 的主 job 成功。显式 `browser_only=true` 只选择 main 的两个完整阶段；四个其他 job 定义在矩阵展开前未选择，不能把原计划十个分区记成十个实际通过的 job。

- material / library：33 文件、960/960；六个必需材料案例各执行一次，0 fail / skip / todo。
- state-controls：5 文件、94/94，包含原 31 个 native cases；名称库存无缺失或替换。
- 16 个 component composition 路径与 16 个独立裸 editor 对照逐字段一致，每对五个 composition 事件；原 48 条 input 的 trusted 值成立。实际 native compositionend 的 `isTrusted=false` 原样保留；16 个脚本派发 end 负控全部被来源观察器拒绝。
- 8 个普通 controlled owner acceptance 及 16 条 composition 的后续 owner 接受、值与 identity 断言均到达终态；没有把原生 CDP 自动输入称作物理 OS IME。
- Portal 九例各三帧 baseline、六帧 handover；三个实际边界用两轮有限校准达到 `+0.04 / 0 / -0.04 px` 误差，实际阈值差为 `-0.96 / 0 / +0.96 px`，predicate 为 true / true / false。原首轮预测偏差 `2.92 / 2.88 / 2.84 px`、严格 0.5 px 和 1 px 门槛保留。
- 11 个 release 与六个 theme ownership 检查无 failure / page error，源码首尾一致。

## 独立 frame 工作流：真实 DPR 失败

[run 45025405460](https://github.com/Proto-UI/Proto-UI/actions/runs/45025405460/job/137217235147) 的 job 为 **failure**。baseline / candidate 测量、两侧 source-progress、84 个 GPU prefilter byte cases、九个集成步骤、program-clear 控制均成功；最后 material / release 阶段五个选中案例为 **4 passed / 1 failed**。另一个诊断原本没有选择，不能计为通过。

失败发生于深色路径在 1100 px 视口切换到 DPR 2 后的原 `quality('self-optical')` 等待，仍是 **20,000 ms**。原快照中 `window.devicePixelRatio=2`、resolution query 匹配，但四宿主的 visible source canvas 均仍是 **466×172**，与 CSS 尺寸相同；所需 physical buffer 为 **932×344**。四宿主均由 sink 正确拒绝为 `source-resize-or-dpr-stale`。这个安全检查不是待移除的阻塞。

同 head 的主套件通过相同路径，提示需要检查通知与恢复时序，尚不能单独确定具体原因或证明这个独立工作流已经恢复。原 `pendingSourceRefreshTasks=0` 是 sink repaint 队列事实，不能推出 producer 已经收到所有 DPR / resize 通知，也不能用无图像解码错误替代 producer 恢复。

独立审查又指出原 quality 等待只检查 material dataset，切换后的首次 poll 可能看到尚未更新的旧 `self-optical`。因此旧主套件的绿色终态原样保留，但不能单独证明 DPR 2 和恢复 DPR 1 后的四个 source buffer 已刷新。下一次真实运行需要在原 20 秒内同时观察当前 DPR、四 source 的 physical/CSS 尺寸、四 consumer 的新 source revision 和原 quality 条件；不得通过主动 redraw 或扩大 deadline 补齐这些事实。

![Actual four-host dark DPR failure](evidence/2026-11-22-sprint-6/380-liquid-dark-dpr-stale.png)

责任层检查发现一个可验证的 producer 缺口：原 `resolutionChanged` 同步读取 DPR、重绑 exact resolution query 并刷新，`window.resize` 也只同步刷新。如果通知时仍可读旧 DPR，下一帧才读到新 DPR，暂停且没有后续通知的 source 不会自行更新。这个模型需要旧源码负控和修复后实测；没有现成 browser event trace 能证明本次 Chrome 内部恰好按这个顺序通知。后续修复应进入现有有界 layout frame、重新读取实际 DPR，保留停用、去重与 dispose 条件，不以无限轮询或 fixture 主动绘制掩盖产品责任。

### 有效负控与 producer 修复

先保持产品源码与 `3801353` 的 Git 对象逐字节一致，仅添加 resolution / resize 两条通知先于可读 DPR 的反例。在 paused / quiet source、没有 RO / 第二次通知 / 显式 `redraw` 的条件下，旧版两条均以 **420×104 而非 840×208** 失败，实际 exit 1；其余 21 条没有选择，不计为通过。这是明确事件序列下的旧实现反证，仍不是对原 Chrome 内部序列的倒推。

修复仅修改 `preview-material-scene.ts`：初始 query / layout / paint 保持同步；之后 resolution、resize 和既有 RO 通知合并到现有单个 layout RAF，在该帧重新读取 DPR 并按需重绑 exact query，随后执行 layout / refresh。DPR 不变不会短路后续 CSS layout 更新；暂停动画不会取消已有 viewport repair；dispose 取消两个不同用途的 RAF，并阻止捕获的迟到回调、旧 MQ 与 RO 重新创建 source。没有常驻轮询，也没有扩大 native 20 秒门限或放松 stale admission。

原 21 个测试与两条真实红例的文本保留，增加 coalescing / listener retirement、1→2→1、后续相同 DPR 的 CSS 更新、pause 和 dispose 观察，完整单文件实际 **27/27、0 skipped / failed**，exit 0。产品 SHA-256 为 `591262014e5be6db86b013dfd21cde229b1f467e2e37568aa9172bafbd9cf5cf`，测试为 `98e32ea0649c579bd7ec4eea3f2640dec590d9a74cfd540952023a3bb2e19f84`。旧源码、两条红例完整文件、原 stdout、完整 green JSON、命令和时间均在[回归归档](evidence/2026-11-22-sprint-6/dpr-regression/archive-manifest.json)，[独立源码审查](evidence/2026-11-22-sprint-6/dpr-regression/sixth-dpr-source-review.json)确认这两文件没有源码阻塞，但明确原生恢复尚待新提交验收。

[实际依赖闭包](evidence/2026-11-22-sprint-6/dpr-regression/dependency-route-manifest.json)表明八个 prominent / hover 分区都激活这个 producer。Bootstrap Navbar 与 motion 也访问两家族共存的 `new-projection-families` 页面：Liquid 的 `material='opaque'` 并不禁用按 prototype ID 自动创建的 scene。因此后续要在新 head 重跑完整 Bootstrap、完整 Liquid 和 frame 三条工作流；不沿用此前仅 CSS 变化时的“Liquid 输入未变”复用结论。

## 程序清理控制和性能原值

固定 neutral regular / 黑场 / null tint / null contact 控制在旧 `19d175f` 和当前 `3801353` 上使用相同 source pixels、geometry、共享 kernel 及实际提交 shader hash。旧首帧、当前首帧和当前 clear 后帧的 PNG SHA-256 均为 `ea322b47e692e63c64bfbf1e1f698da4bc45db84f0afbbebe68a853e802a618a`。旧第二次渲染确实产生 GL 1282 并重绑已退休 program；当前没有这些错误，GPU preparation 从 1 到 2、CPU 为 0，clear / dispose 的 cache 均清零。GPU / CPU 集成资源的 created/deleted 相符，live / doubleDeletes 均为零。

匹配性能比较仍为 `49fc3ac` → `3801353`，同探针、浏览器、lockfile、fixture 和工作负载。Chrome `157.0.8103.78`、Node `24.22.3`，软件 SwiftShader、约 60 Hz rAF。两名执行者分别从 raw samples 重算 240 次 press；每版每模式均 60/60 resolved。

| fresh press | baseline listener→held p95 | candidate listener→held p95 | candidate event timestamp→held p95 | candidate >10 ms，listener / event |
| --- | --: | --: | --: | --: |
| static | 12.200 ms | 12.510 ms | 12.810 ms | 23 / 23 |
| dynamic | 16.475 ms | 36.690 ms | 41.075 ms | 41 / 41 |

本轮动态 p95 没有改善，两个 candidate p95 都未达到原 10 ms。软件 headless 结果不测量物理刷新率或 input-to-photon 延迟，也不能与上一轮不同 runner 的 16.810 / 67.805 ms 混合成加速结论。每版无不可信 input、pointer identity 或 release failure，四宿主 source-progress 的两个窗口无跳跃、顺序错误或停滞记录；这些有界正确性结果不能替代原硬件目标。

## 原始材料与后续边界

[七个 artifact 的完整 JSON 归档](evidence/2026-11-22-sprint-6/fifth-native-archive/manifest.json)保留 **283 份原 JSON、71,741,340 原始字节**，确定性 tar/gzip 共 3,951,447 字节。每个原 ZIP 先核 GitHub digest / CRC，每个归档成员再与原 ZIP member 逐字节比较，并记录原始与压缩 SHA-256。归档包含失败、baseline、未选择状态及诊断结果；没有将摘要改造成原件。原 Actions artifact 为 30 天保留，固定 URL 不是永久下载承诺。代表 PNG 单独保存，其他原图的库存和 hash 仍在原 manifest。

[回读与图片清单](evidence/2026-11-22-sprint-6/fifth-native-readback/manifest.json)保存九份派生回读、一份实际 Issue 跟踪回执、各自 hash 和四张原图出处；[独立审查记录](2026-11-22-sprint-6-fifth-native-review.md)明确保留当前 DPR 阻塞，未据其他绿色结果声明 ready。

当前 PR 的 CI 与实际 DCO App check 成功；`3801353` 的 Vercel provider commit status 也已实际转为 success。先前 quota 错误保留为旧状态。当前连接读取 deployment Git-source 元数据返回 403，未扩大权限，因此 provider status 不升级为独立验证的部署 source metadata 或完整 deployed journey。

修复、审查与后续验收继续按原条件推进。完整 Bootstrap / Liquid 逐 part、Apple 参考接受、原 120 Hz / 10 ms、物理输入 / AT、Compiler / 非 Web 条件没有删除。用户确认的真实 Harness 消费者为 [shenko](https://github.com/cyjin-yl/shenko)，另有 [OpenGreendam/verdant](https://github.com/OpenGreendam/verdant)；本 Sprint 6 分支只读其 source pins，没有执行 App 升级或冒充其他 Sprint 已有的真实消费者运行。
