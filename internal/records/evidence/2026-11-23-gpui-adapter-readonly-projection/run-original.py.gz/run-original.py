from pathlib import Path
import os,subprocess,json,hashlib,datetime,traceback
root=Path('/tank/shared/projects/proto-ui-agent/sprint5-adapter-readonly-75d5e28a')
ops=root.with_name(root.name+'-ops');ops.mkdir(exist_ok=True)
tmp=Path('/tank/shared/projects/s5art75d5');tmp.mkdir(exist_ok=True)
env={**os.environ,'PATH':'/home/ezra/.cargo/bin:'+os.environ['PATH'],'RUSTUP_TOOLCHAIN':'1.98.1','CARGO_BUILD_JOBS':'1','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_TARGET_DIR':'/tank/shared/projects/proto-ui-agent/s5-adapter-readonly-target75d5','TMPDIR':str(tmp)}
paths=['native/gpui/crates/proto-ui-gpui/src/a11y.rs','native/gpui/crates/proto-ui-gpui/src/host.rs','native/gpui/crates/proto-ui-gpui/tests/a11y_projection.rs','native/gpui/fixtures/base-checkbox-session.json','native/gpui/Cargo.lock','native/gpui/Cargo.toml']
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def hashes():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
status={'state':'running','startedAt':now(),'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'before':hashes(),'commands':[],'environment':{k:env[k] for k in ['RUSTUP_TOOLCHAIN','CARGO_BUILD_JOBS','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','CARGO_TARGET_DIR','TMPDIR']}}
def save():(ops/'original-status.json').write_text(json.dumps(status,indent=2)+'\n')
def run(name,cmd,timeout):
 item={'name':name,'command':cmd,'startedAt':now()};status['commands'].append(item);save()
 with (ops/(name+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 item.update({'exitCode':r.returncode,'finishedAt':now()});save();return r.returncode
try:
 assert status['source']=='e18a30d4065111a5794a2aea524564e31678b911'
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
 assert run('rust-toolchain',['/home/ezra/.cargo/bin/rustc','--version','--verbose'],15)==0
 assert run('cargo-toolchain',['/home/ezra/.cargo/bin/cargo','--version'],15)==0
 code=run('original-a11y-projection',['/home/ezra/.cargo/bin/cargo','test','--locked','--manifest-path','native/gpui/Cargo.toml','-p','proto-ui-gpui','--test','a11y_projection','--','--test-threads=1'],1800)
 raw=(ops/'original-a11y-projection.log').read_text()
 status['actualTestExit']=code
 assert code==101,code
 assert 'test result: FAILED. 13 passed; 1 failed; 0 ignored;' in raw,'Original 13/1 failure was not reached'
 assert 'the_recorded_checkbox_is_a_checkbox_unchecked_checked_or_mixed' in raw
 assert 'State { name: "readOnly", value: Bool(false) }' in raw
 status['after']=hashes();assert status['after']==status['before']
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
 status.update({'state':'expected-rejection-observed','finishedAt':now()})
except Exception as e:status.update({'state':'failed','error':str(e),'trace':traceback.format_exc(),'after':hashes(),'finishedAt':now()})
save()
