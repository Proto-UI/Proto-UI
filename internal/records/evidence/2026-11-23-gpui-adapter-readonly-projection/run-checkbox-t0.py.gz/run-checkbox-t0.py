from pathlib import Path
import os,subprocess,json,hashlib,datetime,traceback
root=Path('/tank/shared/projects/proto-ui-agent/sprint5-adapter-readonly-75d5e28a')
ops=root.with_name(root.name+'-ops')
env={**os.environ,'PATH':'/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:/home/ezra/.cargo/bin:'+os.environ['PATH'],'RUSTUP_TOOLCHAIN':'1.98.1','CARGO_BUILD_JOBS':'1','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_TARGET_DIR':'/tank/shared/projects/proto-ui-agent/s5-adapter-readonly-target75d5','TMPDIR':'/tank/shared/projects/proto-ui-agent/s5at75d5'}
paths=list(json.loads((ops/'candidate-final-status.json').read_text())['after'])+['pnpm-lock.yaml','package.json','native/gpui/crates/proto-ui-gpui/tests/checkbox_t0.rs']
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def hashes():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
status={'state':'running','startedAt':now(),'sourceParent':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'before':hashes(),'commands':[]}
def save():(ops/'checkbox-t0-status.json').write_text(json.dumps(status,indent=2)+'\n')
def run(name,cmd,timeout):
 item={'name':name,'command':cmd,'startedAt':now()};status['commands'].append(item);save()
 with (ops/(name+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 item.update({'exitCode':r.returncode,'finishedAt':now()});save()
 if r.returncode!=0:raise RuntimeError(name+' exited '+str(r.returncode))
 return (ops/(name+'.log')).read_text()
try:
 run('install-frozen',['corepack','pnpm@10.32.1','install','--frozen-lockfile'],600)
 raw=run('candidate-checkbox-t0',['/home/ezra/.cargo/bin/cargo','test','--locked','--manifest-path','native/gpui/Cargo.toml','-p','proto-ui-gpui','--test','checkbox_t0','--','--ignored','--test-threads=1'],600)
 assert 'test result: ok. 6 passed; 0 failed; 0 ignored;' in raw,'Expected the six actual Checkbox T0 cases'
 status['after']=hashes();assert status['after']==status['before']
 status['gitStatus']=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
 assert set(subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines())==set(paths[:3])
 status.update({'state':'validated','passed':6,'failed':0,'ignored':0,'finishedAt':now()})
except Exception as e:status.update({'state':'failed','error':str(e),'trace':traceback.format_exc(),'after':hashes(),'finishedAt':now()})
save()
