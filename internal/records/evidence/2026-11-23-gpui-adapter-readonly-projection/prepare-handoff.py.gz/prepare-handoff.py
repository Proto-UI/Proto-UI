from pathlib import Path
import json,hashlib,subprocess
root=Path('/tank/shared/projects/proto-ui-agent/sprint5-adapter-readonly-75d5e28a');ops=root.with_name(root.name+'-ops')
authority={
 'scope':'PR #1738: GPUI Adapter boolean readOnly accessibility projection',
 'executionMode':'human-assisted','executionModeSource':'current-user',
 'owner':'native/gpui/crates/proto-ui-gpui',
 'authority':[
  {'path':'spec/contracts/C-A11Y-0001.yaml','status':'draft','criteria':['C-A11Y-0001-DOMAIN-BOUNDARY','C-A11Y-0001-F','C-A11Y-0001-G'],'meaning':'The Adapter projects host-supported semantic facts; accessibility projection does not own focus, activation policy, or event routing.'},
  {'path':'spec/modules/M-A11Y-0001.yaml','status':'draft','meaning':'A11y retains semantic object IR and delegates host projection.'},
  {'path':'spec/host-caps/HC-A11Y-0001.yaml','status':'draft','criteria':['HC-A11Y-0001-A','HC-A11Y-0001-B'],'meaning':'Complete IR reaches the Adapter without requiring identical native support across all hosts.'},
  {'path':'spec/prototypes/P-BASE-CHECKBOX.yaml','status':'draft','criteria':['P-BASE-CHECKBOX-FORM-INTEGRATION-DEFERRED'],'meaning':'Existing Checkbox readOnly preserves focus; the portable Prototype remains the checked/mixed and activation owner.'}
 ],
 'realizations':[
  'packages/prototypes/base/src/checkbox/root.proto.ts: bool readOnly with false default, accessible.state(readOnly), existing activation guard.',
  'native/gpui/crates/proto-ui-gpui/src/a11y.rs: finite explicit state mapping and residual diagnostics.',
  'native/gpui/crates/proto-ui-gpui/src/host.rs: existing Stateful<Div> wrapper delegates layout/input and writes AccessKit state.',
  'packages/compiler/src/gpui-native-a11y.ts: already uses set_read_only/clear_read_only on the same native Node boundary.',
  'GPUI pin 62e5991dd0f0c8a3af8d5e7e9c4652490d468db8; locked AccessKit 0.24.1 supplies set_read_only/clear_read_only/is_read_only.'
 ],
 'expectedBehavior':[
  'Only exact readOnly with a JSON Boolean maps; absence remains None and unsupported types/keys remain diagnostics.',
  'True sets and false clears the actual AccessKit Node flag after delegating the ordinary element projection.',
  'Checked/unchecked/mixed, disabled, role, label, and advertised activation are preserved.',
  'The original official Checkbox fixture and existing 14 projection assertions remain intact.'
 ],
 'exclusions':['No spec lifecycle promotion','No change to Checkbox business semantics or official generated fixtures','No physical assistive-technology or macOS platform acceptance claim','No unsupported role, action, relation, or state admission'],
 'hostedReproduction':{'head':'db747e1b81cbbfaf2b37dd8af3de48108f036a04','run':45228171867,'job':137880234047,'url':'https://github.com/Proto-UI/Proto-UI/actions/runs/45228171867/job/137880234047'}
}
(ops/'authority-map.json').write_text(json.dumps(authority,indent=2)+'\n')
authorization={'executionMode':'human-assisted','executionModeSource':'current-user','userGoal':'可以继续推进让更多变成 ready 吗','delegatedScope':'Repair the newly observed Adapter readOnly failure in an isolated e18 worktree; retain original assertions and generated fixture; preserve true/false node mapping, checked/mixed and unsupported boundaries. Produce an independently reviewed normal signed-off commit.','allowed':['Local reversible edits','Real source-bound tests','Evidence archival','Normal signed-off commit'],'excluded':['Merge or release','Force push','Fabricated review approval','Weakening CI or assertions','Modifying root native candidate files'],'source':'Current parent-agent task /root to /root/sprint5_ready, continuing the user-authorized portfolio.'}
(ops/'implementation-authorization.json').write_text(json.dumps(authorization,indent=2)+'\n')
def artifact(kind,name,result=None):
 p=ops/name;v={'type':kind,'reference':str(p),'digest':'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()}
 if result:v['result']=result
 return v
handoff={'schemaVersion':2,'kind':'proto-ui.skill-handoff','entrypoint':'development','executionMode':'human-assisted','executionModeSource':'current-user','fromId':'pui-regression','nextSkillId':'pui-validate','outcome':'completed','binding':{'repositoryId':'github.com:Proto-UI/Proto-UI','scopeId':'pr-1738-adapter-readonly','headSha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'reviewInputDigest':None},'artifacts':[artifact('authority-map','authority-map.json'),artifact('implementation-authorization','implementation-authorization.json'),artifact('candidate-change','candidate.patch'),artifact('reproduction','original-status.json','failed'),artifact('evidence-report','candidate-final-status.json','passed')],'humanGates':[],'notes':['The binding head is the clean parent of the patch; the candidate artifact digest and per-file hashes bind the uncommitted three-file source exactly.','The retained original source test reports 13 passed / 1 failed, the candidate reports 17/17 projections and 2/2 Node controls.','Default workspace command exited 0: 263 passed / 45 pre-existing ignored. The initial collector incorrectly assumed no ignored tests; its failure is preserved separately.','Official Checkbox T0 six-case validation is in progress in a separate receipt; no unexecuted case is counted passed.','Technical peer review is separate from GitHub APPROVED status and publication/integration.']}
(ops/'regression-handoff.json').write_text(json.dumps(handoff,indent=2)+'\n')
print(str(ops/'regression-handoff.json'))
