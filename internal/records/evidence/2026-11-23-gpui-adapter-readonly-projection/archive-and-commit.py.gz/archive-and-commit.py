from pathlib import Path
import os,json,hashlib,gzip,subprocess,datetime,traceback
root=Path('/tank/shared/projects/proto-ui-agent/sprint5-adapter-readonly-75d5e28a');ops=root.with_name(root.name+'-ops')
stem='2026-11-23-gpui-adapter-readonly-projection'
record=root/'internal/records'/f'{stem}.md';evidence=root/'internal/records/evidence'/stem
env={**os.environ,'PATH':'/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:/home/ezra/.cargo/bin:'+os.environ['PATH'],'TMPDIR':'/tank/shared/projects/proto-ui-agent/s5at75d5'}
source=['native/gpui/crates/proto-ui-gpui/src/a11y.rs','native/gpui/crates/proto-ui-gpui/src/host.rs','native/gpui/crates/proto-ui-gpui/tests/a11y_projection.rs']
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(data):return hashlib.sha256(data).hexdigest()
status={'state':'running','startedAt':now(),'commands':[]}
def save():(ops/'archive-commit-status.json').write_text(json.dumps(status,indent=2)+'\n')
def run(name,cmd,timeout=180):
 item={'name':name,'command':cmd,'startedAt':now()};status['commands'].append(item);save()
 with (ops/(name+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 item.update({'exitCode':r.returncode,'finishedAt':now()});save()
 if r.returncode:raise RuntimeError(name+' exited '+str(r.returncode))
 return (ops/(name+'.log')).read_text()
try:
 parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 assert parent=='e18a30d4065111a5794a2aea524564e31678b911'
 assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).strip()
 assert set(subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines())==set(source)
 final=json.loads((ops/'validation-report.json').read_text());t0=json.loads((ops/'checkbox-t0-status.json').read_text())
 assert final['result']=='passed' and t0['state']=='validated'
 for p,v in t0['after'].items():assert sha((root/p).read_bytes())==v
 assert not record.exists() and not evidence.exists()
 evidence.mkdir(parents=True)
 manifest={'schemaVersion':1,'scope':'GPUI Adapter boolean readOnly projection','parent':parent,'publicFailureHead':'db747e1b81cbbfaf2b37dd8af3de48108f036a04','publicFailureJob':137880234047,'sourceHashes':final['sourceHashes'],'checks':final['checks'],'files':[]}
 def add(name,data,origin):
  packed=gzip.compress(data,compresslevel=9,mtime=0);assert gzip.decompress(packed)==data
  out=evidence/(name+'.gz');out.write_bytes(packed)
  manifest['files'].append({'path':out.name,'origin':origin,'rawBytes':len(data),'rawSha256':sha(data),'gzipBytes':len(packed),'gzipSha256':sha(packed)})
 files=['hosted-db747-adapter-job137880234047.log','run-original.py','original-launcher.log','run-original-owned-tmp.py','rust-toolchain.log','cargo-toolchain.log','original-status.json','original-a11y-projection.log','prepared-candidate.patch','candidate.patch','run-candidate.py','candidate-status.json','candidate-final-status.json','candidate-rustfmt.log','format-only.patch','candidate-rustfmt-check.log','candidate-diff-check.log','candidate-a11y-projection.log','candidate-accesskit-nodes.log','candidate-workspace.log','run-checkbox-t0.py','install-frozen.log','candidate-checkbox-t0.log','checkbox-t0-status.json','authority-map.json','implementation-authorization.json','regression-handoff.json','regression-handoff-validation.log','validation-report.json','validation-handoff.json','validation-handoff-check.log','prepare-handoff.py','prepare-validation.py']
 for name in files:add(name,(ops/name).read_bytes(),'ops/'+name)
 for p in source:
  original=subprocess.check_output(['git','show',parent+':'+p],cwd=root)
  public=subprocess.check_output(['git','show','db747e1b81cbbfaf2b37dd8af3de48108f036a04:'+p],cwd=root)
  assert original==public
  label=p.split('/')[-1]
  add('original-'+label,original,parent+':'+p)
  add('candidate-'+label,(root/p).read_bytes(),'candidate/'+p)
 for p in ['native/gpui/fixtures/base-checkbox-session.json','native/gpui/crates/proto-ui-gpui/tests/checkbox_t0.rs']:
  data=(root/p).read_bytes();assert data==subprocess.check_output(['git','show',parent+':'+p],cwd=root)
  add('unchanged-'+p.split('/')[-1],data,p)
 add('archive-and-commit.py',Path(__file__).read_bytes(),'ops/archive-and-commit.py')
 (evidence/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 record.write_bytes((ops/'prepared-record.md').read_bytes())
 run('record-format',['corepack','pnpm@10.32.1','exec','prettier','--write',str(record),str(evidence/'manifest.json')])
 run('record-format-check',['corepack','pnpm@10.32.1','exec','prettier','--check',str(record),str(evidence/'manifest.json')])
 run('final-diff-check',['git','diff','--check'])
 for p,v in t0['after'].items():assert sha((root/p).read_bytes())==v
 readback=json.loads((evidence/'manifest.json').read_text())
 for item in readback['files']:
  packed=(evidence/item['path']).read_bytes();assert sha(packed)==item['gzipSha256'];assert sha(gzip.decompress(packed))==item['rawSha256']
 paths=source+[str(record.relative_to(root)),str(evidence.relative_to(root))]
 run('stage',['git','add','--',*paths])
 run('staged-diff-check',['git','diff','--cached','--check'])
 staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).splitlines()
 assert all(p in source or p==str(record.relative_to(root)) or p.startswith(str(evidence.relative_to(root))+'/') for p in staged)
 run('signedoff-commit',['git','commit','--signoff','-m','fix(gpui): project boolean readOnly accessibility state'],300)
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 body=subprocess.check_output(['git','show','-s','--format=%B','HEAD'],cwd=root,text=True)
 assert 'Signed-off-by: ' in body
 porcelain=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True);assert not porcelain.strip(),porcelain
 assert subprocess.check_output(['git','rev-parse','HEAD^'],cwd=root,text=True).strip()==parent
 for p,v in t0['after'].items():assert sha((root/p).read_bytes())==v
 status.update({'state':'committed','head':head,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),'parent':parent,'archiveCount':len(readback['files']),'record':str(record.relative_to(root)),'manifest':str((evidence/'manifest.json').relative_to(root)),'hasSignoff':True,'clean':True,'sourceHashes':final['sourceHashes'],'finishedAt':now()})
except Exception as e:status.update({'state':'failed','error':str(e),'trace':traceback.format_exc(),'finishedAt':now()})
save()
