from pathlib import Path
import os,subprocess,json,hashlib,datetime,traceback,re,difflib
root=Path('/tank/shared/projects/proto-ui-agent/sprint5-adapter-readonly-75d5e28a')
ops=root.with_name(root.name+'-ops')
tmp=Path('/tank/shared/projects/proto-ui-agent/s5at75d5')
env={**os.environ,'PATH':'/home/ezra/.cargo/bin:'+os.environ['PATH'],'RUSTUP_TOOLCHAIN':'1.98.1','CARGO_BUILD_JOBS':'1','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_TARGET_DIR':'/tank/shared/projects/proto-ui-agent/s5-adapter-readonly-target75d5','TMPDIR':str(tmp)}
paths=['native/gpui/crates/proto-ui-gpui/src/a11y.rs','native/gpui/crates/proto-ui-gpui/src/host.rs','native/gpui/crates/proto-ui-gpui/tests/a11y_projection.rs']
protected=['native/gpui/fixtures/base-checkbox-session.json','native/gpui/Cargo.lock','native/gpui/Cargo.toml']
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def hashes(ps):return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ps}
status={'state':'running','startedAt':now(),'sourceParent':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'preparedHashes':hashes(paths),'protectedBefore':hashes(protected),'commands':[],'environment':{k:env[k] for k in ['RUSTUP_TOOLCHAIN','CARGO_BUILD_JOBS','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','CARGO_TARGET_DIR','TMPDIR']}}
def save():(ops/'candidate-status.json').write_text(json.dumps(status,indent=2)+'\n')
def run(name,cmd,timeout):
 item={'name':name,'command':cmd,'startedAt':now()};status['commands'].append(item);save()
 with (ops/(name+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 item.update({'exitCode':r.returncode,'finishedAt':now()});save()
 if r.returncode!=0:raise RuntimeError(name+' exited '+str(r.returncode))
 return (ops/(name+'.log')).read_text()
try:
 original=json.loads((ops/'original-status.json').read_text())
 assert original['state']=='expected-rejection-observed'
 assert status['sourceParent']=='e18a30d4065111a5794a2aea524564e31678b911'
 assert status['protectedBefore']=={p:original['after'][p] for p in protected}
 prepared=json.loads((ops/'prepared-candidate.json').read_text())['files']
 assert all((root/p).read_text()==prepared[p] for p in paths)
 run('candidate-rustfmt',['/home/ezra/.cargo/bin/rustfmt','--edition','2021',*paths],30)
 fmt=''.join(''.join(difflib.unified_diff(prepared[p].splitlines(True),(root/p).read_text().splitlines(True),fromfile='prepared/'+p,tofile='formatted/'+p)) for p in paths)
 (ops/'format-only.patch').write_text(fmt)
 status['before']=hashes(paths+protected);save()
 (ops/'candidate.patch').write_bytes(subprocess.check_output(['git','diff','--no-ext-diff','--',*paths],cwd=root))
 run('candidate-diff-check',['git','diff','--check'],30)
 run('candidate-rustfmt-check',['/home/ezra/.cargo/bin/rustfmt','--check','--edition','2021',*paths],30)
 common=['/home/ezra/.cargo/bin/cargo','test','--locked','--manifest-path','native/gpui/Cargo.toml']
 projection=run('candidate-a11y-projection',common+['-p','proto-ui-gpui','--test','a11y_projection','--','--test-threads=1'],1800)
 assert 'test result: ok. 17 passed; 0 failed; 0 ignored;' in projection
 nodes=run('candidate-accesskit-nodes',common+['-p','proto-ui-gpui','--lib','host::a11y_state_tests','--','--test-threads=1'],1800)
 assert 'test result: ok. 2 passed; 0 failed; 0 ignored;' in nodes
 workspace=run('candidate-workspace',common+['--workspace','--','--test-threads=1'],1800)
 summaries=[{'passed':int(m[0]),'failed':int(m[1]),'ignored':int(m[2]),'measured':int(m[3]),'filtered':int(m[4])} for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',workspace)]
 assert summaries,'No workspace test summaries'
 assert all(s['failed']==0 and s['ignored']==0 for s in summaries),summaries
 status['workspaceResults']=summaries
 status['workspacePassed']=sum(s['passed'] for s in summaries)
 status['after']=hashes(paths+protected)
 assert status['after']==status['before']
 status['gitStatus']=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
 assert set(subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines())==set(paths)
 status.update({'state':'validated','finishedAt':now()})
except Exception as e:
 status.update({'state':'failed','error':str(e),'trace':traceback.format_exc(),'after':hashes(paths+protected),'finishedAt':now()})
save()
