from pathlib import Path
import subprocess,os,json,hashlib,time
w=Path('/tank/shared/projects/proto-ui-agent/sprint6-0246');r=w/'repo';out=w/'evidence/integrate-text-r1';out.mkdir(parents=True,exist_ok=False)
env=os.environ.copy();env['PATH']=str(w/'toolchain/node_modules/node-linux-x64/bin')+os.pathsep+str(w/'toolchain/node_modules/.bin')+os.pathsep+env['PATH'];env['TMPDIR']=str(w/'tmp');env['COREPACK_HOME']=str(w/'corepack-cache');env['GIT_OPTIONAL_LOCKS']='0'
before='25dddc948f0a05ac8a02bb486cf833d5e90ffb08';target='1fda38f3660470128bb12c991a0d2877f7fa5d08';branch='sprint6/bootstrap-liquid-delivery-20261122'
def cmd(args):return subprocess.check_output(args,cwd=r,env=env,text=True).strip()
assert cmd(['git','rev-parse','HEAD'])==before
pr=json.loads(cmd(['gh','api','repos/Proto-UI/Proto-UI/pulls/1712']))
assert pr['state']=='open' and pr['head']['sha']==target and pr['head']['ref']==branch
files=sorted(set(cmd(['git','diff','HEAD','--name-only']).splitlines())|set(cmd(['git','ls-files','--others','--exclude-standard']).splitlines()))
def hashes():return {p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in files}
original=hashes();(out/'source-before.json').write_text(json.dumps(original,indent=2))
(out/'worktree-before.patch').write_bytes(subprocess.check_output(['git','diff','HEAD','--binary'],cwd=r,env=env))
with (out/'fetch.log').open('w') as log:
 result=subprocess.run(['git','fetch','origin','refs/heads/'+branch],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0
assert cmd(['git','rev-parse','FETCH_HEAD'])==target
assert cmd(['git','rev-parse',target+'^'])==before
incoming=set(cmd(['git','diff','--name-only',before,target]).splitlines());assert not incoming.intersection(files),sorted(incoming.intersection(files))
(out/'incoming.json').write_text(json.dumps(sorted(incoming),indent=2))
with (out/'fast-forward.log').open('w') as log:
 result=subprocess.run(['git','merge','--ff-only',target],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'fast-forward.exit').write_text(str(result.returncode)+'\n')
assert result.returncode==0,'Inspect HEAD/status before any retry'
assert cmd(['git','rev-parse','HEAD'])==target and hashes()==original
(out/'source-after.json').write_text(json.dumps(hashes(),indent=2));(out/'complete.json').write_text(json.dumps({'before':before,'after':target,'incomingPaths':len(incoming),'preservedCandidatePaths':len(files),'byteIdenticalCandidate':True},indent=2));print('Fast-forward preserved all',len(files),'candidate files at',target,flush=True)
