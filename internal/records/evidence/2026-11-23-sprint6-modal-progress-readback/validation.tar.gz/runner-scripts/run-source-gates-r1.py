from pathlib import Path
import subprocess,os,json,time,hashlib
w=Path('/tank/shared/projects/proto-ui-agent/sprint6-0246');r=w/'repo';out=w/'evidence/source-gates-r1';out.mkdir(parents=True,exist_ok=False)
node=str(w/'toolchain/node_modules/node-linux-x64/bin/node');env=os.environ.copy();env['PATH']=str(w/'toolchain/node_modules/node-linux-x64/bin')+os.pathsep+str(w/'toolchain/node_modules/.bin')+os.pathsep+env['PATH'];env['TMPDIR']=str(w/'tmp');env['COREPACK_HOME']=str(w/'corepack-cache');env['GIT_OPTIONAL_LOCKS']='0';results=[]
def run(name,argv):
 started=time.time()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(argv,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':argv,'exitCode':p.returncode,'seconds':time.time()-started});(out/'summary.json').write_text(json.dumps(results,indent=2));(out/(name+'.exit')).write_text(str(p.returncode)+'\n');print(name,p.returncode,flush=True);return p.returncode
red=run('consumer-footer-negative-before',[node,'--test','--test-name-pattern=source finalizer rejects inflated consumer TAP footer','scripts/test/check-bootstrap-motion-evidence.test.mjs'])
assert red!=0,'The draft footer defect must be detected by the new control'
p=r/'.github/workflows/bootstrap-state-controls-evidence.yml';s=p.read_text();old='assert.ok(cases.length > 0 && cases.length <= 6);';assert s.count(old)==1
p.write_text(s.replace(old,"assert.equal(cases.length, 6, 'Require six executed consumer cases');"))
changed=subprocess.check_output(['git','diff','--name-only','-z'],cwd=r,env=env).decode().split('\0');untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=r,env=env).decode().split('\0')
files=sorted(set(p for p in changed+untracked if p and Path(p).suffix in ['.ts','.mjs','.yml','.yaml','.md']))
assert run('format',[node,'node_modules/prettier/bin/prettier.cjs','--write',*files])==0
new=[p for p in untracked if p];subprocess.run(['git','add','-N','--',*new],cwd=r,env=env,check=True)
(out/'candidate-files.json').write_text(json.dumps({p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in files},indent=2))
run('source-and-motion-node-gates',[node,'--test','scripts/test/check-bootstrap-motion-evidence.test.mjs','scripts/test/bootstrap-state-controls-evidence.test.mjs','scripts/test/run-runtime-tests.test.mjs'])
run('ci-config-audit',[node,'--test','scripts/ci/test/ci-scheduling-policy.test.mjs','scripts/ci/test/cycle-job-inventory.test.mjs','scripts/ci/test/cycle-report.test.mjs','scripts/ci/test/release-source-ledger-checkpoints.test.mjs'])
run('schedule-audit',[node,'scripts/ci/check-ci-schedule.mjs'])
syntax="""import fs from 'node:fs';import {parse} from 'yaml';import{spawnSync}from'node:child_process';const wf=parse(fs.readFileSync('.github/workflows/bootstrap-state-controls-evidence.yml','utf8'));let count=0;for(const[name,job]of Object.entries(wf.jobs)){for(const step of job.steps??[]){if(!step.run)continue;const script=step.run.replace(/\\$\\{\\{[\\s\\S]*?\\}\\}/g,'synthetic');const result=spawnSync('bash',['-n'],{input:script,encoding:'utf8'});if(result.status!==0)throw new Error(name+'/'+step.name+': '+result.stderr);count++;}}console.log('Parsed '+Object.keys(wf.jobs).length+' jobs and '+count+' Bash steps');"""
run('workflow-syntax',[node,'--input-type=module','-e',syntax])
run('spec-graph',[node,'node_modules/vitest/vitest.mjs','run','packages/spec/graph/test','packages/spec/fixtures/test/prototype-inheritance-schema.test.ts','packages/spec/fixtures/test/adapter-profile-schema.test.ts','packages/spec/fixtures/test/feedback-style-authoring.test.ts','packages/spec/fixtures/test/feedback-style-runtime-patch.test.ts','--pool=forks','--maxWorkers=1','--minWorkers=1','--no-file-parallelism','--reporter=json','--outputFile='+str(out/'spec-graph.json')])
run('spec-authoring',[node,'--import','tsx','scripts/spec/check-lifecycle-authoring.mjs','--base','25dddc948f0a05ac8a02bb486cf833d5e90ffb08'])
(out/'complete.txt').write_text('completed\n')
