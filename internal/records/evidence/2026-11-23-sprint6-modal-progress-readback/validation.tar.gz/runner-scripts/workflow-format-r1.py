from pathlib import Path
import subprocess,os,json,hashlib,re,time
w=Path('/tank/shared/projects/proto-ui-agent/sprint6-0246');r=w/'repo';out=w/'evidence/workflow-format-r1';out.mkdir(parents=True,exist_ok=False)
node=str(w/'toolchain/node_modules/node-linux-x64/bin/node');env=os.environ.copy();env['PATH']=str(w/'toolchain/node_modules/node-linux-x64/bin')+os.pathsep+str(w/'toolchain/node_modules/.bin')+os.pathsep+env['PATH'];env['TMPDIR']=str(w/'tmp');env['COREPACK_HOME']=str(w/'corepack-cache');env['GIT_OPTIONAL_LOCKS']='0'
def cmd(args):return subprocess.check_output(args,cwd=r,env=env,text=True).strip()
assert cmd(['git','rev-parse','HEAD'])=='ccde9d192b2dcb7f51b9ec417435fc14b3fd7a65'
p=r/'.github/workflows/bootstrap-state-controls-evidence.yml';before=p.read_text();assert hashlib.sha256(p.read_bytes()).hexdigest()=='b6268e93d7ab441804b0750d9b79463d681d0d6416af40243811d45f78daf665'
(out/'before.yml').write_text(before);m=re.search(r'          SOURCE_STEP_OUTCOMES: >-\n(?P<body>[\s\S]*?)\n        run: \|',before);assert m
data=json.loads(m.group('body'));scalar=json.dumps(data,separators=(',',':'));assert "'" not in scalar
after=before[:m.start()]+"          SOURCE_STEP_OUTCOMES: '"+scalar+"'\n        run: |"+before[m.end():];p.write_text(after)
def run(name,argv):
 with (out/(name+'.log')).open('w') as log:res=subprocess.run(argv,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/(name+'.exit')).write_text(str(res.returncode)+'\n');print(name,res.returncode,flush=True);assert res.returncode==0
for i in range(2):
 run('format-'+str(i+1),[node,'node_modules/prettier/bin/prettier.cjs','--write',str(p)])
 h=hashlib.sha256(p.read_bytes()).hexdigest()
 if i==0:first=h
 else:assert h==first,'Formatter must be idempotent before publication'
equivalence="""import fs from 'node:fs';import{parse}from'yaml';import assert from'node:assert/strict';const old=parse(fs.readFileSync(process.argv[1],'utf8'));const now=parse(fs.readFileSync(process.argv[2],'utf8'));for(const wf of[old,now]){const step=wf.jobs['source-validation'].steps.find(s=>s.id==='source_results');step.env.SOURCE_STEP_OUTCOMES=JSON.parse(step.env.SOURCE_STEP_OUTCOMES)}assert.deepEqual(now,old);console.log('Entire parsed workflow equal after normalizing the exact JSON outcome scalar');"""
run('yaml-equivalence',[node,'--input-type=module','-e',equivalence,str(out/'before.yml'),str(p)])
run('source-motion-node-gates',[node,'--test','scripts/test/check-bootstrap-motion-evidence.test.mjs','scripts/test/bootstrap-state-controls-evidence.test.mjs','scripts/test/run-runtime-tests.test.mjs'])
(out/'after.yml').write_bytes(p.read_bytes());(out/'complete.json').write_text(json.dumps({'head':'ccde9d192b2dcb7f51b9ec417435fc14b3fd7a65','sha256':first,'idempotent':True,'semanticWorkflowEqual':True},indent=2))
