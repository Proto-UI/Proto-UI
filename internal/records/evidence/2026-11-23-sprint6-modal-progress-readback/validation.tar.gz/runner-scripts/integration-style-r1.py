from pathlib import Path
import subprocess,os,json,time
w=Path('/tank/shared/projects/proto-ui-agent/sprint6-0246');r=w/'repo';out=w/'evidence/integration-style-r1';out.mkdir(parents=True,exist_ok=False)
node=str(w/'toolchain/node_modules/node-linux-x64/bin/node');env=os.environ.copy();env['PATH']=str(w/'toolchain/node_modules/node-linux-x64/bin')+os.pathsep+str(w/'toolchain/node_modules/.bin')+os.pathsep+env['PATH'];env['TMPDIR']=str(w/'tmp');env['COREPACK_HOME']=str(w/'corepack-cache');env['GIT_OPTIONAL_LOCKS']='0'
def g(*a):return subprocess.check_output(['git',*a],cwd=r,env=env,text=True).strip()
head=g('rev-parse','HEAD');assert head=='a6e16060a442a82ccac5b63e4a307b053c76f51c' and g('status','--porcelain=v1')==''
results=[]
for family in ['brutalist','draft-family']:
 for check in [False,True]:
  name=family+('-check' if check else '-generate');args=[node,'--import','tsx','scripts/styles/generate-'+family+'-style-tokens.ts']+(['--check'] if check else [])
  started=time.time()
  with (out/(name+'.log')).open('w') as log:
   try:p=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300);code=p.returncode
   except subprocess.TimeoutExpired:code=124
  results.append({'name':name,'command':args,'exitCode':code,'seconds':time.time()-started,'wrapperTimeoutSeconds':300});(out/(name+'.exit')).write_text(str(code)+'\n');(out/'summary.json').write_text(json.dumps(results,indent=2));print(name,code,flush=True)
  if code:raise SystemExit('Generation did not complete; retain output and inspect.')
after=g('status','--porcelain=v1');(out/'diff.patch').write_text(g('diff','--binary'));(out/'complete.json').write_text(json.dumps({'head':head,'afterStatus':after,'generatedTreeUnchanged':after==''},indent=2));print('generation closure',repr(after),flush=True)
