from pathlib import Path
import subprocess,json,os,time,hashlib,urllib.parse
w=Path('/tank/shared/projects/proto-ui-agent/sprint6-0246');r=w/'repo';out=w/'evidence/source-publication-r4';out.mkdir(parents=True,exist_ok=False)
node=str(w/'toolchain/node_modules/node-linux-x64/bin/node');env=os.environ.copy();env['PATH']=str(w/'toolchain/node_modules/node-linux-x64/bin')+os.pathsep+str(w/'toolchain/node_modules/.bin')+os.pathsep+env['PATH'];env['TMPDIR']=str(w/'tmp');env['COREPACK_HOME']=str(w/'corepack-cache');env['GIT_OPTIONAL_LOCKS']='0'
branch='sprint6/bootstrap-liquid-delivery-20261122';start='1fda38f3660470128bb12c991a0d2877f7fa5d08'
def cmd(args):
 return subprocess.check_output(args,cwd=r,env=env,text=True).strip()
def api(endpoint):
 return json.loads(cmd(['gh','api',endpoint]))
assert cmd(['git','branch','--show-current'])==branch
assert cmd(['git','rev-parse','HEAD'])==start
pr=api('repos/Proto-UI/Proto-UI/pulls/1712');actor=api('user')['login'];repo=api('repos/Proto-UI/Proto-UI')
assert pr['state']=='open' and pr['head']['sha']==start and pr['head']['ref']==branch
assert pr['head']['repo']['full_name']=='Proto-UI/Proto-UI' and repo['permissions'].get('push') is True
(out/'before.json').write_text(json.dumps({'actor':actor,'permissions':repo['permissions'],'pr':{k:pr[k] for k in ['number','state','draft','mergeable','mergeable_state','head','base','updated_at']},'branchRules':api('repos/Proto-UI/Proto-UI/rules/branches/'+urllib.parse.quote(branch,safe=''))},indent=2))
known=set(json.loads((w/'evidence/motion-final-r1/candidate-files.json').read_text()))
baseline='packages/spec/graph/test/shadcn-dropdown-evidence.test.ts'
changed=set(x for x in cmd(['git','diff','HEAD','--name-only']).splitlines() if x)
untracked=set(x for x in cmd(['git','ls-files','--others','--exclude-standard']).splitlines() if x)
assert changed|untracked <= known|{baseline}, sorted((changed|untracked)-(known|{baseline}))
# This checkout had no local identity. Preserve the user's global identity and
# attribute only this agent-authored work to Codex.
for key,value in [('user.name','Codex'),('user.email','codex@openai.com')]:
 local=subprocess.run(['git','config','--local','--get',key],cwd=r,text=True,capture_output=True)
 assert local.returncode!=0 or local.stdout.strip()==value,(key,local.stdout)
 cmd(['git','config','--local',key,value])
groups=[
 ('readback',['packages/adapters/base/src/material/program.ts','packages/adapters/base/test/web-material-program.test.ts'],
  'perf(material): reuse bounded RGBA readback storage\n\nRetain one grow-only backing store within the existing 4 MiB admission limit, while passing only the current exact-length view to GL and contrast scans. Preserve clear, loss and disposal release.\n\nActual old/new regression: 111 passed / 3 failed -> 114 passed / 0 failed. This does not claim a physical frame-budget or zero per-frame object allocations.\n\nAuthored by Codex for the current user-directed Sprint 6 continuation.'),
 ('motion',sorted(known-{'packages/adapters/base/src/material/program.ts','packages/adapters/base/test/web-material-program.test.ts'}),
  'feat(feedback): realize bounded Bootstrap modal and progress motion\n\nAdd typed containing-block top, per-channel presence easing, exact numeric State width targets and source-Web adoption. Repair reentrant width leases and the Portal closed handoff without changing Base State ownership or terminal release ordering.\n\nAdd native Modal/Progress fixtures, explicit unsupported split rejection, strict 11-file / 129-assertion source-and-artifact gate, dedicated browser inventory and draft evidence mappings.\n\nOwnership negative controls: 43 assertions, 12 failures against old production code; repaired related suites: 129/129. Source/motion gate and runtime-inventory checks: 178/178; CI policy checks: 70/70. The real source finalizer also requires 40 graph assertions and six executed public draft consumers, with incomplete TAP negative controls. Final native execution remains pending clean-head CI after the local runner encountered setup I/O blockage; no skipped cases are credited. Local graph validation retained 37 passes and three original-budget timeouts; the Dropdown baseline assertion now passes.\n\nAuthored by Codex for the current user-directed Sprint 6 continuation.'),
 ('catalog-index',[baseline],
  'test(spec): locate Dropdown evidence by stable implementation id\n\nThe unchanged baseline test reads implementations[0] after an earlier catalog addition reordered that list. Select prototypes-shadcn-dropdown-item-contract explicitly and retain every original bilingual evidence-boundary assertion.\n\nAuthored by Codex for the current user-directed Sprint 6 continuation.')
]
assert json.loads((w/'evidence/integrate-text-r1/complete.json').read_text())['byteIdenticalCandidate'] is True
receipts=[]
for name,files,message in groups:
 assert files and all((r/p).is_file() for p in files)
 cmd(['git','add','--',*files]);head=cmd(['git','rev-parse','HEAD']);tree=cmd(['git','write-tree'])
 msg=out/(name+'-message.txt');msg.write_text(message+'\n')
 argv=[node,'scripts/agent-operations/agent-publish.mjs','commit','--mode','human-assisted','--mode-source','current-user','--authorization','explicit-current-user','--repository','github.com:Proto-UI/Proto-UI','--message-file',str(msg),'--branch',branch,'--expected-head',head,'--expected-tree',tree]
 with (out/(name+'-publisher.log')).open('w') as log:
  result=subprocess.run(argv,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/(name+'-publisher.exit')).write_text(str(result.returncode)+'\n')
 if result.returncode:raise SystemExit('Publisher did not report success; reconcile HEAD before retry.')
 actual=cmd(['git','rev-parse','HEAD']);assert cmd(['git','rev-parse',actual+'^'])==head and cmd(['git','rev-parse',actual+'^{tree}'])==tree
 receipts.append({'slice':name,'parent':head,'head':actual,'tree':tree,'files':files})
 (out/'commits.json').write_text(json.dumps(receipts,indent=2));print('committed',name,actual,flush=True)
assert cmd(['git','status','--porcelain=v1'])==''
fresh=api('repos/Proto-UI/Proto-UI/pulls/1712');permission=api('repos/Proto-UI/Proto-UI/collaborators/'+actor+'/permission')
assert fresh['state']=='open' and fresh['head']['sha']==start and fresh['head']['ref']==branch
assert permission['permission'] in ['write','maintain','admin'] or permission.get('role_name') in ['write','maintain','admin']
(out/'pre-push.json').write_text(json.dumps({'prHead':fresh['head']['sha'],'base':fresh['base']['sha'],'permission':permission,'target':branch,'localHead':receipts[-1]['head']},indent=2))
with (out/'push.log').open('w') as log: result=subprocess.run(['git','push','origin','HEAD:refs/heads/'+branch],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'push.exit').write_text(str(result.returncode)+'\n')
if result.returncode:raise SystemExit('Push did not report success; reconcile the remote before retry.')
after=api('repos/Proto-UI/Proto-UI/pulls/1712');assert after['head']['sha']==receipts[-1]['head']
(out/'readback.json').write_text(json.dumps({'head':after['head']['sha'],'base':after['base']['sha'],'draft':after['draft'],'state':after['state'],'mergeable_state':after['mergeable_state']},indent=2))
(out/'complete.txt').write_text('published and read back\n');print('pushed',after['head']['sha'],flush=True)
