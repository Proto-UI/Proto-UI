from pathlib import Path
import subprocess,os,json,hashlib,time
w=Path('/tank/shared/projects/proto-ui-agent/sprint6-0246');r=w/'repo';out=w/'evidence/public-ci-gates-r1';out.mkdir(parents=True,exist_ok=False)
node=str(w/'toolchain/node_modules/node-linux-x64/bin/node');env=os.environ.copy();env['PATH']=str(w/'toolchain/node_modules/node-linux-x64/bin')+os.pathsep+str(w/'toolchain/node_modules/.bin')+os.pathsep+env['PATH'];env['TMPDIR']=str(w/'tmp');env['COREPACK_HOME']=str(w/'corepack-cache');env['GIT_OPTIONAL_LOCKS']='0'
def cmd(args):return subprocess.check_output(args,cwd=r,env=env,text=True).strip()
assert cmd(['git','rev-parse','HEAD'])=='a6e16060a442a82ccac5b63e4a307b053c76f51c'
assert cmd(['git','status','--porcelain=v1'])==''
raw=(w/'checkpoints/public-ci-packet-r1.json').read_bytes();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()=='1f45887543688915678e3242eeba272c6522608e'
packet=json.loads(raw);path=r/packet['targetWorkflow'];before=path.read_text();(out/'before-workflow.yml').write_text(before)
needle='on:\n  workflow_dispatch:\n  workflow_call:\n';assert before.count(needle)==1 and 'validate_public_packages' not in before and 'public-package-validation:' not in before
event='\n'.join('  '+line if line else '' for line in packet['eventInputsYaml'].splitlines() if not line.startswith('#'))+'\n'
path.write_text(before.replace(needle,'on:\n'+event).rstrip()+'\n'+packet['additionalJobYaml'])
files=[packet['targetWorkflow']]
for item in packet['files']:
 p=r/item['path'];assert not p.exists();p.write_text(item['content']);files.append(item['path'])
results=[]
def run(name,args):
 started=time.time()
 with (out/(name+'.log')).open('w') as log:res=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 result={'name':name,'command':args,'exitCode':res.returncode,'seconds':time.time()-started};results.append(result);(out/'summary.json').write_text(json.dumps(results,indent=2));(out/(name+'.exit')).write_text(str(res.returncode)+'\n');print(name,res.returncode,flush=True);return res.returncode
assert run('format-1',[node,'node_modules/prettier/bin/prettier.cjs','--write',*files])==0
first={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in files}
assert run('format-2',[node,'node_modules/prettier/bin/prettier.cjs','--write',*files])==0
assert first=={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in files},'Formatting must be stable'
cmd(['git','add','-N','--',*[p['path'] for p in packet['files']]])
for item in packet['files']:assert run('syntax-'+Path(item['path']).stem,[node,'--check',item['path']])==0
run('node-gates',[node,'--test','scripts/test/run-bootstrap-public-validation.test.mjs','scripts/test/check-bootstrap-motion-evidence.test.mjs','scripts/test/bootstrap-state-controls-evidence.test.mjs','scripts/test/run-runtime-tests.test.mjs'])
run('ci-config-audit',[node,'--test','scripts/ci/test/ci-scheduling-policy.test.mjs','scripts/ci/test/cycle-job-inventory.test.mjs','scripts/ci/test/cycle-report.test.mjs','scripts/ci/test/release-source-ledger-checkpoints.test.mjs'])
run('schedule-audit',[node,'scripts/ci/check-ci-schedule.mjs'])
syntax="""import fs from'node:fs';import{parse}from'yaml';import{spawnSync}from'node:child_process';import assert from'node:assert/strict';const wf=parse(fs.readFileSync('.github/workflows/bootstrap-state-controls-evidence.yml','utf8'));for(const event of['workflow_dispatch','workflow_call'])assert.deepEqual(wf.on[event].inputs.validate_public_packages,{description:'Run the canonical public package build and consumer gates',type:'boolean',required:false,default:false});const job=wf.jobs['public-package-validation'];assert.equal(job.if,'\u0024{{ inputs.validate_public_packages == true }}');assert.equal(job.strategy['fail-fast'],false);assert.deepEqual(job.strategy.matrix.include,[{group:'build',timeout:20},{group:'react',timeout:20},{group:'cli',timeout:15}]);let count=0;for(const[name,job]of Object.entries(wf.jobs)){for(const step of job.steps??[]){if(!step.run)continue;const script=step.run.replace(/\u0024\\{\\{[\\s\\S]*?\\}\\}/g,'synthetic');const result=spawnSync('bash',['-n'],{input:script,encoding:'utf8'});if(result.status!==0)throw new Error(name+'/'+step.name+': '+result.stderr);count++;}}console.log('Parsed '+Object.keys(wf.jobs).length+' job definitions and '+count+' Bash steps; explicit boolean input and 20/20/15 budgets verified');"""
run('workflow-syntax-and-selection',[node,'--input-type=module','-e',syntax])
cmd(['git','diff','--check']);(out/'source-hashes.json').write_text(json.dumps(first,indent=2));(out/'complete.json').write_text(json.dumps({'baseHead':'a6e16060a442a82ccac5b63e4a307b053c76f51c','packetBlob':'1f45887543688915678e3242eeba272c6522608e','allPassed':all(x['exitCode']==0 for x in results),'files':files,'sourceHashes':first},indent=2));print('Completed gates',all(x['exitCode']==0 for x in results),flush=True)
