from pathlib import Path
import subprocess,os,json,hashlib
w=Path('/tank/shared/projects/proto-ui-agent/sprint6-0246');r=w/'repo';out=w/'evidence/public-ci-publication-r1';out.mkdir(parents=True,exist_ok=False)
node=str(w/'toolchain/node_modules/node-linux-x64/bin/node');env=os.environ.copy();env['PATH']=str(w/'toolchain/node_modules/node-linux-x64/bin')+os.pathsep+str(w/'toolchain/node_modules/.bin')+os.pathsep+env['PATH'];env['TMPDIR']=str(w/'tmp');env['COREPACK_HOME']=str(w/'corepack-cache');env['GIT_OPTIONAL_LOCKS']='0'
branch='sprint6/bootstrap-liquid-delivery-20261122';start='a6e16060a442a82ccac5b63e4a307b053c76f51c';remote='1fda38f3660470128bb12c991a0d2877f7fa5d08'
def cmd(args):return subprocess.check_output(args,cwd=r,env=env,text=True).strip()
gate=json.loads((w/'evidence/public-ci-gates-r1/complete.json').read_text());assert gate['baseHead']==start and gate['allPassed']
assert cmd(['git','rev-parse','HEAD'])==start and cmd(['git','branch','--show-current'])==branch
assert set(cmd(['git','diff','HEAD','--name-only']).splitlines())==set(gate['files'])
for p,h in gate['sourceHashes'].items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,p
pr=json.loads(cmd(['gh','api','repos/Proto-UI/Proto-UI/pulls/1712']));assert pr['state']=='open' and pr['head']['sha']==remote and pr['head']['ref']==branch
cmd(['git','add','--',*gate['files']]);tree=cmd(['git','write-tree'])
(out/'prepared.json').write_text(json.dumps({'head':start,'tree':tree,'remoteHead':remote,'files':gate['files'],'gateReceipt':gate},indent=2))
msg=out/'message.txt';msg.write_text('ci(bootstrap): expose strict public package and consumer validation\n\nAdd an explicitly selected build/React/CLI matrix using the existing canonical commands and original 20/20/15 minute budgets. Preserve the normal CI cycle ownership with a boolean default-false input for both dispatch and workflow_call; the Sprint 6 validation will select all three.\n\nRequire full command inventory, real command/tee/pipeline outcomes, raw log hashes, clean before/after source binding, strict nine-entry budget evidence and successful action outcomes. Keep synthetic React coverage and the existing mandatory native Chrome CLI coverage distinct.\n\nGate controls and scheduling/workflow validation were actually executed; public build, budgets and packed consumers still require the final-head hosted run.\n\nAuthored by Codex for the current user-directed Sprint 6 continuation.\n')
args=[node,'scripts/agent-operations/agent-publish.mjs','commit','--mode','human-assisted','--mode-source','current-user','--authorization','explicit-current-user','--repository','github.com:Proto-UI/Proto-UI','--message-file',str(msg),'--branch',branch,'--expected-head',start,'--expected-tree',tree]
with (out/'publisher.log').open('w') as log:res=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'publisher.exit').write_text(str(res.returncode)+'\n')
if res.returncode:raise SystemExit('Publisher did not report success; reconcile HEAD/tree before retry.')
head=cmd(['git','rev-parse','HEAD']);assert cmd(['git','rev-parse',head+'^'])==start and cmd(['git','rev-parse',head+'^{tree}'])==tree
assert cmd(['git','status','--porcelain=v1'])==''
(out/'complete.json').write_text(json.dumps({'head':head,'parent':start,'tree':tree,'files':gate['files'],'pushed':False},indent=2));print('public CI committed',head,flush=True)
