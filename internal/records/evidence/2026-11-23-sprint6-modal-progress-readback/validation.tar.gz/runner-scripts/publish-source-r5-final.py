from pathlib import Path
import subprocess,os,json,urllib.parse,hashlib
w=Path('/tank/shared/projects/proto-ui-agent/sprint6-0246');r=w/'repo';out=w/'evidence/source-publication-r5';out.mkdir(parents=True,exist_ok=False)
node=str(w/'toolchain/node_modules/node-linux-x64/bin/node');env=os.environ.copy();env['PATH']=str(w/'toolchain/node_modules/node-linux-x64/bin')+os.pathsep+str(w/'toolchain/node_modules/.bin')+os.pathsep+env['PATH'];env['TMPDIR']=str(w/'tmp');env['COREPACK_HOME']=str(w/'corepack-cache');env['GIT_OPTIONAL_LOCKS']='0'
branch='sprint6/bootstrap-liquid-delivery-20261122';remoteStart='1fda38f3660470128bb12c991a0d2877f7fa5d08';start='ccde9d192b2dcb7f51b9ec417435fc14b3fd7a65';main='f8460c23001fd4c48e4dca5bbd19150a4d0e7710'
def cmd(args):return subprocess.check_output(args,cwd=r,env=env,text=True).strip()
def api(endpoint):return json.loads(cmd(['gh','api',endpoint]))
assert cmd(['git','branch','--show-current'])==branch and cmd(['git','rev-parse','HEAD'])==start
assert cmd(['git','rev-parse',start+'^'])=='701206bbd82972078b144d1565d13007f5b62a6f'
known=set(json.loads((w/'evidence/motion-final-r1/candidate-files.json').read_text()))
expectedMotion=known-{'packages/adapters/base/src/material/program.ts','packages/adapters/base/test/web-material-program.test.ts'}
assert set(cmd(['git','diff','--name-only',start+'^',start]).splitlines())==expectedMotion
reconciled=json.loads((w/'evidence/source-publication-r4/motion-reconciliation.json').read_text())
assert reconciled['head']==start and len(reconciled['worktreeChangedFromPreCommit'])==1
assert reconciled['worktreeChangedFromPreCommit'][0]['path']=='.github/workflows/bootstrap-state-controls-evidence.yml'
formatProof=json.loads((w/'evidence/workflow-format-r1/complete.json').read_text());assert formatProof['idempotent'] and formatProof['semanticWorkflowEqual']
pr=api('repos/Proto-UI/Proto-UI/pulls/1712');actor=api('user')['login'];repo=api('repos/Proto-UI/Proto-UI')
assert pr['state']=='open' and pr['head']['sha']==remoteStart and pr['head']['ref']==branch and repo['permissions'].get('push') is True
(out/'before.json').write_text(json.dumps({'actor':actor,'remoteHead':remoteStart,'localHead':start,'permission':repo['permissions'],'reconciledPriorCommit':{'sha':start,'tree':cmd(['git','rev-parse',start+'^{tree}']),'publisherOutcome':'created-with-format-only-tree-mismatch','nextFix':formatProof}},indent=2))
assert set(cmd(['git','diff','HEAD','--name-only']).splitlines())=={'.github/workflows/bootstrap-state-controls-evidence.yml','packages/spec/graph/test/shadcn-dropdown-evidence.test.ts'}
assert cmd(['git','ls-files','--others','--exclude-standard'])==''
receipts=[]
def publish(name,message,files=None):
 if files:cmd(['git','add','--',*files])
 head=cmd(['git','rev-parse','HEAD']);tree=cmd(['git','write-tree']);msg=out/(name+'-message.txt');msg.write_text(message+'\n')
 prep={'slice':name,'parent':head,'tree':tree,'files':files};(out/(name+'-prepared.json')).write_text(json.dumps(prep,indent=2))
 args=[node,'scripts/agent-operations/agent-publish.mjs','commit','--mode','human-assisted','--mode-source','current-user','--authorization','explicit-current-user','--repository','github.com:Proto-UI/Proto-UI','--message-file',str(msg),'--branch',branch,'--expected-head',head,'--expected-tree',tree]
 with (out/(name+'-publisher.log')).open('w') as log:result=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/(name+'-publisher.exit')).write_text(str(result.returncode)+'\n')
 if result.returncode:raise SystemExit('Publisher did not report success; reconcile HEAD and tree before retry.')
 actual=cmd(['git','rev-parse','HEAD']);assert cmd(['git','rev-parse',actual+'^1'])==head and cmd(['git','rev-parse',actual+'^{tree}'])==tree
 receipts.append({**prep,'head':actual});(out/'commits.json').write_text(json.dumps(receipts,indent=2));print('committed',name,actual,flush=True);return actual
publish('workflow-format','fix(ci): keep source evidence outcomes formatting stable\n\nUse an explicit JSON string for the step outcomes scalar so repeated formatting does not append blank lines. The entire parsed workflow is equal after parsing that scalar, two formatter passes are identical, and all 178 source/motion gates pass.\n\nThe prior publisher correctly reported a committed-tree mismatch caused only by the formatter-added blank line; preserve and reconcile that actual commit instead of claiming a successful original receipt.\n\nAuthored by Codex for the current user-directed Sprint 6 continuation.',['.github/workflows/bootstrap-state-controls-evidence.yml'])
publish('catalog-index','test(spec): locate Dropdown evidence by stable implementation id\n\nThe unchanged baseline test reads implementations[0] after an earlier catalog addition reordered that list. Select prototypes-shadcn-dropdown-item-contract explicitly and retain every original bilingual evidence-boundary assertion. That assertion passes in the real 37/40 local graph run; three unrelated original-budget timeouts remain retained for clean CI verification.\n\nAuthored by Codex for the current user-directed Sprint 6 continuation.',['packages/spec/graph/test/shadcn-dropdown-evidence.test.ts'])
assert cmd(['git','status','--porcelain=v1'])==''
assert api('repos/Proto-UI/Proto-UI/branches/main')['commit']['sha']==main
with (out/'fetch-main.log').open('w') as log:result=subprocess.run(['git','fetch','origin','refs/heads/main'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0 and cmd(['git','rev-parse','FETCH_HEAD'])==main
(out/'main-binding.json').write_text(json.dumps({'main':main,'before':cmd(['git','rev-parse','HEAD']),'commonAncestor':cmd(['git','merge-base','HEAD',main])},indent=2))
with (out/'merge-main.log').open('w') as log:result=subprocess.run(['git','merge','--no-ff','--no-commit',main],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'merge-main.exit').write_text(str(result.returncode)+'\n')
if result.returncode:raise SystemExit('Merge is not complete; inspect actual conflicts without resetting.')
assert cmd(['git','rev-parse','MERGE_HEAD'])==main
mergeHead=publish('main-sync','Merge current main into the Sprint 6 delivery branch\n\nPreserve both source histories. The shared Brutalist generated-token fix is identical; retain main\'s native Menubar animation-settlement regression. No source feature, prior evidence, or certification is rewritten.\n\nIntegration performed by Codex for the current user-directed Sprint 6 continuation.')
assert cmd(['git','rev-parse',mergeHead+'^2'])==main
assert cmd(['git','status','--porcelain=v1'])==''
(out/'complete.json').write_text(json.dumps({'head':mergeHead,'remoteHeadBeforePush':remoteStart,'main':main,'pushed':False,'commits':receipts},indent=2));print('Local source integration complete',mergeHead,flush=True)
