# #1457 公共诊断边界有限复审（第二版）

## 结论和范围

本次是独立只读复审，未修改实现、未重新运行测试。核对基线为整合源码 `94006b3d1253684afb4340452f9fbef835dd69ac`；读取期间根推进到 `d247c782c19bacbb926b52b5afa75fe76999e014`，本报告列出的 compiler 文件在两者之间没有差异。

检查 `packages/compiler/src/index.ts` 的既有公开 file、watch、project 入口，以及这些入口直接共用的诊断制造函数。发现原 `compileFile` 修复仍漏掉公共 Project、Watch、CLI 异常边界和几个文件输出诊断。它们与 #1457 的未知位置、类别区分和原始异常证据要求相同；修复不需要增加 Hook、语法、目标平台或改变 artifact 发布规则。

当前不能以“所有公共诊断边界已一致”为理由直接 `Closes #1457`。应先完成下面的窄修复和有区分力的负控，再准确拆开旧复合勾选框。已有 81/81 和历史 F2 回执的来源、范围不因此改变。

## A. 已确定的责任层问题

### A1. Project 把内部异常改写为输入错误，并制造位置

`project.ts:68–87` 的 `span(file)` 固定写 `start/end=0` 和 `line/column=1`。`diagnostic(error, file)` 仅对 `CompilerRejection` 原样放行，其余全部变为 `PUI4101 / invalid-input`，只保留 `error.message`。

该函数用于初始 root/entries 检查、config 文件读取、SDK 路径发现和每个 entry 的编译 catch。特别是 `compileAttempt` 中包住 `sources.entry → sources.load → compileFile` 的 catch（约第 283 行）会把内部 `TypeError` 等缺陷伪装成声明输入错误。

可区分的最小负控：在真实临时 root 和合法 entry 上，令 `FileSourceGraph.prototype.load` 拒绝同一个 `TypeError` 对象，调用公开 `compileProject`。旧实现必然返回 `PUI4101 / invalid-input`、`entry.proto.ts:1:1`，不含原 stack；候选应按现有异常治理给出 `PUI1999 / compiler-defect`、原 stack 和未知坐标。普通 loader `Error` 仍是既有输入失败；不能把所有 project 异常无差别重新分类。

同时保留：缺 root/config/entry 的原输入类别、`CompilerRejection` 的 diagnostic identity 和真实 span、失败不发布部分 generation、不污染 cache/lastSuccessful、修复后能恢复、合法规范化路径仍准入。对已越过 loader 后的异常，建议再有一个普通 `Error` 的独立反例，避免只按错误类名猜边界。

### A2. Watch 的既有错误码变体没有登记，异常证据又被截断

`watch.ts:74–84` 为全部 watch 诊断写 `<watch>:1:1`；此处只有来源上下文，没有观测到源文件位置，应使用诊断专用 unknown sentinel。

| 既有路径 | 现有 code/category | 既有契约证据 | 精确处置 |
|---|---|---|---|
| compiler 调用的 Promise 意外拒绝（约 472 行） | `PUI4003 / compiler-defect` | `ProjectWatchRuntime.compileProject` 是既有公开 host seam；failure report 维持 `fatal:false`，允许后续 revision 恢复 | 保留码和类别，登记 watch 专用含义；补真实 `watchProject` 路径正控，保原 stack |
| `onReport` 消费者回调抛错（约 243 行） | `PUI4004 / compiler-defect` | `watch.test.ts` 原有 “closes cleanly when a consumer callback throws…” 明确锁定 PUI4004，并验证释放所有 watcher；`finished` 明确用结果报告终态而不后台 reject | 保留既有协议，meaning 明确是 report callback 异常，不能描述成源代码不受支持；保原 stack |

注册表的既有注释要求记录真实 emission path，并不重设计历史协议。因此这两项可作为精确、可测试的多类别变体登记；不能把所有扫描到的类别自动加入白名单。`PUI4004` 的 code 有原测试直接约束；`PUI4003` 的既有源路径存在但目前没有对应 throw 正控，应补齐。

对普通 watch 配置/root 输入失败仍保持 `PUI4001 / invalid-input`，native watcher 能力或资源失败仍保持 `PUI4002 / unsupported-input`；不要借诊断修复改 quiet period、native 通知、关闭/恢复或旧结果规则。

### A3. CLI 已明确分类为 defect，但丢掉原 stack

`cli.ts:535`（watch 报告发布 queue 的 unexpected catch）和约 832 行（`runCompilerCli` 顶层 unexpected catch）均为 `PUI9002 / compiler-defect`，却只写 `error.message`。`cliDiagnostic`（约 281 行）统一制造 `1:1`。这是公开 compiler 命令边界，不能用 compileFile 已保留 stack 代表它也已满足。

建议保留 PUI9002、exit 3、原 watch 停止行为，只保全原异常证据并使用未知坐标。`CliUsageError` 仍为 `PUI9001 / invalid-input`、exit 2；传入实际配置文件名时保留来源 identity，但不把 JSON/config 错误猜成第一行位置。

## B. 无源码位置的 file/output 诊断制造函数

以下均可通过既有公开入口到达。这里确定的是坐标虚构，不据此宣布其 I/O 类别错误。替换应局限于诊断 span；保留原文件 identity、code/category、输入限制、文件所有权、冲突、回滚和零写入行为。

| 直接责任点 | 公开消费入口或共享关系 | 当前含义 / 最小负控方向 |
|---|---|---|
| `project-output.ts:37–49` 的 reject | projectCompilationArtifacts / writeProjectCompilation / diffProjectCompilation | 无 entry、重复 entry、非法 sourcePath 为 PUI3004；冲突为 PUI3002。空 generation / 已有冲突夹具即可断言 unknown，而不是 `<project-output>:1:1` |
| `artifact-output.ts:150` 的 diff location | diffCompilation / diffRustDataCompilation / diffProjectCompilation | PUI5001 output-conflict，只有目录/artifact 路径；缺目录或非法 artifact 名仍保原类别 |
| `artifact-output.ts:422` 的无效 writer 参数 | writeArtifactSet 以及所有公开 writer | PUI3004 invalid-input；非法 artifact 清单仍必须零写入 |
| `artifact-output.ts:585` 的 publication failure | 同上 | PUI3002 conflict / PUI3003 output-write；保 primary filename 和完整 rollback 说明，不能因为 unknown span 重新归类 |
| `artifact-library.ts:82` 的 libraryRejection | prepare/validate/read/write/link CompilerLibrary | PUI4201/4202/4203/4204 等已有清单；缺 manifest、非法 layout 等没有真实源码坐标。JSON/manifest 验证 catch 的 TypeError 可能本来就表示不受信输入，不能照搬 Project 的内部异常判据 |
| `gpui-native-sdk-compatibility.ts:34` 的 failure | verifyGpuiNativeSdk 及 file/project 的 shared SDK 检查 | PUI_GPUI_SDK_COMPATIBILITY invalid-input；目录/文件 identity 可知，源码位置未知。不需要 Cargo/GPUI 实际运行来测试该诊断 helper |
| `native-support-migration.ts:731` 的 catch | migrateNativeSupport | PUI5001 output-conflict；planFile 是来源上下文而非已观测位置。保原输入校验与事务发布协议 |

通用有区分力的 oracle 应同时验证 raw JSON sentinel 和 formatter：即使为该 identity 提供源文本，输出也必须写 `source location unknown`，不能出现虚构的 `1 |` 摘录/caret。原本具备真实 AST span 的 `CompilerRejection` 仍保持原对象与位置。

## C. 此次有限范围与额外观察

`verifyConsumerClosure` 公开返回独立的 `ConsumerClosureFailure`（path/code/message），不返回 `CompilerDiagnostic` 或 SourceSpan，不属于 PUI 注册表/unknown-span 修复包。不要为迎合本项给它增加编译器错误码或新坐标协议。

四个纯语义入口的诊断 fallback 在首版中列为待判定观察，现已按 root 对 #1457 原普遍 unknown-location 条件的确认完成有限补审，见附录 D。它们仅是诊断上下文；`gpui-native-table.ts` 中 compiler-owned 静态声明的 IR/source identity 继续排除，诊断专用 sentinel 不允许流入有效 IR 或 source map。

本报告不承诺所有 API 的任意非法 JS 对象或恶意 getter 都被完整分类，也未重审新语法、Hook 实现、输出事务或跨平台执行。建议修复当前确定的诊断边界，沿用已有行为正控，完成后按确切 source SHA 和独立复审记录回填。

## 可采用的结项表述条件

旧复合 checkbox 应分别记为：Hook 共同准入、所有已声明 code/category/meaning 的机器约束及混合错误负控、F2 两项历史 undefined-child 分类、真实 callee/可用 span、未知位置、预期 input/I/O 与异常证据、等价修复提示边界。每条引用自身证据来源。实查 `git show 6bfd0bc4:packages/compiler/src/diagnostic-registry.ts` 时有 55 个 code，原 Issue 的历史 55-code 说法正确；到 dc3 及当前基线已有 60 个 code，本次应保留当前 primary snapshot。另一个旧 55 是三个文件的测试总数（28 + 5 + 22），不能与历史 code 数混为一谈。22 是 Hook tests，81 是先前五文件工作树回执，177 是独立历史 F2 批次，互不替代。

根已接受 A/B 中已列公开边界为同一窄诊断包；registry/Rust/Watch 首包已由 B 独立复审并整合为 `01110811771289ba812cfe0e829a989c88657f91`。Project/CLI/output 继续独立验收。root 随后确认四个已列纯诊断 fallback 同属原 unknown-location 条件，附录 D 将其锁入有限清单；不以收窄 README 措辞代替原条件。

新增 registry/Rust/Project/Watch/CLI 及相关公共 file fallback 的候选实现仍须由未实现该切片的人复核，不能把本报告对责任层的判断写成候选已通过。


## D. 四个纯诊断边界补审与最小控制

### 版本与审查方式

本附录读取整合版本 `01110811771289ba812cfe0e829a989c88657f91`；四个文件自首版审查基线起未变。仍为独立只读判断，没有修改实现或运行测试。下面的“旧表现”来自明确源码路径，属于待 C 用原产品负控实测的预期，不把推导写成已经执行的红灯回执。

首版文件与首包独立 review 的绑定保持不变：`diagnostic-public-boundary-review.zh-CN.md`，SHA256 `4782e80319279de863239262197fa8c211c15bced2365a884c80f8c54e22ccb1`。本第二版补齐范围判断，不改变首包 review 的结论或执行来源。

### D1. resolveTargetProfile

- 责任点：`targets.ts:553–574`。`selectionSpan` 是 `<target>` 的 `0/1:1` 占位，唯一选择为 `options.span ?? selectionSpan`。未知 profile、未实现 profile、不匹配模式/版本、不支持的 capability 等都通过 `unsupported(...)` 返回该诊断 span。
- 最小原负控：`resolveTargetProfile('missing-profile')`。旧结果是 `PUI4001 / unsupported-input` 加 `<target>:1:1`，并没有真实作者源位置。候选应保持 code/category/message，使用 unknown sentinel。
- 真实位置正控：对相同失败传入 `{ profile: 'missing-profile', span: actualSpan }`，`actualSpan` 取真实解析的 setup/span；断言 `diagnostics[0].span === actualSpan`。不得把有源位置的拒绝也改成 unknown。
- 原行为正控：合法 profile 仍成功；`targets.test.ts` 现有嵌套 authored Hook 的 `inner.ts:3`、具体方法/capability 位置断言仍保留。`checkTargetOperations` 已显式传入 `ir.setup.span`，不会因为默认 fallback 改动而丢失真实源位置。
- 限定修改：仅 default `selectionSpan`。不调整目标选择、版本、capabilities、Props policy 或 unimplemented admission。

### D2. validateIR

- 责任点：`ir-validation.ts:138–153` 的 `FALLBACK`，另供 `valueType` 默认位置、schema 版本拒绝和末尾非 checked-rejection catch 使用。读取全部 `FALLBACK` 引用，未发现它写入成功的 PrototypeIR。`span(value)` 的合法 IR 校验仍要求非负 offset 和一基 line/column。
- 两个最小原负控：`validateIR(null)` 返回 `PUI2002 / invalid-ir`；`validateIR({ schemaVersion: -1 })` 返回 `PUI2001 / invalid-ir`。两者都没有可用源码位置，旧实现却给 `<ir>:1:1`。候选应保原失败类别与行为，只用 unknown fallback。
- 真实位置正控：从合法源码解析得到含一个 prop 的 IR，复制该 prop 形成同名重复 metadata；现有 `bad('Invalid or duplicate prop metadata.', location)` 应继续保留该 prop 的真实 span。不要把原 `bad(message, actualSpan)` 全部替换为 unknown。
- 原行为正控：相同合法 IR 仍通过；现有 `diagnostic-origin.test.ts` “keeps the diagnostic sentinel out of valid IR and source maps” 必须继续通过。把 unknown sentinel 放进 `ir.setup.span` 仍应拒绝，不能因为诊断容许 unknown 而允许非法 IR 坐标。
- 限定修改：只改诊断 `FALLBACK`。不改 schema、data graph 安全、IR span 有效性、语义 admission、normalization 或已有 invalid-ir 分类；本附录不要求重新设计 `validateIR` 接受未知输入的末尾 catch 分类。

### D3. lowerRulePlan / rule-plan

- 责任点：`rule-plan.ts:35` 的 `fallbackSpan` 仅作为 `lowerRulePlan(declarations, diagnosticSpan = fallbackSpan)` 默认诊断上下文。进入每条 declaration 后，经过验证的 declaration、dependency、condition、intent-op span 会逐层覆盖；成功 RulePlan 保存原 declaration，不写入 fallback。
- 最小原负控：`lowerRulePlan([{} as RuleDeclarationIR])` 在无可用 declaration/source span 的有限 JSON 输入上拒绝，旧结果 `PUI2024 / invalid-ir` 附 `<rule-plan>:1:1`。候选应只修缺失来源位置。
- 显式上下文正控：相同 malformed declarations 调用 `lowerRulePlan(input, actualSpan)`，返回诊断应保持 `span === actualSpan`。
- 真实子节点正控：复用 `rule-declarations.test.ts` 的真实 `extractRuleDeclaration` 夹具（`w.state(checked).eq(true)`），仅把合法 declaration 的 `deps` 清空。原 `validateCondition` 对缺失 dependency 的失败使用实际比较左侧的 `leftSpan`，候选必须仍等于提取出来的 `when.left.span`，不能退回 root context 或 unknown。
- 原行为正控：合法 declaration 的 lower/evaluate 结果、函数/getter 泄漏拒绝、重复 id、unsupported intent 和条件准入保持原状。`evaluateRulePlan` 的成功 StyleContribution 继续使用 `rule.span`；不加新 Rule 算子，不改变 finite-data 验证。
- 限定修改：仅默认诊断 fallback；没有要求新访问不受信输入的 `.span` getter 来猜源位置。

### D4. evaluateStylePlan / style-plan

- 责任点：`style-plan.ts:57` 的 `syntheticSpan` 仅用于 `fail` 中的 `contribution?.span ?? syntheticSpan`。成功 projection 目前只在作者 contribution 真有 span 时复制该 span；没有来源时字段仍可缺省。
- 最小原负控一：`evaluateStylePlan({ contributions: [] }, { target: '', tokens: {} })`，旧 `PUI4201 / invalid-ir` 附 `<style-plan>:1:1`。mapping 本身没有作者源码位置。
- 最小原负控二：合法、无 span 的 contribution 使用 `bg-red`，但 mapping 为 `{ target: 'fixture', tokens: {} }`。旧 `PUI4202 / unsupported-input` 也附虚构位置。该控制保留既有 unsupported 和 invalid-ir 的区别。
- 真实位置正控：为同样的拒绝 contribution 传入真实 `span`，保持 `diagnostics[0].span === contribution.span`；可同时对非法 contributor identity 的 PUI4201 和缺 token mapping 的 PUI4202 检查原位置。mapping 自身失败不应擅自借用某个无关 contribution 的 span。
- 原行为正控：提供合法 mapping 后成功 projection 的 entries 保留已有可选 span；无 span 的成功输入不能被补成 unknown sentinel。现有禁用 contribution 仍验证 mapping、层级优先级、撤销/恢复、consumer-owned style diff 控制保持不变。
- 限定修改：只改 `syntheticSpan` 为诊断 unknown。不变更 token 支持表、优先级、fallback style、withdrawal、consumer 所有权或两个 code/category 分支。

### 本轮锁定的有限边界清单

合并 A/B 与 D，后续公开诊断包限定为：Project（输入/内部异常区分及位置）、CLI（既有 defect stack 及位置）、Project output、artifact diff/write、compiler-library 共用 rejection、GPUI SDK compatibility、native-support migration，以及上述四个纯诊断 fallback。先前 Rust/Watch/registry 首包单独保留其已审源码和回执。

这些控制应共用已有 unknown JSON/formatter oracle：文件/context identity 保留；offset=-1、line/column=0；即使提供 source text 也不能出现第一行 caret。已有真实 span 的正控必须与无位置负控成对保存，原错误码、类别、准入和成功输出不变。ConsumerClosure 独立失败协议及合法 IR synthetic identity 明确不在此包内。

本清单不再扩大为编译器语义全集。C 负责负控实际终态和实现；B 独立复审；root 负责整合来源复验。任何 Search 性能 profile 到达后，B 先处理已存在的 1000 ms 发布红灯归因，不以此文档工作代替生产 Search 验收。
