# #1457 公共诊断边界有限复审

## 结论和范围

本次是独立只读复审，未修改实现、未重新运行测试。核对基线为整合源码 `94006b3d1253684afb4340452f9fbef835dd69ac`；读取期间根推进到 `d247c782c19bacbb926b52b5afa75fe76999e014`，本报告列出的 compiler 文件在两者之间没有差异。

检查 `packages/compiler/src/index.ts` 的既有公开 file、watch、project 入口，以及这些入口直接共用的诊断制造函数。发现原 `compileFile` 修复仍漏掉公共 Project、Watch、CLI 异常边界和几个文件输出诊断。它们与 #1457 的未知位置、类别区分和原始异常证据要求相同；修复不需要增加 Hook、语法、目标平台或改变 artifact 发布规则。

当前不能以“所有公共诊断边界已一致”为理由直接 `Closes #1457`。应先完成下面的窄修复和有区分力的负控，再准确拆开旧复合勾选框。已有 81/81 和历史 F2 回执的来源、范围不因此改变。

## A. 已确定的责任层问题

### A1. Project 把内部异常改写为输入错误，并制造位置

`project.ts:68–87` 的 `span(file)` 固定写 `start/end=0` 和 `line/column=1`。`diagnostic(error, file)` 仅对 `CompilerRejection` 原样放行，其余全部变为 `PUI4101 / invalid-input`，只保留 `error.message`。

该函数用于初始 root/entries 检查、config 文件读取、SDK 路径发现和每个 entry 的编译 catch。特别是 `compileAttempt` 中包住 `sources.entry → sources.load → compileFile` 的 catch（约第 283 行）会把内部 `TypeError` 等缺陷伪装成声明输入错误。

可区分的最小负控：在真实临时 root 和合法 entry 上，令 `FileSourceGraph.prototype.load` 拒绝同一个 `TypeError` 对象，调用公开 `compileProject`。旧实现必然返回 `PUI4101 / invalid-input`、`entry.proto.ts:1:1`，不含原 stack；候选应按现有异常治理给出 `PUI1999 / compiler-defect`、原 stack 和未知坐标。普通 loader `Error` 仍是既有输入失败；不能把所有 project 异常无差别重新分类。

同时保留：缺 root/config/entry 的原输入类别、`CompilerRejection` 的 diagnostic identity 和真实 span、失败不发布部分 generation、不污染 cache/lastSuccessful、修复后能恢复、合法规范化路径仍准入。对已越过 loader 后的异常，建议再有一个普通 `Error` 的独立反例，避免只按错误类名猜边界。

### A2. Watch 的既有错误码变体没有登记，异常证据又被截断

`watch.ts:74–84` 为全部 watch 诊断写 `<watch>:1:1`；此处只有来源上下文，没有观测到源文件位置，应使用诊断专用 unknown sentinel。

| 既有路径 | 现有 code/category | 既有契约证据 | 精确处置 |
|---|---|---|---|
| compiler 调用的 Promise 意外拒绝（约 472 行） | `PUI4003 / compiler-defect` | `ProjectWatchRuntime.compileProject` 是既有公开 host seam；failure report 维持 `fatal:false`，允许后续 revision 恢复 | 保留码和类别，登记 watch 专用含义；补真实 `watchProject` 路径正控，保原 stack |
| `onReport` 消费者回调抛错（约 243 行） | `PUI4004 / compiler-defect` | `watch.test.ts` 原有 “closes cleanly when a consumer callback throws…” 明确锁定 PUI4004，并验证释放所有 watcher；`finished` 明确用结果报告终态而不后台 reject | 保留既有协议，meaning 明确是 report callback 异常，不能描述成源代码不受支持；保原 stack |

注册表的既有注释要求记录真实 emission path，并不重设计历史协议。因此这两项可作为精确、可测试的多类别变体登记；不能把所有扫描到的类别自动加入白名单。`PUI4004` 的 code 有原测试直接约束；`PUI4003` 的既有源路径存在但目前没有对应 throw 正控，应补齐。

对普通 watch 配置/root 输入失败仍保持 `PUI4001 / invalid-input`，native watcher 能力或资源失败仍保持 `PUI4002 / unsupported-input`；不要借诊断修复改 quiet period、native 通知、关闭/恢复或旧结果规则。

### A3. CLI 已明确分类为 defect，但丢掉原 stack

`cli.ts:535`（watch 报告发布 queue 的 unexpected catch）和约 832 行（`runCompilerCli` 顶层 unexpected catch）均为 `PUI9002 / compiler-defect`，却只写 `error.message`。`cliDiagnostic`（约 281 行）统一制造 `1:1`。这是公开 compiler 命令边界，不能用 compileFile 已保留 stack 代表它也已满足。

建议保留 PUI9002、exit 3、原 watch 停止行为，只保全原异常证据并使用未知坐标。`CliUsageError` 仍为 `PUI9001 / invalid-input`、exit 2；传入实际配置文件名时保留来源 identity，但不把 JSON/config 错误猜成第一行位置。

## B. 无源码位置的 file/output 诊断制造函数

以下均可通过既有公开入口到达。这里确定的是坐标虚构，不据此宣布其 I/O 类别错误。替换应局限于诊断 span；保留原文件 identity、code/category、输入限制、文件所有权、冲突、回滚和零写入行为。

| 直接责任点 | 公开消费入口或共享关系 | 当前含义 / 最小负控方向 |
|---|---|---|
| `project-output.ts:37–49` 的 reject | projectCompilationArtifacts / writeProjectCompilation / diffProjectCompilation | 无 entry、重复 entry、非法 sourcePath 为 PUI3004；冲突为 PUI3002。空 generation / 已有冲突夹具即可断言 unknown，而不是 `<project-output>:1:1` |
| `artifact-output.ts:150` 的 diff location | diffCompilation / diffRustDataCompilation / diffProjectCompilation | PUI5001 output-conflict，只有目录/artifact 路径；缺目录或非法 artifact 名仍保原类别 |
| `artifact-output.ts:422` 的无效 writer 参数 | writeArtifactSet 以及所有公开 writer | PUI3004 invalid-input；非法 artifact 清单仍必须零写入 |
| `artifact-output.ts:585` 的 publication failure | 同上 | PUI3002 conflict / PUI3003 output-write；保 primary filename 和完整 rollback 说明，不能因为 unknown span 重新归类 |
| `artifact-library.ts:82` 的 libraryRejection | prepare/validate/read/write/link CompilerLibrary | PUI4201/4202/4203/4204 等已有清单；缺 manifest、非法 layout 等没有真实源码坐标。JSON/manifest 验证 catch 的 TypeError 可能本来就表示不受信输入，不能照搬 Project 的内部异常判据 |
| `gpui-native-sdk-compatibility.ts:34` 的 failure | verifyGpuiNativeSdk 及 file/project 的 shared SDK 检查 | PUI_GPUI_SDK_COMPATIBILITY invalid-input；目录/文件 identity 可知，源码位置未知。不需要 Cargo/GPUI 实际运行来测试该诊断 helper |
| `native-support-migration.ts:731` 的 catch | migrateNativeSupport | PUI5001 output-conflict；planFile 是来源上下文而非已观测位置。保原输入校验与事务发布协议 |

通用有区分力的 oracle 应同时验证 raw JSON sentinel 和 formatter：即使为该 identity 提供源文本，输出也必须写 `source location unknown`，不能出现虚构的 `1 |` 摘录/caret。原本具备真实 AST span 的 `CompilerRejection` 仍保持原对象与位置。

## C. 此次有限范围与额外观察

`verifyConsumerClosure` 公开返回独立的 `ConsumerClosureFailure`（path/code/message），不返回 `CompilerDiagnostic` 或 SourceSpan，不属于 PUI 注册表/unknown-span 修复包。不要为迎合本项给它增加编译器错误码或新坐标协议。

只读扫到另四个已公开的纯语义入口也有诊断 fallback：`targets.ts` 的 `<target>` selectionSpan、`ir-validation.ts` 的 `<ir>` FALLBACK、`rule-plan.ts` 的 `<rule-plan>` fallbackSpan、`style-plan.ts` 的 `<style-plan>` syntheticSpan。它们不在本次 file/watch/project 详细边界审查内；如果 README 要宣称所有公共未知来源都已统一，需把这些**诊断 fallback** 纳入一次有限核查或明确原条款适用对象。不能简单把任何 `0/1:1` 搜索命中全部替换：`gpui-native-table.ts` 的相同数值是 compiler-owned 静态声明的 IR/source identity，不是诊断 fallback，诊断专用 sentinel 不允许流入有效 IR 或 source map。

本报告不承诺所有 API 的任意非法 JS 对象或恶意 getter 都被完整分类，也未重审新语法、Hook 实现、输出事务或跨平台执行。建议修复当前确定的诊断边界，沿用已有行为正控，完成后按确切 source SHA 和独立复审记录回填。

## 可采用的结项表述条件

旧复合 checkbox 应分别记为：Hook 共同准入、所有已声明 code/category/meaning 的机器约束及混合错误负控、F2 两项历史 undefined-child 分类、真实 callee/可用 span、未知位置、预期 input/I/O 与异常证据、等价修复提示边界。每条引用自身证据来源。实查 `git show 6bfd0bc4:packages/compiler/src/diagnostic-registry.ts` 时有 55 个 code，原 Issue 的历史 55-code 说法正确；到 dc3 及当前基线已有 60 个 code，本次应保留当前 primary snapshot。另一个旧 55 是三个文件的测试总数（28 + 5 + 22），不能与历史 code 数混为一谈。22 是 Hook tests，81 是先前五文件工作树回执，177 是独立历史 F2 批次，互不替代。

根已接受 A/B 中已列公开边界为同一窄诊断包，并要求先封存 registry/Rust/Watch 的 72/72 首包，独立复审后再处理 Project/CLI/output。C 中额外的纯语义 fallback 仅作为明确边界观察，不由本报告自行增加实现范围。

新增 registry/Rust/Project/Watch/CLI 及相关公共 file fallback 的候选实现仍须由未实现该切片的人复核，不能把本报告对责任层的判断写成候选已通过。
