"""Read preserved CDP artifacts. No browser or source mutation is performed."""
import collections
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/08438bf804db')
RAW = ROOT / 'sprint1-diagnostic-run-45023577648/raw'
CAPTURES = RAW / 'search-production/homepage-evidence/search-production'
ASSETS = RAW / 'production-assets'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


index = read(ASSETS / 'index.json')
verified = []
for entry in index['entries']:
    path = RAW / entry['artifactPath']
    if not path.is_file():
        path = ASSETS / entry['artifactPath']
    if not path.is_file():
        path = ASSETS / '_astro' / Path(entry['urlPath']).name
    digest = sha(path)
    if digest != entry['sha256']:
        raise ValueError(f'Asset digest mismatch: {path}')
    verified.append({'urlPath': entry['urlPath'], 'sha256': digest})

report = {
    'source': index['source'],
    'workflowRun': 'https://github.com/Proto-UI/Proto-UI/actions/runs/45023577648',
    'artifactId': 14755172370,
    'diagnosticOnly': True,
    'formalAcceptance': False,
    'indexSha256': sha(ASSETS / 'index.json'),
    'verifiedAssetCount': len(verified),
    'method': {
        'publication': 'Original request and ready page timestamps; epoch difference is the original 1000 ms verdict.',
        'cpu': 'Weight each CDP sample by its preceding timeDelta, clipping intervals to request→ready. Align profile microseconds with Performance.NavigationStart + page performance.now. Sampling approximation, not exact function duration; inclusive ancestors must not be summed.',
        'timeline': 'MutationObserver delivery timestamps, not the exact time a mutation began.',
        'metrics': 'Performance metric deltas cover the whole diagnostic capture, including post-publication work.',
    },
    'samples': [],
}

for family in ['shadcn', 'brutalist']:
    for runtime in ['vue', 'react']:
        name = f'{family}-runtime-{runtime}'
        paths = {kind: CAPTURES / f'{name}-{kind}.json' for kind in ['poll', 'diagnostic', 'cpu-profile']}
        poll, diag, cpu = [read(paths[kind]) for kind in ['poll', 'diagnostic', 'cpu-profile']]
        transition = poll['poll']['receipt']['trace']
        request, ready = transition['requestAt'], transition['readyAt']
        initial = {entry['name']: entry['value'] for entry in diag['initialMetrics']['metrics']}
        final = {entry['name']: entry['value'] for entry in diag['finalMetrics']['metrics']}
        navigation = initial['NavigationStart'] * 1e6
        lower, upper = navigation + request * 1000, navigation + ready * 1000
        nodes = {node['id']: node for node in cpu['nodes']}
        parents = {child: node['id'] for node in cpu['nodes'] for child in node.get('children', [])}
        root_child = {}
        for identity in nodes:
            cursor = identity
            while parents.get(cursor) not in [None, 1]:
                cursor = parents[cursor]
            root_child[identity] = cursor
        own = collections.defaultdict(float)
        tasks = collections.defaultdict(float)
        inclusive = collections.defaultdict(float)
        cursor = cpu['startTime']
        for identity, delta in zip(cpu['samples'], cpu['timeDeltas']):
            end = cursor + delta
            weight = max(0, min(end, upper) - max(cursor, lower)) / 1000
            cursor = end
            own[identity] += weight
            tasks[root_child[identity]] += weight
            parent = identity
            while parent in nodes:
                inclusive[parent] += weight
                parent = parents.get(parent)

        def rows(values, limit=16):
            result = []
            for identity, duration in sorted(values.items(), key=lambda pair: -pair[1])[:limit]:
                frame = nodes[identity]['callFrame']
                chain = []
                cursor = identity
                for _ in range(8):
                    chain.append({'node': cursor, **nodes[cursor]['callFrame']})
                    if cursor not in parents:
                        break
                    cursor = parents[cursor]
                result.append({'node': identity, 'sampleWeightedMs': round(duration, 3), 'frame': frame, 'ancestors': chain})
            return result

        timeline = diag['pageTimeline']
        report['samples'].append({
            'name': name,
            'artifacts': {kind: {'path': str(path), 'sha256': sha(path)} for kind, path in paths.items()},
            'verdict': poll['poll']['verdict'],
            'request': transition,
            'performanceDeltaMs': round(ready - request, 3),
            'nodeEventLoop': diag['nodeEventLoop'],
            'phases': [{**phase, 'relativeToRequestMs': round(phase['at'] - request, 3)} for phase in timeline['phases']],
            'longTasksOverlappingPublication': [{**task, 'relativeToRequestMs': round(task['startTime'] - request, 3), 'overlapMs': round(max(0, min(task['startTime'] + task['duration'], ready) - max(task['startTime'], request)), 3)} for task in timeline['longTasks'] if task['startTime'] < ready and task['startTime'] + task['duration'] > request],
            'resourcesStartedBeforePublication': [resource for resource in timeline['resources'] if request <= resource['startTime'] <= ready],
            'wholeDiagnosticMetricDeltas': {key: round(final[key] - value, 6) for key, value in initial.items() if key in final and key in ['TaskDuration', 'ScriptDuration', 'RecalcStyleDuration', 'LayoutDuration', 'TaskOtherDuration', 'ThreadTime', 'DevToolsCommandDuration', 'RecalcStyleCount', 'LayoutCount', 'Nodes', 'JSEventListeners']},
            'requestWindowSelfSamples': rows(own),
            'requestWindowRootTaskSamples': rows(tasks),
            'requestWindowInclusiveSamples': rows(inclusive),
        })

output = ROOT / 'sprint1-b-skill/runtime-profile-analysis-45023577648.json'
output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'path': str(output), 'sha256': sha(output), 'verifiedAssets': len(verified), 'samples': [{'name': item['name'], 'verdict': item['verdict'], 'performanceDeltaMs': item['performanceDeltaMs']} for item in report['samples']]}, ensure_ascii=False))
