# Read-only source diagnostic — run45023577648

This diagnostic ended in failure and retained all10 selected terminals. Source was the clean original e4f7fa8e46c87edaf5354f8d9553b261f66e16c8 (tree7a3c626ec6e1ca6a77836502361e47fc62be0ce4); baseline was dc3b184ba10b0de53e40359c52d012b204b2cd01 (tree513879bf79a93cc9325f5193fa0559e16ea57108). The actual workflow head is separately45d50b5f3a21f615ba3b28993090e8cc87942856. Every step has unchanged clean before/after source. No producer exceeded its outer budget, was interrupted, or left an ownedprocess survivor.

The job ran on Ubuntu26, Node24.22.3 and Chrome157.0.8103.78. All production profile results are diagnostic only; the original1000ms limit remains, and final acceptance must run without profiling. This was not the full11-step Sprint1 selected inventory.

| Step | Terminal | Exit | Seconds |
|---|---|---:|---:|
| install-candidate | PASS / completed | 0 | 9.444 |
| install-baseline | PASS / completed | 0 | 2.823 |
| configure-toolbar | PASS / completed | 0 | 1.992 |
| styles | PASS / completed | 0 | 87.553 |
| matrix-accessibility-consumer | FAIL / completed | 1 | 183.902 |
| search-production | FAIL / completed | 1 | 233.796 |
| baseline-website-types | FAIL / completed | 2 | 12.129 |
| candidate-website-types | FAIL / completed | 2 | 12.582 |
| baseline-astro | PASS / completed | 0 | 136.880 |
| candidate-astro | PASS / completed | 0 | 132.569 |

## Native findings

Production retained3 passed and1 failed case, with no pending cases. The failure is Shadcn React publication at1133ms against1000ms with profilingenabled. The four Vue/React profilewindows, publicruntime polls and diagnostics are under raw/search-production/homepage-evidence/search-production. ActualbuiltJavaScript bytes (2578 assets), URL paths, SHA256s and fourprofile mappings are under raw/production-assets. Later Shadcn recovery steps after the failed React assertion did notrun; their missing captures are not fabricated. B owns responsibility-layer analysis.

Matrix selected the original all-adapter case; it failed at the original60000ms initializationphase. The three othercases were explicitly excluded from thisselectedrun, not claimedpassed. Before activation, both snapshots showed327demos/1308previewers/0initialized, with lazy observers registered. The failure/finally snapshots were unavailable within their original1000ms diagnostic limits. This material does not yet distinguish layout/traversalcost from actual mountingwork. A requested the existing opt-in CPU startupdiagnostic without changing1308,60s,420s or later assertions.

## Type boundary

Explicitbaseline andcandidate websiteTS selections both exited2 and retain all rawdiagnostics. Both fullAstro commands exited0. The exactTS roots/configuration/options and source hashes are under raw/types. C is independently comparing the diagnostic sets; no clean scopedtypecheck is claimed from Astro success.

## Artifact integrity

Artifact14755172370 is retained byte-for-byte as artifact-14755172370.zip (4,960,972bytes), with officialSHA256 c7a97d4e27254dbc44500a5d4f28bb5907681220105ca2df8aaaa12c93950e5c. All2681members safelyextracted (15,490,014bytes) and hashed in raw-manifest.json. The fulljoblog, APIjob/step fields and artifactmetadata remain adjacent. No originalfailure was overwritten or retried by thisintake.


## Completed type comparison

The two explicit-root TypeScript programs reported the same 105 original TS1484
lines in the same 23 unchanged shared-source files. C independently checked the
real configurations and import closure: the manually assembled website program
inherited `verbatimModuleSyntax: true` across project-source boundaries that use
a different normal type configuration. The raw exit 2 results remain failures
of that stated program. No diagnostic was filtered or skipped.

Both normal full Astro commands succeeded: baseline checked 1258 files and the
candidate checked 1265 files, each with 0 errors, 0 warnings and the same 32
hints. All 14 changed website TS roots were included in the actual website
program. Final source still requires its own normal `check:types:workspace` and
`check:types:docs` terminals. The independent detailed review is
`/workspace/scratch/08438bf804db/sprint1-c-types-diagnostic-45023577648.json`, SHA256
`93efb78805c596fd7fd83474eb171f0fdced3677ad0dbf4c77a661cd7420dbbf`.
