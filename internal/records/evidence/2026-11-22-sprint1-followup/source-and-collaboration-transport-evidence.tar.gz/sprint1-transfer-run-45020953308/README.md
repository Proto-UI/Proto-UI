# 原 Actions 源码发布权限拒绝：45020953308

本运行已终态：`source-publication` **failure**，依赖它的 `diagnostic` **skipped**。没有执行生产 Search、Matrix 或类型检查。

## 真实来源与阶段

- [运行](https://github.com/Proto-UI/Proto-UI/actions/runs/45020953308)，attempt1，actor `cyjin-yl`。
- 实际 carrier workflow head：`beb59fc5351c470e8ec03aa92da9b59a4af77742`。
- 被准备发布的原源码：`e4f7fa8e46c87edaf5354f8d9553b261f66e16c8`，tree `7a3c626ec6e1ca6a77836502361e47fc62be0ce4`。二者没有混记。
- Job137203517528 创建于12:10:58Z，12:27:08Z实际启动，12:27:30Z失败；排队970秒。此前各轮API均保留runner_id0与steps空数组；root另在GitHub页面观察到ubuntu24 runner繁忙的明确说明。
- 实际runner1000115323，Ubuntu24.04.5 LTS，image20261116.376.1。此publication job没有启动Chrome，不推定其浏览器结果。

## 失败和精确读回

原service错误为：

> refusing to allow a GitHub App to create or update workflow `.github/workflows/browser-suite-repair-evidence.yml` without `workflows` permission

`raw/publication.json` 记录：原bundle、完整目标tree、6个原commit对象、祖先关系与连通性已经验证，`objectsVerified=true`。实际只尝试一次精确lease的fast-forward：`mutationAttempted=true`、`published=false`；`remoteBefore`和唯一失败后readback均为`2810f0116b5bfe614b6e76d0a40984f86beebe3f`。服务拒绝后没有重试push、替换Actions token或更改仓库权限。

依赖job137207896778于12:27:31Z终态skipped，steps为空；其所有native/type结果均未执行，不能写成0失败或通过。

## 保全材料

- [官方artifact](https://github.com/Proto-UI/Proto-UI/actions/runs/45020953308/artifacts/14753753262)，ZIP40277bytes。
- ZIP SHA256：`a38344b54732edbebc9a11a1c00eec6cc9bb3a04e8c7ed560f2a4ea02aad26f8`，下载结果与官方digest一致。
- 归档bundle31635bytes，SHA256 `118a95c978d606fd1b9912748819f69673cc02e72a06b8b5edcc1aaa73a735f8`，与原审查包完全相同。
- 归档manifest SHA256 `212083874a18b9226e8aab2f8c176ddb73198880096bcc739756a168cee6324e`，与原审查包完全相同。
- 原始记录在 `raw/publication.json`、`raw/git.log`、`github-job-137203517528.log`；机器可读接收表为`intake.json`，逐文件hash为`raw-manifest.json`。

原helper将`GIT_CURL_VERBOSE`设为字符串`0`仍产生了HTTP verbose。已逐行检查保存的job log9条、git.log8条、receipt两份错误字符串各8条Authorization记录（包含重复副本），所有值均有掩码，没有打印或复制凭据值。`publication-verification.json`保留这个有限范围审计。原材料没有改写；这个未执行publisher的后续修理不能当作权限拒绝的解决办法。

## 后续独立操作

root之后使用现有、具备相应workflow权限的GitHub连接器，独立核验服务端6个原commit及fast-forward关系后执行了精确ref更新。A于12:33:29Z独立GET读回公共PR ref为e4；记录在`independent-ref-after-connector.json`。这是一条独立的、已有授权能力完成的操作，**原Actions运行仍为失败，原published=false不改写**。

纯只读诊断需要另一次固定carrier运行取得真实证据。原Ubuntu26写入载体没有dispatch；后续只读载体移除publication job及写token，继续保留原helpers、10步诊断和门限。
