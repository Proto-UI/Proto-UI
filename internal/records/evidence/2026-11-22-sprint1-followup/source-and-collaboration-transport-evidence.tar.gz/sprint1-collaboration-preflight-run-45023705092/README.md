# Ordinary collaboration preflight — run 45023705092

The read-only preflight ended in **failure** at the required live-field collection
boundary. The actual GraphQL HTTP response was 200, with viewer
`github-actions[bot]` and repository `viewerPermission: null`. The collector
reported `Actual repository viewerPermission unavailable`. It recorded no
mutation attempt and did not produce a complete ordinary-collaboration receipt.
This is not evidence that the service received or refused an Issue write.

The separate workflow dispatcher was `cyjin-yl`; dispatch metadata was never
substituted for the real API viewer. The tested source was the clean original
`e4f7fa8e46c87edaf5354f8d9553b261f66e16c8`, tree
`7a3c626ec6e1ca6a77836502361e47fc62be0ce4`. Workflow carrier HEAD was
`ad268102924a6f891ba6934e6bb09f1a5be77c9e`. Job 137211988897 ran on Ubuntu 26
from 12:44:13Z to 12:44:32Z on 2026-11-22. Checkout, helper hashes and installation
completed; the read-only collector stopped at the missing field, and its raw
receipt was uploaded successfully.

Artifact 14755215351 is retained byte-for-byte as `artifact-14755215351.zip`
(2849 bytes). Its SHA256 matches the official digest:
`af356f83e8fbab188814557773975b3bf21f161c02812940908477495e5e6758`.
The five extracted originals remain under `raw/preflight/`. The full job log,
API job polls, official artifact metadata and per-file hashes are adjacent.
`intake.json` distinguishes the real HTTP response from the collector's null
unassigned viewer field. No retry, permission change or alternate identity was
attempted by this intake.
