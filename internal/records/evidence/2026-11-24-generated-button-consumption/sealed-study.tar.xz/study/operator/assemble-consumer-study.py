from pathlib import Path
import copy
import datetime
import hashlib
import json
import shutil

root = Path('/workspace/scratch/0d7d81e85daf')
repo = root / 'proto-ui-s7'
destination = root / 's7-consumer-study-complete-01'
destination.mkdir()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(relative, value):
    target = destination / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    return ref(relative)

def ref(relative):
    return {'path': relative, 'sha256': sha((destination / relative).read_bytes())}

def copy_regular(source, prefix):
    for file in sorted(source.rglob('*')):
        if not file.is_file() or file.is_symlink() or any(part in ('node_modules', '.git', '__pycache__') for part in file.parts):
            continue
        relative = file.relative_to(source)
        if source.name == 's7-consumer-admission-check' and relative.as_posix() in ('inventory.json', 'seal.json'):
            continue
        target = destination / prefix / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(file, target)

copy_regular(root / 's7-consumer-admission-check', Path('.'))
copy_regular(root / 's7-button-participant-02', Path('runs/consumer-02'))
copy_regular(root / 's7-button-participant', Path('excluded/consumer-01/participant'))
copy_regular(root / 's7-button-clock-01', Path('excluded/consumer-01/operator-clock'))
copy_regular(root / 's7-operator-evidence/consumer-01/consumer-01-observation', Path('excluded/consumer-01/operator-native'))
copy_regular(root / 's7-recorder-smoke-01', Path('operator/recorder-control'))
shutil.copy2(root / 's7-control/consumer-02-pre-release.json', destination / 'operator/consumer-02-pre-release.json')
shutil.copy2(root / 's7-control/assemble-consumer-study.py', destination / 'operator/assemble-consumer-study.py')

protocol = json.loads((repo / 'scripts/analysis/invisible-consumption/protocol.json').read_text())
baseline = json.loads((root / 's7-control/artifact-admission-validation.json').read_text())['packet']
participant = destination / 'runs/consumer-02'
clock = json.loads((participant / 'measurement/clock.json').read_text())
release = json.loads((participant / 'measurement/release.json').read_text())
events = json.loads((participant / 'measurement/events.json').read_text())
original_events_hash = sha((participant / 'measurement/events.json').read_bytes())
prefix = 'runs/consumer-02/'

def relocate_reference(original):
    result = copy.deepcopy(original)
    result['path'] = prefix + result['path']
    assert ref(result['path'])['sha256'] == result['sha256'], result['path']
    return result

normalized_events = []
derivations = []
for original in events:
    event = copy.deepcopy(original)
    event['evidence'] = [relocate_reference(value) for value in original['evidence']]
    for key in ('before', 'after', 'diff', 'installedLockfile'):
        if key in original:
            event[key] = relocate_reference(original[key])
    if 'shippedFiles' in original:
        event['shippedFiles'] = [relocate_reference(value) for value in original['shippedFiles']]
    if 'build' in original:
        original_ref = relocate_reference(original['build'])
        command = json.loads((destination / original_ref['path']).read_text())
        normalized = copy.deepcopy(command)
        normalized['stdout'] = relocate_reference(command['stdout'])
        normalized['stderr'] = relocate_reference(command['stderr'])
        normalized['originalReceipt'] = original_ref
        normalized['derivation'] = 'Only stdout/stderr file locators gain the packet prefix. Actual argv/cwd/times/status and raw receipt remain unchanged.'
        event['build'] = save('normalized/build-01.json', normalized)
        derivations.append({'original': original_ref, 'normalized': event['build']})
    normalized_events.append(event)

experience = json.loads((participant / 'evidence/experience.json').read_text())
session = {
    'schemaVersion': 1,
    'id': 'consumer-02',
    'evidenceClass': 'observed-consumer',
    'protocolSha256': release['protocolSha256'],
    'artifactManifestSha256': baseline['artifact']['sha256'],
    'controlLockfileSha256': baseline['controls']['lockfile']['sha256'],
    'taskSha256': release['taskSha256'],
    'environment': baseline['controls']['environment'],
    'initialApp': [{'starterPath': item['path'], 'file': ref(prefix + 'initial-project/' + item['path'].removeprefix('starter/'))} for item in protocol['starter']],
    'participant': {'alias': 'consumer-02', 'frameworkExperience': experience['generalFrameworkKnowledge'], 'libraryExperience': experience['priorUseOfThisDistribution'], 'priorProtoKnowledge': 'none', 'experienceSource': ref(prefix + 'evidence/experience.json')},
    'startedAt': clock['startedAt'],
    'endedMs': clock['endedMs'],
    'clock': clock['clock'],
    'rawLog': ref(prefix + 'measurement/received.jsonl'),
    'events': normalized_events,
    'limitations': [
        'Fresh instructed Agent separation in one shared environment; not secure blinding or a human user sample.',
        'All clock offsets are actual receipt offsets; operator/browser, transport and participant-resume delay remain included. Time-to-first-use is feedback receipt, not the earlier browser wall clock.',
        'One local directory-copy Base Button artifact, one React target, one ordinary supplied preference task; no registry, other-host, AT or physical input claim.',
        'Ordinary distribution includes original generated source/provenance; no Proto internal onboarding was supplied. General React knowledge is prior experience.',
        'Consumer changed generated source to expose className and used application in-flight/error handling; task success is not zero modification.',
        'Provider snapshot, seed, token and billing counters were not exposed; null is not zero.',
        'Consumer-01 actual behavior is retained separately with a missing operator monotonic tail. It is excluded from this strict collector and duration analysis, not classified as participant failure.'
    ],
    'interpretation': {'verdict': 'supported', 'reason': 'This fresh Agent completed the supplied five-stage task, edited and explained the real admitted source distribution, and shipped the exact independently observed production build without internal onboarding. This supports only feasibility for the one artifact/task/environment; it does not establish advantage, demand, ease, adoption or general-library usability.'},
    'derivation': {'originalEvents': {'path': prefix + 'measurement/events.json', 'sha256': original_events_hash}, 'operation': 'Packet-relative evidence locators were prefixed; original event values, timings and evidence bytes are retained.', 'buildReceipts': derivations},
}
run_ref = save('normalized/consumer-02.json', session)
exclusion_ref = save('excluded/consumer-01/disposition.json', {
    'evidenceClass': 'actual-consumer-attempt-with-incomplete-operator-clock',
    'reason': 'The persistent operator PTY recorder disappeared before its final monotonic receipt. No endedMs is reconstructed from UTC participant events.',
    'participantFailure': False,
    'actualProductionJourney': {'checkpoints': 9, 'status': 'passed', 'receipt': ref('excluded/consumer-01/operator-native/browser-01/result.json')},
    'primaryEligible': False,
    'strictDurationAvailable': False,
    'preservation': ['complete participant source and supplied materials', 'actual install/build and failure logs', 'consumer source edits/preimages/diffs and final explanation', 'actual original partial operator-clock files', 'actual production results, screenshots and trace'],
    'noRetrospectiveReconstruction': True,
})
packet = copy.deepcopy(baseline)
packet['runs'] = [run_ref]
packet['excludedAttemptRecords'] = [exclusion_ref]
save('packet.json', packet)
save('operator/assembly-receipt.json', {
    'assembledAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'artifactManifestUnchanged': ref('artifact.json') == baseline['artifact'],
    'primaryRuns': 1, 'additionalActualAttemptsRetained': 1,
    'originalConsumer02EventsSha256': original_events_hash,
    'eventCount': len(events),
    'normalization': 'Original event records and command receipts are preserved. Only derived packet locators change; there is no chronology or behavior fabrication.',
})
print(json.dumps({'root': str(destination), 'events': len(events), 'run': run_ref, 'excluded': exclusion_ref}, indent=2))
