import * as React from 'react';
import { GeneratedButton } from './generated/Component';
import { readPreferences, savePreferences } from './storage';

type SaveStatus =
  | { phase: 'idle' }
  | { phase: 'saving' }
  | { phase: 'success'; name: string }
  | { phase: 'error'; message: string };

export function App() {
  const [name, setName] = React.useState(() => readPreferences().displayName);
  const [savedName, setSavedName] = React.useState(name);
  const [failSave, setFailSave] = React.useState(false);
  const [status, setStatus] = React.useState<SaveStatus>({ phase: 'idle' });
  const saveInFlight = React.useRef(false);
  const isSaving = status.phase === 'saving';

  async function handleSave() {
    // The ref closes the interval before React commits the disabled prop.
    if (saveInFlight.current) return;
    saveInFlight.current = true;
    setStatus({ phase: 'saving' });
    const submittedName = name;

    try {
      const saved = await savePreferences({ displayName: submittedName }, { fail: failSave });
      setSavedName(saved.displayName);
      // Keep any newer draft the user typed while this request was pending.
      setName((current) => current === submittedName ? saved.displayName : current);
      setStatus({ phase: 'success', name: saved.displayName });
    } catch (error) {
      setStatus({
        phase: 'error',
        message: error instanceof Error ? error.message : 'An unexpected storage error occurred',
      });
    } finally {
      saveInFlight.current = false;
    }
  }

  return (
    <main>
      <h1>Preferences</h1>
      <p className="intro">Choose the display name used on this device.</p>
      <label htmlFor="display-name">Display name</label>
      <input
        id="display-name"
        type="text"
        autoComplete="nickname"
        value={name}
        onChange={(event) => setName(event.target.value)}
      />
      <label className="error-control">
        <input type="checkbox" checked={failSave} onChange={(event) => setFailSave(event.target.checked)} />
        Inject a storage error for the debugging exercise
      </label>
      <div className="save-action" aria-busy={isSaving}>
        <GeneratedButton className="save-button" disabled={isSaving} onClick={() => { void handleSave(); }}>
          {isSaving ? 'Saving…' : 'Save preferences'}
        </GeneratedButton>
      </div>
      <p className="saved-name">Current saved name: <strong>{savedName}</strong></p>
      <p role="status" aria-live="polite" aria-atomic="true" className="save-status">
        {status.phase === 'idle' && 'No changes saved in this session.'}
        {status.phase === 'saving' && 'Saving your display name…'}
        {status.phase === 'success' && `Saved preferences for “${status.name}”.`}
      </p>
      {status.phase === 'error' && (
        <p role="alert" className="save-error">Could not save: {status.message}. Try again.</p>
      )}
    </main>
  );
}
