## Actual prior experience

I am an AI coding assistant with general React, TypeScript, Vite, HTML, CSS, and browser-testing knowledge from training. I do not have personal employment or hands-on experience outside this session, and I have not previously used this supplied Button distribution. No provider token, cost, or seed metrics are available to me.
