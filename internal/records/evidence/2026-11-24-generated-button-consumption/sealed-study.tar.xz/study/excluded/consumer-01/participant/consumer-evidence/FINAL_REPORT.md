# Final delivery: preference Save action

## Outcome

The original task is complete. The application uses the supplied editable Button distribution, saves through the unchanged `savePreferences` function, prevents overlapping submissions, presents saving/success/error feedback, recovers after an injected error, and reads the persisted name on reload. The exact submitted production build passed all nine checkpoints in an independent Chromium run. No implementation change was made after the production handoff.

## Timing and attribution

- Original release: **2026-11-23 19:38:25 UTC**.
- Participant's first recorded inspection: **2026-11-23 19:39:09.022578 UTC**.
- Independent browser run: **2026-11-23 20:05:05.299–20:05:17.765 UTC**.
- Result receipt recorded by the participant: **2026-11-23 20:13:06.482134 UTC**.
- Ship completion is recorded at its actual current UTC in `events.jsonl`.

These are distinct events in the original run. The pause for operator work did not restart the task or its clock. Operator finish time has not been substituted for participant receipt or completion time. The original independent event recorder was interrupted; missing monotonic tail values remain missing.

## Source and production output

The editable project is in `project/`; production output is in `project/dist/`. A complete source/build snapshot from the successful original build is retained under `consumer-evidence/builds/attempt-01/`.

`npm ci`, both TypeScript checks, and `npm run build` exited 0. The React, React DOM, development-dependency pins, and lockfile remain exactly as supplied. The entire generated distribution, including hidden helpers, original source map, and provenance, was copied. Supporting helper/map/provenance bytes are unchanged. New production source maps were verified against the exact edited App and Component bytes.

The independent browser's served CSS and JavaScript SHA-256 values match the original submitted production artifacts. All source and configuration bytes were also compared with the saved build snapshot and remain unchanged.

## Activation, saving, and disabled state

The application supplies label children, `onClick`, and the boolean `disabled` to `GeneratedButton`. Its handler sets an in-flight ref immediately, before awaiting storage or waiting for React to render. This closes the interval in which a second activation could otherwise start another save. The visible status becomes `saving`, which drives the component's disabled prop, its `Saving…` label, and the busy state on the action container.

On success, the returned trimmed name updates both the saved-name summary and the status message. On failure, an alert displays the error and the previously saved value remains visible. The handler's `finally` releases the in-flight guard in either case; leaving the saving status re-enables the action. Each save captures the current name and exercise-checkbox value. A newer draft typed during a pending save is preserved rather than overwritten by the response.

The duplicate guard applies to overlapping saves in this mounted application. A later distinct activation after settlement is allowed; no cross-tab or server-side idempotency is claimed.

## Consumer-owned component edit and styling

The small edit to `project/src/generated/Component.tsx` adds an optional `className` prop and forwards it to the physical root. `App.tsx` supplies `save-button`, and ordinary CSS provides the blue action treatment, 44-pixel minimum height, visible focus outline, and distinct disabled appearance. This follows the distribution's permission to edit local source and use ordinary consumer styling.

The generated interaction, accessibility, focus, and disabled logic remain in use. No substitute control, overlay, or alternate activation path bypasses the supplied component. The copied source's stale map comment is replaced by a historical-map note; its original map and provenance remain unchanged, and Vite emits fresh consumer maps. Original bytes, edited bytes, diffs, ownership, and hashes are retained for each source edit.

## Independent production-browser observations

Browser: **Chromium 145.0.7632.6**. Attribution: the independent operator executed these checks; the participant reviewed the returned result, selected screenshots, and exact artifact hashes. The operator recorded no errors.

| Checkpoint | Recorded outcome |
| --- | --- |
| Initial control | Button role, accessible name `Save preferences`, enabled appearance |
| Pending interval | `Saving…`, `aria-disabled=true`, distinct gray appearance |
| Pointer plus immediate duplicate | One successful storage write for the submitted change |
| Keyboard focus | Tab focus with a solid 3 px visible outline |
| Enter | One new successful write |
| Full Space activation | One new successful write |
| Injected error | Prior saved value preserved; alert displayed; action re-enabled; no new write |
| Successful retry | Unchecking the exercise control allowed a later successful save |
| Reload | Input and saved-name summary retained `Recovered preference` |

The actual result, all nine screenshots, and trace are copied under `consumer-evidence/independent-browser/`, with an import/hash manifest in `independent-browser-verification.json`.

## Retained failures and limitations

The first recorder call failed with `Unknown process id 28350`. Its undelivered payload contained a temporary `pending` hash placeholder; the subsequent forwarded event used the actual captured evidence hash. No placeholder event was accepted by that recorder call. The root then reported that its own recorder had ended unexpectedly. Local UTC events and messages continued; no missing monotonic timestamps were reconstructed.

The first preview attempt with `--host 0.0.0.0` failed with `uv_interface_addresses` and exit 1. A loopback preview later printed a listening URL and remained alive when polled, but separate curl requests still failed with exit 7, including retries. These unsuccessful local serving attempts remain in the evidence. The independent operator successfully served and tested the exact build in its browser environment. The cause of the local connectivity discrepancy remains unestablished.

`npm ci` and build emitted an environment `http-proxy` warning; installation also emitted an esbuild install-script warning. Their actual stderr is retained. The installation and build still succeeded.

## Experience, accessed material, and omissions

The participant is an AI coding assistant with general React/TypeScript/Vite knowledge from training, not a human with personal employment or prior hands-on experience. This supplied Button distribution was first encountered in this run. No provider token/cost/seed metrics were available or invented.

No missing internal repository information was needed. The participant inspected only the supplied task, ordinary usage instructions, starter files, editable component source, and relevant helper excerpts during implementation. No public documentation URL was accessed. After explicit followup authorization, only the specified independent result directory's report, screenshots, and trace were accessed outside the participant packet. The access list records this later exception.

There are no unresolved requirements within the supplied task and the observed Chromium scope. No assistive-technology run, other-browser/host compatibility, released-package behavior, or malformed-preexisting-storage recovery is claimed. The extra draft-preservation behavior was source-reviewed but was not an independent browser checkpoint.

`delivery-manifest.json` records source, production output, and evidence file hashes. Live event/server logs are explicitly handled as snapshots so the manifest does not imply a self-referential hash. Earlier handoff and review notes remain unchanged as historical records of what was known at those times.
