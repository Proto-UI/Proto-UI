from pathlib import Path
import hashlib
import json
import shutil

packet = Path(__file__).resolve().parent.parent
project = packet / 'project'
evidence = packet / 'consumer-evidence'
assert (project / 'package-lock.json').read_bytes() == (evidence / 'preimages/project/package-lock.json').read_bytes()
assert (project / 'package.json').read_bytes() == (evidence / 'preimages/project/package.json').read_bytes()
for source in (packet / 'distribution/generated').rglob('*'):
    if source.is_file() and source.name != 'Component.tsx':
        target = project / 'src/generated' / source.relative_to(packet / 'distribution/generated')
        assert source.read_bytes() == target.read_bytes(), f'Unexpected helper/map/provenance modification: {target}'
maps = list((project / 'dist/assets').glob('*.js.map'))
assert len(maps) == 1
map_data = json.loads(maps[0].read_text())
mapped_sources = dict(zip(map_data['sources'], map_data['sourcesContent']))
checks = {}
for relative in ['src/App.tsx', 'src/generated/Component.tsx']:
    matches = [(name, content) for name, content in mapped_sources.items() if name.endswith(relative)]
    assert len(matches) == 1, relative
    name, content = matches[0]
    assert content == (project / relative).read_text(), f'Source map not mapped to current bytes: {relative}'
    checks[relative] = name
build = evidence / 'builds/attempt-01'
shutil.copytree(project / 'dist', build / 'dist')
shutil.copytree(project / 'src', build / 'src')
for file in ['package.json', 'package-lock.json', 'tsconfig.json', 'index.html', 'vite.config.ts']:
    shutil.copy2(project / file, build / file)
manifest = {
    'checks': {'lockfile_unchanged': True, 'dependency_pins_unchanged': True, 'helpers_maps_provenance_unchanged': True, 'fresh_maps_exactly_match_edited_source': checks},
    'dist_files': [{'path': str(file), 'sha256': hashlib.sha256(file.read_bytes()).hexdigest(), 'size_bytes': file.stat().st_size} for file in sorted((project / 'dist').rglob('*')) if file.is_file()],
}
(evidence / 'build-manifest.json').write_text(json.dumps(manifest, indent=2))
print(json.dumps(manifest, indent=2))
