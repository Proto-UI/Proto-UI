# Production browser handoff

## Artifact and command

Build directory: `/workspace/scratch/0d7d81e85daf/s7-button-participant/project/dist`

Project directory: `/workspace/scratch/0d7d81e85daf/s7-button-participant/project`

Serve the production output with `npm run preview -- --port 4173 --strictPort`, using the starter's default `127.0.0.1` host. A plain static server pointed at `dist` is also sufficient for this single-page task if the browser operator needs a different network surface.

`npm run build` passed. The artifact and source snapshot are retained under `consumer-evidence/builds/attempt-01`. Source maps were checked against exact edited App and Component bytes. Dependency pins and lockfile, generated helpers, original map, and provenance are unchanged.

## Current local serving observations

The first preview attempt with `--host 0.0.0.0` exited 1 with `uv_interface_addresses` failure. The loopback preview reported `http://127.0.0.1:4173/` and its tool session remained alive when polled. Separate `curl` calls nonetheless failed to connect, including a retry. Those observations are retained; the cause is not established, and successful HTTP serving or browser interaction is not yet claimed.

## Interaction selectors

- Display name input: `#display-name` (label: `Display name`).
- Exercise control: `input[type="checkbox"]`, labeled `Inject a storage error for the debugging exercise`.
- Save action: `.save-button` / role `button`, accessible name `Save preferences` when idle and `Saving…` while pending.
- Saving container: `.save-action[aria-busy="true"]`.
- Status: `[role="status"]`.
- Error: `[role="alert"]`.
- Saved value: `.saved-name strong`.
- Persisted local-storage key: `consumer-study-preferences`.

## Required browser demonstrations

1. Enter a distinct name, use a real pointer click, and observe success plus the updated saved-name summary.
2. During the 600 ms pending interval observe `aria-disabled="true"`, label `Saving…`, gray appearance, and busy state. Attempt another real pointer activation during that same interval. To prove duplicate suppression, count writes to the relevant local-storage key while preserving the original storage method. A locator method that waits for enabled state would postpone the second click and would not test this interval.
3. Edit the name. Tab from the input through the checkbox to Save, observe visible keyboard focus, then press Enter. Repeat with a new name and Space. The supplied control commits these keys on keydown and blurs when disabled; refocus it for a later keyboard attempt.
4. Edit the name, check the injected-error control, and save. Observe `Could not save: Injected storage error. Try again.`, the unchanged saved-name summary, and the re-enabled action. Uncheck the control and save again successfully.
5. Reload the page. Confirm that the input and saved-name summary show the successful persisted value.

The input remains editable while saving, and a newer draft should be retained if typed before the previous save returns. This is additional implemented behavior, not a required extra test.

## Open questions

Only production browser observations and the local serving/network discrepancy remain unresolved. No missing internal repository information is needed. Do not treat the source review or successful bundle build as a browser pass.
