from pathlib import Path
from datetime import datetime, timezone
import difflib
import hashlib
import json
import shutil
import sys

packet = Path(__file__).resolve().parent.parent
label, ownership, before_arg, live_arg = sys.argv[1:]
live = packet / live_arg
directory = packet / 'consumer-evidence' / 'edits' / label
directory.mkdir(parents=True, exist_ok=True)
suffix = live.suffix
before = directory / ('before' + suffix)
after = directory / ('after' + suffix)
if before_arg == '--new':
    before.write_bytes(b'')
else:
    shutil.copy2(packet / before_arg, before)
shutil.copy2(live, after)
diff = directory / 'change.patch'
diff.write_text(''.join(difflib.unified_diff(
    before.read_text().splitlines(keepends=True),
    after.read_text().splitlines(keepends=True),
    fromfile=live_arg + ' (before)', tofile=live_arg + ' (after)',
)))
record = {
    'utc': datetime.now(timezone.utc).isoformat(), 'ownership': ownership,
    'live_path': str(live), 'new_file': before_arg == '--new',
    'evidence': [{'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in [before, after, diff]],
}
(directory / 'manifest.json').write_text(json.dumps(record, indent=2))
print(json.dumps(record, indent=2))
