from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil

packet = Path(__file__).resolve().parent.parent
evidence = packet / 'consumer-evidence'
shutil.copy2(evidence / 'events.jsonl', evidence / 'events-before-completion.jsonl')
shutil.copy2(evidence / 'server-loopback-output.log', evidence / 'server-loopback-output-final-snapshot.log')
receipt = {
    'utc': datetime.now(timezone.utc).isoformat(),
    'operation': 'Final source/evidence/output manifest and completion preparation',
    'original_release_utc': '2026-11-23T19:38:25Z',
    'implementation_edits_after_handoff': False,
    'unresolved_task_requirements': [],
    'remaining_environment_question': 'Cause of failed local cross-command HTTP connectivity remains unestablished; independently served exact build passed.',
    'status': 'Independent browser evidence verified; ready to record actual ship completion.',
}
(evidence / 'finalization-receipt.json').write_text(json.dumps(receipt, indent=2))
excluded = {
    'consumer-evidence/delivery-manifest.json': 'Manifest cannot include its own hash.',
    'consumer-evidence/events.jsonl': 'Actual completion is appended after this manifest; pre-completion snapshot included.',
    'consumer-evidence/server-loopback-output.log': 'Potential live log; finalization snapshot included.',
    'consumer-delivery.zip': 'Delivery archive is produced after completion and separately hashed.',
    'consumer-delivery.sha256': 'Archive checksum is produced after completion.',
}
records = []
for file in sorted(packet.rglob('*')):
    if not file.is_file() or 'node_modules' in file.parts:
        continue
    relative = file.relative_to(packet).as_posix()
    if relative in excluded:
        continue
    ownership = 'production-output' if relative.startswith('project/dist/') else 'generated-consumer-owned' if relative.startswith('project/src/generated/') else 'application' if relative.startswith('project/') else 'supplied-distribution' if relative.startswith('distribution/') else 'independent-operator-evidence' if relative.startswith('consumer-evidence/independent-browser/') else 'participant-evidence' if relative.startswith('consumer-evidence/') else 'supplied-task'
    records.append({'path': relative, 'ownership': ownership, 'size_bytes': file.stat().st_size, 'sha256': hashlib.sha256(file.read_bytes()).hexdigest()})
manifest = {'created_utc': datetime.now(timezone.utc).isoformat(), 'root': str(packet), 'excluded': excluded, 'installed_dependencies': 'node_modules omitted; exact package.json and package-lock.json retained for npm ci.', 'files': records}
path = evidence / 'delivery-manifest.json'
path.write_text(json.dumps(manifest, indent=2))
print(json.dumps({'manifest': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'files': len(records), 'final_report_sha256': hashlib.sha256((evidence / 'FINAL_REPORT.md').read_bytes()).hexdigest()}, indent=2))
