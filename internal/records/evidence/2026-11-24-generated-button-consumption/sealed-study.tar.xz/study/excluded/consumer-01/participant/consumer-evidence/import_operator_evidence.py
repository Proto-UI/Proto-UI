from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import shutil

packet = Path(__file__).resolve().parent.parent
evidence = packet / 'consumer-evidence'
operator = Path('/workspace/scratch/0d7d81e85daf/s7-operator-evidence/consumer-01/consumer-01-observation/browser-01')
result = json.loads((operator / 'result.json').read_text())
assert result['status'] == 'passed'
assert not result['errors']
assert len(result['checkpoints']) == 9

asset_checks = []
for item in result['assets']:
    actual = hashlib.sha256((packet / 'project/dist' / item['path']).read_bytes()).hexdigest()
    assert item['status'] == 200
    assert item['diskSha256'] == item['servedSha256'] == actual
    asset_checks.append({'path': item['path'], 'sha256': actual, 'status': 200})

snapshot = evidence / 'builds/attempt-01'
unchanged_sources = []
for original in sorted((snapshot / 'src').rglob('*')):
    if original.is_file():
        relative = original.relative_to(snapshot)
        actual = packet / 'project' / relative
        assert original.read_bytes() == actual.read_bytes(), relative
        unchanged_sources.append(str(relative))
for relative in ['package.json', 'package-lock.json', 'tsconfig.json', 'index.html', 'vite.config.ts']:
    assert (snapshot / relative).read_bytes() == (packet / 'project' / relative).read_bytes()
    unchanged_sources.append(relative)

destination = evidence / 'independent-browser'
destination.mkdir(exist_ok=True)
filenames = ['result.json'] + [point['screenshot'] for point in result['checkpoints']] + ['trace.zip']
copied = []
accesses = []
viewed = {'02-pending-disabled.png', '04-keyboard-focus.png', '07-error-and-reenable.png', '09-persisted-after-reload.png'}
for name in filenames:
    assert Path(name).name == name
    source = operator / name
    target = destination / name
    shutil.copy2(source, target)
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    copied.append({'source': str(source), 'copy': str(target), 'sha256': digest})
    action = 'Read independent operator JSON' if name == 'result.json' else 'Viewed screenshot, copied and hashed' if name in viewed else 'Copied and hashed; not visually inspected' if name.endswith('.png') else 'Copied and hashed trace archive; not unpacked'
    accesses.append({'utc': datetime.now(timezone.utc).isoformat(), 'path': str(source), 'purpose': action, 'authorization': 'Root followup explicitly authorized this result directory only.'})
with (evidence / 'accessed-materials.jsonl').open('a') as out:
    for access in accesses:
        out.write(json.dumps(access) + '\n')

record = {
    'verified_at_utc': datetime.now(timezone.utc).isoformat(),
    'attribution': 'Independent production Chromium operator; participant reviewed returned evidence.',
    'operator_started_at': result['startedAt'], 'operator_finished_at': result['finishedAt'],
    'receipt': json.loads((evidence / 'operator-result-receipt.json').read_text()),
    'browser': result['browser'], 'status': result['status'], 'checkpoint_count': len(result['checkpoints']),
    'errors': result['errors'], 'served_assets_match_submitted_build': asset_checks,
    'source_unchanged_since_build': unchanged_sources, 'copied_evidence': copied,
    'scope': result['scope'],
}
(evidence / 'independent-browser-verification.json').write_text(json.dumps(record, indent=2))
print(json.dumps(record, indent=2))
