from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sys

packet = Path(__file__).resolve().parent.parent
kind, stage, detail, *paths = sys.argv[1:]
event = {
    'kind': kind,
    'stage': stage,
    'detail': detail,
    'evidence': [
        {'path': str((packet / path).resolve()), 'sha256': hashlib.sha256((packet / path).read_bytes()).hexdigest()}
        for path in paths
    ],
}
with (packet / 'consumer-evidence' / 'events.jsonl').open('a') as out:
    out.write(json.dumps({'utc': datetime.now(timezone.utc).isoformat(), **event}) + '\n')
print(json.dumps(event))
