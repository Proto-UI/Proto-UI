from pathlib import Path
import hashlib
import zipfile

packet = Path(__file__).resolve().parent.parent
archive = packet / 'consumer-delivery.zip'
checksum = packet / 'consumer-delivery.sha256'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as out:
    for file in sorted(packet.rglob('*')):
        if not file.is_file() or 'node_modules' in file.parts or file in [archive, checksum]:
            continue
        out.write(file, file.relative_to(packet))
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
checksum.write_text(digest + '  consumer-delivery.zip\n')
print(f'{archive}\nSHA256 {digest}\nBytes {archive.stat().st_size}')
