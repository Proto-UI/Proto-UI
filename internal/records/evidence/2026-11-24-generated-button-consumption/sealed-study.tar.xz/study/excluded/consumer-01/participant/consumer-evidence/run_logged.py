from datetime import datetime, timezone
from pathlib import Path
import json
import subprocess
import sys

packet = Path(__file__).resolve().parent.parent
label, cwd, *argv = sys.argv[1:]
logdir = packet / 'consumer-evidence' / 'commands'
logdir.mkdir(exist_ok=True)
record = {
    'started_utc': datetime.now(timezone.utc).isoformat(),
    'cwd': str((packet / cwd).resolve()),
    'argv': argv,
}
result = subprocess.run(argv, cwd=packet / cwd, capture_output=True, text=True)
record.update(
    ended_utc=datetime.now(timezone.utc).isoformat(),
    exit_code=result.returncode,
    stdout=result.stdout,
    stderr=result.stderr,
)
(logdir / (label + '.json')).write_text(json.dumps(record, indent=2))
(logdir / (label + '.stdout.txt')).write_text(result.stdout)
(logdir / (label + '.stderr.txt')).write_text(result.stderr)
sys.stdout.write(result.stdout)
sys.stderr.write(result.stderr)
print(json.dumps({'command_log': str(logdir / (label + '.json')), 'exit_code': result.returncode}))
sys.exit(result.returncode)
