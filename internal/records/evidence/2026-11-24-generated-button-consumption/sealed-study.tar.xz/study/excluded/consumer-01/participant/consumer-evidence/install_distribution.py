from pathlib import Path
import hashlib
import json
import shutil

packet = Path(__file__).resolve().parent.parent
source = packet / 'distribution' / 'generated'
destination = packet / 'project' / 'src' / 'generated'
preimage = packet / 'consumer-evidence' / 'preimages' / 'distribution' / 'generated'
shutil.copytree(source, preimage)
shutil.copytree(source, destination)
manifest = []
for original in sorted(source.rglob('*')):
    if original.is_file():
        relative = original.relative_to(source)
        copied = destination / relative
        old_hash = hashlib.sha256(original.read_bytes()).hexdigest()
        new_hash = hashlib.sha256(copied.read_bytes()).hexdigest()
        assert old_hash == new_hash
        manifest.append({'source': str(original), 'destination': str(copied), 'sha256': new_hash})
lock = packet / 'project' / 'package-lock.json'
old_lock = packet / 'consumer-evidence' / 'preimages' / 'project' / 'package-lock.json'
assert lock.read_bytes() == old_lock.read_bytes(), 'npm ci changed the lockfile'
result = {'copied': manifest, 'lockfile_unchanged': True, 'lockfile_sha256': hashlib.sha256(lock.read_bytes()).hexdigest()}
(packet / 'consumer-evidence' / 'distribution-install-manifest.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
