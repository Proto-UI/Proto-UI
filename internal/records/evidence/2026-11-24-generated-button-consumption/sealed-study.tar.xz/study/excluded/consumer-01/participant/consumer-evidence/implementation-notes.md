# Preference Save implementation

## Installation and supplied code

The distribution is editable local source. Its ordinary instructions require copying the complete `generated` directory, including hidden helper directories, and React / React DOM 19.2.6. The starter already pins these exact versions. `npm ci` installed the existing lockfile. No dependency pins or lockfile bytes were changed.

The complete distribution was copied to `project/src/generated`, with the import `./generated/Component` from `App.tsx`. All original bytes, including maps and provenance, are retained under `consumer-evidence/preimages/distribution/generated` and in the untouched `distribution/generated` directory.

## Activation, saving, and disabled state

1. The supplied Button receives its accessible label as children and invokes the application callback through its documented `onClick` prop.
2. `handleSave` immediately sets an in-flight ref, then sets React's status to `saving`. The ref prevents concurrent calls before a render can update the component.
3. The derived `isSaving` boolean is supplied as `disabled`. The application shows `Saving…`, marks its action container busy, and uses ordinary CSS for the supplied control's `aria-disabled` appearance.
4. The original `savePreferences` trims and validates the submitted name, waits 600 ms, optionally throws the exercise error, and writes to local storage on success.
5. Success updates both the saved-name summary and status. Error displays an alert and preserves the previous saved value. A `finally` block releases the in-flight guard in both cases. The input initializes from the original `readPreferences`, so a reload reads the persisted name.

The input and exercise checkbox remain usable while saving. Each save captures their values when activated. A name typed during the pending save is kept as the next draft rather than overwritten by the response.

## Small consumer-owned source change

`project/src/generated/Component.tsx` adds an optional `className` prop and forwards it to the generated physical root. The application passes `save-button`. This is a small editable-source extension that enables ordinary consumer styling, as permitted by `USAGE.md`. Role, accessible name, disabled projection, focus management, activation, and supporting helpers are unchanged. No substitute button, overlay, alternate event handler, or other behavioral bypass was added.

The copied source's old source-map comment is replaced with an explicit historical-map note. The original map and provenance files remain byte-identical. `vite.config.ts` enables new source maps for the edited consumer build.

## Customization

The action has a blue background, a clear text label, a 44-pixel minimum height, a dark visible keyboard-focus outline, and a distinct gray disabled appearance. The CSS targets the consumer class and uses `aria-disabled` as well as the native disabled selector. Error and status feedback use alert/status semantics and remain outside the busy action wrapper.

## Verification status

Installation and TypeScript checks passed. Production build and live-browser verification are recorded separately when actually performed. No browser success is implied by the source review.

## Failures and recording limitations

The first attempt to send an event to `tools.write_stdin` session 28350 failed with `Unknown process id 28350`; the root reported that process sessions are agent-local. Events were subsequently sent to the root for forwarding while local actual-UTC events continued. The root later reported that its recorder had ended unexpectedly. This is an operator transport interruption; missing monotonic tail timings are not reconstructed or backdated.

`npm ci` exited 0 and emitted warnings for the environment's `http-proxy` configuration and the unapproved esbuild install script. Their exact stderr is retained in the install command log. These were warnings, not an install failure.

No personal prior hands-on experience, unavailable provider token/cost/seed metrics, external documentation access, hidden task information, or unobserved captures are claimed.
