from pathlib import Path
from datetime import datetime, timezone
import json
import subprocess
import sys

packet = Path(__file__).resolve().parent.parent
evidence = packet / 'consumer-evidence'
argv = ['npm', 'run', 'preview', '--', '--host', '0.0.0.0', '--port', '4173', '--strictPort']
process = subprocess.Popen(argv, cwd=packet / 'project', stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
record = {'started_utc': datetime.now(timezone.utc).isoformat(), 'cwd': str(packet / 'project'), 'argv': argv, 'pid': process.pid, 'state': 'running'}
(evidence / 'server-start.json').write_text(json.dumps(record, indent=2))
with (evidence / 'server-output.log').open('w') as out:
    try:
        for line in process.stdout:
            out.write(line)
            out.flush()
            sys.stdout.write(line)
            sys.stdout.flush()
        exit_code = process.wait()
    except KeyboardInterrupt:
        process.terminate()
        exit_code = process.wait()
record.update(ended_utc=datetime.now(timezone.utc).isoformat(), exit_code=exit_code, state='exited')
(evidence / 'server-exit.json').write_text(json.dumps(record, indent=2))
sys.exit(exit_code)
