# Save preferences: implementation explanation

## Activation and asynchronous saving

`App.tsx` imports `{ GeneratedButton }` from `./generated/Component`, following the supplied local-source distribution. The text child remains **Save preferences**, so the action has a stable accessible name. Its `onClick` invokes `handleSave`; the application does not synthesize pointer or keyboard events or replace the component's activation path.

`handleSave` first checks `saveInFlight.current`. It sets this ref immediately before setting React state, which blocks overlapping calls even before React has committed the next render. `isSaving` is the rendered state: it is passed into the supplied `disabled` prop, marks the surrounding region busy, and disables the field and exercise checkbox while the save's captured values are in flight. The supplied storage function retains its original 600ms delay and injected-error behavior.

On success the app uses the actual returned, trimmed display name to update the saved-name area, input and status message. `savePreferences` writes localStorage; initialization calls `readPreferences`, so reload reads the saved value. On failure the app preserves the last successful name, displays the actual error in a live alert and permits another attempt. The `finally` block clears both the ref and the rendered busy state for success and error, including immediate validation errors.

The concurrency guard prevents overlapping submissions. A deliberate later activation after completion may save again; no long-lived deduplication of separate user actions was requested. The component's disabled contract remains active, with the application guard protecting the operation as well.

## Styling and small source change

The supplied USAGE.md supports editing the local generated source and ordinary consumer CSS. Its public text does not document a className API. Source inspection showed className was excluded from prop resolution but was neither typed nor forwarded. The small consumer-owned edit adds optional `className?: string` and forwards it to the physical root, allowing the app's `preference-save` class to style this Button directly. The activation, keyboard, focus and disabled implementation was left unchanged. No alternate button or event system was substituted.

The CSS supplies an indigo action, readable text, a gold `:focus-visible` ring with offset, and a muted disabled treatment matching both `[aria-disabled="true"]` and `:disabled`. The accessible label is not replaced by decoration. Status and saved name appear separately.

Original and edited source bytes and unified diffs are retained in `evidence/snapshots`. The original compiler map and provenance are unchanged. The live sourceMappingURL reference was removed from the edited Component.tsx because that map describes the historical source; the production build will emit a fresh consumer bundle map.

## Evidence and behavioral bounds

The declared dependencies are the supplied exact React 19.2.6 / React DOM 19.2.6 pins, installed with `npm ci`; package.json and package-lock.json were unchanged. The whole generated directory, including hidden context/style/interaction helpers, was copied. No internal documentation, producer sources, other consumer implementations or evaluator sources were consulted. Public external documentation has not been needed. The only instruction gap encountered was the concrete host styling API, resolved from ordinary shipped source.

At this explanation's creation time, source wiring and customization type checks passed. Production browser observations are pending and are not claimed by this explanation. The required production checks are pointer saving, keyboard saving/focus, one save across repeated activation during the disabled interval, injected storage error recovery, a later successful retry and reload persistence. Actual observations will be attributed to their operator and retained when received. No cross-browser or broader component certification is implied.
