import * as React from 'react';
import { GeneratedButton } from './generated/Component';
import { readPreferences, savePreferences } from './storage';

export function App() {
  const [name, setName] = React.useState(() => readPreferences().displayName);
  const [savedName, setSavedName] = React.useState(() => readPreferences().displayName);
  const [failSave, setFailSave] = React.useState(false);
  const [message, setMessage] = React.useState('No changes saved in this session.');

  async function handleSave() {
    const saved = await savePreferences({ displayName: name }, { fail: failSave });
    setSavedName(saved.displayName);
    setName(saved.displayName);
    setMessage(`Saved ${saved.displayName}.`);
  }

  return (
    <main>
      <h1>Preferences</h1>
      <label htmlFor="display-name">Display name</label>
      <input id="display-name" type="text" value={name} onChange={(event) => setName(event.target.value)} />
      <label className="error-control">
        <input type="checkbox" checked={failSave} onChange={(event) => setFailSave(event.target.checked)} />
        Inject a storage error for the debugging exercise
      </label>
      <GeneratedButton disabled={false} onClick={() => { void handleSave(); }}>Save preferences</GeneratedButton>
      <p role="status">{message}</p>
      <p>Saved display name: <strong>{savedName}</strong></p>
    </main>
  );
}
