# Consumer 02 — production browser handoff

Status: production build ready, served over HTTP; ship and observation clock remain active. No browser outcome is claimed yet.

## Build and serving

- Packet: `/workspace/scratch/0d7d81e85daf/s7-button-participant-02`
- Project: `project`
- Production directory: `/workspace/scratch/0d7d81e85daf/s7-button-participant-02/project/dist`
- Actual production command: `npm run build -- --sourcemap`
- Build receipt: `measurement/commands/build-01.json`, exit 0.
- Production manifest: `evidence/production-manifest-01.json` lists all four build files and hashes.
- Actual static-server command: `python3 -m http.server 4172 --bind 127.0.0.1 --directory /workspace/scratch/0d7d81e85daf/s7-button-participant-02/project/dist`
- URL: `http://127.0.0.1:4172/`
- Launch receipt: `evidence/production-server-launch-02.json`.
- HTTP check: `measurement/commands/verify-production-http-02.json`, exit 0; HTTP 200 body exactly matched dist/index.html.

## Controls and pending observations

- Textbox accessible label: `Display name`; CSS selector `#display-name`.
- Exercise checkbox accessible label: `Inject a storage error for the debugging exercise`.
- Button accessible name: `Save preferences`; role button; CSS selector `.preference-save`.
- Status: `[role="status"]`.
- Error alert appears on failure: `[role="alert"]`.
- Saved name: `.saved-preference strong`.
- Busy region: button parent carries `aria-busy`; generated Button receives `disabled={isSaving}`.

Please independently observe the unchanged production dist:

1. Edit the name, activate by pointer, observe disabled and saving status during the original approximately 600ms storage delay, then saved name and re-enabled controls.
2. Rapid repeated activation should produce one in-flight save. Instrumenting localStorage writes is one possible actual observation method. A later deliberate activation after completion is allowed.
3. Focus by keyboard and verify the visible gold ring; activate by Enter and Space using changed names.
4. Enable the exercise checkbox, attempt saving, observe the real injected storage error and recovery to enabled controls. Clear the checkbox and demonstrate a later successful save.
5. Reload and confirm the saved name is read back.

Return actual observations, screenshots/captures, observed browser/version and limitations. The consumer will record their receipt at the then-current time and attribute observations to the operator without backdating.

## Source and evidence

`project/src/App.tsx` contains the synchronous in-flight guard, rendered busy/disabled state, save call, success display, error catch and finally recovery. `evidence/implementation-explanation-v1.md` explains the wiring and behavioral bounds. Immutable original/edited source bytes and diffs are under `evidence/snapshots`. The small component edit forwards an optional className to the generated host; all other supplied generated files, original map and provenance remain unchanged. The consumer build emits a fresh source map.

No dependency pins or lockfile bytes changed. General framework familiarity and unavailable usage metrics are recorded in `evidence/experience.json`. No public external documentation or hidden/internal onboarding was consulted; the documented editable distribution itself was inspected for the concrete styling host.

## Unsuccessful attempt retained

The initial Vite preview child failed with `uv_interface_addresses returned Unknown system error 1`. Its launch wrapper returned 0 because it spawned a child; that wrapper exit is not a successful-server claim, and the child final exit code was not captured. The actual error log is retained as `evidence/production-server-01-failure-snapshot.log`. The following HTTP command failed with connection refused and exit 1 (`measurement/commands/verify-production-http-01.json`). Switching to Python static serving succeeded. No browser was attempted locally and no browser pass is claimed.

Root requested that this working turn end after handoff, with ship active and without RECORDER.py finish. Independent browser waiting time remains included in the original release window.
