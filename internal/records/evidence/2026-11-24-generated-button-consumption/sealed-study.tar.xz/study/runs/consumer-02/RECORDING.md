# Recording the actual task

Work only in this packet. Read TASK.md and the ordinary supplied distribution instructions. Public framework documentation is permitted; record every source consulted. Do not inspect parent/sibling work, internal repository documentation, other consumers, or operator evaluators. This is instructed separation in a shared environment, not secure blinding. The untouched initial project is retained in initial-project; implement in project. Do not alter dependency pins or the supplied package-lock. Do not commit, push, or contact external people.

Record your first command's actual UTC time immediately. Give an honest prior-experience statement: general framework knowledge, prior use of this distribution, and any prior internal Proto knowledge. Provider snapshot, seed, billing/token/cost values unavailable to you are null with reasons.

The task has a 60-minute window from the recorded release. A durable local observation clock is provided in RECORDER.py. It carries no component implementation advice. Every invocation reads the same Linux CLOCK_MONOTONIC epoch; it does not require a persistent terminal. Do not supply, edit or reconstruct atMs. Actual operator waiting and browser feedback time remain included.

## Events

Write an event JSON file under evidence/ and run:

```sh
python3 RECORDER.py --root . event evidence/event-01.json
```

Required event fields are kind, stage, detail and a nonempty evidence array of packet-relative file paths. The recorder computes file hashes. Preserve those referenced bytes: snapshots of edited files must have unique names, not a mutable path that will change later.

Stages, in order: discover-install, use, customize, debug, ship. Start each with kind=start and end it with kind=completed, failed or abandoned before starting the next. A failed command that you will recover from is a step with the error detail; kind=failed is a terminal stage outcome, not an incidental failed attempt. Preserve all unsuccessful commands.

Kinds step, successful-use, internals, escape-hatch, edit, explanation and capture describe actual observations inside the active stage. Do not use successful-use for a source review or build alone. Record any internal-information need or bypass honestly. Ordinary source/provenance included with the distribution is not hidden onboarding.

Example start: {"kind":"start","stage":"discover-install","detail":"Beginning ordinary task discovery","evidence":["TASK.md"]}.

An edit event additionally supplies before, after, diff (each a packet-relative immutable file path), ownership (app or generated), and consumerPath. For a generated edit, consumerPath is relative to the supplied generated directory, for example Component.tsx. Keep the real original and changed bytes plus their diff. An explanation event points to your actual explanation file.

## Actual commands

Run install, type checks, build and other finite commands through:

```sh
python3 RECORDER.py --root . command discover-install install-01 project -- npm ci --ignore-scripts --no-audit --no-fund
```

Use the active stage and a new label per attempt. The command's real argv, cwd, start/end, stdout, stderr, exit/signal/error and hashes are saved under measurement/commands. A step event is recorded automatically. The wrapper's own exit is not the underlying command's result: inspect the receipt. It deliberately retains failed commands without declaring the whole stage terminal.

The completed discover-install event additionally supplies installedLockfile="project/package-lock.json". A completed ship event additionally supplies build="measurement/commands/<actual-build-label>.json" and shippedFiles listing every actual production output file. Shipping also requires a capture event with actual production-browser evidence, a real successful-use observation, and your source-edit/explanation evidence.

## Production handoff and completion

After the production build is ready, report the dist path, actual command, accessible control labels and any pending browser questions to the root operator. Do not spend the window repeatedly retrying an unavailable local browser; retain its real failure and request the independently operated Chromium. You may end a working turn while ship remains active and resume on actual feedback; that does not restart the task clock.

When operator feedback arrives, record its receipt at the current time, attribute the original browser observation accurately, and copy the actual feedback/captures into this packet before referencing them. Do not backdate a receipt to the browser finish time. Complete ship only with actual evidence. Then close the observation clock once:

```sh
python3 RECORDER.py --root . finish
```

Deliver the source, production output, all recording files, immutable edits/diffs, command failures, consulted materials, experience, limitations and an explanation. No preference for the component is required. The recorder's content checks do not authenticate behavior; the operator independently checks the actual files and production observations.
