import * as React from 'react';
import { GeneratedButton } from './generated/Component';
import { readPreferences, savePreferences } from './storage';

export function App() {
  const [name, setName] = React.useState(() => readPreferences().displayName);
  const [savedName, setSavedName] = React.useState(() => readPreferences().displayName);
  const [failSave, setFailSave] = React.useState(false);
  const [isSaving, setIsSaving] = React.useState(false);
  const [message, setMessage] = React.useState('No changes saved in this session.');
  const [error, setError] = React.useState('');
  const saveInFlight = React.useRef(false);

  async function handleSave() {
    // The ref closes the gap before React commits disabled={isSaving}.
    if (saveInFlight.current) return;
    saveInFlight.current = true;
    setIsSaving(true);
    setError('');
    setMessage('Saving preferences…');

    try {
      const saved = await savePreferences({ displayName: name }, { fail: failSave });
      setSavedName(saved.displayName);
      setName(saved.displayName);
      setMessage(`Saved ${saved.displayName}.`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'An unexpected error occurred');
      setMessage('Your changes were not saved. You can try again.');
    } finally {
      saveInFlight.current = false;
      setIsSaving(false);
    }
  }

  return (
    <main>
      <p className="eyebrow">ACCOUNT SETTINGS</p>
      <h1>Preferences</h1>
      <p className="intro">Choose how your name appears.</p>
      <label htmlFor="display-name">Display name</label>
      <input
        id="display-name"
        type="text"
        value={name}
        disabled={isSaving}
        onChange={(event) => setName(event.target.value)}
      />
      <label className="error-control">
        <input
          type="checkbox"
          checked={failSave}
          disabled={isSaving}
          onChange={(event) => setFailSave(event.target.checked)}
        />
        Inject a storage error for the debugging exercise
      </label>
      <div aria-busy={isSaving}>
        <GeneratedButton
          className="preference-save"
          disabled={isSaving}
          onClick={() => { void handleSave(); }}
        >
          Save preferences
        </GeneratedButton>
      </div>
      <p className="save-status" role="status">{message}</p>
      {error && <p className="save-error" role="alert">{error}</p>}
      <p className="saved-preference">Saved display name: <strong>{savedName}</strong></p>
    </main>
  );
}
