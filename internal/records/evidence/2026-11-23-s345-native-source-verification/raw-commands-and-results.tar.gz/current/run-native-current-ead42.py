import pathlib,json,hashlib,subprocess,os,time,datetime,traceback
B=pathlib.Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
K=B/'integration-checkpoint-r3-4deb'
R=B/'continuation-native-ead42f5e-4deb'
E=B/'evidence/continuation-s345-native-ead42f5e-4deb'
E.mkdir(exist_ok=True)
PIN='ead42f5e0bfd0661c4b9215306a47b2d8259ce8d'
TARGET=B/'cargo-target-s345-ead42f5e-01'
SEED=B/'cargo-target-s345-37844189-4dfb55cd-01'
env=dict(os.environ,CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUSTUP_TOOLCHAIN='1.98.1')
env['PATH']=str(B/'tools/node-v24.22.3-linux-x64/bin')+':/home/ezra/.cargo/bin:'+env.get('PATH','')
env['COREPACK_HOME']=str(B/'corepack-cache')
receipt={'schemaVersion':1,'kind':'fresh-pinned-native-producer-sdk-and-consumers','sourceCommit':PIN,'sourceRepository':str(R),'referenceObjectRepository':str(K),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'generatedRustEdited':False,'commands':[],'targetDir':str(TARGET),'cacheSeed':str(SEED),'platformScope':'Linux native execution; not macOS, physical accessibility or hardware evidence.'}
def save(): (E/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,args,cwd=None,stdoutPath=None):
 row={'name':name,'command':args,'cwd':str(cwd or R),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};receipt['commands'].append(row);save()
 start=time.monotonic();logPath=stdoutPath or E/(name+'.log')
 with logPath.open('wb') as log:
  p=subprocess.Popen(args,cwd=cwd or R,env=env,stdout=log,stderr=subprocess.STDOUT if stdoutPath is None else subprocess.PIPE)
  row['pid']=p.pid;save()
  _,stderr=p.communicate()
  rc=p.returncode
  if stderr:(E/(name+'.stderr.log')).write_bytes(stderr)
 row.update({'exitCode':rc,'elapsedSeconds':time.monotonic()-start,'output':str(logPath),'sha256':digest(logPath)});save()
 if rc:raise RuntimeError(name+' exit '+str(rc))
def git(args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def sdkManifest(sdk):return {str(p.relative_to(sdk)):digest(p) for p in sorted(sdk.rglob('*')) if p.is_file()}
def inputManifest(root):return {str(p.relative_to(root)):digest(p) for p in sorted(root.rglob('*')) if p.is_file() and (p.suffix=='.rs' or p.name in ['Cargo.toml','Cargo.lock'])}
try:
 if R.exists() or TARGET.exists():raise RuntimeError('Fresh own source and target paths required')
 if subprocess.check_output(['git','cat-file','-t',PIN],cwd=K,text=True).strip()!='commit':raise RuntimeError('Missing exact source commit')
 run('clone-exact-source',['git','clone','--shared','--no-checkout',str(K),str(R)],cwd=B)
 run('checkout-exact-source',['git','checkout','--detach',PIN])
 if git(['rev-parse','HEAD'])!=PIN or git(['status','--porcelain']):raise RuntimeError('Source checkout is not clean exact pin')
 receipt['tree']=git(['rev-parse','HEAD^{tree}'])
 receipt['lockSha256Before']=digest(R/'pnpm-lock.yaml')
 receipt['compilerSources']={str(p.relative_to(R)):digest(p) for p in sorted((R/'packages/compiler/src').rglob('*')) if p.is_file()}
 save()
 run('frozen-js-install',['corepack','pnpm@10.32.1','install','--frozen-lockfile','--ignore-scripts'])
 if digest(R/'pnpm-lock.yaml')!=receipt['lockSha256Before']:raise RuntimeError('Frozen lock changed')
 run('actual-tools',['node','-e',"console.log(JSON.stringify({node:process.version,typescript:require('typescript').version,typescriptPath:require.resolve('typescript'),tsxPath:require.resolve('tsx')}))"])
 run('ordinary-producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs',str(E/'generated')])
 run('numeric-producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-a11y-value/produce.mjs',str(E/'numeric-action')])
 ordinary=E/'generated/transition'
 numeric=E/'numeric-action'
 receipt['ordinarySdk']=sdkManifest(ordinary/'.proto-ui/gpui-native')
 receipt['numericSdk']=sdkManifest(numeric/'component/.proto-ui/gpui-native')
 receipt['sdkBytesEqualAcrossProducers']=receipt['ordinarySdk']==receipt['numericSdk']
 receipt['generatedInputsAfterEmit']={'ordinary':inputManifest(E/'generated'),'numeric':inputManifest(numeric)}
 receipt['numericLockBeforeMetadata']=digest(numeric/'Cargo.lock');save()
 run('ordinary-graph',['node','scripts/gpui/check-cargo-graph.mjs','--manifest-path',str(ordinary/'Cargo.toml'),'--git','https://github.com/zed-industries/zed','--rev','62e5991dd0f0c8a3af8d5e7e9c4652490d468db8','--toolchain','1.98.1','--output',str(E/'ordinary-graph.json')])
 run('numeric-metadata',['cargo','+1.98.1','metadata','--offline','--all-features','--format-version','1','--manifest-path',str(numeric/'Cargo.toml')],stdoutPath=E/'numeric-metadata.json')
 receipt['numericLockAfterPrescribedMetadata']=digest(numeric/'Cargo.lock');save()
 run('numeric-graph',['node','scripts/gpui/check-cargo-graph.mjs','--manifest-path',str(numeric/'Cargo.toml'),'--git','https://github.com/zed-industries/zed','--rev','62e5991dd0f0c8a3af8d5e7e9c4652490d468db8','--toolchain','1.98.1','--output',str(E/'numeric-graph.json')])
 receipt['generatedInputsBeforeTests']={'ordinary':inputManifest(E/'generated'),'numeric':inputManifest(numeric)};save()
 # Separate current-source cache; SDK bytes are forcibly rebuilt after copying dependencies.
 run('copy-owned-target',['cp','-aL','--reflink=auto','--no-preserve=links',str(SEED),str(TARGET)])
 if TARGET.is_symlink() or TARGET.resolve()==SEED.resolve():raise RuntimeError('Target must be independent')
 run('clean-owned-sdk',['cargo','+1.98.1','clean','--manifest-path',str(numeric/'Cargo.toml'),'--target-dir',str(TARGET),'-p','proto-ui-gpui-native'])
 run('native-sdk-controls',['cargo','+1.98.1','test','--locked','--manifest-path',str(numeric/'Cargo.toml'),'-p','proto-ui-gpui-native','--features','test-support,gpui/test-support','--lib','--','--test-threads=1','--nocapture'])
 run('default-sdk-check',['cargo','+1.98.1','check','--locked','--manifest-path',str(ordinary/'Cargo.toml'),'--lib'])
 run('ordinary-consumer',['cargo','+1.98.1','test','--locked','--manifest-path',str(ordinary/'Cargo.toml'),'--features','test-support','--test','ordinary','--','--test-threads=1','--nocapture'])
 run('numeric-a11y-value',['cargo','+1.98.1','test','--locked','--manifest-path',str(numeric/'Cargo.toml'),'--test','a11y_value','--','--test-threads=1','--nocapture'])
 for name in ['control_label','style_mapping','a11y_activation','scroll_pause','scroll_reader']:
  run(name,['cargo','+1.98.1','test','--locked','--manifest-path',str(ordinary/'Cargo.toml'),'--features','test-support','--test',name,'--','--test-threads=1','--nocapture'])
 receipt['generatedInputsAfterTests']={'ordinary':inputManifest(E/'generated'),'numeric':inputManifest(numeric)}
 if receipt['generatedInputsBeforeTests']!=receipt['generatedInputsAfterTests']:raise RuntimeError('Generated sources or lock changed during locked tests')
 if git(['status','--porcelain']):raise RuntimeError('Pinned source checkout changed')
 receipt['passed']=True
except BaseException as e:
 receipt['failure']=str(e);receipt['passed']=False;traceback.print_exc()
finally:
 receipt['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
