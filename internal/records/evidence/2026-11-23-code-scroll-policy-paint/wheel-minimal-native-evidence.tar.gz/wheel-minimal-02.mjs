import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {chromium} from '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/s67-734-calibration-4deb-04/candidate-consumer/node_modules/playwright-core/index.mjs';
const output='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/continuation-root-4deb/wheel-minimal-02';
fs.mkdirSync(output,{recursive:false});
const report={scope:'Standalone Chromium wheel/policy diagnostic, not Proto UI browser acceptance',node:process.version,startedAt:new Date().toISOString(),cases:[]};
const save=()=>fs.writeFileSync(path.join(output,'result.json'),JSON.stringify(report,null,2)+'\n');
save();
let browser;
try{
 browser=await chromium.launch({executablePath:'/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/playwright-browsers/chromium-1208/chrome-linux64/chrome',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 report.browser=browser.version();
 for(const excursion of [false]){
  const context=await browser.newContext({viewport:{width:1440,height:900}});
  const page=await context.newPage();
  const entry={excursion,stages:[]};report.cases.push(entry);save();
  try{
   await page.setContent('<!doctype html><html><head><style>html{scroll-behavior:auto}body{margin:0;height:3500px}pre{position:absolute;top:1222.59375px;left:376px;margin:0;width:640px;height:24.5px;line-height:24.5px;overflow:auto;overscroll-behavior-x:contain;overscroll-behavior-y:auto}pre code{white-space:pre}</style></head><body><pre><code><span class="line">export default {};</span></code></pre></body></html>');
   await page.evaluate(()=>{window.trace=[];document.addEventListener('wheel',e=>window.trace.push({trusted:e.isTrusted,dy:e.deltaY,time:e.timeStamp,observedAt:performance.now(),defaultPrevented:e.defaultPrevented,scrollY}),{capture:true,passive:true});});
   const pre=page.locator('pre');
   const raf=()=>page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
   for(const [name,policy] of [['initial-auto','auto'],['contain-negative','contain'],['restored-auto','auto']]){
    const quietStart=Date.now();await page.waitForFunction(()=>performance.now()-(window.trace.at(-1)?.observedAt??0)>=750,{},{timeout:2500});
    await pre.evaluate((el,value)=>{el.style.setProperty('overscroll-behavior-y',value,'important');el.scrollIntoView({block:'center'});},policy);
    await raf();
    await page.screenshot({path:path.join(output,name+'-policy.png')});
    const initial=await pre.evaluate(el=>({scrollY,rect:el.getBoundingClientRect().toJSON(),policy:getComputedStyle(el).overscrollBehaviorY,scrollHeight:el.scrollHeight,clientHeight:el.clientHeight,traceLength:window.trace.length}));
    const point={x:initial.rect.x+initial.rect.width/2,y:initial.rect.y+initial.rect.height/2};
    if(excursion&&name==='restored-auto'){await page.mouse.move(20,20);await raf();}
    await page.mouse.move(point.x,point.y);
    const readings=[];
    for(let i=0;i<14;i++){await page.mouse.wheel(0,-220);await raf();readings.push(await page.evaluate(()=>scrollY));}
    await page.waitForFunction(start=>window.trace.slice(start).reduce((sum,e)=>sum+e.dy,0)===-220*14,initial.traceLength,{timeout:2000});
    await raf();
    const final=await page.evaluate(start=>({scrollY,trace:window.trace.slice(start)}),initial.traceLength);
    entry.stages.push({name,initial,final,readings,diagnosticCondition:policy==='contain'?final.scrollY===initial.scrollY:final.scrollY<initial.scrollY-500,quietWaitMs:Date.now()-quietStart});
    save();
   }
  }catch(error){entry.failure=String(error);save();}
  finally{await context.close();}
 }
 report.completedAt=new Date().toISOString();save();
}catch(error){report.setupFailure=String(error);save();}
finally{await browser?.close();}