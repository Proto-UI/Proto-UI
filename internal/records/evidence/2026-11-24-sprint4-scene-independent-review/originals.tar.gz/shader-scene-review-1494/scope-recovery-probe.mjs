import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import crypto from 'node:crypto';
import {reviewBinding} from './review-binding.mjs';
const repo = process.env.PUI_REVIEW_REPO || '/workspace/scratch/1494db44bb7b/sprint4-shader';
const binding = reviewBinding(repo);
const req = createRequire(repo + '/package.json');
const ts = req('typescript');
const { Window } = req('happy-dom');
const sourcePath = process.argv[2] || new URL('./shader-scene-host.snapshot.ts', import.meta.url);
const outputPath = process.argv[3] || new URL('./scope-recovery-probe.json', import.meta.url);
const source = fs.readFileSync(sourcePath, 'utf8');
if (binding.stableFinal) assert.equal(source,fs.readFileSync(repo+'/packages/adapters/base/src/material/shader-scene-host.ts','utf8'));
const validatorSource = fs.readFileSync(repo + '/packages/adapters/base/src/material/shader-webgl2-host.ts', 'utf8');
const validatorCode = ts.transpileModule(validatorSource, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } }).outputText;
globalThis.__reviewValidate = (await import('data:text/javascript;base64,' + Buffer.from(validatorCode).toString('base64'))).validateWebShaderPublication;
const replaced = source.replace(/import\s*\{[\s\S]*?\}\s*from '\.\/shader-webgl2-host';/, 'const createWebShaderPresenter = (options: unknown) => globalThis.__reviewPhysical(options); const validateWebShaderPublication = globalThis.__reviewValidate;');
assert.notEqual(replaced, source);
const code = ts.transpileModule(replaced, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } }).outputText;
const api = await import('data:text/javascript;base64,' + Buffer.from(code).toString('base64'));
const tick = async () => { await new Promise(resolve => setTimeout(resolve, 0)); await new Promise(resolve => setTimeout(resolve, 0)); };
const results = [];
for (const shadow of [false, true]) {
  const name = `${shadow ? 'ShadowRoot' : 'light DOM'}: leave and reenter same scope with same immutable source frame`;
  const window = new Window();
  const doc = window.document;
  const scope = doc.createElement('section'), outside = doc.createElement('section');
  doc.body.append(scope, outside);
  const canvas = doc.createElement('canvas'); canvas.width = canvas.height = 1; scope.append(canvas);
  let home = scope, away = outside;
  if (shadow) {
    const a = doc.createElement('div'), b = doc.createElement('div');
    scope.append(a); outside.append(b);
    home = a.attachShadow({mode:'open'}); away = b.attachShadow({mode:'open'});
  }
  const root = doc.createElement('button'); home.append(root);
  const frame = Object.freeze({revision:1,width:1,height:1,pixels:Uint8Array.from([128,64,255,255]),canvas,scope});
  const counters = {current:0,subscribe:0,off:0,dispose:0,program:0};
  const sourceLease = {
    current() { counters.current++; return frame; },
    subscribe() { counters.subscribe++; return () => {counters.off++;}; },
    dispose() { counters.dispose++; },
  };
  const physical = {active:null,calls:[]};
  globalThis.__reviewPhysical = options => ({
    commit(publication, program, prepare=options.prepare, guard=()=>true) {
      prepare(); physical.active=null;
      physical.calls.push({program:!!program,view:publication.view,revision:publication.revision});
      if (program && guard()) {program(Object.freeze({})); physical.active={publication,guard};}
    },
    release() {physical.active=null;}, dispose() {physical.active=null;}, diagnostics() {return [];},
  });
  const presenter = api.createWebShaderScenePresenter({root:()=>root,prepare(){},host:{ownedScenes:{canvas:sourceLease}}});
  try {
    presenter.commit({slot:'canvas',view:1,revision:1,resources:2,key:'stable',fallback:[1,1,1,1]}, () => {counters.program++;return Object.freeze({});});
    await tick(); assert.equal(counters.program,1);
    away.append(root); await tick(); assert.equal(physical.active,null);
    assert(presenter.diagnostics().includes('shader-scene-scope-unavailable'));
    home.append(root); await tick();
    assert.equal(counters.program,2,'same scope and same immutable source frame must be usable after scope restoration');
    assert.equal(physical.active.guard(),true);
    assert.equal(counters.subscribe,1); assert.equal(counters.off,0); assert.equal(counters.dispose,0);
    results.push({name,pass:true,counters:{...counters}});
  } catch(error) {
    results.push({name,pass:false,message:error.message,actual:error.actual,expected:error.expected,counters:{...counters}});
  } finally {
    presenter.dispose(); window.happyDOM.cancelAsync();
  }
}
const report = {
  sourceSha256:crypto.createHash('sha256').update(source).digest('hex'),
  ordinalValidatorSourceSha256:crypto.createHash('sha256').update(validatorSource).digest('hex'),
  ...binding,
  harness:'Exact copied controller with only physical presenter replaced by recorded stub; Happy DOM MutationObserver and composed tree. No real browser or GPU execution.',
  counts:{total:results.length,pass:results.filter(x=>x.pass).length,fail:results.filter(x=>!x.pass).length},
  results,
};
fs.writeFileSync(outputPath,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
if (report.counts.fail) process.exitCode=1;
