import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';

/** Bind new executions only; preserved earlier reports are never rewritten. */
export function reviewBinding(repo) {
  const git = args => execFileSync('git', args, {cwd:repo,encoding:'utf8'}).trim();
  const reviewCommit = git(['rev-parse','HEAD']);
  const sourceTreeDirty = git(['status','--porcelain=v1','--untracked-files=all']) !== '';
  const expected = process.env.PUI_REVIEW_COMMIT;
  if (expected) {
    assert.equal(reviewCommit,expected,'the checkout must have the requested immutable review commit');
    assert.equal(sourceTreeDirty,false,'a stable review execution requires a clean checkout');
  }
  return Object.freeze({reviewCommit,sourceTreeDirty,stableFinal:!!expected&&!sourceTreeDirty});
}
