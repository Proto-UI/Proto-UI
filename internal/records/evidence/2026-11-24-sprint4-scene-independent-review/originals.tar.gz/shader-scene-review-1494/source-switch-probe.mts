import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {reviewBinding} from './review-binding.mjs';
const root=process.env.PUI_REVIEW_REPO || '/workspace/scratch/1494db44bb7b/sprint4-shader';
const binding=reviewBinding(root);
const req=createRequire(root+'/package.json'),ts=req('typescript');
const {snapshotShaderPresentation}=await import(pathToFileURL(root+'/packages/core/src/shader-presentation.ts').href);
const sourcePath=process.argv[2] || root+'/packages/adapters/base/src/material/shader-webgl2.ts';
const sink=fs.readFileSync(sourcePath,'utf8');
if(binding.stableFinal)assert.equal(sink,fs.readFileSync(root+'/packages/adapters/base/src/material/shader-webgl2.ts','utf8'));
const physical=fs.readFileSync(root+'/packages/adapters/base/src/material/shader-webgl2-host.ts','utf8');
const core=fs.readFileSync(root+'/packages/core/src/shader-presentation.ts','utf8');
async function load(source:string){const code=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText;return import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));}
const physicalApi=await load(physical);
globalThis.__reviewSnapshot=snapshotShaderPresentation;
globalThis.__reviewValidate=physicalApi.validateWebShaderPublication;
const transformed=sink.replace(/import\s*\{\s*snapshotShaderPresentation\s*\}\s*from '@proto.ui\/core';/,'const snapshotShaderPresentation = globalThis.__reviewSnapshot;').replace(/import\s*\{[\s\S]*?\}\s*from '\.\/shader-webgl2-host';/,'const createWebShaderPresenter = options => globalThis.__reviewPhysical(options); const validateWebShaderPublication = globalThis.__reviewValidate;');
const sinkApi=await load(transformed);
const results=[];
const effects={queueStyle(){},flushNow(){},requestFlush(){}};
function frame(kind:string,revision:number,view=1){return{view,revision,declaration:{version:1,source:kind==='owned-scene'?{kind,slot:'canvas'}:{kind,width:1,height:1,pixels:[0,0,0,255],colorSpace:'linear-srgb',alpha:'premultiplied',origin:'top-left'},passes:[{id:'copy',kernel:'copy-rgba8-v1',input:'$source'}],output:'copy',fallback:[1,1,1,1]},style:{tokens:[]}};}
function harness(){
 const pixels=[],scenes=[];let owner,afterSceneDispose;
 globalThis.__reviewPhysical=()=>{
  const state={commits:[],disposes:0,releases:[]};pixels.push(state);
  return{commit(publication,program){state.commits.push({view:publication.view,revision:publication.revision,program:!!program});},release(view){state.releases.push(view);},dispose(){state.disposes++;},diagnostics(){return[];}};
 };
 const host={createScenePresenter(){
  const state={commits:[],disposes:0,releases:[]};scenes.push(state);
  return{commit(publication){state.commits.push({view:publication.view,revision:publication.revision});},release(view){state.releases.push(view);},dispose(){state.disposes++;afterSceneDispose?.(state);},diagnostics(){return[];}};
 }};
 owner=sinkApi.createWebShaderPresentationSink(()=>null,effects,host);
 return{owner,pixels,scenes,onSceneDispose(callback){afterSceneDispose=callback;},details(){return{pixels:structuredClone(pixels),scenes:structuredClone(scenes)};}};
}
async function check(name,run){const h=harness();try{await run(h);results.push({name,pass:true,...h.details()});}catch(error){results.push({name,pass:false,message:error.message,actual:error.actual,expected:error.expected,...h.details()});}finally{h.owner.release(2);h.owner.release(1);}}
await check('scene to pixels to scene in one view retires both previous publishers and reacquires the scene',h=>{
 h.owner.commit(frame('owned-scene',1));assert.equal(h.scenes.length,1);
 h.owner.commit(frame('owned-pixels',2));assert.equal(h.scenes[0].disposes,1,'old scene capability must be retired on pixel selection');
 const painted=h.pixels.filter(x=>x.commits.some(c=>c.program));assert.equal(painted.length,1);assert.equal(painted[0].disposes,0);
 h.owner.commit(frame('owned-scene',3));assert.equal(painted[0].disposes,1,'old pixel presenter must be retired on scene selection');
 assert.equal(h.scenes.length,2);assert.deepEqual(h.scenes[1].commits,[{view:1,revision:3}]);assert.equal(h.scenes[1].disposes,0);
});
await check('old scene cleanup can reenter with a newer scene; outer pixel input does not resume',h=>{
 h.owner.commit(frame('owned-scene',1));
 h.onSceneDispose(state=>{if(state===h.scenes[0])h.owner.commit(frame('owned-scene',3));});
 h.owner.commit(frame('owned-pixels',2));
 assert.equal(h.scenes[0].disposes,1);assert.equal(h.scenes.length,2);assert.deepEqual(h.scenes[1].commits,[{view:1,revision:3}]);
 assert.equal(h.pixels.flatMap(x=>x.commits).filter(x=>x.program).length,0,'superseded outer pixel work must not publish');
});
await check('throwing borrowed scene capability cleanup is diagnosed and new pixel frame still commits',h=>{
 h.owner.commit(frame('owned-scene',1));h.onSceneDispose(()=>{throw undefined;});
 assert.doesNotThrow(()=>h.owner.commit(frame('owned-pixels',2)));assert.equal(h.scenes[0].disposes,1);
 assert.equal(h.pixels.flatMap(x=>x.commits).filter(x=>x.program&&x.revision===2).length,1);
 assert(h.owner.diagnostics().some(x=>/cleanup/.test(x)),'cleanup failure must have an explicit diagnostic');
});
await check('stale or invalid alternate kind does not retire the accepted scene',h=>{
 h.owner.commit(frame('owned-scene',2,2));
 h.owner.commit(frame('owned-pixels',99,1));
 assert.throws(()=>h.owner.commit(frame('owned-pixels',3,-1)));
 assert.equal(h.scenes[0].disposes,0);assert.equal(h.pixels.flatMap(x=>x.commits).filter(x=>x.program).length,0);
 h.owner.commit(frame('owned-scene',3,2));assert.equal(h.scenes.length,1);assert.equal(h.scenes[0].commits.length,2);
});
const sha=(value:string)=>crypto.createHash('sha256').update(value).digest('hex');
const report={sourceHashes:{runtimeSink:sha(sink),physicalValidator:sha(physical),coreSnapshot:sha(core)},...binding,procedure:'Actual Runtime sink and Core snapshot/physical ordinal validation; separate recorded physical and scene capabilities expose disposal, commits and cleanup reentry. This proves sink-level resource authority only, not a live Prototype source-kind switch or browser paint.',counts:{total:results.length,pass:results.filter(x=>x.pass).length,fail:results.filter(x=>!x.pass).length},results};
const basename=process.argv[3] || 'source-switch-probe';
fs.writeFileSync(new URL('./'+basename+'.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
fs.writeFileSync(new URL('./'+basename+'.sink.snapshot.ts',import.meta.url),sink);
console.log(JSON.stringify(report,null,2));if(report.counts.fail)process.exitCode=1;
