import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import crypto from 'node:crypto';
const req = createRequire('/workspace/scratch/1494db44bb7b/Proto-UI/package.json');
const ts = req('typescript');
const { Window } = req('happy-dom');
const source = fs.readFileSync(new URL('./shader-scene-host.snapshot.ts', import.meta.url), 'utf8');
const replaced = source.replace(/import\s*\{[\s\S]*?\}\s*from '\.\/shader-webgl2-host';/, 'const createWebShaderPresenter = (options: unknown) => globalThis.__reviewPhysical(options);');
assert.notEqual(replaced, source);
const code = ts.transpileModule(replaced, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } }).outputText;
const api = await import('data:text/javascript;base64,' + Buffer.from(code).toString('base64'));
const results = [];

function environment({ shadow = false } = {}) {
  const window = new Window();
  const doc = window.document;
  const scope = doc.createElement('section'), other = doc.createElement('section');
  doc.body.append(scope, other);
  const canvas = doc.createElement('canvas');
  canvas.width = 1; canvas.height = 1;
  scope.append(canvas);
  const root = doc.createElement('div');
  let parent = scope, destination = other;
  if (shadow) {
    const a = doc.createElement('div'), b = doc.createElement('div');
    scope.append(a); other.append(b);
    parent = a.attachShadow({ mode: 'open' });
    destination = b.attachShadow({ mode: 'open' });
  }
  parent.append(root);
  const makeFrame = (revision = 1, channels = [128, 64, 255, 255]) => Object.freeze({ revision, width: 1, height: 1, pixels: Uint8Array.from(channels), canvas, scope });
  return { window, doc, scope, other, canvas, root, destination, makeFrame };
}

function physicalHarness() {
  const instances = [];
  globalThis.__reviewPhysical = options => {
    const value = { calls: [], held: [], active: null, retired: false };
    instances.push(value);
    return {
      commit(frame, program, prepare = options.prepare, guard = () => true) {
        if (value.retired) return;
        prepare();
        value.calls.push({ kind: program ? 'program' : 'fallback', view: frame.view, revision: frame.revision });
        value.active = null;
        if (!program || !guard()) return;
        const result = program(Object.freeze({}));
        const held = { frame, guard, result };
        value.held.push(held);
        value.active = held;
      },
      release(view) { value.calls.push({ kind: 'release', view }); value.active = null; },
      dispose() { value.retired = true; value.active = null; },
      diagnostics() { return []; },
    };
  };
  return instances;
}
function lease(frame) {
  const callbacks = new Set();
  const counters = { current: 0, subscribe: 0, off: 0, dispose: 0, revoke: 0, draw: 0 };
  const value = {
    current() { counters.current++; return value.frame; },
    subscribe(callback) { counters.subscribe++; callbacks.add(callback); return () => { counters.off++; callbacks.delete(callback); }; },
    dispose() { counters.dispose++; }, revoke() { counters.revoke++; }, draw() { counters.draw++; },
    frame, callbacks, counters,
    invalidate() { for (const callback of [...callbacks]) callback(); },
  };
  return value;
}
const pub = (slot = 'canvas', revision = 1, view = 1) => ({ slot, revision, view, resources: 2, key: slot, fallback: [1, 1, 1, 1] });
const tick = async () => { await new Promise(resolve => setTimeout(resolve, 0)); await new Promise(resolve => setTimeout(resolve, 0)); };
function create(env, bindings) {
  const instances = physicalHarness();
  const output = [];
  const presenter = api.createWebShaderScenePresenter({ root: () => env.root, prepare() {}, host: { ownedScenes: bindings } });
  const program = (_device, owned) => { output.push(owned); return Object.freeze({}); };
  return { instances, physical: instances[0], presenter, output, program };
}
async function check(name, run) {
  try { await run(); results.push({ name, pass: true }); }
  catch (error) { results.push({ name, pass: false, message: error.message, actual: error.actual, expected: error.expected }); }
}

await check('opaque sRGB conversion and borrowed lease cleanup', () => {
  const env = environment(), src = lease(env.makeFrame()), h = create(env, { canvas: src });
  h.presenter.commit(pub(), h.program);
  assert.deepEqual(h.output[0].pixels, [55, 13, 255, 255]);
  assert.notEqual(h.output[0].pixels, src.frame.pixels);
  h.presenter.dispose();
  assert.equal(src.counters.off, 1);
  assert.deepEqual([src.counters.draw, src.counters.revoke, src.counters.dispose], [0, 0, 0]);
  env.window.happyDOM.cancelAsync();
});
await check('current throwing undefined invalidates held publication; later new frame recovers', () => {
  const env = environment(), src = lease(env.makeFrame()), h = create(env, { canvas: src });
  h.presenter.commit(pub(), h.program);
  const held = h.physical.held[0];
  let throwing = true;
  src.current = () => { if (throwing) throw undefined; return src.frame; };
  src.invalidate();
  assert.equal(h.physical.active, null);
  assert.equal(held.guard(), false);
  assert(h.presenter.diagnostics().includes('shader-scene-current-failed'));
  throwing = false; src.frame = env.makeFrame(2); src.invalidate();
  assert.equal(h.output.length, 2);
  h.presenter.dispose(); env.window.happyDOM.cancelAsync();
});
await check('subscribe throws after synchronous invalidation: fallback and no source read', () => {
  const env = environment(), src = lease(env.makeFrame());
  src.subscribe = callback => { callback(); throw 0; };
  const h = create(env, { canvas: src });
  h.presenter.commit(pub(), h.program);
  assert.equal(h.output.length, 0); assert.equal(src.counters.current, 0);
  assert.equal(h.physical.calls.at(-1).kind, 'fallback');
  assert(h.presenter.diagnostics().includes('shader-scene-subscribe-failed'));
  h.presenter.dispose(); env.window.happyDOM.cancelAsync();
});
await check('subscribe synchronous replacement disposes only the superseded subscription', () => {
  const env = environment(), a = lease(env.makeFrame()), b = lease(env.makeFrame());
  const h = create(env, { a, b });
  a.subscribe = callback => { a.counters.subscribe++; callback(); h.presenter.commit(pub('b', 2), h.program); return () => { a.counters.off++; }; };
  h.presenter.commit(pub('a'), h.program);
  assert.equal(a.counters.current, 0); assert.equal(a.counters.off, 1);
  assert.equal(b.counters.off, 0); assert.equal(h.output.length, 1);
  h.presenter.dispose(); assert.equal(b.counters.off, 1); env.window.happyDOM.cancelAsync();
});
await check('current synchronous replacement cannot publish old owner', () => {
  const env = environment(), a = lease(env.makeFrame()), b = lease(env.makeFrame());
  const h = create(env, { a, b });
  a.current = () => { a.counters.current++; h.presenter.commit(pub('b', 2), h.program); return a.frame; };
  h.presenter.commit(pub('a'), h.program);
  assert.equal(a.counters.off, 1); assert.equal(h.output.length, 1);
  assert.equal(h.physical.active.frame.slot, 'b');
  h.presenter.dispose(); env.window.happyDOM.cancelAsync();
});
await check('old held guard rejects source change without notification and new revision recovers', () => {
  const env = environment(), src = lease(env.makeFrame()), h = create(env, { canvas: src });
  h.presenter.commit(pub(), h.program);
  const held = h.physical.held[0];
  src.frame = env.makeFrame(2, [0, 255, 0, 255]);
  assert.equal(held.guard(), false);
  src.invalidate(); assert.equal(h.output.length, 2);
  src.frame = null; src.invalidate(); assert.equal(h.physical.active, null);
  h.presenter.dispose(); env.window.happyDOM.cancelAsync();
});
await check('late invalidation after release is inert and application lease not disposed', () => {
  const env = environment(), src = lease(env.makeFrame()), h = create(env, { canvas: src });
  h.presenter.commit(pub(), h.program);
  const late = [...src.callbacks][0];
  h.presenter.release(1);
  const count = h.physical.calls.length;
  late(); assert.equal(h.physical.calls.length, count);
  h.presenter.commit(pub('canvas', 2, 1), h.program); assert.equal(h.physical.calls.length, count);
  assert.equal(src.counters.off, 1); assert.equal(src.counters.dispose, 0);
  h.presenter.dispose(); env.window.happyDOM.cancelAsync();
});
await check('reentrant current invalidation is bounded and leaves fallback', () => {
  const env = environment(), src = lease(env.makeFrame()), h = create(env, { canvas: src });
  src.current = () => { src.counters.current++; src.invalidate(); return src.frame; };
  h.presenter.commit(pub(), h.program);
  assert(h.presenter.diagnostics().includes('shader-scene-reentrant-source'));
  assert.equal(h.physical.active, null); assert.equal(src.counters.off, 1);
  assert(src.counters.current <= 32);
  h.presenter.dispose(); env.window.happyDOM.cancelAsync();
});
await check('inherited slot binding and accessor slot binding are not invoked', () => {
  const env = environment(), src = lease(env.makeFrame());
  let reads = 0;
  const inherited = Object.create({ canvas: src });
  const h = create(env, inherited); h.presenter.commit(pub(), h.program);
  assert.equal(h.output.length, 0); h.presenter.dispose();
  const accessors = {}; Object.defineProperty(accessors, 'canvas', { get() { reads++; return src; } });
  const k = create(env, accessors); k.presenter.commit(pub(), k.program);
  assert.equal(k.output.length, 0); assert.equal(reads, 0);
  k.presenter.dispose(); env.window.happyDOM.cancelAsync();
});
await check('document light-DOM movement outside scope retires the current publication', async () => {
  const env = environment(), src = lease(env.makeFrame()), h = create(env, { canvas: src });
  h.presenter.commit(pub(), h.program); await tick();
  env.destination.append(env.root); await tick();
  assert.equal(h.physical.active, null);
  assert(h.presenter.diagnostics().includes('shader-scene-scope-unavailable'));
  h.presenter.dispose(); env.window.happyDOM.cancelAsync();
});
await check('ShadowRoot movement outside scope retires the current publication', async () => {
  const env = environment({ shadow: true }), src = lease(env.makeFrame()), h = create(env, { canvas: src });
  h.presenter.commit(pub(), h.program); await tick();
  assert.equal(h.output.length, 1);
  env.destination.append(env.root); await tick();
  try { assert.equal(h.physical.active, null); }
  finally { h.presenter.dispose(); env.window.happyDOM.cancelAsync(); }
});

const report = {
  sourceSha256: crypto.createHash('sha256').update(source).digest('hex'),
  sourceIsStableFinal: false,
  sourceBase: '4009346439913420769db1fa777354c6479f4846',
  harness: 'TypeScript transpilation of exact copied controller; physical presenter replaced with recorded stub; happy-dom@15.11.7 for scope and MutationObserver. No GPU or browser execution.',
  counts: { total: results.length, pass: results.filter(x => x.pass).length, fail: results.filter(x => !x.pass).length }, results,
};
fs.writeFileSync(new URL('./controller-probe.json', import.meta.url), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
if (report.counts.fail) process.exitCode = 1;
