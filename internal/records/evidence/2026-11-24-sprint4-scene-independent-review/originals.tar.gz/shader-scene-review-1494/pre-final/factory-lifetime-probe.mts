import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { snapshotShaderPresentation } from '../sprint4-shader/packages/core/src/shader-presentation';
import { nativeShaderArtifacts } from '../sprint4-shader/packages/compiler/src/native-shader';
const req = createRequire('/workspace/scratch/1494db44bb7b/Proto-UI/package.json');
const ts = req('typescript');
const root = '/workspace/scratch/1494db44bb7b/sprint4-shader';
const sinkSource = fs.readFileSync(root + '/packages/adapters/base/src/material/shader-webgl2.ts', 'utf8');
const ownerSource = nativeShaderArtifacts(['copy-rgba8-v1'], true).find(f => f.path.endsWith('owner-web-v1.ts'))!.contents;
globalThis.__reviewSnapshot = snapshotShaderPresentation;
async function load(source: string) {
  let code = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } }).outputText;
  code = code.replace(/import \{[^}]+\} from '@proto.ui\/core';/, 'const snapshotShaderPresentation = globalThis.__reviewSnapshot;');
  code = code.replace(/import \{[^}]+\} from '\.\/(?:shader-webgl2-host|webgl2-host-v1)';/, 'const createWebShaderPresenter = options => globalThis.__reviewPhysical(options);');
  return import('data:text/javascript;base64,' + Buffer.from(code).toString('base64'));
}
const sinkApi = await load(sinkSource), ownerApi = await load(ownerSource);
const results = [];
function physicalHarness() {
  const instances = [];
  globalThis.__reviewPhysical = _options => {
    const instance = { calls: [], disposed: 0, reasons: [] };
    instances.push(instance);
    return {
      commit(frame, program, _prepare, _guard, reason) { instance.calls.push({ frame, program: !!program }); if(reason)instance.reasons.push(reason); },
      release(view) { instance.calls.push({ release: view }); },
      dispose() { instance.disposed++; },
      diagnostics() { return instance.reasons; },
    };
  };
  return instances;
}
function capability() {
  const counters = { commits: 0, releases: [], disposes: 0 };
  const api = { commit() { counters.commits++; }, release(view) { counters.releases.push(view); }, dispose() { counters.disposes++; }, diagnostics() { return []; } };
  return { api, counters };
}
function frame(view = 1, revision = 1, kind = 'owned-scene') {
  return { view, revision, declaration: { version: 1,
    source: kind === 'owned-scene' ? { kind, slot: 'canvas' } : { kind, width: 1, height: 1, pixels: [0,0,0,255], colorSpace: 'linear-srgb', alpha: 'premultiplied', origin: 'top-left' },
    passes: [{ id: 'copy', kernel: 'copy-rgba8-v1', input: '$source' }], output: 'copy', fallback: [1,1,1,1] }, style: { tokens: [] } };
}
const effects = { queueStyle() {}, flushNow() {}, requestFlush() {} };
function native(host) { return ownerApi.createNativeShader({ host, setup() {}, alive: () => true, root: () => null, prepare() {} }); }
function declare(owner) { owner.declareScene('canvas', 2, 'canvas', [1,1,1,1], () => Object.freeze({})); }
async function check(name, fn) { try { await fn(); results.push({ name, pass: true }); } catch(error) { results.push({ name, pass: false, error: error.message }); } }

await check('Runtime factory absent from unused and owned-pixel path', () => {
  physicalHarness(); let reads=0;
  const host = { get createScenePresenter() { reads++; throw new Error('must not select'); } };
  const sink = sinkApi.createWebShaderPresentationSink(() => null, effects, host);
  assert.equal(reads,0); sink.commit(frame(1,1,'owned-pixels')); assert.equal(reads,0); sink.release(1);
});
await check('Runtime synchronous release during acquisition retires returned capability', () => {
  physicalHarness(); const cap=capability(); let sink;
  const host = { createScenePresenter() { sink.release(1); return cap.api; } };
  sink = sinkApi.createWebShaderPresentationSink(() => null, effects, host); sink.commit(frame());
  assert.equal(cap.counters.commits,0); assert.equal(cap.counters.disposes,1);
});
await check('Runtime recursive newer commit keeps only newest capability', () => {
  physicalHarness(); const old=capability(), next=capability(); let sink, acquiring=true;
  const host={ createScenePresenter() { if(acquiring){ acquiring=false; sink.commit(frame(2,2)); return old.api; } return next.api; } };
  sink=sinkApi.createWebShaderPresentationSink(() => null,effects,host); sink.commit(frame());
  assert.equal(old.counters.commits,0); assert.equal(old.counters.disposes,1); assert.equal(next.counters.commits,1); assert.equal(next.counters.disposes,0); sink.release(2);
});
await check('Runtime acquisition throwing undefined publishes named fallback', () => {
  const physical=physicalHarness(); const sink=sinkApi.createWebShaderPresentationSink(() => null,effects,{createScenePresenter(){throw undefined;}});
  assert.doesNotThrow(()=>sink.commit(frame()));
  assert.equal(physical[0].calls.at(-1).program,false); assert(sink.diagnostics().includes('shader-scene-host-failed')); sink.release(1);
});
await check('native scene-capable owner keeps host factory idle for owned pixels', () => {
  physicalHarness(); let reads=0; const owner=native({get createScenePresenter(){reads++;throw new Error('must not select');}});
  owner.declare('pixels',[1,1,1,1],()=>({})); owner.mount(); assert.equal(reads,0); owner.dispose();
});
await check('native factory synchronous terminal disposal does not dereference retired declaration', () => {
  physicalHarness(); const cap=capability(); let owner;
  owner=native({createScenePresenter(){owner.dispose();return cap.api;}});declare(owner);
  assert.doesNotThrow(()=>owner.mount()); assert.equal(cap.counters.commits,0);assert.equal(cap.counters.disposes,1);
});
await check('native factory synchronous detach retires returned capability and remount starts fresh', () => {
  physicalHarness(); const old=capability(),next=capability();let owner,initial=true;
  owner=native({createScenePresenter(){if(initial){initial=false;owner.detach();return old.api;}return next.api;}});declare(owner);
  owner.mount();assert.equal(old.counters.commits,0);assert.equal(old.counters.disposes,1);
  owner.mount();assert.equal(next.counters.commits,1);owner.dispose();assert.equal(next.counters.disposes,1);
});
await check('native recursive refresh preserves newest capability', () => {
  physicalHarness(); const old=capability(),next=capability();let owner,initial=true;
  owner=native({createScenePresenter(){if(initial){initial=false;owner.refresh();return old.api;}return next.api;}});declare(owner);owner.mount();
  assert.equal(old.counters.commits,0);assert.equal(old.counters.disposes,1);assert.equal(next.counters.commits,1);owner.dispose();
});
await check('native acquisition throwing false produces fallback', () => {
  const physical=physicalHarness(); const owner=native({createScenePresenter(){throw false;}});declare(owner);
  assert.doesNotThrow(()=>owner.mount());assert.equal(physical[0].calls.at(-1).program,false);assert(physical[0].reasons.includes('shader-scene-host-failed'));owner.dispose();
});
const sha=(x:string)=>crypto.createHash('sha256').update(x).digest('hex');
const report={sourceHashes:{runtimeSink:sha(sinkSource),emittedNativeOwner:sha(ownerSource),nativeEmitter:sha(fs.readFileSync(root+'/packages/compiler/src/native-shader.ts','utf8'))},stableFinal:false,procedure:'Exact Runtime sink and actual emitted native shader owner transpiled, only physical presenter stubbed. Actual Core declaration snapshot validation. No browser or GPU run.',counts:{total:results.length,pass:results.filter(x=>x.pass).length,fail:results.filter(x=>!x.pass).length},results};
fs.writeFileSync(new URL('./factory-lifetime-probe.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
fs.writeFileSync(new URL('./runtime-sink-reviewed.snapshot.ts',import.meta.url),sinkSource);
fs.writeFileSync(new URL('./native-owner-reviewed.snapshot.ts',import.meta.url),ownerSource);
console.log(JSON.stringify(report,null,2));if(report.counts.fail)process.exitCode=1;
