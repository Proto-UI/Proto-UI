import fs from 'node:fs';
import { createRequire } from 'node:module';
import crypto from 'node:crypto';
import { compilePrototype } from '../sprint4-shader/packages/compiler/src/compile';
const req = createRequire('/workspace/scratch/1494db44bb7b/Proto-UI/package.json');
const esbuild = req('esbuild');
const root = '/workspace/scratch/1494db44bb7b/sprint4-shader';
const fixture = fs.readFileSync(root + '/packages/compiler/test/fixtures/shader-scene-owner.proto.ts', 'utf8');
const paths = ['react-source.ts', 'vue-source.ts', 'vue2-source.ts', 'web-component-source.ts', 'native-async.ts', 'native-shader.ts'];
const sourceHashes = Object.fromEntries(paths.map(p => [p, crypto.createHash('sha256').update(fs.readFileSync(root + '/packages/compiler/src/' + p)).digest('hex')]));
const results = [];
for (const profile of ['react-dom-source-v1', 'vue-source-v1', 'vue2-source-v1', 'web-component-source-v1']) {
  for (const componentName of ['MyScene', 'createComponent', 'createShaderHost']) {
    const compiled = compilePrototype(fixture, { profile, componentName });
    if (!compiled.ok) {
      results.push({ profile, componentName, admitted: false, diagnostics: compiled.diagnostics });
      continue;
    }
    try {
      await esbuild.transform(compiled.value.output.code, { loader: profile === 'react-dom-source-v1' ? 'tsx' : 'ts', target: 'es2022' });
      results.push({ profile, componentName, admitted: true, syntaxValid: true });
    } catch (error) {
      results.push({ profile, componentName, admitted: true, syntaxValid: false, errors: error.errors?.map(e => ({ text: e.text, line: e.location?.line })) ?? String(error) });
    }
  }
}
const report = { sourceHashes, stableFinal: false, procedure: 'Actual compilePrototype entry, then independent esbuild syntax validation of actual emitted code; no browser execution.', results };
fs.writeFileSync(new URL('./factory-names-probe.json', import.meta.url), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
if (results.some(r => r.admitted && r.syntaxValid === false)) process.exitCode = 1;
