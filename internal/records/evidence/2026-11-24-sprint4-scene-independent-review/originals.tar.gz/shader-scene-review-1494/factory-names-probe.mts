import fs from 'node:fs';
import { createRequire } from 'node:module';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';
import {reviewBinding} from './review-binding.mjs';
const root = process.env.PUI_REVIEW_REPO || '/workspace/scratch/1494db44bb7b/sprint4-shader';
const binding = reviewBinding(root);
const { compilePrototype } = await import(pathToFileURL(root + '/packages/compiler/src/compile.ts').href);
const req = createRequire(root + '/package.json');
const esbuild = req('esbuild');
const fixture = fs.readFileSync(root + '/packages/compiler/test/fixtures/shader-scene-owner.proto.ts', 'utf8');
const paths = ['react-source.ts', 'vue-source.ts', 'vue2-source.ts', 'web-component-source.ts', 'native-async.ts', 'native-shader.ts'];
const sourceHashes = Object.fromEntries(paths.map(p => [p, crypto.createHash('sha256').update(fs.readFileSync(root + '/packages/compiler/src/' + p)).digest('hex')]));
const results = [];
for (const profile of ['react-dom-source-v1', 'vue-source-v1', 'vue2-source-v1', 'web-component-source-v1']) {
  for (const componentName of ['MyScene', 'createComponent', 'createShaderHost']) {
    const compiled = compilePrototype(fixture, { profile, componentName });
    if (!compiled.ok) {
      results.push({ profile, componentName, admitted: false, diagnostics: compiled.diagnostics });
      continue;
    }
    try {
      await esbuild.transform(compiled.value.output.code, { loader: profile === 'react-dom-source-v1' ? 'tsx' : 'ts', target: 'es2022' });
      results.push({ profile, componentName, admitted: true, syntaxValid: true });
    } catch (error) {
      results.push({ profile, componentName, admitted: true, syntaxValid: false, errors: error.errors?.map(e => ({ text: e.text, line: e.location?.line })) ?? String(error) });
    }
  }
}
const checks = results.map(result => ({...result, pass: result.componentName === 'MyScene' ? result.admitted && result.syntaxValid === true : !result.admitted}));
const report = { sourceHashes, fixtureSha256: crypto.createHash('sha256').update(fixture).digest('hex'), ...binding, procedure: 'Actual compilePrototype entry, then independent esbuild syntax validation of actual emitted code. Every MyScene control must be admitted and parse; each conflicting factory name must be refused. No browser execution.', counts: {total:checks.length,pass:checks.filter(x=>x.pass).length,fail:checks.filter(x=>!x.pass).length}, results:checks };
fs.writeFileSync(new URL('./factory-names-probe.json', import.meta.url), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
if (report.counts.fail) process.exitCode = 1;
