import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import {reviewBinding} from './review-binding.mjs';
const repo=process.env.PUI_REVIEW_REPO || '/workspace/scratch/1494db44bb7b/sprint4-shader';
const binding=reviewBinding(repo);
const req=createRequire(repo+'/package.json');
const ts=req('typescript'), {Window}=req('happy-dom');
const root=repo+'/packages/adapters/base/src/material/';
const host=fs.readFileSync(root+'shader-webgl2-host.ts','utf8');
const scene=fs.readFileSync(root+'shader-scene-host.ts','utf8');
fs.writeFileSync(new URL('./physical-publication-reviewed.snapshot.ts',import.meta.url),host);
fs.writeFileSync(new URL('./scene-publication-reviewed.snapshot.ts',import.meta.url),scene);
const ast=ts.createSourceFile('host.ts',host,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
const device=ast.statements.find(x=>ts.isFunctionDeclaration(x)&&x.name?.text==='createWebShaderResources');
assert(device);
const amended=host.slice(0,device.getStart(ast))+'function createWebShaderResources(document: Document, lost: () => void) { return globalThis.__reviewDevice(document,lost); }'+host.slice(device.end);
async function moduleFrom(source){const code=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText;return import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));}
const hostApi=await moduleFrom(amended);
globalThis.__reviewPhysical=hostApi.createWebShaderPresenter;
globalThis.__reviewValidate=hostApi.validateWebShaderPublication;
const sceneApi=await moduleFrom(scene.replace(/import\s*\{[\s\S]*?\}\s*from '\.\/shader-webgl2-host';/,'const createWebShaderPresenter = options => globalThis.__reviewPhysical(options); const validateWebShaderPublication = globalThis.__reviewValidate;'));
const reports=[];
function setup(shadow=false){
 const window=new Window(),document=window.document,scope=document.createElement('section'),other=document.createElement('section');
 document.body.append(scope,other);const canvas=document.createElement('canvas');canvas.width=canvas.height=1;scope.append(canvas);
 const target=document.createElement('div');let parent=scope,destination=other;
 if(shadow){const a=document.createElement('div'),b=document.createElement('div');scope.append(a);other.append(b);parent=a.attachShadow({mode:'open'});destination=b.attachShadow({mode:'open'});}
 parent.append(target);
 const held=[],resources=[];let observerDeliveries=0;
 const Observer=window.MutationObserver;
 window.MutationObserver=class extends Observer{constructor(callback){super((...args)=>{observerDeliveries++;callback(...args);});}};
 const create=document.createElement.bind(document);
 document.createElement=(name,...args)=>name==='img'?{src:'',decode(){return{then(ok,fail){held.push({ok,fail});}};}}:create(name,...args);
 globalThis.__reviewDevice=()=>{const state={disposed:0};resources.push(state);return{upload(){return{};},copy(){return{};},tint(){return{};},image(){return'data:image/png;base64,AA==';},dispose(){state.disposed++;}};};
 const makeFrame=(revision=1)=>Object.freeze({revision,width:1,height:1,pixels:Uint8Array.from([128,64,255,255]),canvas,scope});
 const listeners=new Set();let sourceFrame=makeFrame(),read=()=>sourceFrame;
 const source={current(){return read();},subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn);}};
 const presenter=sceneApi.createWebShaderScenePresenter({root:()=>target,prepare(){},host:{ownedScenes:{canvas:source}}});
 const commit=(revision=1)=>presenter.commit({view:1,revision,key:'scene',slot:'canvas',resources:2,fallback:[1,1,1,1]},(device,source)=>device.copy(device.upload(source)));
 return{window,document,scope,other,canvas,target,destination,held,resources,makeFrame,presenter,commit,get deliveries(){return observerDeliveries;},setFrame(value){sourceFrame=value;},setRead(fn){read=fn;},getFrame(){return sourceFrame;},close(){presenter.dispose();window.happyDOM.cancelAsync();}};
}
async function check(name,action,{shadow=false,valid=false}={}){
 const env=setup(shadow);
 try{
  env.commit();assert.equal(env.held.length,1);assert.equal(env.target.style.getPropertyValue('background-image'),'none');
  action(env);assert.equal(env.deliveries,0,'observer must not have delivered before the old decode callable');
  env.held[0].ok();
  const paint=env.target.style.getPropertyValue('background-image');
  if(valid)assert(paint.startsWith('url('));else assert.equal(paint,'none','old decode must not publish stale pixels');
  reports.push({name,pass:true,observerDeliveriesAtDecode:env.deliveries,paint,deviceDisposals:env.resources.map(x=>x.disposed)});
 }catch(error){reports.push({name,pass:false,error:error.message});}
 finally{env.close();env.extraWindow?.happyDOM.cancelAsync();}
}
await check('unchanged source publishes held image positive control',()=>{}, {valid:true});
await check('light-DOM move outside scope rejects held decode before observer delivery',e=>e.destination.append(e.target));
await check('ShadowRoot move outside scope rejects held decode before observer delivery',e=>e.destination.append(e.target),{shadow:true});
await check('Document adoption rejects held decode before the old Document observer delivery',e=>{e.extraWindow=new Window();e.extraWindow.document.adoptNode(e.target);e.extraWindow.document.body.append(e.target);assert.equal(e.target.ownerDocument,e.extraWindow.document);});
await check('source loss without notification rejects held decode',e=>e.setFrame(null));
await check('source revision replacement without notification rejects held decode',e=>e.setFrame(e.makeFrame(2)));
await check('source current throwing undefined at decode rejects held decode',e=>e.setRead(()=>{throw undefined;}));
await check('source current moves the surface during decode guard; latest scope is used',e=>{const frame=e.getFrame();e.setRead(()=>{e.destination.append(e.target);return frame;});},{shadow:true});
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const result={sourceHashes:{physical:sha(host),scene:sha(scene)},...binding,procedure:'Actual scene controller plus actual physical publication/retirement functions. Only the selected createWebShaderResources GPU constructor is replaced with a counted device and image decode returns an explicitly held callable. Actual ordinal validation; real happy-dom style and MutationObserver; old decode invoked synchronously before any observer callback. This is not browser/GPU evidence.',counts:{total:reports.length,pass:reports.filter(x=>x.pass).length,fail:reports.filter(x=>!x.pass).length},reports};
fs.writeFileSync(new URL('./publication-guard-probe.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));if(result.counts.fail)process.exitCode=1;
