import pathlib,subprocess,os
p=pathlib.Path('/home/ezra/proto-ui-wc-budget-cb5d-control/whitepaper-candidate-v4')
env=os.environ.copy();env['PATH']='/home/ezra/proto-ui-release-gate-cb5d-control/tools/node_modules/node/bin:'+env['PATH']
with open(p/'render.log','wb') as f:r=subprocess.run(['node',str(p/'render.mjs')],stdout=f,stderr=subprocess.STDOUT,env=env)
(p/'render.exit').write_text(str(r.returncode)+'\n')
