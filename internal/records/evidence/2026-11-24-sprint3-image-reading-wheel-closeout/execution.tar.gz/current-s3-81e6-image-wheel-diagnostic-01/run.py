import os,json,subprocess,hashlib,traceback,datetime,difflib
from pathlib import Path
E=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/integration-20261123-0320')
R=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
D=Path(__file__).resolve().parent
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def save():
 p=D/'status.tmp';p.write_text(json.dumps(S,ensure_ascii=False,indent=2)+'\n');os.replace(p,D/'status.json')
env=dict(os.environ)
env['PATH']=str(R/'tools/node-v24.22.3-linux-x64/bin')+':'+env.get('PATH','')
env['COREPACK_HOME']=str(R/'corepack-cache')
env['ASTRO_TELEMETRY_DISABLED']='1'
env['GIT_OPTIONAL_LOCKS']='0';env['GIT_NO_LAZY_FETCH']='1'
def run(name,argv,timeout=120,allowed=(0,)):
 S['stage']=name;save();beg=now()
 with (D/(name+'.stdout')).open('wb') as out,(D/(name+'.stderr')).open('wb') as err:
  p=subprocess.Popen(argv,cwd=C,env=env,stdout=out,stderr=err);S['child']={'pid':p.pid,'argv':argv};save();expired=False
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   expired=True;p.terminate()
   try:code=p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();code=p.wait()
 S.pop('child',None);S['steps'].append({'name':name,'argv':argv,'started':beg,'finished':now(),'exit':code,'timedOut':expired});save()
 assert not expired and code in allowed,name+' exit='+str(code)
 return (D/(name+'.stdout')).read_text()
def failure(e):
 S['status']='failed';S['error']=repr(e);S['traceback']=traceback.format_exc();S['finished']=now();save()
def source(rel): 
 b=(C/rel).read_bytes();return {'sha256':sha(b),'bytes':len(b)}


import signal,re
C=Path('/var/tmp/proto-ui-s3-acceptance-1bb6-20261123-2147')
assert str(C).startswith('/var/tmp/proto-ui-') and C.is_dir() and str(C)!='undefined'
temp=Path('/var/tmp/proto-ui-s3-image-diagnostic-temp-20261123-2305')
temp.mkdir(exist_ok=True)
env['TMPDIR']=str(temp)
env['CHROME_PATH']=str(R/'tools/playwright-browsers/chromium-1208/chrome-linux64/chrome')
assert Path(env['CHROME_PATH']).is_file()
for k in ['PROTO_UI_BROWSER_BASE_URL','PROTO_UI_BROWSER_SOURCE_BASE_URL','PROTO_UI_SHADCN_SCROLL_AREA_BROWSER_RUNTIME','PROTO_UI_RUNTIME_PHASE','PROTO_UI_RUNTIME_SHARD','PROTO_UI_RUNTIME_SELECTION_FILE','PROTO_UI_RUNTIME_PROGRESS_FILE','PUI_FINF_FEATURE_EVIDENCE_DIR','IMAGE_PREVIEW_EVIDENCE_DIR','PROTO_UI_RUNTIME_EVIDENCE_DIR']:
 env.pop(k,None)
head='81e6b1b2cd516feb276207a6ac3afbebd70fc4a6'
env['CANDIDATE_SHA']=head
env['IMAGE_PREVIEW_WHEEL_DIAGNOSTICS']='1'
env['IMAGE_PREVIEW_EVIDENCE_DIR']=str(D/'captures')
env['PROTO_UI_IMAGE_DIAGNOSTIC_TASK']=str(D)
test='apps/www/src/components/documentation-image-preview.browser.test.ts'
S={'status':'running','started':now(),'pid':os.getpid(),'checkout':str(C),'baseHead':head,'steps':[],'sourcePatched':False,'scope':'One selected original image case; 31 other cases filtered, not passed. Passive diagnostic only.'}
save()
try:
 Q=json.loads((E/'current-s5-1afa-native-scope-regression-01/status.json').read_text())
 assert Q['status']=='passed-native-red-2-2-green-4-and-author-60' and Q.get('finished')
 assert run('head',['git','rev-parse','HEAD']).strip()==head
 assert not run('clean',['git','status','--porcelain=v1','--untracked-files=all']).strip()
 S['tree']=run('tree',['git','rev-parse','HEAD^{tree}']).strip()
 raw=(C/test).read_bytes();assert sha(raw)=='ec971a302d56f4371f022fba5e7d5867edc81b2093530b5f0b9920cc06d5039e'
 (D/'before.test.ts').write_bytes(raw)
 bound={test,'package.json','pnpm-lock.yaml','scripts/test/sprint3-followup-evidence.mjs'}
 for value in re.findall(r"(?:from\s+|import\s*)['\"](\.[^'\"]+)['\"]",raw.decode()):
  p=(C/test).parent/value
  for q in [p,p.with_suffix('.ts'),p.with_suffix('.mjs'),p.with_suffix('.tsx'),p/'index.ts']:
   if q.is_file() and C in q.resolve().parents:
    bound.add(str(q.resolve().relative_to(C)));break
 for p in (C/'apps/www/src/components').glob('documentation-image-preview*'):
  if p.is_file():bound.add(str(p.relative_to(C)))
 S['bindingsBefore']={rel:source(rel) for rel in sorted(bound)}
 S['node']=run('node-version',['node','--version']).strip()
 S['chrome']=run('chrome-version',[env['CHROME_PATH'],'--version']).strip()
 S['environment']={k:env.get(k) for k in ['PATH','TMPDIR','CHROME_PATH','CANDIDATE_SHA','IMAGE_PREVIEW_WHEEL_DIAGNOSTICS','IMAGE_PREVIEW_EVIDENCE_DIR','ASTRO_TELEMETRY_DISABLED']}
 P=E/'current-1743-image-wheel-diagnostic-v2/candidate.patch'
 b=P.read_bytes();assert len(b)==8110 and sha(b)=='bcc6143dc21059c1f2205da055b77fd40086ccebcb07b98fab9b9825821096a5'
 (D/'candidate.patch').write_bytes(b)
 run('patch-check',['git','apply','--check',str(D/'candidate.patch')])
 run('patch-apply',['git','apply',str(D/'candidate.patch')]);S['sourcePatched']=True;save()
 assert source(test)['sha256']=='0ef679987b90ae72a2aa46e9ac4ac3082506a5389223253327da91054f6f553c'
 run('normal-format',['node','node_modules/prettier/bin/prettier.cjs','--write',test])
 run('diff-check',['git','diff','--check'])
 S['testAfter']=source(test);(D/'after.test.ts').write_bytes((C/test).read_bytes());save()
 argv=['corepack','pnpm@10.32.1','exec','vitest','run',test,'--maxWorkers=1','--minWorkers=1','--no-file-parallelism','--reporter=verbose','--reporter=json','--outputFile='+str(D/'vitest.json'),'-t','migrates the actual en whitepaper viewer at 1280px dark']
 S['stage']='original-one-case';beg=now();save();expired=False
 with (D/'original-one-case.stdout').open('wb') as out,(D/'original-one-case.stderr').open('wb') as err:
  p=subprocess.Popen(argv,cwd=C,env=env,stdout=out,stderr=err,start_new_session=True)
  S['child']={'pid':p.pid,'pgid':p.pid,'argv':argv};save()
  try:code=p.wait(timeout=420)
  except subprocess.TimeoutExpired:
   expired=True
   try:os.killpg(p.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:code=p.wait(timeout=5)
   except subprocess.TimeoutExpired:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    code=p.wait()
 S.pop('child',None)
 S['steps'].append({'name':'original-one-case','argv':argv,'started':beg,'finished':now(),'exit':code,'timedOut':expired,'outerResourceTimeoutSeconds':420,'caseTimeoutMs':90000,'setupTimeoutMs':240000,'originalPollTimeoutMs':1000})
 save()
 assert not expired and code in (0,1),'Diagnostic runner or outer resource failure'
 j=json.loads((D/'vitest.json').read_text())
 S['counts']={k:j.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests','success']}
 selected=[a for f in j['testResults'] for a in f['assertionResults'] if a['status'] in ('passed','failed')]
 S['selected']=[{k:a.get(k) for k in ['fullName','title','status','failureMessages']} for a in selected]
 assert len(selected)==1 and selected[0]['title']=='migrates the actual en whitepaper viewer at 1280px dark'
 assert j['numTotalTests']==32 and j['numPendingTests']==31 and j.get('numTodoTests',0)==0
 for rel,item in S['bindingsBefore'].items():
  if rel!=test:assert source(rel)==item,rel
 assert source(test)==S['testAfter']
 S['artifacts']=[]
 if (D/'captures').exists():
  for p in sorted((D/'captures').rglob('*')):
   if p.is_file():
    b=p.read_bytes();S['artifacts'].append({'path':str(p.relative_to(D)),'bytes':len(b),'sha256':sha(b)})
 S['diffSha256']=sha(run('final-diff',['git','diff','--binary']).encode())
 S['status']='diagnostic-completed-case-'+selected[0]['status'];S['finished']=now();save()
except BaseException as e:failure(e);raise
