import os,json,subprocess,hashlib,traceback,datetime,difflib
from pathlib import Path
E=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/integration-20261123-0320')
R=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
D=Path(__file__).resolve().parent
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def save():
 p=D/'status.tmp';p.write_text(json.dumps(S,ensure_ascii=False,indent=2)+'\n');os.replace(p,D/'status.json')
env=dict(os.environ)
env['PATH']=str(R/'tools/node-v24.22.3-linux-x64/bin')+':'+env.get('PATH','')
env['COREPACK_HOME']=str(R/'corepack-cache')
env['ASTRO_TELEMETRY_DISABLED']='1'
env['GIT_OPTIONAL_LOCKS']='0';env['GIT_NO_LAZY_FETCH']='1'
def run(name,argv,timeout=120,allowed=(0,)):
 S['stage']=name;save();beg=now()
 with (D/(name+'.stdout')).open('wb') as out,(D/(name+'.stderr')).open('wb') as err:
  p=subprocess.Popen(argv,cwd=C,env=env,stdout=out,stderr=err);S['child']={'pid':p.pid,'argv':argv};save();expired=False
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   expired=True;p.terminate()
   try:code=p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();code=p.wait()
 S.pop('child',None);S['steps'].append({'name':name,'argv':argv,'started':beg,'finished':now(),'exit':code,'timedOut':expired});save()
 assert not expired and code in allowed,name+' exit='+str(code)
 return (D/(name+'.stdout')).read_text()
def failure(e):
 S['status']='failed';S['error']=repr(e);S['traceback']=traceback.format_exc();S['finished']=now();save()
def source(rel): 
 b=(C/rel).read_bytes();return {'sha256':sha(b),'bytes':len(b)}


import signal,re
C=Path('/var/tmp/proto-ui-s3-acceptance-1bb6-20261123-2147')
assert str(C).startswith('/var/tmp/proto-ui-') and C.is_dir() and str(C)!='undefined'
temp=Path('/var/tmp/proto-ui-s3-image-author-fix-temp-20261123-2316');temp.mkdir(exist_ok=True)
env['TMPDIR']=str(temp)
env['CHROME_PATH']=str(R/'tools/playwright-browsers/chromium-1208/chrome-linux64/chrome')
assert Path(env['CHROME_PATH']).is_file()
for k in ['PROTO_UI_BROWSER_BASE_URL','PROTO_UI_BROWSER_SOURCE_BASE_URL','PROTO_UI_SHADCN_SCROLL_AREA_BROWSER_RUNTIME','PROTO_UI_RUNTIME_PHASE','PROTO_UI_RUNTIME_SHARD','PROTO_UI_RUNTIME_SELECTION_FILE','PROTO_UI_RUNTIME_PROGRESS_FILE','PUI_FINF_FEATURE_EVIDENCE_DIR','IMAGE_PREVIEW_EVIDENCE_DIR','PROTO_UI_RUNTIME_EVIDENCE_DIR']:
 env.pop(k,None)
head='81e6b1b2cd516feb276207a6ac3afbebd70fc4a6'
env['CANDIDATE_SHA']=head
env['IMAGE_PREVIEW_WHEEL_DIAGNOSTICS']='1'
env['IMAGE_PREVIEW_EVIDENCE_DIR']=str(D/'captures')
env['PROTO_UI_IMAGE_DIAGNOSTIC_TASK']=str(D)
test='apps/www/src/components/documentation-image-preview.browser.test.ts'
product='apps/www/src/components/documentation-image-preview.ts'
S={'status':'running','started':now(),'pid':os.getpid(),'checkout':str(C),'baseHead':head,'steps':[],'sourcePatched':False,'derivedFromCommit':'cc5d24a44c09da2e7f27d4532deecb5e42fa3f5d','scope':'One selected original image case after the original author three-hunk Image contribution; 31 other cases filtered, not passed.'}
save()
try:
 w=json.loads((E/'current-s5-1afa-scope-workflow-reconcile-01/status.json').read_text())
 assert w['status']=='workflow-integrated-policy-passed' and w['noTestsRerun']
 B=json.loads((E/'current-s3-81e6-image-wheel-diagnostic-01/status.json').read_text())
 assert B['status']=='diagnostic-completed-case-failed' and B['counts']['numFailedTests']==1
 assert run('head',['git','rev-parse','HEAD']).strip()==head
 assert not run('index',['git','diff','--cached','--name-only']).strip()
 assert not run('untracked',['git','ls-files','--others','--exclude-standard']).strip()
 assert set(run('changed-before',['git','diff','--name-only']).splitlines())=={test}
 assert source(test)==B['testAfter']
 for rel,item in B['bindingsBefore'].items():
  if rel!=test:assert source(rel)==item,rel
 S['baseBindings']=B['bindingsBefore']
 pr=json.loads(run('fresh-pr',['gh','api','repos/Proto-UI/Proto-UI/pulls/1743','--jq','{state,draft,head:{sha:.head.sha,ref:.head.ref}}'],30))
 assert pr['state']=='open' and pr['head']['sha']==head,pr
 S['publicBefore']=pr
 before=(C/product).read_bytes()
 assert hashlib.sha1(b'blob '+str(len(before)).encode()+b'\0'+before).hexdigest()=='9a0c82191fee79306b68a5949e3e42d13f136c07'
 authored=(D/'author-image.ts').read_bytes()
 assert hashlib.sha1(b'blob '+str(len(authored)).encode()+b'\0'+authored).hexdigest()=='a35c35209d398e12c6b79d14bb92166147a54a8c'
 (D/'before.product.ts').write_bytes(before)
 (C/product).write_bytes(authored)
 S['sourcePatched']=True;S['authorBytes']={'bytes':len(authored),'sha256':sha(authored),'gitBlob':'a35c35209d398e12c6b79d14bb92166147a54a8c'};save()
 run('normal-product-format',['node','node_modules/prettier/bin/prettier.cjs','--write',product])
 run('normal-product-format-check',['node','node_modules/prettier/bin/prettier.cjs','--check',product,test])
 run('diff-check',['git','diff','--check'])
 assert (C/product).read_bytes()==authored,'The author source changed under normal formatting; inspect the real delta'
 S['tree']=run('tree',['git','rev-parse','HEAD^{tree}']).strip()
 S['node']=run('node-version',['node','--version']).strip()
 S['chrome']=run('chrome-version',[env['CHROME_PATH'],'--version']).strip()
 S['environment']={k:env.get(k) for k in ['PATH','TMPDIR','CHROME_PATH','CANDIDATE_SHA','IMAGE_PREVIEW_WHEEL_DIAGNOSTICS','IMAGE_PREVIEW_EVIDENCE_DIR','ASTRO_TELEMETRY_DISABLED']}
 S['bindingsBefore']={rel:source(rel) for rel in sorted(B['bindingsBefore'])}
 S['testAfter']=source(test);S['productAfter']=source(product);save()
 argv=['corepack','pnpm@10.32.1','exec','vitest','run',test,'--maxWorkers=1','--minWorkers=1','--no-file-parallelism','--reporter=verbose','--reporter=json','--outputFile='+str(D/'vitest.json'),'-t','migrates the actual en whitepaper viewer at 1280px dark']
 S['stage']='original-one-case';beg=now();save();expired=False
 with (D/'original-one-case.stdout').open('wb') as out,(D/'original-one-case.stderr').open('wb') as err:
  p=subprocess.Popen(argv,cwd=C,env=env,stdout=out,stderr=err,start_new_session=True)
  S['child']={'pid':p.pid,'pgid':p.pid,'argv':argv};save()
  try:code=p.wait(timeout=420)
  except subprocess.TimeoutExpired:
   expired=True
   try:os.killpg(p.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:code=p.wait(timeout=5)
   except subprocess.TimeoutExpired:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    code=p.wait()
 S.pop('child',None)
 S['steps'].append({'name':'original-one-case','argv':argv,'started':beg,'finished':now(),'exit':code,'timedOut':expired,'outerResourceTimeoutSeconds':420,'caseTimeoutMs':90000,'setupTimeoutMs':240000,'originalPollTimeoutMs':1000})
 save()
 assert not expired and code in (0,1),'Diagnostic runner or outer resource failure'
 j=json.loads((D/'vitest.json').read_text())
 S['counts']={k:j.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests','success']}
 selected=[a for f in j['testResults'] for a in f['assertionResults'] if a['status'] in ('passed','failed')]
 S['selected']=[{k:a.get(k) for k in ['fullName','title','status','failureMessages']} for a in selected]
 assert len(selected)==1 and selected[0]['title']=='migrates the actual en whitepaper viewer at 1280px dark'
 assert j['numTotalTests']==32 and j['numPendingTests']==31 and j.get('numTodoTests',0)==0
 for rel,item in S['bindingsBefore'].items():
  if rel!=test:assert source(rel)==item,rel
 assert source(test)==S['testAfter']
 S['artifacts']=[]
 if (D/'captures').exists():
  for p in sorted((D/'captures').rglob('*')):
   if p.is_file():
    b=p.read_bytes();S['artifacts'].append({'path':str(p.relative_to(D)),'bytes':len(b),'sha256':sha(b)})
 S['diffSha256']=sha(run('final-diff',['git','diff','--binary']).encode())
 S['status']='diagnostic-completed-case-'+selected[0]['status'];S['finished']=now();save()
except BaseException as e:failure(e);raise
