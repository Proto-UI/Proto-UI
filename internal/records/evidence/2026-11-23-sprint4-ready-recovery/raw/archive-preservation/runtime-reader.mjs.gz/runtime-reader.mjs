import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';
import { readHistorySnapshot } from '/tmp/proto-ui-sprint4-358e9947/scripts/governance/history-files.mjs';
const repo = '/tmp/proto-ui-sprint4-358e9947';
const input = 'internal/records/2026-11-22-sprint-7-history.snapshot.json.gz';
const paths = [input,
  'internal/records/2026-11-22-sprint-7-history-sources/timeline.index.json',
  'scripts/governance/history-files.mjs',
  'scripts/governance/decode-history-archive.mjs'];
const bindings = [];
for (const path of paths) {
  const bytes = await readFile(`${repo}/${path}`);
  bindings.push({ path, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') });
}
console.log(JSON.stringify({ observation: 'input-binding', node: process.version, bindings }));
const start = performance.now();
try {
  const snapshot = await readHistorySnapshot(`${repo}/${input}`);
  console.log(JSON.stringify({ observation: 'actual-readHistorySnapshot-result', ok: true,
    nativeSourceArchive: snapshot.nativeSourceArchive,
    counts: { pullRequests: snapshot.pullRequests.length, issueTimelines: snapshot.issueTimeline.length,
      inlinePages: snapshot.inlinePages.length },
    elapsedMs: performance.now() - start, memoryUsage: process.memoryUsage(), resourceUsage: process.resourceUsage() }));
} catch (error) {
  console.error(JSON.stringify({ observation: 'actual-readHistorySnapshot-result', ok: false,
    name: error.name, message: error.message, stack: error.stack,
    elapsedMs: performance.now() - start, memoryUsage: process.memoryUsage(), resourceUsage: process.resourceUsage() }));
  process.exitCode = 1;
}
