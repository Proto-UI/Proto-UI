import pathlib,subprocess,os,json,time
root=pathlib.Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono');out=root/'s67-757-typecheck-4deb';replay=out/'replay';env=dict(os.environ);env['PATH']=str(root/'tools/node-v24.22.3-linux-x64/bin')+':'+env['PATH'];env['CHROME_PATH']=str(root/'tools/playwright-browsers/chromium-1208/chrome-linux64/chrome')
args=['node',str(replay/'run.mjs'),str(replay/'build'),str(out/'attempt-01')]
meta={'startedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'args':args,'cwd':str(replay),'scope':'Browser semantic replay of clean a0e512fc build; no new model, install-time or performance comparison'}
(out/'execution.json').write_text(json.dumps(meta,indent=2)+'\n')
try:
 with (out/'browser.log').open('wb') as log:r=subprocess.run(args,cwd=replay,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 meta['exitCode']=r.returncode
except Exception as e:meta['exception']=str(e);meta['exitCode']=1
meta['finishedAt']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());(out/'execution.json').write_text(json.dumps(meta,indent=2)+'\n');(out/'exit-code').write_text(str(meta['exitCode'])+'\n')
