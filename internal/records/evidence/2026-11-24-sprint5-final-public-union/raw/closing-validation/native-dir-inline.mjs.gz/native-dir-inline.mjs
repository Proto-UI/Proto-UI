import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
const report = JSON.parse(await readFile(path.join(process.env.PUI_EVIDENCE_DIR, 'wc-native-dir-auto.json'), 'utf8'));
assert.equal(report.success, true);
assert.equal(report.numPassedTests, 2);
assert.equal(report.numFailedTests, 0);
assert.equal(report.testResults.length, 1);
const assertions = report.testResults[0].assertionResults;
const expected = ['input', 'textarea'].map((kind) => `reprojects entry during native dir=auto ${kind} input without an attribute change`);
for (const title of expected) {
  const matching = assertions.filter((entry) => entry.title === title);
  assert.equal(matching.length, 1, title);
  assert.equal(matching[0].status, 'passed', title);
}
assert.ok(assertions.filter((entry) => entry.status === 'passed').every((entry) => expected.includes(entry.title)));
await writeFile(path.join(process.env.PUI_EVIDENCE_DIR, 'wc-native-dir-auto-execution.json'), JSON.stringify({
  head: process.env.CANDIDATE_SHA,
  selected: expected,
  passed: 2,
  filteredOrSkipped: assertions.filter((entry) => entry.status !== 'passed').length,
  scope: 'Only the two original native dir=auto cases; other Shadow cases were filtered and are not claimed as passed.'
}, null, 2) + '\n');
