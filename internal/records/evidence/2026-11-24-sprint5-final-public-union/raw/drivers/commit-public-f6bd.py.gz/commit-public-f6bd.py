#!/usr/bin/env python3
import pathlib,os,subprocess,json,hashlib,datetime,traceback,fcntl
T=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a');B=pathlib.Path(str(T)+'-ops');O=B/'public-f6bd-commit';O.mkdir(exist_ok=False)
E=dict(os.environ);E['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+E.get('PATH','');E['TMPDIR']='/var/tmp/s5g75d5';assert E.get('HUSKY')!='0'
lock=(B/'public-f6bd-commit.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
S={'phase':'initial','commands':[],'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save(p=None):
 if p:S['phase']=p
 (O/'status.json').write_text(json.dumps(S,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=T,env=E,text=True,timeout=90).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(n,a,trace=False):
 save(n);e=dict(E)
 if trace:e['GIT_TRACE2_EVENT']=str(O/(n+'.trace.jsonl'))
 with (O/(n+'.log')).open('wb') as f:r=subprocess.run(a,cwd=T,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=900)
 S['commands'].append({'name':n,'argv':a,'exitCode':r.returncode});save();assert r.returncode==0,(n,r.returncode)
try:
 v=json.loads((B/'public-f6bd-validation/status.json').read_text());assert v['phase']=='failed' and v['commands'][-1]['name']=='format-check' and v['commands'][-1]['exitCode']==1
 assert [(x['name'],x['exitCode']) for x in v['commands'][:-1]]==[('focused-source',0),('ci-policy',0),('ci-schedule',0),('spec-authoring',0)]
 assert v['focusedCounts']['numPassedTests']==72 and v['focusedCounts']['numFailedTests']==0
 assert git('rev-parse','HEAD')==v['base'] and git('rev-parse','MERGE_HEAD')==v['remote'] and git('diff','--name-only','--diff-filter=U')==''
 f='packages/adapters/web-component/test/shadow-closeout.browser.test.ts';w='.github/workflows/compiler-browser-acceptance.yml'
 formatting=json.loads((B/'public-f6bd-format/status.json').read_text());assert formatting['exitCode']==0 and formatting['before']==v['sourceBefore'][f]
 assert json.loads((B/'public-f6bd-format/ast-equivalence.json').read_text())['equal']
 expected=dict(v['sourceBefore']);expected[f]=formatting['after']
 assert all(sha(T/p)==h for p,h in expected.items())
 assert sorted(git('diff','--name-only').splitlines())==sorted([w,f])
 changed=git('diff','--cached','--name-only').splitlines()
 run('format-check',['corepack','pnpm@10.32.1','exec','prettier','--check',w,*[p for p in changed if pathlib.Path(p).suffix in ['.ts','.mjs','.yml','.yaml','.md','.json']]])
 run('diff-check',['git','diff','--check']);run('index-diff-check',['git','diff','--cached','--check'])
 run('stage',['git','add','--',w,f])
 paths=git('diff','--cached','--name-only').splitlines();assert sorted(paths)==sorted(changed+[w])
 S.update({'base':v['base'],'remote':v['remote'],'sourceBefore':expected,'sourceValidation':{'path':str(B/'public-f6bd-validation/status.json'),'sha256':sha(B/'public-f6bd-validation/status.json'),'counts':v['focusedCounts'],'focusedHashesUnchanged':{p:expected[p] for p in v['focusedPaths']}},'formatterReceipt':formatting,'stagePaths':paths,'preparedTree':git('write-tree')})
 assert git('config','--get','core.hooksPath')=='.husky/_'
 assert os.access(T/'.husky/_/pre-commit',os.X_OK) and os.access(T/'.husky/_/h',os.R_OK)
 msg=O/'message.txt';msg.write_text('merge: preserve concurrent Sprint 5 compiler and owner fixes\n\nRetain JSON backing provenance, Vue retirement, focus-input and Scroll\nlifetime changes alongside the native diagnostic queue repair. Register the\nnew focused source controls in the existing manual acceptance lane.\n')
 run('commit',['git','commit','--signoff','--file',str(msg)],True)
 assert git('rev-parse','HEAD^{tree}')==S['preparedTree'] and git('status','--porcelain=v1')==''
 events=[json.loads(l) for l in (O/'commit.trace.jsonl').read_text().splitlines()];hooks=[e for e in events if e.get('event')=='child_start' and e.get('hook_name')=='pre-commit'];assert len(hooks)==1
 assert any(e.get('event')=='child_exit' and e.get('child_id')==hooks[0]['child_id'] and e.get('code')==0 for e in events)
 S['preCommitEvents']=hooks;S['sourceAfter']={p:sha(T/p) for p in expected};assert S['sourceAfter']==expected
 S['finalHead']=git('rev-parse','HEAD');S['finalTree']=git('rev-parse','HEAD^{tree}');S['clean']=True;S['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save('committed')
except BaseException as ex:
 S['error']=repr(ex);S['traceback']=traceback.format_exc();save('failed');raise
