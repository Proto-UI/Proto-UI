import {createRequire} from 'node:module';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const base='/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a';
const ts=createRequire(base+'/package.json')('typescript');
const ops=base+'-ops/public-f6bd-format';
function shape(n){const v={kind:n.kind};if(ts.isIdentifier(n)||ts.isPrivateIdentifier(n))v.text=n.text;else if(ts.isLiteralExpression(n))v.text=n.text;const c=[];ts.forEachChild(n,x=>{c.push(shape(x));});if(c.length)v.children=c;return v;}
const files=[ops+'/before.ts',base+'/packages/adapters/web-component/test/shadow-closeout.browser.test.ts'];
const out=files.map(path=>{const s=ts.createSourceFile('shadow-closeout.browser.test.ts',readFileSync(path,'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);if(s.parseDiagnostics.length)throw Error('parse diagnostics');const x=JSON.stringify(shape(s));return {path,astSha256:createHash('sha256').update(x).digest('hex'),astBytes:Buffer.byteLength(x)};});
if(out[0].astSha256!==out[1].astSha256)throw Error('formatter structural difference');
writeFileSync(ops+'/ast-equivalence.json',JSON.stringify({kind:'formatter-AST-structure-comparison',compilerVersion:ts.version,files:out,equal:true,scope:'Syntax structure and literal payload equality; this is not a browser execution receipt.'},null,2)+'\n');
console.log(JSON.stringify(out));
