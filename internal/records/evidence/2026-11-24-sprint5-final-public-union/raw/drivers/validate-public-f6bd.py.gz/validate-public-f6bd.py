#!/usr/bin/env python3
import os,sys,pathlib,json,hashlib,subprocess,datetime,traceback,re,fcntl
T=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a');B=pathlib.Path(str(T)+'-ops');O=B/'public-f6bd-validation'
O.mkdir(exist_ok=False)
E=dict(os.environ);E['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+E.get('PATH','');E['TMPDIR']='/var/tmp/s5g75d5';pathlib.Path(E['TMPDIR']).mkdir(exist_ok=True);assert E.get('HUSKY')!='0'
lock=(B/'public-f6bd-validation.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
S={'phase':'initial','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
def save(p=None):
 if p:S['phase']=p
 (O/'status.json').write_text(json.dumps(S,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=T,env=E,text=True,timeout=90).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(n,a,timeout=900,trace=False):
 save(n);env=dict(E)
 if trace:env['GIT_TRACE2_EVENT']=str(O/(n+'.trace.jsonl'))
 with (O/(n+'.log')).open('wb') as f:
  p=subprocess.Popen(a,cwd=T,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  S['active']={'name':n,'pid':p.pid,'argv':a};save()
  try:rc=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   import signal
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   S['commands'].append({'name':n,'argv':a,'timedOut':True});S.pop('active',None);save();raise
 S['commands'].append({'name':n,'argv':a,'exitCode':rc});S.pop('active',None);save();assert rc==0,(n,rc)
try:
 base='669a6d938d159178ceadabbb4f05a4d2f969b6a2';remote='f6bdadf1bf1791bab8a66d7c9a6c25993fc5c1f4'
 assert git('rev-parse','HEAD')==base and git('rev-parse','MERGE_HEAD')==remote
 assert git('diff','--name-only','--diff-filter=U')==''
 wf='.github/workflows/compiler-browser-acceptance.yml'
 expected={wf:'331bfa2f3d9ab7558234091d9b172342e31947fc10d50aa3da447ac5a09459d8','packages/compiler/src/gpui-native-control-label.ts':'f7290b713dfe98b38feafce0c894f3c16c4711e7018fc0f134d16e040291278d','packages/compiler/src/targets.ts':'2fd07e809c8b740303e8ea7b23a119e6d529cbf79425d2ce526488ac0b475e58','packages/compiler/src/callable-effects.ts':'f151a48fd13b23e2111c8072ad1ca6b2dbbc8bb7f271085c719685aec15c2b5c','packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs':'c76ee6adab6ae7db487a984d6289c080d72b9f9788124a6cfcf3ce0458160521'}
 assert all(sha(T/p)==h for p,h in expected.items())
 producer=(T/'packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs').read_text()
 assert producer.count("  'external_scroll',\n  retainModule(")==1
 assert producer.count("  'scroll_reader',\n  emit(")==1
 assert (T/'packages/compiler/src/targets.ts').read_text().count("'scroll.sync'")==1
 text=(T/wf).read_text();block=text.split('      - name: Verify retirement and actual request owner consumers\n',1)[1].split('      - name: Verify repository relocation',1)[0]
 selected=re.findall(r'^\s+(packages/[^\s]+\.test\.ts) \\$',block,re.M)
 assert len(selected)==41 and len(set(selected))==41,(len(selected),len(set(selected)))
 focused=['packages/compiler/test/json-boundary-provenance.test.ts','packages/compiler/test/json-boundary-getter-consumer.test.ts','packages/compiler/test/vue-owner-hydration.test.ts','packages/adapters/web-component/test/focus-entry-input-origin.test.ts','packages/compiler/test/capture-getter-presence.test.ts','packages/compiler/test/capture-host-presence.test.ts']
 assert all(p in selected for p in focused)
 changed=git('diff','--cached','--name-only').splitlines()
 tracked=sorted(set(selected+list(expected)+[p for p in changed if not p.startswith('internal/records/')]+['pnpm-lock.yaml','package.json']))
 S.update({'base':base,'remote':remote,'criticalExpected':expected,'selectedSourcePaths':selected,'focusedPaths':focused,'sourceBefore':{p:sha(T/p) for p in tracked}})
 (O/'source-before.json').write_text(json.dumps(S['sourceBefore'],indent=2)+'\n')
 (O/'registration.patch').write_text(git('diff','--',wf)+'\n')
 (O/'public-integration.patch').write_text(git('diff','--cached','--','packages','.github','scripts','spec')+'\n')
 run('focused-source',['corepack','pnpm@10.32.1','exec','vitest','run',*focused,'--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(O/'focused-source.json')])
 v=json.loads((O/'focused-source.json').read_text())
 S['focusedCounts']={k:v.get(k) for k in ['numTotalTestSuites','numPassedTestSuites','numFailedTestSuites','numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests','success']}
 assert v['success'] and v['numFailedTests']==0 and v['numPendingTests']==0 and v.get('numTodoTests',0)==0
 run('ci-policy',['node','--test','--test-reporter=tap','scripts/ci/test/ci-scheduling-policy.test.mjs'])
 run('ci-schedule',['node','scripts/ci/check-ci-schedule.mjs'])
 run('spec-authoring',['corepack','pnpm@10.32.1','check:spec-authoring','--','--base','0fbb52ef832cc27c78e24c28c59a55a16f51d7fe'])
 run('format-check',['corepack','pnpm@10.32.1','exec','prettier','--check',wf,*[p for p in changed if pathlib.Path(p).suffix in ['.ts','.mjs','.yml','.yaml','.md','.json']]])
 run('diff-check',['git','diff','--check'])
 run('index-diff-check',['git','diff','--cached','--check'])
 S['sourceAfter']={p:sha(T/p) for p in tracked};assert S['sourceAfter']==S['sourceBefore']
 run('stage-workflow',['git','add','--',wf])
 S['preparedTree']=git('write-tree');S['stagePaths']=git('diff','--cached','--name-only').splitlines()
 assert sorted(S['stagePaths'])==sorted(changed+[wf])
 hooks=git('config','--get','core.hooksPath');assert hooks=='.husky/_'
 assert os.access(T/'.husky/_/pre-commit',os.X_OK) and os.access(T/'.husky/_/h',os.R_OK)
 msg=O/'message.txt';msg.write_text('merge: preserve concurrent Sprint 5 compiler and owner fixes\n\nRetain the external JSON, Vue, focus-input and Scroll lifetime changes alongside\nthe native diagnostic queue repair. Register their focused source controls in\nthe existing manual compiler acceptance lane. Preserve all original evidence.\n')
 run('commit',['git','commit','--signoff','--file',str(msg)],trace=True)
 assert git('rev-parse','HEAD^{tree}')==S['preparedTree']
 assert git('status','--porcelain=v1')==''
 events=[json.loads(l) for l in (O/'commit.trace.jsonl').read_text().splitlines()]
 hooks=[e for e in events if e.get('event')=='child_start' and e.get('hook_name')=='pre-commit']
 assert len(hooks)==1
 assert any(e.get('event')=='child_exit' and e.get('child_id')==hooks[0]['child_id'] and e.get('code')==0 for e in events)
 S['preCommitEvents']=hooks;S['sourceAfterCommit']={p:sha(T/p) for p in tracked};assert S['sourceAfterCommit']==S['sourceBefore']
 S['finalHead']=git('rev-parse','HEAD');S['finalTree']=git('rev-parse','HEAD^{tree}');S['clean']=True;S['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save('committed')
except BaseException as ex:
 S['error']=repr(ex);S['traceback']=traceback.format_exc();save('failed');raise
