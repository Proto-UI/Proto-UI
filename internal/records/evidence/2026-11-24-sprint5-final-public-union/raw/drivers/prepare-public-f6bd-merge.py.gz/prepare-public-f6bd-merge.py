#!/usr/bin/env python3
import pathlib,subprocess,os,json,hashlib,datetime,traceback
T=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a');B=pathlib.Path(str(T)+'-ops');O=B/'public-f6bd-integration';O.mkdir(exist_ok=False)
E=dict(os.environ);E['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+E.get('PATH','');E['TMPDIR']='/var/tmp/s5g75d5';pathlib.Path(E['TMPDIR']).mkdir(exist_ok=True)
assert E.get('HUSKY')!='0'
S={'phase':'initial','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
def save(p=None):
 if p:S['phase']=p
 (O/'status.json').write_text(json.dumps(S,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=T,env=E,text=True,timeout=90).strip()
def run(n,a,allowed=(0,)):
 save(n)
 with (O/(n+'.log')).open('wb') as f:r=subprocess.run(a,cwd=T,env=E,stdout=f,stderr=subprocess.STDOUT,timeout=900)
 S['commands'].append({'name':n,'argv':a,'exitCode':r.returncode});save();assert r.returncode in allowed,n
try:
 base='669a6d938d159178ceadabbb4f05a4d2f969b6a2';remote='f6bdadf1bf1791bab8a66d7c9a6c25993fc5c1f4'
 assert git('rev-parse','HEAD')==base and git('status','--porcelain=v1')==''
 S['base']=base;S['remote']=remote
 run('fetch',['git','fetch','--no-tags','origin','refs/heads/fix/sprint5-preview-input-bundle-20261123-75d5:refs/remotes/s5-75d5/public-f6bd'])
 assert git('rev-parse','refs/remotes/s5-75d5/public-f6bd')==remote,'public head advanced; inspect first'
 (O/'public-change-paths.txt').write_text(git('diff','--name-status','2df421b1fc55cc0649be6675c0ee46a69ad9316f',remote)+'\n')
 (O/'public-source.patch').write_text(git('diff','2df421b1fc55cc0649be6675c0ee46a69ad9316f',remote,'--','.github','packages','spec')+'\n')
 run('merge',['git','merge','--no-ff','--no-commit','--signoff',remote],allowed=(0,1))
 S['unmerged']=git('diff','--name-only','--diff-filter=U').splitlines()
 S['stagedPaths']=git('diff','--cached','--name-only').splitlines()
 for p in S['unmerged']:
  for stage in [1,2,3]:
   r=subprocess.run(['git','show',':'+str(stage)+':'+p],cwd=T,env=E,capture_output=True)
   if r.returncode==0:
    d=O/'conflict-stages';d.mkdir(exist_ok=True);(d/(p.replace('/','__')+'.'+str(stage))).write_bytes(r.stdout)
 for p in ['packages/compiler/src/gpui-native-control-label.ts','packages/compiler/src/targets.ts','packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs']:
  raw=(T/p).read_bytes();(O/(p.replace('/','__')+'.automatic')).write_bytes(raw)
  S.setdefault('automaticSha256',{})[p]=hashlib.sha256(raw).hexdigest()
 S['scrollSyncOccurrences']=(T/'packages/compiler/src/targets.ts').read_text().count("'scroll.sync'")
 S['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save('merged-awaiting-source-review')
except BaseException as e:
 S['error']=repr(e);S['traceback']=traceback.format_exc();save('failed');raise
