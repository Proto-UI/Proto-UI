# Independent review of the f6bd callable/data-provenance integration

## Scope and source identity

This is a read-only source and evidence-scope review for PR #1738. No compiler test, native process, browser, live file, PR, index, or commit was changed by this review. It is not a GitHub APPROVED review, a fresh execution receipt, or acceptance of all Sprint 5 Issue criteria.

The reviewed comparison is `2df421b1fc55cc0649be6675c0ee46a69ad9316f` → `f6bdadf1bf1791bab8a66d7c9a6c25993fc5c1f4`. The GitHub comparison has six added commits, zero behind, and an exact 2df merge base. The actual callable-effects source was fetched at both immutable SHAs and its full Git blob identity recomputed:

| Source | Git blob | SHA-256 |
| --- | --- | --- |
| 2df callable-effects.ts | `40088aca3c24f6561cd6db8ad58c7399584d3008` | `3608dbdd18ce3748cbebb67d83cf1fd113639f5f323f7a6e18f27060e367f7ca` |
| f6bd callable-effects.ts | `610b32ae9cf90286c2ffef721b0c9b07eb424e7a` | `f151a48fd13b23e2111c8072ad1ca6b2dbbc8bb7f271085c719685aec15c2b5c` |

The 2df file is exactly the previously reviewed capture getter/own-presence r4 source. The complete new 250-addition/49-deletion diff and the actual adjacent IR/value-type rules were read. The conclusion below is bound to these bytes; a later integration must retain or separately review its changes.

## Source findings

No blocking defect was identified in this bounded integration.

1. **Capture authority and real presence remain intact.** Nineteen relevant function blocks are byte-identical across the comparison, including Store joins, field writes, truth, operation-phase failure, three-state presence, own-value/read-value conversion, executed capture presence, capture own-property reads, shared direct/copied lookup, calls and escape. A missing own key still becomes undefined only when read. Optional host fields retain both explicit undefined and the separate absent alternative. Missing hook identities remain opaque rather than borrowing authority from lookup metadata.

2. **Getter copies still execute the original bodies.** `copyProperties` retains integer-key/creation order, real getter invocation in the current execution context, and the original reachability/throw behavior. Its capture branch still reads `captureOwnProperty`, not a static getter signature. The unknown structural getter fallback still invokes the opaque-provenance guard. Neither copying nor the new data check bypasses the operation phase or external escape checks.

3. **JSON tracking preserves the backing value.** Only `callableEffectIssue` opts into the data check when the IR exposes a non-void event. Actual records, array elements, structured cells, aliases and returned/helper values retain their tracked identity. At an outward event, nested undefined, retained executable values, unresolved shapes and cycles are refused. An explicitly selected scalar can be copied without also transporting the backing record. The parser and standalone IR validation continue to use the same callable/data analysis; no new serialized trust annotation or profile admission is introduced.

4. **Optional overlays and multiple target aliases remain conservative.** `copyField` keeps the previous field on ABSENT, while an own undefined value replaces it. The new `overlayField` keeps the same distinction for assignment. When the target value has more than one possible record, `writeField(..., weak=true)` retains each record's previous alternative rather than assuming every target was selected. `opaqueFields` is ORed across possible sources and copied records and is included in fingerprints. This does not turn an incomplete structural view into a finite output proof.

5. **The analysis mode boundary is preserved.** Calls used for capture tracing/demand keep `checkDataBoundaries=false`; the added ordinary-data tracking and outward sink check do not run in that mode. Its accessor/capture provenance still runs. In data mode, actual capture objects remain on the capture-property/lookup path. The new nominal member fallback is limited by the existing checked member contract; it does not convert a structurally copied capture getter into a host callable.

6. **Intrinsic fallback does not create a new callable source.** The closed `ExpressionIR` intrinsic inventory and `intrinsicResult` were read. `object.freeze` and `object.assign` return their retained values through their dedicated branches; all other admitted results are fixed scalar data or exception, with checked operands. The new `hostValue(value.type)` fallback therefore does not add a function-returning intrinsic or admit an unknown callee by spelling/type alone.

These are static findings, not proof of every possible program. The existing capture/phase/forgery tests and the new JSON/consumer tests still need the actual final combination's formal execution.

## Missing formal source registrations

The exact f6bd `.github/workflows/compiler-browser-acceptance.yml` still has the prior 37-file explicit source selection. It does not include any of the following:

| Required related file | Source-enumerated cases | Nature of proof |
| --- | ---: | --- |
| `packages/compiler/test/json-boundary-provenance.test.ts` | 31 | Source rejection/positive cases and standalone serialized-IR substitutions |
| `packages/compiler/test/json-boundary-getter-consumer.test.ts` | 4 | Emitted React, Vue 3, Vue 2 and WC executing getter/owner consumers in happy-dom |
| `packages/compiler/test/vue-owner-hydration.test.ts` | 4 | Actual emitted Vue and server-renderer with native Vue child scopes/listeners in happy-dom |

The four getter profiles were read directly from `nativeOwnerProfiles`. The Vue file contains four unparameterized tests. The JSON suite expands to 31 cases. This enumeration is not a passing execution count.

The prepared minimal suggestion, `source-registration-f6bd-suggestion.patch`, adds only those three explicit paths. Its SHA-256 is `97e20537c4272a7219542be6c6c9f7ade2601e88a2d0fc95c7dc04086b4d1fa1`. It changes 37 to 40 selected files and adds 39 enumerated cases. If the original selection count remains unchanged, the expected count is 659 + 39 = 698; the actual new Vitest JSON is authoritative. Root separately identified the WC focus-entry file for the final union; its registration or separate actual receipt must be retained independently of this three-line suggestion.

No input default, permission, scheduler, timeout, browser sandbox, or original source path is changed by this suggestion. The old explicit capture presence/host presence and phase/metadata selections remain.

## Evidence and readiness disposition

The existing external JSON record is explicitly tied to its earlier candidate and keeps the old copied-getter failures historical. It describes 31 source/IR checks and four executing getter consumers as happy-dom observations, not physical browser/native application or public SSR acceptance. The new Vue source tests likewise use the direct private emitter and do not authorize canonical SSR admission or close #895/#896.

The earlier 2df production browser 20/20, source 659/659, production build and Adapter results remain valid historical receipts for that head. They cannot be relabelled as executions of f6bd: this integration changes actual callable/compiler and Vue source, and includes WC runtime changes reviewed separately by root. A new source/production/browser invocation is required for the final integration. The native diagnostic repair and its d0c local evidence are separate from this callable review; final Linux/macOS/Flutter results must be read at the published head. Unchanged Adapter evidence may be referenced with its original head and scope.

The PR remains open/Draft in the API snapshot reviewed here. Reviews and review threads were empty. There is no APPROVED review to infer from DCO or local source reviews. The initial body still led with 2df while the API head was already f6bd; it needs a new head-bound section after publication, while preserving all original failed runs and Issue boundaries.

The ten original Issue bodies were read (#1144, #1056, #687, #828, #1169, #1170, #1171, #1172, #895, #896). This bounded repair can become ready for review after its actual remaining gates; it does not complete whole-native operation/optimized-link coverage, GPUI-on-WASM, full website migration, application/physical input/assistive technology validation, shared-definition acceptance, or public SSR admission. No Issue closure, ownership transfer, merge or release is proposed by this review.
