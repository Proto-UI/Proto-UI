import datetime, hashlib, json, os, signal, subprocess
from pathlib import Path
root=Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
out=Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a-ops/integration-controls-cf3fede0a13e')
out.mkdir(exist_ok=False)
env=dict(os.environ, CI='1', COREPACK_ENABLE_DOWNLOAD_PROMPT='0', ASTRO_TELEMETRY_DISABLED='1', NODE_OPTIONS='--max-old-space-size=4096')
bin='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin'
env['PATH']=bin+':'+env['PATH']
files=['scripts/coverage-matrices/test/check-website-production-bundle.test.mjs','scripts/coverage-matrices/check-website-production-bundle.mjs','apps/www/src/components/PrototypePreviewer/browser-compiler-panel.ts','packages/compiler/test/browser-source-input.test.ts','.github/workflows/compiler-browser-acceptance.yml']
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def hashes(): return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}
def git(*a): return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
status={'head':git('rev-parse','HEAD'),'dirtyBefore':git('status','--porcelain'),'sourceSha256Before':hashes(),'startedAt':now(),'state':'running','steps':[]}
def save(): (out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def run(name,cmd,timeout):
 row={'name':name,'command':cmd,'timeoutSeconds':timeout,'startedAt':now(),'state':'running'};status['steps'].append(row);save()
 log=out/(name+'.log')
 with log.open('wb') as f:
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
  try: rc=p.wait(timeout)
  except subprocess.TimeoutExpired:
   row['timedOut']=True
   try: os.killpg(p.pid,signal.SIGTERM)
   except ProcessLookupError: pass
   rc=p.wait(10)
 row.update(exitCode=rc,finishedAt=now(),log=str(log),sha256=hashlib.sha256(log.read_bytes()).hexdigest(),state='passed' if rc==0 and not row.get('timedOut') else 'failed');save()
 if row['state']!='passed': raise RuntimeError(name+' failed')
try:
 assert status['head']=='cf3fede0a13e0479a118665cf176bd3e7efff386'
 assert status['dirtyBefore']=='M scripts/coverage-matrices/test/check-website-production-bundle.test.mjs'
 assert status['sourceSha256Before'][files[0]]=='0fe582736cc7dc8147ab69917517e593ea1892190c084b4f6275ac2a482f9cec'
 run('bundle-gate-controls',[bin+'/node','--test',files[0]],180)
 run('source-input-controls',['corepack','pnpm@10.32.1','exec','vitest','run',
 'packages/compiler/test/browser-source-input.test.ts','packages/compiler/test/browser-client.test.ts',
 'packages/compiler/test/browser-revision-session.test.ts','packages/compiler/test/browser-preview-retirement.test.ts',
 'packages/compiler/test/browser-panel-retirement.test.ts','--maxWorkers=1','--minWorkers=1'],300)
 run('production-receipt-controls',[bin+'/node','--test','scripts/compiler/browser-production.test.mjs','scripts/compiler/browser-delivery-index.test.mjs'],180)
 run('format',['corepack','pnpm@10.32.1','exec','prettier','--check',*files],120)
 run('diff-check',['git','diff','--check'],60)
 status.update(headAfter=git('rev-parse','HEAD'),dirtyAfter=git('status','--porcelain'),sourceSha256After=hashes())
 assert status['headAfter']==status['head'] and status['dirtyAfter']==status['dirtyBefore'] and status['sourceSha256After']==status['sourceSha256Before']
 status['state']='passed'
except Exception as e: status.update(state='failed',error=repr(e))
finally: status['finishedAt']=now();save();print(json.dumps(status,indent=2))
raise SystemExit(0 if status['state']=='passed' else 1)
