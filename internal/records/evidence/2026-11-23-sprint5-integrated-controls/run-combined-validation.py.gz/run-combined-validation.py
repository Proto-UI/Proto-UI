import datetime, hashlib, json, os, re, signal, subprocess, sys
from pathlib import Path

root = Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
ops = Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a-ops')
expected = sys.argv[1] if len(sys.argv) == 2 else ''
if not re.fullmatch(r'[0-9a-f]{40}', expected):
    raise SystemExit('Supply one exact source SHA.')
out = ops / ('combined-validation-' + expected[:12])
out.mkdir(parents=True, exist_ok=False)
env = dict(os.environ)
env.update(CI='1', COREPACK_ENABLE_DOWNLOAD_PROMPT='0', ASTRO_TELEMETRY_DISABLED='1', NODE_OPTIONS='--max-old-space-size=4096')
node_directory = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin'
env['PATH'] = node_directory + ':' + env['PATH']
node = node_directory + '/node'
status = {'expectedHead': expected, 'root': str(root), 'output': str(out), 'state': 'running', 'steps': []}
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def save():
    (out / 'status.json').write_text(json.dumps(status, indent=2) + '\n')
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, env=env, text=True, timeout=90).strip()
def run(name, command, timeout):
    log = out / (name + '.log')
    row = {'name': name, 'command': command, 'timeoutSeconds': timeout, 'startedAt': now(), 'state': 'running', 'log': str(log)}
    status['steps'].append(row)
    print('Starting ' + name, flush=True)
    save()
    with log.open('wb') as output:
        process = subprocess.Popen(command, cwd=root, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        row['pid'] = process.pid
        save()
        try:
            code = process.wait(timeout)
        except subprocess.TimeoutExpired:
            row['timedOut'] = True
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                code = process.wait(10)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                code = process.wait()
    row.update(exitCode=code, state='passed' if code == 0 and not row.get('timedOut') else 'failed', finishedAt=now(), sha256=digest(log))
    save()
    print(name + ': ' + row['state'], flush=True)
    if row['state'] != 'passed':
        raise RuntimeError(name + ' failed; original output remains at ' + str(log))
try:
    status.update(startedAt=now(), head=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'), statusBefore=git('status', '--porcelain'))
    assert status['head'] == expected and not status['statusBefore']
    status['driverSha256'] = digest(Path(__file__))
    status['lockfileSha256Before'] = digest(root / 'pnpm-lock.yaml')
    save()
    run('install-frozen', ['corepack', 'pnpm@10.32.1', 'install', '--frozen-lockfile', '--ignore-scripts', '--prefer-offline'], 600)
    run('bundle-gate-controls', [node, '--test', 'scripts/coverage-matrices/test/check-website-production-bundle.test.mjs'], 180)
    run('source-input-controls', ['corepack', 'pnpm@10.32.1', 'exec', 'vitest', 'run',
        'packages/compiler/test/browser-source-input.test.ts',
        'packages/compiler/test/browser-client.test.ts',
        'packages/compiler/test/browser-revision-session.test.ts',
        'packages/compiler/test/browser-preview-retirement.test.ts',
        'packages/compiler/test/browser-panel-retirement.test.ts',
        '--maxWorkers=1', '--minWorkers=1'], 300)
    run('production-receipt-controls', [node, '--test', 'scripts/compiler/browser-production.test.mjs', 'scripts/compiler/browser-delivery-index.test.mjs'], 180)
    run('format', ['corepack', 'pnpm@10.32.1', 'exec', 'prettier', '--check',
        'apps/www/src/components/PrototypePreviewer/browser-compiler-panel.ts',
        'packages/compiler/test/browser-source-input.test.ts',
        'scripts/coverage-matrices/check-website-production-bundle.mjs',
        'scripts/coverage-matrices/test/check-website-production-bundle.test.mjs',
        '.github/workflows/compiler-browser-acceptance.yml'], 120)
    run('our-delta-diff-check', ['git', 'diff', '--check', '7c66b9b39c9064346887957bc7292c3dc997f82a', 'HEAD'], 60)
    assert git('rev-parse', 'HEAD') == expected and not git('status', '--porcelain')
    run('unobserved-canonical', ['python3', '-u', str(ops / 'run-canonical.py'), expected], 1300)
    status.update(headAfter=git('rev-parse', 'HEAD'), statusAfter=git('status', '--porcelain'), lockfileSha256After=digest(root / 'pnpm-lock.yaml'))
    assert status['headAfter'] == expected and not status['statusAfter']
    assert status['lockfileSha256Before'] == status['lockfileSha256After']
    status['state'] = 'passed'
except Exception as error:
    status.update(state='failed', error=repr(error))
finally:
    status['finishedAt'] = now()
    save()
    print(json.dumps(status, indent=2), flush=True)
raise SystemExit(0 if status.get('state') == 'passed' else 1)
