import cp from 'node:child_process';
import { appendFileSync } from 'node:fs';
import { syncBuiltinESMExports } from 'node:module';
for (const method of ['fork', 'spawn']) {
  const original = cp[method];
  cp[method] = function (...args) {
    const child = original.apply(this, args);
    child.on('exit', (code, signal) => appendFileSync('/tmp/s2-link-worker-exits.jsonl', JSON.stringify({parent: process.pid, child: child.pid, method, code, signal})+'\n'));
    return child;
  };
}
syncBuiltinESMExports();
