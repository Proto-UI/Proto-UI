import os,pathlib,subprocess,hashlib,json,datetime,time,signal,traceback,shutil
C=pathlib.Path('/var/tmp/proto-ui-native-scroll-direct-0b7b-20261123-2010')
R=pathlib.Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
E=pathlib.Path("/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/integration-20261123-0320/current-1738-f6-label-red-01");F=pathlib.Path("/var/tmp/proto-ui-native-f6-label-red-20261123-2113");G=F/'official-control-label'
HEAD='f6bdadf1bf1791bab8a66d7c9a6c25993fc5c1f4'
env=os.environ.copy();env.update({'PATH':str(R/'tools/node-v24.22.3-linux-x64/bin')+':/home/ezra/.cargo/bin:'+env['PATH'],'COREPACK_HOME':str(R/'corepack-cache'),'TMPDIR':'/var/tmp/proto-ui-native-scroll-direct-temp-20261123-2010','CARGO_TARGET_DIR':'/var/tmp/proto-ui-native-scroll-validation-0b7b-20261123-2027/cargo-target','CARGO_BUILD_JOBS':'1','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','GIT_OPTIONAL_LOCKS':'0','GIT_NO_LAZY_FETCH':'1'})
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save():
 p=E/'status.tmp';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(E/'status.json')
def command(a,t=30):
 r=subprocess.run(a,cwd=C,env=env,capture_output=True,text=True,timeout=t)
 if r.returncode:raise RuntimeError(json.dumps({'argv':a,'exit':r.returncode,'stderr':r.stderr[-3000:]}))
 return r.stdout.strip()
required={
'packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs':'c76ee6adab6ae7db487a984d6289c080d72b9f9788124a6cfcf3ce0458160521',
'packages/compiler/test/fixtures/gpui-ordinary-values/scroll-reader-consumer.rs':'8e8ed8d5f994163f491fcd9ae91062667d4c5622553e2f87898ead8c6512fd21',
'packages/compiler/src/gpui-native-owner.ts':'e5050fda084fd3d831fea7fff83186f110278da0e7684e273b001732d06d7f07',
'packages/compiler/src/gpui-native-scroll.ts':'5080784c2335ecfb0454275d89c7506c4b0fd23f1ac2864cd284ad3e8fa817e6',
'packages/compiler/src/gpui-native-control-label.ts':'ee07845235af39b8a1fd723ba9f50ab0004093ea36b485873bc18d1be5bbe77a'}
changed=['packages/compiler/src/gpui-native-owner.ts','packages/compiler/test/fixtures/gpui-ordinary-values/scroll-reader-consumer.rs','internal/records/2026-11-23-gpui-sibling-scroll-clamping.md','internal/records/evidence/2026-11-23-gpui-sibling-scroll-clamping/executed-validation.tar.gz']
def guard():
 assert command(['git','rev-parse','HEAD'])==HEAD
 actual=command(['git','diff','--name-only','HEAD','--']).splitlines();assert set(actual)==set(changed),actual
 assert not command(['git','ls-files','--others','--exclude-standard'])
 hashes={p:sha(C/p) for p in required};assert hashes==required,hashes
 # Include every existing official producer/consumer input used by this original target.
 paths=command(['git','ls-files','packages/compiler/test/fixtures/gpui-control-label']).splitlines()
 return {'head':HEAD,'tree':command(['git','rev-parse','HEAD^{tree}']),'stagedTree':command(['git','write-tree']),'changedPaths':actual,'sha256':hashes,'officialInputs':{p:sha(C/p) for p in paths}}
state={'status':'running','pid':os.getpid(),'started':now(),'budgetSeconds':2700,'checkout':str(C),'fastEvidence':str(F),'stages':[],'scope':'Current f6 with source-identical reviewed sibling repair; unchanged complete official ControlLabel regression before queue repair'}
start=time.monotonic();deadline=start+2700;save()
try:
 integration=json.loads((R/'evidence/integration-20261123-0320/current-1738-f6-sibling-integration-01/status.json').read_text())
 assert integration['status']=='prepared',integration
 assert not F.exists();F.mkdir()
 state['sourceBefore']=guard()
 state['versions']={'node':command(['node','--version'],10),'cargo':command(['cargo','+1.98.1','--version'],20)}
 assert state['versions']['node']=='v24.22.3';assert state['versions']['cargo'].startswith('cargo 1.98.1 ')
 state['environment']={k:env[k] for k in ['TMPDIR','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG']}
 save()
 steps=[
 ('official-producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-control-label/produce.mjs',str(G)]),
 ('official-metadata',['cargo','+1.98.1','metadata','--all-features','--format-version','1','--manifest-path',str(G/'Cargo.toml')]),
 ('official-graph',['node','scripts/gpui/check-cargo-graph.mjs','--manifest-path',str(G/'Cargo.toml'),'--git','https://github.com/zed-industries/zed','--rev','62e5991dd0f0c8a3af8d5e7e9c4652490d468db8','--toolchain','1.98.1','--output',str(F/'official-graph.json')]),
 ('official-control-label',['cargo','+1.98.1','test','--locked','--manifest-path',str(G/'Cargo.toml'),'--test','control_label','--','--test-threads=1','--nocapture'])]
 for name,argv in steps:
  guard();remain=deadline-time.monotonic();assert remain>0
  stage={'name':name,'argv':argv,'started':now(),'status':'running','remainingBudgetSeconds':remain};state['stages'].append(stage);state['currentStage']=name
  log=F/(name+'.log')
  with log.open('xb') as out:
   p=subprocess.Popen(argv,cwd=C,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True);stage['pid']=p.pid;save()
   try:rc=p.wait(timeout=remain)
   except subprocess.TimeoutExpired:
    stage['timedOut']=True;os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=10)
    rc=p.returncode
  stage.update({'finished':now(),'exitCode':rc,'status':'passed' if rc==0 and not stage.get('timedOut') else 'failed','logSHA256':sha(log),'logBytes':log.stat().st_size})
  shutil.copyfile(log,E/(name+'.log'));save()
  if rc!=0 or stage.get('timedOut'):raise RuntimeError('Stage failed: '+name)
 state['status']='passed'
except BaseException as ex:state['status']='failed';state['error']=repr(ex);state['traceback']=traceback.format_exc()
finally:
 try:state['sourceAfter']=guard();state['sourceStable']=state.get('sourceBefore')==state['sourceAfter']
 except BaseException as ex:state['sourceGuardError']=repr(ex)
 for path in [F/'official-graph.json']:
  if path.exists():shutil.copyfile(path,E/path.name)
 state['finished']=now();state['elapsedSeconds']=time.monotonic()-start;state.pop('currentStage',None);save()
