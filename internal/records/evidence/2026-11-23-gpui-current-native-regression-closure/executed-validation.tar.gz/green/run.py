import os,pathlib,subprocess,hashlib,json,datetime,time,signal,traceback,shutil,re
C=pathlib.Path('/var/tmp/proto-ui-native-scroll-direct-0b7b-20261123-2010')
R=pathlib.Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
B=R/'evidence/integration-20261123-0320'
E=pathlib.Path("/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/integration-20261123-0320/current-1738-f6-native-green-01");F=pathlib.Path("/var/tmp/proto-ui-native-f6-green-20261123-2116");G=F/'generated';O=F/'official-control-label';N=F/'numeric-action'
HEAD='f6bdadf1bf1791bab8a66d7c9a6c25993fc5c1f4'
env=dict(os.environ);env.update({'PATH':str(R/'tools/node-v24.22.3-linux-x64/bin')+':/home/ezra/.cargo/bin:'+env['PATH'],'COREPACK_HOME':str(R/'corepack-cache'),'TMPDIR':'/var/tmp/proto-ui-native-scroll-direct-temp-20261123-2010','CARGO_TARGET_DIR':'/var/tmp/proto-ui-native-scroll-validation-0b7b-20261123-2027/cargo-target','CARGO_BUILD_JOBS':'1','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','GIT_OPTIONAL_LOCKS':'0','GIT_NO_LAZY_FETCH':'1'})
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save():
 p=E/'status.tmp';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(E/'status.json')
def cmd(args,t=30):
 r=subprocess.run(args,cwd=C,env=env,capture_output=True,text=True,timeout=t)
 if r.returncode:raise RuntimeError(json.dumps({'argv':args,'exit':r.returncode,'stderr':r.stderr[-4000:]}))
 return r.stdout.strip()
required={
'packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs':'c76ee6adab6ae7db487a984d6289c080d72b9f9788124a6cfcf3ce0458160521',
'packages/compiler/test/fixtures/gpui-ordinary-values/Cargo.lock':'a237377fcd0f62c6121102ab048e90dbf751ded989f29241bfde2a13c42992ec',
'packages/compiler/test/fixtures/gpui-ordinary-values/scroll-reader-consumer.rs':'8e8ed8d5f994163f491fcd9ae91062667d4c5622553e2f87898ead8c6512fd21',
'packages/compiler/src/gpui-native-owner.ts':'e5050fda084fd3d831fea7fff83186f110278da0e7684e273b001732d06d7f07',
'packages/compiler/src/gpui-native-scroll.ts':'5080784c2335ecfb0454275d89c7506c4b0fd23f1ac2864cd284ad3e8fa817e6',
'packages/compiler/src/gpui-native-control-label.ts':'60676bd030e35a027375e141fe511ff2b281f070e75722022fbb3197830588d5'}
changed=['packages/compiler/src/gpui-native-owner.ts','packages/compiler/test/fixtures/gpui-ordinary-values/scroll-reader-consumer.rs','packages/compiler/src/gpui-native-control-label.ts','internal/records/2026-11-23-gpui-sibling-scroll-clamping.md','internal/records/evidence/2026-11-23-gpui-sibling-scroll-clamping/executed-validation.tar.gz']
def guard():
 assert cmd(['git','rev-parse','HEAD'])==HEAD
 actual=cmd(['git','diff','--name-only','HEAD','--']).splitlines();assert set(actual)==set(changed),actual
 assert not cmd(['git','ls-files','--others','--exclude-standard'])
 hashes={p:sha(C/p) for p in required};assert hashes==required,hashes
 inputs=cmd(['git','ls-files','packages/compiler/test/fixtures/gpui-control-label','packages/compiler/test/fixtures/gpui-a11y-value']).splitlines()
 return {'head':HEAD,'tree':cmd(['git','rev-parse','HEAD^{tree}']),'indexTree':cmd(['git','write-tree']),'changedPaths':actual,'workingFiles':{p:sha(C/p) for p in actual},'sha256':hashes,'officialAndNumericInputs':{p:sha(C/p) for p in inputs}}
state={'status':'running','pid':os.getpid(),'started':now(),'budgetSeconds':2700,'checkout':str(C),'fastEvidence':str(F),'stages':[],'scope':'f6 + reviewed sibling callback and full real regression; diagnostics queue repair after unchanged official nine reproduced original assertion'}
start=time.monotonic();deadline=start+2700;save()
try:
 red=B/'current-1738-f6-label-red-01';rs=json.loads((red/'status.json').read_text());assert rs['status']=='failed' and rs['sourceStable']
 raw=(red/'official-control-label.log').read_text();assert 'test result: FAILED. 8 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out;' in raw
 assert 'a refused current pairing must retain its diagnostic' in raw
 assert cmd(['git','rev-parse','HEAD'])==HEAD
 target='packages/compiler/src/gpui-native-control-label.ts'
 before='ee07845235af39b8a1fd723ba9f50ab0004093ea36b485873bc18d1be5bbe77a'
 assert sha(C/target)==before
 patch=B/'current-1738-f6-label-diagnostic-candidate-01/candidate.patch'
 assert sha(patch)=='63b6a2f4cd2f41dc216f36fba590e71cc810af735fa2c15bb3f9d68cfc692cf6'
 shutil.copyfile(C/target,E/'control-label.before.ts');shutil.copyfile(patch,E/'candidate.patch')
 # This continuing human-assisted scope is explicitly extended by current Root instructions.
 authorization={'repositoryId':'github.com:Proto-UI/Proto-UI','headSha':HEAD,'executionMode':'human-assisted','executionModeSource':'current-user','priorRoute':str(B/'current-1738-pui-route-0b7b-01/regression-resolution.json'),'scopeId':'native-scroll-label-f6-20261123','allowedPaths':[p for p in changed if not p.startswith('internal/records/')],'authority':['spec/host-caps/HC-CONTROL-LABEL-0001.yaml','packages/compiler/test/fixtures/gpui-control-label/consumer.rs: original refused-pair diagnostic assertion','spec/constraints/C-SCROLL-END-FOLLOW-0001.yaml'],'reproduction':{'path':str(red/'status.json'),'sha256':sha(red/'status.json'),'officialTests':{'passed':8,'failed':1,'ignored':0,'filtered':0}},'source':'Active current-user task and explicit Root continuation instructions; source peer by Root and S1; no formal GitHub approval claimed','catalogLifecycleChangesAuthorized':False,'testThresholdChangesAuthorized':False,'externalWrites':'After current-head, permission, ownership and DCO reconciliation; this validation does not publish'}
 (E/'scope-continuation.json').write_text(json.dumps(authorization,indent=2)+'\n')
 cmd(['git','apply','--check',str(patch)])
 state['application']={'before':before,'patchSha256':sha(patch),'status':'applying','started':now()};save()
 cmd(['git','apply',str(patch)])
 assert sha(C/target)==required[target]
 out=cmd(['corepack','pnpm@10.32.1','exec','prettier','--write',target],60);(E/'prettier.log').write_text(out+'\n')
 assert sha(C/target)==required[target],'formatter changed reviewed candidate'
 shutil.copyfile(C/target,E/'control-label.after.ts')
 ts="const fs=require('node:fs'),ts=require('typescript');const p=process.argv[1];const s=ts.createSourceFile(p,fs.readFileSync(p,'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);console.log(JSON.stringify({typescript:ts.version,parseDiagnostics:s.parseDiagnostics.map(d=>ts.flattenDiagnosticMessageText(d.messageText,'\\n'))}));if(s.parseDiagnostics.length)process.exit(1)"
 (E/'typescript-parse.json').write_text(cmd(['node','-e',ts,target],30)+'\n')
 cmd(['git','diff','--check'])
 state['application'].update({'status':'applied','after':sha(C/target),'finished':now(),'normalFormatterStable':True});save()
 assert not F.exists();F.mkdir()
 state['sourceBefore']=guard()
 state['versions']={'node':cmd(['node','--version'],10),'cargo':cmd(['cargo','+1.98.1','--version'],20)}
 assert state['versions']['node']=='v24.22.3';assert state['versions']['cargo'].startswith('cargo 1.98.1 ')
 state['environment']={k:env[k] for k in ['TMPDIR','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG']};save()
 def graph(path,out):return ['node','scripts/gpui/check-cargo-graph.mjs','--manifest-path',str(path),'--git','https://github.com/zed-industries/zed','--rev','62e5991dd0f0c8a3af8d5e7e9c4652490d468db8','--toolchain','1.98.1','--output',str(out)]
 def native(path,test,features=False):
  a=['cargo','+1.98.1','test','--locked','--manifest-path',str(path)]
  if features:a+=['--features','test-support']
  return a+['--test',test,'--','--test-threads=1','--nocapture']
 steps=[
 ('official-producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-control-label/produce.mjs',str(O)]),
 ('official-metadata',['cargo','+1.98.1','metadata','--all-features','--format-version','1','--manifest-path',str(O/'Cargo.toml')]),
 ('official-graph',graph(O/'Cargo.toml',F/'official-graph.json')),
 ('official-control-label',native(O/'Cargo.toml','control_label')),
 ('ordinary-producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs',str(G)]),
 ('ordinary-graph',graph(G/'transition/Cargo.toml',F/'ordinary-graph.json')),
 ('default-sdk-check',['cargo','+1.98.1','check','--locked','--manifest-path',str(G/'transition/Cargo.toml'),'--lib']),
 ('ordinary',native(G/'transition/Cargo.toml','ordinary',True)),
 ('ordinary-control-label',native(G/'transition/Cargo.toml','control_label',True)),
 ('style-mapping',native(G/'transition/Cargo.toml','style_mapping',True)),
 ('a11y-activation',native(G/'transition/Cargo.toml','a11y_activation',True)),
 ('scroll-pause',native(G/'transition/Cargo.toml','scroll_pause',True)),
 ('scroll-reader',native(G/'transition/Cargo.toml','scroll_reader',True)),
 ('numeric-producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-a11y-value/produce.mjs',str(N)]),
 ('numeric-metadata',['cargo','+1.98.1','metadata','--all-features','--format-version','1','--manifest-path',str(N/'Cargo.toml')]),
 ('numeric-graph',graph(N/'Cargo.toml',F/'numeric-graph.json')),
 ('numeric-a11y-value',native(N/'Cargo.toml','a11y_value')),
 ('native-sdk-controls',['cargo','+1.98.1','test','--locked','--manifest-path',str(N/'Cargo.toml'),'-p','proto-ui-gpui-native','--features','test-support,gpui/test-support','--lib','--','--test-threads=1','--nocapture'])]
 for name,argv in steps:
  guard();remain=deadline-time.monotonic();assert remain>0,'45 minute original aggregate expired'
  stage={'name':name,'argv':argv,'started':now(),'status':'running','remainingBudgetSeconds':remain};state['stages'].append(stage);state['currentStage']=name
  log=F/(name+'.log')
  with log.open('xb') as out:
   p=subprocess.Popen(argv,cwd=C,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True);stage['pid']=p.pid;save()
   try:rc=p.wait(timeout=remain)
   except subprocess.TimeoutExpired:
    stage['timedOut']=True;os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=10)
    rc=p.returncode
  raw=log.read_text(errors='replace')
  stage.update({'finished':now(),'exitCode':rc,'status':'passed' if rc==0 and not stage.get('timedOut') else 'failed','logSHA256':sha(log),'logBytes':log.stat().st_size,'testResults':re.findall(r'test result: [^\n]+',raw)})
  shutil.copyfile(log,E/(name+'.log'));save()
  if stage['status']!='passed':raise RuntimeError('Stage failed: '+name)
 state['status']='passed'
except BaseException as ex:state['status']='failed';state['error']=repr(ex);state['traceback']=traceback.format_exc()
finally:
 try:state['sourceAfter']=guard();state['sourceStable']=state.get('sourceBefore')==state['sourceAfter']
 except BaseException as ex:state['sourceGuardError']=repr(ex)
 for p in F.glob('*-graph.json'):
  shutil.copyfile(p,E/p.name)
 state['finished']=now();state['elapsedSeconds']=time.monotonic()-start;state.pop('currentStage',None);save()
