import datetime,hashlib,json,os,pathlib,re,signal,subprocess
root=pathlib.Path("/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a");ops=root.with_name(root.name+'-ops');out=ops/'session-fixture-integrated-d946';out.mkdir(exist_ok=False)
base='d946f7758a1f6a2bf7151aaea88989b80e8b8bd2'
env=dict(os.environ,CI='1',COREPACK_ENABLE_DOWNLOAD_PROMPT='0',ASTRO_TELEMETRY_DISABLED='1',NODE_OPTIONS='--max-old-space-size=4096');env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env['PATH'];assert env.get('HUSKY')!='0'
files=['native/gpui/fixtures/base-'+name+'-session.json' for name in ['label','button','toggle','switch','checkbox']]
status={'state':'running','head':base,'steps':[]}
def save():(out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=root,env=env,text=True).strip()
def run(name,cmd,timeout=180,expected=0):
 log=out/(name+'.log');row={'name':name,'command':cmd,'state':'running','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};status['steps'].append(row);save()
 with log.open('wb') as f:
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
  try:rc=p.wait(timeout)
  except subprocess.TimeoutExpired:
   row['timedOut']=True
   try:os.killpg(p.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   rc=p.wait(10)
 row.update(exitCode=rc,state='completed',finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),sha256=hashlib.sha256(log.read_bytes()).hexdigest());save()
 assert not row.get('timedOut') and (expected is None or rc==expected),(name,rc)
 return rc
try:
 assert git('rev-parse','HEAD')==base and git('status','--porcelain')==''
 status['tree']=git('rev-parse','HEAD^{tree}');status['lockSha256']=hashlib.sha256((root/'pnpm-lock.yaml').read_bytes()).hexdigest()
 scripts=json.loads((root/'package.json').read_text())['scripts'];status['formalScripts']={name:scripts[name] for name in ['gpui:session-fixtures','check:gpui-session-fixtures']};save()
 run('install-frozen',['corepack','pnpm@10.32.1','install','--frozen-lockfile','--ignore-scripts','--prefer-offline'],600)
 assert git('status','--porcelain')==''
 (out/'original-fixtures').mkdir();status['fixtureSha256Before']={}
 for f in files:
  raw=(root/f).read_bytes();(out/'original-fixtures'/pathlib.Path(f).name).write_bytes(raw);status['fixtureSha256Before'][f]=hashlib.sha256(raw).hexdigest()
 save()
 rc=run('fixture-original-check',['corepack','pnpm@10.32.1','run','check:gpui-session-fixtures'],180,None)
 originalLog=(out/'fixture-original-check.log').read_text();status['originalCheckExit']=rc
 if rc:
  assert rc==1 and 'base-checkbox-session.json is stale' in originalLog,originalLog[-3000:]
  status['staleFixtures']=re.findall(r'(native/gpui/fixtures/[^\s]+) is stale',originalLog);assert set(status['staleFixtures'])<=set(files)
  run('official-fixture-generator',['corepack','pnpm@10.32.1','run','gpui:session-fixtures'])
  run('fixture-generated-check',['corepack','pnpm@10.32.1','run','check:gpui-session-fixtures'])
 else:status['staleFixtures']=[]
 changed=git('diff','--name-only').splitlines();assert set(changed)<=set(files),changed
 status['changedFixtures']=changed;status['fixtureSha256After']={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files}
 (out/'generated-fixtures').mkdir()
 for f in files:(out/'generated-fixtures'/pathlib.Path(f).name).write_bytes((root/f).read_bytes())
 (out/'generated-fixture.patch').write_text(git('diff','--',*files)+'\n')
 run('diff-check',['git','diff','--check'])
 status['headAfter']=git('rev-parse','HEAD');assert status['headAfter']==base
 assert hashlib.sha256((root/'pnpm-lock.yaml').read_bytes()).hexdigest()==status['lockSha256']
 status['state']='passed'
except Exception as error:status.update(state='failed',error=repr(error))
finally:status['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps(status,indent=2))
raise SystemExit(0 if status['state']=='passed' else 1)
