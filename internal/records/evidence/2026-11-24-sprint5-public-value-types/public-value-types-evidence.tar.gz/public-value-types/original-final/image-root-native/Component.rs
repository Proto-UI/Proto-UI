// Direct checked-source GPUI component. Supporting files are ordinary editable Rust.
  
  pub use proto_ui_gpui_native as native;
  pub use native::gpui_native_owner::{ControlLabelRef, InstanceAssociations};
  use gpui::{prelude::*, App, Context, FocusHandle, Subscription, Window};
  use std::rc::Rc;
  use serde_json::Value as Json;
  use native::gpui_native_owner::*;
  
  
  fn style_vocabulary() -> &'static native::gpui_native_style::StyleVocabulary {
      static VOCABULARY: std::sync::OnceLock<native::gpui_native_style::StyleVocabulary> = std::sync::OnceLock::new();
      VOCABULARY.get_or_init(|| native::gpui_native_style::StyleVocabulary::from_json(include_str!(".proto-ui/fixtures/style-tokens.json")).expect("compiler-produced style vocabulary"))
  }
  fn accepts_context(key: &str, value: &Json) -> bool {
      match key {
          
          _ => false,
      }
  }
  fn accepts_props(value: &Json) -> bool { value.is_object() && value.get("source").map_or(true, |prop| prop.is_null() || prop.is_string()) && value.get("a11yMode").map_or(true, |prop| prop.is_null() || (prop.as_str() == Some("informative") || prop.as_str() == Some("decorative"))) && value.get("alternativeText").map_or(true, |prop| prop.is_null() || prop.is_string()) && value.get("fit").map_or(true, |prop| prop.is_null() || (prop.as_str() == Some("contain") || prop.as_str() == Some("cover") || prop.as_str() == Some("fill"))) }
  fn prop_valid(key: &str, value: &Json) -> bool { match key { "source" => value.is_string(),
        "a11yMode" => (value.as_str() == Some("informative") || value.as_str() == Some("decorative")),
        "alternativeText" => value.is_string(),
        "fit" => (value.as_str() == Some("contain") || value.as_str() == Some("cover") || value.as_str() == Some("fill")), _ => false } }
  fn check_method(name: &str, arguments: &[Value]) { match name {
  
          _ => value_error("unknown exposed method"),
  } }
  
  #[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
#[serde(untagged)]
pub enum GeneratedData1 {
    Alternative0(String),
    Alternative1(String),
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
#[serde(untagged)]
pub enum GeneratedData2 {
    Alternative0(String),
    Alternative1(String),
    Alternative2(String),
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData0 {
    #[serde(rename = "source", default, skip_serializing_if = "Option::is_none")]
    pub field_0: Option<String>,
    #[serde(rename = "a11yMode", default, skip_serializing_if = "Option::is_none")]
    pub field_1: Option<GeneratedData1>,
    #[serde(rename = "alternativeText", default, skip_serializing_if = "Option::is_none")]
    pub field_2: Option<String>,
    #[serde(rename = "fit", default, skip_serializing_if = "Option::is_none")]
    pub field_3: Option<GeneratedData2>,
}
  
  pub type GeneratedProps = GeneratedData0;
  
  #[derive(Clone)]
  pub struct CompiledComponentHandle { pub owner: OwnerRef }
  impl CompiledComponentHandle {
      pub fn state_0(&self) -> Result<String, Value> { self.state("source").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_1(&self) -> Result<String, Value> { self.state("loadingStatus").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_2(&self) -> Result<String, Value> { self.state("fit").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
      pub fn owner(&self) -> OwnerWeak { Rc::downgrade(&self.owner) }
      pub fn state(&self, name: &str) -> Result<Json, Value> { catch_authored(|| { let state=self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed State")); state.get().data() }) }
      pub fn call(&self, name: &str, arguments: Vec<Json>, window: &mut Window, cx: &mut App) -> Result<Json, Value> {
          let outcome = catch_authored(|| {
          refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
          let callback = self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed method"));
          let arguments: Vec<Value> = arguments.into_iter().map(Value::json).collect(); check_method(name, &arguments);
          let result = invoke(&self.owner, "expose-method", &callback, arguments);
          let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
          if matches!(result, Value::Undefined) { Json::Null } else { result.data() }
          });
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome
      }
      pub fn host_target(&self) -> Result<Value, Value> { catch_authored(|| { ensure(&self.owner()); Value::HostTarget(self.owner()) }) }
      pub fn take_events(&self) -> Vec<(String, Json)> { std::mem::take(&mut self.owner.borrow_mut().emitted) }
      pub fn take_failures(&self) -> Vec<NativeFailure> { take_native_failures(&self.owner) }
      pub fn dispose(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
          catch_authored(|| {
          let drive = self.owner.borrow().native_drive.clone();
          let failure = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| Owner::dispose(&self.owner)));
          let driven = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| { if let Some(drive) = drive { drive(window, cx); } }));
          if let Err(failure) = failure { std::panic::resume_unwind(failure); }
          if let Err(failure) = driven { std::panic::resume_unwind(failure); }
          })
      }
  }
  pub struct CompiledComponent { pub owner: OwnerRef, focus: FocusHandle, window_input: Option<FocusHandle>, _focus_subscriptions: Vec<Subscription>, _window_activation: Option<(gpui::WindowId, Subscription)>, _focus_lost: Option<Subscription>, _global_key_capture: Option<Subscription>, _entry_readiness: Option<(gpui::WindowId, Subscription)> }
  impl CompiledComponent {
      pub fn create_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> { Self::create(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn create(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          Self::create_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn create_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          let mut failure = None;
          let entity = cx.new(|cx| Self::new_with_associations(raw_props, parent, associations, window, cx).unwrap_or_else(|error| {
              failure = Some(error);
              // A failed construction still returns normally through GPUI's
              // entity insertion. This inert temporary is dropped immediately
              // below; it is never published or mounted as a native component.
              let owner = Owner::new(Json::Object(Default::default()), Default::default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
              { let mut owner = owner.borrow_mut(); owner.disposed = true; owner.present = false; }
              Self { owner, focus: cx.focus_handle(), window_input: None, _focus_subscriptions: Vec::new(), _window_activation: None, _focus_lost: None, _global_key_capture: None, _entry_readiness: None }
          }));
          match failure { Some(error) => Err(error), None => Ok(entity) }
      }
      pub fn new_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> { Self::new(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn new(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          Self::new_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn new_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          catch_authored(|| {
          let owner_ref = Owner::new(raw_props, parent.unwrap_or_default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
          initialize_instance_associations(&owner_ref, associations);
          let owner = Rc::downgrade(&owner_ref);
          let focus = cx.focus_handle();
          let view = cx.entity().downgrade();
          let drive_owner=owner.clone(); let drive_focus=focus.clone();
          let driving = Rc::new(std::cell::Cell::new(false));
          let drive_pending = Rc::new(std::cell::Cell::new(false));
          let drive: Drive = Rc::new(move |window, cx| {
              // Platform effects need owner storage and its real FocusHandle,
              // not another lease of the generated component. Preserve their
              // synchronous effect (notably physical focus) under public calls.
              if !driving.replace(true) {
                  if let Some(owner)=drive_owner.upgrade() {
                      native_host_callback(&owner, "drive", || { modules_drive(&owner, &drive_focus, window, cx); drive_queued_focus(&owner, window, cx); });
                  }
                  driving.set(false);
              }
              if drive_pending.replace(true) { return; }
              let view=view.clone(); let pending=drive_pending.clone();
              // A public handle can be called from Entity::update. Return the
              // current host lease before requesting another component update.
              // Authored calls, State writes and platform commands remain
              // synchronous; component refresh is coalesced at the host boundary.
              window.defer(cx, move |window, cx| {
                  pending.set(false);
                  let _ = view.update(cx, |view, cx| { if let Err(error) = view.drive(window, cx) { report_native_failure(&view.owner, "drive", error); } });
              });
          });
          { let mut owner = owner_ref.borrow_mut(); owner.native_drive = Some(drive); owner.window_id = Some(window.window_handle().window_id()); }
          image_declaration(&owner, record(vec![("source", Value::string("")), ("alternativeText", Value::string("")), ("a11yMode", Value::string("informative")), ("fit", Value::string("contain"))]));
          configure_native_atoms(&owner_ref, false, false);
          refresh_native_atoms(&owner_ref, window, cx);
          let _lexical_owner = enter_lexical_owner(&owner);
          let renderer = { let owner = owner.clone();  Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_646566: Value = arg(&arguments, 0);
            let v_696d616765: LexicalBinding<Value> = lexical_binding();
            let v_736f75726365: LexicalBinding<Value> = lexical_binding();
            let v_6c6f6164696e67537461747573: LexicalBinding<Value> = lexical_binding();
            let v_666974: LexicalBinding<Value> = lexical_binding();
            let v_70726f6a656374536e617073686f74: LexicalBinding<Value> = lexical_binding();
            let v_73796e63: LexicalBinding<Value> = lexical_binding();
            // Source "packages/prototypes/base/src/image/root.proto.ts":13:3
            { let v_7075695f6e61746976655f30 = v_646566.clone(); props_define(&owner, record(vec![("source", record(vec![("type", Value::string("string")), ("empty", Value::string("fallback"))])), ("a11yMode", record(vec![("type", Value::string("enum")), ("empty", Value::string("fallback")), ("options", Value::Array(Rc::new(vec![Value::string("informative"), Value::string("decorative")])))])), ("alternativeText", record(vec![("type", Value::string("string")), ("empty", Value::string("fallback"))])), ("fit", record(vec![("type", Value::string("enum")), ("empty", Value::string("fallback")), ("options", Value::Array(Rc::new(vec![Value::string("contain"), Value::string("cover"), Value::string("fill")])))]))])) };
            // Source "packages/prototypes/base/src/image/root.proto.ts":27:3
            { let v_7075695f6e61746976655f31 = v_646566.clone(); set_defaults(&owner, record(vec![("a11yMode", Value::string("informative")), ("alternativeText", Value::string("")), ("fit", Value::string("contain"))])) };
            // Source "packages/prototypes/base/src/image/root.proto.ts":33:9
            v_696d616765.initialize(native_builtin_hook(&owner, "asImageView", || image_setup(&owner)));
            // Source "packages/prototypes/base/src/image/root.proto.ts":34:9
            v_736f75726365.initialize({ let v_7075695f6e61746976655f32 = v_646566.clone(); create_state(&owner, "string", Value::string("source"), Value::string(""), Value::Undefined) });
            // Source "packages/prototypes/base/src/image/root.proto.ts":35:9
            v_6c6f6164696e67537461747573.initialize({ let v_7075695f6e61746976655f33 = v_646566.clone(); create_state(&owner, "enum", Value::string("loadingStatus"), Value::string("idle"), record(vec![("options", Value::Array(Rc::new(vec![Value::string("idle"), Value::string("loading"), Value::string("loaded"), Value::string("error")])))])) });
            // Source "packages/prototypes/base/src/image/root.proto.ts":40:9
            v_666974.initialize({ let v_7075695f6e61746976655f34 = v_646566.clone(); create_state(&owner, "enum", Value::string("fit"), Value::string("contain"), record(vec![("options", Value::Array(Rc::new(vec![Value::string("contain"), Value::string("cover"), Value::string("fill")])))])) });
            // Source "packages/prototypes/base/src/image/root.proto.ts":44:3
            { let v_7075695f6e61746976655f35 = v_646566.clone(); expose_state(&owner, Value::string("source"), v_736f75726365.read()) };
            // Source "packages/prototypes/base/src/image/root.proto.ts":45:3
            { let v_7075695f6e61746976655f36 = v_646566.clone(); expose_state(&owner, Value::string("loadingStatus"), v_6c6f6164696e67537461747573.read()) };
            // Source "packages/prototypes/base/src/image/root.proto.ts":46:3
            { let v_7075695f6e61746976655f37 = v_646566.clone(); expose_state(&owner, Value::string("fit"), v_666974.read()) };
            // Source "packages/prototypes/base/src/image/root.proto.ts":47:3
            { let v_7075695f6e61746976655f38 = v_646566.clone(); expose_event(&owner, Value::string("loadingStatusChange")) };
            // Source "packages/prototypes/base/src/image/root.proto.ts":49:9
            v_70726f6a656374536e617073686f74.initialize({  let v_696d616765 = v_696d616765.clone(); let v_736f75726365 = v_736f75726365.clone(); let v_6c6f6164696e67537461747573 = v_6c6f6164696e67537461747573.clone(); let v_666974 = v_666974.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "packages/prototypes/base/src/image/root.proto.ts":50:11
                let v_736e617073686f74 = { let v_7075695f6e61746976655f39 = v_696d616765.read(); image_snapshot(&(v_7075695f6e61746976655f39.clone()).owner()) };
                // Source "packages/prototypes/base/src/image/root.proto.ts":51:5
                { let v_7075695f6e61746976655f3130 = v_736f75726365.read(); state_set(v_7075695f6e61746976655f3130.clone(), { let left = (v_736e617073686f74.clone()).member("source", true); if left.nullish() { Value::string("") } else { left } }, Value::string("reason: image-view source snapshot")) };
                // Source "packages/prototypes/base/src/image/root.proto.ts":52:5
                { let v_7075695f6e61746976655f3131 = v_6c6f6164696e67537461747573.read(); state_set(v_7075695f6e61746976655f3131.clone(), { let left = (v_736e617073686f74.clone()).member("loadingStatus", true); if left.nullish() { Value::string("idle") } else { left } }, Value::string("reason: image-view loading status snapshot")) };
                // Source "packages/prototypes/base/src/image/root.proto.ts":56:5
                { let v_7075695f6e61746976655f3132 = v_666974.read(); state_set(v_7075695f6e61746976655f3132.clone(), { let left = (v_736e617073686f74.clone()).member("fit", true); if left.nullish() { Value::string("contain") } else { left } }, Value::string("reason: image-view fit snapshot")) };
                Value::Undefined
            })) });
            // Source "packages/prototypes/base/src/image/root.proto.ts":59:9
            v_73796e63.initialize({  let v_696d616765 = v_696d616765.clone(); let v_70726f6a656374536e617073686f74 = v_70726f6a656374536e617073686f74.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_70726f7073: Value = arg(&arguments, 0);
                // Source "packages/prototypes/base/src/image/root.proto.ts":60:5
                { let v_7075695f6e61746976655f3133 = v_696d616765.read(); image_sync(&(v_7075695f6e61746976655f3133.clone()).owner(), record(vec![("source", { let left = (v_70726f7073.clone()).member("source", false); if left.nullish() { Value::string("") } else { left } }), ("a11yMode", { let left = (v_70726f7073.clone()).member("a11yMode", false); if left.nullish() { Value::string("informative") } else { left } }), ("alternativeText", { let left = (v_70726f7073.clone()).member("alternativeText", false); if left.nullish() { Value::string("") } else { left } }), ("fit", { let left = (v_70726f7073.clone()).member("fit", false); if left.nullish() { Value::string("contain") } else { left } })])) };
                // Source "packages/prototypes/base/src/image/root.proto.ts":66:5
                v_70726f6a656374536e617073686f74.read().call_authored(vec![]);
                Value::Undefined
            })) });
            // Source "packages/prototypes/base/src/image/root.proto.ts":69:3
            { let v_7075695f6e61746976655f3134 = v_646566.clone(); register_life(&owner, "created", {  let v_73796e63 = v_73796e63.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f64663162353463333632373365346637: Value = arg(&arguments, 0);
                // Source "packages/prototypes/base/src/image/root.proto.ts":69:36
                return v_73796e63.read().call_authored(vec![{ let v_7075695f6e61746976655f3135 = v_72756e5f5f64663162353463333632373365346637.clone(); read_props(&(v_7075695f6e61746976655f3135.clone()).owner(), false) }]);
            })) }) };
            // Source "packages/prototypes/base/src/image/root.proto.ts":70:3
            { let v_7075695f6e61746976655f3136 = v_646566.clone(); watch_props(&owner, Some(Value::Array(Rc::new(vec![Value::string("source"), Value::string("a11yMode"), Value::string("alternativeText"), Value::string("fit")]))), false, {  let v_73796e63 = v_73796e63.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_5f72756e: Value = arg(&arguments, 0);
                let v_6e657874: Value = arg(&arguments, 1);
                // Source "packages/prototypes/base/src/image/root.proto.ts":70:85
                return v_73796e63.read().call_authored(vec![v_6e657874.clone()]);
            })) }) };
            // Source "packages/prototypes/base/src/image/root.proto.ts":72:3
            { let v_7075695f6e61746976655f3137 = v_696d616765.read(); image_on(&(v_7075695f6e61746976655f3137.clone()).owner(), Value::string("loadingStatusChange"), {  let v_70726f6a656374536e617073686f74 = v_70726f6a656374536e617073686f74.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f38663063326462333861623632393336: Value = arg(&arguments, 0);
                let v_6576656e74: Value = arg(&arguments, 1);
                // Source "packages/prototypes/base/src/image/root.proto.ts":73:5
                v_70726f6a656374536e617073686f74.read().call_authored(vec![]);
                // Source "packages/prototypes/base/src/image/root.proto.ts":74:5
                { let v_7075695f6e61746976655f3138 = v_72756e5f5f38663063326462333861623632393336.clone(); emit(&(v_7075695f6e61746976655f3138.clone()).owner(), Value::string("loadingStatusChange"), v_6576656e74.clone()) };
                Value::Undefined
            })) }) };
            // Source "packages/prototypes/base/src/image/root.proto.ts":77:3
            return { let callable={   Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "packages/prototypes/base/src/image/root.proto.ts":77:16
                return Value::Json(Json::Null);
            })) }; match callable {
      Value::NativeFunction{identity,render} => capture_renderer(Value::NativeFunction{identity,render:render.clone()},render),
      Value::Renderer(adapter) => Value::Renderer(adapter),
      Value::Function(callback) => capture_renderer(Value::Function(callback.clone()),Rc::new(move |arguments:Vec<Value>| { { let pui_native_19 = callback(arguments); if matches!(&pui_native_19, Value::Json(Json::Null)) { native::gpui_native_owner::NativeSnapshot::empty() } else { native::gpui_native_owner::NativeSnapshot::invalid(pui_native_19) } } })),
      _ => panic!("checked setup result must be a callable")
    } };
        })) }.call_authored(vec![definition_capability(&owner)]);
          Owner::finish(&owner_ref, renderer);
          // Establish the App's default-action snapshot before any authored
          // global key capture can replace focus during the same keystroke.
          register_sequential_focus_owner(&owner_ref, cx);
          let focus_subscriptions = if native_focus_observation_needed(&owner_ref) {
          let focus_owner = owner_ref.clone();
          let on_focus = cx.on_focus(&focus, window, move |view, window, cx| {
              native_host_callback(&focus_owner, "focus", || {
              let epoch = focus_owner.borrow().epoch;
              if !ready(&focus_owner) || focus_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&focus_owner, window);
              native_focus_fact(&focus_owner, view.focus.is_focused(window));
              if !ready(&focus_owner) || focus_owner.borrow().epoch != epoch { return; }
              dispatch(&focus_owner, "host:focus", false, event_fields("host:focus"));
              if ready(&focus_owner) && focus_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          let blur_owner = owner_ref.clone();
          let on_blur = cx.on_blur(&focus, window, move |view, window, cx| {
              native_host_callback(&blur_owner, "blur", || {
              let epoch = blur_owner.borrow().epoch;
              if !ready(&blur_owner) || blur_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&blur_owner, window);
              native_focus_fact(&blur_owner, view.focus.is_focused(window));
              if !ready(&blur_owner) || blur_owner.borrow().epoch != epoch { return; }
              text_blur(&blur_owner, window, cx);
              dispatch(&blur_owner, "host:blur", false, event_fields("host:blur"));
              if ready(&blur_owner) && blur_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          // A native slot descendant can start this root's keyboard press
          // while the root FocusHandle itself is not focused. Its departure
          // from the physical subtree is distinct from the root's own blur.
          let focus_out_owner = Rc::downgrade(&owner_ref);
          let on_focus_out = cx.on_focus_out(&focus, window, move |view, _, window, cx| {
              let Some(owner) = focus_out_owner.upgrade() else { return; };
              native_host_callback(&owner, "focus-out", || {
              let epoch = owner.borrow().epoch;
              if !ready(&owner) || owner.borrow().window_id != Some(window.window_handle().window_id()) || view.focus.contains_focused(window, cx) { return; }
              // This retires only an existing root press lease. Do not forge
              // host:blur or change the root's own Focus observation here.
              native_press_blur(&owner);
              if ready(&owner) && owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          vec![on_focus, on_blur, on_focus_out]
          } else { Vec::new() };
          let global_key_capture = subscribe_global_key_capture(&owner_ref, cx);
          let window_input = window_input_needed(&owner_ref).then(|| cx.focus_handle().tab_stop(false));
          let focus_lost = window_input.as_ref().map(|_| cx.on_focus_lost(window, |view, window, cx| { let owner=view.owner.clone(); native_host_callback(&owner, "focus-lost", || { if view.owner.borrow().window_id == Some(window.window_handle().window_id()) { if let Some(focus) = &view.window_input { restore_window_input(&view.owner, focus, window, cx); } } }); }));
          let mut view = Self { owner: owner_ref, focus, window_input, _focus_subscriptions: focus_subscriptions, _window_activation: None, _focus_lost: focus_lost, _global_key_capture: global_key_capture, _entry_readiness: None };
          view.bind_window_activation(window, cx);
          view
          })
      }
      #[cfg(feature="test-support")]
      pub fn native_resource_counts(&self) -> Json { let mut counts=native::gpui_native_owner::native_resource_counts(&self.owner); counts["nativeSubscriptions"] = Json::from(self._focus_subscriptions.len() + usize::from(self._window_activation.is_some()) + usize::from(self._focus_lost.is_some()) + usize::from(self._global_key_capture.is_some()) + usize::from(self._entry_readiness.is_some())); counts }
      pub fn handle(&self) -> CompiledComponentHandle { CompiledComponentHandle { owner: self.owner.clone() } }
      pub fn set_props(&mut self, raw: Json, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_props(&self.owner, raw));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; self.drive(window, cx)
      }
      pub fn set_instance_associations(&mut self, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_instance_associations(&self.owner, associations));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; drive_owners(window, cx); self.drive(window, cx)
      }
      pub fn set_slot(&mut self, slot: Vec<native::gpui_native_owner::NativeSnapshot>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { ensure(&Rc::downgrade(&self.owner)); assert_native_slot_children(&slot); let mut owner = self.owner.borrow_mut(); owner.slot = slot; owner.dirty = true; cx.notify(); }) }
      pub fn set_parent(&mut self, parent: Option<OwnerWeak>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { if let Err(error)=set_native_parent(&self.owner, parent.unwrap_or_default()){throw_error("NATIVE_PARENT_INVALID", error)} cx.notify(); }) }
      fn bind_window_activation(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !native_focus_observation_needed(&self.owner) && !native::gpui_native_move::move_owner_has_binding(&self.owner) && !control_label_is_label(&self.owner) { self._window_activation.take(); return; }
          let id = window.window_handle().window_id();
          if self._window_activation.as_ref().is_some_and(|(bound, _)| *bound == id) { return; }
          self._window_activation.take();
          let owner = self.owner.clone();
          let subscription = cx.observe_window_activation(window, move |view, window, cx| {
              let deactivated = owner.borrow().window_id == Some(window.window_handle().window_id()) && !window.is_window_active();
              native_host_callback(&owner, "window-activation", || {
                  if deactivated {
                      native_window_blur(&owner);
                      view.drive(window, cx).unwrap_or_else(|error| throw_value(error));
                  }
              });
              if deactivated { notify_native_change(cx); }
          });
          self._window_activation = Some((id, subscription));
      }
      #[cfg(feature = "experimental-focus-tree")]
      fn bind_entry_readiness(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !self.owner.borrow().modules.hooks.contains("focus-entry") { return; }
          let window_id = window.window_handle().window_id();
          if self._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window_id) { return; }
          self._entry_readiness.take();
          let view = cx.entity().downgrade();
          let subscription = window.observe_focus_tree(cx, move |_, window, cx| {
              let _ = view.update(cx, |view, cx| {
                  if view._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window.window_handle().window_id()) { if let Err(error)=view.drive(window, cx){report_native_failure(&view.owner,"entry-readiness",error)} }
              });
          });
          self._entry_readiness = Some((window_id, subscription));
      }
      fn notify_after_turn(&self, cx: &mut Context<Self>) {
          // GPUI suppresses Entity observer effects while a window is drawing,
          // including its focus/blur phase. Keep authored state synchronous,
          // then publish the host change after that physical draw lease ends.
          // A weak target cannot keep a detached component alive for delivery.
          notify_native_change(cx);
      }
      pub fn drive(&mut self, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let result = catch_authored(|| {
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          modules_drive(&self.owner, &self.focus, window, cx);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          drive_queued_focus(&self.owner, window, cx);
          });
          // A callback can publish before failing or retiring its owner. That
          // output is independent from repaint dirtiness and an unread queue.
          let dirty = std::mem::take(&mut self.owner.borrow_mut().dirty);
          if !notify_native_events(&self.owner, cx) && dirty { self.notify_after_turn(cx); }
          result
      }
  }
  impl Drop for CompiledComponent { fn drop(&mut self) { native_host_callback(&self.owner, "drop", || Owner::dispose(&self.owner)); } }
  impl gpui::Focusable for CompiledComponent { fn focus_handle(&self, _: &App) -> FocusHandle { self.focus.clone() } }
  impl Render for CompiledComponent {
      fn render(&mut self, window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
          let report_owner = self.owner.clone();
          native_host_callback(&report_owner, "render", || {
          refresh_native_atoms(&self.owner, window, cx);
          Owner::project(&self.owner);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); return gpui::div().into_any_element(); }
          if !self.owner.borrow().present { self._window_activation.take(); detach_native_view(&self.owner); return gpui::div().into_any_element(); }
          bind_native_focus_window(&self.owner, window);
          self.bind_window_activation(window, cx);
          #[cfg(feature = "experimental-focus-tree")] self.bind_entry_readiness(window, cx);
          let drive = self.owner.borrow().native_drive.as_ref().expect("live native owner drive").clone();
          // Drawing consumes only repaint dirtiness. A parent Render can call
          // an exposed method before this child is laid out: its independent
          // pending_native_events flag survives until the coalesced drive wakes
          // the consumer. Repeated slot projection cannot create a notify loop.
          self.owner.borrow_mut().dirty = false;
          let snapshot = self.owner.borrow().projection.clone().expect("live native projection");
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          let element = paint_native_root(&snapshot, &self.owner, &self.focus, format!("compiled-root-{}", Rc::as_ptr(&self.owner) as usize), drive);
          if let Some(focus) = &self.window_input { window_input_scope(element, focus, &self.owner) } else { element }
          }).unwrap_or_else(|| gpui::div().into_any_element())
      }
  }
  
//# sourceMappingURL=Component.rs.map
