import ts from '/workspace/scratch/f7b299133482/s5-browser-alias/node_modules/typescript/lib/typescript.js';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';

const root = '/workspace/scratch/f7b299133482/s5-browser-alias';
const target = path.join(root, 'packages/compiler/src/public-value-types.ts');
const source = readFileSync(target, 'utf8');
const config = ts.readConfigFile(path.join(root, 'tsconfig.json'), ts.sys.readFile);
if (config.error) throw new Error(ts.flattenDiagnosticMessageText(config.error.messageText, '\n'));
const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root);
const options = { ...parsed.options, noEmit: true, strict: true, skipLibCheck: false, types: [] };
const roots = [target, path.join(root, 'packages/compiler/src/source-values.ts')];
const receipt = { kind: 'public-finite-value-types-strict-and-exhaustiveness-controls', node: process.version, typescript: ts.version, sourceSha256: createHash('sha256').update(source).digest('hex'), roots, options: { strict: true, skipLibCheck: false, noEmit: true }, cases: [] };
let previous;
for (const [name, contents, expected] of [
  ['current', source, 0],
  ['missing-shared-alternative', source.replace('fill: true', ''), 1],
  ['extra-nonpublic-alternative', source.replace('fill: true', 'fill: true, stretch: true'), 1],
]) {
  if (name !== 'current' && contents === source) throw new Error('Mutation did not reach its target');
  const host = ts.createCompilerHost(options);
  const original = host.getSourceFile.bind(host);
  host.getSourceFile = (file, version, error, fresh) => path.resolve(file) === target
    ? ts.createSourceFile(file, contents, version, true)
    : original(file, version, error, fresh);
  const program = ts.createProgram(roots, options, host, previous);
  const diagnostics = ts.getPreEmitDiagnostics(program).map((item) => ({ code: item.code, file: item.file?.fileName, start: item.start, message: ts.flattenDiagnosticMessageText(item.messageText, '\n') }));
  const sources = program.getSourceFiles().filter((file) => !file.fileName.includes('/node_modules/')).map((file) => ({ path: path.relative(root, file.fileName), sha256: createHash('sha256').update(file.text).digest('hex') }));
  receipt.cases.push({ name, checkedFiles: program.getSourceFiles().length, inputSha256: createHash('sha256').update(contents).digest('hex'), sources, diagnostics, valid: diagnostics.length === expected && (expected === 0 || diagnostics.every((item) => item.file === target)) });
  console.log(JSON.stringify({ name, checkedFiles: program.getSourceFiles().length, diagnostics }));
  previous = program;
}
receipt.sourceDrift = readFileSync(target, 'utf8') !== source;
writeFileSync('/workspace/scratch/f7b299133482/browser-evidence/type-alias-admission/strict-controls.json', JSON.stringify(receipt, null, 2) + '\n');
if (receipt.sourceDrift || receipt.cases.some((row) => !row.valid)) process.exitCode = 1;
