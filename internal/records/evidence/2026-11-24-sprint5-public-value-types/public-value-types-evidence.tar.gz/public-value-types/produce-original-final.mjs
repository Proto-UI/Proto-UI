import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';

const [root, output] = process.argv.slice(2);
if (!path.isAbsolute(root ?? '') || !path.isAbsolute(output ?? '')) throw new Error('absolute root/output required');
mkdirSync(output, { recursive: false });
const sha = (value) => createHash('sha256').update(value).digest('hex');
const { compileFile, writeCompilation } = await import(pathToFileURL(path.join(root, 'packages/compiler/src/compile.ts')));
const { validateIR } = await import(pathToFileURL(path.join(root, 'packages/compiler/src/ir-validation.ts')));
const productFiles = ['packages/compiler/src/public-value-types.ts','packages/compiler/src/source-values.ts','packages/compiler/src/core-value-types.ts','packages/compiler/src/source-type-resolution.ts'];
const files = Object.fromEntries(productFiles.map((name) => [name,sha(readFileSync(path.join(root,name)))]));
const report = { kind:'unchanged-original-alias-consumer', head:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),
  stagedTree:execFileSync('git',['write-tree'],{cwd:root,encoding:'utf8'}).trim(), root, productFiles:files,
  profile:'gpui-source-v1', actualNativeExecution:false, records:[] };
for (const [name, relative] of [['table-header-cell','packages/prototypes/base/src/table/header-cell.proto.ts'],['image-root','packages/prototypes/base/src/image/root.proto.ts']]) {
  const input=readFileSync(path.join(root,relative));
  const result=await compileFile(path.join(root,relative),{root,profile:'gpui-source-v1'});
  const row={name,entry:relative,sourceBytes:input.length,sourceSha256:sha(input),ok:result.ok};
  if(result.ok){
    const cold=validateIR(JSON.parse(JSON.stringify(result.value.ir)));
    row.coldIrAccepted=cold.ok;
    if(!cold.ok)row.coldDiagnostics=cold.diagnostics;
    row.generatedComponentSha256=sha(result.value.output.code);
    row.generatedComponentBytes=Buffer.byteLength(result.value.output.code);
    const written=await writeCompilation(result.value,path.join(output,name+'-native'));
    if(!written.ok)throw new Error(JSON.stringify(written));
    row.artifactPaths=written.value.files;
    row.sourceClosure=result.value.ir.sourceFiles;
    writeFileSync(path.join(output,name+'.checked-ir.json'),JSON.stringify(result.value.ir,null,2)+'\n');
    writeFileSync(path.join(output,name+'.rs'),result.value.output.code);
  }else row.diagnostics=result.diagnostics;
  report.records.push(row);console.log(JSON.stringify(row));
}
report.productSourceDrift=Object.keys(files).filter((name)=>sha(readFileSync(path.join(root,name)))!==files[name]);
writeFileSync(path.join(output,'receipt.json'),JSON.stringify(report,null,2)+'\n');
if(report.productSourceDrift.length)throw new Error('Source changed during producer');
