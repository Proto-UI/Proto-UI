#!/usr/bin/env python3
"""Run the exact S5 native workflow locally in an owned, newly created tree.

No source repair, GitHub write, Cargo-config rewrite, dependency unlock, or
missing-tool success fallback is performed by this driver. Root prepares the
clean exact base and applies the separately hashed candidate patch first.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


parser = argparse.ArgumentParser()
parser.add_argument('--worktree', type=Path, required=True)
parser.add_argument('--candidate', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--cargo-target', type=Path, required=True)
parser.add_argument('--node-bin', type=Path, required=True)
parser.add_argument('--corepack-home', type=Path, required=True)
parser.add_argument('--tmpdir', type=Path, required=True)
parser.add_argument('--phase', choices=['prepare', 'types', 'headless', 'graph-fixtures', 'graph', 'check', 'ordinary', 'control-label', 'style-mapping', 'a11y-activation', 'all'], required=True)
args = parser.parse_args()
root = args.worktree.resolve(strict=True)
out = args.output.resolve()
candidate = json.loads(args.candidate.read_text())
assert args.node_bin.is_dir() and args.tmpdir.is_dir(), 'fixed Node and short temporary directory must exist'
assert out != root and not out.is_relative_to(root), 'evidence must be outside the source tree'
assert args.cargo_target.is_absolute() and not args.cargo_target.is_relative_to(root), 'an owned absolute external Cargo target is required'
out.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
env.update({
    'PATH': str(args.node_bin) + os.pathsep + env.get('PATH', ''),
    'COREPACK_HOME': str(args.corepack_home),
    'TMPDIR': str(args.tmpdir),
    'CARGO_TARGET_DIR': str(args.cargo_target),
    'CARGO_BUILD_JOBS': '1',
    'CARGO_PROFILE_DEV_DEBUG': '0',
    'CARGO_PROFILE_TEST_DEBUG': '0',
    'RUSTUP_TOOLCHAIN': '1.98.1',
    'PROTO_UI_REQUIRE_RUST_DATA_TESTS': '1',
    'PROTO_UI_REQUIRE_CARGO_GRAPH_TESTS': '1',
})
pnpm = ['corepack', 'pnpm@10.32.1']
manifest = out / 'generated/transition/Cargo.toml'
status_path = out / 'status.json'
status = json.loads(status_path.read_text()) if status_path.exists() else {
    'schemaVersion': 1,
    'kind': 's5-compiled-control-label-native-validation',
    'validationDriverSha256': digest(Path(__file__).read_bytes()),
    'priorValidationDriverSha256': '4de0843352629896c9df63a57179cefac37c344558eb774065af5bb0ec090d51',
    'baseValidationDriverSha256': '64d5220df25bb0dc1140cf8f730f95d06e8b528add630da65f52347eae77cf03',
    'candidateDigest': candidate['candidateDigest'],
    'candidateManifestSha256': digest(args.candidate.read_bytes()),
    'base': candidate['base'],
    'startedAt': now(),
    'worktree': str(root),
    'cargoTarget': str(args.cargo_target),
    'toolchain': {'node': '24.22.3', 'pnpm': '10.32.1', 'rust': '1.98.1'},
    'steps': {},
}
assert status['validationDriverSha256'] == digest(Path(__file__).read_bytes()), 'the validation driver changed; use a new receipt directory'
assert status['candidateDigest'] == candidate['candidateDigest'], 'use a new receipt directory for a changed candidate'
assert status['candidateManifestSha256'] == digest(args.candidate.read_bytes()), 'candidate receipt changed'


def save():
    status['updatedAt'] = now()
    temporary = status_path.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(status, indent=2) + '\n')
    temporary.replace(status_path)


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=root, env=env).decode().strip()


def verify_source():
    assert git('rev-parse', 'HEAD') == candidate['base'], 'the prepared base changed'
    for item in candidate['files']:
        source = root / item['path']
        assert source.is_file() and not source.is_symlink(), f'missing/aliased source: {item["path"]}'
        assert digest(source.read_bytes()) == item['sha256'], f'candidate bytes differ: {item["path"]}'
    actual = set(filter(None, git('diff', '--name-only', 'HEAD').splitlines()))
    actual.update(filter(None, git('ls-files', '--others', '--exclude-standard').splitlines()))
    assert actual == {item['path'] for item in candidate['files']}, f'unexpected source change inventory: {sorted(actual)}'
    identity = {'base': candidate['base'], 'files': candidate['files']}
    assert digest(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()) == candidate['candidateDigest']


def step(name, command, timeout=3600, check=None):
    verify_source()
    existing = status['steps'].get(name)
    if existing and existing.get('status') == 'passed':
        log = out / existing['log']
        assert digest(log.read_bytes()) == existing['logSha256'], f'retained log changed: {name}'
        return
    assert existing is None, f'{name} already attempted; preserve this result and use a new receipt directory for a rerun'
    record = {'status': 'running', 'startedAt': now(), 'command': command, 'cwd': str(root), 'log': name + '.log'}
    status['steps'][name] = record
    status['state'] = 'running'
    status['currentStep'] = name
    save()
    start = time.monotonic()
    failure = None
    try:
        with (out / record['log']).open('xb') as log:
            result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
        record['exitCode'] = result.returncode
        if result.returncode:
            raise RuntimeError(f'{name} exited {result.returncode}; inspect {record["log"]}')
        if check:
            check((out / record['log']).read_text(errors='replace'))
        verify_source()
    except Exception as error:
        failure = error
        record['failure'] = str(error)
    finally:
        record['endedAt'] = now()
        record['seconds'] = round(time.monotonic() - start, 3)
        log = out / record['log']
        if log.exists():
            record['logSha256'] = digest(log.read_bytes())
            record['logBytes'] = log.stat().st_size
        record['status'] = 'failed' if failure else 'passed'
        status['state'] = record['status']
        save()
    if failure:
        raise failure


def contains(expected):
    def check(output):
        assert expected in output, f'missing expected tool identity: {expected}'
    return check


def native_count(expected):
    def check(output):
        summaries = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', output)
        assert (str(expected), '0', '0', '0', '0') in summaries, f'the exact {expected} required native tests did not all execute: {summaries}'
    return check


def verify_source_json(_output):
    report = json.loads((out / 'source-regressions.json').read_text())
    assert report['numPassedTests'] == 13 and report['numFailedTests'] == 0 and report['numPendingTests'] == 0
    assert len(report['testResults']) == 1 and report['testResults'][0]['name'].endswith('/packages/compiler/test/gpui-control-label.test.ts')


def verify_producer(_output):
    receipt = json.loads((out / 'generated/source-receipt.json').read_text())
    assert len(receipt['modules']) == 36, 'all original and seven ControlLabel consumers must be emitted'
    assert {entry['name'] for entry in receipt['actualControlLabelConsumers']} == {'base_button', 'base_toggle', 'base_label'}
    for entry in receipt['actualControlLabelConsumers']:
        actual = (root / entry['entry']).read_bytes()
        original = subprocess.check_output(['git', 'show', f'HEAD:{entry["entry"]}'], cwd=root)
        assert actual == original and digest(actual) == entry['sha256'], f'Base Prototype was changed: {entry["entry"]}'
    assert digest((out / 'generated/transition/tests/style_mapping.rs').read_bytes()) == receipt['styleMappingConsumerSha256'], 'style mapping target must be source-receipted'
    assert digest((out / 'generated/transition/tests/a11y_activation.rs').read_bytes()) == receipt['a11yActivationConsumerSha256'], 'a11y activation target must be source-receipted'
    status['producerReceiptSha256'] = digest((out / 'generated/source-receipt.json').read_bytes())


def prepare():
    step('node', ['node', '--version'], 60, contains('v24.22.3'))
    step('pnpm', pnpm + ['--version'], 120, contains('10.32.1'))
    # Fails explicitly if this exact toolchain is absent. Root may then install
    # the same pinned toolchain used by the repository workflow and rerun with
    # a new receipt directory; no system/default Rust is substituted.
    step('rustc', ['rustc', '+1.98.1', '--version', '--verbose'], 120, contains('rustc 1.98.1'))
    step('cargo', ['cargo', '+1.98.1', '--version'], 120, contains('1.98.1'))
    lock = digest((root / 'pnpm-lock.yaml').read_bytes())
    step('frozen-install', pnpm + ['install', '--frozen-lockfile', '--ignore-scripts'], 900)
    assert digest((root / 'pnpm-lock.yaml').read_bytes()) == lock, 'frozen installation changed the lock'
    step('native-prerequisites', ['pkg-config', '--exists', 'alsa', 'fontconfig', 'openssl', 'libudev', 'vulkan', 'wayland-client', 'xcb', 'xcb-composite', 'xcb-randr', 'xcb-shape', 'xcb-xfixes', 'xkbcommon', 'xkbcommon-x11'], 60)
    step('source-regressions', pnpm + ['exec', 'vitest', 'run', 'packages/compiler/test/gpui-control-label.test.ts', '--maxWorkers=1', '--minWorkers=1', '--reporter=json', '--outputFile=' + str(out / 'source-regressions.json')], 300, verify_source_json)
    step('spec-authoring', ['node', '--import', 'tsx', 'scripts/spec/check-lifecycle-authoring.mjs', '--base', candidate['base']], 300)
    step('producer', ['node', '--import', 'tsx', 'packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs', str(out / 'generated')], 300, verify_producer)
    step('lowering-inventory', ['node', '--import', 'tsx', 'scripts/gpui/audit-source-lowering.mjs', str(out / 'generated'), str(out / 'lowering-inventory.json')], 300)


def phases(name):
    if name == 'prepare':
        prepare()
    elif name == 'types':
        step('style-generator', pnpm + ['--filter', 'apps-www', 'generate:proto-ui-style'], 300)
        step('workspace-types', pnpm + ['check:types:workspace'], 600)
    elif name == 'headless':
        step('headless-consumer', pnpm + ['exec', 'vitest', 'run', 'packages/compiler/test/rust-data-source.test.ts', 'packages/compiler/test/rust-data-artifacts.test.ts', '--maxWorkers=1', '--minWorkers=1', '--reporter=default', '--reporter=json', '--outputFile.json=' + str(out / 'headless-consumer.json')], 900)
    elif name == 'graph-fixtures':
        step('cargo-graph-fixtures', ['node', '--test', 'scripts/gpui/test/cargo-graph.test.mjs'], 300)
    elif name == 'graph':
        assert manifest.is_file(), 'run prepare before Cargo phases'
        step('cargo-graph', ['node', 'scripts/gpui/check-cargo-graph.mjs', '--manifest-path', str(manifest), '--git', 'https://github.com/zed-industries/zed', '--rev', '62e5991dd0f0c8a3af8d5e7e9c4652490d468db8', '--toolchain', '1.98.1', '--output', str(out / 'cargo-graph.json')], 900)
    elif name == 'check':
        assert manifest.is_file(), 'run prepare before Cargo phases'
        step('default-check', ['cargo', '+1.98.1', 'check', '--locked', '--manifest-path', str(manifest), '--lib'], 3600)
    elif name in ['ordinary', 'control-label', 'style-mapping', 'a11y-activation']:
        assert manifest.is_file(), 'run prepare before Cargo phases'
        target, expected = {'ordinary': ('ordinary', 39), 'control-label': ('control_label', 14), 'style-mapping': ('style_mapping', 1), 'a11y-activation': ('a11y_activation', 4)}[name]
        step(name + '-consumer', ['cargo', '+1.98.1', 'test', '--locked', '--manifest-path', str(manifest), '--features', 'test-support', '--test', target, '--', '--test-threads=1', '--nocapture'], 5400, native_count(expected))


try:
    verify_source()
    save()
    if args.phase == 'all':
        for name in ['prepare', 'types', 'headless', 'graph-fixtures', 'graph', 'check', 'ordinary', 'control-label', 'style-mapping', 'a11y-activation']:
            phases(name)
    else:
        phases(args.phase)
    status['state'] = 'passed'
    status['lastCompletedPhase'] = args.phase
    status.pop('currentStep', None)
    save()
    print(json.dumps({'phase': args.phase, 'status': 'passed', 'candidateDigest': candidate['candidateDigest'], 'receipt': str(status_path)}))
except Exception as error:
    status['state'] = 'failed'
    status['failure'] = str(error)
    save()
    print(json.dumps({'phase': args.phase, 'status': 'failed', 'failure': str(error), 'receipt': str(status_path)}), file=sys.stderr)
    sys.exit(1)
