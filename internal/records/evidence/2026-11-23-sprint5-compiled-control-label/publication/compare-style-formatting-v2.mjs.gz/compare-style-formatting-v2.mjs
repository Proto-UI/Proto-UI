import fs from 'node:fs';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import path from 'node:path';
const root = process.argv[2];
const evidence = process.argv[3];
const require = createRequire(path.join(root, 'package.json'));
const ts = require('typescript');
const digest = value => crypto.createHash('sha256').update(value).digest('hex');
const excluded = new Set(['pos', 'end', 'id', 'transformFlags', 'modifierFlagsCache', 'nodeCount', 'identifierCount', 'symbolCount', 'multiLine', 'singleQuote', 'parent', 'original', 'emitNode', 'symbol', 'localSymbol', 'locals', 'flowNode', 'endFlowNode', 'returnFlowNode']);
function canonical(node) {
  if (node === undefined) return null;
  if (node === null || typeof node !== 'object') return node;
  if (Array.isArray(node)) return node.map(canonical);
  if (node instanceof Map) return [...node.entries()].map(([k, v]) => [k, canonical(v)]);
  const result = {};
  for (const key of Object.keys(node).sort()) {
    if (excluded.has(key)) continue;
    if (node.kind === ts.SyntaxKind.SourceFile && key === 'text') continue;
    const value = node[key];
    if (typeof value === 'function' || value === undefined) continue;
    result[key] = canonical(value);
  }
  return result;
}
function parse(source) {
  const file = ts.createSourceFile('gpui-native-style.ts', source, ts.ScriptTarget.Latest, false, ts.ScriptKind.TS);
  if (file.parseDiagnostics.length) throw new Error('parse diagnostic');
  return file;
}
function readLiteral(node) {
  if (ts.isAsExpression(node) || ts.isParenthesizedExpression(node)) return readLiteral(node.expression);
  if (ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) return node.text;
  if (ts.isNumericLiteral(node)) return Number(node.text);
  if (ts.isArrayLiteralExpression(node)) return node.elements.map(readLiteral);
  if (ts.isObjectLiteralExpression(node)) return Object.fromEntries(node.properties.map(property => {
    if (!ts.isPropertyAssignment(property)) throw new Error('non-literal property');
    const name = ts.isIdentifier(property.name) || ts.isStringLiteral(property.name) ? property.name.text : null;
    if (name === null) throw new Error('non-literal name');
    return [name, readLiteral(property.initializer)];
  }));
  throw new Error('unexpected literal node ' + ts.SyntaxKind[node.kind]);
}
function embedded(file) {
  const declaration = file.statements.filter(ts.isVariableStatement).flatMap(s => [...s.declarationList.declarations]).find(d => ts.isIdentifier(d.name) && d.name.text === 'gpuiNativeStyleFiles');
  if (!declaration?.initializer) throw new Error('missing embedded support array');
  return readLiteral(declaration.initializer);
}
const before = fs.readFileSync(path.join(evidence, 'formatting/before-gpui-native-style.ts'), 'utf8');
const after = fs.readFileSync(path.join(evidence, 'formatting/after-gpui-native-style.ts'), 'utf8');
const a = parse(before), b = parse(after);
const aTree = JSON.stringify(canonical(a)), bTree = JSON.stringify(canonical(b));
const aFiles = embedded(a), bFiles = embedded(b);
const controls = [
 ['literal', 'const x=1;', 'const x=2;'],
 ['operator', 'const x=a+b;', 'const x=a-b;'],
 ['for-role', 'for(a;;){}', 'for(;a;){}'],
 ['raw-template', 'String.raw`a\\n`', 'String.raw`a\n`'],
 ['flags', 'const x=1;', 'let x=1;'],
];
const negatives = controls.map(([name, x, y]) => ({ name, rejected: JSON.stringify(canonical(parse(x))) !== JSON.stringify(canonical(parse(y))) }));
const report = {
 schemaVersion: 1,
 kind: 's5-prettier-structural-and-embedded-rust-comparison',
 typescript: ts.version,
 beforeSha256: digest(before), afterSha256: digest(after),
 ast: { beforeSha256: digest(aTree), afterSha256: digest(bTree), equal: aTree === bTree, omittedKeys: [...excluded], sourceFileTextExcludedBecauseSeparatelyHashed: true, namedPropertyRolesRetained: true },
 embeddedSupportEqual: JSON.stringify(aFiles) === JSON.stringify(bFiles),
 embeddedFiles: aFiles.map(f => ({ path: f.path, sha256: digest(f.contents), bytes: Buffer.byteLength(f.contents) })),
 negativeControls: negatives,
 scope: 'Structural/decoded-string equivalence of one normal Prettier edit; not a new Rust run or hosted CI result.'
};
fs.writeFileSync(path.join(evidence, 'formatting/equivalence.json'), JSON.stringify(report, null, 2)+'\n');
console.log(JSON.stringify({astEqual:report.ast.equal, embeddedEqual:report.embeddedSupportEqual, embeddedFiles:report.embeddedFiles.length, negativeControls:negatives}));
if (!report.ast.equal || !report.embeddedSupportEqual || negatives.some(x => !x.rejected)) process.exitCode = 1;
