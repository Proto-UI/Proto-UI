# Independent review of hosted run 45259712127

## Conclusion and exact source

The browser, source regression, and production build jobs all succeeded at commit `2df421b1fc55cc0649be6675c0ee46a69ad9316f`, tree `67e54cae53ee5a8f9f3da7206e1b1dc03c6aef20`. Their original ZIP archives passed independent GitHub API SHA-256, byte-size, and complete ZIP CRC verification.

The overall workflow is **failure**: both native consumer jobs failed at the official Input/ControlLabel step. The package budget and shader jobs were skipped. Those separate outcomes are preserved; they are not relabeled as browser results.

The original production browser receipt has **20 passed cases, no failed cases**, covering exactly **two Base Button documentation routes × four targets = eight executed target rows**. This supports acceptance of that bounded execution at the recorded source. It does not close the entire browser inventory or Sprint 5.

## What the actual journey proves

| Condition | Source-bound observation |
| --- | --- |
| Actual production preparation | The owned complete Astro build exited 0 after 132,299 ms. Its clean source, lockfile, emitted files, static server, and final server retirement are recorded. Font preparation succeeded. |
| Cold ordinary preview | The ordinary documentation button was visible before any Compiler bundle request or Compiler Worker creation. Opening the panel loaded the bound QuickJS WASM Compiler and reached ready. |
| English four-target consumption | WC, React, Vue 3, and Vue 2 each mounted the actual emitted control in an iframe. Pointer, Space, and Enter produced three events; forced pointer activation of the disabled control did not add an event. |
| Ordinary Compiler parity | Every generated entry and supporting file displayed by each English target matched the ordinary `compilePrototype` output byte for byte. Revision, request, target, and generated entry hashes are retained. |
| Iframe isolation | Each English target retained `sandbox="allow-scripts"`. Actual iframe attempts to read the parent document, local storage, and cookies were rejected. |
| Edit, reject, recover | An authored top-level throw was rejected with PUI1004 without execution; the old iframe and generated text cleared. A valid disabled edit produced a different request hash, corresponding generated source, and a visibly disabled preview. Restoring the original source recovered. |
| Cancel, close, reopen | Cancel reached disposed and removed the iframe. Actual Workers retired under the existing five-second Worker check. Run restarted; closing disposed the session; reopening reached ready at a different revision. |
| Chinese four-target consumption | Each of the four Chinese targets delivered the expected click event and disabled ARIA state. Navigation back to the English home page removed the Compiler iframe and retired the Workers. |
| Worker and loaded asset closure | Four actual production Workers used the sealed emitted Worker chunk and all closed. Four loaded QuickJS WASM instances matched the recorded binary. Six Compiler/target assets and 206 loaded production resources matched sealed hashes. The page and console error list is empty. |
| Source stability | The before/after input fingerprints match. All 10,683 recorded input hashes were independently checked: 10,632 immutable Git blobs at the exact commit and 51 frozen installed dependency files. No missing or mismatched input was found. |

### The original 250 ms guard

Seven critical runner, Worker, delivery, panel, and retirement files were byte-verified against the original receipt and the prior `0b7b212d` baseline; they are unchanged. The preview acknowledgement code still rejects on its original **250 ms timer**, and the panel preserves retirement failure across later opens.

The selected successful edit/recovery and cancel/reopen journeys did not trigger this guard. The receipt does **not** contain per-retirement elapsed times or a latency distribution. The whole edit case's 8,207 ms and cancel/reopen case's 24,788 ms are complete journey durations, not cleanup times. This evidence does not establish a measured cleanup p95 or a separate hard wall-clock budget.

## Other successful gates and distinct denominators

| Evidence | Actual result |
| --- | --- |
| Source regression selection | 37 files; 659/659 tests; no failed, skipped, or todo tests. |
| Workspace and documentation types | The original `check:types` command chain completed successfully. The 1,330-file total belongs to Astro's documentation check: 0 errors, 0 warnings, 47 hints. It is not the workspace TypeScript file count. |
| Production website | 684 pages built in the separate production build job. |
| Bundle checker controls | 2,150/2,150 control tests. |
| Emitted bundle graph | Separately, 2,606 unique chunks and 5,898 modules in the unmodified raw graph. |
| Actual WC SSR retirement | A separate four-case Chromium fixture passed and retained its own four scenario JSON/PNG pairs and generated-client provenance. These cases are additional to the canonical 20. |

The browser environment was Chrome `157.0.8103.78`, Node `v24.22.3`, and pnpm `10.32.1`. The browser OS sandbox remained enabled. Noto Sans CJK was installed and selected.

## Visual reading and preserved inventory

Both original documentation screenshots were inspected. The English image shows the WC compiled preview ready at revision 20, enabled and disabled labels, editable source, and generated-source disclosure. The Chinese image shows the Vue 2 preview ready at revision 9, legible Chinese labels, and one click event. This does not constitute all-target visual fidelity or assistive technology acceptance.

The delivery overlay preserves its original 494 pages, 264 demos, and 722 prototypes. Only the two selected Base Button pages have the eight executed target rows. The other 492 pages remain pending, all 264 demos remain pending full migration, and 721 other prototypes remain pending browser execution. The overlay's recorded status is `browser-executed-awaiting-independent-acceptance`; this review accepts only the conditions explicitly supported above.

## Custody and limits

The directory retains the three original ZIPs, API run/job/artifact metadata, complete member CRC/SHA manifests, unmodified logs and screenshots, full input verification, and the seven exact reviewed source files. `review.json` contains the machine-readable observations and all 20 original case entries.

The earlier `0b7b212d` run on doesvm remains a production-build resource-deadline failure before any page journey. Older preview cleanup and font preparation failures also remain preserved. This later hosted success is not a rewrite of those results.

This successful `2df421b1` run predates this team's later Focus `:dir` correction and SSR/JSON integration. It cannot be credited to those later changes or relabeled as acceptance of the final `f6bdadf1` tree. Final affected-source verification remains separate. No physical touch/pen/hardware, assistive technology, multiple-browser coverage, accepted performance budget, full inventory migration, every rapid-edit permutation, or public SSR admission is claimed. This is a technical artifact review, not a GitHub approval.
