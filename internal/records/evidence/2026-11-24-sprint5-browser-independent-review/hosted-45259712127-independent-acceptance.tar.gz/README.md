# Independent acceptance record — run 45259712127

This compact record preserves independent acceptance of the selected browser,
source and production results at `2df421b1fc55cc0649be6675c0ee46a69ad9316f`
(tree `67e54cae53ee5a8f9f3da7206e1b1dc03c6aef20`). The full workflow failed in
its native GPUI jobs. Only the three identified successful jobs are accepted here.

The canonical production browser actually passed 20 cases on two Base Button
routes and four generated targets, yielding eight delivery rows. The original
250 ms cleanup guard remained enabled and did not trigger. The receipt does not
contain a cleanup latency distribution. These results predate the later Focus,
SSR and JSON changes and are not relabeled as acceptance of a later head.

Read `review.md` and `review.json` for the condition-by-condition conclusions and
limits. Original receipt, unmodified delivery inventory, production manifest,
source test result, relevant source files, screenshots and API metadata are
included. `delivery-eight-rows.json` extracts the original eight execution rows
without changing their original awaiting-acceptance status. The independent
acceptance decision is recorded separately in the review.

## Repeat verification

`verify.py` uses only the Python standard library. It verifies the compact record
and cross-checks the original successful cases, source/test binding and ownership
closure. It does not execute a browser.

```sh
python verify.py
python verify.py --originals /path/to/original-zip-directory --repo /path/to/repository
```

The optional original directory contains `browser.zip`, `source.zip` and
`production.zip`. Those are the unchanged downloaded GitHub ZIP bytes. The Git
repository must contain the exact historical commit objects; the installed
dependencies must match its frozen lockfile. The script verifies Git inputs with
`git ls-tree -z` and `git cat-file`, without checking out or changing a branch.

The archived successful recheck verified all three ZIP digests and CRCs, all
10,632 tracked input files and 51 installed dependency files, the three sealed
production artifacts and 206 loaded production asset hashes. It also checked the
raw graph of 2,606 chunks and 5,898 modules. The separate 2,150 bundle checker
controls are a different denominator.

## Full artifact identity and retention

Run: <https://github.com/Proto-UI/Proto-UI/actions/runs/45259712127>, attempt 1.
The original large ZIPs and full emitted products are deliberately not duplicated
inside this compact record. The captured GitHub metadata reports these expiry
times; no availability after expiry is promised. `retention.json` preserves IDs,
official API/download URLs, exact byte sizes, digests and capture metadata.

| Scope | Artifact ID | Bytes | Recorded expiry (UTC) | SHA-256 |
|---|---:|---:|---|---|
| Browser | 14859968084 | 2,012,052 | 2026-12-23 20:32:55 | `24f0c13f7d841a162eb9173885a3efa851b3be68d3b5a9375f9b6306964fab3e` |
| Source | 14860895880 | 91,180 | 2026-12-23 20:33:51 | `382630283f003e7932c9fd859bf80906570a60380f37d7275ecd10be2fff8943` |
| Production | 14858984928 | 425,332 | 2026-12-23 20:31:33 | `7cfd2b5a4094c33a3da7799fb4add37ecbae361be6b568663ae852601a2ee1e4` |

This record is intended for repository history together with its archive digest.
The record establishes the stated bounded evidence; it does not activate public
SSR, accept all browser pages or targets, or satisfy physical hardware/AT gates.
