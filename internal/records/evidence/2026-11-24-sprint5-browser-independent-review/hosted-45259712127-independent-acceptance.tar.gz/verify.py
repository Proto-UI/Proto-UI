#!/usr/bin/env python3
"""Recheck the compact acceptance record, optionally the original ZIPs and Git inputs.

This is a read-only evidence verifier, not a browser rerun. The original run
retains its actual overall failure and selected successful job boundaries.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

HEAD = '2df421b1fc55cc0649be6675c0ee46a69ad9316f'
TREE = '67e54cae53ee5a8f9f3da7206e1b1dc03c6aef20'
parser = argparse.ArgumentParser()
parser.add_argument('--bundle', type=Path, default=Path(__file__).resolve().parent)
parser.add_argument('--originals', type=Path, help='Directory containing browser.zip, source.zip, production.zip')
parser.add_argument('--repo', type=Path, help='Git checkout containing HEAD objects and frozen installed dependencies')
parser.add_argument('--output', type=Path)
args = parser.parse_args()
base = args.bundle

def digest(value):
    return hashlib.sha256(value).hexdigest()

def read(name):
    return json.loads((base / name).read_text())

result = {'kind': 'independent-receipt-reverification', 'head': HEAD, 'physicalBrowserRerun': False}
manifest = read('integrity-manifest.json')
for member in manifest['files']:
    content = (base / member['path']).read_bytes()
    assert len(content) == member['bytes'], member['path']
    assert digest(content) == member['sha256'], member['path']
result['compactFilesVerified'] = len(manifest['files'])

run = read('run.json')
assert run['id'] == 45259712127 and run['head_sha'] == HEAD
assert run['conclusion'] == 'failure'
jobs = read('jobs.json')['jobs']
for job_id in [137990901278, 137990901386, 137990901860]:
    job = next(value for value in jobs if value['id'] == job_id)
    assert job['conclusion'] == 'success', job
result['workflow'] = {'overall': run['conclusion'], 'selectedSuccessfulJobs': [137990901278, 137990901386, 137990901860]}

receipt = read('browser/receipt.json')
production = receipt['service']['production']
assert receipt['head'] == HEAD
assert production['source']['head'] == HEAD and production['source']['tree'] == TREE
assert production['build']['exitCode'] == 0
assert receipt['service']['owner']['closed'] is True
assert len(receipt['cases']) == 20 and all(value['status'] == 'passed' for value in receipt['cases'])
assert len(receipt['productionWorkers']) == 4 and all(value['closed'] for value in receipt['productionWorkers'])
assert len(receipt['loadedWasm']) == 4 and len({value['sha256'] for value in receipt['loadedWasm']}) == 1
assert receipt['consoleErrors'] == []
source_digest = digest(json.dumps(receipt['sourceFiles'], ensure_ascii=False, separators=(',', ':')).encode())
assert source_digest == receipt['sourceStability']['beforeSha256'] == receipt['sourceStability']['afterSha256']
for name, loaded in receipt['loadedProductionAssets'].items():
    assert loaded['sha256'] == production['files'][name]['sha256'] and loaded['status'] == 200, name
delivery = read('browser/verified-delivery.json')
rows = read('delivery-eight-rows.json')['rows']
assert len(rows) == 8
assert {row['route'] for row in rows} == {'/en/ui-libraries/base/button/', '/zh-cn/ui-libraries/base/button/'}
assert len(delivery['pages']) == 494 and len(delivery['demos']) == 264 and len(delivery['prototypes']) == 722
assert delivery['receipt']['head'] == HEAD
source_tests = read('source/vitest.json')
assert source_tests['numPassedTests'] == 659 and source_tests['numFailedTests'] == 0 and source_tests['numPendingTests'] == 0
for scenario in ['disposed', 'terminal', 'unmounted', 'same-checkpoint']:
    assert read(f'browser/owner-hydration-retirement/{scenario}.json')['outcome'] == 'PASS'
result['receiptCrossChecks'] = {
    'browserCasesPassed': 20, 'deliveryRows': 8, 'closedWorkers': 4,
    'loadedProductionAssetHashes': len(receipt['loadedProductionAssets']),
    'sourceTestsPassed': 659, 'separateOwnerBrowserCasesPassed': 4,
    'original250msGuard': 'enabled in source; no trigger in selected run; no cleanup duration distribution claimed',
}

artifact_meta = {value['id']: value for value in read('artifacts.json')['artifacts']}
result['originalZipVerification'] = []
if args.originals:
    for kind in ['browser', 'source', 'production']:
        recorded = read(f'{kind}-archive-manifest.json')
        path = args.originals / f'{kind}.zip'
        payload = path.read_bytes()
        api = artifact_meta[recorded['artifactId']]
        assert len(payload) == recorded['zipBytes'] == api['size_in_bytes']
        assert digest(payload) == recorded['zipSha256'] == api['digest'].removeprefix('sha256:')
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
            for member in recorded['files']:
                name = member['path']
                assert not Path(name).is_absolute() and '..' not in Path(name).parts
                value = archive.read(name)
                assert len(value) == member['bytes'] and digest(value) == member['sha256'], name
            if kind == 'browser':
                for name, sealed in production['productionArtifacts'].items():
                    value = archive.read(f'production/{name}')
                    assert len(value) == sealed['bytes'] and digest(value) == sealed['sha256']
            if kind == 'production':
                graph_bytes = archive.read('proto-ui-bundle-graph.json')
                expected = archive.read('production-graph.sha256').decode().split()[0]
                assert digest(graph_bytes) == expected
                graph = json.loads(graph_bytes)
                assert len(graph['chunks']) == 2606 and len(graph['modules']) == 5898
                result['productionGraph'] = {'chunks': 2606, 'modules': 5898, 'sha256': expected}
        result['originalZipVerification'].append({'kind': kind, 'id': api['id'], 'bytes': len(payload), 'sha256': digest(payload), 'files': len(recorded['files']), 'crc': 'passed'})

if args.repo:
    assert subprocess.check_output(['git', 'rev-parse', f'{HEAD}^{{tree}}'], cwd=args.repo, text=True).strip() == TREE
    listing = subprocess.check_output(['git', 'ls-tree', '-r', '-z', HEAD], cwd=args.repo)
    blobs = {}
    for entry in listing.split(b'\0'):
        if not entry:
            continue
        metadata, name = entry.split(b'\t', 1)
        _, kind, oid = metadata.split()
        assert kind == b'blob'
        blobs[name.decode()] = oid.decode()
    expected = receipt['sourceFiles']
    objects = sorted({blobs[name] for name in expected if name in blobs})
    response = subprocess.run(['git', 'cat-file', '--batch'], cwd=args.repo,
        input=('\n'.join(objects) + '\n').encode(), stdout=subprocess.PIPE, check=True).stdout
    hashes = {}
    cursor = 0
    for oid in objects:
        end = response.index(b'\n', cursor)
        actual, kind, length = response[cursor:end].split()
        assert actual.decode() == oid and kind == b'blob'
        cursor = end + 1
        size = int(length)
        hashes[oid] = digest(response[cursor:cursor + size])
        cursor += size + 1
    git_count = dependency_count = 0
    for name, sha in expected.items():
        if name in blobs:
            assert hashes[blobs[name]] == sha, name
            git_count += 1
        else:
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            assert digest((args.repo / name).read_bytes()) == sha, name
            dependency_count += 1
    assert git_count == 10632 and dependency_count == 51
    result['sourceInputVerification'] = {'gitBlobs': git_count, 'frozenDependencyFiles': dependency_count, 'total': len(expected), 'differences': 0}
else:
    result['sourceInputVerification'] = {'mode': 'prior original result included; no Git replay requested', 'record': 'source-input-verification.json'}

result['success'] = True
encoded = json.dumps(result, indent=2) + '\n'
if args.output:
    args.output.write_text(encoded)
print(encoded)
