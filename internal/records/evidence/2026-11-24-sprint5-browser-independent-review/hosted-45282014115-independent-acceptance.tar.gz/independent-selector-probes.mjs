// Read-only independent boundary probes against the exact original helpers.
// This is parser/helper evidence, not native input, timing or a browser rerun.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const output = dirname(fileURLToPath(import.meta.url));
const repo = resolve(process.argv[2]);
const ts = createRequire(resolve(repo, 'package.json'))('typescript');
const path = 'packages/adapters/web-component/src/runtime/modules.ts';
const oldSource = execFileSync('git', ['show', `b8800d4cef9302718d4514b1ba28508860059929:${path}`], { cwd: repo, encoding: 'utf8' });
const frozenPath = resolve(output, 'frozen-source', path);
const newSource = existsSync(frozenPath) ? readFileSync(frozenPath, 'utf8') : execFileSync('git', ['show', `25ca6fcaecd917457f6f3d694b3e12bfb522e89a:${path}`], { cwd: repo, encoding: 'utf8' });
const sha = (value) => createHash('sha256').update(value).digest('hex');
assert.equal(sha(oldSource), '075436cbcf17fdcb7ef8e0983048bd2784f993f65f5579b936a7fb1b24172811');
assert.equal(sha(newSource), '4406d1a05d0249635250457562a843e0ed247eb2855c5abdcc4ed76bcf8c5bfa');
function helper(source) {
  const file = ts.createSourceFile('modules.ts', source, ts.ScriptTarget.Latest, true);
  const names = ['skipSelectorLiteral', 'selectorMayDependOnInputState'];
  const declarations = file.statements.filter((node) => ts.isFunctionDeclaration(node) && names.includes(node.name?.text));
  assert.equal(declarations.length, 2);
  const extracted = declarations.map((node) => node.getText(file)).join('\n');
  const js = ts.transpileModule(extracted, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
  return Function(`${js}\nreturn selectorMayDependOnInputState;`)();
}
const old = helper(oldSource), candidate = helper(newSource);
const identities = [
  'file-selector-button', '-webkit-details-marker', '-webkit-search-decoration',
  '-webkit-date-and-time-value', '-webkit-datetime-edit', '-webkit-datetime-edit-fields-wrapper',
  ...['year','month','day','hour','minute','second','millisecond','meridiem'].map((field) => `-webkit-datetime-edit-${field}-field`),
  '-webkit-calendar-picker-indicator', '-webkit-inner-spin-button', '-webkit-outer-spin-button',
];
assert.equal(identities.length, 17);
const cases = identities.flatMap((name) => [
  { selector: `::${name}`, expected: false, oldExpected: true, boundary: 'finite native identity' },
  { selector: `INPUT::${name.toUpperCase()}`, expected: false, oldExpected: true, boundary: 'CSS case-insensitive identity' },
]);
for (const state of ['valid', 'invalid', 'user-valid', 'user-invalid', 'in-range', 'out-of-range', 'autofill', '-webkit-autofill', 'checked', 'indeterminate', 'placeholder-shown', 'dir(rtl)']) {
  cases.push({ selector: `body:has(input:${state}) .entry::file-selector-button`, expected: true, oldExpected: true, boundary: 'external native state in nested relationship' });
}
for (const selector of [
  '::-webkit-datetime-edit-unknown-field', '::-webkit-search-cancel-button',
  '::-webkit-file-selector-button', '::-moz-progress-bar',
  '::file-selector-button-unknown', '::file-selector-button:future-input-state',
  String.raw`::file-selector-button\2d unknown`, ':where(&)::file-selector-button',
  ':nth-child(2 of :has(input:invalid))::file-selector-button',
  ':not(:is(:checked, .plain))::-webkit-inner-spin-button',
]) cases.push({selector, expected:true, oldExpected:true, boundary:'unresolved or stateful condition remains conservative'});
cases.push({ selector: '[data-note="input:invalid"]::file-selector-button', expected:false, oldExpected:true, boundary:'attribute literal is not a state predicate' });
cases.push({ selector: '.one::file-selector-button, .two:invalid', expected:true, oldExpected:true, boundary:'later selector-list branch still scanned' });
const results = cases.map((item) => {
  const before = old(item.selector), after = candidate(item.selector);
  assert.equal(before, item.oldExpected, `original: ${item.selector}`);
  assert.equal(after, item.expected, `candidate: ${item.selector}`);
  return {...item, before, after, status:'passed'};
});
const result = { kind:'independent-exact-helper-boundary-probes', typescript:ts.version,
  sourceSha256:sha(newSource), originalSourceSha256:sha(oldSource),
  executedRuntime:false, executedPhysicalBrowser:false, passed:results.length, failed:0, results };
writeFileSync(resolve(output, 'independent-selector-probes.json'), `${JSON.stringify(result,null,2)}\n`);
console.log(JSON.stringify({passed:result.passed, failed:0, sourceSha256:result.sourceSha256}));
