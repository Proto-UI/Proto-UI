#!/usr/bin/env python3
"""Independent read-only verification of run 45282014115; no browser rerun."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import zipfile

HEAD = '25ca6fcaecd917457f6f3d694b3e12bfb522e89a'
TREE = '45c5e08bc7a773e3534fd4b07dc66ea437c73c46'
BASE = 'b8800d4cef9302718d4514b1ba28508860059929'
RECORD = '1afa22e88c087db244f0e28a835b2926fb8bce8e'
parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--dependencies', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parent

def sha(value):
    return hashlib.sha256(value).hexdigest()

def read(name):
    path = root / name
    if path.exists():
        return json.loads(path.read_text())
    label, relative = name.split('/', 1)
    return json.loads(artifact_bytes(label, relative))

def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()

def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=args.repo)

result = {'kind': 'independent-source-and-hosted-receipt-review', 'head': HEAD,
          'tree': TREE, 'physicalBrowserRerun': False, 'newBuildRun': False}
assert git('rev-parse', HEAD + '^{tree}').decode().strip() == TREE
assert git('rev-parse', HEAD + '^').decode().strip() == BASE
assert git('rev-parse', RECORD + '^').decode().strip() == HEAD
assert all(name.startswith('internal/records/') for name in
           git('diff', '--name-only', HEAD, RECORD).decode().splitlines())
result['laterRecordOnlyCommit'] = RECORD
metadata = read('github-metadata.json')
run = read('run.json')
assert run['id'] == 45282014115 and run['head_sha'] == HEAD
assert run['status'] == 'completed' and run['conclusion'] == 'success'
result['jobs'] = [{'id': j['id'], 'name': j['name'], 'conclusion': j['conclusion']}
                  for j in metadata['jobs']]
assert sum(j['conclusion'] == 'success' for j in result['jobs']) == 6
assert sum(j['conclusion'] == 'skipped' for j in result['jobs']) == 3

# Verify both original, committed evidence collections without creating another copy.
collections = {}
archive_checks = []
for suffix in ['retirement', 'final-acceptance']:
    name = f'internal/records/evidence/2026-11-23-sprint5-native-part-input-{suffix}/manifest.json'
    payload = (args.repo / name).read_bytes()
    assert payload == git('show', f'{RECORD}:{name}')
    manifest = json.loads(payload)
    originals = {}
    raw_total = gzip_total = 0
    for e in manifest['entries']:
        compressed = (args.repo / e['path']).read_bytes()
        assert len(compressed) == e['gzipBytes'] and sha(compressed) == e['gzipSha256'], e['path']
        value = gzip.decompress(compressed)
        assert len(value) == e['rawBytes'] and sha(value) == e['rawSha256'], e['path']
        raw_total += len(value)
        gzip_total += len(compressed)
        originals[e['logicalPath']] = e
    assert len(originals) == manifest['archiveCount']
    assert raw_total == manifest['rawBytes'] and gzip_total == manifest['gzipBytes']
    collections[suffix] = originals
    archive_checks.append({'name': name, 'manifestSha256': sha(payload),
        'members': len(originals), 'rawBytes': raw_total, 'gzipBytes': gzip_total, 'differences': 0})
result['committedArchiveVerification'] = archive_checks

def original(collection, logical):
    return gzip.decompress((args.repo / collections[collection][logical]['path']).read_bytes())

zip_payloads = {}
for label in ['browser', 'source']:
    local = root / f'{label}.zip'
    zip_payloads[label] = local.read_bytes() if local.exists() else original(
        'final-acceptance', f'hosted/source-browser/{label}-artifact.zip')

def artifact_bytes(label, name):
    local = root / label / name
    if local.exists():
        return local.read_bytes()
    with zipfile.ZipFile(io.BytesIO(zip_payloads[label])) as archive:
        return archive.read(name)

api_artifacts = {a['id']: a for a in metadata['artifacts']}
zip_checks = []
production_zip = original('final-acceptance', 'hosted/production/production-artifact.zip')
for label, artifact_id, payload in [
    ('browser', 14869886909, zip_payloads['browser']),
    ('source', 14869222809, zip_payloads['source']),
    ('production', 14870946323, production_zip),
]:
    api = api_artifacts[artifact_id]
    assert len(payload) == api['size_in_bytes'] and sha(payload) == api['digest'].removeprefix('sha256:')
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        assert archive.testzip() is None
        for name in archive.namelist():
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            if label != 'production' and (root / label / name).exists():
                assert archive.read(name) == (root / label / name).read_bytes(), name
        if label == 'production':
            assert archive.read('source-sha.txt').decode().strip() == HEAD
            assert archive.read('source-tree.txt').decode().strip() == TREE
            graph_bytes = archive.read('proto-ui-bundle-graph.json')
            graph_hash = archive.read('production-graph.sha256').decode().split()[0]
            assert sha(graph_bytes) == graph_hash
            graph = json.loads(graph_bytes)
            controls = archive.read('bundle-gate-controls.log').decode()
            assert '\nℹ pass 2150\n' in controls and '\nℹ fail 0\n' in controls
            result['productionGate'] = {'graphSha256': graph_hash,
                'chunks': len(graph['chunks']), 'modules': len(graph['modules']),
                'checkerControls': 2150, 'checkerFailures': 0}
        zip_checks.append({'kind': label, 'artifactId': artifact_id, 'bytes': len(payload),
            'sha256': sha(payload), 'members': len(archive.namelist()), 'crc': 'passed',
            'expiresAt': api['expires_at']})
result['hostedArtifacts'] = zip_checks

receipt = read('browser/receipt.json')
production = receipt['service']['production']
assert receipt['head'] == HEAD and production['candidate'] == HEAD
assert production['source']['head'] == HEAD and production['source']['tree'] == TREE
assert production['source']['worktreeStatus'] == ''
assert production['build']['exitCode'] == 0 and production['build']['status'] == 'passed'
assert production['build']['stopReason'] is None
assert receipt['service']['mode'] == 'runner-owned-production-static'
assert receipt['service']['owner']['closed'] is True
assert len(receipt['cases']) == 20 and all(c['status'] == 'passed' for c in receipt['cases'])
assert len(receipt['productionWorkers']) == 4 and all(w['closed'] for w in receipt['productionWorkers'])
assert len(receipt['loadedWasm']) == 4 and len({w['sha256'] for w in receipt['loadedWasm']}) == 1
assert receipt['consoleErrors'] == []
assert sha(compact(receipt['sourceFiles'])) == receipt['sourceStability']['beforeSha256'] == receipt['sourceStability']['afterSha256']
assert receipt['sourceStability']['status'] == 'passed'
assert receipt['loadedAssets'] == receipt['buildManifest']['assets'] == receipt['service']['assets']
assert receipt['compilerBuild'] == receipt['buildManifest']['compilerBuild']
assert receipt['loadedAssets']['compiler.js'] == receipt['compilerBuild']['compilerSha256']
for name, loaded in receipt['loadedProductionAssets'].items():
    assert loaded['sha256'] == production['files'][name]['sha256'] and loaded['status'] == 200, name
for name, evidence in production['productionArtifacts'].items():
    payload = artifact_bytes('browser', 'production/' + name)
    assert len(payload) == evidence['bytes'] and sha(payload) == evidence['sha256'], name
assert read('browser/production/dist-files.json') == production['files']
assert sha(artifact_bytes('browser', 'production/dist-files.json')) == production['stability']['distSha256']
delivery = read('browser/verified-delivery.json')
assert delivery['receipt']['head'] == HEAD
assert delivery['receipt']['sourceFilesSha256'] == receipt['sourceStability']['beforeSha256']
assert delivery['receipt']['buildManifestSha256'] == sha(compact(receipt['buildManifest']))
rows = [{'route': p['route'], 'prototypeId': p['prototypeId'], **t}
        for p in delivery['pages'] if p['status'] == 'candidate' for t in p['targets']]
assert len(rows) == 8 and {r['route'] for r in rows} == {'/en/ui-libraries/base/button/', '/zh-cn/ui-libraries/base/button/'}
assert len(delivery['pages']) == 494 and len(delivery['demos']) == 264 and len(delivery['prototypes']) == 722
for c in receipt['cases']:
    if c['name'].startswith('revision-'):
        assert c['targetSha256'] == receipt['buildManifest']['targetModulesSha256'][c['name'][9:]]

source_tests = read('source/vitest.json')
assert source_tests['numPassedTests'] == 778 and source_tests['numFailedTests'] == 0
assert source_tests['numPendingTests'] == 0 and source_tests['numTodoTests'] == 0
assert len(source_tests['testResults']) == 44
focus_suite = next(f for f in source_tests['testResults'] if f['name'].endswith('focus-entry-input-origin.test.ts'))
assert len(focus_suite['assertionResults']) == 60 and all(t['status'] == 'passed' for t in focus_suite['assertionResults'])
direction = read('browser/wc-native-dir-auto.json')
assert direction['numPassedTests'] == 2 and direction['numFailedTests'] == 0 and direction['numPendingTests'] == 190
for scenario in ['disposed', 'terminal', 'unmounted', 'same-checkpoint']:
    assert read(f'browser/owner-hydration-retirement/{scenario}.json')['outcome'] == 'PASS'

listing = git('ls-tree', '-r', '-z', HEAD)
blobs = {}
for entry in listing.split(b'\0'):
    if entry:
        metadata_bytes, name = entry.split(b'\t', 1)
        _, kind, oid = metadata_bytes.split()
        assert kind == b'blob'
        blobs[name.decode()] = oid.decode()
expected = receipt['sourceFiles']
objects = sorted({blobs[name] for name in expected if name in blobs})
response = subprocess.run(['git', 'cat-file', '--batch'], cwd=args.repo,
    input=('\n'.join(objects) + '\n').encode(), stdout=subprocess.PIPE, check=True).stdout
hashes = {}
cursor = 0
for oid in objects:
    end = response.index(b'\n', cursor)
    actual, kind, length = response[cursor:end].split()
    assert actual.decode() == oid and kind == b'blob'
    cursor = end + 1
    size = int(length)
    hashes[oid] = sha(response[cursor:cursor + size])
    cursor += size + 1
git_count = dep_count = 0
for name, expected_hash in expected.items():
    if name in blobs:
        assert hashes[blobs[name]] == expected_hash, name
        git_count += 1
    else:
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        assert sha((args.dependencies / name).read_bytes()) == expected_hash, name
        dep_count += 1
result['sourceInputVerification'] = {'gitBlobs': git_count, 'frozenDependencyFiles': dep_count,
    'total': len(expected), 'differences': 0}

source_names = ['packages/adapters/web-component/src/runtime/modules.ts',
                'packages/adapters/web-component/test/focus-entry-input-origin.test.ts']
result['sourceReview'] = {}
for name in source_names:
    value = git('show', f'{HEAD}:{name}')
    frozen = root / 'frozen-source' / name
    if frozen.exists():
        assert value == frozen.read_bytes()
    result['sourceReview'][name] = {'blob': blobs[name], 'sha256': sha(value), 'bytes': len(value)}
old_test = git('show', f'{BASE}:{source_names[1]}')
assert git('show', f'{HEAD}:{source_names[1]}').startswith(old_test)
result['originalTestPrefixBytes'] = len(old_test)
old = json.loads(original('retirement', 'candidate/ab/old-helper-new-controls.json'))
new = json.loads(original('retirement', 'candidate/ab/new-helper-same-controls.json'))
assert (old['numTotalTests'],old['numPassedTests'],old['numFailedTests']) == (60,26,34)
assert (new['numTotalTests'],new['numPassedTests'],new['numFailedTests']) == (60,60,0)
failures = [a for f in old['testResults'] for a in f['assertionResults'] if a['status']=='failed']
assert len(failures) == 34 and all('expected true to be false' in a['failureMessages'][0] for a in failures)
for name in ['scripts/analysis/browser-compiler-browser.mts',
             'apps/www/src/components/PrototypePreviewer/compiled-preview-sandbox.ts',
             'apps/www/src/components/PrototypePreviewer/compiled-revision-session.ts',
             'apps/www/src/components/PrototypePreviewer/BrowserCompilerPanel.astro']:
    assert git('show', f'{HEAD}:{name}') == git('show', f'{BASE}:{name}'), name
    result.setdefault('unchangedAcceptanceSources', {})[name] = sha(git('show', f'{HEAD}:{name}'))
sandbox = git('show', f'{HEAD}:apps/www/src/components/PrototypePreviewer/compiled-preview-sandbox.ts').decode()
assert '}, 250);' in sandbox and 'Preview cleanup acknowledgement exceeded its 250-millisecond deadline.' in sandbox
canonical = git('show', f'{HEAD}:scripts/analysis/browser-compiler-browser.mts').decode()
assert 'chromiumSandbox: true' in canonical and 'report.productionWorkers.length >= 4' in canonical
result['browser'] = {'version': receipt['browser'], 'productionBuildMs': production['build']['elapsedMs'],
    'passed': 20, 'failed': 0, 'workerCount': 4, 'workersAllClosed': True, 'wasmRequests': 4,
    'loadedProductionAssets': len(receipt['loadedProductionAssets']), 'consoleErrors': 0,
    'sourceSha256': receipt['sourceStability']['beforeSha256'], 'distSha256': production['stability']['distSha256'],
    'deliveryRows': rows, 'inventory': {'pages': 494, 'demos': 264, 'prototypes': 722},
    'cleanupGuard': 'original 250 ms enabled; no failure in this run; no cleanup distribution recorded',
    'separateNativeDir': {'passed': 2, 'unselected': 190}, 'separateWcOwnerCases': 4}
result['sourceTests'] = {'files':44,'passed':778,'failed':0,'pending':0,'focusControls':60}
result['success'] = True
args.output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'success': True, 'sourceInputs': result['sourceInputVerification'],
    'sourceTests': result['sourceTests'], 'browserCases': 20, 'archiveMembers':sum(a['members'] for a in archive_checks),
    'productionGate':result['productionGate']}, indent=2))
