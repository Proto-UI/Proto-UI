# Independent review of the native-part input correction and formal browser acceptance

## Decision and exact source

The bounded browser correction at `25ca6fcaecd917457f6f3d694b3e12bfb522e89a`, tree `45c5e08bc7a773e3534fd4b07dc66ea437c73c46`, has no remaining source finding in this review. Its original production browser acceptance is independently supported by run [45282014115](https://github.com/Proto-UI/Proto-UI/actions/runs/45282014115). This is a source and evidence review; it is not a GitHub APPROVED review, release authorization, or acceptance of every condition in the parent Issues.

The correction is a direct child of `b8800d4cef9302718d4514b1ba28508860059929`. The later `1afa22e88c087db244f0e28a835b2926fb8bce8e` commit changes records only. Both ancestry relationships and the full file lists were checked from Git objects. No pending native/SSR source path in the followup worktree overlaps the two incoming files at the time of review. The separate, unpublished event-dedup alternative was not adopted or included in this acceptance.

| Source | Exact SHA-256 |
| --- | --- |
| `packages/adapters/web-component/src/runtime/modules.ts` | `4406d1a05d0249635250457562a843e0ed247eb2855c5abdcc4ed76bcf8c5bfa` |
| `packages/adapters/web-component/test/focus-entry-input-origin.test.ts` | `63f88eb9770d99e338bb64ff6f4105bf4bad1e1f735de3eb987fd464dc16acd4` |

## Source review and counterexamples

The product diff changes only the finite pseudo-element-name branch in `selectorMayDependOnInputState` and its explanatory comment. It adds exactly 17 explicit native control-part identities. The expression is anchored; it does not accept the whole WebKit namespace. Ordinary host pseudo-classes, later selector-list branches, nested functional conditions, unresolved names, nesting and escaped unknown suffixes still pass through the original conservative scan.

The rest of the dependency collector and `onProjectionEvent` is unchanged. Related descendants, live Portal ownership, slotted/composed ancestor paths and opaque stylesheet dependencies retain their existing sampling path. This patch does not deduplicate or delay events, introduce a CSS declaration allowlist, change event trust, remove observers, or alter the form/radio/reset paths. Consequently, it does not introduce the upper-ancestor ordering question posed by the discarded dedup alternative.

The original 13,229-byte, 18-case test file remains an exact prefix of the new file. The appended 34 input/change controls use the 17 native rules from the captured page; the other eight controls keep mixed real input-state and unresolved selectors conservative. I read the actual old and new JSONs: the old module with all 60 controls produced 26 passes and 34 failures, all at the intended unrelated-entry computed-style-read assertion; the candidate produced 60 passes, zero failures, pending or todo. Their raw SHA-256 values are respectively `6922df095231701e87a821d8a1d175bec1fca021b280251c1b802c64779f4a68` and `0d9c4458c19440504783323d9a295010d1534960a8ca6fb4fd1290c6702717c7`.

I also extracted the exact two helper declarations from both Git-bound sources using TypeScript 5.9.3 and executed 58 independent boundary probes. All passed. These cover the finite identities and case variants, `:user-valid`/`:user-invalid`, range, autofill, checked/indeterminate, `:dir(rtl)`, nested external `:has` conditions, near-miss vendor names, unknown suffixes, unresolved nesting, attribute literals and later selector-list branches. These are helper probes, not another execution of the Focus runtime or native browser timing.

The original read-only CSSOM survey and its peer review were also read. Its 38 sheets/3,646 rules/3,275 style rules had zero read errors, and the exact classification changed 23 native-part rules from dependent to independent. The survey observed an initial hydrated page, not the earlier profiled revision-11 checkpoint. The original diagnostic trace and the survey therefore retain their separate observation boundaries.

## Independent verification of the formal run

The actual workflow completed successfully at the exact 25ca head. Six jobs succeeded; the three explicitly opt-in jobs were skipped. Browser, source and production artifact ZIP byte lengths and SHA-256 digests match the independently fetched GitHub artifact metadata. All ZIP CRCs passed. The production artifact was read from the already committed original container; no new build is claimed here.

| Verified item | Result |
| --- | --- |
| Canonical production browser | 20/20, Chrome 157.0.8103.78 |
| Edit → reject → recover | Passed with source, diagnostic and visible-preview revision checks |
| Cancel/reopen and fresh owner | Passed |
| English/Chinese Base Button | Four generated targets on each route, eight bounded delivery rows |
| Actual production Workers | Four created and all four closed |
| Actual WASM loads | Four requests, one bound binary hash |
| Loaded production assets | 206 hashes matched sealed production output, all status 200 |
| Browser console/page errors | Zero |
| Source input verification | 10,687 files: 10,636 exact Git blobs and 51 frozen dependency files; zero differences |
| Source tests | 44 files, 778/778; zero pending, including all 60 Focus controls |
| Separate native `:dir(auto)` controls | 2/2; 190 unrelated cases were unselected |
| Separate WC emitted-SSR owner fixture | 4/4 |
| Production bundle checker controls | 2,150/2,150; these are controls, not chunk count |
| Actual production graph | 2,606 chunks and 5,898 modules |

The canonical entry performed its own production build in 134,804 ms and served that sealed result. Its source worktree was clean; the build exited zero without a stop reason. Compiler, target-module and generated-entry hashes are retained in the original per-revision rows. Loaded compiler/target assets match the build manifest, Worker URLs resolve to sealed production chunks, and the before/after source hash is `a6fdd08eb45b6043fc68fd3bd0662b6398e8876de0fec8ce62a2e6bc46c18978`. The sealed dist manifest is `07894258dff0d07fa93e0b61ed7b8788e65456ec67585244cb34113d873cef88`; the separate production job's graph is `7b480443e04240400c20b7b17828995cf09a1d2df4f9bf0487c2258914b74d22`.

The original canonical entry and panel/session/sandbox sources are byte-identical to b880. `chromiumSandbox: true`, the original 250 ms cleanup deadline, and the minimum four actual Workers assertion remain present. The 250 ms failure did not trigger in this run. The receipt does not record a cleanup-duration distribution, and the total case durations are not substituted for one.

The type job ran the workspace and documentation checking chain successfully. The `1,330 files / 0 errors / 0 warnings / 47 hints` summary is specifically Astro's documentation result, not a claimed workspace TypeScript file count.

## Custody and accepted limits

`verify.py` rechecked all 353 gzip members in the two already published evidence collections: 208 original failure/diagnostic/candidate items and 145 final acceptance/publication items. Each compressed and decompressed byte length and SHA-256 matched its manifest. The compact review package references those committed originals and the three hosted artifact IDs, digests and expiration dates; it does not duplicate their ZIPs or all emitted outputs.

This review accepts the eight original Base Button browser delivery rows and the narrow Focus correction at 25ca. It preserves the 494-page, 264-demo and 722-prototype inventory. The remaining 492 pages and other unsupported/unexecuted rows are not promoted by this result. Public SSR admission, broader non-Web/AT/hardware requirements, release budgets and parent-Issue completion remain outside this browser acceptance.

The ea600 formal result remains 17/20. Our separate b880 development diagnostic remains 17/19 with the original 250 ms failure and subsequent cancellation failure; it used Chrome 145.0.7632.6 and a passive profiler, so it is diagnostic evidence rather than production acceptance. The earlier 2df green browser result remains valid for its own source and does not replace either failure or the 25ca successor. Future native/SSR changes require their own affected-source acceptance on the separate followup branch.
