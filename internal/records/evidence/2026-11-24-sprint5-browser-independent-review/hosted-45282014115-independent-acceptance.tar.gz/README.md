# Reproduce the independent review

This package contains review material and read-only verification code. It reuses the original committed evidence at `1afa22e88c087db244f0e28a835b2926fb8bce8e` and does not duplicate hosted ZIPs or product source.

With a checkout containing that Git history and original frozen dependencies, run:

```sh
python verify.py --repo /absolute/repository --dependencies /absolute/frozen-checkout --output /absolute/new-verification.json
node independent-selector-probes.mjs /absolute/repository
```

The Python verifier reads the two committed native-part evidence manifests, their complete gzip members, and the original browser/source/production ZIPs. It validates API artifact digests and all 10,687 captured source inputs against exact Git objects or installed dependency bytes. It does not rebuild, rerun the browser, or count unselected tests as passed.

The JavaScript verifier extracts only the two exact selector helper declarations with the installed TypeScript 5.9.3. Its 58 controls are helper-level evidence, not native input or timing.

`review.json` retains hosted artifact IDs, SHA-256, byte sizes and expiry. Original artifact expiry does not remove the copies already committed in the public evidence collection.
