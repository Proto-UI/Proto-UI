import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const W='/tank/shared/projects/proto-ui-agent/continuation-s12-passive-4deb';
const E='/tank/shared/projects/proto-ui-agent/sprint12-evidence/lowered-helper-recovery-20261123/r6-format-validation-02';
const require=createRequire(path.join(W,'package.json'));
const ts=require('typescript');
const loaded=await import(pathToFileURL(require.resolve('prettier')).href);
const prettier=loaded.default??loaded;
const sha=s=>createHash('sha256').update(s).digest('hex');
const expectations={
 'packages/cli/src/services/hook-source-summary.ts':'b9571ce306d392a2329447bf4b6b577fb54ebe051f517c61dedc5e6f746c74fd',
 'packages/cli/test/hook-source-setup-capability.test.ts':'1cde9ce9e14b05ef019b5feeebf3d723bcd1832db328fa64e44e8474be290641',
};
function shape(node){
 if(ts.isParenthesizedExpression(node))return shape(node.expression);
 const children=[];ts.forEachChild(node,child=>{children.push(shape(child));});
 const result={kind:node.kind,children};
 if(typeof node.text==='string'&&!ts.isSourceFile(node))result.text=node.text;
 if(ts.isVariableDeclarationList(node))result.declarationFlags=node.flags&(ts.NodeFlags.Let|ts.NodeFlags.Const|ts.NodeFlags.Using|ts.NodeFlags.AwaitUsing);
 return result;
}
const rows=[];
for(const [relative,expected]of Object.entries(expectations)){
 const file=path.join(W,relative),before=fs.readFileSync(file,'utf8');
 if(sha(before)!==expected)throw Error('source changed '+relative);
 const config=await prettier.resolveConfig(file);
 const after=await prettier.format(before,{...config,filepath:file});
 const parsedBefore=ts.createSourceFile(file,before,ts.ScriptTarget.Latest,true);
 const parsedAfter=ts.createSourceFile(file,after,ts.ScriptTarget.Latest,true);
 if(parsedBefore.parseDiagnostics.length||parsedAfter.parseDiagnostics.length)throw Error('parse errors '+relative);
 const first=JSON.stringify(shape(parsedBefore)),second=JSON.stringify(shape(parsedAfter));
 if(first!==second)throw Error('format changed AST '+relative);
 rows.push({relative,before,after,beforeSha256:sha(before),afterSha256:sha(after),syntaxSha256:sha(first),syntaxEqual:true,parenthesesNormalized:true});
}
for(const row of rows){
 if(sha(fs.readFileSync(path.join(W,row.relative)))!==row.beforeSha256)throw Error('source changed before write '+row.relative);
}
for(const row of rows){
 fs.writeFileSync(path.join(E,path.basename(row.relative)+'.before'),row.before,{flag:'wx'});
 fs.writeFileSync(path.join(W,row.relative),row.after);
 fs.writeFileSync(path.join(E,path.basename(row.relative)+'.formatted'),row.after,{flag:'wx'});
}
const result={formatter:require.resolve('prettier'),version:require('prettier/package.json').version,typescript:ts.version,rows:rows.map(({before,after,...row})=>row)};
fs.writeFileSync(path.join(E,'format-result.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify(result));
