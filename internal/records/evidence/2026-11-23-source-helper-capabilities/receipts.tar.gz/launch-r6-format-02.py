import pathlib,os,subprocess,hashlib,json,time,traceback,resource
W=pathlib.Path('/tank/shared/projects/proto-ui-agent/continuation-s12-passive-4deb')
E=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint12-evidence/lowered-helper-recovery-20261123')
B=pathlib.Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
OUT=E/'r6-format-validation-02';OUT.mkdir(exist_ok=False)
status={'state':'starting','started':time.time(),'scope':'formatting-equivalent R6; original174 and strict proof retained; focused26 rechecked'}
def write():(OUT/'status.json').write_text(json.dumps(status,indent=2))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
tracked=['packages/cli/src/services/hook-source-summary.ts','packages/cli/test/hook-source-setup-capability.test.ts','packages/cli/src/services/hook-source-module.ts','packages/cli/src/services/prototype-style-tokens.ts','packages/cli/src/services/lowered-hook-coverage.ts','pnpm-lock.yaml']
def guard():return {p:sha(W/p) for p in tracked}
write()
env=os.environ.copy();env['PATH']=str(B/'tools/node-v24.22.3-linux-x64/bin')+':'+env.get('PATH','');env['COREPACK_HOME']=str(B/'corepack-cache');env['NODE_OPTIONS']='--max-old-space-size=768';env['TMPDIR']='/tank/shared/projects/proto-ui-agent/s12-tmp'
node=str(B/'tools/node-v24.22.3-linux-x64/bin/node')
try:
 status['sourceBefore']=guard();write()
 with (OUT/'format.log').open('wb') as log:
  run=subprocess.run([node,str(E/'format-r6-02.mjs')],cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
 status['formatExit']=run.returncode;write()
 assert run.returncode==0,'format failure; original evidence retained'
 status['candidate']=guard();write()
 cmd=[node,'node_modules/vitest/vitest.mjs','run','packages/cli/test/hook-source-setup-capability.test.ts','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile.json='+str(OUT/'controls.json')]
 status['command']=cmd;status['state']='running';write()
 with (OUT/'controls.log').open('wb') as log:
  run=subprocess.run(cmd,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 status['exit']=run.returncode;status['sourceAfter']=guard();status['sourceStable']=status['candidate']==status['sourceAfter'];status['waitedChildMaxRssKiB']=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
 if (OUT/'controls.json').is_file():
  r=json.loads((OUT/'controls.json').read_text());status['counts']={k:r.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTotalTestSuites','numPassedTestSuites']}
 status['state']='completed';status['finished']=time.time();write()
except BaseException:
 status['state']='failed';status['error']=traceback.format_exc();status['finished']=time.time();write();raise
