import { definePrototype } from '@proto.ui/core';
import { useFacts as alpha } from './alpha';
import { useFacts as beta } from './beta';
import { paint } from './visual';
const proto = definePrototype({ name: 'two', setup(def) {
  paint(def, alpha().stateHandles);
  paint(def, beta().stateHandles);
} });
proto.setup(foreign);