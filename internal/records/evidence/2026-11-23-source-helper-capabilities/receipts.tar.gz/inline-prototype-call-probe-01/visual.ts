import { tw } from '@proto.ui/core';
export function paint(def, state) {
  def.rule({ when: w => w.state(state.ready).eq(true),
    intent: i => i.feedback.style.use(tw('bg-primary')) });
}