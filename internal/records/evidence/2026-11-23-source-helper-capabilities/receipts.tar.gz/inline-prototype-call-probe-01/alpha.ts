import { defineAsHook } from '@proto.ui/core';
export const useFacts = defineAsHook({
  name: 'alpha',
  setup(def) {
    const ready = def.state.bool('ready', false);
    def.expose.state('ready', ready);
  },
});