import { mkdir, writeFile, readFile } from 'node:fs/promises';
import path from 'node:path';
import { scanRuleStateReads, scanRuleStateReadsFromSources } from '/tank/shared/projects/proto-ui-agent/sprint12-evidence/lowered-helper-recovery-20261123/lowered-debug-r5.mts';
const E='/tank/shared/projects/proto-ui-agent/sprint12-evidence/lowered-helper-recovery-20261123';
const folder=path.join(E,'two-owner-debug-09');
await mkdir(folder,{recursive:true});
const producer=(name:string)=>[
"import { defineAsHook } from '@proto.ui/core';",
"export const useFacts = defineAsHook({",
"  name: '"+name+"',",
"  setup(def) {",
"    const ready = def.state.bool('ready', false);",
"    def.expose.state('ready', ready);",
"  },",
"});",
].join('\n');
const files={
'alpha.ts':producer('alpha'),
'beta.ts':producer('beta'),
'visual.ts':[
"import { tw } from '@proto.ui/core';",
"export function paint(def, state) {",
"  def.rule({ when: w => w.state(state.ready).eq(true),",
"    intent: i => i.feedback.style.use(tw('bg-primary')) });",
"}",
].join('\n'),
'consumer.proto.ts':[
"import { definePrototype } from '@proto.ui/core';",
"import { useFacts as alpha } from './alpha';",
"import { useFacts as beta } from './beta';",
"import { paint } from './visual';",
"export default definePrototype({ name: 'two', setup(def) {",
"  paint(def, alpha().stateHandles);",
"  paint(def, beta().stateHandles);",
"} });",
].join('\n')};
await writeFile(path.join(folder,'tsconfig.json'),JSON.stringify({extends:'/tank/shared/projects/proto-ui-agent/continuation-s12-passive-4deb/tsconfig.json'}));
const inputs=[];
for(const [name,sourceText] of Object.entries(files)){
const fileName=path.join(folder,name);await writeFile(fileName,sourceText);inputs.push({fileName,sourceText});}
const result=scanRuleStateReadsFromSources(inputs);
const encode=(scan:any)=>({...scan,usages:scan.usages.map(({hook,state,provenance}:any)=>({hook,state,provenance}))});
await writeFile(path.join(folder,'observations.json'),JSON.stringify({...result,observations:result.observations.map(o=>({...o,scan:encode(o.scan)}))},null,2));
const direct=files['consumer.proto.ts'].replace('paint(def, alpha().stateHandles);',"def.rule({when:w=>w.state(alpha().stateHandles.ready).eq(true),intent:i=>i.feedback.style.use(tw('bg-primary'))});").replace('paint(def, beta().stateHandles);',"def.rule({when:w=>w.state(beta().stateHandles.ready).eq(true),intent:i=>i.feedback.style.use(tw('bg-primary'))});");
await writeFile(path.join(folder,'direct-source.txt'),direct);
await writeFile(path.join(folder,'direct.json'),JSON.stringify(encode(scanRuleStateReads(direct,path.join(folder,'consumer.proto.ts'))),null,2));
console.log(JSON.stringify({state:'complete',directory:folder}));
