// Direct checked-source GPUI component. Supporting files are ordinary editable Rust.
  #[cfg(panic = "abort")] compile_error!("Authored exception lowering requires panic=unwind");
  pub use proto_ui_gpui_native as native;
  pub use native::gpui_native_owner::{ControlLabelRef, InstanceAssociations};
  use gpui::{prelude::*, App, Context, FocusHandle, Subscription, Window};
  use std::rc::Rc;
  use serde_json::Value as Json;
  use native::gpui_native_owner::*;
  
  
  fn style_vocabulary() -> &'static native::gpui_native_style::StyleVocabulary {
      static VOCABULARY: std::sync::OnceLock<native::gpui_native_style::StyleVocabulary> = std::sync::OnceLock::new();
      VOCABULARY.get_or_init(|| native::gpui_native_style::StyleVocabulary::from_json(include_str!(".proto-ui/fixtures/style-tokens.json")).expect("compiler-produced style vocabulary"))
  }
  fn accepts_context(key: &str, value: &Json) -> bool {
      match key {
          
          _ => false,
      }
  }
  fn accepts_props(value: &Json) -> bool { value.is_object() && value.get("value").map_or(true, |prop| prop.is_null() || prop.as_f64().is_some_and(f64::is_finite)) && value.get("notificationPhase").map_or(true, |prop| prop.is_null() || prop.is_string()) && value.get("notificationRevision").map_or(true, |prop| prop.is_null() || prop.as_f64().is_some_and(f64::is_finite)) }
  fn prop_valid(key: &str, value: &Json) -> bool { match key { "value" => value.as_f64().is_some_and(f64::is_finite),
        "notificationPhase" => value.is_string(),
        "notificationRevision" => value.as_f64().is_some_and(f64::is_finite), _ => false } }
  fn check_method(name: &str, arguments: &[Value]) { match name {
          "emitOnly" => if !(arguments.len() <= 1 && arguments.get(0).map_or(false, |value| (value).try_data().is_some_and(|data| data.as_f64().is_some_and(f64::is_finite)))) { value_type_error("invalid exposed method arguments") },
        "emitThenThrow" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "scrollTo" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "scrollToKind" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "scrollBy" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "scrollPage" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "scrollDrag" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "scrollEnd" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "scrollAxesHorizontal" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "scrollAxesVertical" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "scrollWrongAxis" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "scrollEndWrongAxis" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "attempt" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "invalid" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "read" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "valid" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
          _ => value_error("unknown exposed method"),
  } }
  
  #[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData0 {
    #[serde(rename = "value", default, skip_serializing_if = "Option::is_none")]
    pub field_0: Option<f64>,
    #[serde(rename = "notificationPhase", default, skip_serializing_if = "Option::is_none")]
    pub field_1: Option<String>,
    #[serde(rename = "notificationRevision", default, skip_serializing_if = "Option::is_none")]
    pub field_2: Option<f64>,
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData2 {
    #[serde(rename = "kind")]
    pub field_0: String,
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData3 {
    #[serde(rename = "kind")]
    pub field_0: String,
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
#[serde(untagged)]
pub enum GeneratedData5 {
    Alternative0(String),
    Alternative1(String),
    Alternative2(String),
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData4 {
    #[serde(rename = "kind")]
    pub field_0: String,
    #[serde(rename = "reason")]
    pub field_1: GeneratedData5,
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
#[serde(untagged)]
pub enum GeneratedData1 {
    Alternative0(GeneratedData2),
    Alternative1(GeneratedData3),
    Alternative2(GeneratedData4),
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
#[serde(untagged)]
pub enum GeneratedData6 {
    Alternative0(String),
    Alternative1(String),
    Alternative2(String),
}
  
  pub type GeneratedProps = GeneratedData0;
  
  #[derive(Clone)]
  pub struct CompiledComponentHandle { pub owner: OwnerRef }
  impl CompiledComponentHandle {
      pub fn method_1(&self, argument_0: f64, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![Value::json(serde_json::to_value(argument_0).expect("portable argument"))];
        let callback = self.owner.borrow().exposes.get("emitOnly").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("emitOnly", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_2(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("emitThenThrow").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("emitThenThrow", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_3(&self, window: &mut Window, cx: &mut App) -> Result<GeneratedData1, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("scrollTo").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("scrollTo", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(((result.is_object() && result.get("kind").map_or(false, |field| field.as_str() == Some("dispatched"))) || (result.is_object() && result.get("kind").map_or(false, |field| field.as_str() == Some("queued"))) || (result.is_object() && result.get("kind").map_or(false, |field| field.as_str() == Some("rejected")) && result.get("reason").map_or(false, |field| (field.as_str() == Some("not-mounted") || field.as_str() == Some("not-declared") || field.as_str() == Some("unavailable")))))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_4(&self, window: &mut Window, cx: &mut App) -> Result<GeneratedData6, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("scrollToKind").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("scrollToKind", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !((result.as_str() == Some("dispatched") || result.as_str() == Some("queued") || result.as_str() == Some("rejected"))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_5(&self, window: &mut Window, cx: &mut App) -> Result<GeneratedData6, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("scrollBy").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("scrollBy", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !((result.as_str() == Some("dispatched") || result.as_str() == Some("queued") || result.as_str() == Some("rejected"))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_6(&self, window: &mut Window, cx: &mut App) -> Result<GeneratedData6, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("scrollPage").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("scrollPage", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !((result.as_str() == Some("dispatched") || result.as_str() == Some("queued") || result.as_str() == Some("rejected"))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_7(&self, window: &mut Window, cx: &mut App) -> Result<GeneratedData6, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("scrollDrag").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("scrollDrag", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !((result.as_str() == Some("dispatched") || result.as_str() == Some("queued") || result.as_str() == Some("rejected"))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_8(&self, window: &mut Window, cx: &mut App) -> Result<GeneratedData6, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("scrollEnd").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("scrollEnd", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !((result.as_str() == Some("dispatched") || result.as_str() == Some("queued") || result.as_str() == Some("rejected"))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_9(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("scrollAxesHorizontal").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("scrollAxesHorizontal", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_10(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("scrollAxesVertical").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("scrollAxesVertical", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_11(&self, window: &mut Window, cx: &mut App) -> Result<GeneratedData1, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("scrollWrongAxis").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("scrollWrongAxis", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(((result.is_object() && result.get("kind").map_or(false, |field| field.as_str() == Some("dispatched"))) || (result.is_object() && result.get("kind").map_or(false, |field| field.as_str() == Some("queued"))) || (result.is_object() && result.get("kind").map_or(false, |field| field.as_str() == Some("rejected")) && result.get("reason").map_or(false, |field| (field.as_str() == Some("not-mounted") || field.as_str() == Some("not-declared") || field.as_str() == Some("unavailable")))))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_12(&self, window: &mut Window, cx: &mut App) -> Result<GeneratedData1, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("scrollEndWrongAxis").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("scrollEndWrongAxis", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(((result.is_object() && result.get("kind").map_or(false, |field| field.as_str() == Some("dispatched"))) || (result.is_object() && result.get("kind").map_or(false, |field| field.as_str() == Some("queued"))) || (result.is_object() && result.get("kind").map_or(false, |field| field.as_str() == Some("rejected")) && result.get("reason").map_or(false, |field| (field.as_str() == Some("not-mounted") || field.as_str() == Some("not-declared") || field.as_str() == Some("unavailable")))))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_13(&self, window: &mut Window, cx: &mut App) -> Result<bool, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("attempt").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("attempt", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_boolean()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_14(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("invalid").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("invalid", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_15(&self, window: &mut Window, cx: &mut App) -> Result<f64, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("read").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("read", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.as_f64().is_some_and(f64::is_finite)) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_16(&self, window: &mut Window, cx: &mut App) -> Result<f64, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("valid").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("valid", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.as_f64().is_some_and(f64::is_finite)) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
      pub fn owner(&self) -> OwnerWeak { Rc::downgrade(&self.owner) }
      pub fn state(&self, name: &str) -> Result<Json, Value> { catch_authored(|| { let state=self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed State")); state.get().data() }) }
      pub fn call(&self, name: &str, arguments: Vec<Json>, window: &mut Window, cx: &mut App) -> Result<Json, Value> {
          let outcome = catch_authored(|| {
          refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
          let callback = self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed method"));
          let arguments: Vec<Value> = arguments.into_iter().map(Value::json).collect(); check_method(name, &arguments);
          let result = invoke(&self.owner, "expose-method", &callback, arguments);
          let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
          if matches!(result, Value::Undefined) { Json::Null } else { result.data() }
          });
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome
      }
      pub fn host_target(&self) -> Result<Value, Value> { catch_authored(|| { ensure(&self.owner()); Value::HostTarget(self.owner()) }) }
      pub fn take_events(&self) -> Vec<(String, Json)> { std::mem::take(&mut self.owner.borrow_mut().emitted) }
      pub fn take_failures(&self) -> Vec<NativeFailure> { take_native_failures(&self.owner) }
      pub fn dispose(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
          catch_authored(|| {
          let drive = self.owner.borrow().native_drive.clone();
          let failure = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| Owner::dispose(&self.owner)));
          let driven = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| { if let Some(drive) = drive { drive(window, cx); } }));
          if let Err(failure) = failure { std::panic::resume_unwind(failure); }
          if let Err(failure) = driven { std::panic::resume_unwind(failure); }
          })
      }
  }
  pub struct CompiledComponent { pub owner: OwnerRef, focus: FocusHandle, window_input: Option<FocusHandle>, _focus_subscriptions: Vec<Subscription>, _window_activation: Option<(gpui::WindowId, Subscription)>, _focus_lost: Option<Subscription>, _global_key_capture: Option<Subscription>, _entry_readiness: Option<(gpui::WindowId, Subscription)> }
  impl CompiledComponent {
      pub fn create_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> { Self::create(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn create(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          Self::create_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn create_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          let mut failure = None;
          let entity = cx.new(|cx| Self::new_with_associations(raw_props, parent, associations, window, cx).unwrap_or_else(|error| {
              failure = Some(error);
              // A failed construction still returns normally through GPUI's
              // entity insertion. This inert temporary is dropped immediately
              // below; it is never published or mounted as a native component.
              let owner = Owner::new(Json::Object(Default::default()), Default::default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
              { let mut owner = owner.borrow_mut(); owner.disposed = true; owner.present = false; }
              Self { owner, focus: cx.focus_handle(), window_input: None, _focus_subscriptions: Vec::new(), _window_activation: None, _focus_lost: None, _global_key_capture: None, _entry_readiness: None }
          }));
          match failure { Some(error) => Err(error), None => Ok(entity) }
      }
      pub fn new_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> { Self::new(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn new(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          Self::new_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn new_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          catch_authored(|| {
          let owner_ref = Owner::new(raw_props, parent.unwrap_or_default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
          initialize_instance_associations(&owner_ref, associations);
          let owner = Rc::downgrade(&owner_ref);
          let focus = cx.focus_handle();
          let view = cx.entity().downgrade();
          let drive_owner=owner.clone(); let drive_focus=focus.clone();
          let driving = Rc::new(std::cell::Cell::new(false));
          let drive_pending = Rc::new(std::cell::Cell::new(false));
          let drive: Drive = Rc::new(move |window, cx| {
              // Platform effects need owner storage and its real FocusHandle,
              // not another lease of the generated component. Preserve their
              // synchronous effect (notably physical focus) under public calls.
              if !driving.replace(true) {
                  if let Some(owner)=drive_owner.upgrade() {
                      native_host_callback(&owner, "drive", || { modules_drive(&owner, &drive_focus, window, cx); drive_queued_focus(&owner, window, cx); });
                  }
                  driving.set(false);
              }
              if drive_pending.replace(true) { return; }
              let view=view.clone(); let pending=drive_pending.clone();
              // A public handle can be called from Entity::update. Return the
              // current host lease before requesting another component update.
              // Authored calls, State writes and platform commands remain
              // synchronous; component refresh is coalesced at the host boundary.
              window.defer(cx, move |window, cx| {
                  pending.set(false);
                  let _ = view.update(cx, |view, cx| { if let Err(error) = view.drive(window, cx) { report_native_failure(&view.owner, "drive", error); } });
              });
          });
          { let mut owner = owner_ref.borrow_mut(); owner.native_drive = Some(drive); owner.window_id = Some(window.window_handle().window_id()); }
  
          configure_native_atoms(&owner_ref, false, false);
          refresh_native_atoms(&owner_ref, window, cx);
          let _lexical_owner = enter_lexical_owner(&owner);
          let renderer = { let owner = owner.clone();  Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_646566: Value = arg(&arguments, 0);
            let v_63757272656e74: LexicalBinding<Rc<std::cell::RefCell<Value>>> = lexical_binding();
            let v_7363726f6c6c: LexicalBinding<Value> = lexical_binding();
            let v_76616c75655f5f64613964646266396165373936653835: LexicalBinding<Value> = lexical_binding();
            // Source "validation.proto.ts":9:5
            { let v_7075695f6e61746976655f30 = v_646566.clone(); props_define(&owner, record(vec![("value", record(vec![("type", Value::string("number")), ("default", Value::number(0.0_f64))])), ("notificationPhase", record(vec![("type", Value::string("string")), ("default", Value::string("none"))])), ("notificationRevision", record(vec![("type", Value::string("number")), ("default", Value::number(0.0_f64))]))])) };
            // Source "validation.proto.ts":14:9
            v_63757272656e74.initialize(Rc::new(std::cell::RefCell::new(Value::Json(Json::Null))));
            // Source "validation.proto.ts":15:5
            { let v_7075695f6e61746976655f31 = v_646566.clone(); register_life(&owner, "created", {  let v_63757272656e74 = v_63757272656e74.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f65333163663461626439616638303132: Value = arg(&arguments, 0);
                // Source "validation.proto.ts":15:40
                { let value = v_72756e5f5f65333163663461626439616638303132.clone(); *(v_63757272656e74.read()).borrow_mut() = value; }
                Value::Undefined
            })) }) };
            // Source "validation.proto.ts":16:5
            { let v_7075695f6e61746976655f32 = v_646566.clone(); expose_event(&owner, Value::string("renderRequest")) };
            // Source "validation.proto.ts":17:5
            { let v_7075695f6e61746976655f33 = v_646566.clone(); watch_props(&owner, Some(Value::Array(Rc::new(vec![Value::string("notificationRevision")]))), false, {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f34353037313836333638623932326462: Value = arg(&arguments, 0);
                // Source "validation.proto.ts":17:58
                { let v_7075695f6e61746976655f34 = v_72756e5f5f34353037313836333638623932326462.clone(); request_update(&(v_7075695f6e61746976655f34.clone()).owner()) };
                Value::Undefined
            })) }) };
            // Source "validation.proto.ts":18:5
            { let v_7075695f6e61746976655f35 = v_646566.clone(); register_life(&owner, "mounted", {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f37323765313333303430303361393338: Value = arg(&arguments, 0);
                // Source "validation.proto.ts":19:7
                if (Value::boolean(!strict_equal(&(({ let v_7075695f6e61746976655f38 = v_72756e5f5f37323765313333303430303361393338.clone(); read_props(&(v_7075695f6e61746976655f38.clone()).owner(), false) }).member("notificationPhase", false)), &(Value::string("mounted"))))).bool() {
                    // Source "validation.proto.ts":19:60
                    return Value::Undefined;
                }
                // Source "validation.proto.ts":20:7
                { let v_7075695f6e61746976655f39 = v_72756e5f5f37323765313333303430303361393338.clone(); emit(&(v_7075695f6e61746976655f39.clone()).owner(), Value::string("renderRequest"), record(vec![("phase", Value::string("mounted"))])) };
                // Source "validation.proto.ts":21:7
                throw_value(Value::boolean(false));
            })) }) };
            // Source "validation.proto.ts":23:5
            { let v_7075695f6e61746976655f3130 = v_646566.clone(); register_life(&owner, "mounted", {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f32393631373965623465333465613165: Value = arg(&arguments, 0);
                // Source "validation.proto.ts":24:7
                if (Value::boolean(strict_equal(&(({ let v_7075695f6e61746976655f3133 = v_72756e5f5f32393631373965623465333465613165.clone(); read_props(&(v_7075695f6e61746976655f3133.clone()).owner(), false) }).member("notificationPhase", false)), &(Value::string("mounted"))))).bool() {
                    // Source "validation.proto.ts":25:9
                    { let v_7075695f6e61746976655f3134 = v_72756e5f5f32393631373965623465333465613165.clone(); emit(&(v_7075695f6e61746976655f3134.clone()).owner(), Value::string("renderRequest"), record(vec![("phase", Value::string("after-failed-mounted"))])) };
                }
                Value::Undefined
            })) }) };
            // Source "validation.proto.ts":28:5
            { let v_7075695f6e61746976655f3135 = v_646566.clone(); register_life(&owner, "updated", {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f61306238363631643533656463306234: Value = arg(&arguments, 0);
                // Source "validation.proto.ts":29:7
                if (Value::boolean(!strict_equal(&(({ let v_7075695f6e61746976655f3138 = v_72756e5f5f61306238363631643533656463306234.clone(); read_props(&(v_7075695f6e61746976655f3138.clone()).owner(), false) }).member("notificationPhase", false)), &(Value::string("updated"))))).bool() {
                    // Source "validation.proto.ts":29:60
                    return Value::Undefined;
                }
                // Source "validation.proto.ts":30:7
                { let v_7075695f6e61746976655f3139 = v_72756e5f5f61306238363631643533656463306234.clone(); emit(&(v_7075695f6e61746976655f3139.clone()).owner(), Value::string("renderRequest"), record(vec![("phase", Value::string("updated"))])) };
                // Source "validation.proto.ts":31:7
                throw_value(Value::boolean(false));
            })) }) };
            // Source "validation.proto.ts":33:5
            { let v_7075695f6e61746976655f3230 = v_646566.clone(); register_life(&owner, "updated", {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f66626239356535303037343537613765: Value = arg(&arguments, 0);
                // Source "validation.proto.ts":34:7
                if (Value::boolean(strict_equal(&(({ let v_7075695f6e61746976655f3233 = v_72756e5f5f66626239356535303037343537613765.clone(); read_props(&(v_7075695f6e61746976655f3233.clone()).owner(), false) }).member("notificationPhase", false)), &(Value::string("updated"))))).bool() {
                    // Source "validation.proto.ts":35:9
                    { let v_7075695f6e61746976655f3234 = v_72756e5f5f66626239356535303037343537613765.clone(); emit(&(v_7075695f6e61746976655f3234.clone()).owner(), Value::string("renderRequest"), record(vec![("phase", Value::string("after-failed-updated"))])) };
                }
                Value::Undefined
            })) }) };
            // Source "validation.proto.ts":38:5
            { let v_7075695f6e61746976655f3235 = v_646566.clone(); expose_method(&owner, Value::string("emitOnly"), ({  let v_63757272656e74 = v_63757272656e74.clone(); let call:Rc<dyn Fn(f64)->Value>=Rc::new(move |argument_0: f64| -> Value {
                let v_76616c75655f5f31643837336337343833303534386465: f64 = argument_0;
                // Source "validation.proto.ts":39:7
                if ({ let value = (v_63757272656e74.read()).borrow().clone(); value }).truthy() {
                    // Source "validation.proto.ts":39:20
                    { let v_7075695f6e61746976655f3236 = { let value = (v_63757272656e74.read()).borrow().clone(); value }; emit(&(v_7075695f6e61746976655f3236.clone()).owner(), Value::string("renderRequest"), record(vec![("value", Value::number(v_76616c75655f5f31643837336337343833303534386465.clone()))])) };
                }
                Value::Undefined
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).num())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")) };
            // Source "validation.proto.ts":41:5
            { let v_7075695f6e61746976655f3237 = v_646566.clone(); watch_props(&owner, Some(Value::Array(Rc::new(vec![Value::string("value")]))), false, {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f62346631326635363734343466383964: Value = arg(&arguments, 0);
                let v_6e657874: Value = arg(&arguments, 1);
                // Source "validation.proto.ts":42:7
                { let v_7075695f6e61746976655f3238 = v_72756e5f5f62346631326635363734343466383964.clone(); emit(&(v_7075695f6e61746976655f3238.clone()).owner(), Value::string("renderRequest"), record(vec![("value", Value::number(((v_6e657874.clone()).member("value", false)).num()))])) };
                // Source "validation.proto.ts":43:7
                if { let pui_native_29=((v_6e657874.clone()).member("value", false)).num(); let pui_native_30=13.0_f64; (pui_native_29==pui_native_30) } {
                    // Source "validation.proto.ts":43:30
                    throw_value(Value::boolean(false));
                }
                Value::Undefined
            })) }) };
            // Source "validation.proto.ts":45:5
            { let v_7075695f6e61746976655f3331 = v_646566.clone(); expose_method(&owner, Value::string("emitThenThrow"), {  let v_63757272656e74 = v_63757272656e74.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "validation.proto.ts":46:7
                if ({ let value = (v_63757272656e74.read()).borrow().clone(); value }).truthy() {
                    // Source "validation.proto.ts":46:20
                    { let v_7075695f6e61746976655f3332 = { let value = (v_63757272656e74.read()).borrow().clone(); value }; emit(&(v_7075695f6e61746976655f3332.clone()).owner(), Value::string("renderRequest"), record(vec![("value", Value::number(21.0_f64))])) };
                }
                // Source "validation.proto.ts":47:7
                throw_value(Value::number(0.0_f64));
            })) }) };
            // Source "validation.proto.ts":49:11
            v_7363726f6c6c.initialize(native_builtin_hook(&owner, "asScrollSurface", || scroll_setup(&owner)));
            // Source "validation.proto.ts":50:5
            { let v_7075695f6e61746976655f3333 = v_7363726f6c6c.read(); scroll_configure(&(v_7075695f6e61746976655f3333.clone()).owner(), record(vec![("axes", Value::string("vertical")), ("endFollow", record(vec![("mode", Value::string("while-at-end")), ("axis", Value::string("vertical"))]))])) };
            // Source "validation.proto.ts":51:5
            { let v_7075695f6e61746976655f3334 = v_646566.clone(); expose_method(&owner, Value::string("scrollTo"), {  let v_7363726f6c6c = v_7363726f6c6c.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "validation.proto.ts":52:7
                return { let v_7075695f6e61746976655f3335 = v_7363726f6c6c.read(); scroll_request(&(v_7075695f6e61746976655f3335.clone()).owner(), record(vec![("kind", Value::string("to")), ("axis", Value::string("vertical")), ("position", Value::number(0.5_f64))])) };
            })) }) };
            // Source "validation.proto.ts":54:5
            { let v_7075695f6e61746976655f3336 = v_646566.clone(); expose_method(&owner, Value::string("scrollToKind"), {  let v_7363726f6c6c = v_7363726f6c6c.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "validation.proto.ts":56:13
                return ({ let v_7075695f6e61746976655f3337 = v_7363726f6c6c.read(); scroll_request(&(v_7075695f6e61746976655f3337.clone()).owner(), record(vec![("kind", Value::string("to")), ("axis", Value::string("vertical")), ("position", Value::number(0.5_f64))])) }).member("kind", false);
            })) }) };
            // Source "validation.proto.ts":58:5
            { let v_7075695f6e61746976655f3338 = v_646566.clone(); expose_method(&owner, Value::string("scrollBy"), {  let v_7363726f6c6c = v_7363726f6c6c.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "validation.proto.ts":60:13
                return ({ let v_7075695f6e61746976655f3339 = v_7363726f6c6c.read(); scroll_request(&(v_7075695f6e61746976655f3339.clone()).owner(), record(vec![("kind", Value::string("by")), ("axis", Value::string("vertical")), ("delta", Value::number(10.0_f64))])) }).member("kind", false);
            })) }) };
            // Source "validation.proto.ts":62:5
            { let v_7075695f6e61746976655f3430 = v_646566.clone(); expose_method(&owner, Value::string("scrollPage"), {  let v_7363726f6c6c = v_7363726f6c6c.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "validation.proto.ts":64:13
                return ({ let v_7075695f6e61746976655f3431 = v_7363726f6c6c.read(); scroll_request(&(v_7075695f6e61746976655f3431.clone()).owner(), record(vec![("kind", Value::string("page")), ("axis", Value::string("vertical")), ("direction", Value::string("after"))])) }).member("kind", false);
            })) }) };
            // Source "validation.proto.ts":66:5
            { let v_7075695f6e61746976655f3432 = v_646566.clone(); expose_method(&owner, Value::string("scrollDrag"), {  let v_7363726f6c6c = v_7363726f6c6c.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "validation.proto.ts":68:13
                return ({ let v_7075695f6e61746976655f3433 = v_7363726f6c6c.read(); scroll_request(&(v_7075695f6e61746976655f3433.clone()).owner(), record(vec![("kind", Value::string("control-drag")), ("axis", Value::string("vertical")), ("position", Value::number(0.25_f64))])) }).member("kind", false);
            })) }) };
            // Source "validation.proto.ts":70:5
            { let v_7075695f6e61746976655f3434 = v_646566.clone(); expose_method(&owner, Value::string("scrollEnd"), {  let v_7363726f6c6c = v_7363726f6c6c.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "validation.proto.ts":70:42
                return ({ let v_7075695f6e61746976655f3435 = v_7363726f6c6c.read(); scroll_request(&(v_7075695f6e61746976655f3435.clone()).owner(), record(vec![("kind", Value::string("to-end")), ("axis", Value::string("vertical"))])) }).member("kind", false);
            })) }) };
            // Source "validation.proto.ts":71:5
            { let v_7075695f6e61746976655f3436 = v_646566.clone(); expose_method(&owner, Value::string("scrollAxesHorizontal"), {  let v_7363726f6c6c = v_7363726f6c6c.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "validation.proto.ts":71:53
                return { let v_7075695f6e61746976655f3437 = v_7363726f6c6c.read(); scroll_sync(&(v_7075695f6e61746976655f3437.clone()).owner(), record(vec![("axes", Value::string("horizontal"))])) };
            })) }) };
            // Source "validation.proto.ts":72:5
            { let v_7075695f6e61746976655f3438 = v_646566.clone(); expose_method(&owner, Value::string("scrollAxesVertical"), {  let v_7363726f6c6c = v_7363726f6c6c.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "validation.proto.ts":72:51
                return { let v_7075695f6e61746976655f3439 = v_7363726f6c6c.read(); scroll_sync(&(v_7075695f6e61746976655f3439.clone()).owner(), record(vec![("axes", Value::string("vertical"))])) };
            })) }) };
            // Source "validation.proto.ts":73:5
            { let v_7075695f6e61746976655f3530 = v_646566.clone(); expose_method(&owner, Value::string("scrollWrongAxis"), {  let v_7363726f6c6c = v_7363726f6c6c.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "validation.proto.ts":74:7
                return { let v_7075695f6e61746976655f3531 = v_7363726f6c6c.read(); scroll_request(&(v_7075695f6e61746976655f3531.clone()).owner(), record(vec![("kind", Value::string("to")), ("axis", Value::string("horizontal")), ("position", Value::number(0.5_f64))])) };
            })) }) };
            // Source "validation.proto.ts":76:5
            { let v_7075695f6e61746976655f3532 = v_646566.clone(); expose_method(&owner, Value::string("scrollEndWrongAxis"), {  let v_7363726f6c6c = v_7363726f6c6c.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "validation.proto.ts":77:7
                return { let v_7075695f6e61746976655f3533 = v_7363726f6c6c.read(); scroll_request(&(v_7075695f6e61746976655f3533.clone()).owner(), record(vec![("kind", Value::string("to-end")), ("axis", Value::string("horizontal"))])) };
            })) }) };
            // Source "validation.proto.ts":79:11
            v_76616c75655f5f64613964646266396165373936653835.initialize({ let v_7075695f6e61746976655f3534 = v_646566.clone(); create_state(&owner, "range", Value::string("value"), Value::number(0.0_f64), record(vec![("min", Value::number(0.0_f64)), ("max", Value::number(1.0_f64))])) });
            // Source "validation.proto.ts":80:5
            { let v_7075695f6e61746976655f3535 = v_646566.clone(); expose_method(&owner, Value::string("attempt"), ({  let v_76616c75655f5f64613964646266396165373936653835 = v_76616c75655f5f64613964646266396165373936653835.clone(); let call:Rc<dyn Fn()->bool>=Rc::new(move || -> bool {
                // Source "validation.proto.ts":81:7
                match match catch_authored::<std::ops::ControlFlow<bool>>(|| {
                        // Source "validation.proto.ts":82:9
                        { let v_7075695f6e61746976655f3536 = v_76616c75655f5f64613964646266396165373936653835.read(); state_set(v_7075695f6e61746976655f3536.clone(), Value::number(2.0_f64), Value::Undefined) };
                        // Source "validation.proto.ts":83:9
                        return std::ops::ControlFlow::Break(false);
                    }) {
                        Ok(flow) => flow,
                        Err(_) => (|| -> std::ops::ControlFlow<bool> {
                            // Source "validation.proto.ts":85:9
                            return std::ops::ControlFlow::Break(true);
                        })()
                    } {
                    std::ops::ControlFlow::Break(value) => return value,
                    std::ops::ControlFlow::Continue(()) => {}
                }
                unreachable!("checked scalar function did not return")
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")) };
            // Source "validation.proto.ts":88:5
            { let v_7075695f6e61746976655f3537 = v_646566.clone(); expose_method(&owner, Value::string("invalid"), {  let v_76616c75655f5f64613964646266396165373936653835 = v_76616c75655f5f64613964646266396165373936653835.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "validation.proto.ts":88:40
                return { let v_7075695f6e61746976655f3538 = v_76616c75655f5f64613964646266396165373936653835.read(); state_set(v_7075695f6e61746976655f3538.clone(), Value::number(2.0_f64), Value::Undefined) };
            })) }) };
            // Source "validation.proto.ts":89:5
            { let v_7075695f6e61746976655f3539 = v_646566.clone(); expose_method(&owner, Value::string("read"), ({  let v_76616c75655f5f64613964646266396165373936653835 = v_76616c75655f5f64613964646266396165373936653835.clone(); let call:Rc<dyn Fn()->f64>=Rc::new(move || -> f64 {
                // Source "validation.proto.ts":89:37
                return ({ let v_7075695f6e61746976655f3630 = v_76616c75655f5f64613964646266396165373936653835.read(); Value::number(((v_7075695f6e61746976655f3630.clone()).get()).num()) }).num();
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")) };
            // Source "validation.proto.ts":90:5
            { let v_7075695f6e61746976655f3631 = v_646566.clone(); expose_method(&owner, Value::string("valid"), ({  let v_76616c75655f5f64613964646266396165373936653835 = v_76616c75655f5f64613964646266396165373936653835.clone(); let call:Rc<dyn Fn()->f64>=Rc::new(move || -> f64 {
                // Source "validation.proto.ts":91:7
                { let v_7075695f6e61746976655f3632 = v_76616c75655f5f64613964646266396165373936653835.read(); state_set(v_7075695f6e61746976655f3632.clone(), Value::number(1.0_f64), Value::Undefined) };
                // Source "validation.proto.ts":92:7
                return ({ let v_7075695f6e61746976655f3633 = v_76616c75655f5f64613964646266396165373936653835.read(); Value::number(((v_7075695f6e61746976655f3633.clone()).get()).num()) }).num();
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")) };
            // Source "validation.proto.ts":94:5
            return { let callable={ let pui_native_64={   let call:Rc<dyn Fn(Value)->native::gpui_native_owner::NativeSnapshot>=Rc::new(move |argument_0: Value| -> native::gpui_native_owner::NativeSnapshot {
                let v_72: Value = argument_0;
                // Source "validation.proto.ts":94:19
                return { let v_7075695f6e61746976655f3635 = v_72.clone(); { let pui_native_66 = Value::string("div"); let _ = pui_native_66; let pui_native_67 = Value::Undefined; let pui_native_68 = { let pui_native_70 = Value::Array(Rc::new(vec![])); native::gpui_native_owner::NativeSnapshot::sequence(pui_native_70.items().into_iter().map(|pui_native_71| { let pui_native_72 = pui_native_71; { native::gpui_native_owner::NativeSnapshot::invalid(pui_native_72) } }).collect(), Some(pui_native_70)) };
      let pui_native_69 = if pui_native_67.nullish() { Vec::new() } else { let style = pui_native_67.member("style",false); if style.nullish(){Vec::new()}else{style_items(vec![style])} };
      let frame_children = pui_native_68.clone(); let text_children = pui_native_68.clone();
      native::gpui_native_owner::NativeSnapshot { identity:Rc::new(()),observation:None,valid:pui_native_68.valid,slot_count:pui_native_68.slot_count,passive_content:pui_native_68.passive_content,
        frame:Rc::new(move |owner,focus,parent_path,drive,slot,index| {
          let path=format!("{parent_path}-{}",*index);*index+=1;
          let tokens:Vec<String> = pui_native_69.iter().map(|(token,_)|token.clone()).collect();
          let(style,fixed,translation)=native_presentation(owner,&tokens);
          let mut element=gpui::div().id(gpui::ElementId::Name(path.to_owned().into())); *element.style()=style;
          let mut child_index=0;for child in (frame_children.frame)(owner,focus,&path,drive,slot,&mut child_index){element=element.child(child);}
          let element=translated_element(element.into_any_element(),translation,None); vec![if fixed{viewport_root(element)}else{element}]
        }),text:Rc::new(move|slot|(text_children.text)(slot)) }
    } };
            }); native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:None } }; Value::NativeFunction{identity:pui_native_64.identity.clone(),render:Rc::new(move |arguments:Vec<Value>| {(pui_native_64.call)(arg(&arguments,0))})} }; match callable {
      Value::NativeFunction{identity,render} => capture_renderer(Value::NativeFunction{identity,render:render.clone()},render),
      Value::Renderer(adapter) => Value::Renderer(adapter),
      Value::Function(callback) => capture_renderer(Value::Function(callback.clone()),Rc::new(move |arguments:Vec<Value>| { panic!("checked native renderer entry has no scalar callback alternative") })),
      _ => panic!("checked setup result must be a callable")
    } };
        })) }.call_authored(vec![definition_capability(&owner)]);
          Owner::finish(&owner_ref, renderer);
          // Establish the App's default-action snapshot before any authored
          // global key capture can replace focus during the same keystroke.
          register_sequential_focus_owner(&owner_ref, cx);
          let focus_subscriptions = if native_focus_observation_needed(&owner_ref) {
          let focus_owner = owner_ref.clone();
          let on_focus = cx.on_focus(&focus, window, move |view, window, cx| {
              native_host_callback(&focus_owner, "focus", || {
              let epoch = focus_owner.borrow().epoch;
              if !ready(&focus_owner) || focus_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&focus_owner, window);
              native_focus_fact(&focus_owner, view.focus.is_focused(window));
              if !ready(&focus_owner) || focus_owner.borrow().epoch != epoch { return; }
              dispatch(&focus_owner, "host:focus", false, event_fields("host:focus"));
              if ready(&focus_owner) && focus_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          let blur_owner = owner_ref.clone();
          let on_blur = cx.on_blur(&focus, window, move |view, window, cx| {
              native_host_callback(&blur_owner, "blur", || {
              let epoch = blur_owner.borrow().epoch;
              if !ready(&blur_owner) || blur_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&blur_owner, window);
              native_focus_fact(&blur_owner, view.focus.is_focused(window));
              if !ready(&blur_owner) || blur_owner.borrow().epoch != epoch { return; }
              text_blur(&blur_owner, window, cx);
              dispatch(&blur_owner, "host:blur", false, event_fields("host:blur"));
              if ready(&blur_owner) && blur_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          // A native slot descendant can start this root's keyboard press
          // while the root FocusHandle itself is not focused. Its departure
          // from the physical subtree is distinct from the root's own blur.
          let focus_out_owner = Rc::downgrade(&owner_ref);
          let on_focus_out = cx.on_focus_out(&focus, window, move |view, _, window, cx| {
              let Some(owner) = focus_out_owner.upgrade() else { return; };
              native_host_callback(&owner, "focus-out", || {
              let epoch = owner.borrow().epoch;
              if !ready(&owner) || owner.borrow().window_id != Some(window.window_handle().window_id()) || view.focus.contains_focused(window, cx) { return; }
              // This retires only an existing root press lease. Do not forge
              // host:blur or change the root's own Focus observation here.
              native_press_blur(&owner);
              if ready(&owner) && owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          vec![on_focus, on_blur, on_focus_out]
          } else { Vec::new() };
          let global_key_capture = subscribe_global_key_capture(&owner_ref, cx);
          let window_input = window_input_needed(&owner_ref).then(|| cx.focus_handle().tab_stop(false));
          let focus_lost = window_input.as_ref().map(|_| cx.on_focus_lost(window, |view, window, cx| { let owner=view.owner.clone(); native_host_callback(&owner, "focus-lost", || { if view.owner.borrow().window_id == Some(window.window_handle().window_id()) { if let Some(focus) = &view.window_input { restore_window_input(&view.owner, focus, window, cx); } } }); }));
          let mut view = Self { owner: owner_ref, focus, window_input, _focus_subscriptions: focus_subscriptions, _window_activation: None, _focus_lost: focus_lost, _global_key_capture: global_key_capture, _entry_readiness: None };
          view.bind_window_activation(window, cx);
          view
          })
      }
      #[cfg(feature="test-support")]
      pub fn native_resource_counts(&self) -> Json { let mut counts=native::gpui_native_owner::native_resource_counts(&self.owner); counts["nativeSubscriptions"] = Json::from(self._focus_subscriptions.len() + usize::from(self._window_activation.is_some()) + usize::from(self._focus_lost.is_some()) + usize::from(self._global_key_capture.is_some()) + usize::from(self._entry_readiness.is_some())); counts }
      pub fn handle(&self) -> CompiledComponentHandle { CompiledComponentHandle { owner: self.owner.clone() } }
      pub fn set_props(&mut self, raw: Json, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_props(&self.owner, raw));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; self.drive(window, cx)
      }
      pub fn set_instance_associations(&mut self, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_instance_associations(&self.owner, associations));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; drive_owners(window, cx); self.drive(window, cx)
      }
      pub fn set_slot(&mut self, slot: Vec<native::gpui_native_owner::NativeSnapshot>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { ensure(&Rc::downgrade(&self.owner)); assert_native_slot_children(&slot); let mut owner = self.owner.borrow_mut(); owner.slot = slot; owner.dirty = true; cx.notify(); }) }
      pub fn set_parent(&mut self, parent: Option<OwnerWeak>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { if let Err(error)=set_native_parent(&self.owner, parent.unwrap_or_default()){throw_error("NATIVE_PARENT_INVALID", error)} cx.notify(); }) }
      fn bind_window_activation(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !native_focus_observation_needed(&self.owner) && !native::gpui_native_move::move_owner_has_binding(&self.owner) && !control_label_is_label(&self.owner) { self._window_activation.take(); return; }
          let id = window.window_handle().window_id();
          if self._window_activation.as_ref().is_some_and(|(bound, _)| *bound == id) { return; }
          self._window_activation.take();
          let owner = self.owner.clone();
          let subscription = cx.observe_window_activation(window, move |view, window, cx| {
              let deactivated = owner.borrow().window_id == Some(window.window_handle().window_id()) && !window.is_window_active();
              native_host_callback(&owner, "window-activation", || {
                  if deactivated {
                      native_window_blur(&owner);
                      view.drive(window, cx).unwrap_or_else(|error| throw_value(error));
                  }
              });
              if deactivated { notify_native_change(cx); }
          });
          self._window_activation = Some((id, subscription));
      }
      #[cfg(feature = "experimental-focus-tree")]
      fn bind_entry_readiness(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !self.owner.borrow().modules.hooks.contains("focus-entry") { return; }
          let window_id = window.window_handle().window_id();
          if self._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window_id) { return; }
          self._entry_readiness.take();
          let view = cx.entity().downgrade();
          let subscription = window.observe_focus_tree(cx, move |_, window, cx| {
              let _ = view.update(cx, |view, cx| {
                  if view._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window.window_handle().window_id()) { if let Err(error)=view.drive(window, cx){report_native_failure(&view.owner,"entry-readiness",error)} }
              });
          });
          self._entry_readiness = Some((window_id, subscription));
      }
      fn notify_after_turn(&self, cx: &mut Context<Self>) {
          // GPUI suppresses Entity observer effects while a window is drawing,
          // including its focus/blur phase. Keep authored state synchronous,
          // then publish the host change after that physical draw lease ends.
          // A weak target cannot keep a detached component alive for delivery.
          notify_native_change(cx);
      }
      pub fn drive(&mut self, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let result = catch_authored(|| {
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          modules_drive(&self.owner, &self.focus, window, cx);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          drive_queued_focus(&self.owner, window, cx);
          });
          // A callback can publish before failing or retiring its owner. That
          // output is independent from repaint dirtiness and an unread queue.
          let dirty = std::mem::take(&mut self.owner.borrow_mut().dirty);
          if !notify_native_events(&self.owner, cx) && dirty { self.notify_after_turn(cx); }
          result
      }
  }
  impl Drop for CompiledComponent { fn drop(&mut self) { native_host_callback(&self.owner, "drop", || Owner::dispose(&self.owner)); } }
  impl gpui::Focusable for CompiledComponent { fn focus_handle(&self, _: &App) -> FocusHandle { self.focus.clone() } }
  impl Render for CompiledComponent {
      fn render(&mut self, window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
          let report_owner = self.owner.clone();
          native_host_callback(&report_owner, "render", || {
          refresh_native_atoms(&self.owner, window, cx);
          Owner::project(&self.owner);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); return gpui::div().into_any_element(); }
          if !self.owner.borrow().present { self._window_activation.take(); detach_native_view(&self.owner); return gpui::div().into_any_element(); }
          bind_native_focus_window(&self.owner, window);
          self.bind_window_activation(window, cx);
          #[cfg(feature = "experimental-focus-tree")] self.bind_entry_readiness(window, cx);
          let drive = self.owner.borrow().native_drive.as_ref().expect("live native owner drive").clone();
          // Drawing consumes only repaint dirtiness. A parent Render can call
          // an exposed method before this child is laid out: its independent
          // pending_native_events flag survives until the coalesced drive wakes
          // the consumer. Repeated slot projection cannot create a notify loop.
          self.owner.borrow_mut().dirty = false;
          let snapshot = self.owner.borrow().projection.clone().expect("live native projection");
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          let element = paint_native_root(&snapshot, &self.owner, &self.focus, format!("compiled-root-{}", Rc::as_ptr(&self.owner) as usize), drive);
          if let Some(focus) = &self.window_input { window_input_scope(element, focus, &self.owner) } else { element }
          }).unwrap_or_else(|| gpui::div().into_any_element())
      }
  }
  