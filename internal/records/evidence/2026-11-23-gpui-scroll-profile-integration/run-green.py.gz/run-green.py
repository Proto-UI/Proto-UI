import datetime,hashlib,json,os,pathlib,signal,subprocess
root=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-gpui-sync-75d5e28a')
ops=root.with_name(root.name+'-ops');out=ops/'green'
out.mkdir(parents=True,exist_ok=False)
env=dict(os.environ,CI='1',COREPACK_ENABLE_DOWNLOAD_PROMPT='0',ASTRO_TELEMETRY_DISABLED='1',NODE_OPTIONS='--max-old-space-size=4096')
node_bin='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin'
env['PATH']=node_bin+':'+env['PATH']
files=['packages/compiler/src/targets.ts','packages/compiler/test/scroll-axis-sync.test.ts','packages/compiler/test/gpui-event-notification.test.ts','.github/workflows/compiler-browser-acceptance.yml']
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def hashes():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}
def git(*a):return subprocess.check_output(['git',*a],cwd=root,env=env,text=True).strip()
status={'head':git('rev-parse','HEAD'),'state':'running','startedAt':now(),'steps':[]}
def save():(out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def run(name,cmd,timeout,expected=0):
 log=out/(name+'.log');row={'name':name,'command':cmd,'timeoutSeconds':timeout,'expectedExit':expected,'startedAt':now(),'state':'running','log':str(log)};status['steps'].append(row);save()
 with log.open('wb') as f:
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
  try:rc=p.wait(timeout)
  except subprocess.TimeoutExpired:
   row['timedOut']=True
   try:os.killpg(p.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   rc=p.wait(10)
 row.update(exitCode=rc,state='matched-expected-exit' if rc==expected and not row.get('timedOut') else 'unexpected-result',finishedAt=now(),sha256=hashlib.sha256(log.read_bytes()).hexdigest());save()
 assert row['state']=='matched-expected-exit',(name,rc)
try:
 assert status['head']=='d9958d163436ea08d4a19b325d9e7f5dad3dc951'
 assert hashes()[files[0]]=='55fb01193691ec34dbf86180701eacf91d2fbcc6d47a5b89319b47ad452ca8fb'
 assert env.get('HUSKY')!='0'
 run('format-check',['corepack','pnpm@10.32.1','exec','prettier','--check',files[0],files[1],files[3]],120)
 status.update(sourceSha256Before=hashes(),dirtyBefore=git('status','--porcelain'));save()
 run('public-profile-candidate',['corepack','pnpm@10.32.1','exec','vitest','run',files[1],files[2],'packages/compiler/test/gpui-capabilities.test.ts','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile.json='+str(out/'vitest.json')],300,0)
 result=json.loads((out/'vitest.json').read_text());failed=[case for suite in result['testResults'] for case in suite.get('assertionResults',[]) if case['status']=='failed']
 assert len(failed)==0,(len(failed),[c['fullName'] for c in failed])
 assert result['numTotalTests']==32 and result['numPassedTests']==32
 assert result['numPendingTests']==0
 status.update(state='passed',testCounts={k:result[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']},failedCases=[c['fullName'] for c in failed],sourceSha256After=hashes(),headAfter=git('rev-parse','HEAD'),dirtyAfter=git('status','--porcelain'))
 assert status['sourceSha256Before']==status['sourceSha256After']
 assert status['head']==status['headAfter'] and status['dirtyBefore']==status['dirtyAfter']
except Exception as e:status.update(state='failed',error=repr(e))
finally:status['finishedAt']=now();save();print(json.dumps(status,indent=2))
raise SystemExit(0 if status['state']=='passed' else 1)