import datetime,hashlib,json,os,pathlib,signal,subprocess
root=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-gpui-sync-75d5e28a')
ops=root.with_name(root.name+'-ops');out=ops/'producer-green'
out.mkdir(parents=True,exist_ok=False)
env=dict(os.environ,CI='1',COREPACK_ENABLE_DOWNLOAD_PROMPT='0',ASTRO_TELEMETRY_DISABLED='1',NODE_OPTIONS='--max-old-space-size=4096')
node_bin='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin'
env['PATH']=node_bin+':'+env['PATH']
files=['packages/compiler/src/targets.ts','packages/compiler/test/scroll-axis-sync.test.ts','packages/compiler/test/gpui-event-notification.test.ts','.github/workflows/compiler-browser-acceptance.yml']
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def hashes():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}
def git(*a):return subprocess.check_output(['git',*a],cwd=root,env=env,text=True).strip()
status={'head':git('rev-parse','HEAD'),'state':'running','startedAt':now(),'steps':[]}
def save():(out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def run(name,cmd,timeout,expected=0):
 log=out/(name+'.log');row={'name':name,'command':cmd,'timeoutSeconds':timeout,'expectedExit':expected,'startedAt':now(),'state':'running','log':str(log)};status['steps'].append(row);save()
 with log.open('wb') as f:
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
  try:rc=p.wait(timeout)
  except subprocess.TimeoutExpired:
   row['timedOut']=True
   try:os.killpg(p.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   rc=p.wait(10)
 row.update(exitCode=rc,state='matched-expected-exit' if rc==expected and not row.get('timedOut') else 'unexpected-result',finishedAt=now(),sha256=hashlib.sha256(log.read_bytes()).hexdigest());save()
 assert row['state']=='matched-expected-exit',(name,rc)
try:
 assert status['head']=='d9958d163436ea08d4a19b325d9e7f5dad3dc951'
 assert hashes()[files[0]]=='55fb01193691ec34dbf86180701eacf91d2fbcc6d47a5b89319b47ad452ca8fb'
 status.update(sourceSha256Before=hashes(),dirtyBefore=git('status','--porcelain'));save()
 producer='packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs'
 status['producerSha256Before']=hashlib.sha256((root/producer).read_bytes()).hexdigest();save()
 run('candidate-producer',['node','--import','tsx',producer,str(out/'generated')],300)
 import tomllib
 manifestPath=out/'generated/transition/Cargo.toml'
 manifest=manifestPath.read_text()
 status['manifestSha256']=hashlib.sha256(manifest.encode()).hexdigest()
 status['duplicateAliasCount']=sum(line.startswith('scroll_reader = ') for line in manifest.splitlines())
 assert status['duplicateAliasCount']==1,status['duplicateAliasCount']
 parsed=tomllib.loads(manifest)
 assert parsed['dev-dependencies']['scroll_reader']['path']=='../scroll_reader'
 previous=ops/'producer-original/generated'
 originalManifest=(previous/'transition/Cargo.toml').read_text()
 lines=originalManifest.splitlines(keepends=True)
 matches=[i for i,line in enumerate(lines) if line.startswith('scroll_reader = ')]
 assert len(matches)==2
 del lines[matches[1]]
 assert ''.join(lines)==manifest,'only the duplicate dependency may change the generated consumer manifest'
 oldReceipt=json.loads((previous/'source-receipt.json').read_text())
 newReceipt=json.loads((out/'generated/source-receipt.json').read_text())
 expected=[];seen=set()
 for row in oldReceipt['modules']:
  if row['name'] in seen:
   assert row['name']=='scroll_reader'
  else:
   seen.add(row['name']);expected.append(row)
 assert newReceipt['modules']==expected,'all original generated module bytes and source bindings must remain'
 for key,value in oldReceipt.items():
  if key not in ['modules','consumerManifestSha256']:assert newReceipt[key]==value,key
 manifests=sorted((out/'generated').rglob('Cargo.toml'))
 for candidate in manifests:tomllib.loads(candidate.read_text())
 status['parsedManifestCount']=len(manifests)
 status['generatedModuleCount']=len(newReceipt['modules'])
 status['previousGeneratedModuleCount']=len(oldReceipt['modules'])
 status['generatedModulesUnchangedExceptDuplicateReceipt']=True
 run('format-check',['corepack','pnpm@10.32.1','exec','prettier','--check',*files,producer],120)
 run('diff-check',['git','diff','--check'],60)
 (out/'candidate.patch').write_text(git('diff','--',*files,producer)+'\n')
 status.update(state='passed',sourceSha256After=hashes(),headAfter=git('rev-parse','HEAD'),dirtyAfter=git('status','--porcelain'),producerSha256After=hashlib.sha256((root/producer).read_bytes()).hexdigest())
 assert status['sourceSha256Before']==status['sourceSha256After']
 assert status['producerSha256Before']==status['producerSha256After']
 assert status['head']==status['headAfter'] and status['dirtyBefore']==status['dirtyAfter']
except Exception as e:status.update(state='failed',error=repr(e))
finally:status['finishedAt']=now();save();print(json.dumps(status,indent=2))
raise SystemExit(0 if status['state']=='passed' else 1)