from pathlib import Path
import hashlib,json,os,subprocess,time
ops=Path('/tank/shared/projects/proto-ui-agent/sprint3-retirement-75d5e28a-ops')
work=ops.parent/'sprint3-retirement-75d5e28a'
runtime=ops.parent/'seven-sprints-20261123-chvf1ono'
payload=json.loads((ops/'adaptation.json').read_text())
env=os.environ.copy();env['PATH']=str(runtime/'tools/node-v24.22.3-linux-x64/bin')+os.pathsep+env['PATH']
env['COREPACK_HOME']=str(runtime/'corepack-cache');env['NODE_OPTIONS']='--max-old-space-size=1536'
state={'stage':'checking','candidate':payload['candidate'],'startedAt':time.time(),'runs':[]}
def save(): (ops/'repair-status.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,args,timeout=120):
 start=time.time()
 print(label,flush=True)
 with (ops/(label+'.log')).open('w') as f:
  r=subprocess.run(args,cwd=work,env=env,stdout=f,stderr=subprocess.STDOUT,text=True,timeout=timeout)
 row={'name':label,'argv':args,'exitCode':r.returncode,'durationSeconds':time.time()-start,'log':str(ops/(label+'.log'))}
 state['runs'].append(row);save()
 print((ops/(label+'.log')).read_text()[-800:],flush=True)
 return r.returncode
def tests(label):
 code=run(label,['node','node_modules/vitest/vitest.mjs','run','packages/compiler/test/browser-preview-retirement.test.ts','--maxWorkers=1','--no-file-parallelism','--reporter=json','--outputFile='+str(ops/(label+'.json'))])
 result=json.loads((ops/(label+'.json')).read_text())
 summary={k:result.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','success']}
 state[label]=summary;save();return code,result
save()
try:
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
 if head!=payload['candidate']:raise RuntimeError('baseline head changed')
 for rel,info in payload['files'].items():
  f=work/rel
  if info['before'] is None:
   if f.exists():raise RuntimeError('new test unexpectedly exists')
  elif f.read_text()!=info['before']:raise RuntimeError('source preimage differs '+rel)
 test='packages/compiler/test/browser-preview-retirement.test.ts'
 (work/test).write_text(payload['files'][test]['after'])
 state['stage']='baseline';save()
 code,result=tests('retirement-baseline')
 if code==0 or result.get('numTotalTests')!=10 or result.get('numFailedTests',0)<1:
  raise RuntimeError('expected 10-case discriminating baseline failure not established')
 state['baselineFailures']=[{'name':a['fullName'],'messages':a.get('failureMessages',[])} for t in result.get('testResults',[]) for a in t.get('assertionResults',[]) if a.get('status')=='failed']
 for rel,info in payload['files'].items():
  if info['before'] is not None:(work/rel).write_text(info['after'])
 state['stage']='candidate';save()
 code,result=tests('retirement-repaired')
 if code or result.get('numPassedTests')!=10 or result.get('numFailedTests')!=0 or result.get('numPendingTests')!=0:raise RuntimeError('candidate protocol suite did not pass completely')
 if run('production-controls',['node','--test','--test-concurrency=1','scripts/compiler/browser-production.test.mjs','scripts/compiler/browser-delivery-index.test.mjs','scripts/compiler/browser-assets-production.test.mjs'],180):raise RuntimeError('production control failure')
 if run('format',['corepack','pnpm@10.32.1','exec','prettier','--check',*payload['files'].keys()],60):raise RuntimeError('format check failed')
 if run('diff-check',['git','diff','--check'],30):raise RuntimeError('diff whitespace failed')
 state['sourceHashes']={rel:hashlib.sha256((work/rel).read_bytes()).hexdigest() for rel in payload['files']}
 with (ops/'candidate.patch').open('w') as f:subprocess.run(['git','diff','--',*payload['files'].keys()],cwd=work,stdout=f,check=True)
 state['stage']='validated'
except Exception as e:
 state['stage']='failed';state['error']=repr(e)
finally:
 state['finishedAt']=time.time();save();print(json.dumps(state,indent=2),flush=True)
