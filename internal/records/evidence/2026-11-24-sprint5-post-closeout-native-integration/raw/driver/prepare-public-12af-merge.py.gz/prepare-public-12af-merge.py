#!/usr/bin/env python3
import pathlib,os,subprocess,json,datetime,traceback,hashlib
T=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a');B=pathlib.Path(str(T)+'-ops');O=B/'public-12af-integration';O.mkdir(exist_ok=False)
E=dict(os.environ);E['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+E.get('PATH','');E['TMPDIR']='/var/tmp/s5g75d5';assert E.get('HUSKY')!='0'
S={'phase':'initial','commands':[],'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save(p=None):
 if p:S['phase']=p
 (O/'status.json').write_text(json.dumps(S,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=T,env=E,text=True,timeout=90).strip()
def run(n,a,allowed=(0,)):
 save(n)
 with (O/(n+'.log')).open('wb') as f:r=subprocess.run(a,cwd=T,env=E,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 S['commands'].append({'name':n,'argv':a,'exitCode':r.returncode});save();assert r.returncode in allowed,(n,r.returncode)
try:
 base='d8210d78053e3a4d9ab079f65eb4f8b3beb59463';remote='12af03bcdcdfc1f319c77e51950ae1a71abf6d25'
 assert git('rev-parse','HEAD')==base and git('status','--porcelain=v1')==''
 S.update({'base':base,'remote':remote})
 ref='refs/remotes/s5-75d5/public-12af'
 run('fetch',['git','fetch','--no-tags','origin','refs/heads/fix/sprint5-preview-input-bundle-20261123-75d5:'+ref])
 assert git('rev-parse',ref)==remote,'remote advanced again'
 (O/'public-source.patch').write_text(git('diff','f6bdadf1bf1791bab8a66d7c9a6c25993fc5c1f4',remote,'--','packages')+'\n')
 (O/'public-change-paths.txt').write_text(git('diff','--name-only','f6bdadf1bf1791bab8a66d7c9a6c25993fc5c1f4',remote)+'\n')
 run('merge',['git','merge','--no-ff','--no-commit','--signoff',remote],(0,1))
 S['unmerged']=git('diff','--name-only','--diff-filter=U').splitlines()
 for file in S['unmerged']:
  for stage in [1,2,3]:
   p=O/(file.replace('/','__')+'.stage'+str(stage))
   p.write_bytes(subprocess.check_output(['git','show',':'+str(stage)+':'+file],cwd=T,env=E))
 S['status']=git('status','--porcelain=v1');S['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save('merged-awaiting-review')
except BaseException as ex:
 S['error']=repr(ex);S['traceback']=traceback.format_exc();save('failed');raise
