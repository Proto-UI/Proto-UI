# Root review of the concurrent 12af native repair

Read the complete seven-path comparison from `f6bdadf1bf1791bab8a66d7c9a6c25993fc5c1f4` to `12af03bcdcdfc1f319c77e51950ae1a71abf6d25`, the actual diagnostic state mutations, the owner prepaint/paint callbacks, `builtin_projection`, and the new native validation record on 2026-11-23. This is source review, not another native execution or GitHub APPROVED disposition.

## Diagnostic helper reconciliation

Preserve 12af's helper (`changed || !state.diagnostics.contains(&message)`) and all of d0c's additional assertions in the existing SDK case. The `changed` term preserves diagnostic transitions including A-to-B-to-A; this is not whole-queue deduplication alone. The stderr branch remains gated on a changed message. Pair resolution, physical receipts, immutable captured authority and inactive-action invocation are unaffected by this helper conflict.

The complete source has one queue removal, `std::mem::take`, which drains the queue. Other writes to `last_diagnostic` reset it to `None`; queue insertion is in the diagnostic helper. Under those current reachable states, the public helper and d0c's `queue.is_empty() || last != message` condition have the same observable behavior: when last is the same and the queue is nonempty, the current last message remains in that queue. When the queue was drained, both append a fresh identical refusal. A reset to None makes both record the next refusal. This equivalence is scoped to the current queue API, not a promise for a future selective-removal API.

Taking the public helper therefore preserves the concurrent implementation and the independently added regression checks. The merged file has a new identity: the reported SHA-256 is `0940aedd15a0e0acfb13b869f1ee9b0e14449a05552ceeabd9351ffd5d340183`. It must not be described as the earlier f729 source. Verify mechanically that only the conflict's helper bytes come from the public side and that the rest of d0c's file, including its strengthened SDK assertions, remains intact.

## External sibling Scroll observation

The existing leading canvas still observes external Scroll state during paint, after the complete prepaint pass. The tail canvas now observes only the current built-in projection. This avoids observing a raw external offset before a later sibling viewport clamps its real ScrollHandle, while retaining the built-in slot's post-child observation.

The added fifth reader test uses the actual native wheel path and a later sibling viewport. It observes a clamped non-movement retaining pause, verifies that appending cannot acquire following from that raw sample, and then verifies that actual followed-axis movement can resume following. All four original test bodies remain. The harness's added sibling placement is exercised by the new case; the existing variants still select their original slot placement. The producer and disposing-lease guard from f6bd remain unchanged.

No blocking source defect was identified in this bounded union. Preserve 12af's two records and raw archives as their own historical evidence. Its reported Linux 155-case run is not a run of the new merged source. The final published-head workflow must execute the full native targets, including SDK 62, unchanged official ControlLabel nine and the complete five-case reader target, while the new browser/source/production work remains separately required. No assertion, timeout, native authority check or acceptance scope is relaxed by this reconciliation.
