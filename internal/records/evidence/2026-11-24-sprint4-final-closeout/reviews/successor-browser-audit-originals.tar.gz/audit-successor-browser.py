from pathlib import Path, PurePosixPath
import datetime
import hashlib
import io
import json
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/1494db44bb7b/Proto-UI')
SCRATCH = ROOT.parent
OUT = SCRATCH / 'sprint4-final-acceptance-1494'
HEAD = 'c1f0332eed6ba79734b92bd4407b274f45d5c274'
BASE = '9fff88cf23d4e55375979bc5c68c033e3deaed38'
CAPTURE = '996a2a35b9d9ca19e8d0def7c9b6040fb8afe714'
UPLOAD = 'c1f0332eed6ba79734b92bd4407b274f45d5c274'
EVIDENCE = SCRATCH / 'integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1'
ARCHIVE = SCRATCH / 'integration-evidence/visual-browser-originals.tar.gz'
SUITE = 'packages/compiler/test/shader-presentation.browser.test.ts'
SELECTION = 'scripts/test/shader-browser-selection.json'
EMPTY = hashlib.sha256(b'').hexdigest()
EXPECTED_PROFILES = [('react', 'react-dom-source-v1'), ('vue', 'vue-source-v1'), ('vue2', 'vue2-source-v1'), ('wc', 'web-component-source-v1')]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def blob(revision, path):
    return git('show', revision + ':' + path)

def loaded(path):
    return json.loads(path.read_bytes())

def evidence_file(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(EVIDENCE)), 'bytes': len(data), 'sha256': sha(data)}

OUT.mkdir(exist_ok=True)
observed_head = git('rev-parse', 'HEAD').decode().strip()
archive = ARCHIVE.read_bytes()
assert len(archive) == 3141207
assert sha(archive) == '22da92c2a76be6a901f0cb9ea294d22f592d8a438ca1efc9684701e29c5ac2f0'
archive_files = []
with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tar:
    for member in tar.getmembers():
        path = PurePosixPath(member.name)
        assert not path.is_absolute() and '..' not in path.parts and member.isfile()
        original = tar.extractfile(member).read()
        assert original == (EVIDENCE.parent / member.name).read_bytes()
        archive_files.append({'path': member.name, 'bytes': len(original), 'sha256': sha(original)})
assert len(archive_files) == len({x['path'] for x in archive_files}) == 250
extracted_files = [path for path in EVIDENCE.rglob('*') if path.is_file()]
assert all(not path.is_symlink() for path in EVIDENCE.rglob('*'))
assert {str(path.relative_to(EVIDENCE.parent)) for path in extracted_files} == {x['path'] for x in archive_files}

selection_bytes = blob(HEAD, SELECTION)
selection = json.loads(selection_bytes)
expected_names = selection['originalJourneys'] + selection['sceneJourneys']
assert len(selection['originalJourneys']) == 28 and len(selection['sceneJourneys']) == 9
assert len(expected_names) == len(set(expected_names)) == 37
report = loaded(EVIDENCE / 'browser-vitest.json')
assert report['success'] and report['numTotalTests'] == report['numPassedTests'] == 37
assert report['numFailedTests'] == report['numPendingTests'] == report['numTodoTests'] == 0
assert len(report['testResults']) == 1
suite = report['testResults'][0]
assert suite['name'] == '/home/runner/work/Proto-UI/Proto-UI/' + SUITE
assert suite['status'] == 'passed'
assert len(suite['assertionResults']) == 37
assert sorted(x['fullName'] for x in suite['assertionResults']) == sorted(expected_names)
assert all(x['status'] == 'passed' and not x['failureMessages'] for x in suite['assertionResults'])

build_paths = sorted((EVIDENCE / 'browser').glob('*/build.json'))
assert len(build_paths) == 3
build_data = [(path, loaded(path)) for path in build_paths]
source_paths = {'pnpm-lock.yaml', SELECTION, SUITE}
for path, build in build_data:
    source_paths.update(x['file'] for x in build['sourceGenerator']['files'])
    source_paths.update(build['harness'])
    source_paths.update(x for x in build['inputs'] if x.startswith(('packages/', 'scripts/')))
    for compilation in build['compilations']:
        source_paths.update(x['file'] for x in compilation['sourceFiles'])
source_paths = sorted(source_paths)
proc = subprocess.run(['git', 'cat-file', '--batch'], cwd=ROOT,
                      input=''.join(HEAD + ':' + path + '\n' for path in source_paths).encode(),
                      capture_output=True, check=True)
stream = io.BytesIO(proc.stdout)
blobs = {}
for path in source_paths:
    header = stream.readline().decode().strip().split()
    assert len(header) == 3 and header[1] == 'blob', (path, header)
    data = stream.read(int(header[2])); assert stream.read(1) == b'\n'
    blobs[path] = data
assert stream.read() == b''

builds = []
seen_entries = []
all_missing = []
for path, build in build_data:
    directory = path.parent
    candidate = build['candidate']
    assert candidate['head'] == HEAD and candidate['headTree'] == git('rev-parse', HEAD + '^{tree}').decode().strip()
    assert candidate['dirty'] is False and candidate['statusSha256'] == candidate['trackedDiffSha256'] == EMPTY
    generator = build['sourceGenerator']
    assert len(generator['files']) == len({x['file'] for x in generator['files']}) == 194
    assert sha(json.dumps(generator['files'], separators=(',', ':'), ensure_ascii=False).encode()) == generator['sha256']
    for source in generator['files']:
        assert source['file'].startswith('packages/compiler/src/') and source['file'].endswith('.ts')
        actual = blobs[source['file']]
        assert len(actual) == source['bytes'] and sha(actual) == source['sha256']
    assert sha(blobs['pnpm-lock.yaml']) == build['lockSha256']
    for file, digest in build['harness'].items(): assert sha(blobs[file]) == digest
    assert sha((directory / 'entry.ts').read_bytes()) == build['entrySha256']
    assert sha((directory / 'client.js').read_bytes()) == build['bundleSha256']
    assert sorted((x['target'], x['profile']) for x in build['compilations']) == EXPECTED_PROFILES
    entries = {x['entry'] for x in build['compilations']}; assert len(entries) == 1
    seen_entries.extend(entries)
    assert len({x['sourceSha256'] for x in build['compilations']}) == 1
    assert all(x['sourceFiles'] == build['compilations'][0]['sourceFiles'] for x in build['compilations'])
    for compilation in build['compilations']:
        for source in compilation['sourceFiles']:
            data = blobs[source['file']]
            assert len(data) == source['bytes'] and sha(data) == source['sha256']
    retained, missing = [], []
    assert len({x['path'] for x in build['artifacts']}) == len(build['artifacts'])
    for artifact in build['artifacts']:
        relative = PurePosixPath(artifact['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        file = directory / artifact['path']
        if file.exists():
            data = file.read_bytes(); assert len(data) == artifact['bytes'] and sha(data) == artifact['sha256']
            retained.append(artifact)
        else:
            assert '.proto-ui' in relative.parts
            missing.append(artifact)
            all_missing.append({'fixture': directory.name, **artifact})
    input_counts = {'trackedSourceVerified': 0, 'generatedVerified': 0, 'generatedMissing': 0, 'externalManifestOnly': 0}
    for file, digest in build['inputs'].items():
        if file in blobs:
            assert sha(blobs[file]) == digest; input_counts['trackedSourceVerified'] += 1
        elif file.startswith('../../_temp/shader-presentation/browser/' + directory.name + '/'):
            relative = file.split('/browser/' + directory.name + '/', 1)[1]
            assert '..' not in PurePosixPath(relative).parts
            target = directory / relative
            if target.exists():
                assert sha(target.read_bytes()) == digest; input_counts['generatedVerified'] += 1
            else:
                assert '.proto-ui' in PurePosixPath(relative).parts
                input_counts['generatedMissing'] += 1
        else:
            assert file.startswith('node_modules/'), file
            input_counts['externalManifestOnly'] += 1
    builds.append({'fixture': directory.name, 'build': evidence_file(path), 'sourceGeneratorFilesVerified': 194,
                   'sourceGeneratorSha256': generator['sha256'], 'profiles': EXPECTED_PROFILES,
                   'entry': next(iter(entries)), 'artifactDeclared': len(build['artifacts']),
                   'artifactRetainedAndHashVerified': len(retained), 'artifactMissing': len(missing),
                   'bundleSha256': build['bundleSha256'], 'entrySha256': build['entrySha256'],
                   'inputChecks': input_counts, 'node': build['node'], 'esbuild': build['esbuildVersion']})
assert sorted(seen_entries) == sorted(selection['fixtures'])
assert sum(x['artifactDeclared'] for x in builds) == 106
assert sum(x['artifactRetainedAndHashVerified'] for x in builds) == 106
assert len(all_missing) == 0

prepare = loaded(EVIDENCE / 'isolation-prepare.json')
isolation = loaded(EVIDENCE / 'isolation-run.json')
assert prepare['exitCode'] == 0 and prepare['outcome'] == isolation['outcome'] == 'ready'
assert isolation['uid'] != 0 and all(int(x, 16) == 0 for x in isolation['capabilities'].values())
assert len(isolation['links']) == 1 and isolation['links'][0]['ifname'] == 'lo'
assert isolation['ipv4DefaultRoutes'] == isolation['ipv6DefaultRoutes'] == ''
assert isolation['userNamespace'] not in prepare['command'] and isolation['networkNamespace'] not in prepare['command']
for name in ['source-prepare.json', 'source-run.json', 'isolation-prepare.json', 'isolation-run.json', 'receipt.json']:
    d = loaded(EVIDENCE / name)
    assert d['candidateSha'] == HEAD and d['selectionSha256'] == sha(selection_bytes)
    assert d['expectedCases'] == 37
    assert d['tree'] == git('rev-parse', HEAD + '^{tree}').decode().strip() and d['suite'] == SUITE
assert b'chromiumSandbox: true' in blobs[SUITE]
receipt = loaded(EVIDENCE / 'receipt.json')
assert receipt['exitCode'] == 0 and receipt['signal'] is None and receipt['error'] is None and receipt['outcome'] == 'passed'

# Preserve source identity: c1 is the actual execution, while the product is
# unchanged from 9fff. Never rewrite the CI source or its runner paths.
assert git('diff', '--name-only', BASE, HEAD, '--', 'packages', 'scripts', '.github/workflows').decode().splitlines() == [
    '.github/workflows/shader-presentation-evidence.yml', SUITE]
assert blobs[SUITE] == blob(CAPTURE, SUITE)
assert blob(BASE, SELECTION) == selection_bytes
capture_old = blob(BASE, SUITE).decode()
capture_new = blobs[SUITE].decode()
recovered = capture_new
start = recovered.index('async function captureScenePaint(')
end = recovered.index('it.each(sceneCases)(', start)
recovered = recovered[:start] + recovered[end:]
recovered = recovered.replace('    const name = `scene-${scenario.target}-${scenario.execution}`;\n', '', 1)
recovered = recovered.replace('      name,\n', '      `scene-${scenario.target}-${scenario.execution}`,\n', 1)
for phase in ['initial-paint', 'replacement-paint']:
    recovered = recovered.replace("        await captureScenePaint(page, name, '" + phase + "');\n", '', 1)
assert recovered == capture_old
assert git('diff', '--name-only', BASE, CAPTURE).decode().splitlines() == [SUITE]
workflow = '.github/workflows/shader-presentation-evidence.yml'
old_workflow = blob('e15c2c4912fd7c748682c1b094cad81f9cfa315e', workflow)
new_workflow = blob(UPLOAD, workflow)
addition = b'          # Include .proto-ui generated support from this isolated evidence directory.\n          include-hidden-files: true\n'
assert new_workflow.replace(addition, b'', 1) == old_workflow
assert b'path: ${{ runner.temp }}/shader-presentation' in new_workflow
assert b'env -i PATH=' in new_workflow and b'persist-credentials: false' in new_workflow
assert sum(x['inputChecks']['generatedMissing'] for x in builds) == 0

# Every scenario receipt remains under the original fixture and build hash.
receipts = []
for build_path, build in build_data:
    for path in sorted(build_path.parent.glob('*.json')):
        if path.name == 'build.json' or path.name.endswith('-paint.json'):
            continue
        d = loaded(path)
        assert d['head'] == HEAD and d['buildSha256'] == sha(build_path.read_bytes())
        assert d['scenario'] == path.stem and d['outcome'] == 'PASS'
        assert not d['errors'] and not d['blocked']
        r = d['resources']
        assert r['created'] == r['deleted'] and r['live'] == r['duplicates'] == r['waiting'] == 0
        receipts.append({**evidence_file(path), 'scenario': d['scenario'], 'outcome': d['outcome'],
                         'resourceCreatedAndDeleted': r['created'], 'live': r['live'],
                         'duplicates': r['duplicates'], 'waiting': r['waiting']})
assert len(receipts) == 37

import base64
import math
from PIL import Image

def round_positive(value):
    return math.floor(value + 0.5)

def expected_scene_pixels(replacement):
    # Recompute the fixed authored scene and color transform independently of
    # generated code, using the same declared RGBA8 quantization semantics.
    src = ([0, 255, 0, 255] * 4 if replacement else
           [255, 0, 0, 255, 0, 128, 0, 255, 0, 0, 64, 255, 64, 128, 192, 255])
    multiplier = [0.5, 1, 0.25, 0.5]
    linear = []
    for index, byte in enumerate(src):
        channel = byte / 255
        linear.append(byte if index % 4 == 3 else round_positive(255 * (
            channel / 12.92 if channel < 0.04045 else ((channel + 0.055) / 1.055) ** 2.4)))
    output = [round_positive(value * multiplier[index % 4] * (1 if index % 4 == 3 else multiplier[3]))
              for index, value in enumerate(linear)]
    result = []
    for index, value in enumerate(output):
        if index % 4 == 3:
            result.append(value)
        else:
            alpha = output[index - index % 4 + 3] / 255
            channel = value / (255 * alpha) if alpha else 0
            result.append(round_positive(255 * (12.92 * channel if channel < 0.0031308
                                                else 1.055 * channel ** (1 / 2.4) - 0.055)))
    return result

def premultiplied_bytes(values):
    return [value if index % 4 == 3 else round_positive(value * values[index - index % 4 + 3] / 255)
            for index, value in enumerate(values)]

scene = EVIDENCE / 'browser/shader-presentation-scene-flKmDT'
scene_build_sha = sha((scene / 'build.json').read_bytes())
paint_images, paint_observations, pair_checks, terminal_observations = [], [], [], []
for target in ['react', 'vue', 'vue2', 'wc']:
    for execution in ['runtime', 'compiled']:
        name = f'scene-{target}-{execution}'
        backgrounds, screenshots = [], []
        for phase in ['initial-paint', 'replacement-paint']:
            data_path = scene / (name + '-' + phase + '.json')
            image_path = data_path.with_suffix('.png')
            d = loaded(data_path)
            assert d['head'] == HEAD and d['buildSha256'] == scene_build_sha
            assert d['scenario'] == name and d['checkpoint'] == phase
            o = d['observation']; r = o['resources']; p = o['presentation']; s = o['source']
            assert s['subscriptions'] == 1 and s['borrowedDisposals'] == 0 and s['sourceAvailable']
            assert p['canvases'] == 0 and p['childText'] == 'ordinary childslot child'
            assert p['buttonTexts'] == ['ordinary childslot child'] and p['fallback'] == 'rgb(38, 51, 64)'
            assert r['created'] - r['deleted'] == r['live'] == 16 and r['duplicates'] == r['waiting'] == 0
            assert all('SwiftShader' in renderer for renderer in r['renderers'])
            observed, expected = o['pixels'], expected_scene_pixels(phase == 'replacement-paint')
            assert len(observed) == len(expected) == 16
            diffs = [abs(a - b) for a, b in zip(premultiplied_bytes(observed), premultiplied_bytes(expected))]
            assert max(diffs) <= 1  # exact retained image() assertion: one premultiplied RGBA8 unit
            background = p['background']
            assert background.startswith('url("data:image/png;base64,') and background.endswith('")')
            png = base64.b64decode(background.split('base64,', 1)[1][:-2], validate=True)
            with Image.open(io.BytesIO(png)) as im:
                assert im.size == (2, 2)
            with Image.open(image_path) as im:
                assert im.size == (640, 360)
            backgrounds.append(sha(png)); screenshots.append(sha(image_path.read_bytes()))
            area = ('compact owner around the control, approximately x32..282/y122..167' if target == 'wc'
                    else 'broad owner behind the control, approximately x32..608/y123..243')
            state = ('four-color red/green/blue/teal texture' if phase == 'initial-paint' else 'uniform green paint')
            paint_images.append({**evidence_file(image_path), 'viewed': True,
                                 'observed': f'640x360 screenshot: readable heading and ordinary/slot-child control; {state}; {area}.',
                                 'sourceData': evidence_file(data_path)})
            paint_observations.append({'scenario': name, 'checkpoint': phase, 'source': s,
                                       'pixels': observed, 'independentlyRecomputedExpectedPixels': expected,
                                       'premultipliedAbsoluteDifferences': diffs,
                                       'backgroundPngSha256': sha(png), 'created': r['created'], 'deleted': r['deleted'],
                                       'live': r['live'], 'duplicates': r['duplicates'], 'waiting': r['waiting']})
        assert backgrounds[0] != backgrounds[1] and screenshots[0] != screenshots[1]
        pair_checks.append({'scenario': name, 'backgroundChanged': True, 'screenshotChanged': True,
                            'initialAndReplacementImageSha256': screenshots})
        terminal = loaded(scene / (name + '.json'))
        assert terminal['observation']['background'] is None and terminal['observation']['buttonTexts'] == []
        terminal_observations.append({'scenario': name, 'readback': evidence_file(scene / (name + '.json')),
                                      'terminalPng': evidence_file(scene / (name + '.png')),
                                      'terminalPngViewedInThisFollowup': False,
                                      'observation': terminal['observation'],
                                      'createdAndDeleted': terminal['resources']['created']})

for target in ['react', 'vue', 'vue2', 'wc']:
    for phase in ['initial-paint', 'replacement-paint']:
        runtime = (scene / f'scene-{target}-runtime-{phase}.png').read_bytes()
        compiled = (scene / f'scene-{target}-compiled-{phase}.png').read_bytes()
        assert runtime == compiled

fallback = loaded(scene / 'scene-default-unconfigured.json')
assert fallback['observation']['background'] == 'none' and fallback['observation']['fallback'] == 'rgb(38, 51, 64)'
assert fallback['resources']['attempts'] == fallback['resources']['live'] == 0
fallback_image = {**evidence_file(scene / 'scene-default-unconfigured.png'), 'viewed': True,
                  'observed': '640x360 screenshot: readable heading, ordinary/slot-child control, opaque dark surround; no shader texture.'}

previous_path = OUT / 'first-browser-audit.json'
assert sha(previous_path.read_bytes()) == '7d2d288bb652da4d25b372d13d2b55354077a6a1018add41b70eb11772b46888'
assert sha((OUT / 'first-browser-audit.md').read_bytes()) == '0f1b67dcb779bc3b5e12b55e24f552c4d84d79df629dda217c1c589b698fea66'
assert sha((OUT / 'first-browser-audit-originals.tar.gz').read_bytes()) == '1ba06025f565a67a2129abb151a9896636e981c9904abd81cb4404aeaf72b8c3'

result = {
    'schemaVersion': 1, 'kind': 'independent bounded successor browser artifact and actual screenshot review',
    'reviewer': '/root/sprint4_final_acceptance', 'observedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'actualBrowserHead': HEAD, 'actualBrowserTree': git('rev-parse', HEAD + '^{tree}').decode().strip(),
    'actualBrowserRun': 'https://github.com/Proto-UI/Proto-UI/actions/runs/45266835323',
    'productSourceUnchangedFrom': BASE, 'observedRootHeadAtStart': observed_head,
    'observedRootHeadAtEnd': git('rev-parse', 'HEAD').decode().strip(),
    'rootModifiedByThisAudit': False, 'browserRerunByThisAudit': False,
    'canonicalPrReviewPacketProduced': False, 'githubReviewSubmitted': False,
    'archive': {'path': str(ARCHIVE), 'bytes': len(archive), 'sha256': sha(archive),
                'retainedFilesMatched': len(archive_files), 'members': archive_files},
    'functional': {'report': evidence_file(EVIDENCE / 'browser-vitest.json'),
                   'uniqueCases': 37, 'passed': 37, 'failed': 0, 'pending': 0, 'todo': 0,
                   'fullNamesExactlyMatchCommittedSelection': True,
                   'selectionSha256': sha(selection_bytes), 'fullNames': expected_names,
                   'originalExecutionPathRetained': suite['name'], 'scenarioReceipts': receipts},
    'builds': builds, 'immutableSourceBlobsChecked': len(blobs), 'generatedArtifacts': {
        'declared': 106, 'presentAndHashVerified': 106, 'missing': 0,
        'hiddenSupportArtifactsVerified': sum('.proto-ui' in PurePosixPath(x['path']).parts
                                              for _, b in build_data for x in b['artifacts'])},
    'isolation': {'nonRoot': True, 'uid': isolation['uid'], 'capabilitiesAllZero': True,
                  'loopbackOnly': True, 'noDefaultRoutes': True,
                  'userAndNetworkNamespacesDifferFromParent': True, 'chromiumSandboxEnabledInExactHarness': True},
    'captureDiff': {'onlyTestFileChanged': True,
                    'removingNewObservationHelperAndTwoCallsRecoversOriginalBytes': True,
                    'assertionsNamesAndDeadlinesUnchanged': True, 'executedInThisSuccessor': True},
    'uploadDiff': {'onlyTwoWorkflowLinesAdded': True, 'uploadsOnlyExistingIsolatedEvidenceDirectory': True,
                   'credentialFreeExecutionAndCheckoutUnchanged': True,
                   'allDeclaredGeneratedFilesRetainedInSuccessor': True},
    'paintImages': paint_images, 'fallbackImage': fallback_image, 'paintObservations': paint_observations,
    'paintPairs': pair_checks, 'terminalSceneObservations': terminal_observations,
    'runtimeCompiledScreenshotPairsByteIdentical': 8,
    'previousReport': {'path': str(previous_path), 'sha256': sha(previous_path.read_bytes()),
                       'originalFilesUnchanged': True},
    'findings': [
        {'id': 'S4-CI-VISUAL-001', 'status': 'successor-bounded-visual-evidence-accepted',
         'observation': 'All 16 initial/replacement screenshots were actually viewed; visible paint changes from colored texture to green while child text remains readable. Eight runtime/compiled screenshot pairs are byte-identical.',
         'scope': 'Exact 640x360 fixture and retained c1 run only; no general layout, optics, accessibility or performance acceptance.'},
        {'id': 'S4-CI-ARTIFACT-001', 'status': 'successor-artifact-completeness-verified',
         'observation': 'All 106 declared generated artifacts, including 70 hidden support files, are present and match size/hash; archive has 250 unique regular files matching extraction.',
         'scope': 'Completes the successor retained-file gap; the first run still retained only 36 of 106.'},
        {'id': 'S4-CI-GEOMETRY-OBS-001', 'status': 'observed-scope-limit',
         'observation': 'WC uses a compact paint region around the control; React/Vue/Vue2 use a broad rectangular region. Child text is not clipped in any reviewed screenshot.',
         'scope': 'This is not a claim of cross-host geometry equivalence and is not a new release requirement.'}
    ],
    'limitations': [
        'Local factual review only: no canonical GitHub v5 review-input/APPROVE packet was produced.',
        'Actual execution belongs to c1f0332eed6ba79734b92bd4407b274f45d5c274, not a later budget or documentation head.',
        'The first run remains a valid 37-case success with its original artifact and terminal-picture gaps; it was not rewritten.',
        'Terminal scene pictures do not establish active paint. This follow-up accepts only actually viewed initial/replacement and fallback screenshots.',
        'External node_modules inputs have retained hash/lock witnesses but were not independently fetched or reexecuted by this reviewer.',
        'SwiftShader shows software WebGL execution, not physical GPU performance, all-target support, AT or whole Sprint 4 acceptance.',
        'The source snapshot has no numeric revision field in sceneState; source replacement is bound through actual test order, pixel data and exact checkpoint names.',
        'CI bytes and source hashes are checked against supplied originals and immutable Git; this is not a separate cryptographic attestation of GitHub.'
    ]
}
output = OUT / 'successor-browser-audit.json'
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': str(output), 'actualBrowserHead': HEAD,
                  'uniqueCasesPassed': 37, 'fixtures': len(builds), 'profilesPerFixture': 4,
                  'immutableSourceBlobsChecked': len(blobs), 'generatedArtifactsVerified': 106,
                  'generatedArtifactsMissing': 0, 'archiveFilesVerified': len(archive_files),
                  'paintPicturesActuallyViewed': len(paint_images), 'fallbackPicturesActuallyViewed': 1,
                  'runtimeCompiledScreenshotPairsByteIdentical': 8,
                  'expectedInitialPixels': expected_scene_pixels(False),
                  'expectedReplacementPixels': expected_scene_pixels(True)}, ensure_ascii=False))

