# Sprint 4：后继浏览器原件与实际绘制截图独立复核

**有界结论：本轮 37 条浏览器旅程、106 个生成产物保全，以及 16 张初始／换源绘制截图的证据缺口已经完成独立复核。**

复核者为 `/root/sprint4_final_acceptance`。这是本地事实与原图审阅，不是 canonical GitHub v5 review-input、正式 APPROVE 或整个 Sprint 4 的关闭决定。本次未运行 Chrome，未修改仓库、GitHub、原报告或原图。

## 绑定的真实执行

- CI：[45266835323](https://github.com/Proto-UI/Proto-UI/actions/runs/45266835323)。
- 实际执行 head：`c1f0332eed6ba79734b92bd4407b274f45d5c274`。
- Tree：`ef4ef8fb55f867f41d70717dde180f04d1233d1c`。
- 产品源与 `9fff88cf23d4e55375979bc5c68c033e3deaed38` 相同；实际 CI 仍绑定 c1，不能改标为后续预算或文档提交的执行。
- 选择清单 SHA256：`e3db32445d1aeb0eef5832f1c39e0d2041b25973d10924000329295c1ecc7133`。
- 原报告中的执行路径保持原样：`/home/runner/work/Proto-UI/Proto-UI/packages/compiler/test/shader-presentation.browser.test.ts`。
- 原件归档：`/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals.tar.gz`；3,141,207 bytes；SHA256 `22da92c2a76be6a901f0cb9ea294d22f592d8a438ca1efc9684701e29c5ac2f0`。

250 个归档成员均为唯一常规文件，逐字节匹配解包内容；解包目录不存在额外文件或符号链接。原始 JSON、runner 路径和图片均未改写。该检查是提供的原件与 immutable Git 之间的完整性复核，不是另一份 GitHub 密码学证明。

## 功能名单、生成闭包和来源

37 个唯一 fullName 与提交内原 28 条加 scene 9 条的固定选择清单完全相同：37 passed，0 failed／pending／todo。37 份独立 scenario receipt 全部为 PASS，head 与各自 build hash 相符，errors／blocked 为空；最终 created = deleted，live／duplicate／waiting 均为 0。

| Fixture | 原始输入 | 已保全且大小／哈希匹配 | 缺失 |
|---|---|---:|---:|
| shader-presentation-inline-md76Fg | `packages/compiler/test/fixtures/shader-presentation-owner.proto.ts` | 34/34 | 0 |
| shader-presentation-scene-flKmDT | `packages/compiler/test/fixtures/shader-scene-owner.proto.ts` | 38/38 | 0 |
| shader-presentation-static-data-cb6rif | `packages/compiler/test/fixtures/shader-static-data-owner.proto.ts` | 34/34 | 0 |

三个 fixture 各自完整对应以下四组 target／profile，四组内使用相同的 authored sourceFiles 与 sourceSha256：

| Target | Profile |
|---|---|
| React | `react-dom-source-v1` |
| Vue | `vue-source-v1` |
| Vue2 | `vue2-source-v1` |
| WC | `web-component-source-v1` |

独立逐哈希验证了 608 份唯一 Git 源 blob，包括每份 build 记录的 194 个 Compiler generator 文件、harness、原始 fixture 和打包输入；generator 聚合 hash、锁文件、三份 entry.ts 和 client.js 也一致。106 份生成产物全部保全，其中原来漏传的 70 份生成支持文件本轮均在。外部 node_modules 输入仍只具有保留的 input hash 和 lock witness，本复核未重新拉取或执行依赖。

隔离记录绑定同一 head／tree／suite／selection，UID 1001、所有 capability 为 0、仅 loopback、无默认路由，user 与 network namespace 均不同于父进程；原始 harness 保持 `chromiumSandbox: true`。准备阶段的 `browserJourneysExecuted: 0` 只表示前置检查，真实执行由 browser-vitest.json 和 37 个 scenario receipt 记录。

## 实际查看的 16 张 active paint 图片

下表每行对应一张已经实际打开查看的原图，不把终态 dispose 图算作绘制证明。截图都是 640×360；每份配对 JSON 的 head、build hash、scenario 和 checkpoint 均已核对。

| 原图 | 实际可见结果与有界意见 | PNG SHA256 |
|---|---|---|
| [scene-react-runtime-initial-paint.png](sandbox:/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1/browser/shader-presentation-scene-flKmDT/scene-react-runtime-initial-paint.png) | 控件背后的宽矩形区域可见红／绿／蓝／青色纹理；文字完整可读。接受此 fixture 的初始可见绘制。 | `af2275244081294d242aa4758f4c796f902c3562437764ebfe59109ce35d067d` |
| [scene-react-runtime-replacement-paint.png](sandbox:/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1/browser/shader-presentation-scene-flKmDT/scene-react-runtime-replacement-paint.png) | 相同宽矩形区域已变为绿色，子文本仍可读；接受此 fixture 的可见换源结果。 | `411bb37887a969df27da3bc655dc00457c54e49182b9efdf893dca1f1cb3a4ef` |
| [scene-react-compiled-initial-paint.png](sandbox:/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1/browser/shader-presentation-scene-flKmDT/scene-react-compiled-initial-paint.png) | 控件背后的宽矩形区域可见红／绿／蓝／青色纹理；文字完整可读。接受此 fixture 的初始可见绘制。 | `af2275244081294d242aa4758f4c796f902c3562437764ebfe59109ce35d067d` |
| [scene-react-compiled-replacement-paint.png](sandbox:/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1/browser/shader-presentation-scene-flKmDT/scene-react-compiled-replacement-paint.png) | 相同宽矩形区域已变为绿色，子文本仍可读；接受此 fixture 的可见换源结果。 | `411bb37887a969df27da3bc655dc00457c54e49182b9efdf893dca1f1cb3a4ef` |
| [scene-vue-runtime-initial-paint.png](sandbox:/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1/browser/shader-presentation-scene-flKmDT/scene-vue-runtime-initial-paint.png) | 控件背后的宽矩形区域可见红／绿／蓝／青色纹理；文字完整可读。接受此 fixture 的初始可见绘制。 | `af2275244081294d242aa4758f4c796f902c3562437764ebfe59109ce35d067d` |
| [scene-vue-runtime-replacement-paint.png](sandbox:/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1/browser/shader-presentation-scene-flKmDT/scene-vue-runtime-replacement-paint.png) | 相同宽矩形区域已变为绿色，子文本仍可读；接受此 fixture 的可见换源结果。 | `411bb37887a969df27da3bc655dc00457c54e49182b9efdf893dca1f1cb3a4ef` |
| [scene-vue-compiled-initial-paint.png](sandbox:/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1/browser/shader-presentation-scene-flKmDT/scene-vue-compiled-initial-paint.png) | 控件背后的宽矩形区域可见红／绿／蓝／青色纹理；文字完整可读。接受此 fixture 的初始可见绘制。 | `af2275244081294d242aa4758f4c796f902c3562437764ebfe59109ce35d067d` |
| [scene-vue-compiled-replacement-paint.png](sandbox:/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1/browser/shader-presentation-scene-flKmDT/scene-vue-compiled-replacement-paint.png) | 相同宽矩形区域已变为绿色，子文本仍可读；接受此 fixture 的可见换源结果。 | `411bb37887a969df27da3bc655dc00457c54e49182b9efdf893dca1f1cb3a4ef` |
| [scene-vue2-runtime-initial-paint.png](sandbox:/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1/browser/shader-presentation-scene-flKmDT/scene-vue2-runtime-initial-paint.png) | 控件背后的宽矩形区域可见红／绿／蓝／青色纹理；文字完整可读。接受此 fixture 的初始可见绘制。 | `af2275244081294d242aa4758f4c796f902c3562437764ebfe59109ce35d067d` |
| [scene-vue2-runtime-replacement-paint.png](sandbox:/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1/browser/shader-presentation-scene-flKmDT/scene-vue2-runtime-replacement-paint.png) | 相同宽矩形区域已变为绿色，子文本仍可读；接受此 fixture 的可见换源结果。 | `411bb37887a969df27da3bc655dc00457c54e49182b9efdf893dca1f1cb3a4ef` |
| [scene-vue2-compiled-initial-paint.png](sandbox:/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1/browser/shader-presentation-scene-flKmDT/scene-vue2-compiled-initial-paint.png) | 控件背后的宽矩形区域可见红／绿／蓝／青色纹理；文字完整可读。接受此 fixture 的初始可见绘制。 | `af2275244081294d242aa4758f4c796f902c3562437764ebfe59109ce35d067d` |
| [scene-vue2-compiled-replacement-paint.png](sandbox:/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1/browser/shader-presentation-scene-flKmDT/scene-vue2-compiled-replacement-paint.png) | 相同宽矩形区域已变为绿色，子文本仍可读；接受此 fixture 的可见换源结果。 | `411bb37887a969df27da3bc655dc00457c54e49182b9efdf893dca1f1cb3a4ef` |
| [scene-wc-runtime-initial-paint.png](sandbox:/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1/browser/shader-presentation-scene-flKmDT/scene-wc-runtime-initial-paint.png) | 控件周围窄区域可见红／绿／蓝／青色纹理；文字完整可读。接受此 fixture 的初始可见绘制。 | `b379d12e9bc33811d4df93d444fafc68b8f21574ef8a164fed9bf33c7b8efa3e` |
| [scene-wc-runtime-replacement-paint.png](sandbox:/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1/browser/shader-presentation-scene-flKmDT/scene-wc-runtime-replacement-paint.png) | 相同窄区域已变为绿色，子文本仍可读；接受此 fixture 的可见换源结果。 | `89e95c282fc37566612f44e80b83acadbe417b2ba66a3f5bbe29dea5092b18b0` |
| [scene-wc-compiled-initial-paint.png](sandbox:/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1/browser/shader-presentation-scene-flKmDT/scene-wc-compiled-initial-paint.png) | 控件周围窄区域可见红／绿／蓝／青色纹理；文字完整可读。接受此 fixture 的初始可见绘制。 | `b379d12e9bc33811d4df93d444fafc68b8f21574ef8a164fed9bf33c7b8efa3e` |
| [scene-wc-compiled-replacement-paint.png](sandbox:/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1/browser/shader-presentation-scene-flKmDT/scene-wc-compiled-replacement-paint.png) | 相同窄区域已变为绿色，子文本仍可读；接受此 fixture 的可见换源结果。 | `89e95c282fc37566612f44e80b83acadbe417b2ba66a3f5bbe29dea5092b18b0` |

另实际查看了 [scene-default-unconfigured.png](sandbox:/workspace/scratch/1494db44bb7b/integration-evidence/visual-browser-originals/shader-presentation-c1f0332eed6ba79734b92bd4407b274f45d5c274-45266835323-1/browser/shader-presentation-scene-flKmDT/scene-default-unconfigured.png)：子文本可读，控件周围为不透明深色 fallback，无 shader 纹理。PNG SHA256 `897257163327360843164c9a5cee8c166444e28b313013313e7b9117787821ec`；配对记录为 background `none`、fallback `rgb(38, 51, 64)`、资源 attempts／live 均 0。

同一宿主、同一阶段的 runtime／compiled 截图共有八对，均逐字节相同。每个 scenario 的 initial 与 replacement PNG 均不同，配对的实际 2×2 background PNG 也不同。

初始像素回读均为 `[187,0,0,128, 0,129,0,128, 0,0,34,128, 42,129,102,128]`；按 authored scene 的独立公式重算，第一红色字节为 188，其余相同。按原测试的预乘 RGBA8 比较规则，两者差值全部为 0，没有改变容差。换源回读为四组 `[0,255,0,128]`，同样与重算结果相符。这里接受的是实际 Canvas 表示及其原有一字节预乘容差，没有要求错误的非预乘逐字节绝对相等。

16 个检查点均记录一个活动 source subscription、borrowedDisposals 0、sourceAvailable true、无嵌入 canvas、16 个当前活跃 GPU 资源、duplicates／waiting 0；所有对应场景结束后资源归零。runtime 的前置重放可能增加累计 created／deleted 和 release 计数，未把这些累计数伪装为与 compiled 相同。sceneState 不含数字 revision 字段；换源关联来自真实执行顺序、像素数据及准确的 checkpoint 名称。

**明确保留的视觉范围差异：WC 的绘制区域紧贴控件，React／Vue／Vue2 是更宽更高的矩形。** 这组截图证明各自 fixture 上确实绘制并换源，且文字未裁切，不证明跨宿主布局相同。本观察不新增一个发布门槛。

## 证据增强的静态核对

`996a2a35b9d9ca19e8d0def7c9b6040fb8afe714` 只改测试文件。去掉 captureScenePaint 观察 helper、两个调用和仅用于复用的 name 变量后，原文件逐字节恢复。37 条分母、所有原断言、测试名和 deadline 未变；检查点分别位于已经通过 ready／像素 oracle 后的 initial 与 replacement 阶段。额外读取没有调用 source draw／revoke 或修改 owner。

`c1f0332eed6ba79734b92bd4407b274f45d5c274` 的上传配置仅增加说明注释和 `include-hidden-files: true`；路径仍限制在 `${{ runner.temp }}/shader-presentation`，凭据隔离与 checkout 配置未变。本轮保全的 70 个生成支持文件证实了这一有界修复。

## 首轮缺口的处理与剩余边界

原 `9fff` / 45262028723 的功能 37/37 结果继续有效；该轮仅保全 36/106 生成产物，八张 scene 终态图不显示 active paint。这些原始缺口和数字均未改写。后继 c1 原件补齐了产物和中间态原图，不能倒写为首轮原本完整。

首轮审查 JSON SHA256 仍为 `7d2d288bb652da4d25b372d13d2b55354077a6a1018add41b70eb11772b46888`；首轮 Markdown 与归档 hash 也保持原值。

本次委派的有界检查没有尚未处理的失败。仍不能由这组结果推出物理 GPU 性能、跨宿主几何一致性、整套 optical fidelity、真实 AT、所有非 Web 目标或整个 Sprint 4 的关闭。SwiftShader 是软件 WebGL renderer。后续预算数值和最终 head 的严格 CI 由对应工作流另行绑定，本报告不把 c1 的执行外推到后续提交。

## 完整的 37 个 fullName

1. `'inline' 'react' 'runtime' uses real WebGL2, preserves children/input, and retires each view` — passed。
2. `'inline' 'react' 'compiled' uses real WebGL2, preserves children/input, and retires each view` — passed。
3. `'inline' 'vue' 'runtime' uses real WebGL2, preserves children/input, and retires each view` — passed。
4. `'inline' 'vue' 'compiled' uses real WebGL2, preserves children/input, and retires each view` — passed。
5. `'inline' 'vue2' 'runtime' uses real WebGL2, preserves children/input, and retires each view` — passed。
6. `'inline' 'vue2' 'compiled' uses real WebGL2, preserves children/input, and retires each view` — passed。
7. `'inline' 'wc' 'runtime' uses real WebGL2, preserves children/input, and retires each view` — passed。
8. `'inline' 'wc' 'compiled' uses real WebGL2, preserves children/input, and retires each view` — passed。
9. `'static-data' 'react' 'runtime' uses real WebGL2, preserves children/input, and retires each view` — passed。
10. `'static-data' 'react' 'compiled' uses real WebGL2, preserves children/input, and retires each view` — passed。
11. `'static-data' 'vue' 'runtime' uses real WebGL2, preserves children/input, and retires each view` — passed。
12. `'static-data' 'vue' 'compiled' uses real WebGL2, preserves children/input, and retires each view` — passed。
13. `'static-data' 'vue2' 'runtime' uses real WebGL2, preserves children/input, and retires each view` — passed。
14. `'static-data' 'vue2' 'compiled' uses real WebGL2, preserves children/input, and retires each view` — passed。
15. `'static-data' 'wc' 'runtime' uses real WebGL2, preserves children/input, and retires each view` — passed。
16. `'static-data' 'wc' 'compiled' uses real WebGL2, preserves children/input, and retires each view` — passed。
17. `compares copy and tint GPU readback with an independent linear premultiplied oracle` — passed。
18. `missing host failure preserves opaque fallback and releases partial resources in reverse` — passed。
19. `compile host failure preserves opaque fallback and releases partial resources in reverse` — passed。
20. `allocation host failure preserves opaque fallback and releases partial resources in reverse` — passed。
21. `context loss exposes fallback and restored old context cannot publish again` — passed。
22. `a decoded image from a retired view never publishes after release` — passed。
23. `throwing preparation invalidates the old decoded image before fallback publication` — passed。
24. `cleanup reentry publishes only the newer generation and cannot erase its lease` — passed。
25. `late decode failure never overwrites an external paint owner during fallback, recommit or cleanup` — passed。
26. `a newer revision detects external ownership before retiring the still-pending old decode` — passed。
27. `capability override and reset reacquire fallback without reviving a released binding` — passed。
28. `late decode and release from an overridden capability cannot affect its reacquired GPU lease` — passed。
29. `'react' 'runtime' borrows an actual app scene across held decode, revoke, replacement and scope retirement` — passed。
30. `'react' 'compiled' borrows an actual app scene across held decode, revoke, replacement and scope retirement` — passed。
31. `'vue' 'runtime' borrows an actual app scene across held decode, revoke, replacement and scope retirement` — passed。
32. `'vue' 'compiled' borrows an actual app scene across held decode, revoke, replacement and scope retirement` — passed。
33. `'vue2' 'runtime' borrows an actual app scene across held decode, revoke, replacement and scope retirement` — passed。
34. `'vue2' 'compiled' borrows an actual app scene across held decode, revoke, replacement and scope retirement` — passed。
35. `'wc' 'runtime' borrows an actual app scene across held decode, revoke, replacement and scope retirement` — passed。
36. `'wc' 'compiled' borrows an actual app scene across held decode, revoke, replacement and scope retirement` — passed。
37. `the unchanged default scene export retains an opaque fallback without a source capability` — passed。

## 复核文件

同目录 `audit-successor-browser.py` 是仅使用原件、Git blob、PNG 读取的复核脚本；`successor-browser-audit.json` 保留 250 个 archive member、37 个名称、37 份 scenario receipt、16 份逐图 hash 和观察、源绑定及限制。重新运行脚本不启动浏览器，也不修改仓库。

此报告所标的图片 `viewed: true` 来自本次逐张实际查看；自动化脚本只复算原件的大小、哈希和记录。视觉意见不等同于自动像素检查。
