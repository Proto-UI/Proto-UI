# Sprint 4：首轮浏览器原件与证据补充的独立复核

## 结论与版本

首轮 [Actions 45262028723](https://github.com/Proto-UI/Proto-UI/actions/runs/45262028723)
在 `9fff88cf23d4e55375979bc5c68c033e3deaed38` 上的 **37 条功能旅程全部真实通过**，
未发现替换用例、缺失目标或源码绑定不符。此结论保留原执行 SHA 和 GitHub runner 路径。
本次仅回读原件，没有重新运行 Chrome，也没有修改 root 工作树或 GitHub。

首轮的两个证据缺口仍然成立：八张 scene 图都是 dispose 后的终态；生成文件清单有
106 项，但原上传／传回材料只有 36 项，缺少 70 个 `.proto-ui` 支持文件。这不把已经
执行的 37 条功能结果改成失败，也不允许把原件完整性或 active paint 视觉审阅写成通过。

后继修改已作静态复核：

- `996a2a35b9d9ca19e8d0def7c9b6040fb8afe714` 仅在八条原 scene 旅程中增加
  initial/replacement 的 PNG 和观察 JSON。去除新观察 helper、两次调用及仅用于命名的
  局部变量后，可逐字节恢复原测试文件；原断言、名称、分母和 deadline 没有改变。
- `c1f0332eed6ba79734b92bd4407b274f45d5c274` 在 uploader 中增加说明和
  `include-hidden-files: true`，上传路径仍是 `${{ runner.temp }}/shader-presentation`。
  没有扩大到 checkout、依赖目录或凭据环境；`env -i` 和 checkout 的
  `persist-credentials: false` 保持原样。

这些是修复来源，**不是后继 CI 已执行或已验收的证明**。

## 实际核对

| 范围 | 原件结果及本次核对 |
| --- | --- |
| 用例选择 | 28 个原旅程 + 9 个 scene 旅程，37 个唯一 `fullName` 与该提交的固定清单完全相同；37 passed，0 failed/pending/todo |
| 三份 fixture | inline、static-data、scene 各包含 React、Vue、Vue2、WC 的正确 profile；各目标消费同一 authored source |
| 源码 | 每份 manifest 的 194 个 Compiler generator 文件均匹配 immutable Git blobs；generator 汇总 hash 重算相符 |
| 所有追踪输入 | 共核对 608 个去重的 immutable source blobs，包括源图、harness 和可识别的仓库内 bundle 输入；字节数及 SHA 相符 |
| 实际 bundle | 三份 `entry.ts`、`client.js` 的字节与 manifest 的 SHA 相符；lock witness 与原提交一致 |
| 原件归档 | 148 个实际留存文件逐字节匹配压缩归档；没有把“148 文件”解释为生成清单完整 |
| 隔离 | 非 root、五组 capabilities 均为 0、仅 loopback、无默认路由；user/net namespace 与父命名空间不同；固定 harness 保留 Chromium sandbox |
| scene 清理 | 八条终态 observation 均无 active background/children，已创建资源与已删除资源相等，live/duplicate/waiting 均为 0 |
| renderer | 原件记录的是 SwiftShader software WebGL；没有物理 GPU 或性能结论 |

全部原 report 字节和执行路径均未重写。原包 SHA-256 为
`17ae69acf4266e38118df78784368eb7655a3e3b01700edc62884526f8911856`，大小 2,805,045 字节。
该内容校验针对实际提供的原件，不构成额外的 GitHub 密码学认证。

## 生成文件完整性

| Fixture | 声明 generated artifacts | 留存且逐 hash 相符 | 缺失 |
| --- | ---: | ---: | ---: |
| inline | 34 | 12 | 22 |
| static-data | 34 | 12 | 22 |
| scene | 38 | 12 | 26 |
| 合计 | 106 | 36 | 70 |

70 个缺失文件全部位于 `.proto-ui` 隐藏目录。后继 upload 配置修复后，下载到本机的
转运枚举仍需包含隐藏文件；普通 `rg --files` 也会漏掉它们。应在专用证据目录使用
包含隐藏文件的枚举，并将下载及归档中的所有 106 项逐字节与 manifest 对账。
不能重新生成这 70 项，再把它们称为首轮实际上传的原件。

## 逐图观察

实际用 `view_image` 打开了四个目标 × Runtime/compiled 的八张 scene 终态 PNG，
以及默认未配置源的 fallback PNG。图像大小为 640 × 360。

八张终态图都显示白色页面和 `Actual shader consumer` 标题，组件已退休。图像与
终态 JSON 的空 background/children 以及资源清理结果相符；它们可以说明已观察的
清理后页面，不能显示 shader 生效时的颜色、实际背景绘制或换源结果。

fallback 图在标题下保留深色不透明底层和可读的 ordinary/slot child 控件。
对应 JSON 为 `background: none`、fallback `rgb(38, 51, 64)`、零 GPU attempts/live。
这仅接受该 fixture 的未配置源 fallback 可见状态，不外推完整可访问性、所有家族、
主题、缩放或真实辅助技术读取。

逐图 SHA、逐场景资源计数、全部 70 个缺失路径及检查明细位于
`first-browser-audit.json`。

## 剩余的具体动作

1. 对后继提交的真实 CI 原件，检查相同 37 个用例和三份四目标构建身份。
2. 回读 106 个 generated artifacts，逐 hash 验证隐藏支持文件已实际留存。
3. 打开 8 × 2 个 initial/replacement PNG，关联相应 JSON 的 source revision、pixels、
   host observation 和 build hash，单独给出限定视觉结论。
4. 保留首轮终态图、缺失文件清单和原 functional success；不回写历史成完整接受。

本报告是有界的本地事实与源码复核材料，未生成 canonical v5 PR review-input、
正式 GitHub review packet、APPROVE、merge 或全 Sprint 4 完成结论。
