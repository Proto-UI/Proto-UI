from pathlib import Path, PurePosixPath
import datetime
import hashlib
import io
import json
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/1494db44bb7b/Proto-UI')
SCRATCH = ROOT.parent
OUT = SCRATCH / 'sprint4-final-acceptance-1494'
HEAD = '9fff88cf23d4e55375979bc5c68c033e3deaed38'
CAPTURE = '996a2a35b9d9ca19e8d0def7c9b6040fb8afe714'
UPLOAD = 'c1f0332eed6ba79734b92bd4407b274f45d5c274'
EVIDENCE = SCRATCH / 'integration-evidence/scene-browser-originals/shader-presentation-9fff88cf23d4e55375979bc5c68c033e3deaed38-45262028723-1'
ARCHIVE = SCRATCH / 'integration-evidence/scene-browser-originals.tar.gz'
SUITE = 'packages/compiler/test/shader-presentation.browser.test.ts'
SELECTION = 'scripts/test/shader-browser-selection.json'
EMPTY = hashlib.sha256(b'').hexdigest()
EXPECTED_PROFILES = [('react', 'react-dom-source-v1'), ('vue', 'vue-source-v1'), ('vue2', 'vue2-source-v1'), ('wc', 'web-component-source-v1')]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def blob(revision, path):
    return git('show', revision + ':' + path)

def loaded(path):
    return json.loads(path.read_bytes())

def evidence_file(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(EVIDENCE)), 'bytes': len(data), 'sha256': sha(data)}

OUT.mkdir(exist_ok=True)
observed_head = git('rev-parse', 'HEAD').decode().strip()
archive = ARCHIVE.read_bytes()
assert len(archive) == 2805045
assert sha(archive) == '17ae69acf4266e38118df78784368eb7655a3e3b01700edc62884526f8911856'
archive_files = []
with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tar:
    for member in tar.getmembers():
        path = PurePosixPath(member.name)
        assert not path.is_absolute() and '..' not in path.parts and member.isfile()
        original = tar.extractfile(member).read()
        assert original == (EVIDENCE.parent / member.name).read_bytes()
        archive_files.append({'path': member.name, 'bytes': len(original), 'sha256': sha(original)})
assert len(archive_files) == len({x['path'] for x in archive_files}) == 148

selection_bytes = blob(HEAD, SELECTION)
selection = json.loads(selection_bytes)
expected_names = selection['originalJourneys'] + selection['sceneJourneys']
assert len(selection['originalJourneys']) == 28 and len(selection['sceneJourneys']) == 9
assert len(expected_names) == len(set(expected_names)) == 37
report = loaded(EVIDENCE / 'browser-vitest.json')
assert report['success'] and report['numTotalTests'] == report['numPassedTests'] == 37
assert report['numFailedTests'] == report['numPendingTests'] == report['numTodoTests'] == 0
assert len(report['testResults']) == 1
suite = report['testResults'][0]
assert suite['name'] == '/home/runner/work/Proto-UI/Proto-UI/' + SUITE
assert suite['status'] == 'passed'
assert len(suite['assertionResults']) == 37
assert sorted(x['fullName'] for x in suite['assertionResults']) == sorted(expected_names)
assert all(x['status'] == 'passed' and not x['failureMessages'] for x in suite['assertionResults'])

build_paths = sorted((EVIDENCE / 'browser').glob('*/build.json'))
assert len(build_paths) == 3
build_data = [(path, loaded(path)) for path in build_paths]
source_paths = {'pnpm-lock.yaml', SELECTION, SUITE}
for path, build in build_data:
    source_paths.update(x['file'] for x in build['sourceGenerator']['files'])
    source_paths.update(build['harness'])
    source_paths.update(x for x in build['inputs'] if x.startswith(('packages/', 'scripts/')))
    for compilation in build['compilations']:
        source_paths.update(x['file'] for x in compilation['sourceFiles'])
source_paths = sorted(source_paths)
proc = subprocess.run(['git', 'cat-file', '--batch'], cwd=ROOT,
                      input=''.join(HEAD + ':' + path + '\n' for path in source_paths).encode(),
                      capture_output=True, check=True)
stream = io.BytesIO(proc.stdout)
blobs = {}
for path in source_paths:
    header = stream.readline().decode().strip().split()
    assert len(header) == 3 and header[1] == 'blob', (path, header)
    data = stream.read(int(header[2])); assert stream.read(1) == b'\n'
    blobs[path] = data
assert stream.read() == b''

builds = []
seen_entries = []
all_missing = []
for path, build in build_data:
    directory = path.parent
    candidate = build['candidate']
    assert candidate['head'] == HEAD and candidate['headTree'] == git('rev-parse', HEAD + '^{tree}').decode().strip()
    assert candidate['dirty'] is False and candidate['statusSha256'] == candidate['trackedDiffSha256'] == EMPTY
    generator = build['sourceGenerator']
    assert len(generator['files']) == len({x['file'] for x in generator['files']}) == 194
    assert sha(json.dumps(generator['files'], separators=(',', ':'), ensure_ascii=False).encode()) == generator['sha256']
    for source in generator['files']:
        assert source['file'].startswith('packages/compiler/src/') and source['file'].endswith('.ts')
        actual = blobs[source['file']]
        assert len(actual) == source['bytes'] and sha(actual) == source['sha256']
    assert sha(blobs['pnpm-lock.yaml']) == build['lockSha256']
    for file, digest in build['harness'].items(): assert sha(blobs[file]) == digest
    assert sha((directory / 'entry.ts').read_bytes()) == build['entrySha256']
    assert sha((directory / 'client.js').read_bytes()) == build['bundleSha256']
    assert sorted((x['target'], x['profile']) for x in build['compilations']) == EXPECTED_PROFILES
    entries = {x['entry'] for x in build['compilations']}; assert len(entries) == 1
    seen_entries.extend(entries)
    assert len({x['sourceSha256'] for x in build['compilations']}) == 1
    assert all(x['sourceFiles'] == build['compilations'][0]['sourceFiles'] for x in build['compilations'])
    for compilation in build['compilations']:
        for source in compilation['sourceFiles']:
            data = blobs[source['file']]
            assert len(data) == source['bytes'] and sha(data) == source['sha256']
    retained, missing = [], []
    for artifact in build['artifacts']:
        relative = PurePosixPath(artifact['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        file = directory / artifact['path']
        if file.exists():
            data = file.read_bytes(); assert len(data) == artifact['bytes'] and sha(data) == artifact['sha256']
            retained.append(artifact)
        else:
            assert '.proto-ui' in relative.parts
            missing.append(artifact)
            all_missing.append({'fixture': directory.name, **artifact})
    input_counts = {'trackedSourceVerified': 0, 'generatedVerified': 0, 'generatedMissing': 0, 'externalManifestOnly': 0}
    for file, digest in build['inputs'].items():
        if file in blobs:
            assert sha(blobs[file]) == digest; input_counts['trackedSourceVerified'] += 1
        elif file.startswith('../../_temp/shader-presentation/browser/' + directory.name + '/'):
            relative = file.split('/browser/' + directory.name + '/', 1)[1]
            assert '..' not in PurePosixPath(relative).parts
            target = directory / relative
            if target.exists():
                assert sha(target.read_bytes()) == digest; input_counts['generatedVerified'] += 1
            else:
                assert '.proto-ui' in PurePosixPath(relative).parts
                input_counts['generatedMissing'] += 1
        else:
            assert file.startswith('node_modules/'), file
            input_counts['externalManifestOnly'] += 1
    builds.append({'fixture': directory.name, 'build': evidence_file(path), 'sourceGeneratorFilesVerified': 194,
                   'sourceGeneratorSha256': generator['sha256'], 'profiles': EXPECTED_PROFILES,
                   'entry': next(iter(entries)), 'artifactDeclared': len(build['artifacts']),
                   'artifactRetainedAndHashVerified': len(retained), 'artifactMissing': len(missing),
                   'bundleSha256': build['bundleSha256'], 'entrySha256': build['entrySha256'],
                   'inputChecks': input_counts, 'node': build['node'], 'esbuild': build['esbuildVersion']})
assert sorted(seen_entries) == sorted(selection['fixtures'])
assert sum(x['artifactDeclared'] for x in builds) == 106
assert sum(x['artifactRetainedAndHashVerified'] for x in builds) == 36
assert len(all_missing) == 70

prepare = loaded(EVIDENCE / 'isolation-prepare.json')
isolation = loaded(EVIDENCE / 'isolation-run.json')
assert prepare['exitCode'] == 0 and prepare['outcome'] == isolation['outcome'] == 'ready'
assert isolation['uid'] != 0 and all(int(x, 16) == 0 for x in isolation['capabilities'].values())
assert len(isolation['links']) == 1 and isolation['links'][0]['ifname'] == 'lo'
assert isolation['ipv4DefaultRoutes'] == isolation['ipv6DefaultRoutes'] == ''
assert isolation['userNamespace'] not in prepare['command'] and isolation['networkNamespace'] not in prepare['command']
for name in ['source-prepare.json', 'source-run.json', 'isolation-prepare.json', 'isolation-run.json', 'receipt.json']:
    d = loaded(EVIDENCE / name)
    assert d['candidateSha'] == HEAD and d['selectionSha256'] == sha(selection_bytes)
    assert d['expectedCases'] == 37
assert b'chromiumSandbox: true' in blobs[SUITE]

capture_old = blobs[SUITE].decode()
capture_new = blob(CAPTURE, SUITE).decode()
recovered = capture_new
start = recovered.index('async function captureScenePaint(')
end = recovered.index('it.each(sceneCases)(', start)
recovered = recovered[:start] + recovered[end:]
recovered = recovered.replace('    const name = `scene-${scenario.target}-${scenario.execution}`;\n', '', 1)
recovered = recovered.replace('      name,\n', '      `scene-${scenario.target}-${scenario.execution}`,\n', 1)
for phase in ['initial-paint', 'replacement-paint']:
    recovered = recovered.replace("        await captureScenePaint(page, name, '" + phase + "');\n", '', 1)
assert recovered == capture_old
assert git('diff', '--name-only', HEAD, CAPTURE).decode().splitlines() == [SUITE]
assert blob(HEAD, SELECTION) == blob(CAPTURE, SELECTION)

workflow = '.github/workflows/shader-presentation-evidence.yml'
old_workflow = blob('e15c2c4912fd7c748682c1b094cad81f9cfa315e', workflow)
new_workflow = blob(UPLOAD, workflow)
addition = b'          # Include .proto-ui generated support from this isolated evidence directory.\n          include-hidden-files: true\n'
assert new_workflow.replace(addition, b'', 1) == old_workflow
assert b'path: ${{ runner.temp }}/shader-presentation' in new_workflow
assert b'env -i PATH=' in new_workflow and b'persist-credentials: false' in new_workflow

scene = EVIDENCE / 'browser/shader-presentation-scene-yrWqQb'
images, observations = [], []
for target in ['react', 'vue', 'vue2', 'wc']:
    for execution in ['runtime', 'compiled']:
        name = f'scene-{target}-{execution}'
        d = loaded(scene / (name + '.json')); resources = d['resources']
        assert d['head'] == HEAD and d['outcome'] == 'PASS'
        assert not d['errors'] and not d['blocked']
        assert resources['created'] == resources['deleted'] and resources['live'] == resources['duplicates'] == resources['waiting'] == 0
        assert all('SwiftShader' in x for x in resources['renderers'])
        assert d['observation']['background'] is None and d['observation']['buttonTexts'] == []
        images.append({**evidence_file(scene / (name + '.png')), 'viewed': True, 'observed': '640x360 white page with only the Actual shader consumer heading; fixture already disposed.'})
        observations.append({'scenario': name, 'resourceCreatedAndDeleted': resources['created'], 'live': 0, 'duplicates': 0, 'waiting': 0, 'observation': d['observation']})
fallback = loaded(scene / 'scene-default-unconfigured.json')
assert fallback['observation']['background'] == 'none' and fallback['observation']['fallback'] == 'rgb(38, 51, 64)'
assert fallback['resources']['attempts'] == fallback['resources']['live'] == 0
images.append({**evidence_file(scene / 'scene-default-unconfigured.png'), 'viewed': True, 'observed': '640x360 fixture with heading and a readable ordinary/slot-child control on an opaque dark fallback surround.'})

result = {'schemaVersion': 1, 'kind': 'independent bounded browser artifact and capture-change audit',
          'reviewer': '/root/sprint4_final_acceptance', 'observedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'actualBrowserHead': HEAD, 'actualBrowserRun': 'https://github.com/Proto-UI/Proto-UI/actions/runs/45262028723',
          'captureChangeHead': CAPTURE, 'uploadChangeHead': UPLOAD, 'observedRootHeadAtStart': observed_head,
          'observedRootHeadAtEnd': git('rev-parse', 'HEAD').decode().strip(), 'rootModifiedByThisAudit': False,
          'browserRerunByThisAudit': False, 'canonicalPrReviewPacketProduced': False, 'githubReviewSubmitted': False,
          'archive': {'path': str(ARCHIVE), 'bytes': len(archive), 'sha256': sha(archive), 'retainedFilesMatched': len(archive_files)},
          'functional': {'report': evidence_file(EVIDENCE / 'browser-vitest.json'), 'uniqueCases': 37, 'passed': 37, 'failed': 0,
                         'pending': 0, 'todo': 0, 'fullNamesExactlyMatchCommittedSelection': True,
                         'originalExecutionPathRetained': suite['name']},
          'builds': builds, 'immutableSourceBlobsChecked': len(blobs), 'missingGeneratedArtifacts': all_missing,
          'isolation': {'nonRoot': True, 'capabilitiesAllZero': True, 'loopbackOnly': True, 'noDefaultRoutes': True,
                        'userAndNetworkNamespacesDifferFromParent': True, 'chromiumSandboxEnabledInExactHarness': True},
          'captureDiff': {'onlyTestFileChanged': True, 'removingNewObservationHelperAndTwoCallsRecoversOriginalBytes': True,
                          'assertionsNamesAndDeadlinesUnchanged': True, 'unrunAtThisPoint': True},
          'uploadDiff': {'onlyTwoWorkflowLinesAdded': True, 'uploadsOnlyExistingIsolatedEvidenceDirectory': True,
                         'credentialFreeExecutionAndCheckoutUnchanged': True, 'artifactCompletenessStillNeedsSuccessorReadback': True},
          'images': images, 'terminalSceneObservations': observations,
          'findings': [
              {'id': 'S4-CI-VISUAL-001', 'status': 'successor-source-prepared-result-pending', 'kind': 'verification',
               'observation': 'All eight original scene pictures show disposed state; no active paint is visible.',
               'nextAction': 'Inspect source-bound initial and replacement pictures from the successor run; preserve these terminal pictures.'},
              {'id': 'S4-CI-ARTIFACT-001', 'status': 'successor-source-prepared-result-pending', 'kind': 'verification',
               'observation': '106 generated artifacts are declared, only 36 are retained; all 70 missing paths are in .proto-ui support directories.',
               'nextAction': 'Upload and transfer hidden evidence files and verify all 106 hashes in the downloaded successor archive.'}
          ],
          'limitations': ['This is local factual evidence review, not a canonical GitHub v5 review-input/APPROVE packet.',
                          'The first run remains a genuine 37-case functional success. Missing artifacts and paint-state pictures remain separate verification gaps.',
                          'External node_modules bytes are preserved by the input hashes and lock witness; this audit did not fetch or independently reexecute dependencies.',
                          'SwiftShader proves software WebGL execution, not physical GPU performance, all target support, AT or whole Sprint 4 acceptance.',
                          'The original report path and original bytes were not rewritten. Archive integrity is checked against supplied raw originals, not a separate cryptographic attestation of GitHub.']}
(OUT / 'first-browser-audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': str(OUT / 'first-browser-audit.json'), 'uniqueCasesPassed': 37, 'fixtures': len(builds),
                  'profilesPerFixture': 4, 'immutableSourceBlobsChecked': len(blobs), 'artifactsDeclared': 106,
                  'artifactsPresentAndVerified': 36, 'artifactsMissing': 70, 'picturesViewed': len(images),
                  'captureAssertionsUnchanged': True, 'uploadScopeUnchanged': True}, ensure_ascii=False))
