from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,tarfile,base64,traceback
p=Path('/tank/shared/projects/proto-ui-agent/sprint4-completion-20261124-1494')
o=p/'final-platform-closeout';o.mkdir()
h=p/'final-collaboration-tools';payload=json.loads((h/'payload-compatible-gh.json').read_text())
head='c18bf8f8c35a4ec1f69791468a5952c4cb460f41'
env=dict(os.environ);env.update(PATH=payload['runtimeBin']+os.pathsep+str(p/'github-cli-recovery-v2/runtime/bin')+os.pathsep+env.get('PATH',''),COREPACK_HOME=str(p/'corepack'),COREPACK_ENABLE_DOWNLOAD_PROMPT='0')
node=str(Path(payload['runtimeBin'])/'node');cp=str(Path(payload['runtimeBin'])/'corepack');repo=p/payload['repositoryPath']
def sha(b):return hashlib.sha256(b).hexdigest()
def load(f):return json.loads(f.read_text())
def save(f,x):
 with f.open('x') as out:json.dump(x,out,indent=2);out.write('\n')
def run(label,args,timeout=600):
 r=subprocess.run(args,cwd=repo,env=env,capture_output=True,timeout=timeout)
 (o/(label+'.stdout')).write_bytes(r.stdout);(o/(label+'.stderr')).write_bytes(r.stderr)
 save(o/(label+'.command.json'),{'argv':args,'exitCode':r.returncode,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 assert r.returncode==0,label
 return r.stdout
def trailing(data):
 s=data.decode()
 for i,c in enumerate(s):
  if c=='{':
   try:
    x,end=json.JSONDecoder().raw_decode(s[i:])
    if not s[i+end:].strip():return x
   except ValueError:pass
 raise ValueError('no trailing JSON')
try:
 j=load(p/payload['outputDirectory']/'journal.json')
 assert len(j['operations'])==17 and all(x['state'] in ['verified','observed-already-present'] for x in j['operations'].values())
 assert j['operations']['ready']['state'] in ['verified','observed-already-present']
 run('canonical-collect',[node,str(h/'final-collaboration-helper.mjs'),'collect-pr',str(repo),str(p/payload['externalEvidence']['path']),str(o)])
 x=load(o/'review-input.json');snapshot=load(o/'github-snapshot.json');pr=snapshot['pullRequest']
 assert x['headSha']==head and x['isDraft'] is False and x['pullRequestState']=='OPEN'
 assert pr['title']==payload['prTitle'] and pr['body']==(p/payload['prBody']['path']).read_text() and not pr['merged']
 indexpath=p/payload['progressIndex']['path'];index=load(indexpath);progress=[]
 for c in index['comments']:
  found=[v for v in x['comments'] if c['marker'] in v['body']];assert len(found)==1 and found[0]['author']=='cyjin-yl'
  body=(indexpath.parent.parent/c['path']).read_text()
  assert re.fullmatch(re.escape(body)+r'(?:\n\n<!-- proto-ui-collaboration:[a-f0-9]{64} -->)?\Z',found[0]['body'])
  progress.append({'sha':c['sha'],'id':found[0]['id'],'bodySha256':sha(found[0]['body'].encode())})
 digest=trailing(run('review-input-digest',[cp,'pnpm@10.32.1','agent:review','--','input-digest','--input',str(o/'review-input.json')]))
 assert digest['valid'];save(o/'review-input-digest.json',digest)
 expected={'891':'369663b015794be673f37ce8a2fb3585b305d3585b41255741807236dbdfe258','892':'758d54d313510ea9d47f7e47948c9a4f85e392857aa309dbf7c8fadd7e9fffcf','893':'c5cf7caf01369952d616fd5cd8e17c0a60fdf7b19fd392e97f58638c96a7174a','894':'8effaa714f9be7f1655bf7bb7b9f17dae4442bb7f2e34cc10b3f92219a8baded','913':'959779d35d6e4e26a3be06241c0690de7db1f44962534edd71370965ac90d02f','914':'2a4369c09a32b6f24208ef07d162ba272f8d947557492ec13be0c15b33166679','915':'9a2a916068170a1fd845731f35c80eb2adb983910edc7e760f0c580ca00368e3'}
 expected.update({str(a['number']):a['body']['sha256'] for a in payload['issues']})
 issues=[]
 for n,d in expected.items():
  item=json.loads(run('issue-'+n,['gh','api','repos/Proto-UI/Proto-UI/issues/'+n]))
  actual=sha(item['body'].encode());assert actual==d and item['state']=='open' and not item.get('pull_request')
  issues.append({'number':int(n),'url':item['html_url'],'state':item['state'],'updatedAt':item['updated_at'],'bodySha256':actual,'preparedBodyMatches':True})
 groups={}
 for c in x['checks']:groups.setdefault(c['conclusion'] or c['status'],[]).append(c['name'])
 result={'kind':'sprint4.final-platform-readback','observedAt':snapshot['observedAt'],'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repositoryId':x['repositoryId'],'pullRequest':1754,'url':pr['html_url'],'headSha':head,'baseSha':x['baseSha'],'isDraft':False,'merged':False,'reviewInputDigest':digest['reviewInputDigest'],'progressComments':progress,'commentCount':len(x['comments']),'formalReviewCount':len(x['reviews']),'reviewThreadCount':len(x['threads']),'checks':groups,'issues':issues,'journalOperationCount':17,'journalSha256':sha((p/payload['outputDirectory']/'journal.json').read_bytes()),'claims':{'boundedImplementationReadyForReview':True,'allSprint4Complete':False,'privateIR10Replayed':False,'formalApprovalManufactured':False,'mergePerformed':False}}
 save(o/'receipt.json',result)
 transfer=p/'final-collaboration-receipts-transfer';transfer.mkdir()
 files=[]
 roots=['final-collaboration-results','final-collaboration-results-compatible-gh','final-collaboration-tools','final-collaboration-inputs','github-cli-recovery-v2','final-platform-closeout','tracking-results']
 for root in roots:
  folder=p/root;assert folder.is_dir()
  names=subprocess.check_output(['rg','--files','--hidden','--no-ignore',str(folder)],text=True).splitlines()
  for name in names:
   f=Path(name);relative=f.relative_to(p)
   if root=='github-cli-recovery-v2' and len(relative.parts)>2:continue
   assert f.is_file() and not f.is_symlink()
   files.append(f)
 files.append(p/'collect-final-platform-closeout.py')
 files=sorted(set(files))
 manifest={'kind':'sprint4.collaboration-originals','headSha':head,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'members':[{'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f in files]}
 save(transfer/'manifest.json',manifest)
 archive=transfer/'originals.tar.gz'
 with tarfile.open(archive,'w:gz') as t:
  for f in files:t.add(f,arcname=str(f.relative_to(p)),recursive=False)
 blob=archive.read_bytes();encoded=base64.b64encode(blob).decode()
 chunks=[]
 for i in range(0,len(encoded),600000):
  name='part-'+str(i//600000).zfill(3)+'.base64';part=encoded[i:i+600000];(transfer/name).write_text(part)
  chunks.append({'name':name,'characters':len(part),'sha256':sha(part.encode())})
 meta={'archive':'originals.tar.gz','bytes':len(blob),'sha256':sha(blob),'members':len(files),'uncompressedBytes':sum(f.stat().st_size for f in files),'manifestSha256':sha((transfer/'manifest.json').read_bytes()),'chunks':chunks}
 save(transfer/'transport.json',meta)
 print(json.dumps({'outcome':'verified-and-archived','readback':result,'transport':meta}),flush=True)
except Exception as error:
 save(o/'stopped.json',{'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'error':str(error),'externalWrites':0})
 traceback.print_exc();raise
