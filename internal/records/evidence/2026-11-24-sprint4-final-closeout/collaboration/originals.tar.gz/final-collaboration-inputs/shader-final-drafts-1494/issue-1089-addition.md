<!-- proto-ui:sprint4:shader-two-slices:20261124:1089:v4:begin -->

## 2026-11-24 Sprint 4：独立定义、纯源与应用 source 接续

Agent: ChatGPT，按当前用户“补完 Sprint 4”的授权核对。原公共交付 [PR #1714](https://github.com/Proto-UI/Proto-UI/pull/1714) 已合入 `3551b85049630877e8c062b4d80a56ec2133c532`；本轮接续为 [PR #1754](https://github.com/Proto-UI/Proto-UI/pull/1754)，本段浏览器与归档实际执行仍绑定 `c1f0332eed6ba79734b92bd4407b274f45d5c274`；当前独立数值提交为 `c18bf8f8c35a4ec1f69791468a5952c4cb460f41`，本地 245 条整合仍绑定 `9fff88cf`。原八项完整条件保持原分母，以下只回填具有来源的子项。

两片 shader 实现以当前 draft C/HC/T 定义为依据：纯源码只包含有限数据与 source slot；应用 DOM/provider 通过独立 host capability 进入四 Runtime Adapter 和四 native factory，不进入 portable Props/IR。Compiler 保持直接 lowering，按 reached 能力生成共享第一方 atoms，不携带 proof evaluator、组件协议或 graph interpreter。此处不提升 spec lifecycle。

下方原 body 与既有评论保留其历史时点。既有消费者记录继续有效，但它们的暂时迁移、正式采用、真实窗口/输入/AT 和 distribution 接受分别记录。

- [x] **原独立定义与有界组合证据已合入。** 未修改 authored `asTransition`、独立 oracle、无 DOM Runtime 与四 Web native target 的原 15/15 旅程，以及独立 CPU/GPU shader 对照保留原执行 SHA。普通 work 的 root 读取为零与真实声明正控继续保留。
- [x] **原 Shenko/Verdant 消费及许可后继已合入。** Shenko 原应用 `f3fa6f4d`／compiler `c857471` 的 51/51 与 6/6 production frontend，Verdant 原应用 `91a77554`／compiler `ef60557` 的 7/7 与 locked app Cargo check 保留各自来源。`13bd3c3` 的 source-license omission/显式声明及两个真实 Verdant data unit 后继已经完成；AGPL-3.0-or-later 输入及翻译与 Proto-UI SDK/support 的 MIT 继续分开，不再把旧硬编码 MIT 写成未实现，也不声称重新授权或 distribution-ready。
- [x] **两片候选的纯源与独立边界已有本地实现和控制。** 静态 alias/helper/capture proof 有正反例与 cold IR；scene 通过纯 slot 绑定应用 lease，真实无 Web globals Runtime 保留两个旧 fixture 并加入同一 scene fixture，当前共 6/6。Host 实现 scope/revision/color/fallback 与消费方退休，不取得应用 draw/revoke/dispose 权限。
- [x] **本地整合与独立审查结果已准确绑定。** `9fff88cf` 的 17 文件 **245/245**；第一片独立 72/72 保留原执行版本。第二片 **48/48** 绑定 `27b5429b`，其 13 份审查源码与 `9fff88cf` 逐字节一致。Shadow 范围、恢复、factory/cleanup 重入、source-kind 退休和导出冲突的原失败与修复后报告均保留；这些本地控制不替代真实浏览器/GPU。
- [x] **当前 shader 子集的实际 Web 消费与生成原件已取得。** `c1f0332e` 的 [Actions 45266835323](https://github.com/Proto-UI/Proto-UI/actions/runs/45266835323) **37/37**，三份相同 authored fixture 各生成 React/Vue/Vue2/WC 四个 profile；250 件原件含 **106/106** 生成产物和 **16 张 active paint 图＋16 份 JSON**。`9fff88cf` 首轮八张 post-dispose 图与漏传 70 个隐藏支持文件保持历史事实；后继已补采集/归档，本 fixture 的独立视觉结果见下。
- [x] **本 fixture 的 scene 初始／换源视觉已独立接受。** 审阅者实际查看 16 张中间图及 fallback，并核验 608 个唯一源 blob；八对同宿主同阶段 Runtime/compiled 截图逐字节一致。WC 绘制范围与其他三宿主不同，不声称跨宿主几何一致、完整产品视觉、AT 或物理 GPU 性能。<!-- coordinator-slot:visual-review-45266835323:completed-bounded -->
- [x] **改前预算原件与独立数值提交已形成。** `c1f0332e` 的 [Actions 45266820171](https://github.com/Proto-UI/Proto-UI/actions/runs/45266820171) 已独立核验为严格 **6/9、exit 1**；7,831 份测量源文件、3,831 个唯一 closure inputs 与原件均核对。已发布 [数值提交 `c18bf8f8`](https://github.com/Proto-UI/Proto-UI/blob/c18bf8f8c35a4ec1f69791468a5952c4cb460f41/internal/records/2026-11-24-sprint4-scene-package-budget.md)，只将 React/Vue/WC 三个 gzip ceiling 分别由 172600/171400/207200 改为 172800/171600/207400（各 +200），保留原失败及其他测量/阻断条件。<!-- coordinator-slot:canonical-budget-45266820171:verified-red-6-of-9 -->
- [x] **数值提交的改后 canonical CI 已通过并回读原件。** 精确 `c18bf8f8` 的 [Actions 45269915996](https://github.com/Proto-UI/Proto-UI/actions/runs/45269915996) 为严格 **9/9、exit 0**，source clean/exact/stable；九项 minified/gzip/hash/closure 和 diagnostics 与改前相同，只改变三项预算及派生判定字段。<!-- coordinator-slot:canonical-budget-45269915996:verified-green-9-of-9 -->
- [x] **数值提交独立技术审查完成。** 审阅者核验精确 c18 的全部原件、7,831 份来源指纹、3,831 个唯一闭包输入和仅三项数值变化，接受本次有限成本事务；收据 SHA256 为 `fca91f938691c3c210d26f038b5bf9401b460d0d8cd5dcc20b8a3771b8c691ba`。轻量 [CI 45269910724](https://github.com/Proto-UI/Proto-UI/actions/runs/45269910724) 仅四个 job 实际成功、18 skipped；原生 DCO 成功。这不是正式 GitHub APPROVE，主线合入仍未发生。<!-- coordinator-slot:numeric-independent-review-c18bf8f8:completed-bounded -->
- [ ] **当前主线及真实应用接受。** 回填实际 CI/DCO/review 与主线合入。本轮没有更新 Shenko/Verdant 应用 pin，不能把旧临时消费结果改写为新 shader source 的正式采用；既有许可证后继和限定成功保留。
- [ ] **原八项与私有 IR10 完整接受。** 按全部受影响能力完成 source/admission/host boundary、无 Web globals、host leakage、薄 Compiler、忠于定义、独立无补偿组合与消费者接受。原 IR10 packet/pinned inputs、原作者来源和真实贡献认证、共享定义 owner 的精确绑定、13 节点真实 parent/head/build/verify 与完整迁移保持独立；公共语义、重建工具与本轮 agent sign-off 不替代这些条件。

来源：[独立数值事务与改前原件](https://github.com/Proto-UI/Proto-UI/blob/c18bf8f8c35a4ec1f69791468a5952c4cb460f41/internal/records/2026-11-24-sprint4-scene-package-budget.md) · [两片 shader 记录](https://github.com/Proto-UI/Proto-UI/blob/c1f0332eed6ba79734b92bd4407b274f45d5c274/internal/records/2026-11-24-sprint4-owned-scene-shader.md) · [纯静态构造与独立条件映射](https://github.com/Proto-UI/Proto-UI/blob/c1f0332eed6ba79734b92bd4407b274f45d5c274/internal/records/2026-11-24-sprint4-static-shader-data.md) · [原来源和定义边界](https://github.com/Proto-UI/Proto-UI/blob/c1f0332eed6ba79734b92bd4407b274f45d5c274/internal/records/2026-11-24-sprint4-foundation-reconstruction.md) · [已合入真实消费者](https://github.com/Proto-UI/Proto-UI/blob/3551b85049630877e8c062b4d80a56ec2133c532/internal/records/2026-11-22-sprint4-integration.md) · [Verdant source-license 后继](https://github.com/Proto-UI/Proto-UI/blob/3551b85049630877e8c062b4d80a56ec2133c532/internal/records/2026-11-23-sprint4-rust-data-license-metadata.md)。

[本次完整原件、独立审查和可预览原图](https://github.com/Proto-UI/Proto-UI/blob/528ece4cb575a7277981f481ccc0f54dfac8ca70/internal/records/evidence/2026-11-24-sprint4-final-closeout/README.md)；[c18 严格预算及独立接受](https://github.com/Proto-UI/Proto-UI/blob/528ece4cb575a7277981f481ccc0f54dfac8ca70/internal/records/evidence/2026-11-24-sprint4-final-closeout/final-budget.json)。证据单独保存，未改动已验证实现 head。

<!-- proto-ui:sprint4:shader-two-slices:20261124:1089:v4:end -->

---

