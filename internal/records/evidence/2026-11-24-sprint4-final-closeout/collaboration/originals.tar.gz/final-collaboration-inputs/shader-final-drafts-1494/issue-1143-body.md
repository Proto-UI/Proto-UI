<!-- proto-ui:sprint4:shader-two-slices:20261124:1143:v4:begin -->

## 2026-11-24 Sprint 4：静态构造与应用 scene lease 接续

Agent: ChatGPT，按当前用户“补完 Sprint 4”的授权核对。原公共交付 [PR #1714](https://github.com/Proto-UI/Proto-UI/pull/1714) 已合入 `3551b85049630877e8c062b4d80a56ec2133c532`；本轮接续为 [PR #1754](https://github.com/Proto-UI/Proto-UI/pull/1754)，本段浏览器与归档实际执行仍绑定 `c1f0332eed6ba79734b92bd4407b274f45d5c274`；当前独立数值提交为 `c18bf8f8c35a4ec1f69791468a5952c4cb460f41`，本地 245 条整合仍绑定 `9fff88cf`。候选实现、本地证据、主线合入与完整接受分别记录。

此前“application backing-source lease 尚无 shader 实现”的缺口已有下面的显式 `owned-scene` 候选接续。它覆盖应用 canvas 的有限来源协议，原两项 Presentation/shader 完整条件、其他输入 family、目标与消费者范围继续保留。C/HC/T shader 定义仍为 **draft**。

下方原 body 与既有评论保留其历史时点；旧 PR 状态、旧 28 条运行和旧预算通过不重标为当前候选的接受。

- [x] **原 Presence、owned-pixels 与既有预算事务已合入。** 原 Chromium 16/16、Runtime/native WebGL2 20/20、`c53d2067` 的五项归因预算事务及 `f653cfc2` strict 9/9 保留准确来源；SwiftShader 不提供物理 GPU 性能证据。
- [x] **本轮静态 shader 构造的候选实现与本地验证完成。** alias、纯 helper、参数/default、捕获数据沿 binding identity 证明不可变性；修改、逃逸和无法证明的构造保持 `PUI4009`。Compiler 生成直接 GPU 调用，proof evaluator 不进入产物。原第一片独立 72/72 保留实际执行版本。
- [x] **本轮应用 canvas scene lease 的候选实现与本地验证完成。** 纯声明为 `{ kind: 'owned-scene', slot }`，四 Runtime Adapter 与四 native Web profile 接入同一显式 host capability；配置不进入 portable Props/IR。已实现颜色转换、scope/Document/revision 与资源检查、失源 fallback、旧 decode 阻止发布和重入退休；借用消费者只退订自己的订阅，应用 source 的 draw/revoke/dispose 权限仍属于应用。
- [x] **当前本地整合与独立控制有准确回执。** `9fff88cf` 的 17 文件 **245/245**、0 failed/pending；含相同 authored scene 的真实无 DOM Runtime，总 6/6。第二片独立 **48/48** 执行于 `27b5429b`；审查的 13 份源码在 `9fff88cf` 逐字节一致，此次比较没有重跑或重标 48 条。受控 host/GPU/decode 反例不记作真实浏览器结果。
- [x] **当前候选的真实浏览器功能和完整生成原件已取得。** `c1f0332e` 的 [Actions 45266835323](https://github.com/Proto-UI/Proto-UI/actions/runs/45266835323) 为 **37/37**，0 failed/skip/pending；三份 fixture × 四个准确 profile。250 件原件包含 **106/106** 生成产物，以及八条 scene 旅程的 **16 张 active paint 图＋16 份 JSON**。`9fff88cf` 首轮 37/37 的八张终态图和漏传 70 个隐藏支持文件保留原样；后继补图/上传修复弥补该范围，未改产品断言或 37 条分母。
- [x] **本 fixture 的 scene 初始／换源视觉已独立接受。** 审阅者实际查看 16 张中间图及 fallback，并核验 608 个唯一源 blob；八对同宿主同阶段 Runtime/compiled 截图逐字节一致。WC 绘制范围与其他三宿主不同，不声称跨宿主几何一致、完整产品视觉、AT 或物理 GPU 性能。<!-- coordinator-slot:visual-review-45266835323:completed-bounded -->
- [x] **改前预算原件与独立数值提交已形成。** `c1f0332e` 的 [Actions 45266820171](https://github.com/Proto-UI/Proto-UI/actions/runs/45266820171) 已独立核验为严格 **6/9、exit 1**；7,831 份测量源文件、3,831 个唯一 closure inputs 与原件均核对。已发布 [数值提交 `c18bf8f8`](https://github.com/Proto-UI/Proto-UI/blob/c18bf8f8c35a4ec1f69791468a5952c4cb460f41/internal/records/2026-11-24-sprint4-scene-package-budget.md)，只将 React/Vue/WC 三个 gzip ceiling 分别由 172600/171400/207200 改为 172800/171600/207400（各 +200），保留原失败及其他测量/阻断条件。<!-- coordinator-slot:canonical-budget-45266820171:verified-red-6-of-9 -->
- [x] **数值提交的改后 canonical CI 已通过并回读原件。** 精确 `c18bf8f8` 的 [Actions 45269915996](https://github.com/Proto-UI/Proto-UI/actions/runs/45269915996) 为严格 **9/9、exit 0**，source clean/exact/stable；九项 minified/gzip/hash/closure 和 diagnostics 与改前相同，只改变三项预算及派生判定字段。<!-- coordinator-slot:canonical-budget-45269915996:verified-green-9-of-9 -->
- [x] **数值提交独立技术审查完成。** 审阅者核验精确 c18 的全部原件、7,831 份来源指纹、3,831 个唯一闭包输入和仅三项数值变化，接受本次有限成本事务；收据 SHA256 为 `fca91f938691c3c210d26f038b5bf9401b460d0d8cd5dcc20b8a3771b8c691ba`。轻量 [CI 45269910724](https://github.com/Proto-UI/Proto-UI/actions/runs/45269910724) 仅四个 job 实际成功、18 skipped；原生 DCO 成功。这不是正式 GitHub APPROVE，主线合入仍未发生。<!-- coordinator-slot:numeric-independent-review-c18bf8f8:completed-bounded -->
- [ ] **平台与主线整合接受。** 回填实际 head 的 CI/DCO/review 与真实主线合入结果。旧本地启动失败和 `282cbca2` 的 28 条准备超时/0 条执行保留。
- [ ] **原完整 Presentation/shader 条件继续接受。** 其他 Presentation/input families、image/video/compositor 等 source authority、其他 kernels、非 Web GPU、物理性能和完整独立消费者条件仍未由 canvas 子集覆盖。原 Issue 未给出完整可枚举输入族分母，不以这两片另造分母或关闭原两项。

来源：[独立数值事务与改前原件](https://github.com/Proto-UI/Proto-UI/blob/c18bf8f8c35a4ec1f69791468a5952c4cb460f41/internal/records/2026-11-24-sprint4-scene-package-budget.md) · [静态数据构造](https://github.com/Proto-UI/Proto-UI/blob/c1f0332eed6ba79734b92bd4407b274f45d5c274/internal/records/2026-11-24-sprint4-static-shader-data.md) · [显式 scene 与原始收据](https://github.com/Proto-UI/Proto-UI/blob/c1f0332eed6ba79734b92bd4407b274f45d5c274/internal/records/2026-11-24-sprint4-owned-scene-shader.md) · [原浏览器准备失败](https://github.com/Proto-UI/Proto-UI/blob/c1f0332eed6ba79734b92bd4407b274f45d5c274/internal/records/2026-11-24-sprint4-browser-preparation.md) · [已合入原公共交付](https://github.com/Proto-UI/Proto-UI/blob/3551b85049630877e8c062b4d80a56ec2133c532/internal/records/2026-11-22-sprint4-integration.md)。

[本次完整原件、独立审查和可预览原图](https://github.com/Proto-UI/Proto-UI/blob/528ece4cb575a7277981f481ccc0f54dfac8ca70/internal/records/evidence/2026-11-24-sprint4-final-closeout/README.md)；[c18 严格预算及独立接受](https://github.com/Proto-UI/Proto-UI/blob/528ece4cb575a7277981f481ccc0f54dfac8ca70/internal/records/evidence/2026-11-24-sprint4-final-closeout/final-budget.json)。证据单独保存，未改动已验证实现 head。

<!-- proto-ui:sprint4:shader-two-slices:20261124:1143:v4:end -->

---

<!-- proto-ui:issue-governance:20261122:1143:v1 -->

## 2026-11-22 当前代码进度核对

Agent: ChatGPT，按当前用户授权核对与治理。审计截止 [`a8bf56087`](https://github.com/Proto-UI/Proto-UI/commit/a8bf56087e5836e3c14c153cafbd796bd98bff37)；各项执行证据保留其实际 SHA。

核对基线：[2c7eae2](https://github.com/Proto-UI/Proto-UI/commit/2c7eae25357d0c5bae29bd5e92caae3a4ea39730)。

- [x] **有限presentation/owner atoms已有主线实现** — [operation definitions](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/compiler/src/operations.ts)以及 [4/4 authored frontend](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/compiler/test/authored-transition-frontend.test.ts)证明Transition源通过普通IR消费presence/scheduler/capture能力；[8/8](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/compiler/test/authored-native-consumer.test.ts)给出有界native运行。
- [ ] **完整Presentation准入IR→target链** — 保留原source key、适用spec/lifecycle、原owner与所有native/CI边界，不能以Transition一个source family取代整个Presentation验收。
- [ ] **shader Runtime/Compiler实现契约** — 尚无可据以勾选的完整shared shader契约、compiler lowering及独立消费者矩阵；保持0.4。

---

## 来源

拆自 #1090（2026-11-01 全量 Issue 梳理，Finf v2 #890 清零）。父 Issue 保留为追踪入口，本 Issue 为有界执行切片，不是父 Issue 的重复。
## 范围（原 checklist 逐项保留）

- [ ] 贯通 Presentation 准入中间表示与目标生成
- [ ] 贯通 shader Runtime 与 Compiler 实现契约

## 验收与验证边界

每项须原 source key / 完整条件、适用 spec 与 lifecycle、允许改变和排除项、当前 owner/claim、真实 CI/DCO 与原生证据。不以历史证据冒充当前 head 验收。 编译器/IR 投递走 proto-compiler pane。