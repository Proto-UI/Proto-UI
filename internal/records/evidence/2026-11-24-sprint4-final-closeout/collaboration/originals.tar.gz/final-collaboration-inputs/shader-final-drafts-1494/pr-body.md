## Summary

本 PR 接续 Sprint 4，补上两个具体缺口：合法、可证明不可变的 shader 数据构造曾被 Compiler 拒绝；应用已有的 canvas scene lease 尚不能通过纯声明被 Runtime 与生成目标共同消费。当前 PR 提交为 `c18bf8f8c35a4ec1f69791468a5952c4cb460f41`。浏览器及归档实际执行仍绑定 `c1f0332e`，定向整合 245 条仍绑定 `9fff88cf`；数值调整后的 canonical CI 单独绑定当前提交。

- **静态数据构造。** Compiler 按 lexical binding identity 证明 alias、纯 helper、参数/default 与捕获数据的不可变性，生成直接 upload/copy/tint 调用。修改、逃逸、副作用、递归和无法证明的输入继续给出 `PUI4009`；不 reached 的站点不生成 shader host，proof evaluator 不进入产物。
- **显式应用 scene。** 纯声明新增 `{ kind: 'owned-scene', slot }`；四 Web Runtime Adapter 通过 `shader: createWebShaderHost({ ownedScenes })` 接入既有 `CanvasBackdropLease`，四 native Web profile 通过 `createComponent(createShaderHost(...))` 接入同一 host 协议。DOM、provider 与应用权限不进入 portable Props、IR 或序列化。
- **资源与发布。** Host 校验 scope/Document、单调 revision、extent 与资源上限，将 opaque sRGB 转为 linear RGBA8；换源、失源、移动、旧 decode、factory/cleanup 重入保持当前 owner 的权限。消费者只退订自己的订阅，不调用应用 source 的 draw/revoke/dispose。默认导出保留无 capability 的 opaque fallback。
- **来源与定义对照工具。** 固定原 archive/manifest 身份后，可把 captured inputs 保真重建到新目录；工具拒绝覆盖、symlink、越界、碰撞和损坏对象，不执行源码。61 项定义比较绑定 immutable Git revision 与原账本，保留未知原 hash、依赖方向和真正缺少的原输入／认证。
- **证据入口。** 新增手动 shader evidence workflow，接受器逐项核对原 28 条与新增 9 条的身份、三份 authored fixture、四个 profile、源 SHA 和执行终态。原失败、取消、未执行和不同版本的结果各自保留。

## Authority and scope

关联 #1143、#1089、#891–#894、#913–#915；原交付 #1714 已合入 `3551b85049630877e8c062b4d80a56ec2133c532`。

适用 `C-FEEDBACK-SHADER-PRESENTATION-0001`、`HC-FEEDBACK-SHADER-PRESENTATION-0001`、`T-FEEDBACK-SHADER-PRESENTATION-0001` 与 `internal/compiler/atomic-lowering-completion.md`。更新后的 shader 契约仍为 **draft**。两片实现使用共享定义、普通 IR 和按 reached 能力生成的第一方 host atoms，没有组件名称／路径特判，也没有嵌入 Prototype 协议或解释器。

`owned-scene` 是应用拥有的完整场景，按 normalized UV 取样；它没有改变 `in-app-backdrop` 的 viewport/backdrop 语义。原声明在 setup 后冻结，低层 sink 的 source-kind 切换控制不代表 mounted Prototype 可以运行时重写声明。

## Validation

| 检查 | 实际结果与版本边界 |
| --- | --- |
| 当前整合回归 | **17 个文件、245/245**，0 failed/pending，绑定 `9fff88cf`；含公共 dormant/optional/getter/abrupt、静态 shader、scene/owner、项目闭包与 Runtime。原始报告的 245 条 assertion 和 17 个文件已独立回读。 |
| 真实无 Web globals Runtime | 上表内 **6/6**：保留原两个 authored fixture，加入相同 scene fixture 的实际 setup/mount/detach/remount/dispose 路径。 |
| 第一片独立 proof 控制 | **72/72**，保留该片准确源 hash 与原 capture 误拒失败，不重标为本轮新执行。 |
| 第二片独立控制 | **48/48**，执行于干净 `27b5429b46fdc31ae94d1f6a1bd37fb1c6a8323c`。其中 controller/owner 使用明确控制的 host；publication 保留真实发布/退休代码，只控制 GPU 构造与 held decode。审查的 13 份源码在 `9fff88cf` 逐字节一致；这项对照没有重跑或重标 48 条。 |
| 四目标生成类型 | 作者记录中四 profile 各五种源通过：copy、tint、combined、immutable factory、configured scene；Vue2 保留 `checkJs`。原失败与完整 source-bound 收据保留。 |
| 来源工具 | 14/14 文件系统／完整性控制，7/7 独立反例；原 packet 的实际重建未因此计作执行。 |
| 实际浏览器 | **37/37、0 failed/skip/pending**，执行于 `c1f0332e` 的 [Actions 45266835323](https://github.com/Proto-UI/Proto-UI/actions/runs/45266835323)。三份 authored fixture 各生成四个准确 profile；source/head/tree/selection witness 绑定实际候选。 |
| 归档与绘制中采集 | 最新原件 **250 files、106/106 generated artifacts**，包含 `.proto-ui` 支持文件；八条 scene 旅程分别保留 initial/replacement，共 **16 张 active paint PNG＋16 份配套 JSON**。独立审阅已实际查看全部 16 张中间图及 fallback，确认本 fixture 的初始绘制、换源与文字可读性。 |
| 历史浏览器范围 | `9fff88cf` 的 [首轮 37/37](https://github.com/Proto-UI/Proto-UI/actions/runs/45262028723) 保留 148 件原件；八张 scene 图是 post-dispose 终态，且漏传 70 个隐藏支持文件。`996a2a35` 补中间截图，`c1f0332e` 补归档；后继完整原件弥补这些缺口，旧原件不重写。更早本地 socket 拒绝、`282cbca2` 的准备超时/0 条执行也保留。 |
| 独立原件与视觉回读 | 审阅者验证 **608 个唯一 Git source blobs**，逐张查看 16 张 active paint 图及 fallback；同宿主同阶段的 **8 对 Runtime/compiled 图逐字节一致**。WC 绘制范围与 React/Vue/Vue2 不同，只接受各自 fixture 的可见绘制与换源，不声称跨宿主几何一致、完整产品视觉、AT 或物理 GPU 性能。 |
| 原预算与数值提交 | `c1f0332e` 的 [Actions 45266820171](https://github.com/Proto-UI/Proto-UI/actions/runs/45266820171) 已独立核验为 **严格 6/9、exit 1**；六份原件、7,831 份测量源文件及 3,831 个唯一 closure inputs 均核对。`c18bf8f8` 已发布独立数值事务，将 React/Vue/WC 三个 gzip 上限各增加 200 bytes；原红结果保留。 |
| 改后 canonical CI | 精确 `c18bf8f8` 的 [Actions 45269915996](https://github.com/Proto-UI/Proto-UI/actions/runs/45269915996) 已取得 **严格 9/9、exit 0** 原件，source clean/exact/stable。九项 minified/gzip/hash/closure 及 diagnostics 与改前相同；只改变三项预算及其派生判定字段。**独立数值审查已完成，收据 `fca91f938691c3c210d26f038b5bf9401b460d0d8cd5dcc20b8a3771b8c691ba` 接受本次有界事务。** |
| 轻量 CI | [Actions 45269910724](https://github.com/Proto-UI/Proto-UI/actions/runs/45269910724) completed success；实际成功只有 `ci-config-audit`、`test-plan`、`public_package_plan`、`lockstep-check` 四个 job，其余 **18 skipped**。这不代表全量回归执行。 |

未选中 scene 的普通 React/Vue/WC root bundle 中，scene provider 本体的已测 retained bytes 为零；共同 dispatch/retirement 仍有成本。这个归因结果不替代上表 whole-entry 预算，也不证明全部初始化分配或物理 GPU 性能。

## Bounded package-budget transaction

数值事务依据已独立核验的来源与 retained closure，接受这次已审查 Web scene 子集的具体成本。三项上限各增加 200 bytes，取实际值之上的下一个 100-byte 刻度；其他六项上限、入口、压缩、externals、产品实现和严格阻断规则保持原样。改后精确提交的 canonical 运行已给出 9/9；原改前 6/9 继续保留，数值提交的独立审查单独完成。详见[事务与原件记录](https://github.com/Proto-UI/Proto-UI/blob/c18bf8f8c35a4ec1f69791468a5952c4cb460f41/internal/records/2026-11-24-sprint4-scene-package-budget.md)。

| Entry | 实测 gzip bytes | 原上限 | 新上限 | 余量 |
| --- | ---: | ---: | ---: | ---: |
| React root | 172749 | 172600 | 172800 | 51 |
| Vue root | 171536 | 171400 | 171600 | 64 |
| WC root | 207303 | 207200 | 207400 | 97 |

## Remaining acceptance

- 正式 GitHub 独立 review 与主线合入尚未发生；已完成的技术审查及严格 9/9 不替代平台 APPROVE。
- 当前 head 的轻量 CI 四项实际通过、18 skipped，原生 DCO 成功；Vercel 受每日部署配额限制，需保留其真实后继部署结果。完整 scheduled 回归与主线接受仍有各自条件。
- #1143 的其他 Presentation 输入 family、image/video/compositor 等 source authority、其他 kernels、非 Web GPU、物理性能与原 source-key 整体接受。现有 Issue 未给出完整可枚举 input-family 分母，本 PR 不另造分母。
- #1089 的原八项完整能力与消费者组合接受；既有 Shenko/Verdant 临时消费和 source-license 后继保留其真实版本，未改写为本轮正式采用、完整 Harness、窗口／输入／AT 或 distribution-ready 接受。
- 原私有 IR10 packet 与 pinned installed inputs、原作者来源／贡献权利和真实认证、共享定义精确绑定、13 节点真实公开 parent/head 及逐层 build/verify、完整迁移和原候选接受。当前公共工具、语义成功与本轮 agent sign-off 均不替代这些事实。

本 PR 完成上述可审查实现与证据增量，**不声明全 Sprint 4 完成，也不自动关闭关联 Issue**。

## Records and provenance

<!-- coordinator-slot:visual-review-45266835323:completed-bounded -->
<!-- coordinator-slot:canonical-budget-45266820171:verified-red-6-of-9 -->
<!-- coordinator-slot:canonical-budget-45269915996:verified-green-9-of-9 -->
<!-- coordinator-slot:numeric-independent-review-c18bf8f8:completed-bounded -->

- [独立数值事务与改前原件](https://github.com/Proto-UI/Proto-UI/blob/c18bf8f8c35a4ec1f69791468a5952c4cb460f41/internal/records/2026-11-24-sprint4-scene-package-budget.md)
- [当前真实浏览器运行](https://github.com/Proto-UI/Proto-UI/actions/runs/45266835323)
- [整合回归、独立审查和旧 canonical 失败](https://github.com/Proto-UI/Proto-UI/blob/c1f0332eed6ba79734b92bd4407b274f45d5c274/internal/records/2026-11-24-sprint4-integrated-scene-validation.md)
- [静态 shader 数据构造](https://github.com/Proto-UI/Proto-UI/blob/c1f0332eed6ba79734b92bd4407b274f45d5c274/internal/records/2026-11-24-sprint4-static-shader-data.md)
- [显式应用 scene、原失败与预算快照](https://github.com/Proto-UI/Proto-UI/blob/c1f0332eed6ba79734b92bd4407b274f45d5c274/internal/records/2026-11-24-sprint4-owned-scene-shader.md)
- [来源重建与 61 项定义比较](https://github.com/Proto-UI/Proto-UI/blob/c1f0332eed6ba79734b92bd4407b274f45d5c274/internal/records/2026-11-24-sprint4-foundation-reconstruction.md)
- [当前定义与真正未决边界](https://github.com/Proto-UI/Proto-UI/blob/c1f0332eed6ba79734b92bd4407b274f45d5c274/internal/records/2026-11-24-sprint4-definition-decision-boundaries.md)
- [原浏览器失败与显式证据 workflow](https://github.com/Proto-UI/Proto-UI/blob/c1f0332eed6ba79734b92bd4407b274f45d5c274/internal/records/2026-11-24-sprint4-browser-preparation.md)

Agent: ChatGPT / Codex，按当前用户“你来补完 Sprint 4”的授权实现和验证。新工具、proof、host 协议、测试和记录由 coding agents 编写；其他 agent 独立发现并推动修复实际问题。各提交保留实际作者与 sign-off，没有替原私有作者补签或重新授权输入。原 LICENSE/NOTICE 与失败原件保持来源边界；人类及平台 review 的结论以实际记录为准。

## Final originals and directly viewable paint

[完整证据、重放入口与五张原图](https://github.com/Proto-UI/Proto-UI/blob/528ece4cb575a7277981f481ccc0f54dfac8ca70/internal/records/evidence/2026-11-24-sprint4-final-closeout/README.md) · [最终严格预算原件和独立复核](https://github.com/Proto-UI/Proto-UI/blob/528ece4cb575a7277981f481ccc0f54dfac8ca70/internal/records/evidence/2026-11-24-sprint4-final-closeout/final-budget.json) · [本地独立数值审查 packet](https://github.com/Proto-UI/Proto-UI/blob/528ece4cb575a7277981f481ccc0f54dfac8ca70/internal/records/evidence/2026-11-24-sprint4-final-closeout/reviews/numeric/record.json)。证据提交 `528ece4cb575a7277981f481ccc0f54dfac8ca70` 只保存收据；实现 PR head 保持 `c18bf8f8c35a4ec1f69791468a5952c4cb460f41`。

| React runtime 初始纹理 | 同一旅程换源后的绘制 |
| --- | --- |
| ![640×360 白底 fixture，初始纹理与可读子文本](https://github.com/Proto-UI/Proto-UI/blob/528ece4cb575a7277981f481ccc0f54dfac8ca70/internal/records/evidence/2026-11-24-sprint4-final-closeout/visual/scene-react-runtime-initial-paint.png?raw=true) | ![相同 fixture，应用换源为绿色后子文本保持可读](https://github.com/Proto-UI/Proto-UI/blob/528ece4cb575a7277981f481ccc0f54dfac8ca70/internal/records/evidence/2026-11-24-sprint4-final-closeout/visual/scene-react-runtime-replacement-paint.png?raw=true) |

图像实际执行绑定 c1；它们不是物理 GPU 性能或全宿主布局一致性的接受。
