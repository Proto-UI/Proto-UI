from pathlib import Path
import os,json,hashlib,subprocess,shutil,datetime,traceback
p=Path('/tank/shared/projects/proto-ui-agent/sprint4-completion-20261124-1494');o=p/'github-cli-recovery-v2';h=p/'final-collaboration-tools'
def sha(q):return hashlib.sha256(q.read_bytes()).hexdigest()
def load(q):return json.loads(q.read_text())
def save(q,obj):
 with q.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
with (o/'prepare-compatible-attempt.lock').open('x') as f:f.write(str(os.getpid()))
old=p/'final-collaboration-results';oldj=old/'journal.json';j=load(oldj)
assert list(j['operations'])==['progress-01-cc6f2c5f']
op=j['operations']['progress-01-cc6f2c5f'];assert op['state']=='halted-unresolved'
failed=Path(op['directory']);request=load(failed/'request.json')
assert request['requestDigest']==op['requestDigest']=='0f7093feb0ffd4f6bbcc51bd5d351724b757f1a87823ab504053954bc27bccfc'
assert not (failed/'receipt.json').exists()
assert 'unknown flag: --slurp' in (failed/'apply.stderr.log').read_text()
assert load(failed/'apply.result.json')['exitCode']==1
reconciliation=load(o/'no-write-reconciliation.json');assert reconciliation['matches']==[] and reconciliation['firstInvocationFailedBeforeWriteDuringReadOnlyCollection'] is True
assert reconciliation['oldRequestDigest']==request['requestDigest']
install=load(o/'install-receipt.json');assert install['outcome']=='verified-compatible' and install['actor']=='cyjin-yl'
binary=Path(install['binary']['path']);assert sha(binary)==install['binary']['sha256']=='fa7cff06d4db9eee98e00b10ac93beebfe1822109ac04a6cbbf9d806c21d0073'
pages=load(o/'new-slurp-readback.stdout');assert all(isinstance(x,list) for x in pages)
comments=[c for page in pages for c in page];pr=load(o/'new-pr-readback.stdout')
assert len(comments)==pr['comments']==2
assert pr['draft'] and pr['head']['sha']==reconciliation['head']=='c18bf8f8c35a4ec1f69791468a5952c4cb460f41'
markers=['agent-commit-progress:Proto-UI/Proto-UI#1754:cc6f2c5f',request['requestDigest']]
assert not any(any(m in c['body'] for m in markers) for c in comments)
expected={'final-collaboration-runner.py':'46ed2a4f68183d0e2cc2c781e6ef5b4a58728488e6b972fde4cbaf1988e4c028','final-collaboration-helper.mjs':'f9f7cce82bced3b2ddb56a12ef635051ff86e650df6dbe63137345df2ef4776c','final-collaboration-payload.schema.json':'731b9e8f4bd1cb03f67c94b6d96d09a9b08cac9c81adc992009a023b60c8c021'}
for name,digest in expected.items():assert sha(h/name)==digest
original=load(h/'payload.json');new=dict(original);new['outputDirectory']='final-collaboration-results-compatible-gh'
assert [k for k in new if new[k]!=original[k]]==['outputDirectory']
assert not (p/new['outputDirectory']).exists()
newpath=h/'payload-compatible-gh.json';save(newpath,new)
env=dict(os.environ);env['PATH']=str(binary.parent)+os.pathsep+env.get('PATH','')
effective=dict(env);effective['PATH']=original['runtimeBin']+os.pathsep+effective['PATH']
assert Path(shutil.which('gh',path=effective['PATH'])).resolve()==binary.resolve()
v=subprocess.check_output(['gh','--version'],env=effective,text=True);assert 'gh version 2.105.0' in v
args=['python3',str(h/'final-collaboration-runner.py'),'validate-payload','--payload',str(newpath)]
with (o/'compatible-validate.stdout').open('x') as out,(o/'compatible-validate.stderr').open('x') as err:r=subprocess.run(args,env=env,cwd=p,stdout=out,stderr=err,timeout=120)
assert r.returncode==0
reports=list((p/new['outputDirectory']).glob('*-validate-payload/payload-validation.json'));assert len(reports)==1
validation=load(reports[0]);assert validation['valid'] is True and validation['localIntentSha256']==j['localIntentSha256']
bound=[oldj,failed/'request.json',failed/'apply.stdout.log',failed/'apply.stderr.log',failed/'apply.result.json',o/'no-write-reconciliation.json',o/'new-slurp-readback.stdout',o/'new-pr-readback.stdout',o/'install-receipt.json',o/'official-release.json',h/'payload.json',newpath,reports[0]]
rec={'kind':'sprint4.collaboration-compatibility-recovery','observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'outcome':'confirmed-no-write-compatible-new-attempt-prepared','oldJournalRetained':True,'oldJournalState':op['state'],'oldRequestDigest':request['requestDigest'],'oldFailureDisposition':'pre-write read-only collection failed; exhaustive readback confirms zero mutation','localIntentSha256':j['localIntentSha256'],'payloadChanges':[{'path':'/outputDirectory','before':original['outputDirectory'],'after':new['outputDirectory']}],'binary':install['binary'],'effectiveVersion':v.strip(),'effectiveBinaryPath':str(binary),'fullCommentCount':len(comments),'commentIds':[c['id'] for c in comments],'checkedMarkers':markers,'headSha':pr['head']['sha'],'draft':pr['draft'],'actor':'cyjin-yl','sourceChecksums':expected,'boundEvidence':[{'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':sha(f)} for f in bound],'externalWrites':0,'nextAction':'fresh canonical collect and ordinary repository CLI apply-updates; never reuse old sealed request'}
save(o/'compatible-attempt-recovery.json',rec)
print(json.dumps({'outcome':rec['outcome'],'localIntentSha256':rec['localIntentSha256'],'payload':str(newpath),'validation':str(reports[0])}),flush=True)
