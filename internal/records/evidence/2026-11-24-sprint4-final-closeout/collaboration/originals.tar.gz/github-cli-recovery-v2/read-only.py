from pathlib import Path
import subprocess,json,traceback,datetime,os
p=Path('/tank/shared/projects/proto-ui-agent/sprint4-completion-20261124-1494');o=p/'github-cli-recovery-v2';o.mkdir(exist_ok=True)
with (o/'read-only.lock').open('x') as f:f.write(str(os.getpid()))
def run(name,args):
 r=subprocess.run(args,cwd=p/'repo',capture_output=True,text=True,timeout=45)
 (o/(name+'.stdout')).write_text(r.stdout);(o/(name+'.stderr')).write_text(r.stderr)
 if r.returncode:raise RuntimeError(name+' exit '+str(r.returncode))
 return r.stdout
try:
 print(run('version',['gh','--version']),flush=True)
 print('binary',run('binary',['which','gh']),flush=True)
 raw=run('comments',['gh','api','--paginate','repos/Proto-UI/Proto-UI/issues/1754/comments?per_page=100']);remaining=raw.strip();pages=[];decoder=json.JSONDecoder()
 while remaining:
  x,n=decoder.raw_decode(remaining);assert isinstance(x,list);pages.append(x);remaining=remaining[n:].strip()
 comments=[x for a in pages for x in a];pr=json.loads(run('pr',['gh','api','repos/Proto-UI/Proto-UI/pulls/1754']));assert len(comments)==pr['comments']
 req=json.loads((p/'final-collaboration-results/20261123T214616007758Z-apply-updates/progress-01-cc6f2c5f/request.json').read_text());markers=['agent-commit-progress:Proto-UI/Proto-UI#1754:cc6f2c5fb4d223be4d838471d7aa7b77f4c14f80','proto-ui-collaboration:'+req['requestDigest']]
 q={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':pr['head']['sha'],'fullCommentCount':len(comments),'matches':[{'id':x['id'],'url':x['html_url']} for x in comments if any(m in x['body'] for m in markers)],'oldRequestDigest':req['requestDigest'],'firstInvocationFailedBeforeWriteDuringReadOnlyCollection':True};(o/'no-write-reconciliation.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(q),flush=True)
 release=json.loads(run('official-release',['gh','api','repos/cli/cli/releases/latest']));(o/'official-release.json').write_text(json.dumps(release,indent=2)+'\n');print(json.dumps({'tag':release['tag_name'],'assets':[{'id':x['id'],'name':x['name'],'url':x['browser_download_url'],'digest':x.get('digest'),'size':x['size']} for x in release['assets'] if x['name'].endswith('linux_amd64.tar.gz') or x['name'].endswith('checksums.txt')]}),flush=True)
except Exception:
 traceback.print_exc();raise
