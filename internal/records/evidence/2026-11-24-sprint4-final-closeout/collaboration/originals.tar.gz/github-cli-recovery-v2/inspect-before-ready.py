from pathlib import Path
import json,hashlib,datetime,subprocess,os
p=Path('/tank/shared/projects/proto-ui-agent/sprint4-completion-20261124-1494');o=p/'github-cli-recovery-v2';h=p/'final-collaboration-tools'
payload=json.loads((h/'payload-compatible-gh.json').read_text());j=json.loads((p/payload['outputDirectory']/'journal.json').read_text())
assert len(j['operations'])==16 and all(v['state']=='verified' for v in j['operations'].values())
x=json.loads((Path(j['operations']['pr-title-body']['directory'])/'review-input.json').read_text())
old=json.loads((p/'final-platform-intake/review-input.json').read_text())
prior={c['id']:c for c in old['comments']};other=[c for c in x['comments'] if c['author']!='cyjin-yl']
changed=[c for c in other if prior.get(c['id'])!=c]
env=dict(os.environ);env['PATH']=str(o/'runtime/bin')+os.pathsep+env.get('PATH','')
raw=subprocess.check_output(['gh','api','repos/Proto-UI/Proto-UI/pulls/1754'],cwd=p/'collaboration-repo',env=env)
with (o/'pre-ready-pr.json').open('xb') as f:f.write(raw)
pr=json.loads(raw)
assert pr['head']['sha']==payload['expectedHead'] and pr['body']==(p/payload['prBody']['path']).read_text() and pr['title']==payload['prTitle']
assert pr['state']=='open' and not pr['merged']
r={'kind':'sprint4.pre-ready-inspection','observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'operations':{k:v['state'] for k,v in j['operations'].items()},'head':pr['head']['sha'],'draft':pr['draft'],'actualPrMetadataMatches':True,'canonicalCommentCount':len(x['comments']),'externalCommentsUnchanged':not changed,'changedExternalComments':changed,'reviews':x['reviews'],'threads':x['threads'],'checks':[{'name':c['name'],'status':c['status'],'conclusion':c['conclusion']} for c in x['checks']]}
with (o/'pre-ready-inspection.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps(r),flush=True)
