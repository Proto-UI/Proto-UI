from pathlib import Path
import os,subprocess,json,hashlib,tarfile,datetime,traceback
p=Path('/tank/shared/projects/proto-ui-agent/sprint4-completion-20261124-1494');o=p/'github-cli-recovery-v2';d=o/'download';d.mkdir(exist_ok=True)
with (o/'install.lock').open('x') as f:f.write(str(os.getpid()))
rec={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'task-local official GitHub CLI compatibility repair','source':'https://github.com/cli/cli/releases/tag/v2.105.0','oldVersion':'2.46.0','newVersion':'2.105.0','systemInstallationChanged':False,'repositoryPolicyChanged':False,'operations':[]}
def save(): (o/'install-receipt.json').write_text(json.dumps(rec,indent=2)+'\n')
def run(label,args,env=None,timeout=120):
 r=subprocess.run(args,cwd=p/'repo',env=env,capture_output=True,text=True,timeout=timeout)
 (o/(label+'.stdout')).write_text(r.stdout);(o/(label+'.stderr')).write_text(r.stderr);rec['operations'].append({'label':label,'command':args,'exitCode':r.returncode});save()
 if r.returncode:raise RuntimeError(label+' failed '+str(r.returncode))
 return r.stdout
try:
 q=json.loads((o/'no-write-reconciliation.json').read_text());assert q['matches']==[] and q['head']=='c18bf8f8c35a4ec1f69791468a5952c4cb460f41'
 release=json.loads((o/'official-release.json').read_text());assert release['tag_name']=='v2.105.0'
 names=['gh_2.105.0_linux_amd64.tar.gz','gh_2.105.0_checksums.txt']
 run('official-download',['/usr/bin/gh','release','download','v2.105.0','--repo','cli/cli','--pattern',names[0],'--pattern',names[1],'--dir',str(d)],timeout=180)
 checks={line.split()[-1].lstrip('*'):line.split()[0] for line in (d/names[1]).read_text().splitlines() if line.strip()}
 for n in names:
  a=next(x for x in release['assets'] if x['name']==n);b=(d/n).read_bytes();assert len(b)==a['size'];assert 'sha256:'+hashlib.sha256(b).hexdigest()==a['digest']
 assert checks[names[0]]==hashlib.sha256((d/names[0]).read_bytes()).hexdigest()=='79e7ab5db738c48777b696e374f8b428f0647debfb424f44d2f426370407fe2f'
 dest=o/'runtime/bin';dest.mkdir(parents=True,exist_ok=True);target=dest/'gh'
 with tarfile.open(d/names[0]) as t:
  member=t.getmember('gh_2.105.0_linux_amd64/bin/gh');assert member.isfile();b=t.extractfile(member).read()
 with target.open('xb') as f:f.write(b)
 target.chmod(0o755);rec['binary']={'path':str(target),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};save()
 version=run('new-version',[str(target),'--version']);assert 'gh version 2.105.0' in version
 helptext=run('new-api-help',[str(target),'api','--help']);assert '--slurp' in helptext
 pages=json.loads(run('new-slurp-readback',[str(target),'api','--paginate','--slurp','repos/Proto-UI/Proto-UI/issues/1754/comments?per_page=100']));assert isinstance(pages,list) and all(isinstance(x,list) for x in pages);comments=[x for a in pages for x in a]
 pr=json.loads(run('new-pr-readback',[str(target),'api','repos/Proto-UI/Proto-UI/pulls/1754']));assert len(comments)==pr['comments'] and pr['head']['sha']==q['head'];assert not any('agent-commit-progress:Proto-UI/Proto-UI#1754:cc6f2c5f' in x['body'] for x in comments)
 actor=json.loads(run('new-actor',[str(target),'api','user']));assert actor['login']=='cyjin-yl'
 rec.update(outcome='verified-compatible',slurpFullCommentCount=len(comments),actor=actor['login'],finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print(json.dumps({'outcome':rec['outcome'],'binary':rec['binary'],'actor':rec['actor'],'comments':len(comments)}),flush=True)
except Exception as error:
 rec.update(outcome='stopped',error=str(error),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();traceback.print_exc();raise
