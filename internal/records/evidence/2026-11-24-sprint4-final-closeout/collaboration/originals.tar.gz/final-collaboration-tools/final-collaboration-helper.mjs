#!/usr/bin/env node
// Read-only collection/schema adapter. All mutations belong to agent:collaborate.
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { isDeepStrictEqual } from 'node:util';

const [command, repoArg, ...args] = process.argv.slice(2);
const repo = path.resolve(repoArg ?? '.');
const read = (p) => JSON.parse(fs.readFileSync(p, 'utf8'));
const write = (p, value) => fs.writeFileSync(p, `${JSON.stringify(value, null, 2)}\n`, { flag: 'wx' });
const requireRepo = createRequire(path.join(repo, 'package.json'));
const importRepo = (p) => import(pathToFileURL(path.join(repo, p)).href);
const assert = (ok, message) => { if (!ok) throw new Error(message); };
const REPOSITORY = 'github.com:Proto-UI/Proto-UI';
const HEAD = 'c18bf8f8c35a4ec1f69791468a5952c4cb460f41';
const apiRoot = 'repos/Proto-UI/Proto-UI';

function schema(schemaPath, value) {
  const Ajv = requireRepo('ajv/dist/2020.js').default;
  const ajv = new Ajv({ allErrors: true, strict: false });
  ajv.addFormat('date-time', (s) => /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/i.test(s) && Number.isFinite(Date.parse(s)));
  const validate = ajv.compile(read(schemaPath));
  assert(validate(value), `schema validation failed: ${JSON.stringify(validate.errors)}`);
}

function gh(args) {
  return JSON.parse(execFileSync('gh', args, {
    cwd: repo, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024,
    stdio: ['ignore', 'pipe', 'pipe'], timeout: 120_000,
  }));
}
const get = (p) => gh(['api', p]);
function metadata(item) {
  const sorted = (xs) => [...new Set(xs)].sort((a, b) => a.localeCompare(b));
  return {
    title: item.title, body: item.body ?? null,
    milestoneNumber: item.milestone?.number ?? null,
    assignees: sorted((item.assignees ?? []).map((x) => x.login)),
    labels: sorted((item.labels ?? []).map((x) => x.name)),
  };
}
function anchor(item) {
  return { number: item.number, updatedAt: item.updated_at, state: item.state,
    metadata: metadata(item), head: item.head?.sha ?? null, base: item.base?.sha ?? null,
    baseRefName: item.base?.ref ?? null, draft: item.draft ?? null, merged: item.merged ?? null,
    commentCount: item.comments };
}
function assertPR(p) {
  assert(p.number === 1754 && p.head?.sha === HEAD, 'PR number/head changed');
  assert(p.base?.repo?.full_name === 'Proto-UI/Proto-UI', 'PR repository mismatch');
  assert(p.state === 'open' && p.merged === false && p.merged_at === null, 'PR is not open/unmerged');
}
function commentProjection(comments) {
  assert(Array.isArray(comments), 'comments must be an exhaustive array');
  const ids = new Set();
  const result = comments.map((c) => {
    assert(Number.isSafeInteger(c.id) && c.id > 0 && !ids.has(c.id), 'invalid/duplicate comment id');
    ids.add(c.id);
    assert(typeof c.body === 'string' && typeof c.user?.login === 'string' && typeof c.updated_at === 'string', 'incomplete comment');
    return { id: c.id, body: c.body, author: c.user.login, updatedAt: c.updated_at };
  });
  return result.sort((a, b) => a.id - b.id);
}
function issueComments(n) {
  const pages = gh(['api', '--paginate', '--slurp', `${apiRoot}/issues/${n}/comments?per_page=100`]);
  assert(Array.isArray(pages) && pages.every(Array.isArray), 'invalid comment pagination');
  return { pages, comments: pages.flat() };
}

try {
  if (command === 'schema') {
    schema(args[0], read(args[1]));
    console.log(JSON.stringify({ valid: true }));
  } else if (command === 'fixture-review') {
    const { analysis } = await importRepo('scripts/agent-operations/test/fixtures/cloud-review.mjs');
    const input = analysis({ repositoryId: REPOSITORY, pullRequest: 1754, headSha: HEAD,
      pullRequestBody: 'OFFLINE STRUCTURE FIXTURE — no live evidence or readiness claim', isDraft: true }).input;
    write(args[0], input);
    console.log(JSON.stringify({ valid: true, synthetic: true }));
  } else if (command === 'collect-pr') {
    const [externalPath, outDir] = args;
    const externalEvidence = read(externalPath);
    assert(Array.isArray(externalEvidence), 'externalEvidence must be the exact supplied array');
    const before = get(`${apiRoot}/pulls/1754`);
    assertPR(before);
    const { collectLiveReviewInput } = await importRepo('scripts/agent-operations/collect-live-review-input.mjs');
    // This repository collector already exhausts every connection twice and
    // rejects unequal complete canonical inputs. Never replace it with a count.
    const collected = collectLiveReviewInput(REPOSITORY, 1754, { externalEvidence });
    const after = get(`${apiRoot}/pulls/1754`);
    assertPR(after);
    assert(isDeepStrictEqual(anchor(before), anchor(after)), 'PR metadata moved during canonical collection');
    const input = collected.input;
    assert(input.schemaVersion === 5 && input.repositoryId === REPOSITORY && input.pullRequest === 1754 && input.headSha === HEAD, 'wrong canonical review input');
    assert(input.pullRequestState === 'OPEN' && input.pullRequestBody === (after.body ?? '') && input.isDraft === after.draft && input.baseSha === after.base.sha && input.baseRefName === after.base.ref, 'canonical input/metadata disagree');
    assert(input.comments.length === after.comments, 'top-level conversation count changed');
    schema(path.join(repo, 'internal/agent-operations/schemas/review-input.schema.json'), input);
    write(path.join(outDir, 'review-input.json'), input);
    const snapshot = { kind: 'sprint4.pr-live-snapshot', repositoryId: REPOSITORY,
      observedAt: new Date().toISOString(), target: { kind: 'pull-request', number: 1754, updatedAt: after.updated_at, headSha: HEAD },
      metadata: metadata(after), pullRequest: after, collection: collected,
      scope: { pullRequest: 1754, comments: 'exhaustive', reviewConnections: 'two complete equal scans', metadataStableBeforeAfter: true } };
    write(path.join(outDir, 'github-snapshot.json'), snapshot);
    console.log(JSON.stringify({ valid: true, observedAt: snapshot.observedAt, viewerLogin: collected.viewerLogin, viewerPermission: collected.viewerPermission }));
  } else if (command === 'collect-issue') {
    const [numberText, inspectedPath, outDir] = args;
    const number = Number(numberText);
    assert([1143, 1089].includes(number), 'Issue outside fixed scope');
    assertPR(get(`${apiRoot}/pulls/1754`));
    const viewer = gh(['api', 'graphql', '-f', 'query=query { viewer { login } repository(owner:"Proto-UI",name:"Proto-UI") { viewerPermission } }']);
    assert(!viewer.errors?.length && typeof viewer.data?.viewer?.login === 'string' && typeof viewer.data?.repository?.viewerPermission === 'string', 'viewer unavailable');
    const before = get(`${apiRoot}/issues/${number}`);
    const first = issueComments(number);
    const second = issueComments(number);
    const after = get(`${apiRoot}/issues/${number}`);
    const snapshot = { kind: 'sprint4.issue-live-snapshot', repositoryId: REPOSITORY,
      observedAt: new Date().toISOString(), target: { kind: 'issue', number, updatedAt: after.updated_at, headSha: null },
      metadata: metadata(after), issue: after, comments: second.comments,
      viewerLogin: viewer.data.viewer.login, viewerPermission: viewer.data.repository.viewerPermission,
      collection: { paginationExhausted: true, firstPages: first.pages.length, secondPages: second.pages.length,
        ids: second.comments.map((c) => String(c.id)), count: second.comments.length },
      interpretation: { reference: inspectedPath, status: 'pending-comparison' } };
    write(path.join(outDir, 'github-snapshot.json'), snapshot);
    assert(before.number === number && after.number === number && !after.pull_request && after.state === 'open', 'Issue is not the expected open Issue');
    assert(isDeepStrictEqual(anchor(before), anchor(after)), 'Issue metadata moved during full comment collection');
    assert(isDeepStrictEqual(commentProjection(first.comments), commentProjection(second.comments)) && second.comments.length === after.comments, 'Issue comments changed or collection incomplete');
    assert(isDeepStrictEqual(commentProjection(read(inspectedPath)), commentProjection(second.comments)), 'Issue comments differ from the supplied interpreted archive; inspect the saved snapshot before a new request');
    assertPR(get(`${apiRoot}/pulls/1754`));
    console.log(JSON.stringify({ valid: true, observedAt: snapshot.observedAt, viewerLogin: snapshot.viewerLogin, viewerPermission: snapshot.viewerPermission, commentsInterpretedArchiveMatches: true }));
  } else if (command === 'validate-pair') {
    const [requestPath, handoffPath] = args;
    const request = read(requestPath), handoff = read(handoffPath);
    schema(path.join(repo, 'internal/agent-operations/schemas/collaboration-request.schema.json'), request);
    schema(path.join(repo, 'internal/agent-operations/schemas/skill-handoff.schema.json'), handoff);
    const runtime = await importRepo('scripts/agent-operations/collaboration-runtime.mjs');
    const registry = await importRepo('scripts/agent-operations/skill-registry.mjs');
    runtime.validateCollaborationRequest(request);
    registry.validateSkillHandoff(handoff, registry.loadSkillRegistry());
    runtime.validateCollaborationHandoffBinding(request, handoff);
    console.log(JSON.stringify({ valid: true }));
  } else if (command === 'validate-handoff') {
    const handoff = read(args[0]);
    schema(path.join(repo, 'internal/agent-operations/schemas/skill-handoff.schema.json'), handoff);
    const registry = await importRepo('scripts/agent-operations/skill-registry.mjs');
    registry.validateSkillHandoff(handoff, registry.loadSkillRegistry());
    console.log(JSON.stringify({ valid: true }));
  } else if (command === 'verify-receipt') {
    const [requestPath, receiptPath, outPath, expectedActor] = args;
    const request = read(requestPath), receipt = read(receiptPath);
    const runtime = await importRepo('scripts/agent-operations/collaboration-runtime.mjs');
    runtime.validateCollaborationReceipt(receipt, request);
    schema(path.join(repo, 'internal/agent-operations/schemas/collaboration-receipt.schema.json'), receipt);
    assert(['applied', 'no-op'].includes(receipt.outcome), `collaboration rejected: ${receipt.note}`);
    assert(receipt.actor.toLowerCase() === expectedActor.toLowerCase(), 'receipt actor changed');
    const { collectLiveCollaborationState } = await importRepo('scripts/agent-operations/collect-live-collaboration-state.mjs');
    const readback = collectLiveCollaborationState(request);
    write(outPath, readback);
    assert(readback.viewerLogin.toLowerCase() === expectedActor.toLowerCase() && readback.current.state === 'OPEN', 'readback actor/state changed');
    assert(runtime.desiredCollaborationStateSatisfied(request, readback), 'readback no longer satisfies exact request');
    assertPR(get(`${apiRoot}/pulls/1754`));
    console.log(JSON.stringify({ valid: true, outcome: receipt.outcome, verifiedAt: readback.observedAt }));
  } else {
    throw new Error(`unknown helper command: ${command}`);
  }
} catch (error) {
  process.stderr.write(`[final-collaboration-helper] ${error.message}\n`);
  process.exitCode = 1;
}
