#!/usr/bin/env python3
"""PR #1754 ordinary governed collaboration. Default commands never mutate GitHub.

All remote writes use the repository's agent:collaborate CLI exactly once.
Local hashes below pin artifacts/configuration; canonical request/review digests
are exclusively computed by the repository CLI. This is not an authority source.
"""
from __future__ import annotations

import argparse
import copy
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

REPOSITORY = "github.com:Proto-UI/Proto-UI"
HEAD = "c18bf8f8c35a4ec1f69791468a5952c4cb460f41"
PR = 1754
MODE = ["--mode", "human-assisted", "--mode-source", "current-user"]
HERE = Path(__file__).resolve().parent
HELPER = HERE / "final-collaboration-helper.mjs"
SCHEMA = HERE / "final-collaboration-payload.schema.json"
METADATA = "update-governed-issue-or-pull-request-metadata"
COMMENT = "post-bounded-reconciliation-comment"
READY = "mark-exact-head-ready-for-review"
HEX = re.compile(r"[a-f0-9]{64}\Z")


class Halt(RuntimeError):
    pass


def need(condition, message):
    if not condition:
        raise Halt(message)


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()


def read_json(path):
    return json.loads(Path(path).read_bytes())


def write_json(path, value, *, replace=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = encode(value)
    if replace:
        temp = path.with_name(path.name + f".tmp-{os.getpid()}")
        with temp.open("xb") as output:
            output.write(data)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temp, path)
    else:
        with path.open("xb") as output:
            output.write(data)
            output.flush()
            os.fsync(output.fileno())


def parse_cli_json(text):
    """Permit pnpm's leading banner, require one complete trailing JSON object."""
    decoder = json.JSONDecoder()
    for match in re.finditer(r"(?m)^\s*\{", text):
        start = text.index("{", match.start(), match.end())
        try:
            value, end = decoder.raw_decode(text, start)
        except ValueError:
            continue
        if isinstance(value, dict) and not text[end:].strip():
            return value
    raise Halt("CLI did not return a complete trailing JSON object; inspect preserved logs")


class Runner:
    def __init__(self, repo, runtime_bin, corepack_home, timeout=600):
        self.repo = Path(repo).resolve()
        self.runtime = Path(runtime_bin).resolve()
        self.timeout = timeout
        self.env = dict(os.environ)
        self.env.update(PATH=str(self.runtime) + os.pathsep + self.env.get("PATH", ""),
                        COREPACK_HOME=str(corepack_home), COREPACK_ENABLE_DOWNLOAD_PROMPT="0")
        self.node = str(self.runtime / "node")
        self.corepack = str(self.runtime / "corepack")
        need(self.repo.is_dir() and (self.repo / "node_modules").is_dir(), "tooling checkout/dependencies missing")
        need(Path(self.node).is_file() and Path(self.corepack).exists(), "Node/corepack runtime missing")
        version = subprocess.check_output([self.node, "--version"], env=self.env, text=True).strip()
        need(version.startswith("v24."), "repository requires Node 24")
        self.node_version = version

    def run(self, args, prefix, *, allow_failure=False):
        """No retry. A timeout during apply remains UNKNOWN even after termination."""
        prefix = Path(prefix)
        prefix.parent.mkdir(parents=True, exist_ok=True)
        command_record = {"argv": [str(a) for a in args], "cwd": str(self.repo), "startedAt": now()}
        write_json(prefix.with_suffix(".command.json"), command_record)
        with prefix.with_suffix(".stdout.log").open("xb") as stdout, prefix.with_suffix(".stderr.log").open("xb") as stderr:
            process = subprocess.Popen([str(a) for a in args], cwd=self.repo, env=self.env,
                                       stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                       start_new_session=True)
            deadline = time.monotonic() + self.timeout
            try:
                while process.poll() is None:
                    try:
                        process.wait(timeout=min(30, max(0.1, deadline - time.monotonic())))
                    except subprocess.TimeoutExpired:
                        if time.monotonic() >= deadline:
                            raise Halt(f"command timeout; outcome may be unknown: {prefix}")
                        print(json.dumps({"waitingFor": str(prefix), "at": now()}), flush=True)
            except BaseException:
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGTERM)
                    try:
                        process.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        process.wait()
                raise
        command_record.update(exitCode=process.returncode, finishedAt=now())
        write_json(prefix.with_suffix(".result.json"), command_record)
        if process.returncode and not allow_failure:
            raise Halt(f"command failed ({process.returncode}); stopped; see {prefix}.stderr.log")
        output = prefix.with_suffix(".stdout.log").read_text(encoding="utf-8")
        try:
            parsed = parse_cli_json(output)
        except Halt:
            if allow_failure:
                return process.returncode, None
            raise
        return process.returncode, parsed

    def helper(self, command, args, prefix):
        _, result = self.run([self.node, HELPER, command, self.repo, *args], prefix)
        need(result.get("valid") is True, f"helper {command} did not validate")
        return result

    def cli(self, script, command, args, prefix, *, allow_failure=False):
        return self.run([self.corepack, "pnpm@10.32.1", script, "--", command, *args], prefix,
                        allow_failure=allow_failure)


class Payload:
    def __init__(self, filename):
        self.path = Path(filename).resolve()
        self.value = read_json(self.path)
        self.root = Path(self.value["workspaceRoot"]).resolve()
        need(self.root.is_dir(), "workspaceRoot is unavailable")
        self.repo = self.within(self.value["repositoryPath"])
        self.output = self.within(self.value["outputDirectory"])
        need(not self.output.is_relative_to(self.repo), "receipts must stay outside the tooling checkout")
        self.runner = Runner(self.repo, self.value["runtimeBin"], self.within(self.value["corepackHome"]),
                             self.value["commandTimeoutSeconds"])
        self.files = {}

    def within(self, name):
        path = (self.root / name).resolve()
        need(path.is_relative_to(self.root), f"path outside workspaceRoot: {name}")
        return path

    def artifact(self, item, label):
        need(isinstance(item, dict) and isinstance(item.get("sha256"), str) and HEX.fullmatch(item["sha256"]), f"{label} artifact SHA is required")
        path = self.within(item["path"])
        data = path.read_bytes()
        need(digest(data) == item["sha256"], f"{label} artifact changed: {path}")
        self.files[label] = (path, data)
        return path, data

    def validate(self, out):
        self.runner.helper("schema", [SCHEMA, self.path], out / "payload-schema")
        p = self.value
        need(p["repositoryId"] == REPOSITORY and p["pullRequest"] == PR and p["expectedHead"] == HEAD, "fixed target mismatch")
        need([i["number"] for i in p["issues"]] == [1143, 1089], "Issue order must be 1143 then 1089")
        for name in ["requestContext", "capabilityEnvelope", "boundedSubject", "authorityMap", "progressIndex", "prBody"]:
            self.artifact(p[name], name)
        context = json.loads(self.files["requestContext"][1])
        need(context.get("source") == "current-user" and all(n in context.get("issues", []) for n in [1143, 1089]), "request context is not the actual current-user Sprint 4 scope")
        need(context.get("originalScopeRetained") is True, "original Sprint 4 scope must remain retained")
        envelope = json.loads(self.files["capabilityEnvelope"][1])
        need(envelope.get("executionMode") == "human-assisted" and envelope.get("executionModeSource") == "current-user", "capability mode/source mismatch")
        index_path, index_bytes = self.files["progressIndex"]
        self.index = json.loads(index_bytes)
        need(self.index.get("repository") == "Proto-UI/Proto-UI" and self.index.get("pr") == PR and self.index.get("head") == HEAD, "progress index target/head changed")
        comments = self.index.get("comments", [])
        need(self.index.get("count") == 13 and len(comments) == 13, "exactly 13 prepared progress comments required")
        self.comments = []
        prior = self.index["exclusiveBase"]
        for sequence, comment in enumerate(comments, 1):
            need(comment["sequence"] == sequence and comment["firstParent"] == prior, "progress first-parent chain/order mismatch")
            marker = f"agent-commit-progress:Proto-UI/Proto-UI#{PR}:{comment['sha']}"
            need(comment["marker"] == marker, "progress marker mismatch")
            body_path = (index_path.parent.parent / comment["path"]).resolve()
            need(body_path.is_relative_to(index_path.parent.parent), "progress path escaped draft directory")
            data = body_path.read_bytes()
            need(digest(data) == comment["sha256"] and len(data) == comment["bytes"] and len(data) <= 4000, "progress content/hash/size mismatch")
            text = data.decode("utf-8")
            need(text.count(marker) == 1 and "<!-- proto-ui-collaboration:" not in text, "progress body marker mismatch/reserved marker")
            self.comments.append(dict(comment, body=text, absolutePath=str(body_path)))
            prior = comment["sha"]
        need(prior == HEAD, "progress chain does not end at candidate")
        self.pr_body = self.files["prBody"][1].decode("utf-8")
        need(0 < len(self.pr_body) <= 65536, "PR body size invalid")
        self.issues = []
        for item in p["issues"]:
            n = item["number"]
            loaded = {name: self.artifact(item[name], f"issue-{n}-{name}") for name in ["originalIssue", "addition", "body", "interpretedComments"]}
            original = json.loads(loaded["originalIssue"][1])
            need(original["number"] == n and isinstance(original.get("body"), str), "original Issue source mismatch")
            body = loaded["body"][1]
            addition = loaded["addition"][1]
            need(body == addition + original["body"].encode("utf-8"), f"#{n} must retain the byte-exact entire original body as suffix")
            need(addition.decode().count(item["marker"]) == 1 and item["marker"] not in original["body"], "Issue marker missing/repeated/in original")
            need(0 < len(body.decode()) <= 65536, "Issue body size invalid")
            need(isinstance(json.loads(loaded["interpretedComments"][1]), list), "interpreted comment archive must be an exhaustive array")
            self.issues.append(dict(item, originalBody=original["body"], desiredBody=body.decode(), commentPath=str(loaded["interpretedComments"][0])))
        need(p["externalEvidence"] is not None, "root must supply the real external-evidence array and SHA (empty only when explicitly correct)")
        self.external_path, external_bytes = self.artifact(p["externalEvidence"], "externalEvidence")
        need(isinstance(json.loads(external_bytes), list), "external evidence must be an array")
        self.ready_report = None
        if p["ready"]["validationReport"] is not None:
            self.validation_path, data = self.artifact(p["ready"]["validationReport"], "validationReport")
            self.ready_report = json.loads(data)
        # This is only an immutable local intent fingerprint, NOT either protocol digest.
        intent = {k: p[k] for k in ["repositoryId", "pullRequest", "expectedHead", "requestContext", "progressIndex", "prTitle", "prBody", "prOriginalTitle", "prOriginalBodySha256"]}
        intent["issues"] = [{k: i[k] for k in ["number", "originalIssue", "addition", "body", "marker"]} for i in p["issues"]]
        self.intent_hash = digest(json.dumps(intent, sort_keys=True, ensure_ascii=False).encode())
        write_json(out / "payload-validation.json", {"valid": True, "repositoryId": REPOSITORY, "pullRequest": PR, "headSha": HEAD,
                    "comments": len(self.comments), "issueBodiesRetainOriginalBytes": True, "localIntentSha256": self.intent_hash,
                    "externalWrites": 0, "readyEnabled": p["ready"]["enabled"], "validatedAt": now()})

    def check_ready(self):
        need(self.value["ready"]["enabled"] is True, "Ready is disabled in the payload")
        r = self.ready_report
        need(isinstance(r, dict), "root must provide the actual final validation-report")
        need(r.get("repositoryId") == REPOSITORY and r.get("pullRequest") == PR and r.get("headSha") == HEAD, "final validation report is not bound to the exact target")
        need(r.get("readyForReview") is True, "final validation report does not state readiness")
        need(r.get("externalEvidenceSha256") == self.value["externalEvidence"]["sha256"], "validation report must bind the same external evidence array")
        # No inferred CI or approval result: root authors the evidence assessment;
        # the fresh canonical input is retained alongside it, including failures.


def artifact(kind, path, *, canonical_digest=None):
    return {"type": kind, "reference": str(path), "digest": "sha256:" + (canonical_digest or digest(Path(path).read_bytes()))}


def make_handoff(source, artifacts, next_skill="pui-collaborate"):
    return {"schemaVersion": 1, "kind": "proto-ui.skill-handoff", "entrypoint": "development",
            "executionMode": "human-assisted", "executionModeSource": "current-user", "fromId": source,
            "nextSkillId": next_skill, "artifacts": artifacts, "humanGates": [],
            "notes": ["Ordinary governed current-user Sprint 4 collaboration; no review disposition, lifecycle promotion, merge, or Issue closure.",
                      "V1 is the supported completed singleton handoff; Ready validation-report is bound identically in request and handoff."]}


def seal_request(runner, directory, request, artifacts, source):
    draft = directory / "request-draft.json"
    write_json(draft, request)
    _, result = runner.cli("agent:collaborate", "request-digest", ["--request", draft], directory / "request-digest")
    need(result.get("valid") is True and HEX.fullmatch(result.get("requestDigest", "")), "request-digest CLI failed")
    request = dict(request, requestDigest=result["requestDigest"])
    request_path = directory / "request.json"
    write_json(request_path, request)
    handoff = make_handoff(source, artifacts + [artifact("collaboration-request", request_path, canonical_digest=request["requestDigest"])])
    handoff_path = directory / "handoff.json"
    write_json(handoff_path, handoff)
    runner.helper("validate-pair", [request_path, handoff_path], directory / "schema-pair")
    _, validation = runner.cli("agent:collaborate", "validate", [*MODE, "--request", request_path, "--handoff", handoff_path], directory / "cli-validate")
    need(validation.get("valid") is True, "repository CLI validation failed")
    return request, request_path, handoff, handoff_path


class Execution:
    def __init__(self, payload, command, session):
        self.p = payload
        self.r = payload.runner
        self.command = command
        self.session = session
        self.journal_path = payload.output / "journal.json"
        self.journal = read_json(self.journal_path) if self.journal_path.exists() else {
            "kind": "sprint4.final-collaboration-journal", "repositoryId": REPOSITORY, "pullRequest": PR,
            "headSha": HEAD, "localIntentSha256": payload.intent_hash, "operations": {}}
        need(self.journal["localIntentSha256"] == payload.intent_hash, "prepared update content differs from the existing journal; do not overwrite prior intent")
        blocked = {k: v for k, v in self.journal["operations"].items() if v["state"] not in ["verified", "observed-already-present"]}
        need(not blocked, f"prior write is unresolved/rejected; no retry allowed: {list(blocked)}")

    def journal_state(self, op, value):
        self.journal["operations"][op] = value
        self.journal["updatedAt"] = now()
        write_json(self.journal_path, self.journal, replace=True)

    def collect(self, op, issue=None):
        d = self.session / op
        d.mkdir()
        if issue is None:
            self.r.helper("collect-pr", [self.p.external_path, d], d / "collect")
            _, result = self.r.cli("agent:review", "input-digest", ["--input", d / "review-input.json"], d / "input-digest")
            need(result.get("valid") is True and HEX.fullmatch(result.get("reviewInputDigest", "")), "review-input CLI digest unavailable")
            review_digest = result["reviewInputDigest"]
            source = "pui-pr"
        else:
            self.r.helper("collect-issue", [str(issue["number"]), issue["commentPath"], d], d / "collect")
            review_digest = None
            source = "pui-issue"
        snapshot = read_json(d / "github-snapshot.json")
        if issue is None:
            viewer = snapshot["collection"]
            need(viewer["viewerLogin"].lower() == self.p.value["expectedActor"].lower(), "authenticated actor changed")
            need(snapshot["pullRequest"]["draft"] is True or self.command == "ready", "PR unexpectedly already Ready during updates")
            input_value = read_json(d / "review-input.json")
            shas = {c["sha"] for c in input_value["commits"]}
            need(all(c["sha"] in shas for c in self.p.comments), "progress commit absent from current PR canonical commit set")
            report = {"kind": "sprint4.pull-request-report", "repositoryId": REPOSITORY, "pullRequest": PR,
                      "baseRefName": input_value["baseRefName"], "baseSha": input_value["baseSha"], "headSha": HEAD,
                      "observedAt": snapshot["observedAt"], "reviewInputDigest": review_digest,
                      "reviewClass": "review-governed-implementation-slice", "scope": "Prepared progress/title/body/Ready collaboration only",
                      "facts": {"state": input_value["pullRequestState"], "isDraft": input_value["isDraft"],
                                "reviews": input_value["reviews"], "threads": input_value["threads"], "checks": input_value["checks"],
                                "mergeable": viewer["mergeable"], "mergeStateStatus": viewer["mergeStateStatus"],
                                "externalEvidence": input_value["externalEvidence"], "conversationComments": len(input_value["comments"])},
                      "interpretation": self.p.value["prInterpretationNotes"],
                      "limits": ["Canonical input was fully collected twice; this report does not manufacture an independent review or reinterpret every discussion.",
                                 "CI, independent acceptance, and external delivery remain separate. Check failures/pending results stay in the input.",
                                 "Metadata API has no atomic compare-and-swap; CLI preflight/final admission/readback delimit this operation."],
                      "nextSkillId": "pui-collaborate"}
            report_type = "pull-request-report"
        else:
            viewer = snapshot
            need(viewer["viewerLogin"].lower() == self.p.value["expectedActor"].lower(), "authenticated actor changed")
            report_type = "issue-report"
            report = {"kind": "sprint4.issue-report", "repositoryId": REPOSITORY, "issue": issue["number"],
                      "observedAt": snapshot["observedAt"], "query": f"repo:Proto-UI/Proto-UI issue:{issue['number']} all comments",
                      "truncated": False, "collection": snapshot["collection"], "facts": {"metadata": snapshot["metadata"], "state": snapshot["issue"]["state"]},
                      "interpretation": {"archive": issue["commentPath"], "allCommentIdsAndExactBodiesMatchInspectedArchive": True,
                                         "notes": issue["interpretationNotes"]},
                      "proposal": "Prepend the prepared evidence block; keep the complete original body byte-exact; keep Issue open.",
                      "unknowns": ["Project fields are not queried or changed by this bounded body-only operation."],
                      "nextSkillId": "pui-collaborate"}
        report_path = d / f"{report_type}.json"
        write_json(report_path, report)
        envelope = json.loads(self.p.files["capabilityEnvelope"][1])
        envelope.update(authenticatedActor=viewer["viewerLogin"], viewerPermission=viewer["viewerPermission"],
                        observedActorAt=snapshot["observedAt"], currentOperation=op,
                        permissionsObserved={"repositoryPermission": viewer["viewerPermission"]})
        envelope_path = d / "capability-envelope.json"
        write_json(envelope_path, envelope)
        artifacts = [artifact("request-context", self.p.files["requestContext"][0]), artifact("capability-envelope", envelope_path),
                     artifact("bounded-subject", self.p.files["boundedSubject"][0]), artifact("authority-map", self.p.files["authorityMap"][0]),
                     artifact("github-snapshot", d / "github-snapshot.json"), artifact(report_type, report_path)]
        if review_digest:
            artifacts.append(artifact("review-input", d / "review-input.json", canonical_digest=review_digest))
        return d, snapshot, source, artifacts

    def already(self, op, d, source, artifacts, detail):
        previous = self.journal["operations"].get(op)
        record = {"kind": "sprint4.observed-no-write-disposition", "operation": op, "state": "observed-already-present",
                  "observedAt": now(), "headSha": HEAD, "detail": detail, "externalMutationAttempts": 0,
                  "notACollaborationCliReceipt": True, "priorVerifiedOperation": previous}
        write_json(d / "no-write-disposition.json", record)
        write_json(d / "completed-handoff.json", make_handoff(source, artifacts, None))
        self.r.helper("validate-handoff", [d / "completed-handoff.json"], d / "completed-handoff-validation")
        self.journal_state(op, dict(record, directory=str(d)))
        print(json.dumps({"operation": op, "outcome": "already-present", "mutationCount": 0}), flush=True)

    def apply(self, op, d, snapshot, source, artifacts, action, expected, desired, rationale):
        need(op not in self.journal["operations"], f"previously verified {op} no longer matches live state; stop rather than repair it implicitly")
        purpose = artifact("current-user-instruction", self.p.files["requestContext"][0])
        write_json(d / "prepared-action.json", {"action": action, "target": snapshot["target"], "expected": expected, "desired": desired})
        evidence = [purpose, artifact("prepared-content", d / "prepared-action.json"), artifact("external-evidence", self.p.external_path)]
        if action == READY:
            validation = artifact("validation-report", self.p.validation_path)
            artifacts.append(validation)
            evidence.append(validation)
        request = {"schemaVersion": 1, "kind": "proto-ui.collaboration-request", "repositoryId": REPOSITORY,
                   "authorizationId": "explicit-current-user", "action": action, "requestedAt": now(),
                   "requestDigest": "0" * 64, "target": snapshot["target"], "expected": expected, "desired": desired,
                   "evidence": evidence, "rationale": rationale, "humanGates": []}
        auth_path = d / "mutation-authorization.json"
        write_json(auth_path, {"authorizationId": "explicit-current-user", "executionMode": "human-assisted",
                   "executionModeSource": "current-user", "currentUserInstruction": purpose,
                   "sanitizedUserRequest": "补完 Sprint 4", "repositoryId": REPOSITORY, "headSha": HEAD,
                   "action": action, "target": snapshot["target"], "rationale": rationale,
                   "limits": ["Prepared bounded collaboration only; no new review, merge, Issue close, release, or stable lifecycle acceptance."]})
        artifacts.append({"type": "mutation-authorization", "reference": "explicit-current-user", "digest": "sha256:" + digest(auth_path.read_bytes())})
        request["evidence"].append(artifact("authorization-record", auth_path))
        request, request_path, handoff, handoff_path = seal_request(self.r, d, request, artifacts, source)
        # Durable write-ahead record BEFORE spawning the only mutation process.
        record = {"state": "in-flight", "directory": str(d), "requestDigest": request["requestDigest"], "startedAt": now()}
        self.journal_state(op, record)
        try:
            code, receipt = self.r.cli("agent:collaborate", "apply", [*MODE, "--request", request_path, "--handoff", handoff_path], d / "apply", allow_failure=True)
            if receipt is not None:
                write_json(d / "receipt.json", receipt)
            need(code == 0 and receipt is not None, "collaboration failed/unknown; no retry; inspect saved CLI logs and result")
            need(receipt.get("outcome") in ["applied", "no-op"], f"collaboration rejected: {receipt.get('note')}")
            self.r.helper("verify-receipt", [request_path, d / "receipt.json", d / "readback.json", self.p.value["expectedActor"]], d / "readback-validation")
            completed = make_handoff("pui-collaborate", handoff["artifacts"] + [artifact("mutation-receipt", d / "receipt.json")], None)
            write_json(d / "completed-handoff.json", completed)
            self.r.helper("validate-handoff", [d / "completed-handoff.json"], d / "completed-handoff-validation")
            record.update(state="verified", completedAt=now(), outcome=receipt["outcome"], mutationCount=receipt["mutationCount"], receipt=str(d / "receipt.json"))
            self.journal_state(op, record)
            print(json.dumps({"operation": op, "outcome": receipt["outcome"], "mutationCount": receipt["mutationCount"]}), flush=True)
        except BaseException as error:
            record.update(state="halted-unresolved", stoppedAt=now(), reason=str(error), retryPermitted=False)
            self.journal_state(op, record)
            raise

    def find_progress(self, snapshot, comment):
        matches = [c for c in snapshot["collection"]["input"]["comments"] if comment["marker"] in c["body"]]
        need(len(matches) <= 1, f"duplicate progress marker: {comment['marker']}")
        if not matches:
            return None
        c = matches[0]
        need(c["author"].lower() == self.p.value["expectedActor"].lower(), "progress marker belongs to another actor")
        # Our exact supplied body plus the only marker trailer the CLI appends.
        pattern = re.escape(comment["body"]) + r"(?:\n\n<!-- proto-ui-collaboration:[a-f0-9]{64} -->)?\Z"
        need(re.fullmatch(pattern, c["body"]) is not None, "existing progress marker has different body")
        return {"id": c["id"], "author": c["author"], "updatedAt": c["updatedAt"], "bodySha256": digest(c["body"].encode())}

    def updates(self):
        for comment in self.p.comments:
            op = f"progress-{comment['sequence']:02d}-{comment['sha'][:8]}"
            d, snapshot, source, artifacts = self.collect(op)
            existing = self.find_progress(snapshot, comment)
            if existing:
                self.already(op, d, source, artifacts, existing)
                continue
            self.apply(op, d, snapshot, source, artifacts, COMMENT, {"markerAbsent": True}, {"body": comment["body"]},
                       f"Publish the prepared bounded progress for commit {comment['sha']} under the current user's Sprint 4 request; retain actual failures and remaining acceptance.")
        op = "pr-title-body"
        d, snapshot, source, artifacts = self.collect(op)
        expected = snapshot["metadata"]
        desired = dict(expected, title=self.p.value["prTitle"], body=self.p.pr_body)
        need(expected["title"] in [self.p.value["prOriginalTitle"], self.p.value["prTitle"]],
             "PR title changed after draft preparation; stop instead of overwriting another edit")
        need(expected["body"] == self.p.pr_body or
             (isinstance(expected["body"], str) and digest(expected["body"].encode("utf-8")) == self.p.value["prOriginalBodySha256"]),
             "PR body changed after draft preparation; stop instead of overwriting another edit (live snapshot preserved)")
        if desired == expected:
            self.already(op, d, source, artifacts, {"metadataMatches": True})
        else:
            self.apply(op, d, snapshot, source, artifacts, METADATA, expected, desired,
                       "Update PR #1754's prepared title/body with exact-head evidence and retained unresolved Sprint 4 scope; preserve labels, milestone and assignees.")
        for issue in self.p.issues:
            op = f"issue-{issue['number']}-body"
            d, snapshot, source, artifacts = self.collect(op, issue)
            expected = snapshot["metadata"]
            if expected["body"] == issue["desiredBody"]:
                self.already(op, d, source, artifacts, {"bodyMatches": True, "originalSuffixRetained": True})
                continue
            need(expected["body"] == issue["originalBody"], f"#{issue['number']} body changed from the prepared source; stop instead of overwriting concurrent edits")
            desired = dict(expected, body=issue["desiredBody"])
            self.apply(op, d, snapshot, source, artifacts, METADATA, expected, desired,
                       f"Prepend the prepared PR #1754 evidence block to #{issue['number']}; retain the full byte-exact original body and all unfinished conditions; keep the Issue open.")

    def ready(self):
        self.p.check_ready()
        expected_ops = [f"progress-{c['sequence']:02d}-{c['sha'][:8]}" for c in self.p.comments] + ["pr-title-body", "issue-1143-body", "issue-1089-body"]
        need(all(k in self.journal["operations"] for k in expected_ops), "complete and verify all 16 updates before separate Ready call")
        # Recheck the same two Issue bodies/comments, without any repair/write.
        for issue in self.p.issues:
            d, snapshot, source, artifacts = self.collect(f"ready-check-issue-{issue['number']}", issue)
            need(snapshot["metadata"]["body"] == issue["desiredBody"], "Issue body changed since publication")
            write_json(d / "read-only-check.json", {"valid": True, "externalMutationAttempts": 0})
        op = "ready"
        d, snapshot, source, artifacts = self.collect(op)
        need(snapshot["metadata"]["title"] == self.p.value["prTitle"] and snapshot["metadata"]["body"] == self.p.pr_body, "PR title/body changed before Ready")
        need(all(self.find_progress(snapshot, c) for c in self.p.comments), "progress comment missing before Ready")
        if snapshot["pullRequest"]["draft"] is False:
            self.already(op, d, source, artifacts, {"alreadyReadyAtExpectedHead": True})
            return
        self.apply(op, d, snapshot, source, artifacts, READY, {"isDraft": True}, {"isDraft": False},
                   "Mark only the exact candidate head Ready using the coordinator's final bound validation report; retain recorded limitations and do not represent Ready as independent approval or merge authority.")


def offline_validate(args):
    """Actual repository schemas + CLI digests/admission; no apply or gh invocation."""
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=False)
    runner = Runner(args.repo, args.runtime_bin, args.corepack_home)
    runner.helper("fixture-review", [out / "review-input.json"], out / "fixture")
    _, review = runner.cli("agent:review", "input-digest", ["--input", out / "review-input.json"], out / "review-digest")
    need(review.get("valid") is True, "offline canonical fixture failed")
    for label in ["capability-envelope", "github-snapshot", "pull-request-report", "issue-report", "request-context", "mutation-authorization", "validation-report"]:
        write_json(out / f"{label}.json", {"synthetic": True, "kind": label, "note": "OFFLINE SCHEMA FIXTURE; not evidence, not readiness, no remote actions"})
    variants = [
        ("comment", COMMENT, "pui-pr", {"markerAbsent": True}, {"body": "OFFLINE SCHEMA FIXTURE ONLY"}, "pull-request", PR),
        ("pr-metadata", METADATA, "pui-pr", {"title": "before", "body": "before", "milestoneNumber": None, "assignees": [], "labels": []}, {"title": "after", "body": "after", "milestoneNumber": None, "assignees": [], "labels": []}, "pull-request", PR),
        ("issue-metadata", METADATA, "pui-issue", {"title": "unchanged", "body": "before", "milestoneNumber": None, "assignees": [], "labels": []}, {"title": "unchanged", "body": "addition\nbefore", "milestoneNumber": None, "assignees": [], "labels": []}, "issue", 1143),
        ("ready", READY, "pui-pr", {"isDraft": True}, {"isDraft": False}, "pull-request", PR),
    ]
    results = []
    for label, action, source, expected, desired, kind, number in variants:
        d = out / label
        d.mkdir()
        artifacts = [artifact(t, out / f"{t}.json") for t in ["capability-envelope", "github-snapshot", "pull-request-report" if source == "pui-pr" else "issue-report"]]
        artifacts.append({"type": "mutation-authorization", "reference": "explicit-current-user", "digest": "sha256:" + digest((out / "mutation-authorization.json").read_bytes())})
        if source == "pui-pr":
            artifacts.append(artifact("review-input", out / "review-input.json", canonical_digest=review["reviewInputDigest"]))
        evidence = [artifact("current-user-instruction", out / "request-context.json")]
        if action == READY:
            validation = artifact("validation-report", out / "validation-report.json")
            evidence.append(validation)
            artifacts.append(validation)
        request = {"schemaVersion": 1, "kind": "proto-ui.collaboration-request", "repositoryId": REPOSITORY,
                   "authorizationId": "explicit-current-user", "action": action, "requestedAt": now(), "requestDigest": "0" * 64,
                   "target": {"kind": kind, "number": number, "updatedAt": "2026-11-23T00:00:00Z", "headSha": HEAD if kind == "pull-request" else None},
                   "expected": expected, "desired": desired, "evidence": evidence,
                   "rationale": "OFFLINE STRUCTURE FIXTURE: validates schemas and digest bindings only; no live facts or authorization claim.", "humanGates": []}
        sealed, _, _, _ = seal_request(runner, d, request, artifacts, source)
        results.append({"case": label, "schemasAndRepositoryCliValidate": True, "requestDigest": sealed["requestDigest"]})
    write_json(out / "summary.json", {"valid": True, "synthetic": True, "externalReads": 0, "externalWrites": 0,
                "node": runner.node_version, "repo": str(runner.repo), "cases": results,
                "limitations": ["No live state, permission, CI, evidence truth, mutation, or readback was exercised."]})
    print(json.dumps({"valid": True, "offlineCases": len(results), "externalWrites": 0, "report": str(out / "summary.json")}), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ["validate-payload", "apply-updates", "ready"]:
        sub.add_parser(name).add_argument("--payload", required=True)
    off = sub.add_parser("offline-validate")
    off.add_argument("--repo", required=True)
    off.add_argument("--runtime-bin", required=True)
    off.add_argument("--corepack-home", required=True)
    off.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.command == "offline-validate":
        offline_validate(args)
        return
    payload = Payload(args.payload)
    payload.output.mkdir(parents=True, exist_ok=True)
    with (payload.output / "runner.lock").open("a+") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise Halt("another final collaboration runner holds the workspace lock")
        session = payload.output / f"{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')}-{args.command}"
        session.mkdir()
        try:
            payload.validate(session)
            if args.command == "validate-payload":
                print(json.dumps({"valid": True, "externalWrites": 0, "report": str(session / 'payload-validation.json')}), flush=True)
                return
            need(payload.value["allowWrites"] is True, "allowWrites is false; only the coordinator may enable actual execution")
            # Every artifact was checked before operation construction. Copy the
            # caller's payload for audit; subprocesses never execute its prose.
            write_json(session / "payload.json", payload.value)
            execution = Execution(payload, args.command, session)
            execution.updates() if args.command == "apply-updates" else execution.ready()
            write_json(session / "complete.json", {"command": args.command, "completedAt": now(), "headSha": HEAD,
                       "readyAutomaticallyCalled": False, "journal": str(execution.journal_path)})
        except BaseException as error:
            write_json(session / "stopped.json", {"command": args.command, "stoppedAt": now(), "reason": str(error), "automaticRetry": False})
            raise


if __name__ == "__main__":
    try:
        main()
    except (Halt, OSError, ValueError, KeyError) as error:
        print(f"[final-collaboration] STOP: {error}", file=sys.stderr)
        sys.exit(1)
