// Editable generated Vue 2.6.14 component options. Profile: vue2-source-v1.
// Inline native-lowering helpers: logical owner, prop resolution, state, semantic templates.
// No Proto-UI Core, Runtime, Hooks or Adapter dependency; optional native helpers are emitted artifacts.
// Source graph SHA-256: a9eb18c4d14173d2aa7c8a9482363b7896944117e7ec4964ecc4f2afaa8bc372
import {createNativeShader as __pui_CreateShader} from './.proto-ui/shader/owner-web-v1';



import { createNativeStyle as __pui_CreateNativeStyle, templateStyleTokens as __pui_TemplateStyleTokens } from './.proto-ui/style/native-v1';
import { createContextScope as __pui_CreateContextScope, scopeKey as __pui_ScopeKey, acceptsContextValue as __pui_AcceptsContextValue } from './.proto-ui/context/scope-v1';


// Source "packages/compiler/test/fixtures/shader-static-data-owner.proto.ts":6:1
const __puiModule0 = /** @param {number} multiplier @returns {{ readonly "version": 1; readonly "source": ({ readonly "kind": "owned-pixels"; readonly "width": number; readonly "height": number; readonly "pixels": ReadonlyArray<number>; readonly "colorSpace": "linear-srgb"; readonly "alpha": "premultiplied"; readonly "origin": "top-left" }) | ({ readonly "kind": "owned-scene"; readonly "slot": string }); readonly "passes": ReadonlyArray<{ "id": string; "kernel": "copy-rgba8-v1" | "tint-rgba8-v1"; "input": string; "tint"?: ReadonlyArray<number> }>; readonly "output": string; readonly "fallback": ReadonlyArray<number> }} */ (multiplier = __puiModule1) => {
  // Source "packages/compiler/test/fixtures/shader-static-data-owner.proto.ts":7:9
  const graph = /** @type {{ readonly "version": 1; readonly "source": ({ readonly "kind": "owned-pixels"; readonly "width": number; readonly "height": number; readonly "pixels": ReadonlyArray<number>; readonly "colorSpace": "linear-srgb"; readonly "alpha": "premultiplied"; readonly "origin": "top-left" }) | ({ readonly "kind": "owned-scene"; readonly "slot": string }); readonly "passes": ReadonlyArray<{ "id": string; "kernel": "copy-rgba8-v1" | "tint-rgba8-v1"; "input": string; "tint"?: ReadonlyArray<number> }>; readonly "output": string; readonly "fallback": ReadonlyArray<number> }} */ ({ ["version"]: 1, ["source"]: { ["kind"]: "owned-pixels", ["width"]: 2, ["height"]: 2, ["pixels"]: __puiModule2, ["colorSpace"]: "linear-srgb", ["alpha"]: "premultiplied", ["origin"]: "top-left" }, ["passes"]: [{ ["id"]: "copied", ["kernel"]: "copy-rgba8-v1", ["input"]: "$source" }, { ["id"]: "tinted", ["kernel"]: "tint-rgba8-v1", ["input"]: "copied", ["tint"]: [multiplier, 1, 0.25, 0.5] }], ["output"]: "tinted", ["fallback"]: [0.15, 0.2, 0.25, 1] });
  // Source "packages/compiler/test/fixtures/shader-static-data-owner.proto.ts":25:9
  const result = graph;
  // Source "packages/compiler/test/fixtures/shader-static-data-owner.proto.ts":26:3
  return result;
};
// Source "packages/compiler/test/fixtures/shader-static-data-owner.proto.ts":3:14
const __puiModule1 = 0.5;
// Source "packages/compiler/test/fixtures/shader-static-data-owner.proto.ts":4:16
const __puiModule2 = [255, 0, 0, 255, 0, 128, 0, 128, 0, 0, 64, 64, 64, 128, 192, 255];


/** @typedef {{
  "visible"?: boolean | null;
}} GeneratedProps */
/** @typedef {Readonly<{
  readonly "visible": boolean;
} & Record<string, unknown>>} __pui_ResolvedProps */
/** @typedef {{

}} GeneratedExposes */
/** @typedef {Array<import('vue').VNode | string>} __pui_NativeChildren */
/** @typedef {{ used: boolean }} __pui_NativeSlotFrame */
/** @typedef {(h: import('vue').CreateElement, vm: import('vue').default, slots: __pui_NativeSlotFrame) => __pui_NativeChildren} __pui_NativePaint */
/** @typedef {{
 * slot: () => __pui_NativePaint,
 * read: {
 *   props: {
 *     get: () => __pui_ResolvedProps,
 *     getRaw: () => Readonly<Record<string, unknown>>,
 *     isProvided: (key: PropertyKey) => boolean
 *   },
 *   context: {
 *     read: (key: object) => ReturnType<import('./.proto-ui/context/scope-v1').ContextScope['read']>,
 *     tryRead: (key: object) => ReturnType<import('./.proto-ui/context/scope-v1').ContextScope['tryRead']>
 *   }
 * }
 * }} __pui_NativeRenderer */
/** @typedef {import('./.proto-ui/style/native-v1').NativeStyleHandle} __pui_NativeStyleHandle */

/**
 * @template T
 * @typedef {{ get: () => T, subscribe: (callback: (event: { type: 'next', prev: T, next: T, reason?: unknown } | { type: 'disconnect', reason: 'unmount' }) => void) => (() => void), unsubscribe: (off: () => void) => void, spec: Readonly<Record<string, unknown>> }} __pui_ExternalState
 */
/** @typedef {'boolean' | 'number' | 'string' | 'null' | 'void' | { kind: 'literal', value: string | number | boolean | null } | { kind: 'array', element: __pui_DataType } | { kind: 'union', members: readonly __pui_DataType[] } | { kind: 'record', fields: readonly { name: string, type: __pui_DataType, optional?: boolean }[] }} __pui_DataType */
/** @typedef {Readonly<Record<string, unknown>>} __pui_RawProps */
/** @typedef {{ type: 'boolean' | 'number' | 'string' | 'object' | 'any' | 'enum', empty?: 'accept' | 'fallback' | 'error', default?: unknown, options?: readonly string[], range?: { min?: number, max?: number } }} __pui_PropSpec */
/** @typedef {{ options?: readonly (boolean | string | number)[], min?: unknown, max?: unknown, step?: unknown, clamp?: boolean } & Record<string, unknown>} __pui_StateConfiguration */
/** @typedef {'bool' | 'string' | 'enum' | 'number.discrete' | 'number.range'} __pui_StateKind */
/** @typedef {ReturnType<typeof __pui_CreateOwner>} __pui_Owner */
/** @typedef {Parameters<Parameters<__pui_Owner['def']['props']['watch']>[1]>[0]} __pui_Run */
/** @typedef {import('vue').default & { readonly instanceAssociations?: Readonly<{controlLabel?: object | null}>; readonly __pui_ParentScope?: import('./.proto-ui/context/scope-v1').ContextScope | null }} __pui_OwnerInstance */
/** @typedef {(renderer: __pui_NativeRenderer) => __pui_NativePaint} __pui_RenderFunction */
/** @typedef {{ changedKeysAll: string[], changedKeysMatched: string[] }} __pui_PropsWatchInfo */
/** @template Run @template Snapshot @typedef {(run: Run, next: Snapshot, previous: Snapshot, info: __pui_PropsWatchInfo) => void} __pui_PropsWatchCallback */
/** @template Run @typedef {{ kind: 'resolved' | 'resolved-all', keys: readonly string[] | null, fn: __pui_PropsWatchCallback<Run, __pui_ResolvedProps> } | { kind: 'raw' | 'raw-all', keys: readonly string[] | null, fn: __pui_PropsWatchCallback<Run, __pui_RawProps> }} __pui_PropsWatchRegistration */
/** @typedef {"created" | "mounted" | "updated" | "unmounted" | "beforeDispose"} __pui_LifecycleKind */
/** @template Run @typedef {(run: Run) => void} __pui_LifecycleCallback */
/** @template Run @typedef {__pui_PropsWatchRegistration<Run> & { active: boolean }} __pui_PropsWatcher */
/** @typedef {{ epoch: number, revision: number, kind: 'update' }} __pui_PendingCommit */
/** @typedef {{ epoch: number, version: number, present: boolean, vnode: import('vue').VNode, kind: 'mount' | 'update' | 'none' | 'detach', revision?: number | null }} __pui_RenderedCommit */
/** @param {unknown} value @param {PropertyKey} key */
const __pui_Own = (value, key) => Object.prototype.hasOwnProperty.call(value, key);

/** @param {__pui_DataType} type @param {unknown} value @returns {boolean} */
function __pui_Accepts(type, value) {
  if (typeof type === 'string') return type === 'null' ? value === null : typeof value === type && (type !== 'number' || Number.isFinite(value));
  if (type.kind === 'literal') return Object.is(value, type.value);
  if (type.kind === 'union') return type.members.some((member) => __pui_Accepts(member, value));
  if (type.kind === 'array') return Array.isArray(value) && value.every((item) => __pui_Accepts(type.element, item));
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false;
  const record = /** @type {Record<string, unknown>} */ (value);
  return type.fields.every((field) =>
    __pui_Own(record, field.name) ? __pui_Accepts(field.type, record[field.name]) : field.optional === true);
}
/** @param {unknown} value @param {Set<object>} [seen] @returns {boolean} */
function __pui_Json(value, seen = new Set()) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return true;
  if (typeof value === 'number') return Number.isFinite(value);
  if (typeof value !== 'object' || seen.has(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  if (!Array.isArray(value) && prototype !== Object.prototype && prototype !== null) return false;
  if (Array.isArray(value) && (Object.keys(value).length !== value.length || !Object.keys(value).every((key) => /^(0|[1-9]\d*)$/.test(key) && Number(key) < value.length))) return false;
  seen.add(value);
  const valid = Object.values(value).every((item) => __pui_Json(item, seen));
  seen.delete(value);
  return valid;
}


/** @param {__pui_OwnerInstance} vm @param {(owner: __pui_Owner) => __pui_RenderFunction | void} setup @param {Record<string, __pui_DataType>} types @param {string} rootTag @param {boolean} autoUpdate */
function __pui_CreateOwner(vm, setup, types, rootTag, autoUpdate) {
  
  let phase = 'setup';
  let terminal = false;
  let disposed = false;
  let hydrated = false;
  let nativeMounted = false;
  let hostActive = true;
  let present = true;
  let viewActive = false;
  let epoch = 0;
  let revision = 0;
  let commitVersion = 0;
  let queued = false;
  /** @type {__pui_PendingCommit | null} */
  let pending = null;
  /** @type {__pui_RenderedCommit | null} */
  let renderedCommit = null;
  /** @type {Element | null} */ let activeRoot = null;
  
  /** @type {__pui_NativePaint | null} */
  let template = null;
  /** @type {__pui_RenderFunction | null | void} */
  let renderFunction;
  /** @type {(() => void) | undefined} */
  let unwatch;
  /** @type {__pui_RawProps} */
  let raw = Object.freeze({});
  /** @type {__pui_ResolvedProps} */
  let resolved = /** @type {__pui_ResolvedProps} */ (Object.freeze({}));
  /** @type {Record<string, unknown>} */
  let previousValid = Object.create(null);
  /** @type {Record<string, __pui_PropSpec>} */
  let specs = Object.create(null);
  /** @type {__pui_RawProps[]} */
  const defaults = [];
  /** @type {Array<__pui_PropsWatcher<typeof run>>} */
  const watchers = [];
  /** @type {Record<string, unknown>} */
  const exposed = Object.create(null);
  /** @type {Record<string, unknown>} */
  const eventDeclarations = Object.create(null);
  /** @type {Record<__pui_LifecycleKind, Array<__pui_LifecycleCallback<typeof run>>>} */
  const lifecycle = { "created": [], "mounted": [], "updated": [], "unmounted": [], "beforeDispose": [] };
  
  let dispatchingProps = false;
  /** @type {{raw: __pui_RawProps; resolved: __pui_ResolvedProps} | null} */
  let propsWindow = null;
  const alive = () => { if (disposed) throw new Error('[Vue2 native] logical instance has been disposed.'); };
  const publicAlive = () => { if (terminal) throw new Error('[Vue2 native] exposed target has been terminally invalidated.'); };
  const callback = () => { alive(); if (phase !== 'callback') throw new Error('[Vue2 native] mutation requires callback scope.'); };
  const setupOnly = () => { alive(); if (phase !== 'setup') throw new Error('[Vue2 native] declaration requires setup scope.'); };
  const style = __pui_CreateNativeStyle({
    
    ensureSetup: setupOnly,
    ensureRuntime: callback,
    isAlive: () => !terminal && !disposed,
    project: (tokens) => {
      if (!activeRoot) return;
      if (tokens.length) activeRoot.setAttribute('data-pui-style', tokens.join(' '));
      else activeRoot.removeAttribute('data-pui-style');
    },
  });
  /** @returns {__pui_RawProps} */
  const hostRaw = () => {
    
    // Full snapshots preserve omission and explicit undefined. Vue Boolean casting and
    // default materialization never participate in the semantic prop contract.
    const out = Object.create(null);
    /** @type {Record<string, unknown>} */
    const input = { ...(vm.$attrs || {}), ...((vm.$options && vm.$options.propsData) || {}) };
    /** @type {Readonly<Record<string, unknown>>} */
    const provided = /** @type {Readonly<Record<string, unknown>>} */ ((vm.$options && vm.$options.propsData) || {});
    for (const key of Object.keys(types)) {
      const hostKey = key.replace(/-(\w)/g, (_match, letter) => letter.toUpperCase());
      // Track native prop notifications, but keep values/presence from the raw snapshot.
      if (vm.$props) void (/** @type {Readonly<Record<string, unknown>>} */ (vm.$props))[hostKey];
      if (__pui_Own(provided, hostKey)) input[key] = provided[hostKey];
    }
    for (const key of Object.keys(input)) if (key !== 'instanceAssociations' && key !== 'instance-associations') out[key] = input[key];
    return Object.freeze(out);
  };
  /** @param {__pui_RawProps} a @param {__pui_RawProps} b */
  const same = (a, b) => {
    const keys = Object.keys(a);
    return keys.length === Object.keys(b).length && keys.every((key) => __pui_Own(b, key) && Object.is(a[key], b[key]));
  };
  /** @param {string} key @param {unknown} value */
  const validValue = (key, value) => {
    const spec = specs[key];
    if (!__pui_Json(value) || !__pui_Accepts(types[key], value)) return false;
    if (spec.type === 'enum' && (typeof value !== 'string' || !spec.options?.includes(value))) return false;
    return !spec.range || typeof value === 'number' && value >= (spec.range.min ?? -Infinity) && value <= (spec.range.max ?? Infinity);
  };
  /** @param {__pui_RawProps} input @param {boolean} strict */
  const resolveProps = (input, strict) => {
    /** @type {Record<string, unknown>} */
    const out = Object.create(null);
    const nextValid = { ...previousValid };
    /** @type {{ providedKeys: string[], emptyKeys: string[], invalidKeys: string[], usedFallbackKeys: string[], acceptedEmptyKeys: string[] }} */
    const meta = { providedKeys: [], emptyKeys: [], invalidKeys: [], usedFallbackKeys: [], acceptedEmptyKeys: [] };
    for (const key of Object.keys(specs)) {
      const spec = specs[key];
      const provided = __pui_Own(input, key);
      const value = input[key] === undefined ? null : input[key];
      const empty = spec.empty ?? 'fallback';
      if (provided) meta.providedKeys.push(key);
      if (provided && value !== null && validValue(key, value)) {
        out[key] = value; nextValid[key] = value; continue;
      }
      if (provided && value === null) {
        meta.emptyKeys.push(key);
        if (empty === 'accept') { out[key] = null; meta.acceptedEmptyKeys.push(key); continue; }
      } else if (provided) meta.invalidKeys.push(key);
      let found = false;
      /** @type {unknown} */
      let selected = null;
      let usedDefault = true;
      /** @param {unknown} candidate @param {boolean} fromDefault */
      const take = (candidate, fromDefault) => {
        if (found || candidate === undefined || strict && empty === 'error' && candidate === null) return;
        if (candidate !== null && !validValue(key, candidate)) return;
        found = true; selected = candidate; usedDefault = fromDefault;
      };
      if (provided && __pui_Own(previousValid, key)) take(previousValid[key], false);
      for (const layer of defaults) if (__pui_Own(layer, key)) take(layer[key], true);
      if (__pui_Own(spec, 'default')) take(spec.default, true);
      if (!found && strict && empty === 'error') throw new Error('[Vue2 native] prop ' + key + ' requires a non-empty valid value or fallback.');
      out[key] = selected;
      if (usedDefault) meta.usedFallbackKeys.push(key);
      if (provided && selected !== null) nextValid[key] = selected;
    }
    previousValid = nextValid;
    /** @type {__pui_ResolvedProps} */
    const snapshot = /** @type {__pui_ResolvedProps} */ (Object.freeze(out));
    return { snapshot, meta };
  };
  /** @template T @param {() => T} fn @param {boolean} [sync] @returns {T} */
  const invoke = (fn, sync = true) => {
    alive();
    const previousPhase = phase;
    phase = 'callback';
    try { if (sync && !terminal ) syncHost(false); return fn(); }
    finally { phase = previousPhase; }
  };
  /** @param {boolean} request */
  const syncHost = (request) => {
    if (terminal) return;
{ const __pui_Associations = vm.instanceAssociations;
    if (__pui_Associations !== undefined) {
      if (__pui_Associations === null || typeof __pui_Associations !== 'object' || Object.getPrototypeOf(__pui_Associations) !== Object.prototype)
        throw new TypeError('[InstanceAssociations] expected a plain record');
      for (const key of Reflect.ownKeys(__pui_Associations)) if (key !== 'controlLabel')
        throw new TypeError('[InstanceAssociations] unknown association key');
      if (Object.prototype.hasOwnProperty.call(__pui_Associations, 'controlLabel') && Reflect.get(__pui_Associations, 'controlLabel') != null)
        throw new Error('[ControlLabel] this Prototype has not declared Label or target participation');
    }
  }
    const nextRaw = hostRaw();
    if (hydrated && same(raw, nextRaw)) return;
    const previousRaw = raw;
    const previous = resolved;
    const next = resolveProps(nextRaw, true);
    raw = nextRaw; resolved = next.snapshot;
    if (!hydrated) { hydrated = true; style.refresh();__pui_Shader.refresh(); return; }
    const changedKeys = Object.keys(specs).filter((key) => !Object.is(previous[key], resolved[key]));
    const changedRawKeys = watchers.some((watch) => watch.active && (watch.kind === 'raw' || watch.kind === 'raw-all'))
      ? [...new Set([...Object.keys(previousRaw), ...Object.keys(raw)])].filter((key) => !Object.is(previousRaw[key], raw[key])) : [];
    if (changedKeys.length) { style.refresh();__pui_Shader.refresh(); }
    if ((changedKeys.length || changedRawKeys.length) && !dispatchingProps) {
      dispatchingProps = true;
      const previousWindow = propsWindow; propsWindow = {raw: nextRaw, resolved: next.snapshot};
      try {
        invoke(() => {
          // Raw-all precedes raw-keyed; resolved-all and keyed share declaration order.
          const snapshot = watchers.slice();
          for (let group = 0; group < 3; ++group) {
            for (const watch of snapshot) {
              if (!watch.active || (watch.kind === 'raw-all' ? 0 : watch.kind === 'raw' ? 1 : 2) !== group) continue;
              const isRaw = group < 2;
              const changedKeysAll = isRaw ? changedRawKeys : changedKeys;
              const changedKeysMatched = watch.keys === null ? changedKeysAll : watch.keys.filter((key) => changedKeysAll.includes(key));
              if (changedKeysMatched.length) {
                const info = { changedKeysAll: [...changedKeysAll], changedKeysMatched: [...changedKeysMatched] };
                // The registration discriminant preserves the raw/resolved callback
                // relation; the host group order and snapshot copies stay unchanged.
                if (watch.kind === 'raw' || watch.kind === 'raw-all') {
                  console.warn('[Props] raw watchers are an adapter-snapshot escape hatch; avoid in official prototypes.');
                  watch.fn(run, nextRaw, previousRaw, info);
                }
                else watch.fn(run, next.snapshot, previous, info);
              }
            }
          }
        }, false);
      } finally { propsWindow = previousWindow; dispatchingProps = false; }
    }
    if (request && autoUpdate) update();
  };
  const renderSemantic = () => {
    if (!renderFunction) throw new Error('[Vue2 native] renderer is unavailable outside the initialized instance lifetime.');
    const previousPhase = phase;
    phase = 'render';
    try { template = renderFunction(renderer); }
    finally { phase = previousPhase; }
  };
  const force = () => { if (!terminal && nativeMounted) vm.$forceUpdate(); };
  const update = () => {
    if (terminal) return;
    invoke(() => {}, true);
    if (!nativeMounted || !hostActive || !present || !viewActive) return;
    if (pending) { queued = true; return; }
    renderSemantic();
    pending = { epoch, revision: ++revision, kind: 'update' };
    force();
  };
  /** @param {boolean} next */
  const setPresent = (next) => {
    callback();
    if (terminal) throw new Error('[Vue2 native] presence is locked for terminal disposal.');
    if (present === next) return;
    present = next; ++epoch; pending = null; renderedCommit = null; queued = false;
    const requestedEpoch = epoch, failures = [];
    // Vue must patch at the owned anchor, not leave its replacement comment
    // in the Portal host and later resurrect the already-removed Root.
    
    if (!terminal && epoch === requestedEpoch && present === next) {
      
      if (!terminal && epoch === requestedEpoch && present === next) {
        // A newer presence request or terminal disposal always wins reentry.
        try {
          if (next && nativeMounted && hostActive && viewActive) renderSemantic();
          force();
        } catch (error) { failures.push(error); }
      }
    }
    if (failures.length) throw failures.length === 1 ? failures[0]
      : new AggregateError(failures, '[Vue2 native] presence withdrawal failed.');
  };

  /** @type {Map<object, (value: unknown) => boolean>} */
  const contextChecks = new Map([

  ]);
  const contextScope = __pui_CreateContextScope({
    getParent: () => vm["__pui_ParentScope"] || null,
    isAlive: () => !disposed,
    invoke: (fn) => invoke(fn, false),
    validate: (key, value) => contextChecks.get(key)?.(value) === true,
  });
  const contextRead = Object.freeze({ read: (/** @param {object} key */ (key) => { alive(); return contextScope.read(key); }), tryRead: (/** @param {object} key */ (key) => { alive(); return contextScope.tryRead(key); }) });

  const __pui_Shader = __pui_CreateShader({setup: () => { setupOnly(); }, alive: () => !disposed, root: () => activeRoot && activeRoot.ownerDocument.defaultView && activeRoot instanceof activeRoot.ownerDocument.defaultView.HTMLElement ? activeRoot : null, prepare: () => { style.refresh(); }});

  
  const run = {
    context: { ...contextRead, update: (/** @param {object} key @param {unknown} value */ (key, value) => { callback(); contextScope.update(key, value); }), tryUpdate: (/** @param {object} key @param {unknown} value */ (key, value) => { callback(); return contextScope.tryUpdate(key, value); }) },
    feedback: { style },
    update: () => { callback(); update(); },
    props: {
      get: () => { alive(); return propsWindow?.resolved ?? resolved; },
      getRaw: () => { alive(); return propsWindow?.raw ?? raw; },
      isProvided: (/** @param {PropertyKey} key */ (key) => { alive(); return __pui_Own(propsWindow?.raw ?? raw, key); }),
    },
    lifecycle: { setPresent },
    expose: { emit: (/** @param {string} key @param {unknown} [payload] @param {unknown} [options] */ (key, payload, options) => {
      callback();
      if (!__pui_Own(eventDeclarations, key)) throw new Error('[Vue2 native] undeclared expose event: ' + key);
      const listener = vm.$attrs && (/** @type {Readonly<Record<string, unknown>>} */ (vm.$attrs))['on' + key[0].toUpperCase() + key.slice(1)];
      // Host sink failures do not re-enter authored callbacks, matching the Vue2 sink.
      try { if (typeof listener === 'function') listener(payload, options); } catch {}
      try { vm.$emit(key, payload, options); } catch {}
    }) },
  };
  
  /** @type {__pui_NativeRenderer} */
  const renderer = { 
    slot: () => /** @type {__pui_NativePaint} */ ((_h, nativeVm, slots) => {
      if (slots.used) throw new Error('[Vue2 native] only one default slot is supported.');
      slots.used = true;
      const scoped = nativeVm.$scopedSlots.default;
      return (scoped ? scoped({}) : nativeVm.$slots.default) || [];
    }),
    read: Object.freeze({ props: Object.freeze({ get: () => { alive(); return resolved; }, getRaw: () => { alive(); return raw; }, isProvided: (/** @param {PropertyKey} key */ (key) => { alive(); return __pui_Own(raw, key); }) }) , context: contextRead }) };
  /** @param {Record<string, __pui_PropSpec>} input */
  const defineProps = (input) => {
    setupOnly();
    const next = { ...specs };
    const rank = { accept: 0, fallback: 1, error: 2 };
    for (const key of Object.keys(input)) {
      const spec = input[key];
      if (!spec || !['boolean', 'number', 'string', 'object', 'any', 'enum'].includes(spec.type)) throw new Error('[Vue2 native] invalid prop declaration: ' + key);
      if (spec.empty !== undefined && !__pui_Own(rank, spec.empty)) throw new Error('[Vue2 native] invalid empty behavior: ' + key);
      if (spec.type === 'enum' && (!Array.isArray(spec.options) || !spec.options.length || !spec.options.every((value) => typeof value === 'string'))) throw new Error('[Vue2 native] invalid enum options: ' + key);
      if (spec.type !== 'enum' && __pui_Own(spec, 'options')) throw new Error('[Vue2 native] only enum props accept options: ' + key);
      if (__pui_Own(spec, 'default') && !__pui_Json(spec.default)) throw new Error('[Vue2 native] non-JSON prop default: ' + key);
      const prior = next[key];
      if (prior) {
        if (prior.type !== spec.type || __pui_Own(spec, 'empty') && spec.empty !== undefined && rank[spec.empty] > rank[prior.empty ?? 'fallback']) throw new Error('[Vue2 native] conflicting prop declaration: ' + key);
        if (prior.options && !prior.options.every((value) => spec.options && spec.options.includes(value))) throw new Error('[Vue2 native] prop options cannot narrow: ' + key);
        if (prior.range && spec.range && ((spec.range.min ?? -Infinity) > (prior.range.min ?? -Infinity) || (spec.range.max ?? Infinity) < (prior.range.max ?? Infinity))) throw new Error('[Vue2 native] prop range cannot narrow: ' + key);
        next[key] = { ...prior, ...spec, empty: prior.empty ?? 'fallback', range: spec.range ?? prior.range };
        if (__pui_Own(prior, 'default')) next[key].default = prior.default;
      } else next[key] = { ...spec };
    }
    specs = next; resolved = resolveProps(raw, false).snapshot;
  };
  /** @param {__pui_PropsWatcher<typeof run>} watch */
  const registerPropsWatch = (watch) => {
    setupOnly();
    const { kind, keys } = watch;
    if (keys !== null && (!keys.length || keys.some((key) => typeof key !== 'string'
      || kind === 'resolved' && !__pui_Own(specs, key)))) throw new Error('[Vue2 native] watch requires non-empty valid prop keys.');
    watch.keys = keys === null ? null : [...keys];
    watchers.push(watch);
    return () => { watch.active = false; };
  };
  /** @type {readonly __pui_LifecycleKind[]} */
  const lifecycleKeys = ["created","mounted","updated","unmounted","beforeDispose"];
  const def = {
    context: { provide: (/** @param {object} key @param {unknown} value */ (key, value) => { setupOnly(); contextScope.provide(key, value); }), subscribe: (/** @param {object} key @param {(run: __pui_Run, next: unknown, previous: unknown) => void} [fn] */ (key, fn) => { setupOnly(); return contextScope.subscribe(key, 'required', fn ? (next, prev) => fn(run, next, prev) : undefined); }), trySubscribe: (/** @param {object} key @param {(run: __pui_Run, next: unknown, previous: unknown) => void} [fn] */ (key, fn) => { setupOnly(); return contextScope.subscribe(key, 'optional', fn ? (next, prev) => fn(run, next, prev) : undefined); }) },
    feedback: { style },
    
    props: {
      define: defineProps,
      setDefaults: (/** @param {__pui_RawProps} layer */ (layer) => {
        setupOnly();
        for (const key of Object.keys(layer)) if (!__pui_Own(specs, key) || !__pui_Json(layer[key])) throw new Error('[Vue2 native] invalid prop default: ' + key);
        defaults.unshift({ ...layer }); resolved = resolveProps(raw, false).snapshot;
      }),
      /** @param {readonly string[]} keys @param {__pui_PropsWatchCallback<typeof run, __pui_ResolvedProps>} fn */
      watch: (keys, fn) => registerPropsWatch({ kind: 'resolved', keys, fn, active: true }),
      /** @param {__pui_PropsWatchCallback<typeof run, __pui_ResolvedProps>} fn */
      watchAll: (fn) => registerPropsWatch({ kind: 'resolved-all', keys: null, fn, active: true }),
      /** @param {readonly string[]} keys @param {__pui_PropsWatchCallback<typeof run, __pui_RawProps>} fn */
      watchRaw: (keys, fn) => registerPropsWatch({ kind: 'raw', keys, fn, active: true }),
      /** @param {__pui_PropsWatchCallback<typeof run, __pui_RawProps>} fn */
      watchRawAll: (fn) => registerPropsWatch({ kind: 'raw-all', keys: null, fn, active: true }),
    },
    expose: {
      /** @param {string} key @param {unknown} value */
      value: (key, value) => { setupOnly(); if (__pui_Own(exposed, key)) throw new Error('[Expose] duplicate declaration'); exposed[key] = value; },
      /** @template T @param {string} key @param {{ external: __pui_ExternalState<T> }} handle */
      state: (key, handle) => { setupOnly(); exposed[key] = handle.external;  },
      /** @template {unknown[]} Args @template Result @param {string} key @param {(...args: Args) => Result} fn @param {(value: Result) => Result} [project] */
      method: (key, fn, project) => { setupOnly();  exposed[key] = (/** @param {Args} args */ (...args) => { publicAlive(); const result = invoke(() => fn(...args)); return project ? project(result) : result; }); },
      /** @param {string} key @param {unknown} [spec] */
      event: (key, spec) => { setupOnly(); eventDeclarations[key] = spec; },
    },
    lifecycle: Object.fromEntries(lifecycleKeys.map((key) => {
      /** @type {[string, (fn: __pui_LifecycleCallback<typeof run>) => void]} */
      const entry = ['on' + key[0].toUpperCase() + key.slice(1), (fn) => { setupOnly(); lifecycle[key].push(fn); }];
      return entry;
    })),
  };
  /** @param {__pui_LifecycleKind} kind */
  const fire = (kind) => invoke(() => { if (kind === 'unmounted') { __pui_Shader.detach(); } try { for (const fn of lifecycle[kind]) fn(run); } finally { if (kind === 'unmounted') { __pui_Shader.detach(); } } }, !terminal);
  const detach = () => {
    if (!viewActive) return;
    viewActive = false; pending = null; queued = false;
    
    
    style.unmount();
    if (activeRoot) activeRoot.removeAttribute('data-pui-style');
    activeRoot = null;
    fire('unmounted');
  };
  const afterCommit = () => {
    if (terminal) return;
    syncHost(true);
    const commit = renderedCommit;
    if (!commit) return;
    renderedCommit = null;
    const target = vm.$el;
    // Removal has already committed when Vue calls updated. Do not postpone its
    // unmount notification into a tick which may belong to a replacement view.
    if (!commit.present && commit.vnode.elm === target) { detach(); return; }
    vm.$nextTick(() => {
      if (terminal || commit.epoch !== epoch || commit.version !== commitVersion || vm.$el !== target || commit.vnode.elm !== target) return;
      if (!present || !hostActive) return;
      
      
      const kind = commit.kind;
      if (kind === 'mount' && !viewActive) {
        viewActive = true;
        activeRoot = target;
        
        
        style.mount();
        __pui_Shader.mount();
        fire('mounted');
        
      } else if (viewActive) {
        if (activeRoot !== target) { __pui_Shader.detach(); activeRoot = target; __pui_Shader.mount(); }
        
        if (kind !== 'update' || !pending || pending.revision !== commit.revision) return;
        pending = null;
        const again = queued; queued = false;
        fire('updated');
        if (again && present && viewActive && !terminal && !pending) update();
      }
    });
  };
  const owner = {
    
    
    shader: __pui_Shader,
    contextScope,
    host() { return viewActive && present && hostActive && !terminal ? vm.$el : null; },
    
    def,
    get resolvedProps() { return resolved; },
    
    initialize() {
      
      try {
        renderFunction = setup(owner);
        if (typeof renderFunction !== 'function') renderFunction = (renderer) => renderer.slot();
        phase = 'idle';
        syncHost(false);
        fire('created');
         unwatch = vm.$watch(() => hostRaw(), () => syncHost(true), { deep: true });
      } catch (error) {
        
        terminal = true;
        
        try { style.dispose(); } catch {}
        try { contextScope.dispose(); } catch {}
        disposed = true;
        phase = 'idle';
        throw error;
      }
    },
    hostMounted() {  nativeMounted = true; afterCommit(); },
    afterCommit,
    /** @param {import('vue').CreateElement} h */
    render(h) {
      
      if (terminal || !present || !hostActive) {
        const vnode = h();
        renderedCommit = { epoch, version: ++commitVersion, present: false, vnode, kind: 'detach' };
        return vnode;
      }
      if (!viewActive) renderSemantic();
      const tag = rootTag;
      const children = template ? template(h, vm, { used: false }) : [];
      if (['input', 'textarea', 'img'].includes(tag) && children.length) throw new Error('[Template] physical control Root requires empty children.');
      const rootData = { pre: true, attrs: { 'data-pui-root': '' } };
      const vnode = h(tag, rootData, children);
      renderedCommit = { epoch, version: ++commitVersion, present: true, vnode, kind: !viewActive ? 'mount' : pending ? 'update' : 'none', revision: pending && pending.revision };
      return vnode;
    },
    update,
    getExposes() { if (terminal) return {}; return { ...exposed }; },
    /** @template T @param {() => T} fn @returns {T} */
    invokePublic(fn) { publicAlive(); return invoke(fn); },
    deactivate() {
      if (terminal || !hostActive) return;
      hostActive = false; ++epoch; renderedCommit = null; pending = null; queued = false;
      detach();
    },
    activate() {
      if (terminal || hostActive) return;
      hostActive = true; ++epoch; pending = null; renderedCommit = null;
      vm.$forceUpdate();
    },
    dispose() {
      if (terminal) return;
      terminal = true; ++epoch; renderedCommit = null; pending = null; queued = false;
      
      unwatch?.(); unwatch = undefined;
      /** @type {{ error: unknown } | undefined} */ let failure;
      try { detach(); } catch (error) { failure = { error }; }
       try {
        fire('beforeDispose');
      } catch (error) { failure ??= { error }; }
      try { contextScope.dispose(); } catch (error) { failure ??= { error }; }
      
      try { style.dispose(); } catch (error) { failure ??= { error }; }
      const target = vm.$el;
      if (target && target.nodeType === 1 && target.hasAttribute('data-pui-root')) target.removeAttribute('data-pui-style');
      __pui_Shader.dispose();
      disposed = true; phase = 'idle';
      watchers.length = 0; defaults.length = 0;
      for (const callbacks of Object.values(lifecycle)) callbacks.length = 0;
      for (const key of Object.keys(exposed)) delete exposed[key];
      for (const key of Object.keys(eventDeclarations)) delete eventDeclarations[key];
      specs = Object.create(null); previousValid = Object.create(null); raw = Object.freeze({}); resolved = /** @type {__pui_ResolvedProps} */ (Object.freeze({})); template = renderFunction = null;
      
      if (failure) throw failure.error;
    },
  };
  return owner;
}


/** @param {__pui_Owner} __pui_Owner */
function __pui_Setup(__pui_Owner) {


  const __pui_Shader = __pui_Owner.shader;

  /** @type {((renderer: __pui_NativeRenderer) => ((__pui_NativePaint))) | void} */
  const __pui_AuthoredRenderer = (/** @param {__pui_Owner['def']} def */ (def) => {
    // Source "packages/compiler/test/fixtures/shader-static-data-owner.proto.ts":33:5
    def.props.define({ ["visible"]: { ["type"]: "boolean", ["default"]: true } });
    // Source "packages/compiler/test/fixtures/shader-static-data-owner.proto.ts":34:5
    def.feedback.style.use({"kind":"tw","tokens":["block","p-4"],"groups":["display","p-"]});
    // Source "packages/compiler/test/fixtures/shader-static-data-owner.proto.ts":35:11
    const graph = __puiModule0();
    // Source "packages/compiler/test/fixtures/shader-static-data-owner.proto.ts":36:11
    const alias = graph;
    // Source "packages/compiler/test/fixtures/shader-static-data-owner.proto.ts":37:5
    (void (def), __pui_Shader.declare("9a44eadea553d2056aecd4d59f9ddfe471bd81ee6b6ea5052f3b5a7c16491c63", [0.15,0.2,0.25,1], (__shaderDevice) => { const __shaderSource = __shaderDevice.upload({"width":2,"height":2,"pixels":[255,0,0,255,0,128,0,128,0,0,64,64,64,128,192,255]}); const __shaderPass0 = __shaderDevice.copy(__shaderSource); const __shaderPass1 = __shaderDevice.tint(__shaderPass0, [0.5,1,0.25,0.5]); return __shaderPass1; }));
    // Source "packages/compiler/test/fixtures/shader-static-data-owner.proto.ts":38:5
    def.lifecycle.onCreated(/** @param {__pui_Run} run */ (run) => {
      // Source "packages/compiler/test/fixtures/shader-static-data-owner.proto.ts":38:38
      return run.lifecycle.setPresent((run.props.get())["visible"]);
    });
    // Source "packages/compiler/test/fixtures/shader-static-data-owner.proto.ts":39:5
    def.props.watch(["visible"], /** @param {__pui_Run} run @param {__pui_ResolvedProps} next */ (run, next) => {
      // Source "packages/compiler/test/fixtures/shader-static-data-owner.proto.ts":39:49
      return run.lifecycle.setPresent((next)["visible"]);
    });
    // Source "packages/compiler/test/fixtures/shader-static-data-owner.proto.ts":40:5
    return /** @param {__pui_NativeRenderer} r */ (r) => {
      // Source "packages/compiler/test/fixtures/shader-static-data-owner.proto.ts":40:19
      return (/** @param {unknown} __pui_Receiver0 @param {string} __pui_Tag1 @param {Array<((string | number) | __pui_NativePaint)>} __pui_Arg2 */ (__pui_Receiver0, __pui_Tag1, __pui_Arg2) => {
      
      return /** @type {__pui_NativePaint} */ ((__pui_H5, __pui_Vm6, __pui_Slots7) => {
        /** @type {__pui_NativeChildren} */ const __pui_Children8 = [];
        for (const __pui_Child10 of __pui_Arg2) { if (typeof __pui_Child10 === 'function') { __pui_Children8.push(.../** @type {__pui_NativePaint} */ (__pui_Child10)(__pui_H5, __pui_Vm6, __pui_Slots7)); } else if (typeof __pui_Child10 === 'string' || typeof __pui_Child10 === 'number') { __pui_Children8.push('' + (__pui_Child10)); } else { throw new TypeError('[Vue2 native] invalid template child.'); } }
        /** @type {import('vue').VNodeData & { pre: true }} */ const __pui_Data9 = { pre: true };
        return [__pui_H5(__pui_Tag1, __pui_Data9, __pui_Children8)];
      });
    })(r, "button", ["ordinary child", (/** @param {unknown} __pui_Receiver11 */ (__pui_Receiver11) =>
      /** @type {__pui_NativePaint} */ ((__pui_H12, __pui_Vm13, __pui_Slots14) => {
        if (__pui_Slots14.used) throw new Error('[Vue2 native] only one default slot is supported.');
        __pui_Slots14.used = true;
        const scoped = __pui_Vm13.$scopedSlots.default;
        return (scoped ? scoped({}) : __pui_Vm13.$slots.default) || [];
      }))(r)]);
    };
  })(__pui_Owner.def);
  if (typeof __pui_AuthoredRenderer !== 'function') return __pui_AuthoredRenderer;
  return (/** @param {__pui_NativeRenderer} __pui_Renderer */ (__pui_Renderer) => (/** @param {((__pui_NativePaint))} __pui_Committed15 */ (__pui_Committed15) => /** @type {__pui_NativePaint} */ ((__pui_H16, __pui_Vm17, __pui_Slots18) => {
      /** @type {__pui_NativeChildren} */ const __pui_Children19 = [];
      if (typeof __pui_Committed15 === 'function') { __pui_Children19.push(.../** @type {__pui_NativePaint} */ (__pui_Committed15)(__pui_H16, __pui_Vm17, __pui_Slots18)); } else { throw new TypeError('[Vue2 native] invalid template child.'); }
      return __pui_Children19;
    }))(__pui_AuthoredRenderer(__pui_Renderer)));
}

/** @typedef {import('vue').default & { readonly "__pui_Owner": ReturnType<typeof __pui_CreateOwner>; readonly "__pui_ParentScope"?: ReturnType<typeof __pui_CreateContextScope> | null }} __pui_NativeInstance */
export const CompiledComponent = {
  name: "shader-static-data-owner",
  inheritAttrs: false,
  props: { instanceAssociations: { type: Object, default: undefined }, ["visible"]: {} },
  inject: { ["__pui_ParentScope"]: { from: __pui_ScopeKey, default: null } },
  /** @this {__pui_NativeInstance} */
  provide() { return { [__pui_ScopeKey]: this["__pui_Owner"].contextScope }; },
  /** @this {__pui_NativeInstance} */
  beforeCreate() {
    Object.defineProperty(this, "__pui_Owner", { value: __pui_CreateOwner(this, __pui_Setup, {"visible":"boolean"}, "div", true) });
    
  },
  /** @this {__pui_NativeInstance} */
  created() { this["__pui_Owner"].initialize(); },
  /** @this {__pui_NativeInstance} */
  mounted() { this["__pui_Owner"].hostMounted(); },
  /** @this {__pui_NativeInstance} */
  updated() { this["__pui_Owner"].afterCommit(); },
  /** @this {__pui_NativeInstance} */
  activated() { this["__pui_Owner"].activate(); },
  /** @this {__pui_NativeInstance} */
  deactivated() { this["__pui_Owner"].deactivate(); },
  /** @this {__pui_NativeInstance} */
  beforeDestroy() { this["__pui_Owner"].dispose(); },
  methods: {
    /** @this {__pui_NativeInstance} */
    update() { this["__pui_Owner"].update(); },
    /** @this {__pui_NativeInstance} */
    getExposes() { return this["__pui_Owner"].getExposes(); },
    /** @this {__pui_NativeInstance} @template T @param {() => T} callback */
    invokeInCallbackScope(callback) { return this["__pui_Owner"].invokePublic(callback); },
  },
  /** @this {__pui_NativeInstance} @param {import('vue').CreateElement} h */
  render(h) { return this["__pui_Owner"].render(h); },
};

export default CompiledComponent;


//# sourceMappingURL=Component.js.map
