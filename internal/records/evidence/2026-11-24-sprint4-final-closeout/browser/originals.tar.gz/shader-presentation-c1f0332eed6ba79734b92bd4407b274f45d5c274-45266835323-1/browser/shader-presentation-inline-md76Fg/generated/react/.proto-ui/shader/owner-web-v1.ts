import {createWebShaderPresenter, type WebShaderProgram} from './webgl2-host-v1';

/** Physical owner lifecycle only. The compiler supplies the finite direct pass program. */
export function createNativeShader(options: {setup(): void; alive(): boolean; root(): HTMLElement | null; prepare(): void}) {
  type Declaration = {kind:'pixels'; key:string; fallback:readonly [number,number,number,number]; program:WebShaderProgram};
  let declaration: Declaration | null = null;
  let view = 0, revision = 0, mounted = false, disposed = false;
  const presenter = createWebShaderPresenter({root:options.root, prepare:options.prepare});
  
  function refresh() {
    if (disposed || !mounted || !declaration || !options.alive()) return;
    
    presenter.commit({view, revision:++revision, key:declaration.key, fallback:declaration.fallback}, declaration.program);
  }
  function register(input: Declaration) {
    options.setup();
    if (disposed || declaration) throw new Error('One live shader declaration per material surface');
    const owned = Object.freeze({...input, fallback:Object.freeze([...input.fallback]) as typeof input.fallback});
    declaration = owned;
    return () => {options.setup(); if (declaration !== owned) return; declaration = null; presenter.release(view); };
  }
  return {
    declare(key:string, fallback:readonly [number,number,number,number], program:WebShaderProgram) {
      return register({kind:'pixels', key, fallback, program});
    },
    
    mount() {if (disposed) return; if (!mounted) {mounted=true; view++;} refresh();},
    refresh,
    detach() {if (!mounted) return; mounted=false;  presenter.release(view); },
    dispose() {if (disposed) return; disposed=true; mounted=false; declaration=null;  presenter.dispose(); },
  };
}
