import * as react from "/home/runner/work/_temp/shader-presentation/browser/shader-presentation-static-data-cb6rif/generated/react/Component.tsx";
import * as vue from "/home/runner/work/_temp/shader-presentation/browser/shader-presentation-static-data-cb6rif/generated/vue/Component.ts";
import * as vue2 from "/home/runner/work/_temp/shader-presentation/browser/shader-presentation-static-data-cb6rif/generated/vue2/Component.js";
import * as wc from "/home/runner/work/_temp/shader-presentation/browser/shader-presentation-static-data-cb6rif/generated/wc/Component.ts";
import prototype from "/home/runner/work/Proto-UI/Proto-UI/packages/compiler/test/fixtures/shader-static-data-owner.proto.ts";
import {createShaderBrowserFixture} from "/home/runner/work/Proto-UI/Proto-UI/packages/compiler/test/shader-browser-consumer.ts";
export const fixture=createShaderBrowserFixture({react,vue,vue2,wc}, prototype);
