import * as react from "/home/runner/work/_temp/shader-presentation/browser/shader-presentation-scene-flKmDT/generated/react/Component.tsx";
import * as vue from "/home/runner/work/_temp/shader-presentation/browser/shader-presentation-scene-flKmDT/generated/vue/Component.ts";
import * as vue2 from "/home/runner/work/_temp/shader-presentation/browser/shader-presentation-scene-flKmDT/generated/vue2/Component.js";
import * as wc from "/home/runner/work/_temp/shader-presentation/browser/shader-presentation-scene-flKmDT/generated/wc/Component.ts";
import prototype from "/home/runner/work/Proto-UI/Proto-UI/packages/compiler/test/fixtures/shader-scene-owner.proto.ts";
import {createShaderSceneBrowserFixture} from "/home/runner/work/Proto-UI/Proto-UI/packages/compiler/test/shader-browser-consumer.ts";
export const fixture=createShaderSceneBrowserFixture({react,vue,vue2,wc}, prototype);
