import {createWebShaderPresenter, type WebShaderProgram} from './webgl2-host-v1';
import type {WebShaderScenePresenter, WebShaderSceneProgram, WebShaderHostOptions} from './scene-web-v1';
/** Physical owner lifecycle only. The compiler supplies the finite direct pass program. */
export function createNativeShader(options: {setup(): void; alive(): boolean; root(): HTMLElement | null; prepare(): void; host?: WebShaderHostOptions}) {
  type Declaration = {kind:'pixels'; key:string; fallback:readonly [number,number,number,number]; program:WebShaderProgram} | {kind:'scene'; slot:string; resources:number; key:string; fallback:readonly [number,number,number,number]; program:WebShaderSceneProgram};
  let declaration: Declaration | null = null;
  let view = 0, revision = 0, mounted = false, disposed = false, turn = 0;
  const presenter = createWebShaderPresenter({root:options.root, prepare:options.prepare});
  let scene: WebShaderScenePresenter | undefined;
  function refresh() {
    if (disposed || !mounted || !declaration || !options.alive()) return;
    const selected = declaration, operation = ++turn;
    if (selected.kind === 'scene') {
      const frame = {view, revision:++revision, key:selected.key, fallback:selected.fallback};
      if (!scene) {
        let acquired: WebShaderScenePresenter | undefined;
        try { acquired = options.host?.createScenePresenter({root:options.root, prepare:options.prepare}); }
        catch { if (!disposed && mounted && turn === operation && declaration === selected) presenter.commit(frame, null, undefined, undefined, 'shader-scene-host-failed'); return; }
        if (disposed || !mounted || turn !== operation || declaration !== selected || !options.alive()) { acquired?.dispose(); return; }
        scene = acquired;
      }
      if (scene) scene.commit({...frame, slot:selected.slot, resources:selected.resources}, selected.program);
      else presenter.commit(frame, null, undefined, undefined, 'shader-scene-capability-unavailable');
      return;
    }
    presenter.commit({view, revision:++revision, key:selected.key, fallback:selected.fallback}, selected.program);
  }
  function register(input: Declaration) {
    options.setup();
    if (disposed || declaration) throw new Error('One live shader declaration per material surface');
    const owned = Object.freeze({...input, fallback:Object.freeze([...input.fallback]) as typeof input.fallback});
    declaration = owned;
    return () => {options.setup(); if (declaration !== owned) return; declaration = null; presenter.release(view); scene?.release(view);};
  }
  return {
    declare(key:string, fallback:readonly [number,number,number,number], program:WebShaderProgram) {
      return register({kind:'pixels', key, fallback, program});
    },
    declareScene(slot:string, resources:number, key:string, fallback:readonly [number,number,number,number], program:WebShaderSceneProgram) { return register({kind:'scene', slot, resources, key, fallback, program}); },
    mount() {if (disposed) return; if (!mounted) {mounted=true; view++;} refresh();},
    refresh,
    detach() {if (!mounted) return; mounted=false; turn++; presenter.release(view); scene?.release(view);},
    dispose() {if (disposed) return; disposed=true; mounted=false; declaration=null; turn++; presenter.dispose(); scene?.dispose();},
  };
}
