import { writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const repo = process.env.PUI_SOURCE_ROOT ?? '/workspace/scratch/b2027510c911/s2-transition-types';
const { scanRuleStateReadInventory } = await import(pathToFileURL(path.join(repo, 'packages/cli/src/services/lowered-hook-coverage.ts')).href);
const files = [
  'packages/prototypes/shadcn/src/alert-dialog/action.proto.ts',
  'packages/prototypes/shadcn/src/alert-dialog/cancel.proto.ts',
  'packages/prototypes/base/src/transition/machine.ts',
  'packages/prototypes/shadcn/src/calendar/calendar.proto.ts',
  'packages/prototypes/base/src/number-field/root.proto.ts',
  'packages/prototypes/shadcn/src/data-table/data-table.proto.ts',
].map((name) => path.join(repo, name));
const inventory = scanRuleStateReadInventory(files);
const summarize = (row) => ({ ...row, usages: row.usages.map((usage) => ({ ...usage, provenance: usage.provenance })) });
const report = { files: inventory.files, observations: inventory.observations.map(summarize), evaluated: inventory.evaluated.map(summarize) };
await writeFile(process.argv[2], JSON.stringify(report, null, 2)+'\n');
console.log(JSON.stringify({ rows: report.evaluated.length, usages: report.evaluated.flatMap((row) => row.usages.map((usage) => ({ entry: path.relative(repo,row.entryFile), rule: path.relative(repo,row.rule.file), hook: usage.hook,state:usage.state }))), unresolved: report.evaluated.flatMap((row)=>row.unresolved.map((miss)=>({entry:path.relative(repo,row.entryFile),rule:path.relative(repo,row.rule.file),...miss}))) }, null, 2));
