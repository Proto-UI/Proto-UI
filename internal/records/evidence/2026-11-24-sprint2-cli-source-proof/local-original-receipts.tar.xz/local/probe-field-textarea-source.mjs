import { readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
const repo='/workspace/scratch/b2027510c911/s2-transition-types';
const require=createRequire(path.join(repo,'package.json'));
const ts=require('typescript');
const { createHookSourceSummaryContext }=await import(pathToFileURL(path.join(repo,'packages/cli/src/services/hook-source-summary.ts')).href);
const { scanRuleStateReads }=await import(pathToFileURL(path.join(repo,'packages/cli/src/services/lowered-hook-coverage.ts')).href);
const file=path.join(repo,'packages/prototypes/brutalist/src/field/textarea.proto.ts');
const text=await readFile(file,'utf8');
const source=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true);
const context=createHookSourceSummaryContext();context.registerSource(source);
const environment=new Map();const facts=[];
const summarize=(value,depth=0)=>{
 if(!value || typeof value!=='object')return value;
 if(depth>3)return {kind:value.kind};
 if(value.kind==='object')return {kind:value.kind,members:Object.fromEntries([...value.members].map(([k,v])=>[k,summarize(v,depth+1)]))};
 if(value.kind==='result')return {kind:value.kind,name:value.name,states:[...value.stateHandles.keys()],children:[...value.children.keys()],handle:summarize(value.handle,depth+1)};
 if(value.kind==='callable')return {kind:value.kind,operation:value.operation};
 return value;
};
function visit(node){
 if(ts.isVariableDeclaration(node)&&ts.isIdentifier(node.name)&&node.initializer){
  const resolved=context.resolve(node.initializer,source,environment);
  environment.set(node.name.text,resolved.value);facts.push({name:node.name.text,resolved:summarize(resolved.value)});
 }
 if(ts.isPropertyAccessExpression(node)&&node.getText(source)==='binding.state.invalid')facts.push({name:node.getText(source),resolved:summarize(context.resolve(node,source,environment).value)});
 ts.forEachChild(node,visit);
}
visit(source);
const input=text.replace('setupTextareaVisual(def, textarea.stateHandles, binding.state.invalid);',"def.rule({ when: w => w.state(binding.state.invalid).eq(true), intent: i => i.feedback.style.use(tw('block')) });");
const direct=scanRuleStateReads(input,file);
const report={facts,direct:{...direct,usages:direct.usages.map(u=>({...u,provenance:u.provenance}))},input};
await writeFile(process.argv[2],JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({facts,direct:report.direct},null,2));
