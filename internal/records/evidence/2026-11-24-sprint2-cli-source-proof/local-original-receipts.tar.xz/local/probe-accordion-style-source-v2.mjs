import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const repo = path.resolve(process.env.PUI_SOURCE_ROOT ?? process.cwd());
const output = path.resolve(process.argv[2]);
await mkdir(output, { recursive: false });
const require = createRequire(path.join(repo, 'package.json'));
const ts = require('typescript');
const { createHookSourceSummaryContext } = await import(pathToFileURL(path.join(repo, 'packages/cli/src/services/hook-source-summary.ts')).href);
const { collectProtoStyleTokensFromFiles } = await import(pathToFileURL(path.join(repo, 'packages/cli/src/services/prototype-style-tokens.ts')).href);
const entry = path.join(repo, 'packages/prototypes/shadcn/src/accordion/content.proto.ts');
const content = await readFile(entry, 'utf8');
const source = ts.createSourceFile(entry, content, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
const context = createHookSourceSummaryContext();
context.registerSource(source);
const resolutions = [];
function visit(node) {
  const text = node.getText(source);
  if ((ts.isCallExpression(node) && text === 'asAccordionContent()') || (ts.isPropertyAccessExpression(node) && text === 'inherited.stateHandles!.open'))
    resolutions.push({ expression: text, resolved: context.resolve(node, source) });
  ts.forEachChild(node, visit);
}
visit(source);
const tokens = await collectProtoStyleTokensFromFiles([entry]);
const hash = (value) => createHash('sha256').update(value).digest('hex');
const git = (...args) => execFileSync('git', args, { cwd: repo, encoding: 'utf8' });
const report = { kind: 'actual-accordion-style-source-proof', sourceHead: git('rev-parse', 'HEAD').trim(), sourceDiffSha256: hash(git('diff', '--binary')), entry, entrySha256: hash(content), tokens, resolutions };
const seen = new WeakMap();
function serialize(value) {
  if (!value || typeof value !== 'object') return value;
  if (seen.has(value)) return { $ref: seen.get(value) };
  const id = ++serialize.sequence;
  seen.set(value, id);
  if (value instanceof Map) return { $id: id, entries: Object.fromEntries([...value].map(([key, item]) => [key, serialize(item)])) };
  if (Array.isArray(value)) return { $id: id, items: value.map(serialize) };
  return { $id: id, ...Object.fromEntries(Object.entries(value).map(([key, item]) => [key, serialize(item)])) };
}
serialize.sequence = 0;
report.resolutions = resolutions.map(({ expression, resolved }) => ({ expression, resolved: serialize(resolved) }));
report.resolutionFormat = 'source-values-with-identity-references.v1';
const serialized = JSON.stringify(report, null, 2)+'\n';
await writeFile(path.join(output, 'report.json'), serialized);
await writeFile(path.join(output, 'input.proto.ts'), content);
console.log(serialized);

