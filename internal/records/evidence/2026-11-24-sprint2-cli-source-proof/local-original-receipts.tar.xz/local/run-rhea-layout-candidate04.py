#!/usr/bin/env python3
"""Run unchanged Rhea layout cases with this candidate's normal generated CSS.

This follows run-final-s2-web.py's owned external Astro pattern. Generation and
server warmup have separate receipts; they do not satisfy the suite's 150s cold
startup acceptance. No browser fixture, assertions, or product CSS are patched.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import urllib.request

R = Path('/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202')
repo = R / 'Proto-UI-types-fix'
out = R / 'results' / 'accordion-rhea-layout-candidate04-01'
expected = '5cb80eb937f20982dd7dc8cbc93a90e91d665c31'
test = 'apps/www/src/content/docs/zh-cn/demo-accordion-family.browser.test.ts'
node = os.environ['S2_NODE']


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)


def save(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')


def snapshot():
    changed = git('diff', '--name-only', 'HEAD').decode().splitlines()
    names = sorted(set(changed + [test, 'apps/www/src/content/docs/zh-cn/browser-harness.ts']))
    return {
        'head': git('rev-parse', 'HEAD').decode().strip(),
        'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
        'dirty': git('status', '--porcelain', '--untracked-files=no').decode().strip(),
        'diffSha256': digest(git('diff', '--binary', 'HEAD')),
        'files': [{ 'path': p, 'sha256': digest((repo / p).read_bytes()),
                    'bytes': (repo / p).stat().st_size } for p in names],
    }


def generated():
    names = ['apps/www/src/styles/shadcn-theme.css',
             'apps/www/src/styles/proto-ui-tokens.generated.css',
             'apps/www/src/styles/proto-ui-style.css']
    return [{ 'path': p, 'sha256': digest((repo / p).read_bytes()),
              'bytes': (repo / p).stat().st_size } for p in names if (repo / p).is_file()]


def step(name, command, cwd, env, timeout):
    item = {'name': name, 'command': command, 'cwd': str(cwd), 'startedAt': now(),
            'timeoutSeconds': timeout, 'sourceBefore': snapshot()}
    start = time.monotonic()
    with (out / (name + '.log')).open('x') as log:
        proc = subprocess.Popen(command, cwd=cwd, env=env, stdout=log,
                                stderr=subprocess.STDOUT, start_new_session=True)
        item['pid'] = proc.pid
        save(name + '.start.json', item)
        try:
            item['exitCode'] = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            item['timeout'] = True
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
            item['exitCode'] = proc.returncode
    item.update(endedAt=now(), durationMs=round((time.monotonic() - start) * 1000),
                sourceAfter=snapshot())
    item['sourceStable'] = item['sourceBefore'] == item['sourceAfter']
    save(name + '.json', item)
    data['steps'].append(item)
    save('progress.json', data)
    print(json.dumps({'step': name, 'exitCode': item['exitCode'],
                      'durationMs': item['durationMs'], 'sourceStable': item['sourceStable']}), flush=True)
    if item['exitCode'] != 0 or not item['sourceStable']:
        raise RuntimeError(name + ' did not pass with a stable candidate')
    return item


out.mkdir(parents=True, exist_ok=False)
source = snapshot()
data = {'kind': 'unchanged-rhea-layout-successor.v1', 'startedAt': now(),
        'driverSha256': digest(Path(__file__).read_bytes()),
        'source': source, 'steps': [], 'warmup': [], 'coldStartupAccepted': False,
        'scope': 'Original eight Rhea homepage layout cases; original 90s per-case limits.',
        'filter': 'Rhea homepage', 'expectedSelectedCases': 8,
        'testUnchangedFromHead': (repo / test).read_bytes() == git('show', expected + ':' + test),
        'normalStyleGeneration': True, 'borrowedExternalCss': False,
        'generatedBefore': generated()}
save('start.json', data)
assert source['head'] == expected and data['testUnchangedFromHead'], data
build = json.loads((R / 'evidence/accordion-cli-public-build-5cb80-01/result.json').read_text())
assert build['exitCode'] == 0 and build['finalHead'] == expected, build
env = os.environ.copy()
server = None
serverlog = None
failed = None
try:
    step('normal-website-style-generation', ['corepack', 'pnpm@10.32.1', 'run', 'generate:proto-ui-style'],
         repo / 'apps/www', env, 1200)
    data['generatedAfter'] = generated()
    assert len(data['generatedAfter']) == 3
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
    base = f'http://127.0.0.1:{port}'
    env.update(PROTO_UI_BROWSER_BASE_URL=base, PROTO_UI_BROWSER_TEST='1',
               PROTO_UI_ACCORDION_SCREENSHOT_DIR=str(out / 'accordion'))
    command = ['corepack', 'pnpm@10.32.1', '--filter', 'apps-www', 'exec', 'astro', 'dev',
               '--host', '127.0.0.1', '--port', str(port), '--strictPort']
    serverlog = (out / 'owned-astro.log').open('x')
    server = subprocess.Popen(command, cwd=repo, env=env, stdout=serverlog,
                              stderr=subprocess.STDOUT, start_new_session=True)
    data['server'] = {'command': command, 'pid': server.pid, 'baseUrl': base, 'startedAt': now()}
    save('server-start.json', data['server'])
    for route in ['/en/ui-libraries/base/accordion/', '/en/']:
        deadline = time.monotonic() + 180
        while True:
            if server.poll() is not None:
                raise RuntimeError('Owned Astro server exited before warmup')
            item = {'route': route, 'at': now()}
            try:
                with urllib.request.urlopen(base + route, timeout=10) as response:
                    item.update(status=response.status, bytes=len(response.read()))
            except Exception as error:
                item['error'] = str(error)
            data['warmup'].append(item)
            save('server-warmup.json', data['warmup'])
            if item.get('status') == 200:
                break
            if time.monotonic() >= deadline:
                raise RuntimeError('Owned server warmup deadline: ' + route)
            time.sleep(1)
    step('original-rhea-eight', [node, 'node_modules/vitest/vitest.mjs', 'run', test,
         '-t', 'Rhea homepage', '--pool=forks', '--minWorkers=1', '--maxWorkers=1',
         '--no-file-parallelism', '--reporter=default', '--reporter=json',
         '--outputFile=' + str(out / 'vitest.json')], repo, env, 1200)
    report = json.loads((out / 'vitest.json').read_text())
    selected = [a for result in report['testResults'] for a in result['assertionResults']
                if 'Rhea homepage' in a['fullName']]
    data['selected'] = [{'name': a['fullName'], 'status': a['status'],
                         'duration': a.get('duration')} for a in selected]
    data['vitestCounts'] = {k: report.get(k) for k in ['numTotalTests', 'numPassedTests',
                           'numFailedTests', 'numPendingTests', 'numTodoTests']}
    assert len(selected) == 8 and all(a['status'] == 'passed' for a in selected)
    assert report['numFailedTests'] == 0
except Exception as error:
    failed = repr(error)
finally:
    if server is not None:
        data['server']['unexpectedExitBeforeCleanup'] = server.poll()
        for sig, seconds in [(signal.SIGTERM, 5), (signal.SIGKILL, 1)]:
            if server.poll() is not None:
                break
            try:
                os.killpg(server.pid, sig)
            except ProcessLookupError:
                pass
            try:
                server.wait(timeout=seconds)
            except subprocess.TimeoutExpired:
                pass
        data['serverRetirement'] = {'at': now(), 'exitCode': server.poll(),
                                    'ownedProcessGroup': server.pid}
        serverlog.close()
    data.update(finishedAt=now(), error=failed, sourceAfter=snapshot(),
                generatedFinal=generated())
    data['passed'] = (failed is None and data['source'] == data['sourceAfter'] and
                      data.get('generatedAfter') == data['generatedFinal'] and
                      data.get('server', {}).get('unexpectedExitBeforeCleanup') is None)
    save('receipt.json', data)
print(json.dumps({k: data.get(k) for k in ['passed', 'error', 'vitestCounts', 'coldStartupAccepted']}))
sys.exit(0 if data['passed'] else 1)
