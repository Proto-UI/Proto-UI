import { mkdir, readdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
const repo=process.env.PUI_SOURCE_ROOT;
const out=process.argv[2];
if(!repo || !out) throw new Error('PUI_SOURCE_ROOT and output directory required');
await mkdir(out,{recursive:true});
const {scanRuleStateReadInventory}=await import(pathToFileURL(path.join(repo,'packages/cli/src/services/lowered-hook-coverage.ts')).href);
const {collectSourceFiles}=await import(pathToFileURL(path.join(repo,'packages/cli/src/services/prototype-style-tokens.ts')).href);
const files=[];
for(const entry of await readdir(path.join(repo,'packages/prototypes'),{withFileTypes:true})){
 if(!entry.isDirectory())continue;
 try{files.push(...await collectSourceFiles(path.join(repo,'packages/prototypes',entry.name,'src')))}
 catch(error){if(error.code!=='ENOENT')throw error;}
}
files.sort();
const hash=async file=>createHash('sha256').update(await readFile(file)).digest('hex');
const inputHashes=await Promise.all(files.map(async file=>({file:path.relative(repo,file),sha256:await hash(file)})));
const sources=['packages/cli/src/services/hook-source-summary.ts','packages/cli/src/services/lowered-hook-coverage.ts','packages/cli/src/services/prototype-style-tokens.ts'];
const sourceHashes=await Promise.all(sources.map(async file=>({file,sha256:await hash(path.join(repo,file))})));
const start=performance.now();
const inventory=scanRuleStateReadInventory(files);
const unresolved=inventory.evaluated.flatMap(row=>row.unresolved.map(miss=>({entryFile:row.entryFile,rule:row.rule,callPath:row.callPath,declarationOnly:row.declarationOnly,...miss})));
const counts={files:files.length,observations:inventory.observations.length,evaluated:inventory.evaluated.length,usages:inventory.evaluated.reduce((n,row)=>n+row.usages.length,0),unresolved:unresolved.length,elapsedMs:performance.now()-start,heapUsed:process.memoryUsage().heapUsed,rss:process.memoryUsage().rss};
const summarize=new Map();
for(const miss of unresolved){const key=path.relative(repo,miss.entryFile);summarize.set(key,(summarize.get(key)||0)+1)}
const report={sourceHead:execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim(),sourceHashes,inputHashes,counts,inventory,unresolved};
await writeFile(path.join(out,'inventory.json'),JSON.stringify(report,null,2)+'\n');
const brief={...counts,topUnresolved:[...summarize].sort((a,b)=>b[1]-a[1]).slice(0,25)};
await writeFile(path.join(out,'summary.json'),JSON.stringify(brief,null,2)+'\n');
console.log(JSON.stringify(brief,null,2));
