import os,json,subprocess,hashlib,traceback,datetime,difflib
from pathlib import Path
E=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/integration-20261123-0320')
R=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
D=Path(__file__).resolve().parent
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def save():
 p=D/'status.tmp';p.write_text(json.dumps(S,ensure_ascii=False,indent=2)+'\n');os.replace(p,D/'status.json')
env=dict(os.environ)
env['PATH']=str(R/'tools/node-v24.22.3-linux-x64/bin')+':'+env.get('PATH','')
env['COREPACK_HOME']=str(R/'corepack-cache')
env['ASTRO_TELEMETRY_DISABLED']='1'
env['GIT_OPTIONAL_LOCKS']='0';env['GIT_NO_LAZY_FETCH']='1'
def run(name,argv,timeout=120,allowed=(0,)):
 S['stage']=name;save();beg=now()
 with (D/(name+'.stdout')).open('wb') as out,(D/(name+'.stderr')).open('wb') as err:
  p=subprocess.Popen(argv,cwd=C,env=env,stdout=out,stderr=err);S['child']={'pid':p.pid,'argv':argv};save();expired=False
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   expired=True;p.terminate()
   try:code=p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();code=p.wait()
 S.pop('child',None);S['steps'].append({'name':name,'argv':argv,'started':beg,'finished':now(),'exit':code,'timedOut':expired});save()
 assert not expired and code in allowed,name+' exit='+str(code)
 return (D/(name+'.stdout')).read_text()
def failure(e):
 S['status']='failed';S['error']=repr(e);S['traceback']=traceback.format_exc();S['finished']=now();save()
def source(rel): 
 b=(C/rel).read_bytes();return {'sha256':sha(b),'bytes':len(b)}


import re
C=Path('/var/tmp/proto-ui-s5-input-origin-b880-20261123-2231')
assert str(C).startswith('/var/tmp/proto-ui-') and C.is_dir() and str(C)!='undefined'
env['TMPDIR']='/var/tmp/proto-ui-s5-scope-workflow-temp-20261123-2316'
Path(env['TMPDIR']).mkdir(exist_ok=True)
head='1afa22e88c087db244f0e28a835b2926fb8bce8e'
mod='packages/adapters/web-component/src/runtime/modules.ts'
test='packages/adapters/web-component/test/shadow-closeout.browser.test.ts'
workflow='.github/workflows/compiler-browser-acceptance.yml'
S={'status':'running','started':now(),'pid':os.getpid(),'checkout':str(C),'baseHead':head,'steps':[],'workflowApplied':False}
save()
try:
 G=json.loads((E/'current-s5-1afa-native-scope-regression-01/status.json').read_text())
 assert G['status']=='passed-native-red-2-2-green-4-and-author-60' and G.get('finished')
 assert run('head',['git','rev-parse','HEAD']).strip()==head
 assert not run('index',['git','diff','--cached','--name-only']).strip()
 assert not run('untracked',['git','ls-files','--others','--exclude-standard']).strip()
 assert set(run('changed-before',['git','diff','--name-only']).splitlines())=={mod,test}
 assert source(mod)==G['productAfter'] and source(test)==G['testAfter']
 pr=json.loads(run('fresh-pr',['gh','api','repos/Proto-UI/Proto-UI/pulls/1738','--jq','{state,draft,head:{sha:.head.sha,ref:.head.ref}}'],30))
 assert pr['state']=='open' and pr['head']['sha']==head and pr['draft'] is True,pr
 S['publicBefore']=pr
 plan=json.loads((D/'plan.json').read_text())
 raw=(C/workflow).read_bytes()
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==plan['gitBlob']
 (D/'before.workflow.yml').write_bytes(raw)
 content=raw.decode()
 for old,new in plan['replacements']:
  assert content.count(old)==1,old
  content=content.replace(old,new,1)
 (C/workflow).write_text(content)
 S['workflowApplied']=True;save()
 run('normal-workflow-format',['node','node_modules/prettier/bin/prettier.cjs','--write',workflow])
 run('normal-workflow-format-check',['node','node_modules/prettier/bin/prettier.cjs','--check',workflow])
 output=run('original-workflow-policy-controls',['node','--test','scripts/ci/test/ci-scheduling-policy.test.mjs'],120)
 counts={}
 for name in ['tests','suites','pass','fail','cancelled','skipped','todo']:
  found=re.findall(r'^# '+name+r' (\d+)$',output,re.M)
  if found:counts[name]=int(found[-1])
 assert counts.get('fail')==0 and counts.get('cancelled',0)==0
 S['policyCounts']=counts
 assert source(mod)==G['productAfter'] and source(test)==G['testAfter']
 run('diff-check',['git','diff','--check'])
 paths=[mod,test,workflow]
 assert set(run('changed-after',['git','diff','--name-only']).splitlines())==set(paths)
 S['after']={rel:source(rel) for rel in paths}
 (D/'after.workflow.yml').write_bytes((C/workflow).read_bytes())
 diff=run('candidate-diff',['git','diff','--binary','--',*paths])
 (D/'candidate.patch').write_text(diff)
 S['diffSha256']=sha(diff.encode())
 S['status']='workflow-integrated-policy-passed';S['finished']=now();save()
except BaseException as e:failure(e);raise
