import os,json,subprocess,hashlib,traceback,datetime,difflib
from pathlib import Path
E=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/integration-20261123-0320')
R=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
D=Path(__file__).resolve().parent
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def save():
 p=D/'status.tmp';p.write_text(json.dumps(S,ensure_ascii=False,indent=2)+'\n');os.replace(p,D/'status.json')
env=dict(os.environ)
env['PATH']=str(R/'tools/node-v24.22.3-linux-x64/bin')+':'+env.get('PATH','')
env['COREPACK_HOME']=str(R/'corepack-cache')
env['ASTRO_TELEMETRY_DISABLED']='1'
env['GIT_OPTIONAL_LOCKS']='0';env['GIT_NO_LAZY_FETCH']='1'
def run(name,argv,timeout=120,allowed=(0,)):
 S['stage']=name;save();beg=now()
 with (D/(name+'.stdout')).open('wb') as out,(D/(name+'.stderr')).open('wb') as err:
  p=subprocess.Popen(argv,cwd=C,env=env,stdout=out,stderr=err);S['child']={'pid':p.pid,'argv':argv};save();expired=False
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   expired=True;p.terminate()
   try:code=p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();code=p.wait()
 S.pop('child',None);S['steps'].append({'name':name,'argv':argv,'started':beg,'finished':now(),'exit':code,'timedOut':expired});save()
 assert not expired and code in allowed,name+' exit='+str(code)
 return (D/(name+'.stdout')).read_text()
def failure(e):
 S['status']='failed';S['error']=repr(e);S['traceback']=traceback.format_exc();S['finished']=now();save()
def source(rel): 
 b=(C/rel).read_bytes();return {'sha256':sha(b),'bytes':len(b)}


import signal
C=Path('/var/tmp/proto-ui-s5-input-origin-b880-20261123-2231')
assert str(C).startswith('/var/tmp/proto-ui-') and C.is_dir() and str(C)!='undefined'
env['TMPDIR']='/var/tmp/proto-ui-s5-input-origin-temp-20261123-2231'
env['CHROME_PATH']=str(R/'tools/playwright-browsers/chromium-1208/chrome-linux64/chrome')
assert Path(env['CHROME_PATH']).is_file()
head='1afa22e88c087db244f0e28a835b2926fb8bce8e'
old='29bac4a3f7032002d8b5468fc9c22b8509338d9f'
branch='work/s5-native-scope-1afa-20261123'
mod='packages/adapters/web-component/src/runtime/modules.ts'
test='packages/adapters/web-component/test/shadow-closeout.browser.test.ts'
unit='packages/adapters/web-component/test/focus-entry-input-origin.test.ts'
S={'status':'running','started':now(),'pid':os.getpid(),'checkout':str(C),'head':head,'steps':[],'productApplied':False}
save()
def browser(name):
 phase=D/name;phase.mkdir()
 argv=['corepack','pnpm@10.32.1','exec','vitest','run',test,'--pool=forks','--maxWorkers=1','--minWorkers=1','--no-file-parallelism','-t','reprojects entry during native dir=auto (input|textarea) input without an attribute change|reprojects entry during native input in an @scope (start|end) selector','--reporter=default','--reporter=json','--outputFile='+str(phase/'vitest.json')]
 S['stage']=name;save();beg=now();expired=False
 benv=dict(env);benv['PROTO_UI_RUNTIME_EVIDENCE_DIR']=str(phase);benv['CANDIDATE_SHA']=head
 benv['PROTO_UI_SCOPE_VALIDATION_TASK']=str(phase)
 with (D/(name+'.stdout')).open('wb') as out,(D/(name+'.stderr')).open('wb') as err:
  p=subprocess.Popen(argv,cwd=C,env=benv,stdout=out,stderr=err,start_new_session=True)
  S['child']={'pid':p.pid,'pgid':p.pid,'argv':argv};save()
  try:code=p.wait(timeout=120)
  except subprocess.TimeoutExpired:
   expired=True
   try:os.killpg(p.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:code=p.wait(timeout=5)
   except subprocess.TimeoutExpired:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    code=p.wait()
 S.pop('child',None)
 S['steps'].append({'name':name,'argv':argv,'started':beg,'finished':now(),'exit':code,'timedOut':expired,'outerResourceTimeoutSeconds':120,'testBoundsUnchanged':True})
 save()
 assert not expired and code in (0,1),'Browser environment/timeout failure: '+name
 j=json.loads((phase/'vitest.json').read_text())
 rows=[a for f in j['testResults'] for a in f['assertionResults']]
 selected=[a for a in rows if a['status'] in ('passed','failed')]
 titles={a['title'] for a in selected}
 expected={f'reprojects entry during native dir=auto {kind} input without an attribute change' for kind in ['input','textarea']}|{f'reprojects entry during native input in an @scope {kind} selector' for kind in ['start','end']}
 result={'counts':{k:j.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests','success']},'selected':[{k:a.get(k) for k in ['fullName','title','status','failureMessages']} for a in selected],'reportSha256':sha((phase/'vitest.json').read_bytes())}
 S[name]=result;save()
 assert titles==expected and len(selected)==4 and j['numTotalTests']==194 and j['numPendingTests']==190 and j.get('numTodoTests',0)==0,'Unexpected selected cases/environment; preserve without changing oracle'
 return j,selected
try:
 assert json.loads((E/'current-s1-411a-cssom-getter-matrix-01/status.json').read_text())['status']=='matrix-failed'
 assert json.loads((E/'current-s4-c18-cleanup-reentry-green-01/status.json').read_text())['status']=='passed-54-and-workspace-types'
 assert json.loads((E/'current-s1-411a-producer-probe-01/status.json').read_text())['status']=='diagnostic-completed'
 assert run('prior-head',['git','rev-parse','HEAD']).strip()==old
 assert not run('clean-before',['git','status','--porcelain=v1','--untracked-files=all']).strip()
 public=json.loads(run('fresh-public',['gh','api','repos/Proto-UI/Proto-UI/pulls/1738','--jq','{state,draft,head:{sha:.head.sha,ref:.head.ref}}'],30))
 assert public['head']['sha']==head and public['state']=='open',public
 S['publicBefore']=public
 run('fetch-exact',['git','fetch','--no-tags','origin',head],120)
 assert run('fetched-head',['git','rev-parse','FETCH_HEAD']).strip()==head
 assert run('fetched-parent',['git','rev-parse',head+'^']).strip()=='25ca6fcaecd917457f6f3d694b3e12bfb522e89a'
 delta=run('record-successor-diff',['git','diff','--name-only','25ca6fcaecd917457f6f3d694b3e12bfb522e89a',head]).splitlines()
 assert delta and all(p.startswith('internal/records/') for p in delta),delta
 S['recordOnlySuccessorPaths']=delta
 beforeLock=run('lock-old',['git','rev-parse',old+':pnpm-lock.yaml']).strip()
 assert run('lock-new',['git','rev-parse',head+':pnpm-lock.yaml']).strip()==beforeLock
 assert run('agents-old',['git','rev-parse',old+':AGENTS.md']).strip()==run('agents-new',['git','rev-parse',head+':AGENTS.md']).strip()
 run('switch-owned-new-branch',['git','switch','-c',branch,head],120)
 assert not run('clean-current',['git','status','--porcelain=v1','--untracked-files=all']).strip()
 assert run('module-blob',['git','hash-object','--',mod]).strip()=='ea392c52f4ea577f81d9a82eb802a24d7ba6561e'
 assert run('test-blob',['git','hash-object','--',test]).strip()=='d7b58d317f05266f8b647a0fac70c91e12279a5e'
 assert run('unit-blob',['git','hash-object','--',unit]).strip()=='449661fe74dc63b8be794b46a75acc3bfba2c0c3'
 S['node']=run('node-version',['node','--version']).strip()
 S['chrome']=run('chrome-version',[env['CHROME_PATH'],'--version']).strip()
 P=E/'current-s5-b880-scope-candidates-01'
 for n,h,z in [('test-only.patch','e1b006f7ee7fcf5caf82253ba299e4c5d08fa5ac27c6877d6d0543a5d5275a56',5738),('product.patch','c40b037aff8227cd318fa6b3670b482d5940260fc35d20850563dca5928b6e4a',1117)]:
  b=(P/n).read_bytes();assert len(b)==z and sha(b)==h
  (D/n).write_bytes(b)
 S['before']={rel:source(rel) for rel in [mod,test,unit]}
 for rel in [mod,test]:
  p=D/'before'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((C/rel).read_bytes())
 run('test-patch-check',['git','apply','--check',str(D/'test-only.patch')])
 run('test-patch-apply',['git','apply',str(D/'test-only.patch')])
 run('normal-test-format',['node','node_modules/prettier/bin/prettier.cjs','--write',test])
 run('test-diff-check',['git','diff','--check'])
 S['testAfter']=source(test);save()
 j,rows=browser('red')
 failed=[a for a in rows if a['status']=='failed']
 assert j['numPassedTests']==2 and j['numFailedTests']==2 and len(failed)==2 and all('native input in an @scope' in a['title'] for a in failed),'Expected actual scope assertion failures only'
 assert all(any('AssertionError' in m for m in a.get('failureMessages',[])) for a in failed),'Setup error is not source counterexample'
 assert source(mod)==S['before'][mod] and source(unit)==S['before'][unit]
 S['redProved']=True;save()
 run('product-patch-check',['git','apply','--check',str(D/'product.patch')])
 run('product-patch-apply',['git','apply',str(D/'product.patch')]);S['productApplied']=True;save()
 run('normal-product-format',['node','node_modules/prettier/bin/prettier.cjs','--write',mod])
 S['productAfter']=source(mod);save()
 j,rows=browser('green')
 assert j['success'] and j['numPassedTests']==4 and j['numFailedTests']==0
 assert source(test)==S['testAfter']
 assert source(unit)==S['before'][unit]
 (D/'unit').mkdir()
 run('author-complete-input-origin-controls',['node','node_modules/vitest/vitest.mjs','run','--no-file-parallelism','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(D/'unit/vitest.json'),unit],120)
 j=json.loads((D/'unit/vitest.json').read_text());S['authorUnitCounts']={k:j.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests','success']}
 assert j['success'] and j['numTotalTests']==60 and j['numPassedTests']==60 and j['numPendingTests']==0 and j.get('numTodoTests',0)==0
 run('normal-format-check',['node','node_modules/prettier/bin/prettier.cjs','--check',mod,test])
 run('diff-check',['git','diff','--check'])
 assert set(run('changed',['git','diff','--name-only']).splitlines())=={mod,test}
 assert source(mod)==S['productAfter'] and source(test)==S['testAfter']
 S['diffSha256']=sha(run('final-diff',['git','diff','--binary']).encode())
 S['status']='passed-native-red-2-2-green-4-and-author-60';S['finished']=now();save()
except BaseException as e:failure(e);raise
