import { afterEach, describe, expect, it, vi } from 'vitest';
import { createAnatomyFamily } from '@proto.ui/core';
import { AnatomyModuleImpl } from '../src/impl';
import type { AnatomyRootTargetGetter } from '../src/caps';
import { makeCaps } from './utils/fake-caps';

const owners: AnatomyModuleImpl[] = [];
afterEach(() => {
  for (const owner of owners.splice(0).reverse()) owner.dispose();
});

function fixture(getRootTarget: AnatomyRootTargetGetter) {
  const family = createAnatomyFamily('independent-comparison-review', {
    roles: {
      root: { cardinality: { min: 1, max: 1 } },
      item: { cardinality: { min: 0, max: '*' } },
    },
  });
  const rootToken = {};
  const getParent = (token: unknown) => (token === rootToken ? null : rootToken);
  const make = (role?: 'root' | 'item') => {
    const owner = new AnatomyModuleImpl(
      makeCaps({
        instance: role === 'root' ? rootToken : {},
        getParent,
        getPrototype: () => ({ name: 'review-owner', setup() {} }),
        getRootTarget,
      }),
      'review-owner',
      { get: () => undefined, getAll: () => ({}), has: () => false, keys: () => [] }
    );
    owners.push(owner);
    if (role) owner.claim(family, { role });
    return owner;
  };
  const root = make('root');
  return { root, rootToken, make, family, notify: () => root.port.syncStructure() };
}

describe('independent comparison-path adversarial controls', () => {
  it('revalidates the right target identity while the left target and comparator stay unchanged', () => {
    const compare = function (this: { rank: number }, other: unknown) {
      return this.rank < (other as { rank: number }).rank ? 4 : 2;
    };
    const oldRoot = { rank: 0, compareDocumentPosition: compare };
    const newRoot = { rank: 2, compareDocumentPosition: compare };
    const item = { rank: 1, compareDocumentPosition: compare };
    let rootToken: unknown;
    let armed = false;
    let reads = 0;
    const f = fixture((token) =>
      token === rootToken ? (armed && ++reads >= 2 ? newRoot : oldRoot) : item
    );
    rootToken = f.rootToken;
    f.make('item');
    const first = vi.fn();
    const later = vi.fn();
    f.make().port.subscribeOrder(f.family, first);
    f.make().port.subscribeOrder(f.family, later);
    armed = true;
    f.notify();
    armed = false;
    expect(reads).toBe(2);
    expect(first).not.toHaveBeenCalled();
    expect(later).toHaveBeenCalledOnce();
  });

  it('reads a comparator accessor on every comparison even when target identities are stable', () => {
    const root = { compareDocumentPosition: () => 4 };
    const forward = () => 2;
    const reverse = () => 4;
    let armed = false;
    let reads = 0;
    const item = {
      get compareDocumentPosition() {
        return armed && ++reads >= 2 ? reverse : forward;
      },
    };
    let rootToken: unknown;
    const f = fixture((token) => (token === rootToken ? root : item));
    rootToken = f.rootToken;
    f.make('item');
    const first = vi.fn();
    const later = vi.fn();
    f.make().port.subscribeOrder(f.family, first);
    f.make().port.subscribeOrder(f.family, later);
    armed = true;
    f.notify();
    armed = false;
    expect(reads).toBe(2);
    expect(first).not.toHaveBeenCalled();
    expect(later).toHaveBeenCalledOnce();
  });

  it('keeps stable fallback for an intervening uncomparable target then sees its new valid comparator', () => {
    const root = { compareDocumentPosition: () => 4 };
    const item: { compareDocumentPosition?: () => number } = { compareDocumentPosition: () => 2 };
    const reverse = () => 4;
    let rootToken: unknown;
    let armed = false;
    let reads = 0;
    const f = fixture((token) => {
      if (token === rootToken) return root;
      if (armed && ++reads === 2) item.compareDocumentPosition = undefined;
      if (armed && reads === 3) item.compareDocumentPosition = reverse;
      return item;
    });
    rootToken = f.rootToken;
    f.make('item');
    const listeners = [vi.fn(), vi.fn(), vi.fn()];
    for (const listener of listeners) f.make().port.subscribeOrder(f.family, listener);
    armed = true;
    f.notify();
    armed = false;
    expect(reads).toBe(3);
    expect(listeners[0]).not.toHaveBeenCalled();
    expect(listeners[1]).not.toHaveBeenCalled();
    expect(listeners[2]).toHaveBeenCalledOnce();
  });

  it('does not hide a later comparator getter failure behind an earlier trace result', () => {
    const root = { compareDocumentPosition: () => 4 };
    const forward = () => 2;
    let armed = false;
    let reads = 0;
    const item = {
      get compareDocumentPosition() {
        if (armed && ++reads === 2) throw new Error('host comparator getter failed');
        return forward;
      },
    };
    let rootToken: unknown;
    const f = fixture((token) => (token === rootToken ? root : item));
    rootToken = f.rootToken;
    f.make('item');
    const listeners = [vi.fn(), vi.fn()];
    for (const listener of listeners) f.make().port.subscribeOrder(f.family, listener);
    armed = true;
    expect(() => f.notify()).toThrow('host comparator getter failed');
    armed = false;
    expect(() => f.notify()).not.toThrow();
    expect(listeners.every((listener) => listener.mock.calls.length === 0)).toBe(true);
  });
});
