from pathlib import Path
import datetime
import hashlib
import json
import shutil
import subprocess
import sys

source = Path(__file__).parent / 'root-native-cost-unique-inputs'
destination = Path(__file__).parent / 'unique-artifact-negative-controls-v2'
destination.mkdir(exist_ok=False)
original = json.loads((source / 'import-manifest.json').read_text())
assert all(hashlib.sha256((source / name).read_bytes()).hexdigest() == sha
           for name, sha in original.items())
results = []
mutants = [
    ('duplicate-library', 'Every measured tree requires its own linked library filename'),
    ('cargo-library-mismatch', 'Library identity does not match the frozen case: base_button'),
    ('receipt-library-mismatch', 'Library identity does not match the frozen case: base_button'),
    ('omitted-tree', 'The exact empty / original Base Button / composed denominator is required'),
]
for name, expected in mutants:
    root = destination / name
    generated = root / 'generated'
    shutil.copytree(source, generated)
    receipt_path = generated / 'source-receipt.json'
    receipt = json.loads(receipt_path.read_text())
    if name == 'duplicate-library':
        receipt['cases'][1]['libraryName'] = receipt['cases'][0]['libraryName']
    elif name == 'cargo-library-mismatch':
        manifest_path = generated / 'consumers/base_button/Cargo.toml'
        value = manifest_path.read_text()
        assert value.count('name = "proto_ui_cost_base_button"') == 1
        manifest_path.write_text(value.replace('name = "proto_ui_cost_base_button"',
                                               'name = "proto_ui_cost_empty"'))
    elif name == 'receipt-library-mismatch':
        receipt['cases'][1]['libraryName'] = 'proto_ui_cost_foreign'
    elif name == 'omitted-tree':
        receipt['cases'].pop()
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    # Freeze each deliberately invalid complete input, so the semantic identity
    # guards execute rather than an incidental manifest-integrity mismatch.
    manifest = {file: hashlib.sha256((generated / file).read_bytes()).hexdigest()
                for file in original}
    (generated / 'import-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    command = [sys.executable, str(generated / 'run-cost.py'), str(generated),
               '--output', str(root / 'result'), '--target-dir', str(root / 'unused-target')]
    run = subprocess.run(command, capture_output=True, text=True)
    (root / 'stdout.log').write_text(run.stdout)
    (root / 'stderr.log').write_text(run.stderr)
    state = json.loads((root / 'result/status.json').read_text())
    assert run.returncode == 1, name
    assert state['status'] == 'failed' and expected in state['error'], name
    assert state['commands'] == [] and state['cases'] == [], name
    assert state['sourceDrift'] == [], name
    results.append({'name': name, 'exitCode': run.returncode, 'expected': expected,
                    'actualError': state['error'], 'cargoOrLinkExecuted': False,
                    'statusSha256': hashlib.sha256((root / 'result/status.json').read_bytes()).hexdigest(),
                    'mutatedFiles': [file for file in original if original[file] != manifest[file]]})
report = {'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'sourceManifestSha256': hashlib.sha256((source / 'import-manifest.json').read_bytes()).hexdigest(),
          'runnerSha256': hashlib.sha256((source / 'run-cost.py').read_bytes()).hexdigest(),
          'mutationsDeclared': True, 'nativeAcceptanceClaimed': False, 'passed': len(results),
          'results': results}
(destination / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
