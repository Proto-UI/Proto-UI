use gpui::{prelude::*,App,Context,Entity,Render,Window};
use proto_ui_gpui_native::gpui_native_owner::{NativeSnapshot,OwnerRef,Value};
use serde_json::{json,Value as Json};use std::rc::Rc;
pub const CASE:&str="composed";pub const OWNER_COUNT:usize=4;
pub struct Tree{pub root:Entity<empty::CompiledComponent>,pub button0:Entity<base_button::CompiledComponent>,
pub button1:Entity<base_button::CompiledComponent>,
pub button2:Entity<base_button::CompiledComponent>,}
struct NativeChild;impl Render for NativeChild{fn render(&mut self,_:&mut Window,_:&mut Context<Self>)->impl IntoElement{gpui::div().child("ordinary native child")}}
impl Render for Tree{fn render(&mut self,_:&mut Window,_:&mut Context<Self>)->impl IntoElement{self.root.clone()}}
pub fn mount(window:&mut Window,cx:&mut App)->Entity<Tree>{
    let root=empty::CompiledComponent::create(json!({}),None,window,cx).expect("compiled root");
    let button0=base_button::CompiledComponent::create(json!({}),Some(Rc::downgrade(&root.read(cx).owner)),window,cx).expect("official Base Button");
    button0.update(cx,|button,cx|button.set_slot(vec![NativeSnapshot::text_value(Value::string("button0"))],cx).unwrap());
let button1=base_button::CompiledComponent::create(json!({}),Some(Rc::downgrade(&root.read(cx).owner)),window,cx).expect("official Base Button");
    button1.update(cx,|button,cx|button.set_slot(vec![NativeSnapshot::text_value(Value::string("button1"))],cx).unwrap());
let button2=base_button::CompiledComponent::create(json!({}),Some(Rc::downgrade(&root.read(cx).owner)),window,cx).expect("official Base Button");
    button2.update(cx,|button,cx|button.set_slot(vec![NativeSnapshot::text_value(Value::string("button2"))],cx).unwrap());let native=cx.new(|_|NativeChild);root.update(cx,|root,cx|root.set_slot(vec![NativeSnapshot::native_view(button0.clone().into()),NativeSnapshot::native_view(button1.clone().into()),NativeSnapshot::native_view(button2.clone().into()),NativeSnapshot::native_view(native.into())],cx).unwrap());
    cx.new(|_|Tree{root,button0,button1,button2})
}
impl Tree{
    #[cfg(feature="test-support")]pub fn owners(&self,cx:&App)->Vec<OwnerRef>{vec![self.root.read(cx).owner.clone(),self.button0.read(cx).owner.clone(),self.button1.read(cx).owner.clone(),self.button2.read(cx).owner.clone()]}
    #[cfg(feature="test-support")]pub fn resource_counts(&self,cx:&App)->Json{json!({"root":self.root.read(cx).native_resource_counts(),"button0":self.button0.read(cx).native_resource_counts(),"button1":self.button1.read(cx).native_resource_counts(),"button2":self.button2.read(cx).native_resource_counts()})}
    #[cfg(feature="test-support")]pub fn exercise(&mut self,window:&mut Window,cx:&mut Context<Self>){
        self.button0.update(cx,|button,cx|{button.set_props(json!({"disabled":true}),window,cx).unwrap();assert_eq!(button.handle().state("disabled").unwrap(),json!(true));
        button.set_props(json!({"disabled":false}),window,cx).unwrap();assert_eq!(button.handle().state("disabled").unwrap(),json!(false));});

        self.button1.update(cx,|button,cx|{button.set_props(json!({"disabled":true}),window,cx).unwrap();assert_eq!(button.handle().state("disabled").unwrap(),json!(true));
        button.set_props(json!({"disabled":false}),window,cx).unwrap();assert_eq!(button.handle().state("disabled").unwrap(),json!(false));});

        self.button2.update(cx,|button,cx|{button.set_props(json!({"disabled":true}),window,cx).unwrap();assert_eq!(button.handle().state("disabled").unwrap(),json!(true));
        button.set_props(json!({"disabled":false}),window,cx).unwrap();assert_eq!(button.handle().state("disabled").unwrap(),json!(false));});}
    #[cfg(feature="test-support")]pub fn retire(&mut self,window:&mut Window,cx:&mut Context<Self>){self.button2.update(cx,|component,cx|component.handle().dispose(window,cx).unwrap());
self.button1.update(cx,|component,cx|component.handle().dispose(window,cx).unwrap());
self.button0.update(cx,|component,cx|component.handle().dispose(window,cx).unwrap());
self.root.update(cx,|component,cx|component.handle().dispose(window,cx).unwrap());}
}
#[cfg(feature="test-support")]pub fn assert_resource_boundary(resources:&Json){
    let root=&resources["root"];for key in ["states","hooks","listeners","stateWatchers","propsWatchers","contextSubscriptions","anatomySubscriptions","collectionStates","scrollHandles","boundaryRegions","boundaryCallbacks","metadataKeys","schedulerBindings","delays","presenceOwners","nativeSubscriptions"]{assert_eq!(root[key],json!(0),"empty owner unexpectedly initialized {key}: {root}");}
    for key in ["pointerInput","keyInput","boundaryInput","focusObservation"]{assert_eq!(root[key],json!(false));}
    assert!(resources["button0"]["states"].as_u64().unwrap()>0);assert!(resources["button0"]["nativeSubscriptions"].as_u64().unwrap()>0);
assert!(resources["button1"]["states"].as_u64().unwrap()>0);assert!(resources["button1"]["nativeSubscriptions"].as_u64().unwrap()>0);
assert!(resources["button2"]["states"].as_u64().unwrap()>0);assert!(resources["button2"]["nativeSubscriptions"].as_u64().unwrap()>0);
}
// A narrow native linking probe: the same ordinary mount implementation is
// retained behind symbols. This ABI is only for this exact Rust/GPUI build.
#[no_mangle]pub unsafe extern "C" fn proto_ui_cost_mount(window:*mut Window,cx:*mut App)->*mut Entity<Tree>{Box::into_raw(Box::new(mount(&mut *window,&mut *cx)))}
#[no_mangle]pub unsafe extern "C" fn proto_ui_cost_drop(tree:*mut Entity<Tree>){if !tree.is_null(){drop(Box::from_raw(tree));}}
