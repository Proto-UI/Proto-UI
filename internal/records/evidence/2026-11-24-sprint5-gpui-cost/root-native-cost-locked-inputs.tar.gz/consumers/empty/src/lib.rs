use gpui::{prelude::*,App,Context,Entity,Render,Window};
use proto_ui_gpui_native::gpui_native_owner::{NativeSnapshot,OwnerRef,Value};
use serde_json::{json,Value as Json};use std::rc::Rc;
pub const CASE:&str="empty";pub const OWNER_COUNT:usize=1;
pub struct Tree{pub root:Entity<empty::CompiledComponent>,}
struct NativeChild;impl Render for NativeChild{fn render(&mut self,_:&mut Window,_:&mut Context<Self>)->impl IntoElement{gpui::div().child("ordinary native child")}}
impl Render for Tree{fn render(&mut self,_:&mut Window,_:&mut Context<Self>)->impl IntoElement{self.root.clone()}}
pub fn mount(window:&mut Window,cx:&mut App)->Entity<Tree>{
    let root=empty::CompiledComponent::create(json!({}),None,window,cx).expect("compiled root");
    
    cx.new(|_|Tree{root})
}
impl Tree{
    #[cfg(feature="test-support")]pub fn owners(&self,cx:&App)->Vec<OwnerRef>{vec![self.root.read(cx).owner.clone()]}
    #[cfg(feature="test-support")]pub fn resource_counts(&self,cx:&App)->Json{json!({"root":self.root.read(cx).native_resource_counts()})}
    #[cfg(feature="test-support")]pub fn exercise(&mut self,window:&mut Window,cx:&mut Context<Self>){}
    #[cfg(feature="test-support")]pub fn retire(&mut self,window:&mut Window,cx:&mut Context<Self>){self.root.update(cx,|component,cx|component.dispose(window,cx).unwrap());}
}
#[cfg(feature="test-support")]pub fn assert_resource_boundary(resources:&Json){
    let root=&resources["root"];for key in ["states","hooks","listeners","stateWatchers","propsWatchers","contextSubscriptions","anatomySubscriptions","collectionStates","scrollHandles","boundaryRegions","boundaryCallbacks","metadataKeys","schedulerBindings","delays","presenceOwners","nativeSubscriptions"]{assert_eq!(root[key],json!(0),"empty owner unexpectedly initialized {key}: {root}");}
    for key in ["pointerInput","keyInput","boundaryInput","focusObservation"]{assert_eq!(root[key],json!(false));}
    
}
// A narrow native linking probe: the same ordinary mount implementation is
// retained behind symbols. This ABI is only for this exact Rust/GPUI build.
#[no_mangle]pub unsafe extern "C" fn proto_ui_cost_mount(window:*mut Window,cx:*mut App)->*mut Entity<Tree>{Box::into_raw(Box::new(mount(&mut *window,&mut *cx)))}
#[no_mangle]pub unsafe extern "C" fn proto_ui_cost_drop(tree:*mut Entity<Tree>){if !tree.is_null(){drop(Box::from_raw(tree));}}
