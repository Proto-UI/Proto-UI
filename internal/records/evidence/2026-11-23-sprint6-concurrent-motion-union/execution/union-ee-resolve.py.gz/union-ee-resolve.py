from pathlib import Path
import os, json, hashlib, subprocess, time, re, fcntl, traceback

root = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
base = Path(str(root) + '-ops/final-23122')
ops = base / 'union-ee2379'
status = ops / 'resolution-status.json'
lock = open(ops / 'resolution.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not status.exists(), 'Read existing resolution receipt before another writer.'
env = dict(os.environ)
env['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:' + env['PATH']
env['TMPDIR'] = '/var/tmp/s6-75d5-modal'
env['GIT_OPTIONAL_LOCKS'] = '0'
head = 'cf15c6b15ea575f5c62f891c9c5502621bdf7882'
remote = 'ee2379da5a71c811268efb1b692e38d35c70c870'
workflow = '.github/workflows/bootstrap-state-controls-evidence.yml'
gate = 'scripts/test/check-bootstrap-motion-evidence.mjs'
test = 'scripts/test/check-bootstrap-motion-evidence.test.mjs'
files = [workflow, gate, test]
state = {'phase': 'starting', 'pid': os.getpid(), 'head': head, 'remote': remote, 'runs': []}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save():
    t = status.with_suffix('.tmp'); t.write_text(json.dumps(state, indent=2)+'\n'); os.replace(t,status)

def git(*args):
    return subprocess.check_output(['git','-c','core.fsmonitor=false','-c','submodule.recurse=false',*args],cwd=root,env=env,text=True,timeout=120).rstrip('\n')

def blob(ref, path):
    return subprocess.check_output(['git','show',ref+':'+path],cwd=root,env=env,timeout=120).decode()

def run(args, label, seconds=240):
    state['phase']=label; save(); log=ops/(label+'.log'); started=time.monotonic()
    with log.open('w') as out:
        p=subprocess.Popen(args,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
        state['childPid']=p.pid; save()
        try: code=p.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            state['pendingChild']={'pid':p.pid,'label':label,'outerSeconds':seconds}; save(); raise
    state.pop('childPid',None)
    state['runs'].append({'name':label,'command':args,'exit':code,'seconds':round(time.monotonic()-started,3),'logSha256':sha(log)}); save()
    assert code==0,{'label':label,'exit':code}

def once(source, before, after):
    assert source.count(before)==1, before
    return source.replace(before,after)

try:
    save()
    merge=json.loads((ops/'merge-status.json').read_text())
    assert merge['phase']=='merged-awaiting-resolution' and merge['conflicts']==files
    assert not Path('/proc/'+str(merge['pid'])).exists()
    assert git('rev-parse','HEAD')==head
    assert Path(git('rev-parse','--git-path','MERGE_HEAD')).read_text().splitlines()==[remote]
    assert git('diff','--name-only','--diff-filter=U').splitlines()==files
    before={p:(root/p).read_text() for p in files}
    state['conflictedFileSha256']={p:sha(root/p) for p in files}
    pattern=re.compile(r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> '+remote+r'\n',re.M|re.S)
    resolved={}; blocks={}
    for p in files:
        found=list(pattern.finditer(before[p])); blocks[p]=[{'ours':m[1],'theirs':m[2]} for m in found]
        assert len(found)=={workflow:1,gate:2,test:3}[p],p
        resolved[p]=pattern.sub(lambda m:m[1],before[p])
        assert not any(marker in resolved[p] for marker in ['<<<<<<<','=======','>>>>>>>']),p
    resolved[workflow]=once(resolved[workflow],'Require all 130 motion assertions','Require all 137 motion assertions')
    resolved[gate]=once(resolved[gate],"{ file: 'packages/modules/feedback/test/resident-width.test.ts', cases: 6 }","{ file: 'packages/modules/feedback/test/resident-width.test.ts', cases: 9 }")
    resolved[gate]=once(resolved[gate],"{ file: 'packages/adapters/base/test/web-resident-width.test.ts', cases: 7 }","{ file: 'packages/adapters/base/test/web-resident-width.test.ts', cases: 11 }")
    for a,b in [('numTotalTests: 130','numTotalTests: 137'),('numPassedTests: 130','numPassedTests: 137'),('eleven exact files and 130 executed','eleven exact files and 137 executed'),('result.requiredAssertions, 130','result.requiredAssertions, 137'),('report.numTotalTests = 131;','report.numTotalTests = 138;')]:
        resolved[test]=once(resolved[test],a,b)
    # Verify the conflict-only reconciliation cannot discard unrelated incoming work.
    assert resolved[workflow]==blob(remote,workflow).replace('Require all 136 motion assertions','Require all 137 motion assertions')
    expected_gate=blob(head,gate).replace("'packages/modules/feedback/test/resident-width.test.ts', cases: 6","'packages/modules/feedback/test/resident-width.test.ts', cases: 9").replace("'packages/adapters/base/test/web-resident-width.test.ts', cases: 7","'packages/adapters/base/test/web-resident-width.test.ts', cases: 11")
    assert resolved[gate]==expected_gate
    expected_test=blob(head,test)
    for a,b in [('numTotalTests: 130','numTotalTests: 137'),('numPassedTests: 130','numPassedTests: 137'),('eleven exact files and 130 executed','eleven exact files and 137 executed'),('result.requiredAssertions, 130','result.requiredAssertions, 137'),('report.numTotalTests = 131;','report.numTotalTests = 138;')]: expected_test=once(expected_test,a,b)
    assert resolved[test]==expected_test
    (ops/'conflict-blocks.json').write_text(json.dumps(blocks,indent=2)+'\n')
    for p in files:
        out=ops/'resolved-inputs'/p; out.parent.mkdir(parents=True,exist_ok=True); out.write_text(resolved[p])
    for p in files: assert sha(root/p)==state['conflictedFileSha256'][p],p
    for p in files: (root/p).write_text(resolved[p])
    run(['corepack','pnpm@10.32.1','exec','prettier','--check',*files],'resolution-format')
    run(['git','add','--',*files],'resolution-stage')
    assert not git('diff','--name-only','--diff-filter=U') and not git('diff','--name-only')
    run(['git','diff','--cached','--check'],'resolution-whitespace')
    inventory_code="import {BOOTSTRAP_MOTION_SUITES as s,MODAL_CASES as m,PROGRESS_CASES as p} from './scripts/test/check-bootstrap-motion-evidence.mjs'; console.log(JSON.stringify({suites:s,total:s.reduce((n,x)=>n+x.cases,0),source:s.filter(x=>!x.file.endsWith('.browser.test.ts')).reduce((n,x)=>n+x.cases,0),nativePositive:m.length+p.length,splitRejected:1}));"
    raw=subprocess.check_output(['node','--input-type=module','-e',inventory_code],cwd=root,env=env,text=True,timeout=30)
    inv=json.loads(raw); assert len(inv['suites'])==11 and inv['total']==137 and inv['source']==124 and inv['nativePositive']==12
    (ops/'motion-inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
    prep=json.loads((base/'final-current/preparation-r3-status.json').read_text())
    archive=json.loads((base/'final-current/checkpoint-archive-status.json').read_text())
    assert all(sha(root/x['path'])==x['sha256'] for x in prep['restored16'])
    assert sha(root/archive['record'])==archive['recordSha256'] and sha(root/archive['manifest'])==archive['manifestSha256']
    assert (root/'spec/host-caps/HC-CONTROL-LABEL-0001.yaml').read_bytes()==subprocess.check_output(['git','show','0fbb52ef832cc27c78e24c28c59a55a16f51d7fe:spec/host-caps/HC-CONTROL-LABEL-0001.yaml'],cwd=root,env=env,timeout=120)
    incoming=git('diff','--name-only','84ef7893e732a316388aeb730af1758b96f703e8',remote).splitlines()
    bound=set(prep['sourceSha256'])|{p for p in incoming if not p.startswith('internal/records/')}|{s['file'] for s in inv['suites']}
    bound.update(['pnpm-lock.yaml','scripts/test/run-bootstrap-public-validation.test.mjs','scripts/test/run-bootstrap-public-validation.mjs'])
    source_hashes={p:sha(root/p) for p in sorted(bound) if (root/p).is_file()}
    own_paths=git('diff','--cached','--name-only',remote,'--','packages','scripts','.github','spec').splitlines()
    run(['git','diff','--cached',remote,'--',*own_paths],'source-relative-to-external')
    state.update(phase='prepared-not-committed',tree=git('write-tree'),motionInventory=inv,sourceSha256=source_hashes,sourceBindings=len(source_hashes),ownSourcePaths=own_paths,protectedHistoryStable=True,checkpointRecordStable=True,resolvedSha256={p:sha(root/p) for p in files})
except BaseException as e:
    state.update(phase='pending-child' if 'pendingChild' in state else 'failed',error=repr(e),traceback=traceback.format_exc())
save()
