from pathlib import Path
import os,json,hashlib,subprocess,time,fcntl,traceback

root=Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
base=Path(str(root)+'-ops/final-23122');ops=base/'union-ee2379';out=ops/'type-repair'
out.mkdir(exist_ok=True);status=out/'status.json';lock=open(out/'worker.lock','a')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not status.exists(),'Read the existing worker before starting another mutation.'
env=dict(os.environ);env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env['PATH'];env['TMPDIR']='/var/tmp/s6-75d5-modal';env['GIT_OPTIONAL_LOCKS']='0'
state={'phase':'starting','pid':os.getpid(),'runs':[],'scope':'Two incoming material test fixtures only. No product, assertion, native timing or budget changes.'}
files=['packages/adapters/base/test/material-paint-reservation.test.ts','packages/modules/feedback/test/material-reservation-cleanup.test.ts']
expected={files[0]:'05b1b6ffafc5ac3269f5d3a0ab81cf63db6a2ea9f094f125f7286a3e37fe2ba1',files[1]:'0e930ec3af7ed8c62e15617ab595b90b80d6d36ed48182dc268d138eeb6ea2e3'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def save():
    t=status.with_suffix('.tmp');t.write_text(json.dumps(state,indent=2)+'\n');os.replace(t,status)
def git(*args):return subprocess.check_output(['git','-c','core.fsmonitor=false','-c','submodule.recurse=false',*args],cwd=root,env=env,text=True,timeout=120).strip()
def run(args,name,seconds=300,allowed=(0,)):
    state['phase']=name;save();log=out/(name+'.log');started=time.monotonic()
    with log.open('w') as stream:
        p=subprocess.Popen(args,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);state['childPid']=p.pid;save()
        try:code=p.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            state['pendingChild']={'pid':p.pid,'name':name,'outerSeconds':seconds};save();raise
    state.pop('childPid',None);state['runs'].append({'name':name,'command':args,'exit':code,'seconds':round(time.monotonic()-started,3),'logSha256':sha(log)});save();assert code in allowed
    return code
def replace(text,before,after,count=1):
    assert text.count(before)==count,{'expectedCount':count,'actualCount':text.count(before),'before':before}
    return text.replace(before,after)
try:
    save();prep=read(ops/'resolution-status.json');validation=read(ops/'validation/status.json')
    assert validation['phase']=='completed-with-failures' and validation['sourceStable']
    assert not Path('/proc/'+str(validation['pid'])).exists()
    assert next(x for x in validation['runs'] if x['name']=='workspace-types')['exit']==2
    assert sha(ops/'validation/workspace-types.log')=='7fc95875acc1418a4e66fb8d6a5cf298c517ec33c771957e5a210d3c7c64bfdc'
    assert git('rev-parse','HEAD')==prep['head'] and git('write-tree')==prep['tree']
    assert git('rev-parse','MERGE_HEAD')==prep['remote'] and not git('diff','--name-only')
    sources=prep['sourceSha256'];assert set(files).issubset(sources);assert all(sha(root/p)==h for p,h in sources.items())
    assert all(sha(root/p)==h for p,h in expected.items())
    before_dir=out/'before';before_dir.mkdir()
    for i,p in enumerate(files):(before_dir/str(i)).write_bytes((root/p).read_bytes())
    state.update(head=prep['head'],remote=prep['remote'],originalSourceTree=prep['tree'],before=expected,validationSha256=sha(ops/'validation/status.json'));save()

    p=root/files[0];text=p.read_text()
    text=replace(text,'    let replacement: (() => void) | null = null;','    const replacement: { current: (() => void) | null } = { current: null };')
    text=replace(text,'      replacement = connectWebMaterialPaintReservation(f.target, f.part, {});','      replacement.current = connectWebMaterialPaintReservation(f.target, f.part, {});')
    text=replace(text,'    replacement?.();','    replacement.current?.();')
    p.write_text(text)

    p=root/files[1];text=p.read_text()
    text=replace(text,"import { createAnatomyFamily, tw } from '@proto.ui/core';","import { createAnatomyFamily, tw, type AnatomyPartView } from '@proto.ui/core';\nimport type { AnatomyPort } from '@proto.ui/module-anatomy';")
    old="""  const self = {},
    physical = {},
    part = { role: 'target' };
  const anatomy = {
    resolveSelfInstance: () => self,
    resolveSelfRole: () => 'heading',
    parts: () => [part],
    isCurrentPart: () => true,
    resolveAncestorInstance: () => self,
    resolvePartTarget: () => physical,
    subscribeOrder: () => () => {},
    subscribeTargets: () => () => {},
  };"""
    text=replace(text,old,'  const anatomy = anatomyFixture();',2)
    helper="""// This fixture exposes only the operations exercised by reservation cleanup.
// Unexpected Anatomy use fails instead of silently fabricating a result.
function anatomyFixture(): AnatomyPort {
  const unused = (): never => {
    throw new Error('unexpected Anatomy operation in reservation cleanup fixture');
  };
  const self = {},
    physical = {};
  const part: AnatomyPartView = {
    role: 'target',
    hasExpose: unused,
    getExpose: unused,
    hasHook: unused,
  };
  return {
    resolveSelfInstance: () => self,
    resolveSelfRole: () => 'heading',
    parts: () => [part],
    isCurrentPart: () => true,
    resolveAncestorInstance: () => self,
    resolvePartTarget: () => physical,
    subscribeOrder: () => () => {},
    subscribeTargets: () => () => {},
    getDiagnostics: unused,
    syncStructure: unused,
    resolvePartInstance: unused,
    resolveDomainScope: unused,
    descendantsOf: unused,
    order: {
      version: unused,
      parts: unused,
      partsOf: unused,
      indexOfSelf: unused,
      prevOfSelf: unused,
      nextOfSelf: unused,
    },
    setOrderCallbackDispatcher: unused,
  };
}

"""
    text=replace(text,'// Real Feedback module and registry, injected Anatomy and host disconnects.',helper+'// Real Feedback module and registry, injected Anatomy and host disconnects.')
    text=replace(text,"      tryPort: (name: string) => (name === 'anatomy' ? anatomy : undefined),","      // ModuleDeps erases the named port type at this registration boundary.\n      tryPort: <T>(name: string) => (name === 'anatomy' ? anatomy : undefined) as T | undefined,",2)
    p.write_text(text)
    run(['corepack','pnpm@10.32.1','exec','prettier','--write',*files],'format-fixtures')
    assert set(git('diff','--name-only').splitlines())==set(files)
    assert all(sha(root/p)==h for p,h in sources.items() if p not in files)
    run(['git','add','--',*files],'stage-fixtures')
    patch=subprocess.check_output(['git','diff','--cached',prep['tree'],'--',*files],cwd=root,env=env)
    (out/'actual.patch').write_bytes(patch)
    after_sources={p:sha(root/p) for p in sources}
    state.update(phase='prepared',sourceTree=git('write-tree'),after={p:sha(root/p) for p in files},sourceSha256=after_sources,patchSha256=sha(out/'actual.patch'));save()
    run(['git','diff','--cached','--check'],'whitespace')
    code=run(['corepack','pnpm@10.32.1','exec','vitest','run',*files,'--maxWorkers=1','--no-file-parallelism','--reporter=json','--outputFile='+str(out/'fixtures.json')],'fixture-tests',300,(0,1))
    report=read(out/'fixtures.json')
    actual={str(Path(f['name']).relative_to(root)):f for f in report['testResults']}
    assert set(actual)==set(files) and len(report['testResults'])==2
    assert {p:len(f['assertionResults']) for p,f in actual.items()}=={files[0]:7,files[1]:4}
    state['fixtureResult']={k:report[k] for k in ('numTotalTests','numPassedTests','numFailedTests','numPendingTests')}
    state['fixtureResult']['reportSha256']=sha(out/'fixtures.json');save()
    if code==0:assert report['numTotalTests']==report['numPassedTests']==11 and report['numFailedTests']==report['numPendingTests']==0
    run(['node','--max-old-space-size=6144','node_modules/typescript/bin/tsc','-p','tsconfig.workspace.json','--noEmit'],'workspace-types',900,(0,1,2))
    assert git('rev-parse','HEAD')==prep['head'] and git('write-tree')==state['sourceTree'] and not git('diff','--name-only')
    assert all(sha(root/p)==h for p,h in after_sources.items())
    assert set(git('diff','--cached','--name-only',prep['tree']).splitlines())==set(files)
    state.update(phase='completed' if all(x['exit']==0 for x in state['runs']) else 'completed-with-failures',sourceStable=True)
except BaseException as exc:state.update(phase='pending-child' if 'pendingChild' in state else 'failed',error=repr(exc),traceback=traceback.format_exc())
save()
