from pathlib import Path
import os,json,hashlib,gzip,subprocess,time,fcntl,traceback

root=Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
base=Path(str(root)+'-ops/final-23122');ops=base/'union-ee2379';validation=ops/'validation'
status=ops/'archive-status.json';lock=open(ops/'archive.lock','a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not status.exists(),'Read existing archive status before another writer.'
env=dict(os.environ);env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env['PATH'];env['TMPDIR']='/var/tmp/s6-75d5-modal';env['GIT_OPTIONAL_LOCKS']='0'
name='2026-11-23-sprint6-concurrent-motion-union'
record=root/'internal/records'/(name+'.md');evidence=root/'internal/records/evidence'/name
state={'phase':'starting','pid':os.getpid(),'runs':[]}
def digest(raw):return hashlib.sha256(raw).hexdigest()
def sha(p):return digest(p.read_bytes())
def read(p):return json.loads(p.read_text())
def save():
    p=status.with_suffix('.tmp');p.write_text(json.dumps(state,indent=2)+'\n');os.replace(p,status)
def git(*args):return subprocess.check_output(['git','-c','core.fsmonitor=false','-c','submodule.recurse=false',*args],cwd=root,env=env,text=True,timeout=120).strip()
def run(args,name,seconds=240):
    state['phase']=name;save();log=ops/(name+'.log');started=time.monotonic()
    with log.open('w') as stream:
        p=subprocess.Popen(args,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);state['childPid']=p.pid;save()
        try:code=p.wait(timeout=seconds)
        except subprocess.TimeoutExpired:state['pendingChild']={'pid':p.pid,'name':name,'outerSeconds':seconds};save();raise
    state.pop('childPid',None);state['runs'].append({'name':name,'command':args,'exit':code,'seconds':round(time.monotonic()-started,3),'logSha256':sha(log)});save();assert code==0

try:
    save();prep=read(ops/'resolution-status.json');checks=read(validation/'status.json');repair=read(ops/'type-repair/status.json');old=read(base/'final-current/preparation-r3-status.json');checkpoint=read(base/'final-current/checkpoint-archive-status.json')
    assert prep['phase']=='prepared-not-committed'
    assert checks['phase'] in ('completed','completed-with-failures') and checks['sourceStable']
    assert not Path('/proc/'+str(checks['pid'])).exists()
    assert all(r['exit']==0 for r in checks['runs'] if r['name'] not in ('original-deadline-graph','original-deadline-schema','workspace-types'))
    assert next(r for r in checks['runs'] if r['name']=='workspace-types')['exit']==2
    assert repair['phase']=='completed' and repair['sourceStable'] and all(r['exit']==0 for r in repair['runs'])
    assert not Path('/proc/'+str(repair['pid'])).exists()
    assert repair['fixtureResult']['numTotalTests']==repair['fixtureResult']['numPassedTests']==11
    assert repair['fixtureResult']['numFailedTests']==repair['fixtureResult']['numPendingTests']==0
    assert set(repair['after'])=={'packages/adapters/base/test/material-paint-reservation.test.ts','packages/modules/feedback/test/material-reservation-cleanup.test.ts'}
    assert set(git('diff','--cached','--name-only',prep['tree']).splitlines())==set(repair['after'])
    assert checks['nodeControls']['counts']=={'tests':98,'pass':98,'fail':0,'cancelled':0,'skipped':0,'todo':0}
    source=checks['combined-source'];assert source['numPassedTests']==source['numTotalTests']==148 and source['numFailedTests']==source['numPendingTests']==0
    assert len(source['files'])==12 and checks['portalReentry'][0]['status']=='passed'
    assert git('rev-parse','HEAD')==prep['head'] and git('write-tree')==repair['sourceTree']
    assert not git('diff','--name-only')
    assert Path(git('rev-parse','--git-path','MERGE_HEAD')).read_text().splitlines()==[prep['remote']]
    assert all(sha(root/p)==h for p,h in repair['sourceSha256'].items())
    assert all(h==repair['sourceSha256'][p] for p,h in prep['sourceSha256'].items() if p not in repair['after'])
    assert all(sha(root/x['path'])==x['sha256'] for x in old['restored16'])
    assert sha(root/checkpoint['record'])==checkpoint['recordSha256'] and sha(root/checkpoint['manifest'])==checkpoint['manifestSha256']
    assert sha(ops/'root-review.md')=='ddd02d24e93431e374596ce7dbdcb0639a21d5349136ff596f730e31c55d5a57'
    assert sha(ops/'type-repair/root-review.md')=='f10a71b4cd02e3d52b180fda24c9c018831d4d0b7aa803d6d18e50a088c0f4dd'
    assert sha(ops/'incoming-inventory-review.json')=='7d11cae81372e0682b73a4e22615675ddd8305bd4124aa9260c0e0dc208e88f4'
    assert sha(ops/'incoming-ci/readback.json')=='095441d1904669892b80c531543bac8fdf84042e8a4307961e8e1a2a47f8beca'
    incoming=read(ops/'incoming-ci/readback.json');incoming_transfer=read(ops/'incoming-ci-transfer.json')
    assert incoming['head']==prep['remote'] and incoming['tree']=='5436844100fd03f66b8e64753a7ca0e88670085c'
    assert len(incoming_transfer['entries'])==14
    for item in incoming_transfer['entries']:
        p=ops/'incoming-ci'/item['file'];assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
    assert sha(ops/'source-relative-to-external.log')=='f193f7a2be110d44244f1f10159e6901cfe611cfe4e68342af17c72e09667692'
    assert not record.exists() and not evidence.exists();evidence.mkdir(parents=True)
    entries=[]
    def archive(p,rel):
        raw=p.read_bytes();stored=gzip.compress(raw,mtime=0);dest=evidence/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(stored)
        entries.append({'file':rel,'source':str(p),'rawBytes':len(raw),'rawSha256':digest(raw),'storedBytes':len(stored),'storedSha256':digest(stored),'encoding':'gzip'})
    for rel in ['merge-launch.json','merge-status.json','fetch-external.log','verify-motion-parent.log','verify-main-parent.log','incoming-stat.log','normal-merge-external.log','unmerged-diff.log','conflict-blocks.json','resolution-launch.json','resolution-status.json','resolution-format.log','resolution-stage.log','resolution-whitespace.log','source-relative-to-external.log','motion-inventory.json','root-review.md','incoming-inventory-review.json']:
        archive(ops/rel,'raw/'+rel+'.gz')
    for p in sorted((ops/'conflict-inputs').rglob('*')):
        if p.is_file():archive(p,'conflict-inputs/'+p.relative_to(ops/'conflict-inputs').as_posix()+'.gz')
    for p in sorted((ops/'resolved-inputs').rglob('*')):
        if p.is_file():archive(p,'resolved-inputs/'+p.relative_to(ops/'resolved-inputs').as_posix()+'.gz')
    for p in sorted(validation.iterdir()):
        if p.is_file() and (p.suffix in ('.json','.log','.mjs')):archive(p,'validation/'+p.name+'.gz')
    for item in incoming_transfer['entries']:
        archive(ops/'incoming-ci'/item['file'],'incoming-ci/'+item['file']+'.gz')
    for p in sorted((ops/'type-repair').rglob('*')):
        if p.is_file() and p.suffix!='.lock':archive(p,'type-repair/'+p.relative_to(ops/'type-repair').as_posix()+'.gz')
    for rel in ['checkpoint-publish-status.json','checkpoint-publish.log','checkpoint-publish-r2-status.json','checkpoint-publish-r2.log']:
        archive(base/'final-current'/rel,'checkpoint-publication/'+rel+'.gz')
    for script in ['union-ee.py','union-ee-resolve.py','union-ee-validate.py','union-ee-fixture-types.py','union-ee-archive.py','checkpoint-publish.py','checkpoint-publish-r2.py']:
        archive(base/script,'execution/'+script+'.gz')
    graph=checks['original-deadline-graph'];schema=checks['original-deadline-schema'];inv=prep['motionInventory']
    manifest={
        'schemaVersion':1,'scope':'Local exact-source integration evidence before final commit and original hosted Bootstrap/public acceptance.',
        'headBeforeCommit':prep['head'],'normalMergeHead':prep['remote'],'mainParent':checks['main'],'preparedSourceTree':repair['sourceTree'],'originalCombinedSourceTree':prep['tree'],
        'ownSourcePaths':prep['ownSourcePaths']+list(repair['after']),'sourceSha256':repair['sourceSha256'],'sourceBindings':len(repair['sourceSha256']),
        'sourcePatchSha256':sha(ops/'source-relative-to-external.log'),'motionInventory':inv,'localSourceResult':source,
        'nodeResult':checks['nodeControls'],'commands':checks['runs'],'graph':graph,'schema':schema,
        'fixtureTypeRepair':{'originalWorkspaceTypeExit':2,'originalWorkspaceTypeLogSha256':sha(validation/'workspace-types.log'),'changedFiles':repair['after'],'patchSha256':repair['patchSha256'],'peerReviewSha256':sha(ops/'type-repair/root-review.md'),'commands':repair['runs'],'fixtures':repair['fixtureResult'],'unchangedSourceBindings':len(prep['sourceSha256'])-2,'boundary':'Only two incoming material test fixtures changed after the original combined run. The 148 source cases and 98 protocol cases were not rerun or relabelled as a new combined execution.'},
        'incomingCI':{'scope':'Prior ee2379 runs only; not acceptance of the later union.','readbackSha256':sha(ops/'incoming-ci/readback.json'),'head':incoming['head'],'tree':incoming['tree'],'budget':{'run':incoming['budget']['run'],'passedEntries':4,'failedEntries':5},'cleanSource':{'run':incoming['cleanSource']['run'],'nativeExecuted':False},'representative':{'run':incoming['representative']['run'],'counts':incoming['representative']['counts']}},
        'nativeAcceptance':{'state':'pending-on-new-combination','originalWorkflow':'bootstrap-state-controls-evidence.yml','positiveCases':12,'splitRejectionCases':1,'priorSameInputAttempts':[{'sourceTree':old['tree'],'result':'5/6','failure':'Dialog cold acknowledgement 13.400062476158382ms >=12ms'},{'sourceTree':old['tree'],'result':'5/6','failure':'Dialog later visual-enter capture timeout1000ms, zero samples in the original opacity interval'}]},
        'checkpointPreserved':{'commit':prep['head'],'record':checkpoint['record'],'recordSha256':checkpoint['recordSha256'],'manifest':checkpoint['manifest'],'manifestSha256':checkpoint['manifestSha256'],'restored16':old['restored16']},
        'reviewBoundary':'Root reviewed the original ten source paths relative to ee2379. The two subsequent fixture files have a separate bounded review. Neither is a blanket review of all external material capability paths or GitHub APPROVED.',
        'artifacts':entries,
    }
    path=evidence/'manifest.json';path.write_text(json.dumps(manifest,indent=2)+'\n')
    rows='\n'.join('| `'+r['name']+'` | '+str(r['exit'])+' | '+str(r['seconds'])+' |' for r in checks['runs'])
    rows+='\n'+'\n'.join('| `fixture-repair/'+r['name']+'` | '+str(r['exit'])+' | '+str(r['seconds'])+' |' for r in repair['runs'])
    suite_rows='\n'.join('| `'+s['file']+'` | '+str(s['cases'])+' | '+('Hosted native pending' if s['file'].endswith('.browser.test.ts') else 'Passed in current source run')+' |' for s in inv['suites'])
    record.write_text(f'''# Sprint 6 concurrent motion union and strict inventory

This normal merge preserves the externally published branch and the bounded WC/Modal repair. It is a development continuation for PR #1712, which was already Ready. It neither merges the PR nor promotes draft definitions to stable acceptance.

## Exact source and preserved external work

- Local checkpoint parent: `{prep['head']}`.
- External normal merge parent: `{prep['remote']}`.
- Included main: `{checks['main']}`.
- Combined source tree for the initial validation: `{prep['tree']}`.
- Prepared source tree after the bounded fixture type repair: `{repair['sourceTree']}`.
- The manifest binds {len(repair['sourceSha256'])} actual source files, the original ten-file patch relative to the external parent, and the separate exact two-fixture repair.

The external `13213ba6bad6003c01488c659a2c3cfb428fb3fe` motion repair freezes requested properties only after admission and rechecks frame identity/generation after environment and clock callbacks. All seven new width cases are preserved. The later `ee2379da5a71c811268efb1b692e38d35c70c870` commit preserves its draft Anatomy-owned material reservation, four Web transports, source/layout/lifecycle checks, Chinese composition fonts and explicit pending native acceptance. Its 63 paths and historical receipts are retained through Git; this record does not relabel that author's historical executions as this Agent's tests or blanket acceptance of that capability.

Separate incoming-head CI observations remain independent: the ordinary CI run `45264556195` passed on ee2379. Strict package-budget run `45265557437` failed after 47/47 public builds and 28/28 controls passed: Core 12868/12800, Runtime 106768/104300, React 178328/172600, Vue 177109/171400 and Web Component 213818/207200 gzip bytes exceeded their unchanged caps; the other four entries passed. The clean exact-head report bound 7855 stable source files. Liquid comparison `45265516671` failed at its original three-minute Chinese-font setup step before native execution; downstream missing receipts are not product assertions. Representative Liquid-reservation run `45265290475` executed four cases and failed in all four hosts, with zero pending/todo cases: each terminal DOM reported nested `source-scope-unavailable` and `opaque-fallback` instead of the asserted `source-painted-ancestor`, while page/capture errors were empty. That observation alone does not decide whether product or fixture ownership is wrong. The independent readback, three original logs, step receipts, exact budget report, all four terminal receipts, Vitest result and source plan are archived with original hashes. Both source artifact ZIP digests were independently verified and remain recorded in the readback. Those are incoming-head results, not acceptance of this later combined source or reasons to weaken its checks. Their owning capability and final exact-head acceptance remain separate from this WC/Modal integration.

The normal merge produced only three conflicts: the Bootstrap workflow label and the motion checker/test inventories. Their exact stage inputs and conflict blocks are archived. The workflow equals the external parent's complete file with only its 136 label changed to 137, preserving the font-install step. The checker preserves the local Portal identity rule while taking both new width counts. The two current main ControlLabel criterion IDs remain unchanged. The sixteen protected historical originals and the earlier 94-artifact checkpoint remain byte-for-byte intact.

## Bounded repair retained

The WC helper disables the retiring event gate before invoking native detached-attribute reactions. A newer present intent on an existing retained view clears the marker even when marker-first close reenters before concealment starts. Fresh acquisition, request/owner guards and the false-branch gate checks remain unchanged. The real public-Props/synthetic MouseEvent fixture and exact lifecycle counts are preserved. Its previous old-helper counterfactual is attributed to source `8882ea51f4ce4ce99f37dbdc5df75d5975efa3fc`; this record does not invent a new counterfactual run after the external material changes.

Modal observation uses the same pure ownership predicates in browser and refusal controls. It requires connected authored hosts, same physical view/owner, retained projection and zero unmounts during concealment, then physical projection withdrawal and the acknowledged unmount. Every closed sample still independently asserts detached and concealed. The original 12ms timing tolerance, 1000ms observation watchdog, two trailing frames and all native actions remain unchanged.

## Strict inventory and actual source execution

The complete motion gate is 137 = 124 source assertions + 12 native positives + 1 explicit experimental split refusal. The positive fixture and required totals are 137; the false-total negative is 138. Missing/replaced/duplicate Portal identity refusals are retained. Passing the protocol tests is not native execution.

| Required file | Assertions | Current evidence |
| --- | --- | --- |
{suite_rows}

The combined run on `{prep['tree']}` executed all nine source files above plus complete first-render reentry (2), Dialog overlay (8) and CLI Text (14) files: **148/148**, zero failed or pending assertions, twelve exact files. The reentry title occurs exactly once and passed. The original three Node files executed **98/98**, with zero skipped, cancelled or todo cases. Frozen installation used the updated exact lockfile in this worktree. Only the two incoming material test fixtures described below changed afterward; all product code, those selected source files and the other 113 bound source files remained byte-for-byte unchanged. These earlier executions are reused within that unchanged scope, not relabelled as a second run.

## Official projections, types and spec evidence

Current-main authoring, prototype catalog, actual SpecGraph loader, official draft-family generation and check, CLI public-package build, website token generation and public type contracts passed on the initial frozen combination. No generated file was hand-edited; generated/check execution left tracked source unchanged.

The first workspace type check exited 2 with four diagnostics in two incoming material test fixtures. The nullable callback assignment was invisible to the local control-flow narrowing; its explicit nullable property cell preserves the same callback installation and optional cleanup. The cleanup fixture now implements the complete typed AnatomyPort and AnatomyPartView. Its eight used operations and fresh object identities remain unchanged; unexercised port/order/expose operations throw if unexpectedly called. The generic ModuleDeps lookup uses the existing named-port registration boundary, with no unknown/any cast of the port or part and no product interface weakening. Every original assertion remains intact. The two actual full fixture files then passed **11/11**, zero failed or pending, and the complete workspace type check exited 0 on `{repair['sourceTree']}`. Both original type failure and corrected execution are archived; the earlier 148/98 cases were not needlessly repeated.

The actual commands, flags, exits and raw output are archived, including the original workspace type failure followed by the separate correction.

| Actual command group | Exit | Seconds |
| --- | --- | --- |
{rows}

Original-deadline graph: {graph['numPassedTests']} passed / {graph['numFailedTests']} failed / {graph['numPendingTests']} pending. Original-deadline schema: {schema['numPassedTests']} passed / {schema['numFailedTests']} failed / {schema['numPendingTests']} pending. Those original 5000ms test deadlines were not widened. Any failed assertions remain failed in their raw report; a successful standalone loader is a separate observation.

## Native and publication boundary

This new combination has not been rerun in local Chrome. Its original strict hosted Bootstrap/public workflow remains the acceptance path. The earlier frozen 8882 checkpoint had two native runs, each 5/6. First, Dialog cold acknowledgement measured 13.400062476158382ms against the strict 12ms bound. The single controlled fresh recheck passed those timing/close assertions but later timed out in a separate Dialog visual-enter capture: its page-local trace had fifteen samples and zero samples in 0.55–0.85, including a 170.5ms callback gap. All three AlertDialog cases passed in that second run. The attempts are not combined into 6/6, and no third unchanged-input run was attempted.

The earlier checkpoint publication's first process exited before committing because the system `/tmp` had no free bytes. Actual HEAD/index readback proved no commit or source drift. A new receipt used the existing owned 0700 `/var/tmp/s6-75d5-modal`, kept normal hooks and created the signed-off checkpoint. Both original failure and successful recovery are archived; no global cache was cleared.

Root independently read the actual 840-line ten-path patch relative to ee2379 and recorded no bounded source blocker. Root then independently read the exact two-fixture patch together with the real AnatomyPort, Part, Order and ModuleDeps interfaces, again finding no blocker within that narrow scope. Both local reviews and the independent incoming 136→137 inventory analysis are preserved as original bytes. They are not GitHub APPROVED reviews or blanket acceptance of all 63 external material paths. The earlier entered-Dialog screenshot was visually inspected as an older 8882 entered-state image only; it does not prove the missing capture interval, final combined native behavior or physical/AT acceptance.

[The complete evidence manifest](evidence/{name}/manifest.json) binds all raw/stored hashes and source identities. The final commit/push and exact-head workflow results are recorded by their actual later Git/PR receipts. No source-derived record is silently rewritten after new CI evidence arrives.
''')
    run(['corepack','pnpm@10.32.1','exec','prettier','--write',str(record.relative_to(root)),str(path.relative_to(root))],'final-evidence-format')
    for e in entries:
        stored=(evidence/e['file']).read_bytes();raw=gzip.decompress(stored)
        assert digest(stored)==e['storedSha256'] and len(stored)==e['storedBytes']
        assert digest(raw)==e['rawSha256'] and len(raw)==e['rawBytes']
    assert all(sha(root/p)==h for p,h in repair['sourceSha256'].items())
    assert all(sha(root/x['path'])==x['sha256'] for x in old['restored16'])
    run(['git','add','--',str(record.relative_to(root)),str(evidence.relative_to(root))],'final-evidence-stage')
    changed=git('diff','--cached','--name-only',repair['sourceTree']).splitlines()
    assert all(p==str(record.relative_to(root)) or p.startswith(str(evidence.relative_to(root))+'/') for p in changed)
    assert not git('diff','--name-only')
    run(['git','diff','--cached','--check'],'final-evidence-whitespace')
    state.update(phase='prepared-not-committed',head=prep['head'],remote=prep['remote'],sourceTree=repair['sourceTree'],tree=git('write-tree'),record=str(record.relative_to(root)),recordSha256=sha(record),manifest=str(path.relative_to(root)),manifestSha256=sha(path),sourceStable=True,files=len(entries),rawBytes=sum(e['rawBytes'] for e in entries),storedBytes=sum(e['storedBytes'] for e in entries),evidenceOnlyAddedPaths=changed)
except BaseException as exc:state.update(phase='pending-child' if 'pendingChild' in state else 'failed',error=repr(exc),traceback=traceback.format_exc())
save()
