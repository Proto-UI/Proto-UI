from pathlib import Path
import os, json, subprocess, hashlib, time, fcntl, traceback

root = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
base = Path(str(root) + '-ops/final-23122')
ops = base / 'final-current'
status = ops / 'checkpoint-publish-r2-status.json'
lock = open(ops / 'checkpoint-publish-r2.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not status.exists(), 'Read the existing publisher and Git result; never repeat an unknown commit.'
env = dict(os.environ)
env['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:' + env['PATH']
env['GIT_OPTIONAL_LOCKS'] = '0'
env['TMPDIR'] = '/var/tmp/s6-75d5-modal'
state = {'phase': 'starting', 'pid': os.getpid(), 'scope': 'Normal signed-off local checkpoint only; no push, body update, dispatch or PR merge.'}

def save():
    tmp = status.with_suffix('.tmp')
    tmp.write_text(json.dumps(state, indent=2) + '\n')
    os.replace(tmp, status)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-c', 'core.fsmonitor=false', '-c', 'submodule.recurse=false', *args], cwd=root, env=env, text=True, timeout=120).strip()

try:
    save()
    prior = json.loads((ops / 'checkpoint-publish-status.json').read_text())
    assert prior['phase'] == 'failed' and prior['exit'] == 1 and prior['actualHead'] == '366a38112bd0ba994f2ef6a7743ffc981a051bfe'
    assert not Path('/proc/' + str(prior['pid'])).exists()
    assert (ops / 'checkpoint-publish.log').read_text().strip() == 'Error: ENOSPC: no space left on device, write'
    tmp = Path(env['TMPDIR'])
    assert tmp.is_dir() and tmp.stat().st_uid == os.getuid() and tmp.stat().st_mode & 0o777 == 0o700
    disk = os.statvfs(tmp)
    assert disk.f_bavail * disk.f_frsize > 1024 * 1024 * 1024
    state.update(priorFailedReceipt=str(ops / 'checkpoint-publish-status.json'), TMPDIR=str(tmp))
    archive = json.loads((ops / 'checkpoint-archive-status.json').read_text())
    prep = json.loads((ops / 'preparation-r3-status.json').read_text())
    assert archive['phase'] == 'prepared-not-committed' and archive['sourceStable']
    assert not Path('/proc/' + str(archive['pid'])).exists()
    assert archive['tree'] == '02353b36f80cb55f92f5443193e773704c62d9d1'
    assert git('rev-parse', 'HEAD') == archive['head'] == '366a38112bd0ba994f2ef6a7743ffc981a051bfe'
    assert git('write-tree') == archive['tree'] and not git('diff', '--name-only')
    assert git('branch', '--show-current') == 'work/sprint6-main-sync-75d5e28a-20261123'
    assert Path(git('rev-parse', '--git-path', 'MERGE_HEAD')).read_text().splitlines() == archive['mergeHeads']
    assert sha(root / archive['record']) == archive['recordSha256']
    assert sha(root / archive['manifest']) == archive['manifestSha256']
    assert all(sha(root / p) == h for p, h in prep['sourceSha256'].items())
    assert all(sha(root / r['path']) == r['sha256'] for r in prep['restored16'])
    message = ops / 'checkpoint-r2-message.txt'
    message.write_text('''fix(web-component): preserve retained view through marker reentry

Normally integrate the current external Sprint 6 and main parents while retaining
their lifetime, composition, historical byte-custody and dual ControlLabel IDs.
Project a newer present intent immediately when marker-first close synchronously
reenters on the same retained view, before concealment has begun. Preserve the
existing owner/generation checks, new acquisition path and disable-before-toggle.

Keep the unchanged public-Props regression: real old-helper press-count failure,
then 59/59 full DOM cases; current-main CLI 14/14 is separately retained. Actual
Node selection is 88+10=98/98 after recording the collector/inventory correction.
Authoring against main0fbb, catalog and real loader passed on the frozen source.

Archive both original current-source native runs as 5/6, not a combined pass.
The first Dialog cold acknowledgement failed 13.400062ms <12ms; the single fresh
recheck later missed the original visual-enter sampling window with no qualifying
page-local sample. Do not retry unchanged source or loosen timing. Final newer
external-source integration and strict hosted validation remain pending.

Refs #1712
''')
    command = ['node', 'scripts/agent-operations/agent-publish.mjs', 'commit', '--mode', 'human-assisted', '--mode-source', 'current-user', '--authorization', 'explicit-current-user', '--repository', 'github.com:Proto-UI/Proto-UI', '--message-file', str(message), '--branch', 'work/sprint6-main-sync-75d5e28a-20261123', '--expected-head', archive['head'], '--expected-tree', archive['tree']]
    log = ops / 'checkpoint-publish-r2.log'
    started = time.monotonic()
    state.update(phase='normal-commit-running', expectedHead=archive['head'], expectedTree=archive['tree'], expectedParents=[archive['head'], *archive['mergeHeads']], command=command)
    save()
    with log.open('w') as stream:
        proc = subprocess.Popen(command, cwd=root, env=env, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        state['childPid'] = proc.pid
        save()
        try:
            code = proc.wait(timeout=900)
        except subprocess.TimeoutExpired:
            state.update(phase='pending-child', pendingChild={'pid': proc.pid, 'outerSeconds': 900}, seconds=round(time.monotonic()-started,3))
            save()
            raise
    state.pop('childPid', None)
    state.update(exit=code, seconds=round(time.monotonic()-started,3), logSha256=sha(log))
    head = git('rev-parse', 'HEAD')
    state.update(actualHead=head, actualTree=git('show', '-s', '--format=%T', head), actualParents=git('show', '-s', '--format=%P', head).split(), commitMessage=git('show', '-s', '--format=%B', head), trackedStatus=git('status', '--porcelain', '--untracked-files=no'), untracked=git('ls-files', '--others', '--exclude-standard'))
    save()
    assert code == 0, 'Publisher exited nonzero; reconcile actual commit before any future writer.'
    assert head != archive['head'] and state['actualTree'] == archive['tree']
    assert state['actualParents'] == state['expectedParents']
    assert '\nSigned-off-by: ' in '\n' + state['commitMessage']
    assert not state['trackedStatus'] and not state['untracked']
    assert all(sha(root / p) == h for p, h in prep['sourceSha256'].items())
    assert all(sha(root / r['path']) == r['sha256'] for r in prep['restored16'])
    assert sha(root / archive['record']) == archive['recordSha256'] and sha(root / archive['manifest']) == archive['manifestSha256']
    state.update(phase='committed-local-only', sourceStable=True)
except BaseException as exc:
    state.update(phase='pending-child' if 'pendingChild' in state else 'failed', error=repr(exc), traceback=traceback.format_exc())
save()
