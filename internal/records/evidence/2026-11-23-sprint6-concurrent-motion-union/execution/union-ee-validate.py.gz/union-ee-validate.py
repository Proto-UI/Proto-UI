from pathlib import Path
import os, json, hashlib, subprocess, re, time, fcntl, traceback

root=Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
ops=Path(str(root)+'-ops/final-23122/union-ee2379')
out=ops/'validation'; out.mkdir(exist_ok=True)
status=out/'status.json'; lock=open(out/'validation.lock','a')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not status.exists(),'Reconcile the existing finite validation worker first.'
env=dict(os.environ)
env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env['PATH']
env['TMPDIR']='/var/tmp/s6-75d5-modal'; env['GIT_OPTIONAL_LOCKS']='0'; env['LC_ALL']='C'
state={'phase':'starting','pid':os.getpid(),'runs':[],'scope':'Exact prepared merge source; local source, protocols, official generators/types/spec. No native browser execution in this worker.'}

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save():
    t=status.with_suffix('.tmp');t.write_text(json.dumps(state,indent=2)+'\n');os.replace(t,status)
def git(*args): return subprocess.check_output(['git','-c','core.fsmonitor=false','-c','submodule.recurse=false',*args],cwd=root,env=env,text=True,timeout=120).strip()
def run(args,name,seconds=300,allowed=(0,)):
    state['phase']=name;save();log=out/(name+'.log');start=time.monotonic()
    with log.open('w') as stream:
        p=subprocess.Popen(args,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        state['childPid']=p.pid;save()
        try: code=p.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            state['pendingChild']={'pid':p.pid,'name':name,'outerSeconds':seconds};save();raise
    state.pop('childPid',None)
    state['runs'].append({'name':name,'command':args,'exit':code,'seconds':round(time.monotonic()-start,3),'logSha256':sha(log)});save()
    assert code in allowed,{'name':name,'exit':code}
    return code
def frozen():
    assert git('rev-parse','HEAD')==prep['head']
    assert git('write-tree')==prep['tree']
    assert not git('diff','--name-only')
    assert all(sha(root/p)==h for p,h in sources.items())
def vitest(files,name,expected=None):
    assert len(files)==len(set(files)) and all((root/p).is_file() for p in files)
    code=run(['corepack','pnpm@10.32.1','exec','vitest','run',*files,'--maxWorkers=1','--no-file-parallelism','--reporter=json','--outputFile='+str(out/(name+'.json'))],name,600,(0,1))
    p=out/(name+'.json');report=json.loads(p.read_text())
    actual={str(Path(f['name']).relative_to(root)):f for f in report['testResults']}
    result={k:report[k] for k in ['numPassedTests','numFailedTests','numPendingTests','numTotalTests']}
    result.update(reportSha256=sha(p),files=[{'file':k,'assertions':len(v['assertionResults']),'passed':sum(a['status']=='passed' for a in v['assertionResults']),'failed':sum(a['status']=='failed' for a in v['assertionResults']),'pending':sum(a['status'] not in ('passed','failed') for a in v['assertionResults'])} for k,v in actual.items()],failures=[{'file':k,'title':a['fullName'],'messages':a['failureMessages']} for k,v in actual.items() for a in v['assertionResults'] if a['status']=='failed'])
    state[name]=result;save()
    assert len(actual)==len(report['testResults']) and set(actual)==set(files),'Actual selected file inventory differs from the plan.'
    if expected:
        assert {k:len(v['assertionResults']) for k,v in actual.items()}==expected
        assert report['numTotalTests']==sum(expected.values())
    if code==0:
        assert report['numFailedTests']==report['numPendingTests']==0
        assert all(a['status']=='passed' for v in actual.values() for a in v['assertionResults'])
    frozen()
    return report

try:
    save();prep=json.loads((ops/'resolution-status.json').read_text())
    assert prep['phase']=='prepared-not-committed' and prep['tree']=='b5347d12a49ec914cfa2193dd7a0dd4d6be48240'
    assert not Path('/proc/'+str(prep['pid'])).exists()
    sources=prep['sourceSha256'];frozen()
    assert Path(git('rev-parse','--git-path','MERGE_HEAD')).read_text().splitlines()==[prep['remote']]
    state.update(head=prep['head'],remote=prep['remote'],main='0fbb52ef832cc27c78e24c28c59a55a16f51d7fe',preparedTree=prep['tree'],sourceBefore=sources)
    run(['node','--version'],'node-version',30)
    run(['corepack','pnpm@10.32.1','install','--frozen-lockfile'],'frozen-install',600)
    frozen()
    node_files=['scripts/test/bootstrap-state-controls-evidence.test.mjs','scripts/test/check-bootstrap-motion-evidence.test.mjs','scripts/test/run-bootstrap-public-validation.test.mjs']
    node_code=run(['node','--test','--test-reporter=tap',*node_files],'strict-node-controls',300,(0,1))
    raw=(out/'strict-node-controls.log').read_text()
    counts={k:int(re.findall(r'^# '+k+r' (\d+)$',raw,re.M)[-1]) for k in ['tests','pass','fail','cancelled','skipped','todo']}
    names=re.findall(r'^# Subtest: (.*)$',raw,re.M)
    state['nodeControls']={'counts':counts,'identities':names,'sourceSha256':{p:sha(root/p) for p in node_files}}
    save();assert counts['tests']==len(names)==len(set(names))==98
    critical=['requires eleven exact files and 137 executed cases while separating positive and rejected profiles','rejects green extra case replacing the Portal reentry','rejects duplicate Portal reentry with distinct generic identities','Modal observation waits for physical withdrawal and acknowledged unmount','Modal observation rejects replaced lifetimes and missing conceal ownership']
    assert all(name in names for name in critical)
    if node_code==0: assert counts=={'tests':98,'pass':98,'fail':0,'cancelled':0,'skipped':0,'todo':0}
    frozen()
    inventory=prep['motionInventory']
    expected={x['file']:x['cases'] for x in inventory['suites'] if not x['file'].endswith('.browser.test.ts')}
    assert len(expected)==9 and sum(expected.values())==124
    expected.update({'packages/adapters/web-component/test/portal-first-render-reentry.test.ts':2,'packages/adapters/web-component/test/dialog-overlay.test.ts':8,'packages/cli/test/text-prototype.test.ts':14})
    source_report=vitest(list(expected),'combined-source',expected)
    portal=next(f for f in source_report['testResults'] if f['name'].endswith('packages/adapters/web-component/test/portal-conceal.test.ts'))
    title='retains the reopened event gate after native detached attribute reentry'
    state['portalReentry']=[a for a in portal['assertionResults'] if a['title']==title]
    assert len(state['portalReentry'])==1
    save()
    run(['corepack','pnpm@10.32.1','check:spec-authoring','--','--base',state['main']],'current-base-authoring',300,(0,1))
    run(['corepack','pnpm@10.32.1','check:prototype-catalog'],'current-catalog',300,(0,1))
    loader=out/'current-spec-loader.mjs'
    loader.write_text("import assert from 'node:assert/strict';\nimport {writeFileSync} from 'node:fs';\nimport {loadSpecWorkspaceFromDirectory} from '"+str(root/'packages/spec/engine/src/node.ts')+"';\nconst start=performance.now();\nconst w=await loadSpecWorkspaceFromDirectory("+json.dumps(str(root/'spec'))+");\nconst result={entityCount:w.entities.length,issues:w.issues,elapsedMs:performance.now()-start};\nwriteFileSync("+json.dumps(str(out/'current-spec-loader.json'))+",JSON.stringify(result,null,2)+'\\n');\nconsole.log(JSON.stringify(result));assert.deepEqual(result.issues,[]);\n")
    run(['node','--import','tsx',str(loader)],'current-spec-loader',300,(0,1))
    frozen()
    run(['node','--import','tsx','scripts/styles/generate-draft-family-style-tokens.ts'],'draft-family-generator',600)
    run(['node','--import','tsx','scripts/styles/generate-draft-family-style-tokens.ts','--check'],'draft-family-generator-check',600)
    frozen()
    run(['node','scripts/build/public-packages.mjs','--package','@proto.ui/cli'],'official-cli-build',600)
    run(['node','apps/www/scripts/generate-website-prototype-tokens.mjs'],'official-website-token-generator',600)
    frozen()
    run(['node','--max-old-space-size=6144','node_modules/typescript/bin/tsc','-p','internal/contracts/types/tsconfig.json'],'public-type-contracts',600,(0,1,2))
    run(['node','--max-old-space-size=6144','node_modules/typescript/bin/tsc','-p','tsconfig.workspace.json','--noEmit'],'workspace-types',900,(0,1,2))
    frozen()
    vitest(['packages/spec/graph/test/shadcn-dropdown-evidence.test.ts'],'original-deadline-graph')
    vitest(['packages/spec/fixtures/test/prototype-inheritance-schema.test.ts','packages/spec/fixtures/test/adapter-profile-schema.test.ts','packages/spec/fixtures/test/feedback-style-authoring.test.ts','packages/spec/fixtures/test/feedback-style-runtime-patch.test.ts'],'original-deadline-schema')
    frozen()
    state.update(phase='completed' if all(r['exit']==0 for r in state['runs']) else 'completed-with-failures',sourceStable=True)
except BaseException as e:
    state.update(phase='pending-child' if 'pendingChild' in state else 'failed',error=repr(e),traceback=traceback.format_exc())
save()
