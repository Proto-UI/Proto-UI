from pathlib import Path
import os, json, hashlib, subprocess, time, fcntl, traceback

root = Path('/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123')
base = Path(str(root) + '-ops/final-23122')
prior = base / 'final-current'
ops = base / 'union-ee2379'
ops.mkdir(exist_ok=True)
status = ops / 'merge-status.json'
lock = open(ops / 'merge.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not status.exists(), 'Reconcile existing merge status before any new writer.'
env = dict(os.environ)
env['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:' + env['PATH']
env['GIT_OPTIONAL_LOCKS'] = '0'
env['TMPDIR'] = '/var/tmp/s6-75d5-modal'
remote = 'ee2379da5a71c811268efb1b692e38d35c70c870'
main = '0fbb52ef832cc27c78e24c28c59a55a16f51d7fe'
branch = 'sprint6/bootstrap-liquid-delivery-20261122'
state = {'phase': 'starting', 'pid': os.getpid(), 'remote': remote, 'main': main, 'runs': [], 'purpose': 'Preserve external motion and draft reservation commits through a normal local merge; no push or PR merge.'}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save():
    tmp = status.with_suffix('.tmp')
    tmp.write_text(json.dumps(state, indent=2) + '\n')
    os.replace(tmp, status)

def git(*args):
    return subprocess.check_output(['git', '-c', 'core.fsmonitor=false', '-c', 'submodule.recurse=false', *args], cwd=root, env=env, text=True, timeout=120).strip()

def run(args, label, allowed=(0,), seconds=300):
    state['phase'] = label
    save()
    log = ops / (label + '.log')
    started = time.monotonic()
    with log.open('w') as stream:
        p = subprocess.Popen(args, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True)
        state['childPid'] = p.pid
        save()
        try:
            code = p.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            state['pendingChild'] = {'pid': p.pid, 'label': label, 'outerSeconds': seconds}
            save()
            raise
    state.pop('childPid', None)
    row = {'label': label, 'command': args, 'exit': code, 'seconds': round(time.monotonic()-started,3), 'logSha256': sha(log)}
    state['runs'].append(row)
    save()
    assert code in allowed, row
    return code

def api(path, label):
    p = subprocess.run(['gh', 'api', path], cwd=root, env=env, capture_output=True, text=True, timeout=90)
    (ops / (label + '.stderr')).write_text(p.stderr)
    assert p.returncode == 0, {'path': path, 'exit': p.returncode}
    j = json.loads(p.stdout)
    (ops / (label + '.json')).write_text(json.dumps(j, indent=2) + '\n')
    return j

try:
    save()
    commit = json.loads((prior / 'checkpoint-publish-r2-status.json').read_text())
    archive = json.loads((prior / 'checkpoint-archive-status.json').read_text())
    prep = json.loads((prior / 'preparation-r3-status.json').read_text())
    assert commit['phase'] == 'committed-local-only' and commit['sourceStable']
    assert not Path('/proc/' + str(commit['pid'])).exists()
    assert git('rev-parse', 'HEAD') == commit['actualHead']
    assert git('write-tree') == commit['actualTree'] == archive['tree']
    assert not git('status', '--porcelain', '--untracked-files=all')
    assert not Path(git('rev-parse', '--git-path', 'MERGE_HEAD')).exists()
    assert all(sha(root / r['path']) == r['sha256'] for r in prep['restored16'])
    assert sha(root / archive['record']) == archive['recordSha256']
    assert sha(root / archive['manifest']) == archive['manifestSha256']
    live = api('repos/Proto-UI/Proto-UI/pulls/1712', 'pr-before-merge')
    assert live['state'] == 'open' and not live['merged'] and live['head']['ref'] == branch
    assert live['head']['sha'] == remote and live['base']['sha'] == main, 'Fresh remote changed: inspect the additional commits before continuing.'
    state.update(headBeforeMerge=commit['actualHead'], checkpointTree=commit['actualTree'])
    run(['git', 'fetch', '--no-tags', 'origin', 'refs/heads/' + branch + ':refs/remotes/s6-ee-75d5/head', 'refs/heads/main:refs/remotes/s6-ee-75d5/main'], 'fetch-external', seconds=300)
    assert git('rev-parse', 'refs/remotes/s6-ee-75d5/head') == remote
    assert git('rev-parse', 'refs/remotes/s6-ee-75d5/main') == main
    run(['git', 'merge-base', '--is-ancestor', '13213ba6bad6003c01488c659a2c3cfb428fb3fe', remote], 'verify-motion-parent')
    run(['git', 'merge-base', '--is-ancestor', main, remote], 'verify-main-parent')
    run(['git', 'diff', '--stat', '84ef7893e732a316388aeb730af1758b96f703e8', remote], 'incoming-stat')
    code = run(['git', 'merge', '--no-ff', '--no-commit', remote], 'normal-merge-external', allowed=(0,1), seconds=600)
    conflicts = git('diff', '--name-only', '--diff-filter=U').splitlines()
    assert code == 0 or conflicts, 'Merge failed without a declared conflict; inspect the real log.'
    run(['git', 'diff', '--cc'], 'unmerged-diff')
    stage_dir = ops / 'conflict-inputs'
    for path in conflicts:
        for stage in (1,2,3):
            p = subprocess.run(['git', 'show', ':' + str(stage) + ':' + path], cwd=root, env=env, capture_output=True, timeout=120)
            if p.returncode == 0:
                out = stage_dir / str(stage) / path
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_bytes(p.stdout)
    state.update(phase='merged-awaiting-resolution' if conflicts else 'merged-awaiting-validation', mergeExit=code, conflicts=conflicts, actualHead=git('rev-parse','HEAD'), mergeHeads=Path(git('rev-parse','--git-path','MERGE_HEAD')).read_text().splitlines(), protectedHistoryStable=all(sha(root / r['path']) == r['sha256'] for r in prep['restored16']), checkpointRecordStable=sha(root / archive['record']) == archive['recordSha256'] and sha(root / archive['manifest']) == archive['manifestSha256'])
    if not conflicts:
        state['preparedTree'] = git('write-tree')
except BaseException as exc:
    state.update(phase='pending-child' if 'pendingChild' in state else 'failed', error=repr(exc), traceback=traceback.format_exc())
save()
