import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {loadSpecWorkspaceFromDirectory} from '/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123/packages/spec/engine/src/node.ts';
const start=performance.now();
const w=await loadSpecWorkspaceFromDirectory("/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123/spec");
const result={entityCount:w.entities.length,issues:w.issues,elapsedMs:performance.now()-start};
writeFileSync("/tank/shared/projects/proto-ui-agent/sprint6-main-sync-75d5e28a-20261123-ops/final-23122/union-ee2379/validation/current-spec-loader.json",JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result));assert.deepEqual(result.issues,[]);
