import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export function assertQtNativeReports({
  vitest,
  version,
  configure,
  build,
  consumer,
  drift,
  source,
}) {
  assert.equal(vitest.success, true);
  assert.equal(vitest.numTotalTests, 1);
  assert.equal(vitest.numPassedTests, 1);
  assert.equal(vitest.numFailedTests, 0);
  assert.equal(vitest.numPendingTests, 0);
  assert.equal(vitest.testResults.length, 1);
  const suite = vitest.testResults[0];
  assert.ok(suite.name.endsWith('/packages/compiler/test/qt-native-consumer.native.test.ts'));
  assert.equal(suite.status, 'passed');
  assert.deepEqual(
    suite.assertionResults.map((entry) => entry.status),
    ['passed']
  );
  for (const result of [version, configure, build, consumer]) {
    assert.equal(result.status, 0);
    assert.equal(result.signal, null);
    assert.equal(result.error, undefined);
  }
  assert.equal(version.stdout.trim(), '6.4.2');
  assert.deepEqual(version.command.slice(1), ['-query', 'QT_VERSION']);
  assert.ok(configure.command.includes('-DCMAKE_BUILD_TYPE=Release'));
  assert.deepEqual(build.command.slice(1), ['--build', 'build', '--parallel', '2']);
  assert.equal(path.basename(consumer.command[0]), 'compiled-qt');
  assert.equal(path.basename(consumer.command[1]), 'Consumer.qml');
  const lines = `${consumer.stdout}\n${consumer.stderr}`
    .split('\n')
    .filter((line) => line.includes('PUI_QT_RESULT '));
  assert.equal(lines.length, 1);
  const actual = JSON.parse(lines[0].split('PUI_QT_RESULT ')[1]);
  assert.equal(source.expectedCases.length, 8);
  assert.equal(new Set(source.expectedCases).size, 8);
  assert.equal(actual.passed, 8);
  assert.equal(actual.failed, 0);
  assert.deepEqual(
    actual.cases,
    source.expectedCases.map((name) => ({ name, status: 'passed' }))
  );
  assert.deepEqual(drift, []);
  return { wrapperPassed: 1, wrapperSkipped: 0, nativePassed: 8, nativeFailed: 0 };
}

export function verifyQtNativeEvidence(directory, expectedSource) {
  const root = path.resolve(directory);
  const children = readdirSync(root, { withFileTypes: true }).filter(
    (entry) => entry.isDirectory() && entry.name.startsWith('proto-qt-native-')
  );
  assert.equal(children.length, 1);
  const child = path.join(root, children[0].name);
  const files = {
    vitest: path.join(root, 'vitest.json'),
    version: path.join(child, 'qt-version.json'),
    configure: path.join(child, 'configure.json'),
    build: path.join(child, 'build.json'),
    consumer: path.join(child, 'consumer.json'),
    drift: path.join(child, 'generated-drift.json'),
    source: path.join(child, 'source-receipt.json'),
  };
  const raw = Object.fromEntries(
    Object.entries(files).map(([key, file]) => [key, readFileSync(file)])
  );
  const reports = Object.fromEntries(
    Object.entries(raw).map(([key, value]) => [key, JSON.parse(value)])
  );
  const source = readFileSync(path.join(root, 'source-sha.txt'), 'utf8').trim();
  assert.match(source, /^[a-f0-9]{40}$/);
  assert.equal(source, expectedSource);
  assert.equal(reports.source.head, source);
  const sha = (data) => createHash('sha256').update(data).digest('hex');
  for (const input of reports.source.inputs)
    assert.equal(input.sha256, sha(readFileSync(path.resolve(input.file))), input.file);
  for (const artifact of reports.source.files)
    assert.equal(
      artifact.sha256,
      sha(readFileSync(path.join(child, artifact.file))),
      artifact.file
    );
  assert.equal(
    sha(readFileSync(path.join(child, 'Consumer.qml'))),
    sha(
      readFileSync(
        new URL(
          '../../packages/compiler/test/fixtures/qt-native-consumer/Consumer.qml',
          import.meta.url
        )
      )
    )
  );
  const receipt = {
    source,
    ...assertQtNativeReports(reports),
    qt: '6.4.2',
    mode: 'Actual Qt Quick offscreen/software; no physical GPU, hardware input or AT acceptance',
    publicQtProfileActivated: false,
    files: Object.fromEntries(
      Object.entries(raw).map(([key, value]) => [
        key,
        { path: path.relative(root, files[key]), sha256: sha(value) },
      ])
    ),
  };
  writeFileSync(path.join(root, 'acceptance.json'), JSON.stringify(receipt, null, 2) + '\n', {
    flag: 'wx',
  });
  return receipt;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  assert.equal(process.argv.length, 3, 'usage: check-qt-native-evidence <directory>');
  console.log(JSON.stringify(verifyQtNativeEvidence(process.argv[2], process.env.GITHUB_SHA)));
}
