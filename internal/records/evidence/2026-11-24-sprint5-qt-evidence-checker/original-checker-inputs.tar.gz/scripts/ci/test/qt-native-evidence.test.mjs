import assert from 'node:assert/strict';
import test from 'node:test';
import { assertQtNativeReports } from '../check-qt-native-evidence.mjs';

test('Qt evidence requires one executed wrapper and every native consumer result', () => {
  const cases = Array.from({ length: 8 }, (_, index) => `independent case ${index}`);
  const success = (command, stdout = '') => ({
    command,
    stdout,
    stderr: '',
    status: 0,
    signal: null,
  });
  const reports = {
    vitest: {
      success: true,
      numTotalTests: 1,
      numPassedTests: 1,
      numFailedTests: 0,
      numPendingTests: 0,
      testResults: [
        {
          name: '/checkout/packages/compiler/test/qt-native-consumer.native.test.ts',
          status: 'passed',
          assertionResults: [{ status: 'passed' }],
        },
      ],
    },
    version: success(['/pinned/bin/qmake', '-query', 'QT_VERSION'], '6.4.2\n'),
    configure: success(['cmake', '-DCMAKE_BUILD_TYPE=Release']),
    build: success(['cmake', '--build', 'build', '--parallel', '2']),
    consumer: success(
      ['/generated/build/compiled-qt', '/generated/Consumer.qml'],
      'qml: PUI_QT_RESULT ' +
        JSON.stringify({
          passed: 8,
          failed: 0,
          cases: cases.map((name) => ({ name, status: 'passed' })),
        })
    ),
    source: { expectedCases: cases },
    drift: [],
  };
  assert.deepEqual(assertQtNativeReports(reports), {
    wrapperPassed: 1,
    wrapperSkipped: 0,
    nativePassed: 8,
    nativeFailed: 0,
  });
  for (const mutate of [
    (copy) => {
      copy.vitest.numPassedTests = 0;
      copy.vitest.numPendingTests = 1;
    },
    (copy) => {
      copy.consumer.status = 1;
    },
    (copy) => {
      copy.consumer.stdout = '';
    },
    (copy) => {
      copy.consumer.stdout = copy.consumer.stdout.replace('"passed":8', '"passed":7');
    },
    (copy) => {
      copy.consumer.stdout = copy.consumer.stdout.replace('independent case 3', 'unexpected case');
    },
    (copy) => {
      copy.source.expectedCases[0] = copy.source.expectedCases[1];
    },
    (copy) => {
      copy.version.stdout = '6.5.0';
    },
    (copy) => {
      copy.build.signal = 'SIGKILL';
    },
    (copy) => {
      copy.drift.push({ file: 'generated.qml' });
    },
  ]) {
    const copy = structuredClone(reports);
    mutate(copy);
    assert.throws(() => assertQtNativeReports(copy));
  }
});
