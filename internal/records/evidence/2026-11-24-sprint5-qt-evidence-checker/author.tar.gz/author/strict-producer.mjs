import ts from 'typescript';
const cfg=ts.readConfigFile('tsconfig.json',ts.sys.readFile);
if(cfg.error)throw Error(ts.flattenDiagnosticMessageText(cfg.error.messageText,'\n'));
const parsed=ts.parseJsonConfigFileContent(cfg.config,ts.sys,process.cwd());
const program=ts.createProgram(['packages/compiler/test/fixtures/qt-native-consumer/prepare.ts','packages/compiler/test/qt-native-consumer.native.test.ts'],{...parsed.options,noEmit:true,incremental:false,composite:false,types:['node']});
const diagnostics=ts.getPreEmitDiagnostics(program);
console.log(JSON.stringify({sourceFiles:program.getSourceFiles().length,diagnostics:diagnostics.length,options:program.getCompilerOptions()},null,2));
for(const diagnostic of diagnostics)console.log(ts.formatDiagnostic(diagnostic,{getCurrentDirectory:()=>process.cwd(),getNewLine:()=> '\n',getCanonicalFileName:file=>file}));
process.exitCode=diagnostics.length?1:0;
