// Editable ordinary Qt Quick 6.4.2 source. No Proto Runtime/Core/Adapter dependency.
// Authored templates are cached and reconciled only at explicit update or view epoch entry.
// Helper cost: owned Props/State/Context resources, Qt native facts/style repaint, QML node reconciliation.
// Public Props are a full presence-preserving rawProps map; mutation requires a replacement snapshot.
import QtQuick 6.4
import QtQuick.Window 6.4
import QtQml 6.4 as Qml
import PuiQtNative 1.0
import "./.proto-ui/qt/QtOwner.mjs" as PuiQtNative

import "./.proto-ui/qt/context/QtContextScope.mjs" as PuiQtContext
import "./.proto-ui/qt" as PuiQtView



FocusScope {
    id: puiQtHost
    objectName: "Component"
    property var rawProps: ({})
    property Item logicalParent: null
    readonly property Window nativeWindow: puiQtHost.Window.window
    default property alias slotContent: puiQtParking.data
    readonly property var logicalOwner: !puiQtClosed && puiQtOwner ? puiQtOwner.identity : null
    readonly property var exposes: !puiQtClosed && puiQtOwner ? puiQtOwner.exposes : ({})
    readonly property bool disposed: puiQtClosed
    readonly property int viewEpoch: puiQtEpoch
    readonly property bool present: puiQtPresent
    readonly property Item nativeRoot: puiQtRoot
    property var puiQtOwner: null
    property bool puiQtClosed: false
    property bool puiQtReady: false
    property int puiQtRevision: 0
    property int puiQtEpoch: 0
    property bool puiQtPresent: false
    property Item puiQtRoot: null
    implicitWidth: puiQtRoot ? puiQtRoot.implicitWidth : 0
    implicitHeight: puiQtRoot ? puiQtRoot.implicitHeight : 0
    function exposedMethod0(): var {
        if (!puiQtOwner) throw new Error('Qt component is not ready')
        return puiQtOwner.getExposes()["snapshot"]()
    }
    function exposedMethod1(): var {
        if (!puiQtOwner) throw new Error('Qt component is not ready')
        return puiQtOwner.getExposes()["horizontal"]()
    }
    function exposedMethod2(): var {
        if (!puiQtOwner) throw new Error('Qt component is not ready')
        return puiQtOwner.getExposes()["vertical"]()
    }
    function exposedMethod3(): var {
        if (!puiQtOwner) throw new Error('Qt component is not ready')
        return puiQtOwner.getExposes()["both"]()
    }
    function exposedMethod4(): var {
        if (!puiQtOwner) throw new Error('Qt component is not ready')
        return puiQtOwner.getExposes()["same"]()
    }
    function exposedMethod5(): var {
        if (!puiQtOwner) throw new Error('Qt component is not ready')
        return puiQtOwner.getExposes()["extra"]()
    }
    function exposedMethod6(): var {
        if (!puiQtOwner) throw new Error('Qt component is not ready')
        return puiQtOwner.getExposes()["middle"]()
    }
    function exposedMethod7(): var {
        if (!puiQtOwner) throw new Error('Qt component is not ready')
        return puiQtOwner.getExposes()["relative"]()
    }
    function exposedMethod8(): var {
        if (!puiQtOwner) throw new Error('Qt component is not ready')
        return puiQtOwner.getExposes()["pageBefore"]()
    }
    function exposedMethod9(): var {
        if (!puiQtOwner) throw new Error('Qt component is not ready')
        return puiQtOwner.getExposes()["quarter"]()
    }
    function exposedMethod10(): var {
        if (!puiQtOwner) throw new Error('Qt component is not ready')
        return puiQtOwner.getExposes()["end"]()
    }
    function exposedMethod11(): var {
        if (!puiQtOwner) throw new Error('Qt component is not ready')
        return puiQtOwner.getExposes()["pause"]()
    }
    signal exposed(string key, var payload)
    signal nativeHostEvent(string type, var event)
    onNativeHostEvent: (type, event) => { if (puiQtOwner && !puiQtClosed) puiQtOwner.nativeEvent(type, event) }
    property Item puiQtParking: Item { id: puiQtParking; readonly property Item logicalParent: puiQtHost; parent: puiQtHost; visible: parent !== puiQtHost; width: childrenRect.width; height: childrenRect.height; implicitWidth: childrenRect.width; implicitHeight: childrenRect.height }
    property Item puiQtContent: Item { parent: puiQtHost; anchors.fill: parent }
    property Qml.Component puiQtNodeComponent: Qml.Component { PuiQtView.QtNode {} }
    property NativeInputObserver puiQtInputObserver: NativeInputObserver {
        root: null
        onObserved: (name, event) => { if (puiQtOwner && !puiQtClosed) puiQtOwner.globalNativeEvent(name, event) }
    }
    function ensureOwner() {
        if (puiQtClosed) throw new Error('Qt component is terminally disposed')
        if (puiQtOwner) return puiQtOwner
        puiQtOwner = PuiQtNative.createOwner(puiQtHost, {
            parking: puiQtParking, slot: puiQtParking, content: puiQtContent,
            createNode: function(parent) { return puiQtNodeComponent.createObject(parent) },
            connected: function() { return puiQtHost.Window.window !== null },
            later: function(callback) { Qt.callLater(callback) },
            rootChanged: function(root) { puiQtRoot = root },
            epochChanged: function(epoch, present) { puiQtEpoch = epoch; puiQtPresent = present },
            changed: function() { ++puiQtRevision },
            emit: function(key, payload) { puiQtHost.deliverExpose(key, payload) },
            propChecks: {["present"]: function(value) { return (typeof value === "boolean"); }}, eventChecks: {}, methodChecks: {["snapshot"]: {args:function(args) { return args.length <= 0; },result:function(value) { return (value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["axes","horizontal","vertical","scrolling","projection","endFollow"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "axes") && (typeof value["axes"] === "string")) && (Object.prototype.hasOwnProperty.call(value, "horizontal") && (value["horizontal"] !== null && typeof value["horizontal"] === 'object' && !Array.isArray(value["horizontal"]) && (Object.getPrototypeOf(value["horizontal"]) === Object.prototype || Object.getPrototypeOf(value["horizontal"]) === null) && Object.keys(value["horizontal"]).every(function(key) { return ["position","visibleRatio","canScrollBefore","canScrollAfter","atEnd"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value["horizontal"], key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value["horizontal"], "position") && (typeof value["horizontal"]["position"] === "number" && Number.isFinite(value["horizontal"]["position"]))) && (Object.prototype.hasOwnProperty.call(value["horizontal"], "visibleRatio") && (typeof value["horizontal"]["visibleRatio"] === "number" && Number.isFinite(value["horizontal"]["visibleRatio"]))) && (Object.prototype.hasOwnProperty.call(value["horizontal"], "canScrollBefore") && (typeof value["horizontal"]["canScrollBefore"] === "boolean")) && (Object.prototype.hasOwnProperty.call(value["horizontal"], "canScrollAfter") && (typeof value["horizontal"]["canScrollAfter"] === "boolean")) && (Object.prototype.hasOwnProperty.call(value["horizontal"], "atEnd") && (typeof value["horizontal"]["atEnd"] === "boolean")))) && (Object.prototype.hasOwnProperty.call(value, "vertical") && (value["vertical"] !== null && typeof value["vertical"] === 'object' && !Array.isArray(value["vertical"]) && (Object.getPrototypeOf(value["vertical"]) === Object.prototype || Object.getPrototypeOf(value["vertical"]) === null) && Object.keys(value["vertical"]).every(function(key) { return ["position","visibleRatio","canScrollBefore","canScrollAfter","atEnd"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value["vertical"], key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value["vertical"], "position") && (typeof value["vertical"]["position"] === "number" && Number.isFinite(value["vertical"]["position"]))) && (Object.prototype.hasOwnProperty.call(value["vertical"], "visibleRatio") && (typeof value["vertical"]["visibleRatio"] === "number" && Number.isFinite(value["vertical"]["visibleRatio"]))) && (Object.prototype.hasOwnProperty.call(value["vertical"], "canScrollBefore") && (typeof value["vertical"]["canScrollBefore"] === "boolean")) && (Object.prototype.hasOwnProperty.call(value["vertical"], "canScrollAfter") && (typeof value["vertical"]["canScrollAfter"] === "boolean")) && (Object.prototype.hasOwnProperty.call(value["vertical"], "atEnd") && (typeof value["vertical"]["atEnd"] === "boolean")))) && (Object.prototype.hasOwnProperty.call(value, "scrolling") && (typeof value["scrolling"] === "boolean")) && (Object.prototype.hasOwnProperty.call(value, "projection") && (typeof value["projection"] === "string")) && (Object.prototype.hasOwnProperty.call(value, "endFollow") && (value["endFollow"] !== null && typeof value["endFollow"] === 'object' && !Array.isArray(value["endFollow"]) && (Object.getPrototypeOf(value["endFollow"]) === Object.prototype || Object.getPrototypeOf(value["endFollow"]) === null) && Object.keys(value["endFollow"]).every(function(key) { return ["state","requestStatus"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value["endFollow"], key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value["endFollow"], "state") && (typeof value["endFollow"]["state"] === "string")) && (Object.prototype.hasOwnProperty.call(value["endFollow"], "requestStatus") && (typeof value["endFollow"]["requestStatus"] === "string"))))); }}, ["horizontal"]: {args:function(args) { return args.length <= 0; },result:function(value) { return value === undefined; }}, ["vertical"]: {args:function(args) { return args.length <= 0; },result:function(value) { return value === undefined; }}, ["both"]: {args:function(args) { return args.length <= 0; },result:function(value) { return value === undefined; }}, ["same"]: {args:function(args) { return args.length <= 0; },result:function(value) { return value === undefined; }}, ["extra"]: {args:function(args) { return args.length <= 0; },result:function(value) { return value === undefined; }}, ["middle"]: {args:function(args) { return args.length <= 0; },result:function(value) { return ((value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "dispatched")) || (value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "queued")) || (value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind","reason"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "rejected") && (Object.prototype.hasOwnProperty.call(value, "reason") && (value["reason"] === "not-mounted" || value["reason"] === "not-declared" || value["reason"] === "unavailable")))); }}, ["relative"]: {args:function(args) { return args.length <= 0; },result:function(value) { return ((value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "dispatched")) || (value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "queued")) || (value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind","reason"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "rejected") && (Object.prototype.hasOwnProperty.call(value, "reason") && (value["reason"] === "not-mounted" || value["reason"] === "not-declared" || value["reason"] === "unavailable")))); }}, ["pageBefore"]: {args:function(args) { return args.length <= 0; },result:function(value) { return ((value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "dispatched")) || (value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "queued")) || (value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind","reason"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "rejected") && (Object.prototype.hasOwnProperty.call(value, "reason") && (value["reason"] === "not-mounted" || value["reason"] === "not-declared" || value["reason"] === "unavailable")))); }}, ["quarter"]: {args:function(args) { return args.length <= 0; },result:function(value) { return ((value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "dispatched")) || (value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "queued")) || (value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind","reason"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "rejected") && (Object.prototype.hasOwnProperty.call(value, "reason") && (value["reason"] === "not-mounted" || value["reason"] === "not-declared" || value["reason"] === "unavailable")))); }}, ["end"]: {args:function(args) { return args.length <= 0; },result:function(value) { return ((value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "dispatched")) || (value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "queued")) || (value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind","reason"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "rejected") && (Object.prototype.hasOwnProperty.call(value, "reason") && (value["reason"] === "not-mounted" || value["reason"] === "not-declared" || value["reason"] === "unavailable")))); }}, ["pause"]: {args:function(args) { return args.length <= 0; },result:function(value) { return ((value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "dispatched")) || (value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "queued")) || (value !== null && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null) && Object.keys(value).every(function(key) { return ["kind","reason"].indexOf(key) >= 0 && Object.prototype.hasOwnProperty.call(Object.getOwnPropertyDescriptor(value, key), 'value'); }) && (Object.prototype.hasOwnProperty.call(value, "kind") && value["kind"] === "rejected") && (Object.prototype.hasOwnProperty.call(value, "reason") && (value["reason"] === "not-mounted" || value["reason"] === "not-declared" || value["reason"] === "unavailable")))); }}},
            styleTable: {"w-60":{"fixedWidth":240},"h-50":{"fixedHeight":200}},
            declarations: [],
            tableFamilies: [],
            contextCheck: (key, value) => false
        })
        const puiQtDef = puiQtOwner.def

        const puiQtHookResults = new Map();

        try {
            puiQtOwner.setRender((function(def) {
                // Source "qt-native-scroll.proto.ts":6:5
                def.props.define({["present"]: {["type"]: "boolean", ["default"]: true}});
                // Source "qt-native-scroll.proto.ts":7:5
                def.props.watch(["present"], function(run, next) {
                    // Source "qt-native-scroll.proto.ts":7:49
                    return run.lifecycle.setPresent((next)["present"]);
                });
                // Source "qt-native-scroll.proto.ts":8:11
                const scroll = puiQtOwner.interaction.asScrollSurface();
                // Source "qt-native-scroll.proto.ts":9:5
                scroll.configure({["axes"]: "vertical", ["projection"]: "system", ["endFollow"]: {["mode"]: "while-at-end", ["axis"]: "vertical"}});
                // Source "qt-native-scroll.proto.ts":14:5
                def.feedback.style.use({"kind":"tw","tokens":["w-60","h-50"],"groups":["w-","h-"]});
                // Source "qt-native-scroll.proto.ts":15:5
                def.expose.method("snapshot", function() {
                    // Source "qt-native-scroll.proto.ts":15:41
                    return scroll.getSnapshot();
                });
                // Source "qt-native-scroll.proto.ts":16:5
                def.expose.method("horizontal", function() {
                    // Source "qt-native-scroll.proto.ts":16:43
                    return scroll.sync({["axes"]: "horizontal"});
                });
                // Source "qt-native-scroll.proto.ts":17:5
                def.expose.method("vertical", function() {
                    // Source "qt-native-scroll.proto.ts":17:41
                    return scroll.sync({["axes"]: "vertical"});
                });
                // Source "qt-native-scroll.proto.ts":18:5
                def.expose.method("both", function() {
                    // Source "qt-native-scroll.proto.ts":18:37
                    return scroll.sync({["axes"]: "both"});
                });
                // Source "qt-native-scroll.proto.ts":19:5
                def.expose.method("same", function() {
                    // Source "qt-native-scroll.proto.ts":19:37
                    return scroll.sync({});
                });
                // Source "qt-native-scroll.proto.ts":20:11
                const extra = {["axes"]: "horizontal", ["projection"]: "composed"};
                // Source "qt-native-scroll.proto.ts":24:5
                def.expose.method("extra", function() {
                    // Source "qt-native-scroll.proto.ts":24:38
                    return scroll.sync(extra);
                });
                // Source "qt-native-scroll.proto.ts":25:5
                def.expose.method("middle", function() {
                    // Source "qt-native-scroll.proto.ts":26:7
                    return scroll.request({["kind"]: "to", ["axis"]: "vertical", ["position"]: 0.5});
                });
                // Source "qt-native-scroll.proto.ts":28:5
                def.expose.method("relative", function() {
                    // Source "qt-native-scroll.proto.ts":29:7
                    return scroll.request({["kind"]: "by", ["axis"]: "vertical", ["delta"]: 10});
                });
                // Source "qt-native-scroll.proto.ts":31:5
                def.expose.method("pageBefore", function() {
                    // Source "qt-native-scroll.proto.ts":32:7
                    return scroll.request({["kind"]: "page", ["axis"]: "vertical", ["direction"]: "before"});
                });
                // Source "qt-native-scroll.proto.ts":34:5
                def.expose.method("quarter", function() {
                    // Source "qt-native-scroll.proto.ts":35:7
                    return scroll.request({["kind"]: "control-drag", ["axis"]: "vertical", ["position"]: 0.25});
                });
                // Source "qt-native-scroll.proto.ts":37:5
                def.expose.method("end", function() {
                    // Source "qt-native-scroll.proto.ts":37:36
                    return scroll.request({["kind"]: "to-end", ["axis"]: "vertical"});
                });
                // Source "qt-native-scroll.proto.ts":38:5
                def.expose.method("pause", function() {
                    // Source "qt-native-scroll.proto.ts":38:38
                    return scroll.pauseFollowing();
                });
                // Source "qt-native-scroll.proto.ts":39:5
                return function(r) {
                    // Source "qt-native-scroll.proto.ts":39:19
                    return r.slot();
                };
            })(puiQtDef))
            puiQtOwner.hydrate(rawProps)
            puiQtOwner.created()
            puiQtReady = true
            ++puiQtRevision
        } catch (error) {
            try { puiQtOwner.dispose() } finally { puiQtOwner = null; puiQtClosed = true }
            throw error
        }
        return puiQtOwner
    }
    function deliverExpose(key, payload) {
        exposed(key, payload)

    }
    function setProps(next) { if (puiQtClosed) throw new Error('Qt component disposed'); rawProps = next }
    function update() { ensureOwner().update() }
    function getExposes() { return ensureOwner().getExposes() }
    function dispose() { if (puiQtClosed) return; puiQtClosed = true; puiQtReady = false; if (puiQtOwner) puiQtOwner.dispose() }
    onRawPropsChanged: if (puiQtOwner && !puiQtClosed) puiQtOwner.hydrate(rawProps)
    onParentChanged: if (puiQtOwner && !puiQtClosed) Qt.callLater(function() { if (!puiQtClosed) puiQtOwner.topologyChanged() })
    onNativeWindowChanged: if (puiQtOwner && !puiQtClosed) Qt.callLater(function() { if (!puiQtClosed) puiQtOwner.topologyChanged() })
    onLogicalParentChanged: if (puiQtOwner && !puiQtClosed) Qt.callLater(function() { if (!puiQtClosed) puiQtOwner.topologyChanged() })
    Qml.Component.onCompleted: { ensureOwner(); puiQtOwner.reconcile() }
    Qml.Component.onDestruction: dispose()
}
