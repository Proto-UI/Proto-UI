import { readFileSync, writeFileSync, mkdirSync, mkdtempSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { verifyQtNativeEvidence } from './proto-ui-s5/scripts/ci/check-qt-native-evidence.mjs';

const root = '/workspace/scratch/f7b299133482/proto-ui-s5';
const parent = '/workspace/scratch/f7b299133482/owner-qt-evidence-review';
mkdirSync(parent, { recursive: true });
const head = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim();
const cases = [
  'void setup preserves the original native slot child',
  'template sibling order and independent Root styles',
  'empty template retains its host Root',
  'initial native Flickable viewport and facts',
  'explicit update preserves Root identity',
  'axes-only sync and unrelated policy preservation',
  'detach and same-owner replacement with retained intent',
  'terminal old callable refusal',
];
const success = (command, stdout = '') => ({ command, stdout, stderr: '', status: 0, signal: null });
const producerInput = 'packages/compiler/test/fixtures/qt-native-consumer/prepare.ts';
const hash = (data) => createHash('sha256').update(data).digest('hex');
const results = [];
for (const name of ['empty-inventories', 'omitted-generated-artifacts', 'foreign-case-list']) {
  const directory = mkdtempSync(path.join(parent, name + '-'));
  const child = path.join(directory, 'proto-qt-native-independent');
  mkdirSync(child);
  const selectedCases = name === 'foreign-case-list' ? cases.map((_, index) => `foreign ${index}`) : cases;
  const reports = {
    vitest: {
      success: true, numTotalTests: 1, numPassedTests: 1, numFailedTests: 0, numPendingTests: 0,
      testResults: [{ name: root + '/packages/compiler/test/qt-native-consumer.native.test.ts', status: 'passed', assertionResults: [{ status: 'passed' }] }],
    },
    version: success(['/pinned/bin/qmake', '-query', 'QT_VERSION'], '6.4.2\n'),
    configure: success(['cmake', '-DCMAKE_BUILD_TYPE=Release']),
    build: success(['cmake', '--build', 'build', '--parallel', '2']),
    consumer: success(['/generated/build/compiled-qt', '/generated/Consumer.qml'], 'qml: PUI_QT_RESULT ' + JSON.stringify({ passed: 8, failed: 0, cases: selectedCases.map((name) => ({ name, status: 'passed' })) })),
    drift: [],
    source: {
      head, expectedCases: selectedCases,
      inputs: name === 'empty-inventories' ? [] : [{ file: producerInput, sha256: hash(readFileSync(path.join(root, producerInput))) }],
      files: [],
    },
  };
  const locations = { vitest: path.join(directory, 'vitest.json'), version: path.join(child, 'qt-version.json'), configure: path.join(child, 'configure.json'), build: path.join(child, 'build.json'), consumer: path.join(child, 'consumer.json'), drift: path.join(child, 'generated-drift.json'), source: path.join(child, 'source-receipt.json') };
  for (const [key, file] of Object.entries(locations)) writeFileSync(file, JSON.stringify(reports[key]));
  writeFileSync(path.join(directory, 'source-sha.txt'), head + '\n');
  writeFileSync(path.join(child, 'Consumer.qml'), readFileSync(path.join(root, 'packages/compiler/test/fixtures/qt-native-consumer/Consumer.qml')));
  let accepted = false, error = null;
  try { verifyQtNativeEvidence(directory, head); accepted = true; }
  catch (caught) { error = String(caught); }
  results.push({ name, accepted, error, directory, noGeneratedCodeOrIrProvided: true });
}
const receipt = {
  scope: 'Independent evidence-checker negative controls only; synthetic reports are deliberately not actual Qt execution evidence.',
  checkerSha256: hash(readFileSync(path.join(root, 'scripts/ci/check-qt-native-evidence.mjs'))),
  results,
};
writeFileSync(path.join(parent, 'findings.json'), JSON.stringify(receipt, null, 2) + '\n');
console.log(JSON.stringify(receipt, null, 2));
