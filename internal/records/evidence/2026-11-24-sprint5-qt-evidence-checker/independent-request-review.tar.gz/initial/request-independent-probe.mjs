import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
const root='/workspace/scratch/f7b299133482/proto-ui-s5';
const file=path.join(root,'packages/compiler/src/qt-native-controls.ts');
const bytes=readFileSync(file);
const source=new Function(bytes.toString().replace('export const qtControlsSource','const qtControlsSource')+'\nreturn qtControlsSource;')();
const createControls=new Function(source.replace('export function createControls','function createControls')+'\nreturn createControls;')();
function consumer(){
 const movements=[];let ready=true;
 const nativeRoot={syncScroll(){},scrollRequest(request){movements.push(request);}};
 const controller=createControls({declarations:[],alive(){},setup(){},runtime(){},changed(){},refreshFacts(){},active:()=>true,ready:()=>ready,root:()=>nativeRoot,invoke:(fn,args)=>fn(...args)});
 const surface=controller.hooks.asScrollSurface();
 surface.configure({axes:'vertical',projection:'system',endFollow:{mode:'while-at-end',axis:'vertical'}});
 controller.mount();
 return {surface,controller,movements,nativeRoot,setReady(value){ready=value;}};
}
const results=[];
function probe(name,execute){try{const observation=execute();results.push({name,passed:true,observation});}catch(error){results.push({name,passed:false,error:String(error),actual:error.actual,expected:error.expected});}}
probe('unchanged current end request has pending then applied',()=>{
 const c=consumer(),events=[];c.surface.endFollow.requestStatus.subscribe(e=>events.push(e.next));
 assert.deepEqual(c.surface.request({kind:'to-end',axis:'vertical'}),{kind:'dispatched'});
 assert.deepEqual(events,['pending','applied']);assert.equal(c.movements.length,1);
 return {events};
});
probe('axes sync cancels pending request with a rejected fact',()=>{
 const c=consumer();let once=true;
 c.surface.endFollow.requestStatus.subscribe(e=>{if(once&&e.next==='pending'){once=false;c.surface.sync({axes:'horizontal'});}});
 const outcome=c.surface.request({kind:'to-end',axis:'vertical'});
 assert.deepEqual(outcome,{kind:'rejected',reason:'unavailable'});assert.equal(c.movements.length,0);
 assert.equal(c.surface.endFollow.requestStatus.get(),'rejected');
 return {outcome};
});
probe('new position request retires superseded pending end fact',()=>{
 const c=consumer();let once=true,inner;
 c.surface.endFollow.requestStatus.subscribe(e=>{if(once&&e.next==='pending'){once=false;inner=c.surface.request({kind:'to',axis:'vertical',position:0.4});}});
 const outcome=c.surface.request({kind:'to-end',axis:'vertical'});
 assert.deepEqual(outcome,{kind:'rejected',reason:'unavailable'});assert.deepEqual(inner,{kind:'dispatched'});assert.equal(c.movements.length,1);
 assert.equal(c.surface.endFollow.requestStatus.get(),'rejected');
 return {outcome,inner};
});
probe('pending observer failure retires request and preserves undefined',()=>{
 const c=consumer();let caught=false,value='uncaught';
 c.surface.endFollow.requestStatus.subscribe(e=>{if(e.next==='pending')throw undefined;});
 try{c.surface.request({kind:'to-end',axis:'vertical'});}catch(error){caught=true;value=error;}
 assert.equal(caught,true);assert.equal(value,undefined);assert.equal(c.movements.length,0);
 assert.equal(c.surface.endFollow.requestStatus.get(),'rejected');
 return {firstFailure:'undefined',caught};
});
probe('first undefined host failure survives secondary observer failure',()=>{
 const c=consumer();let caught=false,value='uncaught';
 c.nativeRoot.scrollRequest=()=>{throw undefined;};
 c.surface.endFollow.requestStatus.subscribe(e=>{if(e.next==='rejected')throw Error('secondary');});
 try{c.surface.request({kind:'to-end',axis:'vertical'});}catch(error){caught=true;value=error;}
 assert.equal(caught,true);assert.equal(value,undefined);assert.equal(c.surface.endFollow.requestStatus.get(),'rejected');
 return {firstFailure:'undefined',caught};
});
const sha=createHash('sha256').update(bytes).digest('hex');
assert.equal(createHash('sha256').update(readFileSync(file)).digest('hex'),sha);
const receipt={scope:'Independent emitted QtControls guest probes; no native Qt execution or hardware claim.',sourceFile:file,sourceSha256:sha,results};
writeFileSync('/workspace/scratch/f7b299133482/qt-evidence-checker-review/request-independent-probe.json',JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify(receipt,null,2));
process.exitCode=results.some(result=>!result.passed)?1:0;
