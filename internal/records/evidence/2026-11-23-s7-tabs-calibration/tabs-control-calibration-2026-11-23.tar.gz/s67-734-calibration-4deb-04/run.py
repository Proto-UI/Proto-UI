
import base64,gzip,json,pathlib,subprocess,hashlib,os,sys,time,socket,traceback
base=pathlib.Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
repo=base/'continuation-s67-4deb'
out=base/'s67-734-calibration-4deb-04'
payload=json.loads(gzip.decompress((out/'payload.gz').read_bytes()))
env=dict(os.environ)
env['PATH']=str(base/'tools/node-v24.22.3-linux-x64/bin')+os.pathsep+env.get('PATH','')
env['npm_config_cache']=str(base/'i750-npm-cache-remote-01')
env['npm_config_audit']='false'
env['npm_config_fund']='false'
env['ASTRO_TELEMETRY_DISABLED']='1'
summary={'head':'d0392fb31513b12f55b9e99b1fcf26a6338569c9','expectedOriginalSha256':payload['expectedSha256'],'candidateSha256':payload['candidateSha256'],'historicalPatchSource':payload['historicalPatchSource'],'startedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'commands':[],'cells':[]}
def save(): (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
def run(args,cwd,log,timeout=180):
    start=time.time()
    with (out/log).open('wb') as f:
        r=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    summary['commands'].append({'args':args,'cwd':str(cwd),'log':log,'returncode':r.returncode,'elapsedSeconds':time.time()-start})
    save()
    return r.returncode
servers=[]
try:
    actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
    assert actual==summary['head'],actual
    rel='benchmarks/interaction/knowledge-consumer/example/check.mjs'
    original=subprocess.check_output(['git','show','HEAD:'+rel],cwd=repo)
    assert hashlib.sha256(original).hexdigest()==payload['expectedSha256'],'d039 evaluator source differs; do not replace'
    (out/'original-check.mjs').write_bytes(original)
    (out/'candidate-check.mjs').write_bytes(base64.b64decode(payload['candidate']))
    summary['sourceFiles']=[]
    for sourceRel,encoded in payload['files'].items():
        sourceBytes=base64.b64decode(encoded)
        if sourceRel!='package-lock.json':
            committed=subprocess.check_output(['git','show',summary['head']+':benchmarks/interaction/knowledge-consumer/example/'+sourceRel],cwd=repo)
            assert committed==sourceBytes,sourceRel+' source mismatch'
        summary['sourceFiles'].append({'path':sourceRel,'sha256':hashlib.sha256(sourceBytes).hexdigest(),'source':'recovered installation lock' if sourceRel=='package-lock.json' else summary['head']})
    original_html=base64.b64decode(payload['files']['index.html'])
    target=b'    <title>Reference sections</title>'
    assert original_html.count(target)==1
    repaired_html=original_html.replace(target,b'    <link rel="icon" href="data:," />\n'+target)
    payload['files']['index.html']=base64.b64encode(repaired_html).decode()
    summary['fixtureRepair']={'path':'index.html','originalSha256':hashlib.sha256(original_html).hexdigest(),'candidateSha256':hashlib.sha256(repaired_html).hexdigest(),'reason':'The preserved round 03 Chromium trace reports a 404 at /favicon.ico; declare an explicit empty icon rather than ignoring console errors. Both checker versions use the same repaired fixture.'}
    summary['nodeVersion']=subprocess.check_output(['node','--version'],env=env,text=True).strip()
    chrome=next(iter(sorted((base/'tools/playwright-browsers').glob('chromium-*/chrome-linux*/chrome'))),None)
    if chrome is None: chrome=next(iter(sorted((base/'tools/playwright-browsers').glob('chromium_headless_shell-*/chrome-linux*/headless_shell'))),None)
    assert chrome is not None,'no installed Chromium'
    env['CHROME_PATH']=str(chrome)
    summary['browserExecutable']=str(chrome)
    summary['browserVersion']=subprocess.check_output([str(chrome),'--version'],env=env,text=True).strip()
    summary['browserSha256']=hashlib.sha256(chrome.read_bytes()).hexdigest()
    for name in ['original','candidate']:
        consumer=out/(name+'-consumer')
        consumer.mkdir()
        for rel,encoded in payload['files'].items():
            f=consumer/rel; f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(base64.b64decode(encoded))
        (consumer/'check.mjs').write_bytes(original if name=='original' else base64.b64decode(payload['candidate']))
        assert run(['npm','ci','--ignore-scripts','--no-audit','--no-fund'],consumer,name+'-install.log',240)==0,name+' install failed'
        assert run(['npm','run','build'],consumer,name+'-build.log',120)==0,name+' build failed'
        with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
        log=(out/(name+'-server.log')).open('wb')
        process=subprocess.Popen(['npm','run','preview','--','--port',str(port)],cwd=consumer,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        servers.append((process,log))
        import urllib.request
        ready=False
        for attempt in range(60):
            if process.poll() is not None: break
            try:
                with urllib.request.urlopen('http://127.0.0.1:'+str(port)+'/',timeout=1) as response:
                    if response.status==200: ready=True;break
            except Exception: time.sleep(.2)
        assert ready,name+' preview not ready'
        cells=[('positive-wide','none','wide','light'),('automatic','automatic','wide','light')] if name=='original' else [('positive-wide','none','wide','light'),('positive-narrow-dark','none','narrow','dark'),('automatic','automatic','wide','light'),('relationship','relationship','wide','light'),('removal','removal','wide','light')]
        for cell,control,viewport,color in cells:
            ident=name+'-'+cell
            dest=out/ident
            args=['node','check.mjs','--url','http://127.0.0.1:'+str(port),'--out',str(dest),'--viewport',viewport,'--color-scheme',color,'--negative-control',control]
            code=run(args,consumer,ident+'.log',120)
            report=json.loads((dest/'report.json').read_text())
            failed=[x['id'] for x in report['checks'] if x['status']=='failed']
            passed=sum(x['status']=='passed' for x in report['checks'])
            expected=None if name=='original' or control=='none' else {'automatic':'right-skips-disabled','relationship':'initial-selection','removal':'removal'}[control]
            accepted=(code==0 and report['outcome']=='passed' and passed==22) if expected is None else (code==1 and failed==[expected] and not report['runtimeErrors'] and not report['cleanupErrors'])
            if name=='candidate' and control=='automatic':
                state=json.loads((dest/'failure.json').read_text())
                accepted=accepted and any(x['target']=='Details' and x['event']=='keydown' and x['key']=='Enter' and x['isTrusted'] is False for x in report['mutationEvents']) and [x['text'].strip() for x in state['tabs'] if x['selected']=='true']==['Details']
            summary['cells'].append({'id':ident,'exitCode':code,'outcome':report['outcome'],'passed':passed,'planned':len(report['checks']),'failed':failed,'expectedFailure':expected,'expectationMet':accepted})
            save()
        process.terminate()
        try:process.wait(timeout=10)
        except subprocess.TimeoutExpired:process.kill();process.wait()
        log.close()
    summary['outcome']='passed' if all(x['expectationMet'] for x in summary['cells']) and len(summary['cells'])==7 else 'failed'
except Exception as e:
    summary['outcome']='error';summary['error']=traceback.format_exc()
finally:
    for p,log in servers:
        if p.poll() is None:
            p.terminate()
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:p.kill();p.wait()
        if not log.closed:log.close()
    summary['finishedAt']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());save()
    (out/'exit-code').write_text('0\n' if summary.get('outcome')=='passed' else '1\n')
