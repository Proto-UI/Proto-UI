import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtempSync, readFileSync, readdirSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const repository = '/workspace/scratch/1494db44bb7b/Proto-UI';
const evidence = '/workspace/scratch/1494db44bb7b/ir10-semantics-evidence';
const filename = path.join(repository, 'scripts/test/shader-browser-evidence.mjs');
const source = readFileSync(filename, 'utf8');
const digest = (s) => createHash('sha256').update(s).digest('hex');
const module = await import(pathToFileURL(filename));
const selection = module.SHADER_BROWSER_SELECTION;
const original = JSON.parse(readFileSync(path.join(evidence, 'shader28-original-full-names.json'), 'utf8'));
assert.deepEqual(selection.originalJourneys, original);
const report = () => ({
  success: true, numTotalTests: 37, numPassedTests: 37,
  numFailedTests: 0, numPendingTests: 0, numTodoTests: 0,
  testResults: [{ name: path.join(repository, module.SHADER_BROWSER_SUITE), status: 'passed',
    assertionResults: [...selection.originalJourneys, ...selection.sceneJourneys].map((fullName) => ({ fullName, status: 'passed' })) }],
});
const results = [];
function check(name, expectation, fn) {
  let rejected = false, error = null;
  try { fn(); } catch (e) { rejected = true; error = String(e.message).slice(0,1800); }
  const observed = rejected ? 'rejected' : 'accepted';
  results.push({ name, expectation, observed, matched: expectation === observed, error });
}
check('complete 28 original plus 9 added identities', 'accepted', () => module.verifyShaderBrowserReport(report()));
for (const [label, index] of [['original', 0], ['scene', 28]]) {
  check(`${label} journey replaced with a distinct substitute at unchanged count`, 'rejected', () => {
    const r = report(); r.testResults[0].assertionResults[index].fullName = 'independent substitute journey';
    module.verifyShaderBrowserReport(r);
  });
}
check('actual first-slice failed suite is not accepted', 'rejected', () => module.verifyShaderBrowserReport(
  JSON.parse(readFileSync(path.join(evidence, 'remote-shader28-originals/shader28-282cbca2.report.json'), 'utf8'))));

// Invoke the exported pure acceptance validator; no CLI, Git or browser is run.
const verifyBuilds = module.verifyShaderBrowserBuilds;
assert.equal(typeof verifyBuilds, 'function');
const syntheticHead = 'a'.repeat(40);
const profiles = { react: 'react-dom-source-v1', vue: 'vue-source-v1', vue2: 'vue2-source-v1', wc: 'web-component-source-v1' };
const builds = () => selection.fixtures.map((entry) => ({
  candidate: { head: syntheticHead, dirty: false },
  sourceGenerator: { files: [{ file: 'synthetic-probe.ts', sha256: '0'.repeat(64) }] },
  inputs: { 'synthetic-input.ts': '0'.repeat(64) },
  compilations: Object.entries(profiles).map(([target, profile]) => ({ target, profile, entry })),
}));
function inspectBuilds(label, expectation, mutate) {
  const dir = mkdtempSync(path.join(evidence, 'synthetic-ci-review-'));
  try {
    const records = builds(); mutate?.(records);
    records.forEach((record, i) => { const sub = path.join(dir, `synthetic-${i}`); mkdirSync(sub); writeFileSync(path.join(sub, 'build.json'), JSON.stringify(record)); });
    check(label, expectation, () => verifyBuilds(dir, syntheticHead));
  } finally { rmSync(dir, { recursive: true, force: true }); }
}
inspectBuilds('three distinct sources and four matching target/profile pairs', 'accepted');
inspectBuilds('duplicate fixture at unchanged build count', 'rejected', (r) => { r[2] = structuredClone(r[0]); });
inspectBuilds('substitute fixture at unchanged build count', 'rejected', (r) => { for (const c of r[2].compilations) c.entry = 'synthetic-unselected.proto.ts'; });
inspectBuilds('one fixture uses a different entry for a target', 'rejected', (r) => { r[1].compilations[0].entry = r[0].compilations[0].entry; });
inspectBuilds('wrong candidate in one fixture', 'rejected', (r) => { r[1].candidate.head = 'b'.repeat(40); });
inspectBuilds('dirty candidate in one fixture', 'rejected', (r) => { r[1].candidate.dirty = true; });
inspectBuilds('target names preserved while a profile is substituted', 'rejected', (r) => { r[1].compilations[0].profile = 'vue-source-v1'; });

const files = ['.github/workflows/browser-suite-repair-evidence.yml', '.github/workflows/shader-presentation-evidence.yml', 'scripts/test/shader-browser-evidence.mjs', 'scripts/test/shader-browser-evidence.test.mjs', 'scripts/test/shader-browser-selection.json'];
const summary = {
  kind: 'independent local synthetic acceptance-control review',
  browserJourneysExecuted: 0,
  originalNamesMatchActualReport: true,
  sourceHashes: Object.fromEntries(files.map((file) => [file, digest(readFileSync(path.join(repository, file)))])),
  validatorExposure: 'Exported pure acceptance function invoked directly; no source edits and no runner, Git, namespace or browser execution.',
  results,
  counts: { total: results.length, matched: results.filter((r) => r.matched).length, unexpected: results.filter((r) => !r.matched).length },
};
const output = path.join(evidence, 'shader-ci-independent-review.json');
writeFileSync(output, JSON.stringify(summary, null, 2) + '\n');
console.log(JSON.stringify({ output, counts: summary.counts, unexpected: results.filter((r) => !r.matched) }, null, 2));
