import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { performance } from 'node:perf_hooks';
import { validateShadowStyleArtifact as previous } from './baseline/shadow-style-artifact.ts';
import { validateShadowStyleArtifact as candidate } from '../../Proto-UI/packages/adapters/web-component/src/shadow-style-artifact.ts';
import { protoShadowStyleArtifact } from '../../Proto-UI/apps/www/src/styles/proto-ui-shadow-style.generated.js';

const iterations = 30;
const digest = (data: string) => crypto.createHash('sha256').update(data).digest('hex');
const measure = (name: string, validate: typeof candidate) => {
  const started = performance.now();
  for (let index = 0; index < iterations; index += 1) {
    const result = validate(protoShadowStyleArtifact);
    assert.equal(result.cssText, protoShadowStyleArtifact.cssText);
    assert.notEqual(result, protoShadowStyleArtifact);
    assert.equal(Object.isFrozen(result), true);
  }
  return { name, iterations, milliseconds: performance.now() - started };
};
const results = [
  measure('previous-first', previous),
  measure('candidate-including-first-validation', candidate),
  measure('previous-after-candidate', previous),
  measure('candidate-already-validated', candidate),
];
const result = {
  diagnosticOnly: true,
  provesMatrixDeadline: false,
  node: process.version,
  cssCodeUnits: protoShadowStyleArtifact.cssText.length,
  cssSha256: digest(protoShadowStyleArtifact.cssText),
  previousSha256: digest(fs.readFileSync(new URL('./baseline/shadow-style-artifact.ts', import.meta.url), 'utf8')),
  candidateSha256: digest(fs.readFileSync(new URL('../../Proto-UI/packages/adapters/web-component/src/shadow-style-artifact.ts', import.meta.url), 'utf8')),
  results,
};
fs.writeFileSync(new URL('./benchmark.json', import.meta.url), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result));
