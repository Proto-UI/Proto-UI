const ts=require("/workspace/scratch/f7b299133482/s5-owner/node_modules/typescript");const path=require('node:path');const root="/workspace/scratch/f7b299133482/s5-owner";
const config=ts.readConfigFile(path.join(root,'tsconfig.json'),ts.sys.readFile);
const parsed=ts.parseJsonConfigFileContent(config.config,ts.sys,root);
const program=ts.createProgram({rootNames:["packages/compiler/src/vue-source.ts", "packages/compiler/src/vue-ssr-support.ts", "packages/compiler/test/owner-hydration-matrix-fixture.ts", "packages/compiler/test/owner-hydration-matrix-consumer.ts", "packages/compiler/test/owner-hydration-matrix-build.ts", "packages/compiler/test/owner-hydration-matrix-assertions.ts", "packages/compiler/test/owner-hydration-matrix.browser.test.ts", "packages/compiler/test/owner-hydration-matrix.test.ts"].map(file=>path.join(root,file)),options:{...parsed.options,strict:true,noEmit:true,incremental:false}});
const diagnostics=ts.getPreEmitDiagnostics(program);
process.stdout.write(JSON.stringify({strict:program.getCompilerOptions().strict,sourceFiles:program.getSourceFiles().length,diagnostics:diagnostics.length})+'\n');
if(diagnostics.length)process.stdout.write(ts.formatDiagnosticsWithColorAndContext(diagnostics,{getCurrentDirectory:()=>root,getCanonicalFileName:file=>file,getNewLine:()=>"\n"}));
process.exitCode=diagnostics.length?1:0;
