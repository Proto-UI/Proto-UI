import base from "/workspace/scratch/f7b299133482/s5-owner/vitest.config.ts";
import{readFileSync}from"node:fs";
const root="/workspace/scratch/f7b299133482/s5-owner";
const out="/workspace/scratch/f7b299133482/owner-matrix-check/props-only";
export default{...base,root,plugins:[{name:"readonly-vue-props-only-parent",enforce:"pre",load(id){for(const file of ["vue-source.ts","vue-ssr-support.ts"])if(id.split("?")[0]===root+"/packages/compiler/src/"+file)return readFileSync(out+"/"+file,"utf8");}},...(base.plugins??[])]};
