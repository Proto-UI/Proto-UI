import base from "/workspace/scratch/f7b299133482/s5-owner/vitest.config.ts";
import{readFileSync}from'node:fs';
const original="throw new Error('[Vue SSR] client initial render differs from source-bound server projection');";
const replacement="throw new Error('[Vue SSR] client initial render differs from source-bound server projection ' + JSON.stringify({id:${n('Tree')}.id,expected:${n('Record')},actual:${n('Project')}(children, ${n('SlotView')}),present:${n('Present')}.value,tag}));";
export default {...base,root:"/workspace/scratch/f7b299133482/s5-owner",plugins:[{name:'readonly-actual-projection-diagnostic',enforce:'pre',load(id){if(id.split('?')[0]==="/workspace/scratch/f7b299133482/s5-owner/packages/compiler/src/vue-source.ts"){const text=readFileSync(id,'utf8');if(text.split(original).length!==2)throw new Error('diagnostic site mismatch');return text.replace(original,replacement);}}},...(base.plugins??[])]};
