# Sprint 5 private browser owner matrix and Vue initial Context acceptance

## Scope

This increment addresses concrete #896 owner initialization conditions without promoting either owner draft or canonical SSR admission. It adds one source-bound browser suite for React, Vue 3 and Vue 2, with a matching simulated DOM preflight. The actual server renderers produce all HTML and carriers; the browser bundle contains the actual emitted source/support modules and real frameworks. No authored prototype runs in place of compiled output and no native renderer, State or Context implementation is mocked.

At author freeze the physical eight-case Chromium run is **pending**. Source execution, actual generated artifact typing and runtime-plan discovery below are established. They are not physical-browser receipts. The draft mapping is `T-LIFECYCLE-OWNER-BROWSER-0001`; the original complete-target initialization requirement remains separate.

## Actual defect

The Vue ownership journey first adopts seed 3, updates to 7, withdraws/re-enters the view, disposes, then explicitly creates a fresh owner from the original carrier with current controlling seed 9. During that last adoption, the parent validated its server projection and immediately applied current Props. Its Context changed to 9 before child `0.0` validated the initial server projection of 3. The generated helper consequently rejected a valid input change and retired the native application.

A diagnostic-only emitter override retained the same control flow and added the expected/actual projection to the existing error. It observed child `0.0`, expected output text `3`, actual `9`, followed by complete native retirement. It did not serve as passing evidence. The exact raw observation is retained as `owner-matrix-vue-projection.log`.

The private Vue session now tracks initial owner records and defers normal current-Props application until those records have been accepted. Existing setup/created and initial view validation still run against the source-bound server inputs. Once initial adoption is complete, pending Props notifications run in parent-before-descendant order through the existing watcher policy. Closing a session drops its initial records and pending Props work before retiring owners. This selects no new transport trust policy and introduces no public target admission.

An initially absent owner must also complete its initial acceptance. Its actual initial presence is checked after created; after accepted absence it can apply current input and create a normal visible epoch. That later epoch must not compare itself with the already-accepted empty server projection. An intermediate candidate missed this final distinction and rejected output 9 against an absent record. The original failure is retained as `owner-matrix-absence-projection.log`; the corresponding final control passes.

The complete generated Vue artifact closure exposed a pre-existing strict-TypeScript defect in the encoder. Reassigning the unknown input before a stored `Array.isArray` boolean lost TypeScript's later narrowing, producing TS2339 for `length`/`map` and TS7006 for `item`. A direct `Array.isArray(value)` branch preserves the same actual data check and gives the compiler its ordinary array narrowing. No cast to an admitted data shape, broader unknown allowance or data-boundary exception was added.

## Consumer observations

The three common ownership journeys directly compare four State handles and Context value identities across a native wrapper and a nested provider. Normal updates retain State; Context values propagate within their actual provider graph. Withdrawing a view retains the root owner but retires native child owners. Re-entry creates distinct children, and a held callback from the old child refuses execution after release. Final disposal invalidates State and public methods. Explicit fresh adoption accepts current seed 9 while retaining source-bound adoption, creates a distinct owner graph, and leaves old State terminal.

The three mismatch journeys use real native effects, watchers and event listeners. Rejected adoption must leave no active probe, and old signals/events cannot trigger retired work. Explicitly selected current input then succeeds. The Vue-specific absence journey begins with an actual server absence comment and one record, then creates its visible child graph from current input. The Vue-specific partial-startup journey throws the actual falsy value `false` from the child's native event consumer, observes the parent still at initial value 3, checks terminal cleanup, and recovers with fresh input 9.

Readiness observes actual handles, rendered output and passive cleanup. It does not equate the existence of a root handle with completion of all nested framework commits. The early fixture attempts are retained: the first bundle used the repository directory instead of the compiler package's declared dependency directory; subsequent preflights identified premature reads of nested React handles, paint and passive retirement. The final parent-source replay uses the final unchanged oracle, so these earlier fixture errors are not counted as product defects.

## Verification at author freeze

| Check | Actual result |
| --- | --- |
| Matrix preflight and complete Vue artifact strict check | 9/9 pass: eight actual bundle journeys in happy-dom and one complete artifact typecheck |
| Affected existing Vue source, Context and adoption suites | 22/22 pass |
| Combined source result | 31/31 pass, no skip |
| Exact parent Vue source/support bytes substituted under the final nine assertions | 5 pass / 4 fail: fresh Context adoption, absence recovery, failure recovery and the existing encoder type errors |
| Changed production source modules and their strict dependency closure | 329 files, zero diagnostics |
| Full new fixture/production dependency-closure source typecheck | Process ended with SIGKILL / exit 137 before diagnostics; not a pass and no cause inferred |
| Actual Vue request, data-boundary and held native serializer subset | 22 pass; 65 other target cases deliberately filtered |
| Canonical SSR refusals | Four selected tests pass; 83 other cases deliberately filtered |
| Runtime planning/discovery controls | 134/134 pass; exactly one browser owner and excluded from the general phase |
| Catalog authoring | Two changed inputs against `c99a224ad2` pass; one is the already-reviewed request-owner mapping and one is this new draft test |

The actual artifact strict test covers every generated Vue support file. The limited 329-file source program checks both changed emitters without claiming that the killed broader source check passed. Full integration type gates remain required.

The runtime registration assigns the browser suite dynamically through the existing shard planner. In the authoring tree it occurs once in shard `16/18`; a later integrated inventory may rebalance it. Its unique ownership and general-phase exclusion were checked directly as well as by the 134 controls. The physical runner uses sandboxed Chromium, actual HTTP delivery of the generated bundle, source/artifact/framework hashes and separate per-case JSON/PNG evidence.

## Reproduction and custody

The final affected source command is:

```sh
corepack pnpm@10.32.1 exec vitest run \
  packages/compiler/test/owner-hydration-matrix.test.ts \
  packages/compiler/test/vue-owner-hydration.test.ts \
  packages/compiler/test/vue-context-source.test.ts \
  packages/compiler/test/vue-source.test.ts \
  --maxWorkers=1 --minWorkers=1
```

The physical successor is:

```sh
COMPILER_EVIDENCE_DIR=<absolute-evidence-directory> \
  corepack pnpm@10.32.1 exec vitest run \
  packages/compiler/test/owner-hydration-matrix.browser.test.ts \
  --maxWorkers=1 --minWorkers=1
```

Raw failures, diagnostic controls, source success, exact-parent replay, source/artifact type results, request subsets, runtime ownership and catalog output are retained in `evidence/2026-11-24-sprint5-owner-browser-matrix/author.tar.gz`; the adjacent manifest binds archive entries and final source files. The parent substitution uses the exact Vue files from reviewed tree `95576086dfad30c721b95dff5e97d4d103ba6be8`; it is a two-module counterfactual over the same final authoring tree, not a claim that every file in that historical tree was rerun.

This patch contains only the new Vue ordering/type correction and matrix/evidence additions. The previously integrated Vue native retirement and React recovery patches are its baseline. It does not reapply their historical changes.

## Remaining acceptance boundary

Independent review and the exact-source Chromium eight-case receipt remain pending at author freeze. These controlled trusted fixtures do not establish application authentication/provenance, complete compiler/helper/request compatibility governance, all native platform consumers, arbitrary runtime-State migration or every physical/assistive-technology route. The original full-target and shared-definition conditions in #895/#896 therefore remain separate. Canonical SSR still refuses admission; both owner specifications stay draft.
