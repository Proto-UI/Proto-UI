// @vitest-environment happy-dom
import { createRequire } from 'node:module';
import { posix } from 'node:path';
import { URL as NodeURL } from 'node:url';
import ts from 'typescript';
import * as Vue from 'vue';
import * as Renderer from 'vue/server-renderer';
import { expect, it } from 'vitest';
import { parsePrototype } from '../src/parser';
import { emitVueSource } from '../src/vue-source';

const floating = createRequire(new NodeURL('../../modules/positioning/package.json', import.meta.url));
const key = `import {createContextKey} from '@proto.ui/core'; export const KEY=createContextKey<{value:number}>('independent-initial-graph');`;

function modules(mutateDuringMounted: boolean) {
  const sources = new Map<string, string>();
  const authored = {
    Provider: `import {definePrototype} from '@proto.ui/core'; import {KEY} from './keys';
export default definePrototype({name:'independent-initial-provider',setup(def){
 def.context.provide(KEY,{value:0});
 def.expose.event('phase',{payload:'json'});
 def.lifecycle.onCreated(run=>{run.context.update(KEY,{value:3});run.expose.emit('phase','created');});
 def.lifecycle.onMounted(run=>{${mutateDuringMounted ? "run.context.update(KEY,{value:7});" : ''}run.expose.emit('phase','mounted');});
 def.lifecycle.onBeforeDispose(run=>run.expose.emit('phase','disposed'));
 return r=>r.el('section',{},[r.slot()]);
}});`,
    Child: `import {definePrototype} from '@proto.ui/core'; import {KEY} from './keys';
export default definePrototype({name:'independent-initial-child',setup(def){
 const value=def.state.numberDiscrete('value',0);
 def.context.subscribe(KEY,(run,next)=>{value.set(next.value);run.update();});
 def.expose.state('value',value);
 def.expose.event('phase',{payload:'json'});
 def.lifecycle.onCreated(run=>{value.set(run.context.read(KEY).value);run.expose.emit('phase','created');});
 def.lifecycle.onBeforeDispose(run=>run.expose.emit('phase','disposed'));
 return r=>r.el('output',value.get());
}});`,
  };
  for (const [name, source] of Object.entries(authored)) {
    const parsed = parsePrototype(source, { fileName: `${name}.proto.ts`, files: { 'keys.ts': key } });
    if (!parsed.ok) throw Error(JSON.stringify(parsed.diagnostics));
    const emitted = emitVueSource(parsed.value, { ssr: true, componentName: `Independent${name}` });
    if (!emitted.ok) throw Error(JSON.stringify(emitted.diagnostics));
    sources.set(`${name}.ts`, emitted.value.code);
    for (const file of emitted.value.supportingFiles ?? []) {
      const previous = sources.get(file.path);
      if (previous !== undefined && previous !== file.contents) throw Error(`conflicting support ${file.path}`);
      sources.set(file.path, file.contents);
    }
  }
  const cache = new Map<string, any>();
  function load(file: string): any {
    if (cache.has(file)) return cache.get(file);
    const input = sources.get(file); if (input === undefined) throw Error(`missing ${file}`);
    const exports = {}; cache.set(file, exports);
    const js = ts.transpileModule(input, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText;
    new Function('exports', 'require', js)(exports, (specifier: string) => {
      if (specifier === 'vue') return Vue;
      if (specifier === 'vue/server-renderer') return Renderer;
      if (specifier === '@floating-ui/dom') return floating(specifier);
      if (!specifier.startsWith('.')) throw Error(`unexpected ${specifier}`);
      const name = posix.normalize(posix.join(posix.dirname(file), specifier));
      return load(sources.has(name) ? name : `${name}.ts`);
    });
    return exports;
  }
  return { provider: load('Provider.ts'), child: load('Child.ts') };
}

it.each([false, true])('keeps the adopted graph alive with parent mounted Context mutation=%s', async (mutate) => {
  const { provider, child } = modules(mutate);
  const phase: string[] = [];
  const ref = Vue.shallowRef<any>(null);
  const rendered = await provider.renderToString({}, { slots: { default: () => [Vue.h(child.default)] } });
  expect(rendered.html).toContain('<output>3</output>');
  const host = document.createElement('div'); host.innerHTML = rendered.html; document.body.append(host);
  const app = provider.hydrate(host, rendered.handoff, {
    props: { onPhase: (value: string) => phase.push(`parent:${value}`) },
    slots: { default: () => [Vue.h(child.default, { ref, onPhase: (value: string) => phase.push(`child:${value}`) })] },
  });
  const session = app._context.provides[Symbol.for('ProtoUI.Vue.SSR.Session.v1')];
  try {
    for (let i = 0; i < 12; i++) { await Vue.nextTick(); await Promise.resolve(); }
    const observed = { closed: session.closed, failure: String(session.failure?.value), owners: session.owners.size, initial: session.initialOwners.size, phase, html: host.innerHTML };
    expect(session.closed, JSON.stringify(observed)).toBe(false);
    expect(ref.value?.getExposes().value.get()).toBe(mutate ? 7 : 3);
    expect(host.querySelector('output')?.textContent).toBe(mutate ? '7' : '3');
  } finally { try { app.unmount(); } catch {} host.remove(); }
}, 10_000);
