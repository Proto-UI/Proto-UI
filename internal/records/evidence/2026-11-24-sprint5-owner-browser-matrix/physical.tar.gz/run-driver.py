from pathlib import Path
import os,subprocess,json,datetime,sys
root=Path('/tank/shared/projects/proto-ui-agent/sprint5-f7b2/owner-matrix-543ea')
node='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin/node'
vitest='/tank/shared/projects/proto-ui-agent/sprint5-f7b2/repo/node_modules/vitest/vitest.mjs'
env=dict(os.environ,TMPDIR='/tank/shared/projects/proto-ui-agent/sprint5-f7b2/t',PROTO_UI_PLAYWRIGHT_MODULE='/tank/shared/projects/proto-ui-agent/sprint5-f7b2/repo/apps/www/node_modules/playwright-core',PROTO_UI_CHROME='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/playwright-browsers/chromium-1208/chrome-linux64/chrome')
argv=[node,vitest,'run','--config',str(root/'vitest.config.mjs'),'--maxWorkers=1','--minWorkers=1','--reporter=json','--outputFile='+str(root/'vitest.json')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root/'browser.log').open('x') as log:
 proc=subprocess.Popen(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 (root/'process.json').write_text(json.dumps({'pid':proc.pid,'startedAt':start,'argv':argv,'chromiumSandbox':True},indent=2)+'\n')
 code=proc.wait()
(root/'finished.json').write_text(json.dumps({'exitCode':code,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
sys.exit(code)
