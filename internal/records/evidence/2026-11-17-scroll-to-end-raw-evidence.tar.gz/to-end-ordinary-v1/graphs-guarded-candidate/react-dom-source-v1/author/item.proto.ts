import{definePrototype,type RunHandle}from'@proto.ui/core';import{FAMILY}from'./family';
export default definePrototype({name:'scroll-family-item',setup(def){
def.anatomy.claim(FAMILY,{role:'item'});let current:RunHandle<{}>|null=null;
def.lifecycle.onCreated(run=>{current=run;});
def.expose.method('hide',()=>current?.lifecycle.setPresent(false));
def.expose.method('show',()=>current?.lifecycle.setPresent(true));return r=>r.el('span','item');}});