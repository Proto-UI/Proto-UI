import{definePrototype,type RunHandle,type ScrollSurfaceRevealRequest}from'@proto.ui/core';
import{asScrollSurface}from'@proto.ui/hooks';import{FAMILY,OTHER}from'./family';
export default definePrototype({name:'scroll-family-surface',setup(def){
def.anatomy.claim(FAMILY,{role:'surface'});let current:RunHandle<{}>|null=null;
def.lifecycle.onCreated(run=>{current=run;});
def.expose.method('hide',()=>current?.lifecycle.setPresent(false));
def.expose.method('show',()=>current?.lifecycle.setPresent(true));
const scroll=asScrollSurface();scroll.configure({axes:'vertical',projection:'system',endFollow:{mode:'while-at-end',axis:'vertical'}});
let saved:ScrollSurfaceRevealRequest|null=null;
def.expose.method('reveal',(index:number)=>{
  if(current){const parts=current.anatomy.order.partsOf(FAMILY,'item');const part=index===0?parts[0]:index===1?parts[1]:parts[2];
    if(part)return scroll.request({kind:'reveal',axis:'vertical',family:FAMILY,part});}
  return {kind:'rejected',reason:'unavailable'};
});
def.expose.method('revealOther',(index:number)=>{
  if(current){const parts=current.anatomy.order.partsOf(FAMILY,'item');const part=index===0?parts[0]:index===1?parts[1]:parts[2];
    if(part)return scroll.request({kind:'reveal',axis:'vertical',family:OTHER,part});}
  return {kind:'rejected',reason:'unavailable'};
});
def.expose.method('revealSelf',()=>{
  if(current){const index=current.anatomy.order.indexOfSelf(FAMILY,'surface');const parts=current.anatomy.order.partsOf(FAMILY,'surface');const part=index===0?parts[0]:index===1?parts[1]:parts[2];
    if(part)return scroll.request({kind:'reveal',axis:'vertical',family:FAMILY,part});}
  return {kind:'rejected',reason:'unavailable'};
});
def.expose.method('revealSurface',(index:number)=>{
  if(current){const parts=current.anatomy.order.partsOf(FAMILY,'surface');const part=index===0?parts[0]:index===1?parts[1]:parts[2];
    if(part)return scroll.request({kind:'reveal',axis:'vertical',family:FAMILY,part});}
  return {kind:'rejected',reason:'unavailable'};
});
def.expose.method('capture',(index:number)=>{
  if(current){const parts=current.anatomy.order.partsOf(FAMILY,'item');const part=index===0?parts[0]:index===1?parts[1]:parts[2];
    if(part){const request:ScrollSurfaceRevealRequest={kind:'reveal',axis:'vertical',family:FAMILY,part};saved=request;}}
});
def.expose.method('revealSaved',()=>{if(saved)return scroll.request(saved);return{kind:'rejected',reason:'unavailable'};});
let completionArmed=false;
let completionVisits=0;
let completionBeforeAtEnd=false;
let completionBeforeState='';
let completionAfterAtEnd=false;
let completionAfterState='';
let completionNestedKind='';
scroll.endFollow.requestStatus.watch((run,event)=>{
  if(event.type!=='next'||event.next!=='applied'||!completionArmed)return;
  completionArmed=false;
  completionVisits=completionVisits+1;
  completionBeforeAtEnd=scroll.vertical.atEnd.get();
  completionBeforeState=scroll.endFollow.state.get();
  const parts=run.anatomy.order.partsOf(FAMILY,'item');
  const part=parts[0];
  if(part){const outcome=scroll.request({kind:'reveal',axis:'vertical',family:FAMILY,part});completionNestedKind=outcome.kind;}
  completionAfterAtEnd=scroll.vertical.atEnd.get();
  completionAfterState=scroll.endFollow.state.get();
});
def.expose.method('armCompletionReveal',()=>{completionArmed=true;});
def.expose.method('requestEnd',()=>scroll.request({kind:'to-end',axis:'vertical'}));
def.expose.method('readCompletionTrace',()=>({visits:completionVisits,beforeAtEnd:completionBeforeAtEnd,beforeState:completionBeforeState,nestedKind:completionNestedKind,afterAtEnd:completionAfterAtEnd,afterState:completionAfterState}));
def.expose.method('read',()=>scroll.getSnapshot());
return r=>r.slot();}});