import{definePrototype}from'@proto.ui/core';import{FAMILY}from'./family';
export default definePrototype({name:'scroll-family-root',setup(def){
def.anatomy.claim(FAMILY,{role:'root'});return r=>r.slot();}});