// Editable generated React DOM source. Profile: react-dom-source-v1.
// Inline owner lowering and emitted shared checked-data/Context helpers v1; no Proto-UI Runtime/Core/Adapter dependencies.
// Source graph SHA-256: ee2f50abdc8601b58803b59edf3deb2864e210a628c418caec37f95fd68b29f2
import * as __puiReact from 'react';



import { createPortal as __puiCreatePortal } from 'react-dom';


import { createContextScope as __puiCreateContextScope, acceptsContextValue as __puiAccepts } from "./.proto-ui/context/scope-v1";
import type { ContextScope as __puiContextScope } from "./.proto-ui/context/scope-v1";
import { ContextTransport as __puiContextTransport } from './.proto-ui/context/react-v1';

import { createNativeInteraction as __puiCreateNativeInteraction, type NativeInteraction as __puiNativeInteraction, type NativeFocus as __puiNativeFocus, type NativeAccessible as __puiNativeAccessible, type NativeObservedState as __puiNativeObservedState, type NativeInput as __puiNativeInput, type NativeFocusOptions as __puiNativeFocusOptions } from './.proto-ui/interaction/native-5e2b22a9a4480de7-v2';
import type { NativeModuleCapability as __puiNativeModuleCapability } from './.proto-ui/interaction/modules-5e2b22a9a4480de7-v2';

import { declaration as __puiDeclaration0 } from "./.proto-ui/declaration/anatomy/family-9cce0127f15063f6a64b4e541aa9d587";
import { declaration as __puiDeclaration1 } from "./.proto-ui/declaration/anatomy/family-6cd0be0b284d3faa349f16ea9900e0c1";


export type GeneratedProps = {

};
export type GeneratedExposes = {
  "hide": () => void;
  "show": () => void;
};
export type GeneratedComponentProps = GeneratedProps & {
  children?: __puiReact.ReactNode;
  instanceAssociations?: Readonly<{ controlLabel?: object | null }>;

  [event: `on${string}`]: unknown;
};
export interface GeneratedHandle {
  update(): void;
  getExposes(): GeneratedExposes;
  invokeInCallbackScope<T>(callback: () => T): T;
}
type __puiResolvedProps = Readonly<{  }>;
type __puiStateEvent<T> = { type: 'next'; prev: T; next: T; reason?: unknown } | { type: 'disconnect'; reason: 'unmount' };
type __puiExternalState<T> = {
  get(): T;
  subscribe(callback: (event: __puiStateEvent<T>) => void): () => void;
  unsubscribe(off: () => void): void;
  readonly spec: Readonly<__puiStateSpec>;
};
type __puiState<T> = { get(): T; setDefault(value: T): void; set(value: T, reason?: unknown): void };
type __puiStateSpec = { kind: 'bool' | 'enum' | 'string' | 'number.discrete' | 'number.range'; options?: readonly (string | number)[]; min?: number; max?: number; step?: number; clamp?: boolean };
type __puiDataSchema = string | { kind: string; fields?: readonly { name: string; type: __puiDataSchema; optional?: boolean }[]; element?: __puiDataSchema; members?: readonly __puiDataSchema[]; value?: unknown };
type __puiPropSpec = { type: __puiDataSchema; default?: unknown; empty?: 'accept' | 'fallback' | 'error'; options?: readonly string[]; range?: { min?: number; max?: number } };
type __puiRun = {
  update(): void;

  props: { get(): __puiResolvedProps; getRaw(): Readonly<Record<string, unknown>>; isProvided(key: string): boolean };
  context: {
    read<T>(key: object): T;
    tryRead<T>(key: object): T | null;
    update<T>(key: object, next: T | ((prev: T) => T)): void;
    tryUpdate<T>(key: object, next: T | ((prev: T) => T)): boolean;
  };
  expose: { emit(key: string, payload?: unknown, options?: Record<string, unknown>): void };
  lifecycle: { setPresent(present: boolean): void };
};
type __puiFrame = { revision: number; epoch: number; kind: 'mount' | 'update' | 'detach'; node: __puiReact.ReactNode };
type __puiOwner = {
  handle: GeneratedHandle;
  scope: __puiContextScope;
  getHostProjection(): { tag: string; properties: Readonly<Record<string, string | number | boolean | null>>; portalTarget: HTMLElement | null };
  bindRoot(root: HTMLElement | null): void;
  connect(): void;
  connectView(): void;
  disconnectView(): void;
  start(): void;
  applyProps(props: GeneratedComponentProps): void;
  accept(frame: __puiFrame): boolean;
  disconnect(): void;

};

const __puiSlots = new WeakSet<object>();
function __puiBindSlots(node: __puiReact.ReactNode, slot: __puiReact.ReactNode): __puiReact.ReactNode {
  if (Array.isArray(node)) {
    let result: __puiReact.ReactNode[] | null = null;
    for (let index = 0; index < node.length; index++) {
      const child = __puiBindSlots(node[index], slot);
      if (child !== node[index]) { result ??= node.slice(); result[index] = child; }
    }
    return result ?? node;
  }
  if (!__puiReact.isValidElement(node)) return node;
  const element = node as __puiReact.ReactElement<{ children?: __puiReact.ReactNode }>;
  if (__puiSlots.has(element)) return __puiReact.createElement(__puiReact.Fragment, { key: element.key }, slot);
  const previous = element.props.children, next = __puiBindSlots(previous, slot);
  return previous === next ? node : __puiReact.cloneElement(element, undefined, next);
}
function __puiRootProperties(properties: Readonly<Record<string, unknown>>): Record<string, unknown> {
  const result: Record<string, unknown> = { ...properties };
  // Native TextControl owns subsequent value writes and IME restoration. React
  // supplies only the initial value, avoiding a competing controlled writer.
  if (Object.hasOwn(result, 'value')) { result.defaultValue = result.value; delete result.value; }
  if (typeof result.style === 'string') {
    const style: Record<string, string> = {};
    for (const declaration of result.style.split(';')) {
      const colon = declaration.indexOf(':');
      if (colon < 1) continue;
      const name = declaration.slice(0, colon).trim();
      style[name.startsWith('--') ? name : name.replace(/-([a-z])/g, (_match, letter: string) => letter.toUpperCase())] = declaration.slice(colon + 1).trim();
    }
    result.style = style;
  }
  return result;
}
function __puiHasRootContent(node: __puiReact.ReactNode): boolean {
  if (node === null || node === undefined || typeof node === 'boolean' || node === '') return false;
  if (Array.isArray(node)) return node.some(__puiHasRootContent);
  if (__puiReact.isValidElement(node) && node.type === __puiReact.Fragment)
    return __puiHasRootContent((node.props as { children?: __puiReact.ReactNode }).children);
  return true;
}
function __puiRenderRoot(tag: string, attributes: Record<string, unknown>, children: __puiReact.ReactNode): __puiReact.ReactElement {
  if (tag === 'input' || tag === 'textarea' || tag === 'img') {
    if (__puiHasRootContent(children)) throw new TypeError('[Template] this physical control Root cannot contain semantic children.');
    return __puiReact.createElement(tag, attributes);
  }
  return __puiReact.createElement(tag, attributes, children);
}

function __puiResolveProps(
  specs: Readonly<Record<string, __puiPropSpec>>,
  defaults: readonly Readonly<Record<string, unknown>>[],
  previousValid: Record<string, unknown>,
  raw: Readonly<Record<string, unknown>>,
  strict: boolean
): __puiResolvedProps {
  const next: Record<string, unknown> = Object.create(null);
  for (const key of Object.keys(specs)) {
    const spec = specs[key];
    const provided = Object.hasOwn(raw, key);
    const value = raw[key];
    const empty = value === null || value === undefined;
    const valid = (candidate: unknown) => __puiAccepts(spec.type, candidate)
      && (!spec.range || typeof candidate === 'number'
        && candidate >= (spec.range.min ?? -Infinity) && candidate <= (spec.range.max ?? Infinity));
    if (provided && !empty && valid(value)) {
      next[key] = value;
      previousValid[key] = value;
      continue;
    }
    if (provided && empty && spec.empty === 'accept') { next[key] = null; continue; }
    const nonEmpty = strict && spec.empty === 'error';
    let found = false;
    const take = (candidate: unknown) => {
      if (candidate === undefined || nonEmpty && candidate === null) return false;
      if (candidate !== null && !valid(candidate)) return false;
      next[key] = candidate;
      found = true;
      return true;
    };
    if (provided && Object.hasOwn(previousValid, key)) take(previousValid[key]);
    if (!found) for (const layer of defaults) if (Object.hasOwn(layer, key) && take(layer[key])) break;
    if (!found && Object.hasOwn(spec, 'default')) take(spec.default);
    if (!found) {
      if (nonEmpty) throw new Error('[Props] missing, empty or invalid prop without non-empty fallback: ' + key);
      next[key] = null;
    }
    if (provided && next[key] !== null) previousValid[key] = next[key];
  }
  return Object.freeze(next) as __puiResolvedProps;
}

function __puiCreateOwner(initial: GeneratedComponentProps, publish: (frame: __puiFrame) => void, getParent: () => __puiContextScope | null, publishHost: () => void): __puiOwner {
  let phase: 'setup' | 'callback' | 'render' | 'idle' = 'setup';
  let lifetime: 'alive' | 'disposing' | 'disposed' = 'alive';
  let connected = true;
  let cleanupVersion = 0;
  let desiredPresent = true;
  let mounted = false;
  let viewConnected = false;
  let epoch = 0;
  let revision = 0;
  let acceptedRevision = 0;
  let latest: __puiFrame | null = null;
  let dirty = false;
  let updateQueued = false;
  let scheduled = false;
  let hostScheduled = false;
  let callbackDepth = 0;
  let slotUsed = false;
  let elementSequence = 0;
  let hostProps = initial;
  let root: HTMLElement | null = null;
  let raw: Readonly<Record<string, unknown>> = Object.freeze({});
  let resolved: __puiResolvedProps;
  let hydrated = false;
  let propsWindow: { raw: Readonly<Record<string, unknown>>; resolved: __puiResolvedProps } | null = null;
  const specs: Record<string, __puiPropSpec> = Object.create(null);
  const defaults: Readonly<Record<string, unknown>>[] = [];
  const previousValid: Record<string, unknown> = Object.create(null);
  const stateNames = new Set<string>();
  // Reserve before setup; only successful setup publishes a reusable opaque result.

  const stateSubscribers = new Set<Set<(event: __puiStateEvent<unknown>) => void>>();
  const pendingStateEvents: (() => void)[] = [];
  const authorStateWatchCleanups: (() => void)[] = [];
  let emittingState = false;
  type __puiResolvedWatcher = { active: boolean; keys: readonly string[] | null; callback: (run: __puiRun, next: __puiResolvedProps, prev: __puiResolvedProps, info: Readonly<Record<string, unknown>>) => void };
  type __puiRawWatcher = { active: boolean; keys: readonly string[] | null; callback: (run: __puiRun, next: Readonly<Record<string, unknown>>, prev: Readonly<Record<string, unknown>>, info: Readonly<Record<string, unknown>>) => void };
  const watchers: __puiResolvedWatcher[] = [];
  const rawWatchers: __puiRawWatcher[] = [], rawAllWatchers: __puiRawWatcher[] = [];
  const exposes: Record<string, unknown> = Object.create(null);
  const methodSchemas: Record<string, { args(args: unknown[]): boolean; result(value: unknown): boolean }> = {
    "hide": { args: (args: unknown[]) => args.length <= 0, result: (result: unknown) => __puiAccepts("void", result) },
    "show": { args: (args: unknown[]) => args.length <= 0, result: (result: unknown) => __puiAccepts("void", result) },
  };
  const eventSchemas: Record<string, __puiDataSchema> = {

  };
  const propSchemas: Record<string, __puiDataSchema> = {

  };
  const callbacks = {
    created: [] as ((run: __puiRun) => void)[], mounted: [] as ((run: __puiRun) => void)[],
    updated: [] as ((run: __puiRun) => void)[], unmounted: [] as ((run: __puiRun) => void)[],
    beforeDispose: [] as ((run: __puiRun) => void)[],
  };
  function ensureAlive() {
    if (lifetime === 'disposed' || !connected && phase !== 'callback')
      throw new Error('Generated handle is invalid after terminal disposal.');
  }
  function ensurePhase(expected: typeof phase) {
    ensureAlive();
    if (phase !== expected) throw new Error('Illegal generated operation phase: ' + phase + '; expected ' + expected);
  }
  function ensureExternal() {
    if (!connected || lifetime !== 'alive') throw new Error('Generated handle is invalid after terminal disposal begins.');
  }
  function invoke<T>(callback: () => T): T {
    ensureAlive();
    if (phase === 'render' || phase === 'setup') throw new Error('Cannot enter callback scope from ' + phase);
    const previous = phase;
    phase = 'callback';
    ++callbackDepth;
    try { return callback(); }
    finally { phase = previous; --callbackDepth; if (!callbackDepth) schedule(); }
  }
  

  
  const context = __puiCreateContextScope({
    getParent, isAlive: () => lifetime !== 'disposed', invoke,
    validate: (key: object, value: unknown): boolean => false,
  });
  function dispatch(list: readonly ((run: __puiRun) => void)[]) {
    if (list === callbacks.unmounted) {  }
    try { invoke(() => { for (const callback of list) callback(__puiRunHandle); }); }
    finally { if (list === callbacks.unmounted) {  } }
  }
  function schedule() {
    if (scheduled || callbackDepth || !connected || lifetime !== 'alive') return;
    if (!updateQueued && desiredPresent === mounted && !(!desiredPresent && root) && !(latest && latest.revision > acceptedRevision)) return;
    scheduled = true;
    queueMicrotask(() => {
      scheduled = false;
      if (!connected || lifetime !== 'alive') return;
      if (latest && latest.revision > acceptedRevision) return;
      if (!desiredPresent) {
        if (mounted || root) deliver('detach');
        else { dirty = dirty || updateQueued; updateQueued = false; }
      } else if (!mounted) deliver('mount');
      else if (updateQueued) deliver('update');
    });
  }
  function deliver(kind: __puiFrame['kind']) {
    updateQueued = false;
    let node: __puiReact.ReactNode = null;
    if (kind === 'mount') ++epoch;
    if (kind !== 'detach') {
      slotUsed = false;
      elementSequence = 0;
      phase = 'render';
      try { node = normalize(render(__puiRenderer)); }
      finally { phase = 'idle'; }
      dirty = false;
    }
    latest = { revision: ++revision, epoch, kind, node };
    publish(latest);
  }
  function normalize(value: unknown): __puiReact.ReactNode {
    if (value === null) return null;
    if (Array.isArray(value)) return value.flatMap((item) => {
      const child = normalize(item);
      return child === null ? [] : [child];
    });
    if (typeof value === 'string' || typeof value === 'number' && Number.isFinite(value) || __puiReact.isValidElement(value)) return value;
    throw new Error('[Template] child must be null, text, a finite number or an authored element/slot.');
  }
  function __puiElement(tag: string, ...args: unknown[]) {
    ensurePhase('render');
    if (!tag || typeof tag !== 'string') throw new Error('[Template] native elements require a tag string.');
    let children: unknown = null;
    let props: Record<string, unknown> = {};
    if (args.length === 1) {
      const argument = args[0];
      if (argument !== null && typeof argument === 'object' && !Array.isArray(argument) && !__puiReact.isValidElement(argument)) {
        props = argument as Record<string, unknown>;
      } else children = argument;
    } else if (args.length === 2) {
      if (!args[0] || typeof args[0] !== 'object' || Array.isArray(args[0]))
        throw new Error('[Template] native template props must be a record.');
      props = args[0] as Record<string, unknown>;
      children = args[1];
    }
    if (Object.keys(props).some((key) => key !== 'style'))
      throw new Error('[Template] native template props support only style.');
    if (Object.hasOwn(props, 'style')) throw new Error('[Template] style requires an admitted style handle.');
    const tokens = '';
    const normalized = normalize(children);
    return __puiReact.createElement(tag, { key: elementSequence++, ...(tokens ? { 'data-pui-style': tokens } : {}) }, ...(Array.isArray(normalized) ? normalized : [normalized]));
  }
  const __puiRenderer = {
    read: Object.freeze({
      props: Object.freeze({
        get() { ensurePhase('render'); return resolved; },
        getRaw() { ensurePhase('render'); return raw; },
        isProvided(key: string) { ensurePhase('render'); return Object.hasOwn(raw, key); },
      }),
      context: Object.freeze({
        read<T>(key: object): T { ensurePhase('render'); return context.read<T>(key); },
        tryRead<T>(key: object): T | null { ensurePhase('render'); return context.tryRead<T>(key); },
      }),
    }),
    el: __puiElement,
    slot: () => {
      ensurePhase('render');
      if (slotUsed) throw new Error('[Template] multiple anonymous slots are not supported.');
      slotUsed = true;
      const slot = __puiReact.createElement(__puiReact.Fragment, { key: elementSequence++ });
      __puiSlots.add(slot);
      return slot;
    },
  };
  function __puiCreateState<T extends boolean | string | number>(name: string, initialValue: T, spec: __puiStateSpec): __puiState<T> {
    ensurePhase('setup');
    if (typeof name !== 'string' || name.length === 0 || stateNames.has(name)) throw new Error('[State] illegal or duplicate state name: ' + name);
    spec = Object.freeze({ ...spec, ...(spec.options ? { options: Object.freeze([...spec.options]) } : {}) });
    const type = spec.kind === 'bool' ? 'boolean' : spec.kind === 'string' || spec.kind === 'enum' ? 'string' : 'number';
    if (spec.options?.some((option) => typeof option !== type || typeof option === 'number' && !Number.isFinite(option)))
      throw new Error('[State] invalid state options: ' + name);
    if (spec.kind === 'number.range' && (!Number.isFinite(spec.min) || !Number.isFinite(spec.max))
      || spec.min !== undefined && !Number.isFinite(spec.min) || spec.max !== undefined && !Number.isFinite(spec.max)
      || spec.min !== undefined && spec.max !== undefined && spec.min > spec.max
      || spec.step !== undefined && !Number.isFinite(spec.step))
      throw new Error('[State] invalid numeric domain: ' + name);
    function validate(next: T) {
      if (typeof next !== type || typeof next === 'number' && !Number.isFinite(next))
        throw new TypeError('[State] invalid state value: ' + name);
      if (spec.kind === 'enum' && !spec.options?.includes(next as string)) throw new Error('[State] enum value outside options: ' + name);
      if (spec.options?.length && (spec.kind === 'enum' || spec.kind === 'string' || spec.kind === 'number.discrete')) {
        if (!spec.options.includes(next as string | number)) throw new Error('[State] state value outside options: ' + name);
        return;
      }
      if (typeof next !== 'number') return;
      if (next < (spec.min ?? -Infinity) || next > (spec.max ?? Infinity))
        throw new Error('[State] state value outside range: ' + name);
      if (spec.kind === 'number.discrete' && spec.step !== undefined && spec.step > 0
        && !Number.isInteger((next - (spec.min ?? 0)) / spec.step))
        throw new Error('[State] state value violates step: ' + name);
    }
    let value = initialValue;
    // Core range clamping normalizes definition defaults only, never callback writes.
    if (spec.kind === 'number.range' && spec.clamp && typeof value === 'number' && Number.isFinite(value))
      value = Math.min(spec.max!, Math.max(spec.min!, value)) as T;
    validate(value);
    stateNames.add(name);
    const subscribers = new Set<(event: __puiStateEvent<T>) => void>();
    stateSubscribers.add(subscribers as Set<(event: __puiStateEvent<unknown>) => void>);
    const state = {
      get() { ensureAlive(); return value; },
      setDefault(next: T) { ensurePhase('setup'); validate(next); value = next; },
      set(next: T, reason?: unknown) {
        ensurePhase('callback');
        validate(next);
        if (Object.is(value, next)) return;
        const event: __puiStateEvent<T> = { type: 'next', prev: value, next, reason };
        value = next;

        __puiInteraction.refresh();
        for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(pendingStateEvents, pendingStateEvents.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!emittingState) {
  emittingState = true;
  const notificationFailures: unknown[] = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < pendingStateEvents.length) {
      try { pendingStateEvents[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { pendingStateEvents.length = 0; emittingState = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
      },
    };
    const external: __puiExternalState<T> = Object.freeze({
      get() { ensureExternal(); return state.get(); },
      subscribe(callback: (event: __puiStateEvent<T>) => void) {
        ensureExternal(); const registration: typeof callback = event => callback(event); subscribers.add(registration); return () => { subscribers.delete(registration); };
      },
      unsubscribe(off: () => void) { off(); },
      spec: Object.freeze(spec),
    });
    externalStates.set(state, external);

    return state;
  }
  const externalStates = new WeakMap<object, unknown>();
  const observedStateCleanups: (() => void)[] = [];
  function registerObservedState<T extends boolean | string | number>(state: __puiNativeObservedState<T>) {
    const subscribers = new Set<(event: __puiStateEvent<T>) => void>();
    stateSubscribers.add(subscribers as Set<(event: __puiStateEvent<unknown>) => void>);
    observedStateCleanups.push(state.subscribe((event) => {

      __puiInteraction.refresh();
      for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(pendingStateEvents, pendingStateEvents.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!emittingState) {
  emittingState = true;
  const notificationFailures: unknown[] = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < pendingStateEvents.length) {
      try { pendingStateEvents[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { pendingStateEvents.length = 0; emittingState = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
    }));
    const kind = typeof state.get();
    const external: __puiExternalState<T> = Object.freeze({
      get() { ensureExternal(); return state.get(); },
      subscribe(callback: (event: __puiStateEvent<T>) => void) {
        ensureExternal(); const registration: typeof callback = event => callback(event); subscribers.add(registration); return () => { subscribers.delete(registration); };
      },
      unsubscribe(off: () => void) { off(); },
      spec: Object.freeze({ kind: kind === 'boolean' ? 'bool' as const : kind === 'number' ? 'number.discrete' as const : 'string' as const }),
    });
    externalStates.set(state, external);
  }
  const __puiInteraction: __puiNativeInteraction<__puiRun> = __puiCreateNativeInteraction<__puiRun>({
    ensureSetup: () => ensurePhase('setup'),
    ensureRuntime: () => ensurePhase('callback'),
    ensureEvent: () => ensurePhase('callback'),
    isAlive: () => lifetime !== 'disposed',
    isSetupComplete: () => phase !== 'setup',
    isReady: () => phase !== 'setup' && mounted && viewConnected && desiredPresent && connected && lifetime === 'alive',
    invoke,
    getRun: () => __puiRunHandle,
    getResolvedProps: () => resolved,

    subscribeState(state, callback) { return (externalStates.get(state) as __puiExternalState<unknown> | undefined)?.subscribe(callback) ?? (state as __puiNativeObservedState<unknown>).subscribe(callback); },
    getRoot: () => viewConnected ? root : null,
    identity: context,
    getLogicalParent: getParent,
    declarations: [],
    tableFamily: undefined,
    getExposes: () => exposes,
    registerExpose(key, value) {
      const state = value && typeof value === 'object' ? externalStates.get(value) : undefined;
      if (state) registerExpose(key, state);
      else if (typeof value === 'function') registerExpose(key, (...args: unknown[]) => { ensureExternal(); return invoke(() => value(...args)); });
      else registerExpose(key, value);
    },
    createOwnedState: <T extends boolean | string | number>(name: string, value: T, spec?: __puiStateSpec) => __puiCreateState(name, value, spec ?? { kind: typeof value === 'boolean' ? 'bool' : typeof value === 'number' ? 'number.discrete' : 'string' }),
    watchState<T>(state: {get(): T}, callback: (run: __puiRun, event: __puiStateEvent<T>) => void) {
      ensurePhase('setup');
      const external = externalStates.get(state) as __puiExternalState<T>;
      if (!external) throw new Error('[State] foreign watch target');
      const off = external.subscribe(event => invoke(() => callback(__puiRunHandle, event)));
      authorStateWatchCleanups.push(off); return off;
    },
    isPropProvided: key => Object.hasOwn(raw, key),
    setPresent: value => __puiRunHandle.lifecycle.setPresent(value),
    requestHostUpdate() {
      if (hostScheduled || lifetime !== 'alive') return;
      hostScheduled = true;
      queueMicrotask(() => { hostScheduled = false; if (connected && lifetime === 'alive') publishHost(); });
    },
    registerGenericObservedState: registerObservedState,
    emit: key => __puiRunHandle.expose.emit(key),
  });
  function disposeInteraction() {
    try { __puiInteraction.dispose(); }
    finally { for (const off of observedStateCleanups.splice(0)) off(); for (const off of authorStateWatchCleanups.splice(0)) off(); }
  }
  const __puiRunHandle: __puiRun = {

    update() {
      ensurePhase('callback');
      if (lifetime !== 'alive') return;
      dirty = true;
      if (desiredPresent && mounted) updateQueued = true;
      schedule();
    },
    props: {
      get() { ensureAlive(); return propsWindow?.resolved ?? resolved; },
      getRaw() { ensureAlive(); return propsWindow?.raw ?? raw; },
      isProvided(key: string) { ensureAlive(); return Object.hasOwn(propsWindow?.raw ?? raw, key); },
    },
    context: Object.freeze({
      read<T>(key: object): T { ensurePhase('callback'); return context.read<T>(key); },
      tryRead<T>(key: object): T | null { ensurePhase('callback'); return context.tryRead<T>(key); },
      update<T>(key: object, next: T | ((prev: T) => T)) { ensurePhase('callback'); context.update(key, next); },
      tryUpdate<T>(key: object, next: T | ((prev: T) => T)) { ensurePhase('callback'); return context.tryUpdate(key, next); },
    }),
    expose: { emit(key, payload, options) {
      ensurePhase('callback');
      const declaration = exposes[key] as { kind?: string; payload: __puiDataSchema } | undefined;
      if (declaration?.kind !== 'event') throw new Error('[Expose] event was not declared: ' + key);
      if (!__puiAccepts(declaration.payload, payload)) throw new TypeError('[Expose] invalid event payload: ' + key);
      const sink = (hostProps as Record<string, unknown>)['on' + key.charAt(0).toUpperCase() + key.slice(1)];
      if (typeof sink === 'function') { try { sink(payload, options); } catch { /* Host sink failures do not re-enter prototype execution. */ } }
    } },
    lifecycle: { setPresent(present) {
      ensurePhase('callback');
      if (lifetime !== 'alive') throw new Error('[Lifecycle] cannot update view presence after terminal disposal begins.');
      if (typeof present !== 'boolean') throw new Error('[Lifecycle] view presence must be boolean.');
      if (desiredPresent === present) return;
      desiredPresent = present;
      schedule();
    } },
  };
  function registerExpose(key: string, value: unknown) {
    ensurePhase('setup');
    if (!key || Object.hasOwn(exposes, key)) throw new Error('[Expose] empty or duplicate declaration: ' + key);
    exposes[key] = value;
  }
  const __puiDef = {

    context: Object.freeze({
      provide<T>(key: object, value: T) { ensurePhase('setup'); context.provide(key, value); },
      subscribe<T>(key: object, callback?: (run: __puiRun, next: T, prev: T) => void) {
        ensurePhase('setup');
        return context.subscribe<T>(key, 'required', callback ? (next, prev) => callback(__puiRunHandle, next as T, prev as T) : undefined);
      },
      trySubscribe<T>(key: object, callback?: (run: __puiRun, next: T | null, prev: T | null) => void) {
        ensurePhase('setup');
        return context.subscribe<T>(key, 'optional', callback ? (next, prev) => callback(__puiRunHandle, next, prev) : undefined);
      },
    }),
    props: {
      define(incoming: Record<string, Omit<__puiPropSpec, 'type'> & { type: __puiDataSchema | 'enum' | 'object' | 'any' }>) {
        ensurePhase('setup');
        const next = { ...specs };
        for (const [key, authored] of Object.entries(incoming)) {
          const schema = propSchemas[key];
          if (!schema) throw new Error('[Props] missing checked declaration: ' + key);
          const spec: __puiPropSpec = { ...authored, type: schema };
          const previous = specs[key];
          if (!previous) { next[key] = { ...spec }; continue; }
          const rank = (empty: __puiPropSpec['empty']) => empty === 'accept' ? 0 : empty === 'error' ? 2 : 1;
          if (JSON.stringify(previous.type) !== JSON.stringify(spec.type) || Object.hasOwn(spec, 'empty') && rank(spec.empty) > rank(previous.empty)
            || previous.range && spec.range && ((spec.range.min ?? -Infinity) > (previous.range.min ?? -Infinity)
              || (spec.range.max ?? Infinity) < (previous.range.max ?? Infinity)))
            throw new Error('[Props] conflicting or stricter prop definition: ' + key);
          next[key] = { ...previous, ...spec, empty: previous.empty ?? 'fallback', range: spec.range ?? previous.range };
          if (Object.hasOwn(previous, 'default')) next[key].default = previous.default;
        }
        Object.assign(specs, next);
        resolved = __puiResolveProps(specs, defaults, previousValid, raw, false);
        __puiInteraction.refresh();
      },
      setDefaults(partial: Record<string, unknown>) {
        ensurePhase('setup');
        for (const key of Object.keys(partial)) if (!Object.hasOwn(specs, key)) throw new Error('[Props] undeclared default key: ' + key);
        defaults.unshift({ ...partial });
        resolved = __puiResolveProps(specs, defaults, previousValid, raw, false);
        __puiInteraction.refresh();
      },
      watch(keys: readonly string[], callback: (run: __puiRun, next: __puiResolvedProps, prev: __puiResolvedProps, info: Readonly<Record<string, unknown>>) => void) {
        ensurePhase('setup');
        if (!keys.length || keys.some((key) => !Object.hasOwn(specs, key))) throw new Error('[Props] watchers require declared keys.');
        const watcher = { keys: [...keys], callback, active: true };
        watchers.push(watcher);
        return () => { watcher.active = false; };
      },
      watchAll(callback: __puiResolvedWatcher['callback']) {
        ensurePhase('setup');
        const watcher: __puiResolvedWatcher = { keys: null, callback, active: true };
        watchers.push(watcher);
        return () => { watcher.active = false; };
      },
      watchRaw(keys: readonly string[], callback: __puiRawWatcher['callback']) {
        ensurePhase('setup');
        if (!keys.length || keys.some(key => typeof key !== 'string' || !key.length)) throw new Error('[Props] raw watchers require nonempty keys.');
        const watcher: __puiRawWatcher = { keys: [...keys], callback, active: true };
        rawWatchers.push(watcher);
        return () => { watcher.active = false; };
      },
      watchRawAll(callback: __puiRawWatcher['callback']) {
        ensurePhase('setup');
        const watcher: __puiRawWatcher = { keys: null, callback, active: true };
        rawAllWatchers.push(watcher);
        return () => { watcher.active = false; };
      },
    },
    state: {
      bool: (name: string, value: boolean) => __puiCreateState(name, value, { kind: 'bool' }),
      string: (name: string, value: string, spec: Omit<__puiStateSpec, 'kind'> = {}) => __puiCreateState(name, value, { kind: 'string', ...spec }),
      enum: (name: string, value: string, spec: { options: readonly string[] }) => __puiCreateState(name, value, { kind: 'enum', ...spec }),
      numberDiscrete: (name: string, value: number, spec: Omit<__puiStateSpec, 'kind'> = {}) => __puiCreateState(name, value, { kind: 'number.discrete', ...spec }),
      numberRange: (name: string, value: number, spec: Omit<__puiStateSpec, 'kind'>) => __puiCreateState(name, value, { kind: 'number.range', ...spec }),
    },
    expose: {
      value: registerExpose,
      state(key: string, state: object) {
        const external = externalStates.get(state);
        if (!external) throw new Error('[Expose] state must belong to this instance.');
        registerExpose(key, external);
      },
      event(key: string, _spec: { payload?: 'void' | 'any' | 'json'; options?: Readonly<Record<string, unknown>> } = {}) {
        if (!Object.hasOwn(eventSchemas, key)) throw new Error('[Expose] missing checked event schema: ' + key);
        registerExpose(key, Object.freeze({ kind: 'event', payload: eventSchemas[key] }));
      },
      method<A extends unknown[], R>(key: string, callback: (...args: A) => R, project?: (value: R) => R) {

        registerExpose(key, (...args: A): R => {
          ensureExternal();
          return invoke(() => {
          const schema = methodSchemas[key];
          if (!schema || !schema.args(args))
            throw new TypeError('[Expose] invalid method arguments: ' + key);
          const result = callback(...args);
          if (!schema.result(result)) throw new TypeError('[Expose] invalid method result: ' + key);
          return project ? project(result) : result;
          });
        });
      },
    },
    lifecycle: {
      onCreated(callback: (run: __puiRun) => void) { ensurePhase('setup'); callbacks.created.push(callback); },
      onMounted(callback: (run: __puiRun) => void) { ensurePhase('setup'); callbacks.mounted.push(callback); },
      onUpdated(callback: (run: __puiRun) => void) { ensurePhase('setup'); callbacks.updated.push(callback); },
      onUnmounted(callback: (run: __puiRun) => void) { ensurePhase('setup'); callbacks.unmounted.push(callback); },
      onBeforeDispose(callback: (run: __puiRun) => void) { ensurePhase('setup'); callbacks.beforeDispose.push(callback); },
    },
  };

  let render: (renderer: typeof __puiRenderer) => unknown;
  try {
    render = ((def: typeof __puiDef) => {
    // Source "item.proto.ts":3:1
    __puiInteraction.anatomy.claim(__puiDeclaration0, { "role": "item" });
    // Source "item.proto.ts":3:45
    let current: (__puiRun) | (null) = (null as (__puiRun) | (null));
    // Source "item.proto.ts":4:1
    def.lifecycle.onCreated((run: __puiRun) => {
      // Source "item.proto.ts":4:31
      (current = run);
    });
    // Source "item.proto.ts":5:1
    def.expose.method("hide", (): void => {
      // Source "item.proto.ts":5:30
      return ((__puiOptionalReceiver: (__puiRun) | (null)) => __puiOptionalReceiver == null ? undefined : __puiOptionalReceiver.lifecycle.setPresent(false))(current);
    });
    // Source "item.proto.ts":6:1
    def.expose.method("show", (): void => {
      // Source "item.proto.ts":6:30
      return ((__puiOptionalReceiver: (__puiRun) | (null)) => __puiOptionalReceiver == null ? undefined : __puiOptionalReceiver.lifecycle.setPresent(true))(current);
    });
    // Source "item.proto.ts":6:67
    return (r: typeof __puiRenderer) => {
      // Source "item.proto.ts":6:77
      return r.el("span", "item");
    };
  })(__puiDef) ?? (() => __puiRenderer.slot());
    if (typeof render !== 'function') throw new Error('[Prototype] setup must return a render function or void.');
  } catch (error) { for (const off of authorStateWatchCleanups.splice(0)) off(); try { disposeInteraction(); } catch {} context.dispose();  throw error; }
  phase = 'idle';
  function applyProps(nextHost: GeneratedComponentProps) {
    ensureAlive();
    hostProps = nextHost;
{ const __puiAssociations = nextHost.instanceAssociations;
    if (__puiAssociations !== undefined) {
      if (__puiAssociations === null || typeof __puiAssociations !== 'object' || Object.getPrototypeOf(__puiAssociations) !== Object.prototype)
        throw new TypeError('[InstanceAssociations] expected a plain record');
      for (const key of Reflect.ownKeys(__puiAssociations)) if (key !== 'controlLabel')
        throw new TypeError('[InstanceAssociations] unknown association key');
      if (Object.prototype.hasOwnProperty.call(__puiAssociations, 'controlLabel') && Reflect.get(__puiAssociations, 'controlLabel') != null)
        throw new Error('[ControlLabel] this Prototype has not declared Label or target participation');
    }
  }
    const nextRaw: Record<string, unknown> = Object.create(null);
    for (const [key, value] of Object.entries(nextHost)) {
      if (key === 'children' || key === 'instanceAssociations' || !Object.hasOwn(specs, key) && (['class', 'className', 'hostClass', 'surfaceClass', 'style', 'hostStyle', 'surfaceStyle'].includes(key) || /^on[A-Z]/.test(key) && typeof value === 'function')) continue;
      nextRaw[key] = value;
    }
    if (hydrated && Object.keys(raw).length === Object.keys(nextRaw).length
      && Object.keys(nextRaw).every((key) => Object.hasOwn(raw, key) && Object.is(raw[key], nextRaw[key]))) return false;
    const previous = resolved;
    const previousRaw = raw;
    raw = Object.freeze(nextRaw);
    resolved = __puiResolveProps(specs, defaults, previousValid, raw, true);

    __puiInteraction.refresh();
    if (!hydrated) { hydrated = true; return false; }
    const nextResolved = resolved, nextRawSnapshot = raw;
    invoke(() => {
      const previousWindow = propsWindow;
      propsWindow = { raw: nextRawSnapshot, resolved: nextResolved };
      try {
      if (rawAllWatchers.length || rawWatchers.length) {
        const changedRaw = [...new Set([...Object.keys(previousRaw), ...Object.keys(nextRawSnapshot)])].filter(key => Object.hasOwn(previousRaw, key) !== Object.hasOwn(nextRawSnapshot, key) || !Object.is(previousRaw[key], nextRawSnapshot[key]));
        if (changedRaw.length) for (let groupIndex = 0; groupIndex < 2; ++groupIndex) for (const watcher of groupIndex === 0 ? rawAllWatchers : rawWatchers) {
          if (!watcher.active) continue;
          const changedKeysMatched = watcher.keys ? watcher.keys.filter(key => changedRaw.includes(key)) : changedRaw;
          if (!changedKeysMatched.length) continue;
          console.warn('[Props] raw watchers are an adapter-snapshot escape hatch; avoid in official prototypes.');
          watcher.callback(__puiRunHandle, nextRawSnapshot, previousRaw, { changedKeysAll: changedRaw, changedKeysMatched });
        }
      }
      const changedKeysAll = Object.keys(specs).filter((key) => !Object.is(previous[key as keyof GeneratedProps], nextResolved[key as keyof GeneratedProps]));
      for (const watcher of watchers) {
        if (!watcher.active) continue;
        const changedKeysMatched = watcher.keys ? watcher.keys.filter((key) => changedKeysAll.includes(key)) : changedKeysAll;
        if (changedKeysMatched.length) watcher.callback(__puiRunHandle, nextResolved, previous, { changedKeysAll, changedKeysMatched });
      }
      } finally { propsWindow = previousWindow; }
    });
    return true;
  }
  const handle: GeneratedHandle = Object.freeze({
    update() { ensureExternal(); invoke(() => __puiRunHandle.update()); },
    getExposes() { ensureExternal(); return { ...exposes } as GeneratedExposes; },
    invokeInCallbackScope<T>(callback: () => T): T { ensureExternal(); return invoke(callback); },
  });
  return {
    handle,
    scope: context,
    getHostProjection() { return { tag: __puiInteraction.rootTag() ?? 'div', properties: __puiInteraction.rootProperties(), portalTarget: __puiInteraction.portalTarget() }; },

    bindRoot(nextRoot) {
      if (root === nextRoot) return;
      __puiInteraction.unmount();
      
      root = nextRoot;

      if (mounted && desiredPresent && viewConnected) __puiInteraction.mount();
    },
    connect() { connected = true; ++cleanupVersion; },
    connectView() {
      viewConnected = true;
      if (mounted && desiredPresent) __puiInteraction.mount();
    },
    disconnectView() { viewConnected = false; __puiInteraction.unmount(); },
    start() {
      try {
        applyProps(initial); dispatch(callbacks.created);
        schedule();
      }
      catch (error) { try { disposeInteraction(); } catch {} context.dispose();  lifetime = 'disposed'; connected = false; throw error; }
    },
    applyProps,
    accept(frame: __puiFrame) {
      if (!connected || lifetime !== 'alive' || frame.revision <= acceptedRevision || frame !== latest) return false;
      acceptedRevision = frame.revision;
      if (frame.kind === 'detach') {
        __puiInteraction.unmount();

        if (mounted) { mounted = false; dispatch(callbacks.unmounted); }
      } else if (!desiredPresent) {
        // Physical materialization is not a published mount. Remove the obsolete
        // Root without manufacturing mounted/unmounted for a never-mounted epoch.
        schedule();
        return false;
      } else if (frame.kind === 'mount') {
        mounted = true;
        // The published mount may predate an explicit update intent. Only
        // after its acknowledgement may that dirty intent enter update flow.
        if (dirty) updateQueued = true;

        __puiInteraction.mount();
        dispatch(callbacks.mounted);
      } else if (mounted && frame.epoch === epoch) dispatch(callbacks.updated);
      schedule();
      return true;
    },
    disconnect() {
      connected = false;
      const version = ++cleanupVersion;
      queueMicrotask(() => {
        if (connected || cleanupVersion !== version || lifetime !== 'alive') return;
        lifetime = 'disposing';
        for (const off of authorStateWatchCleanups.splice(0)) off();
        phase = 'callback';
        let failure: { error: unknown } | undefined;
        try { __puiInteraction.unmount(); }
        catch (error) { failure = { error }; }
        try { if (mounted) { mounted = false; dispatch(callbacks.unmounted); } }
        catch (error) { failure ??= { error }; }
        try { dispatch(callbacks.beforeDispose); }
        catch (error) { failure ??= { error }; }
        finally {
          try { disposeInteraction(); } catch (error) { failure ??= { error }; }
          
          root = null;

          context.dispose(); 
          lifetime = 'disposed'; phase = 'idle';
          for (const subscribers of stateSubscribers) subscribers.clear();
          pendingStateEvents.length = 0;
          watchers.length = 0;
          rawWatchers.length = 0; rawAllWatchers.length = 0;
          for (const list of Object.values(callbacks)) list.length = 0;
          for (const key of Object.keys(exposes)) delete exposes[key];
        }
        if (failure) throw failure.error;
      });
    },
  };
}


export const CompiledComponent = __puiReact.forwardRef<GeneratedHandle, GeneratedComponentProps>(function CompiledComponent(props, ref) {
  const ownerRef = __puiReact.useRef<__puiOwner | null>(null);
  const parentScope = __puiReact.useContext(__puiContextTransport);
  const parentRef = __puiReact.useRef<__puiContextScope | null>(null);
  const [frame, setFrame] = __puiReact.useState<__puiFrame | null>(null);
  const [, publishHost] = __puiReact.useReducer((version: number) => version + 1, 0);
  const bindRoot = __puiReact.useCallback((root: HTMLElement | null) => { ownerRef.current?.bindRoot(root); }, []);
  // All irreversible work begins after an accepted shell commit, never during React render.
  __puiReact.useLayoutEffect(() => {
    parentRef.current = parentScope;
    let owner = ownerRef.current;
    if (!owner) {
      owner = __puiCreateOwner(props, setFrame, () => parentRef.current, publishHost);
      ownerRef.current = owner;
      owner.start();
    } else owner.connect();
    owner.connectView();
    return () => { owner.disconnectView(); };
  }, []);
  __puiReact.useLayoutEffect(() => { parentRef.current = parentScope; }, [parentScope]);
  // Suspense can disconnect layout effects without unmounting the owner shell.
  // Passive cleanup identifies shell unmount; same-turn StrictMode replay cancels disposal.
  __puiReact.useEffect(() => {
    const owner = ownerRef.current;
    if (!owner) return;
    owner.connect();
    return () => { owner.disconnect(); };
  }, []);
  __puiReact.useLayoutEffect(() => { const owner = ownerRef.current; owner?.applyProps(props); }, [props]);
  __puiReact.useLayoutEffect(() => { if (frame) ownerRef.current!.accept(frame); }, [frame]);
  __puiReact.useImperativeHandle(ref, () => ownerRef.current!.handle, []);
  const template = __puiReact.useMemo(() => __puiBindSlots(frame?.node, props.children), [frame?.node, props.children]);
  const host = ownerRef.current?.getHostProjection();
  const rootView = frame && frame.kind !== 'detach'
    ? __puiRenderRoot(host!.tag, { ...__puiRootProperties(host!.properties), 'data-pui-root': '', ref: bindRoot }, template) : null;
  const view = rootView && host?.portalTarget ? __puiCreatePortal(rootView, host.portalTarget) : rootView;
  return __puiReact.createElement(__puiContextTransport.Provider, { value: ownerRef.current?.scope ?? null }, view);

});
CompiledComponent.displayName = "scroll-family-item";

//# sourceMappingURL=Item.tsx.map
