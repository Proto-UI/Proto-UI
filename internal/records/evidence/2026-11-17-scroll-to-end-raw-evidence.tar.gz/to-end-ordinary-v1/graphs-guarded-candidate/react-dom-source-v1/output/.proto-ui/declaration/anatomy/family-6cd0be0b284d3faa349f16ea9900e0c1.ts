// Native anatomy family v1. No Proto package, interpreter or host dependency.
// Original declaration "family.ts#OTHER"
const roles = Object.freeze({["root"]: Object.freeze({["cardinality"]: Object.freeze({["min"]: 1, ["max"]: 1} as const)} as const), ["surface"]: Object.freeze({["cardinality"]: Object.freeze({["min"]: 0, ["max"]: "*"} as const)} as const), ["item"]: Object.freeze({["cardinality"]: Object.freeze({["min"]: 0, ["max"]: "*"} as const)} as const)} as const);
const relations = Object.freeze([] as const);
const profiles = Object.freeze({} as const);
export const declaration = Object.freeze({ debugName: "scroll-consumer-family", roles, relations, profiles });
