import { owners, parts, targets, hostIds, logicalRoot, ancestor, descends, hostOrder, isElement, type Claim, type Owner } from './ownership-v2';
export type NativeConfig = Readonly<Record<string, unknown>>;
export type NativeStateEvent<T> = {
    type: 'next';
    prev: T;
    next: T;
    reason?: unknown;
} | {
    type: 'disconnect';
    reason: 'unmount';
};
export type NativeObserved<T> = {
    get(): T;
    watch<R>(callback: (run: R, event: NativeStateEvent<T>) => void): () => void;
    subscribe(callback: (event: {
        type: 'next';
        prev: T;
        next: T;
        reason?: unknown;
    }) => void): () => void;
};
export type NativeOwnedState<T> = {
    get(): T;
    set(value: T, reason?: unknown): void;
    setDefault(value: T): void;
};
export type NativeOwnedStateSpec = {
    kind: 'bool' | 'string' | 'enum' | 'number.discrete';
    options?: readonly string[];
};
type NativeStateCell<T> = {
    handle: NativeOwnedState<T>;
    set(value: T): void;
};
export type NativeFocusRequest = {
    reason?: 'programmatic' | 'keyboard' | 'pointer';
    preventScroll?: boolean;
    defer?: boolean;
};
export type NativeFocusScopeActivation = NativeFocusRequest & {
    entry?: 'configured' | 'manual';
};
export type NativeFocusBase = {
    focused: NativeObserved<boolean>;
    focusVisible: NativeObserved<boolean>;
    focusable: NativeObserved<boolean>;
    configure(config: NativeConfig): void;
    setDisabled(value: boolean): void;
    focusSelf(options?: NativeFocusRequest): void;
};
export interface NativeFocusEntry {
    configure(config: NativeConfig): void;
    setDisabled(value: boolean): void;
    focus(options?: NativeFocusRequest): void;
}
export interface NativeFocusRoving {
    active: NativeObserved<boolean>;
    hasFocused: NativeObserved<boolean>;
    configure(config: NativeConfig): void;
    setLoop(value: boolean): void;
    setOrientation(value: string): void;
    focusFirst(options?: NativeFocusRequest): void;
    focusLast(options?: NativeFocusRequest): void;
    focusSelected(options?: NativeFocusRequest): void;
    focusNext(): void;
    focusPrev(): void;
}
export interface NativeFocusScope {
    active: NativeObserved<boolean>;
    hasFocused: NativeObserved<boolean>;
    configure(config: NativeConfig): void;
    focusFirst(): void;
    focusLast(): void;
    focusNext(): void;
    focusPrev(): void;
    focusSelected(): void;
    activate(options?: NativeFocusScopeActivation): void;
    deactivate(options?: NativeFocusRequest): void;
    restoreFocus(): void;
    isActive(): boolean;
    getRoving(): NativeFocusRoving | null;
}
export type NativeAnatomyFamily = {
    debugName: string;
    roles: Readonly<Record<string, {
        cardinality: {
            min: number;
            max: number | '*';
        };
        requires?: readonly {
            kind: string;
            name: string;
        }[];
    }>>;
    relations?: readonly unknown[];
    profiles?: Readonly<Record<string, unknown>>;
};
export interface NativeAnatomyPart {
    readonly role: string;
    hasExpose(key: string): boolean;
    getExpose(key: string): unknown | null;
    hasHook(name: string): boolean;
}
export interface NativeAnatomyOrder {
    version(family: NativeAnatomyFamily): number;
    parts(family: NativeAnatomyFamily): readonly NativeAnatomyPart[];
    partsOf(family: NativeAnatomyFamily, role: string): readonly NativeAnatomyPart[];
    indexOfSelf(family: NativeAnatomyFamily, role: string): number;
    prevOfSelf(family: NativeAnatomyFamily, role: string): NativeAnatomyPart | null;
    nextOfSelf(family: NativeAnatomyFamily, role: string): NativeAnatomyPart | null;
}
export interface NativeAnatomy<Run = unknown> extends NativeAnatomyOrder {
    claim(family: NativeAnatomyFamily, declaration: {
        role: string;
        profile?: string;
    }): void;
    has(family: NativeAnatomyFamily, role: string): boolean;
    subscribeParts(family: NativeAnatomyFamily, role: string, callback: (run: Run, parts: readonly NativeAnatomyPart[]) => void): () => void;
    readonly order: NativeAnatomyOrder;
}
export type NativeCollectionSnapshot = Readonly<Record<string, unknown> & {
    index: number;
    total: number;
    first: boolean;
    last: boolean;
}>;
export interface NativeCollection {
    readonly count: NativeOwnedState<number>;
    configure(config: NativeConfig): void;
    getItems(): readonly NativeCollectionSnapshot[];
    getCount(): number;
}
export interface NativeCollectionItem {
    readonly collectionIndex: NativeOwnedState<number>;
    readonly collectionTotal: NativeOwnedState<number>;
    readonly collectionFirst: NativeOwnedState<boolean>;
    readonly collectionLast: NativeOwnedState<boolean>;
    configure(config: NativeConfig): void;
    getSnapshot(): NativeCollectionSnapshot;
}
export interface NativeBoundary<Run = unknown> {
    configure(config: NativeConfig): void;
    observe(type: string): void;
    setStackActive(active: boolean): void;
    registerRegion(target: unknown, options?: NativeConfig): () => void;
    unregisterRegion(target: unknown): void;
    classify(sample?: NativeConfig): 'inside' | 'outside' | 'unknown';
    notify(sample?: NativeConfig): 'inside' | 'outside' | 'unknown';
    subscribeOutside(callback: (event: NativeConfig) => void): () => void;
}
export interface NativeHitParticipation {
    configure(config: NativeConfig): void;
    registerRegion(target: unknown, options?: NativeConfig): () => void;
    unregisterRegion(target: unknown): void;
}
export type NativePositionSnapshot = Readonly<{
    side: string;
    align: string;
    strategy: string;
}>;
export interface NativePositioning {
    connect(connection: NativeConfig): void;
    update(config: NativeConfig): void;
    requestUpdate(): void;
    disconnect(): void;
    getSnapshot(): NativePositionSnapshot | null;
}
export interface NativeOverlay {
    readonly open: NativeObserved<boolean>;
    configure(config: NativeConfig): void;
    isOpen(): boolean;
    openOverlay(reason?: string): void;
    close(reason?: string): void;
    toggle(reason?: string): void;
    updatePosition(config: NativeConfig): void;
    registerTrigger(target: unknown): void;
    registerAnchor(target: unknown): void;
    registerAnchorPart(part: NativeAnatomyPart | null): void;
    registerContent(target: unknown): void;
    getPositionSnapshot(): NativePositionSnapshot | null;
    keepMounted(): void;
    bindPresence(binding: NativeConfig): void;
}
export interface NativeScrollAxis {
    position: NativeObserved<number>;
    visibleRatio: NativeObserved<number>;
    canScrollBefore: NativeObserved<boolean>;
    canScrollAfter: NativeObserved<boolean>;
    atEnd: NativeObserved<boolean>;
}
export type NativeScrollAxisSnapshot = Readonly<{
    position: number;
    visibleRatio: number;
    canScrollBefore: boolean;
    canScrollAfter: boolean;
    atEnd: boolean;
}>;
export type NativeScrollSnapshot = Readonly<{
    axes: string;
    horizontal: NativeScrollAxisSnapshot;
    vertical: NativeScrollAxisSnapshot;
    scrolling: boolean;
    projection: string;
    endFollow: Readonly<{
        state: string;
        requestStatus: string;
    }>;
}>;
export type NativeScrollPositionRequest = {
    kind: 'by';
    axis: 'horizontal' | 'vertical';
    delta: number;
} | {
    kind: 'to' | 'control-drag';
    axis: 'horizontal' | 'vertical';
    position: number;
} | {
    kind: 'page';
    axis: 'horizontal' | 'vertical';
    direction: 'before' | 'after';
} | {
    kind: 'to-end';
    axis: 'horizontal' | 'vertical';
};
export type NativeScrollRequest = NativeScrollPositionRequest | {
    kind: 'reveal';
    axis: 'vertical';
    family: NativeAnatomyFamily;
    part: NativeAnatomyPart;
};
export type NativeScrollRequestOutcome = {
    kind: 'dispatched';
} | {
    kind: 'queued';
} | {
    kind: 'rejected';
    reason: 'not-mounted' | 'not-declared' | 'unavailable';
};
export interface NativeScroll {
    axes: NativeObserved<string>;
    horizontal: NativeScrollAxis;
    vertical: NativeScrollAxis;
    scrolling: NativeObserved<boolean>;
    projection: NativeObserved<string>;
    endFollow: {
        state: NativeObserved<string>;
        requestStatus: NativeObserved<string>;
    };
    configure(config: NativeConfig): void;
    bindComposedChrome(binding: NativeConfig): void;
    request(request: NativeScrollRequest): NativeScrollRequestOutcome;
    getSnapshot(): NativeScrollSnapshot;
}
export type NativeTextEvent = Readonly<{
    type: string;
    value: string;
    composing: boolean;
    data: string | null;
    inputType: string | null;
}>;
export type NativeImageEvent = Readonly<{
    status: string;
    previousStatus: string;
    source: string;
}>;
export interface NativeTextControl<Run = unknown> {
    on(type: string, callback: (run: Run, event: NativeTextEvent) => void): () => void;
    sync(patch: NativeConfig): void;
    snapshot(): {
        value: string;
        composing: boolean;
    } | null;
}
export interface NativeImageView<Run = unknown> {
    on(type: string, callback: (run: Run, event: NativeImageEvent) => void): () => void;
    sync(patch: NativeConfig): void;
    snapshot(): {
        source: string;
        loadingStatus: string;
        fit: string;
    } | null;
}
export interface NativeTableStructure {
    readonly role: string;
    readonly states: {
        a11yRole: NativeOwnedState<string>;
        rowCount: NativeOwnedState<number>;
        columnCount: NativeOwnedState<number>;
        row: NativeOwnedState<number>;
        column: NativeOwnedState<number>;
        rowSpan: NativeOwnedState<number>;
        columnSpan: NativeOwnedState<number>;
    };
    configure(patch: NativeConfig): void;
    getObjectRef(): object;
    getSnapshot(): NativeTableSnapshot | null;
}
export type NativeTableCell = Readonly<{
    ref: object;
    kind: 'column-header' | 'row-header' | 'cell';
    row: number;
    column: number;
    rowSpan: number;
    columnSpan: number;
    columnHeaders: readonly object[];
    rowHeaders: readonly object[];
    orderedHeaders: readonly object[];
}>;
export type NativeTableRow = Readonly<{
    ref: object;
    index: number;
    cells: readonly NativeTableCell[];
}>;
export type NativeTableDiagnostic = Readonly<{
    code: string;
    ref?: object;
    row?: number;
    headerKey?: string;
}>;
export type NativeTableSnapshot = Readonly<{
    root: object;
    caption: object | undefined;
    rowCount: number;
    columnCount: number;
    rows: readonly NativeTableRow[];
    valid: boolean;
    diagnostics: readonly NativeTableDiagnostic[];
}>;
export interface NativeAccessibleExtension {
    readonly objectRef: object;
    id(value: string | {
        get(): string | null | undefined;
    }): void;
    name(value: string | {
        get(): string | null | undefined;
    }): void;
    description(value: string | {
        get(): string | null | undefined;
    }): void;
    relation(kind: string, target: NativeConfig): void;
    tree(config: NativeConfig): void;
    level(value: number | {
        get(): number;
    }): void;
}
export type NativeControlLabelAnatomyPair = Readonly<{
    family: NativeAnatomyFamily;
    labelRole: string;
    targetRole: string;
}>;
export type NativeControlLabelRequest = Readonly<{
    source: 'pointer' | 'accessibility';
    isCurrent(): boolean;
}>;
export type NativeControlLabelHandle = Readonly<{
    sync(options: Readonly<{
        naming: boolean;
        activation: boolean;
    }>): void;
}>;
export type NativeControlLabel<Run = unknown> = Readonly<{
    label(pair?: NativeControlLabelAnatomyPair): NativeControlLabelHandle;
    target(activate: (run: Run, request: NativeControlLabelRequest) => void, pair?: NativeControlLabelAnatomyPair): NativeControlLabelHandle;
}>;
export type NativeModuleCapability<Kind extends string, Run = unknown> = Kind extends 'control-label' ? NativeControlLabel<Run> : Kind extends 'control-label-handle' ? NativeControlLabelHandle : Kind extends 'control-label-request' ? NativeControlLabelRequest : Kind extends 'binding-disposer' ? () => void : Kind extends 'collection-snapshot' ? NativeConfig : Kind extends 'collection-snapshot-list' ? readonly NativeConfig[] : Kind extends 'focus-entry' ? NativeFocusEntry : Kind extends 'focus-roving' ? NativeFocusRoving : Kind extends 'focus-scope' ? NativeFocusScope : Kind extends 'anatomy-family' ? NativeAnatomyFamily : Kind extends 'anatomy-part' ? NativeAnatomyPart : Kind extends 'anatomy-parts' ? readonly NativeAnatomyPart[] : Kind extends 'anatomy-order' ? NativeAnatomyOrder : Kind extends 'collection' ? NativeCollection : Kind extends 'collection-item' ? NativeCollectionItem : Kind extends 'boundary' ? NativeBoundary<Run> : Kind extends 'hit-participation' ? NativeHitParticipation : Kind extends 'positioning' ? NativePositioning : Kind extends 'overlay' ? NativeOverlay : Kind extends 'scroll' ? NativeScroll : Kind extends 'scroll-axis' ? NativeScrollAxis : Kind extends 'scroll-follow' ? NativeScroll['endFollow'] : Kind extends 'text-control' ? NativeTextControl<Run> : Kind extends 'image-view' ? NativeImageView<Run> : Kind extends 'table-structure' ? NativeTableStructure : Kind extends 'table-states' ? NativeTableStructure['states'] : Kind extends 'table-snapshot' ? NativeTableSnapshot : Kind extends 'table-row' ? NativeTableRow : Kind extends 'table-cell' ? NativeTableCell : Kind extends 'table-diagnostic' ? NativeTableDiagnostic : Kind extends 'table-row-list' ? readonly NativeTableRow[] : Kind extends 'table-cell-list' ? readonly NativeTableCell[] : Kind extends 'table-diagnostic-list' ? readonly NativeTableDiagnostic[] : Kind extends 'a11y-ref-list' ? readonly object[] : Kind extends 'subscription-disposer' ? () => void : Kind extends 'host-target' ? Element : Kind extends 'focus-scope-key' | 'focus-roving-key' | 'a11y-ref' ? object : NativeConfig;
export interface NativeModuleCapabilities<Run = unknown> {
    anatomy: NativeAnatomy<Run>;
    asScrollSurface(): NativeScroll;
    rootTag(): string | null;
    rootProperties(): Readonly<Record<string, string | number | boolean | null>>;
    projectAttributes(): Readonly<Record<string, string | null>>;
    portalTarget(): HTMLElement | null;
    adoptControlState(): void;
    mount(): void;
    unmount(): void;
    refresh(): void;
    dispose(): void;
}
export interface NativeAdapterModuleOptions<Run> {
    ensureSetup(operation: string): void;
    ensureRuntime(operation: string): void;
    ensureEvent(operation: string): void;
    isAlive(): boolean;
    isReady?(): boolean;
    invoke<T>(callback: () => T): T;
    getRun(): Run;
    getResolvedProps(): Readonly<Record<string, unknown>>;
    getRoot(): HTMLElement | null;
    getHost?(): HTMLElement | null;
    declarations: readonly {
        id: string;
        config: NativeConfig;
    }[];
    getLogicalParent(): object | null;
    identity: object;
    registerObservedState?<T extends boolean | string | number>(state: NativeObserved<T>): void;
    getExposes?(): Readonly<Record<string, unknown>>;
    setPresent?(value: boolean): void;
    requestHostUpdate?(): void;
    baseFocus?(): NativeFocusBase;
    getAccessibleRole?(): string | null;
    /** Internal focus bridge cleanup; never blurs the physical target. */
    cancelPendingFocus?(): void;
    emit?(key: string): void;
    createOwnedState?<T extends boolean | string | number>(name: string, initial: T, spec?: NativeOwnedStateSpec): NativeOwnedState<T>;
    watchState?<T>(state: {
        get(): T;
    }, callback: (run: Run, event: NativeStateEvent<T>) => void): () => void;
    isPropProvided?(key: string): boolean;
    getMeta?(key: string): unknown;
    registerExpose?(key: string, value: unknown): void;
    tableFamily?: NativeAnatomyFamily;
    requestAttributeRefresh?(): void;
    getAttributeBaseline?(name: string): string | null;
    subscribeState?(state: {
        get(): unknown;
    }, callback: () => void): () => void;
}
type NativeTableCellInput = {
    ref: object;
    kind: 'headerCell' | 'cell';
    headerKey?: string;
    headerKind?: unknown;
    headers: readonly string[];
    rowSpan?: number;
    columnSpan?: number;
};
type NativeTableInput = {
    root: object;
    captions: readonly object[];
    rows: readonly {
        ref: object;
        cells: readonly NativeTableCellInput[];
    }[];
    unmatchedCells: readonly object[];
    roleMismatches: readonly object[];
};
/** Host-local geometry only. No target or measurement crosses the author boundary. */
function nativeScrollDescendant(surface: HTMLElement, target: HTMLElement): boolean {
    let node: Node | null = target;
    const visited = new Set<Node>();
    while (node && !visited.has(node)) {
        if (node === surface)
            return target !== surface;
        visited.add(node);
        const element: Element | null = node.nodeType === 1 ? (node as Element) : null;
        node =
            element?.assignedSlot ??
                node.parentNode ??
                (node.nodeType === 11 ? ((node as ShadowRoot).host ?? null) : null);
    }
    return false;
}
const nativeScrollPixels = (value: string, percentageBasis?: number): number => {
    const text = value.trim();
    if (text === '' || text === 'auto' || text === '0')
        return 0;
    const match = /^([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?)(px|%)$/i.exec(text);
    if (!match)
        return NaN;
    const parsed = Number(match[1]);
    if (!Number.isFinite(parsed))
        return NaN;
    return match[2] === 'px'
        ? parsed
        : percentageBasis === undefined
            ? NaN
            : (parsed * percentageBasis) / 100;
};
/**
 * Reveal inside this surface only. Native scrollIntoView may move unrelated
 * ancestors or the page; focus is independently owned by the Focus domain.
 */
function revealNativeScrollTarget(surface: HTMLElement, candidate: unknown, isCurrent: () => boolean, beforeApply: () => void = () => { }): boolean {
    const document = surface.ownerDocument;
    const view = document.defaultView;
    if (!view || !(candidate instanceof view.HTMLElement))
        return false;
    const target = candidate as HTMLElement;
    const current = () => isCurrent() &&
        surface.ownerDocument === document &&
        target.ownerDocument === document &&
        surface.isConnected &&
        target.isConnected &&
        nativeScrollDescendant(surface, target);
    if (!current())
        return false;
    if (!surface.getClientRects().length || !target.getClientRects().length)
        return false;
    const surfaceStyle = view.getComputedStyle(surface);
    const targetStyle = view.getComputedStyle(target);
    if ([surfaceStyle.visibility, targetStyle.visibility].some((visibility) => visibility === 'hidden' || visibility === 'collapse'))
        return false;
    const surfaceBox = surface.getBoundingClientRect();
    const targetBox = target.getBoundingClientRect();
    const clientHeight = surface.clientHeight;
    // offsetHeight rounds the used layout size to an integer. Treating that
    // rounding as a transform scales every distant offset and can overshoot a
    // short viewport by an entire row. Computed used lengths preserve the
    // fractional border box while still accounting for actual CSS scaling.
    const usedHeight = nativeScrollPixels(surfaceStyle.height);
    const usedBorderBox = usedHeight +
        (surfaceStyle.boxSizing === 'border-box'
            ? 0
            : nativeScrollPixels(surfaceStyle.paddingTop) +
                nativeScrollPixels(surfaceStyle.paddingBottom) +
                nativeScrollPixels(surfaceStyle.borderTopWidth) +
                nativeScrollPixels(surfaceStyle.borderBottomWidth));
    const layoutHeight = Number.isFinite(usedBorderBox) && usedHeight > 0 && usedBorderBox > 0
        ? usedBorderBox
        : surface.offsetHeight;
    const scale = layoutHeight > 0 ? surfaceBox.height / layoutHeight : 1;
    const start = surfaceBox.top +
        (surface.clientTop + nativeScrollPixels(surfaceStyle.scrollPaddingTop, clientHeight)) * scale;
    const end = surfaceBox.top +
        (surface.clientTop + clientHeight - nativeScrollPixels(surfaceStyle.scrollPaddingBottom, clientHeight)) *
            scale;
    const targetStart = targetBox.top - nativeScrollPixels(targetStyle.scrollMarginTop) * scale;
    const targetEnd = targetBox.bottom + nativeScrollPixels(targetStyle.scrollMarginBottom) * scale;
    const position = surface.scrollTop;
    const range = Math.max(0, surface.scrollHeight - clientHeight);
    if (![start, end, targetStart, targetEnd, scale, position, range].every(Number.isFinite) ||
        scale <= 0 ||
        clientHeight <= 0 ||
        surfaceBox.width <= 0 ||
        targetBox.width <= 0 ||
        targetBox.height <= 0 ||
        end <= start)
        return false;
    if (!current())
        return false;
    // A contained target, or one spanning both viewport edges, is already at
    // the nearest position. Otherwise move the closer edge into the viewport.
    const visible = (targetStart >= start && targetEnd <= end) || (targetStart <= start && targetEnd >= end);
    const leading = targetStart - start;
    const trailing = targetEnd - end;
    const delta = visible ? 0 : Math.abs(leading) < Math.abs(trailing) ? leading : trailing;
    const next = Math.min(range, Math.max(0, position + delta / scale));
    beforeApply();
    if (!current())
        return false;
    if (next === position)
        return true;
    const previous = surface.style.getPropertyValue('scroll-behavior');
    const priority = surface.style.getPropertyPriority('scroll-behavior');
    // Keyboard navigation must reveal this item before the next key, including
    // when a consumer has authored smooth scrolling for other interactions.
    surface.style.setProperty('scroll-behavior', 'auto', 'important');
    try {
        if (!current())
            return false;
        surface.scrollTop = next;
        return current();
    }
    finally {
        // A reentrant owner may replace the style. Restore only our exact write.
        if (surface.style.getPropertyValue('scroll-behavior') === 'auto' &&
            surface.style.getPropertyPriority('scroll-behavior') === 'important') {
            if (previous)
                surface.style.setProperty('scroll-behavior', previous, priority);
            else
                surface.style.removeProperty('scroll-behavior');
        }
    }
}
export function createNativeAdapterModules<Run>(options: NativeAdapterModuleOptions<Run>): NativeModuleCapabilities<Run> {
    let disposed = false;
    let root: HTMLElement | null = null;
    let generation = 0;
    let hostProperties: Readonly<Record<string, string | number | boolean | null>> | null = null;
    let hostPortal: HTMLElement | null = null;
    const cleanups: (() => void)[] = [];
    const terminalCleanups: (() => void)[] = [];
    const propertyBaselines = new Map<string, {
        value: string;
        projected: string;
    }>();
    const hooks = new Set<string>();
    const claims = new Map<object, Claim>();
    const topologySubscribers = new Set<() => void>();
    const focusConfig: Record<string, unknown> = { disabled: false, navParticipation: 'auto' };
    const scopeConfig: Record<string, unknown> = { trap: false, loop: false, navigation: 'tab', orientation: 'both', entry: 'first', entryFallback: 'none', restore: 'previous', emptyPolicy: 'container' };
    const rovingConfig: Record<string, unknown> = { loop: false, navigation: 'arrow', orientation: 'both', entry: 'active', selectOnFocus: false };
    const nativeNotifications: (() => void)[] = [];
    let nativeNotifying = false;
    const observed = <T extends boolean | string | number>(initial: T) => {
        let value = initial;
        const listeners = new Set<(event: {
            type: 'next';
            prev: T;
            next: T;
            reason?: unknown;
        }) => void>();
        const handle: NativeObserved<T> = Object.freeze({
            get() { alive(); return value; },
            watch<R>(callback: (run: R, event: NativeStateEvent<T>) => void) {
                setup('state.watch');
                const listener = (event: {
                    type: 'next';
                    prev: T;
                    next: T;
                    reason?: unknown;
                }) => callback(options.getRun() as unknown as R, event);
                listeners.add(listener);
                return () => { listeners.delete(listener); };
            },
            subscribe(callback: (event: {
                type: 'next';
                prev: T;
                next: T;
                reason?: unknown;
            }) => void) {
                alive();
                const registration = (event: {
                    type: 'next';
                    prev: T;
                    next: T;
                    reason?: unknown;
                }) => callback(event);
                listeners.add(registration);
                return () => listeners.delete(registration);
            },
        });
        terminalCleanups.push(() => listeners.clear());
        return { handle, set(next: T) {
                if (Object.is(value, next))
                    return;
                const prev = value;
                value = next;
                const epoch = generation, viewRoot = root;
                const event = { type: 'next' as const, prev, next, reason: 'native-module' };
                for (const subscriber of Array.from(listeners)) {
                    Object.defineProperty(nativeNotifications, nativeNotifications.length, { value: () => {
                            if ((!disposed && options.isAlive()) && listeners.has(subscriber)) {
                                if (viewRoot !== null && viewRoot === root && epoch === generation && ready() && (options.isReady?.() ?? true))
                                    options.invoke(() => subscriber(event));
                            }
                        }, writable: true, enumerable: true, configurable: true });
                }
                if (!nativeNotifying) {
                    nativeNotifying = true;
                    const notificationFailures: unknown[] = [];
                    let notificationIndex = 0;
                    try {
                        while (notificationIndex < nativeNotifications.length && (!disposed && options.isAlive())) {
                            try {
                                nativeNotifications[notificationIndex++]();
                            }
                            catch (error) {
                                Object.defineProperty(notificationFailures, notificationFailures.length, { value: error, writable: true, enumerable: true, configurable: true });
                            }
                        }
                    }
                    finally {
                        nativeNotifications.length = 0;
                        nativeNotifying = false;
                    }
                    if (notificationFailures.length === 1)
                        throw notificationFailures[0];
                    if (notificationFailures.length > 1)
                        throw new AggregateError(notificationFailures, '[State] subscriber failures');
                }
            } };
    };
    const owner: Owner = { identity: options.identity, parent: options.getLogicalParent, target: () => root, host: () => root ? options.getHost?.() ?? root : null, alive: () => !disposed && options.isAlive(), hooks, claims, exposes: () => options.getExposes?.() ?? {}, focusConfig, scopeConfig, rovingConfig, selected: false, active: false, scopeDeclared: false, rovingDeclared: false, focusDeclared: false, entryDeclared: false, scopeActive: false, focus: () => { throw new Error('[Focus] owner does not declare focus.'); }, cancelPendingFocus() {
        }, changed: () => {
            const epoch = generation;
            for (const callback of [...topologySubscribers]) {
                if (epoch !== generation || !ready() || !(options.isReady?.() ?? true))
                    break;
                if (topologySubscribers.has(callback))
                    options.invoke(callback);
            }
            refresh();
        } };
    if (owners.has(options.identity))
        throw new Error('[Modules] duplicate live owner identity.');
    function alive() {
        if (disposed || !options.isAlive())
            throw new Error('[Modules] owner is terminally disposed.');
    }
    function setup(operation: string) { alive(); options.ensureSetup(operation); }
    function runtime(operation: string) { alive(); options.ensureRuntime(operation); }
    function requestPresentation() {
        if (disposed || !options.isAlive() || !(options.isReady?.() ?? true))
            return;
        const next = rootProperties(), portal = portalTarget();
        const changed = !hostProperties || portal !== hostPortal || Object.keys(next).length !== Object.keys(hostProperties).length || Object.keys(next).some(key => next[key] !== hostProperties![key]);
        hostProperties = next;
        hostPortal = portal;
        if (changed)
            options.requestHostUpdate?.();
    }
    function ready() { return !disposed && options.isAlive() && !!root && root === options.getRoot() && root.isConnected; }
    function announceTopology(rootOwner = logicalRoot(owner)) {
        for (const participant of [...owners.values()])
            if (participant.alive() && logicalRoot(participant) === rootOwner)
                participant.changed();
    }
    function declare(name: string) { setup('hook.' + name); hooks.add(name); }
    function listen(target: EventTarget, type: string, callback: (event: Event) => void, listenerOptions?: AddEventListenerOptions) {
        const epoch = generation;
        const guarded = (event: Event) => {
            if (epoch === generation && ready() && (options.isReady?.() ?? true))
                callback(event);
        };
        target.addEventListener(type, guarded, listenerOptions);
        cleanups.push(() => target.removeEventListener(type, guarded, listenerOptions));
    }
    function styleProperty(target: HTMLElement, name: string, value: string) {
        const current = target.style.getPropertyValue(name);
        const key = name;
        let record = propertyBaselines.get(key);
        if (!record) {
            record = { value: current, projected: current };
            propertyBaselines.set(key, record);
        }
        else if (current !== record.projected)
            record.value = current;
        if (current !== value) {
            if (value)
                target.style.setProperty(name, value);
            else
                target.style.removeProperty(name);
        }
        record.projected = value;
    }
    function domain(family: NativeAnatomyFamily, required = true): Owner | null {
        const found = ancestor(owner, participant => participant.claims.get(family)?.role === 'root');
        if (!found && required)
            throw new Error('[Anatomy] current owner has no root domain for ' + family.debugName);
        return found;
    }
    function anatomyOwners(family: NativeAnatomyFamily, role?: string, ordered = false): Owner[] {
        const rootOwner = domain(family);
        const found: Owner[] = [];
        for (const participant of owners.values())
            if (participant.alive() && participant.claims.has(family) && (!role || participant.claims.get(family)!.role === role)
                && ancestor(participant, current => current.claims.get(family)?.role === 'root') === rootOwner)
                found.push(participant);
        return ordered ? found.sort(hostOrder) : found;
    }
    const anatomyVersions = new Map<object, {
        members: readonly Owner[];
        version: number;
    }>();
    const anatomyOrder: NativeAnatomyOrder = {
        version(family) {
            alive();
            const members = anatomyOwners(family, undefined, true);
            const previous = anatomyVersions.get(family);
            if (!previous) {
                anatomyVersions.set(family, { members, version: 0 });
                return 0;
            }
            if (members.length !== previous.members.length || members.some((member, index) => member !== previous.members[index])) {
                previous.members = members;
                ++previous.version;
            }
            return previous.version;
        },
        parts(family) { alive(); return anatomyOwners(family, undefined, true).map(participant => participant.claims.get(family)!.part); },
        partsOf(family, role) { alive(); return anatomyOwners(family, role, true).map(participant => participant.claims.get(family)!.part); },
        indexOfSelf(family, role) { alive(); return anatomyOwners(family, role, true).indexOf(owner); },
        prevOfSelf(family, role) { const members = anatomyOwners(family, role, true); const index = members.indexOf(owner); return index > 0 ? members[index - 1].claims.get(family)!.part : null; },
        nextOfSelf(family, role) { const members = anatomyOwners(family, role, true); const index = members.indexOf(owner); return index >= 0 && index + 1 < members.length ? members[index + 1].claims.get(family)!.part : null; },
    };
    const anatomy: NativeAnatomy<Run> = {
        ...anatomyOrder, order: anatomyOrder,
        claim(family, declaration) {
            setup('anatomy.claim');
            if (!family?.roles[declaration.role] || claims.has(family))
                throw new Error('[Anatomy] invalid/duplicate family role claim.');
            if (declaration.profile && (declaration.role !== 'root' || !family.profiles?.[declaration.profile]))
                throw new Error('[Anatomy] invalid root profile.');
            const part: NativeAnatomyPart = Object.freeze({ role: declaration.role, hasExpose(key: string) { return Object.hasOwn(owner.exposes(), key); }, getExpose(key: string) { return owner.exposes()[key] ?? null; }, hasHook(name: string) { return hooks.has(name); } });
            claims.set(family, { family, ...declaration, part });
            parts.set(part, owner);
        },
        has(family, role) { alive(); return domain(family, false) !== null && anatomyOwners(family, role).length > 0; },
        parts(family) { alive(); return anatomyOwners(family).map(participant => participant.claims.get(family)!.part); },
        partsOf(family, role) { alive(); return anatomyOwners(family, role).map(participant => participant.claims.get(family)!.part); },
        subscribeParts(family, role, callback) {
            setup('anatomy.subscribeParts');
            let previous: readonly NativeAnatomyPart[] = [];
            const changed = () => {
                if (!domain(family, false))
                    return;
                const next = anatomyOrder.partsOf(family, role);
                if (next.length === previous.length && next.every((part, index) => part === previous[index]))
                    return;
                previous = next;
                callback(options.getRun(), next);
            };
            topologySubscribers.add(changed);
            return () => { setup('anatomy.subscribeParts.off'); topologySubscribers.delete(changed); };
        },
    };
    const readValue = (value: unknown): unknown => value && typeof value === 'object' && 'get' in value && typeof value.get === 'function' ? value.get() : value;
    const scrollAxes = observed<string>('vertical');
    const scrollProjection = observed<string>('unresolved');
    const scrolling = observed<boolean>(false);
    const followState = observed<string>('off');
    const followRequest = observed<string>('idle');
    let scrollRequestStatusVersion = 0;
    function setScrollRequestStatus(next: string) {
        ++scrollRequestStatusVersion;
        followRequest.set(next);
    }
    function axisFacts(): {
        handle: NativeScrollAxis;
        update(position: number, viewport: number, extent: number, current: () => boolean): void;
    } {
        const position = observed<number>(0), ratio = observed<number>(1), before = observed<boolean>(false), after = observed<boolean>(false), end = observed<boolean>(true);
        return { handle: { position: position.handle, visibleRatio: ratio.handle, canScrollBefore: before.handle, canScrollAfter: after.handle, atEnd: end.handle },
            update(offsetValue, viewport, extent, current) {
                const range = Math.max(0, extent - viewport), clamped = Math.min(range, Math.max(0, offsetValue));
                position.set(range > 0 ? clamped / range : 0);
                if (!current())
                    return;
                ratio.set(extent > 0 ? Math.max(0, Math.min(1, viewport / extent)) : 1);
                if (!current())
                    return;
                before.set(clamped > 0);
                if (!current())
                    return;
                after.set(clamped < range);
                if (!current())
                    return;
                end.set(range - clamped <= 1);
            },
        };
    }
    const horizontal = axisFacts();
    const vertical = axisFacts();
    let scrollConfig: NativeConfig = { axes: 'vertical', projection: 'auto', endFollow: { mode: 'off' } };
    let scrollChrome: NativeConfig | null = null;
    let readerContacts = 0;
    let scrollTimer: number | undefined;
    type ScrollBinding = {
        surface: HTMLElement;
        epoch: number;
    };
    type ScrollEndWork = {
        binding: ScrollBinding;
        axis: 'horizontal' | 'vertical';
        frame: number | null;
    };
    let scrollBinding: ScrollBinding | null = null;
    let scrollAttachment: {
        binding: ScrollBinding;
        requests: NativeConfig[];
    } | null = null;
    let scrollEndWork: ScrollEndWork | null = null;
    let readerIntent = 0;
    const chromeCleanups: (() => void)[] = [];
    const chromeTargets = new Map<HTMLElement, {
        width: string;
        height: string;
        transform: string;
        display: string;
        size: string;
        offset: string;
    }>();
    function currentScrollBinding(binding: ScrollBinding): boolean {
        return scrollBinding === binding && generation === binding.epoch && root === binding.surface && ready();
    }
    function scrollFacts(resumeEndAxis?: 'horizontal' | 'vertical') {
        const binding = scrollBinding;
        if (!binding || !currentScrollBinding(binding))
            return;
        const current = () => currentScrollBinding(binding), surface = binding.surface;
        const left = surface.scrollLeft, width = surface.clientWidth, scrollWidth = surface.scrollWidth;
        const top = surface.scrollTop, height = surface.clientHeight, scrollHeight = surface.scrollHeight;
        if (!current())
            return;
        horizontal.update(left, width, scrollWidth, current);
        if (!current())
            return;
        vertical.update(top, height, scrollHeight, current);
        if (!current())
            return;
        const follow = scrollConfig.endFollow as NativeConfig;
        if (follow?.mode === 'while-at-end') {
            const followAxis = follow.axis === 'horizontal' ? 'horizontal' : 'vertical';
            const atEnd = (followAxis === 'horizontal' ? horizontal.handle : vertical.handle).atEnd.get();
            if (resumeEndAxis === followAxis && atEnd)
                followState.set('following');
            else if (readerContacts || !atEnd && Date.now() < readerIntent)
                followState.set('paused');
            else if (atEnd)
                followState.set('following');
        }
        if (current())
            projectChrome();
    }
    function cancelScrollEnd(binding: ScrollBinding, axis: 'horizontal' | 'vertical') {
        const work = scrollEndWork;
        if (!work || work.binding !== binding || work.axis !== axis)
            return;
        scrollEndWork = null;
        if (work.frame !== null)
            binding.surface.ownerDocument.defaultView?.cancelAnimationFrame(work.frame);
        if (currentScrollBinding(binding))
            setScrollRequestStatus('rejected');
    }
    function revealScroll(request: NativeConfig, binding: ScrollBinding): NativeScrollRequestOutcome {
        const rejected = { kind: 'rejected', reason: 'unavailable' } as const;
        if (request.axis !== 'vertical' || scrollConfig.axes === 'horizontal' || scrollAttachment)
            return rejected;
        const family = request.family as NativeAnatomyFamily, part = request.part as NativeAnatomyPart;
        const participant = part && typeof part === 'object' ? parts.get(part) : undefined;
        const role = claims.get(family)?.role, familyRoot = role ? domain(family, false) : null;
        if (!participant || participant === owner || !role || !familyRoot)
            return rejected;
        const currentPart = () => currentScrollBinding(binding) && !scrollAttachment &&
            claims.get(family)?.role === role && domain(family, false) === familyRoot &&
            participant.alive() && participant.claims.get(family)?.part === part &&
            ancestor(participant, candidate => candidate.claims.get(family)?.role === 'root') === familyRoot &&
            ancestor(participant, candidate => candidate !== participant && candidate.claims.get(family)?.role === role) === owner;
        if (!currentPart())
            return rejected;
        const target = participant.target();
        if (!target)
            return rejected;
        const currentTarget = () => currentPart() && participant.target() === target && targets.get(target) === participant && currentPart();
        if (!revealNativeScrollTarget(binding.surface, target, currentTarget, () => cancelScrollEnd(binding, 'vertical')) || !currentTarget())
            return rejected;
        scrollFacts();
        if (!currentTarget())
            return rejected;
        const follow = scrollConfig.endFollow as NativeConfig;
        if (follow?.mode === 'while-at-end' && (follow.axis ?? 'vertical') === 'vertical')
            followState.set(vertical.handle.atEnd.get() ? 'following' : 'paused');
        return currentTarget() ? { kind: 'dispatched' } : rejected;
    }
    function applyScroll(request: NativeConfig): NativeScrollRequestOutcome {
        if (!hooks.has('asScrollSurface'))
            return { kind: 'rejected', reason: 'not-declared' };
        if (!root)
            return { kind: 'rejected', reason: 'not-mounted' };
        const surface = root, epoch = generation;
        const currentView = () => epoch === generation && root === surface && ready();
        if (!currentView())
            return { kind: 'rejected', reason: 'unavailable' };
        if (request.axis !== 'horizontal' && request.axis !== 'vertical')
            throw new Error('[Scroll] request axis must be horizontal or vertical.');
        const binding = scrollBinding;
        if (request.kind === 'reveal')
            return binding && currentScrollBinding(binding) ? revealScroll(request, binding) : { kind: 'rejected', reason: 'unavailable' };
        if (!['by', 'to', 'control-drag', 'page', 'to-end'].includes(String(request.kind)))
            throw new Error('[Scroll] invalid request kind.');
        const attachment = scrollAttachment;
        if (attachment && attachment.binding.surface === surface && attachment.binding.epoch === epoch) {
            const queued = { ...request };
            if (!currentView() || scrollAttachment !== attachment)
                return { kind: 'rejected', reason: 'unavailable' };
            attachment.requests.push(queued);
            return { kind: 'queued' };
        }
        if (!binding || !currentScrollBinding(binding))
            return { kind: 'rejected', reason: 'unavailable' };
        const horizontalAxis = request.axis === 'horizontal';
        const viewport = horizontalAxis ? surface.clientWidth : surface.clientHeight, extent = horizontalAxis ? surface.scrollWidth : surface.scrollHeight;
        const current = horizontalAxis ? surface.scrollLeft : surface.scrollTop, range = Math.max(0, extent - viewport);
        let next: number;
        if (request.kind === 'by')
            next = current + Number(request.delta);
        else if (request.kind === 'to' || request.kind === 'control-drag')
            next = Math.max(0, Math.min(1, Number(request.position))) * range;
        else if (request.kind === 'page')
            next = current + (request.direction === 'before' ? -viewport : viewport);
        else if (request.kind === 'to-end')
            next = range;
        else
            throw new Error('[Scroll] invalid request kind.');
        if (!Number.isFinite(next))
            throw new Error('[Scroll] request coordinate must be finite.');
        if (!currentView())
            return { kind: 'rejected', reason: 'unavailable' };
        const statusVersion = scrollRequestStatusVersion;
        if (horizontalAxis)
            surface.scrollLeft = Math.max(0, Math.min(range, next));
        else
            surface.scrollTop = Math.max(0, Math.min(range, next));
        if (!currentView())
            return { kind: 'rejected', reason: 'unavailable' };
        scrollFacts(request.kind === 'to-end' ? horizontalAxis ? 'horizontal' : 'vertical' : undefined);
        if (!currentView())
            return { kind: 'rejected', reason: 'unavailable' };
        if (request.kind === 'to-end' && statusVersion === scrollRequestStatusVersion)
            setScrollRequestStatus('applied');
        return { kind: 'dispatched' };
    }
    function endFollowContentChanged() {
        const binding = scrollBinding;
        if (!binding || !currentScrollBinding(binding) || scrollAttachment)
            return;
        const follow = scrollConfig.endFollow as NativeConfig;
        if (follow?.mode !== 'while-at-end' || followState.handle.get() !== 'following' || readerContacts || Date.now() < readerIntent) {
            scrollFacts();
            return;
        }
        const view = binding.surface.ownerDocument.defaultView;
        if (!view || scrollEndWork)
            return;
        const axis = follow.axis === 'horizontal' ? 'horizontal' : 'vertical';
        const work: ScrollEndWork = { binding, axis, frame: null };
        scrollEndWork = work;
        setScrollRequestStatus('pending');
        if (scrollEndWork !== work || !currentScrollBinding(binding))
            return;
        work.frame = view.requestAnimationFrame(() => {
            if (scrollEndWork !== work)
                return;
            scrollEndWork = null;
            if (!currentScrollBinding(binding))
                return;
            if (readerContacts || Date.now() < readerIntent || followState.handle.get() !== 'following') {
                setScrollRequestStatus('rejected');
                return;
            }
            options.invoke(() => applyScroll({ kind: 'to-end', axis }));
        });
    }
    function chromeParts(): {
        track: HTMLElement;
        thumb: HTMLElement;
        axis: string;
    }[] {
        if (!scrollChrome)
            return [];
        const family = scrollChrome.anatomy as NativeAnatomyFamily;
        if (!family || !domain(family, false))
            return [];
        const thumbs = anatomyOwners(family, String(scrollChrome.thumbRole), true);
        return anatomyOwners(family, String(scrollChrome.scrollbarRole), true).flatMap(track => {
            const target = track.target();
            if (!target)
                return [];
            const thumb = thumbs.find(candidate => descends(candidate, track));
            const thumbTarget = thumb?.target();
            if (!thumbTarget)
                return [];
            const exposed = track.exposes()[String(scrollChrome!.orientationExpose)];
            const axis = readValue(exposed);
            if (axis !== 'horizontal' && axis !== 'vertical')
                throw new Error('[Scroll] composed chrome orientation expose must resolve to a portable axis.');
            return [{ track: target, thumb: thumbTarget, axis }];
        });
    }
    function projectChrome() {
        if (!ready())
            return;
        for (const control of chromeParts()) {
            const { thumb, track, axis } = control;
            let baseline = chromeTargets.get(thumb);
            if (!baseline) {
                baseline = { width: thumb.style.width, height: thumb.style.height, transform: thumb.style.transform, display: thumb.style.display, size: thumb.style.getPropertyValue('--proto-ui-scroll-thumb-size'), offset: thumb.style.getPropertyValue('--proto-ui-scroll-thumb-offset') };
                chromeTargets.set(thumb, baseline);
            }
            const facts = axis === 'horizontal' ? horizontal.handle : vertical.handle;
            const length = axis === 'horizontal' ? track.clientWidth : track.clientHeight;
            const sizeValue = Math.min(length, Math.max(18, length * facts.visibleRatio.get()));
            const offsetValue = Math.max(0, length - sizeValue) * facts.position.get();
            thumb.style.setProperty('--proto-ui-scroll-thumb-size', sizeValue + 'px');
            thumb.style.setProperty('--proto-ui-scroll-thumb-offset', offsetValue + 'px');
            if (axis === 'horizontal') {
                thumb.style.width = sizeValue + 'px';
                thumb.style.transform = 'translateX(' + offsetValue + 'px)';
            }
            else {
                thumb.style.height = sizeValue + 'px';
                thumb.style.transform = 'translateY(' + offsetValue + 'px)';
            }
            thumb.style.display = scrollProjection.handle.get() === 'composed' && facts.visibleRatio.get() < 1 ? baseline.display : 'none';
        }
    }
    function attachChrome() {
        for (const remove of chromeCleanups.splice(0))
            remove();
        for (const control of chromeParts()) {
            const { track, thumb, axis } = control;
            let drag: {
                id: number;
                start: number;
                offset: number;
            } | null = null;
            const down = (native: Event) => {
                if (!ready() || scrollProjection.handle.get() !== 'composed')
                    return;
                const event = native as PointerEvent;
                if (event.button !== 0)
                    return;
                const coordinate = axis === 'horizontal' ? event.clientX : event.clientY;
                if (event.target === thumb || thumb.contains(event.target as Node)) {
                    drag = { id: event.pointerId, start: coordinate, offset: (axis === 'horizontal' ? horizontal.handle : vertical.handle).position.get() };
                    readerContacts++;
                    readerIntent = Date.now() + 250;
                    followState.set('paused');
                    thumb.setPointerCapture(event.pointerId);
                    event.preventDefault();
                }
                else {
                    const rect = thumb.getBoundingClientRect();
                    const before = coordinate < (axis === 'horizontal' ? rect.left : rect.top);
                    options.invoke(() => applyScroll({ kind: 'page', axis, direction: before ? 'before' : 'after' }));
                    event.preventDefault();
                }
            };
            const move = (native: Event) => {
                const event = native as PointerEvent;
                if (!drag || event.pointerId !== drag.id || !ready())
                    return;
                const travel = (axis === 'horizontal' ? track.clientWidth - thumb.getBoundingClientRect().width : track.clientHeight - thumb.getBoundingClientRect().height);
                if (travel <= 0)
                    return;
                const coordinate = axis === 'horizontal' ? event.clientX : event.clientY;
                options.invoke(() => applyScroll({ kind: 'control-drag', axis, position: drag!.offset + (coordinate - drag!.start) / travel }));
                event.preventDefault();
            };
            const end = (native: Event) => {
                const event = native as PointerEvent;
                if (!drag || event.pointerId !== drag.id)
                    return;
                if (thumb.hasPointerCapture(drag.id))
                    thumb.releasePointerCapture(drag.id);
                drag = null;
                readerContacts = Math.max(0, readerContacts - 1);
                scrollFacts();
            };
            track.addEventListener('pointerdown', down);
            thumb.addEventListener('pointermove', move);
            thumb.addEventListener('pointerup', end);
            thumb.addEventListener('pointercancel', end);
            thumb.addEventListener('lostpointercapture', end);
            chromeCleanups.push(() => {
                if (drag && thumb.hasPointerCapture(drag.id))
                    thumb.releasePointerCapture(drag.id);
                drag = null;
                track.removeEventListener('pointerdown', down);
                thumb.removeEventListener('pointermove', move);
                thumb.removeEventListener('pointerup', end);
                thumb.removeEventListener('pointercancel', end);
                thumb.removeEventListener('lostpointercapture', end);
            });
        }
        projectChrome();
    }
    const scroll: NativeScroll = {
        axes: scrollAxes.handle, horizontal: horizontal.handle, vertical: vertical.handle, scrolling: scrolling.handle, projection: scrollProjection.handle, endFollow: { state: followState.handle, requestStatus: followRequest.handle },
        configure(config) {
            setup('scroll.configure');
            if (config.axes && !['horizontal', 'vertical', 'both'].includes(String(config.axes)))
                throw new Error('[Scroll] invalid axes.');
            if (config.projection && !['auto', 'system', 'composed'].includes(String(config.projection)))
                throw new Error('[Scroll] invalid projection.');
            scrollConfig = { ...scrollConfig, ...config };
            scrollAxes.set(String(scrollConfig.axes));
            const follow = scrollConfig.endFollow as NativeConfig;
            followState.set(follow?.mode === 'while-at-end' ? 'pending' : 'off');
        },
        bindComposedChrome(binding) {
            setup('scroll.bindComposedChrome');
            if (!binding.anatomy || !binding.scrollbarRole || !binding.thumbRole || !binding.orientationExpose || !binding.scope)
                throw new Error('[Scroll] composed chrome requires explicit Context/Anatomy binding.');
            scrollChrome = binding;
        },
        request(request) { runtime('scroll.request'); return applyScroll(request); },
        getSnapshot() {
            alive();
            const snapshot = (axis: NativeScrollAxis) => Object.freeze({ position: axis.position.get(), visibleRatio: axis.visibleRatio.get(), canScrollBefore: axis.canScrollBefore.get(), canScrollAfter: axis.canScrollAfter.get(), atEnd: axis.atEnd.get() });
            return Object.freeze({ axes: scrollAxes.handle.get(), horizontal: snapshot(horizontal.handle), vertical: snapshot(vertical.handle), scrolling: scrolling.handle.get(), projection: scrollProjection.handle.get(), endFollow: { state: followState.handle.get(), requestStatus: followRequest.handle.get() } });
        },
    };
    function attachScroll() {
        if (!hooks.has('asScrollSurface') || !root)
            return;
        const binding: ScrollBinding = { surface: root, epoch: generation }, surface = binding.surface;
        const attachment = { binding, requests: [] as NativeConfig[] };
        scrollAttachment = attachment;
        const acquiring = () => scrollAttachment === attachment && generation === binding.epoch && root === surface && ready();
        const current = () => currentScrollBinding(binding);
        let acquired = false;
        try {
            const preference = String(scrollConfig.requireProjection ?? scrollConfig.projection);
            if (preference === 'composed' && !scrollChrome)
                throw new Error('[Scroll] required composed projection needs authored chrome binding.');
            const projection = preference === 'composed' || preference === 'auto' && scrollChrome ? 'composed' : 'system';
            if (projection === 'composed') {
                styleProperty(surface, 'scrollbar-width', 'none');
                styleProperty(surface, '-ms-overflow-style', 'none');
            }
            styleProperty(surface, 'overflow-x', scrollConfig.axes === 'vertical' ? 'hidden' : 'auto');
            styleProperty(surface, 'overflow-y', scrollConfig.axes === 'horizontal' ? 'hidden' : 'auto');
            if (!acquiring())
                return;
            const view = surface.ownerDocument.defaultView;
            listen(surface, 'scroll', () => {
                if (!current())
                    return;
                scrolling.set(true);
                if (!current())
                    return;
                scrollFacts();
                if (!current())
                    return;
                view?.clearTimeout(scrollTimer);
                scrollTimer = view?.setTimeout(() => {
                    if (!current())
                        return;
                    scrollTimer = undefined;
                    scrolling.set(false);
                    if (current())
                        scrollFacts();
                }, 120);
            }, { passive: true });
            listen(surface, 'wheel', event => {
                if (!current())
                    return;
                readerIntent = Date.now() + 250;
                const wheel = event as WheelEvent;
                if (scrollProjection.handle.get() === 'composed') {
                    const axis = scrollConfig.axes === 'horizontal' || Math.abs(wheel.deltaX) > Math.abs(wheel.deltaY) ? 'horizontal' : 'vertical';
                    const delta = axis === 'horizontal' ? wheel.deltaX || wheel.deltaY : wheel.deltaY;
                    options.invoke(() => applyScroll({ kind: 'by', axis, delta: delta * (wheel.deltaMode === 1 ? 16 : wheel.deltaMode === 2 ? surface.clientHeight : 1) }));
                    event.preventDefault();
                }
                if (current() && followState.handle.get() !== 'off' && !(scrollConfig.axes === 'horizontal' ? horizontal.handle : vertical.handle).atEnd.get())
                    followState.set('paused');
            }, { passive: false });
            listen(surface, 'pointerdown', () => {
                if (current()) {
                    readerContacts++;
                    readerIntent = Date.now() + 250;
                }
            });
            const endContact = () => {
                if (current()) {
                    readerContacts = Math.max(0, readerContacts - 1);
                    readerIntent = Date.now() + 250;
                    scrollFacts();
                }
            };
            listen(surface.ownerDocument, 'pointerup', endContact, { capture: true });
            listen(surface.ownerDocument, 'pointercancel', endContact, { capture: true });
            listen(surface, 'keydown', () => {
                if (current())
                    readerIntent = Date.now() + 250;
            });
            if (typeof ResizeObserver !== 'undefined') {
                const resize = new ResizeObserver(() => {
                    if (current())
                        endFollowContentChanged();
                });
                resize.observe(surface);
                for (const child of surface.children)
                    resize.observe(child);
                cleanups.push(() => resize.disconnect());
            }
            if (typeof MutationObserver !== 'undefined') {
                const mutation = new MutationObserver(records => {
                    if (!current() || records.every(record => record.type === 'attributes' && (record.target === surface || isElement(record.target) && chromeTargets.has(record.target) && record.attributeName === 'style')))
                        return;
                    endFollowContentChanged();
                    if (current())
                        attachChrome();
                });
                mutation.observe(surface, { childList: true, subtree: true, characterData: true, attributes: true });
                cleanups.push(() => mutation.disconnect());
            }
            if (!acquiring())
                return;
            scrollBinding = binding;
            attachChrome();
            if (!acquiring())
                return;
            // Publish only after host resources are acquired. Reentrant position
            // requests belong to this transaction; reveal never joins its queue.
            scrollProjection.set(projection);
            if (!acquiring())
                return;
            scrollFacts();
            if (!acquiring())
                return;
            acquired = true;
        }
        finally {
            if (scrollAttachment === attachment)
                scrollAttachment = null;
        }
        if (acquired)
            for (const request of attachment.requests) {
                if (!current())
                    break;
                applyScroll(request);
            }
    }
    function rootTag(): string | null { alive(); return null; }
    function adoptControlState(): void {
        alive();
        if (root)
            throw new Error('[Modules] adopt control state before the first view mount.');
        const target = options.getRoot();
        if (!target)
            throw new Error('[Modules] hydration requires the adopted physical Root.');
        if (target.id)
            hostIds.set(options.identity, target.id);
    }
    function rootProperties(): Readonly<Record<string, string | number | boolean | null>> {
        alive();
        const result: Record<string, string | number | boolean | null> = Object.create(null);
        return result;
    }
    function projectAttributes(): Readonly<Record<string, string | null>> {
        alive();
        const result: Record<string, string | null> = Object.create(null);
        return result;
    }
    const attributeBaselines = new Map<string, {
        baseline: string | null;
        projected: string | null;
    }>();
    function projectModuleAttributes() {
        if (!ready())
            return;
        if (options.requestAttributeRefresh) {
            options.requestAttributeRefresh();
            return;
        }
        for (const [name, value] of Object.entries(projectAttributes())) {
            const current = root!.getAttribute(name);
            let ownership = attributeBaselines.get(name);
            if (!ownership) {
                ownership = { baseline: current, projected: current };
                attributeBaselines.set(name, ownership);
            }
            else if (current !== ownership.projected)
                ownership.baseline = current;
            if (current !== value) {
                if (value === null)
                    root!.removeAttribute(name);
                else
                    root!.setAttribute(name, value);
            }
            ownership.projected = value;
        }
    }
    function refresh() {
        if (disposed || !options.isAlive())
            return;
        if (!ready()) {
            requestPresentation();
            return;
        }
        projectModuleAttributes();
        requestPresentation();
    }
    function portalTarget(): HTMLElement | null { return null; }
    function unmount() {
        const previous = root;
        ++generation;
        root = null;
        {
            scrollBinding = null;
            scrollAttachment = null;
            const work = scrollEndWork;
            scrollEndWork = null;
            if (work && work.frame !== null)
                work.binding.surface.ownerDocument.defaultView?.cancelAnimationFrame(work.frame);
            if (work)
                setScrollRequestStatus('rejected');
            scrollProjection.set('unresolved');
        }
        if (previous && targets.get(previous) === owner)
            targets.delete(previous);
        const failures: unknown[] = [];
        for (const cleanup of cleanups.splice(0))
            try {
                cleanup();
            }
            catch (error) {
                failures.push(error);
            }
        for (const cleanup of chromeCleanups.splice(0))
            try {
                cleanup();
            }
            catch (error) {
                failures.push(error);
            }
        if (previous) {
            {
                previous.ownerDocument.defaultView?.clearTimeout(scrollTimer);
                scrollTimer = undefined;
            }
            for (const [name, ownership] of attributeBaselines)
                if (previous.getAttribute(name) === ownership.projected) {
                    if (ownership.baseline === null)
                        previous.removeAttribute(name);
                    else
                        previous.setAttribute(name, ownership.baseline);
                }
            for (const [name, ownership] of propertyBaselines)
                if (previous.style.getPropertyValue(name) === ownership.projected) {
                    if (ownership.value)
                        previous.style.setProperty(name, ownership.value);
                    else
                        previous.style.removeProperty(name);
                }
        }
        attributeBaselines.clear();
        propertyBaselines.clear();
        for (const [target, snapshot] of chromeTargets) {
            target.style.width = snapshot.width;
            target.style.height = snapshot.height;
            target.style.transform = snapshot.transform;
            target.style.display = snapshot.display;
            if (snapshot.size)
                target.style.setProperty('--proto-ui-scroll-thumb-size', snapshot.size);
            else
                target.style.removeProperty('--proto-ui-scroll-thumb-size');
            if (snapshot.offset)
                target.style.setProperty('--proto-ui-scroll-thumb-offset', snapshot.offset);
            else
                target.style.removeProperty('--proto-ui-scroll-thumb-offset');
        }
        {
            chromeTargets.clear();
            readerContacts = 0;
        }
        if (previous) {
            if (options.isAlive() && (options.isReady?.() ?? true)) {
                options.invoke(() => {
                    scrolling.set(false);
                });
            }
            announceTopology();
        }
        if (failures.length)
            throw new AggregateError(failures, '[Modules] view cleanup failed.');
    }
    function mount() {
        alive();
        const candidate = options.getRoot();
        if (root === candidate && ready()) {
            refresh();
            return;
        }
        unmount();
        root = candidate;
        if (!root)
            return;
        const mountEpoch = generation;
        targets.set(root, owner);
        if (root.id)
            hostIds.set(options.identity, root.id);
        try {
            const doc = root.ownerDocument;
            {
                attachScroll();
                if (mountEpoch !== generation || root !== candidate)
                    return;
            }
            refresh();
            announceTopology();
            if (typeof MutationObserver !== 'undefined' && (claims.size || scrollChrome)) {
                const mutation = new MutationObserver(records => {
                    if (!records.some(record => record.type === 'childList'))
                        return;
                    announceTopology();
                    if (scrollChrome)
                        attachChrome();
                });
                mutation.observe(root, { childList: true, subtree: true });
                cleanups.push(() => mutation.disconnect());
            }
        }
        catch (error) {
            if (mountEpoch === generation && root === candidate)
                try {
                    unmount();
                }
                catch (cleanup) {
                    throw new AggregateError([error, cleanup], '[Modules] mount and cleanup failed.');
                }
            throw error;
        }
    }
    const registeredFacts = new Set<object>();
    function registerFacts<T extends boolean | string | number>(state: NativeObserved<T>) {
        if (registeredFacts.has(state))
            return;
        registeredFacts.add(state);
        options.registerObservedState?.(state);
    }
    const capabilities: NativeModuleCapabilities<Run> = {
        anatomy,
        asScrollSurface() {
            declare('asScrollSurface');
            registerFacts(scroll.axes);
            registerFacts(scroll.scrolling);
            registerFacts(scroll.projection);
            registerFacts(scroll.endFollow.state);
            registerFacts(scroll.endFollow.requestStatus);
            for (const axis of [scroll.horizontal, scroll.vertical]) {
                registerFacts(axis.position);
                registerFacts(axis.visibleRatio);
                registerFacts(axis.canScrollBefore);
                registerFacts(axis.canScrollAfter);
                registerFacts(axis.atEnd);
            }
            return scroll;
        },
        rootTag, rootProperties, projectAttributes, portalTarget, adoptControlState, refresh, mount, unmount,
        dispose() {
            if (disposed)
                return;
            const rootOwner = logicalRoot(owner);
            const failures: unknown[] = [];
            try {
                unmount();
            }
            catch (error) {
                failures.push(error);
            }
            disposed = true;
            nativeNotifications.length = 0;
            owners.delete(options.identity);
            claims.clear();
            hooks.clear();
            topologySubscribers.clear();
            for (const cleanup of terminalCleanups.splice(0))
                try {
                    cleanup();
                }
                catch (error) {
                    failures.push(error);
                }
            anatomyVersions.clear();
            announceTopology(rootOwner);
            if (failures.length)
                throw new AggregateError(failures, '[Modules] terminal cleanup failed.');
        }
    };
    owners.set(options.identity, owner);
    return capabilities;
}
