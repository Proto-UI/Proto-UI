import { owners, parts, targets, hostIds, logicalRoot, ancestor, hostOrder, type Claim, type Owner } from './ownership-v2';
export type NativeConfig = Readonly<Record<string, unknown>>;
export type NativeStateEvent<T> = {
    type: 'next';
    prev: T;
    next: T;
    reason?: unknown;
} | {
    type: 'disconnect';
    reason: 'unmount';
};
export type NativeObserved<T> = {
    get(): T;
    watch<R>(callback: (run: R, event: NativeStateEvent<T>) => void): () => void;
    subscribe(callback: (event: {
        type: 'next';
        prev: T;
        next: T;
        reason?: unknown;
    }) => void): () => void;
};
export type NativeOwnedState<T> = {
    get(): T;
    set(value: T, reason?: unknown): void;
    setDefault(value: T): void;
};
export type NativeOwnedStateSpec = {
    kind: 'bool' | 'string' | 'enum' | 'number.discrete';
    options?: readonly string[];
};
type NativeStateCell<T> = {
    handle: NativeOwnedState<T>;
    set(value: T): void;
};
export type NativeFocusRequest = {
    reason?: 'programmatic' | 'keyboard' | 'pointer';
    preventScroll?: boolean;
    defer?: boolean;
};
export type NativeFocusScopeActivation = NativeFocusRequest & {
    entry?: 'configured' | 'manual';
};
export type NativeFocusBase = {
    focused: NativeObserved<boolean>;
    focusVisible: NativeObserved<boolean>;
    focusable: NativeObserved<boolean>;
    configure(config: NativeConfig): void;
    setDisabled(value: boolean): void;
    focusSelf(options?: NativeFocusRequest): void;
};
export interface NativeFocusEntry {
    configure(config: NativeConfig): void;
    setDisabled(value: boolean): void;
    focus(options?: NativeFocusRequest): void;
}
export interface NativeFocusRoving {
    active: NativeObserved<boolean>;
    hasFocused: NativeObserved<boolean>;
    configure(config: NativeConfig): void;
    setLoop(value: boolean): void;
    setOrientation(value: string): void;
    focusFirst(options?: NativeFocusRequest): void;
    focusLast(options?: NativeFocusRequest): void;
    focusSelected(options?: NativeFocusRequest): void;
    focusNext(): void;
    focusPrev(): void;
}
export interface NativeFocusScope {
    active: NativeObserved<boolean>;
    hasFocused: NativeObserved<boolean>;
    configure(config: NativeConfig): void;
    focusFirst(): void;
    focusLast(): void;
    focusNext(): void;
    focusPrev(): void;
    focusSelected(): void;
    activate(options?: NativeFocusScopeActivation): void;
    deactivate(options?: NativeFocusRequest): void;
    restoreFocus(): void;
    isActive(): boolean;
    getRoving(): NativeFocusRoving | null;
}
export type NativeAnatomyFamily = {
    debugName: string;
    roles: Readonly<Record<string, {
        cardinality: {
            min: number;
            max: number | '*';
        };
        requires?: readonly {
            kind: string;
            name: string;
        }[];
    }>>;
    relations?: readonly unknown[];
    profiles?: Readonly<Record<string, unknown>>;
};
export interface NativeAnatomyPart {
    readonly role: string;
    hasExpose(key: string): boolean;
    getExpose(key: string): unknown | null;
    hasHook(name: string): boolean;
}
export interface NativeAnatomyOrder {
    version(family: NativeAnatomyFamily): number;
    parts(family: NativeAnatomyFamily): readonly NativeAnatomyPart[];
    partsOf(family: NativeAnatomyFamily, role: string): readonly NativeAnatomyPart[];
    indexOfSelf(family: NativeAnatomyFamily, role: string): number;
    prevOfSelf(family: NativeAnatomyFamily, role: string): NativeAnatomyPart | null;
    nextOfSelf(family: NativeAnatomyFamily, role: string): NativeAnatomyPart | null;
}
export interface NativeAnatomy<Run = unknown> extends NativeAnatomyOrder {
    claim(family: NativeAnatomyFamily, declaration: {
        role: string;
        profile?: string;
    }): void;
    has(family: NativeAnatomyFamily, role: string): boolean;
    subscribeParts(family: NativeAnatomyFamily, role: string, callback: (run: Run, parts: readonly NativeAnatomyPart[]) => void): () => void;
    readonly order: NativeAnatomyOrder;
}
export type NativeCollectionSnapshot = Readonly<Record<string, unknown> & {
    index: number;
    total: number;
    first: boolean;
    last: boolean;
}>;
export interface NativeCollection {
    readonly count: NativeOwnedState<number>;
    configure(config: NativeConfig): void;
    getItems(): readonly NativeCollectionSnapshot[];
    getCount(): number;
}
export interface NativeCollectionItem {
    readonly collectionIndex: NativeOwnedState<number>;
    readonly collectionTotal: NativeOwnedState<number>;
    readonly collectionFirst: NativeOwnedState<boolean>;
    readonly collectionLast: NativeOwnedState<boolean>;
    configure(config: NativeConfig): void;
    getSnapshot(): NativeCollectionSnapshot;
}
export interface NativeBoundary<Run = unknown> {
    configure(config: NativeConfig): void;
    observe(type: string): void;
    setStackActive(active: boolean): void;
    registerRegion(target: unknown, options?: NativeConfig): () => void;
    unregisterRegion(target: unknown): void;
    classify(sample?: NativeConfig): 'inside' | 'outside' | 'unknown';
    notify(sample?: NativeConfig): 'inside' | 'outside' | 'unknown';
    subscribeOutside(callback: (event: NativeConfig) => void): () => void;
}
export interface NativeHitParticipation {
    configure(config: NativeConfig): void;
    registerRegion(target: unknown, options?: NativeConfig): () => void;
    unregisterRegion(target: unknown): void;
}
export type NativePositionSnapshot = Readonly<{
    side: string;
    align: string;
    strategy: string;
}>;
export interface NativePositioning {
    connect(connection: NativeConfig): void;
    update(config: NativeConfig): void;
    requestUpdate(): void;
    disconnect(): void;
    getSnapshot(): NativePositionSnapshot | null;
}
export interface NativeOverlay {
    readonly open: NativeObserved<boolean>;
    configure(config: NativeConfig): void;
    isOpen(): boolean;
    openOverlay(reason?: string): void;
    close(reason?: string): void;
    toggle(reason?: string): void;
    updatePosition(config: NativeConfig): void;
    registerTrigger(target: unknown): void;
    registerAnchor(target: unknown): void;
    registerAnchorPart(part: NativeAnatomyPart | null): void;
    registerContent(target: unknown): void;
    getPositionSnapshot(): NativePositionSnapshot | null;
    keepMounted(): void;
    bindPresence(binding: NativeConfig): void;
}
export interface NativeScrollAxis {
    position: NativeObserved<number>;
    visibleRatio: NativeObserved<number>;
    canScrollBefore: NativeObserved<boolean>;
    canScrollAfter: NativeObserved<boolean>;
    atEnd: NativeObserved<boolean>;
}
export type NativeScrollAxisSnapshot = Readonly<{
    position: number;
    visibleRatio: number;
    canScrollBefore: boolean;
    canScrollAfter: boolean;
    atEnd: boolean;
}>;
export type NativeScrollSnapshot = Readonly<{
    axes: string;
    horizontal: NativeScrollAxisSnapshot;
    vertical: NativeScrollAxisSnapshot;
    scrolling: boolean;
    projection: string;
    endFollow: Readonly<{
        state: string;
        requestStatus: string;
    }>;
}>;
export type NativeScrollPositionRequest = {
    kind: 'by';
    axis: 'horizontal' | 'vertical';
    delta: number;
} | {
    kind: 'to' | 'control-drag';
    axis: 'horizontal' | 'vertical';
    position: number;
} | {
    kind: 'page';
    axis: 'horizontal' | 'vertical';
    direction: 'before' | 'after';
} | {
    kind: 'to-end';
    axis: 'horizontal' | 'vertical';
};
export type NativeScrollRequest = NativeScrollPositionRequest | {
    kind: 'reveal';
    axis: 'vertical';
    family: NativeAnatomyFamily;
    part: NativeAnatomyPart;
};
export type NativeScrollRequestOutcome = {
    kind: 'dispatched';
} | {
    kind: 'queued';
} | {
    kind: 'rejected';
    reason: 'not-mounted' | 'not-declared' | 'unavailable';
};
export interface NativeScroll {
    axes: NativeObserved<string>;
    horizontal: NativeScrollAxis;
    vertical: NativeScrollAxis;
    scrolling: NativeObserved<boolean>;
    projection: NativeObserved<string>;
    endFollow: {
        state: NativeObserved<string>;
        requestStatus: NativeObserved<string>;
    };
    configure(config: NativeConfig): void;
    bindComposedChrome(binding: NativeConfig): void;
    request(request: NativeScrollRequest): NativeScrollRequestOutcome;
    getSnapshot(): NativeScrollSnapshot;
}
export type NativeTextEvent = Readonly<{
    type: string;
    value: string;
    composing: boolean;
    data: string | null;
    inputType: string | null;
}>;
export type NativeImageEvent = Readonly<{
    status: string;
    previousStatus: string;
    source: string;
}>;
export interface NativeTextControl<Run = unknown> {
    on(type: string, callback: (run: Run, event: NativeTextEvent) => void): () => void;
    sync(patch: NativeConfig): void;
    snapshot(): {
        value: string;
        composing: boolean;
    } | null;
}
export interface NativeImageView<Run = unknown> {
    on(type: string, callback: (run: Run, event: NativeImageEvent) => void): () => void;
    sync(patch: NativeConfig): void;
    snapshot(): {
        source: string;
        loadingStatus: string;
        fit: string;
    } | null;
}
export interface NativeTableStructure {
    readonly role: string;
    readonly states: {
        a11yRole: NativeOwnedState<string>;
        rowCount: NativeOwnedState<number>;
        columnCount: NativeOwnedState<number>;
        row: NativeOwnedState<number>;
        column: NativeOwnedState<number>;
        rowSpan: NativeOwnedState<number>;
        columnSpan: NativeOwnedState<number>;
    };
    configure(patch: NativeConfig): void;
    getObjectRef(): object;
    getSnapshot(): NativeTableSnapshot | null;
}
export type NativeTableCell = Readonly<{
    ref: object;
    kind: 'column-header' | 'row-header' | 'cell';
    row: number;
    column: number;
    rowSpan: number;
    columnSpan: number;
    columnHeaders: readonly object[];
    rowHeaders: readonly object[];
    orderedHeaders: readonly object[];
}>;
export type NativeTableRow = Readonly<{
    ref: object;
    index: number;
    cells: readonly NativeTableCell[];
}>;
export type NativeTableDiagnostic = Readonly<{
    code: string;
    ref?: object;
    row?: number;
    headerKey?: string;
}>;
export type NativeTableSnapshot = Readonly<{
    root: object;
    caption: object | undefined;
    rowCount: number;
    columnCount: number;
    rows: readonly NativeTableRow[];
    valid: boolean;
    diagnostics: readonly NativeTableDiagnostic[];
}>;
export interface NativeAccessibleExtension {
    readonly objectRef: object;
    id(value: string | {
        get(): string | null | undefined;
    }): void;
    name(value: string | {
        get(): string | null | undefined;
    }): void;
    description(value: string | {
        get(): string | null | undefined;
    }): void;
    relation(kind: string, target: NativeConfig): void;
    tree(config: NativeConfig): void;
    level(value: number | {
        get(): number;
    }): void;
}
export type NativeControlLabelAnatomyPair = Readonly<{
    family: NativeAnatomyFamily;
    labelRole: string;
    targetRole: string;
}>;
export type NativeControlLabelRequest = Readonly<{
    source: 'pointer' | 'accessibility';
    isCurrent(): boolean;
}>;
export type NativeControlLabelHandle = Readonly<{
    sync(options: Readonly<{
        naming: boolean;
        activation: boolean;
    }>): void;
}>;
export type NativeControlLabel<Run = unknown> = Readonly<{
    label(pair?: NativeControlLabelAnatomyPair): NativeControlLabelHandle;
    target(activate: (run: Run, request: NativeControlLabelRequest) => void, pair?: NativeControlLabelAnatomyPair): NativeControlLabelHandle;
}>;
export type NativeModuleCapability<Kind extends string, Run = unknown> = Kind extends 'control-label' ? NativeControlLabel<Run> : Kind extends 'control-label-handle' ? NativeControlLabelHandle : Kind extends 'control-label-request' ? NativeControlLabelRequest : Kind extends 'binding-disposer' ? () => void : Kind extends 'collection-snapshot' ? NativeConfig : Kind extends 'collection-snapshot-list' ? readonly NativeConfig[] : Kind extends 'focus-entry' ? NativeFocusEntry : Kind extends 'focus-roving' ? NativeFocusRoving : Kind extends 'focus-scope' ? NativeFocusScope : Kind extends 'anatomy-family' ? NativeAnatomyFamily : Kind extends 'anatomy-part' ? NativeAnatomyPart : Kind extends 'anatomy-parts' ? readonly NativeAnatomyPart[] : Kind extends 'anatomy-order' ? NativeAnatomyOrder : Kind extends 'collection' ? NativeCollection : Kind extends 'collection-item' ? NativeCollectionItem : Kind extends 'boundary' ? NativeBoundary<Run> : Kind extends 'hit-participation' ? NativeHitParticipation : Kind extends 'positioning' ? NativePositioning : Kind extends 'overlay' ? NativeOverlay : Kind extends 'scroll' ? NativeScroll : Kind extends 'scroll-axis' ? NativeScrollAxis : Kind extends 'scroll-follow' ? NativeScroll['endFollow'] : Kind extends 'text-control' ? NativeTextControl<Run> : Kind extends 'image-view' ? NativeImageView<Run> : Kind extends 'table-structure' ? NativeTableStructure : Kind extends 'table-states' ? NativeTableStructure['states'] : Kind extends 'table-snapshot' ? NativeTableSnapshot : Kind extends 'table-row' ? NativeTableRow : Kind extends 'table-cell' ? NativeTableCell : Kind extends 'table-diagnostic' ? NativeTableDiagnostic : Kind extends 'table-row-list' ? readonly NativeTableRow[] : Kind extends 'table-cell-list' ? readonly NativeTableCell[] : Kind extends 'table-diagnostic-list' ? readonly NativeTableDiagnostic[] : Kind extends 'a11y-ref-list' ? readonly object[] : Kind extends 'subscription-disposer' ? () => void : Kind extends 'host-target' ? Element : Kind extends 'focus-scope-key' | 'focus-roving-key' | 'a11y-ref' ? object : NativeConfig;
export interface NativeModuleCapabilities<Run = unknown> {
    anatomy: NativeAnatomy<Run>;
    rootTag(): string | null;
    rootProperties(): Readonly<Record<string, string | number | boolean | null>>;
    projectAttributes(): Readonly<Record<string, string | null>>;
    portalTarget(): HTMLElement | null;
    adoptControlState(): void;
    mount(): void;
    unmount(): void;
    refresh(): void;
    dispose(): void;
}
export interface NativeAdapterModuleOptions<Run> {
    ensureSetup(operation: string): void;
    ensureRuntime(operation: string): void;
    ensureEvent(operation: string): void;
    isAlive(): boolean;
    isReady?(): boolean;
    invoke<T>(callback: () => T): T;
    getRun(): Run;
    getResolvedProps(): Readonly<Record<string, unknown>>;
    getRoot(): HTMLElement | null;
    getHost?(): HTMLElement | null;
    declarations: readonly {
        id: string;
        config: NativeConfig;
    }[];
    getLogicalParent(): object | null;
    identity: object;
    registerObservedState?<T extends boolean | string | number>(state: NativeObserved<T>): void;
    getExposes?(): Readonly<Record<string, unknown>>;
    setPresent?(value: boolean): void;
    requestHostUpdate?(): void;
    baseFocus?(): NativeFocusBase;
    getAccessibleRole?(): string | null;
    /** Internal focus bridge cleanup; never blurs the physical target. */
    cancelPendingFocus?(): void;
    emit?(key: string): void;
    createOwnedState?<T extends boolean | string | number>(name: string, initial: T, spec?: NativeOwnedStateSpec): NativeOwnedState<T>;
    watchState?<T>(state: {
        get(): T;
    }, callback: (run: Run, event: NativeStateEvent<T>) => void): () => void;
    isPropProvided?(key: string): boolean;
    getMeta?(key: string): unknown;
    registerExpose?(key: string, value: unknown): void;
    tableFamily?: NativeAnatomyFamily;
    requestAttributeRefresh?(): void;
    getAttributeBaseline?(name: string): string | null;
    subscribeState?(state: {
        get(): unknown;
    }, callback: () => void): () => void;
}
type NativeTableCellInput = {
    ref: object;
    kind: 'headerCell' | 'cell';
    headerKey?: string;
    headerKind?: unknown;
    headers: readonly string[];
    rowSpan?: number;
    columnSpan?: number;
};
type NativeTableInput = {
    root: object;
    captions: readonly object[];
    rows: readonly {
        ref: object;
        cells: readonly NativeTableCellInput[];
    }[];
    unmatchedCells: readonly object[];
    roleMismatches: readonly object[];
};
export function createNativeAdapterModules<Run>(options: NativeAdapterModuleOptions<Run>): NativeModuleCapabilities<Run> {
    let disposed = false;
    let root: HTMLElement | null = null;
    let generation = 0;
    let hostProperties: Readonly<Record<string, string | number | boolean | null>> | null = null;
    let hostPortal: HTMLElement | null = null;
    const cleanups: (() => void)[] = [];
    const terminalCleanups: (() => void)[] = [];
    const propertyBaselines = new Map<string, {
        value: string;
        projected: string;
    }>();
    const hooks = new Set<string>();
    const claims = new Map<object, Claim>();
    const topologySubscribers = new Set<() => void>();
    const focusConfig: Record<string, unknown> = { disabled: false, navParticipation: 'auto' };
    const scopeConfig: Record<string, unknown> = { trap: false, loop: false, navigation: 'tab', orientation: 'both', entry: 'first', entryFallback: 'none', restore: 'previous', emptyPolicy: 'container' };
    const rovingConfig: Record<string, unknown> = { loop: false, navigation: 'arrow', orientation: 'both', entry: 'active', selectOnFocus: false };
    const owner: Owner = { identity: options.identity, parent: options.getLogicalParent, target: () => root, host: () => root ? options.getHost?.() ?? root : null, alive: () => !disposed && options.isAlive(), hooks, claims, exposes: () => options.getExposes?.() ?? {}, focusConfig, scopeConfig, rovingConfig, selected: false, active: false, scopeDeclared: false, rovingDeclared: false, focusDeclared: false, entryDeclared: false, scopeActive: false, focus: () => { throw new Error('[Focus] owner does not declare focus.'); }, cancelPendingFocus() {
        }, changed: () => {
            const epoch = generation;
            for (const callback of [...topologySubscribers]) {
                if (epoch !== generation || !ready() || !(options.isReady?.() ?? true))
                    break;
                if (topologySubscribers.has(callback))
                    options.invoke(callback);
            }
            refresh();
        } };
    if (owners.has(options.identity))
        throw new Error('[Modules] duplicate live owner identity.');
    function alive() {
        if (disposed || !options.isAlive())
            throw new Error('[Modules] owner is terminally disposed.');
    }
    function setup(operation: string) { alive(); options.ensureSetup(operation); }
    function requestPresentation() {
        if (disposed || !options.isAlive() || !(options.isReady?.() ?? true))
            return;
        const next = rootProperties(), portal = portalTarget();
        const changed = !hostProperties || portal !== hostPortal || Object.keys(next).length !== Object.keys(hostProperties).length || Object.keys(next).some(key => next[key] !== hostProperties![key]);
        hostProperties = next;
        hostPortal = portal;
        if (changed)
            options.requestHostUpdate?.();
    }
    function ready() { return !disposed && options.isAlive() && !!root && root === options.getRoot() && root.isConnected; }
    function announceTopology(rootOwner = logicalRoot(owner)) {
        for (const participant of [...owners.values()])
            if (participant.alive() && logicalRoot(participant) === rootOwner)
                participant.changed();
    }
    function domain(family: NativeAnatomyFamily, required = true): Owner | null {
        const found = ancestor(owner, participant => participant.claims.get(family)?.role === 'root');
        if (!found && required)
            throw new Error('[Anatomy] current owner has no root domain for ' + family.debugName);
        return found;
    }
    function anatomyOwners(family: NativeAnatomyFamily, role?: string, ordered = false): Owner[] {
        const rootOwner = domain(family);
        const found: Owner[] = [];
        for (const participant of owners.values())
            if (participant.alive() && participant.claims.has(family) && (!role || participant.claims.get(family)!.role === role)
                && ancestor(participant, current => current.claims.get(family)?.role === 'root') === rootOwner)
                found.push(participant);
        return ordered ? found.sort(hostOrder) : found;
    }
    const anatomyVersions = new Map<object, {
        members: readonly Owner[];
        version: number;
    }>();
    const anatomyOrder: NativeAnatomyOrder = {
        version(family) {
            alive();
            const members = anatomyOwners(family, undefined, true);
            const previous = anatomyVersions.get(family);
            if (!previous) {
                anatomyVersions.set(family, { members, version: 0 });
                return 0;
            }
            if (members.length !== previous.members.length || members.some((member, index) => member !== previous.members[index])) {
                previous.members = members;
                ++previous.version;
            }
            return previous.version;
        },
        parts(family) { alive(); return anatomyOwners(family, undefined, true).map(participant => participant.claims.get(family)!.part); },
        partsOf(family, role) { alive(); return anatomyOwners(family, role, true).map(participant => participant.claims.get(family)!.part); },
        indexOfSelf(family, role) { alive(); return anatomyOwners(family, role, true).indexOf(owner); },
        prevOfSelf(family, role) { const members = anatomyOwners(family, role, true); const index = members.indexOf(owner); return index > 0 ? members[index - 1].claims.get(family)!.part : null; },
        nextOfSelf(family, role) { const members = anatomyOwners(family, role, true); const index = members.indexOf(owner); return index >= 0 && index + 1 < members.length ? members[index + 1].claims.get(family)!.part : null; },
    };
    const anatomy: NativeAnatomy<Run> = {
        ...anatomyOrder, order: anatomyOrder,
        claim(family, declaration) {
            setup('anatomy.claim');
            if (!family?.roles[declaration.role] || claims.has(family))
                throw new Error('[Anatomy] invalid/duplicate family role claim.');
            if (declaration.profile && (declaration.role !== 'root' || !family.profiles?.[declaration.profile]))
                throw new Error('[Anatomy] invalid root profile.');
            const part: NativeAnatomyPart = Object.freeze({ role: declaration.role, hasExpose(key: string) { return Object.hasOwn(owner.exposes(), key); }, getExpose(key: string) { return owner.exposes()[key] ?? null; }, hasHook(name: string) { return hooks.has(name); } });
            claims.set(family, { family, ...declaration, part });
            parts.set(part, owner);
        },
        has(family, role) { alive(); return domain(family, false) !== null && anatomyOwners(family, role).length > 0; },
        parts(family) { alive(); return anatomyOwners(family).map(participant => participant.claims.get(family)!.part); },
        partsOf(family, role) { alive(); return anatomyOwners(family, role).map(participant => participant.claims.get(family)!.part); },
        subscribeParts(family, role, callback) {
            setup('anatomy.subscribeParts');
            let previous: readonly NativeAnatomyPart[] = [];
            const changed = () => {
                if (!domain(family, false))
                    return;
                const next = anatomyOrder.partsOf(family, role);
                if (next.length === previous.length && next.every((part, index) => part === previous[index]))
                    return;
                previous = next;
                callback(options.getRun(), next);
            };
            topologySubscribers.add(changed);
            return () => { setup('anatomy.subscribeParts.off'); topologySubscribers.delete(changed); };
        },
    };
    function rootTag(): string | null { alive(); return null; }
    function adoptControlState(): void {
        alive();
        if (root)
            throw new Error('[Modules] adopt control state before the first view mount.');
        const target = options.getRoot();
        if (!target)
            throw new Error('[Modules] hydration requires the adopted physical Root.');
        if (target.id)
            hostIds.set(options.identity, target.id);
    }
    function rootProperties(): Readonly<Record<string, string | number | boolean | null>> {
        alive();
        const result: Record<string, string | number | boolean | null> = Object.create(null);
        return result;
    }
    function projectAttributes(): Readonly<Record<string, string | null>> {
        alive();
        const result: Record<string, string | null> = Object.create(null);
        return result;
    }
    const attributeBaselines = new Map<string, {
        baseline: string | null;
        projected: string | null;
    }>();
    function projectModuleAttributes() {
        if (!ready())
            return;
        if (options.requestAttributeRefresh) {
            options.requestAttributeRefresh();
            return;
        }
        for (const [name, value] of Object.entries(projectAttributes())) {
            const current = root!.getAttribute(name);
            let ownership = attributeBaselines.get(name);
            if (!ownership) {
                ownership = { baseline: current, projected: current };
                attributeBaselines.set(name, ownership);
            }
            else if (current !== ownership.projected)
                ownership.baseline = current;
            if (current !== value) {
                if (value === null)
                    root!.removeAttribute(name);
                else
                    root!.setAttribute(name, value);
            }
            ownership.projected = value;
        }
    }
    function refresh() {
        if (disposed || !options.isAlive())
            return;
        if (!ready()) {
            requestPresentation();
            return;
        }
        projectModuleAttributes();
        requestPresentation();
    }
    function portalTarget(): HTMLElement | null { return null; }
    function unmount() {
        const previous = root;
        ++generation;
        root = null;
        if (previous && targets.get(previous) === owner)
            targets.delete(previous);
        const failures: unknown[] = [];
        for (const cleanup of cleanups.splice(0))
            try {
                cleanup();
            }
            catch (error) {
                failures.push(error);
            }
        if (previous) {
            for (const [name, ownership] of attributeBaselines)
                if (previous.getAttribute(name) === ownership.projected) {
                    if (ownership.baseline === null)
                        previous.removeAttribute(name);
                    else
                        previous.setAttribute(name, ownership.baseline);
                }
            for (const [name, ownership] of propertyBaselines)
                if (previous.style.getPropertyValue(name) === ownership.projected) {
                    if (ownership.value)
                        previous.style.setProperty(name, ownership.value);
                    else
                        previous.style.removeProperty(name);
                }
        }
        attributeBaselines.clear();
        propertyBaselines.clear();
        if (previous) {
            if (options.isAlive() && (options.isReady?.() ?? true)) {
            }
            announceTopology();
        }
        if (failures.length)
            throw new AggregateError(failures, '[Modules] view cleanup failed.');
    }
    function mount() {
        alive();
        const candidate = options.getRoot();
        if (root === candidate && ready()) {
            refresh();
            return;
        }
        unmount();
        root = candidate;
        if (!root)
            return;
        const mountEpoch = generation;
        targets.set(root, owner);
        if (root.id)
            hostIds.set(options.identity, root.id);
        try {
            const doc = root.ownerDocument;
            refresh();
            announceTopology();
            if (typeof MutationObserver !== 'undefined' && (claims.size)) {
                const mutation = new MutationObserver(records => {
                    if (!records.some(record => record.type === 'childList'))
                        return;
                    announceTopology();
                });
                mutation.observe(root, { childList: true, subtree: true });
                cleanups.push(() => mutation.disconnect());
            }
        }
        catch (error) {
            if (mountEpoch === generation && root === candidate)
                try {
                    unmount();
                }
                catch (cleanup) {
                    throw new AggregateError([error, cleanup], '[Modules] mount and cleanup failed.');
                }
            throw error;
        }
    }
    const capabilities: NativeModuleCapabilities<Run> = {
        anatomy,
        rootTag, rootProperties, projectAttributes, portalTarget, adoptControlState, refresh, mount, unmount,
        dispose() {
            if (disposed)
                return;
            const rootOwner = logicalRoot(owner);
            const failures: unknown[] = [];
            try {
                unmount();
            }
            catch (error) {
                failures.push(error);
            }
            disposed = true;
            owners.delete(options.identity);
            claims.clear();
            hooks.clear();
            topologySubscribers.clear();
            for (const cleanup of terminalCleanups.splice(0))
                try {
                    cleanup();
                }
                catch (error) {
                    failures.push(error);
                }
            anatomyVersions.clear();
            announceTopology(rootOwner);
            if (failures.length)
                throw new AggregateError(failures, '[Modules] terminal cleanup failed.');
        }
    };
    owners.set(options.identity, owner);
    return capabilities;
}
