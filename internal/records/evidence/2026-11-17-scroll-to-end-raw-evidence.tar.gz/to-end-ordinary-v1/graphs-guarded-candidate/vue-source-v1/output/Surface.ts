// Editable Vue 3 source. Profile: vue-source-v1; no Proto Runtime or Adapter dependency.
// Inline native costs: owner/update queue, constrained state subscriptions, prop resolution/watchers,
// public boundary guards, view commit lifecycle and native element/slot composition.
// Source graph SHA-256: af1b1717bea939993f099ae8feb4774d67a008656ea11091e321874d6b786160



import * as __puiVueVue from 'vue';


import { createNativeInteraction as __puiVueCreateInteraction, type NativeInteraction as __puiVueNativeInteraction, type NativeFocus as __puiVueFocus, type NativeAccessible as __puiVueAccessible, type NativeObservedState as __puiVueObservedState, type NativeInput as __puiVueInput } from './.proto-ui/interaction/native-2d89a78d93dfffe7-v2';
import type { NativeModuleCapability as __puiVueModuleCapability } from './.proto-ui/interaction/modules-2d89a78d93dfffe7-v2';
import { createContextScope as __puiVueCreateContextScope, scopeKey as __puiVueScopeKey, acceptsContextValue as __puiVueAcceptsContextValue, type ContextScope as __puiVueContextScope } from './.proto-ui/context/scope-v1';

import { declaration as __puiVueStatic0 } from "./.proto-ui/declaration/anatomy/family-9cce0127f15063f6a64b4e541aa9d587";
import { declaration as __puiVueStatic1 } from "./.proto-ui/declaration/anatomy/family-6cd0be0b284d3faa349f16ea9900e0c1";



type __puiVueRun = Readonly<{ readonly owner: symbol }>;
type __puiVueStateEvent<T> = { type: 'next'; prev: T; next: T; reason?: unknown } | {type:'disconnect';reason:'unmount'};
type __puiVueSpec = Readonly<{ kind: 'bool' | 'enum' | 'string' | 'number.range' | 'number.discrete'; options?: readonly (string | number)[]; min?: number; max?: number; step?: number; clamp?: boolean }>;
type __puiVuePropSpec = { type: unknown; default?: unknown; empty?: 'accept' | 'fallback' | 'error'; range?: { min?: number; max?: number }; options?: readonly unknown[] };
type __puiVueWatchInfo = { changedKeysAll: string[]; changedKeysMatched: string[] };
export type __puiVuePublicState<T> = { get(): T; subscribe(callback: (event: __puiVueStateEvent<T>) => void): () => void; unsubscribe(off: () => void): void; readonly spec: __puiVueSpec };
type __puiVueState<T> = __puiVuePublicState<T> & { setDefault(next: T): void; set(next: T, reason?: unknown): void };
type __puiVueEpoch = { id: number; active: boolean; committed: boolean };
type __puiVueFrame = { epoch: __puiVueEpoch; slotUsed: boolean };
export type GeneratedProps = {

};
export type GeneratedResolvedProps = {

};
export type GeneratedExposes = {
  readonly "hide": () => void;
  readonly "show": () => void;
  readonly "reveal": (index: number) => { "kind": "dispatched" } | { "kind": "queued" } | { "kind": "rejected"; "reason": "not-mounted" | "not-declared" | "unavailable" } | { "kind": string; "reason": string };
  readonly "revealOther": (index: number) => { "kind": "dispatched" } | { "kind": "queued" } | { "kind": "rejected"; "reason": "not-mounted" | "not-declared" | "unavailable" } | { "kind": string; "reason": string };
  readonly "revealSelf": () => { "kind": "dispatched" } | { "kind": "queued" } | { "kind": "rejected"; "reason": "not-mounted" | "not-declared" | "unavailable" } | { "kind": string; "reason": string };
  readonly "revealSurface": (index: number) => { "kind": "dispatched" } | { "kind": "queued" } | { "kind": "rejected"; "reason": "not-mounted" | "not-declared" | "unavailable" } | { "kind": string; "reason": string };
  readonly "capture": (index: number) => void;
  readonly "revealSaved": () => { "kind": "dispatched" } | { "kind": "queued" } | { "kind": "rejected"; "reason": "not-mounted" | "not-declared" | "unavailable" } | { "kind": string; "reason": string };
  readonly "armCompletionReveal": () => void;
  readonly "requestEnd": () => { "kind": "dispatched" } | { "kind": "queued" } | { "kind": "rejected"; "reason": "not-mounted" | "not-declared" | "unavailable" };
  readonly "readCompletionTrace": () => { "visits": number; "beforeAtEnd": boolean; "beforeState": string; "nestedKind": string; "afterAtEnd": boolean; "afterState": string };
  readonly "read": () => { "axes": string; "horizontal": { "position": number; "visibleRatio": number; "canScrollBefore": boolean; "canScrollAfter": boolean; "atEnd": boolean }; "vertical": { "position": number; "visibleRatio": number; "canScrollBefore": boolean; "canScrollAfter": boolean; "atEnd": boolean }; "scrolling": boolean; "projection": string; "endFollow": { "state": string; "requestStatus": string } };
};
export type GeneratedHandle = { update(): void; getExposes(): GeneratedExposes };

// The slot is a real Vue child render, so authored Vue children retain native ownership.
const __puiVueSlotView = __puiVueVue.defineComponent({
  name: 'CompiledSlot', inheritAttrs: false,
  props: { read: { type: Function as __puiVueVue.PropType<() => __puiVueVue.VNodeChild>, required: true } },
  setup(props) { return () => props.read!(); },
});

export const CompiledComponent = __puiVueVue.defineComponent({
  name: "scroll-family-surface", inheritAttrs: false,
  props: { instanceAssociations: { type: Object as __puiVueVue.PropType<Readonly<{controlLabel?: object | null}>>, default: undefined } },
  emits: [],
  setup(_props, __puiVueContext) {
    // Protocol values intentionally do not enter Vue's reactive state graph.
    const __puiVueInstance = __puiVueVue.getCurrentInstance()!;

    const __puiVueRevision = __puiVueVue.shallowRef(0);
    const __puiVueHostRevision = __puiVueVue.shallowRef(0);
    let __puiVueHostScheduled = false;
    const __puiVuePresent = __puiVueVue.shallowRef(true);
    const __puiVueSlotRevision = __puiVueVue.shallowRef(0);
    let __puiVueDisposed = false, __puiVueDisposing = false, __puiVueInternalTeardown = false;
    let __puiVueQueued = false, __puiVueRequested = false, __puiVueQueueTicket = 0;
    let __puiVueEpochId = 0;
    let __puiVueCurrentEpoch: __puiVueEpoch | undefined;

    const __puiVueLife: Record<'created' | 'mounted' | 'updated' | 'unmounted' | 'beforeDispose', Array<(run: __puiVueRun) => void>> = { created: [], mounted: [], updated: [], unmounted: [], beforeDispose: [] };
    const __puiVueExposes: Record<string, unknown> = Object.create(null);
    const __puiVueStates = new Set<object>();
    const __puiVuePublicStates = new WeakMap<object, object>();
    const __puiVueInternalSubscriptions = new WeakMap<object, (callback: (event: __puiVueStateEvent<unknown>) => void) => () => void>();
    const __puiVueStateCleanup: Array<() => void> = [];
    const __puiVueEvents = new Set<string>();
    const __puiVuePropChecks: Record<string, (value: unknown) => boolean> = {

    };
    const __puiVueMethodChecks: Record<string, { args(args: unknown[]): boolean; result(value: unknown): boolean }> = {
    ["hide"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 0, result: (__puiVueValue: unknown) => __puiVueValue === undefined },
    ["show"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 0, result: (__puiVueValue: unknown) => __puiVueValue === undefined },
    ["reveal"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 1 && ((typeof __puiVueArgs[0] === 'number' && Number.isFinite(__puiVueArgs[0]))), result: (__puiVueValue: unknown) => ((__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey0) => ["kind"].includes(__puiVueKey0)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "dispatched")) || (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey1) => ["kind"].includes(__puiVueKey1)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "queued")) || (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey2) => ["kind","reason"].includes(__puiVueKey2)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "rejected") && (Object.hasOwn(__puiVueValue, "reason") && (__puiVueValue["reason"] === "not-mounted" || __puiVueValue["reason"] === "not-declared" || __puiVueValue["reason"] === "unavailable"))) || (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey3) => ["kind","reason"].includes(__puiVueKey3)) && (Object.hasOwn(__puiVueValue, "kind") && (typeof __puiVueValue["kind"] === 'string')) && (Object.hasOwn(__puiVueValue, "reason") && (typeof __puiVueValue["reason"] === 'string')))) },
    ["revealOther"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 1 && ((typeof __puiVueArgs[0] === 'number' && Number.isFinite(__puiVueArgs[0]))), result: (__puiVueValue: unknown) => ((__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey4) => ["kind"].includes(__puiVueKey4)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "dispatched")) || (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey5) => ["kind"].includes(__puiVueKey5)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "queued")) || (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey6) => ["kind","reason"].includes(__puiVueKey6)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "rejected") && (Object.hasOwn(__puiVueValue, "reason") && (__puiVueValue["reason"] === "not-mounted" || __puiVueValue["reason"] === "not-declared" || __puiVueValue["reason"] === "unavailable"))) || (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey7) => ["kind","reason"].includes(__puiVueKey7)) && (Object.hasOwn(__puiVueValue, "kind") && (typeof __puiVueValue["kind"] === 'string')) && (Object.hasOwn(__puiVueValue, "reason") && (typeof __puiVueValue["reason"] === 'string')))) },
    ["revealSelf"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 0, result: (__puiVueValue: unknown) => ((__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey8) => ["kind"].includes(__puiVueKey8)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "dispatched")) || (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey9) => ["kind"].includes(__puiVueKey9)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "queued")) || (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey10) => ["kind","reason"].includes(__puiVueKey10)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "rejected") && (Object.hasOwn(__puiVueValue, "reason") && (__puiVueValue["reason"] === "not-mounted" || __puiVueValue["reason"] === "not-declared" || __puiVueValue["reason"] === "unavailable"))) || (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey11) => ["kind","reason"].includes(__puiVueKey11)) && (Object.hasOwn(__puiVueValue, "kind") && (typeof __puiVueValue["kind"] === 'string')) && (Object.hasOwn(__puiVueValue, "reason") && (typeof __puiVueValue["reason"] === 'string')))) },
    ["revealSurface"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 1 && ((typeof __puiVueArgs[0] === 'number' && Number.isFinite(__puiVueArgs[0]))), result: (__puiVueValue: unknown) => ((__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey12) => ["kind"].includes(__puiVueKey12)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "dispatched")) || (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey13) => ["kind"].includes(__puiVueKey13)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "queued")) || (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey14) => ["kind","reason"].includes(__puiVueKey14)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "rejected") && (Object.hasOwn(__puiVueValue, "reason") && (__puiVueValue["reason"] === "not-mounted" || __puiVueValue["reason"] === "not-declared" || __puiVueValue["reason"] === "unavailable"))) || (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey15) => ["kind","reason"].includes(__puiVueKey15)) && (Object.hasOwn(__puiVueValue, "kind") && (typeof __puiVueValue["kind"] === 'string')) && (Object.hasOwn(__puiVueValue, "reason") && (typeof __puiVueValue["reason"] === 'string')))) },
    ["capture"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 1 && ((typeof __puiVueArgs[0] === 'number' && Number.isFinite(__puiVueArgs[0]))), result: (__puiVueValue: unknown) => __puiVueValue === undefined },
    ["revealSaved"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 0, result: (__puiVueValue: unknown) => ((__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey16) => ["kind"].includes(__puiVueKey16)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "dispatched")) || (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey17) => ["kind"].includes(__puiVueKey17)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "queued")) || (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey18) => ["kind","reason"].includes(__puiVueKey18)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "rejected") && (Object.hasOwn(__puiVueValue, "reason") && (__puiVueValue["reason"] === "not-mounted" || __puiVueValue["reason"] === "not-declared" || __puiVueValue["reason"] === "unavailable"))) || (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey19) => ["kind","reason"].includes(__puiVueKey19)) && (Object.hasOwn(__puiVueValue, "kind") && (typeof __puiVueValue["kind"] === 'string')) && (Object.hasOwn(__puiVueValue, "reason") && (typeof __puiVueValue["reason"] === 'string')))) },
    ["armCompletionReveal"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 0, result: (__puiVueValue: unknown) => __puiVueValue === undefined },
    ["requestEnd"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 0, result: (__puiVueValue: unknown) => ((__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey20) => ["kind"].includes(__puiVueKey20)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "dispatched")) || (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey21) => ["kind"].includes(__puiVueKey21)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "queued")) || (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey22) => ["kind","reason"].includes(__puiVueKey22)) && (Object.hasOwn(__puiVueValue, "kind") && __puiVueValue["kind"] === "rejected") && (Object.hasOwn(__puiVueValue, "reason") && (__puiVueValue["reason"] === "not-mounted" || __puiVueValue["reason"] === "not-declared" || __puiVueValue["reason"] === "unavailable")))) },
    ["readCompletionTrace"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 0, result: (__puiVueValue: unknown) => (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey23) => ["visits","beforeAtEnd","beforeState","nestedKind","afterAtEnd","afterState"].includes(__puiVueKey23)) && (Object.hasOwn(__puiVueValue, "visits") && (typeof __puiVueValue["visits"] === 'number' && Number.isFinite(__puiVueValue["visits"]))) && (Object.hasOwn(__puiVueValue, "beforeAtEnd") && (typeof __puiVueValue["beforeAtEnd"] === 'boolean')) && (Object.hasOwn(__puiVueValue, "beforeState") && (typeof __puiVueValue["beforeState"] === 'string')) && (Object.hasOwn(__puiVueValue, "nestedKind") && (typeof __puiVueValue["nestedKind"] === 'string')) && (Object.hasOwn(__puiVueValue, "afterAtEnd") && (typeof __puiVueValue["afterAtEnd"] === 'boolean')) && (Object.hasOwn(__puiVueValue, "afterState") && (typeof __puiVueValue["afterState"] === 'string'))) },
    ["read"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 0, result: (__puiVueValue: unknown) => (__puiVueIsRecord(__puiVueValue) && Object.keys(__puiVueValue).every((__puiVueKey24) => ["axes","horizontal","vertical","scrolling","projection","endFollow"].includes(__puiVueKey24)) && (Object.hasOwn(__puiVueValue, "axes") && (typeof __puiVueValue["axes"] === 'string')) && (Object.hasOwn(__puiVueValue, "horizontal") && (__puiVueIsRecord(__puiVueValue["horizontal"]) && Object.keys(__puiVueValue["horizontal"]).every((__puiVueKey25) => ["position","visibleRatio","canScrollBefore","canScrollAfter","atEnd"].includes(__puiVueKey25)) && (Object.hasOwn(__puiVueValue["horizontal"], "position") && (typeof __puiVueValue["horizontal"]["position"] === 'number' && Number.isFinite(__puiVueValue["horizontal"]["position"]))) && (Object.hasOwn(__puiVueValue["horizontal"], "visibleRatio") && (typeof __puiVueValue["horizontal"]["visibleRatio"] === 'number' && Number.isFinite(__puiVueValue["horizontal"]["visibleRatio"]))) && (Object.hasOwn(__puiVueValue["horizontal"], "canScrollBefore") && (typeof __puiVueValue["horizontal"]["canScrollBefore"] === 'boolean')) && (Object.hasOwn(__puiVueValue["horizontal"], "canScrollAfter") && (typeof __puiVueValue["horizontal"]["canScrollAfter"] === 'boolean')) && (Object.hasOwn(__puiVueValue["horizontal"], "atEnd") && (typeof __puiVueValue["horizontal"]["atEnd"] === 'boolean')))) && (Object.hasOwn(__puiVueValue, "vertical") && (__puiVueIsRecord(__puiVueValue["vertical"]) && Object.keys(__puiVueValue["vertical"]).every((__puiVueKey26) => ["position","visibleRatio","canScrollBefore","canScrollAfter","atEnd"].includes(__puiVueKey26)) && (Object.hasOwn(__puiVueValue["vertical"], "position") && (typeof __puiVueValue["vertical"]["position"] === 'number' && Number.isFinite(__puiVueValue["vertical"]["position"]))) && (Object.hasOwn(__puiVueValue["vertical"], "visibleRatio") && (typeof __puiVueValue["vertical"]["visibleRatio"] === 'number' && Number.isFinite(__puiVueValue["vertical"]["visibleRatio"]))) && (Object.hasOwn(__puiVueValue["vertical"], "canScrollBefore") && (typeof __puiVueValue["vertical"]["canScrollBefore"] === 'boolean')) && (Object.hasOwn(__puiVueValue["vertical"], "canScrollAfter") && (typeof __puiVueValue["vertical"]["canScrollAfter"] === 'boolean')) && (Object.hasOwn(__puiVueValue["vertical"], "atEnd") && (typeof __puiVueValue["vertical"]["atEnd"] === 'boolean')))) && (Object.hasOwn(__puiVueValue, "scrolling") && (typeof __puiVueValue["scrolling"] === 'boolean')) && (Object.hasOwn(__puiVueValue, "projection") && (typeof __puiVueValue["projection"] === 'string')) && (Object.hasOwn(__puiVueValue, "endFollow") && (__puiVueIsRecord(__puiVueValue["endFollow"]) && Object.keys(__puiVueValue["endFollow"]).every((__puiVueKey27) => ["state","requestStatus"].includes(__puiVueKey27)) && (Object.hasOwn(__puiVueValue["endFollow"], "state") && (typeof __puiVueValue["endFollow"]["state"] === 'string')) && (Object.hasOwn(__puiVueValue["endFollow"], "requestStatus") && (typeof __puiVueValue["endFollow"]["requestStatus"] === 'string'))))) },
    };
    const __puiVueEventChecks: Record<string, (value: unknown) => boolean> = {

    };
    const __puiVuePropSpecs: Record<string, __puiVuePropSpec> = Object.create(null);
    const __puiVueDefaults: Array<Record<string, unknown>> = [];
    const __puiVuePreviousValid: Record<string, unknown> = Object.create(null);
    // Setup declarations precede hydration; the final snapshot is validated before created.
    let __puiVueProps: Readonly<GeneratedResolvedProps>;
    let __puiVueRawProps: Record<string, unknown> = Object.create(null);
    let __puiVuePropsWindow: {raw: Readonly<Record<string, unknown>>; resolved: Readonly<GeneratedResolvedProps>} | null = null;
    const __puiVueWatchers: Array<{ keys: readonly string[] | null; active: boolean; callback: (run: __puiVueRun, next: Readonly<GeneratedResolvedProps>, previous: Readonly<GeneratedResolvedProps>, info: __puiVueWatchInfo) => void }> = [];

    const __puiVueStateQueue: Array<() => void> = [];
    let __puiVueEmittingState = false;
    let __puiVueSetup = true;
    let __puiVueRootElement: HTMLElement | null = null;
    let __puiVueRootEpoch: __puiVueEpoch | undefined;

    const __puiVueParentScope = __puiVueVue.inject<__puiVueContextScope | null>(__puiVueScopeKey, null);
    const __puiVueContextChecks = new Map<object, (value: unknown) => boolean>([

    ]);
    const __puiVueScope = __puiVueCreateContextScope({
      getParent: () => __puiVueParentScope, isAlive: () => !__puiVueDisposed,
      invoke: (callback) => { __puiVueAlive(); return callback(); },
      validate: (key, value) => __puiVueContextChecks.get(key)?.(value) === true,
    });
    __puiVueVue.provide(__puiVueScopeKey, __puiVueScope);
    function __puiVueReadContext(run: __puiVueRun, key: object, optional: boolean): unknown {
      __puiVueRequireRun(run); return optional ? __puiVueScope.tryRead(key) : __puiVueScope.read(key);
    }
    function __puiVueUpdateContext(run: __puiVueRun, key: object, value: unknown, optional: boolean): void | boolean {
      __puiVueRequireRun(run); return optional ? __puiVueScope.tryUpdate(key, value) : __puiVueScope.update(key, value);
    }
    function __puiVueReadFrameContext(frame: __puiVueFrame, key: object, optional: boolean): unknown {
      __puiVueActiveFrame(frame); return optional ? __puiVueScope.tryRead(key) : __puiVueScope.read(key);
    }

    let __puiVueCallbackScope: string | undefined;
    function __puiVueInvoke<T>(scope: string, callback: () => T): T {
      __puiVueAlive();
      if (!__puiVueSetup && !__puiVueDisposing && (scope === 'event' || scope === 'expose-method')) __puiVueNotifyProps();
      const previous = __puiVueCallbackScope; __puiVueCallbackScope = scope;
      try { return callback(); } finally { __puiVueCallbackScope = previous; }
    }

    function __puiVueRegisterObservedState<T extends boolean | string | number>(state: __puiVueObservedState<T>): void {
      const subscribers = new Set<(event: __puiVueStateEvent<T>) => void>();
      const projection: __puiVuePublicState<T> = Object.freeze({
        spec: Object.freeze({ kind: typeof state.get() === 'boolean' ? 'bool' as const : typeof state.get() === 'number' ? 'number.discrete' as const : 'string' as const }),
        get() { __puiVuePublicAlive(); return state.get(); },
        subscribe(callback: (event: __puiVueStateEvent<T>) => void) {
          __puiVuePublicAlive();
          const registration = (event: __puiVueStateEvent<T>) => callback(event);
          subscribers.add(registration);
          return () => { __puiVuePublicAlive(); subscribers.delete(registration); };
        },
        unsubscribe(off: () => void) { __puiVuePublicAlive(); off(); },
      });
      __puiVueStates.add(state); __puiVuePublicStates.set(state, projection);
      __puiVueInternalSubscriptions.set(state, callback => state.subscribe(callback));
      const refresh = state.subscribe((event) => {

        __puiVueInteraction.refresh();
        for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(__puiVueStateQueue, __puiVueStateQueue.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!__puiVueEmittingState) {
  __puiVueEmittingState = true;
  const notificationFailures: unknown[] = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < __puiVueStateQueue.length) {
      try { __puiVueStateQueue[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { __puiVueStateQueue.length = 0; __puiVueEmittingState = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
      });
      __puiVueStateCleanup.push(() => { refresh(); subscribers.clear(); });
    }
    const __puiVueInteraction: __puiVueNativeInteraction<__puiVueRun> = __puiVueCreateInteraction<__puiVueRun>({
      ensureSetup(operation) { __puiVueAlive(); if (!__puiVueSetup) throw new Error('[Vue source] ' + operation + ' requires setup'); },
      ensureRuntime(operation) {
        __puiVueAlive();
        if (__puiVueSetup || !__puiVueCallbackScope || __puiVueDisposing && !__puiVueInternalTeardown) throw new Error('[Vue source] ' + operation + ' requires an owned runtime callback');
      },
      ensureEvent(operation) {
        __puiVueAlive();
        if (__puiVueSetup || __puiVueCallbackScope !== 'event' || __puiVueDisposing) throw new Error('[Vue source] ' + operation + ' requires an input callback');
      },
      isAlive: () => !__puiVueDisposed && (!__puiVueDisposing || __puiVueInternalTeardown),
      isSetupComplete: () => !__puiVueSetup,
      isReady: () => !__puiVueSetup && !__puiVueDisposing && !!__puiVueCurrentEpoch?.committed && __puiVuePresent.value,
      invoke: (callback) => __puiVueInvoke('event', callback),
      getRun: () => __puiVueRunValue, getResolvedProps: () => __puiVueProps,

      subscribeState(state, callback) { return __puiVueSubscribeInternal(state, callback); },
      getRoot: () => __puiVueRootEpoch?.active && __puiVueRootEpoch === __puiVueCurrentEpoch ? __puiVueRootElement : null,
      identity: __puiVueScope, getLogicalParent: () => __puiVueParentScope,
      declarations: [],
      tableFamily: undefined,
      getExposes: () => __puiVueExposes,
      registerExpose: (key, value) => {
        if (value && typeof value === 'object' && __puiVueStates.has(value)) __puiVueExposeState(key, value as __puiVueState<unknown>);
        else if (typeof value === 'function') __puiVueDeclare(key, (...args: unknown[]) => { __puiVuePublicAlive(); return __puiVueInvoke('expose-method', () => value(...args)); });
        else __puiVueDeclare(key, value);
      },
      createOwnedState: <T extends boolean | string | number>(name: string, value: T, spec?: __puiVueSpec) => __puiVueCreateState(spec?.kind ?? (typeof value === 'boolean' ? 'bool' : typeof value === 'number' ? 'number.discrete' : 'string'), name, value, spec) as __puiVueState<T>,
      watchState<T>(state: {get(): T}, callback: (run: __puiVueRun, event: __puiVueStateEvent<T>) => void) {
        const off = __puiVueSubscribeInternal(state, event => __puiVueInvoke('state-watch', () => callback(__puiVueRunValue, event)));
        __puiVueStateCleanup.push(off); return off;
      },
      isPropProvided: key => Object.hasOwn(__puiVueRawProps, key),
        setPresent: value => __puiVueSetPresent(__puiVueRunValue, value),
      requestHostUpdate() {
        if (__puiVueHostScheduled || __puiVueDisposed || __puiVueDisposing) return;
        __puiVueHostScheduled = true;
        queueMicrotask(() => { __puiVueHostScheduled = false; if (!__puiVueDisposed && !__puiVueDisposing) __puiVueHostRevision.value += 1; });
      },
      registerGenericObservedState: __puiVueRegisterObservedState,
      emit: key => __puiVueEmit(__puiVueRunValue, key),
    });

    

    
    const __puiVueRunValue: __puiVueRun = Object.freeze({ owner: Symbol("scroll-family-surface") });

    function __puiVueIsRecord(value: unknown): value is Record<string, unknown> {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
      const prototype = Object.getPrototypeOf(value);
      return (prototype === Object.prototype || prototype === null) && Reflect.ownKeys(value).every((key) => {
        const descriptor = Object.getOwnPropertyDescriptor(value, key)!;
        return typeof key === 'string' && descriptor.enumerable && Object.hasOwn(descriptor, 'value');
      });
    }
    function __puiVueIsArray(value: unknown): value is unknown[] {
      if (!Array.isArray(value) || Object.keys(value).length !== value.length) return false;
      const prototype = Object.getPrototypeOf(value);
      if (prototype !== Array.prototype && prototype !== null) return false;
      return Reflect.ownKeys(value).every((key) => {
        if (key === 'length') return true;
        const descriptor = Object.getOwnPropertyDescriptor(value, key)!;
        return typeof key === 'string' && /^(0|[1-9]\d*)$/.test(key) && Number(key) < value.length && descriptor.enumerable && Object.hasOwn(descriptor, 'value');
      });
    }

    function __puiVueAlive(): void {
      if (__puiVueDisposed || (__puiVueDisposing && !__puiVueInternalTeardown)) throw new Error('[Vue source] owner is disposed');
    }
    function __puiVuePublicAlive(): void {
      if (__puiVueDisposed || __puiVueDisposing) throw new Error('[Vue source] owner is disposed');
    }
    function __puiVueSubscribeInternal<T>(state: {get(): T}, callback: (event: __puiVueStateEvent<T>) => void): () => void {
      __puiVueAlive();
      const subscribe = __puiVueInternalSubscriptions.get(state);
      if (!subscribe) throw new Error('[State] unknown owner subscription target');
      return subscribe(event => callback(event as __puiVueStateEvent<T>));
    }
    function __puiVueRequireRun(run: __puiVueRun): void {
      __puiVueAlive();
      if (run !== __puiVueRunValue) throw new Error('[Vue source] foreign run handle');
    }
    function __puiVueRequestUpdate(run: __puiVueRun): void {
      __puiVueRequireRun(run);
      if (__puiVueDisposing) return;
      __puiVueRequested = true;

      if (__puiVueQueued) return;
      __puiVueQueued = true;
      const ticket = __puiVueQueueTicket;
      queueMicrotask(() => {
        if (ticket !== __puiVueQueueTicket || __puiVueDisposed || __puiVueDisposing) return;
        __puiVueQueued = false;
        if (!__puiVueRequested) return;
        __puiVueRequested = false;
        if (__puiVuePresent.value) __puiVueRevision.value += 1;
      });
    }
    function __puiVueSetPresent(run: __puiVueRun, present: boolean): void {
      __puiVueRequireRun(run);
      if (__puiVueDisposing) throw new Error('[Vue source] terminal presence is locked');
      if (typeof present !== 'boolean') throw new TypeError('[Vue source] presence must be boolean');
      __puiVuePresent.value = present;
    }
    function __puiVueInvokeLife(kind: keyof typeof __puiVueLife): void {
      if (kind === 'unmounted') {  }
      try { for (const callback of __puiVueLife[kind]) callback(__puiVueRunValue); }
      finally { if (kind === 'unmounted') {  } }
    }
    function __puiVueUnbindRoot(epoch: __puiVueEpoch): void {
      if (__puiVueRootEpoch !== epoch) return;

      
      __puiVueRootElement = null; __puiVueRootEpoch = undefined;
      __puiVueInteraction.unmount();
    }
    function __puiVueCommitUnmount(epoch: __puiVueEpoch): void {
      epoch.active = false;
      __puiVueUnbindRoot(epoch);
      if (!epoch.committed) return;
      epoch.committed = false;
      const previous = __puiVueInternalTeardown;
      __puiVueInternalTeardown = __puiVueDisposing;
      try { __puiVueInvokeLife('unmounted'); } finally { __puiVueInternalTeardown = previous; }
    }
    function __puiVueCreateState(kind: 'bool', semantic: string, initial: boolean): __puiVueState<boolean>;
    function __puiVueCreateState(kind: 'string' | 'enum', semantic: string, initial: string, options?: Omit<__puiVueSpec, 'kind'>): __puiVueState<string>;
    function __puiVueCreateState(kind: 'number.range' | 'number.discrete', semantic: string, initial: number, options?: Omit<__puiVueSpec, 'kind'>): __puiVueState<number>;
    function __puiVueCreateState(kind: __puiVueSpec['kind'], semantic: string, initial: boolean | number | string, options?: Omit<__puiVueSpec, 'kind'>): __puiVueState<boolean | number | string>;
    function __puiVueCreateState(kind: __puiVueSpec['kind'], semantic: string, initial: boolean | number | string, options: Omit<__puiVueSpec, 'kind'> = {}): unknown {

      if (typeof semantic !== 'string' || semantic.length === 0) throw new Error('[Vue source] invalid state semantic');
      const spec: __puiVueSpec = Object.freeze({ ...options, ...(options.options ? { options: Object.freeze([...options.options]) } : {}), kind });
      function validate(value: boolean | number | string): void {
        if (kind === 'bool' ? typeof value !== 'boolean' : kind === 'string' || kind === 'enum' ? typeof value !== 'string' : typeof value !== 'number' || !Number.isFinite(value)) throw new TypeError('[Vue source] invalid state value');
        if (spec.options?.length && (typeof value === 'boolean' || !spec.options.includes(value))) throw new RangeError('[Vue source] state value not in options');
        if (typeof value === 'number' && (kind === 'number.range' || (kind === 'number.discrete' && !spec.options?.length)) && (spec.min !== undefined && value < spec.min || spec.max !== undefined && value > spec.max)) throw new RangeError('[Vue source] state value out of range');
        if (typeof value === 'number' && kind === 'number.discrete' && !spec.options?.length && spec.step !== undefined && spec.step > 0 && !Number.isInteger((value - (spec.min ?? 0)) / spec.step)) throw new RangeError('[Vue source] state value violates step');
      }
      if (kind === 'number.range' && (typeof spec.min !== 'number' || typeof spec.max !== 'number' || Number.isNaN(spec.min) || Number.isNaN(spec.max) || spec.min > spec.max)) throw new RangeError('[Vue source] invalid state range');
      let value = initial;
      if (kind === 'number.range' && spec.clamp && typeof value === 'number') value = Math.min(spec.max!, Math.max(spec.min!, value));
      validate(value);
      const subscribers = new Set<(event: __puiVueStateEvent<boolean | number | string>) => void>();
      const handle: __puiVueState<boolean | number | string> = {
        spec,
        get() { __puiVueAlive(); return value; },
        setDefault(next) { __puiVueAlive(); if (!__puiVueSetup) throw new Error('[State] setDefault requires setup'); validate(next); value = next; },
        set(next, reason) {
          __puiVueAlive(); validate(next);
          if (Object.is(value, next)) return;
          const event: __puiVueStateEvent<boolean | number | string> = { type: 'next', prev: value, next, reason };
          value = next;

          __puiVueInteraction.refresh();
          for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(__puiVueStateQueue, __puiVueStateQueue.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!__puiVueEmittingState) {
  __puiVueEmittingState = true;
  const notificationFailures: unknown[] = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < __puiVueStateQueue.length) {
      try { __puiVueStateQueue[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { __puiVueStateQueue.length = 0; __puiVueEmittingState = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
        },
        subscribe(callback) { __puiVuePublicAlive(); const registration: typeof callback = event => callback(event); subscribers.add(registration); return () => { __puiVuePublicAlive(); subscribers.delete(registration); }; },
        unsubscribe(off) { __puiVuePublicAlive(); off(); },
      };
      __puiVueStates.add(handle);
      __puiVueInternalSubscriptions.set(handle, callback => {
        const registration: typeof callback = event => callback(event); subscribers.add(registration);
        return () => { subscribers.delete(registration); };
      });
      __puiVueStateCleanup.push(() => subscribers.clear());

      return handle;
    }
    function __puiVueDeclare(key: string, value: unknown): void {
      if (Object.hasOwn(__puiVueExposes, key)) throw new Error('[Vue source] duplicate exposure: ' + key);
      Object.defineProperty(__puiVueExposes, key, { value, enumerable: true });
    }
    function __puiVueExposeState<T>(key: string, handle: __puiVuePublicState<T> | __puiVueObservedState<T>): void {
      if (!__puiVueStates.has(handle)) throw new Error('[Vue source] foreign state handle');
      let projection = __puiVuePublicStates.get(handle);
      if (!projection) {
        if (!('spec' in handle)) throw new Error('[Vue source] unregistered observed state');
        projection = Object.freeze({ get() { __puiVuePublicAlive(); return handle.get(); }, subscribe: handle.subscribe, unsubscribe: handle.unsubscribe, spec: handle.spec });
        __puiVuePublicStates.set(handle, projection);
      }
      __puiVueDeclare(key, projection);
    }
    function __puiVueExposeMethod<Args extends unknown[], Result>(key: string, callback: (...args: Args) => Result, project?: (value: Result) => Result): void {

      const boundary = __puiVueMethodChecks[key];
      __puiVueDeclare(key, (...args: unknown[]) => {
        __puiVuePublicAlive();
        if (!boundary.args(args)) throw new TypeError('[Vue source] invalid method arguments: ' + key);
        // The specialized predicate just checked the concrete declared argument tuple.
        const checkedArgs = args as Args;
        const result = __puiVueInvoke('expose-method', () => callback(...checkedArgs));
        if (!boundary.result(result)) throw new TypeError('[Vue source] invalid method result: ' + key);
        return project ? project(result) : result;
      });
    }
    function __puiVueExposeEvent(key: string, _spec?: unknown): void {
      __puiVueEvents.add(key);
      __puiVueDeclare(key, Object.freeze({ kind: 'event' as const }));
    }
    function __puiVueEmit(run: __puiVueRun, key: string, payload?: unknown, options?: unknown): void {
      __puiVueRequireRun(run);
      if (!__puiVueEvents.has(key) || !__puiVueEventChecks[key](payload)) throw new TypeError('[Vue source] undeclared event or invalid payload: ' + key);
      __puiVueContext.emit(key as never, payload, options);
    }
    function __puiVueValidProp(key: string, value: unknown): boolean {
      const spec = __puiVuePropSpecs[key];
      return __puiVuePropChecks[key](value) && (!spec.options || spec.options.includes(value)) && (!spec.range || typeof value === 'number' && value >= (spec.range.min ?? -Infinity) && value <= (spec.range.max ?? Infinity));
    }
    function __puiVueResolveProps(raw: Record<string, unknown>, strict: boolean): Readonly<GeneratedResolvedProps> {
      const next: Record<string, unknown> = Object.create(null);
      for (const key of Object.keys(__puiVuePropSpecs)) {
        const spec = __puiVuePropSpecs[key], provided = Object.hasOwn(raw, key), candidate = raw[key];
        const empty = spec.empty ?? 'fallback';
        if (provided && candidate != null && __puiVueValidProp(key, candidate)) {
          next[key] = candidate; __puiVuePreviousValid[key] = candidate; continue;
        }
        if (provided && candidate == null && empty === 'accept') { next[key] = null; continue; }
        const required = strict && empty === 'error';
        let found = false;
        function take(value: unknown): void {
          if (found || value === undefined || required && value === null || value !== null && !__puiVueValidProp(key, value)) return;
          next[key] = value; found = true;
        }
        if (provided && Object.hasOwn(__puiVuePreviousValid, key)) take(__puiVuePreviousValid[key]);
        for (const layer of __puiVueDefaults) if (Object.hasOwn(layer, key)) take(layer[key]);
        if (Object.hasOwn(spec, 'default')) take(spec.default);
        if (!found && required) throw new TypeError('[Vue source] missing/invalid required prop: ' + key);
        if (!found) next[key] = null;
        if (provided && next[key] !== null) __puiVuePreviousValid[key] = next[key];
      }
      // Every declared key above passed its specialized predicate or canonical null fallback.
      const snapshot = Object.freeze(next) as Readonly<GeneratedResolvedProps>;
      return snapshot;
    }
    function __puiVueDefineProps(declarations: Record<string, __puiVuePropSpec>): void {
      for (const key of Object.keys(declarations)) {
        const incoming = declarations[key], previous = __puiVuePropSpecs[key];
        if (!Object.hasOwn(__puiVuePropChecks, key)) throw new Error('[Vue source] undeclared prop schema');
        const rank = (empty: string) => empty === 'accept' ? 0 : empty === 'error' ? 2 : 1;
        if (previous && incoming.empty && rank(incoming.empty) > rank(previous.empty ?? 'fallback')) throw new Error('[Vue source] props cannot become stricter');
        if (previous?.options && (!incoming.options || previous.options.some((value) => !incoming.options!.includes(value)))) throw new Error('[Vue source] prop options cannot narrow');
        if (previous?.range && ((incoming.range?.min ?? -Infinity) > (previous.range.min ?? -Infinity) || (incoming.range?.max ?? Infinity) < (previous.range.max ?? Infinity))) throw new Error('[Vue source] prop range cannot narrow');
        __puiVuePropSpecs[key] = { ...previous, ...incoming, ...(previous ? { empty: previous.empty ?? 'fallback' } : {}), ...(previous && Object.hasOwn(previous, 'default') ? { default: previous.default } : {}) };
      }
      __puiVueProps = __puiVueResolveProps(__puiVueRawProps, false);

      __puiVueInteraction.refresh();
    }
    function __puiVueSetDefaults(defaults: Record<string, unknown>): void {
      for (const key of Object.keys(defaults)) if (!Object.hasOwn(__puiVuePropSpecs, key)) throw new Error('[Vue source] defaults require a declared prop');
      __puiVueDefaults.unshift({ ...defaults });
      __puiVueProps = __puiVueResolveProps(__puiVueRawProps, false);

      __puiVueInteraction.refresh();
    }
    function __puiVueWatchProps(keys: readonly string[] | null, callback: (run: __puiVueRun, next: Readonly<GeneratedResolvedProps>, previous: Readonly<GeneratedResolvedProps>, info: __puiVueWatchInfo) => void): () => void {
      if (keys && (!keys.length || keys.some((key) => !Object.hasOwn(__puiVuePropSpecs, key)))) throw new Error('[Vue source] watch requires declared prop keys');
      const entry = { keys: keys && [...keys], callback, active: true };
      __puiVueWatchers.push(entry);
      return () => { __puiVueAlive(); entry.active = false; };
    }

    function __puiVueReadProps(run: __puiVueRun): Readonly<GeneratedResolvedProps> { __puiVueRequireRun(run); return __puiVuePropsWindow?.resolved ?? __puiVueProps; }
    function __puiVueReadRawProps(run: __puiVueRun): Readonly<Record<string, unknown>> { __puiVueRequireRun(run); return __puiVuePropsWindow?.raw ?? Object.freeze({ ...__puiVueRawProps }); }
    function __puiVueIsProvided(run: __puiVueRun, key: string): boolean { __puiVueRequireRun(run); return Object.hasOwn(__puiVuePropsWindow?.raw ?? __puiVueRawProps, key); }
    function __puiVueGetHostProps(): Record<string, unknown> {
{ const __puiVueInitialAssociations = _props.instanceAssociations;
    if (__puiVueInitialAssociations !== undefined) {
      if (__puiVueInitialAssociations === null || typeof __puiVueInitialAssociations !== 'object' || Object.getPrototypeOf(__puiVueInitialAssociations) !== Object.prototype)
        throw new TypeError('[InstanceAssociations] expected a plain record');
      for (const key of Reflect.ownKeys(__puiVueInitialAssociations)) if (key !== 'controlLabel')
        throw new TypeError('[InstanceAssociations] unknown association key');
      if (Object.prototype.hasOwnProperty.call(__puiVueInitialAssociations, 'controlLabel') && Reflect.get(__puiVueInitialAssociations, 'controlLabel') != null)
        throw new Error('[ControlLabel] this Prototype has not declared Label or target participation');
    }
  }
      // Read the authored host snapshot, bypassing Vue Boolean casts and camelization.
      const raw: Record<string, unknown> = Object.create(null);
      for (const key of Object.keys(__puiVueInstance.vnode.props ?? {})) {
        const value = __puiVueInstance.vnode.props![key];
        if (['key', 'ref', 'ref_for', 'ref_key', 'instanceAssociations', 'instance-associations'].includes(key) || key.startsWith('onVnode')) continue;
        if (!Object.hasOwn(__puiVuePropChecks, key) && (
          ['class', 'hostClass', 'surfaceClass', 'style', 'hostStyle', 'surfaceStyle'].includes(key) ||
          /^on[A-Z]/.test(key) && typeof value === 'function'
        )) continue;
        raw[key] = value;
      }
      return raw;
    }
    function __puiVueNotifyProps(): void {
      if (__puiVueDisposed || __puiVueDisposing) return;
{ const __puiVueAssociations = _props.instanceAssociations;
    if (__puiVueAssociations !== undefined) {
      if (__puiVueAssociations === null || typeof __puiVueAssociations !== 'object' || Object.getPrototypeOf(__puiVueAssociations) !== Object.prototype)
        throw new TypeError('[InstanceAssociations] expected a plain record');
      for (const key of Reflect.ownKeys(__puiVueAssociations)) if (key !== 'controlLabel')
        throw new TypeError('[InstanceAssociations] unknown association key');
      if (Object.prototype.hasOwnProperty.call(__puiVueAssociations, 'controlLabel') && Reflect.get(__puiVueAssociations, 'controlLabel') != null)
        throw new Error('[ControlLabel] this Prototype has not declared Label or target participation');
    }
  }
      const raw = __puiVueGetHostProps();
      const changed = Object.keys({ ...__puiVueRawProps, ...raw }).some((key) => Object.hasOwn(raw, key) !== Object.hasOwn(__puiVueRawProps, key) || !Object.is(raw[key], __puiVueRawProps[key]));
      if (!changed) return;

      const previous = __puiVueProps;
      const next = __puiVueResolveProps(raw, true);
      __puiVueRawProps = raw; __puiVueProps = next;

      __puiVueInteraction.refresh();
      const previousWindow = __puiVuePropsWindow;
      __puiVuePropsWindow = {raw: Object.freeze({...raw}), resolved: next};
      try {
      const all = Object.keys(__puiVuePropSpecs).filter((key) => !Object.is(Reflect.get(previous, key), Reflect.get(next, key)));

      for (const watcher of __puiVueWatchers) {
        if (!watcher.active) continue;
        const matched = watcher.keys ? watcher.keys.filter((key) => all.includes(key)) : all;
        if (matched.length) watcher.callback(__puiVueRunValue, next, previous, { changedKeysAll: all, changedKeysMatched: matched });
      }

      } finally { __puiVuePropsWindow = previousWindow; }
    }
    function __puiVueActiveFrame(frame: __puiVueFrame): void {
      __puiVueAlive();
      if (!frame.epoch.active || frame.epoch !== __puiVueCurrentEpoch || !__puiVuePresent.value) throw new Error('[Vue source] stale view work');
    }
    function __puiVueReadFrameProps(frame: __puiVueFrame): Readonly<GeneratedResolvedProps> { __puiVueActiveFrame(frame); return __puiVueProps; }
    function __puiVueReadFrameRawProps(frame: __puiVueFrame): Readonly<Record<string, unknown>> { __puiVueActiveFrame(frame); return Object.freeze({ ...__puiVueRawProps }); }
    function __puiVueFrameProvided(frame: __puiVueFrame, key: string): boolean { __puiVueActiveFrame(frame); return Object.hasOwn(__puiVueRawProps, key); }
    function __puiVueChildren(input: unknown): __puiVueVue.VNode | string | number | null | __puiVueVue.VNodeArrayChildren {
      if (input === null) return null;
      if (Array.isArray(input)) return input.map(__puiVueChildren);
      if (typeof input === 'string' || typeof input === 'number' || __puiVueVue.isVNode(input)) return input;
      throw new TypeError('[Vue source] invalid template child');
    }
    function __puiVueElement(frame: __puiVueFrame, tag: string, ...args: unknown[]): __puiVueVue.VNode {
      __puiVueActiveFrame(frame);
      let children: unknown = null;
      let attributes: Record<string, string> | null = null;
      if (args.length > 1 || args.length === 1 && args[0] !== null && typeof args[0] === 'object' && !Array.isArray(args[0]) && !__puiVueVue.isVNode(args[0])) {
        if (!__puiVueIsRecord(args[0])) throw new Error('[Vue source] unsupported template props');
        const keys = Object.keys(args[0]);
        if (keys.length) throw new Error('[Vue source] unsupported template props');
        children = args.length > 1 ? args[1] : null;
      } else if (args.length) children = args[0];
      const normalized = __puiVueChildren(children);
      return __puiVueVue.h(tag, attributes, normalized ?? undefined);
    }
    function __puiVueSlot(frame: __puiVueFrame): __puiVueVue.VNode {
      __puiVueActiveFrame(frame);
      if (frame.slotUsed) throw new Error('[Vue source] multiple slots are not supported');
      frame.slotUsed = true;
      return __puiVueVue.h(__puiVueSlotView, { read: () => {
        __puiVueSlotRevision.value;
        if (__puiVueDisposed || __puiVueDisposing || !frame.epoch.active || frame.epoch !== __puiVueCurrentEpoch || !__puiVuePresent.value) return null;
        return __puiVueContext.slots.default?.() ?? null;
      } });
    }


    const __puiVueRenderer = ((): ((frame: __puiVueFrame) => __puiVueVue.VNodeChild) | void => {
      try {
        const renderer = ((def: void) => {
        // Source "surface.proto.ts":4:1
        __puiVueInteraction.anatomy.claim(__puiVueStatic0, { ["role"]: "surface" });
        // Source "surface.proto.ts":4:48
        let current: (__puiVueRun) | (null) = (null as (__puiVueRun) | (null));
        // Source "surface.proto.ts":5:1
        __puiVueLife.created.push((run: __puiVueRun) => __puiVueInvoke("created", () => {
          // Source "surface.proto.ts":5:31
          (current = run);
        }));
        // Source "surface.proto.ts":6:1
        __puiVueExposeMethod("hide", (): void => {
          // Source "surface.proto.ts":6:30
          return ((__puiVueOptionalReceiver: (__puiVueRun) | (null)) => __puiVueOptionalReceiver == null ? undefined : __puiVueSetPresent(__puiVueOptionalReceiver, false))(current);
        });
        // Source "surface.proto.ts":7:1
        __puiVueExposeMethod("show", (): void => {
          // Source "surface.proto.ts":7:30
          return ((__puiVueOptionalReceiver: (__puiVueRun) | (null)) => __puiVueOptionalReceiver == null ? undefined : __puiVueSetPresent(__puiVueOptionalReceiver, true))(current);
        });
        // Source "surface.proto.ts":8:7
        const scroll = __puiVueInteraction.asScrollSurface();
        // Source "surface.proto.ts":8:32
        scroll.configure({ ["axes"]: "vertical", ["projection"]: "system", ["endFollow"]: { ["mode"]: "while-at-end", ["axis"]: "vertical" } });
        // Source "surface.proto.ts":9:5
        let saved: ({ "kind": "reveal"; "axis": "vertical"; "family": __puiVueModuleCapability<"anatomy-family", __puiVueRun>; "part": __puiVueModuleCapability<"anatomy-part", __puiVueRun> }) | (null) = (null as ({ "kind": "reveal"; "axis": "vertical"; "family": __puiVueModuleCapability<"anatomy-family", __puiVueRun>; "part": __puiVueModuleCapability<"anatomy-part", __puiVueRun> }) | (null));
        // Source "surface.proto.ts":10:1
        __puiVueExposeMethod("reveal", (index: number): { "kind": "dispatched" } | { "kind": "queued" } | { "kind": "rejected"; "reason": "not-mounted" | "not-declared" | "unavailable" } | { "kind": string; "reason": string } => {
          // Source "surface.proto.ts":11:3
          if (current) {
            // Source "surface.proto.ts":11:21
            const parts = __puiVueInteraction.anatomy.order.partsOf(__puiVueStatic0, "item");
            // Source "surface.proto.ts":11:78
            const part = ((index === 0) ? (parts)["0"] : ((index === 1) ? (parts)["1"] : (parts)["2"]));
            // Source "surface.proto.ts":12:5
            if (part) {
              // Source "surface.proto.ts":12:13
              return scroll.request({ ["kind"]: "reveal", ["axis"]: "vertical", ["family"]: __puiVueStatic0, ["part"]: (part as __puiVueModuleCapability<"anatomy-part", __puiVueRun>) });
            }
          }
          // Source "surface.proto.ts":13:3
          return { ["kind"]: "rejected", ["reason"]: "unavailable" };
        });
        // Source "surface.proto.ts":15:1
        __puiVueExposeMethod("revealOther", (index: number): { "kind": "dispatched" } | { "kind": "queued" } | { "kind": "rejected"; "reason": "not-mounted" | "not-declared" | "unavailable" } | { "kind": string; "reason": string } => {
          // Source "surface.proto.ts":16:3
          if (current) {
            // Source "surface.proto.ts":16:21
            const parts = __puiVueInteraction.anatomy.order.partsOf(__puiVueStatic0, "item");
            // Source "surface.proto.ts":16:78
            const part = ((index === 0) ? (parts)["0"] : ((index === 1) ? (parts)["1"] : (parts)["2"]));
            // Source "surface.proto.ts":17:5
            if (part) {
              // Source "surface.proto.ts":17:13
              return scroll.request({ ["kind"]: "reveal", ["axis"]: "vertical", ["family"]: __puiVueStatic1, ["part"]: (part as __puiVueModuleCapability<"anatomy-part", __puiVueRun>) });
            }
          }
          // Source "surface.proto.ts":18:3
          return { ["kind"]: "rejected", ["reason"]: "unavailable" };
        });
        // Source "surface.proto.ts":20:1
        __puiVueExposeMethod("revealSelf", (): { "kind": "dispatched" } | { "kind": "queued" } | { "kind": "rejected"; "reason": "not-mounted" | "not-declared" | "unavailable" } | { "kind": string; "reason": string } => {
          // Source "surface.proto.ts":21:3
          if (current) {
            // Source "surface.proto.ts":21:21
            const index = __puiVueInteraction.anatomy.order.indexOfSelf(__puiVueStatic0, "surface");
            // Source "surface.proto.ts":21:85
            const parts = __puiVueInteraction.anatomy.order.partsOf(__puiVueStatic0, "surface");
            // Source "surface.proto.ts":21:145
            const part = ((index === 0) ? (parts)["0"] : ((index === 1) ? (parts)["1"] : (parts)["2"]));
            // Source "surface.proto.ts":22:5
            if (part) {
              // Source "surface.proto.ts":22:13
              return scroll.request({ ["kind"]: "reveal", ["axis"]: "vertical", ["family"]: __puiVueStatic0, ["part"]: (part as __puiVueModuleCapability<"anatomy-part", __puiVueRun>) });
            }
          }
          // Source "surface.proto.ts":23:3
          return { ["kind"]: "rejected", ["reason"]: "unavailable" };
        });
        // Source "surface.proto.ts":25:1
        __puiVueExposeMethod("revealSurface", (index: number): { "kind": "dispatched" } | { "kind": "queued" } | { "kind": "rejected"; "reason": "not-mounted" | "not-declared" | "unavailable" } | { "kind": string; "reason": string } => {
          // Source "surface.proto.ts":26:3
          if (current) {
            // Source "surface.proto.ts":26:21
            const parts = __puiVueInteraction.anatomy.order.partsOf(__puiVueStatic0, "surface");
            // Source "surface.proto.ts":26:81
            const part = ((index === 0) ? (parts)["0"] : ((index === 1) ? (parts)["1"] : (parts)["2"]));
            // Source "surface.proto.ts":27:5
            if (part) {
              // Source "surface.proto.ts":27:13
              return scroll.request({ ["kind"]: "reveal", ["axis"]: "vertical", ["family"]: __puiVueStatic0, ["part"]: (part as __puiVueModuleCapability<"anatomy-part", __puiVueRun>) });
            }
          }
          // Source "surface.proto.ts":28:3
          return { ["kind"]: "rejected", ["reason"]: "unavailable" };
        });
        // Source "surface.proto.ts":30:1
        __puiVueExposeMethod("capture", (index: number): void => {
          // Source "surface.proto.ts":31:3
          if (current) {
            // Source "surface.proto.ts":31:21
            const parts = __puiVueInteraction.anatomy.order.partsOf(__puiVueStatic0, "item");
            // Source "surface.proto.ts":31:78
            const part = ((index === 0) ? (parts)["0"] : ((index === 1) ? (parts)["1"] : (parts)["2"]));
            // Source "surface.proto.ts":32:5
            if (part) {
              // Source "surface.proto.ts":32:20
              const request: { "kind": "reveal"; "axis": "vertical"; "family": __puiVueModuleCapability<"anatomy-family", __puiVueRun>; "part": __puiVueModuleCapability<"anatomy-part", __puiVueRun> } = { ["kind"]: "reveal", ["axis"]: "vertical", ["family"]: __puiVueStatic0, ["part"]: (part as __puiVueModuleCapability<"anatomy-part", __puiVueRun>) };
              // Source "surface.proto.ts":32:106
              (saved = request);
            }
          }
        });
        // Source "surface.proto.ts":34:1
        __puiVueExposeMethod("revealSaved", (): { "kind": "dispatched" } | { "kind": "queued" } | { "kind": "rejected"; "reason": "not-mounted" | "not-declared" | "unavailable" } | { "kind": string; "reason": string } => {
          // Source "surface.proto.ts":34:38
          if (saved) {
            // Source "surface.proto.ts":34:47
            return scroll.request((saved as { "kind": "reveal"; "axis": "vertical"; "family": __puiVueModuleCapability<"anatomy-family", __puiVueRun>; "part": __puiVueModuleCapability<"anatomy-part", __puiVueRun> }));
          }
          // Source "surface.proto.ts":34:76
          return { ["kind"]: "rejected", ["reason"]: "unavailable" };
        });
        // Source "surface.proto.ts":35:5
        let completionArmed: boolean = false;
        // Source "surface.proto.ts":36:5
        let completionVisits: number = 0;
        // Source "surface.proto.ts":37:5
        let completionBeforeAtEnd: boolean = false;
        // Source "surface.proto.ts":38:5
        let completionBeforeState: string = "";
        // Source "surface.proto.ts":39:5
        let completionAfterAtEnd: boolean = false;
        // Source "surface.proto.ts":40:5
        let completionAfterState: string = "";
        // Source "surface.proto.ts":41:5
        let completionNestedKind: string = "";
        // Source "surface.proto.ts":42:1
        ((scroll)["endFollow"])["requestStatus"].watch((run: __puiVueRun, event: __puiVueStateEvent<string>) => __puiVueInvoke("state-watch", () => {
          // Source "surface.proto.ts":43:3
          if (((((event)["type"] !== "next") || (((event as Extract<__puiVueStateEvent<string>, {type:'next'}>))["next"] !== "applied")) || (!completionArmed))) {
            // Source "surface.proto.ts":43:68
            return;
          }
          // Source "surface.proto.ts":44:3
          (completionArmed = false);
          // Source "surface.proto.ts":45:3
          (completionVisits = (completionVisits + 1));
          // Source "surface.proto.ts":46:3
          (completionBeforeAtEnd = (((scroll)["vertical"])["atEnd"].get() as boolean));
          // Source "surface.proto.ts":47:3
          (completionBeforeState = (((scroll)["endFollow"])["state"].get() as string));
          // Source "surface.proto.ts":48:9
          const parts = __puiVueInteraction.anatomy.order.partsOf(__puiVueStatic0, "item");
          // Source "surface.proto.ts":49:9
          const part = (parts)["0"];
          // Source "surface.proto.ts":50:3
          if (part) {
            // Source "surface.proto.ts":50:18
            const outcome = scroll.request({ ["kind"]: "reveal", ["axis"]: "vertical", ["family"]: __puiVueStatic0, ["part"]: (part as __puiVueModuleCapability<"anatomy-part", __puiVueRun>) });
            // Source "surface.proto.ts":50:93
            (completionNestedKind = (outcome)["kind"]);
          }
          // Source "surface.proto.ts":51:3
          (completionAfterAtEnd = (((scroll)["vertical"])["atEnd"].get() as boolean));
          // Source "surface.proto.ts":52:3
          (completionAfterState = (((scroll)["endFollow"])["state"].get() as string));
        }));
        // Source "surface.proto.ts":54:1
        __puiVueExposeMethod("armCompletionReveal", (): void => {
          // Source "surface.proto.ts":54:46
          (completionArmed = true);
        });
        // Source "surface.proto.ts":55:1
        __puiVueExposeMethod("requestEnd", (): { "kind": "dispatched" } | { "kind": "queued" } | { "kind": "rejected"; "reason": "not-mounted" | "not-declared" | "unavailable" } => {
          // Source "surface.proto.ts":55:36
          return scroll.request({ ["kind"]: "to-end", ["axis"]: "vertical" });
        });
        // Source "surface.proto.ts":56:1
        __puiVueExposeMethod("readCompletionTrace", (): { "visits": number; "beforeAtEnd": boolean; "beforeState": string; "nestedKind": string; "afterAtEnd": boolean; "afterState": string } => {
          // Source "surface.proto.ts":56:45
          return { ["visits"]: completionVisits, ["beforeAtEnd"]: completionBeforeAtEnd, ["beforeState"]: completionBeforeState, ["nestedKind"]: completionNestedKind, ["afterAtEnd"]: completionAfterAtEnd, ["afterState"]: completionAfterState };
        });
        // Source "surface.proto.ts":57:1
        __puiVueExposeMethod("read", (): { "axes": string; "horizontal": { "position": number; "visibleRatio": number; "canScrollBefore": boolean; "canScrollAfter": boolean; "atEnd": boolean }; "vertical": { "position": number; "visibleRatio": number; "canScrollBefore": boolean; "canScrollAfter": boolean; "atEnd": boolean }; "scrolling": boolean; "projection": string; "endFollow": { "state": string; "requestStatus": string } } => {
          // Source "surface.proto.ts":57:30
          return scroll.getSnapshot();
        });
        // Source "surface.proto.ts":58:1
        return (r: __puiVueFrame) => {
          // Source "surface.proto.ts":58:11
          return __puiVueSlot(r);
        };
      })(undefined);
        __puiVueSetup = false;
        __puiVueRawProps = __puiVueGetHostProps();

        __puiVueProps = __puiVueResolveProps(__puiVueRawProps, true);

        __puiVueInteraction.refresh();
        __puiVueInvokeLife('created');
        return renderer;
      } catch (error) {
        __puiVueDisposing = true;
        try { __puiVueInteraction.dispose(); }
        finally {
          try {  }
          finally {
            try { __puiVueScope.dispose(); }
            finally {
              __puiVueDisposed = true; 
              for (const cleanup of __puiVueStateCleanup) cleanup();
              __puiVueStateQueue.length = 0; __puiVueWatchers.length = 0;
            }
          }
        }
        throw error;
      }
    })();

    const __puiVueHandle: GeneratedHandle = Object.freeze({
      update() { __puiVuePublicAlive(); __puiVueRequestUpdate(__puiVueRunValue); },
      getExposes() { __puiVuePublicAlive(); return __puiVueExposes as GeneratedExposes; },
    });
    __puiVueContext.expose(__puiVueHandle);

    const __puiVueView = __puiVueVue.defineComponent({
      name: 'CompiledView', inheritAttrs: false,
      props: { revision: { type: Number, required: true } },
      setup(viewProps) {
        let epoch: __puiVueEpoch = { id: ++__puiVueEpochId, active: true, committed: false };
        __puiVueCurrentEpoch = epoch;
        const activation = __puiVueVue.shallowRef(0);
        let deactivated = false;

        let drawnRevision = -1, drawnActivation = -1, committedRevision = -1;
        let cached: __puiVueVue.VNodeArrayChildren = [];
        let root: HTMLElement | null = null;
        function bindRoot(element: Element | __puiVueVue.ComponentPublicInstance | null): void {
          if (!element) { __puiVueUnbindRoot(epoch); return; }
          if (!(element instanceof HTMLElement)) throw new TypeError('[Vue source] Root must be an HTMLElement');
          root = element;
          if (epoch !== __puiVueCurrentEpoch || !epoch.active) return;
          if (__puiVueRootEpoch && (__puiVueRootElement !== root || __puiVueRootEpoch !== epoch)) __puiVueUnbindRoot(__puiVueRootEpoch);
          __puiVueRootElement = root; __puiVueRootEpoch = root ? epoch : undefined;
          if (epoch.committed) {

            __puiVueInteraction.mount();
          }
        }
        function commit(): void {

          if (__puiVueDisposed || __puiVueDisposing || deactivated || !epoch.active || epoch !== __puiVueCurrentEpoch || !__puiVuePresent.value) return;
          if (!epoch.committed) {

            epoch.committed = true;
            committedRevision = drawnRevision;


            __puiVueInteraction.mount();
            __puiVueInvokeLife('mounted');

          }
          else if (committedRevision !== drawnRevision) { committedRevision = drawnRevision; __puiVueInvokeLife('updated'); }
        }
        __puiVueVue.onMounted(commit);
        __puiVueVue.onUpdated(commit);
        __puiVueVue.onBeforeUnmount(() => { epoch.active = false; __puiVueUnbindRoot(epoch); });
        __puiVueVue.onUnmounted(() => { __puiVueCommitUnmount(epoch); });
        __puiVueVue.onDeactivated(() => { deactivated = true; __puiVueCommitUnmount(epoch); });
        __puiVueVue.onActivated(() => {
          if (!deactivated || __puiVueDisposed || __puiVueDisposing) return;
          deactivated = false;
          epoch = { id: ++__puiVueEpochId, active: true, committed: false };
          __puiVueCurrentEpoch = epoch;
          __puiVueRootElement = root; __puiVueRootEpoch = root ? epoch : undefined;
          activation.value += 1;
        });
        return () => {
          __puiVueHostRevision.value;
          const revision = viewProps.revision!, active = activation.value;
          if (__puiVueDisposed || __puiVueDisposing || deactivated || !epoch.active || epoch !== __puiVueCurrentEpoch || !__puiVuePresent.value) return null;
          if (drawnRevision !== revision || drawnActivation !== active) {
            drawnRevision = revision; drawnActivation = active;
            __puiVueRequested = false;
            const frame: __puiVueFrame = { epoch, slotUsed: false };
            const children = typeof __puiVueRenderer === 'function' ? __puiVueChildren(__puiVueRenderer(frame)) : null;
            cached = children == null ? [] : Array.isArray(children) ? children : [children];
          }
          const tag = __puiVueInteraction.rootTag() ?? 'div';
          if (['input', 'textarea', 'img'].includes(tag) && cached.length) throw new Error('[Template] physical control Root requires empty children');
          const physical = __puiVueVue.h(tag, { 'data-pui-root': '', ...__puiVueInteraction.rootProperties(), ref: bindRoot }, cached.length ? cached : undefined);
          const portal = __puiVueInteraction.portalTarget();
          return portal ? __puiVueVue.h(__puiVueVue.Teleport, { to: portal }, [physical]) : physical;
        };
      },
    });
    __puiVueVue.onBeforeUpdate(() => { __puiVueNotifyProps(); __puiVueSlotRevision.value += 1; });
    __puiVueVue.onBeforeUnmount(() => {
      __puiVueDisposing = true;
      __puiVueQueueTicket += 1;
      __puiVueRequested = false;
      if (__puiVueCurrentEpoch) __puiVueUnbindRoot(__puiVueCurrentEpoch);
      if (__puiVueCurrentEpoch) __puiVueCurrentEpoch.active = false;
    });
    __puiVueVue.onUnmounted(() => {
      __puiVueInternalTeardown = true;
      try { __puiVueInvokeLife('beforeDispose'); }

      finally {
        try { __puiVueScope.dispose(); }
        finally {
          try { __puiVueInteraction.dispose(); }
          finally {
            try {  }
            finally {
              __puiVueInternalTeardown = false; __puiVueDisposed = true; 
              for (const cleanup of __puiVueStateCleanup) cleanup();
              __puiVueStateQueue.length = 0; __puiVueWatchers.length = 0;
            }
          }
        }
      }
    });
    return () => __puiVuePresent.value && !__puiVueDisposing ? __puiVueVue.h(__puiVueView, { revision: __puiVueRevision.value }) : null;
  },
});

export default CompiledComponent;

//# sourceMappingURL=Surface.ts.map
