import datetime,hashlib,json,os,pathlib,re,signal,subprocess
root=pathlib.Path("/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a");ops=root.with_name(root.name+'-ops');out=ops/'combined-controls-c0e5bc91';out.mkdir(exist_ok=False)
base='c0e5bc91c47589d64080af974d0c98edd308099c'
temp=pathlib.Path('/tank/shared/projects/proto-ui-agent/s5-controls-tmp75d5');temp.mkdir(exist_ok=True)
env=dict(os.environ,CI='1',COREPACK_ENABLE_DOWNLOAD_PROMPT='0',ASTRO_TELEMETRY_DISABLED='1',NODE_OPTIONS='--max-old-space-size=4096',TMPDIR=str(temp));env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env['PATH']
workflow=root/'.github/workflows/compiler-browser-acceptance.yml';source=workflow.read_text();block=re.search(r'corepack pnpm@10\.32\.1 exec vitest run\s+([\s\S]+?)--maxWorkers=1',source).group(1);tests=re.findall(r'(packages/[^\s\\]+\.test\.ts)',block)
assert len(tests)==24 and len(set(tests))==24,tests
assert {'packages/compiler/test/scroll-axis-sync.test.ts','packages/compiler/test/gpui-event-notification.test.ts','packages/compiler/test/browser-source-input.test.ts'}<=set(tests)
files=[*tests,'.github/workflows/compiler-browser-acceptance.yml','packages/compiler/src/targets.ts','packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs','scripts/coverage-matrices/check-website-production-bundle.mjs','scripts/coverage-matrices/test/check-website-production-bundle.test.mjs','native/gpui/fixtures/base-checkbox-session.json']
def hashes():return {f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files}
def git(*a):return subprocess.check_output(['git',*a],cwd=root,env=env,text=True).strip()
status={'state':'running','head':base,'testFiles':tests,'TMPDIR':str(temp),'steps':[]}
def save():(out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def run(name,cmd,timeout):
 log=out/(name+'.log');row={'name':name,'command':cmd,'state':'running','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};status['steps'].append(row);save()
 with log.open('wb') as f:
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
  try:rc=p.wait(timeout)
  except subprocess.TimeoutExpired:
   row['timedOut']=True
   try:os.killpg(p.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   rc=p.wait(10)
 row.update(exitCode=rc,state='passed' if rc==0 and not row.get('timedOut') else 'failed',finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),sha256=hashlib.sha256(log.read_bytes()).hexdigest());save()
 assert row['state']=='passed',(name,rc)
try:
 assert git('rev-parse','HEAD')==base and git('status','--porcelain')==''
 status.update(tree=git('rev-parse','HEAD^{tree}'),sourceSha256Before=hashes());save()
 run('official-source-regressions',['corepack','pnpm@10.32.1','exec','vitest','run',*tests,'--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile.json='+str(out/'vitest.json')],600)
 result=json.loads((out/'vitest.json').read_text());status['sourceTestCounts']={k:result[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']};assert result['numFailedTests']==0 and result['numPendingTests']==0 and result['numTotalTests']>=401
 run('full-bundle-gate',['node','--test','--test-reporter=tap','scripts/coverage-matrices/test/check-website-production-bundle.test.mjs'],180)
 counts={k:int(v) for k,v in re.findall(r'^# (tests|pass|fail|skipped) (\d+)$',(out/'full-bundle-gate.log').read_text(),re.M)};status['gateTestCounts']=counts;assert counts['fail']==0 and counts['skipped']==0 and counts['pass']>=2082
 run('committed-fixture-check',['corepack','pnpm@10.32.1','run','check:gpui-session-fixtures'],180)
 status.update(sourceSha256After=hashes(),headAfter=git('rev-parse','HEAD'),statusAfter=git('status','--porcelain'))
 assert status['sourceSha256After']==status['sourceSha256Before'] and status['headAfter']==base and status['statusAfter']==''
 status['state']='passed'
except Exception as error:status.update(state='failed',error=repr(error))
finally:status['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps(status,indent=2))
raise SystemExit(0 if status['state']=='passed' else 1)
