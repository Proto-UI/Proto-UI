import datetime,hashlib,json,os,pathlib,re,subprocess
root=pathlib.Path("/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a");ops=root.with_name(root.name+'-ops');out=ops/'manual-policy-final-validation';out.mkdir(exist_ok=False)
base='c0e5bc91c47589d64080af974d0c98edd308099c';policy='047b0fdf438e15da771c7e7e3511827520e2d99a'
temp=pathlib.Path('/tank/shared/projects/proto-ui-agent/s5ci75d5');temp.mkdir(exist_ok=True)
env=dict(os.environ,CI='1',COREPACK_ENABLE_DOWNLOAD_PROMPT='0',TMPDIR=str(temp));env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env['PATH'];assert env.get('HUSKY')!='0'
status={'state':'running','sourceValidationHead':base,'policyOriginalCommit':policy,'TMPDIR':str(temp),'commands':[]}
def save():(out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=root,env=env,text=True).strip()
def run(name,cmd,timeout=180):
 log=out/(name+'.log');row={'name':name,'command':cmd,'state':'running','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};status['commands'].append(row);save()
 with log.open('wb') as f:p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 row.update(exitCode=p.returncode,state='passed' if p.returncode==0 else 'failed',finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),sha256=hashlib.sha256(log.read_bytes()).hexdigest());save();assert p.returncode==0,(name,p.returncode)
def assertTestSummary(name,expected):
 counts={k:int(v) for k,v in re.findall(r'^# (tests|pass|fail|skipped) (\d+)$',(out/(name+'.log')).read_text(),re.M)}
 assert counts=={'tests':expected,'pass':expected,'fail':0,'skipped':0},(name,counts)
 status.setdefault('counts',{})[name]=counts;save()
try:
 assert git('rev-parse','HEAD')==base and git('status','--porcelain')==''
 run('fetch-policy',['git','fetch','origin','fix/sprint1-dispatch-wiring-20261124-75d5'])
 run('signed-off-policy',['git','cherry-pick','--signoff','-x',policy])
 status['head']=git('rev-parse','HEAD');status['tree']=git('rev-parse','HEAD^{tree}')
 changed=git('diff','--name-only',base,'HEAD').splitlines();status['policyChangedPaths']=changed
 assert all(p=='scripts/ci/test/ci-scheduling-policy.test.mjs' or p.startswith('internal/records/') for p in changed),changed
 source=json.loads((ops/'combined-controls-c0e5bc91/status.json').read_text());assert source['state']=='passed'
 status['retainedSourceHashes']={}
 for f,h in source['sourceSha256After'].items():
  actual=hashlib.sha256((root/f).read_bytes()).hexdigest();assert actual==h,(f,actual,h);status['retainedSourceHashes'][f]=actual
 status['sourceAndGateInputsUnchanged']=True;save()
 run('scheduling-controls',['node','--test','--test-reporter=tap','scripts/ci/test/ci-scheduling-policy.test.mjs']);assertTestSummary('scheduling-controls',31)
 run('cycle-controls',['node','--test','--test-reporter=tap','scripts/ci/test/cycle-job-inventory.test.mjs','scripts/ci/test/cycle-report.test.mjs']);assertTestSummary('cycle-controls',28)
 run('ledger-controls',['node','--test','--test-reporter=tap','scripts/ci/test/release-source-ledger-checkpoints.test.mjs'],300);assertTestSummary('ledger-controls',21)
 run('schedule',['node','scripts/ci/check-ci-schedule.mjs'])
 run('diff-check',['git','diff','--check','457d27f7fe554f398970a836ee9c95edb4846f47','HEAD'])
 status['headAfter']=git('rev-parse','HEAD');status['statusAfter']=git('status','--porcelain');assert status['headAfter']==status['head'] and status['statusAfter']==''
 for f,h in status['retainedSourceHashes'].items():assert hashlib.sha256((root/f).read_bytes()).hexdigest()==h
 status['state']='passed'
except Exception as error:status.update(state='failed',error=repr(error))
finally:status['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps(status,indent=2))
raise SystemExit(0 if status['state']=='passed' else 1)
