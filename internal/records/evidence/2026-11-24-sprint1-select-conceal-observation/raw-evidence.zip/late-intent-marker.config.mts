import base from "/workspace/scratch/62ffef219b8e/proto-ui-sprint1/vitest.config.ts";
import { writeFileSync } from 'node:fs';

export default {
  ...base,
  plugins: [
    ...(base.plugins ?? []),
    {
      name: 'select-conceal-late-intent-marker',
      enforce: 'pre',
      transform(code, id) {
        if (id.split('?')[0] !== "/workspace/scratch/62ffef219b8e/proto-ui-sprint1/packages/adapters/web-component/src/adapt.ts") return;
        const original = "if (!snapshot.present) setViewDetached(true);";
        const occurrences = code.split(original).length - 1;
        if (occurrences !== 2) throw new Error(`Expected known original source, found ${occurrences} matches`);
        const mutated = code.replace(original, "/* mutation: delay the not-present marker until physical retirement */");
        writeFileSync("/workspace/scratch/62ffef219b8e/select-conceal/late-intent-marker-transformed-source.ts", mutated);
        return { code: mutated, map: null };
      },
    },
  ],
};
