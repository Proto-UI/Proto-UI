import base from "/workspace/scratch/62ffef219b8e/proto-ui-sprint1/vitest.config.ts";
import { writeFileSync } from 'node:fs';

export default {
  ...base,
  plugins: [
    ...(base.plugins ?? []),
    {
      name: 'select-conceal-one-frame',
      enforce: 'pre',
      transform(code, id) {
        if (id.split('?')[0] !== "/workspace/scratch/62ffef219b8e/proto-ui-sprint1/packages/adapters/web-component/src/portal-conceal.ts") return;
        const original = "        frame = view.requestAnimationFrame(() => {\n          if (pending !== finish) return;\n          frame = view.requestAnimationFrame(finish);\n        });";
        const occurrences = code.split(original).length - 1;
        if (occurrences !== 1) throw new Error(`Expected known original source, found ${occurrences} matches`);
        const mutated = code.replace(original, "        frame = view.requestAnimationFrame(finish);");
        writeFileSync("/workspace/scratch/62ffef219b8e/select-conceal/one-frame-transformed-source.ts", mutated);
        return { code: mutated, map: null };
      },
    },
  ],
};
