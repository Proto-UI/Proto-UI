import { afterEach, describe, expect, it, vi } from 'vitest';
import type { WebComponentAdapterElement } from '@proto.ui/adapter-web-component';
import { AdaptToWebComponent, setElementProps } from '@proto.ui/adapter-web-component';
import { installRenderingOpportunities } from '../../test-utils/rendering-opportunities';
import { selectContent, selectItem, selectRoot, selectTrigger, selectValue } from '../src/select';

AdaptToWebComponent(selectRoot as any);
AdaptToWebComponent(selectTrigger as any);
AdaptToWebComponent(selectValue as any);
AdaptToWebComponent(selectContent as any);
AdaptToWebComponent(selectItem as any);

async function flush(): Promise<void> {
  await Promise.resolve();
  await Promise.resolve();
  await Promise.resolve();
}

async function settle(): Promise<void> {
  await vi.advanceTimersByTimeAsync(0);
  await flush();
}

function createSelect(options?: {
  root?: Record<string, unknown>;
  trigger?: Record<string, unknown>;
  value?: Record<string, unknown>;
  content?: Record<string, unknown>;
  contentElement?: WebComponentAdapterElement<typeof selectContent>;
  items?: Array<Record<string, unknown>>;
}) {
  const root = document.createElement('base-select-root') as any;
  const trigger = document.createElement('base-select-trigger') as any;
  const value = document.createElement('base-select-value') as any;
  const content = options?.contentElement ?? (document.createElement('base-select-content') as any);
  const items = (
    options?.items ?? [
      { value: 'alpha', textValue: 'Alpha' },
      { value: 'beta', textValue: 'Beta' },
      { value: 'gamma', textValue: 'Gamma' },
    ]
  ).map((props) => {
    const item = document.createElement('base-select-item') as any;
    setElementProps(item, props);
    item.textContent = String(props.textValue ?? props.value ?? 'Option');
    content.appendChild(item);
    return item;
  });
  setElementProps(root, options?.root ?? {});
  setElementProps(trigger, options?.trigger ?? {});
  setElementProps(value, options?.value ?? { placeholder: 'Pick one' });
  setElementProps(content, options?.content ?? {});
  trigger.appendChild(value);
  root.append(trigger, content);
  document.body.appendChild(root);
  return { root, trigger, value, content, items };
}

afterEach(async () => {
  document.body.replaceChildren();
  await flush();
  vi.useRealTimers();
});

describe('prototypes/base: select', () => {
  it('projects a stable public author name independently of selected text and clears removed labels', async () => {
    // T-BASE-SELECT-TRIGGER-0001-CASE-AUTHOR-NAME
    vi.useFakeTimers();
    const { root, trigger, value } = createSelect({
      root: { defaultValue: 'alpha' },
      trigger: { accessibleLabel: 'Runtime' },
    });
    await settle();
    expect(trigger.getAttribute('aria-label')).toBe('Runtime');
    expect(value.textContent).toBe('Alpha');
    setElementProps(root, { value: 'beta' });
    await settle();
    expect(trigger.getAttribute('aria-label')).toBe('Runtime');
    expect(value.textContent).toBe('Beta');
    setElementProps(trigger, { accessibleLabel: '运行时' });
    await settle();
    expect(trigger.getAttribute('aria-label')).toBe('运行时');
    setElementProps(trigger, { accessibleLabel: '' });
    await settle();
    expect(trigger.hasAttribute('aria-label')).toBe(false);
    expect(value.textContent).toBe('Beta');
    expect(root.getExposes().value.get()).toBe('beta');
  });

  it('owns single-selection facts, collection, anatomy, and live selected text', async () => {
    // T-BASE-SELECT-0001-CASE-ROOT-OWNERSHIP
    // T-BASE-SELECT-0001-CASE-SELECTION-TEXT
    // T-BASE-SELECT-VALUE-0001-CASE-CONTEXT-FALLBACK
    vi.useFakeTimers();
    const { root, value, items } = createSelect({ root: { defaultValue: 'beta' } });
    await settle();

    expect(root.getExposes()).toHaveProperty('requestOpen');
    expect(root.getExposes()).toHaveProperty('requestValue');
    expect(root.getExposes().value.get()).toBe('beta');
    expect(root.getExposes().textValue.get()).toBe('Beta');
    expect(value.getExposes().displayValue.get()).toBe('Beta');
    expect(value.textContent).toBe('Beta');
    expect(
      root
        .getExposes()
        .getCollectionItems()
        .map((item: any) => item.value)
    ).toEqual(['alpha', 'beta', 'gamma']);
    expect(items[1].getExposes().selected.get()).toBe(true);

    setElementProps(items[1], { value: 'beta', textValue: 'Beta v2' });
    await flush();
    expect(root.getExposes().value.get()).toBe('beta');
    expect(root.getExposes().textValue.get()).toBe('Beta v2');
    expect(value.textContent).toBe('Beta v2');
  });

  it('emits controlled open and value requests without replacing either owner fact', async () => {
    // T-BASE-SELECT-0001-CASE-REQUESTS
    // T-BASE-SELECT-ITEM-0001-CASE-COMMIT
    vi.useFakeTimers();
    const { root, trigger, items } = createSelect({
      root: { open: false, value: 'alpha' },
    });
    const openRequests: any[] = [];
    const valueRequests: any[] = [];
    root.addEventListener('openChange', (event: Event) =>
      openRequests.push((event as CustomEvent).detail)
    );
    root.addEventListener('valueChange', (event: Event) =>
      valueRequests.push((event as CustomEvent).detail)
    );
    await settle();

    trigger.click();
    await settle();
    expect(root.getExposes().open.get()).toBe(false);
    expect(openRequests.at(-1)).toEqual(
      expect.objectContaining({ open: true, reason: 'trigger.press', focusReason: 'pointer' })
    );

    setElementProps(root, { open: true, value: 'alpha' });
    await settle();
    items[1].click();
    await settle();
    expect(root.getExposes().value.get()).toBe('alpha');
    expect(root.getExposes().open.get()).toBe(true);
    expect(valueRequests.at(-1)).toEqual({ value: 'beta', textValue: 'Beta', reason: 'pointer' });
    expect(openRequests.at(-1)).toEqual(
      expect.objectContaining({ open: false, reason: 'item.select' })
    );
  });

  it.each([
    ['selected-or-first', '', 0],
    ['selected-or-last', '', 2],
    ['selected-or-first', 'gamma', 2],
    ['selected-or-last', 'alpha', 0],
  ] as const)(
    'keeps genuine opening entry %s with selected value %s',
    async (entry, selected, target) => {
      // T-BASE-SELECT-0001-CASE-REPEATED-OPEN-BOUNDARIES
      vi.useFakeTimers();
      const { root, trigger, items } = createSelect({
        root: { defaultValue: selected },
        items: [
          { value: 'alpha', textValue: 'Alpha' },
          { value: 'beta', textValue: 'Beta', disabled: true },
          { value: 'gamma', textValue: 'Gamma' },
        ],
      });
      await settle();
      trigger.focus();
      const requests: unknown[] = [];
      root.addEventListener('openChange', (event: Event) =>
        requests.push((event as CustomEvent).detail)
      );
      expect(
        root.getExposes().requestOpen({
          open: true,
          reason: 'entry-regression',
          focusReason: 'keyboard',
          entry,
        })
      ).toBe(true);
      await settle();
      expect(root.getExposes().open.get()).toBe(true);
      expect(root.getExposes().value.get()).toBe(selected);
      expect(document.activeElement).toBe(items[target]);
      expect(items.map((item: any) => item.getExposes().active.get())).toEqual(
        items.map((_item: any, index: number) => index === target)
      );
      expect(items.map((item: any) => item.getExposes().selected.get())).toEqual([
        selected === 'alpha',
        false,
        selected === 'gamma',
      ]);
      expect(requests).toEqual([
        { open: true, reason: 'entry-regression', focusReason: 'keyboard' },
      ]);
    }
  );

  it.each(['refused', 'synchronous', 'asynchronous'] as const)(
    'keeps controlled opening acceptance with the owner (%s)',
    async (acceptance) => {
      // T-BASE-SELECT-0001-CASE-REPEATED-OPEN-BOUNDARIES
      vi.useFakeTimers();
      const { root, trigger, items } = createSelect({ root: { open: false, value: 'alpha' } });
      await settle();
      trigger.focus();
      const requests: unknown[] = [];
      root.addEventListener('openChange', (event: Event) => {
        requests.push((event as CustomEvent).detail);
        if (acceptance === 'synchronous') setElementProps(root, { open: true, value: 'alpha' });
      });
      expect(
        root.getExposes().requestOpen({
          open: true,
          reason: 'controlled-entry-regression',
          focusReason: 'keyboard',
          entry: 'selected-or-last',
        })
      ).toBe(true);
      await settle();
      expect(root.getExposes().open.get()).toBe(acceptance === 'synchronous');
      expect(root.getExposes().value.get()).toBe('alpha');
      if (acceptance !== 'synchronous') {
        expect(document.activeElement).toBe(trigger);
        expect(items.map((item: any) => item.getExposes().active.get())).toEqual([
          false,
          false,
          false,
        ]);
      }
      if (acceptance === 'asynchronous') {
        setElementProps(root, { open: true, value: 'alpha' });
        await settle();
      }
      if (acceptance !== 'refused') {
        expect(document.activeElement).toBe(items[0]);
        expect(items.map((item: any) => item.getExposes().active.get())).toEqual([
          true,
          false,
          false,
        ]);
      }
      expect(requests).toEqual([
        { open: true, reason: 'controlled-entry-regression', focusReason: 'keyboard' },
      ]);
    }
  );

  it('rejects repeated public open when Root is disabled without publishing a request', async () => {
    // T-BASE-SELECT-0001-CASE-REPEATED-OPEN-BOUNDARIES
    vi.useFakeTimers();
    const { root, items } = createSelect({
      root: { defaultOpen: true, defaultValue: 'alpha' },
    });
    await settle();
    setElementProps(root, { disabled: true });
    await settle();
    const read = () => ({
      open: root.getExposes().open.get(),
      value: root.getExposes().value.get(),
      active: items.map((item: any) => item.getExposes().active.get()),
      selected: items.map((item: any) => item.getExposes().selected.get()),
    });
    const before = read();
    const focused = document.activeElement;
    const requests: unknown[] = [];
    root.addEventListener('openChange', (event: Event) =>
      requests.push((event as CustomEvent).detail)
    );
    expect(
      root.getExposes().requestOpen({
        open: true,
        reason: 'disabled-repeat-regression',
        focusReason: 'programmatic',
      })
    ).toBe(false);
    await settle();
    expect(read()).toEqual(before);
    expect(document.activeElement).toBe(focused);
    expect(requests).toEqual([]);
  });

  it('projects combobox, listbox, option, and stable relationship semantics', async () => {
    // T-BASE-SELECT-TRIGGER-0001-CASE-COMMAND-A11Y
    // T-BASE-SELECT-CONTENT-0001-CASE-A11Y-FOCUS
    // T-BASE-SELECT-ITEM-0001-CASE-COLLECTION-A11Y
    vi.useFakeTimers();
    const { trigger, value, content, items } = createSelect({ root: { defaultValue: 'beta' } });
    await settle();

    expect(trigger.getAttribute('role')).toBe('combobox');
    expect(trigger.getAttribute('aria-haspopup')).toBe('listbox');
    expect(trigger.getAttribute('aria-expanded')).toBe('false');
    expect(trigger.getAttribute('aria-controls')).toMatch(/^pui-select-\d+-content$/);
    expect(value.getAttribute('data-pui-style')).toContain('pointer-events-none');
    trigger.click();
    await settle();
    expect(content.getAttribute('id')).toBe(trigger.getAttribute('aria-controls'));
    expect(content.getAttribute('role')).toBe('listbox');
    expect(content.getAttribute('aria-orientation')).toBe('vertical');
    expect(items[0].getAttribute('role')).toBe('option');
    expect(items[0].getAttribute('aria-selected')).toBe('false');
    expect(items[1].getAttribute('aria-selected')).toBe('true');
    expect(items[0].getAttribute('aria-disabled')).toBe('false');
  });

  it.each([
    ['Enter', 'beta'],
    [' ', 'beta'],
    ['ArrowDown', 'beta'],
    ['ArrowUp', 'beta'],
  ])('opens from Trigger %j and focuses selected option %s once', async (key, expectedValue) => {
    // T-BASE-SELECT-TRIGGER-0001-CASE-KEYBOARD
    vi.useFakeTimers();
    const { root, trigger, items } = createSelect({ root: { defaultValue: 'beta' } });
    const requests: any[] = [];
    root.addEventListener('openChange', (event: Event) =>
      requests.push((event as CustomEvent).detail)
    );
    await settle();

    trigger.focus();
    trigger.dispatchEvent(new KeyboardEvent('keydown', { key, bubbles: true }));
    await settle();
    expect(root.getExposes().open.get()).toBe(true);
    expect(document.activeElement).toBe(items[1]);
    expect(items[1].getExposes().active.get()).toBe(true);
    expect(items[1].getExposes().selected.get()).toBe(true);
    expect(items[1].textContent).toBe(expectedValue === 'beta' ? 'Beta' : expectedValue);
    expect(requests.filter((request) => request.open).length).toBe(1);
  });

  it('uses first or last enabled boundary when no value is selected', async () => {
    // T-BASE-SELECT-TRIGGER-0001-CASE-KEYBOARD
    // T-BASE-SELECT-CONTENT-0001-CASE-KEYBOARD
    vi.useFakeTimers();
    const down = createSelect({ items: [{ value: 'a' }, { value: 'b', disabled: true }] });
    await settle();
    down.trigger.focus();
    down.trigger.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true }));
    await settle();
    expect(document.activeElement).toBe(down.items[0]);
    expect(down.root.getExposes().value.get()).toBe('');
    down.root.remove();
    await flush();

    const up = createSelect({
      items: [{ value: 'a' }, { value: 'b', disabled: true }, { value: 'c' }],
    });
    await settle();
    up.trigger.focus();
    up.trigger.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowUp', bubbles: true }));
    await settle();
    expect(document.activeElement).toBe(up.items[2]);
    expect(up.root.getExposes().value.get()).toBe('');
  });

  it('keeps active navigation separate from selected and skips disabled options', async () => {
    // T-BASE-SELECT-ITEM-0001-CASE-STATE-SEPARATION
    // T-BASE-SELECT-ITEM-0001-CASE-DISABLED
    vi.useFakeTimers();
    const { root, items } = createSelect({
      root: { defaultOpen: true, defaultValue: 'alpha' },
      items: [
        { value: 'alpha', textValue: 'Alpha' },
        { value: 'beta', textValue: 'Beta', disabled: true },
        { value: 'gamma', textValue: 'Gamma' },
      ],
    });
    await settle();
    expect(document.activeElement).toBe(items[0]);

    window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown' }));
    await flush();
    expect(document.activeElement).toBe(items[2]);
    expect(items[0].getExposes().selected.get()).toBe(true);
    expect(items[0].getExposes().active.get()).toBe(false);
    expect(items[2].getExposes().selected.get()).toBe(false);
    expect(items[2].getExposes().active.get()).toBe(true);
    expect(root.getExposes().value.get()).toBe('alpha');

    items[1].click();
    await flush();
    expect(root.getExposes().value.get()).toBe('alpha');
    expect(root.getExposes().open.get()).toBe(true);
    expect(items[1].getAttribute('aria-disabled')).toBe('true');
  });

  it('clears non-focused pointer transient state on leave and resets every Item on close', async () => {
    // T-BASE-SELECT-ITEM-0001-CASE-TRANSIENT-RESET
    // T-BASE-SELECT-CONTENT-0001-CASE-ENTRY-STABILITY
    vi.useFakeTimers();
    const { root, trigger, items } = createSelect({
      root: { defaultOpen: true, defaultValue: 'alpha' },
    });
    await settle();
    expect(document.activeElement).toBe(items[0]);

    items[1].dispatchEvent(new PointerEvent('pointerenter', { bubbles: true }));
    await flush();
    expect(items[1].getExposes().hovered.get()).toBe(true);
    // Definition delta: enter alone is hover, not admitted mouse navigation.
    expect(items[1].getExposes().active.get()).toBe(false);
    expect(items[0].getExposes().active.get()).toBe(true);
    expect(root.getExposes().value.get()).toBe('alpha');

    items[1].dispatchEvent(new PointerEvent('pointerleave', { bubbles: true }));
    await flush();
    expect(items[1].getExposes().hovered.get()).toBe(false);
    expect(items[1].getExposes().active.get()).toBe(false);
    expect(items[0].getExposes().active.get()).toBe(true);

    items[1].focus();
    await flush();
    expect(items[1].getExposes().active.get()).toBe(true);
    trigger.focus();
    await flush();
    expect(items[1].getExposes().focused.get()).toBe(false);
    expect(items[1].getExposes().active.get()).toBe(false);

    items[1].dispatchEvent(new PointerEvent('pointerenter', { bubbles: true }));
    items[1].click();
    await settle();
    expect(root.getExposes().open.get()).toBe(false);
    expect(document.activeElement).toBe(trigger);
    for (const item of items) {
      expect(item.getExposes().hovered.get()).toBe(false);
      expect(item.getExposes().focused.get()).toBe(false);
      expect(item.getExposes().active.get()).toBe(false);
    }

    trigger.click();
    await settle();
    expect(document.activeElement).toBe(items[1]);
    expect(items.filter((item) => item.getExposes().focused.get())).toEqual([items[1]]);
    expect(items.filter((item) => item.getExposes().active.get())).toEqual([items[1]]);
  });

  it('supports Home, End, and printable typeahead through asFocusRoving', async () => {
    // T-BASE-SELECT-CONTENT-0001-CASE-KEYBOARD
    vi.useFakeTimers();
    const { items } = createSelect({ root: { defaultOpen: true } });
    await settle();
    expect(document.activeElement).toBe(items[0]);

    window.dispatchEvent(new KeyboardEvent('keydown', { key: 'End' }));
    await flush();
    expect(document.activeElement).toBe(items[2]);
    window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Home' }));
    await flush();
    expect(document.activeElement).toBe(items[0]);
    window.dispatchEvent(new KeyboardEvent('keydown', { key: 'g' }));
    await flush();
    expect(document.activeElement).toBe(items[2]);
  });

  it('commits with keyboard, refreshes Value, closes, and restores Trigger focus', async () => {
    // T-BASE-SELECT-ITEM-0001-CASE-COMMIT
    // T-BASE-SELECT-CONTENT-0001-CASE-DISMISS
    vi.useFakeTimers();
    const { root, trigger, value, items } = createSelect();
    await settle();
    trigger.focus();
    trigger.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true }));
    await settle();
    window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown' }));
    await flush();
    expect(document.activeElement).toBe(items[1]);

    items[1].dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
    await settle();
    expect(root.getExposes().value.get()).toBe('beta');
    expect(value.textContent).toBe('Beta');
    expect(root.getExposes().open.get()).toBe(false);
    expect(document.activeElement).toBe(trigger);
  });

  it('Escape cancels navigation, closes, and restores Trigger focus', async () => {
    // T-BASE-SELECT-0001-CASE-SELECTION-TEXT
    // T-BASE-SELECT-CONTENT-0001-CASE-DISMISS
    vi.useFakeTimers();
    const { root, trigger, items } = createSelect({ root: { defaultValue: 'alpha' } });
    await settle();
    trigger.click();
    await settle();
    window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown' }));
    await flush();
    expect(document.activeElement).toBe(items[1]);

    window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
    await settle();
    expect(root.getExposes().open.get()).toBe(false);
    expect(root.getExposes().value.get()).toBe('alpha');
    expect(document.activeElement).toBe(trigger);
  });

  it('Tab and outside press close without accidental selection', async () => {
    // T-BASE-SELECT-CONTENT-0001-CASE-DISMISS
    vi.useFakeTimers();
    const tabSelect = createSelect({ root: { defaultOpen: true, defaultValue: 'alpha' } });
    await settle();
    const tabEvent = new KeyboardEvent('keydown', { key: 'Tab', cancelable: true });
    window.dispatchEvent(tabEvent);
    await settle();
    expect(tabSelect.root.getExposes().open.get()).toBe(false);
    expect(tabSelect.root.getExposes().value.get()).toBe('alpha');
    expect(tabEvent.defaultPrevented).toBe(false);
    tabSelect.root.remove();
    await flush();

    const outsideSelect = createSelect({ root: { defaultOpen: true } });
    await settle();
    document.body.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true }));
    await settle();
    expect(outsideSelect.root.getExposes().open.get()).toBe(false);
    expect(outsideSelect.root.getExposes().value.get()).toBe('');
  });

  it.each([false, true])(
    'Tab from Trigger dismisses before deferred entry (shift=%s)',
    async (shiftKey) => {
      vi.useFakeTimers();
      const { root, trigger, items } = createSelect({ root: { defaultValue: 'alpha' } });
      await settle();
      trigger.focus();
      trigger.click();
      await flush(); // Deliberately do not run the deferred open-focus timer.
      expect(root.getExposes().open.get()).toBe(true);
      expect(document.activeElement).toBe(trigger);
      const event = new KeyboardEvent('keydown', {
        key: 'Tab',
        shiftKey,
        bubbles: true,
        cancelable: true,
      });
      trigger.dispatchEvent(event);
      await flush();
      expect(root.getExposes().open.get()).toBe(false);
      expect(root.getExposes().value.get()).toBe('alpha');
      expect(event.defaultPrevented).toBe(false);
      await settle();
      expect(items.some((item) => item === document.activeElement)).toBe(false);
    }
  );

  it.each([false, true])(
    'deferred Tab honors controlled rejection and does not dismiss another domain (shift=%s)',
    async (shiftKey) => {
      vi.useFakeTimers();
      const a = createSelect({ root: { open: false, value: 'alpha' } });
      const b = createSelect({ root: { open: false, value: 'beta' } });
      await settle();
      const requestsA: any[] = [];
      const requestsB: any[] = [];
      a.root.addEventListener('openChange', (event: any) => requestsA.push(event.detail));
      b.root.addEventListener('openChange', (event: any) => requestsB.push(event.detail));
      setElementProps(a.root, { open: true, value: 'alpha' });
      setElementProps(b.root, { open: true, value: 'beta' });
      await flush();
      a.trigger.focus();
      const tab = new KeyboardEvent('keydown', {
        key: 'Tab',
        shiftKey,
        bubbles: true,
        cancelable: true,
      });
      a.trigger.dispatchEvent(tab);
      expect(tab.defaultPrevented).toBe(false);
      await flush();
      expect(requestsA).toEqual([expect.objectContaining({ open: false, reason: 'tab' })]);
      expect(requestsB).toEqual([]);
      expect(a.root.getExposes().open.get()).toBe(true);
      expect(b.root.getExposes().open.get()).toBe(true);
      expect(a.root.getExposes().value.get()).toBe('alpha');
      const outside = document.createElement('button');
      document.body.append(outside);
      outside.focus();
      // A late Item publication must not revive the cancelled entry of this open epoch.
      const later = document.createElement('base-select-item');
      setElementProps(later, { value: 'later', textValue: 'Later' });
      a.content.appendChild(later);
      await flush();
      outside.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', bubbles: true }));
      await flush();
      expect(requestsA).toHaveLength(1);
      expect(requestsB).toHaveLength(0);
      b.root.remove();
      await settle();
      await settle();
      await settle();
      expect(document.activeElement).toBe(outside);
      expect(a.root.getExposes().open.get()).toBe(true);
      expect(a.root.getExposes().value.get()).toBe('alpha');

      // Cancelling this old entry must not disable a subsequent accepted open epoch.
      setElementProps(a.root, { open: false, value: 'alpha' });
      await settle();
      setElementProps(a.root, { open: true, value: 'alpha' });
      await settle();
      await settle();
      expect(document.activeElement).toBe(a.items[0]);
    }
  );

  it('uses Transition as Overlay presence and applies anchored positioning props', async () => {
    // T-BASE-SELECT-CONTENT-0001-CASE-PRESENCE-POSITION
    vi.useFakeTimers();
    const frame = installRenderingOpportunities();
    const lifecycle: Array<{ type: string; epoch?: number }> = [];
    // Keep the authored prototype intact; this fixture owns its diagnostic sink.
    const TracedContent = AdaptToWebComponent(selectContent, {
      registerAs: 'base-select-conceal-content',
      diagnostics: {
        onLifecycleEvent(event) {
          if (
            event.type === 'mount.mounted' ||
            event.type === 'unmount.begin' ||
            event.type === 'unmount.done' ||
            event.type === 'instance.dispose.done'
          )
            lifecycle.push(event);
        },
      },
    });
    try {
      const { root, trigger, content } = createSelect({
        contentElement: new TracedContent(),
        content: { side: 'top', align: 'end', sideOffset: 12, alignOffset: 3 },
      });
      await settle();
      expect(content.hasAttribute('data-pui-view-detached')).toBe(true);

      trigger.click();
      await settle();
      expect(content.hasAttribute('data-pui-view-detached')).toBe(false);
      expect(content.getExposes().transitionState.get()).toBe('entered');
      expect(content.style.position).toBe('fixed');
      expect(content.dataset.side).toBe('top');
      expect(content.dataset.align).toBe('end');
      expect(content.parentElement).toBe(document.body);
      expect(lifecycle).toEqual([{ type: 'mount.mounted', epoch: expect.any(Number) }]);
      const mounted = lifecycle.slice();
      const epoch = mounted[0]?.epoch;

      trigger.click();
      await settle();
      expect(content.getExposes().transitionState.get()).toBe('closed');
      // The shared marker follows not-present intent immediately. Physical
      // portal retirement still crosses both rendering opportunities.
      expect(content.hasAttribute('data-pui-view-detached')).toBe(true);
      expect(content.parentElement).toBe(document.body);
      expect(lifecycle).toEqual(mounted);
      expect(await frame()).toBeGreaterThan(0);
      expect(content.hasAttribute('data-pui-view-detached')).toBe(true);
      expect(content.parentElement).toBe(document.body);
      expect(lifecycle).toEqual(mounted);
      expect(await frame()).toBeGreaterThan(0);
      expect(content.hasAttribute('data-pui-view-detached')).toBe(true);
      expect(content.parentElement).toBe(root);
      expect(lifecycle).toEqual([
        ...mounted,
        { type: 'unmount.begin', epoch },
        { type: 'unmount.done', epoch },
      ]);
    } finally {
      frame.restore();
    }
  });

  it('refreshes placeholder and raw-value fallback through the Value display state', async () => {
    // T-BASE-SELECT-VALUE-0001-CASE-RENDER-EXPOSE
    // T-BASE-SELECT-VALUE-0001-CASE-BOUNDARY
    vi.useFakeTimers();
    const { root, value } = createSelect({
      root: { value: 'missing' },
      value: { placeholder: 'Initial placeholder' },
      items: [],
    });
    await settle();
    expect(value.getExposes()).toEqual(
      expect.objectContaining({
        displayValue: expect.objectContaining({ get: expect.any(Function) }),
      })
    );
    expect(value.getExposes().displayValue.get()).toBe('missing');
    expect(value.textContent).toBe('missing');

    setElementProps(root, { value: '' });
    await flush();
    expect(value.textContent).toBe('Initial placeholder');
    setElementProps(value, { placeholder: 'Updated placeholder' });
    await flush();
    expect(value.getExposes().displayValue.get()).toBe('Updated placeholder');
    expect(value.textContent).toBe('Updated placeholder');
    expect(value.getExposes()).not.toHaveProperty('focusSelf');
    expect(value.getExposes()).not.toHaveProperty('click');
  });

  it('suppresses Trigger and Item behavior under local or Root disabled state', async () => {
    // T-BASE-SELECT-TRIGGER-0001-CASE-DISABLED
    // T-BASE-SELECT-ITEM-0001-CASE-DISABLED
    vi.useFakeTimers();
    const local = createSelect({ trigger: { disabled: true } });
    await settle();
    local.trigger.click();
    await settle();
    expect(local.root.getExposes().open.get()).toBe(false);
    expect(local.trigger.getAttribute('aria-disabled')).toBe('true');
    expect(local.trigger.getAttribute('tabindex')).not.toBe('0');
    local.root.remove();
    await flush();

    const rootDisabled = createSelect({ root: { disabled: true, defaultOpen: true } });
    await settle();
    rootDisabled.items[0].click();
    await settle();
    expect(rootDisabled.root.getExposes().value.get()).toBe('');
    expect(rootDisabled.root.getExposes().open.get()).toBe(true);
    expect(rootDisabled.items[0].getAttribute('aria-disabled')).toBe('true');
  });
});

it('a controlled owner refusing repeated Escape preserves presence, focus, active item and scroll', async () => {
  // T-BASE-SELECT-CONTENT-0001-CASE-CONTROLLED-PRESENCE
  vi.useFakeTimers();
  const { root, content, items } = createSelect({ root: { open: true, value: 'beta' } });
  await settle();
  const phases: unknown[] = [],
    requests: unknown[] = [];
  root.addEventListener('openChange', (event: Event) =>
    requests.push((event as CustomEvent).detail)
  );
  const transition = content.getExposes().transitionState;
  const off = transition.subscribe((event: { type: string; next?: unknown }) => {
    if (event.type === 'next') phases.push(event.next);
  });
  items[1].focus();
  content.scrollTop = 37;
  const focused = document.activeElement;
  const active = items[1].getExposes().active.get();
  try {
    for (let index = 0; index < 2; index++)
      items[1].dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    expect(root.getExposes().open.get()).toBe(true);
    expect(phases).toEqual([]);
    expect(requests).toHaveLength(2);
    expect(document.activeElement).toBe(focused);
    expect(items[1].getExposes().active.get()).toBe(active);
    expect(content.scrollTop).toBe(37);
    await settle();
    expect(content.getExposes().transitionState.get()).toBe('entered');
  } finally {
    off();
  }
});

it('a synchronously accepting controlled owner drives exactly one committed leave', async () => {
  // T-BASE-SELECT-CONTENT-0001-CASE-CONTROLLED-PRESENCE
  vi.useFakeTimers();
  const { root, trigger, content, items } = createSelect({
    root: { open: true, value: 'beta' },
    content: { leaveDuration: 100 },
  });
  await settle();
  items[1].focus();
  const phases: unknown[] = [],
    requests: unknown[] = [];
  const off = content
    .getExposes()
    .transitionState.subscribe((event: { type: string; next?: unknown }) => {
      if (event.type === 'next') phases.push(event.next);
    });
  root.addEventListener('openChange', (event: Event) => {
    const request = (event as CustomEvent).detail;
    requests.push(request);
    if (!request.open) setElementProps(root, { open: false, value: 'beta' });
  });
  try {
    items[1].dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    await flush();
    expect(requests).toHaveLength(1);
    expect(root.getExposes().open.get()).toBe(false);
    expect(phases.filter((phase) => phase === 'leaving')).toHaveLength(1);
    expect(content.getExposes().transitionState.get()).toBe('leaving');
    expect(document.activeElement).toBe(trigger);
    await vi.advanceTimersByTimeAsync(100);
    await flush();
    expect(content.getExposes().transitionState.get()).toBe('closed');
  } finally {
    off();
  }
});

it('an asynchronous controlled acceptance waits for the owner prop commit', async () => {
  // T-BASE-SELECT-CONTENT-0001-CASE-CONTROLLED-PRESENCE
  vi.useFakeTimers();
  const { root, content, items } = createSelect({
    root: { open: true, value: 'beta' },
    content: { leaveDuration: 100 },
  });
  await settle();
  items[1].focus();
  const phases: unknown[] = [],
    requests: unknown[] = [];
  root.addEventListener('openChange', (event: Event) =>
    requests.push((event as CustomEvent).detail)
  );
  const off = content
    .getExposes()
    .transitionState.subscribe((event: { type: string; next?: unknown }) => {
      if (event.type === 'next') phases.push(event.next);
    });
  try {
    items[1].dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    await settle();
    expect(requests).toHaveLength(1);
    expect(phases).toEqual([]);
    expect(document.activeElement).toBe(items[1]);
    setElementProps(root, { open: false, value: 'beta' });
    await flush();
    expect(phases).toEqual(['leaving']);
    await vi.advanceTimersByTimeAsync(100);
    await flush();
    expect(content.getExposes().transitionState.get()).toBe('closed');
  } finally {
    off();
  }
});

it('committed close then immediate controlled reopen retains only the new selected entry', async () => {
  // T-BASE-SELECT-CONTENT-0001-CASE-CONTROLLED-PRESENCE
  vi.useFakeTimers();
  const { root, content, items } = createSelect({
    root: { open: true, value: 'beta' },
    content: { interrupt: 'wait', enterDuration: 0, leaveDuration: 0 },
  });
  await settle();
  items[1].focus();
  setElementProps(root, { open: false, value: 'gamma' });
  await flush();
  expect(root.getExposes().open.get()).toBe(false);
  setElementProps(root, { open: true, value: 'gamma' });
  await flush();
  await vi.advanceTimersByTimeAsync(1);
  await flush();
  expect(root.getExposes().open.get()).toBe(true);
  expect(content.getExposes().transitionState.get()).toBe('entered');
  expect(root.getExposes().value.get()).toBe('gamma');
  expect(document.activeElement).toBe(items[2]);
});
