import { afterEach, describe, expect, it, vi } from 'vitest';
import type { WebComponentAdapterElement } from '@proto.ui/adapter-web-component';
import { AdaptToWebComponent, setElementProps } from '@proto.ui/adapter-web-component';
import { styleContains } from '../../test-utils/style';
import { installRenderingOpportunities } from '../../test-utils/rendering-opportunities';
import { selectContent, selectItem, selectRoot, selectTrigger, selectValue } from '../src/select';

AdaptToWebComponent(selectRoot as any);
AdaptToWebComponent(selectTrigger as any);
AdaptToWebComponent(selectValue as any);
AdaptToWebComponent(selectContent as any);
AdaptToWebComponent(selectItem as any);

async function flush(): Promise<void> {
  await Promise.resolve();
  await Promise.resolve();
  await Promise.resolve();
}

async function settle(): Promise<void> {
  await vi.advanceTimersByTimeAsync(0);
  await flush();
}

function createSelect(options?: {
  root?: Record<string, unknown>;
  trigger?: Record<string, unknown>;
  content?: Record<string, unknown>;
  contentElement?: WebComponentAdapterElement<typeof selectContent>;
}) {
  const root = document.createElement('shadcn-select-root') as any;
  const trigger = document.createElement('shadcn-select-trigger') as any;
  const value = document.createElement('shadcn-select-value') as any;
  const content =
    options?.contentElement ?? (document.createElement('shadcn-select-content') as any);
  const alpha = document.createElement('shadcn-select-item') as any;
  const beta = document.createElement('shadcn-select-item') as any;
  setElementProps(root, options?.root ?? {});
  setElementProps(trigger, options?.trigger ?? {});
  setElementProps(value, { placeholder: 'Select a framework' });
  setElementProps(content, options?.content ?? {});
  setElementProps(alpha, { value: 'alpha', textValue: 'Alpha' });
  setElementProps(beta, { value: 'beta', textValue: 'Beta' });
  alpha.textContent = 'Alpha';
  beta.textContent = 'Beta';
  trigger.appendChild(value);
  content.append(alpha, beta);
  root.append(trigger, content);
  document.body.appendChild(root);
  return { root, trigger, value, content, alpha, beta };
}

afterEach(async () => {
  document.body.replaceChildren();
  await flush();
  vi.useRealTimers();
});

describe('prototypes/shadcn: select', () => {
  it('keeps every Select anatomy part as a named direct entry', () => {
    expect(selectRoot.name).toBe('shadcn-select-root');
    expect(selectTrigger.name).toBe('shadcn-select-trigger');
    expect(selectValue.name).toBe('shadcn-select-value');
    expect(selectContent.name).toBe('shadcn-select-content');
    expect(selectItem.name).toBe('shadcn-select-item');
  });

  it('composes the official five-part API with shadcn Trigger, Content, and Item styling', async () => {
    vi.useFakeTimers();
    const { trigger, value, content, alpha } = createSelect();
    await settle();

    expect(trigger.getAttribute('role')).toBe('combobox');
    expect(trigger.querySelector('svg')?.querySelector('path')?.getAttribute('d')).toBe(
      'm6 9 6 6 6-6'
    );
    expect(styleContains(trigger, 'rounded-md')).toBe(true);
    expect(styleContains(trigger, 'border-input')).toBe(true);
    expect(styleContains(trigger, 'h-9')).toBe(true);
    expect(styleContains(trigger, 'justify-between')).toBe(true);
    expect(styleContains(trigger, 'w-fit')).toBe(true);
    expect(styleContains(trigger, 'transition-[color,box-shadow]')).toBe(true);
    expect(styleContains(value, 'line-clamp-1')).toBe(true);
    expect(styleContains(value, 'flex')).toBe(true);
    expect(styleContains(value, 'items-center')).toBe(true);
    expect(styleContains(value, 'gap-2')).toBe(true);
    expect(styleContains(trigger.querySelector('span')!, 'text-muted-foreground')).toBe(true);
    expect(trigger.hasAttribute('data-placeholder')).toBe(true);
    expect(value.textContent).toBe('Select a framework');
    expect(content.hasAttribute('data-pui-view-detached')).toBe(true);
    trigger.click();
    await settle();
    expect(styleContains(content, 'bg-popover')).toBe(true);
    expect(styleContains(content, 'rounded-md')).toBe(true);
    expect(styleContains(content, 'w-[var(--proto-ui-anchor-width)]')).toBe(true);
    expect(styleContains(content, 'min-w-[var(--proto-ui-anchor-width)]')).toBe(true);
    expect(styleContains(alpha, 'rounded-sm')).toBe(true);
    expect(styleContains(alpha, 'justify-between')).toBe(false);
    expect(styleContains(alpha, 'pl-2')).toBe(true);
    expect(styleContains(alpha, 'pr-8')).toBe(true);
    expect(alpha.querySelector('svg')).toBeNull();
    expect(alpha.lastElementChild?.tagName).toBe('SPAN');
  });

  it('projects one-pixel press feedback from inherited state through the Adapter', async () => {
    vi.useFakeTimers();
    const { trigger } = createSelect();
    await settle();

    expect(trigger.getExposes().pressed.get()).toBe(false);
    // Appearance plus inherited state is runtime-projected, not a state-only class.
    expect(styleContains(trigger, 'data-[pressed]:translate-y-px')).toBe(false);
    expect(styleContains(trigger, 'translate-y-px')).toBe(false);

    trigger.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true }));
    await flush();
    expect(trigger.getExposes().pressed.get()).toBe(true);
    expect(trigger.hasAttribute('data-pressed')).toBe(true);
    expect(styleContains(trigger, 'bg-input/70')).toBe(false);
    expect(styleContains(trigger, 'translate-y-px')).toBe(false);

    trigger.dispatchEvent(new PointerEvent('pointerup', { bubbles: true }));
    await flush();
    expect(trigger.getExposes().pressed.get()).toBe(false);
    expect(trigger.hasAttribute('data-pressed')).toBe(false);
    expect(styleContains(trigger, 'translate-y-px')).toBe(false);
  });

  it('inherits keyboard selection behavior and selected indicator facts from Base', async () => {
    vi.useFakeTimers();
    const { root, trigger, value, content, alpha, beta } = createSelect({
      root: { defaultValue: 'alpha' },
      content: { position: 'popper' },
    });
    await settle();
    expect(alpha.hasAttribute('data-selected')).toBe(true);
    expect(alpha.querySelector('svg')).not.toBeNull();
    expect(alpha.lastElementChild?.querySelector('svg')).not.toBeNull();
    expect(alpha.querySelector('svg')?.querySelector('path')?.getAttribute('d')).toBe(
      'm20 6-11 11-5-5'
    );
    expect(beta.querySelector('svg')).toBeNull();

    trigger.focus();
    trigger.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true }));
    await settle();
    expect(styleContains(content, 'w-[var(--proto-ui-anchor-width)]')).toBe(true);
    expect(document.activeElement).toBe(alpha);
    window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown' }));
    await flush();
    expect(document.activeElement).toBe(beta);
    beta.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
    await settle();
    expect(root.getExposes().value.get()).toBe('beta');
    expect(value.textContent).toBe('Beta');
    expect(beta.hasAttribute('data-selected')).toBe(true);
    expect(beta.querySelector('svg')).not.toBeNull();
    expect(root.getExposes().open.get()).toBe(false);
  });

  it('accepts official size and position props and retires its closed portal after conceal', async () => {
    vi.useFakeTimers();
    const frame = installRenderingOpportunities();
    const lifecycle: Array<{ type: string; epoch?: number }> = [];
    // Keep the authored prototype intact; this fixture owns its diagnostic sink.
    const TracedContent = AdaptToWebComponent(selectContent, {
      registerAs: 'shadcn-select-conceal-content',
      diagnostics: {
        onLifecycleEvent(event) {
          if (
            event.type === 'mount.mounted' ||
            event.type === 'unmount.begin' ||
            event.type === 'unmount.done' ||
            event.type === 'instance.dispose.done'
          )
            lifecycle.push(event);
        },
      },
    });
    try {
      const { root, trigger, content, alpha } = createSelect({
        contentElement: new TracedContent(),
        trigger: { size: 'sm' },
        content: { position: 'item-aligned' },
      });
      await settle();
      expect(styleContains(trigger, 'h-8')).toBe(true);

      trigger.click();
      await settle();
      expect(root.getExposes().open.get()).toBe(true);
      expect(content.parentElement).toBe(document.body);
      expect(lifecycle).toEqual([{ type: 'mount.mounted', epoch: expect.any(Number) }]);
      const mounted = lifecycle.slice();
      const epoch = mounted[0]?.epoch;
      expect(styleContains(content, 'w-[var(--proto-ui-anchor-width)]')).toBe(true);
      expect(content.getExposes().transitionState.get()).toBe('entering');
      expect(styleContains(content, 'animate-in')).toBe(true);
      content.getExposes().controls.complete();
      await flush();

      alpha.click();
      await settle();
      expect(content.getExposes().transitionState.get()).toBe('closed');
      expect(styleContains(content, 'animate-out')).toBe(true);
      // The marker follows semantic closure immediately; the physical portal
      // retires only after the existing two rendering opportunities.
      expect(content.hasAttribute('data-pui-view-detached')).toBe(true);
      expect(content.parentElement).toBe(document.body);
      expect(lifecycle).toEqual(mounted);
      expect(await frame()).toBeGreaterThan(0);
      expect(content.hasAttribute('data-pui-view-detached')).toBe(true);
      expect(content.parentElement).toBe(document.body);
      expect(lifecycle).toEqual(mounted);
      expect(await frame()).toBeGreaterThan(0);
      expect(content.hasAttribute('data-pui-view-detached')).toBe(true);
      expect(content.parentElement).toBe(root);
      expect(lifecycle).toEqual([
        ...mounted,
        { type: 'unmount.begin', epoch },
        { type: 'unmount.done', epoch },
      ]);
      expect(styleContains(content, 'animate-out')).toBe(false);
      await vi.advanceTimersByTimeAsync(100);
      await flush();
      expect(content.hasAttribute('data-pui-view-detached')).toBe(true);
    } finally {
      frame.restore();
    }
  });
});

it('withdraws placeholder foreground only during ghost hover or press', async () => {
  // T-SHADCN-SELECT-TRIGGER-0001-CASE-GHOST
  vi.useFakeTimers();
  const { trigger, value } = createSelect({ trigger: { appearance: 'ghost' } });
  await settle();
  const hasMutedForeground = () =>
    styleContains(trigger, 'text-muted-foreground') ||
    (trigger.hasAttribute('data-placeholder') &&
      styleContains(trigger, 'data-[placeholder]:text-muted-foreground'));
  expect(trigger.hasAttribute('data-placeholder')).toBe(true);
  expect(value.textContent).toBe('Select a framework');
  expect(hasMutedForeground()).toBe(true);

  trigger.dispatchEvent(new PointerEvent('pointerenter', { bubbles: true }));
  await flush();
  expect(trigger.getExposes().hovered.get()).toBe(true);
  expect(styleContains(trigger, 'text-accent-foreground')).toBe(true);
  expect(hasMutedForeground()).toBe(false);

  trigger.dispatchEvent(new PointerEvent('pointerleave', { bubbles: true }));
  // Touch can press without entering the pointer-hover state.
  trigger.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, pointerType: 'touch' }));
  await flush();
  expect(trigger.getExposes().hovered.get()).toBe(false);
  expect(trigger.getExposes().pressed.get()).toBe(true);
  expect(styleContains(trigger, 'text-accent-foreground')).toBe(true);
  expect(hasMutedForeground()).toBe(false);

  trigger.setProps({});
  await flush();
  expect(trigger.getExposes().pressed.get()).toBe(true);
  expect(hasMutedForeground()).toBe(true);
  expect(styleContains(trigger, 'text-accent-foreground')).toBe(false);
  trigger.setProps({ appearance: 'ghost' });
  await flush();
  expect(hasMutedForeground()).toBe(false);
  expect(styleContains(trigger, 'text-accent-foreground')).toBe(true);

  trigger.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerType: 'touch' }));
  await flush();
  expect(trigger.getExposes().pressed.get()).toBe(false);
  expect(hasMutedForeground()).toBe(true);
  expect(styleContains(trigger, 'text-accent-foreground')).toBe(false);
});

it('supports ghost presentation and restores default while inherited states stay live', async () => {
  // T-SHADCN-SELECT-TRIGGER-0001-CASE-GHOST
  vi.useFakeTimers();
  const { trigger, content, root } = createSelect();
  await settle();
  trigger.setProps({ appearance: 'ghost' });
  await flush();
  expect(styleContains(trigger, 'border-transparent')).toBe(true);
  expect(styleContains(trigger, 'border-input')).toBe(false);
  expect(styleContains(trigger, 'shadow-xs')).toBe(false);
  trigger.dispatchEvent(new PointerEvent('pointerenter', { bubbles: true }));
  trigger.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true }));
  await flush();
  expect(trigger.getExposes().pressed.get()).toBe(true);
  expect(styleContains(trigger, 'bg-accent')).toBe(true);
  expect(styleContains(trigger, 'translate-y-px')).toBe(false);
  trigger.setProps({});
  await flush();
  expect(trigger.getExposes().pressed.get()).toBe(true);
  expect(styleContains(trigger, 'border-input')).toBe(true);
  expect(styleContains(trigger, 'bg-input/70')).toBe(false);
  expect(styleContains(trigger, 'translate-y-px')).toBe(false);
  trigger.setProps({ appearance: 'ghost' });
  await flush();
  expect(styleContains(trigger, 'translate-y-px')).toBe(false);
  trigger.dispatchEvent(new PointerEvent('pointerup', { bubbles: true }));
  trigger.click();
  await settle();
  expect(root.getExposes().open.get()).toBe(true);
  expect(styleContains(content, 'bg-popover')).toBe(true);
  trigger.blur();
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', bubbles: true }));
  trigger.getExposes().focusSelf();
  await settle();
  expect(trigger.getExposes().focusVisible.get()).toBe(true);
  expect(styleContains(trigger, 'ring-3')).toBe(true);
  expect(styleContains(trigger, 'border-ring')).toBe(true);
  expect(styleContains(trigger, 'shadow-none')).toBe(true);
  trigger.setProps({ appearance: 'ghost', disabled: true });
  await settle();
  expect(trigger.getAttribute('aria-disabled')).toBe('true');
  expect(styleContains(trigger, 'cursor-not-allowed')).toBe(true);
});
