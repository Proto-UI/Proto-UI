from pathlib import Path
import subprocess,os,time,json,hashlib,datetime
b=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono');e=b/'evidence/continuation-s345-main-merge-4deb';d=e/'candidate-01';m=json.loads((d/'transfer-manifest.json').read_text())
for x in m['files']:assert hashlib.sha256((d/x['path']).read_bytes()).hexdigest()==x['sha256'],x['path']
env=dict(os.environ,PATH='/home/ezra/.cargo/bin:'+str(b/'tools/node-v24.22.3-linux-x64/bin')+':'+os.environ['PATH'],RUSTUP_TOOLCHAIN='1.98.1',CARGO_TARGET_DIR=str(b/'cargo-target-s5-control-label-2015'),CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_RETRY='1',CARGO_HTTP_TIMEOUT='30')
report={'schemaVersion':1,'candidatePatchSha256':m['candidatePatchSha256'],'candidateParent':m['candidateParent'],'mainParent':m['mainParent'],'compilerSourceFiles':m['compilerSourceFiles'],'generatedRustEdited':False,'platform':'Linux','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]};(e/'native-01.json').write_text(json.dumps(report,indent=2))
num=str(d/'numeric-action/Cargo.toml');ordinary=str(d/'generated/transition/Cargo.toml')
commands=[('rustc',['rustc','+1.98.1','--version','--verbose']),('numeric-metadata',['cargo','+1.98.1','metadata','--format-version','1','--manifest-path',num]),('native-sdk-controls',['cargo','+1.98.1','test','--locked','--manifest-path',num,'-p','proto-ui-gpui-native','--features','test-support,gpui/test-support','--lib','--','--test-threads=1','--nocapture']),('numeric-consumer',['cargo','+1.98.1','test','--locked','--manifest-path',num,'--test','a11y_value','--','--test-threads=1','--nocapture'])]
for name in ['control_label','style_mapping','a11y_activation','scroll_pause','scroll_reader']:commands.append((name,['cargo','+1.98.1','test','--locked','--manifest-path',ordinary,'--features','test-support','--test',name,'--','--test-threads=1','--nocapture']))
for name,cmd in commands:
 print('RUN',name,flush=True);start=time.monotonic();log=e/(name+'-01.log')
 with log.open('w') as out:p=subprocess.run(cmd,cwd=d,env=env,stdout=out,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-start,'logSha256':hashlib.sha256(log.read_bytes()).hexdigest()};report['commands'].append(row);(e/'native-01.json').write_text(json.dumps(report,indent=2));print(json.dumps(row),flush=True)
 if p.returncode:break
report['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();report['passed']=len(report['commands'])==len(commands) and all(x['exitCode']==0 for x in report['commands']);(e/'native-01.json').write_text(json.dumps(report,indent=2));raise SystemExit(0 if report['passed'] else 1)
