#!/usr/bin/env bash
set -uo pipefail
cd /home/ezra/proto-ui-browser-tail-cb5d
for attempt in {1..40}; do if ! curl -fsS http://127.0.0.1:4351/ >/dev/null 2>&1; then break; fi; sleep 0.25; done
pnpm --filter apps-www exec astro dev --host 127.0.0.1 --port 4351 --strictPort
