import {createRequire} from 'node:module';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const req=createRequire('/home/ezra/proto-ui-browser-tail-cb5d/apps/www/package.json');
const {chromium}=req('playwright-core');
const scope='[data-shadow-s3]', profiles=['light','split','mixed'];
const out={kind:'read-only AX transport equivalence and timing diagnostic, not 150s acceptance',pageErrors:[],phases:[]};
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,chromiumSandbox:true,args:['--disable-dev-shm-usage']});
function project(node){return node?{backendDOMNodeId:node.backendDOMNodeId,ignored:node.ignored,role:node.role?.value,name:node.name?.value,labelledby:node.properties?.find(p=>p.name==='labelledby')?.value.relatedNodes?.map(r=>({idref:r.idref,backendDOMNodeId:r.backendDOMNodeId,text:r.text}))}:null}
try {
 const context=await browser.newContext({colorScheme:'light',viewport:{width:1440,height:1000}});
 const page=await context.newPage();page.setDefaultTimeout(30000);page.on('pageerror',e=>out.pageErrors.push(e.message));
 await page.goto('http://127.0.0.1:4351/zh-cn/internal/demo-matrix/#shadow-split-s3');
 await page.waitForSelector(scope+'[data-ready=true]');await page.waitForTimeout(240);
 const cdp=await context.newCDPSession(page);
 const selectors=profiles.flatMap(profile=>['a','b','c','d'].map(value=>({profile,value,selector:scope+' [data-s3-profile="'+profile+'"] [data-s3-component="content-'+value+'"]'})));
 for (const phase of ['initial-a','native-b']) {
  if(phase==='native-b'){for(const profile of profiles)await page.locator(scope+' [data-s3-profile="'+profile+'"] [data-s3-component="trigger-b"]').click();await page.waitForTimeout(240)}
  const start=performance.now();const ax=await cdp.send('Accessibility.getFullAXTree');const fullMs=performance.now()-start;
  const {root}=await cdp.send('DOM.getDocument');const full=[];
  const beforeLookup=performance.now();
  for(const item of selectors){const {nodeId}=await cdp.send('DOM.querySelector',{nodeId:root.nodeId,selector:item.selector});const {node}=await cdp.send('DOM.describeNode',{nodeId});full.push({profile:item.profile,value:item.value,node:project(ax.nodes.find(n=>n.backendDOMNodeId===node.backendNodeId&&!n.ignored))})}
  const fullLookupMs=performance.now()-beforeLookup;const scopedStart=performance.now();
  const partial=await Promise.all(selectors.map(async item=>{const {nodeId}=await cdp.send('DOM.querySelector',{nodeId:root.nodeId,selector:item.selector});const {node}=await cdp.send('DOM.describeNode',{nodeId});const result=await cdp.send('Accessibility.getPartialAXTree',{backendNodeId:node.backendNodeId,fetchRelatives:false});return {profile:item.profile,value:item.value,node:project(result.nodes.find(n=>n.backendDOMNodeId===node.backendNodeId&&!n.ignored))}}));
  const partialMs=performance.now()-scopedStart;assert.deepEqual(partial,full);assert.equal(full.filter(x=>x.node).length,3);
  const row={phase,fullTreeNodes:ax.nodes.length,fullTreeBytes:JSON.stringify(ax).length,fullMs,fullLookupMs,partialMs,subjects:full};out.phases.push(row);console.log(JSON.stringify({phase,fullTreeNodes:ax.nodes.length,fullMs,fullLookupMs,partialMs}));
 }
 await cdp.detach();await context.close();assert.deepEqual(out.pageErrors,[]);out.equivalent=true;
} catch(e){out.failure=e.stack;process.exitCode=1}finally{await browser.close();await fs.writeFile('/home/ezra/proto-ui-browser-tail-cb5d-control/shadow-s3-ax-equivalence.json',JSON.stringify(out,null,2))}
