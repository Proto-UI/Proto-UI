#!/usr/bin/env bash
set -uo pipefail
export PATH=/home/ezra/proto-ui-release-gate-cb5d-control/tools/node_modules/node/bin:/home/ezra/proto-ui-release-gate-cb5d-control/tools/node_modules/.bin:$PATH
export PROTO_UI_BROWSER_BASE_URL=http://127.0.0.1:4351
cd /home/ezra/proto-ui-browser-tail-cb5d
for attempt in {1..100}; do if curl -fsS http://127.0.0.1:4351/en/ >/dev/null 2>&1; then break; fi; sleep 0.25; done
node /home/ezra/proto-ui-browser-tail-cb5d-control/shadow-s3-light-identity.mjs > /home/ezra/proto-ui-browser-tail-cb5d-control/shadow-s3-light-identity.log 2>&1
result=$?
if [[ "$result" != 0 ]]; then printf '%s\n' "$result" > /home/ezra/proto-ui-browser-tail-cb5d-control/shadow-s3-light-identity.exit; exit "$result"; fi
pnpm exec vitest run apps/www/src/content/docs/zh-cn/demo-shadow-split-s3.browser.test.ts --maxWorkers=1 --minWorkers=1 --reporter=json --outputFile=/home/ezra/proto-ui-browser-tail-cb5d-control/shadow-s3-testenv-candidate.json > /home/ezra/proto-ui-browser-tail-cb5d-control/shadow-s3-testenv-candidate.log 2>&1
result=$?
printf '%s\n' "$result" > /home/ezra/proto-ui-browser-tail-cb5d-control/shadow-s3-testenv-candidate.exit
exit "$result"
