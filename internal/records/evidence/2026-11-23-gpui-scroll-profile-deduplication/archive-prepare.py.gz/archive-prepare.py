from pathlib import Path
import os,json,hashlib,gzip,subprocess,datetime,traceback
root=Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
ops=root.with_name(root.name+'-ops'); raw=ops/'scroll-profile-dedup'
stem='2026-11-23-gpui-scroll-profile-deduplication'
record=root/'internal/records'/f'{stem}.md'; evidence=root/'internal/records/evidence'/stem
browserStem='2026-11-23-sprint5-browser-retirement-diagnostic'
browserRecord=root/'internal/records'/f'{browserStem}.md'
browserEvidence=root/'internal/records/evidence'/browserStem
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','PATH':'/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+os.environ['PATH'],'TMPDIR':'/tank/shared/projects/proto-ui-agent/s5at75d5'}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(data):return hashlib.sha256(data).hexdigest()
state={'state':'preparing','startedAt':now(),'commands':[]}
def save():(ops/'dedup-diagnostic-prepare-status.json').write_text(json.dumps(state,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=root,env=env)
def run(name,cmd,timeout=120):
 item={'name':name,'command':cmd,'startedAt':now()};state['commands'].append(item);save()
 with (ops/(name+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 item.update({'exitCode':r.returncode,'finishedAt':now()});save()
 if r.returncode:raise RuntimeError(name+' exited '+str(r.returncode))
try:
 parent=git('rev-parse','HEAD').decode().strip();assert parent=='691f31462159af32882b65e0f3630c5ce04475d7'
 source='packages/compiler/src/targets.ts'
 assert git('diff','--cached','--name-only').decode().strip()==''
 assert git('diff','--name-only').decode().splitlines()==[source]
 status=json.loads((raw/'status.json').read_text())
 assert status['state']=='validated' and status['parent']==parent and status['testCounts']=={'numTotalTests':32,'numPassedTests':32,'numFailedTests':0,'numPendingTests':0}
 assert status['before']==status['after'] and status['matchesIntegratedMainTargets']
 for path,digest in status['after'].items():assert sha((root/path).read_bytes())==digest,path
 original=git('show',parent+':'+source);candidate=(root/source).read_bytes()
 assert original==(raw/'original-targets.ts').read_bytes()
 assert candidate==(raw/'candidate-targets.ts').read_bytes()
 assert sha(original)=='c66a50f16798afd2555baf04d617d30a737ba4f21eddebd18a98236fcc82add2'
 assert sha(candidate)=='2fd07e809c8b740303e8ea7b23a119e6d529cbf79425d2ce526488ac0b475e58'
 originalMain='457d27f7fe554f398970a836ee9c95edb4846f47'
 assert candidate==git('show',originalMain+':'+source)
 assert original.replace(b"        ...nativeOperations,\n        'scroll.sync',\n",b"        ...nativeOperations,\n",1)==candidate
 actualPatch=git('diff','--',source);assert actualPatch==(raw/'candidate.patch').read_bytes()
 assert not record.exists() and not evidence.exists()
 evidence.mkdir(parents=True)
 manifest={'schemaVersion':1,'scope':'Remove an integrated duplicate GPUI operation entry','sourceParent':parent,'integratedMain':originalMain,'sourceFile':source,'originalSha256':sha(original),'candidateSha256':sha(candidate),'candidateByteEqualToIntegratedMain':True,'testCounts':status['testCounts'],'verifiedSourceHashes':status['after'],'files':[]}
 def add(name,data,origin):
  packed=gzip.compress(data,compresslevel=9,mtime=0);assert gzip.decompress(packed)==data
  out=evidence/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(packed)
  manifest['files'].append({'path':str(out.relative_to(evidence)),'origin':origin,'rawBytes':len(data),'rawSha256':sha(data),'gzipBytes':len(packed),'gzipSha256':sha(packed)})
 for p in sorted(raw.iterdir()):
  assert p.is_file(),str(p)
  add('raw/'+p.name,p.read_bytes(),'scroll-profile-dedup/'+p.name)
 for path in status['after']:
  if path==source:continue
  data=(root/path).read_bytes();assert data==git('show',parent+':'+path)
  add('unchanged-source/'+path,data,parent+':'+path)
 add('archive-prepare.py',Path(__file__).read_bytes(),'archive preparation driver')
 (evidence/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 record.write_text("""# GPUI scroll profile duplicate removal

Date: 2026-11-23 UTC.

## Source and scope

The integrated S5 branch listed `scroll.sync` twice in the GPUI profile after both the earlier S5 repair and main's existing admission were retained. This change removes only the first duplicate string. The remaining GPUI entry still admits the implemented operation. The shared `nativeOperations` list and every other target profile are unchanged.

- Parent: `691f31462159af32882b65e0f3630c5ce04475d7`.
- Source: `packages/compiler/src/targets.ts`.
- Parent file SHA-256: `c66a50f16798afd2555baf04d617d30a737ba4f21eddebd18a98236fcc82add2`.
- Candidate file SHA-256: `2fd07e809c8b740303e8ea7b23a119e6d529cbf79425d2ce526488ac0b475e58`.
- The complete candidate file is byte-identical to the same file in integrated main `457d27f7fe554f398970a836ee9c95edb4846f47`.

This is a merge redundancy cleanup; no new failing product behavior is asserted. The earlier profile repair's original failure and validation records remain in history.

## Actual bounded validation

The existing public compiler, GPUI lifecycle, capability, legal-axis and rejection controls passed: **32 tests, 32 passed, zero failed, zero pending**. The three unchanged test files are:

- `packages/compiler/test/scroll-axis-sync.test.ts`
- `packages/compiler/test/gpui-event-notification.test.ts`
- `packages/compiler/test/gpui-capabilities.test.ts`

The run used Node 24.22.3 and pnpm 10.32.1, Vitest with one worker, and both the default and JSON reporters. Exact argv, timestamps, raw output and source hashes are retained in the [evidence manifest](evidence/2026-11-23-gpui-scroll-profile-deduplication/manifest.json). Source hashes matched before and after the test. Prettier and file-scoped `git diff --check` both exited zero.

No test or assertion was changed to obtain this result. This source validation does not claim new Cargo, browser, macOS, physical accessibility, or hosted acceptance.

## Separate browser diagnostic archive

The accompanying [browser retirement diagnostic](2026-11-23-sprint5-browser-retirement-diagnostic.md) preserves its exact observed d995 source and failure receipts. It retains the 250-millisecond cleanup failure and the later zero-fill profile attempt. Its instrumented 17/19 result is not an unobserved canonical pass and does not unblock Ready by itself.
""")
 run('dedup-diagnostic-format',['corepack','pnpm@10.32.1','exec','prettier','--write',str(record),str(evidence/'manifest.json'),str(browserRecord),str(browserEvidence/'manifest.json')])
 run('dedup-diagnostic-format-check',['corepack','pnpm@10.32.1','exec','prettier','--check',source,str(record),str(evidence/'manifest.json'),str(browserRecord),str(browserEvidence/'manifest.json')])
 run('dedup-diagnostic-diff-check',['git','diff','--check'])
 verified={}
 for folder in [evidence,browserEvidence]:
  m=json.loads((folder/'manifest.json').read_text());seen=set()
  for item in m['files']:
   assert item['path'] not in seen;seen.add(item['path'])
   packed=(folder/item['path']).read_bytes();unpacked=gzip.decompress(packed)
   assert len(packed)==item['gzipBytes'] and sha(packed)==item['gzipSha256']
   assert len(unpacked)==item['rawBytes'] and sha(unpacked)==item['rawSha256']
  assert {str(p.relative_to(folder)) for p in folder.rglob('*.gz')}==seen
  verified[str(folder.relative_to(root))]={'files':len(seen),'manifestSha256':sha((folder/'manifest.json').read_bytes())}
 for path,digest in status['after'].items():assert sha((root/path).read_bytes())==digest,path
 assert git('diff','--',source)==actualPatch
 state.update({'state':'validated','parent':parent,'sourceFile':source,'sourceSha256':sha(candidate),'candidateByteEqualToIntegratedMain':True,'testCounts':status['testCounts'],'archives':verified,'records':{str(p.relative_to(root)):sha(p.read_bytes()) for p in [record,browserRecord]},'expectedCommitPaths':[source,str(record.relative_to(root)),str(evidence.relative_to(root)),str(browserRecord.relative_to(root)),str(browserEvidence.relative_to(root))],'finishedAt':now()})
except Exception as e:state.update({'state':'failed','error':str(e),'trace':traceback.format_exc(),'finishedAt':now()})
save()
