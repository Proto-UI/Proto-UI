from pathlib import Path
import os,json,subprocess,hashlib,datetime,traceback
root=Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a');ops=root.with_name(root.name+'-ops')/'scroll-profile-dedup';ops.mkdir(exist_ok=True)
env={**os.environ,'PATH':'/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+os.environ['PATH'],'TMPDIR':'/tank/shared/projects/proto-ui-agent/s5at75d5','GIT_OPTIONAL_LOCKS':'0'}
paths=['packages/compiler/src/targets.ts','packages/compiler/test/scroll-axis-sync.test.ts','packages/compiler/test/gpui-event-notification.test.ts','packages/compiler/test/gpui-capabilities.test.ts']
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def hashes():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
s={'state':'running','startedAt':now(),'parent':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,env=env,text=True).strip(),'before':hashes(),'commands':[]}
def save():(ops/'status.json').write_text(json.dumps(s,indent=2)+'\n')
def run(name,cmd,timeout):
 i={'name':name,'command':cmd,'startedAt':now()};s['commands'].append(i);save()
 with (ops/(name+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 i.update({'exitCode':r.returncode,'finishedAt':now()});save();assert r.returncode==0,(name,r.returncode)
try:
 assert s['parent']=='691f31462159af32882b65e0f3630c5ce04475d7'
 original=subprocess.check_output(['git','show',s['parent']+':'+paths[0]],cwd=root,env=env)
 current=(root/paths[0]).read_bytes();needle=b"        ...nativeOperations,\n        'scroll.sync',\n        'eventControl.requestDefaultActionPrevention',\n        'hook.asControlLabel',"
 assert original.count(needle)==1
 expected=original.replace(needle,needle.replace(b"        'scroll.sync',\n",b'',1),1);assert current==expected
 main=subprocess.check_output(['git','show','457d27f7fe554f398970a836ee9c95edb4846f47:'+paths[0]],cwd=root,env=env)
 s['matchesIntegratedMainTargets']=current==main
 (ops/'original-targets.ts').write_bytes(original);(ops/'candidate-targets.ts').write_bytes(current)
 (ops/'candidate.patch').write_bytes(subprocess.check_output(['git','diff','--no-ext-diff','--',paths[0]],cwd=root,env=env))
 run('format-check',['corepack','pnpm@10.32.1','exec','prettier','--check',paths[0]],120)
 run('diff-check',['git','diff','--check','--',paths[0]],30)
 run('scope-controls',['corepack','pnpm@10.32.1','exec','vitest','run',*paths[1:],'--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile.json='+str(ops/'vitest.json')],300)
 results=json.loads((ops/'vitest.json').read_text());keys=['numTotalTests','numPassedTests','numFailedTests','numPendingTests'];s['testCounts']={k:results[k] for k in keys};assert s['testCounts']==dict(zip(keys,[32,32,0,0])),s['testCounts']
 s['after']=hashes();assert s['after']==s['before'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,env=env,text=True).strip()==s['parent']
 s.update({'state':'validated','finishedAt':now()})
except Exception as e:s.update({'state':'failed','error':str(e),'trace':traceback.format_exc(),'after':hashes(),'finishedAt':now()})
save()
