import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {parsePrototype} from '../proto-ui-sprint1/packages/compiler/src/parser.ts';
import {validateIR} from '../proto-ui-sprint1/packages/compiler/src/ir-validation.ts';
const root='/workspace/scratch/62ffef219b8e/proto-ui-sprint1';
const files=['packages/compiler/src/callable-effects.ts','packages/compiler/src/expression-types.ts','packages/compiler/src/ir-validation.ts'];
const hashes=()=>Object.fromEntries(files.map(p=>[p,createHash('sha256').update(readFileSync(`${root}/${p}`)).digest('hex')]));
const make=(body:string)=>`import {defineAsHook,definePrototype} from '@proto.ui/core';
const asChild=defineAsHook({name:'child',setup(def){def.expose.method('read',()=>7);}});
export default definePrototype({name:'capture-cache-review',setup(def){const child=asChild();${body}return()=> 'done';}});`;
const cases=[
 ['original repeated-bag counterexample',make("let bag=child.methods;def.expose.method('refresh',()=>{bag=child.methods;});def.expose.method('readAlias',()=>bag?.read?.());"),true],
 ['mutable spread accepts a lawful replacement',make("const bag={...child.methods};def.expose.method('replace',()=>{bag.read=()=>9;});def.expose.method('readAlias',()=>{const source=child.methods;return bag.read?.();});"),true],
 ['mutable spread retains its illegal replacement across a facade read',make("const bag={...child.methods};def.expose.method('replace',()=>{bag.read=()=>{def.state.bool('late',false);return 9;};});def.expose.method('readAlias',()=>{const source=child.methods;return bag.read?.();});"),false],
];
const before=hashes();
const results=cases.map(([name,source,expected])=>{const start=performance.now();const parsed=parsePrototype(source as string,{fileName:'capture-cache-review.proto.ts'});const validated=parsed.ok?validateIR(JSON.parse(JSON.stringify(parsed.value))):undefined;return {name,source,expected,ok:parsed.ok,validated:validated?.ok,pass:parsed.ok===expected&&(!parsed.ok||validated?.ok),elapsedMs:performance.now()-start,diagnostics:parsed.ok?(validated&&!validated.ok?validated.diagnostics:[]):parsed.diagnostics};});
const report={before,after:hashes(),results};
writeFileSync('/workspace/scratch/62ffef219b8e/props-policy-work/capture-cache-review.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,results:results.map(({source,...rest})=>rest)},null,2));
if(results.some(r=>!r.pass)||JSON.stringify(report.before)!==JSON.stringify(report.after))process.exitCode=1;
