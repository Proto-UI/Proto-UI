import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { compilePrototype } from '../proto-ui-sprint1/packages/compiler/src/compile.ts';

const root = '/workspace/scratch/62ffef219b8e/proto-ui-sprint1';
const observed = ['packages/compiler/src/callable-effects.ts', 'packages/compiler/src/ir-validation.ts', 'packages/compiler/src/props-update-analysis.ts'];
const digest = () => Object.fromEntries(observed.map(file => [file, createHash('sha256').update(readFileSync(`${root}/${file}`)).digest('hex')]));
const before = digest();
function source(extra: string, consumption: string, projection = 'return {...result};') {
  return `import {defineAsHook,definePrototype,type RunHandle} from '@proto.ui/core';
  const asChild=defineAsHook({name:'child',setup(def){
    def.props.define({label:{type:'string',default:'first'}});
    ${extra}
    return r=>r.el('strong',[r.read.props.get().label]);
  },projectHandle(result){${projection}}});
  export default definePrototype({name:'capture-props-review',setup(def){
    const child=asChild();${consumption}
  }});`;
}
const cases = [
  ['copied render without request', source('', 'return child.render;'), 'missing-authored-update'],
  ['copied render with actual watch', source("def.props.watch(['label'],run=>run.update());", 'return child.render;'), 'authored-update-present'],
  ['literal detached method keeps source', source("def.expose.method('read',()=>7);", "const get=child.getMethod;const read=get?.('read');def.expose.method('invoke',()=>read?.());return child.render;"), 'missing-authored-update'],
  ['external callback stays unknown', source("def.expose.method('invoke',(work:()=>void)=>work());", "const get=child.getMethod;def.expose.value('alias',get?.('invoke'));return child.render;"), 'unknown'],
  ['runtime authority remains refused at public boundary', source("def.expose.method('refresh',(run:RunHandle)=>run.update());", "const get=child.getMethod;const refresh=get?.('refresh');def.event.on('press.commit',run=>refresh?.(run));return child.render;"), 'PUI4003'],
  ['dynamic method invocation not certified', source("def.expose.method('read',()=>7);", "def.expose.method('invoke',(key:string)=>child.getMethod?.(key)?.());return child.render;"), 'not-missing'],
  ['unknown outer call does not gain getter authority', source('', "def.expose.method('invoke',(get:(key:string)=>()=>void)=>get('read')());return child.render;"), 'unknown'],
];
const rows = cases.map(([name, input, expected]) => {
  const result = compilePrototype(input, {fileName:'capture-review.proto.ts',profile:'react-dom-source-v1'});
  const analysis = result.ok ? result.value.analysis?.propsUpdates : undefined;
  const pass = expected === 'not-missing' ? !result.ok || analysis?.status === 'unknown' : expected.startsWith('PUI') ? !result.ok && result.diagnostics.some(row=>row.code===expected) : result.ok && analysis?.status === expected;
  return {name,source:input,expected,pass,ok:result.ok,...(result.ok?{analysis}:{diagnostics:result.diagnostics})};
});
const after=digest();
const report={before,after,sourceUnchanged:JSON.stringify(before)===JSON.stringify(after),passed:rows.filter(row=>row.pass).length,total:rows.length,rows};
writeFileSync('/workspace/scratch/62ffef219b8e/props-policy-work/capture-review.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({sourceUnchanged:report.sourceUnchanged,passed:report.passed,total:report.total,rows:rows.map(({name,pass,ok,analysis,diagnostics})=>({name,pass,ok,status:analysis?.status,unknown:analysis?.unknownReasons,diagnostics}))},null,2));
if(!report.sourceUnchanged||report.passed!==report.total)process.exitCode=1;
