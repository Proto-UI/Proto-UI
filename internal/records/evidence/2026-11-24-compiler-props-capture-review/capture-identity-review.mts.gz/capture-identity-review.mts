import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { parsePrototype } from '../proto-ui-sprint1/packages/compiler/src/parser.ts';
import { validateIR } from '../proto-ui-sprint1/packages/compiler/src/ir-validation.ts';
const variant = process.argv[2] ?? 'refresh';
const source = `import {defineAsHook,definePrototype} from '@proto.ui/core';
const asChild=defineAsHook({name:'child',setup(def){def.expose.method('read',()=>7);}});
export default definePrototype({name:'stable-capture-bag',setup(def){
const child=asChild();let bag=child.methods;
${variant === 'refresh' ? "def.expose.method('refresh',()=>{bag=child.methods;});" : ''}
def.expose.method('readAlias',()=>bag?.read?.());return()=> 'done';}});`;
const file='/workspace/scratch/62ffef219b8e/proto-ui-sprint1/packages/compiler/src/callable-effects.ts';
const hash=()=>createHash('sha256').update(readFileSync(file)).digest('hex');
const before=hash(),started=performance.now();
const result=parsePrototype(source,{fileName:'capture-identity.proto.ts'});
const validated=result.ok?validateIR(JSON.parse(JSON.stringify(result.value))):undefined;
const report={variant,source,before,after:hash(),elapsedMs:performance.now()-started,ok:result.ok,diagnostics:result.ok?[]:result.diagnostics,validated};
writeFileSync(`/workspace/scratch/62ffef219b8e/props-policy-work/capture-identity-${variant}.json`,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,source:undefined,validated:validated?{ok:validated.ok,...(!validated.ok?{diagnostics:validated.diagnostics}:{})}:undefined},null,2));
