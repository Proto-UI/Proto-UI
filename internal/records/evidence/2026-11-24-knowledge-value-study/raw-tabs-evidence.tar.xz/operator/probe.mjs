import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
const {chromium}=createRequire('/tank/shared/projects/proto-ui-agent/s7-browser-20261124-0d7d/s7-tabs-calibration/package.json')('playwright-core');
const evaluatorPath='/tank/shared/projects/proto-ui-agent/s7-browser-20261124-0d7d/operator/evaluator-reviewed.mjs';
const src=await fs.readFile(evaluatorPath,'utf8');
await fs.writeFile('/tank/shared/projects/proto-ui-agent/s7-browser-20261124-0d7d/operator/evaluator-reviewed.mjs',src);
const browser=await chromium.launch({executablePath:'/home/ezra/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome',headless:true});
const page=await browser.newPage();
const start=src.indexOf('const liveCount = ');
const end=src.indexOf('\n    const before = await liveCount();',start);
const liveCount=new Function('page',src.slice(start,end)+'\nreturn liveCount;')(page);
const accepts=(before,after)=>before.some(entry=>entry.numbers.includes(0)) && after.some(entry=>entry.numbers.includes(1)&&!before.some(old=>old.text===entry.text));
const cases=[];
for(const input of [
 {id:'explicit-live-off',initial:'<p role="status" aria-live="off" id="count">Actions: 0</p>',update:['count','Actions: 1'],violation:'The action count is explicitly aria-live=off, not politely announced.'},
 {id:'unrelated-region-changes',initial:'<p role="status" id="count">Actions: 0</p><p role="status" id="noise">Build: 9</p>',update:['noise','Build: 1'],violation:'The action count remains zero; only an unrelated live region changes.'}
]){
 await page.setContent(input.initial);
 const before=await liveCount();
 await page.evaluate(([id,text])=>document.getElementById(id).textContent=text,input.update);
 const after=await liveCount();
 cases.push({...input,before,after,evaluatorAccepts:accepts(before,after)});
}
await page.setContent('<div role="tablist" aria-label="Reference sections"><button role="tab" id="overview" aria-controls="panel" aria-selected="true" tabindex="0"><span aria-hidden="true">★</span>Overview</button></div><section role="tabpanel" id="panel" aria-labelledby="overview">Overview content</section>');
const accessibleNameMatches=await page.getByRole('tab',{name:'Overview',exact:true}).count()===1;
const rawText=await page.getByRole('tab',{name:'Overview',exact:true}).textContent();
cases.push({id:'accessible-decoration',accessibleNameMatches,rawText,evaluatorRawTextMatches:rawText.trim()==='Overview',violation:'A lawful aria-hidden decoration preserves the specified accessible name but fails textContent identity.'});
const result={kind:'independent-evaluator-predicate-counterexamples',scope:'Exact count helper and acceptance predicate, plus actual Chromium accessible-name contrast; not a full task rerun.',evaluator:{path:evaluatorPath,sha256:createHash('sha256').update(src).digest('hex')},browser:browser.version(),node:process.version,cases};
await fs.writeFile('/tank/shared/projects/proto-ui-agent/s7-browser-20261124-0d7d/operator/predicate-counterexamples.json',JSON.stringify(result,null,2)+'\n');
await browser.close();
console.log(JSON.stringify(result,null,2));
