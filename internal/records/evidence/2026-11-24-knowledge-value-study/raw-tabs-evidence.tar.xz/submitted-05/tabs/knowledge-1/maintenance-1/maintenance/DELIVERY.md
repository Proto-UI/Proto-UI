# Maintenance delivery

The two requested changes are complete in `project/src/main.jsx`:

- Each mapped tabpanel now contains an ordinary native `More information` link with `href="#reference-information"`. The link receives normal browser keyboard and pointer behavior.
- The visible live-region text is now `Completed actions: N`. The initial zero, functional increment, polite announcement, atomic status, and continued host behavior after removal are retained.

The tab navigation, manual activation, disabled item, explicit looping, focus logic, relationships, panel visibility, and removal controls were not changed. No dependencies were added. The manifest, lock, initial `DELIVERY.md`, initial `DELIVERY.json`, and initial `events.jsonl` were verified byte-for-byte unchanged using SHA-256 before/after records.

`npm run build` completed with exit 0. The actual production output is in `project/dist/`. Build stdout, stderr, and the exit code are retained in this directory. The existing npm `http-proxy` configuration warning remains in stderr.

Exact clean project snapshots are in `before/project/` and `after/project/`, including their respective production output. `source.diff` contains the exact source change. `snapshot-sha256.json` records every file in both snapshots. The updated project archive is `maintenance/project-delivery.tar.gz`.

No local browser run or independent browser pass is claimed for this build. Production confirmation of the two changes and the preserved interaction behavior remains for the parent operator. The parent's reported pre-maintenance pass applies to the initial build only.

Actual UTC events and the first maintenance command are recorded here. Provider snapshot, seed, token usage, billing, and cost remain null because those values are unavailable. No external source, sibling implementation, evaluator material, or Proto internals were consulted. No commits, pushes, or external posts were made.
