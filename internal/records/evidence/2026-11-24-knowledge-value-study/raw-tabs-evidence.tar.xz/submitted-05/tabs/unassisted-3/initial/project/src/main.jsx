import React, { useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

const sections = [
  { id: 'overview', label: 'Overview', heading: 'A clear starting point', description: 'Explore this reference using the section tabs above.' },
  { id: 'unavailable', label: 'Unavailable', disabled: true, heading: 'Unavailable section', description: 'This section is currently unavailable.' },
  { id: 'details', label: 'Details', heading: 'The details', description: 'Each section has its own associated panel. Choose a tab to reveal its content.' },
  { id: 'history', label: 'History', heading: 'Reference history', description: 'This reference begins with its first recorded version.' },
];

function ReferenceTabs() {
  const [selected, setSelected] = useState('overview');
  const [tabStop, setTabStop] = useState('overview');
  const tabRefs = useRef({});
  const enabledSections = sections.filter(section => !section.disabled);
  // This reference fixture explicitly enables wraparound navigation.
  const loop = true;

  function focusTab(id) {
    setTabStop(id);
    tabRefs.current[id]?.focus();
  }

  function handleKeyDown(event, id) {
    const index = enabledSections.findIndex(section => section.id === id);
    let targetIndex;
    switch (event.key) {
      case 'ArrowRight':
        targetIndex = loop ? (index + 1) % enabledSections.length : Math.min(index + 1, enabledSections.length - 1);
        break;
      case 'ArrowLeft':
        targetIndex = loop ? (index - 1 + enabledSections.length) % enabledSections.length : Math.max(index - 1, 0);
        break;
      case 'Home':
        targetIndex = 0;
        break;
      case 'End':
        targetIndex = enabledSections.length - 1;
        break;
      case 'Enter':
      case ' ':
        event.preventDefault();
        setSelected(id);
        return;
      default:
        return;
    }
    event.preventDefault();
    focusTab(enabledSections[targetIndex].id);
  }

  return (
    <section className="reference-fixture" aria-label="Reference fixture">
      <div className="tabs" role="tablist" aria-label="Reference sections" aria-orientation="horizontal">
        {sections.map(section => (
          <button
            key={section.id}
            ref={node => { tabRefs.current[section.id] = node; }}
            id={`reference-tab-${section.id}`}
            type="button"
            role="tab"
            aria-controls={`reference-panel-${section.id}`}
            aria-selected={selected === section.id}
            aria-disabled={section.disabled || undefined}
            disabled={section.disabled}
            tabIndex={!section.disabled && tabStop === section.id ? 0 : -1}
            onFocus={() => setTabStop(section.id)}
            onKeyDown={event => handleKeyDown(event, section.id)}
            onClick={() => { focusTab(section.id); setSelected(section.id); }}
          >
            {section.label}
          </button>
        ))}
      </div>
      {sections.map(section => (
        <div
          key={section.id}
          id={`reference-panel-${section.id}`}
          role="tabpanel"
          aria-labelledby={`reference-tab-${section.id}`}
          hidden={selected !== section.id}
          tabIndex={0}
          className="panel"
        >
          <span className="section-label">{section.label}</span>
          <h2>{section.heading}</h2>
          <p>{section.description}</p>
        </div>
      ))}
      <p className="keyboard-help">Use ← and → to move between available tabs. Press Enter or Space to open a section.</p>
    </section>
  );
}

function App() {
  const [fixtureVisible, setFixtureVisible] = useState(true);
  const [actionCount, setActionCount] = useState(0);

  return (
    <main>
      <header>
        <p className="eyebrow">INTERACTION REFERENCE</p>
        <h1>Reference sections</h1>
        <p className="intro">Four sections. One place to explore.</p>
      </header>
      {fixtureVisible ? <ReferenceTabs /> : <p className="removed" role="status">Reference fixture removed.</p>}
      <div className="host-actions">
        <button type="button" className="secondary-button" onClick={() => setFixtureVisible(false)}>Remove reference fixture</button>
        <button type="button" className="primary-button" onClick={() => setActionCount(count => count + 1)}>After fixture</button>
      </div>
      <p className="action-count" role="status" aria-live="polite" aria-atomic="true">Action count: {actionCount}</p>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
