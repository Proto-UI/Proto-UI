import { chromium } from '../project/node_modules/playwright-core/index.mjs';
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import assert from 'node:assert/strict';

const dist = resolve('project/dist');
const server = createServer(async (request, response) => {
  try {
    const pathname = new URL(request.url, 'http://localhost').pathname;
    const filename = resolve(dist, '.' + (pathname === '/' ? '/index.html' : pathname));
    if (!filename.startsWith(dist + '/')) throw new Error('Invalid path');
    const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
    response.setHeader('Content-Type', mime[extname(filename)] || 'application/octet-stream');
    response.end(await readFile(filename));
  } catch {
    response.statusCode = 404;
    response.end('Not found');
  }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
let browser;
try {
  browser = await chromium.launch({ headless: true, timeout: 15000 });
  const page = await browser.newPage();
  await page.goto(`http://127.0.0.1:${server.address().port}/`);
  const tab = name => page.getByRole('tab', { name, exact: true });
  const focusedName = () => page.evaluate(() => document.activeElement.textContent.trim());
  const selectedName = () => page.locator('[role="tab"][aria-selected="true"]').textContent();
  const assertInvariant = async () => {
    assert.equal(await page.getByRole('tablist', { name: 'Reference sections' }).count(), 1);
    assert.equal(await page.getByRole('tab').count(), 4);
    assert.equal(await page.locator('[role="tab"][tabindex="0"]').count(), 1);
    assert.equal(await page.locator('[role="tab"][aria-selected="true"]').count(), 1);
    assert.equal(await page.getByRole('tabpanel').count(), 1);
    assert.equal(await page.locator('[role="tabpanel"]').count(), 4);
    assert.equal(await page.evaluate(() => [...document.querySelectorAll('[role="tab"]')].every(tab => {
      const panel = document.getElementById(tab.getAttribute('aria-controls'));
      return panel && panel.getAttribute('aria-labelledby') === tab.id;
    })), true);
  };
  await assertInvariant();
  assert.equal(await selectedName(), 'Overview');
  assert.equal(await tab('Unavailable').isDisabled(), true);
  await tab('Overview').focus();
  await page.keyboard.press('ArrowRight');
  assert.equal(await focusedName(), 'Details');
  assert.equal(await selectedName(), 'Overview');
  await page.keyboard.press('End');
  assert.equal(await focusedName(), 'History');
  await page.keyboard.press('ArrowRight');
  assert.equal(await focusedName(), 'Overview');
  await page.keyboard.press('ArrowLeft');
  assert.equal(await focusedName(), 'History');
  assert.equal(await selectedName(), 'Overview');
  await page.keyboard.press('Enter');
  assert.equal(await selectedName(), 'History');
  await page.keyboard.press('Home');
  assert.equal(await focusedName(), 'Overview');
  assert.equal(await selectedName(), 'History');
  await page.keyboard.press('Space');
  assert.equal(await selectedName(), 'Overview');
  await tab('Details').click();
  await tab('Details').click();
  assert.equal(await selectedName(), 'Details');
  await assertInvariant();
  await page.screenshot({ path: 'logs/fixture.png', fullPage: true });
  await page.getByRole('button', { name: 'Remove reference fixture', exact: true }).click();
  assert.equal(await page.getByRole('tablist').count(), 0);
  await page.keyboard.press('Tab');
  assert.equal(await focusedName(), 'After fixture');
  await page.keyboard.press('Enter');
  assert.equal(await page.getByText('Action count: 1', { exact: true }).count(), 1);
  await page.keyboard.press('Space');
  assert.equal(await page.getByText('Action count: 2', { exact: true }).count(), 1);
  assert.equal(await page.locator('[aria-live="polite"]').textContent(), 'Action count: 2');
  console.log('PASS: production Chromium smoke assertions completed.');
} catch (error) {
  console.error(error.stack || String(error));
  process.exitCode = 1;
} finally {
  if (browser) await browser.close();
  await new Promise(resolve => server.close(resolve));
}
