import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import * as Tabs from '@radix-ui/react-tabs';
import './style.css';

const sections = [
  { value: 'overview', label: 'Overview', text: 'A clear view of the reference and its available sections.' },
  { value: 'unavailable', label: 'Unavailable', disabled: true, text: 'This section is currently unavailable.' },
  { value: 'details', label: 'Details', text: 'Explore the supporting details for this reference.' },
  { value: 'history', label: 'History', text: 'Review the changes and activity associated with this reference.' },
];

function ReferenceFixture() {
  return (
    <Tabs.Root className="reference" defaultValue="overview" orientation="horizontal" dir="ltr" activationMode="manual">
      <Tabs.List className="tabs" aria-label="Reference sections" loop={true}>
        {sections.map((section) => (
          <Tabs.Trigger className="tab" key={section.value} value={section.value} disabled={section.disabled}>
            {section.label}
          </Tabs.Trigger>
        ))}
      </Tabs.List>
      {sections.map((section) => (
        <Tabs.Content className="panel" key={section.value} value={section.value}>
          <span className="eyebrow">Reference section</span>
          <h2>{section.label}</h2>
          <p>{section.text}</p>
          <a href="#reference-information">More information</a>
        </Tabs.Content>
      ))}
    </Tabs.Root>
  );
}

function App() {
  const [fixtureVisible, setFixtureVisible] = useState(true);
  const [actionCount, setActionCount] = useState(0);

  return (
    <main>
      <header>
        <span className="eyebrow">Interaction reference</span>
        <h1>Reference sections</h1>
        <p>Choose a section to explore its content.</p>
      </header>
      {fixtureVisible ? <ReferenceFixture /> : <p className="removed" role="status">Reference fixture removed.</p>}
      <section className="fixture-actions" aria-label="Fixture actions">
        <div className="buttons">
          <button className="button secondary" type="button" onClick={() => setFixtureVisible(false)}>Remove reference fixture</button>
          <button className="button primary" type="button" onClick={() => setActionCount((count) => count + 1)}>After fixture</button>
        </div>
        <p className="count" role="status" aria-live="polite" aria-atomic="true">Completed actions: {actionCount}</p>
      </section>
      <p className="keyboard-hint" id="reference-information">Use Left / Right or Home / End to move between available tabs. Press Enter or Space to open a section.</p>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
