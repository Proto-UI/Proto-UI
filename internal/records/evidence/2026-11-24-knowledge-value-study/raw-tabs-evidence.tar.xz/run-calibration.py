from pathlib import Path
import subprocess,os,datetime,json,hashlib,time,http.server,threading,functools
root=Path('/tank/shared/projects/proto-ui-agent/s7-browser-20261124-0d7d')
repo=Path('/tank/shared/projects/proto-ui-agent/s7-complete-20261124-0d7d')
node='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin/node'
chrome='/home/ezra/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome'
env={**os.environ,'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'CHROME_PATH':chrome}
out=root/'results';out.mkdir(exist_ok=False)
class Handler(http.server.SimpleHTTPRequestHandler):
 def do_GET(self):
  if self.path=='/favicon.ico':self.send_response(204);self.end_headers();return
  super().do_GET()
servers=[]
for name,port in [('s7-tabs-calibration',18734),('s7-button-artifact-01/clean-consumer',18750)]:
 h=functools.partial(Handler,directory=str(root/name/'dist'))
 s=http.server.ThreadingHTTPServer(('127.0.0.1',port),h);servers.append(s);threading.Thread(target=s.serve_forever,daemon=True).start()
records=[]
def run(name,args,cwd):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(name+'.log')).open('w') as f:
  try:
   p=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120);code=p.returncode
  except subprocess.TimeoutExpired:code=124
 r={'name':name,'command':args,'cwd':str(cwd),'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':code}
 records.append(r);(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
try:
 run('independent-predicate-counterexamples',[node,str(root/'operator/probe.mjs')],root)
 for label,extra in [('positive-wide',[]),('positive-narrow-dark',['--viewport','narrow','--color-scheme','dark']),('negative-automatic',['--negative-control','automatic']),('negative-relationship',['--negative-control','relationship']),('negative-removal',['--negative-control','removal'])]:
  run(label,[node,str(root/'operator/evaluate-tabs.mjs'),'--project',str(root/'s7-tabs-calibration'),'--url','http://127.0.0.1:18734/','--out',str(out/label),*extra],root)
 run('button-native-preflight',[node,'--import','tsx','scripts/analysis/invisible-consumption/observe-button.mjs',str(root/'s7-button-artifact-01'),'http://127.0.0.1:18750/'],repo)
finally:
 for server in servers:server.shutdown();server.server_close()
 meta={'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'node':subprocess.check_output([node,'--version'],text=True).strip(),'chrome':subprocess.check_output([chrome,'--version'],text=True).strip(),'chromeSha256':hashlib.sha256(Path(chrome).read_bytes()).hexdigest(),'commands':records}
 (out/'completed.json').write_text(json.dumps(meta,indent=2)+'\n')
