from pathlib import Path
root=Path('/tank/shared/projects/proto-ui-agent/s7-browser-20261124-0d7d')
(root/'s7-button-artifact-01/operator').mkdir(exist_ok=True)
s=(root/'run-calibration.py').read_text().replace("out=root/'results'","out=root/'results-04'").replace('operator/probe.mjs','operator/probe-v2.mjs').replace('operator/evaluate-tabs.mjs','operator/evaluate-tabs-v2.mjs').replace("'CHROME_PATH':chrome","'CHROME_PATH':chrome,'TMPDIR':'/tank/shared/projects/proto-ui-agent/t0d7d'")
exec(compile(s,str(root/'run-calibration.py'),'exec'))
