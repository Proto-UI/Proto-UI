from pathlib import Path
root=Path('/tank/shared/projects/proto-ui-agent/s7-browser-20261124-0d7d')
repo=Path('/tank/shared/projects/proto-ui-agent/s7-complete-20261124-0d7d')
p=repo/'apps/www/node_modules'
if not p.exists():p.symlink_to('/home/ezra/proto-ui-sprint1-postmerge-20261124-56f6684/apps/www/node_modules',target_is_directory=True)
s=(root/'run-calibration.py').read_text().replace("out=root/'results'","out=root/'results-03'").replace('operator/probe.mjs','operator/probe-v2.mjs').replace('operator/evaluate-tabs.mjs','operator/evaluate-tabs-v2.mjs')
exec(compile(s,str(root/'run-calibration.py'),'exec'))
