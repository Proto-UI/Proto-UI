from pathlib import Path
root=Path('/tank/shared/projects/proto-ui-agent/s7-browser-20261124-0d7d')
s=(root/'run-calibration.py').read_text().replace("out=root/'results'","out=root/'results-05'").replace('operator/evaluate-tabs.mjs','operator/evaluate-tabs-v4.mjs').replace("'CHROME_PATH':chrome","'CHROME_PATH':chrome,'TMPDIR':'/tank/shared/projects/proto-ui-agent/t0d7d'")
s='\n'.join(line for line in s.splitlines() if not "run('independent-predicate-counterexamples'" in line and not "run('button-native-preflight'" in line)
s=s.replace("('negative-removal',['--negative-control','removal'])","('negative-removal',['--negative-control','removal']),('legal-structure',['--calibration-control','legal-structure']),('duplicate-panel',['--calibration-control','duplicate-panel']),('live-off',['--calibration-control','live-off']),('unrelated-count',['--calibration-control','unrelated-count'])")
exec(compile(s,str(root/'run-calibration.py'),'exec'))
