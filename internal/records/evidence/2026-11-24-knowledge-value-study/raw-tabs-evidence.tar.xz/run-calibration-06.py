from pathlib import Path
root=Path('/tank/shared/projects/proto-ui-agent/s7-browser-20261124-0d7d')
s=(root/'run-calibration-05.py').read_text().replace('results-05','results-06').replace('evaluate-tabs-v4.mjs','evaluate-tabs-v5.mjs')
exec(compile(s,str(root/'run-calibration-05.py'),'exec'))
