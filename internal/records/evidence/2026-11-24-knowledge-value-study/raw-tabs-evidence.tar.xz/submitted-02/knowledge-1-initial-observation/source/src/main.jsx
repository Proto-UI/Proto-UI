import React, { useId, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

const sections = [
  { value: 'overview', label: 'Overview', title: 'A place to begin', description: 'Explore the reference, review its details, and follow its history.' },
  { value: 'unavailable', label: 'Unavailable', disabled: true, title: 'Section unavailable', description: 'This section is currently unavailable.' },
  { value: 'details', label: 'Details', title: 'The finer details', description: 'This section holds the supporting information for this reference.' },
  { value: 'history', label: 'History', title: 'A record of changes', description: 'This section keeps the reference’s history together in one place.' },
];
const enabledSections = sections.filter((section) => !section.disabled);

function ReferenceFixture() {
  const id = useId();
  const [selected, setSelected] = useState('overview');
  const [tabStop, setTabStop] = useState('overview');
  const buttons = useRef(new Map());

  function moveFocus(event, currentValue) {
    if (event.altKey || event.ctrlKey || event.metaKey) return;
    const currentIndex = enabledSections.findIndex((section) => section.value === currentValue);
    let nextIndex;

    switch (event.key) {
      // Looping is an explicit choice for this fixture.
      case 'ArrowRight':
        nextIndex = (currentIndex + 1) % enabledSections.length;
        break;
      case 'ArrowLeft':
        nextIndex = (currentIndex - 1 + enabledSections.length) % enabledSections.length;
        break;
      case 'Home':
        nextIndex = 0;
        break;
      case 'End':
        nextIndex = enabledSections.length - 1;
        break;
      default:
        return;
    }

    event.preventDefault();
    const nextValue = enabledSections[nextIndex].value;
    setTabStop(nextValue);
    buttons.current.get(nextValue)?.focus();
  }

  return (
    <section className="reference-fixture" aria-label="Reference fixture">
      <div
        className="tabs"
        role="tablist"
        aria-label="Reference sections"
        aria-orientation="horizontal"
        onBlur={(event) => {
          // Re-entering the tab list starts at its selected tab.
          if (!event.currentTarget.contains(event.relatedTarget)) setTabStop(selected);
        }}
      >
        {sections.map((section) => (
          <button
            key={section.value}
            ref={(element) => {
              if (element) buttons.current.set(section.value, element);
              else buttons.current.delete(section.value);
            }}
            type="button"
            role="tab"
            id={`${id}-tab-${section.value}`}
            aria-controls={`${id}-panel-${section.value}`}
            aria-selected={selected === section.value}
            aria-disabled={section.disabled || undefined}
            disabled={section.disabled}
            tabIndex={!section.disabled && tabStop === section.value ? 0 : -1}
            onFocus={() => setTabStop(section.value)}
            onKeyDown={(event) => moveFocus(event, section.value)}
            onClick={() => {
              // Native button clicks cover pointer, Enter, and Space activation.
              setTabStop(section.value);
              setSelected(section.value);
            }}
          >
            {section.label}
          </button>
        ))}
      </div>

      {sections.map((section) => (
        <div
          key={section.value}
          className="panel"
          role="tabpanel"
          id={`${id}-panel-${section.value}`}
          aria-labelledby={`${id}-tab-${section.value}`}
          hidden={selected !== section.value}
          tabIndex={0}
        >
          <span className="section-label">{section.label}</span>
          <h2>{section.title}</h2>
          <p>{section.description}</p>
        </div>
      ))}
      <p className="keyboard-help">Use ← →, Home, or End to move between tabs. Press Enter or Space to open a section.</p>
    </section>
  );
}

function App() {
  const [fixtureVisible, setFixtureVisible] = useState(true);
  const [actionCount, setActionCount] = useState(0);

  return (
    <main>
      <header className="page-header">
        <p className="eyebrow"><span aria-hidden="true" />REFERENCE LIBRARY</p>
        <h1>Reference sections</h1>
        <p className="intro">One reference. A few different perspectives.</p>
      </header>

      <div className="card">
        {fixtureVisible ? <ReferenceFixture /> : (
          <div className="removed-state">
            <h2>Reference fixture removed</h2>
            <p>The action below is still available.</p>
          </div>
        )}
        <footer className="host-controls">
          <div className="button-row">
            <button className="button button-secondary" type="button" onClick={() => setFixtureVisible(false)}>
              Remove reference fixture
            </button>
            <button className="button button-primary" type="button" onClick={() => setActionCount((count) => count + 1)}>
              After fixture
            </button>
          </div>
          <p className="action-count" role="status" aria-live="polite" aria-atomic="true">Action count: {actionCount}</p>
        </footer>
      </div>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
