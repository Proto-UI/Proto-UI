# Reference sections — initial delivery

## Delivered implementation

The complete Vite project is in `project/`. The source is confined to `index.html`, `src/main.jsx`, and `src/style.css`. The supplied package manifest and lock are unchanged. `project/dist/` contains the actual production build.

The four horizontal native button tabs are Overview, Unavailable, Details, and History. Unavailable is disabled. Overview is initially selected. Focus and selection have separate React state. Left/Right explicitly wrap over enabled tabs; Home/End focus the first/last enabled tab. Enter and Space use native button activation, and pointer clicks select. A single tab has a roving tab stop. Each stable tab ID and panel ID refer back to one another; inactive panels remain present but hidden. Repeated activation reuses the same keyed controls and panels.

The removal button is outside the removable reference fixture. It remains focusable after removal, preserving the next Tab stop at After fixture. The independent host action counter starts at zero, uses a functional React state update, and is displayed in a polite, atomic status region.

## Route and knowledge use

This is a custom React implementation. Pinned Radix Tabs 1.1.13 is installed but unused. React 18.3.1 and react-dom 18.3.1 are the runtime dependencies used. Vite 6.4.1 builds the production output. Playwright Core 1.58.2 is used only by the retained verification attempt.

The supplied draft knowledge helped maintain the separation between selected-value ownership, roving focus, derived panel visibility, and host behavior. Explicit looping comes from TASK.txt and this fixture’s implementation. No Proto default or Proto runtime API is claimed or reproduced.

The public [WAI-ARIA Tabs Pattern](https://www.w3.org/WAI/ARIA/apg/patterns/tabs/) was consulted for manual activation, keyboard behavior, and accessible relationships. No linked Proto source was opened. Exact consulted materials are recorded in `evidence/materials.json`.

## Actual commands and results

| Command | Result | Evidence |
| --- | --- | --- |
| `npm ci --ignore-scripts --no-audit --no-fund` | Exit 0; 34 packages installed | `evidence/npm-ci.stdout.log`, `evidence/npm-ci.stderr.log`, `evidence/npm-ci.exit-code.txt` |
| `npm run build` | Exit 0; production bundle generated | `evidence/npm-build.stdout.log`, `evidence/npm-build.stderr.log`, `evidence/npm-build.exit-code.txt` |
| `node evidence/verify.mjs` | Exit 1 before page creation | `evidence/browser.stdout.log`, `evidence/browser.stderr.log`, `evidence/browser.exit-code.txt`, `evidence/browser-results.json` |

The npm commands emitted an existing environment warning about an unknown `http-proxy` configuration key. It did not prevent installation or build. No package pins or dependency routes were changed to address it.

The verification harness started a production Vite preview and reached it over HTTP. `/usr/bin/chromium` then aborted: `process_singleton_posix.cc` reported that `socket()` failed with `Operation not permitted`, followed by SIGABRT. Zero interaction checks ran. No browser screenshots or browser version are claimed. The preview process was terminated after the attempt; its actual termination is in `evidence/preview.exit.json`.

## Precise unresolved verification

All requested behaviors have implementation code, but browser confirmation remains unresolved because Chromium failed to launch in this environment. This includes keyboard navigation and manual activation, pointer behavior, disabled skipping, wrapping, Home/End, the single roving stop and selected tab, one visible panel, reciprocal relationships, repeated activations, and the host counter after fixture removal. The retained harness checks these against production output when run in an environment that permits Chromium to start.

Polite live-region attributes are implemented, but actual screen-reader announcement output was not observed. No claim is made about other hosts, assistive-technology combinations, dynamic selected-trigger removal, Proto lifecycle resources, or behavior outside the task.

## Events and usage facts

`events.jsonl` contains actual UTC event timestamps. `FIRST_COMMAND_UTC.txt` records the actual first command time. `DELIVERY.json` records the actual delivery packaging time, route, dependencies, results, and the available model label. Provider snapshot, seed, token usage, billing, and cost are null because they are not exposed, not zero.

No commits, pushes, or messages to external people were made. All work remained inside this packet. The whole clean project is available in `project-delivery.tar.gz`; `submission.tar.gz` includes the project, supplied task material, report, event record, and retained evidence, excluding installed `node_modules`.
