import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { chromium } from '../project/node_modules/playwright-core/index.mjs';

const evidence = path.dirname(fileURLToPath(import.meta.url));
const packet = path.dirname(evidence);
const events = path.join(packet, 'events.jsonl');
const event = (name, detail = {}) => fs.appendFileSync(events, JSON.stringify({ at: new Date().toISOString(), event: name, ...detail }) + '\n');
const checks = [];
const serverOut = fs.openSync(path.join(evidence, 'preview.stdout.log'), 'w');
const serverErr = fs.openSync(path.join(evidence, 'preview.stderr.log'), 'w');
const port = 45131;
const server = spawn(process.execPath, ['node_modules/vite/bin/vite.js', 'preview', '--host', '127.0.0.1', '--port', String(port), '--strictPort'], { cwd: path.join(packet, 'project'), stdio: ['ignore', serverOut, serverErr] });
event('production_preview_started', { pid: server.pid, port, command: ['node', 'node_modules/vite/bin/vite.js', 'preview', '--host', '127.0.0.1', '--port', String(port), '--strictPort'] });
let browser;
let failed = false;
const pageErrors = [];

try {
  for (let attempt = 0; attempt < 100; attempt++) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}`);
      if (response.ok) break;
    } catch {}
    if (attempt === 99) throw new Error('Production preview did not become available.');
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  event('browser_launch_started', { engine: 'Chromium', executable: '/usr/bin/chromium' });
  browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox'] });
  const version = browser.version();
  event('browser_launched', { version });
  const page = await browser.newPage({ viewport: { width: 1120, height: 850 } });
  page.on('pageerror', (error) => pageErrors.push(error.message));
  await page.goto(`http://127.0.0.1:${port}`, { waitUntil: 'networkidle' });
  const tab = (name) => page.getByRole('tab', { name, exact: true });

  async function verify(label, selected, focused = null) {
    await page.waitForFunction(({ selected, focused }) => {
      const chosen = document.querySelector('[role="tab"][aria-selected="true"]');
      return chosen?.textContent === selected && (!focused || document.activeElement?.textContent === focused);
    }, { selected, focused });
    const state = await page.evaluate(() => {
      const tabs = [...document.querySelectorAll('[role="tab"]')];
      const panels = [...document.querySelectorAll('[role="tabpanel"]')];
      return {
        labels: tabs.map((element) => element.textContent),
        selected: tabs.filter((element) => element.getAttribute('aria-selected') === 'true').map((element) => element.textContent),
        stops: tabs.filter((element) => element.tabIndex === 0).map((element) => element.textContent),
        visiblePanels: panels.filter((element) => !element.hidden).map((element) => element.id),
        panelCount: panels.length,
        uniqueIds: new Set([...tabs, ...panels].map((element) => element.id)).size === tabs.length + panels.length,
        reciprocal: tabs.every((element) => {
          const panel = document.getElementById(element.getAttribute('aria-controls'));
          return panel?.getAttribute('role') === 'tabpanel' && panel.getAttribute('aria-labelledby') === element.id;
        }),
        selectedPanelId: tabs.find((element) => element.getAttribute('aria-selected') === 'true')?.getAttribute('aria-controls'),
        disabled: tabs[1].disabled && tabs[1].getAttribute('aria-disabled') === 'true' && tabs[1].tabIndex === -1,
        focused: document.activeElement?.textContent,
      };
    });
    assert.deepEqual(state.labels, ['Overview', 'Unavailable', 'Details', 'History']);
    assert.deepEqual(state.selected, [selected]);
    assert.equal(state.stops.length, 1);
    if (focused) assert.deepEqual(state.stops, [focused]);
    assert.deepEqual(state.visiblePanels, [state.selectedPanelId]);
    assert.equal(state.panelCount, 4);
    assert.equal(state.uniqueIds, true);
    assert.equal(state.reciprocal, true);
    assert.equal(state.disabled, true);
    checks.push({ label, result: 'pass', selected, focused, state });
  }

  assert.equal(await page.getByRole('tablist', { name: 'Reference sections', exact: true }).getAttribute('aria-orientation'), 'horizontal');
  await verify('Initial semantics and Overview selection', 'Overview');
  assert.equal(await page.getByRole('status').innerText(), 'Action count: 0');
  assert.equal(await page.getByRole('status').getAttribute('aria-live'), 'polite');
  assert.equal(await page.getByRole('status').getAttribute('aria-atomic'), 'true');
  await page.screenshot({ path: path.join(evidence, 'initial-desktop.png'), fullPage: true });

  await tab('Overview').focus();
  await page.keyboard.press('ArrowRight');
  await verify('Right skips disabled without selecting', 'Overview', 'Details');
  await page.keyboard.press('ArrowRight');
  await verify('Right advances to History without selecting', 'Overview', 'History');
  await page.keyboard.press('ArrowRight');
  await verify('Right wraps to Overview', 'Overview', 'Overview');
  await page.keyboard.press('ArrowLeft');
  await verify('Left wraps to History', 'Overview', 'History');
  await page.keyboard.press('ArrowLeft');
  await verify('Left moves to Details', 'Overview', 'Details');
  await page.keyboard.press('ArrowLeft');
  await verify('Left skips disabled', 'Overview', 'Overview');
  await page.keyboard.press('End');
  await verify('End focuses last enabled tab', 'Overview', 'History');
  await page.keyboard.press('Home');
  await verify('Home focuses first enabled tab', 'Overview', 'Overview');
  await page.keyboard.press('End');
  await page.keyboard.press('Enter');
  await verify('Enter selects focused tab', 'History', 'History');
  await page.keyboard.press('ArrowLeft');
  await verify('Focus and selection remain independent', 'History', 'Details');
  await page.keyboard.press('Space');
  await verify('Space selects focused tab', 'Details', 'Details');
  await tab('Overview').click();
  await verify('Pointer selects tab', 'Overview', 'Overview');
  const disabledBounds = await tab('Unavailable').boundingBox();
  await page.mouse.click(disabledBounds.x + disabledBounds.width / 2, disabledBounds.y + disabledBounds.height / 2);
  await verify('Pointer cannot select disabled tab', 'Overview');

  for (let attempt = 0; attempt < 12; attempt++) {
    const name = ['Details', 'History', 'Overview'][attempt % 3];
    await tab(name).click();
    await page.keyboard.press('Enter');
    await page.keyboard.press('Space');
  }
  await verify('Repeated activation keeps four controls and panels', 'Overview', 'Overview');

  await page.getByRole('button', { name: 'After fixture', exact: true }).click();
  assert.equal(await page.getByRole('status').innerText(), 'Action count: 1');
  const remove = page.getByRole('button', { name: 'Remove reference fixture', exact: true });
  await remove.focus();
  await page.keyboard.press('Enter');
  assert.equal(await page.getByRole('tablist').count(), 0);
  assert.equal(await page.getByRole('tabpanel', { includeHidden: true }).count(), 0);
  await page.keyboard.press('Tab');
  assert.equal(await page.evaluate(() => document.activeElement.textContent.trim()), 'After fixture');
  await page.keyboard.press('Enter');
  assert.equal(await page.getByRole('status').innerText(), 'Action count: 2');
  await page.keyboard.press('Space');
  assert.equal(await page.getByRole('status').innerText(), 'Action count: 3');
  await page.getByRole('button', { name: 'After fixture', exact: true }).click();
  assert.equal(await page.getByRole('status').innerText(), 'Action count: 4');
  checks.push({ label: 'Host action count starts at zero, survives removal, and responds to Enter, Space, and pointer', result: 'pass', finalCount: 4, liveRegion: 'polite, atomic' });
  await page.screenshot({ path: path.join(evidence, 'removed-desktop.png'), fullPage: true });
  assert.deepEqual(pageErrors, []);
  fs.writeFileSync(path.join(evidence, 'browser-results.json'), JSON.stringify({ result: 'pass', browser: { engine: 'Chromium', version, executable: '/usr/bin/chromium' }, productionUrl: `http://127.0.0.1:${port}`, checks, pageErrors, limitations: ['No assistive-technology speech output was observed; the live-region attributes and visible count were checked in Chromium.'] }, null, 2) + '\n');
  event('browser_verification_passed', { checks: checks.length, version, pageErrors });
  console.log(`PASS: ${checks.length} production Chromium checks; version ${version}; no page errors.`);
} catch (error) {
  failed = true;
  fs.writeFileSync(path.join(evidence, 'browser-results.json'), JSON.stringify({ result: 'fail', error: error.stack, checks, pageErrors }, null, 2) + '\n');
  event('browser_verification_failed', { error: error.stack, completedChecks: checks.length });
  console.error(error);
} finally {
  if (browser) await browser.close();
  server.kill('SIGTERM');
  await new Promise((resolve) => server.once('exit', (code, signal) => {
    fs.writeFileSync(path.join(evidence, 'preview.exit.json'), JSON.stringify({ exitCode: code, signal }) + '\n');
    event('production_preview_stopped', { exitCode: code, signal });
    resolve();
  }));
  fs.closeSync(serverOut);
  fs.closeSync(serverErr);
  process.exitCode = failed ? 1 : 0;
}
