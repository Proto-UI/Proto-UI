import React, { useId, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

const sections = [
  { id: 'overview', label: 'Overview', heading: 'A clear starting point', text: 'Explore the reference using the tabs above. Each section keeps its own place while you move between tabs.' },
  { id: 'unavailable', label: 'Unavailable', disabled: true, heading: 'Section unavailable', text: 'This section is currently unavailable.' },
  { id: 'details', label: 'Details', heading: 'The details, in focus', text: 'Arrow keys move focus between available tabs. Press Enter or Space to open the focused section.' },
  { id: 'history', label: 'History', heading: 'A record of the reference', text: 'This reference begins with its overview. You can return to it at any time, including by moving right from this last tab.' },
];
const enabledSections = sections.filter((section) => !section.disabled);

function ReferenceTabs() {
  const instanceId = useId();
  const [selectedId, setSelectedId] = useState('overview');
  const [rovingId, setRovingId] = useState('overview');
  const tabRefs = useRef({});
  const tabId = (id) => `${instanceId}-tab-${id}`;
  const panelId = (id) => `${instanceId}-panel-${id}`;

  function focusTab(id) {
    setRovingId(id);
    tabRefs.current[id]?.focus();
  }

  function selectTab(id) {
    setSelectedId(id);
    focusTab(id);
  }

  function onTabKeyDown(event, id) {
    const index = enabledSections.findIndex((section) => section.id === id);
    const count = enabledSections.length;
    let nextIndex;

    switch (event.key) {
      case 'ArrowRight':
        nextIndex = (index + 1) % count;
        break;
      case 'ArrowLeft':
        nextIndex = (index - 1 + count) % count;
        break;
      case 'Home':
        nextIndex = 0;
        break;
      case 'End':
        nextIndex = count - 1;
        break;
      case 'Enter':
      case ' ':
        event.preventDefault();
        selectTab(id);
        return;
      default:
        return;
    }

    event.preventDefault();
    // This fixture explicitly opts into wrapping; selection remains unchanged.
    focusTab(enabledSections[nextIndex].id);
  }

  return (
    <section className="reference-fixture" aria-label="Reference fixture">
      <div className="tablist" role="tablist" aria-label="Reference sections" aria-orientation="horizontal">
        {sections.map((section) => (
          <button
            key={section.id}
            ref={(element) => { tabRefs.current[section.id] = element; }}
            type="button"
            role="tab"
            id={tabId(section.id)}
            aria-controls={panelId(section.id)}
            aria-selected={selectedId === section.id}
            disabled={Boolean(section.disabled)}
            aria-disabled={section.disabled ? true : undefined}
            tabIndex={!section.disabled && rovingId === section.id ? 0 : -1}
            onFocus={() => setRovingId(section.id)}
            onKeyDown={(event) => onTabKeyDown(event, section.id)}
            onClick={() => selectTab(section.id)}
          >
            {section.label}
          </button>
        ))}
      </div>
      {sections.map((section) => (
        <div
          key={section.id}
          className="tabpanel"
          role="tabpanel"
          id={panelId(section.id)}
          aria-labelledby={tabId(section.id)}
          hidden={selectedId !== section.id}
          tabIndex={0}
        >
          <p className="section-label">{section.label}</p>
          <h2>{section.heading}</h2>
          <p>{section.text}</p>
        </div>
      ))}
      <p className="keyboard-help"><span>Keyboard guide</span> ← / → to move · Home / End to jump · Enter / Space to select</p>
    </section>
  );
}

function App() {
  const [showFixture, setShowFixture] = useState(true);
  const [actionCount, setActionCount] = useState(0);
  const afterFixtureRef = useRef(null);

  function removeFixture() {
    setShowFixture(false);
    afterFixtureRef.current?.focus();
  }

  return (
    <main>
      <header>
        <p className="eyebrow">INTERACTION REFERENCE</p>
        <h1>A place for every section.</h1>
        <p className="intro">A simple, keyboard-friendly reference with four horizontal tabs.</p>
      </header>

      {showFixture ? <ReferenceTabs /> : <section className="removed-state"><h2>Reference fixture removed</h2><p>The action below remains available.</p></section>}

      <footer className="fixture-controls">
        <div className="actions">
          <button type="button" className="button secondary" disabled={!showFixture} onClick={removeFixture}>Remove reference fixture</button>
          <button type="button" className="button primary" ref={afterFixtureRef} onClick={() => setActionCount((count) => count + 1)}>After fixture</button>
        </div>
        <p className="action-count" role="status" aria-live="polite" aria-atomic="true">Action count: <strong>{actionCount}</strong></p>
      </footer>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
