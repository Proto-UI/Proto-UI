import { chromium } from '../project/node_modules/playwright-core/index.mjs';
import { createServer } from 'node:http';
import { readFile, writeFile, appendFile } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import assert from 'node:assert/strict';

const packet = resolve(import.meta.dirname, '..');
const event = async (name, data = {}) => appendFile(resolve(packet, 'events.jsonl'), JSON.stringify({ utc: new Date().toISOString(), event: name, ...data }) + '\n');
const checks = [];
const record = (name) => { checks.push(name); console.log(`PASS: ${name}`); };
const server = createServer(async (request, response) => {
  try {
    const path = new URL(request.url, 'http://localhost').pathname;
    const file = resolve(packet, 'project/dist', path === '/' ? 'index.html' : path.slice(1));
    const data = await readFile(file);
    const mime = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css' }[extname(file)] || 'application/octet-stream';
    response.writeHead(200, { 'Content-Type': mime }); response.end(data);
  } catch { response.writeHead(404); response.end(); }
});
let browser;
let result;
await event('browser_check_started', { command: 'node evidence/check-production.mjs', target: 'project/dist', executable: '/usr/bin/chromium' });
try {
  await new Promise((resolveListen) => server.listen(0, '127.0.0.1', resolveListen));
  browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox'] });
  const page = await browser.newPage({ viewport: { width: 1200, height: 820 } });
  const runtimeErrors = [];
  page.on('pageerror', (error) => runtimeErrors.push(error.message));
  await page.goto(`http://127.0.0.1:${server.address().port}`);
  const tablist = page.getByRole('tablist', { name: 'Reference sections' });
  const tabs = tablist.getByRole('tab');
  const tab = (name) => tablist.getByRole('tab', { name, exact: true });
  const selected = async () => page.locator('[role="tab"][aria-selected="true"]').innerText();
  const focused = async () => page.evaluate(() => document.activeElement.textContent);
  const invariant = async () => {
    assert.equal(await tabs.count(), 4);
    assert.equal(await page.locator('[role="tabpanel"]').count(), 4);
    assert.equal(await page.locator('[role="tab"][aria-selected="true"]').count(), 1);
    assert.equal(await page.locator('[role="tab"][tabindex="0"]').count(), 1);
    assert.equal(await page.locator('[role="tabpanel"]:visible').count(), 1);
    assert.equal(await page.locator('[role="tabpanel"]:visible').getAttribute('aria-labelledby'), await page.locator('[role="tab"][aria-selected="true"]').getAttribute('id'));
  };
  assert.deepEqual(await tabs.allTextContents(), ['Overview', 'Unavailable', 'Details', 'History']);
  assert.equal(await tab('Unavailable').isDisabled(), true);
  assert.equal(await tab('Unavailable').getAttribute('tabindex'), '-1');
  assert.equal(await selected(), 'Overview');
  await invariant();
  record('Initial overview, labels, disabled tab, one selection/roving stop/visible panel');

  assert.equal(await page.evaluate(() => Array.from(document.querySelectorAll('[role="tab"]')).every((element) => {
    const panel = document.getElementById(element.getAttribute('aria-controls'));
    return panel?.getAttribute('role') === 'tabpanel' && panel.getAttribute('aria-labelledby') === element.id;
  })), true);
  record('Every tab and panel has a reciprocal accessible relationship');

  await page.keyboard.press('Tab');
  assert.equal(await focused(), 'Overview');
  for (const [key, expected] of [['ArrowRight', 'Details'], ['ArrowRight', 'History'], ['ArrowRight', 'Overview'], ['ArrowLeft', 'History'], ['ArrowLeft', 'Details'], ['ArrowLeft', 'Overview'], ['End', 'History'], ['Home', 'Overview']]) {
    await page.keyboard.press(key); assert.equal(await focused(), expected); assert.equal(await selected(), 'Overview'); await invariant();
  }
  record('Left/Right skip disabled, wrap in both directions, Home/End move focus only');

  await page.keyboard.press('ArrowRight');
  await page.keyboard.press('Enter'); assert.equal(await selected(), 'Details'); await invariant();
  await page.keyboard.press('ArrowRight');
  await page.keyboard.press('Space'); assert.equal(await selected(), 'History'); await invariant();
  await tab('Overview').click(); assert.equal(await selected(), 'Overview'); await invariant();
  record('Enter, Space and pointer activate their focused or clicked tabs');

  for (let i = 0; i < 4; i++) {
    for (const label of ['History', 'Overview', 'Details', 'Details']) { await tab(label).click(); await invariant(); }
  }
  record('Repeated selections preserve exactly four controls and four panels');
  await tab('Overview').click();
  await page.screenshot({ path: resolve(packet, 'evidence/desktop.png') });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.screenshot({ path: resolve(packet, 'evidence/mobile.png') });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  record('390px viewport has no document overflow');

  const after = page.getByRole('button', { name: 'After fixture', exact: true });
  const status = page.getByRole('status');
  assert.equal(await status.getAttribute('aria-live'), 'polite');
  assert.match(await status.innerText(), /Action count: 0/);
  await after.click(); assert.match(await status.innerText(), /Action count: 1/);
  await page.keyboard.press('Space'); assert.match(await status.innerText(), /Action count: 2/);
  record('After fixture increments the visible polite action count by pointer and keyboard');

  const remove = page.getByRole('button', { name: 'Remove reference fixture', exact: true });
  await remove.focus(); await page.keyboard.press('Tab'); assert.equal(await focused(), 'After fixture');
  await remove.click();
  assert.equal(await page.getByRole('tablist').count(), 0);
  assert.equal(await page.locator('[role="tabpanel"]').count(), 0);
  assert.equal(await focused(), 'After fixture');
  await page.keyboard.press('Enter'); assert.match(await status.innerText(), /Action count: 3/);
  assert.equal(await after.isEnabled(), true);
  await page.screenshot({ path: resolve(packet, 'evidence/removed.png') });
  record('Removal clears the fixture, preserves and focuses After fixture, and keyboard activation still works');
  assert.deepEqual(runtimeErrors, []);
  record('No page runtime errors during the complete interaction sequence');
  result = { status: 'passed', browser: 'Chromium', browserVersion: browser.version(), checks, runtimeErrors };
} catch (error) {
  console.error(error.stack || String(error));
  result = { status: 'failed', checks, error: error.stack || String(error) };
  process.exitCode = 1;
} finally {
  await writeFile(resolve(packet, 'evidence/browser-result.json'), JSON.stringify(result, null, 2) + '\n');
  if (browser) await browser.close();
  await new Promise((resolveClose) => server.close(resolveClose));
  await event('browser_check_finished', { status: result.status, exit_code: process.exitCode || 0 });
}
