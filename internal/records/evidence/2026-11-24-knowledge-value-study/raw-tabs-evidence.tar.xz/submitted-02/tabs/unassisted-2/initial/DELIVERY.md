# Reference tabs delivery

Implemented the supplied task in `project/`. `project-delivery.zip` contains the complete clean project, including the supplied package manifest and lock, implementation source, and production build. Installed `node_modules` remain locally available and are excluded from the archive.

## Implementation

The implementation uses React 18.3.1 and react-dom 18.3.1 directly. Vite 6.4.1 builds the project. The pinned Radix Tabs dependency remains installed and unused. No package pins or lock were changed.

The four horizontal tabs have the exact requested labels and tablist name. Overview starts selected; Unavailable is disabled. Arrow keys skip it and explicitly loop across the three enabled tabs. Home and End focus the first and last enabled tab. Navigation changes focus only; Enter, Space, and pointer activation change selection. Stable tab/panel IDs provide reciprocal ARIA relationships, with a single selected tab, roving tab stop, and visible panel. Selection changes update existing keyed elements.

The fixture controls follow the reference. Removing the reference removes all its tab controls and panels, disables the removal button, and focuses the surviving After fixture button. Its action count starts at zero, increments independently, and is visible in a polite, atomic status region.

## Observed validation

- Clean `npm ci --ignore-scripts --no-audit --no-fund`: exit 0.
- Production `npm run build`: exit 0.
- Local production-browser check: exit 1 before page load. Chromium could not create its process singleton socket (`Operation not permitted`) and terminated with SIGABRT. No interaction assertions ran and no screenshots were created.

Actual stdout, stderr and exit records are retained under `evidence/`. The attempted check script is `evidence/check-production.mjs`. Its assertions are planned checks, not passed results. The environment also produced a nonfatal npm `http-proxy` configuration warning, retained verbatim in the logs.

## Unresolved items

No known implementation requirement is intentionally omitted. Browser behavior and visual appearance remain unverified locally because Chromium failed to launch. The operator should independently check the production output.

## Materials and provenance

The participant read only the supplied instructions, task, arm, package manifest and initial source files in this packet. No URLs, external documentation, local declaration files, other participants, Proto internals or evaluator material were consulted. The supplied dependency lock was used by the clean installation without modification. Implementation used ordinary React and WAI-ARIA knowledge.

`events.jsonl` contains actual UTC events, including the observed first command time and delivery finalization. `delivery.json` records the exact dependency route, commands, results, remaining verification and available model facts. Model/provider snapshot, seed, tokens, billing and cost are unavailable and are represented as null with a reason. No commits, pushes, or messages to external people were made.
