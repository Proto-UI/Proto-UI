from pathlib import Path
import subprocess,json,base64,hashlib,tarfile,io,http.server,functools,threading,os,datetime
root=Path('/tank/shared/projects/proto-ui-agent/s7-browser-20261124-0d7d')
stage=root/'submitted-05';stage.mkdir()
refs=['cbcafe88398f1ccea3fdcd936602de4e281c0249','76226927107b03a3069611ad6fa758151d6ce267']
parts=[]
for ref in refs:
 d=json.loads(subprocess.check_output(['gh','api','repos/Proto-UI/Proto-UI/git/blobs/'+ref]))
 raw=base64.b64decode(d['content']);assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==ref;parts.append(raw)
data=b''.join(parts);assert hashlib.sha256(data).hexdigest()=='758336eff9b6354d21dfb285d70d0348b894b720aa85727fa166a40bb8e89976'
(stage/'input.tar.gz').write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:t.extractall(stage,filter='data')
node='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin/node'
chrome='/home/ezra/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome'
evaluator=root/'operator/evaluate-tabs-v5.mjs'
assert hashlib.sha256(evaluator.read_bytes()).hexdigest()=='cc7161a66a30f87eeedaa18e28f759c31583e1e7309da6b01ed400d94f71710b'
env={**os.environ,'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'CHROME_PATH':chrome,'TMPDIR':'/tank/shared/projects/proto-ui-agent/t0d7d'}
records=[]
for name,attempt in [('unassisted-3','initial'),('knowledge-1','maintenance-1'),('library-1','maintenance-1')]:
 project=stage/'tabs'/name/attempt/'project'; nm=project/'node_modules';nm.mkdir();(nm/'playwright-core').symlink_to('/home/ezra/proto-ui-sprint1-postmerge-20261124-56f6684/node_modules/.pnpm/playwright-core@1.58.2/node_modules/playwright-core',target_is_directory=True)
 assets=[]
 class Handler(http.server.SimpleHTTPRequestHandler):
  def do_GET(self):
   if self.path=='/favicon.ico':self.send_response(204);self.end_headers();return
   path=Path(self.translate_path(self.path));effective=path/'index.html' if path.is_dir() else path
   if effective.is_file():assets.append({'url':self.path,'path':str(effective.relative_to(project/'dist')),'sha256':hashlib.sha256(effective.read_bytes()).hexdigest(),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
   super().do_GET()
 handler=functools.partial(Handler,directory=str(project/'dist'))
 server=http.server.ThreadingHTTPServer(('127.0.0.1',19734),handler);threading.Thread(target=server.serve_forever,daemon=True).start()
 out=stage/(name+'-'+attempt+'-observation')
 args=[node,str(evaluator),'--project',str(project),'--url','http://127.0.0.1:19734/','--out',str(out)]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 try:
  with (stage/(name+'-'+attempt+'.log')).open('w') as f:p=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
  code=p.returncode
 except subprocess.TimeoutExpired:code=124
 finally:server.shutdown();server.server_close()
 records.append({'run':name,'attempt':attempt,'command':args,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':code,'servedAssets':assets})
 (stage/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'done':len(records),'exitCodes':[r['exitCode'] for r in records]}),flush=True)
