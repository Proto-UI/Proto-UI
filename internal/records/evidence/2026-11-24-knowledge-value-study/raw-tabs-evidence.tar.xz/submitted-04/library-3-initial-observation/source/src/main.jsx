import React, { useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import * as Tabs from '@radix-ui/react-tabs';
import './style.css';

const sections = [
  { value: 'overview', label: 'Overview', text: 'A quick introduction to the reference sections.' },
  { value: 'unavailable', label: 'Unavailable', text: 'This reference section is unavailable.', disabled: true },
  { value: 'details', label: 'Details', text: 'Additional information about this reference.' },
  { value: 'history', label: 'History', text: 'The reference history appears here.' },
];

function ReferenceTabs() {
  const [selected, setSelected] = useState('overview');
  const [tabStop, setTabStop] = useState('overview');

  return (
    <Tabs.Root
      value={selected}
      onValueChange={setSelected}
      activationMode="manual"
      orientation="horizontal"
      dir="ltr"
      className="reference-tabs"
    >
      <Tabs.List aria-label="Reference sections" loop={true} tabIndex={-1} className="tab-list">
        {sections.map((section) => (
          <Tabs.Trigger
            key={section.value}
            value={section.value}
            disabled={section.disabled}
            tabIndex={tabStop === section.value ? 0 : -1}
            onFocus={() => setTabStop(section.value)}
            className="tab"
          >
            {section.label}
          </Tabs.Trigger>
        ))}
      </Tabs.List>
      {sections.map((section) => (
        <Tabs.Content
          key={section.value}
          value={section.value}
          forceMount
          hidden={selected !== section.value}
          tabIndex={selected === section.value ? 0 : -1}
          className="panel"
        >
          <h2>{section.label}</h2>
          <p>{section.text}</p>
        </Tabs.Content>
      ))}
    </Tabs.Root>
  );
}

function App() {
  const [fixtureVisible, setFixtureVisible] = useState(true);
  const [actionCount, setActionCount] = useState(0);
  const afterButton = useRef(null);

  function removeFixture() {
    setFixtureVisible(false);
    afterButton.current?.focus();
  }

  return (
    <main>
      <header>
        <p className="eyebrow">REFERENCE</p>
        <h1>Explore the reference</h1>
        <p className="intro">Use the arrow keys, Home or End to move between tabs. Press Enter or Space to open a section.</p>
      </header>
      {fixtureVisible && (
        <section aria-label="Reference fixture">
          <ReferenceTabs />
          <button type="button" className="secondary" onClick={removeFixture}>Remove reference fixture</button>
        </section>
      )}
      <div className="host-actions">
        <button type="button" ref={afterButton} onClick={() => setActionCount((count) => count + 1)}>After fixture</button>
        <p role="status" aria-live="polite" aria-atomic="true">Action count: {actionCount}</p>
      </div>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
