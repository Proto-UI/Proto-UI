import React, { useId, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

const sections = [
  { value: 'overview', label: 'Overview', body: 'A place to start. Explore the reference details and its history using the tabs above.' },
  { value: 'unavailable', label: 'Unavailable', disabled: true, body: 'This section is currently unavailable.' },
  { value: 'details', label: 'Details', body: 'The reference brings related information together in a single, focused view.' },
  { value: 'history', label: 'History', body: 'This is the beginning of the reference history. Future changes will appear here.' },
];
const enabledSections = sections.filter((section) => !section.disabled);

function ReferenceTabs({ loop }) {
  const instanceId = useId();
  const [selected, setSelected] = useState('overview');
  const [focusable, setFocusable] = useState('overview');
  const triggers = useRef({});
  const tabId = (value) => `${instanceId}-tab-${value}`;
  const panelId = (value) => `${instanceId}-panel-${value}`;

  function navigate(event, value) {
    const index = enabledSections.findIndex((section) => section.value === value);
    let destination;
    switch (event.key) {
      case 'ArrowLeft': destination = index - 1; break;
      case 'ArrowRight': destination = index + 1; break;
      case 'Home': destination = 0; break;
      case 'End': destination = enabledSections.length - 1; break;
      case 'Enter':
      case ' ':
        event.preventDefault();
        setSelected(value);
        return;
      default: return;
    }
    event.preventDefault();
    const length = enabledSections.length;
    destination = loop
      ? (destination + length) % length
      : Math.max(0, Math.min(destination, length - 1));
    const nextValue = enabledSections[destination].value;
    setFocusable(nextValue);
    triggers.current[nextValue]?.focus();
  }

  return (
    <section className="reference-fixture" aria-label="Reference fixture">
      <div
        className="tablist"
        role="tablist"
        aria-label="Reference sections"
        aria-orientation="horizontal"
        onBlur={(event) => {
          if (!event.currentTarget.contains(event.relatedTarget)) setFocusable(selected);
        }}
      >
        {sections.map((section) => (
          <button
            key={section.value}
            type="button"
            role="tab"
            id={tabId(section.value)}
            aria-controls={panelId(section.value)}
            aria-selected={selected === section.value}
            aria-disabled={section.disabled || undefined}
            disabled={section.disabled}
            tabIndex={!section.disabled && focusable === section.value ? 0 : -1}
            ref={(element) => { triggers.current[section.value] = element; }}
            onFocus={() => setFocusable(section.value)}
            onKeyDown={(event) => navigate(event, section.value)}
            onClick={() => {
              setFocusable(section.value);
              setSelected(section.value);
            }}
          >
            {section.label}
          </button>
        ))}
      </div>
      {sections.map((section) => (
        <div
          key={section.value}
          className="tabpanel"
          role="tabpanel"
          id={panelId(section.value)}
          aria-labelledby={tabId(section.value)}
          hidden={selected !== section.value}
          tabIndex={selected === section.value ? 0 : -1}
        >
          <span className="panel-kicker">REFERENCE</span>
          <h2>{section.label}</h2>
          <p>{section.body}</p>
        </div>
      ))}
      <p className="keyboard-hint">Move with ← and →, or Home and End. Open a section with Enter or Space.</p>
    </section>
  );
}

function App() {
  const [fixtureVisible, setFixtureVisible] = useState(true);
  const [actionCount, setActionCount] = useState(0);
  const afterFixture = useRef(null);

  function removeFixture() {
    setFixtureVisible(false);
    afterFixture.current?.focus();
  }

  return (
    <main>
      <header>
        <p className="eyebrow">REFERENCE WORKSPACE</p>
        <h1>Your reference, organized.</h1>
        <p className="intro">Find the context you need, one section at a time.</p>
      </header>
      {fixtureVisible ? <ReferenceTabs loop={true} /> : (
        <div className="removed-message">The reference fixture has been removed.</div>
      )}
      <div className="host-actions">
        {fixtureVisible && (
          <button className="secondary-button" type="button" onClick={removeFixture}>
            Remove reference fixture
          </button>
        )}
        <button
          className="primary-button"
          type="button"
          ref={afterFixture}
          onClick={() => setActionCount((count) => count + 1)}
        >
          After fixture
        </button>
      </div>
      <p className="action-count" role="status" aria-live="polite" aria-atomic="true">
        Action count: <strong>{actionCount}</strong>
      </p>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
