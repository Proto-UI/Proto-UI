import { createRequire } from 'node:module';
import { spawn } from 'node:child_process';
import { writeFileSync, appendFileSync } from 'node:fs';
import { resolve } from 'node:path';
import assert from 'node:assert/strict';
const root = resolve('.');
const require = createRequire(resolve(root, 'project/package.json'));
const { chromium } = require('playwright-core');
const now = () => new Date().toISOString();
const event = (value) => appendFileSync(resolve(root, 'events.jsonl'), `${JSON.stringify({ at: now(), ...value })}\n`);
const report = { started_at: now(), launch: { executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox'] }, checks: [], status: 'started' };
let browser;
let server;
let serverOutput = '';
try {
  server = spawn('npm', ['run', 'preview', '--', '--port', '4273'], { cwd: resolve(root, 'project'), stdio: ['ignore', 'pipe', 'pipe'] });
  server.stdout.on('data', (data) => { serverOutput += data; });
  server.stderr.on('data', (data) => { serverOutput += data; });
  let ready = false;
  for (let attempt = 0; attempt < 60; attempt++) {
    try { ready = (await fetch('http://127.0.0.1:4273')).ok; if (ready) break; } catch {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  assert.equal(ready, true, 'Production preview started');
  event({ event: 'browser_launch_attempt', executable: '/usr/bin/chromium', url: 'http://127.0.0.1:4273' });
  browser = await chromium.launch(report.launch);
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await page.goto('http://127.0.0.1:4273');
  const tabs = page.getByRole('tab');
  const tab = (name) => page.getByRole('tab', { name, exact: true });
  const state = async () => page.evaluate(() => ({
    focused: document.activeElement?.textContent?.trim(),
    selected: Array.from(document.querySelectorAll('[role="tab"][aria-selected="true"]')).map((el) => el.textContent.trim()),
    stops: Array.from(document.querySelectorAll('[role="tab"]')).filter((el) => el.tabIndex === 0).length,
    visiblePanels: Array.from(document.querySelectorAll('[role="tabpanel"]')).filter((el) => !el.hidden).length,
  }));
  const check = async (name, selected, focused) => {
    const value = await state();
    assert.deepEqual(value.selected, [selected], name);
    assert.equal(value.stops, 1, name);
    assert.equal(value.visiblePanels, 1, name);
    if (focused) assert.equal(value.focused, focused, name);
    report.checks.push({ name, passed: true, state: value });
  };
  assert.equal(await page.getByRole('tablist', { name: 'Reference sections', exact: true }).count(), 1);
  assert.deepEqual(await tabs.allTextContents(), ['Overview', 'Unavailable', 'Details', 'History']);
  assert.equal(await tab('Unavailable').isDisabled(), true);
  await check('initial state', 'Overview');
  await tab('Overview').focus();
  await page.keyboard.press('ArrowRight');
  await check('right skips disabled with manual activation', 'Overview', 'Details');
  await page.keyboard.press('ArrowRight');
  await check('right moves to History', 'Overview', 'History');
  await page.keyboard.press('ArrowRight');
  await check('right wraps', 'Overview', 'Overview');
  await page.keyboard.press('ArrowLeft');
  await check('left wraps', 'Overview', 'History');
  await page.keyboard.press('Home');
  await check('Home focuses first', 'Overview', 'Overview');
  await page.keyboard.press('End');
  await check('End focuses last', 'Overview', 'History');
  await page.keyboard.press('Enter');
  await check('Enter selects', 'History', 'History');
  await page.keyboard.press('ArrowLeft');
  await check('left movement preserves selection', 'History', 'Details');
  await page.keyboard.press('Space');
  await check('Space selects', 'Details', 'Details');
  for (let attempt = 0; attempt < 8; attempt++) await tab('Overview').click();
  await check('repeated pointer selection', 'Overview', 'Overview');
  assert.equal(await tabs.count(), 4);
  assert.equal(await page.locator('[role="tabpanel"]').count(), 4);
  const relationships = await page.evaluate(() => Array.from(document.querySelectorAll('[role="tab"]')).every((el) => {
    const panel = document.getElementById(el.getAttribute('aria-controls'));
    return panel?.getAttribute('aria-labelledby') === el.id;
  }));
  assert.equal(relationships, true);
  report.checks.push({ name: 'unique controls and reciprocal relationships', passed: true });
  await page.getByRole('button', { name: 'After fixture', exact: true }).click();
  assert.match(await page.getByRole('status').textContent(), /Action count:\s*1/);
  await page.getByRole('button', { name: 'Remove reference fixture', exact: true }).focus();
  await page.keyboard.press('Enter');
  assert.equal(await tabs.count(), 0);
  assert.equal(await page.locator('[role="tabpanel"]').count(), 0);
  assert.equal(await page.evaluate(() => document.activeElement.textContent.trim()), 'After fixture');
  await page.keyboard.press('Space');
  assert.match(await page.getByRole('status').textContent(), /Action count:\s*2/);
  assert.equal(await page.getByRole('status').getAttribute('aria-live'), 'polite');
  report.checks.push({ name: 'host count and keyboard continuation after fixture removal', passed: true });
  assert.deepEqual(errors, []);
  report.status = 'passed';
} catch (error) {
  report.status = report.checks.length ? 'failed' : 'blocked';
  report.error = error.stack || String(error);
  console.error(report.error);
  process.exitCode = 1;
} finally {
  await browser?.close();
  server?.kill('SIGTERM');
  report.finished_at = now();
  writeFileSync(resolve(root, 'receipts/browser-check.json'), `${JSON.stringify(report, null, 2)}\n`);
  writeFileSync(resolve(root, 'receipts/preview.stdout-stderr.txt'), serverOutput);
  event({ event: 'browser_check_finished', status: report.status, passed_checks: report.checks.length, report: 'receipts/browser-check.json' });
  console.log(JSON.stringify({ status: report.status, passed_checks: report.checks.length }));
}
