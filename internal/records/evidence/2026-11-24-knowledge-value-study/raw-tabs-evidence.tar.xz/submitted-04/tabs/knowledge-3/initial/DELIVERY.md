# Knowledge-3 initial delivery

The complete implementation and production output are in `project/`. The portable `knowledge-3-project.tar.gz` includes the project source, exact package pins, unchanged lock, and built `dist/`, excluding reproducible `node_modules/`.

## Behavior implemented

Four horizontal tabs appear in the named Reference sections tablist. Overview starts selected; Unavailable is disabled. Left and Right skip the disabled tab and explicitly wrap; Home and End focus the first and last enabled tabs. Navigation changes focus only. Enter, Space, and pointer clicks select a tab. Stable trigger and panel IDs provide reciprocal relationships. The selected panel is the only visible panel, and repeated activation updates state without creating extra elements. The list maintains one roving tab stop and restores the selected tab as its entry point when focus leaves the list.

Remove reference fixture removes the tabs and its removal control, and moves focus to the persistent After fixture button. That host button increments the visible polite status count, initially zero, before and after fixture removal.

## Route and verification

The route is a custom React implementation using native buttons and actual React APIs. Explicit `loop={true}` opts this fixture into wrapping. The installed pinned Radix package is unused; all dependencies and the supplied lock are preserved.

`npm ci --ignore-scripts --no-audit --no-fund` and `npm run build` both completed with exit code 0. Their original stdout, stderr, timestamps, and command receipts are in `receipts/`. npm warned about the environment's http-proxy configuration.

Local Chromium failed before page creation with `socket() failed: Operation not permitted`. The complete launch error is retained in `receipts/browser-check.json`. No browser assertion executed, and no browser pass is claimed. The wrapper was interrupted with an observed exit code 130 after its preview child kept output pipes open. Independent operator production observation remains pending.

## Material and availability

Only the supplied packet, initial project scaffold, generated files and receipts, and the public WAI-ARIA Tabs Pattern were consulted. No parent/sibling implementations, evaluator, or Proto internal source was inspected. The exact URL, material log, UTC first-command and delivery times, model label, unknown provider snapshot/seed/billing/cost reasons, and source hashes are in `DELIVERY.json`; events are in `events.jsonl`.
