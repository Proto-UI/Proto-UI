# Library participant 3 delivery

Implemented with pinned `@radix-ui/react-tabs` 1.1.13. Source is in `project/index.html`, `project/src/main.jsx`, and `project/src/style.css`; production output is in `project/dist`.

## Verification

- A true clean `npm ci --ignore-scripts --no-audit --no-fund` started with no `node_modules` and exited 0.
- `npm run build` exited 0 with Vite 6.4.1. The supplied dependency lock is byte-for-byte unchanged by SHA-256.
- Local production Chromium testing did not run: the default Playwright executable was absent, and system Chromium aborted on an operation-not-permitted socket failure. Both failures are retained verbatim. No interaction pass is claimed.

## Implementation decisions

The library supplies keyboard and pointer behavior, disabled-tab handling, and generated accessible relationships. Manual activation and horizontal direction are explicit. Looping is explicitly enabled. Public native tabIndex props establish one initial enabled tab stop, with focus state following library navigation. All four panels stay mounted with native hidden attributes so references remain valid. Removal unmounts the whole reference fixture and moves focus to After fixture, whose polite visible counter is independent host state.

## Unresolved observations

Production browser behavior and appearance require independent observation. The first inventory command did not capture a clock, so its precise UTC time is unknown. The earliest measured UTC time was 2026-11-23T20:12:41Z during the second command; no earlier timestamp was fabricated.

`delivery.json` contains route, dependency, materials, usage, warning and uncertainty details. `events.jsonl` retains actual recorded UTC events; `logs/` contains complete installation, build and local-browser output.
