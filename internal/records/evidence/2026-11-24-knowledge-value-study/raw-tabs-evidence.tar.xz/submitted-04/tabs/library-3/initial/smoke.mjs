import { chromium } from './project/node_modules/playwright-core/index.mjs';
import { createServer } from 'node:http';
import { readFile, stat, writeFile } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import assert from 'node:assert/strict';

const root = resolve('project/dist');
const results = { production: true, checks: [], launchAttempts: [] };
const server = createServer(async (req, res) => {
  try {
    const path = resolve(root, '.' + new URL(req.url, 'http://localhost').pathname.replace(/\/$/, '/index.html'));
    if (!path.startsWith(root + '/')) throw new Error('Invalid path');
    res.setHeader('Content-Type', { '.js': 'application/javascript', '.css': 'text/css', '.html': 'text/html' }[extname(path)] || 'application/octet-stream');
    res.end(await readFile(path));
  } catch { res.statusCode = 404; res.end('Not found'); }
});
await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
let browser;
let passed = false;
try {
  const executablePaths = [undefined, '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome'];
  for (const executablePath of executablePaths) {
    if (executablePath && !(await stat(executablePath).catch(() => null))) continue;
    try {
      browser = await chromium.launch({ headless: true, executablePath, args: ['--no-sandbox'] });
      results.launchAttempts.push({ executablePath: executablePath || 'playwright default', passed: true });
      break;
    } catch (error) {
      results.launchAttempts.push({ executablePath: executablePath || 'playwright default', passed: false, error: String(error) });
    }
  }
  if (!browser) throw new Error('No attempted local Chromium launch succeeded.');
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', (error) => errors.push(String(error)));
  await page.goto(`http://127.0.0.1:${server.address().port}/`);
  const tab = (name) => page.getByRole('tab', { name, exact: true });
  async function check(label, selected, focused) {
    const data = await page.evaluate(() => {
      const tabs = [...document.querySelectorAll('[role=tab]')];
      const panels = [...document.querySelectorAll('[role=tabpanel]')];
      return {
        names: tabs.map((el) => el.textContent),
        selected: tabs.filter((el) => el.getAttribute('aria-selected') === 'true').map((el) => el.textContent),
        tabStops: tabs.filter((el) => el.tabIndex === 0).length,
        panels: panels.length,
        visible: panels.filter((el) => !el.hidden && getComputedStyle(el).display !== 'none').map((el) => el.getAttribute('aria-labelledby')),
        reciprocal: tabs.every((el) => document.getElementById(el.getAttribute('aria-controls'))?.getAttribute('aria-labelledby') === el.id),
        focused: document.activeElement.textContent,
      };
    });
    assert.deepEqual(data.names, ['Overview', 'Unavailable', 'Details', 'History']);
    assert.deepEqual(data.selected, [selected]);
    assert.equal(data.tabStops, 1);
    assert.equal(data.panels, 4);
    assert.equal(data.visible.length, 1);
    assert.equal(data.reciprocal, true);
    assert.equal(data.visible[0], await tab(selected).getAttribute('id'));
    if (focused) assert.equal(data.focused, focused);
    results.checks.push({ label, passed: true, data });
  }
  async function key(key, selected, focused) {
    await page.keyboard.press(key);
    await page.waitForFunction((name) => document.activeElement.textContent === name, focused);
    await check(key, selected, focused);
  }
  await check('initial', 'Overview');
  assert.equal(await page.getByRole('tablist', { name: 'Reference sections' }).count(), 1);
  assert.equal(await tab('Unavailable').isDisabled(), true);
  await tab('Overview').focus();
  await key('ArrowRight', 'Overview', 'Details');
  await key('End', 'Overview', 'History');
  await key('ArrowRight', 'Overview', 'Overview');
  await key('ArrowLeft', 'Overview', 'History');
  await key('Home', 'Overview', 'Overview');
  await key('ArrowRight', 'Overview', 'Details');
  await key('Enter', 'Details', 'Details');
  await key('End', 'Details', 'History');
  await key('Space', 'History', 'History');
  await tab('Overview').click();
  await check('pointer activation', 'Overview', 'Overview');
  for (let n = 0; n < 8; n++) await tab('Overview').click();
  await check('repeated selection', 'Overview', 'Overview');
  await page.getByRole('button', { name: 'After fixture', exact: true }).click();
  assert.equal(await page.getByRole('status').textContent(), 'Action count: 1');
  await page.screenshot({ path: 'logs/production.png', fullPage: true });
  await page.getByRole('button', { name: 'Remove reference fixture', exact: true }).click();
  assert.equal(await page.getByRole('tablist').count(), 0);
  assert.equal(await page.getByRole('tabpanel', { includeHidden: true }).count(), 0);
  assert.equal(await page.evaluate(() => document.activeElement.textContent), 'After fixture');
  await page.keyboard.press('Enter');
  await page.keyboard.press('Space');
  assert.equal(await page.getByRole('status').textContent(), 'Action count: 3');
  assert.equal(await page.getByRole('status').getAttribute('aria-live'), 'polite');
  assert.deepEqual(errors, []);
  results.checks.push({ label: 'Removal preserves keyboard activation and polite host count', passed: true });
  passed = true;
} catch (error) {
  results.error = String(error);
  console.error(error);
} finally {
  if (browser) await browser.close();
  await new Promise((resolve) => server.close(resolve));
  results.passed = passed;
  await writeFile('logs/browser-results.json', JSON.stringify(results, null, 2) + '\n');
  console.log(JSON.stringify(results, null, 2));
}
if (!passed) process.exitCode = 1;
