# Maintenance delivery

Only `project/src/main.jsx` changed, in two hunks. Each tabpanel now renders a normal `More information` link with `href="#reference-information"`. The existing hidden-panel behavior is retained. The visible polite counter now reads `Completed actions: N`; state initialization, increment logic and removal behavior are unchanged.

The fresh `npm run build` completed with exit 0. Exact stdout, stderr, command UTC events and exit are retained alongside before/after source snapshots, hashes and `changes.patch`. npm emitted its existing `http-proxy` environment warning. No browser attempt or browser pass is claimed for maintenance; independent operator observation remains pending.

`project-clean.tar.gz` is the updated complete clean project, including production `dist`, excluding installed `node_modules`. The original initial `DELIVERY.json`, event record, evidence and archive outside this maintenance directory remain untouched.

First actual maintenance command: 2026-11-23T20:18:02Z. The receipt was recorded at 2026-11-23T20:18:02.946003+00:00. The precise parent-send time is null because there is no timestamped send receipt; parent explicitly confirmed it was not separately recorded and must not be inferred. See `DELIVERY.json` and `events.jsonl` for the actual delivery/build timestamps.
