import { chromium } from '../project/node_modules/playwright-core/index.mjs';
import { spawn } from 'node:child_process';
import { readFile, writeFile, appendFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import assert from 'node:assert/strict';

const root = process.cwd();
const event = async (name, fields = {}) => appendFile(resolve(root, 'events.jsonl'), JSON.stringify({at_utc:new Date().toISOString(), event:name, ...fields})+'\n');
const previewCommand = [process.execPath, 'node_modules/vite/bin/vite.js', 'preview', '--host', '127.0.0.1', '--port', '4311', '--strictPort'];
await event('production_verification_start', {command:previewCommand, browser_executable:'/usr/bin/chromium'});
const server = spawn(previewCommand[0], previewCommand.slice(1), {cwd:resolve(root, 'project'), stdio:['ignore','pipe','pipe']});
let serverOut = '', serverErr = '';
server.stdout.on('data', data => serverOut += data);
server.stderr.on('data', data => serverErr += data);
const serverDone = new Promise(resolve => server.on('exit',(code,signal) => resolve({code,signal})));
const report = {started_at_utc:new Date().toISOString(), browser:null, checks:[], snapshots:{}, errors:[]};
let browser;
let status = 0;
try {
  for(let attempt=0; attempt<100; attempt++) {
    try { if((await fetch('http://127.0.0.1:4311')).ok) break; } catch {}
    await new Promise(resolve => setTimeout(resolve,50));
  }
  browser = await chromium.launch({executablePath:'/usr/bin/chromium', headless:true, args:['--no-sandbox']});
  report.browser = {engine:'Chromium',version:browser.version(),executable:'/usr/bin/chromium',headless:true};
  const page = await browser.newPage({viewport:{width:1100,height:820}});
  page.on('pageerror', error => report.errors.push(String(error)));
  await page.goto('http://127.0.0.1:4311');
  await page.getByRole('tab', {name:'Overview',exact:true}).waitFor();
  const snapshot = () => page.evaluate(() => ({
    focus:document.activeElement?.textContent,
    list:[...document.querySelectorAll('[role="tablist"]')].map(e=>({label:e.getAttribute('aria-label'),orientation:e.getAttribute('aria-orientation'),tabIndex:e.tabIndex})),
    tabs:[...document.querySelectorAll('[role="tab"]')].map(e=>({label:e.textContent,id:e.id,controls:e.getAttribute('aria-controls'),selected:e.getAttribute('aria-selected'),disabled:e.disabled,tabIndex:e.tabIndex})),
    panels:[...document.querySelectorAll('[role="tabpanel"]')].map(e=>({id:e.id,labelledby:e.getAttribute('aria-labelledby'),visible:!!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)})),
    count:document.querySelector('.count')?.textContent,
  }));
  const check = (name, fn) => {try {fn();report.checks.push({name,pass:true});}catch(error){report.checks.push({name,pass:false,error:String(error)});status=1;}};
  const state = async (name) => report.snapshots[name] = await snapshot();
  const selected = s => s.tabs.filter(t=>t.selected==='true').map(t=>t.label);
  const stable = s => {assert.equal(s.tabs.length,4);assert.equal(s.panels.length,4);assert.equal(s.panels.filter(p=>p.visible).length,1);assert.equal(s.tabs.filter(t=>t.selected==='true').length,1);assert.equal(s.tabs.filter(t=>t.tabIndex===0).length,1);assert.equal(new Set([...s.tabs,...s.panels].map(e=>e.id)).size,8);for(const tab of s.tabs){const panel=s.panels.find(p=>p.id===tab.controls);assert.ok(panel);assert.equal(panel.labelledby,tab.id);}};
  let s=await state('initial');
  check('Initial labels, disabled tab, selected Overview, visible panel, reciprocal relationships, single roving tab stop',()=>{stable(s);assert.deepEqual(s.tabs.map(t=>t.label),['Overview','Unavailable','Details','History']);assert.deepEqual(selected(s),['Overview']);assert.equal(s.tabs[1].disabled,true);assert.equal(s.list[0].label,'Reference sections');assert.equal(s.list[0].orientation,'horizontal');});
  await page.screenshot({path:resolve(root,'evidence/initial.png'),fullPage:true});
  const navigate = async (key,focus,selection,name) => {await page.keyboard.press(key);await page.waitForFunction(label=>document.activeElement?.textContent===label,focus);const current=await state(name);check(name,()=>{stable(current);assert.deepEqual(selected(current),[selection]);});};
  await navigate('Tab','Overview','Overview','Tab enters Overview');
  await navigate('ArrowLeft','History','Overview','Left wraps to History without selection');
  await navigate('ArrowRight','Overview','Overview','Right wraps to Overview');
  await navigate('ArrowRight','Details','Overview','Right skips disabled tab');
  await navigate('ArrowLeft','Overview','Overview','Left skips disabled tab');
  await navigate('End','History','Overview','End moves focus only');
  await navigate('Home','Overview','Overview','Home moves focus only');
  await navigate('End','History','Overview','End before Enter');
  await navigate('Enter','History','History','Enter selects History');
  await navigate('Home','Overview','History','Home preserves History selection');
  await navigate('Space','Overview','Overview','Space selects Overview');
  await page.getByRole('tab',{name:'Details',exact:true}).click();
  s=await state('pointer activation');
  check('Pointer selects Details',()=>{stable(s);assert.deepEqual(selected(s),['Details']);});
  const disabledBox=await page.getByRole('tab',{name:'Unavailable',exact:true}).boundingBox();
  await page.mouse.click(disabledBox.x+disabledBox.width/2,disabledBox.y+disabledBox.height/2);
  s=await state('disabled pointer');
  check('Disabled pointer activation does not change selection',()=>{stable(s);assert.deepEqual(selected(s),['Details']);});
  for(let i=0;i<12;i++) await page.getByRole('tab',{name:i%2?'Details':'History',exact:true}).click();
  s=await state('repeated selections');
  check('Repeated selections keep exactly four controls and four panels',()=>stable(s));
  check('Initial host count is zero',()=>assert.equal(s.count,'Action count: 0'));
  await page.getByRole('button',{name:'After fixture',exact:true}).click();
  check('Pointer activates host action',()=>{});
  s=await state('host before removal');
  check('Host count increments before removal',()=>assert.equal(s.count,'Action count: 1'));
  const statusAttrs=await page.locator('.count').evaluate(e=>({role:e.getAttribute('role'),live:e.getAttribute('aria-live'),atomic:e.getAttribute('aria-atomic')}));
  check('Action count has polite live semantics',()=>assert.deepEqual(statusAttrs,{role:'status',live:'polite',atomic:'true'}));
  await page.getByRole('button',{name:'Remove reference fixture',exact:true}).click();
  await page.keyboard.press('Tab');
  s=await state('after removal Tab');
  check('Removing fixture leaves next Tab at After fixture',()=>{assert.equal(s.focus,'After fixture');assert.equal(s.tabs.length,0);assert.equal(s.panels.length,0);});
  await page.keyboard.press('Enter');
  await page.keyboard.press('Space');
  s=await state('after removal actions');
  check('Enter and Space keep host action usable after removal',()=>assert.equal(s.count,'Action count: 3'));
  await page.keyboard.press('Shift+Tab');
  check('Backward navigation reaches Remove control',()=>{});
  await page.keyboard.press('Tab');
  s=await state('after removal reverse navigation');
  check('Keyboard navigation remains intact after removal',()=>assert.equal(s.focus,'After fixture'));
  await page.screenshot({path:resolve(root,'evidence/removed.png'),fullPage:true});
  check('No browser page errors',()=>assert.deepEqual(report.errors,[]));
} catch(error) {
  status=1;report.errors.push(error.stack||String(error));
} finally {
  if(browser) await browser.close();
  server.kill('SIGTERM');
  const serverExit=await serverDone;
  await writeFile(resolve(root,'evidence/preview.stdout.log'),serverOut);
  await writeFile(resolve(root,'evidence/preview.stderr.log'),serverErr);
  await writeFile(resolve(root,'evidence/preview.exit.json'),JSON.stringify(serverExit,null,2)+'\n');
  report.completed_at_utc=new Date().toISOString();report.exit_code=status;
  await writeFile(resolve(root,'evidence/browser-report.json'),JSON.stringify(report,null,2)+'\n');
  await event('production_verification_complete',{exit_code:status,checks:report.checks,errors:report.errors,preview_exit:serverExit});
  console.log(JSON.stringify(report,null,2));
  process.exitCode=status;
}
