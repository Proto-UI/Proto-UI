import { chromium } from '../project/node_modules/playwright-core/index.mjs';
import { spawn } from 'node:child_process';
import { appendFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import assert from 'node:assert/strict';

const evidence = path.dirname(fileURLToPath(import.meta.url));
const root = path.dirname(evidence);
const event = (name, values = {}) => appendFileSync(path.join(root, 'events.jsonl'), JSON.stringify({ utc: new Date().toISOString(), event: name, ...values }) + '\n');
const checks = [];
const check = (name, result) => { assert.ok(result, name); checks.push(name); console.log('PASS ' + name); };
let browser;
let previewOut = '';
let previewErr = '';
const preview = spawn('npm', ['run', 'preview', '--', '--port', '43187'], { cwd: path.join(root, 'project'), detached: true });
preview.stdout.on('data', (data) => { previewOut += data; });
preview.stderr.on('data', (data) => { previewErr += data; });
event('production_browser_check_started', { executable: '/usr/bin/chromium', url: 'http://127.0.0.1:43187', headless: true });
let error = null;
try {
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Preview readiness timeout')), 15000);
    preview.stdout.on('data', () => { if (previewOut.includes('43187')) { clearTimeout(timer); resolve(); } });
    preview.on('error', reject);
    preview.on('exit', (code) => { clearTimeout(timer); reject(new Error('Preview exited with ' + code)); });
  });
  browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox'] });
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const pageErrors = [];
  page.on('pageerror', (caught) => pageErrors.push(String(caught)));
  await page.goto('http://127.0.0.1:43187');
  const tab = (name) => page.getByRole('tab', { name, exact: true });
  const selected = () => page.locator('[role="tab"][aria-selected="true"]').textContent();
  const focused = () => page.evaluate(() => document.activeElement?.textContent?.trim());
  const invariant = async (label) => {
    const state = await page.evaluate(() => {
      const tabs = [...document.querySelectorAll('[role="tab"]')];
      const panels = [...document.querySelectorAll('[role="tabpanel"]')];
      return {
        tabs: tabs.length,
        panels: panels.length,
        stops: tabs.filter((node) => node.tabIndex === 0).length,
        selected: tabs.filter((node) => node.getAttribute('aria-selected') === 'true').length,
        visible: panels.filter((node) => !node.hidden).length,
        related: tabs.every((node) => {
          const panel = document.getElementById(node.getAttribute('aria-controls'));
          return panel?.getAttribute('aria-labelledby') === node.id;
        }),
      };
    });
    check(label, state.tabs === 4 && state.panels === 4 && state.stops === 1 && state.selected === 1 && state.visible === 1 && state.related);
  };
  check('Named horizontal tablist', await page.getByRole('tablist', { name: 'Reference sections' }).getAttribute('aria-orientation') === 'horizontal');
  check('Initial Overview selection', await selected() === 'Overview');
  check('Unavailable is disabled', await tab('Unavailable').isDisabled());
  check('Initial action count is zero and politely announced', await page.locator('.action-count').getAttribute('aria-live') === 'polite' && await page.locator('.action-count').textContent() === 'Action count: 0');
  await invariant('Initial control, panel, focus and relationship invariants');
  await page.screenshot({ path: path.join(evidence, 'production-initial.png'), fullPage: true });

  await page.keyboard.press('Tab');
  check('First Tab enters Overview', await focused() === 'Overview');
  await page.keyboard.press('ArrowRight');
  check('Right skips disabled and preserves selection', await focused() === 'Details' && await selected() === 'Overview');
  await page.keyboard.press('ArrowRight');
  check('Right reaches History', await focused() === 'History');
  await page.keyboard.press('ArrowRight');
  check('Right wraps to Overview', await focused() === 'Overview');
  await page.keyboard.press('ArrowLeft');
  check('Left wraps to History', await focused() === 'History');
  await page.keyboard.press('ArrowLeft');
  check('Left reaches Details', await focused() === 'Details');
  await page.keyboard.press('ArrowLeft');
  check('Left skips disabled', await focused() === 'Overview');
  await page.keyboard.press('End');
  check('End focuses last enabled tab without selecting', await focused() === 'History' && await selected() === 'Overview');
  await page.keyboard.press('Home');
  check('Home focuses first enabled tab', await focused() === 'Overview');
  await page.keyboard.press('End');
  await page.keyboard.press('Enter');
  check('Enter selects focused History', await selected() === 'History');
  await page.keyboard.press('ArrowLeft');
  await page.keyboard.press('Space');
  check('Space selects focused Details', await selected() === 'Details');
  await invariant('Keyboard interaction retains invariants');
  await tab('Overview').click();
  check('Pointer activates Overview', await selected() === 'Overview');
  for (let index = 0; index < 6; index++) {
    await tab('Details').click();
    await tab('History').click();
  }
  await invariant('Repeated selections do not duplicate controls or panels');
  await page.keyboard.press('Tab');
  check('Tab leaves tablist for visible panel', await page.evaluate(() => document.activeElement?.getAttribute('role') === 'tabpanel'));
  await page.keyboard.press('Tab');
  check('Remove button follows fixture in tab order', await focused() === 'Remove reference fixture');
  await page.keyboard.press('Tab');
  check('After button follows Remove button', await focused() === 'After fixture');
  await page.keyboard.press('Enter');
  check('After action increments before removal', await page.locator('.action-count').textContent() === 'Action count: 1');
  await page.getByRole('button', { name: 'Remove reference fixture', exact: true }).click();
  check('Removal unmounts all tabs and panels', await page.locator('[role="tab"], [role="tabpanel"], [role="tablist"]').count() === 0);
  check('Removal moves focus to enabled After action', await focused() === 'After fixture' && await page.getByRole('button', { name: 'After fixture', exact: true }).isEnabled());
  await page.keyboard.press('Enter');
  await page.keyboard.press('Space');
  await page.getByRole('button', { name: 'After fixture', exact: true }).click();
  check('After action handles Enter, Space and pointer after removal', await page.locator('.action-count').textContent() === 'Action count: 4');
  await page.keyboard.press('Tab');
  await page.keyboard.press('Shift+Tab');
  check('After action remains keyboard reachable', await focused() === 'After fixture');
  check('No page runtime errors', pageErrors.length === 0);
  await page.screenshot({ path: path.join(evidence, 'production-removed.png'), fullPage: true });
  event('production_browser_check_completed', { passed: checks.length, browser_version: browser.version() });
} catch (caught) {
  error = String(caught.stack || caught);
  console.error(error);
  event('production_browser_check_failed', { error, completed_checks: checks.length });
  process.exitCode = 1;
} finally {
  if (browser) await browser.close();
  try { process.kill(-preview.pid, 'SIGTERM'); } catch {}
  writeFileSync(path.join(evidence, 'preview.stdout.log'), previewOut);
  writeFileSync(path.join(evidence, 'preview.stderr.log'), previewErr);
  writeFileSync(path.join(evidence, 'browser-result.json'), JSON.stringify({ checks, error }, null, 2) + '\n');
}
