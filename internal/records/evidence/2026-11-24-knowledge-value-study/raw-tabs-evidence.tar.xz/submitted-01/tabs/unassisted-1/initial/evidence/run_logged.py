import datetime
import json
import pathlib
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent.parent
label = sys.argv[1]
command = sys.argv[2:]

def event(kind, **fields):
    record = {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "event": kind, **fields}
    with (root / "events.jsonl").open("a") as stream:
        stream.write(json.dumps(record) + "\n")
    return record

started = event("command_started", label=label, command=command, cwd=str(root / "project"))
result = subprocess.run(command, cwd=root / "project", capture_output=True, text=True)
(root / "evidence" / f"{label}.stdout.log").write_text(result.stdout)
(root / "evidence" / f"{label}.stderr.log").write_text(result.stderr)
finished = event("command_finished", label=label, command=command, exit_code=result.returncode)
(root / "evidence" / f"{label}.result.json").write_text(json.dumps({"start": started, "finish": finished}, indent=2) + "\n")
print(result.stdout, end="")
print(result.stderr, end="", file=sys.stderr)
print(json.dumps({"label": label, "exit_code": result.returncode}))
sys.exit(result.returncode)
