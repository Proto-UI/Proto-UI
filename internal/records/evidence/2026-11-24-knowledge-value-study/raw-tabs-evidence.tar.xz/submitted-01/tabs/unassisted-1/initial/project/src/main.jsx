import React, { useId, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

const sections = [
  {
    name: 'Overview',
    heading: 'A place for every reference.',
    description: 'Explore the reference sections using the tabs above. Your current section stays open while you move between tabs.',
    note: 'Start here to see the reference at a glance.',
  },
  {
    name: 'Unavailable',
    disabled: true,
    heading: 'This section is unavailable.',
    description: 'This reference section is not currently available.',
    note: 'Choose another section to continue.',
  },
  {
    name: 'Details',
    heading: 'The details, all together.',
    description: 'This section holds the supporting information for your reference. Switch sections whenever you are ready.',
    note: 'Supporting context belongs here.',
  },
  {
    name: 'History',
    heading: 'See how the reference evolved.',
    description: 'Keep track of the reference over time. The history section provides a dedicated place for previous changes.',
    note: 'No changes have been recorded in this example.',
  },
];

function ReferenceTabs({ loop }) {
  const id = useId();
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [focusIndex, setFocusIndex] = useState(0);
  const tabRefs = useRef([]);
  const enabledIndices = sections.flatMap((section, index) => section.disabled ? [] : [index]);

  function handleKeyDown(event, index) {
    const currentPosition = enabledIndices.indexOf(index);
    let target;

    if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
      const step = event.key === 'ArrowRight' ? 1 : -1;
      let nextPosition = currentPosition + step;
      if (loop) {
        nextPosition = (nextPosition + enabledIndices.length) % enabledIndices.length;
      } else {
        nextPosition = Math.max(0, Math.min(enabledIndices.length - 1, nextPosition));
      }
      target = enabledIndices[nextPosition];
    } else if (event.key === 'Home') {
      target = enabledIndices[0];
    } else if (event.key === 'End') {
      target = enabledIndices[enabledIndices.length - 1];
    } else if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      setSelectedIndex(index);
      return;
    } else {
      return;
    }

    event.preventDefault();
    setFocusIndex(target);
    tabRefs.current[target]?.focus();
  }

  return (
    <section className="reference-card" aria-label="Reference fixture">
      <div className="card-heading">
        <span className="eyebrow">REFERENCE</span>
        <span className="section-count">3 available sections</span>
      </div>
      <div className="tablist" role="tablist" aria-label="Reference sections" aria-orientation="horizontal">
        {sections.map((section, index) => (
          <button
            key={section.name}
            ref={(node) => { tabRefs.current[index] = node; }}
            type="button"
            role="tab"
            id={`${id}-tab-${index}`}
            aria-controls={`${id}-panel-${index}`}
            aria-selected={selectedIndex === index}
            aria-disabled={section.disabled || undefined}
            disabled={section.disabled}
            tabIndex={focusIndex === index ? 0 : -1}
            onFocus={() => setFocusIndex(index)}
            onKeyDown={(event) => handleKeyDown(event, index)}
            onClick={() => {
              setFocusIndex(index);
              setSelectedIndex(index);
              tabRefs.current[index]?.focus();
            }}
          >
            {section.name}
          </button>
        ))}
      </div>
      {sections.map((section, index) => (
        <div
          key={section.name}
          className="panel"
          role="tabpanel"
          id={`${id}-panel-${index}`}
          aria-labelledby={`${id}-tab-${index}`}
          hidden={selectedIndex !== index}
          tabIndex={selectedIndex === index ? 0 : -1}
        >
          <span className="panel-label">{section.name}</span>
          <h2>{section.heading}</h2>
          <p>{section.description}</p>
          <div className="panel-note"><span aria-hidden="true">↳</span> {section.note}</div>
        </div>
      ))}
      <p className="keyboard-hint">Use ← / → to move. Press Enter or Space to open a section.</p>
    </section>
  );
}

function App() {
  const [showReference, setShowReference] = useState(true);
  const [actionCount, setActionCount] = useState(0);
  const afterButtonRef = useRef(null);

  function removeReference() {
    setShowReference(false);
    afterButtonRef.current?.focus();
  }

  return (
    <main>
      <header className="page-header">
        <div className="brand-mark" aria-hidden="true">R</div>
        <span>Reference workspace</span>
      </header>
      <div className="intro">
        <span className="eyebrow">A SIMPLE REFERENCE</span>
        <h1>Find your section.</h1>
        <p>A small workspace for an overview, the details, and the story so far.</p>
      </div>

      {showReference ? <ReferenceTabs loop={true} /> : (
        <div className="removed-state" role="status">
          <span aria-hidden="true">✓</span>
          <h2>Reference fixture removed.</h2>
          <p>The action below is still available.</p>
        </div>
      )}

      <section className="fixture-actions" aria-label="Fixture actions">
        <div className="action-buttons">
          <button className="secondary-button" type="button" onClick={removeReference} disabled={!showReference}>
            Remove reference fixture
          </button>
          <button className="primary-button" type="button" ref={afterButtonRef} onClick={() => setActionCount((count) => count + 1)}>
            After fixture
          </button>
        </div>
        <p className="action-count" role="status" aria-live="polite" aria-atomic="true">Action count: <strong>{actionCount}</strong></p>
      </section>
      <footer>Move freely. Open a section when you are ready.</footer>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
