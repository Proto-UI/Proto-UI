# Delivery — unassisted-1

## Project

The complete application is in `project/`: pinned package manifest and lock, `index.html`, `src/main.jsx`, `src/style.css`, and the production `dist/` output. `project-clean.tar.gz` contains the same clean project without installed `node_modules`.

The implementation uses ordinary React 18.3.1 and React DOM 18.3.1 APIs, with Vite 6.4.1. Pinned Radix Tabs 1.1.13 remains installed but is not imported. No dependency pins or lock contents were edited.

## Implemented behavior

- Four horizontal tabs named Overview, Unavailable, Details and History in the `Reference sections` tablist. Unavailable uses native `disabled` and `aria-disabled`.
- Overview starts selected. Every tab has a stable controlled-panel ID; every panel points back to its tab. Exactly one tab has `tabIndex=0`, exactly one is selected, and exactly one panel is not hidden.
- Arrow navigation skips disabled tabs and explicitly wraps because this fixture passes `loop={true}`. Home and End focus the first and last enabled tabs. Navigation does not change selection. Enter, Space and pointer activation select.
- Controls and panels are mapped from a stable four-entry list, so repeated selections update state without appending elements.
- Remove reference fixture unmounts the tabs and panels, disables its own removal button, and moves focus to After fixture. Handlers are component-local with no global keyboard subscriptions.
- After fixture remains mounted after removal. Pointer, Enter and Space activate the native button. A persistent polite, atomic status displays an action count initialized to zero.

## Actual checks and limitations

`npm ci --ignore-scripts --no-audit --no-fund`: **exit 0**. `npm run build`: **exit 0**. Both produced an npm warning about the pre-existing `http-proxy` environment configuration. Exact stdout, stderr, exit and UTC events are retained under `evidence/` and in `events.jsonl`.

A production-preview Playwright attempt was made against `/usr/bin/chromium`. The preview started, but Chromium failed before connecting: `socket() failed: Operation not permitted`. The attempt exited 1 and completed **zero browser assertions**. No screenshot or browser version is claimed. `evidence/check-production.mjs` preserves the intended interaction checks; `evidence/browser.stderr.log` preserves the full real failure. These checks were not run successfully.

No known implementation requirements are deliberately omitted. Actual Chromium interaction behavior and visual layout remain unverified by this participant. The independent operator must establish the outcome.

## Materials and provenance

Read only the supplied participant, task and arm instructions and this packet's project skeleton/manifest. npm consumed this packet's pinned lock. No public URLs, local library declarations, other participants, reference implementations, evaluator files or Proto internals were consulted. The route was ordinary framework/ecosystem knowledge. `DELIVERY.json` records dependency pins, runtime versions, first-command and delivery timestamps, unresolved verification, and available model/usage facts. Unknown provider snapshot, seed, tokens and cost are null with reasons.

No commit, push or external person-directed message was sent.
