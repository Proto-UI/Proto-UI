import React, { useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import * as Tabs from '@radix-ui/react-tabs';
import './style.css';

const sections = [
  { value: 'overview', label: 'Overview', description: 'A concise introduction to this reference and its available sections.' },
  { value: 'unavailable', label: 'Unavailable', disabled: true, description: 'This section is currently unavailable.' },
  { value: 'details', label: 'Details', description: 'Explore the supporting details for this reference.' },
  { value: 'history', label: 'History', description: 'Review the history of this reference.' },
];

function ReferenceFixture({ onRemove }) {
  const [selected, setSelected] = useState('overview');
  const [tabStop, setTabStop] = useState('overview');

  return (
    <section className="reference" aria-labelledby="reference-heading">
      <div className="section-heading">
        <p className="eyebrow">REFERENCE</p>
        <h1 id="reference-heading">Reference sections</h1>
        <p className="intro">Choose a section to explore its content.</p>
      </div>
      <Tabs.Root value={selected} onValueChange={setSelected} activationMode="manual" orientation="horizontal" dir="ltr">
        {/* Explicit tab stops keep one trigger tabbable, including before first focus. */}
        <Tabs.List className="tabs" aria-label="Reference sections" loop={true} tabIndex={-1}>
          {sections.map((section) => (
            <Tabs.Trigger
              className="tab"
              key={section.value}
              value={section.value}
              disabled={section.disabled}
              tabIndex={!section.disabled && tabStop === section.value ? 0 : -1}
              onFocus={() => setTabStop(section.value)}
            >
              {section.label}
            </Tabs.Trigger>
          ))}
        </Tabs.List>
        {sections.map((section) => (
          <Tabs.Content className="panel" key={section.value} value={section.value}>
            <p className="eyebrow">{section.label.toUpperCase()}</p>
            <h2>{section.label}</h2>
            <p>{section.description}</p>
          </Tabs.Content>
        ))}
      </Tabs.Root>
      <p className="keyboard-help">Use Left and Right to move between available tabs. Home and End move to the first and last. Press Enter or Space to open a section.</p>
      <button className="button button-secondary" type="button" onClick={onRemove}>Remove reference fixture</button>
    </section>
  );
}

function App() {
  const [showReference, setShowReference] = useState(true);
  const [actionCount, setActionCount] = useState(0);
  const afterRef = useRef(null);

  function removeReference() {
    setShowReference(false);
    afterRef.current?.focus();
  }

  return (
    <main className="page">
      {showReference ? <ReferenceFixture onRemove={removeReference} /> : <p className="removed">Reference fixture removed.</p>}
      <section className="host-actions" aria-label="Host actions">
        <button className="button button-primary" type="button" ref={afterRef} onClick={() => setActionCount((count) => count + 1)}>After fixture</button>
        <p className="action-count" role="status" aria-live="polite" aria-atomic="true">Action count: <strong>{actionCount}</strong></p>
      </section>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
