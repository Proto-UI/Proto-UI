# Knowledge participant 2 delivery

Implemented the requested fixture with custom React state and native buttons. The installed pinned Radix package is unused. Dependency pins and the supplied lock are unchanged.

## Behavior

Four keyed horizontal tabs have one independent selected value and one roving focus value. Left/Right use an explicit modulo loop over enabled sections; Home/End move to the first/last enabled tab. Enter, Space and pointer clicks select. Every tab has an associated panel, and every panel points back to its tab. Inactive panels use the native hidden attribute. Overview starts selected. Unavailable is disabled.

The removal button stays mounted immediately before After fixture. Removing the reference unmounts the tabs and panels while leaving the host button and its polite action count intact. Repeated removal is harmless. The action count uses a functional state update and starts at zero.

## Receipts and limits

- Clean `npm ci --ignore-scripts --no-audit --no-fund`: exit 0.
- Production `npm run build`: exit 0.
- Ordinary local Chromium attempt: exit 1 before any page checks; Chromium reported `socket() failed: Operation not permitted` and a ptrace denial. No browser behavior or screenshots are claimed.
- Independent operator Chromium verification remains outstanding. There are no known source-level omissions.

The complete clean project, including production dist, is in knowledge-2-delivery.tar.gz and the project directory. Full stdout, stderr and exit-code receipts are in receipts/. All local browser failure details and the attempted harness are retained. delivery.json includes timings, actual route, materials, tool counts, model facts and unavailable usage fields. manifest.json hashes source, dependency metadata and dist. events.jsonl records actual UTC events.
