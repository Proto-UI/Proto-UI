import { chromium } from '../project/node_modules/playwright-core/index.mjs';
import { createServer } from 'node:http';
import { readFile, writeFile, appendFile } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import assert from 'node:assert/strict';

const packet = process.cwd();
const started = new Date().toISOString();
const checks = [];
const browserErrors = [];
let browser;
const root = resolve(packet, 'project/dist');
const server = createServer(async (req, res) => {
  try {
    const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    const file = resolve(root, '.' + (pathname === '/' ? '/index.html' : pathname));
    if (!file.startsWith(root + '/')) throw new Error('Invalid path');
    res.setHeader('Content-Type', ({'.html':'text/html','.css':'text/css','.js':'application/javascript'})[extname(file)] || 'application/octet-stream');
    res.end(await readFile(file));
  } catch { res.statusCode = 404; res.end('Not found'); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const origin = `http://127.0.0.1:${server.address().port}`;
let error = null;
try {
  browser = await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
  const page = await browser.newPage({viewport:{width:1100,height:800}});
  page.on('pageerror', err => browserErrors.push(String(err)));
  await page.goto(origin);
  await page.getByRole('tab', {name:'Overview',exact:true}).waitFor();
  const tab = name => page.getByRole('tab',{name,exact:true});
  const check = async (name, focused, selected) => {
    const state = await page.evaluate(() => ({
      focused: document.activeElement.textContent.trim(),
      selected: [...document.querySelectorAll('[role="tab"][aria-selected="true"]')].map(x=>x.textContent.trim()),
      stops: document.querySelectorAll('[role="tab"][tabindex="0"]').length,
      visiblePanels: [...document.querySelectorAll('[role="tabpanel"]')].filter(x=>!x.hidden).map(x=>x.id),
      tabCount: document.querySelectorAll('[role="tab"]').length,
      panelCount: document.querySelectorAll('[role="tabpanel"]').length,
    }));
    if (focused) assert.equal(state.focused,focused);
    assert.deepEqual(state.selected,[selected]);
    assert.equal(state.stops,1);
    assert.deepEqual(state.visiblePanels,[`reference-panel-${selected.toLowerCase()}`]);
    assert.equal(state.tabCount,4);assert.equal(state.panelCount,4);
    checks.push({name,passed:true,state});
  };
  assert.equal(await page.getByRole('tablist',{name:'Reference sections',exact:true}).count(),1);
  assert.deepEqual(await page.getByRole('tab').allTextContents(),['Overview','Unavailable','Details','History']);
  assert.equal(await tab('Unavailable').isDisabled(),true);
  assert.equal(await page.getByRole('status').textContent(),'Action count: 0');
  assert.equal(await page.getByRole('status').getAttribute('aria-live'),'polite');
  await check('initial state',null,'Overview');
  await page.keyboard.press('Tab');await check('initial keyboard entry','Overview','Overview');
  await page.keyboard.press('ArrowRight');await check('Right skips disabled and does not select','Details','Overview');
  await page.keyboard.press('ArrowRight');await check('Right advances','History','Overview');
  await page.keyboard.press('ArrowRight');await check('Right wraps','Overview','Overview');
  await page.keyboard.press('ArrowLeft');await check('Left wraps','History','Overview');
  await page.keyboard.press('Home');await check('Home focuses first enabled','Overview','Overview');
  await page.keyboard.press('End');await check('End focuses last enabled','History','Overview');
  await page.keyboard.press('Enter');await check('Enter selects focused tab','History','History');
  await page.keyboard.press('ArrowLeft');await check('Left changes focus only','Details','History');
  await page.keyboard.press('Space');await check('Space selects focused tab','Details','Details');
  await tab('Overview').click();await check('pointer selects','Overview','Overview');
  for(let i=0;i<4;i++) await tab('Overview').click();
  await check('repeated selection does not duplicate','Overview','Overview');
  const relationships = await page.evaluate(() => [...document.querySelectorAll('[role="tab"]')].map(tab=> {
    const panel=document.getElementById(tab.getAttribute('aria-controls'));
    return {tab:tab.id,panel:panel?.id,reciprocal:panel?.getAttribute('aria-labelledby')===tab.id};
  }));
  assert(relationships.every(x=>x.reciprocal));checks.push({name:'reciprocal relationships',passed:true,relationships});
  await page.screenshot({path:resolve(packet,'receipts/fixture.png'),fullPage:true});
  const after=page.getByRole('button',{name:'After fixture',exact:true});
  await after.click();await page.keyboard.press('Enter');await page.keyboard.press('Space');
  assert.equal(await page.getByRole('status').textContent(),'Action count: 3');
  checks.push({name:'host pointer, Enter and Space activation before removal',passed:true,count:3});
  await page.getByRole('button',{name:'Remove reference fixture',exact:true}).click();
  assert.equal(await page.getByRole('tab').count(),0);assert.equal(await page.getByRole('tabpanel').count(),0);
  await page.keyboard.press('Tab');
  assert.equal(await after.evaluate(node=>node===document.activeElement),true);
  await page.keyboard.press('Enter');await page.keyboard.press('Space');
  assert.equal(await page.getByRole('status').textContent(),'Action count: 5');
  checks.push({name:'removal preserves Tab route and host keyboard counter',passed:true,count:5});
  assert.deepEqual(browserErrors,[]);
  await page.screenshot({path:resolve(packet,'receipts/after-removal.png'),fullPage:true});
} catch(err) {
  error = {name:err.name,message:err.message,stack:err.stack};
  process.exitCode=1;
} finally {
  if(browser) await browser.close();
  await new Promise(resolve=>server.close(resolve));
  const receipt={started_utc:started,ended_utc:new Date().toISOString(),production_url:origin,engine:'Chromium /usr/bin/chromium through pinned playwright-core 1.58.2',result:error?'failed':'passed',checks,browserErrors,error};
  await writeFile(resolve(packet,'receipts/local-browser.json'),JSON.stringify(receipt,null,2)+'\n');
  await appendFile(resolve(packet,'events.jsonl'),JSON.stringify({time_utc:new Date().toISOString(),event:'local_browser_attempt',tool_call_number:7,result:receipt.result,receipt:'receipts/local-browser.json'})+'\n');
  console.log(JSON.stringify(receipt,null,2));
}
