# Initial delivery — library-2

## Implementation

The complete implementation is in `project/index.html`, `project/src/main.jsx`, and `project/src/style.css`. Production output is in `project/dist/`. `project-delivery.tar.gz` contains the full project source, unchanged manifests and lock, and built production output, excluding installed node_modules.

Route: the required mature public `@radix-ui/react-tabs` 1.1.13 library with React/react-dom 18.3.1 and Vite 6.4.1. No dependencies or pins changed.

Radix Root uses `activationMode="manual"`, `orientation="horizontal"`, and `dir="ltr"`. List explicitly opts into `loop={true}`. Trigger uses native `disabled` for Unavailable. The library supplies keyboard navigation, activation, stable IDs, tab/panel semantics, and hidden panel behavior. Native `tabIndex` plus `onFocus` props keep exactly one trigger in the tab sequence from initial render, while the tablist itself is -1. Focus state and selection state remain separate. The persistent host action uses React state for the count and a polite atomic status region. Removing the fixture focuses the surviving After fixture button.

## Validation receipts

- `receipts/npm-ci.json`: clean required npm ci command completed with exit 0. Real stdout and stderr retained.
- `receipts/build.json`: production build completed with exit 0. Real stdout and stderr retained.
- `receipts/dependency-integrity.json`: package.json and package-lock.json hashes match their supplied versions.
- `receipts/browser-result.json`: local Chromium launch FAILED before opening a page; process singleton socket() failed with Operation not permitted. No interaction checks ran. The failed test script is retained as `receipts/check-production.mjs`.
- `receipts/browser-wrapper.json`: the outer harness subsequently timed out at 50 seconds because its npm preview child kept the process alive. This is a separate retained harness failure, not a browser pass.
- Build warnings: npm reported its environment http-proxy configuration warning; Vite ignored Radix module-level use client directives. The build still exited 0.

## Unresolved requirements

No known implementation requirement is deliberately omitted. Actual Chromium behavior is unverified locally due to the startup failure. Independent production testing must establish initial state, disabled skipping, explicit wrapping, focus-only navigation, manual and pointer activation, one roving trigger, reciprocal relationships, stable cardinality, removal navigation, and live action count behavior.

## Materials, scope and usage

`materials.json` records supplied files, public documentation URLs, and consulted installed dependency declaration/implementation files. Current Radix public docs showed version 1.1.22, so installed 1.1.13 declarations and source were also checked. No parent, sibling, evaluator, Proto internal source, or other participant implementation was opened. No commits, pushes, or messages to external people were made.

`events.jsonl` records actual event timestamps including the first command and delivery. `telemetry.json` records known model/runtime facts and null values with explanations for unavailable provider snapshot, seed, usage, billing, and cost.
