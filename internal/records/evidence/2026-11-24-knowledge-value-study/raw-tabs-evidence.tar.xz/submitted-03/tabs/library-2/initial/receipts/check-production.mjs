import { chromium } from '../project/node_modules/playwright-core/index.mjs';
import { spawn } from 'node:child_process';
import { writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';

const root = fileURLToPath(new URL('../', import.meta.url));
const report = { started_at: new Date().toISOString(), url: 'http://127.0.0.1:4272', executable: '/usr/bin/chromium', cases: [], page_errors: [] };
const server = spawn('npm', ['run', 'preview', '--', '--port', '4272'], { cwd: root + 'project', stdio: ['ignore', 'pipe', 'pipe'] });
let serverOut = '', serverErr = '', browser;
server.stdout.on('data', d => serverOut += d);
server.stderr.on('data', d => serverErr += d);
try {
  let ready = false;
  for (let attempt = 0; attempt < 50; attempt++) {
    try { const r = await fetch(report.url); if (r.ok) { ready = true; break; } } catch {}
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  assert.ok(ready, 'production server available');
  browser = await chromium.launch({ executablePath: report.executable, headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage({ viewport: { width: 1100, height: 850 } });
  page.on('pageerror', error => report.page_errors.push(String(error)));
  await page.goto(report.url);
  const tabs = page.getByRole('tab');
  async function invariants(selected) {
    assert.equal(await tabs.count(), 4);
    assert.equal(await page.locator('[role="tabpanel"]').count(), 4);
    assert.equal(await page.locator('[role="tab"][tabindex="0"]').count(), 1);
    assert.equal(await page.locator('[role="tab"][aria-selected="true"]').count(), 1);
    assert.equal(await page.locator('[role="tab"][aria-selected="true"]').innerText(), selected);
    assert.equal(await page.locator('[role="tabpanel"]:visible').count(), 1);
    const relationships = await tabs.evaluateAll(nodes => nodes.every(tab => {
      const panel = document.getElementById(tab.getAttribute('aria-controls'));
      return panel?.getAttribute('role') === 'tabpanel' && panel.getAttribute('aria-labelledby') === tab.id;
    }));
    assert.ok(relationships, 'reciprocal relationships');
  }
  async function key(key, focused, selected) {
    await page.keyboard.press(key);
    await page.waitForFunction(label => document.activeElement?.textContent === label, focused);
    await invariants(selected);
  }
  assert.equal(await page.getByRole('tablist', { name: 'Reference sections', exact: true }).count(), 1);
  assert.equal(await page.getByRole('tablist').getAttribute('aria-orientation'), 'horizontal');
  assert.ok(await page.getByRole('tab', { name: 'Unavailable', exact: true }).isDisabled());
  await invariants('Overview');
  report.cases.push('Initial state, disabled tab, one roving trigger, named horizontal tablist, reciprocal IDs');
  await page.keyboard.press('Tab');
  await page.waitForFunction(() => document.activeElement?.textContent === 'Overview');
  await key('ArrowRight', 'Details', 'Overview');
  await key('ArrowRight', 'History', 'Overview');
  await key('ArrowRight', 'Overview', 'Overview');
  await key('ArrowLeft', 'History', 'Overview');
  await key('ArrowLeft', 'Details', 'Overview');
  await key('ArrowLeft', 'Overview', 'Overview');
  report.cases.push('Left/right focus only; disabled skip; wrap both directions');
  await key('End', 'History', 'Overview');
  await key('Home', 'Overview', 'Overview');
  await key('ArrowRight', 'Details', 'Overview');
  await key('Enter', 'Details', 'Details');
  await key('End', 'History', 'Details');
  await key('Space', 'History', 'History');
  report.cases.push('Home/End focus only; Enter and Space activate focused tab');
  await page.getByRole('tab', { name: 'Overview', exact: true }).click();
  await invariants('Overview');
  for (let index = 0; index < 8; index++) {
    await page.getByRole('tab', { name: 'Details', exact: true }).click();
    await invariants('Details');
    await page.keyboard.press('Enter');
    await invariants('Details');
  }
  report.cases.push('Pointer activation and repeated selection preserve exactly four controls/panels');
  await page.getByRole('button', { name: 'After fixture', exact: true }).click();
  assert.equal(await page.getByRole('status').innerText(), 'Action count: 1');
  assert.equal(await page.getByRole('status').getAttribute('aria-live'), 'polite');
  await page.screenshot({ path: root + 'receipts/production.png', fullPage: true });
  await page.getByRole('button', { name: 'Remove reference fixture', exact: true }).click();
  assert.equal(await tabs.count(), 0);
  assert.equal(await page.locator('[role="tabpanel"]').count(), 0);
  assert.equal(await page.evaluate(() => document.activeElement?.textContent), 'After fixture');
  await page.keyboard.press('Enter');
  assert.equal(await page.getByRole('status').innerText(), 'Action count: 2');
  await page.keyboard.press('Space');
  assert.equal(await page.getByRole('status').innerText(), 'Action count: 3');
  report.cases.push('After fixture increments politely announced count before removal and remains focused/keyboard usable after removal');
  assert.deepEqual(report.page_errors, []);
  report.status = 'passed';
} catch (error) {
  report.status = 'failed';
  report.error = String(error?.stack || error);
  process.exitCode = 1;
} finally {
  if (browser) await browser.close();
  server.kill('SIGTERM');
  report.finished_at = new Date().toISOString();
  await writeFile(root + 'receipts/browser-result.json', JSON.stringify(report, null, 2) + '\n');
  await writeFile(root + 'receipts/preview.stdout.txt', serverOut);
  await writeFile(root + 'receipts/preview.stderr.txt', serverErr);
  console.log(JSON.stringify(report, null, 2));
}
