import React, { useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

const sections = [
  { value: 'overview', label: 'Overview', body: 'Explore the reference using the sections above.' },
  { value: 'unavailable', label: 'Unavailable', disabled: true, body: 'This section is currently unavailable.' },
  { value: 'details', label: 'Details', body: 'The reference brings its supporting information together in this section.' },
  { value: 'history', label: 'History', body: 'The reference history appears here.' },
];
const enabledSections = sections.filter((section) => !section.disabled);

function ReferenceTabs() {
  const [selected, setSelected] = useState('overview');
  const [tabStop, setTabStop] = useState('overview');
  const triggers = useRef({});

  function handleKeyDown(event, value) {
    const index = enabledSections.findIndex((section) => section.value === value);
    let nextIndex;

    // This fixture explicitly enables looping. Focus and selection are independent.
    switch (event.key) {
      case 'ArrowRight':
        nextIndex = (index + 1) % enabledSections.length;
        break;
      case 'ArrowLeft':
        nextIndex = (index - 1 + enabledSections.length) % enabledSections.length;
        break;
      case 'Home':
        nextIndex = 0;
        break;
      case 'End':
        nextIndex = enabledSections.length - 1;
        break;
      case 'Enter':
      case ' ':
        event.preventDefault();
        setSelected(value);
        return;
      default:
        return;
    }

    event.preventDefault();
    const next = enabledSections[nextIndex].value;
    setTabStop(next);
    triggers.current[next]?.focus();
  }

  return (
    <section className="reference-fixture" aria-label="Reference fixture">
      <div className="tabs" role="tablist" aria-label="Reference sections" aria-orientation="horizontal">
        {sections.map((section) => (
          <button
            type="button"
            role="tab"
            key={section.value}
            id={`reference-tab-${section.value}`}
            aria-controls={`reference-panel-${section.value}`}
            aria-selected={selected === section.value}
            aria-disabled={section.disabled || undefined}
            disabled={section.disabled}
            tabIndex={!section.disabled && tabStop === section.value ? 0 : -1}
            ref={(node) => { triggers.current[section.value] = node; }}
            onFocus={() => setTabStop(section.value)}
            onKeyDown={(event) => handleKeyDown(event, section.value)}
            onClick={() => {
              setTabStop(section.value);
              setSelected(section.value);
            }}
          >
            {section.label}
          </button>
        ))}
      </div>
      {sections.map((section) => (
        <div
          className="tab-panel"
          role="tabpanel"
          key={section.value}
          id={`reference-panel-${section.value}`}
          aria-labelledby={`reference-tab-${section.value}`}
          hidden={selected !== section.value}
          tabIndex={0}
        >
          <h2>{section.label}</h2>
          <p>{section.body}</p>
        </div>
      ))}
    </section>
  );
}

function App() {
  const [showReference, setShowReference] = useState(true);
  const [actionCount, setActionCount] = useState(0);

  return (
    <main>
      <p className="eyebrow">INTERACTION REFERENCE</p>
      <h1>Reference sections</h1>
      <p className="intro">Use Left and Right to move between available tabs. Home and End jump to either end. Press Enter or Space to open the focused section.</p>

      {showReference ? <ReferenceTabs /> : <p className="removed">Reference fixture removed.</p>}

      <div className="host-actions">
        <button type="button" className="secondary" onClick={() => setShowReference(false)}>Remove reference fixture</button>
        <button type="button" className="primary" onClick={() => setActionCount((count) => count + 1)}>After fixture</button>
      </div>
      <p className="action-count" role="status" aria-live="polite" aria-atomic="true">Action count: {actionCount}</p>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
