#!/usr/bin/env python3
import pathlib, os, subprocess, json, hashlib, datetime, traceback, gzip, base64, fcntl

T = pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
B = pathlib.Path(str(T) + '-ops')
R = pathlib.Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a-ops')
O = B / 'final-25ca-evidence-closeout-r1'
lock = (B / 'final-25ca-evidence-closeout-r1.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
O.mkdir(exist_ok=False)
E = dict(os.environ)
E['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:' + E.get('PATH', '')
E['TMPDIR'] = '/var/tmp/s5g75d5'
assert E.get('HUSKY') != '0'
H = '25ca6fcaecd917457f6f3d694b3e12bfb522e89a'
TREE = '45c5e08bc7a773e3534fd4b07dc66ea437c73c46'
MAIN = '0fbb52ef832cc27c78e24c28c59a55a16f51d7fe'
S = {'phase': 'initial', 'pid': os.getpid(), 'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'executedHead': H, 'executedTree': TREE, 'commands': [], 'pushAttempted': False, 'dispatchAttempted': False}

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    return digest(pathlib.Path(path).read_bytes())

def read(path):
    return json.loads(pathlib.Path(path).read_text())

def save(phase=None):
    if phase:
        S['phase'] = phase
    (O / 'status.json').write_text(json.dumps(S, indent=2) + '\n')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=T, env=E, text=True, timeout=90).strip()

def run(name, argv, timeout=180, trace=False):
    save(name)
    (O / (name + '.command.json')).write_text(json.dumps({'argv': argv, 'cwd': str(T), 'timeoutSeconds': timeout}, indent=2) + '\n')
    env = dict(E)
    if trace:
        env['GIT_TRACE2_EVENT'] = str(O / (name + '.trace.jsonl'))
    with (O / (name + '.log')).open('wb') as out:
        child = subprocess.Popen(argv, cwd=T, env=env, stdout=out, stderr=subprocess.STDOUT, start_new_session=True)
        S['childPid'] = child.pid
        save()
        try:
            code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            import signal
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=10)
            raise
    S.pop('childPid', None)
    S['commands'].append({'name': name, 'argv': argv, 'exitCode': code})
    save()
    assert code == 0, (name, code)
    return (O / (name + '.log')).read_text()

def api(name, path):
    return json.loads(run(name, ['gh', 'api', path]))

def source_tree(ref):
    raw = subprocess.check_output(['git', 'ls-tree', '-r', '-z', ref], cwd=T, env=E, timeout=90)
    entries = []
    for row in raw.split(b'\0'):
        if not row:
            continue
        header, path = row.split(b'\t', 1)
        path = path.decode()
        if path.startswith('internal/records/'):
            continue
        mode, kind, oid = header.decode().split()
        entries.append({'path': path, 'mode': mode, 'kind': kind, 'gitObject': oid})
    return entries

try:
    assert git('rev-parse', 'HEAD') == H and git('rev-parse', 'HEAD^{tree}') == TREE
    assert git('branch', '--show-current') == 'codex/sprint5-input-75d5e28a' and git('status', '--porcelain=v1') == ''
    closeout = read(B / 'native-part-input-closeout-r1/status.json')
    assert closeout['phase'] == 'committed' and closeout['finalHead'] == H and closeout['artifactBytesStable'] and closeout['preCommitEvents']
    assert all(sha(T / p) == value for p, value in closeout['sourceAfter'].items())
    publisher = read(B / 'publish-native-part-input-r1/status.json')
    assert publisher['phase'] == 'dispatched-exact-head' and publisher['publishedHead'] == H and publisher['run']['id'] == 45282014115
    assert publisher['dispatchInputs'] == {'browser_acceptance': 'true', 'adapter_acceptance': 'false', 'package_budget_evidence': 'false', 'website_shader_evidence': 'false'}
    native = read(B / 'formal-25ca-native/status.json')
    assert native['phase'] == 'artifacts-verified' and native['head'] == H and len(native['jobs']) == 3
    assert all(j['finalObservedConclusion'] == 'success' and j['sourceSha'] == H for j in native['jobs'])
    native_readback = read(B / 'formal-25ca-native/readback.json')
    assert sha(B / 'formal-25ca-native/readback.json') == 'f74713e19f8c2b3f120d33cf2b7bb78d2d20ec8d7fed69fc33601923f89e8140'
    assert all(v['total'] == 155 and v['failed'] == v['ignored'] == v['filtered'] == 0 for v in native_readback['native'].values())
    assert native_readback['flutter']['nativeWidgetsPassed'] == 14 and native_readback['flutter']['innerReceiptDigestsMatch']
    custody = read(B / 'formal-25ca-source-browser/status.json')
    assert custody['phase'] == 'custody-verified' and custody['head'] == H and custody['extractedFileCount'] == 48
    peer_path = B / 'formal-25ca-source-browser/formal-source-browser-readback.json'
    assert sha(peer_path) == '073eb44a1a4d0f7d80953809b92d8864d2edfcbb728c99602adb23c73c8b06ea'
    peer = read(peer_path)
    assert peer['head'] == H and peer['tree'] == TREE
    assert peer['source']['actualFiles'] == 44 and peer['source']['actualAssertions'] == 778 and peer['source']['actualAssertionStatuses'] == {'passed': 778}
    assert peer['source']['types']['workspaceTypeScript']['result'] == 'exit 0' and peer['source']['types']['astroDocs'] == {'files': 1330, 'errors': 0, 'warnings': 0, 'hints': 47}
    assert peer['browser']['canonical']['total'] == 20 and peer['browser']['canonical']['statuses'] == {'passed': 20}
    assert peer['browser']['SSR']['passed'] == 4 and peer['browser']['nativeShadow']['selectedPassed'] == 2 and peer['browser']['nativeShadow']['filteredOrSkipped'] == 190
    assert peer['browser']['independentReceiptRebuild']['stepConclusion'] == 'success'
    assert len(peer['browser']['independentReceiptRebuild']['rows']) == 8 and all(r['status'] == 'browser-executed-awaiting-independent-acceptance' for r in peer['browser']['independentReceiptRebuild']['rows'])
    assert peer['browser']['sourceStability']['inputFileCount'] == 10687 and peer['browser']['sourceStability']['status'] == 'passed'
    for job in custody['jobs']:
        for item in [job['zip'], job['originalJobLog'], *job['extracted']]:
            p = B / 'formal-25ca-source-browser' / item['path']
            assert p.stat().st_size == item['bytes'] and sha(p) == item['sha256']
    vitest = read(B / 'formal-25ca-source-browser/source-artifact/vitest.json')
    assert vitest['success'] and len(vitest['testResults']) == 44 and vitest['numPassedTests'] == vitest['numTotalTests'] == 778 and vitest['numFailedTests'] == vitest['numPendingTests'] == vitest['numTodoTests'] == 0
    receipt = read(B / 'formal-25ca-source-browser/browser-artifact/receipt.json')
    assert receipt['head'] == H and len(receipt['cases']) == 20 and all(c['status'] == 'passed' for c in receipt['cases'])
    production_path = R / 'final-25ca-production/root-readback.json'
    assert sha(production_path) == 'd5c76f24b4b2a27ab066cfd4e0261c82c6d3e32d79bbc7d7ae180d582d49152f'
    production = read(production_path)
    assert production['source'] == H and production['sourceTree'] == TREE and production['replayReturncode'] == 0 and production['replay']['issues'] == []
    assert production['originalGateControls']['pass'] == 2150 and production['originalGateControls']['fail'] == production['originalGateControls']['skipped'] == 0
    packed = base64.b64decode((B / '25ca-final-primary-packet.json.gz.b64').read_text())
    assert digest(packed) == '6709d742c81a0d3c947d62feac3fe9113e44325194a20fcd78e2602c47a74a15'
    packet_bytes = gzip.decompress(packed)
    assert digest(packet_bytes) == '21536c6841a39939f2edf9eb812e5ef271c04f48c4a15850c5af7202acab135f'
    packet = json.loads(packet_bytes)
    for key in ['template', 'rules']:
        entry = packet[key]
        data = entry['content'].encode()
        assert len(data) == entry['bytes'] and digest(data) == entry['sha256']
        (O / entry['path']).write_bytes(data)
    assert packet['rules']['sha256'] == '83be45fb2f1956b147466a08a57718bd02a18d1bd6dbf63820d9aacb29827459'
    pr = api('public-pr', 'repos/Proto-UI/Proto-UI/pulls/1738')
    assert pr['head']['sha'] == H and pr['state'] == 'open' and not pr['merged'] and pr['draft']
    main = api('public-main', 'repos/Proto-UI/Proto-UI/branches/main')
    assert main['commit']['sha'] == MAIN
    formal = api('formal-run', 'repos/Proto-UI/Proto-UI/actions/runs/45282014115')
    standard = api('standard-run', 'repos/Proto-UI/Proto-UI/actions/runs/45282010587')
    assert all(r['head_sha'] == H and r['status'] == 'completed' and r['conclusion'] == 'success' and r['run_attempt'] == 1 for r in [formal, standard])
    checks = api('head-checks', 'repos/Proto-UI/Proto-UI/commits/' + H + '/check-runs?per_page=100')
    dco = [r for r in checks['check_runs'] if r['name'] == 'DCO']
    assert len(dco) == 1 and dco[0]['conclusion'] == 'success'
    statuses = api('head-statuses', 'repos/Proto-UI/Proto-UI/commits/' + H + '/status')
    vercel = [r for r in statuses['statuses'] if r['context'] == 'Vercel']
    assert len(vercel) >= 1 and vercel[0]['state'] == 'failure' and 'Deployment rate limited' in vercel[0]['description']
    entries_before = source_tree(H)
    map_data = {'executedHead': H, 'executedTree': TREE, 'excludedPrefix': 'internal/records/', 'entryCount': len(entries_before), 'entriesSha256': digest(json.dumps(entries_before, sort_keys=True, separators=(',', ':')).encode()), 'entries': entries_before}
    (O / 'executed-source-tree.json').write_text(json.dumps(map_data, indent=2) + '\n')
    files = {}
    def add(label, path):
        path = pathlib.Path(path)
        assert path.is_file() and not path.is_symlink(), str(path)
        assert '.private.' not in label and 'transfer-links' not in label
        assert label not in files
        files[label] = path
    def add_dir(label, path, recursive=False):
        path = pathlib.Path(path)
        assert path.is_dir(), str(path)
        for p in sorted(path.rglob('*') if recursive else path.iterdir()):
            if p.is_file():
                add(label + '/' + str(p.relative_to(path)), p)
    add_dir('hosted/native', B / 'formal-25ca-native')
    add_dir('hosted/source-browser', B / 'formal-25ca-source-browser')
    add_dir('hosted/production', R / 'final-25ca-production', True)
    add('hosted/production-collector.py', R / 'collect-25ca-production.py')
    add_dir('publication/publisher', B / 'publish-native-part-input-r1')
    for name in ['status.json', 'commit.trace.jsonl', 'commit.log', 'commit.command.json', 'message.txt', 'staged-diff-check.log', 'staged-diff-check.command.json', 'format-records.log', 'format-records.command.json', 'format-final.log', 'format-final.command.json', 'diff-check.log', 'diff-check.command.json', 'stage.log', 'stage.command.json']:
        add('publication/normal-commit/' + name, B / 'native-part-input-closeout-r1' / name)
    for name in ['native-part-input-closeout-launch.json', 'native-part-input-closeout-r1-launch.log', 'close-native-part-input-r1.py', 'publish-native-part-input-r1.py', 'publish-native-part-input-launch.json', 'publish-native-part-input-r1-launch.log', 'collect-25ca-native.py', 'collect-25ca-native-launch.json', 'collect-25ca-native-launch.log', 'collect-25ca-source-browser-custody.py', 'collect-25ca-source-browser-launch.json', 'collect-25ca-source-browser-launch.log']:
        add('drivers/' + name, B / name)
    for p in sorted(O.iterdir()):
        if p.is_file() and p.name != 'status.json':
            add('closing/' + p.name, p)
    add('closing/driver.py', pathlib.Path(__file__))
    expected_zips = {'1627a7cc9936dea9fc93deb172307cb74653e84afd2c953c12723f068f3ffba7', '130c3a1f92db37d223e82b8164d82d67763a1f2ac4d4652c646ad2be3bf6b6d4', '4de5f5edfee7ccbc5292a964a4f1e7fe320bb377dcebe64b7574335bb480fb3c', '59f9d09519caeea18e2702229ca9c77f11d405d4daf7222b2de2d772b713be22', 'c1ea65c90dc45127e6bbc920fe1d7abb42eff646a9a2f510855e3c25ecb38f2d', '39a49360ae5a7447f70785931a0554fb5cabee4b515c17edaf0587799aeb0ecf'}
    assert {sha(p) for p in files.values() if p.suffix == '.zip'} == expected_zips
    slug = '2026-11-23-sprint5-native-part-input-final-acceptance'
    evidence = T / 'internal/records/evidence' / slug
    record = T / 'internal/records' / (slug + '.md')
    assert not evidence.exists() and not record.exists()
    evidence.mkdir()
    archives = []
    save('archiving')
    for label, path in sorted(files.items()):
        data = path.read_bytes()
        gz = gzip.compress(data, compresslevel=6, mtime=0)
        dest = evidence / 'raw' / (label + '.gz')
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(gz)
        assert gzip.decompress(dest.read_bytes()) == data and path.read_bytes() == data
        archives.append({'logicalPath': label, 'originalPath': str(path), 'path': str(dest.relative_to(T)), 'rawBytes': len(data), 'rawSha256': digest(data), 'gzipBytes': len(gz), 'gzipSha256': digest(gz)})
    manifest = {'schemaVersion': 1, 'kind': 'exact-source-final-formal-acceptance-and-record-only-publication', 'executedHead': H, 'executedTree': TREE, 'run': 45282014115, 'runConclusion': 'success', 'canonical': {'passed': 20, 'total': 20}, 'sourceControls': {'files': 44, 'passed': 778, 'total': 778}, 'native': native_readback['native'], 'sourceTreeManifest': map_data['entriesSha256'], 'sourceTreeEntryCount': map_data['entryCount'], 'archiveCount': len(archives), 'rawBytes': sum(x['rawBytes'] for x in archives), 'gzipBytes': sum(x['gzipBytes'] for x in archives), 'originalHostedZipCount': 6, 'entries': archives}
    manifest_path = evidence / 'manifest.json'
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    text = packet['template']['content']
    for key, value in {'@@RAW_COUNT@@': str(len(archives)), '@@RAW_BYTES@@': f"{manifest['rawBytes']:,}", '@@ARCHIVE_BYTES@@': f"{manifest['gzipBytes']:,}"}.items():
        text = text.replace(key, value)
    assert '@@' not in text
    record.write_text(text)
    docs = [str(p.relative_to(T)) for p in [record, manifest_path]]
    run('format-records', ['corepack', 'pnpm@10.32.1', 'exec', 'prettier', '--write', *docs], timeout=120)
    run('format-check', ['corepack', 'pnpm@10.32.1', 'exec', 'prettier', '--check', *docs], timeout=120)
    run('diff-check', ['git', 'diff', '--check'], timeout=30)
    stage_paths = [*docs, *[a['path'] for a in archives]]
    assert all(p.startswith('internal/records/') for p in stage_paths)
    assert sorted(git('ls-files', '--others', '--exclude-standard').splitlines()) == sorted(stage_paths)
    assert git('diff', '--name-only') == '' and git('diff', '--cached', '--name-only') == ''
    for a in archives:
        original = pathlib.Path(a['originalPath']).read_bytes()
        packed = (T / a['path']).read_bytes()
        assert digest(original) == a['rawSha256'] and digest(packed) == a['gzipSha256'] and gzip.decompress(packed) == original
    run('stage', ['git', 'add', '--', *stage_paths], timeout=120)
    assert sorted(git('diff', '--cached', '--name-only').splitlines()) == sorted(stage_paths)
    run('staged-diff-check', ['git', 'diff', '--cached', '--check'], timeout=30)
    prepared = git('write-tree')
    assert source_tree(prepared) == entries_before
    hashes = {p: sha(T / p) for p in stage_paths}
    S.update({'preparedTree': prepared, 'sourceTreeEntriesSha256': map_data['entriesSha256'], 'sourceTreeEntryCount': map_data['entryCount'], 'sourceUnchanged': True, 'stagePaths': stage_paths, 'archiveCount': len(archives), 'rawBytes': manifest['rawBytes'], 'gzipBytes': manifest['gzipBytes'], 'manifestSha256': sha(manifest_path), 'recordSha256': sha(record)})
    save('prepared')
    assert git('config', '--get', 'core.hooksPath') == '.husky/_' and os.access(T / '.husky/_/pre-commit', os.X_OK) and os.access(T / '.husky/_/h', os.R_OK)
    message = O / 'message.txt'
    message.write_text('docs: retain final Sprint 5 source-bound acceptance\n\nKeep the original 25ca hosted browser, source, production and native\nreceipts with digest-verified artifacts and explicit record-only source\nequivalence. Preserve the earlier failures and the review boundary.\n')
    S['commitAttempted'] = True
    save('committing')
    run('commit', ['git', 'commit', '--signoff', '--file', str(message)], timeout=900, trace=True)
    assert git('rev-parse', 'HEAD^{tree}') == prepared and git('status', '--porcelain=v1') == ''
    assert source_tree('HEAD') == entries_before and all(sha(T / p) == value for p, value in hashes.items())
    assert all(p.startswith('internal/records/') for p in git('diff', '--name-only', H, 'HEAD').splitlines())
    events = [json.loads(line) for line in (O / 'commit.trace.jsonl').read_text().splitlines()]
    hooks = [event for event in events if event.get('event') == 'child_start' and event.get('hook_name') == 'pre-commit']
    assert len(hooks) == 1 and any(event.get('event') == 'child_exit' and event.get('sid') == hooks[0]['sid'] and event.get('child_id') == hooks[0]['child_id'] and event.get('code') == 0 for event in events)
    S.update({'finalHead': git('rev-parse', 'HEAD'), 'finalTree': prepared, 'clean': True, 'sourceUnchanged': True, 'artifactBytesStable': True, 'preCommitEvents': hooks, 'finishedAt': now()})
    save('committed')
except BaseException as error:
    S['error'] = repr(error)
    S['traceback'] = traceback.format_exc()
    S['failedAt'] = now()
    try:
        S['observedHeadOnFailure'] = git('rev-parse', 'HEAD')
    except BaseException:
        pass
    save('failed')
    raise
