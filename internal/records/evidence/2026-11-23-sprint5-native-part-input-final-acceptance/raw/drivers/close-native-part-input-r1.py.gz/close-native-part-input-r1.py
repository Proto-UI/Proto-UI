#!/usr/bin/env python3
import pathlib,os,subprocess,json,hashlib,datetime,traceback,gzip,base64,fcntl
T=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a');B=pathlib.Path(str(T)+'-ops')
D=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-ea600-browser-diag-75d5e28a-ops')
R=pathlib.Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a-ops')
O=B/'native-part-input-closeout-r1'
lock=(B/'native-part-input-closeout-r1.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
O.mkdir(exist_ok=False)
E=dict(os.environ);E['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+E.get('PATH','');E['TMPDIR']='/var/tmp/s5g75d5';assert E.get('HUSKY')!='0'
H='b8800d4cef9302718d4514b1ba28508860059929';A='ea60064882924eb455e1dfc3ff7de55a32de4558';MAIN='0fbb52ef832cc27c78e24c28c59a55a16f51d7fe'
SOURCE={'packages/adapters/web-component/src/runtime/modules.ts':'4406d1a05d0249635250457562a843e0ed247eb2855c5abdcc4ed76bcf8c5bfa','packages/adapters/web-component/test/focus-entry-input-origin.test.ts':'63f88eb9770d99e338bb64ff6f4105bf4bad1e1f735de3eb987fd464dc16acd4'}
S={'phase':'initial','pid':os.getpid(),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[],'pushAttempted':False,'dispatchAttempted':False}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(b):return hashlib.sha256(b).hexdigest()
def sha(p):return digest(pathlib.Path(p).read_bytes())
def save(phase=None):
 if phase:S['phase']=phase
 (O/'status.json').write_text(json.dumps(S,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=T,env=E,text=True,timeout=90).strip()
def run(name,args,timeout=900,trace=False):
 save(name);(O/(name+'.command.json')).write_text(json.dumps({'argv':args,'cwd':str(T),'timeoutSeconds':timeout},indent=2)+'\n');env=dict(E)
 if trace:env['GIT_TRACE2_EVENT']=str(O/(name+'.trace.jsonl'))
 with (O/(name+'.log')).open('wb') as out:
  child=subprocess.Popen(args,cwd=T,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True);S['childPid']=child.pid;save()
  try:code=child.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   import signal
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10)
   raise
 S.pop('childPid',None);S['commands'].append({'name':name,'argv':args,'exitCode':code});save();assert code==0,(name,code)
def read(p):return json.loads(pathlib.Path(p).read_text())
try:
 assert git('rev-parse','HEAD')==H and git('branch','--show-current')=='codex/sprint5-input-75d5e28a'
 assert sorted(git('diff','--name-only').splitlines())==sorted(SOURCE) and not git('diff','--cached','--name-only') and not git('ls-files','--others','--exclude-standard')
 assert all(sha(T/p)==v for p,v in SOURCE.items())
 ab=read(B/'pseudo-input-identity-r1/status.json');assert ab['phase']=='candidate-tested-not-committed' and ab['baseHead']==H and ab['sourceAfter']==SOURCE and ab['originalTestPrefixUnchanged']
 assert ab['red']['numPassedTests']==26 and ab['red']['numFailedTests']==34 and ab['green']['numPassedTests']==60 and ab['green']['numFailedTests']==0
 assert sha(B/'pseudo-input-identity-r1/old-helper-new-controls.json')=='6922df095231701e87a821d8a1d175bec1fca021b280251c1b802c64779f4a68'
 assert sha(B/'pseudo-input-identity-r1/new-helper-same-controls.json')=='0d9c4458c19440504783323d9a295010d1534960a8ca6fb4fd1290c6702717c7'
 profile=read(D/'profile-original-fill-r1/status.json');assert profile['diagnosticState']=='captured' and profile['canonicalAcceptance'] is False and profile['sourceStable'] and profile['originalReceiptBindingVerified']
 assert profile['originalRunnerReceipt']['passed']==17 and profile['originalRunnerReceipt']['caseCount']==20 and profile['observation']['browserClosed'] and profile['originalRunnerReceipt']['serviceClosed']
 survey=read(D/'listener-style-survey-r1/inventory-readback.json')
 assert survey['survey']['browserClosed'] and survey['survey']['serviceClosed'] and survey['survey']['sourceStable'] and survey['survey']['distStable']
 assert survey['listeners']['summary']['matchingXu']==21 and survey['listeners']['allTargetsDoNotContainEditor']
 assert len(survey['listeners']['targetShortIdentityGroups'])==2
 classification=read(D/'listener-style-survey-r1/helper-classification.json')
 assert classification['summary']['oldHits']==23 and classification['summary']['candidateHits']==0 and classification['summary']['changedRules']==23 and classification['remaining']==[]
 assert classification['sources']['candidate']['sha256']==SOURCE['packages/adapters/web-component/src/runtime/modules.ts']
 assert not classification['cssom']['errors']
 assert read(B/'formal-ea600-source-browser/status.json')['phase']=='custody-verified'
 native=read(B/'formal-ea600-native/status.json');assert native['phase']=='artifacts-verified' and len(native['jobs'])==3
 assert all(j['finalObservedConclusion']=='success' and j['sourceSha']==A for j in native['jobs'])
 production=read(R/'final-ea600-production/root-readback.json');assert production['source']==A and production['replayReturncode']==0 and production['replay']['issues']==[] and production['originalGateControls']['pass']==2150
 zipExpected={'2628d370297cb1fac053f57d972cae23c06a599e3d4a69f8f2f6943cb22ae664','6ef201a56dd18ce12a0eabd5b6bfa86592ec92cbdf4ab33400563b88f4ecdfb6','d8de6c994285019604a660186c56345f7dbc1d046aefb3d9d806c0e78df901bd','61a8b51b17c015923e6e97777394e073b71a903cc899af6b128a4f6163918bd7','9b56c4470458c16fb6e61f98b05d156409f676d601d3605f802a5e985fedda57','acee4d22c294ee1f4d5aee28601be58a659334edf24576f9b0912c6ca35d92ad'}
 packetGz=base64.b64decode((B/'native-part-archive-packet.json.gz.b64').read_text())
 assert digest(packetGz)=='226b1ff8f89bd3e445611d1b154a93af0ee81f38f7438338a642aa6815dc4f48'
 packetRaw=gzip.decompress(packetGz);assert digest(packetRaw)=='462a14a9b2119c93cf08d2c8da728413a02f6c4631e2b663f81ddd6e56abfc93'
 packet=json.loads(packetRaw);(O/'primary-packet-original.json.gz').write_bytes(packetGz)
 for entry in packet['entries']:
  rel=pathlib.PurePosixPath(entry['logicalPath']);assert not rel.is_absolute() and '..' not in rel.parts
  raw=entry['content'].encode();assert len(raw)==entry['bytes'] and digest(raw)==entry['sha256']
  out=O/'primary'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
 run('authoring',['corepack','pnpm@10.32.1','check:spec-authoring','--','--base',MAIN],timeout=300)
 run('format-source',['corepack','pnpm@10.32.1','exec','prettier','--check',*SOURCE],timeout=90)
 run('source-diff-check',['git','diff','--check'],timeout=30)
 sourceMap={'baseCommit':H,'baseTree':git('rev-parse','HEAD^{tree}'),'hostedExecutedCommit':A,'candidateWorkingTreeSourceSha256':SOURCE,'workingTreeDeltaPaths':git('diff','--name-only').splitlines(),'publicNonRecordDeltaFromExecutedHead':[p for p in git('diff','--name-only',A,H).splitlines() if not p.startswith('internal/records/')],'unchangedTrackedFilesEstablishedByExactTwoPathDiff':True,'criticalTrackedInputs':{}}
 for p in ['.github/workflows/compiler-browser-acceptance.yml','.github/workflows/compiler-gpui-source-consumers.yml','pnpm-lock.yaml','package.json','scripts/analysis/browser-compiler-browser.mts','scripts/compiler/browser-production.mjs','apps/www/src/components/PrototypePreviewer/browser-compiler-panel.ts','apps/www/src/components/PrototypePreviewer/compiled-revision-session.ts','apps/www/src/components/PrototypePreviewer/compiled-preview-sandbox.ts']:
  sourceMap['criticalTrackedInputs'][p]={'baseGitBlob':git('rev-parse',H+':'+p),'workingTreeSha256':sha(T/p)}
 (O/'source-map.json').write_text(json.dumps(sourceMap,indent=2)+'\n')
 (O/'closing-validation.json').write_text(json.dumps({'commands':S['commands'],'sourceBefore':SOURCE,'sourceAfter':{p:sha(T/p) for p in SOURCE},'head':H,'onlyChangedSourcePaths':git('diff','--name-only').splitlines()},indent=2)+'\n')
 files={}
 def add(label,p):
  p=pathlib.Path(p);assert p.is_file() and not p.is_symlink(),str(p);assert '.private.' not in label and 'transfer-links' not in label
  if label in files:assert files[label]==p
  files[label]=p
 def addDir(label,p,recursive=True):
  p=pathlib.Path(p);assert p.is_dir(),str(p)
  for f in sorted(p.rglob('*') if recursive else p.iterdir()):
   if f.is_file():add(label+'/'+str(f.relative_to(p)),f)
 addDir('hosted/native',B/'formal-ea600-native',False)
 addDir('hosted/source-browser',B/'formal-ea600-source-browser',False)
 addDir('hosted/production',R/'final-ea600-production')
 addDir('diagnostic/profile',D/'profile-original-fill-r1')
 addDir('diagnostic/survey',D/'listener-style-survey-r1')
 for name in ['static-css-input-state','static-css-input-state-v2','static-css-input-state-v3']:addDir('diagnostic/'+name,D/name)
 for p in sorted(D.iterdir()):
  if p.is_file() and p.suffix in ['.py','.cjs','.mjs','.json','.log']:add('diagnostic/drivers/'+p.name,p)
 for entry in survey['files']:
  p=pathlib.Path(entry['path']);assert p.is_relative_to(D) and sha(p)==entry['sha256'] and p.stat().st_size==entry['bytes']
  if p.parent==D:add('diagnostic/drivers/'+p.name,p)
 addDir('candidate/ab',B/'pseudo-input-identity-r1')
 for name in ['pseudo-input-identity-candidate-v1.json','pseudo-input-identity-ab-v1.py','pseudo-input-identity-ab-v1.log','collect-ea600-native.py','collect-ea600-source-browser-custody-v1.py','collect-ea600-source-browser-custody-v1.log']:add('candidate/drivers/'+name,B/name)
 for name in ['public-12af-final','publish-final-public-union','publish-final-12af-union','dispatch-ea600-after-reconcile']:addDir('publication/'+name,B/name)
 addDir('peer',O/'primary')
 for name in ['source-map.json','closing-validation.json','authoring.log','authoring.command.json','format-source.log','format-source.command.json','source-diff-check.log','source-diff-check.command.json']:add('closing/'+name,O/name)
 add('closing/driver.py',pathlib.Path(__file__))
 zipObserved={sha(p) for p in files.values() if p.suffix=='.zip'}
 assert zipObserved==zipExpected,{'unexpected':list(zipObserved-zipExpected),'missing':list(zipExpected-zipObserved)}
 slug='2026-11-23-sprint5-native-part-input-retirement';evidence=T/'internal/records/evidence'/slug
 recordPaths=[T/'internal/records/2026-11-23-sprint5-ea600-hosted-acceptance.md',T/'internal/records'/ (slug+'.md')]
 assert not evidence.exists() and all(not p.exists() for p in recordPaths);evidence.mkdir()
 entries=[];save('archiving')
 for label,p in sorted(files.items()):
  raw=p.read_bytes();gz=gzip.compress(raw,compresslevel=6,mtime=0);out=evidence/'raw'/(label+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gz)
  assert gzip.decompress(out.read_bytes())==raw and p.read_bytes()==raw
  entries.append({'logicalPath':label,'originalPath':str(p),'path':str(out.relative_to(T)),'rawBytes':len(raw),'rawSha256':digest(raw),'gzipBytes':len(gz),'gzipSha256':digest(gz)})
 manifest={'schemaVersion':1,'kind':'failed-hosted-acceptance-diagnostic-causality-and-bounded-native-part-repair','hostedHead':A,'hostedRun':45271472592,'hostedOverallConclusion':'failure','candidateBaseHead':H,'candidateBaseTree':git('rev-parse','HEAD^{tree}'),'candidateSourceSha256':SOURCE,'originalFormalCanonical':{'passed':17,'total':20},'diagnosticCanonical':{'passed':17,'total':20,'acceptance':False},'hostModelOld':ab['red'],'hostModelCandidate':ab['green'],'liveCssomClassification':classification['summary'],'archiveCount':len(entries),'rawBytes':sum(x['rawBytes'] for x in entries),'gzipBytes':sum(x['gzipBytes'] for x in entries),'uniqueOriginalHostedZipCount':len(zipObserved),'entries':entries}
 m=evidence/'manifest.json';m.write_text(json.dumps(manifest,indent=2)+'\n')
 replacements={'@@RAW_COUNT@@':str(len(entries)),'@@RAW_BYTES@@':f"{manifest['rawBytes']:,}",'@@ARCHIVE_BYTES@@':f"{manifest['gzipBytes']:,}"}
 for key,path in zip(['formal','candidate'],recordPaths):
  text=packet['templates'][key]
  for k,v in replacements.items():text=text.replace(k,v)
  assert '@@' not in text;path.write_text(text)
 docs=[str(p.relative_to(T)) for p in [*recordPaths,m]]
 run('format-records',['corepack','pnpm@10.32.1','exec','prettier','--write',*docs],timeout=120)
 run('format-final',['corepack','pnpm@10.32.1','exec','prettier','--check',*SOURCE,*docs],timeout=120)
 run('diff-check',['git','diff','--check'],timeout=30)
 manifest=read(m)
 for e in manifest['entries']:
  raw=pathlib.Path(e['originalPath']).read_bytes();packed=(T/e['path']).read_bytes()
  assert len(raw)==e['rawBytes'] and digest(raw)==e['rawSha256'] and digest(packed)==e['gzipSha256'] and gzip.decompress(packed)==raw
 assert all(sha(T/p)==v for p,v in SOURCE.items())
 artifacts=[*docs,*[e['path'] for e in entries]];stagePaths=[*SOURCE,*artifacts]
 assert sorted(git('ls-files','--others','--exclude-standard').splitlines())==sorted(artifacts)
 assert sorted(git('diff','--name-only').splitlines())==sorted(SOURCE) and not git('diff','--cached','--name-only')
 run('stage',['git','add','--',*stagePaths],timeout=120)
 assert sorted(git('diff','--cached','--name-only').splitlines())==sorted(stagePaths)
 run('staged-diff-check',['git','diff','--cached','--check'],timeout=60)
 prepared=git('write-tree');artifactHashes={p:sha(T/p) for p in artifacts}
 S.update({'sourceBefore':SOURCE,'sourceBase':H,'preparedTree':prepared,'archiveCount':len(entries),'rawBytes':manifest['rawBytes'],'gzipBytes':manifest['gzipBytes'],'stagePaths':stagePaths,'manifestSha256':sha(m),'recordSha256':{str(p.relative_to(T)):sha(p) for p in recordPaths},'stagedNonRecordPaths':[p for p in git('diff','--cached','--name-only').splitlines() if not p.startswith('internal/records/')]});save('prepared')
 assert S['stagedNonRecordPaths']==sorted(SOURCE)
 assert git('config','--get','core.hooksPath')=='.husky/_' and os.access(T/'.husky/_/pre-commit',os.X_OK) and os.access(T/'.husky/_/h',os.R_OK)
 message=O/'message.txt';message.write_text('fix(wc): avoid foreign input scans for native control parts\n\nClassify only the observed native pseudo-element identities as input-state\nindependent while preserving synchronous state and unknown-selector guards.\nRetain the actual 34-counterexample red, the same 60 passing controls, and\nsource-bound hosted failure, profile, CSSOM and concurrency evidence.\n')
 S['commitAttempted']=True;save('committing')
 run('commit',['git','commit','--signoff','--file',str(message)],timeout=900,trace=True)
 assert git('rev-parse','HEAD^{tree}')==prepared and git('status','--porcelain=v1')==''
 events=[json.loads(l) for l in (O/'commit.trace.jsonl').read_text().splitlines()]
 hooks=[e for e in events if e.get('event')=='child_start' and e.get('hook_name')=='pre-commit'];assert len(hooks)==1
 assert any(e.get('event')=='child_exit' and e.get('child_id')==hooks[0]['child_id'] and e.get('code')==0 for e in events)
 assert all(sha(T/p)==v for p,v in SOURCE.items()) and all(sha(T/p)==v for p,v in artifactHashes.items())
 assert sorted([p for p in git('diff','--name-only',H,'HEAD').splitlines() if not p.startswith('internal/records/')])==sorted(SOURCE)
 S.update({'finalHead':git('rev-parse','HEAD'),'finalTree':git('rev-parse','HEAD^{tree}'),'clean':True,'sourceAfter':{p:sha(T/p) for p in SOURCE},'preCommitEvents':hooks,'artifactBytesStable':True,'finishedAt':now()});save('committed')
except BaseException as ex:
 S['error']=repr(ex);S['traceback']=traceback.format_exc();S['failedAt']=now()
 try:S['observedHeadOnFailure']=git('rev-parse','HEAD')
 except BaseException:pass
 save('failed');raise
