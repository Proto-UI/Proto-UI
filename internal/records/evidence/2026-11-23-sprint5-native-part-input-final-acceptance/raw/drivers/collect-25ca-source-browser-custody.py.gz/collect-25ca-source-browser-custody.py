#!/usr/bin/env python3
import pathlib,os,subprocess,json,datetime,hashlib,traceback,zipfile,stat,shutil
T=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
B=pathlib.Path(str(T)+'-ops'); O=B/'formal-25ca-source-browser'
O.mkdir(exist_ok=False)
H='25ca6fcaecd917457f6f3d694b3e12bfb522e89a'; RUN=45282014115; REPO='Proto-UI/Proto-UI'
E=dict(os.environ); E['TMPDIR']='/var/tmp/s5g75d5'
S={'phase':'initial','head':H,'run':RUN,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'crossDeviceCustodyCopy':True,'executedTests':False,'modifiedSources':False,'jobs':[]}
def save(phase=None):
 if phase:S['phase']=phase
 (O/'status.json').write_text(json.dumps(S,indent=2)+'\n')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def gh(name,endpoint,binary=False):
 save('copying-'+name); p=O/name
 with p.open('wb') as out:
  r=subprocess.run(['gh','api',endpoint],cwd=T,env=E,stdout=out,stderr=subprocess.PIPE,timeout=180)
 (O/(name+'.stderr')).write_bytes(r.stderr)
 assert r.returncode==0,(name,r.returncode,r.stderr.decode(errors='replace'))
 return p if binary else json.loads(p.read_text())
def entry(p,base=O):
 return {'path':str(p.relative_to(base)),'bytes':p.stat().st_size,'sha256':digest(p)}
try:
 peer=B/'formal-25ca-source-browser-peer.json'
 assert digest(peer)=='073eb44a1a4d0f7d80953809b92d8864d2edfcbb728c99602adb23c73c8b06ea'
 shutil.copyfile(peer,O/'formal-source-browser-readback.json')
 S['peerReadback']=entry(O/'formal-source-browser-readback.json')
 run=gh('run.json','repos/'+REPO+'/actions/runs/'+str(RUN))
 assert run['head_sha']==H and run['status']=='completed' and run['conclusion']=='success'
 artifacts=gh('artifacts.json','repos/'+REPO+'/actions/runs/'+str(RUN)+'/artifacts?per_page=100')['artifacts']
 expected=[
 ('browser',138068627546,'success',14869886909,2019065,'59f9d09519caeea18e2702229ca9c77f11d405d4daf7222b2de2d772b713be22',1058929,'034cd96b07a5018b19432405bb858d144097017a25fc715624e01f2de0002171'),
 ('source',138068627534,'success',14869222809,103564,'c1ea65c90dc45127e6bbc920fe1d7abb42eff646a9a2f510855e3c25ecb38f2d',1011452,'b2c6104288ef00d10cb11056ede0704f51905c41cd0f82e56dabfe0a49d4389c')]
 for key,jid,conclusion,aid,zsize,zsha,lsize,lsha in expected:
  meta=gh(key+'-job.json','repos/'+REPO+'/actions/jobs/'+str(jid))
  assert meta['run_id']==RUN and meta['status']=='completed' and meta['conclusion']==conclusion
  matches=[a for a in artifacts if a['id']==aid]
  assert len(matches)==1; a=matches[0]
  assert not a['expired'] and a['workflow_run']['head_sha']==H
  z=gh(key+'-artifact.zip','repos/'+REPO+'/actions/artifacts/'+str(aid)+'/zip',True)
  assert z.stat().st_size==zsize==a['size_in_bytes']
  assert digest(z)==zsha and a['digest']=='sha256:'+zsha
  log=gh(key+'-job-original.log','repos/'+REPO+'/actions/jobs/'+str(jid)+'/logs',True)
  assert log.stat().st_size==lsize and digest(log)==lsha,(key,entry(log),'expected',lsize,lsha)
  extracted=O/(key+'-artifact'); extracted.mkdir()
  with zipfile.ZipFile(z) as archive:
   assert archive.testzip() is None
   for item in archive.infolist():
    p=pathlib.PurePosixPath(item.filename)
    assert not p.is_absolute() and '..' not in p.parts and not stat.S_ISLNK(item.external_attr>>16)
   archive.extractall(extracted)
  shaFiles=list(extracted.rglob('source-sha.txt'))
  assert len(shaFiles)==1 and shaFiles[0].read_text().strip()==H
  files=sorted([p for p in extracted.rglob('*') if p.is_file()])
  S['jobs'].append({'key':key,'jobId':jid,'conclusion':conclusion,'artifactId':aid,'sourceSha':H,'zip':entry(z),'originalJobLog':entry(log),'extracted':[entry(p) for p in files]})
  save()
 S['extractedFileCount']=sum(len(j['extracted']) for j in S['jobs'])
 S['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 S['summary']='Original hosted artifact and job-log bytes copied across devices and checked against independently retained primary originals. No test/build/browser execution.'
 save('custody-verified')
except BaseException as ex:
 S['error']=repr(ex);S['traceback']=traceback.format_exc();save('failed');raise
