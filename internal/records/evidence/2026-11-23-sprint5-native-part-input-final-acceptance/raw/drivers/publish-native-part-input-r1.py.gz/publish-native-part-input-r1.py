#!/usr/bin/env python3
import pathlib, os, json, subprocess, datetime, time, traceback, fcntl, hashlib

T = pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
B = pathlib.Path(str(T) + '-ops')
O = B / 'publish-native-part-input-r1'
lock = (B / 'publish-native-part-input-r1.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
O.mkdir(exist_ok=False)
E = dict(os.environ)
E['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:' + E.get('PATH', '')
E['TMPDIR'] = '/var/tmp/s5g75d5'
assert E.get('HUSKY') != '0'
repo = 'Proto-UI/Proto-UI'
branch = 'fix/sprint5-preview-input-bundle-20261123-75d5'
expected_remote = 'b8800d4cef9302718d4514b1ba28508860059929'
expected_main = '0fbb52ef832cc27c78e24c28c59a55a16f51d7fe'
endpoint = 'repos/' + repo + '/actions/workflows/compiler-gpui-source-consumers.yml/runs?event=workflow_dispatch&branch=' + branch + '&per_page=30'
S = {'phase': 'initial', 'pid': os.getpid(), 'commands': [], 'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pushAttempted': False, 'dispatchAttempted': False}

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(phase=None):
    if phase:
        S['phase'] = phase
    (O / 'status.json').write_text(json.dumps(S, indent=2) + '\n')

def run(name, argv, timeout=180):
    save(name)
    (O / (name + '.command.json')).write_text(json.dumps({'argv': argv, 'cwd': str(T), 'timeoutSeconds': timeout}, indent=2) + '\n')
    with (O / (name + '.log')).open('wb') as out:
        result = subprocess.run(argv, cwd=T, env=E, stdout=out, stderr=subprocess.STDOUT, timeout=timeout)
    S['commands'].append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    save()
    assert result.returncode == 0, (name, result.returncode)
    return (O / (name + '.log')).read_text()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=T, env=E, text=True, timeout=90).strip()

def api(name, path):
    return json.loads(run(name, ['gh', 'api', path]))

try:
    receipt = json.loads((B / 'native-part-input-closeout-r1/status.json').read_text())
    assert receipt['phase'] == 'committed' and receipt['clean'] and receipt['artifactBytesStable']
    head = receipt['finalHead']
    assert git('rev-parse', 'HEAD') == head and git('rev-parse', 'HEAD^{tree}') == receipt['preparedTree']
    assert git('branch', '--show-current') == 'codex/sprint5-input-75d5e28a' and git('status', '--porcelain=v1') == ''
    assert all(hashlib.sha256((T / p).read_bytes()).hexdigest() == h for p, h in receipt['sourceAfter'].items())
    assert receipt['sourceBase'] == expected_remote and receipt['preCommitEvents']
    S.update({'head': head, 'tree': receipt['preparedTree'], 'sourceSha256': receipt['sourceAfter'], 'expectedRemote': expected_remote, 'expectedMain': expected_main})
    pr = api('pr-before', 'repos/' + repo + '/pulls/1738')
    assert pr['state'] == 'open' and not pr['merged'] and pr['draft'] and pr['head']['ref'] == branch and pr['head']['sha'] == expected_remote, 'fresh PR differs: preserve concurrent work before publication'
    main = api('main-before', 'repos/' + repo + '/branches/main')
    S['observedMain'] = main['commit']['sha']
    assert S['observedMain'] == expected_main, 'fresh main needs an actual impact comparison'
    permission = api('repository-permission', 'repos/' + repo)
    assert permission.get('permissions', {}).get('push') is True
    remote = run('remote-before', ['git', 'ls-remote', 'origin', 'refs/heads/' + branch]).split()[0]
    assert remote == expected_remote
    run('remote-ancestry', ['git', 'merge-base', '--is-ancestor', remote, head])
    run('main-ancestry', ['git', 'merge-base', '--is-ancestor', expected_main, head])
    S['pushAttempted'] = True
    S['pushAttemptStartedAt'] = now()
    save('push-attempt-pending')
    run('push', ['git', 'push', 'origin', 'HEAD:refs/heads/' + branch], timeout=900)
    S['pushCommandSucceeded'] = True
    save('push-succeeded-reconciling-readback')
    observed_remote = run('remote-after', ['git', 'ls-remote', 'origin', 'refs/heads/' + branch]).split()[0]
    assert observed_remote == head, 'remote advanced after push; reconcile without repeating push'
    post = None
    for index in range(10):
        post = api('pr-after-' + str(index), 'repos/' + repo + '/pulls/1738')
        assert post['state'] == 'open' and post['draft']
        if post['head']['sha'] == head:
            break
        assert post['head']['sha'] == expected_remote, 'concurrent public head requires reconciliation'
        time.sleep(3)
    assert post['head']['sha'] == head, 'push succeeded but API readback still stale; do not repeat push'
    S.update({'publishedHead': head, 'publishedDraft': True})
    save('published')
    before = api('runs-before-dispatch', endpoint)
    matching = [r for r in before['workflow_runs'] if r['head_sha'] == head]
    if matching:
        S['existingRunNeedsInputConfirmation'] = True
        S['runs'] = [{k: r.get(k) for k in ['id', 'html_url', 'head_sha', 'event', 'status', 'conclusion']} for r in matching]
        save('existing-exact-head-run-awaiting-input-confirmation')
    else:
        current = api('pr-before-dispatch', 'repos/' + repo + '/pulls/1738')
        assert current['state'] == 'open' and current['draft'] and current['head']['sha'] == head
        inputs = {'browser_acceptance': 'true', 'adapter_acceptance': 'false', 'package_budget_evidence': 'false', 'website_shader_evidence': 'false'}
        S.update({'dispatchInputs': inputs, 'dispatchAttempted': True, 'dispatchAttemptStartedAt': now()})
        save('dispatch-attempt-pending')
        command = ['gh', 'workflow', 'run', 'compiler-gpui-source-consumers.yml', '--repo', repo, '--ref', branch]
        for key, value in inputs.items():
            command += ['-f', key + '=' + value]
        run('dispatch', command)
        S['dispatchIssued'] = True
        save('dispatch-issued-awaiting-readback')
        for index in range(10):
            time.sleep(3)
            runs = api('runs-readback-' + str(index), endpoint)
            matching = [r for r in runs['workflow_runs'] if r['head_sha'] == head]
            if matching:
                assert len(matching) == 1, 'multiple exact-head runs need reconciliation'
                S['run'] = {k: matching[0].get(k) for k in ['id', 'html_url', 'head_sha', 'event', 'status', 'conclusion']}
                save('dispatched-exact-head')
                break
    S['finishedAt'] = now()
    save()
except BaseException as error:
    S['error'] = repr(error)
    S['traceback'] = traceback.format_exc()
    S['failedAt'] = now()
    save('failed')
    raise
