#!/usr/bin/env python3
import pathlib,os,subprocess,json,datetime,hashlib,traceback,zipfile,re,stat
T=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a');B=pathlib.Path(str(T)+'-ops');O=B/'formal-25ca-native';O.mkdir(exist_ok=False)
E=dict(os.environ);E['TMPDIR']='/var/tmp/s5g75d5'
H='25ca6fcaecd917457f6f3d694b3e12bfb522e89a';RUN=45282014115;REPO='Proto-UI/Proto-UI'
S={'phase':'initial','head':H,'run':RUN,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'jobs':[]}
def save(p=None):
 if p:S['phase']=p
 (O/'status.json').write_text(json.dumps(S,indent=2)+'\n')
def gh(n,path,binary=False):
 save(n);p=O/n
 with p.open('wb') as out:
  r=subprocess.run(['gh','api',path],cwd=T,env=E,stdout=out,stderr=subprocess.PIPE,timeout=180)
 (O/(n+'.stderr')).write_bytes(r.stderr);assert r.returncode==0,(n,r.returncode,r.stderr.decode(errors='replace'))
 return p if binary else json.loads(p.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 run=gh('run-before.json','repos/'+REPO+'/actions/runs/'+str(RUN));assert run['head_sha']==H
 arts=gh('artifacts.json','repos/'+REPO+'/actions/runs/'+str(RUN)+'/artifacts?per_page=100')['artifacts']
 jobs=[('linux',138068627417,'compiler-gpui-source-Linux-'),('macos',138068627481,'compiler-gpui-source-macOS-'),('flutter',138068627114,'compiler-flutter-scroll-')]
 logs={'ordinary':'consumer.log','controlLabel':'control-label-consumer.log','officialInput':'official-control-label-consumer.log','style':'style-mapping-consumer.log','a11yActivation':'a11y-activation-consumer.log','numeric':'numeric-consumer.log','scrollPause':'scroll-pause-consumer.log','scrollReader':'scroll-reader-consumer.log','sdk':'native-sdk-controls.log'}
 for key,jid,prefix in jobs:
  meta=gh(key+'-job-before.json','repos/'+REPO+'/actions/jobs/'+str(jid));assert meta['run_id']==RUN and meta['status']=='completed'
  exact=prefix+H+'-'+str(RUN);matches=[a for a in arts if a['name']==exact];assert len(matches)==1
  a=matches[0];assert a['workflow_run']['head_sha']==H and not a['expired']
  z=gh(key+'.zip','repos/'+REPO+'/actions/artifacts/'+str(a['id'])+'/zip',True);rawSha=digest(z)
  assert z.stat().st_size==a['size_in_bytes'] and a['digest']=='sha256:'+rawSha
  extracted=O/'extracted'/key;extracted.mkdir(parents=True)
  with zipfile.ZipFile(z) as archive:
   assert archive.testzip() is None
   for entry in archive.infolist():
    p=pathlib.PurePosixPath(entry.filename);assert not p.is_absolute() and '..' not in p.parts and not stat.S_ISLNK(entry.external_attr>>16)
   archive.extractall(extracted)
   names=archive.namelist()
  shaFiles=list(extracted.rglob('source-sha.txt'));assert len(shaFiles)==1 and shaFiles[0].read_text().strip()==H
  result={'key':key,'jobId':jid,'observedStatus':meta['status'],'observedConclusion':meta['conclusion'],'artifact':a,'zipSha256':rawSha,'zipBytes':z.stat().st_size,'zipMembers':len(names),'sourceSha':H,'entries':[]}
  result['sourceTreeFiles']=[{'path':str(p.relative_to(extracted)),'value':p.read_text().strip()} for p in extracted.rglob('source-tree.txt')]
  for item in result['sourceTreeFiles']:assert item['value']=='45c5e08bc7a773e3534fd4b07dc66ea437c73c46'
  if key!='flutter':
   counts={}
   for label,name in logs.items():
    p=extracted/name
    if not p.exists():
     counts[label]={'missing':True};continue
    text=p.read_text();results=[]
    for match in re.finditer(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text):
     results.append(dict(zip(['outcome','passed','failed','ignored','measured','filtered'],[match[1],*[int(match[i]) for i in range(2,7)]])))
    counts[label]={'rawSha256':digest(p),'rawBytes':p.stat().st_size,'results':results}
   result['nativeTargets']=counts
  else:
   reports=[p for p in extracted.rglob('*.json') if p.name in ['vitest.json','flutter-widgets.json','flutter-acceptance.json','flutter-sdk-identity.json']]
   result['reportPaths']=[str(p.relative_to(extracted)) for p in reports]
   v=[p for p in reports if p.name=='vitest.json'];assert len(v)==1
   data=json.loads(v[0].read_text());result['vitest']={k:data.get(k) for k in ['success','numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests']}
  final=gh(key+'-job-after.json','repos/'+REPO+'/actions/jobs/'+str(jid));result['finalObservedStatus']=final['status'];result['finalObservedConclusion']=final['conclusion']
  if final['status']=='completed':
   log=gh(key+'-job.log','repos/'+REPO+'/actions/jobs/'+str(jid)+'/logs',True);result['jobLog']={'path':str(log),'bytes':log.stat().st_size,'sha256':digest(log)}
  result['entries']=[{'path':str(p.relative_to(extracted)),'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(extracted.rglob('*')) if p.is_file()]
  S['jobs'].append(result);save()
 S['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save('artifacts-verified')
except BaseException as ex:
 S['error']=repr(ex);S['traceback']=traceback.format_exc();save('failed');raise
