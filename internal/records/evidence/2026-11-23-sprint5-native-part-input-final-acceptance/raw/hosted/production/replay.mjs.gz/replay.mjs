import fs from 'node:fs';
import {validateWebsiteProductionBundle, collectWebsiteProductionBundleIssues} from './exact-head-bundle-gate.mjs';
const graph=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const issues=collectWebsiteProductionBundleIssues({graph});
const result=validateWebsiteProductionBundle({graph});
console.log(JSON.stringify({issues,result,chunks:graph.chunks.length,modules:graph.modules.length}));
