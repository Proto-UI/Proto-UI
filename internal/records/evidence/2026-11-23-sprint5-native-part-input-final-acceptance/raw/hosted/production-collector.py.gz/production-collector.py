#!/usr/bin/env python3
"""Read one original hosted production artifact and replay its unchanged graph gate."""
from pathlib import Path, PurePosixPath
import datetime
import fcntl
import hashlib
import json
import os
import re
import stat
import subprocess
import traceback
import zipfile

ROOT = Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
OPS = Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a-ops')
OUT = OPS / 'final-25ca-production'
HEAD = '25ca6fcaecd917457f6f3d694b3e12bfb522e89a'
TREE = '45c5e08bc7a773e3534fd4b07dc66ea437c73c46'
RUN, JOB, ARTIFACT = 45282014115, 138068627488, 14870946323
ZIP_SHA = '39a49360ae5a7447f70785931a0554fb5cabee4b515c17edaf0587799aeb0ecf'
NODE = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin/node'
GATE_PATH = 'scripts/coverage-matrices/check-website-production-bundle.mjs'
GATE_SHA = '5cdd0a6b574685c12051fcbe25dac13dc9925cedd746f8c38fbc0198134bcc1a'
lock = (OPS / 'final-25ca-production.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
OUT.mkdir(exist_ok=False)
environment = dict(os.environ, TMPDIR='/var/tmp/s5g75d5', GIT_OPTIONAL_LOCKS='0')
state = {'source': HEAD, 'sourceTree': TREE, 'run': RUN, 'job': JOB, 'artifact': ARTIFACT,
         'pid': os.getpid(), 'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'phase': 'starting', 'downloads': []}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def save(phase):
    state['phase'] = phase
    write('status.json', state)


def gh(name, endpoint, binary=False):
    save('downloading-' + name)
    target = OUT / name
    with target.open('xb') as output:
        result = subprocess.run(['gh', 'api', endpoint], cwd=ROOT, env=environment,
                                stdin=subprocess.DEVNULL, stdout=output,
                                stderr=subprocess.PIPE, timeout=120)
    (OUT / (name + '.stderr')).write_bytes(result.stderr)
    raw = target.read_bytes()
    state['downloads'].append({'file': name, 'endpoint': endpoint, 'exitCode': result.returncode,
                               'bytes': len(raw), 'sha256': digest(raw)})
    save('downloaded-' + name)
    assert result.returncode == 0, (name, result.returncode)
    return target if binary else json.loads(raw)


def git_object(path):
    return subprocess.check_output(['git', 'show', HEAD + ':' + path], cwd=ROOT,
                                   env=environment, timeout=30)


try:
    assert subprocess.check_output(['git', 'rev-parse', HEAD + '^{tree}'], cwd=ROOT,
                                   env=environment, text=True, timeout=30).strip() == TREE
    run = gh('run.json', f'repos/Proto-UI/Proto-UI/actions/runs/{RUN}')
    assert run['head_sha'] == HEAD and run['event'] == 'workflow_dispatch'
    job = gh('job.json', f'repos/Proto-UI/Proto-UI/actions/jobs/{JOB}')
    assert job['run_id'] == RUN and job['status'] == 'completed' and job['conclusion'] == 'success'
    metadata = gh('artifact.json', f'repos/Proto-UI/Proto-UI/actions/artifacts/{ARTIFACT}')
    assert metadata['name'] == f'compiler-production-build-{HEAD}-{RUN}'
    assert metadata['workflow_run']['head_sha'] == HEAD and not metadata['expired']
    assert metadata['digest'] == 'sha256:' + ZIP_SHA and metadata['size_in_bytes'] == 425021
    archive_path = gh('production-artifact.zip', f'repos/Proto-UI/Proto-UI/actions/artifacts/{ARTIFACT}/zip', True)
    assert digest(archive_path.read_bytes()) == ZIP_SHA
    assert archive_path.stat().st_size == metadata['size_in_bytes']
    job_log = gh('production-job.log', f'repos/Proto-UI/Proto-UI/actions/jobs/{JOB}/logs', True)
    extracted = OUT / 'extracted'
    extracted.mkdir()
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        for member in archive.infolist():
            relative = PurePosixPath(member.filename)
            assert not relative.is_absolute() and '..' not in relative.parts
            assert not stat.S_ISLNK(member.external_attr >> 16)
        archive.extractall(extracted)

    def exactly_one(name):
        found = list(extracted.rglob(name))
        assert len(found) == 1, (name, len(found))
        return found[0]

    assert exactly_one('source-sha.txt').read_text().strip() == HEAD
    assert exactly_one('source-tree.txt').read_text().strip() == TREE
    graph_path = exactly_one('proto-ui-bundle-graph.json')
    graph_raw = graph_path.read_bytes()
    graph_sha = digest(graph_raw)
    assert exactly_one('production-graph.sha256').read_text().split()[0] == graph_sha
    build_inputs = []
    for line in exactly_one('build-inputs.sha256').read_text().splitlines():
        expected, relative = line.split(None, 1)
        relative = relative.strip().removeprefix('*')
        assert relative in ('pnpm-lock.yaml', 'apps/www/astro.config.mjs')
        actual = digest(git_object(relative))
        assert actual == expected
        build_inputs.append({'path': relative, 'hostedSha256': expected, 'gitObjectSha256': actual})
    assert {entry['path'] for entry in build_inputs} == {'pnpm-lock.yaml', 'apps/www/astro.config.mjs'}
    gate = git_object(GATE_PATH)
    assert digest(gate) == GATE_SHA
    (OUT / 'exact-head-bundle-gate.mjs').write_bytes(gate)
    replay_source = """import fs from 'node:fs';
import {validateWebsiteProductionBundle, collectWebsiteProductionBundleIssues} from './exact-head-bundle-gate.mjs';
const graph=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const issues=collectWebsiteProductionBundleIssues({graph});
const result=validateWebsiteProductionBundle({graph});
console.log(JSON.stringify({issues,result,chunks:graph.chunks.length,modules:graph.modules.length}));
"""
    (OUT / 'replay.mjs').write_text(replay_source)
    save('replaying-original-graph')
    with (OUT / 'replay.stdout').open('xb') as output, (OUT / 'replay.stderr').open('xb') as error:
        replay = subprocess.run([NODE, 'replay.mjs', str(graph_path)], cwd=OUT, env=environment,
                                stdin=subprocess.DEVNULL, stdout=output, stderr=error, timeout=60)
    assert replay.returncode == 0
    result = json.loads((OUT / 'replay.stdout').read_text())
    assert result['issues'] == [] and graph_path.read_bytes() == graph_raw
    controls_raw = exactly_one('bundle-gate-controls.log').read_text()
    clean_controls = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', controls_raw)
    counts = {}
    for label in ('tests', 'pass', 'fail', 'cancelled', 'skipped', 'todo'):
        values = re.findall(r'(?:#|ℹ)\s*' + label + r'\s+(\d+)', clean_controls)
        assert values, label
        counts[label] = int(values[-1])
    assert counts == {'tests': 2150, 'pass': 2150, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}
    build_log = exactly_one('production-build.log').read_text()
    pages = re.findall(r'(\d+) page\(s\) built', build_log)
    assert len(pages) == 1
    members = [{'file': str(path.relative_to(extracted)), 'bytes': path.stat().st_size,
                'sha256': digest(path.read_bytes())} for path in sorted(extracted.rglob('*')) if path.is_file()]
    report = {'source': HEAD, 'sourceTree': TREE, 'run': RUN, 'job': JOB, 'artifact': ARTIFACT,
              'artifactSha256': ZIP_SHA, 'artifactBytes': archive_path.stat().st_size,
              'graphSha256': graph_sha, 'graphBytes': len(graph_raw), 'gateSourceSha256': GATE_SHA,
              'startedAt': state['startedAt'], 'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'replayReturncode': replay.returncode, 'replay': result,
              'buildInputHashesIndependentlyMatched': len(build_inputs), 'buildInputs': build_inputs,
              'originalBuildLogPageCount': int(pages[0]), 'originalGateControls': counts,
              'originalJobLog': {'bytes': job_log.stat().st_size, 'sha256': digest(job_log.read_bytes())},
              'originalArtifactMembers': members, 'originalHostedJobConclusion': job['conclusion'],
              'scope': 'Hosted build and original artifact readback, plus independent replay of the unmodified emitted graph using the exact source commit gate; no second production build claimed.'}
    write('root-readback.json', report)
    state['readbackSha256'] = digest((OUT / 'root-readback.json').read_bytes())
    state['finishedAt'] = report['finishedAt']
    save('verified')
    print(json.dumps(report, indent=2))
except BaseException as error:
    state['error'] = repr(error)
    state['traceback'] = traceback.format_exc()
    save('failed')
    raise
