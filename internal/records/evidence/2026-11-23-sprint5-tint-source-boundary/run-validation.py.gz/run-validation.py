import datetime,hashlib,json,os,pathlib,signal,subprocess
root=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
ops=root.with_name(root.name+'-ops');out=ops/'style-tint-source-validation'
out.mkdir(parents=True,exist_ok=False)
env=dict(os.environ,CI='1',COREPACK_ENABLE_DOWNLOAD_PROMPT='0',ASTRO_TELEMETRY_DISABLED='1',NODE_OPTIONS='--max-old-space-size=4096')
node_bin='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin'
env['PATH']=node_bin+':'+env['PATH']
files=['scripts/coverage-matrices/check-website-production-bundle.mjs','scripts/coverage-matrices/test/check-website-production-bundle.test.mjs']
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def hashes():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}
def git(*a):return subprocess.check_output(['git',*a],cwd=root,env=env,text=True).strip()
status={'head':git('rev-parse','HEAD'),'state':'running','startedAt':now(),'steps':[]}
def save():(out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def run(name,cmd,timeout,expected=0):
 log=out/(name+'.log');row={'name':name,'command':cmd,'timeoutSeconds':timeout,'expectedExit':expected,'startedAt':now(),'state':'running','log':str(log)};status['steps'].append(row);save()
 with log.open('wb') as f:
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
  try:rc=p.wait(timeout)
  except subprocess.TimeoutExpired:
   row['timedOut']=True
   try:os.killpg(p.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   rc=p.wait(10)
 row.update(exitCode=rc,state='matched-expected-exit' if rc==expected and not row.get('timedOut') else 'unexpected-result',finishedAt=now(),sha256=hashlib.sha256(log.read_bytes()).hexdigest());save()
 assert row['state']=='matched-expected-exit',(name,rc)
try:
 assert status['head']=='d9958d163436ea08d4a19b325d9e7f5dad3dc951'
 assert hashes()[files[0]]=='4d9cf1dd97f00afa77d39184c4df2573f4fc985ab3dc53139145e3b1afbc46ff'
 assert env.get('HUSKY')!='0'
 run('format-preparation',['corepack','pnpm@10.32.1','exec','prettier','--write',*files],120)
 status.update(sourceSha256Before=hashes(),dirtyBefore=git('status','--porcelain'));save()
 run('actual-production-graph-replay',['node',str(ops/'replay-style-tint-source.mjs')],120)
 run('full-bundle-gate-controls',['node','--test',files[1]],180)
 tap=(out/'full-bundle-gate-controls.log').read_text()
 import re
 counts={k:int(v) for k,v in re.findall(r'^# (tests|pass|fail|skipped) (\d+)$',tap,re.M)}
 assert counts=={'tests':2082,'pass':2082,'fail':0,'skipped':0},counts
 run('diff-check',['git','diff','--check'],60)
 (out/'candidate.patch').write_text(git('diff','--',*files)+'\n')
 status.update(state='passed',testCounts=counts,sourceSha256After=hashes(),headAfter=git('rev-parse','HEAD'),dirtyAfter=git('status','--porcelain'))
 assert status['sourceSha256Before']==status['sourceSha256After']
 assert status['head']==status['headAfter'] and status['dirtyBefore']==status['dirtyAfter']
except Exception as e:status.update(state='failed',error=repr(e))
finally:status['finishedAt']=now();save();print(json.dumps(status,indent=2))
raise SystemExit(0 if status['state']=='passed' else 1)