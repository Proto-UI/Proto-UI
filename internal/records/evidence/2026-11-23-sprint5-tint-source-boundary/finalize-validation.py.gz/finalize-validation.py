import datetime,hashlib,json,os,pathlib,re,subprocess
root=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
ops=root.with_name(root.name+'-ops');out=ops/'style-tint-source-validation'
status=json.loads((out/'status.json').read_text())
assert status['error']=='AssertionError({})' and status['state']=='failed'
assert all(row['exitCode']==0 for row in status['steps'])
raw=out/'full-bundle-gate-controls.log'
assert hashlib.sha256(raw.read_bytes()).hexdigest()=='255fadfe855dd60f84df7a7241895e9f8fb23b4f2fd2021a4bfa51fd04a5a320'
counts={k:int(v) for k,v in re.findall(r'^[ℹ#] (tests|pass|fail|skipped) (\d+)$',raw.read_text(),re.M)}
assert counts=={'tests':2082,'pass':2082,'fail':0,'skipped':0},counts
files=list(status['sourceSha256Before'])
after={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}
assert after==status['sourceSha256Before']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
dirty=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
assert head==status['head'] and dirty==status['dirtyBefore']
check=subprocess.run(['git','diff','--check'],cwd=root,capture_output=True,text=True)
(out/'diff-check.log').write_text(check.stdout+check.stderr)
assert check.returncode==0
patch=subprocess.check_output(['git','diff','--',*files],cwd=root,text=True)
(out/'candidate.patch').write_text(patch)
replay=json.loads((ops/'style-tint-source-replay.json').read_text())
assert replay['graphSha256Before']==replay['graphSha256After'] and [r['issueCount'] for r in replay['checks']]==[4,0]
final={**status,'state':'passed','error':None,'testCounts':counts,'sourceSha256After':after,'headAfter':head,'dirtyAfter':dirty,'originalHarnessStatus':'status.json','harnessExplanation':'The original commands all exited zero; the wrapper expected TAP # summaries, while Node 24 emitted spec ℹ summaries. Parsed the unchanged raw log and retained the original failed wrapper status. No test was rerun or result edited.','diffCheckExit':0,'replay':replay,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'final-status.json').write_text(json.dumps(final,indent=2)+'\n')
print(json.dumps({'state':final['state'],'counts':counts,'replayIssueCounts':[r['issueCount'] for r in replay['checks']],'head':head,'patch':str(out/'candidate.patch')}))
