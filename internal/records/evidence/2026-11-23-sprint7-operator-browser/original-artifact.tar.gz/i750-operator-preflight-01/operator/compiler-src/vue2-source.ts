import { pruneDeadValues } from './demand-pruning';
import { ordinaryValueChildren } from './value-children';
import { nativeVue2AssociationsArtifact } from './native-vue2-associations';
import { resolvedPropFacts } from './resolved-props';
import { emitUndeclaredInstanceAssociations } from './native-instance-associations';
import {
  nativePublicCallsArtifact,
  nativeAuthoredCallablesArtifact,
  hasPublicCallable,
  emitPublicValue,
  emitPublicMethodProjection,
} from './native-public-values';
import { nativeHostAtomPlan, emitNativeHostAtom, type NativeHostAtomPlan } from './native-async';
import {
  nativeAuthoredHooksArtifact,
  emitAuthoredHookDefinition,
  emitPrivilegedHookCall,
} from './native-authored-hooks';
import {
  createJavaScriptValueReader,
  planJavaScriptCallBoundaries,
  emitJavaScriptMember,
  emitJavaScriptValue,
  emitJavaScriptParameters,
  emitUninvokedJavaScriptFunction,
  formatJavaScriptValueType,
  emitOptionalOperation,
} from './native-value-lowering';
import { isDataValueType } from './ir';
import { emitRecordedNotification } from './notification-plan';
import { observableSemantics } from './observable-semantics';
import { NativeLexicalScope, moduleLexicalScope } from './template-shape';
import { partitionModuleBindings } from './source-module-bindings';
import {
  collectVue2NativeChildShapes,
  createVue2NativeTemplateEmitter,
} from './vue2-native-template';
import { unsupportedControlLabel, unsupportedPointerFacts } from './pointer-facts-admission';
import { formatDataType } from './data-types';
import { validateIR, validIdentifier } from './ir-validation';
import { buildNativeContextArtifacts } from './native-context';
import { nativeSupportArtifacts, planNativeSupport } from './native-interaction';
import { buildNativeStaticDeclarations } from './native-static-declarations';
import { emitNativeRule, emitNativeStyleHandle, nativeStyleArtifact } from './native-style';
import { OPERATION_RULES } from './operations';
import { vue2SsrEntrypoints } from './vue2-ssr-entry';
import { checkTargetOperations, resolveTargetProfile } from './targets';
import { statementsTerminate as terminates } from './ir';
import type {
  CompileResult,
  CompilerDiagnostic,
  ExpressionIR,
  FunctionIR,
  GeneratedModule,
  ParameterIR,
  PrototypeIR,
  StatementIR,
  ValueType,
} from './ir';

export interface Vue2SourceOptions {
  componentName?: string;
  rootTag?: string;
  autoUpdateOnPropsChange?: boolean;
  propsUpdatePolicy?: import('./observable-semantics').PropsUpdatePolicy;
  ssr?: boolean;
}

/** Component-options output for the concrete Vue 2.6.14 consumer, not an Adapter bridge. */
export function emitVue2Source(
  input: PrototypeIR,
  options: Vue2SourceOptions = {}
): CompileResult<GeneratedModule> {
  const validated = validateIR(input);
  if (!validated.ok) return validated;
  const ir = pruneDeadValues(validated.value);
  const readValue = createJavaScriptValueReader(ir, typeName, false);
  const callBoundaries = planJavaScriptCallBoundaries(ir);
  const moduleParts = partitionModuleBindings(
    ir,
    undefined,
    (value) => value.kind === 'call' && callBoundaries.calls.has(value)
  );
  if (options.ssr) {
    const controlLabelDiagnostics = unsupportedControlLabel(ir, 'vue2-source SSR');
    if (controlLabelDiagnostics.length) return { ok: false, diagnostics: controlLabelDiagnostics };
    const pointerDiagnostics = unsupportedPointerFacts(ir, 'vue2-source SSR');
    if (pointerDiagnostics.length) return { ok: false, diagnostics: pointerDiagnostics };
  }
  const profile = options.ssr ? 'vue2-ssr-v1' : 'vue2-source-v1';
  const selected = resolveTargetProfile('vue2-source-v1');
  if (!selected.ok) return selected;
  const admitted = checkTargetOperations(ir, selected.value);
  if (!admitted.ok) return admitted;
  const supportPlan = planNativeSupport(ir, admitted.value);
  const controlLabel = admitted.value.operations.includes('hook.asControlLabel');
  const componentName = options.componentName ?? 'CompiledComponent';
  const rootTag = options.rootTag ?? 'div';
  const diagnostics: CompilerDiagnostic[] = [];
  const reject = (message: string, span = ir.setup.span): void => {
    diagnostics.push({ code: 'PUI4102', category: 'unsupported-input', message, span });
  };
  const usesStyle = admitted.value.sites.some(
    (site) =>
      site.operation.startsWith('style.') ||
      site.operation.startsWith('rule.') ||
      site.operation.startsWith('feedback.')
  );
  const usesInteraction = supportPlan.features.length > 0;
  const atomicInteraction = false;
  const interactionPath = './' + supportPlan.interactionPath.slice(0, -3);
  // Admission follows referenced functions/aliases, closures and authored hooks.
  // Interaction supplies createOwnedState and observed-state subscription cleanup.
  // Only admitted Overlay capability can produce a non-null portal target.
  const usesPortal = admitted.value.operations.includes('hook.asOverlay');
  const reachedFunctions = new Set(admitted.value.functions);
  const reachedHooks = new Set(admitted.value.authoredHooks);
  const stateDeclarations = new Set([
    'state.bool',
    'state.string',
    'state.enum',
    'state.numberDiscrete',
    'state.numberRange',
  ]);
  const usesState =
    (usesInteraction && !atomicInteraction) ||
    admitted.value.operations.some((operation) => stateDeclarations.has(operation));
  if (
    !validIdentifier(componentName) ||
    ['GeneratedProps', 'GeneratedExposes'].includes(componentName)
  ) {
    return {
      ok: false,
      diagnostics: [
        {
          code: 'PUI3001',
          category: 'invalid-input',
          message: 'Choose a valid, non-reserved generated component identifier.',
          span: ir.setup.span,
        },
      ],
    };
  }
  if (!/^[a-z][a-z0-9-]*$/.test(rootTag)) {
    reject('The Vue2 native rootTag must be a static lowercase DOM tag.');
  }
  const hostPropNames = new Map<string, string>();
  const nullableDefaults = new Set<string>();
  const propDefinitions = new Map<string, number>();
  const constrainedProps = new Set<string>();
  let unknownPropDeclarations = false;
  let unknownDefaults = false;
  for (const prop of ir.props) {
    const hostName = prop.name.replace(/-(\w)/g, (_match, letter: string) => letter.toUpperCase());
    const prior = hostPropNames.get(hostName);
    if (hostName === '__proto__' || (prior !== undefined && prior !== prop.name)) {
      reject(
        `Prop ${JSON.stringify(prop.name)} cannot be represented without a Vue2 prop-name collision.`,
        prop.span
      );
    }
    hostPropNames.set(hostName, prop.name);
  }
  // An operation name is not proof that every host-specific argument has a lowering.
  // Fail closed before emitting, including inside statically expanded authored hooks.
  function inspect(node: ExpressionIR): void {
    const ordinary = ordinaryValueChildren(node);
    if (ordinary) {
      ordinary.forEach(inspect);
      return;
    }
    if (node.kind === 'operation') {
      if (node.operation === 'props.define') {
        const declarations = node.arguments[0];
        if (declarations?.kind !== 'record') unknownPropDeclarations = true;
        else
          for (const entry of declarations.entries) {
            propDefinitions.set(entry.key, (propDefinitions.get(entry.key) ?? 0) + 1);
            if (
              entry.value.kind !== 'record' ||
              entry.value.entries.some((field) => field.key === 'range' || field.key === 'options')
            )
              constrainedProps.add(entry.key);
          }
      }
      if (node.operation === 'props.setDefaults') {
        const layer = node.arguments[0];
        if (layer?.kind !== 'record') unknownDefaults = true;
        else
          for (const entry of layer.entries) {
            if (entry.value.kind !== 'literal' || entry.value.value === null)
              nullableDefaults.add(entry.key);
          }
      }
      if (node.operation === 'render.el') {
        const props = node.arguments[1];
        const record =
          props &&
          (props.kind === 'record' ||
            props.type === 'template-props' ||
            props.type === 'record' ||
            (typeof props.type === 'object' && props.type.kind === 'record'));
        if (
          record &&
          (props.kind !== 'record' ||
            props.entries.length > 1 ||
            props.entries.some(
              (entry) => entry.key !== 'style' || entry.value.type !== 'style-handle'
            ))
        ) {
          reject(
            'vue2-source-v1 TemplateProps supports only one static tw handle under style.',
            props.span
          );
        }
      }
      if (node.operation === 'props.define' && node.arguments[0]?.kind === 'record') {
        for (const entry of node.arguments[0].entries) {
          if (entry.value.kind !== 'record') continue;
          for (const field of entry.value.entries) {
            if (!['type', 'default', 'empty', 'options', 'range'].includes(field.key)) {
              reject(
                `vue2-source-v1 does not implement prop descriptor field ${JSON.stringify(field.key)}.`,
                field.value.span
              );
            }
          }
        }
      }
      if (node.receiver) inspect(node.receiver);
      node.arguments.forEach(inspect);
    } else if (node.kind === 'function') {
      node.function.parameters.forEach((parameter) => {
        if (parameter.default) inspect(parameter.default);
      });
      inspectBody(node.function.body);
    } else if (node.kind === 'member') inspect(node.object);
    else if (node.kind === 'unary') inspect(node.operand);
    else if (node.kind === 'lexical-cell') inspect(node.value);
    else if (node.kind === 'lexical-read' || node.kind === 'lexical-update') inspect(node.cell);
    else if (node.kind === 'lexical-write') {
      inspect(node.cell);
      inspect(node.value);
    } else if (node.kind === 'conditional') {
      inspect(node.condition);
      inspect(node.then);
      inspect(node.otherwise);
    } else if (node.kind === 'binary') {
      inspect(node.left);
      inspect(node.right);
    } else if (node.kind === 'array') node.elements.forEach(inspect);
    else if (node.kind === 'record') node.entries.forEach((entry) => inspect(entry.value));
    else if (node.kind === 'helper-call') node.arguments.forEach(inspect);
  }
  function inspectBody(body: readonly StatementIR[]): void {
    for (const statement of body) {
      if (statement.kind === 'const') inspect(statement.value);
      else if (statement.kind === 'effect') inspect(statement.expression);
      else if (statement.kind === 'return' && statement.value) inspect(statement.value);
      else if (statement.kind === 'throw') inspect(statement.value);
      else if (statement.kind === 'try') {
        inspectBody(statement.body);
        if (statement.catch) inspectBody(statement.catch.body);
        if (statement.finally) inspectBody(statement.finally);
      } else if (statement.kind === 'if') {
        inspect(statement.condition);
        inspectBody(statement.then);
        inspectBody(statement.otherwise);
      }
    }
  }
  for (const fn of admitted.value.functions)
    for (const parameter of fn.parameters) if (parameter.default) inspect(parameter.default);
  inspectBody(ir.setup.body);
  for (const hook of ir.hooks) inspectBody(hook.setup.body);
  if (diagnostics.length) return { ok: false, diagnostics };

  const names = new Set<string>([componentName]);
  function collect(value: unknown): void {
    if (Array.isArray(value)) value.forEach(collect);
    else if (value !== null && typeof value === 'object') {
      for (const [key, item] of Object.entries(value)) {
        if (key === 'name' && typeof item === 'string') names.add(item);
        collect(item);
      }
    }
  }
  collect(ir);
  let prefix = '__pui';
  while ([...names].some((name) => name.startsWith(prefix))) prefix += '_';
  // Client-native checkpoint. SSR capture residualization is a separate pending
  // part of this same candidate; this switch must disappear before completion.
  let nativeScope = moduleLexicalScope(ir);
  const nativePlan = options.ssr ? undefined : collectVue2NativeChildShapes(ir);
  const nativeTemplate =
    nativePlan &&
    createVue2NativeTemplateEmitter({
      prefix,
      styled: usesStyle,
      ...nativePlan,
      expression,
      scope: () => nativeScope,
    });
  const contextArtifacts = buildNativeContextArtifacts(ir);
  const staticDeclarations = buildNativeStaticDeclarations(
    ir.staticDeclarations,
    ir.moduleDeclarations
  );
  const staticNames = new Map<string, string>();
  let staticSequence = 0;
  const staticImports = [...staticDeclarations.capabilities]
    .map(([id, entry]) => {
      const name = `${prefix}Static${staticSequence++}`;
      staticNames.set(id, name);
      return `import { declaration as ${name} } from ${JSON.stringify('./' + entry.file.replace(/\.ts$/, ''))};`;
    })
    .join('\n');
  const contextNames = new Map(
    ir.contextKeys.map((key, index) => [key.id, `${prefix}ContextKey${index}`])
  );
  const atoms = nativeHostAtomPlan(admitted.value.operations, prefix);
  const hasAuthoredHooks = admitted.value.authoredHooks.length > 0;
  const publicCalls =
    callBoundaries.calls.size > 0 ||
    ir.exposes.some(
      (entry) =>
        (entry.kind === 'value' && hasPublicCallable(entry.type)) ||
        (entry.kind === 'method' && hasPublicCallable(entry.returnType))
    );
  const aliases = new Map(ir.hooks.map((hook, index) => [hook.id, `${prefix}Hook${index}`]));
  function typeName(type: ValueType): string {
    const atom = atoms.typeName(type, `${prefix}Run`);
    if (atom) return atom;
    if (typeof type === 'string' && type.startsWith('lexical:')) return type.slice(8);
    if (typeof type !== 'string' && !isDataValueType(type))
      return formatJavaScriptValueType(type, typeName);
    if (type === 'exception') return 'unknown';
    if (typeof type !== 'string') return formatJavaScriptValueType(type, typeName);
    if (isDataValueType(type)) return formatDataType(type);
    if (['boolean', 'number', 'string', 'null', 'void', 'unknown'].includes(type)) return type;
    if (type.startsWith('nullable:')) return `${typeName(type.slice(9) as ValueType)} | null`;
    if (type.startsWith('optional:')) return `${typeName(type.slice(9) as ValueType)} | undefined`;
    if (
      !usesInteraction &&
      (['focus', 'accessible', 'event', 'event-control', 'event-or-control'].includes(type) ||
        type.startsWith('observed:'))
    )
      return 'unknown';
    if (!usesStyle && ['style-handle', 'rule-handle', 'template-props'].includes(type))
      return 'unknown';
    if (type.startsWith('borrowed:'))
      return `${prefix}OwnedState<${type.slice(9)}> & {watch(callback: (run: ${prefix}Run, event: ${prefix}StateEvent<${type.slice(9)}>) => void): () => void}`;
    if (type === 'props') return `${prefix}ResolvedProps`;
    if (type === 'def') return `${prefix}Owner['def']`;
    if (type === 'run') return `${prefix}Run`;
    if (type === 'render' && !options.ssr) return `${prefix}NativeRenderer`;
    if (type.startsWith('state:')) return `${prefix}OwnedState<${type.slice(6)}>`;
    if (type.startsWith('state-event:')) return `${prefix}StateEvent<${type.slice(12)}>`;
    if (type.startsWith('state-next:'))
      return `Extract<${prefix}StateEvent<${type.slice(11)}>, {type:'next'}>`;
    if (type === 'context-key')
      return "{readonly __brand: 'ContextKey'; readonly debugName?: string}";
    if (type === 'focus') return `${prefix}NativeFocus`;
    if (type === 'accessible') return `${prefix}NativeAccessible`;
    if (type === 'event') return `${prefix}NativeInput`;
    if (type === 'event-control') return `${prefix}NativeInput['control']`;
    if (type === 'event-or-control')
      return `(${prefix}NativeInput | ${prefix}NativeInput['control'])`;
    if (type === 'host-event') return 'Event';
    if (type === 'host-target') return 'HTMLElement | null';
    if (type === 'observed:boolean') return `${prefix}NativeObservedState<boolean>`;
    if (
      type === 'control-label' ||
      type === 'control-label-handle' ||
      type === 'control-label-request' ||
      (usesInteraction && (type === 'anatomy-family' || type === 'anatomy-part'))
    )
      return `import(${JSON.stringify('./' + supportPlan.modulesPath.slice(0, -3))}).NativeModuleCapability<${JSON.stringify(type)}, ${prefix}Run>`;
    return 'unknown';
  }
  function parameters(values: readonly ParameterIR[]): string {
    return values
      .map(
        (parameter) =>
          `${parameter.name}${parameter.optional && !parameter.default ? '?' : ''}: ${typeName(parameter.type)}${parameter.default ? ` = ${expression(parameter.default, 0)}` : ''}`
      )
      .join(', ');
  }
  function fn(value: FunctionIR, depth: number): string {
    if (!reachedFunctions.has(value)) return emitUninvokedJavaScriptFunction(value, false);
    if (nativePlan?.identityOnly.has(value)) {
      // Complete lexical use proof, not absence from the invocation collector.
      // Preserve this allocation site and original arity. Opaque unused formals
      // are not node provenance or an expanded callable interface.
      const opaque = value.parameters
        .map((parameter) => ` * @param {unknown} ${parameter.name}`)
        .join('\n');
      return `${opaque ? `/**\n${opaque}\n */ ` : ''}(${emitJavaScriptParameters(value.parameters, (item) => expression(item, depth))}) => {}`;
    }
    const saved = nativeScope;
    for (const parameter of value.parameters) {
      nativeScope = nativeScope.bind(parameter.name, {
        kind: 'reference',
        name: '\0vue2-formal-' + parameter.name,
        type: parameter.type,
        span: value.span,
      });
    }
    try {
      const annotations = value.parameters
        .map((parameter) => {
          const contextual =
            parameter.type === 'unknown' || parameter.type === 'template'
              ? nativeTemplate?.parameterType(parameter)
              : undefined;
          return `@param {${contextual ?? typeName(parameter.type)}} ${parameter.optional && !parameter.default ? `[${parameter.name}]` : parameter.name}`;
        })
        .join(' ');
      const returns =
        value.context === 'helper' &&
        !['function', 'unknown', 'template'].includes(value.returnType as string)
          ? ` @returns {${typeName(value.returnType)}}`
          : '';
      const callable = `${annotations || returns ? `/** ${annotations}${returns} */ ` : ''}(${emitJavaScriptParameters(value.parameters, (item) => expression(item, depth))}) => {\n${body(value.body, depth + 1)}${'  '.repeat(depth)}}`;
      return callBoundaries.authored.has(value)
        ? `${prefix}MarkAuthoredCallable(${callable})`
        : callable;
    } finally {
      nativeScope = saved;
    }
  }

  function expression(value: ExpressionIR, depth: number): string {
    switch (value.kind) {
      case 'narrow':
      case 'member-write':
      case 'element':
      case 'conditional':
      case 'call':
      case 'intrinsic':
      case 'object-spread':
        return emitJavaScriptValue(value, (item) => expression(item, depth), typeName, false, {
          plan: callBoundaries,
          wrap: `${prefix}WrapPublic`,
          prefix: prefix,
          isAuthored: `${prefix}IsAuthoredCallable`,
        })!;
      case 'undefined':
        return '(void 0)';
      case 'literal':
        return JSON.stringify(value.value);
      case 'reference':
        return readValue(value, value.name);
      case 'lexical-cell':
        return expression(value.value, depth);
      case 'lexical-read':
        return readValue(value, expression(value.cell, depth));
      case 'lexical-write':
        return `(${expression(value.cell, depth)} = ${expression(value.value, depth)})`;
      case 'lexical-update': {
        const cell = expression(value.cell, depth),
          operator = value.delta === 1 ? '++' : '--';
        return `(${value.prefix ? operator + cell : cell + operator})`;
      }
      case 'context-key':
        return contextNames.get(value.keyId)!;
      case 'style-handle':
        return emitNativeStyleHandle(value.handle, false);
      case 'rule':
        return emitNativeRule(
          value,
          (item) => expression(item, depth),
          `${prefix}Owner.def.feedback.style`,
          `${prefix}Owner.resolvedProps`,
          false
        );
      case 'member':
        return emitJavaScriptMember(
          value,
          (item) => expression(item, depth),
          typeName,
          false,
          readValue
        );
      case 'unary':
        return `(${value.operator}${expression(value.operand, depth)})`;
      case 'binary':
        return `(${expression(value.left, depth)} ${value.operator} ${expression(value.right, depth)})`;
      case 'array':
        return `[${value.elements.map((item) => expression(item, depth)).join(', ')}]`;
      case 'record':
        return `{ ${value.entries.map((entry) => `[${JSON.stringify(entry.key)}]: ${expression(entry.value, depth)}`).join(', ')} }`;
      case 'function':
        return fn(value.function, depth);
      case 'helper-call':
        return `${value.name}(${value.arguments.map((item) => expression(item, depth)).join(', ')})`;
      case 'authored-hook':
        return `${aliases.get(value.hookId)}(${(value.arguments ?? []).map((item) => expression(item, depth)).join(', ')})`;
      case 'static-capability':
        return staticNames.get(value.declarationId)!;
      case 'operation': {
        const optional = emitOptionalOperation(
          value,
          (item) => expression(item, depth),
          `${prefix}OptionalReceiver`
        );
        if (optional !== undefined) return optional;
        const atom = emitNativeHostAtom(value, (item) => expression(item, depth), prefix);
        if (atom !== undefined) return atom;
        if (hasAuthoredHooks && value.operation.startsWith('hook.'))
          return emitPrivilegedHookCall({
            value: value,
            manager: `${prefix}Authored`,
            callee: `${prefix}Owner.interaction.${OPERATION_RULES[value.operation].path}`,
            prefix: prefix,
            emit: (item) => expression(item, depth),
            typeName,
            typed: false,
          });
        if (value.operation === 'expose.value' && hasPublicCallable(value.arguments[1].type))
          return `${expression(value.receiver!, depth)}.expose.value(${expression(value.arguments[0], depth)}, ${emitPublicValue({ value: expression(value.arguments[1], depth), type: value.arguments[1].type, wrap: `${prefix}WrapPublic`, prefix: prefix, typeName, typed: false })})`;
        if (value.operation === 'expose.method') {
          const projection = emitPublicMethodProjection(value.arguments[1].type, {
            wrap: `${prefix}WrapPublic`,
            prefix: prefix,
            typeName,
            typed: false,
          });
          if (projection)
            return `${expression(value.receiver!, depth)}.expose.method(${value.arguments.map((item) => expression(item, depth)).join(', ')}, ${projection})`;
        }
        if (value.operation.startsWith('capture.'))
          return `/** @type {${typeName(value.type)}} */ (${expression(value.receiver!, depth)}.${OPERATION_RULES[value.operation].path}?.(${value.arguments.map((item) => expression(item, depth)).join(', ')}))`;
        if (nativeTemplate && value.operation === 'render.el')
          return nativeTemplate.element(value, depth);
        if (nativeTemplate && value.operation === 'render.slot')
          return nativeTemplate.slot(value, depth);
        const argumentsCode = value.arguments.map((item) => expression(item, depth)).join(', ');
        if (value.operation === 'state.get')
          return `/** @type {${typeName(value.type)}} */ (${expression(value.receiver!, depth)}.get())`;
        if (OPERATION_RULES[value.operation].path === 'call')
          return `${expression(value.receiver!, depth)}(${argumentsCode})`;
        if (value.operation.startsWith('hook.') || value.operation.startsWith('anatomy.')) {
          return `${prefix}Owner.interaction.${OPERATION_RULES[value.operation].path}(${argumentsCode})`;
        }
        if (value.operation === 'host.get') return `${prefix}Owner.host()`;
        return `${expression(value.receiver!, depth)}.${OPERATION_RULES[value.operation].path}(${argumentsCode})`;
      }
    }
  }
  function body(
    statements: readonly StatementIR[],
    depth: number,
    deadBindings = new Set<string>()
  ): string {
    const indent = '  '.repeat(depth);
    let output = '';
    for (const statement of statements) {
      const origin = `${indent}// Source ${JSON.stringify(statement.span.file)}:${statement.span.line}:${statement.span.column}\n`;
      if (statement.kind === 'const') {
        output += `${origin}${['lexical-cell', 'record', 'object-spread'].includes(statement.value.kind) ? `${indent}/** @type {${typeName(statement.value.type)}} */\n` : ''}${indent}${statement.value.kind === 'lexical-cell' ? 'let' : 'const'} ${statement.name} = ${expression(statement.value, depth)};\n`;
        nativeScope = nativeScope.bind(statement.name, statement.value);
      } else if (statement.kind === 'effect') {
        output += `${origin}${indent}${expression(statement.expression, depth)};\n`;
      } else if (statement.kind === 'return') {
        output += `${origin}${indent}return${statement.value ? ` ${expression(statement.value, depth)}` : ''};\n`;
        break;
      } else if (statement.kind === 'throw') {
        output += `${origin}${indent}throw ${expression(statement.value, depth)};\n`;
        break;
      } else if (statement.kind === 'try') {
        const branch = (items: readonly StatementIR[], name?: string) => {
          const saved = nativeScope;
          try {
            if (name) nativeScope = nativeScope.parameter(name, undefined, nativeScope, null);
            return body(items, depth + 1, new Set(deadBindings));
          } finally {
            nativeScope = saved;
          }
        };
        output += `${origin}${indent}try {\n${branch(statement.body)}${indent}}${statement.catch ? ` catch${statement.catch.name ? ` (${statement.catch.name})` : ''} {\n${branch(statement.catch.body, statement.catch.name)}${indent}}` : ''}${statement.finally ? ` finally {\n${branch(statement.finally)}${indent}}` : ''}\n`;
        if (terminates([statement])) break;
      } else {
        const branch = (statements: readonly StatementIR[]) => {
          const saved = nativeScope;
          try {
            return body(statements, depth + 1, new Set(deadBindings));
          } finally {
            nativeScope = saved;
          }
        };
        output += `${origin}${indent}if (${expression(statement.condition, depth)}) {\n${branch(statement.then)}${indent}}${statement.otherwise.length ? ` else {\n${branch(statement.otherwise)}${indent}}` : ''}\n`;
        if (terminates(statement.then) && terminates(statement.otherwise)) break;
      }
    }
    return output;
  }
  const propsType = ir.props
    .map((prop) => `  ${JSON.stringify(prop.name)}?: ${typeName(prop.type)} | null;`)
    .join('\n')
    .replace(/\*\//g, '*\\/');
  const { nonNull: nonNullProps, required: guaranteedProps } = resolvedPropFacts(ir);
  const resolvedPropsType = ir.props
    .map(
      (prop) =>
        `  readonly ${JSON.stringify(prop.name)}${guaranteedProps.has(prop.name) ? '' : '?'}: ${typeName(prop.type)}${nonNullProps.has(prop.name) ? '' : ' | null'};`
    )
    .join('\n')
    .replace(/\*\//g, '*\\/');
  const exposesType = ir.exposes
    .filter((entry) => entry.kind !== 'event')
    .map((entry) => {
      const type =
        entry.kind === 'state'
          ? `${prefix}ExternalState<${typeName(entry.type)}>`
          : entry.kind === 'value'
            ? typeName(entry.type)
            : `(${parameters(entry.parameters)}) => ${typeName(entry.returnType)}`;
      return `  ${JSON.stringify(entry.name)}: ${type};`;
    })
    .join('\n')
    .replace(/\*\//g, '*\\/');
  const propTypes = Object.fromEntries(ir.props.map((prop) => [prop.name, prop.type]));
  const hooks =
    body(moduleParts.owned, 1) +
    ir.hooks
      .filter((hook) => reachedHooks.has(hook.id))
      .map(
        (hook) =>
          '  ' +
          emitAuthoredHookDefinition({
            hook,
            name: aliases.get(hook.id)!,
            manager: `${prefix}Authored`,
            def: `${prefix}Owner.def`,
            emit: (value) => fn(value, 1),
            typeName,
            typed: false,
          })
      )
      .join('\n');
  const styleImport = usesStyle
    ? `import { createNativeStyle as ${prefix}CreateNativeStyle, templateStyleTokens as ${prefix}TemplateStyleTokens } from './.proto-ui/style/native-v1';\n`
    : '';
  const interactionImport = usesInteraction
    ? `import { createNativeInteraction as ${prefix}CreateNativeInteraction } from '${interactionPath}';
/** @template Run @typedef {import('${interactionPath}').NativeInteraction<Run>} ${prefix}NativeInteraction */
${
  atomicInteraction
    ? ''
    : `/** @typedef {import('${interactionPath}').NativeFocus} ${prefix}NativeFocus */
/** @typedef {import('${interactionPath}').NativeAccessible} ${prefix}NativeAccessible */
/** @template T @typedef {import('${interactionPath}').NativeObservedState<T>} ${prefix}NativeObservedState */
/** @typedef {import('${interactionPath}').NativeInput} ${prefix}NativeInput */
/** @typedef {import('${interactionPath}').NativeFocusOptions} ${prefix}NativeFocusOptions */
`
}`
    : '';
  const contextImports =
    (controlLabel
      ? `import { normalizeVue2InstanceAssociations as ${prefix}NormalizeAssociations } from './.proto-ui/interaction/vue2-associations-v1';\n`
      : '') +
    styleImport +
    interactionImport +
    (contextArtifacts
      ? `import { createContextScope as ${prefix}CreateContextScope, scopeKey as ${prefix}ScopeKey, acceptsContextValue as ${prefix}AcceptsContextValue } from '${contextArtifacts.scopeFile.replace(/\.ts$/, '')}';\n${ir.contextKeys.map((key) => `import { key as ${contextNames.get(key.id)} } from '${contextArtifacts.keys.get(key.id)!.file.replace(/\.ts$/, '')}';`).join('\n')}`
      : '');
  const contextCode = contextArtifacts
    ? `
  /** @type {Map<object, (value: unknown) => boolean>} */
  const contextChecks = new Map([
${ir.contextKeys.map((key) => `    [${contextNames.get(key.id)}, (/** @param {unknown} value */ (value) => ${prefix}AcceptsContextValue(${JSON.stringify(key.type)}, value))],`).join('\n')}
  ]);
  const contextScope = ${prefix}CreateContextScope({
    getParent: () => vm[${JSON.stringify(`${prefix}ParentScope`)}] || null,
    isAlive: () => !disposed,
    invoke: (fn) => invoke(fn, false),
    validate: (key, value) => contextChecks.get(key)?.(value) === true,
  });
  const contextRead = Object.freeze({ read: (/** @param {object} key */ (key) => { alive(); return contextScope.read(key); }), tryRead: (/** @param {object} key */ (key) => { alive(); return contextScope.tryRead(key); }) });
`
    : '';
  const helpers = nativeHelpers(
    {
      owner: contextCode,
      run: contextArtifacts
        ? `context: { ...contextRead, update: (/** @param {object} key @param {unknown} value */ (key, value) => { callback(); contextScope.update(key, value); }), tryUpdate: (/** @param {object} key @param {unknown} value */ (key, value) => { callback(); return contextScope.tryUpdate(key, value); }) },`
        : '',
      read: contextArtifacts ? ', context: contextRead' : '',
      def: contextArtifacts
        ? `context: { provide: (/** @param {object} key @param {unknown} value */ (key, value) => { setupOnly(); contextScope.provide(key, value); }), subscribe: (/** @param {object} key @param {(run: PUIRun, next: unknown, previous: unknown) => void} [fn] */ (key, fn) => { setupOnly(); return contextScope.subscribe(key, 'required', fn ? (next, prev) => fn(run, next, prev) : undefined); }), trySubscribe: (/** @param {object} key @param {(run: PUIRun, next: unknown, previous: unknown) => void} [fn] */ (key, fn) => { setupOnly(); return contextScope.subscribe(key, 'optional', fn ? (next, prev) => fn(run, next, prev) : undefined); }) },`.replace(
            /\bPUI/g,
            prefix
          )
        : '',
      handle: contextArtifacts ? 'contextScope,' : '',
      dispose: contextArtifacts
        ? 'try { contextScope.dispose(); } catch (error) { failure ??= { error }; }'
        : '',
      setupFailure: contextArtifacts ? 'contextScope.dispose();' : '',
    },
    usesStyle,
    usesInteraction,
    usesState,
    usesPortal,
    options.ssr === true,
    JSON.stringify(ir.moduleDeclarations.map(({ id, config }) => ({ id, config }))),
    staticNames.get('@proto.ui/module-table-structure#TABLE_STRUCTURE_FAMILY') ?? 'undefined',
    atomicInteraction,
    null,
    supportPlan.features.includes('event'),
    atoms,
    hasAuthoredHooks,
    publicCalls,
    controlLabel
  ).replace(/\bPUI/g, prefix);
  const ownerKey = JSON.stringify(`${prefix}Owner`);
  const propDeclarations = ir.props.map((prop) => `[${JSON.stringify(prop.name)}]: {}`).join(', ');
  const code = `// Editable generated Vue 2.6.14 component options. Profile: ${profile}.
// Inline native-lowering helpers: logical owner, prop resolution, state, semantic templates.
// No Proto-UI Core, Runtime, Hooks or Adapter dependency; optional native helpers are emitted artifacts.
// Source graph SHA-256: ${ir.source.sha256}
${atoms.jsImports}
${publicCalls ? `import { createNativePublicCalls as ${prefix}CreatePublicCalls } from './.proto-ui/owner/public-callables-v1';` : ''}
${callBoundaries.authored.size ? `import { markNativeAuthoredCallable as ${prefix}MarkAuthoredCallable, isNativeAuthoredCallable as ${prefix}IsAuthoredCallable } from './.proto-ui/owner/authored-callables-v1';` : ''}
${hasAuthoredHooks ? `import { createNativeAuthoredHooks as ${prefix}CreateAuthored } from './.proto-ui/owner/authored-hooks-v1';` : ''}
${contextImports}
${staticImports}
${body(moduleParts.shared, 0)}

/** @typedef {{
${propsType}
}} GeneratedProps */
/** @typedef {Readonly<{
${resolvedPropsType}
} & Record<string, unknown>>} ${prefix}ResolvedProps */
/** @typedef {{
${exposesType}
}} GeneratedExposes */
${nativeTemplate?.declarations ?? ''}
${
  nativeTemplate
    ? `/** @typedef {{
 * slot: () => ${prefix}NativePaint,
 * read: {
 *   props: {
 *     get: () => ${prefix}ResolvedProps,
 *     getRaw: () => Readonly<Record<string, unknown>>,
 *     isProvided: (key: PropertyKey) => boolean
 *   }${
   contextArtifacts
     ? `,
 *   context: {
 *     read: (key: object) => ReturnType<import('${contextArtifacts.scopeFile.replace(/\.ts$/, '')}').ContextScope['read']>,
 *     tryRead: (key: object) => ReturnType<import('${contextArtifacts.scopeFile.replace(/\.ts$/, '')}').ContextScope['tryRead']>
 *   }`
     : ''
 }
 * }
 * }} ${prefix}NativeRenderer */`
    : ''
}
${usesStyle ? `/** @typedef {import('./.proto-ui/style/native-v1').NativeStyleHandle} ${prefix}NativeStyleHandle */` : ''}
${helpers}

/** @param {${prefix}Owner} ${prefix}Owner */
function ${prefix}Setup(${prefix}Owner) {
${publicCalls ? `  const ${prefix}WrapPublic = ${prefix}Owner.wrapPublic;` : ''}
${hasAuthoredHooks ? `  const ${prefix}Authored = ${prefix}Owner.authored;` : ''}
${atoms.delay ? `  const ${prefix}Delay = ${prefix}Owner.delay;` : ''}${atoms.presence ? `  const ${prefix}Presence = ${prefix}Owner.presence;` : ''}${atoms.meta ? `  const ${prefix}Meta = ${prefix}Owner.meta;` : ''}
${hooks}
  ${
    ir.setup.returnType === 'void'
      ? `(${fn(ir.setup, 1)})(${prefix}Owner.def); return;`
      : nativeTemplate
        ? `/** @type {((renderer: ${prefix}NativeRenderer) => ${nativeTemplate.resultType}) | void} */
  const ${prefix}AuthoredRenderer = (${fn(ir.setup, 1)})(${prefix}Owner.def);
  if (typeof ${prefix}AuthoredRenderer !== 'function') return ${prefix}AuthoredRenderer;
  return (/** @param {${prefix}NativeRenderer} ${prefix}Renderer */ (${prefix}Renderer) => ${nativeTemplate.publication(`${prefix}AuthoredRenderer(${prefix}Renderer)`)});`
        : `return (${fn(ir.setup, 1)})(${prefix}Owner.def);`
  }
}

/** @typedef {import('vue').default & { readonly ${ownerKey}: ReturnType<typeof ${prefix}CreateOwner>${contextArtifacts ? `; readonly ${JSON.stringify(`${prefix}ParentScope`)}?: ReturnType<typeof ${prefix}CreateContextScope> | null` : ''} }} ${prefix}NativeInstance */
export const ${componentName} = {
  name: ${JSON.stringify(ir.name)},
  inheritAttrs: false,
  props: { instanceAssociations: { type: Object, default: undefined }, ${propDeclarations} },
  ${
    contextArtifacts
      ? `inject: { [${JSON.stringify(`${prefix}ParentScope`)}]: { from: ${prefix}ScopeKey, default: null } },
  /** @this {${prefix}NativeInstance} */
  provide() { return { [${prefix}ScopeKey]: this[${ownerKey}].contextScope }; },`
      : ''
  }
  /** @this {${prefix}NativeInstance} */
  beforeCreate() {
    Object.defineProperty(this, ${ownerKey}, { value: ${prefix}CreateOwner(this, ${prefix}Setup, ${JSON.stringify(propTypes)}, ${JSON.stringify(rootTag)}, ${options.propsUpdatePolicy ? options.propsUpdatePolicy === 'host' : options.autoUpdateOnPropsChange !== false}) });
    ${
      options.ssr
        ? `const session = ${prefix}FindSession(this);
    if (session) this[${ownerKey}].bindSession(session, ${JSON.stringify(ir.source.sha256)});`
        : ''
    }
  },
  /** @this {${prefix}NativeInstance} */
  created() { this[${ownerKey}].initialize(); },
  /** @this {${prefix}NativeInstance} */
  mounted() { this[${ownerKey}].hostMounted(); },
  /** @this {${prefix}NativeInstance} */
  updated() { this[${ownerKey}].afterCommit(); },
  /** @this {${prefix}NativeInstance} */
  activated() { this[${ownerKey}].activate(); },
  /** @this {${prefix}NativeInstance} */
  deactivated() { this[${ownerKey}].deactivate(); },
  /** @this {${prefix}NativeInstance} */
  beforeDestroy() { this[${ownerKey}].dispose(); },
  methods: {
    /** @this {${prefix}NativeInstance} */
    update() { this[${ownerKey}].update(); },
    /** @this {${prefix}NativeInstance} */
    getExposes() { return this[${ownerKey}].getExposes(); },
    /** @this {${prefix}NativeInstance} @template T @param {() => T} callback */
    invokeInCallbackScope(callback) { return this[${ownerKey}].invokePublic(callback); },
  },
  /** @this {${prefix}NativeInstance} @param {import('vue').CreateElement} h */
  render(h) { return this[${ownerKey}].render(h); },
};
export default ${componentName};
${options.ssr ? vue2SsrEntrypoints(prefix, componentName, ir.source.sha256) : ''}
`;
  return {
    ok: true,
    value: {
      code,
      profile,
      supportingFiles: [
        ...atoms.files,
        ...(publicCalls ? [nativePublicCallsArtifact] : []),
        ...(callBoundaries.authored.size ? [nativeAuthoredCallablesArtifact] : []),
        ...(hasAuthoredHooks ? [nativeAuthoredHooksArtifact] : []),
        ...(contextArtifacts?.files ?? []),
        ...staticDeclarations.files,
        ...(usesStyle ? [nativeStyleArtifact] : []),
        ...(controlLabel ? [nativeVue2AssociationsArtifact] : []),
        ...(usesInteraction ? nativeSupportArtifacts(supportPlan) : []),
      ],
      dependencies: [
        ...selected.value.dependencies
          .filter(
            (dependency) =>
              supportPlan.packages.includes(dependency.name) ||
              dependency.name !== '@floating-ui/dom'
          )
          .map((dependency) => ({ ...dependency })),
        ...(options.ssr
          ? [{ name: 'vue-server-renderer', version: '2.6.14', role: 'target' as const }]
          : []),
      ],
      provenance: {
        source: ir.source,
        irVersion: ir.schemaVersion,
        backend: profile,
        observableSemantics: observableSemantics(
          'vue2',
          'source',
          options.propsUpdatePolicy ??
            (options.autoUpdateOnPropsChange === false ? 'explicit' : undefined)
        ),
        ...(usesInteraction
          ? {
              nativeSupport: {
                version: 2 as const,
                id: supportPlan.id,
                features: [...supportPlan.features],
              },
            }
          : {}),
      },
    },
  };
}

// This is target-specific generated host code, never a shared IR interpreter.
function nativeHelpers(
  context: {
    owner: string;
    run: string;
    read: string;
    def: string;
    handle: string;
    dispose: string;
    setupFailure: string;
  },
  styled: boolean,
  interactive: boolean,
  stateful: boolean,
  portal: boolean,
  ssr: boolean,
  declarations: string,
  tableFamily: string,
  atomicInteractive: boolean,
  imageConfig: string | null,
  eventSupport: boolean,
  atoms: NativeHostAtomPlan,
  hasAuthoredHooks: boolean,
  publicCalls: boolean,
  controlLabel: boolean
): string {
  const refresh = `${styled ? 'style.refresh();' : ''}${interactive ? ' interaction.refresh();' : ''}`;
  // Derive the generated finite registry and its key enumeration from the same
  // canonical operation metadata; no independent callback-shape analysis.
  const lifecycleKeys = Object.values(OPERATION_RULES)
    .filter((rule) => rule.receiver === 'def' && rule.path.startsWith('lifecycle.on'))
    .map((rule) => {
      const event = rule.path.slice('lifecycle.on'.length);
      return event.slice(0, 1).toLowerCase() + event.slice(1);
    });
  // Atomic Text/Image selection fixes the physical Root to input/textarea/img.
  // Only its successful native commit narrows Vue2's otherwise generic Element;
  // the ordinary owner instance and general rootTag path keep their real types.
  return String.raw`
/**
 * @template T
 * @typedef {{ get: () => T, subscribe: (callback: (event: { type: 'next', prev: T, next: T, reason?: unknown } | { type: 'disconnect', reason: 'unmount' }) => void) => (() => void), unsubscribe: (off: () => void) => void, spec: Readonly<Record<string, unknown>> }} PUIExternalState
 */
${
  stateful
    ? String.raw`/** @template T @typedef {{ type: 'next', prev: T, next: T, reason?: unknown } | { type: 'disconnect', reason: 'unmount' }} PUIStateEvent */
/** @template T @typedef {{ get: () => T, setDefault: (value: T) => void, set: (value: T, reason?: unknown) => void, external: PUIExternalState<T>, dispose: () => void }} PUIOwnedState */
`
    : ''
}/** @typedef {'boolean' | 'number' | 'string' | 'null' | 'void' | { kind: 'literal', value: string | number | boolean | null } | { kind: 'array', element: PUIDataType } | { kind: 'union', members: readonly PUIDataType[] } | { kind: 'record', fields: readonly { name: string, type: PUIDataType, optional?: boolean }[] }} PUIDataType */
/** @typedef {Readonly<Record<string, unknown>>} PUIRawProps */
/** @typedef {{ type: 'boolean' | 'number' | 'string' | 'object' | 'any' | 'enum', empty?: 'accept' | 'fallback' | 'error', default?: unknown, options?: readonly string[], range?: { min?: number, max?: number } }} PUIPropSpec */
/** @typedef {{ options?: readonly (boolean | string | number)[], min?: unknown, max?: unknown, step?: unknown, clamp?: boolean } & Record<string, unknown>} PUIStateConfiguration */
/** @typedef {'bool' | 'string' | 'enum' | 'number.discrete' | 'number.range'} PUIStateKind */
/** @typedef {ReturnType<typeof PUICreateOwner>} PUIOwner */
/** @typedef {Parameters<Parameters<PUIOwner['def']['props']['watch']>[1]>[0]} PUIRun */
/** @typedef {import('vue').default & { readonly instanceAssociations?: Readonly<{controlLabel?: object | null}>; readonly PUIParentScope?: import('./.proto-ui/context/scope-v1').ContextScope | null }} PUIOwnerInstance */
${ssr ? '' : '/** @typedef {(renderer: PUINativeRenderer) => PUINativePaint} PUIRenderFunction */'}
/** @typedef {{ changedKeysAll: string[], changedKeysMatched: string[] }} PUIPropsWatchInfo */
/** @template Run @template Snapshot @typedef {(run: Run, next: Snapshot, previous: Snapshot, info: PUIPropsWatchInfo) => void} PUIPropsWatchCallback */
/** @template Run @typedef {{ kind: 'resolved' | 'resolved-all', keys: readonly string[] | null, fn: PUIPropsWatchCallback<Run, PUIResolvedProps> } | { kind: 'raw' | 'raw-all', keys: readonly string[] | null, fn: PUIPropsWatchCallback<Run, PUIRawProps> }} PUIPropsWatchRegistration */
/** @typedef {${lifecycleKeys.map((key) => JSON.stringify(key)).join(' | ')}} PUILifecycleKind */
/** @template Run @typedef {(run: Run) => void} PUILifecycleCallback */
/** @template Run @typedef {PUIPropsWatchRegistration<Run> & { active: boolean }} PUIPropsWatcher */
/** @typedef {{ epoch: number, revision: number, kind: 'update' }} PUIPendingCommit */
/** @typedef {{ epoch: number, version: number, present: boolean, vnode: import('vue').VNode, kind: 'mount' | 'update' | 'none' | 'detach', revision?: number | null }} PUIRenderedCommit */
/** @param {unknown} value @param {PropertyKey} key */
const PUIOwn = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
${
  stateful
    ? `// Keep native relational coercion in all three open-schema comparisons.
/** @template T @param {T} left @param {T} right */
const PUIBefore = (left, right) => left < right;
`
    : ''
}
/** @param {PUIDataType} type @param {unknown} value @returns {boolean} */
function PUIAccepts(type, value) {
  if (typeof type === 'string') return type === 'null' ? value === null : typeof value === type && (type !== 'number' || Number.isFinite(value));
  if (type.kind === 'literal') return Object.is(value, type.value);
  if (type.kind === 'union') return type.members.some((member) => PUIAccepts(member, value));
  if (type.kind === 'array') return Array.isArray(value) && value.every((item) => PUIAccepts(type.element, item));
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false;
  const record = /** @type {Record<string, unknown>} */ (value);
  return type.fields.every((field) =>
    PUIOwn(record, field.name) ? PUIAccepts(field.type, record[field.name]) : field.optional === true);
}
/** @param {unknown} value @param {Set<object>} [seen] @returns {boolean} */
function PUIJson(value, seen = new Set()) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return true;
  if (typeof value === 'number') return Number.isFinite(value);
  if (typeof value !== 'object' || seen.has(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  if (!Array.isArray(value) && prototype !== Object.prototype && prototype !== null) return false;
  if (Array.isArray(value) && (Object.keys(value).length !== value.length || !Object.keys(value).every((key) => /^(0|[1-9]\d*)$/.test(key) && Number(key) < value.length))) return false;
  seen.add(value);
  const valid = Object.values(value).every((item) => PUIJson(item, seen));
  seen.delete(value);
  return valid;
}
${
  ssr
    ? String.raw`function PUIElement(tag, a, b) {
  const props = a !== null && typeof a === 'object' && !Array.isArray(a) && !PUIOwn(a, 'tag') && !PUIOwn(a, 'slot');
  const children = arguments.length > 2 ? b : props ? null : a;
  ${styled ? "const tokens = props && PUIOwn(a, 'style') ? PUITemplateStyleTokens(a.style) : undefined;" : ''}
  return Object.freeze({ tag, children${styled ? ', tokens' : ''} });
}
function PUIChildren(value, h, vm, slots) {
  if (value === null || value === undefined) return [];
  if (Array.isArray(value)) return value.flatMap((item) => PUIChildren(item, h, vm, slots));
  if (typeof value === 'string' || typeof value === 'number') return [value];
  if (typeof value !== 'object') throw new TypeError('[Vue2 native] template children must be text, elements, slots or null.');
  if (value.slot) {
    if (slots.used) throw new Error('[Vue2 native] only one default slot is supported.');
    slots.used = true;
    const scoped = vm.$scopedSlots && vm.$scopedSlots.default;
    const nodes = scoped ? scoped({}) : vm.$slots && vm.$slots.default;
    return nodes ? Array.isArray(nodes) ? nodes : [nodes] : [];
  }
  if (typeof value.tag !== 'string') throw new TypeError('[Vue2 native] invalid semantic element.');
  // Vue2's pre flag prevents a registered component from hijacking a semantic DOM tag.
  return [h(value.tag, { pre: true${styled ? ", attrs: value.tokens === undefined ? {} : { 'data-pui-style': value.tokens }" : ''} }, PUIChildren(value.children, h, vm, slots))];
}`
    : ''
}
${
  interactive || ssr
    ? `/** @param {Readonly<Record<string, string | number | boolean | null>>} properties @param {Record<string, string | null>} attrs @param {boolean} initial */
function PUIRootData(properties, attrs, initial) {
  /** @type {import('vue').VNodeData & { pre: true, attrs: Record<string, string | number | null> }} */
  const result = { pre: true, attrs: { ...attrs } };
  for (const [key, value] of Object.entries(properties)) {
    if (key === 'value') { if (initial) result.domProps = { value }; }
    else if (key === 'style') { if (typeof value === 'string') result.style = value; }
    else result.attrs[key] = value === false ? null : value === true ? '' : value;
  }
  return result;
}`
    : ''
}
${ssr ? '' : '/** @param {PUIOwnerInstance} vm @param {(owner: PUIOwner) => PUIRenderFunction | void} setup @param {Record<string, PUIDataType>} types @param {string} rootTag @param {boolean} autoUpdate */'}
function PUICreateOwner(vm, setup, types, rootTag, autoUpdate) {
  ${
    ssr
      ? `let session, initialProjection, requestIndex, sourceIdentity;
  let initialized = false;
  let shell = false;
  let bootRaw = false;
  let firstContinuation = false;`
      : ''
  }
  let phase = 'setup';
  let terminal = false;
  let disposed = false;
  let hydrated = false;
  let nativeMounted = false;
  let hostActive = true;
  let present = true;
  let viewActive = false;
  let epoch = 0;
  let revision = 0;
  let commitVersion = 0;
  let queued = false;
  /** @type {PUIPendingCommit | null} */
  let pending = null;
  /** @type {PUIRenderedCommit | null} */
  let renderedCommit = null;
  ${styled || interactive ? `/** @type {${interactive ? 'HTMLElement' : 'Element'} | null} */ let activeRoot = null;` : ''}
  ${interactive ? 'let activeEpoch = -1;' : ''}
  ${ssr ? '' : '/** @type {PUINativePaint | null} */'}
  let template = null;
  ${ssr ? '' : '/** @type {PUIRenderFunction | null | void} */'}
  let renderFunction;
  /** @type {(() => void) | undefined} */
  let unwatch;
  /** @type {PUIRawProps} */
  let raw = Object.freeze({});
  /** @type {PUIResolvedProps} */
  let resolved = /** @type {PUIResolvedProps} */ (Object.freeze({}));
  /** @type {Record<string, unknown>} */
  let previousValid = Object.create(null);
  /** @type {Record<string, PUIPropSpec>} */
  let specs = Object.create(null);
  /** @type {PUIRawProps[]} */
  const defaults = [];
  /** @type {Array<PUIPropsWatcher<typeof run>>} */
  const watchers = [];
${stateful ? '  /** @type {Array<{ dispose: () => void }>} */\n  const states = [];\n' : ''}  /** @type {Record<string, unknown>} */
  const exposed = Object.create(null);
  /** @type {Record<string, unknown>} */
  const eventDeclarations = Object.create(null);
  /** @type {Record<PUILifecycleKind, Array<PUILifecycleCallback<typeof run>>>} */
  const lifecycle = { ${lifecycleKeys.map((key) => `${JSON.stringify(key)}: []`).join(', ')} };
${stateful ? '  /** @type {Array<() => void>} */\n  const notifications = [];\n' : ''}  ${
    interactive
      ? `/** @type {WeakMap<object, PUIExternalState<unknown>>} */
  const observedExternals = new WeakMap();
  /** @template T @param {{ get: () => T }} state @returns {PUIExternalState<T>} */
  function externalState(state) {
    const external = observedExternals.get(state);
    if (!external) throw new Error('[State] handle does not belong to this generated owner.');
    // Registration binds this exact handle to its same-value external view.
    return /** @type {PUIExternalState<T>} */ (external);
  }`
      : ''
  }
${stateful ? '  let notifying = false;\n' : ''}${
    portal
      ? `  let portalAnchor = null, portalRoot = null;
  function syncPortal(target, destination) {
    if (portalRoot && portalRoot !== target) restorePortal();
    if (destination && target?.nodeType === 1) {
      if (!portalAnchor) { portalAnchor = target.ownerDocument.createComment('pui-portal'); target.parentNode?.insertBefore(portalAnchor, target); portalRoot = target; }
      if (target.parentNode !== destination) destination.appendChild(target);
    } else restorePortal();
  }
  function restorePortal() {
    const target = portalRoot, anchor = portalAnchor, moveEpoch = epoch;
    // Relinquish this move before DOM callbacks can reenter the same owner.
    portalAnchor = portalRoot = null;
    const failures = [];
    let restored = false;
    if (target && anchor?.parentNode) {
      try { anchor.parentNode.insertBefore(target, anchor); restored = true; }
      catch (error) { failures.push(error); }
    }
    // A failed DOM operation may have admitted a newer open synchronously.
    // Transfer this still-owned move to it rather than erase its Root/anchor.
    const handedToNewer = target && !restored && !terminal && present
      && epoch !== moveEpoch && !portalRoot && !portalAnchor;
    if (handedToNewer) { portalRoot = target; portalAnchor = anchor; }
    // A lost/failed anchor must not strand an old view in the Portal host.
    // Never remove resources already claimed by a newer reentrant move.
    if (!handedToNewer && target && !restored && portalRoot !== target) {
      try { target.remove(); } catch (error) { failures.push(error); }
    }
    if (!handedToNewer && anchor && portalAnchor !== anchor) {
      try { anchor.remove(); } catch (error) { failures.push(error); }
    }
    if (failures.length) throw failures.length === 1 ? failures[0]
      : new AggregateError(failures, '[Vue2 native] Portal restoration and cleanup failed.');
  }
`
      : ''
  }  let dispatchingProps = false;
  /** @type {{raw: PUIRawProps; resolved: PUIResolvedProps} | null} */
  let propsWindow = null;
  const alive = () => { if (disposed) throw new Error('[Vue2 native] logical instance has been disposed.'); };
  const publicAlive = () => { if (terminal) throw new Error('[Vue2 native] exposed target has been terminally invalidated.'); };
  const callback = () => { alive(); if (phase !== 'callback') throw new Error('[Vue2 native] mutation requires callback scope.'); };
  const setupOnly = () => { alive(); if (phase !== 'setup') throw new Error('[Vue2 native] declaration requires setup scope.'); };
${
  styled
    ? `  const style = PUICreateNativeStyle({
    ensureSetup: setupOnly,
    ensureRuntime: callback,
    isAlive: () => !terminal && !disposed,
    project: (tokens) => {
      if (!activeRoot) return;
      if (tokens.length) activeRoot.setAttribute('data-pui-style', tokens.join(' '));
      else activeRoot.removeAttribute('data-pui-style');
    },
  });`
    : ''
}
  /** @returns {PUIRawProps} */
  const hostRaw = () => {
    ${ssr ? `if (bootRaw) return PUIDecodeRaw(initialProjection.raw);` : ''}
    // Full snapshots preserve omission and explicit undefined. Vue Boolean casting and
    // default materialization never participate in the semantic prop contract.
    const out = Object.create(null);
    /** @type {Record<string, unknown>} */
    const input = { ...(vm.$attrs || {}), ...((vm.$options && vm.$options.propsData) || {}) };
    /** @type {Readonly<Record<string, unknown>>} */
    const provided = /** @type {Readonly<Record<string, unknown>>} */ ((vm.$options && vm.$options.propsData) || {});
    for (const key of Object.keys(types)) {
      const hostKey = key.replace(/-(\w)/g, (_match, letter) => letter.toUpperCase());
      // Track native prop notifications, but keep values/presence from the raw snapshot.
      if (vm.$props) void (/** @type {Readonly<Record<string, unknown>>} */ (vm.$props))[hostKey];
      if (PUIOwn(provided, hostKey)) input[key] = provided[hostKey];
    }
    for (const key of Object.keys(input)) if (key !== 'instanceAssociations' && key !== 'instance-associations') out[key] = input[key];
    return Object.freeze(out);
  };
  /** @param {PUIRawProps} a @param {PUIRawProps} b */
  const same = (a, b) => {
    const keys = Object.keys(a);
    return keys.length === Object.keys(b).length && keys.every((key) => PUIOwn(b, key) && Object.is(a[key], b[key]));
  };
  /** @param {string} key @param {unknown} value */
  const validValue = (key, value) => {
    const spec = specs[key];
    if (!PUIJson(value) || !PUIAccepts(types[key], value)) return false;
    if (spec.type === 'enum' && (typeof value !== 'string' || !spec.options?.includes(value))) return false;
    return !spec.range || typeof value === 'number' && value >= (spec.range.min ?? -Infinity) && value <= (spec.range.max ?? Infinity);
  };
  /** @param {PUIRawProps} input @param {boolean} strict */
  const resolveProps = (input, strict) => {
    /** @type {Record<string, unknown>} */
    const out = Object.create(null);
    const nextValid = { ...previousValid };
    /** @type {{ providedKeys: string[], emptyKeys: string[], invalidKeys: string[], usedFallbackKeys: string[], acceptedEmptyKeys: string[] }} */
    const meta = { providedKeys: [], emptyKeys: [], invalidKeys: [], usedFallbackKeys: [], acceptedEmptyKeys: [] };
    for (const key of Object.keys(specs)) {
      const spec = specs[key];
      const provided = PUIOwn(input, key);
      const value = input[key] === undefined ? null : input[key];
      const empty = spec.empty ?? 'fallback';
      if (provided) meta.providedKeys.push(key);
      if (provided && value !== null && validValue(key, value)) {
        out[key] = value; nextValid[key] = value; continue;
      }
      if (provided && value === null) {
        meta.emptyKeys.push(key);
        if (empty === 'accept') { out[key] = null; meta.acceptedEmptyKeys.push(key); continue; }
      } else if (provided) meta.invalidKeys.push(key);
      let found = false;
      /** @type {unknown} */
      let selected = null;
      let usedDefault = true;
      /** @param {unknown} candidate @param {boolean} fromDefault */
      const take = (candidate, fromDefault) => {
        if (found || candidate === undefined || strict && empty === 'error' && candidate === null) return;
        if (candidate !== null && !validValue(key, candidate)) return;
        found = true; selected = candidate; usedDefault = fromDefault;
      };
      if (provided && PUIOwn(previousValid, key)) take(previousValid[key], false);
      for (const layer of defaults) if (PUIOwn(layer, key)) take(layer[key], true);
      if (PUIOwn(spec, 'default')) take(spec.default, true);
      if (!found && strict && empty === 'error') throw new Error('[Vue2 native] prop ' + key + ' requires a non-empty valid value or fallback.');
      out[key] = selected;
      if (usedDefault) meta.usedFallbackKeys.push(key);
      if (provided && selected !== null) nextValid[key] = selected;
    }
    previousValid = nextValid;
    /** @type {PUIResolvedProps} */
    const snapshot = /** @type {PUIResolvedProps} */ (Object.freeze(out));
    return { snapshot, meta };
  };
  /** @template T @param {() => T} fn @param {boolean} [sync] @returns {T} */
  const invoke = (fn, sync = true) => {
    alive();
    const previousPhase = phase;
    phase = 'callback';
    try { if (sync && !terminal ${ssr ? '&& !(firstContinuation && !bootRaw)' : ''}) syncHost(false); return fn(); }
    finally { phase = previousPhase; }
  };
  /** @param {boolean} request */
  const syncHost = (request) => {
    if (terminal) return;
${controlLabel ? '    interaction.refresh();' : emitUndeclaredInstanceAssociations('vm.instanceAssociations', 'PUIAssociations')}
    const nextRaw = hostRaw();
    if (hydrated && same(raw, nextRaw)) return;
    const previousRaw = raw;
    const previous = resolved;
    const next = resolveProps(nextRaw, true);
    raw = nextRaw; resolved = next.snapshot;
    if (!hydrated) { hydrated = true; ${refresh} return; }
    const changedKeys = Object.keys(specs).filter((key) => !Object.is(previous[key], resolved[key]));
    const changedRawKeys = watchers.some((watch) => watch.active && (watch.kind === 'raw' || watch.kind === 'raw-all'))
      ? [...new Set([...Object.keys(previousRaw), ...Object.keys(raw)])].filter((key) => PUIOwn(previousRaw, key) !== PUIOwn(raw, key) || !Object.is(previousRaw[key], raw[key])) : [];
    ${refresh ? `if (changedKeys.length) { ${refresh} }` : ''}
    if ((changedKeys.length || changedRawKeys.length) && !dispatchingProps) {
      dispatchingProps = true;
      const previousWindow = propsWindow; propsWindow = {raw: nextRaw, resolved: next.snapshot};
      try {
        invoke(() => {
          // Raw-all precedes raw-keyed; resolved-all and keyed share declaration order.
          const snapshot = watchers.slice();
          for (let group = 0; group < 3; ++group) {
            for (const watch of snapshot) {
              if (!watch.active || (watch.kind === 'raw-all' ? 0 : watch.kind === 'raw' ? 1 : 2) !== group) continue;
              const isRaw = group < 2;
              const changedKeysAll = isRaw ? changedRawKeys : changedKeys;
              const changedKeysMatched = watch.keys === null ? changedKeysAll : watch.keys.filter((key) => changedKeysAll.includes(key));
              if (changedKeysMatched.length) {
                const info = { changedKeysAll: [...changedKeysAll], changedKeysMatched: [...changedKeysMatched] };
                // The registration discriminant preserves the raw/resolved callback
                // relation; the host group order and snapshot copies stay unchanged.
                if (watch.kind === 'raw' || watch.kind === 'raw-all') watch.fn(run, nextRaw, previousRaw, info);
                else watch.fn(run, next.snapshot, previous, info);
              }
            }
          }
        }, false);
      } finally { propsWindow = previousWindow; dispatchingProps = false; }
    }
    if (request && autoUpdate) update();
  };
  const renderSemantic = () => {
    if (!renderFunction) throw new Error('[Vue2 native] renderer is unavailable outside the initialized instance lifetime.');
    const previousPhase = phase;
    phase = 'render';
    try { template = renderFunction(renderer); }
    finally { phase = previousPhase; }
  };
  const force = () => { if (!terminal && nativeMounted) vm.$forceUpdate(); };
  const update = () => {
    if (terminal) return;
    invoke(() => {}, true);
    if (!nativeMounted || !hostActive || !present || !viewActive) return;
    if (pending) { queued = true; return; }
    renderSemantic();
    pending = { epoch, revision: ++revision, kind: 'update' };
    force();
  };
  /** @param {boolean} next */
  const setPresent = (next) => {
    callback();
    if (terminal) throw new Error('[Vue2 native] presence is locked for terminal disposal.');
    if (present === next) return;
    present = next; ++epoch; pending = null; renderedCommit = null; queued = false;
    const requestedEpoch = epoch, failures = [];
    // Vue must patch at the owned anchor, not leave its replacement comment
    // in the Portal host and later resurrect the already-removed Root.
    ${portal ? 'if (!next) { try { restorePortal(); } catch (error) { failures.push(error); } }' : ''}
    if (!terminal && epoch === requestedEpoch && present === next) {
      ${interactive ? 'if (!next) { try { interaction.unmount(); } catch (error) { failures.push(error); } }' : ''}
      if (!terminal && epoch === requestedEpoch && present === next) {
        // A newer presence request or terminal disposal always wins reentry.
        try {
          if (next && nativeMounted && hostActive && viewActive) renderSemantic();
          force();
        } catch (error) { failures.push(error); }
      }
    }
    if (failures.length) throw failures.length === 1 ? failures[0]
      : new AggregateError(failures, '[Vue2 native] presence withdrawal failed.');
  };
${context.owner}
  ${atoms.owner({ setup: 'setupOnly()', runtime: 'callback()', alive: '!disposed', invoke: 'invoke(callback, false)', invokeRun: 'invoke(() => callback(run), false)', document: "vm.$el?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document)", run: 'PUIRun', typed: false })}
${
  hasAuthoredHooks
    ? `  /** @type {(() => void)[]} */ const PUIAuthoredWatchCleanups = [];
  const PUIAuthored = PUICreateAuthored({setup: setupOnly, borrow(/** @type {unknown} */ value) {
    ${
      stateful
        ? `
    const state = /** @type {PUIOwnedState<unknown>} */ (value);
    return Object.freeze({get: () => state.get(), setDefault: (/** @type {unknown} */ value) => state.setDefault(value), set: (/** @param {unknown} value @param {unknown} [reason] */ (value, reason) => state.set(value, reason)), watch: (/** @type {(run: PUIRun, event: PUIStateEvent<unknown>) => void} */ fn) => { setupOnly(); const off = state.external.subscribe(event => invoke(() => fn(run, event), false)); PUIAuthoredWatchCleanups.push(off); return off; }});
    `
        : 'return value;'
    }
  }});`
    : ''
}
  ${publicCalls ? `const PUIWrapPublic = PUICreatePublicCalls({alive: publicAlive, invoke});` : ''}
  const run = {
    ${context.run}
    ${styled ? 'feedback: { style },' : ''}
    update: () => { callback(); update(); },
    props: {
      get: () => { alive(); return propsWindow?.resolved ?? resolved; },
      getRaw: () => { alive(); return propsWindow?.raw ?? raw; },
      isProvided: (/** @param {PropertyKey} key */ (key) => { alive(); return PUIOwn(propsWindow?.raw ?? raw, key); }),
    },
    lifecycle: { setPresent },
    expose: { emit: (/** @param {string} key @param {unknown} [payload] @param {unknown} [options] */ (key, payload, options) => {
      callback();
      if (!PUIOwn(eventDeclarations, key)) throw new Error('[Vue2 native] undeclared expose event: ' + key);
      const listener = vm.$attrs && (/** @type {Readonly<Record<string, unknown>>} */ (vm.$attrs))['on' + key[0].toUpperCase() + key.slice(1)];
      // Host sink failures do not re-enter authored callbacks, matching the Vue2 sink.
      try { if (typeof listener === 'function') listener(payload, options); } catch {}
      try { vm.$emit(key, payload, options); } catch {}
    }) },
  };
  ${
    interactive
      ? atomicInteractive
        ? `/** @type {PUINativeInteraction<typeof run>} */
  const interaction = PUICreateNativeInteraction({
    ${imageConfig ? 'imageConfig: ' + imageConfig + ',\n    ' : ''}ensureSetup: setupOnly, ensureRuntime: callback,
    isAlive: () => !terminal && !disposed,
    isReady: () => phase !== 'setup' && viewActive && present && hostActive && !terminal,
    invoke: (fn) => invoke(fn), getRun: () => run,
    getRoot: () => viewActive && present && hostActive && activeEpoch === epoch ? activeRoot : null,
    identity: contextScope, getLogicalParent: () => vm[${JSON.stringify('PUIParentScope')}] || null,
    getExposes: () => exposed,
    requestHostUpdate: force,
  });`
        : `/** @type {PUINativeInteraction<typeof run>} */
  const interaction = PUICreateNativeInteraction({
    ensureSetup: setupOnly,
    ensureRuntime: callback,
    ensureEvent: callback,
    isAlive: () => !terminal && !disposed,
    isSetupComplete: () => phase !== 'setup',
    isReady: () => phase !== 'setup' && viewActive && present && hostActive && !terminal,
    invoke: (fn) => invoke(fn),
    getRun: () => run,
    getResolvedProps: () => resolved,
${controlLabel ? '    getAssociations: () => PUINormalizeAssociations(vm.instanceAssociations, (/** @type {{_base?: {observable?: (value: object) => object}}} */ (vm.$options))._base?.observable),\n' : ''}
    subscribeState: (state, fn) => externalState(state).subscribe(fn),
    getRoot: () => viewActive && present && hostActive && activeEpoch === epoch ? activeRoot : null,
    identity: contextScope, getLogicalParent: () => vm[${JSON.stringify('PUIParentScope')}] || null,
    declarations: ${declarations}, tableFamily: ${tableFamily},
    getExposes: () => exposed,
    registerExpose: (key, value) => {
      setupOnly(); if (PUIOwn(exposed, key)) throw new Error('[Expose] duplicate declaration: ' + key);
      if (value !== null && typeof value === 'object' && observedExternals.has(value)) exposed[key] = observedExternals.get(value);
      else if (typeof value === 'function') exposed[key] = (/** @param {unknown[]} args */ (...args) => { publicAlive(); return invoke(() => value(...args)); });
      else exposed[key] = value;
    },
    createOwnedState: (name, value, spec) => createState(spec?.kind ?? (typeof value === 'boolean' ? 'bool' : typeof value === 'number' ? 'number.discrete' : 'string'), name, value, spec),
    watchState: (state, fn) => { setupOnly(); return externalState(state).subscribe(event => invoke(() => fn(run, event))); },
    isPropProvided: key => PUIOwn(raw, key),
    setPresent, requestHostUpdate: force,
    emit: (key) => run.expose.emit(key),
    registerGenericObservedState: (handle) => {
      /** @type {Set<(event: PUIStateEvent<ReturnType<typeof handle.get>>) => void>} */
      const subscribers = new Set();
      const off = handle.subscribe((event) => {
        ${refresh}
        ${emitRecordedNotification({ queue: 'notifications', draining: 'notifying', subscribers: 'subscribers', deliver: 'subscriber(event)', typed: false })}
      });
      /** @type {PUIExternalState<ReturnType<typeof handle.get>>} */
      const external = Object.freeze({
        get: () => { publicAlive(); return handle.get(); },
        subscribe: (fn) => { publicAlive(); /** @type {typeof fn} */ const registration = (/** @type {Parameters<typeof fn>[0]} */ event) => fn(event); subscribers.add(registration); return () => subscribers.delete(registration); },
        unsubscribe: (unsubscribe) => { publicAlive(); if (typeof unsubscribe === 'function') unsubscribe(); },
        spec: Object.freeze({ kind: typeof handle.get() === 'boolean' ? 'bool' : typeof handle.get() === 'number' ? 'number.discrete' : 'string', observed: true }),
      });
      observedExternals.set(handle, external);
      states.push({ dispose: () => {
        off();
        try { for (const fn of Array.from(subscribers)) fn({ type: 'disconnect', reason: 'unmount' }); }
        finally { subscribers.clear(); }
      } });
    },
  });`
      : ''
  }
  ${ssr ? '' : '/** @type {PUINativeRenderer} */'}
  const renderer = { ${
    ssr
      ? 'el: PUIElement, slot: () => Object.freeze({ slot: true }),'
      : `
    slot: () => /** @type {PUINativePaint} */ ((_h, nativeVm, slots) => {
      if (slots.used) throw new Error('[Vue2 native] only one default slot is supported.');
      slots.used = true;
      const scoped = nativeVm.$scopedSlots.default;
      return (scoped ? scoped({}) : nativeVm.$slots.default) || [];
    }),`
  }
    read: Object.freeze({ props: Object.freeze({ get: () => { alive(); return resolved; }, getRaw: () => { alive(); return raw; }, isProvided: (/** @param {PropertyKey} key */ (key) => { alive(); return PUIOwn(raw, key); }) }) ${context.read} }) };
${
  stateful
    ? String.raw`  /**
   * @template T
   * @param {T} initial
   * @param {Readonly<Record<string, unknown>>} spec
   * @param {(value: T, initialValue?: boolean) => T} check
   * @returns {PUIOwnedState<T>}
   */
  const createStateCell = (initial, spec, check) => {
    let value = check(initial, true);
    /** @type {Set<(event: PUIStateEvent<T>) => void>} */
    const subscribers = new Set();
    /** @type {PUIOwnedState<T>} */
    const handle = {
      get: () => { alive(); return value; },
      setDefault: next => { setupOnly(); value = check(next, true); },
      set: (next, reason) => {
        callback();
        next = check(next);
        if (Object.is(value, next)) return;
        const previous = value; value = next;
        ${refresh}
        /** @type {PUIStateEvent<T>} */
        const event = { type: 'next', prev: previous, next, reason };
        ${emitRecordedNotification({ queue: 'notifications', draining: 'notifying', subscribers: 'subscribers', deliver: 'subscriber(event)', typed: false })}
      },
      external: {
        get: () => { publicAlive(); return handle.get(); },
        subscribe: (fn) => { publicAlive(); /** @type {typeof fn} */ const registration = (/** @type {Parameters<typeof fn>[0]} */ event) => fn(event); subscribers.add(registration); return () => subscribers.delete(registration); },
        unsubscribe: (off) => { publicAlive(); if (typeof off === 'function') off(); },
        spec,
      },
      dispose: () => {
        try { for (const fn of Array.from(subscribers)) fn({ type: 'disconnect', reason: 'unmount' }); }
        finally { subscribers.clear(); }
      },
    };
    ${interactive ? 'observedExternals.set(handle, handle.external);' : ''}
    states.push(handle);
    return handle;
  };
  /** @template {boolean | string | number} T @param {PUIStateKind} kind @param {string} key @param {T} initial @param {PUIStateConfiguration} [configuration] @returns {PUIOwnedState<T>} */
  const createState = (kind, key, initial, configuration = {}) => {
    setupOnly();
    const spec = Object.freeze({ ...configuration, kind });
    /** @param {T} value @param {boolean} [initialValue] @returns {T} */
    const check = (value, initialValue = false) => {
      const expected = kind === 'bool' ? 'boolean' : kind === 'string' || kind === 'enum' ? 'string' : 'number';
      if (typeof value !== expected || expected === 'number' && !Number.isFinite(value)) throw new TypeError('[Vue2 native] invalid state value: ' + key);
      if (spec.options && spec.options.length && !spec.options.includes(value)) throw new Error('[Vue2 native] state value not in options: ' + key);
      // Numeric-family schemas prove these numeric views. Other families keep
      // their structurally admitted extra fields and native relational coercion.
      if (kind === 'number.range' && initialValue && spec.clamp) value = /** @type {T} */ (Math.min(/** @type {number} */ (spec.max), Math.max(/** @type {number} */ (spec.min), /** @type {number} */ (value))));
      if (!(kind === 'number.discrete' && spec.options && spec.options.length) && (spec.min !== undefined && PUIBefore(value, spec.min) || spec.max !== undefined && PUIBefore(spec.max, value))) throw new Error('[Vue2 native] state value out of range: ' + key);
      if (kind === 'number.discrete' && !(spec.options && spec.options.length) && PUIBefore(0, spec.step) && !Number.isInteger((/** @type {number} */ (value) - /** @type {number} */ (spec.min ?? 0)) / /** @type {number} */ (spec.step))) throw new Error('[Vue2 native] state value violates step: ' + key);
      return value;
    };
    ${hasAuthoredHooks ? 'PUIAuthored.claimState(key);' : ''}
    const handle = createStateCell(initial, spec, check);
    ${hasAuthoredHooks ? 'PUIAuthored.state(key, handle);' : ''}
    return handle;
  };
`
    : ''
}  /** @param {Record<string, PUIPropSpec>} input */
  const defineProps = (input) => {
    setupOnly();
    const next = { ...specs };
    const rank = { accept: 0, fallback: 1, error: 2 };
    for (const key of Object.keys(input)) {
      const spec = input[key];
      if (!spec || !['boolean', 'number', 'string', 'object', 'any', 'enum'].includes(spec.type)) throw new Error('[Vue2 native] invalid prop declaration: ' + key);
      if (spec.empty !== undefined && !PUIOwn(rank, spec.empty)) throw new Error('[Vue2 native] invalid empty behavior: ' + key);
      if (spec.type === 'enum' && (!Array.isArray(spec.options) || !spec.options.length || !spec.options.every((value) => typeof value === 'string'))) throw new Error('[Vue2 native] invalid enum options: ' + key);
      if (spec.type !== 'enum' && PUIOwn(spec, 'options')) throw new Error('[Vue2 native] only enum props accept options: ' + key);
      if (PUIOwn(spec, 'default') && !PUIJson(spec.default)) throw new Error('[Vue2 native] non-JSON prop default: ' + key);
      const prior = next[key];
      if (prior) {
        if (prior.type !== spec.type || PUIOwn(spec, 'empty') && spec.empty !== undefined && rank[spec.empty] > rank[prior.empty ?? 'fallback']) throw new Error('[Vue2 native] conflicting prop declaration: ' + key);
        if (prior.options && !prior.options.every((value) => spec.options && spec.options.includes(value))) throw new Error('[Vue2 native] prop options cannot narrow: ' + key);
        if (prior.range && spec.range && ((spec.range.min ?? -Infinity) > (prior.range.min ?? -Infinity) || (spec.range.max ?? Infinity) < (prior.range.max ?? Infinity))) throw new Error('[Vue2 native] prop range cannot narrow: ' + key);
        next[key] = { ...prior, ...spec, empty: prior.empty ?? 'fallback', range: spec.range ?? prior.range };
        if (PUIOwn(prior, 'default')) next[key].default = prior.default;
      } else next[key] = { ...spec };
    }
    specs = next; resolved = resolveProps(raw, false).snapshot;
  };
  /** @param {PUIPropsWatcher<typeof run>} watch */
  const registerPropsWatch = (watch) => {
    setupOnly();
    const { kind, keys } = watch;
    if (keys !== null && (!keys.length || keys.some((key) => typeof key !== 'string'
      || kind === 'resolved' && !PUIOwn(specs, key)))) throw new Error('[Vue2 native] watch requires non-empty valid prop keys.');
    watch.keys = keys === null ? null : [...keys];
    watchers.push(watch);
    return () => { watch.active = false; };
  };
  /** @type {readonly PUILifecycleKind[]} */
  const lifecycleKeys = ${JSON.stringify(lifecycleKeys)};
  const def = {
    ${context.def}
    ${styled ? 'feedback: { style },' : ''}
    ${eventSupport ? 'event: interaction.event,' : ''}
    props: {
      define: defineProps,
      setDefaults: (/** @param {PUIRawProps} layer */ (layer) => {
        setupOnly();
        for (const key of Object.keys(layer)) if (!PUIOwn(specs, key) || !PUIJson(layer[key])) throw new Error('[Vue2 native] invalid prop default: ' + key);
        defaults.unshift({ ...layer }); resolved = resolveProps(raw, false).snapshot;
      }),
      /** @param {readonly string[]} keys @param {PUIPropsWatchCallback<typeof run, PUIResolvedProps>} fn */
      watch: (keys, fn) => registerPropsWatch({ kind: 'resolved', keys, fn, active: true }),
      /** @param {PUIPropsWatchCallback<typeof run, PUIResolvedProps>} fn */
      watchAll: (fn) => registerPropsWatch({ kind: 'resolved-all', keys: null, fn, active: true }),
      /** @param {readonly string[]} keys @param {PUIPropsWatchCallback<typeof run, PUIRawProps>} fn */
      watchRaw: (keys, fn) => registerPropsWatch({ kind: 'raw', keys, fn, active: true }),
      /** @param {PUIPropsWatchCallback<typeof run, PUIRawProps>} fn */
      watchRawAll: (fn) => registerPropsWatch({ kind: 'raw-all', keys: null, fn, active: true }),
    },
${
  stateful
    ? String.raw`    state: {
      /** @param {string} key @param {boolean} value */
      bool: (key, value) => createState('bool', key, value),
      /** @param {string} key @param {string} value @param {PUIStateConfiguration} [spec] */
      string: (key, value, spec) => createState('string', key, value, spec),
      /** @param {string} key @param {string} value @param {PUIStateConfiguration} [spec] */
      enum: (key, value, spec) => createState('enum', key, value, spec),
      /** @param {string} key @param {number} value @param {PUIStateConfiguration} [spec] */
      numberDiscrete: (key, value, spec) => createState('number.discrete', key, value, spec),
      /** @param {string} key @param {number} value @param {PUIStateConfiguration} spec */
      numberRange: (key, value, spec) => createState('number.range', key, value, spec),
    },
`
    : ''
}    expose: {
      /** @param {string} key @param {unknown} value */
      value: (key, value) => { setupOnly(); if (PUIOwn(exposed, key)) throw new Error('[Expose] duplicate declaration'); exposed[key] = value; },
      /** @template T @param {string} key @param {${interactive ? '{get(): T}' : '{ external: PUIExternalState<T> }'}} handle */
      state: (key, handle) => { setupOnly(); exposed[key] = ${interactive ? 'externalState(handle)' : 'handle.external'}; ${hasAuthoredHooks ? 'PUIAuthored.introduceObserved(handle);' : ''} },
      /** @template {unknown[]} Args @template Result @param {string} key @param {(...args: Args) => Result} fn @param {(value: Result) => Result} [project] */
      method: (key, fn, project) => { setupOnly(); ${hasAuthoredHooks ? 'PUIAuthored.method(key, fn);' : ''} exposed[key] = (/** @param {Args} args */ (...args) => { publicAlive(); const result = invoke(() => fn(...args)); return project ? project(result) : result; }); },
      /** @param {string} key @param {unknown} [spec] */
      event: (key, spec) => { setupOnly(); eventDeclarations[key] = spec; },
    },
    lifecycle: Object.fromEntries(lifecycleKeys.map((key) => {
      /** @type {[string, (fn: PUILifecycleCallback<typeof run>) => void]} */
      const entry = ['on' + key[0].toUpperCase() + key.slice(1), (fn) => { setupOnly(); lifecycle[key].push(fn); }];
      return entry;
    })),
  };
  /** @param {PUILifecycleKind} kind */
  const fire = (kind) => invoke(() => { if (kind === 'unmounted') { ${atoms.detach} } try { for (const fn of lifecycle[kind]) fn(run); } finally { if (kind === 'unmounted') { ${atoms.detach} } } }, !terminal);
  const detach = () => {
    if (!viewActive) return;
    viewActive = false; pending = null; queued = false;
    ${portal ? 'restorePortal();' : ''}
    ${interactive ? 'interaction.unmount();' : ''}
    ${styled ? "style.unmount();\n    if (activeRoot) activeRoot.removeAttribute('data-pui-style');" : ''}
    ${styled || interactive ? 'activeRoot = null;' : ''}
    fire('unmounted');
  };
  const afterCommit = () => {
    if (terminal) return;
    ${ssr ? 'if (!firstContinuation) syncHost(true);' : 'syncHost(true);'}
    const commit = renderedCommit;
    if (!commit) return;
    renderedCommit = null;
    const target = vm.$el;
    // Removal has already committed when Vue calls updated. Do not postpone its
    // unmount notification into a tick which may belong to a replacement view.
    if (!commit.present && commit.vnode.elm === target) { detach(); return; }
    vm.$nextTick(() => {
      if (terminal || commit.epoch !== epoch || commit.version !== commitVersion || vm.$el !== target || commit.vnode.elm !== target) return;
      if (!present || !hostActive) return;
      ${
        interactive
          ? `const elementType = target.ownerDocument.defaultView?.HTMLElement;
      if (!elementType || !(target instanceof elementType)) throw new Error('[Vue2 native] interaction Root must be an HTML element.');`
          : ''
      }
      ${portal ? 'syncPortal(target, interaction.portalTarget());' : ''}
      const kind = commit.kind;
      if (kind === 'mount' && !viewActive) {
        viewActive = true;
        ${styled || interactive ? 'activeRoot = target;' : ''}
        ${
          interactive
            ? `activeEpoch = epoch;
        ${ssr ? 'if (firstContinuation) interaction.adoptAttributes(initialProjection.attributes);' : ''}
        interaction.mount();
        // The native editor now owns value and composition for this view lease.
        // Vue clears an old domProp when the next VNode omits it; retire the
        // initial transport property before any ordinary host repaint.
        if (commit.vnode.data?.domProps) delete commit.vnode.data.domProps.value;`
            : ''
        }
        ${interactive ? 'if (terminal || commit.epoch !== epoch || !present || !hostActive) return;' : ''}
        ${styled ? 'style.mount();' : ''}
        fire('mounted');
        ${ssr ? `if (firstContinuation) { firstContinuation = false; syncHost(true); }` : ''}
      } else if (viewActive) {
        ${
          interactive
            ? `if (activeRoot !== target || activeEpoch !== epoch) {
          activeRoot = target; activeEpoch = epoch;
          interaction.mount();
        }
        if (terminal || commit.epoch !== epoch || !present || !hostActive) return;`
            : ''
        }
        if (kind !== 'update' || !pending || pending.revision !== commit.revision) return;
        pending = null;
        const again = queued; queued = false;
        fire('updated');
        if (again && present && viewActive && !terminal && !pending) update();
      }
    });
  };
  const owner = {
    ${publicCalls ? 'wrapPublic: PUIWrapPublic,' : ''}
    ${hasAuthoredHooks ? 'authored: PUIAuthored,' : ''}
    ${atoms.delay ? `delay: ${atoms.names.delay},` : ''}${atoms.presence ? `presence: ${atoms.names.presence},` : ''}${atoms.meta ? `meta: ${atoms.names.meta},` : ''}
    ${context.handle}
    host() { return viewActive && present && hostActive && !terminal ? vm.$el : null; },
    ${interactive ? 'interaction,' : ''}
    def,
    get resolvedProps() { return resolved; },
    ${
      ssr
        ? `bindSession(value, source) {
      session = value; sourceIdentity = source;
      if (session.closed) { owner.dispose(); throw new Error('[Vue2 SSR] request already retired.'); }
      requestIndex = session.owners.length;
      session.owners.push(owner);
      if (session.mode === 'hydrate') {
        initialProjection = session.carrier.projections[requestIndex];
        if (!initialProjection || initialProjection.source !== source || typeof initialProjection.rootTag !== 'string'
          || typeof initialProjection.present !== 'boolean' || !initialProjection.attrs || typeof initialProjection.attrs !== 'object'
          || Array.isArray(initialProjection.attrs) || Object.values(initialProjection.attrs).some((value) => value !== null && typeof value !== 'string')
          || !initialProjection.attributes || typeof initialProjection.attributes !== 'object' || Array.isArray(initialProjection.attributes)
          || Object.values(initialProjection.attributes).some((value) => value !== null && typeof value !== 'string')) throw new Error('[Vue2 SSR] source/profile projection mismatch.');
        shell = true;
      }
    },
    acceptHydration() {
      if (terminal || !shell) return;
      bootRaw = true;
      owner.initialize();
      bootRaw = false;
      shell = false;
      if (present !== initialProjection.present || (${interactive ? 'interaction.rootTag() || rootTag' : 'rootTag'}) !== initialProjection.rootTag) throw new Error('[Vue2 SSR] initial owner Root/presence differs from server projection.');
      if (present) { renderSemantic(); if (JSON.stringify(template) !== JSON.stringify(initialProjection.template)) throw new Error('[Vue2 SSR] initial owner template differs from server projection.'); }
      firstContinuation = initialProjection.present && present;
      unwatch = vm.$watch(() => ${controlLabel ? '({ props: hostRaw(), associations: PUINormalizeAssociations(vm.instanceAssociations, (/** @type {{_base?: {observable?: (value: object) => object}}} */ (vm.$options))._base?.observable) })' : 'hostRaw()'}, () => syncHost(true), { deep: true });
      // The accepted carrier is a render snapshot, not transferred State or handles.
      template = initialProjection.template;
      if (initialProjection.present && renderedCommit) {
        // Once accepted, Root presentation is imperative owner output. Do not let a
        // later ordinary Vue render diff the transport attrs against style-only changes.
        renderedCommit.vnode.data.attrs = { 'data-pui-root': '' };
      }
      owner.hostMounted();
      if (present !== initialProjection.present) force();
      if (!initialProjection.present) syncHost(true);
    },`
        : ''
    }
    initialize() {
      ${
        ssr
          ? `if (shell && !bootRaw || initialized) return;
      initialized = true;`
          : ''
      }
      try {
        renderFunction = setup(owner);
        if (typeof renderFunction !== 'function') renderFunction = (renderer) => renderer.slot();
        phase = 'idle';
        syncHost(false);
        fire('created');
        ${ssr ? `if (!session || session.mode === 'client' && !bootRaw)` : ''} unwatch = vm.$watch(() => ${controlLabel ? '({ props: hostRaw(), associations: PUINormalizeAssociations(vm.instanceAssociations, (/** @type {{_base?: {observable?: (value: object) => object}}} */ (vm.$options))._base?.observable) })' : 'hostRaw()'}, () => syncHost(true), { deep: true });
      } catch (error) {
        ${
          ssr
            ? `try { owner.dispose(); }
        catch (cleanupError) { throw new AggregateError([error, cleanupError], '[Vue2 SSR] initialization and cleanup failed.'); }
        throw error;`
            : `
        terminal = true;
        ${interactive ? 'try { interaction.dispose(); } catch {}' + (stateful ? '\n        for (const state of states) { try { state.dispose(); } catch {} }' : '') : ''}
        ${styled ? 'try { style.dispose(); } catch {}' : ''}
        ${context.setupFailure ? `try { ${context.setupFailure} } catch {}` : ''}
        disposed = true;
        phase = 'idle';
        throw error;`
        }
      }
    },
    hostMounted() { ${ssr ? 'if (shell) return;' : ''} nativeMounted = true; afterCommit(); },
    afterCommit,
    /** @param {import('vue').CreateElement} h */
    render(h) {
      ${
        ssr
          ? `if (shell) {
        const vnode = initialProjection.present
          ? h(initialProjection.rootTag, PUIRootData(initialProjection.properties, initialProjection.attrs, true), PUIChildren(initialProjection.template, h, vm, { used: false })) : h();
        renderedCommit = { epoch, version: ++commitVersion, present: initialProjection.present, vnode, kind: initialProjection.present ? 'mount' : 'detach' };
        return vnode;
      }
      if (session && session.mode === 'server') {
        if (present && hostActive && !terminal) renderSemantic();
        const attributes = ${interactive ? 'interaction.projectAttributes()' : '{}'};
        const attrs = { 'data-pui-root': '', ${styled ? "'data-pui-style': style.serverTokens().join(' ')," : ''} ...attributes };
        if (attrs['data-pui-style'] === '') delete attrs['data-pui-style'];
        const tag = ${interactive ? 'interaction.rootTag() || rootTag' : 'rootTag'}, properties = ${interactive ? 'interaction.rootProperties()' : '{}'};
        const children = PUIChildren(template, h, vm, { used: false });
        if (['input', 'textarea', 'img'].includes(tag) && children.length) throw new Error('[Template] physical control Root requires empty children.');
        const projection = { source: sourceIdentity, rootTag: tag, properties, present: present && hostActive && !terminal, raw: PUIEncodeRaw(raw), template: JSON.parse(JSON.stringify(template ?? null)), attrs, attributes };
        // This validates transport data only; callbacks and logical handles never cross.
        if (!PUIJson(projection)) throw new TypeError('[Vue2 SSR] render projection is not serializable.');
        session.projections[requestIndex] = projection;
        return projection.present ? h(tag, PUIRootData(properties, attrs, true), children) : h();
      }`
          : ''
      }
      if (terminal || !present || !hostActive) {
        const vnode = h();
        renderedCommit = { epoch, version: ++commitVersion, present: false, vnode, kind: 'detach' };
        return vnode;
      }
      if (!viewActive) renderSemantic();
      const tag = ${interactive ? 'interaction.rootTag() || rootTag' : 'rootTag'};
      const children = ${ssr ? 'PUIChildren(template, h, vm, { used: false })' : 'template ? template(h, vm, { used: false }) : []'};
      if (['input', 'textarea', 'img'].includes(tag) && children.length) throw new Error('[Template] physical control Root requires empty children.');
      ${interactive || ssr ? '' : "const rootData = { pre: true, attrs: { 'data-pui-root': '' } };\n      "}const vnode = h(tag, ${
        interactive || ssr
          ? `PUIRootData(${interactive ? 'interaction.rootProperties()' : '{}'}, { 'data-pui-root': '' }, !viewActive)`
          : 'rootData'
      }, children);
      renderedCommit = { epoch, version: ++commitVersion, present: true, vnode, kind: !viewActive ? 'mount' : pending ? 'update' : 'none', revision: pending && pending.revision };
      return vnode;
    },
    update,
    getExposes() { if (terminal) return {}; return { ...exposed }; },
    /** @template T @param {() => T} fn @returns {T} */
    invokePublic(fn) { publicAlive(); return invoke(fn); },
    deactivate() {
      if (terminal || !hostActive) return;
      hostActive = false; ++epoch; renderedCommit = null; pending = null; queued = false;
      detach();
    },
    activate() {
      if (terminal || hostActive) return;
      hostActive = true; ++epoch; pending = null; renderedCommit = null;
      vm.$forceUpdate();
    },
    dispose() {
      if (terminal) return;
      terminal = true; ++epoch; renderedCommit = null; pending = null; queued = false;
      ${hasAuthoredHooks ? 'for (const off of PUIAuthoredWatchCleanups.splice(0)) off();' : ''}
      unwatch?.(); unwatch = undefined;
      /** @type {{ error: unknown } | undefined} */ let failure;
      try { detach(); } catch (error) { failure = { error }; }
      ${ssr ? 'if (initialized)' : ''} try { fire('beforeDispose'); } catch (error) { failure ??= { error }; }
${
  stateful
    ? String.raw`      for (const state of states) {
        try { state.dispose(); } catch (error) { failure ??= { error }; }
      }
`
    : ''
}      ${context.dispose}
      ${interactive ? 'try { interaction.dispose(); } catch (error) { failure ??= { error }; }' : ''}
      ${
        styled
          ? `try { style.dispose(); } catch (error) { failure ??= { error }; }
      const target = vm.$el;
      if (target && target.nodeType === 1 && target.hasAttribute('data-pui-root')) target.removeAttribute('data-pui-style');`
          : ''
      }
      ${atoms.dispose}${hasAuthoredHooks ? 'PUIAuthored.dispose();' : ''}
      disposed = true; phase = 'idle';
      watchers.length = 0;${stateful ? ' notifications.length = 0; states.length = 0;' : ''} defaults.length = 0;
      for (const callbacks of Object.values(lifecycle)) callbacks.length = 0;
      for (const key of Object.keys(exposed)) delete exposed[key];
      for (const key of Object.keys(eventDeclarations)) delete eventDeclarations[key];
      specs = Object.create(null); previousValid = Object.create(null); raw = Object.freeze({}); resolved = /** @type {PUIResolvedProps} */ (Object.freeze({})); template = renderFunction = null;
      ${
        ssr
          ? `if (session && session.mode === 'client') {
        const index = session.owners.indexOf(owner);
        if (index >= 0) session.owners.splice(index, 1);
      }`
          : ''
      }
      if (failure) throw failure.error;
    },
  };
  return owner;
}
`;
}
