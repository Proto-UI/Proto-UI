import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
const ts=createRequire(path.resolve('package.json'))('typescript');
const digest=x=>crypto.createHash('sha256').update(x).digest('hex');
const excluded=new Set(['pos','end','id','transformFlags','modifierFlagsCache','nodeCount','identifierCount','symbolCount','multiLine','singleQuote']);
function canonical(node) {
  const fields={};
  for(const [key,value] of Object.entries(node)) {
    if(excluded.has(key)||(key==='text'&&node.kind===ts.SyntaxKind.SourceFile)) continue;
    if(value===null||['string','number','boolean'].includes(typeof value)) fields[key]=value;
  }
  const children=[]; ts.forEachChild(node,c=>{children.push(canonical(c));});
  return {fields,children};
}
const result=process.argv.slice(2).map(file=>{
 const source=fs.readFileSync(file,'utf8');
 const ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
 if(ast.parseDiagnostics.length) throw Error(file+': parser diagnostics');
 const scanner=ts.createScanner(ts.ScriptTarget.Latest,false,ts.LanguageVariant.Standard,source);
 const comments=[];for(let token=scanner.scan();token!==ts.SyntaxKind.EndOfFileToken;token=scanner.scan())
  if(token===ts.SyntaxKind.SingleLineCommentTrivia||token===ts.SyntaxKind.MultiLineCommentTrivia) comments.push(scanner.getTokenText().replace(/\s+/g,' ').trim());
 return {path:file,bytes:Buffer.byteLength(source),sourceSha256:digest(source),astSha256:digest(JSON.stringify(canonical(ast))),commentsSha256:digest(JSON.stringify(comments))};
});
process.stdout.write(JSON.stringify({typescript:ts.version,excluded:[...excluded],sourceFileTextExcluded:true,rawTextAndFlagsRetained:true,files:result},null,2)+'\n');
