import base from '/workspace/scratch/62ffef219b8e/proto-ui-sprint1/vitest.config.ts';
import { readFileSync } from 'node:fs';
export default { ...base, plugins: [...(base.plugins ?? []), { name:'browser-detach-original', enforce:'pre', transform(code,id) { if (id.split('?')[0] !== '/workspace/scratch/62ffef219b8e/proto-ui-sprint1/apps/www/src/content/docs/zh-cn/demo-matrix-browser-diagnostic.ts') return; return { code:readFileSync('/workspace/scratch/62ffef219b8e/matrix-diagnosis/browser-before-detach/demo-matrix-browser-diagnostic.ts','utf8'), map:null }; } }] };
