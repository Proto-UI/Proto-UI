import { createRequire } from 'node:module';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const require = createRequire('/home/ezra/proto-ui-browser-gate-cb5d/apps/www/package.json');
const { chromium } = require('playwright-core');
const outDir = '/home/ezra/proto-ui-browser-gate-cb5d-control/root-prominent-preferences';
await fs.mkdir(outDir, { recursive: true });
const report = { scope: 'Native preference regression diagnostic on actual existing fixture; not official production admission', cases: [] };
const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--disable-dev-shm-usage'] });
try {
  for (const runtime of ['wc', 'react', 'vue', 'vue2']) for (const theme of ['light', 'dark']) for (const part of ['button', 'submit']) {
    const row = { runtime, theme, part, samples: [], errors: [] };
    report.cases.push(row);
    const context = await browser.newContext({ viewport: { width: 1280, height: 900 }, deviceScaleFactor: 1, colorScheme: theme });
    const page = await context.newPage();
    page.setDefaultTimeout(15000);
    page.on('pageerror', error => row.errors.push(error.message));
    const cdp = await context.newCDPSession(page);
    const preferences = async (overrides = {}) => cdp.send('Emulation.setEmulatedMedia', { features: Object.entries({ 'prefers-color-scheme': theme, 'prefers-reduced-motion': 'no-preference', 'prefers-reduced-transparency': 'no-preference', 'prefers-contrast': 'no-preference', 'forced-colors': 'none', ...overrides }).map(([name, value]) => ({ name, value })) });
    const target = page.locator('[data-tint-control="tinted"] [data-demo-ref="subject"]');
    const wait = async (quality, contact) => page.waitForFunction(({ quality, contact }) => {
      const el = document.querySelector('[data-tint-control="tinted"] [data-demo-ref="subject"]');
      return el?.dataset.materialQuality === quality && (!contact || el.dataset.materialContact === contact);
    }, { quality, contact }, { timeout: 4000 });
    const take = async (stage) => {
      const sample = await page.evaluate(async () => {
        const el = document.querySelector('[data-tint-control="tinted"] [data-demo-ref="subject"]');
        const css = getComputedStyle(el);
        const firstPaint = { background: css.backgroundColor, foreground: css.color, transitionProperty: css.transitionProperty, motion: el.dataset.materialMotion, contact: el.dataset.materialContact, quality: el.dataset.materialQuality };
        const facts = await window.prominentTintFixture.capture('tinted');
        return { firstPaint, binding: facts.binding, sourceStillCurrent: facts.sourceStillCurrent, snapshot: { motion: facts.snapshot.motion, receipt: facts.snapshot.receipt, fallbackContrast: facts.snapshot.fallbackContrast, uriPresent: !!facts.snapshot.uri, paint: facts.snapshot.paint, verifiedAfterDecode: facts.snapshot.snapshot.verifiedAfterDecode, minForegroundContrast: facts.snapshot.pixels?.content.minForegroundContrast } };
      });
      row.samples.push({ stage, ...sample });
      return sample;
    };
    try {
      await preferences();
      await page.goto(`http://127.0.0.1:4347/en/test/liquid-glass-prominent-tint/?runtime=${runtime}&theme=${theme}&part=${part}&content=text`);
      await page.waitForFunction(() => !!window.prominentTintFixture);
      await page.evaluate(() => window.prominentTintFixture.paint('pastel', 0));
      await wait('self-optical');
      await target.hover();
      await page.mouse.down();
      await wait('self-optical', 'held');
      await take('held');
      await preferences({ 'prefers-reduced-motion': 'reduce' });
      await wait('self-optical');
      const reduced = await take('reduced-motion-held');
      assert.equal(reduced.snapshot.motion, 'static');
      assert.equal(reduced.snapshot.receipt.contact, 'rest');
      assert.equal(reduced.snapshot.paint.committed, true);
      assert.equal(reduced.snapshot.verifiedAfterDecode, true);
      assert.ok(reduced.snapshot.minForegroundContrast >= 4.5);
      await page.mouse.up();
      await preferences();
      await page.evaluate(() => window.prominentTintFixture.paint('pastel', 0));
      await wait('self-optical', 'rest');
      await page.locator('[data-tint-focus="tinted"]').focus();
      await page.keyboard.press('Tab');
      for (const [feature, value] of [['prefers-reduced-transparency', 'reduce'], ['prefers-contrast', 'more'], ['forced-colors', 'active']]) {
        await preferences({ [feature]: value });
        await wait('opaque-fallback');
        const fallback = await take(feature);
        assert.equal(fallback.snapshot.uriPresent, false);
        assert.ok(fallback.snapshot.fallbackContrast >= 4.5, `${feature}: ${JSON.stringify(fallback)}`);
        assert.ok(!fallback.firstPaint.background.startsWith('rgba('), `${feature}: nonopaque first paint`);
        assert.equal(await target.evaluate(el => el === document.activeElement), true);
        await target.screenshot({ path: `${outDir}/${runtime}-${theme}-${part}-${feature}.png` });
        await preferences();
        await page.evaluate(() => window.prominentTintFixture.paint('pastel', 0));
        await wait('self-optical');
      }
      assert.deepEqual(row.errors, []);
      row.passed = true;
    } catch (error) { row.passed = false; row.failure = error.stack; }
    finally { await context.close(); }
    await fs.writeFile(`${outDir}/report.json`, JSON.stringify(report, null, 2));
    console.log(JSON.stringify({ runtime, theme, part, passed: row.passed, failure: row.failure }));
  }
} finally { await browser.close(); }
report.passed = report.cases.every(row => row.passed);
await fs.writeFile(`${outDir}/report.json`, JSON.stringify(report, null, 2));
process.exitCode = report.passed ? 0 : 1;
