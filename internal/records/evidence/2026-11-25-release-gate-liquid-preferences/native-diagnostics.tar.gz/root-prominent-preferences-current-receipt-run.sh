#!/bin/bash
export PATH=/home/ezra/proto-ui-release-gate-cb5d-control/tools/node_modules/node/bin:/home/ezra/proto-ui-release-gate-cb5d-control/tools/node_modules/.bin:$PATH
node /tank/shared/projects/proto-ui/node_modules/.cache/proto-ui-ci-transfer-cb5d/root-prominent-preferences-current-receipt.mjs
rc=$?
printf "%s\n" "$rc" > /home/ezra/proto-ui-browser-gate-cb5d-control/root-prominent-preferences-current-receipt.exit
exit "$rc"
