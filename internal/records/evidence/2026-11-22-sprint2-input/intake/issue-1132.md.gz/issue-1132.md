# [proposal][Events] 定义可移植 pointer sample 事实并完成四 Web / Compiler 对等（Select hover 前置）

https://github.com/Proto-UI/Proto-UI/issues/1132

<!-- proto-ui:issue-governance:20261122:1132:v1 -->

## 2026-11-22 当前代码进度核对

Agent: ChatGPT，按当前用户授权核对与治理。审计截止 [`a8bf56087`](https://github.com/Proto-UI/Proto-UI/commit/a8bf56087e5836e3c14c153cafbd796bd98bff37)；各项执行证据保留其实际 SHA。

核对基线：[2c7eae2](https://github.com/Proto-UI/Proto-UI/commit/2c7eae25357d0c5bae29bd5e92caae3a4ea39730)。 本轮上述pointer suites合计500/500、0skip；这500条含Runtime376与Compiler124，均为本地Node/HappyDOM/TypeScript验证。

- [x] **定义与公开有限字段已落地** — [C-EVENT-TYPE-0003](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/spec/contracts/C-EVENT-TYPE-0003.yaml)、C-EVENT-0002/M-EVENT-0001/[T-EVENT-0002](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/spec/tests/T-EVENT-0002.yaml)已约束有限映射、unknown、独立getter失败与epoch cleanup；[public types](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/types/src/event.ts)同步，所有原draft状态保留。
- [x] **真实author callback端到端传递** — [四Runtime共享消费者](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/adapters/base/test/fixtures/pointer-facts-conformance.ts)本轮各74/74，[EventModule](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/modules/event/test/contract/pointer-facts.v0.contract.test.ts)80/80，覆盖fresh/frozen、raw对象不变、host字段不泄露、key/control与cleanup。
- [x] **四compiled Web与完整strict图已通过** — [native消费者65/65](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/compiler/test/pointer-facts-native.test.ts)加 [admission59/59](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/compiler/test/pointer-facts-admission.test.ts)；四投影完整生成module graph使用真实依赖声明并strict检查0诊断，包含先前Vue2失败项。
- [ ] **原完整Select/source交互矩阵** — 仍需同一候选的A→B任意button、touch cancel/late move、pen、keyboard/value/selected/check、blur/reconnect/replacement及nested/portal完整组合证据；目前finite事实测试不覆盖所有消费协议。
- [ ] **真实浏览器/硬件与归档负控** — 补mouse/keyboard交接、真实touch/scroll/cancel/implicit capture、关闭重开、source/viewport/profile/日志及baseline/单侧withdrawal对照；synthetic HappyDOM不是硬件证据，不能用旧生产图验收。
- [ ] **原35195a6严格失败重现与#1178对账** — 当前green不替代原11个diagnostics的完整retained red graph；以本轮精确SHA/65条结果更新#1178，完整release/native gate保持开放。

---

<!-- dot-pointer-sample-facts-1100-20261031 -->
## 目的与依赖

为 #1100 的 Select 双向导航唯一高亮提供必要的 **atomic Event 输入事实**；这是独立、definition-first 的前置项，不是已批准的新公共 API，也不是整个 Gesture 系统重构。相关消费者实证见 [#1100 的公开复现记录](https://github.com/Proto-UI/Proto-UI/issues/1100#issuecomment-6547561734)。本 Issue 完成前，不能把缺少输入分类的 `pointer.move` 候选作为安全修复发布。

现网已实际复现 mouse/keyboard 后两行同时灰底。静态修复审查又发现：item 的本地 `pressed` 在 leave 后清除，不能区分 A 按下后跨到 B 的 touch/pressed mouse 移动。触控风险是**候选静态缺口**，不是已经实测的新生产事故。旧候选未执行、未发布；不能只删 Shadcn paint 或把所有 pointer 当 mouse 交差。

## 查重与 ownership

2026-10-31 18:46–18:52 UTC 检索 open Events/pointer/gesture、全状态 pointerType / pointer payload / pointer input / portable payload，并读相关讨论。没有找到可直接承接此公开 sample-fact 协议的独立 Issue；这不是全仓无相关工作的证明。

- #495 是 interaction research umbrella；[维护者拆分](https://github.com/Proto-UI/Proto-UI/issues/495#issuecomment-5390467217) 为受约束拖动、几何与 Select positioning，不自动批准此 API。#498 是 design-only Switch drag-to-value，也不承接被动 pointer 数据。
- #732 / #817 / #902 的 Adapter/Compiler 对等与既有 Compiler owner 边界继续有效；本 Issue 不分配、接管其代码或认证其完成。
- #496 positioning、#1085 readiness/旧 React focus 与 Header 44px density 是不同范围。#1100 本身保持 open，原大项不勾选。

此刻只登记待定义队列，不宣称独占实现 lease。实现前须重读当时 owner/claims 和 source revision，协调各 owner 串行集成。

## 固定源码事实

静态检查基于 `9011d271970db883800d086c911b70e1437942c9`（tree `b5fa88482c0615fb54df728ff5aac4e632f4abfc`）：

- [`ProtoEventPayload`](https://github.com/Proto-UI/Proto-UI/blob/9011d271970db883800d086c911b70e1437942c9/packages/types/src/event.ts) 只有 type、键盘修饰及同步 control，没有公开 pointer kind / buttons 事实。
- [`EventModule`](https://github.com/Proto-UI/Proto-UI/blob/9011d271970db883800d086c911b70e1437942c9/packages/modules/event/src/impl.ts) 用 whitelist 创建 fresh/frozen author payload；只改 router 会被此层丢弃。
- 四 Web Runtime 共用 [`web-event-router.ts`](https://github.com/Proto-UI/Proto-UI/blob/9011d271970db883800d086c911b70e1437942c9/packages/adapters/base/src/events/web-event-router.ts)。其 private visual contact、`asTrigger`、privileged input sample identity 都不是原型可借用的跨项 contact lease。
- [`Compiler native-interaction.ts`](https://github.com/Proto-UI/Proto-UI/blob/9011d271970db883800d086c911b70e1437942c9/packages/compiler/src/native-interaction.ts) 独立构造 frozen payload，不能靠 Runtime router 改动假定自动获得支持。

```mermaid
flowchart LR
  D[共享 Event 定义与公共 types] --> W[四 Web Runtime ingress]
  W --> E[EventModule fresh immutable payload]
  E --> P[原型 callback / Select Focus owner]
  D --> C[独立 Compiler lowering 与 native input]
  C --> N[四 compiled Web target 实际消费者]
  P --> T[同定义的独立正负验收]
  N --> T
```

该图表达待实现职责，不表示各边已经通过。

## 最小定义决策（公共名字和标量形式待审）

- 每次 pointer sample 可携带有限、规范化的 input kind（与现有 Move 的 mouse/touch/pen/unknown 概念协调）以及 **已知无活动 buttons/contact、已知有活动 buttons/contact、未知** 的区分。数据描述本次 sample，不是全局 last-modality 或持久 contact registry。
- 缺失、无效、空或未知输入必须保留 unknown；不能默认 mouse，也不能把缺失 buttons 强制成0。Web mapping 依据 current `buttons`，不能混用表示变化按钮的 `button`。
- 不暴露 nativeEvent、target、PointerId、坐标、capture handle、DOM 方法或私有 contact registry。保留 payload fresh/frozen、无 raw alias、同步 control lifetime；不为读 hover 新增捕获/阻止默认/drag recognizer。
- 最小 Select 消费准入：真实 move、known mouse、known no active buttons，加既有 open/enabled/current-owner 条件后才请求现有 Focus owner。enter-only 不转移 focus；touch、pen、unknown、任意活动按钮不走 mouse-hover 导航。普通 tap/press、键盘、受控拒绝仍由原 owner 处理。
- 这是建议的 drag-safe consumer 策略，不冒称完全复制固定上游 BaseUI1.6 的 mouse handler。独立鼠标与别处触点并行的全局仲裁、多触点身份、硬件 hover 能力、pen hover 准入均非本 slice 的隐含保证。

## 待完成 / 必须全部满足的验收

- [x] **定义与公开说明已落地：** 通过现有定义流程明确职责、输入、规范化、未知/缺失、生命周期、兼容与支持边界；更新适用 `C-EVENT-0002` / `C-EVENT-TYPE-0003` / `M-EVENT-0001` / `T-EVENT-0002` 等实体及公开说明，不把 draft 升格为既有 stable 保证。
- [x] **公开传递链已完成：** 公共 types、共享 Web ingress 与 EventModule 完整传递；真实 author callback 收到新事实、fresh/frozen、raw object 不被修改且不泄漏宿主对象。只验证内部 `CustomEvent.detail` 不算完成。
- [ ] WC / React / Vue / Vue2 **四个 Web Runtime** 按同一定义通过独立消费者正负矩阵；保留既有 key/modifier/control、事件去重与嵌套/portal routing。
- [ ] 由既有 Compiler owner 独立实现共享定义，并在 **四个 compiled Web 投影** 验证实际消费者和相同正负矩阵；不得 component-name/path 特判、复制 Select 业务协议、削弱合法 prototype 或嵌入第二套 Runtime。
- [ ] Source fixtures 覆盖 known mouse move0 正控；enter-only；任意 mouse button 跨 A→B；touch A-down→leave→B-move、cancel 后 late move；pen hover/contact；missing/invalid kind/buttons；键盘/Enter/Space、valid touch tap、selected/check 与值不被 hover 改写；blur/detach/reconnect/替换 owner 清理。
- [ ] 实际浏览器覆盖 mouse/keyboard 交接及真实 touch 序列、滚动/取消和关闭重开；区分 implicit capture 导致未投递与消费者明确拒绝。合成事件测试不是硬件证据，也不能用默认空 pointerType 充当 mouse 正控。
- [ ] 保存 baseline / 单侧撤回负控、精确 source/commit/viewport/runtime/profile、适用原生效果与日志；再以新精确候选修订 Select 消费方并独立验收。旧生产图不得冒充候选效果。

**四 Web Runtime 与 Compiler 对等是完成条件，不是可选 report。** 任一必需路径缺失只能如实保留 blocking/unchecked；不能以 unsupported 日志、静默 no-op、mouse-all-pointer、跳过 touch 控制或降低验收数量结项。当前未执行任何本轮新源码、generator 或测试，以上 checkbox 全部未完成。

## 证据与范围限制

公开实证时间、assets、DOM 状态和上游固定链接已在 #1100 的上述评论中保留；生产资产未被冒称精确 deployed commit。该原型层设计图可直接公开；实际生产 screenshots 的 GitHub 内联上传仍欠，后续只公开项目页面、绑定真实目标版本，不上传用户私人参考图。Header density、所有 style profiles 的间距审查、AT、非 Web backend 与全局多指针仲裁不被本 Issue 偷换成已完成。

AI-assisted by dot for cyjin-yl。


## 2026-11-13 compiler 0.3 audit reconciliation

Agent-authored tracking update requested by the owner. Source: the user's Shenko audit of main `35195a6e6f1ba6a7d800da0029f2683013abd18b`, Node 24.22 / React 19.3.1 / Chromium via Playwright. Reported executions are **not independently rerun here**; original fixtures/captures are not yet public. The declared React target is 19.2.6, so reproduce on that admitted target as well as the reported consumer version. Existing owners, source history, passed bounded deliveries, failures and remaining criteria are retained. The checkboxes below record outstanding work, not a new acceptance claim or a release-scope decision.

### F2 audit link: Vue2 generated pointer strictness
- [ ] Reproduce the user-reported 35195a6 Vue2 full emitted pointer module graph strict-check failure (11 errors) with pinned dependency declarations and retain the failing generated files plus diagnostics. Coordinate the existing owner; no duplicate implementation claim is made.
- [x] **完整生成图 strict 修复已验证：** Repair the owning native state/type/element/callback contracts and prove the complete generated graph passes strict checks, with applicable runtime consumer regression evidence. No ts-nocheck, relaxed strict/noImplicitAny, stubbed dependency declarations or narrowed graph.
- [ ] Report exact candidate SHA and real CI/test result to #1178; this does not change this Issue's original pointer capability or cross-host acceptance boundaries.

<!-- compiler-audit-20261113:F-reconcile:1132 -->

