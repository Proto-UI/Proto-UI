# [Finf v2][887-followup][base-parity-forms] 既有 Base 家族四投影原子对等 · 表单输入（Button/Checkbox/Radio Group/Input/Textarea/Toggle/Switch）

https://github.com/Proto-UI/Proto-UI/issues/1160

<!-- proto-ui:issue-governance:20261122:1160:v1 -->

## 当前主线核对 · 2026-11-22

Agent: ChatGPT，按当前用户授权核对与治理。审计截止 [`a8bf56087`](https://github.com/Proto-UI/Proto-UI/commit/a8bf56087e5836e3c14c153cafbd796bd98bff37)；各项执行证据保留其实际 SHA。

核对基线：[`a8bf56087`](https://github.com/Proto-UI/Proto-UI/commit/a8bf56087e5836e3c14c153cafbd796bd98bff37)。以下将已交付的源码与尚未完成的验收分开，原始范围和历史记录保留。

- [x] **七类表单控件的真实源码与家族映射已交付**：每个父项已拆出 source 子项；特别是 Liquid Checkbox/Input/Radio/Switch/Textarea/Toggle、Brutalist Input/Radio、Bootstrap Radio 都确实存在，原历史 TODO 不再视作源码缺失。
- [x] **图标命名与开发诊断路径已交付**：[React 文档](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/adapters/react/README.md)给出 `instanceAssociations.controlLabel` 与 dropped-host-prop 诊断；#1454 的命名/受控/disabled 有限消费者证据单独记账。
- [x] **原 #1581 reduced-motion 有限接受结果保留**：八配置托管观察与合入记录不撤销；仍不替代当前整合主线和全部家族运动检查。
- [ ] 按原七项补齐所有适用 Form/readOnly、controlled/IME、变体/尺寸/主题、字体缩放命中、group/toolbar、真实 native/AT 和 #1581 主线整合回归；父项继续开放。

### a8bf 整合补充

- [x] **与七类输入相邻的数值/主题源修复已整合**：#1666 的 Number Field 本地化/null/scrub 复用 Base editor/Field/Form owner；#1668 的[嵌套主题继承](https://github.com/Proto-UI/Proto-UI/blob/a8bf56087e5836e3c14c153cafbd796bd98bff37/apps/www/src/components/PrototypePreviewer/projection-composition.ts)及[新增回归](https://github.com/Proto-UI/Proto-UI/blob/a8bf56087e5836e3c14c153cafbd796bd98bff37/apps/www/src/components/PrototypePreviewer/projection-composition.test.ts)已在主线。原七类 Form/readOnly/IME/主题/物理输入/AT 的完整条件不因此完成。

新能力候选的 **36文件/593 tests** 与文档/类型结果属于记录中的开发组合；a8bf 合入后的完整原生/周期未由本次审计重跑，不能把该数字当整合主线全量通过。

---

## 来源

拆自 #1100（2026-11-01 全量 Issue 梳理，Finf v2 #890 清零）。父 Issue 保留为追踪入口，本 Issue 为有界执行切片，不是父 Issue 的重复。
## 范围（原 checklist 逐项保留）

- [ ] Button：Base 交互状态与四家族入口；共享 Shadcn New York h-9 paint 与独占尺寸间隙，被复合命令复用而无第二个行为 owner；有界原生命令消费者现验证 36/72px 默认。TODO：hover90 仍因借用 Form 状态 CSS 闭环而延后（active hover80 保留）；完整变体、暗色/失效/图标/换行边界与独立字体缩放输入/视觉/AT 证据
  - [x] **Base 与各家族 Button 源码及 governed ControlLabel 命名路线已交付** — [源码](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/prototypes/base/src/button/button.proto.ts)。
  - [ ] hover90 的适用 Form owner、全部变体/暗色/失效/图标/换行与独立缩放/native/AT 仍开放。
- [ ] Checkbox：Base/Shadcn/Brutalist/Bootstrap 受控/mixed Root/Indicator；TODO：Liquid Glass 映射；解决适用 readOnly/Form 边界并完整家族/输入证据
  - [x] **Base 继承的 Checkbox 各家族及 Liquid Glass Root/Indicator 源映射已交付** — [源码](https://github.com/Proto-UI/Proto-UI/tree/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/prototypes/liquid-glass/src/checkbox)。
  - [ ] readOnly/Form 适用边界与全部家族/真实输入证据仍开放。
- [ ] Input：纯文本原生编辑、受控/IME/readOnly 与 Field 组合；TODO：Brutalist/Liquid Glass 映射；定义适用非文本/文件范围而非发明宿主绕过
  - [x] **既有物理 editor 与 Brutalist/Liquid Glass Input 源映射已交付** — [源码](https://github.com/Proto-UI/Proto-UI/tree/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/prototypes/liquid-glass/src/input)。
  - [ ] 非文本/文件范围、完整受控/IME/readOnly/Field 原生接受仍需按原条件验证。
- [ ] Radio Group：Base/Shadcn 单选择、漫游焦点与类型化 Label；TODO：Brutalist/Bootstrap/Liquid Glass 映射；适用 readOnly/Form 范围与完整输入/AT 证据
  - [x] **Base 单选择/漫游焦点/Label 及 Brutalist/Bootstrap/Liquid Radio Group 源映射已交付** — [源码](https://github.com/Proto-UI/Proto-UI/tree/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/prototypes/liquid-glass/src/radio-group)。
  - [ ] readOnly/Form 适用边界、完整输入与 AT 仍开放。
- [ ] Switch：布尔 Root/Thumb；固定 New York default/sm 尺寸与驻留运动；Brutalist 驻留 Thumb；TODO：Liquid Glass 映射、完整字体缩放命中/运动证据与适用 Form/readOnly 边界
  - [x] **布尔 Root/Thumb 与 Liquid Glass 源映射已交付；原 #1581 有限减弱动态效果成果保留** — [源码](https://github.com/Proto-UI/Proto-UI/tree/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/prototypes/liquid-glass/src/switch)。
  - [ ] 主线整合回归、完整字体缩放命中/运动以及 Form/readOnly 仍开放。
- [ ] Textarea：原生多行/IME/readOnly 与三家族入口；TODO：Liquid Glass 映射；Field 失效状态、尺寸/回流、选择与原生/AT 验收
  - [x] **Base 原生多行 editor 与 Liquid Glass Textarea 源映射已交付** — [源码](https://github.com/Proto-UI/Proto-UI/tree/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/prototypes/liquid-glass/src/textarea)。
  - [ ] Field invalid、尺寸/回流、选择、IME 和完整 native/AT 仍开放。
- [ ] Toggle：三家族受控活跃态区别于瞬态 pressed；TODO：Liquid Glass 映射与完整家族变体/尺寸加 group/toolbar 输入证据
  - [x] **Base controlled active owner 与 Liquid Glass Toggle 源映射已交付** — [源码](https://github.com/Proto-UI/Proto-UI/tree/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/prototypes/liquid-glass/src/toggle)。
  - [ ] 全部变体/尺寸、group/toolbar 真实输入与各家族完整接受仍开放。

## 验收与验证边界

每个原型须四投影原子对等（Base/Shadcn/Brutalist/Bootstrap 或 Liquid Glass 映射），完整家族变体/尺寸/间距、原生视觉与 AT 证据。不以历史证据冒充当前 head 验收。
<!-- proto-ui:0.3:switch-live-motion-1581 -->

### Switch · 减弱动态效果子项

- [x] 验证 #1581 的 Shadcn New York Switch 候选。本轮托管 Chrome 157.0.8103.50 在 default/sm、Document/Shadow、16/32px 八个配置中通过了已挂载控件的动态偏好切换。恢复普通动态效果时，轨道背景色过渡、Thumb transform 过渡、途中位置和最终位置均符合断言。再次开启减弱动态效果后，原 30ms 检查仍通过。
- [x] #1581 独立批准并合入 `3992ae27691ae65d52138e00681d27177623fcb4`。
- [ ] 核对整合主线回归。原 Switch 条件里的家族、字体缩放命中、Form/readOnly 及其他宿主证据仍独立跟踪。

托管运行 `44544348245` 使用 #1581 `37a4999352892c6ba2721ce4caed0dcf630976d0` 的产品字节及一处仅测试变更 `bb66941fe40951106ce480e97d36bdb626e393ea`，执行八个直接配置。另四个用例未由这次过滤运行执行。

[PR](https://github.com/Proto-UI/Proto-UI/pull/1581) · [托管测试和样本](https://github.com/Proto-UI/Proto-UI/actions/runs/44544348245)

