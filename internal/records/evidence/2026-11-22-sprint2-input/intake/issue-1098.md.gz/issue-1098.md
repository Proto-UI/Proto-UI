# [Finf v2][887-followup] Base 家族投影完成度 · 值/分段输入与日期：Slider/Number Field/Progress/Meter/OTP/Calendar/Date Picker

https://github.com/Proto-UI/Proto-UI/issues/1098

<!-- proto-ui:issue-governance:20261122:1098:v1 -->

## 当前主线核对 · 2026-11-22

Agent: ChatGPT，按当前用户授权核对与治理。审计截止 [`a8bf56087`](https://github.com/Proto-UI/Proto-UI/commit/a8bf56087e5836e3c14c153cafbd796bd98bff37)；各项执行证据保留其实际 SHA。

审计截止：[`a8bf56087`](https://github.com/Proto-UI/Proto-UI/commit/a8bf56087e5836e3c14c153cafbd796bd98bff37)；#1666 已合入，以下更新早先“仍缺失”的 source 子条件，不删除原始验收范围。

- [x] **Calendar Range/Multiple 与逐日事实已交付**：[公开接口](https://github.com/Proto-UI/Proto-UI/blob/a8bf56087e5836e3c14c153cafbd796bd98bff37/packages/prototypes/base/src/calendar/types.ts)和[draft 契约](https://github.com/Proto-UI/Proto-UI/blob/a8bf56087e5836e3c14c153cafbd796bd98bff37/spec/contracts/C-CALENDAR-SELECTION-0001.yaml)包含 mode、values/range、数量/夜数约束、不可用跨度拒绝、rangeStart/rangeEnd/rangeMiddle/rangePending，保留 single value 兼容。
- [x] **Date Picker 的新选择完成语义已交付**：[组合源码](https://github.com/Proto-UI/Proto-UI/blob/a8bf56087e5836e3c14c153cafbd796bd98bff37/packages/prototypes/base/src/date-picker/date-picker.proto.ts)复用同一 Calendar owner；只有 popup 内仍有效且已接受的 single/完整 range 请求才请求关闭，multiple、不完整或被拒绝的请求保持打开，Popover 继续拥有受控关闭与焦点。
- [x] **Number Field locale/nullable/scrub 已交付**：[格式/严格解析](https://github.com/Proto-UI/Proto-UI/blob/a8bf56087e5836e3c14c153cafbd796bd98bff37/packages/prototypes/base/src/number-field/format.ts)覆盖 decimal/currency/percent；[owner](https://github.com/Proto-UI/Proto-UI/blob/a8bf56087e5836e3c14c153cafbd796bd98bff37/packages/prototypes/base/src/number-field/root.proto.ts)和[Label scrub](https://github.com/Proto-UI/Proto-UI/blob/a8bf56087e5836e3c14c153cafbd796bd98bff37/packages/prototypes/base/src/number-field/label.proto.ts)提供 number|null、allowEmpty、受控返回原值提议、IME/reset/失效取消；scrub 为显式 opt-in，编辑器不被改成拖拽面。
- [x] **五家族公共配方与类型同步已交付**：Base/Shadcn/Brutalist/Bootstrap/Liquid 的相关中英文页面、真实 public-atom demo 和 consumer probes 已纳入 #1666。Bootstrap/Liquid 继续 Experimental。
- [x] **原有有限成果保留**：single Calendar caption 的原 9/9、七项既有 source children、Shadcn/Bootstrap/Liquid 三组 Slider Values 源码不撤销，仍按各自原 source 绑定记账。
- [ ] 完成新 Range/Multiple、locale/null/scrub 的 exact-head真实输入/绘制/焦点及 AT；旧单日期 caption 9/9、开发593测试与文档类型成功不能替代这些原生条件。
- [ ] Brutalist Slider Values、完整多滑块 pointer/capture/交换焦点和分组 Field/Compiler 仍开放；Progress/Meter 的动态读出与阈值、OTP 选择/物理IME/自动填充等原条件保持。

候选验证的准确边界见[能力交付记录](https://github.com/Proto-UI/Proto-UI/blob/a8bf56087e5836e3c14c153cafbd796bd98bff37/internal/records/2026-11-22-component-capabilities.md)：在开发分支纳入 `9c1afbc70` 后记录 **36 文件 / 593 tests passed**、文档 1,258 文件 0 errors、各家族公开类型 probes 与 workspace types 通过；这不是本次在 a8bf 重跑。[真实浏览器 runner](https://github.com/Proto-UI/Proto-UI/blob/a8bf56087e5836e3c14c153cafbd796bd98bff37/scripts/analysis/component-capabilities-browser.mjs)和 workflow 已交付，但记录中的本地浏览器在页面创建前受阻，当前尚未核对到该能力候选的 exact-head native artifact。物理 IME、hardware touch、AT、non-Web 与 Compiler parity 不在这组证据内。

---

## 来源

拆自 #887「Finf scope」→「Values, segmented input and dates」。关联 Finf v2 总追踪 #890。原 PR872 body 的 54 原型/组合 0/54 已验收，本 Issue 承接其中值/分段输入与日期一类。

## 未完成项（原 checklist 逐项保留）

- [ ] Slider：标量家族加草案 Base sliderValues 部分、受控 owner、索引键盘与数值碰撞提案；TODO：真实多滑块指针/捕获/交换焦点、分组 Field、四家族 Values 投影与原生/编译器验收
  - [x] Slider：标量家族加草案 Base sliderValues 部分、受控 owner、索引键盘与数值碰撞提案 — 实现层已交付：`packages/prototypes/base/src/slider/`，`packages/prototypes/shadcn/src/slider/`，`packages/prototypes/brutalist/src/slider/`，`P-BASE-SLIDER.yaml`@9da3dfd18，`P-SHADCN-SLIDER.yaml`@9da3dfd18，`P-BRUTALIST-SLIDER.yaml`@9da3dfd18
  - [ ] 真实多滑块指针/捕获/交换焦点、分组 Field、四家族 Values 投影与原生/编译器验收
    - [x] **Shadcn、Bootstrap、Liquid Glass 的 Values 六部分源码与入口已交付** — 主线代码链接见下。
    - [ ] Brutalist Values、真实多滑块输入/捕获/焦点、Field 与所有适用原生/Compiler 验收继续开放。
- [ ] Number Field：数值 owner、可编辑输入、增减、边界/步长与 Field 集成；TODO：解决 locale/空/scrub 目标语义并完成原生编辑/IME、拒绝与家族 recipe
  - [x] Number Field：数值 owner、可编辑输入、增减、边界/步长与 Field 集成 — 实现层已交付：`packages/prototypes/base/src/number-field/`，`packages/prototypes/shadcn/src/number-field/`，`packages/prototypes/brutalist/src/number-field/`，`P-BASE-NUMBER-FIELD.yaml`@9da3dfd18，`P-SHADCN-NUMBER-FIELD.yaml`@9da3dfd18，`P-BRUTALIST-NUMBER-FIELD.yaml`@9da3dfd18
  - [ ] 解决 locale/空/scrub 目标语义并完成原生编辑/IME、拒绝与家族 recipe
    - [x] **Number Field locale/decimal/currency/percent、null/allowEmpty、opt-in Label scrub 和取消/重入源码已交付** — #1666 已合入 a8bf56087，证据见下方当前核对。
    - [ ] 真实原生编辑/物理IME、受控拒绝、家族recipe和AT完整验收保留。
- [ ] Progress：确定/不确定范围、label/value/valueText 与安全有限百分比；TODO：完整格式/读出示意、动态范围与家族/原生/AT 验证
  - [x] Progress：确定/不确定范围、label/value/valueText 与安全有限百分比 — 实现层已交付：`packages/prototypes/base/src/progress/`，`packages/prototypes/shadcn/src/progress/`，`packages/prototypes/brutalist/src/progress/`，`P-BASE-PROGRESS.yaml`@9da3dfd18，`P-SHADCN-PROGRESS.yaml`@9da3dfd18，`P-BRUTALIST-PROGRESS.yaml`@9da3dfd18
  - [ ] 完整格式/读出示意、动态范围与家族/原生/AT 验证
- [ ] Meter：范围加 low/high/optimum、label/value/valueText 与家族部分；TODO：完整阈值/读出示意/几何行为与原生/AT 验证
  - [x] Meter：范围加 low/high/optimum、label/value/valueText 与家族部分 — 实现层已交付：`packages/prototypes/base/src/meter/`，`packages/prototypes/shadcn/src/meter/`，`packages/prototypes/brutalist/src/meter/`，`P-BASE-METER.yaml`@9da3dfd18，`P-SHADCN-METER.yaml`@9da3dfd18，`P-BRUTALIST-METER.yaml`@9da3dfd18
  - [ ] 完整阈值/读出示意/几何行为与原生/AT 验证
- [ ] OTP：原生编辑器、长度/模式、group/separator/slots 与受控输入；TODO：准入选择/活动槽事实；真实粘贴/IME/选择、自动填充与四家族验收
  - [x] OTP：原生编辑器、长度/模式、group/separator/slots 与受控输入 — 实现层已交付：`packages/prototypes/base/src/input-otp/`，`packages/prototypes/shadcn/src/input-otp/`，`packages/prototypes/brutalist/src/input-otp/`，`P-BASE-INPUT-OTP.yaml`@9da3dfd18，`P-SHADCN-INPUT-OTP.yaml`@9da3dfd18，`P-BRUTALIST-INPUT-OTP.yaml`@9da3dfd18
  - [ ] 准入选择/活动槽事实；真实粘贴/IME/选择、自动填充与四家族验收
- [ ] Calendar：单日期、受控月份、min/max/不可用、可变周、locale/RTL 与 caption；溢出修复已落地；TODO：Range/Multiple 与逐日范围事实仍缺失；完整家族状态、caption 与原生/AT 验收
  - [x] Calendar：单日期、受控月份、min/max/不可用、可变周、locale/RTL 与 caption；溢出修复已落地 — 实现层已交付：`packages/prototypes/base/src/calendar/`，`packages/prototypes/shadcn/src/calendar/`，`packages/prototypes/brutalist/src/calendar/`，`P-BASE-CALENDAR.yaml`@9da3dfd18，`P-SHADCN-CALENDAR.yaml`@9da3dfd18，`P-BRUTALIST-CALENDAR.yaml`@9da3dfd18
  - [x] caption 与原生验收（单日期路径）—— 官方 Calendar 证据套件在 main `152b607e` 上 9/9 通过（run `43836326384`，工作流 `finf-representative-features-evidence`，`feature_group=calendar`）：caption 的 wc/react/vue/vue2 四运行时旅程、101 项年份选项的键盘打开与选择、焦点环与月份/年份菜单均通过；此前在 `758eaa20` 上为 3/9（run `43821467877`），其中 `shadcn-calendar-year-scroll` 与 `shadcn-calendar-caption-vue` 已转绿。本项仅确证单日期路径的 caption 与原生验收。
  - [ ] Range/Multiple 与逐日范围事实仍缺失；完整家族状态与其余原生/AT 验收（owner：当前 0.3 执行 Agent）。下一动作：按原条件补齐 Range/Multiple 与逐日范围事实，再完成其余家族状态与原生/AT 验收；不得以单日期路径的 9/9 替代该条件。
    - [x] **Calendar Range/Multiple、min/max数量或夜数、不可用跨度拒绝和逐日范围事实已定义并实现** — #1666 已合入 a8bf56087，证据见下方当前核对。
    - [ ] 完整家族状态、exact-head真实多宿主native与其余AT验收保留；旧单日期9/9不覆盖新能力。
- [ ] Date Picker composition：Calendar + Popover 与日/值/触发组合；TODO：Range/Multiple 依赖 Calendar；完整选择/受控关闭/拒绝与焦点/AT recipe
  - [x] Date Picker composition：Calendar + Popover 与日/值/触发组合 — 实现层已交付：`packages/prototypes/base/src/date-picker/`，`packages/prototypes/shadcn/src/date-picker/`，`packages/prototypes/brutalist/src/date-picker/`，`P-BASE-DATE-PICKER.yaml`@9da3dfd18，`P-SHADCN-DATE-PICKER.yaml`@9da3dfd18，`P-BRUTALIST-DATE-PICKER.yaml`@9da3dfd18
  - [ ] Range/Multiple 依赖 Calendar；完整选择/受控关闭/拒绝与焦点/AT recipe
    - [x] **Date Picker继承Range/Multiple，accepted completion关闭与multiple保持打开的源码已交付** — #1666 已合入 a8bf56087，证据见下方当前核对。
    - [ ] 完整真实选择/受控关闭拒绝、焦点/AT recipe与整合验收保留。

## 验收与验证边界

每个原型须四投影原子对等，完整家族变体/尺寸/间距、原生视觉与 AT 证据。不以历史证据冒充当前 head 验收。
## 0.3 实现层拆分说明

原始 checkbox 把「实现」与「验收（原生视觉/辅助技术证据）」写在同一行，因此任何一行都无法单独勾选。按 0.3 计划「Check completed source-bound children promptly」与 pui-dev 的 compound-checkbox 规则，下面把已具备证据的实现条件拆成可独立勾选的子项并勾选；父项与验收子项保持未勾选。

Bootstrap 2.3.2 与 Liquid Glass 不在 0.3 范围内，涉及它们的 TODO 不构成 0.3 阻塞。

