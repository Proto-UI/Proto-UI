# proposal(style): govern reactive accessibility preferences and material fallback

https://github.com/Proto-UI/Proto-UI/issues/793

<!-- proto-ui:issue-governance:20261122:793:v1 -->

## 当前主线核对 · 2026-11-22

Agent: ChatGPT，按当前用户授权核对与治理。审计截止 [`a8bf56087`](https://github.com/Proto-UI/Proto-UI/commit/a8bf56087e5836e3c14c153cafbd796bd98bff37)；各项执行证据保留其实际 SHA。

核对基线：[`2c7eae253`](https://github.com/Proto-UI/Proto-UI/commit/2c7eae25357d0c5bae29bd5e92caae3a4ea39730)。以下将已交付的源码与尚未完成的验收分开，原始范围和历史记录保留。

- [x] **独立偏好词汇及 draft 契约链已交付**：`preference.reducedMotion` / `reducedTransparency` / `contrast` / `forcedColors` 与显式 `unknown` 由[契约](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/spec/contracts/C-RULE-PREFERENCES-0001.yaml)约束；[批准范围记录](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/internal/records/2026-10-03-bounded-reactive-preferences.md)只批准 bounded draft，原 sampled key 和 colorScheme 保持原边界。
- [x] **Web 共享观察与 getter/lease 生命周期实现已交付**：[source](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/adapters/base/src/platform/web-preference-source.ts)和[生命周期回归](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/runtime/test/contract/rule.preferences-lifecycle.contract.test.ts)覆盖依赖订阅、custom getter 隔离、失源/替换/重挂、晚回调和销毁。
- [x] **本基线窄回归 24/24 通过**：本次实际执行 `web-preferences.test.ts`、`web-preference-source.test.ts`、`rule.preferences-lifecycle.contract.test.ts`，3 个文件 / 24 个测试全部通过；这是 getter/observer/Rule 租约范围，不替代浏览器材质验收。
- [x] **偏好与材质顺序回归已编写**：[测试源码](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/adapters/base/test/web-material-preferences-sequence.test.ts)覆盖 mounted preference 改变及 held decode；这是已有源码范围，不宣称本轮重跑或完整 native 通过。
- [ ] 对四 Web 宿主真实 forced-colors/contrast/transparency/motion、实际材质支持与 fallback 重绘完成 source-bound 验收；GPUI wire、Compiler #732 differential 和 Flutter/Qt backend 仍须独立完成。

---

## Parent and purpose

Dependency of #792 (Liquid Glass / Bootstrap 2.3.2 projections). This Issue isolates the genuinely new environment/material ownership questions from the ordinary Base-inheriting projection implementation. It does not admit a new Base component or a stable all-host guarantee.

## Source-grounded gap

At main `fedbe05a`:
- `M-RULE-META-0001-A` explicitly keeps keys other than colorScheme, including reducedMotion, **sampled**.
- `C-RULE-COLOR-SCHEME-0001` and `HC-COLOR-SCHEME-INVALIDATION-0001` govern the bounded mounted colorScheme lease; `RuleMetaModuleImpl.reconcileLease()` deliberately selects only meta:colorScheme dependencies.
- `createDefaultWebMetaGetter()` supplies colorScheme/reducedMotion only. A new getter key alone would become stale after a preference change.
- Existing author-side tokens can express alpha fills and `backdrop-blur-xs`; they cannot query host realization support, guarantee background-sensitive legibility, or express native Liquid Glass/refraction.
- GPUI's Rust mapper returns explicit unmapped diagnostics for backdrop-filter/box-shadow/background-image; Flutter and Qt have no current repository backend/profile.

## Proposed ownership (for explicit semantic review)

1. **No new Base Button/Switch behavior:** Base retains activation, focus, value and accessibility semantics. Family Prototypes own the visual fallback policy.
2. A bounded environment-preference capability supplies current values and mounted invalidation for reducedMotion, reducedTransparency and contrast. Unknown must remain distinguishable from no-preference; a missing API is not affirmative enhancement support.
3. Preserve the current colorScheme-only contract and its getter binding, lease generations, detach/rebind/dispose guarantees. Either introduce a separately named bounded preference source or explicitly revise/replace the general source contract; do not silently broaden the existing colorScheme capability.
4. Host realization support is separate from user preference: an explicit capability describes the admitted alpha/background-blur/shadow subset. Prototype intent is not CSS.supports, platform names or a browser media query.
5. Start with **bounded translucent blur**, not an invented general Liquid Glass material API. An opaque readable surface is the default whenever support or accessibility input is unknown, unsupported or reduction is requested. Regular functional/navigation controls are the initial use, not page/content backgrounds.
6. True refraction, adaptive luminosity, moving specular highlights and morphing require separately designed material capabilities. #495 already owns the drag/geometry/value-motion proposals; do not duplicate them.

## Smallest executable progression

- [x] **Record and accept exact keys/value vocabulary, ownership, unknown policy and per-key subscription scope before revising normative entities.**
- [x] **Add a draft contract/capability/test chain for that bounded decision; never promote it based on package presence.**
- [x] **Implement Web MediaQueryList source with one shared observer per relevant realm/query, dependency-driven instance leases, prompt live preference re-evaluation and terminal cleanup.**
- [x] **Preserve custom getter isolation; do not silently combine a custom getter with default observer data. Prove replacement, getter mismatch, detach/remount, late callback, duplicate lease and disposal cases.**
- [ ] Prototype rule chooses readable opaque vs bounded blur/alpha from actual declared host support and preference inputs; property change without pointer interaction must repaint the mounted control.
- [ ] Verify both ordinary and reduced-transparency/contrast/motion modes in WC/React/Vue3/Vue2 using real host rendering and forced-colors coverage. Unsupported media queries fail to the safe policy rather than a fabricated preference.
- [ ] Extend the GPUI wire/environment path and mapped subset only with versioned data and executable host tests; no synchronous guest-runtime work in a frame path.
- [ ] Add Compiler source/IR/backend and independent differential coverage via #732 before advertising generated parity. Flutter/Qt remain explicit backend dependencies.

## Decision packet

The blocking choice is the public owner and lifetime of reactive environment preferences and host material support, not whether the family may use existing Base semantics. The recommended first design is a separately bounded preference-source capability plus separately bounded style-support facts, keeping colorScheme compatibility unchanged. A generic unrestricted reactive key/value bus or family-local browser observer is not the proposed shortcut.

## References

- [Apple Materials HIG](https://developer.apple.com/design/human-interface-guidelines/materials)
- `spec/modules/M-RULE-META-0001.yaml`
- `spec/contracts/C-RULE-COLOR-SCHEME-0001.yaml`
- `packages/modules/rule-meta/src/{caps,create}.ts`
- `packages/adapters/base/src/platform/{web-preferences,web-color-scheme-source}.ts`
- `native/gpui/crates/proto-ui-gpui/src/style.rs`
- #495, #687, #732, #733

## Agent evidence

Sanitized request paraphrase: new style families must remain real portable Prototypes with a path to all requested runtimes and Compiler, including safe accessibility fallback. Evidence disposition: partial, source-bound proposal only. No capability is claimed implemented by this Issue. The source observation is the explicit colorScheme-only dependency test and sampled-key criterion; executable regression and actual rendered before/after captures remain implementation debt.

Co-author by OpenAI Dots

