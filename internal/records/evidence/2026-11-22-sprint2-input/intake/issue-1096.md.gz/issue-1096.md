# [Finf v2][887-followup] Base 家族投影完成度 · Disclosure：Collapsible/Accordion 家族特定披露行为与中断

https://github.com/Proto-UI/Proto-UI/issues/1096

<!-- proto-ui:issue-governance:20261122:1096:v1 -->

## 当前主线核对 · 2026-11-22

Agent: ChatGPT，按当前用户授权核对与治理。审计截止 [`a8bf56087`](https://github.com/Proto-UI/Proto-UI/commit/a8bf56087e5836e3c14c153cafbd796bd98bff37)；各项执行证据保留其实际 SHA。

核对基线：[`2c7eae253`](https://github.com/Proto-UI/Proto-UI/commit/2c7eae25357d0c5bae29bd5e92caae3a4ea39730)。以下将已交付的源码与尚未完成的验收分开，原始范围和历史记录保留。

- [x] **既有受控/presence 实现与 Shadcn block-flow 修复保留**：[Collapsible](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/prototypes/base/src/collapsible/content.proto.ts)及[Accordion](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/prototypes/base/src/accordion/content.proto.ts)实际调用 Runtime presence；原 #1130 八个 native 场景继续按原开发 head 记账。
- [x] **家族披露范围已有源码区分**：[配方记录](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/internal/records/2026-10-10-finf-disclosure-recipe-repair.md)说明固定 Shadcn/Neo wrapper 的要求，不能把所有家族都当成同一高度动画。
- [ ] 完成原始 family-specific 披露/中断、真实内容范围与动态增删/反转/卸载，以及 #884 解剖/生命周期协同的接受证据；AT 与跨宿主/完整视觉仍开放。
- [ ] Bootstrap Collapse 高度运动仍需独立定义、实现与 native 证明；Bootstrap/Liquid 属于 0.4，不把其未完条件误记成已完成或自动扩入 0.3。

---

## 来源

拆自 #887「Finf scope」→「Disclosure」。关联 Finf v2 总追踪 #890。原 PR872 body 的 54 原型/组合 0/54 已验收，本 Issue 承接其中 Disclosure 一类。

## 未完成项（原 checklist 逐项保留）

- [ ] Collapsible：受控 Root/Trigger/Content、keepMounted 与运行时拥有 presence；TODO：验证家族特定披露行为与中断；固定 Shadcn/Neo wrapper 无需内容动画，而 Bootstrap Collapse 高度运动需单独定义/实现与原生证据；与 #884 owner 整合生命周期/解剖工作
  - [x] Collapsible：受控 Root/Trigger/Content、keepMounted 与运行时拥有 presence — 实现层已交付：`packages/prototypes/base/src/collapsible/`，`packages/prototypes/shadcn/src/collapsible/`，`packages/prototypes/brutalist/src/collapsible/`，`P-BASE-COLLAPSIBLE.yaml`@9da3dfd18，`P-SHADCN-COLLAPSIBLE.yaml`@9da3dfd18，`P-BRUTALIST-COLLAPSIBLE.yaml`@9da3dfd18
  - [ ] 验证家族特定披露行为与中断；固定 Shadcn/Neo wrapper 无需内容动画，而 Bootstrap Collapse 高度运动需单独定义/实现与原生证据；与 #884 owner 整合生命周期/解剖工作
- [ ] Accordion：单/多打开项、allowEmpty、orientation/RTL 与五部分；TODO：真实内容范围运动、反转与动态生命周期验收；保持 #884 所有权独立
  - [x] Accordion：单/多打开项、allowEmpty、orientation/RTL 与五部分 — 实现层已交付：`packages/prototypes/base/src/accordion/`，`packages/prototypes/shadcn/src/accordion/`，`packages/prototypes/brutalist/src/accordion/`，`P-BASE-ACCORDION.yaml`@9da3dfd18，`P-SHADCN-ACCORDION.yaml`@9da3dfd18，`P-BRUTALIST-ACCORDION.yaml`@9da3dfd18
  - [ ] 真实内容范围运动、反转与动态生命周期验收；保持 #884 所有权独立

## 验收与验证边界

每个原型须四投影原子对等，完整家族变体/尺寸/间距、原生视觉与 AT 证据。不以历史证据冒充当前 head 验收。Collapsible/Accordion 与 #884 owner 的整合边界保持独立。

## 已完成的有限修复（不勾选上方复合未完成项）
<!-- dot-accordion-flow-1130-checked-20261031 -->

- [x] Shadcn Accordion Content 的展开 block flow / 普通块子元素实际 padding；WC、React、Vue、Vue 2 关闭与重开恢复。#1130，开发 head `2571d7b444537eb395bc11acdbcd40eb252072e6`；新增 8 个 native 场景全通过，生产四 host 复验详见 [证据与未完成边界](https://github.com/Proto-UI/Proto-UI/issues/1096#issuecomment-6547495952)。此项不代表全部 Accordion、Collapsible、运动/AT/GPUI 验收；原 native 2 项失败与其他开放项保留。

## 0.3 实现层拆分说明

原始 checkbox 把「实现」与「验收（原生视觉/辅助技术证据）」写在同一行，因此任何一行都无法单独勾选。按 0.3 计划「Check completed source-bound children promptly」与 pui-dev 的 compound-checkbox 规则，下面把已具备证据的实现条件拆成可独立勾选的子项并勾选；父项与验收子项保持未勾选。

Bootstrap 2.3.2 与 Liquid Glass 不在 0.3 范围内，涉及它们的 TODO 不构成 0.3 阻塞。

