# [Finf v2][887-followup] Base 家族投影完成度 · Form 与关系：Label/Field/Fieldset/Form/Checkbox Group 四投影原子对等

https://github.com/Proto-UI/Proto-UI/issues/1094

<!-- proto-ui:issue-governance:20261122:1094:v1 -->

## 当前主线核对 · 2026-11-22

Agent: ChatGPT，按当前用户授权核对与治理。审计截止 [`a8bf56087`](https://github.com/Proto-UI/Proto-UI/commit/a8bf56087e5836e3c14c153cafbd796bd98bff37)；各项执行证据保留其实际 SHA。

核对基线：[`a8bf56087`](https://github.com/Proto-UI/Proto-UI/commit/a8bf56087e5836e3c14c153cafbd796bd98bff37)。以下将已交付的源码与尚未完成的验收分开，原始范围和历史记录保留。

- [x] **原五类 Label 公开消费者成果继续保留**：body 已登记 `bcc9dd4b` 的 12/12 四宿主结果；仍按原 source 记录，不重命名为本基线重新运行。
- [x] **Button、Toggle、ToggleGroup Item 的命名/激活扩展已交付**：[Button](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/prototypes/base/src/button/button.proto.ts)、[Toggle](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/prototypes/base/src/toggle/toggle.proto.ts)、[Item](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/packages/prototypes/base/src/toggle-group/item.proto.ts)复用 governed ControlLabel；[既有 source-bound native 记录](https://github.com/Proto-UI/Proto-UI/blob/2c7eae25357d0c5bae29bd5e92caae3a4ea39730/internal/records/2026-11-16-0.3-release-blocking-list.md)含 Base/Shadcn/Brutalist × React/WC 六例实际名称、关联、受控拒绝和 disabled 验证。
- [ ] Label 真实 AT/完整家族仍开放；Field 嵌套/复合校验与恢复、Fieldset disabled/Form 与组命名、Form submit/reset/validator 重入、CheckboxGroup 父组/提交重置及各家族原生证据继续保留。

### a8bf 整合补充

- [x] **Number Field nullable/locale/scrub 与现有 Field/Form 的实现组合已交付**：[能力回归源码](https://github.com/Proto-UI/Proto-UI/blob/a8bf56087e5836e3c14c153cafbd796bd98bff37/packages/prototypes/base/test/number-field-capabilities.test.ts)包含 required Field/Form 的实际 null、reset、controlled refusal 和 IME lease，已列入 #1666 的593候选回归。此项不等于所有嵌套 Form/validator recipe 的原生/AT接受。

新能力候选的 **36文件/593 tests** 与文档/类型结果属于记录中的开发组合；a8bf 合入后的完整原生/周期未由本次审计重跑，不能把该数字当整合主线全量通过。

---

## 来源

拆自 #887「Finf scope」→「Form and relationships」与「Prior-work closeouts」。关联 Finf v2 总追踪 #890。原 PR872 body 的 54 原型/组合 0/54 已验收，本 Issue 承接其中 Form 与关系一类。

## 未完成项（原 checklist 逐项保留）

- [ ] Label：typed naming/activation association 与四投影；TODO：真实跨控命名、激活与辅助技术证据
  - [x] Label：typed naming/activation association 与四投影 — 实现层已交付：`packages/prototypes/base/src/label/`，`packages/prototypes/shadcn/src/label/`，`packages/prototypes/brutalist/src/label/`，`P-BASE-LABEL.yaml`@76de3e2ef，`P-SHADCN-LABEL.yaml`@9da3dfd18，`P-BRUTALIST-LABEL.yaml`@9da3dfd18
  - [ ] 真实跨控命名、激活与辅助技术证据
    - [x] **跨控命名/激活的有限真实浏览器证据已经交付** — 原 12/12 Label 消费者，加 #1454 三种 command target 的六个 React/WC 消费者；source 绑定见下。
    - [ ] 真实辅助技术和完整家族验收未完成，父项保留。
- [ ] Field：Control/Label/Description/Error/Validity、约束与可打断外部校验；TODO：完整嵌套/复合控校验、受控恢复与家族状态/AT 证据
  - [x] Field：Control/Label/Description/Error/Validity、约束与可打断外部校验 — 实现层已交付：`packages/prototypes/base/src/field/`，`packages/prototypes/shadcn/src/field/`，`packages/prototypes/brutalist/src/field/`，`P-BASE-FIELD.yaml`@9da3dfd18，`P-SHADCN-FIELD.yaml`@9da3dfd18，`P-BRUTALIST-FIELD.yaml`@9da3dfd18
  - [ ] 完整嵌套/复合控校验、受控恢复与家族状态/AT 证据
- [ ] Fieldset：Base 与四家族的 Root/Legend/Description；TODO：嵌套 disabled/form 组合、原生组命名与生命周期验收
  - [x] Fieldset：Base 与四家族的 Root/Legend/Description — 实现层已交付：`packages/prototypes/base/src/fieldset/`，`packages/prototypes/shadcn/src/fieldset/`，`packages/prototypes/brutalist/src/fieldset/`，`P-BASE-FIELDSET.yaml`@9da3dfd18，`P-SHADCN-FIELDSET.yaml`@9da3dfd18，`P-BRUTALIST-FIELDSET.yaml`@9da3dfd18
  - [ ] 嵌套 disabled/form 组合、原生组命名与生命周期验收
- [ ] Form：Field 注册、submit/reset 动作与异步提交/校验状态；TODO：完整公开复合控与 validator recipe、失败/重入与原生提交/AT 证据
  - [x] Form：Field 注册、submit/reset 动作与异步提交/校验状态 — 实现层已交付：`packages/prototypes/base/src/form/`，`packages/prototypes/shadcn/src/form/`，`packages/prototypes/brutalist/src/form/`，`P-BASE-FORM.yaml`@9da3dfd18，`P-SHADCN-FORM.yaml`@9da3dfd18，`P-BRUTALIST-FORM.yaml`@af3a15a9d
  - [ ] 完整公开复合控与 validator recipe、失败/重入与原生提交/AT 证据
- [ ] Checkbox Group：受控多值、All/mixed 状态、readOnly 与被动 indicator recipe；TODO：嵌套父与 Form 提交/重置组合；完整四家族/输入证据
  - [x] Checkbox Group：受控多值、All/mixed 状态、readOnly 与被动 indicator recipe — 实现层已交付：`packages/prototypes/base/src/checkbox-group/`，`packages/prototypes/shadcn/src/checkbox-group/`，`packages/prototypes/brutalist/src/checkbox-group/`，`P-BASE-CHECKBOX-GROUP.yaml`@9da3dfd18，`P-SHADCN-CHECKBOX-GROUP.yaml`@9da3dfd18，`P-BRUTALIST-CHECKBOX-GROUP.yaml`@9da3dfd18
  - [ ] 嵌套父与 Form 提交/重置组合；完整四家族/输入证据

## 验收与验证边界

每个原型须四投影原子对等（Base/Shadcn/Brutalist/Bootstrap 或 Liquid Glass 映射），完整家族变体/尺寸/间距、原生视觉与 AT 证据。不以历史证据冒充当前 head 验收。
## 0.3 实现层拆分说明

原始 checkbox 把「实现」与「验收（原生视觉/辅助技术证据）」写在同一行，因此任何一行都无法单独勾选。按 0.3 计划「Check completed source-bound children promptly」与 pui-dev 的 compound-checkbox 规则，下面把已具备证据的实现条件拆成可独立勾选的子项并勾选；父项与验收子项保持未勾选。

Bootstrap 2.3.2 与 Liquid Glass 不在 0.3 范围内，涉及它们的 TODO 不构成 0.3 阻塞。

<!-- proto-ui:1094:label-browser-44354089920-shard4 -->

### 2026-11-19 · Label 浏览器验收增量

- [x] 已核对 `bcc9dd4b75e410cf858886a7058f4ec21c9cae1b` 的 Label 公开消费者套件。Base、Shadcn、Brutalist × WC、React、Vue、Vue 2 共 12 例全部通过。用例覆盖五类真实目标的命名和操作归属，含此前失败的 Shadcn / React 只读 Textarea 行。[分片报告及原生截图](https://github.com/Proto-UI/Proto-UI/actions/runs/44354089920/artifacts/14453306757)
- [ ] Label 辅助技术与完整家族验收。父条件继续开放，分片内其他失败及 0.3 整体回归结果继续由 #1178 跟踪。

