import { describe, expect, it, vi } from 'vitest';
import type { TextControlEvent, TextControlLineMode, TextControlPatch } from '@proto.ui/core';
import { CapsVault, SYS_CAP, type SystemCaps } from '@proto.ui/module-base';
import {
  TEXT_CONTROL_HOST_CAP,
  TEXT_CONTROL_RUN_IN_CALLBACK_CAP,
  type TextControlHost,
  type TextControlHostConnection,
  type TextControlHostLease,
} from '../src/caps';
import { createTextControlModule } from '../src/create';
import { declareTextControl } from '../src/declaration';
import { createWebTextControlHost } from '../src/web';

// Retain exact assertions for the pre-existing value/composition surface while
// the independently specified selection surface is checked in selection.test.ts.
function withoutSelection<T extends { selection?: unknown } | null>(value: T) {
  if (!value) return value;
  const { selection: _selection, ...prior } = value;
  return prior;
}

type TestSystemCaps = SystemCaps & {
  phase: 'setup' | 'callback';
  flushDeferred(): void;
};

function createSystemCaps(): TestSystemCaps {
  let phase: 'setup' | 'callback' = 'setup';
  const deferred: Array<() => void> = [];
  const run = { update() {} };
  return {
    execPhase: () => phase,
    domain: () => (phase === 'setup' ? 'setup' : 'runtime'),
    protoPhase: () => 'mounted',
    instancePhase: () => 'alive',
    mountPhase: () => 'mounted',
    isDisposed: () => false,
    ensureNotDisposed() {},
    ensureExecPhase(_op, expected) {
      const values = Array.isArray(expected) ? expected : [expected];
      if (!values.includes(phase)) throw new Error('illegal phase');
    },
    ensureSetup() {
      if (phase !== 'setup') throw new Error('illegal phase');
    },
    ensureRuntime() {
      if (phase === 'setup') throw new Error('illegal phase');
    },
    ensureCallback() {
      if (phase !== 'callback') throw new Error('illegal phase');
    },
    getCallbackCtx: () => (phase === 'callback' ? run : undefined),
    deferAfterCallback: (task) => deferred.push(task),
    set phase(value: 'setup' | 'callback') {
      phase = value;
    },
    flushDeferred() {
      for (const task of deferred.splice(0)) task();
    },
  } as TestSystemCaps;
}

function event(type: TextControlEvent['type'], value: string, composing = false): TextControlEvent {
  return { type, value, composing, data: null, inputType: null };
}

function createHarness(
  withHost = true,
  lineMode: TextControlLineMode = 'multiline',
  beforeRun?: () => void
) {
  const sys = createSystemCaps();
  const vault = new CapsVault();
  const connectionBox: { current: TextControlHostConnection | null } = { current: null };
  let patchValue = '';
  let latestPatch: TextControlPatch = {};
  let disposed = 0;
  let updateCount = 0;
  vault.attachBase([[SYS_CAP, sys]]);
  const lease: TextControlHostLease = {
    update(patch) {
      updateCount += 1;
      latestPatch = patch;
      if (typeof patch.value === 'string') patchValue = patch.value;
    },
    snapshot: () => ({ value: patchValue, composing: false }),
    dispose() {
      disposed += 1;
    },
  };
  const host: TextControlHost = {
    attach(connection) {
      connectionBox.current = connection;
      latestPatch = connection.patch;
      patchValue = connection.patch.value ?? connection.patch.defaultValue ?? '';
      return lease;
    },
  };
  if (withHost)
    vault.attach([
      [TEXT_CONTROL_HOST_CAP, host],
      ...(beforeRun
        ? [
            [
              TEXT_CONTROL_RUN_IN_CALLBACK_CAP,
              (callback: () => void) => {
                beforeRun();
                callback();
              },
            ] as const,
          ]
        : []),
    ]);
  const module = createTextControlModule({
    init: {
      prototypeName: 'x-textarea',
      declarations: [declareTextControl({ content: 'plain-text', lineMode, engine: 'host' })],
    },
    caps: vault,
    deps: {
      requireFacade: () => {
        throw new Error('unused');
      },
      requirePort: () => {
        throw new Error('unused');
      },
      tryFacade: () => undefined,
      tryPort: () => undefined,
    },
  });
  return {
    sys,
    vault,
    module,
    connectionBox,
    getPatchValue: () => patchValue,
    getLatestPatch: () => latestPatch,
    setPatchValue: (value: string) => {
      patchValue = value;
    },
    getDisposed: () => disposed,
    getUpdateCount: () => updateCount,
  };
}

describe('module-text-control', () => {
  it('keeps uncontrolled ownership stable after edits and later prop changes', () => {
    const harness = createHarness();
    const control = harness.module.facade.declare();
    expect(() => harness.module.facade.declare()).toThrow(/one text control/);
    harness.module.hooks.onMountPhase?.('mounted', 1);
    harness.sys.phase = 'callback';
    control.sync({ valueMode: 'uncontrolled', defaultValue: 'initial' });
    const connection = harness.connectionBox.current;
    if (!connection) throw new Error('text-control host connection was not attached');

    const values: string[] = [];
    harness.sys.phase = 'setup';
    control.on('input', (_run, next) => values.push(next.value));
    harness.sys.phase = 'callback';
    connection.onEvent(event('input', 'dirty'));
    expect(withoutSelection(control.snapshot())).toEqual({ value: 'dirty', composing: false });
    expect(values).toEqual(['dirty']);

    control.sync({ valueMode: 'uncontrolled', defaultValue: 'replacement' });
    control.sync({ valueMode: 'controlled', value: 'late control' });
    expect(control.snapshot()?.value).toBe('dirty');
    expect(harness.getPatchValue()).toBe('dirty');

    harness.module.hooks.onMountPhase?.('detached', 1);
    expect(harness.getDisposed()).toBeGreaterThan(0);
  });

  it('retains defaultValue across unrelated patches and a fresh host lease', () => {
    const harness = createHarness();
    const control = harness.module.facade.declare();
    harness.module.hooks.onMountPhase?.('mounted', 1);
    harness.sys.phase = 'callback';
    control.sync({ valueMode: 'uncontrolled', defaultValue: 'initial' });
    control.sync({ disabled: true });

    expect(harness.getLatestPatch()).toMatchObject({
      valueMode: 'uncontrolled',
      defaultValue: 'initial',
      disabled: true,
    });

    harness.module.hooks.onMountPhase?.('detached', 1);
    harness.module.hooks.onMountPhase?.('mounted', 2);
    expect(harness.getLatestPatch()).toMatchObject({
      valueMode: 'uncontrolled',
      defaultValue: 'initial',
      disabled: true,
    });
  });

  it('retains the declaration and accepts common hints for both line modes', () => {
    const multiline = createHarness(true, 'multiline');
    const multilineControl = multiline.module.facade.declare();
    multiline.module.hooks.onMountPhase?.('mounted', 1);
    multiline.sys.phase = 'callback';
    expect(() => multilineControl.sync({ inputMode: 'search' })).not.toThrow();
    expect(() => multilineControl.sync({ enterKeyHint: 'search' })).not.toThrow();
    expect(() => multilineControl.sync({ rows: 4, wrap: 'hard' })).not.toThrow();

    const single = createHarness(true, 'single');
    const singleControl = single.module.facade.declare();
    single.module.hooks.onMountPhase?.('mounted', 1);
    single.sys.phase = 'callback';
    expect(() => singleControl.sync({ rows: 4 })).toThrow(/not compatible with single-line/);
    expect(() => singleControl.sync({ wrap: 'hard' })).toThrow(/not compatible with single-line/);
    expect(() => singleControl.sync({ inputMode: 'search', enterKeyHint: 'search' })).not.toThrow();
  });

  it('removes normalized line feeds from single-line patch, state, and event values', () => {
    const harness = createHarness(true, 'single');
    const control = harness.module.facade.declare();
    harness.module.hooks.onMountPhase?.('mounted', 1);
    const seen: string[] = [];
    control.on('input', (_run, next) => seen.push(next.value));

    harness.sys.phase = 'callback';
    control.sync({ valueMode: 'uncontrolled', defaultValue: 'a\r\nb\nc' });
    expect(harness.getLatestPatch().defaultValue).toBe('abc');
    expect(withoutSelection(control.snapshot())).toEqual({ value: 'abc', composing: false });

    const connection = harness.connectionBox.current;
    if (!connection) throw new Error('text-control host connection was not attached');
    connection.onEvent(event('input', 'x\r\ny\nz'));
    expect(withoutSelection(control.snapshot())).toEqual({ value: 'xyz', composing: false });
    expect(seen).toEqual(['xyz']);
  });

  it('canonicalizes CR and CRLF in outward event data', () => {
    const harness = createHarness(true, 'multiline');
    const control = harness.module.facade.declare();
    harness.module.hooks.onMountPhase?.('mounted', 1);
    const seen: Array<string | null> = [];
    control.on('compositionupdate', (_run, next) => seen.push(next.data));

    const connection = harness.connectionBox.current;
    if (!connection) throw new Error('text-control host connection was not attached');
    harness.sys.phase = 'callback';
    connection.onEvent({
      ...event('compositionupdate', 'value'),
      data: 'a\r\nb\rc',
      inputType: 'insertCompositionText',
    });

    expect(seen).toEqual(['a\nb\nc']);
  });

  it('preserves controlled composition and restores only after the IME boundary', async () => {
    const harness = createHarness();
    const control = harness.module.facade.declare();
    harness.module.hooks.onMountPhase?.('mounted', 1);
    harness.sys.phase = 'callback';
    control.sync({ valueMode: 'controlled', value: 'fixed' });
    const connection = harness.connectionBox.current;
    if (!connection) throw new Error('text-control host connection was not attached');

    const beforeComposition = harness.getUpdateCount();
    connection.onEvent(event('compositionstart', 'fixed', true));
    harness.setPatchValue('編');
    connection.onEvent({
      ...event('input', '編', true),
      data: '編',
      inputType: 'insertCompositionText',
    });
    expect(harness.getPatchValue()).toBe('編');
    expect(withoutSelection(control.snapshot())).toEqual({ value: 'fixed', composing: true });
    expect(harness.getUpdateCount()).toBe(beforeComposition);

    control.sync({ disabled: true });
    expect(harness.getPatchValue()).toBe('編');

    connection.onEvent(event('compositionend', '編'));
    expect(harness.getPatchValue()).toBe('編');
    await Promise.resolve();
    expect(harness.getPatchValue()).toBe('fixed');

    harness.setPatchValue('attempt');
    connection.onEvent(event('input', 'attempt'));
    await Promise.resolve();
    expect(harness.getPatchValue()).toBe('fixed');

    control.sync({ valueMode: 'controlled', value: 'accepted' });
    expect(control.snapshot()?.value).toBe('accepted');
    expect(harness.getPatchValue()).toBe('accepted');
  });

  it('disposes the active host lease when attached capabilities reset', () => {
    const harness = createHarness();
    const control = harness.module.facade.declare();
    harness.module.hooks.onMountPhase?.('mounted', 1);
    harness.sys.phase = 'callback';
    control.sync({ valueMode: 'uncontrolled', defaultValue: 'initial' });

    expect(harness.getDisposed()).toBe(0);
    harness.vault.resetAttached();
    expect(harness.getDisposed()).toBe(1);
  });

  it('requires a declaration while tolerating a temporarily missing host', () => {
    const sys = createSystemCaps();
    const vault = new CapsVault();
    vault.attachBase([[SYS_CAP, sys]]);
    const withoutDeclaration = createTextControlModule({
      init: { prototypeName: 'x-missing-declaration', declarations: [] },
      caps: vault,
      deps: {
        requireFacade: () => {
          throw new Error('unused');
        },
        requirePort: () => {
          throw new Error('unused');
        },
        tryFacade: () => undefined,
        tryPort: () => undefined,
      },
    });
    expect(() => withoutDeclaration.facade.declare()).toThrow(/static text-control declaration/);

    const harness = createHarness(false);
    const control = harness.module.facade.declare();
    harness.module.hooks.onMountPhase?.('mounted', 1);
    harness.sys.phase = 'callback';
    expect(() =>
      control.sync({ valueMode: 'uncontrolled', defaultValue: 'retained' })
    ).not.toThrow();
    expect(control.snapshot()?.value).toBe('retained');
  });
});

describe.each(['single', 'multiline'] as const)('text-control %s composition lease', (lineMode) => {
  for (const valueMode of ['controlled', 'uncontrolled'] as const) {
    it.each(['detach', 'provider reset', 'provider replacement'] as const)(
      `projects the retained ${valueMode} value after %s interrupts composition`,
      (boundary) => {
        const h = createHarness(false, lineMode);
        const createTarget = () =>
          document.createElement(lineMode === 'single' ? 'input' : 'textarea');
        let target = createTarget();
        const host = createWebTextControlHost(() => target);
        h.vault.attach([[TEXT_CONTROL_HOST_CAP, host]]);
        const control = h.module.facade.declare();
        const seen: TextControlEvent[] = [];
        for (const type of ['input', 'change', 'compositionstart', 'compositionend'] as const) {
          control.on(type, (_run, next) => seen.push(next));
        }
        h.module.hooks.onMountPhase?.('mounted', 1);
        h.sys.phase = 'callback';
        control.sync({ valueMode, value: 'owner', defaultValue: 'initial' });
        target.dispatchEvent(new CompositionEvent('compositionstart'));
        target.value = 'draft\r\nvalue';
        target.dispatchEvent(new InputEvent('input', { isComposing: true }));
        control.sync({ value: 'latest\r\nowner' });
        const expected = valueMode === 'controlled' ? 'latest\nowner' : 'draft\nvalue';
        const value = lineMode === 'single' ? expected.replace('\n', '') : expected;
        expect(withoutSelection(control.snapshot())).toEqual({ value, composing: true });
        const old = target;
        const beforeRevocation = seen.slice();

        if (boundary === 'detach') {
          h.module.hooks.onMountPhase?.('unmounting', 1);
          h.module.hooks.onMountPhase?.('detached', 1);
        } else if (boundary === 'provider reset') {
          h.vault.resetAttached();
        }
        target = createTarget();
        if (boundary === 'detach') {
          h.module.hooks.onMountPhase?.('mounted', 2);
        } else {
          h.vault.attach([
            [
              TEXT_CONTROL_HOST_CAP,
              boundary === 'provider reset' ? host : createWebTextControlHost(() => target),
            ],
          ]);
        }

        expect(withoutSelection(control.snapshot())).toEqual({ value, composing: false });
        expect(target.value).toBe(value);
        expect(seen).toEqual(beforeRevocation);
        control.sync({ value: 'next owner', placeholder: 'new lease' });
        expect(target.value).toBe(valueMode === 'controlled' ? 'next owner' : value);
        expect(target.placeholder).toBe('new lease');

        target.dispatchEvent(new CompositionEvent('compositionstart'));
        target.value = 'new candidate';
        old.dispatchEvent(new CompositionEvent('compositionend'));
        old.dispatchEvent(new InputEvent('input'));
        expect(control.snapshot()?.composing).toBe(true);
        expect(target.value).toBe('new candidate');
        expect(seen).toHaveLength(beforeRevocation.length + 1);
        h.module.hooks.dispose?.();
        target.dispatchEvent(new CompositionEvent('compositionend'));
        target.dispatchEvent(new InputEvent('input'));
        expect(control.snapshot()).toBeNull();
        expect(target.value).toBe('new candidate');
        expect(seen).toHaveLength(beforeRevocation.length + 1);
      }
    );
  }
});

it('keeps old composition callbacks and queued restoration out of a new lease', async () => {
  const h = createHarness();
  const control = h.module.facade.declare();
  h.module.hooks.onMountPhase?.('mounted', 1);
  h.sys.phase = 'callback';
  control.sync({ valueMode: 'controlled', value: 'owner' });
  const old = h.connectionBox.current!;
  old.onEvent(event('compositionstart', 'owner', true));
  old.onEvent(event('compositionend', 'old candidate'));
  h.module.hooks.onMountPhase?.('detached', 1);
  h.module.hooks.onMountPhase?.('mounted', 2);
  h.connectionBox.current!.onEvent(event('compositionstart', 'owner', true));
  h.setPatchValue('new candidate');
  const updates = h.getUpdateCount();

  old.onEvent(event('compositionend', 'stale'));
  old.onEvent(event('input', 'stale'));
  await Promise.resolve();
  expect(withoutSelection(control.snapshot())).toEqual({ value: 'owner', composing: true });
  expect(h.getPatchValue()).toBe('new candidate');
  expect(h.getUpdateCount()).toBe(updates);
});

it.each(['input', 'compositionend'] as const)(
  'does not schedule old %s restoration into a lease replaced by its listener',
  async (type) => {
    const h = createHarness();
    const control = h.module.facade.declare();
    control.on(type, () => {
      h.module.hooks.onMountPhase?.('detached', 1);
      h.module.hooks.onMountPhase?.('mounted', 2);
      h.connectionBox.current!.onEvent(event('compositionstart', 'owner', true));
      h.setPatchValue('new candidate');
    });
    h.module.hooks.onMountPhase?.('mounted', 1);
    h.sys.phase = 'callback';
    control.sync({ valueMode: 'controlled', value: 'owner' });
    const old = h.connectionBox.current!;
    old.onEvent(event('compositionstart', 'owner', true));
    old.onEvent(event(type, 'old candidate'));
    const updates = h.getUpdateCount();
    await Promise.resolve();
    expect(withoutSelection(control.snapshot())).toEqual({ value: 'owner', composing: true });
    expect(h.getPatchValue()).toBe('new candidate');
    expect(h.getUpdateCount()).toBe(updates);
  }
);

it('T-TEXT-CONTROL-0001-CASE-LIFETIME: stale lease events cannot change current value or invoke listeners', () => {
  const h = createHarness();
  const control = h.module.facade.declare();
  const values: string[] = [];
  control.on('input', (_run, event) => values.push(event.value));
  h.module.hooks.onMountPhase?.('mounted', 1);
  h.sys.phase = 'callback';
  control.sync({ defaultValue: 'initial' });
  const old = h.connectionBox.current!;
  h.module.hooks.onMountPhase?.('detached', 1);
  h.module.hooks.onMountPhase?.('mounted', 2);
  old.onEvent(event('input', 'stale'));
  expect(control.snapshot()?.value).toBe('initial');
  expect(values).toEqual([]);
  h.connectionBox.current!.onEvent(event('input', 'current'));
  expect(values).toEqual(['current']);
  h.module.hooks.dispose?.();
  h.connectionBox.current!.onEvent(event('input', 'disposed'));
  expect(values).toEqual(['current']);
});

it('T-TEXT-CONTROL-0001-CASE-CANCEL: listener cancellation is setup-only', () => {
  const h = createHarness();
  const control = h.module.facade.declare();
  const off = control.on('input', () => {});
  off();
  off();
  h.sys.phase = 'callback';
  expect(off).toThrow('illegal phase');
});

// C-TEXT-CONTROL-0001-D/E/F/G: CallbackScope drains pending props before
// invoking the event listener. This controlled prelude reproduces that order.
describe('TextControl composition across callback-scope entry', () => {
  it.each([
    ['compositionstart', true],
    ['input', true],
    ['input', false],
    ['compositionend', false],
  ] as const)(
    'protects the native candidate while old props drain before %s (composing=%s)',
    async (type, composing) => {
      let beforeRun = () => {};
      const h = createHarness(true, 'multiline', () => beforeRun());
      const control = h.module.facade.declare();
      const seen: Array<{ value: string; composing: boolean }> = [];
      control.on(type, (_run, next) => {
        seen.push({ value: next.value, composing: next.composing });
        if (!next.composing) control.sync({ value: next.value });
      });
      h.module.hooks.onMountPhase?.('mounted', 1);
      h.sys.phase = 'callback';
      control.sync({ valueMode: 'controlled', value: 'A备' });
      const connection = h.connectionBox.current!;
      if (type === 'compositionend') connection.onEvent(event('compositionstart', 'A备', true));
      h.setPatchValue('A备注');
      const during: Array<{ value: string; composing: boolean }> = [];
      beforeRun = () => {
        // A pending props task drains once; later reconciliation must not
        // invent another stale owner update after this event was accepted.
        beforeRun = () => {};
        control.sync({ value: 'A备' });
        during.push({ value: h.getPatchValue(), composing: control.snapshot()!.composing });
      };
      connection.onEvent(event(type, 'A备注', composing));
      expect(during).toEqual([
        { value: 'A备注', composing: type === 'compositionend' || composing },
      ]);
      expect(seen).toEqual([{ value: 'A备注', composing }]);
      await Promise.resolve();
      expect(h.getPatchValue()).toBe('A备注');
      h.module.hooks.onMountPhase?.('detached', 1);
    }
  );

  it.each(['compositionstart', 'compositionend'] as const)(
    'does not deliver an old %s after the callback prelude replaces the lease',
    async (type) => {
      let beforeRun = () => {};
      const h = createHarness(true, 'multiline', () => beforeRun());
      const control = h.module.facade.declare();
      const seen: TextControlEvent[] = [];
      control.on(type, (_run, next) => seen.push(next));
      h.module.hooks.onMountPhase?.('mounted', 1);
      h.sys.phase = 'callback';
      control.sync({ valueMode: 'controlled', value: 'owner' });
      const old = h.connectionBox.current!;
      if (type === 'compositionend') old.onEvent(event('compositionstart', 'owner', true));
      beforeRun = () => {
        h.module.hooks.onMountPhase?.('detached', 1);
        h.module.hooks.onMountPhase?.('mounted', 2);
      };
      old.onEvent(event(type, 'obsolete', type !== 'compositionend'));
      await Promise.resolve();
      expect(seen).toEqual([]);
      expect(withoutSelection(control.snapshot())).toEqual({ value: 'owner', composing: false });
      expect(h.getPatchValue()).toBe('owner');
      h.module.hooks.onMountPhase?.('detached', 2);
    }
  );
});

it('releases an interrupted event prelude so later owner values still project', () => {
  let interrupt = false;
  const h = createHarness(true, 'multiline', () => {
    if (interrupt) throw new Error('prelude interrupted');
  });
  const control = h.module.facade.declare();
  h.module.hooks.onMountPhase?.('mounted', 1);
  h.sys.phase = 'callback';
  control.sync({ valueMode: 'controlled', value: 'owner' });
  interrupt = true;
  h.setPatchValue('proposal');
  expect(() => h.connectionBox.current!.onEvent(event('input', 'proposal'))).toThrow(
    'prelude interrupted'
  );
  control.sync({ value: 'recovered' });
  expect(h.getPatchValue()).toBe('recovered');
  h.module.hooks.onMountPhase?.('detached', 1);
});

it.each(['input', 'compositionend'] as const)(
  'reconciles queued owner props before deferred %s restoration',
  async (type) => {
    let queuedOwner: string | undefined;
    let control: ReturnType<ReturnType<typeof createTextControlModule>['facade']['declare']>;
    const h = createHarness(true, 'multiline', () => {
      if (queuedOwner !== undefined) {
        const value = queuedOwner;
        queuedOwner = undefined;
        control.sync({ value });
      }
    });
    control = h.module.facade.declare();
    control.on(type, (_run, next) => {
      // Runtime owner props are pending for the next callback-scope entry,
      // matching the real React18 trace. Do not fabricate a host write here.
      queueMicrotask(() => {
        queuedOwner = next.value;
      });
    });
    h.module.hooks.onMountPhase?.('mounted', 1);
    h.sys.phase = 'callback';
    control.sync({ valueMode: 'controlled', value: '' });
    const connection = h.connectionBox.current!;
    if (type === 'compositionend') connection.onEvent(event('compositionstart', '', true));
    h.setPatchValue('accepted edit');
    connection.onEvent(event(type, 'accepted edit'));
    expect(h.getPatchValue()).toBe('accepted edit');
    await Promise.resolve();
    expect(h.getPatchValue()).toBe('accepted edit');
    expect(queuedOwner).toBeUndefined();
    h.module.hooks.onMountPhase?.('detached', 1);
  }
);

it('still restores a rejected proposal when the owner did not accept it', async () => {
  const h = createHarness(true, 'multiline', () => {}),
    control = h.module.facade.declare();
  h.module.hooks.onMountPhase?.('mounted', 1);
  h.sys.phase = 'callback';
  control.sync({ valueMode: 'controlled', value: 'owner' });
  h.setPatchValue('unaccepted proposal');
  h.connectionBox.current!.onEvent(event('input', 'unaccepted proposal'));
  await Promise.resolve();
  expect(h.getPatchValue()).toBe('owner');
});
it('does not enter an old deferred callback after a replacement lease is mounted first', async () => {
  let runs = 0;
  const h = createHarness(true, 'multiline', () => {
      runs++;
    }),
    control = h.module.facade.declare();
  control.on('input', () =>
    queueMicrotask(() => {
      h.module.hooks.onMountPhase?.('detached', 1);
      h.module.hooks.onMountPhase?.('mounted', 2);
      control.sync({ value: 'new owner' });
    })
  );
  h.module.hooks.onMountPhase?.('mounted', 1);
  h.sys.phase = 'callback';
  control.sync({ valueMode: 'controlled', value: 'owner' });
  h.setPatchValue('old proposal');
  h.connectionBox.current!.onEvent(event('input', 'old proposal'));
  await Promise.resolve();
  expect(h.getPatchValue()).toBe('new owner');
  expect(runs).toBe(1);
});
it('does not apply restoration to a lease replaced by callback-scope prework', async () => {
  let replace = false,
    updatesAfterReplace = -1;
  let control: any;
  const h = createHarness(true, 'multiline', () => {
    if (replace) {
      replace = false;
      h.module.hooks.onMountPhase?.('detached', 1);
      h.module.hooks.onMountPhase?.('mounted', 2);
      control.sync({ value: 'new owner' });
      updatesAfterReplace = h.getUpdateCount();
    }
  });
  control = h.module.facade.declare();
  control.on('input', () =>
    queueMicrotask(() => {
      replace = true;
    })
  );
  h.module.hooks.onMountPhase?.('mounted', 1);
  h.sys.phase = 'callback';
  control.sync({ valueMode: 'controlled', value: 'owner' });
  h.setPatchValue('proposal');
  h.connectionBox.current!.onEvent(event('input', 'proposal'));
  await Promise.resolve();
  expect(updatesAfterReplace).toBeGreaterThanOrEqual(0);
  expect(h.getPatchValue()).toBe('new owner');
  expect(h.getUpdateCount()).toBe(updatesAfterReplace);
});
it('a new composition begun before restoration retains its current candidate', async () => {
  const h = createHarness(true, 'multiline', () => {}),
    control = h.module.facade.declare();
  control.on('input', () =>
    queueMicrotask(() => {
      h.connectionBox.current!.onEvent(event('compositionstart', 'new candidate', true));
      h.setPatchValue('new candidate');
    })
  );
  h.module.hooks.onMountPhase?.('mounted', 1);
  h.sys.phase = 'callback';
  control.sync({ valueMode: 'controlled', value: 'owner' });
  h.setPatchValue('proposal');
  h.connectionBox.current!.onEvent(event('input', 'proposal'));
  await Promise.resolve();
  expect(control.snapshot()?.composing).toBe(true);
  expect(h.getPatchValue()).toBe('new candidate');
});

it.each([
  ['single', 'input'],
  ['multiline', 'input'],
  ['single', 'compositionend'],
  ['multiline', 'compositionend'],
] as const)(
  'preserves real Web %s caret while draining queued owner %s acceptance',
  async (lineMode, type) => {
    let control: any,
      pendingOwner: string | null = null;
    const h = createHarness(false, lineMode);
    const target = document.createElement(lineMode === 'single' ? 'input' : 'textarea');
    document.body.append(target);
    h.vault.attach([
      [TEXT_CONTROL_HOST_CAP, createWebTextControlHost(() => target)],
      [
        TEXT_CONTROL_RUN_IN_CALLBACK_CAP,
        (fn: () => void) => {
          if (pendingOwner !== null) {
            const value = pendingOwner;
            pendingOwner = null;
            control.sync({ value });
          }
          fn();
        },
      ],
    ]);
    control = h.module.facade.declare();
    control.on(type, (_run: any, ev: any) =>
      queueMicrotask(() => {
        pendingOwner = ev.value;
      })
    );
    h.module.hooks.onMountPhase?.('mounted', 1);
    h.sys.phase = 'callback';
    control.sync({ valueMode: 'controlled', value: '' });
    target.focus();
    try {
      if (type === 'compositionend') target.dispatchEvent(new CompositionEvent('compositionstart'));
      target.value = 'accepted native text';
      target.setSelectionRange(20, 20);
      target.dispatchEvent(
        type === 'input'
          ? new InputEvent('input', { data: 'accepted native text', inputType: 'insertText' })
          : new CompositionEvent('compositionend', { data: 'accepted native text' })
      );
      expect(target.selectionStart).toBe(20);
      await Promise.resolve();
      expect(target.value).toBe('accepted native text');
      expect(target.selectionStart).toBe(20);
      expect(target.selectionEnd).toBe(20);
    } finally {
      h.module.hooks.dispose?.();
      target.remove();
    }
  }
);

describe.each(['single', 'multiline'] as const)(
  'interrupted %s composition boundaries',
  (lineMode) => {
    it.each([
      ['compositionstart', true],
      ['input', true],
      ['input', false],
      ['compositionend', false],
    ] as const)('settles %s (%s) when callback prework throws', (type, composing) => {
      let beforeRun = () => {};
      const h = createHarness(true, lineMode, () => beforeRun());
      const control = h.module.facade.declare();
      h.module.hooks.onMountPhase?.('mounted', 1);
      h.sys.phase = 'callback';
      control.sync({ valueMode: 'controlled', value: 'owner' });
      h.connectionBox.current!.onEvent(event('compositionstart', 'candidate', true));
      beforeRun = () => {
        throw new Error('prework failed');
      };
      expect(() => h.connectionBox.current!.onEvent(event(type, 'candidate', composing))).toThrow(
        'prework failed'
      );
      expect(control.snapshot()?.composing).toBe(composing);
      control.sync({ value: 'recovered' });
      expect(h.getLatestPatch().value).toBe(composing ? undefined : 'recovered');
      h.module.hooks.onMountPhase?.('detached', 1);
    });

    it.each([false, true])(
      'does not clear a newer composition when interrupted (new lease=%s)',
      (replaceLease) => {
        let beforeRun = () => {};
        const h = createHarness(true, lineMode, () => beforeRun());
        const control = h.module.facade.declare();
        h.module.hooks.onMountPhase?.('mounted', 1);
        h.sys.phase = 'callback';
        control.sync({ valueMode: 'controlled', value: 'owner' });
        const old = h.connectionBox.current!;
        old.onEvent(event('compositionstart', 'old candidate', true));
        beforeRun = () => {
          beforeRun = () => {};
          if (replaceLease) {
            h.module.hooks.onMountPhase?.('detached', 1);
            h.module.hooks.onMountPhase?.('mounted', 2);
          }
          h.connectionBox.current!.onEvent(event('compositionstart', 'new candidate', true));
          throw new Error('old prework failed');
        };
        expect(() => old.onEvent(event('compositionend', 'old candidate'))).toThrow(
          'old prework failed'
        );
        expect(control.snapshot()?.composing).toBe(true);
        control.sync({ value: 'new owner' });
        expect(h.getLatestPatch().value).toBeUndefined();
        h.connectionBox.current!.onEvent(event('compositionend', 'new candidate'));
        control.sync({ value: 'recovered' });
        expect(h.getLatestPatch().value).toBe('recovered');
        h.module.hooks.onMountPhase?.('detached', replaceLease ? 2 : 1);
      }
    );
  }
);

it.each([false, true])(
  'settles composition after a throwing listener without overwriting nested input (%s)',
  (nested) => {
    const h = createHarness();
    const control = h.module.facade.declare();
    control.on('compositionend', () => {
      if (nested)
        h.connectionBox.current!.onEvent(event('compositionstart', 'new candidate', true));
      throw new Error('listener failed');
    });
    h.module.hooks.onMountPhase?.('mounted', 1);
    h.sys.phase = 'callback';
    control.sync({ valueMode: 'controlled', value: 'owner' });
    h.connectionBox.current!.onEvent(event('compositionstart', 'old candidate', true));
    expect(() =>
      h.connectionBox.current!.onEvent(event('compositionend', 'old candidate'))
    ).toThrow('listener failed');
    expect(control.snapshot()?.composing).toBe(nested);
    control.sync({ value: 'recovered' });
    expect(h.getLatestPatch().value).toBe(nested ? undefined : 'recovered');
    h.module.hooks.onMountPhase?.('detached', 1);
  }
);

it('does not deliver a superseded event after newer composition enters during prework', () => {
  let beforeRun = () => {};
  const h = createHarness(true, 'multiline', () => beforeRun());
  const control = h.module.facade.declare();
  const seen: string[] = [];
  control.on('compositionend', () => seen.push('obsolete end'));
  h.module.hooks.onMountPhase?.('mounted', 1);
  h.sys.phase = 'callback';
  control.sync({ valueMode: 'controlled', value: 'owner' });
  h.connectionBox.current!.onEvent(event('compositionstart', 'old candidate', true));
  beforeRun = () => {
    beforeRun = () => {};
    h.connectionBox.current!.onEvent(event('compositionstart', 'new candidate', true));
  };
  h.connectionBox.current!.onEvent(event('compositionend', 'old candidate'));
  expect(seen).toEqual([]);
  expect(control.snapshot()?.composing).toBe(true);
  h.module.hooks.onMountPhase?.('detached', 1);
});

it.each(['has', 'get'] as const)(
  'settles native completion even when callback capability %s throws',
  (stage) => {
    const h = createHarness(true, 'multiline', () => {}),
      control = h.module.facade.declare();
    h.module.hooks.onMountPhase?.('mounted', 1);
    h.sys.phase = 'callback';
    control.sync({ valueMode: 'controlled', value: 'owner' });
    h.connectionBox.current!.onEvent(event('compositionstart', 'draft', true));
    const original = h.vault[stage].bind(h.vault);
    const spy = vi.spyOn(h.vault, stage).mockImplementation(((cap: any) => {
      if (cap === TEXT_CONTROL_RUN_IN_CALLBACK_CAP) throw new Error('cap lookup failed');
      return original(cap);
    }) as any);
    try {
      expect(() => h.connectionBox.current!.onEvent(event('compositionend', 'draft'))).toThrow(
        'cap lookup failed'
      );
      expect(control.snapshot()?.composing).toBe(false);
      control.sync({ value: 'recovered' });
      expect(h.getPatchValue()).toBe('recovered');
    } finally {
      spy.mockRestore();
      h.module.hooks.dispose?.();
    }
  }
);
it.each([false, true])(
  'does not settle an old failing lookup over new composition (new lease=%s)',
  (replace) => {
    const h = createHarness(true, 'multiline', () => {}),
      control = h.module.facade.declare();
    h.module.hooks.onMountPhase?.('mounted', 1);
    h.sys.phase = 'callback';
    control.sync({ valueMode: 'controlled', value: 'owner' });
    h.connectionBox.current!.onEvent(event('compositionstart', 'old', true));
    const original = h.vault.get.bind(h.vault);
    let armed = true;
    const spy = vi.spyOn(h.vault, 'get').mockImplementation(((cap: any) => {
      if (cap === TEXT_CONTROL_RUN_IN_CALLBACK_CAP && armed) {
        armed = false;
        if (replace) {
          h.module.hooks.onMountPhase?.('detached', 1);
          h.module.hooks.onMountPhase?.('mounted', 2);
        }
        h.connectionBox.current!.onEvent(event('compositionstart', 'new', true));
        throw new Error('lookup interrupted');
      }
      return original(cap);
    }) as any);
    try {
      expect(() => h.connectionBox.current!.onEvent(event('compositionend', 'old'))).toThrow(
        'lookup interrupted'
      );
      expect(control.snapshot()?.composing).toBe(true);
      control.sync({ value: 'owner-new' });
      expect(h.getLatestPatch().value).toBeUndefined();
    } finally {
      spy.mockRestore();
      h.module.hooks.dispose?.();
    }
  }
);
it.each([false, true])(
  'preserves latest facts and releases prelude when deferred restoration throws (nested=%s)',
  (nested) => {
    let fail = false;
    const h = createHarness(true, 'multiline', () => {
        if (fail) {
          fail = false;
          if (nested)
            h.connectionBox.current!.onEvent(event('compositionstart', 'new draft', true));
          throw new Error('restore prework');
        }
      }),
      control = h.module.facade.declare();
    h.module.hooks.onMountPhase?.('mounted', 1);
    h.sys.phase = 'callback';
    control.sync({ valueMode: 'controlled', value: 'owner' });
    h.connectionBox.current!.onEvent(event('compositionstart', 'old draft', true));
    const tasks: Array<() => void> = [];
    const queue = vi.spyOn(globalThis, 'queueMicrotask').mockImplementation((fn) => tasks.push(fn));
    try {
      h.connectionBox.current!.onEvent(event('compositionend', 'old draft'));
      expect(tasks).toHaveLength(1);
      fail = true;
      expect(() => tasks.shift()!()).toThrow('restore prework');
      expect(control.snapshot()?.composing).toBe(nested);
      control.sync({ value: 'recovered' });
      expect(h.getLatestPatch().value).toBe(nested ? undefined : 'recovered');
    } finally {
      queue.mockRestore();
      h.module.hooks.dispose?.();
    }
  }
);

// C-TEXT-CONTROL-0001-B/D/E/G: a queued owner patch must reach the
// current editor even when a change event, rather than input, drains it.
describe.each(['single', 'multiline'] as const)('Web %s change callback preludes', (lineMode) => {
  it.each([false, true])(
    'projects a queued owner value while retaining native change facts (same value=%s)',
    async (sameValue) => {
      let pendingOwner: string | undefined;
      const h = createHarness(false, lineMode);
      const target = document.createElement(lineMode === 'single' ? 'input' : 'textarea');
      document.body.append(target);
      const control = h.module.facade.declare();
      h.vault.attach([
        [TEXT_CONTROL_HOST_CAP, createWebTextControlHost(() => target)],
        [
          TEXT_CONTROL_RUN_IN_CALLBACK_CAP,
          (callback: () => void) => {
            if (pendingOwner !== undefined) {
              const value = pendingOwner;
              pendingOwner = undefined;
              control.sync({ value });
            }
            callback();
          },
        ],
      ]);
      const seen: TextControlEvent[] = [];
      control.on('change', (_run, next) => seen.push(next));
      h.module.hooks.onMountPhase?.('mounted', 1);
      h.sys.phase = 'callback';
      control.sync({ valueMode: 'controlled', value: 'original' });
      target.focus();
      try {
        target.value = 'native candidate';
        target.setSelectionRange(3, 3);
        pendingOwner = sameValue ? target.value : 'queued owner';
        target.dispatchEvent(new Event('change'));
        await Promise.resolve();
        expect(withoutSelection(control.snapshot())).toEqual({
          value: sameValue ? 'native candidate' : 'queued owner',
          composing: false,
        });
        expect(target.value).toBe(sameValue ? 'native candidate' : 'queued owner');
        expect(seen.map(withoutSelection)).toEqual([event('change', 'native candidate')]);
        if (sameValue) {
          expect(target.selectionStart).toBe(3);
          expect(target.selectionEnd).toBe(3);
        }
      } finally {
        h.module.hooks.dispose?.();
        target.remove();
      }
    }
  );

  it('keeps change-triggered owner patches out of an active composition', async () => {
    let beforeRun = () => {};
    const h = createHarness(true, lineMode, () => beforeRun());
    const control = h.module.facade.declare();
    h.module.hooks.onMountPhase?.('mounted', 1);
    h.sys.phase = 'callback';
    control.sync({ valueMode: 'controlled', value: 'owner' });
    const connection = h.connectionBox.current!;
    connection.onEvent(event('compositionstart', 'candidate', true));
    h.setPatchValue('candidate');
    beforeRun = () => {
      beforeRun = () => {};
      control.sync({ value: 'queued owner' });
    };
    connection.onEvent(event('change', 'candidate', true));
    await Promise.resolve();
    expect(h.getPatchValue()).toBe('candidate');
    expect(withoutSelection(control.snapshot())).toEqual({
      value: 'queued owner',
      composing: true,
    });
    connection.onEvent(event('compositionend', 'candidate'));
    await Promise.resolve();
    expect(h.getPatchValue()).toBe('queued owner');
    h.module.hooks.dispose?.();
  });
});

it.each(['compositionstart', 'input'] as const)(
  'does not carry an interrupted old %s into a replacement lease',
  (type) => {
    let beforeRun = () => {};
    const h = createHarness(true, 'multiline', () => beforeRun());
    const control = h.module.facade.declare();
    h.module.hooks.onMountPhase?.('mounted', 1);
    h.sys.phase = 'callback';
    control.sync({ valueMode: 'controlled', value: 'owner' });
    const old = h.connectionBox.current!;
    const failure = new Error('old lease prelude failure');
    beforeRun = () => {
      beforeRun = () => {};
      h.module.hooks.onMountPhase?.('detached', 1);
      h.module.hooks.onMountPhase?.('mounted', 2);
      throw failure;
    };
    try {
      expect(() => old.onEvent(event(type, 'old candidate', true))).toThrow(failure);
      expect(control.snapshot()?.composing).toBe(false);
      control.sync({ value: 'new owner' });
      expect(h.getLatestPatch().value).toBe('new owner');
    } finally {
      h.module.hooks.dispose?.();
    }
  }
);

// C-TEXT-CONTROL-0001-D/E/F/G/CHANGE-COMMIT: change-only edits are proposals,
// including when the owner responds only at the deferred callback boundary.
describe.each(['single', 'multiline'] as const)('Web %s change-only restoration', (lineMode) => {
  it.each(['reject', 'accept', 'replace'] as const)(
    'reconciles a change-only candidate after owner response=%s',
    async (response) => {
      let pendingOwner: string | undefined;
      const h = createHarness(false, lineMode);
      const target = document.createElement(lineMode === 'single' ? 'input' : 'textarea');
      document.body.append(target);
      const control = h.module.facade.declare();
      h.vault.attach([
        [TEXT_CONTROL_HOST_CAP, createWebTextControlHost(() => target)],
        [
          TEXT_CONTROL_RUN_IN_CALLBACK_CAP,
          (callback: () => void) => {
            if (pendingOwner !== undefined) {
              const value = pendingOwner;
              pendingOwner = undefined;
              control.sync({ value });
            }
            callback();
          },
        ],
      ]);
      const seen: TextControlEvent[] = [];
      control.on('change', (_run, next) => {
        seen.push(next);
        if (response !== 'reject')
          pendingOwner = response === 'accept' ? next.value : 'replacement';
      });
      h.module.hooks.onMountPhase?.('mounted', 1);
      h.sys.phase = 'callback';
      control.sync({ valueMode: 'controlled', value: 'owner' });
      target.focus();
      try {
        target.value = 'native candidate';
        target.setSelectionRange(3, 3);
        target.dispatchEvent(new Event('change'));
        expect(seen.map(withoutSelection)).toEqual([event('change', 'native candidate')]);
        expect(target.value).toBe('native candidate');
        await Promise.resolve();
        const expected =
          response === 'reject'
            ? 'owner'
            : response === 'accept'
              ? 'native candidate'
              : 'replacement';
        expect(target.value).toBe(expected);
        expect(withoutSelection(control.snapshot())).toEqual({ value: expected, composing: false });
        if (response === 'accept') {
          expect(target.selectionStart).toBe(3);
          expect(target.selectionEnd).toBe(3);
        }
      } finally {
        h.module.hooks.dispose?.();
        target.remove();
      }
    }
  );

  it('preserves a change-only candidate and caret during active composition', async () => {
    const h = createHarness(false, lineMode);
    const target = document.createElement(lineMode === 'single' ? 'input' : 'textarea');
    document.body.append(target);
    const control = h.module.facade.declare();
    h.vault.attach([[TEXT_CONTROL_HOST_CAP, createWebTextControlHost(() => target)]]);
    const seen: TextControlEvent[] = [];
    control.on('change', (_run, next) => seen.push(next));
    h.module.hooks.onMountPhase?.('mounted', 1);
    h.sys.phase = 'callback';
    control.sync({ valueMode: 'controlled', value: 'owner' });
    target.focus();
    try {
      target.dispatchEvent(new CompositionEvent('compositionstart'));
      target.value = 'composing candidate';
      target.setSelectionRange(3, 3);
      target.dispatchEvent(new Event('change'));
      control.sync({ value: 'next owner' });
      await Promise.resolve();
      expect(seen.map(withoutSelection)).toEqual([event('change', 'composing candidate', true)]);
      expect(target.value).toBe('composing candidate');
      expect(target.selectionStart).toBe(3);
      expect(target.selectionEnd).toBe(3);
      expect(withoutSelection(control.snapshot())).toEqual({
        value: 'next owner',
        composing: true,
      });
      target.dispatchEvent(new CompositionEvent('compositionend'));
      await Promise.resolve();
      expect(target.value).toBe('next owner');
      expect(control.snapshot()?.composing).toBe(false);
    } finally {
      h.module.hooks.dispose?.();
      target.remove();
    }
  });

  it.each(['detach', 'dispose', 'new-composition'] as const)(
    'does not let pending change restoration overwrite %s',
    async (transition) => {
      const h = createHarness(false, lineMode);
      let target = document.createElement(lineMode === 'single' ? 'input' : 'textarea');
      const oldTarget = target;
      const control = h.module.facade.declare();
      h.vault.attach([[TEXT_CONTROL_HOST_CAP, createWebTextControlHost(() => target)]]);
      h.module.hooks.onMountPhase?.('mounted', 1);
      h.sys.phase = 'callback';
      control.sync({ valueMode: 'controlled', value: 'owner' });
      try {
        target.value = 'old candidate';
        target.dispatchEvent(new Event('change'));
        if (transition === 'dispose') h.module.hooks.dispose?.();
        else {
          if (transition === 'detach') {
            h.module.hooks.onMountPhase?.('detached', 1);
            target = document.createElement(lineMode === 'single' ? 'input' : 'textarea');
            h.module.hooks.onMountPhase?.('mounted', 2);
          }
          target.dispatchEvent(new CompositionEvent('compositionstart'));
          target.value = 'new composition';
        }
        await Promise.resolve();
        expect(target.value).toBe(transition === 'dispose' ? 'old candidate' : 'new composition');
        if (transition === 'detach') expect(oldTarget.value).toBe('old candidate');
        if (transition !== 'dispose') {
          expect(control.snapshot()?.composing).toBe(true);
          target.dispatchEvent(new CompositionEvent('compositionend'));
          await Promise.resolve();
          expect(target.value).toBe('owner');
        }
      } finally {
        h.module.hooks.dispose?.();
      }
    }
  );
});

describe.each(['single', 'multiline'] as const)('Web %s controlled owner changes', (lineMode) => {
  it.each(['input', 'change', 'compositionend'] as const)(
    'retires candidate protection when the %s callback changes owner and changes back',
    (type) => {
      const h = createHarness(false, lineMode);
      const target = document.createElement(lineMode === 'single' ? 'input' : 'textarea');
      const control = h.module.facade.declare();
      h.vault.attach([[TEXT_CONTROL_HOST_CAP, createWebTextControlHost(() => target)]]);
      const observed: string[] = [];
      control.on(type, () => {
        control.sync({ value: 'accepted owner' });
        observed.push(target.value);
        control.sync({ value: 'original owner' });
        observed.push(target.value);
      });
      h.module.hooks.onMountPhase?.('mounted', 1);
      h.sys.phase = 'callback';
      control.sync({ valueMode: 'controlled', value: 'original owner' });
      try {
        target.value = 'candidate';
        target.dispatchEvent(new Event(type));
        expect(observed).toEqual(['accepted owner', 'original owner']);
        expect(control.snapshot()?.value).toBe('original owner');
      } finally {
        h.module.hooks.dispose?.();
      }
    }
  );
});

describe('TextControl bounded reset', () => {
  it('resets uncontrolled canonical value, retires composition and rejects old events', () => {
    const h = createHarness(),
      control = h.module.facade.declare();
    h.module.hooks.onMountPhase?.('mounted', 1);
    h.sys.phase = 'callback';
    control.sync({ valueMode: 'uncontrolled', defaultValue: 'initial' });
    const old = h.connectionBox.current!;
    old.onEvent(event('compositionstart', 'dirty', true));
    expect(control.resetValue('restored\r\nvalue')).toBe(true);
    expect(withoutSelection(control.snapshot())).toEqual({
      value: 'restored\nvalue',
      composing: false,
    });
    old.onEvent(event('input', 'stale'));
    expect(control.snapshot()?.value).toBe('restored\nvalue');
    expect(h.getPatchValue()).toBe('restored\nvalue');
    h.module.hooks.onMountPhase?.('detached', 1);
    expect(control.resetValue('detached')).toBe(false);
  });
  it('does not change controlled owner state and does not deliver the old event after reentrant reset', () => {
    const h = createHarness(),
      control = h.module.facade.declare();
    let called = 0;
    control.on('input', () => {
      control.resetValue('reset');
    });
    control.on('input', () => called++);
    h.module.hooks.onMountPhase?.('mounted', 1);
    h.sys.phase = 'callback';
    control.sync({ defaultValue: 'initial' });
    h.connectionBox.current!.onEvent(event('input', 'candidate'));
    expect(called).toBe(0);
    expect(control.snapshot()?.value).toBe('reset');
    const other = createHarness(),
      controlled = other.module.facade.declare();
    other.module.hooks.onMountPhase?.('mounted', 1);
    other.sys.phase = 'callback';
    controlled.sync({ valueMode: 'controlled', value: 'owner' });
    const old = other.connectionBox.current!;
    old.onEvent(event('compositionstart', 'candidate', true));
    expect(controlled.resetValue('attempt')).toBe(false);
    expect(withoutSelection(controlled.snapshot())).toEqual({ value: 'owner', composing: false });
    old.onEvent(event('compositionend', 'stale'));
    expect(controlled.snapshot()?.value).toBe('owner');
  });
});
