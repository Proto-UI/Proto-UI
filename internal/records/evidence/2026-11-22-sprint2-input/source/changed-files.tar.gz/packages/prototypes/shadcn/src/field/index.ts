export { default as fieldRoot, default as shadcnFieldRoot } from './root.proto';
export { default as fieldLabel, default as shadcnFieldLabel } from './label.proto';
export { default as fieldControl, default as shadcnFieldControl } from './control.proto';
export {
  default as fieldDescription,
  default as shadcnFieldDescription,
} from './description.proto';
export { default as fieldError, default as shadcnFieldError } from './error.proto';
export { default as fieldValidity, default as shadcnFieldValidity } from './validity.proto';
export type {
  FieldRootProps,
  FieldRootExposes,
  FieldLabelProps,
  FieldLabelExposes,
  FieldControlProps,
  FieldControlExposes,
  FieldDescriptionProps,
  FieldDescriptionExposes,
  FieldErrorProps,
  FieldErrorExposes,
  FieldValidityProps,
  FieldValidityExposes,
} from '@proto.ui/prototypes-base/field';
export type {
  ShadcnFieldRootProps,
  ShadcnFieldControlProps,
  ShadcnFieldLabelProps,
  ShadcnFieldDescriptionProps,
  ShadcnFieldErrorProps,
  ShadcnFieldValidityProps,
} from './types';

export { default as fieldTextarea, default as shadcnFieldTextarea } from './textarea.proto';
export type { ShadcnFieldTextareaProps, ShadcnFieldTextareaExposes } from './textarea.proto';

export {
  default as fieldSelectTrigger,
  default as shadcnFieldSelectTrigger,
} from './select-trigger.proto';
export type {
  ShadcnFieldSelectTriggerProps,
  ShadcnFieldSelectTriggerExposes,
} from './select-trigger.proto';

export { default as fieldSwitch, default as shadcnFieldSwitch } from './switch.proto';
export type { ShadcnFieldSwitchProps, ShadcnFieldSwitchExposes } from './switch.proto';

export { default as fieldCheckbox, default as shadcnFieldCheckbox } from './checkbox.proto';
export type { ShadcnFieldCheckboxProps, ShadcnFieldCheckboxExposes } from './checkbox.proto';
export { default as fieldRadioGroup, default as shadcnFieldRadioGroup } from './radio-group.proto';
export type { ShadcnFieldRadioGroupProps, ShadcnFieldRadioGroupExposes } from './radio-group.proto';
