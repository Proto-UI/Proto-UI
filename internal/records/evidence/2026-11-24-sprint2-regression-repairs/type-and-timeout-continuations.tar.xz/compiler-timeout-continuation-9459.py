#!/usr/bin/env python3
from pathlib import Path
import subprocess,os,json,datetime,hashlib
ROOT=Path('/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202')
repo=ROOT/'Proto-UI-publisher'
out=ROOT/'evidence/compiler-timeout-continuation-9459'
out.mkdir(parents=True,exist_ok=True)
node='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin/node'
files=['packages/compiler/test/transition-timing-matrix.test.ts','packages/compiler/test/native-presence-presentation.test.ts','packages/compiler/test/native-support-migration.test.ts']
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
initial=git('rev-parse','HEAD')
assert initial=='9459bb786b2a0e8de1a48f0940ac14eeba2f2733'
assert git('status','--porcelain')==''
rows=[]
for i,file in enumerate(files):
 path=out/('file-'+str(i));path.mkdir(exist_ok=False)
 argv=[node,str(repo/'node_modules/vitest/vitest.mjs'),'run',file,'--maxWorkers=1','--minWorkers=1','--no-file-parallelism','--reporter=default','--reporter=json','--outputFile='+str(path/'report.json')]
 row={'file':file,'sourceRevision':initial,'sourceSHA256':hashlib.sha256((repo/file).read_bytes()).hexdigest(),'started':now(),'argv':argv,'timeoutSeconds':1800,'headBefore':git('rev-parse','HEAD'),'dirtyBefore':git('status','--porcelain')}
 assert row['headBefore']==initial and row['dirtyBefore']==''
 (path/'start.json').write_text(json.dumps(row,indent=2))
 with (path/'stdout.log').open('wb') as log:
  try:
   run=subprocess.run(argv,cwd=repo,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=1800)
   row['exitCode']=run.returncode
  except subprocess.TimeoutExpired:
   row['exitCode']=None;row['timedOut']=True
 row.update(ended=now(),headAfter=git('rev-parse','HEAD'),dirtyAfter=git('status','--porcelain'))
 if (path/'report.json').exists():
  report=json.loads((path/'report.json').read_text())
  row['counts']={k:report.get(k) for k in ['numPassedTests','numFailedTests','numPendingTests','numTotalTests']}
  row['reportSHA256']=hashlib.sha256((path/'report.json').read_bytes()).hexdigest()
 (path/'receipt.json').write_text(json.dumps(row,indent=2))
 rows.append(row);(out/'progress.json').write_text(json.dumps(rows,indent=2))
 print(json.dumps({'file':file,'exitCode':row.get('exitCode'),'counts':row.get('counts'),'ended':row['ended']}),flush=True)
 assert row['headAfter']==initial and row['dirtyAfter']==''
status=0 if all(x.get('exitCode')==0 for x in rows) else 1
(out/'summary.json').write_text(json.dumps({'sourceRevision':initial,'files':rows,'exitCode':status},indent=2))
raise SystemExit(status)
