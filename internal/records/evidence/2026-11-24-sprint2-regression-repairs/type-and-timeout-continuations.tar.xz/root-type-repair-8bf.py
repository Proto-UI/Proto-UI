from pathlib import Path
import subprocess,hashlib,json,os,datetime
R=Path('/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202');repo=R/'Proto-UI-publisher';out=R/'evidence/root-type-repair-8bf';out.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
assert git('rev-parse','HEAD')=='8bf1bef48c7bae707c842ece3d3db90084c4d60b' and git('status','--porcelain')==''
patch=R/'transfer/s2-type-followup-8bf.patch';subprocess.run(['git','apply','--check',str(patch)],cwd=repo,check=True);subprocess.run(['git','apply',str(patch)],cwd=repo,check=True)
files=['packages/compiler/src/callable-effects.ts','packages/compiler/test/json-array-provenance.test.ts']
before={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in files};rows=[]
for name,argv in [('normal-website-generation',['corepack','pnpm@10.32.1','--filter','apps-www','generate:proto-ui-style']),('workspace-types',[os.environ['S2_NODE'],'node_modules/typescript/bin/tsc','-p','tsconfig.workspace.json','--noEmit'])]:
 row={'name':name,'argv':argv,'started':now()}
 with (out/(name+'.log')).open('wb') as log:
  p=subprocess.run(argv,cwd=repo,env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT)
 row.update(exitCode=p.returncode,ended=now());rows.append(row);(out/'progress.json').write_text(json.dumps(rows,indent=2))
 print(json.dumps(row),flush=True)
 if p.returncode!=0:break
after={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in files}
report={'base':'8bf1bef48c7bae707c842ece3d3db90084c4d60b','patchSha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'before':before,'after':after,'runs':rows,'sourceAfter':git('status','--porcelain'),'exitCode':0 if len(rows)==2 and all(x['exitCode']==0 for x in rows) and before==after else 1}
(out/'receipt.json').write_text(json.dumps(report,indent=2));assert before==after;print(json.dumps(report));raise SystemExit(report['exitCode'])
