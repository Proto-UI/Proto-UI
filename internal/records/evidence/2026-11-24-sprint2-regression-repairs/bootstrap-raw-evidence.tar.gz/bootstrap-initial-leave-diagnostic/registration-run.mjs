/** External exact-source browser probe. Does not write to the candidate checkout. */
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { access, mkdir, readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(process.env.PUI_SOURCE_ROOT ?? process.cwd());
const expected = process.env.PUI_EXPECTED_COMMIT ?? '9cd4108a5aa4c00af4a2e160577ab761885313c9';
const output = path.resolve(process.env.PUI_EVIDENCE_DIR ?? path.join(here, 'evidence'));
const git = (...args) => execFileSync('git', args, { cwd: repo, encoding: 'utf8' }).trim();
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const source = () => ({ head: git('rev-parse', 'HEAD'), status: git('status', '--porcelain') });
const require = createRequire(path.join(repo, 'package.json'));
const { build } = require('esbuild');
await mkdir(output, { recursive: false });
const report = {
  kind: 'native-first-leave-registration-pair', startedAt: new Date().toISOString(),
  sourceBefore: source(), sourceExpected: expected,
  driverSha256: hash(await readFile(fileURLToPath(import.meta.url))),
  fixtureSha256: hash(await readFile(path.join(here, 'registration-fixture.ts'))),
  cases: [], pageErrors: [], status: 'running',
  scope: 'Read-only native observation of the original direct-sink registration fixture, paired with an actual applied-zero reversal. Same owner facts and 500ms duration. Native layout, clock and RAF; no fake geometry or time. No claim for other hosts or complete prototype semantics.',
};
const write = () => writeFile(path.join(output, 'report.json'), JSON.stringify(report, null, 2)+'\n');
let browser;
try {
  assert.equal(report.sourceBefore.head, expected, 'Freeze the exact reviewed source.');
  assert.equal(report.sourceBefore.status, '', 'Candidate must be clean.');
  const result = await build({
    absWorkingDir: repo, entryPoints: [path.join(here, 'registration-fixture.ts')],
    bundle: true, write: false, outfile: path.join(output, 'consumer.js'),
    format: 'iife', globalName: 'NativeRepeatedAdoption', platform: 'browser', target: 'es2022',
    tsconfig: path.join(repo, 'tsconfig.json'), metafile: true,
    define: { 'process.env.NODE_ENV': '"production"' },
    plugins: [{ name: 'candidate-presence', setup(build) {
      build.onResolve({filter:/^candidate-presence-source$/}, () => ({path:path.join(repo,'packages/adapters/base/src/motion/web-presence-presentation.ts')}));
    }}],
  });
  const script = result.outputFiles.find((file) => file.path.endsWith('.js')).text;
  report.bundleSha256 = hash(script);
  report.inputs = await Promise.all(Object.keys(result.metafile.inputs).sort().map(async (input) => {
    const resolved = path.resolve(repo, input);
    return { path: path.relative(repo,resolved), sha256: hash(await readFile(resolved)), dependency: resolved.includes(`${path.sep}node_modules${path.sep}`) };
  }));
  await writeFile(path.join(output, 'consumer.js'), script);
  await writeFile(path.join(output, 'bundle-metafile.json'), JSON.stringify(result.metafile,null,2)+'\n');
  const playwright = process.env.PUI_PLAYWRIGHT_MODULE
    ? await import(pathToFileURL(process.env.PUI_PLAYWRIGHT_MODULE).href)
    : createRequire(path.join(repo,'apps/www/package.json'))('playwright-core');
  let executablePath;
  for (const candidate of [process.env.PUI_CHROME_EXECUTABLE,process.env.CHROME_PATH,playwright.chromium.executablePath(),'/usr/bin/chromium'].filter(Boolean)) {
    try { await access(candidate); executablePath=candidate; break; } catch {}
  }
  assert(executablePath, 'An existing Chromium executable is required.');
  report.launchOptions = { executablePath, headless: true, chromiumSandbox: true, args: ['--disable-dev-shm-usage'] };
  browser = await playwright.chromium.launch(report.launchOptions);
  report.environment = { browser:browser.version(), node:process.version, viewport:{width:1000,height:800}, reducedMotion:'no-preference' };
  for (const mode of ['registration-before-first-application','reversal-after-zero-application']) {
    const context = await browser.newContext({viewport:report.environment.viewport,reducedMotion:'no-preference'});
    const page = await context.newPage();
    const errors=[];
    page.on('pageerror',(error)=>errors.push(String(error.stack??error)));
    try {
      await page.setContent('<!doctype html><html><head><meta charset="utf-8"><title>Native first-leave registration comparison</title><style>html{font-size:16px}body{margin:16px;background:white;color:black}</style></head><body><h1>Native first-leave registration comparison</h1></body></html>');
      await page.addScriptTag({content:script});
      const observed = await page.evaluate(async (mode) => {
        return await Promise.race([
          NativeRepeatedAdoption.run(mode),
          new Promise((_,reject)=>setTimeout(()=>reject(new Error('Probe environmental wall timeout (5s); original per-owner guard remains 1000ms.')),5000)),
        ]);
      },mode);
      observed.pageErrors=errors;
      if(errors.length) observed.status='failed';
      report.cases.push(observed);
    } catch(error) {
      report.cases.push({mode,status:'failed',error:String(error.stack??error),pageErrors:errors});
    } finally {
      await context.close();
    }
    await write();
  }
  report.sourceAfter=source();
  assert.deepEqual(report.sourceAfter,report.sourceBefore,'Candidate changed during probe.');
  assert.equal(report.cases.length,2);
  assert(report.cases.every((row)=>row.status==='passed'),JSON.stringify(report.cases.map((row)=>({mode:row.mode,status:row.status,error:row.error}))));
  report.status='passed';
} catch(error) {
  report.status='failed-or-blocked';
  report.error=String(error.stack??error);
} finally {
  try { await browser?.close(); } catch(error) { report.status='failed-or-blocked';report.cleanupError=String(error); }
  report.sourceAfter=source();
  report.finishedAt=new Date().toISOString();
  await write();
  console.log(JSON.stringify({status:report.status,cases:report.cases.map((row)=>({mode:row.mode,status:row.status,assertions:row.assertions?.length,error:row.error})),error:report.error,report:path.join(output,'report.json')}));
}
if(report.status!=='passed') process.exitCode=1;
