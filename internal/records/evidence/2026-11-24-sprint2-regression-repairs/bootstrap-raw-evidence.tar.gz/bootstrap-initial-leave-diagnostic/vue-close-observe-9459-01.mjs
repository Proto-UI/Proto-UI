/** One original Vue cold-open/retained-close journey, with native observations only. */
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const output = process.env.PUI_EVIDENCE_DIR;
const prior = process.env.PUI_PRIOR_EVIDENCE_DIR;
const head = '9459bb786b2a0e8de1a48f0940ac14eeba2f2733';
assert(output && prior);
await mkdir(output, { recursive: true });
const hash = (data) => createHash('sha256').update(data).digest('hex');
const git = (...args) => execFileSync('git', args, { cwd: root, encoding: 'utf8' }).trim();
const previousBytes = await readFile(path.join(prior, 'report.json'));
const previous = JSON.parse(previousBytes);
assert.equal(previous.source.head, head);
assert.equal(previous.source.dirty, false);
assert.equal(git('rev-parse', 'HEAD'), head);
assert.equal(git('status', '--porcelain'), '');
const script = await readFile(path.join(prior, 'consumer.js'));
const css = await readFile(path.join(prior, 'consumer.css'), 'utf8');
assert.equal(hash(script), previous.source.bundleSha256);
assert.equal(hash(css), previous.source.cssSha256);
for (const input of previous.source.inputs)
  assert.equal(hash(await readFile(path.join(root, input.path))), input.sha256, input.path);
const themePath = path.join(root, 'packages/prototypes/bootstrap-2-3-2/src/theme.ts');
const { renderThemeCss } = await import(pathToFileURL(themePath).href);
const { chromium } = createRequire(path.join(root, 'apps/www/package.json'))('playwright-core');
const report = {
  kind: 'bootstrap-vue-close-native-observation',
  at: new Date().toISOString(),
  source: {
    head,
    dirty: false,
    driverSha256: hash(await readFile(new URL(import.meta.url))),
    priorReport: path.join(prior, 'report.json'),
    priorReportSha256: hash(previousBytes),
    bundleSha256: hash(script),
    cssSha256: hash(css),
    verifiedInputCount: previous.source.inputs.length,
    themeSha256: hash(await readFile(themePath)),
  },
  environment: {
    runtime: 'vue', kind: 'collapsible', viewport: { width: 960, height: 720 },
    theme: 'light', locale: 'en', reducedMotion: 'no-preference',
    node: process.version, sandbox: true, cpuCount: os.cpus().length, loadAverage: os.loadavg(),
  },
  boundary: 'One original cold-open-retained-close journey in a fresh page, reusing the exact previous consumer bundle and CSS. Native RAF wrappers forward real callbacks and IDs; MutationObserver reads attributes without forcing layout; LongTask and CDP trace observe actual browser work. This diagnostic cannot replace the accumulated-history forty-case result.',
  originalCriterion: { durationMs: 350, readinessGuardMs: 1000, observationWaitMs: 520, intermediateCount: 3, zeroEdge: '0 < native height < 2' },
  assertions: [], errors: [],
};
const browser = await chromium.launch({ executablePath: process.env.PUI_CHROME_EXECUTABLE, headless: true, chromiumSandbox: true, args: ['--disable-dev-shm-usage'] });
report.environment.browser = browser.version();
const page = await browser.newPage({ viewport: report.environment.viewport, colorScheme: 'light', reducedMotion: 'no-preference' });
page.on('pageerror', (error) => report.errors.push(String(error.stack ?? error)));
page.setDefaultTimeout(5000);
const cdp = await page.context().newCDPSession(page);
let tracing = false;
let traceDone;
const expect = (name, predicate, detail) => {
  report.assertions.push({ name, passed: !!predicate, detail });
};
try {
  await page.setContent('<!doctype html><html data-theme="light"><head><meta charset="utf-8"></head><body><main><h1>Bootstrap 2.3.2 · intrinsic Collapse</h1><p id="scope"></p><div id="fixture"></div></main></body></html>');
  await page.addStyleTag({ content: `${renderThemeCss()}\n${css}\n*,::before,::after {box-sizing:border-box} body{margin:0;background:#f6f6f6;color:#333;font-family:"Helvetica Neue",Arial,sans-serif} main{width:640px;margin:40px auto;padding:24px;background:#fff} h1{font-size:22px;line-height:30px;margin:0 0 12px} #scope{font-size:14px;margin-bottom:18px} .collapse-copy>div{min-height:20px}` });
  await page.evaluate(() => {
    const nativeRAF = window.requestAnimationFrame;
    const nativeCancelRAF = window.cancelAnimationFrame;
    const data = { installedAt: performance.now(), raf: [], cancelled: [], callbacks: [], longTasks: [], mutations: [], marks: [], dropped: {} };
    const maximum = 3000;
    const push = (name, value) => {
      if (data[name].length < maximum) data[name].push(value);
      else data.dropped[name] = (data.dropped[name] ?? 0) + 1;
    };
    const callbacks = new WeakMap();
    window.requestAnimationFrame = function (callback) {
      let callbackId = callbacks.get(callback);
      if (!callbackId) {
        callbackId = callbacks.size ?? data.callbacks.length + 1;
        callbacks.set(callback, callbackId);
        push('callbacks', { id: callbackId, name: callback.name, source: Function.prototype.toString.call(callback).slice(0, 500) });
      }
      const requestedAt = performance.now();
      let id;
      id = nativeRAF.call(this, function (timestamp) {
        const deliveredAt = performance.now();
        try { return callback.call(this, timestamp); }
        finally { push('raf', { id, callbackId, requestedAt, timestamp, deliveredAt, completedAt: performance.now() }); }
      });
      return id;
    };
    window.cancelAnimationFrame = function (id) {
      push('cancelled', { id, time: performance.now() });
      return nativeCancelRAF.call(this, id);
    };
    const nodes = new WeakMap();
    let nextNode = 1;
    const describe = (node) => {
      let id = nodes.get(node);
      if (!id) { id = nextNode++; nodes.set(node, id); }
      return { id, name: node.nodeName, ref: node.nodeType === 1 ? node.getAttribute('data-demo-ref') : null };
    };
    const observer = new MutationObserver((records) => {
      const time = performance.now();
      for (const record of records) {
        const value = { time, target: describe(record.target), connected: record.target.isConnected, type: record.type };
        if (record.type === 'attributes') Object.assign(value, { attribute: record.attributeName, oldValue: record.oldValue, finalValueAtDelivery: record.target.getAttribute(record.attributeName) });
        else Object.assign(value, { added: Array.from(record.addedNodes, describe), removed: Array.from(record.removedNodes, describe) });
        push('mutations', value);
      }
    });
    observer.observe(document.querySelector('#fixture'), { subtree: true, childList: true, attributes: true, attributeOldValue: true, attributeFilter: ['style', 'class', 'hidden', 'aria-expanded', 'data-pui-view-detached', 'data-pui-style'] });
    let longTasks;
    try {
      longTasks = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) push('longTasks', { startTime: entry.startTime, duration: entry.duration, name: entry.name, attribution: entry.attribution?.map((value) => ({ name: value.name, containerType: value.containerType, containerName: value.containerName, containerId: value.containerId, containerSrc: value.containerSrc })) });
      });
      longTasks.observe({ type: 'longtask', buffered: true });
    } catch (error) { data.longTaskObserverError = String(error); }
    window.S2NativeObserve = {
      mark(name) { const time = performance.now(); data.marks.push({ name, time }); performance.mark(`s2-vue-${name}`); return time; },
      read() { return data; },
      stop() { observer.disconnect(); longTasks?.disconnect(); window.requestAnimationFrame = nativeRAF; window.cancelAnimationFrame = nativeCancelRAF; return data; },
    };
  });
  await page.addScriptTag({ content: script.toString('utf8') });
  traceDone = new Promise((resolve) => cdp.once('Tracing.tracingComplete', resolve));
  await cdp.send('Tracing.start', { categories: 'devtools.timeline,v8,disabled-by-default-v8.gc,blink.user_timing', transferMode: 'ReturnAsStream', streamFormat: 'json' });
  tracing = true;
  await page.evaluate(() => BootstrapCollapse.mount('vue', 'collapsible', { controlled: true }));
  await page.locator('#scope').evaluate((element) => { element.textContent = 'vue · collapsible · light · native Chromium'; });
  const initial = await page.evaluate(() => BootstrapCollapse.snapshot());
  expect('initial closed height is zero', initial.height === 0, initial);
  await page.evaluate(() => { S2NativeObserve.mark('open-trace-start'); BootstrapCollapse.startTrace(); });
  await page.evaluate(() => BootstrapCollapse.accept(true));
  await page.waitForTimeout(520);
  report.open = await page.evaluate(() => BootstrapCollapse.stopTrace());
  const entered = await page.evaluate(() => BootstrapCollapse.snapshot());
  report.entered = entered;
  expect('entered natural height exceeds 110px', entered.height > 110, entered.height);
  expect('entered releases block-size', entered.size === '', entered.size);
  expect('entered remains semantically visible', entered.hidden === false, entered.hidden);
  const intermediate = (samples) => samples.filter((sample) => sample.height > .5 && sample.height < entered.height - .5).length;
  expect('open contains at least three real intermediate heights', intermediate(report.open) >= 3, intermediate(report.open));
  await page.screenshot({ path: path.join(output, 'vue-collapsible-entered.png') });
  await page.evaluate(() => { S2NativeObserve.mark('close-trace-start'); BootstrapCollapse.startTrace(); });
  report.closeRequestedAt = await page.evaluate(async () => { const time = S2NativeObserve.mark('close-request'); await BootstrapCollapse.accept(false); S2NativeObserve.mark('close-accepted'); return time; });
  await page.waitForTimeout(520);
  report.close = await page.evaluate(() => { S2NativeObserve.mark('close-trace-stop'); return BootstrapCollapse.stopTrace(); });
  report.final = await page.evaluate(() => BootstrapCollapse.snapshot());
  expect('close contains at least three real intermediate heights', intermediate(report.close) >= 3, intermediate(report.close));
  expect('final closed height is zero', report.final.height === 0, report.final);
  expect('final semantic hidden is true', report.final.hidden === true, report.final.hidden);
  expect('exit reaches original positive zero-edge witness', report.close.some((sample) => sample.height > 0 && sample.height < 2), report.close.filter((sample) => sample.height > 0).map((sample) => ({ time: sample.time, height: sample.height, size: sample.size, phase: sample.phase })));
  const closed = report.close.find((sample) => sample.phase === 'closed' && sample.time >= report.closeRequestedAt);
  report.firstObservedClosedElapsedMs = closed ? closed.time - report.closeRequestedAt : null;
  expect('observed completion remains within original 1000ms guard', !!closed && report.firstObservedClosedElapsedMs < 1000, report.firstObservedClosedElapsedMs);
  report.dispose = await page.evaluate(() => { S2NativeObserve.mark('dispose-start'); return BootstrapCollapse.dispose(); });
  report.native = await page.evaluate(() => { S2NativeObserve.mark('dispose-complete'); return S2NativeObserve.stop(); });
  expect('no native observer records were dropped', Object.keys(report.native.dropped).length === 0, report.native.dropped);
  expect('no page errors', report.errors.length === 0, report.errors);
} catch (error) {
  report.driverError = String(error.stack ?? error);
  try { report.native = await page.evaluate(() => S2NativeObserve.stop()); } catch {}
} finally {
  if (tracing) {
    try {
      await cdp.send('Tracing.end');
      const done = await traceDone;
      assert(done.stream, 'CDP trace stream required');
      const pieces = [];
      while (true) {
        const part = await cdp.send('IO.read', { handle: done.stream });
        pieces.push(Buffer.from(part.data, part.base64Encoded ? 'base64' : 'utf8'));
        if (part.eof) break;
      }
      await cdp.send('IO.close', { handle: done.stream });
      const raw = Buffer.concat(pieces);
      await writeFile(path.join(output, 'native-trace.json'), raw);
      const events = JSON.parse(raw).traceEvents;
      report.trace = { path: 'native-trace.json', bytes: raw.length, sha256: hash(raw), events: events.length, marks: events.filter((event) => event.name?.startsWith('s2-vue-')), longestEvents: events.filter((event) => typeof event.dur === 'number' && event.dur >= 10000).sort((a,b) => b.dur-a.dur).slice(0,80) };
    } catch (error) { report.traceError = String(error.stack ?? error); }
  }
  await browser.close();
  report.source.finalHead = git('rev-parse', 'HEAD');
  report.source.finalDirty = !!git('status', '--porcelain');
  report.source.sourceStable = report.source.finalHead === head && !report.source.finalDirty;
  report.summary = { passed: report.assertions.filter((value) => value.passed).length, failed: report.assertions.filter((value) => !value.passed).length, driverError: !!report.driverError, traceError: !!report.traceError };
  await writeFile(path.join(output, 'report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify({ summary: report.summary, sourceStable: report.source.sourceStable, firstObservedClosedElapsedMs: report.firstObservedClosedElapsedMs, longTasks: report.native?.longTasks, failed: report.assertions.filter((value) => !value.passed).map((value) => value.name) }));
  process.exitCode = report.summary.failed || report.driverError || report.traceError || !report.source.sourceStable ? 1 : 0;
}
