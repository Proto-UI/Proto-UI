import { tw } from '@proto.ui/core';
import { createWebPresencePresentationSink } from 'candidate-presence-source';

/** Same direct-sink owner facts as the original registration unit fixture. */
export async function run(mode: string) {
  const report: any = { mode, status: 'running', assertions: [], frames: [] };
  const check = (label: string, value: unknown) => {
    report.assertions.push({ label, passed: !!value });
    if (!value) throw new Error(label);
  };
  const el = document.createElement('div');
  Object.assign(el.style, { width: '320px', height: '200px', boxSizing: 'border-box' });
  document.body.append(el);
  const nativeRaf = window.requestAnimationFrame.bind(window);
  const nativeCancel = window.cancelAnimationFrame.bind(window);
  const raf = window.requestAnimationFrame;
  const cancel = window.cancelAnimationFrame;
  const pending = new Set<number>();
  window.requestAnimationFrame = (callback) => {
    const id = nativeRaf((time) => {
      pending.delete(id);
      report.frames.push({ time, opacityBefore: Number(getComputedStyle(el).opacity) });
      callback(time);
    });
    pending.add(id);
    return id;
  };
  window.cancelAnimationFrame = (id) => { pending.delete(id); nativeCancel(id); };
  let styleApplications = 0, subscriptions = 0, cleanups = 0;
  const outcomes: any[] = [];
  const owner = Object.freeze({});
  let sink: any;
  const frame = (phase: string) => ({
    view: 1, revision: 1, targetRevision: 1, style: tw('bg-background'),
    owner: { owner, revision: 1, phase, attempt: { ownerEpoch: 1, phaseAttempt: 1 },
      completion: 'presentation', durationMs: 500, timeoutMs: 1000 },
    closed: { opacity: 0 }, entered: { opacity: 1 }, easing: [0.32, 0.72, 0, 1],
    bind() {},
    complete(_binding: unknown, outcome: string) {
      outcomes.push({ outcome, at: performance.now() });
      el.hidden = true;
    },
  });
  try {
    sink = createWebPresencePresentationSink(el, {
      queueStyle() { styleApplications++; }, requestFlush() {},
    }, { subscribeDocumentChange() {
      subscriptions++;
      report.atSubscription = { inline: el.style.opacity,
        computed: getComputedStyle(el).opacity, styleApplications, pending: pending.size };
      if (mode === 'registration-before-first-application') sink.commit(frame('leaving'));
      return () => { cleanups++; };
    } });
    const started = performance.now();
    sink.commit(frame('entering'));
    report.afterEnteringCall = { inline: el.style.opacity, computed: getComputedStyle(el).opacity,
      styleApplications, pending: pending.size, outcomes: [...outcomes] };
    check('one adoption subscription', subscriptions === 1);
    check('registration precedes all semantic or transient applications', report.atSubscription.styleApplications === 0);
    check('registration sees the actual neutral semantic opacity', report.atSubscription.computed === '1' && report.atSubscription.inline === '');
    if (mode === 'registration-before-first-application') {
      check('superseding first enter has not applied a closed sample', el.style.opacity === '');
      check('the first admitted leave remains active', outcomes.length === 0 && pending.size === 1);
      while (!outcomes.length && performance.now() - started < 1000) {
        await new Promise<void>((resolve) => nativeRaf(() => resolve()));
      }
      check('exactly one successful completion', outcomes.length === 1 && outcomes[0].outcome === 'finished');
      report.elapsedMs = outcomes[0].at - started;
      check('completion follows the original duration before its deadline', report.elapsedMs >= 500 && report.elapsedMs < 1000);
      check('native frames observe intermediate opacity', report.frames.some((f: any) => f.opacityBefore > 0 && f.opacityBefore < 1));
    } else {
      check('the original entering frame applied zero', el.style.opacity === '0');
      sink.commit(frame('leaving'));
      check('reversal of applied zero finishes synchronously', outcomes.length === 1 && outcomes[0].outcome === 'finished');
      check('no native frame was needed to reverse zero', report.frames.length === 0);
    }
    check('terminal owner hides the surface', el.hidden);
    check('terminal presentation has no outstanding RAF', pending.size === 0);
    sink.release(1);
    check('subscription cleanup occurs once', cleanups === 1);
    check('release leaves no outstanding RAF', pending.size === 0);
    report.outcomes = outcomes;
    report.status = 'passed';
  } catch (error) {
    report.status = 'failed'; report.error = String((error as Error).stack ?? error);
  } finally {
    sink?.release(1);
    for (const id of pending) nativeCancel(id);
    window.requestAnimationFrame = raf;
    window.cancelAnimationFrame = cancel;
    el.remove();
  }
  return report;
}
