/** Actual Vue consumers: unchanged endpoint and deliberately executed mutations. */
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { createRequire } from "node:module";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { installBootstrapCloseEndpointOracle } from "./bootstrap-collapse-endpoint-oracle.mjs";

const root = process.cwd();
const output = process.env.PUI_EVIDENCE_DIR;
const prior = process.env.PUI_PRIOR_EVIDENCE_DIR;
const expectedHead = "8bf1bef48c7bae707c842ece3d3db90084c4d60b";
const bundleSourceHead = "9459bb786b2a0e8de1a48f0940ac14eeba2f2733";
assert(output && prior);
await mkdir(output, { recursive: true });
const sha = (raw) => createHash("sha256").update(raw).digest("hex");
const git = (...args) =>
  execFileSync("git", args, { cwd: root, encoding: "utf8" }).trim();
const priorBytes = await readFile(path.join(prior, "report.json"));
const priorReport = JSON.parse(priorBytes);
assert.equal(priorReport.source.head, bundleSourceHead);
assert.equal(priorReport.source.dirty, false);
assert.equal(git("rev-parse", "HEAD"), expectedHead);
assert.equal(git("status", "--porcelain"), "");
const bundle = await readFile(path.join(prior, "consumer.js"));
const css = await readFile(path.join(prior, "consumer.css"), "utf8");
assert.equal(sha(bundle), priorReport.source.bundleSha256);
assert.equal(sha(css), priorReport.source.cssSha256);
for (const input of priorReport.source.inputs)
  assert.equal(
    sha(await readFile(path.join(root, input.path))),
    input.sha256,
    input.path,
  );
const themePath = path.join(
  root,
  "packages/prototypes/bootstrap-2-3-2/src/theme.ts",
);
const { renderThemeCss } = await import(pathToFileURL(themePath).href);
const { chromium } = createRequire(path.join(root, "apps/www/package.json"))(
  "playwright-core",
);
const report = {
  kind: "bootstrap-live-owner-endpoint-oracle-calibration",
  at: new Date().toISOString(),
  source: {
    head: expectedHead,
    bundleSourceHead,
    dirty: false,
    driverSha256: sha(await readFile(new URL(import.meta.url))),
    oracleSha256: sha(
      await readFile(
        new URL("./bootstrap-collapse-endpoint-oracle.mjs", import.meta.url),
      ),
    ),
    priorReportSha256: sha(priorBytes),
    bundleSha256: sha(bundle),
    cssSha256: sha(css),
    verifiedInputCount: priorReport.source.inputs.length,
    themeSha256: sha(await readFile(themePath)),
  },
  authority: [
    "C-FEEDBACK-INTRINSIC-BLOCK-SIZE-0001-DECLARATION",
    "C-FEEDBACK-INTRINSIC-BLOCK-SIZE-0001-OWNERSHIP",
    "C-FEEDBACK-PRESENCE-PRESENTATION-0001-ACKNOWLEDGEMENT",
    "HC-FEEDBACK-PRESENCE-PRESENTATION-0001-EVIDENCE",
  ],
  boundary:
    "The unmodified Vue consumer and three deliberate host-boundary mutations run in independent native Chromium pages using the identical source bundle. This calibrates endpoint application/retirement assertions; it does not replace the original forty-case run or certify physical rasterization, other runtimes, real AT or performance budgets. Native layout reads at candidate zero writes are observer overhead.",
  environment: {
    node: process.version,
    sandbox: true,
    viewport: { width: 960, height: 720 },
    theme: "light",
    reducedMotion: "no-preference",
    durationMs: 350,
    observationWaitMs: 520,
    absoluteGuardMs: 1000,
  },
  cases: [],
};
const browser = await chromium.launch({
  executablePath: process.env.PUI_CHROME_EXECUTABLE,
  headless: true,
  chromiumSandbox: true,
  args: ["--disable-dev-shm-usage"],
});
report.environment.browser = browser.version();
const modes = [
  "observe",
  "skip-zero",
  "detach-before-zero",
  "zero-on-replacement",
  "ancestor-hide-before-zero",
  "late-positive-idl",
];
try {
  for (const mode of modes) {
    const row = { mode, status: "running", pageErrors: [], assertions: [] };
    report.cases.push(row);
    const page = await browser.newPage({
      viewport: report.environment.viewport,
      colorScheme: "light",
      reducedMotion: "no-preference",
    });
    page.on("pageerror", (error) =>
      row.pageErrors.push(String(error.stack ?? error)),
    );
    const check = (name, passed, detail) =>
      row.assertions.push({ name, passed: !!passed, detail });
    const evaluate = async (fn, argument) => {
      let timer;
      try {
        return await Promise.race([
          page.evaluate(fn, argument),
          new Promise((_, reject) => {
            timer = setTimeout(
              () =>
                reject(
                  new Error(
                    "Harness evaluation did not return within10000ms; not a product success.",
                  ),
                ),
              10000,
            );
          }),
        ]);
      } finally {
        clearTimeout(timer);
      }
    };
    try {
      await page.setContent(
        '<!doctype html><html data-theme="light"><head><meta charset="utf-8"></head><body><main><h1>Bootstrap 2.3.2 · intrinsic Collapse</h1><p id="scope"></p><div id="fixture"></div></main></body></html>',
      );
      await page.addStyleTag({
        content: `${renderThemeCss()}\n${css}\n*,::before,::after {box-sizing:border-box} body{margin:0;background:#f6f6f6;color:#333;font-family:"Helvetica Neue",Arial,sans-serif} main{width:640px;margin:40px auto;padding:24px;background:#fff} h1{font-size:22px;line-height:30px;margin:0 0 12px} #scope{font-size:14px;margin-bottom:18px} .collapse-copy>div{min-height:20px}`,
      });
      await page.addScriptTag({ content: bundle.toString("utf8") });
      await evaluate(() =>
        BootstrapCollapse.mount("vue", "collapsible", { controlled: true }),
      );
      await page.locator("#scope").evaluate((element) => {
        element.textContent = "vue · collapsible · light · native Chromium";
      });
      row.initial = await evaluate(() => BootstrapCollapse.snapshot());
      check(
        "original initial closed height",
        row.initial.height === 0,
        row.initial.height,
      );
      await evaluate(() => BootstrapCollapse.startTrace());
      await evaluate(() => BootstrapCollapse.accept(true));
      await page.waitForTimeout(520);
      row.open = await evaluate(() => BootstrapCollapse.stopTrace());
      row.entered = await evaluate(() => BootstrapCollapse.snapshot());
      const intermediate = (samples) =>
        samples.filter(
          (sample) =>
            sample.height > 0.5 && sample.height < row.entered.height - 0.5,
        ).length;
      check(
        "original entered natural visible geometry",
        row.entered.height > 110 &&
          row.entered.size === "" &&
          row.entered.hidden === false,
        row.entered,
      );
      check(
        "original entry has three native intermediate heights",
        intermediate(row.open) >= 3,
        intermediate(row.open),
      );
      await page.screenshot({ path: path.join(output, `${mode}-entered.png`) });
      row.witnessStart = await evaluate(installBootstrapCloseEndpointOracle, {
        mode,
      });
      await evaluate(() => BootstrapCollapse.startTrace());
      row.closeRequestedAt = await evaluate(async () => {
        const time = BootstrapCloseEndpointWitness.requestStarted();
        await BootstrapCollapse.accept(false);
        return time;
      });
      await page.waitForTimeout(520);
      row.close = await evaluate(() => BootstrapCollapse.stopTrace());
      row.endpoint = await evaluate(
        (samples) => BootstrapCloseEndpointWitness.finish(samples),
        row.close,
      );
      row.final = await evaluate(() => BootstrapCollapse.snapshot());
      row.originalObservations = {
        intermediateCount: intermediate(row.close),
        nearZeroRaf: row.close.some(
          (sample) => sample.height > 0 && sample.height < 2,
        ),
        finalHeight: row.final.height,
        finalHidden: row.final.hidden,
      };
      check(
        "native observer retained its original method ownership",
        row.endpoint.observerOwned &&
          !row.endpoint.observationError &&
          row.endpoint.recordsDropped === 0,
        {
          owned: row.endpoint.observerOwned,
          error: row.endpoint.observationError,
          dropped: row.endpoint.recordsDropped,
        },
      );
      check(
        "no page errors before result capture",
        row.pageErrors.length === 0,
        row.pageErrors,
      );
      if (mode === "observe") {
        check(
          "original close has three native intermediate heights",
          intermediate(row.close) >= 3,
          intermediate(row.close),
        );
        check(
          "original terminal height and semantic hidden",
          row.final.height === 0 && row.final.hidden === true,
          row.final,
        );
        check(
          "same live owner applies actual zero before hidden/removal",
          row.endpoint.accepted,
          row.endpoint.acceptedZero,
        );
        check(
          "baseline contains no intentional mutation",
          !row.endpoint.mutationPerformed,
          row.endpoint.mutations,
        );
      } else {
        check(
          "intentional native mutation actually executed",
          row.endpoint.mutationPerformed,
          row.endpoint.mutations,
        );
        check(
          "endpoint oracle rejects the executed mutation",
          row.endpoint.accepted === false,
          {
            accepted: row.endpoint.accepted,
            zeroEvents: row.endpoint.zeros.length,
            retirements: row.endpoint.retirements,
          },
        );
      }
      row.status = row.assertions.every((value) => value.passed)
        ? "passed"
        : "failed";
    } catch (error) {
      row.status = "failed";
      row.driverError = String(error.stack ?? error);
    } finally {
      try {
        await evaluate(() =>
          globalThis.BootstrapCloseEndpointWitness?.finish(),
        );
        row.cleanup = await evaluate(() => BootstrapCollapse.dispose());
      } catch (error) {
        row.cleanupError = String(error.stack ?? error);
        row.status = "failed";
      }
      await page.close();
      await writeFile(
        path.join(output, "report.json"),
        JSON.stringify(report, null, 2),
      );
      console.log(
        JSON.stringify({
          mode,
          status: row.status,
          oracleAccepted: row.endpoint?.accepted,
          mutationPerformed: row.endpoint?.mutationPerformed,
          failed: row.assertions
            .filter((value) => !value.passed)
            .map((value) => value.name),
          driverError: row.driverError,
          cleanupError: row.cleanupError,
        }),
      );
    }
    if (row.driverError) break;
  }
} finally {
  await browser.close();
  report.source.finalHead = git("rev-parse", "HEAD");
  report.source.finalDirty = !!git("status", "--porcelain");
  report.source.sourceStable =
    report.source.finalHead === expectedHead && !report.source.finalDirty;
  report.summary = {
    cases: report.cases.length,
    passed: report.cases.filter((row) => row.status === "passed").length,
    failed: report.cases.filter((row) => row.status !== "passed").length,
    assertionsPassed: report.cases.reduce(
      (sum, row) => sum + row.assertions.filter((value) => value.passed).length,
      0,
    ),
    assertionsFailed: report.cases.reduce(
      (sum, row) =>
        sum + row.assertions.filter((value) => !value.passed).length,
      0,
    ),
  };
  await writeFile(
    path.join(output, "report.json"),
    JSON.stringify(report, null, 2),
  );
  console.log(
    JSON.stringify({
      summary: report.summary,
      sourceStable: report.source.sourceStable,
    }),
  );
  process.exitCode =
    report.summary.failed || !report.source.sourceStable ? 1 : 0;
}
