"use strict";
var NativeRepeatedAdoption = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // ../bootstrap-initial-leave-diagnostic/registration-fixture.ts
  var registration_fixture_exports = {};
  __export(registration_fixture_exports, {
    run: () => run
  });

  // packages/core/src/spec/feedback/placeholder.ts
  var PLACEHOLDER_COLOR_TOKENS = /* @__PURE__ */ new Set([
    "placeholder:text-foreground",
    "placeholder:text-muted-foreground",
    "placeholder:text-primary",
    "placeholder:text-destructive"
  ]);
  function isPlaceholderColorTokenV0(token) {
    return PLACEHOLDER_COLOR_TOKENS.has(token);
  }

  // packages/core/src/spec/feedback/application-role.ts
  var COMPOSITE_DISPLAY_TOKENS = /* @__PURE__ */ new Set([
    "block",
    "flex",
    "flow-root",
    "grid",
    "inline",
    "inline-block",
    "inline-flex",
    "inline-grid",
    "table",
    "table-row",
    "table-cell",
    "table-caption"
  ]);
  var ROOT_GEOMETRY_TOKENS = /* @__PURE__ */ new Set([
    "translate-y-px",
    "translate-x-0",
    // D-FEEDBACK-STYLE-ROLE-RESOLUTION-0001-RESIDENT-SPACING: exact 1.25rem only.
    "translate-x-5",
    "translate-x-0.25",
    "translate-x-[calc(100%_-_2px)]",
    // Draft bounded percentage-translation slice: this operand stays static.
    "translate-x-[calc(100%_-_4px)]",
    "translate-x-[calc(100%_+_2px)]",
    "translate-x-[calc(100%_-_8px)]",
    "scale-[0.98]",
    "will-change-transform",
    // K1 exact additions retain the independent Root geometry domain.
    "-translate-x-1/2",
    "-translate-y-1/2"
  ]);
  var PERCENTAGE_ROOT_TRANSLATIONS = /* @__PURE__ */ new Set([
    "translate-x-[calc((100%_-_2px)*var(--pui-percentage)/100)]",
    "translate-x-[calc((100%_-_4px)*var(--pui-percentage)/100)]",
    "translate-x-[calc((100%_-_8px)*var(--pui-percentage)/100)]",
    "translate-x-[calc((2px_-_100%)*var(--pui-percentage)/100)]",
    "translate-x-[calc((4px_-_100%)*var(--pui-percentage)/100)]",
    "translate-x-[calc((8px_-_100%)*var(--pui-percentage)/100)]",
    "translate-x-[calc(1px_+_(100%_+_1px)*var(--pui-percentage)/100)]",
    "translate-x-[calc(-1px_-_(100%_+_1px)*var(--pui-percentage)/100)]"
  ]);
  function isPercentageRootTranslationV1(token) {
    return PERCENTAGE_ROOT_TRANSLATIONS.has(token);
  }
  var UNRESOLVED_EXACT_TOKENS = /* @__PURE__ */ new Set([
    "collapse",
    "hidden",
    "invisible",
    "relative",
    "transform",
    "transform-gpu",
    "transform-none",
    "visible"
  ]);
  var UNRESOLVED_PREFIXES = [
    "origin-",
    "overflow-",
    "overscroll-",
    "pointer-events-",
    "rotate-",
    "scale-",
    "skew-",
    "translate-",
    "will-change-"
  ];
  var PLACEMENT_EXACT_TOKENS = /* @__PURE__ */ new Set([
    "absolute",
    "fixed",
    "grow",
    "shrink",
    "static",
    "sticky",
    "isolate",
    "float-left",
    "float-right",
    "align-top",
    "align-middle",
    "align-bottom"
  ]);
  var PLACEMENT_PREFIXES = [
    "aspect-",
    "basis-",
    "bottom-",
    "end-",
    "grow-",
    "h-",
    "inset-",
    "inset-x-",
    "inset-y-",
    "left-",
    "m-",
    "max-h-",
    "max-w-",
    "mb-",
    "me-",
    "min-h-",
    "min-w-",
    "ml-",
    "mr-",
    "ms-",
    "mt-",
    "mx-",
    "my-",
    "order-",
    "right-",
    "self-",
    "shrink-",
    "size-",
    "start-",
    "top-",
    "w-",
    "z-"
  ];
  var SURFACE_EXACT_TOKENS = /* @__PURE__ */ new Set([
    "border",
    "capitalize",
    "lowercase",
    "normal-case",
    "outline",
    "peer",
    "rounded",
    "shadow",
    "underline",
    "uppercase"
  ]);
  var SURFACE_PREFIXES = [
    "animate-",
    "backdrop-",
    "bg-",
    "border-",
    "content-",
    "cursor-",
    "decoration-",
    "delay-",
    "duration-",
    "ease-",
    "fade-",
    "flex-col",
    "flex-row",
    "flex-wrap",
    "font-",
    "gap-",
    "gap-x-",
    "gap-y-",
    "grid-cols-",
    "grid-flow-",
    "grid-rows-",
    "group/",
    "items-",
    "justify-",
    "leading-",
    "opacity-",
    "outline-",
    "p-",
    "pb-",
    "pe-",
    "pl-",
    "place-content-",
    "place-items-",
    "pr-",
    "ps-",
    "pt-",
    "px-",
    "py-",
    "ring-",
    "rounded-",
    "resize-",
    "select-",
    "shadow-",
    "slide-in-",
    "slide-out-",
    "space-x-",
    "space-y-",
    "text-",
    "touch-",
    "tracking-",
    "transition-",
    "underline-offset-",
    "whitespace-",
    "zoom-"
  ];
  function withoutNegativePrefix(token) {
    return token.startsWith("-") ? token.slice(1) : token;
  }
  function startsWithAny(token, prefixes) {
    return prefixes.some((prefix) => token.startsWith(prefix));
  }
  function isPlacementFlexItemToken(token) {
    return /^flex-(?:1|auto|initial|none|\[)/.test(token);
  }
  function resolution(token, role, roleSource) {
    return Object.freeze({ token, role, roleSource });
  }
  function classifyTwTokenApplicationRoleV0(token) {
    if (token === "overflow-y-auto") return resolution(token, "surface", "canonical");
    if (token === "scroll-my-1" || token === "scroll-my-1.5")
      return resolution(token, "placement", "canonical");
    if (isPlaceholderColorTokenV0(token)) return resolution(token, "surface", "canonical");
    if (token === "hidden") return resolution(token, "root-participation", "canonical");
    if (token === "relative") return resolution(token, "root-geometry", "canonical");
    if (ROOT_GEOMETRY_TOKENS.has(token) || isPercentageRootTranslationV1(token))
      return resolution(token, "root-geometry", "canonical");
    if (token === "pointer-events-none") return resolution(token, "hit-testing", "canonical");
    if (token === "field-sizing-content" || token === "field-sizing-fixed") {
      return resolution(token, "surface", "canonical");
    }
    const comparable = withoutNegativePrefix(token);
    if (UNRESOLVED_EXACT_TOKENS.has(comparable) || startsWithAny(comparable, UNRESOLVED_PREFIXES)) {
      return resolution(token, "unresolved", "unresolved");
    }
    if (COMPOSITE_DISPLAY_TOKENS.has(comparable)) {
      return resolution(token, "composite", "canonical");
    }
    if (PLACEMENT_EXACT_TOKENS.has(comparable) || startsWithAny(comparable, PLACEMENT_PREFIXES) || isPlacementFlexItemToken(comparable)) {
      return resolution(token, "placement", "canonical");
    }
    if (SURFACE_EXACT_TOKENS.has(comparable) || startsWithAny(comparable, SURFACE_PREFIXES)) {
      return resolution(token, "surface", "canonical");
    }
    return resolution(token, "surface", "fallback");
  }

  // packages/core/src/spec/feedback/semantic-merge.ts
  var PREFIXES_V0 = [
    // Color
    "bg-",
    // Spacing
    "p-",
    "px-",
    "py-",
    "pt-",
    "pr-",
    "pb-",
    "pl-",
    "m-",
    "mx-",
    "my-",
    "mt-",
    "mr-",
    "mb-",
    "ml-",
    // Sizing
    "w-",
    "h-",
    "min-w-",
    "min-h-",
    "max-w-",
    "max-h-",
    // Layout
    "justify-",
    "items-",
    "content-",
    // Effects
    "opacity-",
    "shadow-",
    "tracking-",
    "transition-",
    "rounded"
  ];
  var TEXT_SIZE_TOKENS = /* @__PURE__ */ new Set([
    "xs",
    "sm",
    "base",
    "lg",
    "xl",
    "2xl",
    "3xl",
    "4xl",
    "5xl",
    "6xl",
    "7xl",
    "8xl",
    "9xl"
  ]);
  var TEXT_ALIGN_TOKENS = /* @__PURE__ */ new Set(["left", "right", "center", "justify", "start", "end"]);
  function getSemanticGroupKeyV0(token) {
    if (token === "-mx-4") return "mx-";
    if (token === "-mb-4") return "mb-";
    if (token === "ease-linear" || token === "ease-in-out") return "transition timing";
    if (token === "box-border" || token === "box-content") return "box sizing";
    if (token === "float-left" || token === "float-right") return "float placement";
    if (token === "text-balance") return "text wrapping";
    if (/^font-(normal|medium|semibold|bold|black|\[100\])$/.test(token)) return "font weight";
    if (token === "border-collapse" || token === "border-separate") return "table border model";
    if (token === "border-spacing-0") return "table border spacing";
    if (token === "caption-bottom") return "table caption side";
    if (token === "align-top" || token === "align-middle" || token === "align-bottom")
      return "vertical alignment";
    const roundedSide = token.match(/^rounded-([trbl])-/);
    if (roundedSide) return `rounded-${roundedSide[1]}-`;
    if (token === "scroll-py-1" || token === "scroll-py-1.5") return "finite scroll padding block";
    if (token === "scroll-my-1" || token === "scroll-my-1.5") return "finite scroll margin block";
    if (isPlaceholderColorTokenV0(token)) return "placeholder:text-color";
    if (/^(?:-z-(?:1|10)|z-(?:10|40|50|\[(?:2|1000|1051)\]))$/.test(token)) return "finite z index";
    if (token === "backdrop-blur-xs" || token === "backdrop-filter-[blur(40px)_saturate(1.5)]")
      return "complete backdrop filter";
    const selectionPrefix = "selection:";
    if (token.startsWith(selectionPrefix)) {
      return `${selectionPrefix}${getSemanticGroupKeyV0(token.slice(selectionPrefix.length))}`;
    }
    if (token === "resize-y" || token === "resize-none") return "field resize affordance";
    if (token === "field-sizing-content" || token === "field-sizing-fixed") {
      return "field intrinsic sizing";
    }
    const translateAxis = token.match(/^-?translate-([xy])-/);
    if (translateAxis) return `translate-${translateAxis[1]}-`;
    if (token === "select-auto" || token === "select-text" || token === "select-none") {
      return "content-selection affordance";
    }
    if (token === "flex" || token === "inline-flex" || token === "block" || token === "inline-block" || token === "table" || token === "table-row" || token === "table-cell" || token === "table-caption") {
      return "display";
    }
    if (token === "flex-row" || token === "flex-row-reverse" || token === "flex-col" || token === "flex-col-reverse") {
      return "flex-direction";
    }
    if (token === "border" || token === "border-0" || token === "border-2" || token === "border-[3px]" || token === "border-4" || token === "border-8") {
      return "border-width";
    }
    const directionalBorderWidth = token.match(/^border-([trblxy])(?:-(0|2|4|8))?$/);
    if (directionalBorderWidth) {
      return `border-${directionalBorderWidth[1]}-width`;
    }
    if (token.startsWith("border-b-")) return "border-b-color";
    if (token.startsWith("border-")) {
      return "border-color";
    }
    if (token.startsWith("bg-clip-")) return "bg-clip-";
    if (token.startsWith("text-")) {
      const suffix = token.slice("text-".length);
      if (TEXT_ALIGN_TOKENS.has(suffix)) return "text-align";
      if (/^\[#[0-9a-fA-F]+\]$/.test(suffix)) return "text-color";
      if (TEXT_SIZE_TOKENS.has(suffix) || suffix.startsWith("[")) return "text-size";
      return "text-color";
    }
    for (const p of PREFIXES_V0) {
      if (token.startsWith(p)) return p;
    }
    return token;
  }
  function mergeTwTokensV0(tokens) {
    const groupOrder = [];
    const seen = /* @__PURE__ */ new Set();
    const lastByGroup = /* @__PURE__ */ new Map();
    for (const t of tokens) {
      const g = getSemanticGroupKeyV0(t);
      if (!seen.has(g)) {
        seen.add(g);
        groupOrder.push(g);
      }
      lastByGroup.set(g, t);
    }
    const out = [];
    for (const g of groupOrder) {
      const v = lastByGroup.get(g);
      if (v) out.push(v);
    }
    return { tokens: out };
  }

  // packages/core/src/spec/feedback/tokens.ts
  function selectionPayloadHasSelectorSyntax(token) {
    let bracketDepth = 0;
    let quote;
    let escaped = false;
    for (let index = 0; index < token.length; index += 1) {
      const character = token[index];
      if (escaped) {
        escaped = false;
        continue;
      }
      if (character === "\\") {
        escaped = true;
        continue;
      }
      if (bracketDepth > 0) {
        if (quote) {
          if (character === quote) quote = void 0;
        } else if (character === "'" || character === '"') {
          quote = character;
        } else if (character === "[") {
          bracketDepth += 1;
        } else if (character === "]") {
          bracketDepth -= 1;
        }
        continue;
      }
      if (character === "[") {
        if (index === 0 || token[index - 1] !== "-") return true;
        bracketDepth = 1;
        continue;
      }
      if (character === "]") return true;
      if (/[&>+~,*|#]/.test(character)) return true;
      if (character === "." && !(/[0-9]/.test(token[index - 1] ?? "") && /[0-9]/.test(token[index + 1] ?? ""))) {
        return true;
      }
    }
    return bracketDepth !== 0 || quote !== void 0 || escaped;
  }
  function assertTwTokenV0(token, ctx) {
    const where = ctx ? ` (${ctx})` : "";
    if (typeof token !== "string" || !token.trim()) {
      throw new Error(`[feedback] invalid tw token${where}: empty`);
    }
    if (/\s/.test(token)) {
      throw new Error(`[feedback] invalid tw token${where}: contains whitespace: "${token}"`);
    }
    if (token.startsWith(".") || token.startsWith("#")) {
      throw new Error(
        `[feedback] invalid tw token${where}: selector-like token is forbidden in "${token}"`
      );
    }
    if (isPlaceholderColorTokenV0(token)) return;
    if (token.includes(":")) {
      const selectionPrefix = "selection:";
      if (token.startsWith(selectionPrefix) && !token.slice(selectionPrefix.length).includes(":")) {
        if (/^select-(auto|text|none)$/.test(token.slice(selectionPrefix.length))) {
          throw new Error(
            `[feedback] invalid tw token${where}: content-selection affordances require the subject, not its selection highlight: "${token}"`
          );
        }
        if (selectionPayloadHasSelectorSyntax(token.slice(selectionPrefix.length))) {
          throw new Error(
            `[feedback] invalid tw token${where}: selector-like selection payload is forbidden in "${token}"`
          );
        }
        assertTwTokenV0(token.slice(selectionPrefix.length), ctx);
        return;
      }
      throw new Error(`[feedback] invalid tw token${where}: forbidden character ":" in "${token}"`);
    }
    const left = token.indexOf("[");
    const right = token.lastIndexOf("]");
    if (left !== -1 || right !== -1) {
      if (!(left !== -1 && right !== -1 && right > left)) {
        throw new Error(`[feedback] invalid tw token${where}: malformed bracket in "${token}"`);
      }
      const inside = token.slice(left + 1, right);
      if (!inside.length) {
        throw new Error(`[feedback] invalid tw token${where}: empty bracket value in "${token}"`);
      }
      if (/[\s]/.test(inside)) {
        throw new Error(
          `[feedback] invalid tw token${where}: bracket value contains whitespace in "${token}"`
        );
      }
      if (inside.includes(":")) {
        throw new Error(
          `[feedback] invalid tw token${where}: bracket value contains ":" in "${token}"`
        );
      }
    }
  }

  // packages/core/src/spec/feedback/root-effect.ts
  function resolveRootStyleEntry(token, origin) {
    if (token.includes(":")) {
      try {
        assertTwTokenV0(token);
      } catch {
        return Object.freeze({
          token,
          authorToken: token,
          origin,
          role: "unresolved",
          roleSource: "unresolved"
        });
      }
    }
    const resolution2 = classifyTwTokenApplicationRoleV0(token);
    return Object.freeze({ ...resolution2, authorToken: token, origin });
  }
  function createRootStyleEffect(entries2) {
    const snapshot = Object.freeze(entries2.map((entry) => Object.freeze({ ...entry })));
    return { kind: "tw", tokens: snapshot.map((entry) => entry.token), entries: snapshot };
  }
  function readRootStyleEntries(handle, origin) {
    if (!("entries" in handle)) return handle.tokens.map((t) => resolveRootStyleEntry(t, origin));
    const entries2 = handle.entries;
    if (!Array.isArray(entries2) || entries2.length !== handle.tokens.length || entries2.some((entry, index) => !entry || entry.token !== handle.tokens[index])) {
      throw new Error("[feedback] Root style effect token/provenance mismatch");
    }
    return entries2;
  }
  function mergeRootStyleEntries(entries2) {
    const byToken = new Map(entries2.map((entry) => [entry.token, entry]));
    return mergeTwTokensV0(entries2.map((entry) => entry.token)).tokens.map(
      (token) => byToken.get(token)
    );
  }

  // packages/core/src/internal.ts
  var activeRuntimeDelayContexts = [];
  function getActiveRuntimeDelayContext() {
    return activeRuntimeDelayContexts.at(-1);
  }

  // packages/core/src/prototype.ts
  var MODULE_DECLARATION_TOKEN_BRAND = Symbol("@proto.ui/module-declaration-token");

  // packages/core/src/spec/feedback/recorder.ts
  var FeedbackStyleRecorder = class {
    nextId = 1;
    chunks = [];
    runtimePatch = /* @__PURE__ */ new Map();
    /**
     * setup-only: record style intent tokens (tw handles only)
     */
    use(...handles) {
      return this.recordAuthorHandles(handles, "setup");
    }
    /** Internal Rule contribution; replay keeps this origin rather than reclassifying. */
    useRuntime(...handles) {
      return this.recordAuthorHandles(handles, "rule");
    }
    recordAuthorHandles(handles, origin) {
      const flattened = [];
      for (const h of handles) {
        if (!h || h.kind !== "tw" || !Array.isArray(h.tokens)) {
          throw new Error(`[feedback] unsupported style handle in v0`);
        }
        for (const t of h.tokens) {
          assertTwTokenV0(t, "feedback.style.use");
          flattened.push(t);
        }
      }
      const chunk = {
        id: this.nextId++,
        entries: flattened.map((t) => resolveRootStyleEntry(t, origin)),
        removed: false
      };
      this.chunks.push(chunk);
      const unUse = () => {
        chunk.removed = true;
      };
      return unUse;
    }
    /**
     * internal: record style tokens without v0 tw validation.
     * Used by rule extensions that generate selector-based tokens.
     */
    useUnsafe(...handles) {
      const flattened = [];
      for (const h of handles) {
        if (!h || h.kind !== "tw" || !Array.isArray(h.tokens)) {
          throw new Error(`[feedback] unsupported style handle in v0`);
        }
        for (const t of h.tokens) {
          if (typeof t !== "string" || !t) {
            throw new Error(`[feedback] invalid tw token (unsafe): empty`);
          }
        }
        flattened.push(...readRootStyleEntries(h, "rule"));
      }
      const chunk = {
        id: this.nextId++,
        entries: createRootStyleEffect(flattened).entries,
        removed: false
      };
      this.chunks.push(chunk);
      const unUse = () => {
        chunk.removed = true;
      };
      return unUse;
    }
    /**
     * runtime-only: write positive style patches over the current base result.
     */
    patch(...handles) {
      for (const token of this.flattenRuntimePatchHandles(handles, "run.feedback.style.patch")) {
        this.runtimePatch.set(getSemanticGroupKeyV0(token), {
          kind: "patch",
          entry: resolveRootStyleEntry(token, "runtime")
        });
      }
    }
    /**
     * runtime-only: suppress semantic groups from the current base result.
     */
    suppress(...handles) {
      for (const token of this.flattenRuntimePatchHandles(handles, "run.feedback.style.suppress")) {
        this.runtimePatch.set(getSemanticGroupKeyV0(token), { kind: "suppress" });
      }
    }
    /**
     * runtime-only: remove every style patch entry for the current instance.
     */
    clearPatch() {
      this.runtimePatch.clear();
    }
    /**
     * Export a semantic snapshot of merged tokens.
     *
     * v0 recommendation: export is allowed in any phase (pure snapshot).
     */
    export() {
      return this.exportWithAdditional();
    }
    /**
     * Export a semantic snapshot after appending additional base style handles,
     * then applying the runtime patch layer.
     *
     * Additional handles are used by rule/runtime internals: they are still part of
     * the pre-patch base semantic result, not host translation artifacts.
     */
    exportWithAdditional(...handles) {
      return { tokens: this.exportRootEffect(...handles).tokens };
    }
    exportBase() {
      return { tokens: this.exportBaseEntries().map((entry) => entry.token) };
    }
    /** Internal Root-only effect snapshot. Public export retains its token-only shape. */
    exportRootEffect(...handles) {
      return createRootStyleEffect(this.applyPatchLayer(this.exportBaseEntries(handles)));
    }
    exportBaseEntries(additionalHandles = []) {
      const inputs = [];
      for (const c of this.chunks) {
        if (c.removed) continue;
        inputs.push(...c.entries);
      }
      for (const h of additionalHandles) {
        if (!h || h.kind !== "tw" || !Array.isArray(h.tokens)) {
          throw new Error(`[feedback] unsupported style handle in v0`);
        }
        inputs.push(...readRootStyleEntries(h, "rule"));
      }
      return mergeRootStyleEntries(inputs);
    }
    applyPatchLayer(baseEntries) {
      if (this.runtimePatch.size === 0) return baseEntries;
      const patchEntries = [];
      const baseAfterSuppress = [];
      for (const entry of baseEntries) {
        if (this.runtimePatch.has(getSemanticGroupKeyV0(entry.token))) continue;
        baseAfterSuppress.push(entry);
      }
      for (const entry of this.runtimePatch.values()) {
        if (entry.kind === "patch") patchEntries.push(entry.entry);
      }
      return mergeRootStyleEntries([...baseAfterSuppress, ...patchEntries]);
    }
    flattenRuntimePatchHandles(handles, op) {
      const flattened = [];
      for (const h of handles) {
        if (!h || h.kind !== "tw" || !Array.isArray(h.tokens)) {
          throw new Error(`[feedback] unsupported style handle in v0`);
        }
        for (const t of h.tokens) {
          assertTwTokenV0(t, op);
          if (t === "data-pui-style") {
            throw new Error(`[feedback] invalid tw token (${op}): host style artifact is forbidden`);
          }
          flattened.push(t);
        }
      }
      return flattened;
    }
  };

  // packages/core/src/spec/feedback/style.ts
  function tw(tokens, ...more) {
    const all = [tokens, ...more].join(" ").trim();
    const list = all ? all.split(/\s+/g) : [];
    return { kind: "tw", tokens: list };
  }

  // packages/core/src/errors/codes.ts
  var ProtoUiError = class extends Error {
    code;
    details;
    constructor(code, message, details) {
      super(message);
      this.code = code;
      this.details = details;
    }
  };
  function illegalPhase(op, phase, details) {
    return new ProtoUiError("E_ILLEGAL_PHASE", `[Phase] illegal phase for ${op}: ${phase}`, details);
  }

  // packages/core/src/delay.ts
  function delay(durationMs, callback) {
    if (!Number.isFinite(durationMs) || durationMs < 0) {
      throw new Error("[Delay] durationMs must be a non-negative finite number.");
    }
    if (typeof callback !== "function") {
      throw new Error("[Delay] callback must be a function.");
    }
    const ctx = getActiveRuntimeDelayContext();
    if (!ctx) {
      throw new Error(
        "[Delay] delay() is runtime-only and requires an active runtime callback context."
      );
    }
    return ctx.scheduleDelay(durationMs, callback);
  }

  // packages/core/src/caps/token.ts
  function cap(id) {
    return { id };
  }

  // packages/core/src/caps/host.ts
  var HOST_ELEMENT_CAP = cap("@proto.ui/web/hostElement");

  // packages/core/src/material.ts
  function record(value, required, optional = []) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    const prototype = Object.getPrototypeOf(value);
    if (prototype !== Object.prototype && prototype !== null) return null;
    const keys = Reflect.ownKeys(value);
    if (keys.some((key) => typeof key !== "string" || ![...required, ...optional].includes(key)))
      return null;
    const result = /* @__PURE__ */ Object.create(null);
    for (const key of keys) {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!descriptor || !("value" in descriptor) || !descriptor.enumerable) return null;
      result[key] = descriptor.value;
    }
    return required.every((key) => Object.hasOwn(result, key)) ? result : null;
  }
  function snapshotMaterialCandidate(value) {
    const kind = record(value, ["intent"], ["variant", "deformation", "tone", "tint"]);
    if (kind?.intent === "liquid-glass") {
      const candidate = record(value, ["intent"], ["variant", "deformation", "tint"]);
      if (!candidate) throw new Error("Invalid liquid-glass material intent");
      if (Object.hasOwn(candidate, "variant") && candidate.variant !== "regular" && candidate.variant !== "clear")
        throw new Error("Invalid liquid-glass variant");
      if (Object.hasOwn(candidate, "tint") && candidate.tint !== "style-fill")
        throw new Error("Invalid liquid-glass tint");
      let deformation;
      if (Object.hasOwn(candidate, "deformation")) {
        const data = record(candidate.deformation, ["kind", "phase"], ["contact"]);
        if (data?.kind !== "press" || data.phase !== "rest" && data.phase !== "pressed")
          throw new Error("Invalid finite material deformation");
        if (Object.hasOwn(data, "contact") && data.contact !== "pointer")
          throw new Error("Invalid finite material contact");
        deformation = Object.freeze({
          kind: "press",
          phase: data.phase,
          ...data.contact === "pointer" ? { contact: "pointer" } : {}
        });
      }
      return Object.freeze({
        intent: "liquid-glass",
        ...candidate.variant ? { variant: candidate.variant } : {},
        ...deformation ? { deformation } : {},
        ...candidate.tint === "style-fill" ? { tint: "style-fill" } : {}
      });
    }
    if (kind?.intent === "adaptive-blur") {
      const candidate = record(value, ["intent"], ["tone"]);
      if (!candidate || Object.hasOwn(candidate, "tone") && candidate.tone !== "system" && candidate.tone !== "light" && candidate.tone !== "dark")
        throw new Error("Invalid adaptive-blur material intent");
      return Object.freeze({
        intent: "adaptive-blur",
        ...candidate.tone ? { tone: candidate.tone } : {}
      });
    }
    throw new Error("Unknown material intent");
  }
  function snapshotMaterialSlot(value) {
    const slot = record(value, ["version", "shape", "source", "fallback"]);
    const shape2 = record(slot?.shape, ["kind", "geometry"]);
    const fallback = record(slot?.fallback, ["fill", "foreground"]);
    if (slot?.version !== 2 || shape2?.kind !== "rounded-rect" || shape2.geometry !== "style" || fallback?.fill !== "style" || fallback.foreground !== "style")
      throw new Error("Invalid material slot");
    const source = record(slot.source, ["kind"], ["slot"]);
    let copy;
    if (source?.kind === "owned-scene" && typeof source.slot === "string" && /^[a-zA-Z][a-zA-Z0-9_-]{0,63}$/.test(source.slot)) {
      copy = Object.freeze({ kind: "owned-scene", slot: source.slot });
    } else if (source && !Object.hasOwn(source, "slot") && (source.kind === "in-app-backdrop" || source.kind === "behind-window")) {
      copy = Object.freeze({ kind: source.kind });
    } else throw new Error("Invalid material source request");
    return Object.freeze({
      version: 2,
      shape: Object.freeze({ kind: "rounded-rect", geometry: "style" }),
      source: copy,
      fallback: Object.freeze({ fill: "style", foreground: "style" })
    });
  }

  // packages/core/src/resident-motion.ts
  function snapshotResidentMotion(value) {
    const fail3 = () => {
      throw new Error("[feedback.motion] Invalid declaration");
    };
    const field2 = (object2, key) => {
      const descriptor = Object.getOwnPropertyDescriptor(object2, key);
      if (!descriptor || !("value" in descriptor)) return fail3();
      return descriptor.value;
    };
    if (!value || typeof value !== "object") return fail3();
    const dense3 = (input) => {
      if (!Array.isArray(input)) return fail3();
      return Array.from({ length: input.length }, (_, i) => field2(input, String(i)));
    };
    const properties = dense3(field2(value, "properties"));
    const easing = dense3(field2(value, "easing"));
    const durationMs = field2(value, "durationMs");
    if (!properties.length || new Set(properties).size !== properties.length || properties.some((p) => p !== "translate" && p !== "background-color") || typeof durationMs !== "number" || !Number.isFinite(durationMs) || durationMs < 0 || easing.length !== 4 || easing.some((n) => typeof n !== "number" || !Number.isFinite(n)) || easing[0] < 0 || easing[0] > 1 || easing[2] < 0 || easing[2] > 1)
      return fail3();
    return Object.freeze({
      properties: Object.freeze(properties),
      durationMs,
      easing: Object.freeze(easing)
    });
  }

  // packages/core/src/presence-presentation.ts
  var fail = () => {
    throw new Error("[feedback.presence] Invalid declaration");
  };
  function object(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return fail();
    return value;
  }
  function field(value, key) {
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor || !("value" in descriptor)) return fail();
    return descriptor.value;
  }
  function shape(value, allowed, required = allowed) {
    const result = object(value);
    if (Reflect.ownKeys(result).some((key) => typeof key !== "string" || !allowed.includes(key)))
      return fail();
    for (const key of required) field(result, key);
    return result;
  }
  function finite(value) {
    if (typeof value !== "number" || !Number.isFinite(value)) return fail();
    return value;
  }
  function nonnegative(value) {
    const n = finite(value);
    if (n < 0) return fail();
    return n;
  }
  function integer(value) {
    const n = nonnegative(value);
    if (!Number.isSafeInteger(n)) return fail();
    return n;
  }
  function dense(value, length) {
    if (!Array.isArray(value) || value.length !== length || Reflect.ownKeys(value).some(
      (key) => key !== "length" && !Array.from({ length }, (_, i) => String(i)).includes(key)
    ))
      return fail();
    return Array.from({ length }, (_, i) => field(value, String(i)));
  }
  function affine(value) {
    const v = shape(value, ["px", "rootText", "ownBox"]);
    return Object.freeze({
      px: finite(field(v, "px")),
      rootText: finite(field(v, "rootText")),
      ownBox: finite(field(v, "ownBox"))
    });
  }
  function translation(value) {
    const pair = dense(value, 2);
    return Object.freeze([affine(pair[0]), affine(pair[1])]);
  }
  function selectedTranslation(value) {
    if (Array.isArray(value)) return translation(value);
    const v = shape(value, ["source", "cases"]);
    const source = object(field(v, "source"));
    const input = object(field(v, "cases"));
    const keys = Reflect.ownKeys(input);
    if (!keys.length || keys.some((key) => typeof key !== "string")) return fail();
    const cases = /* @__PURE__ */ Object.create(null);
    for (const key of keys) cases[key] = translation(field(input, key));
    return Object.freeze({ source, cases: Object.freeze(cases) });
  }
  function endpoint(value) {
    const v = shape(value, ["translate", "opacity", "blockSize"], []);
    const keys = Reflect.ownKeys(v);
    if (!keys.length) return fail();
    const result = {};
    if (keys.includes("translate")) result.translate = selectedTranslation(field(v, "translate"));
    if (keys.includes("opacity")) {
      const opacity = finite(field(v, "opacity"));
      if (opacity < 0 || opacity > 1) return fail();
      result.opacity = opacity;
    }
    if (keys.includes("blockSize")) {
      const size = field(v, "blockSize");
      result.blockSize = size === "intrinsic" ? size : nonnegative(size);
    }
    return Object.freeze(result);
  }
  function snapshotPresencePresentation(value) {
    const v = shape(value, ["owner", "closed", "entered", "easing"]);
    const owner = object(field(v, "owner"));
    const closed = endpoint(field(v, "closed"));
    const entered = endpoint(field(v, "entered"));
    if (Object.keys(closed).some((key) => !Object.hasOwn(entered, key)) || Object.keys(closed).length !== Object.keys(entered).length)
      return fail();
    const easing = dense(field(v, "easing"), 4).map(finite);
    if (easing[0] < 0 || easing[0] > 1 || easing[2] < 0 || easing[2] > 1) return fail();
    return Object.freeze({
      owner,
      closed,
      entered,
      easing: Object.freeze(easing)
    });
  }
  function snapshotPresentationOwnerFrame(value) {
    const v = shape(value, [
      "owner",
      "revision",
      "phase",
      "attempt",
      "completion",
      "durationMs",
      "timeoutMs"
    ]);
    const owner = object(field(v, "owner"));
    const revision = integer(field(v, "revision"));
    const phase = field(v, "phase");
    if (!["closed", "preparing", "entering", "entered", "leaving"].includes(phase)) return fail();
    const completion = field(v, "completion");
    if (completion !== "timer" && completion !== "presentation") return fail();
    const durationMs = nonnegative(field(v, "durationMs"));
    const timeout = field(v, "timeoutMs");
    const timeoutMs = timeout === null ? null : finite(timeout);
    if (completion === "timer" && timeoutMs !== null || completion === "presentation" && (timeoutMs === null || timeoutMs <= 0))
      return fail();
    const rawAttempt = field(v, "attempt");
    let attempt = null;
    if (rawAttempt !== null) {
      const a = shape(rawAttempt, ["ownerEpoch", "phaseAttempt"]);
      attempt = Object.freeze({
        ownerEpoch: integer(field(a, "ownerEpoch")),
        phaseAttempt: integer(field(a, "phaseAttempt"))
      });
    }
    if ((phase === "entering" || phase === "leaving") !== (attempt !== null)) return fail();
    return Object.freeze({ owner, revision, phase, attempt, completion, durationMs, timeoutMs });
  }

  // packages/core/src/shader-presentation.ts
  var SHADER_PRESENTATION_LIMITS = Object.freeze({
    maxExtent: 1024,
    maxTexels: 262144,
    maxPasses: 16,
    maxResourceBytes: 16 * 1024 * 1024
  });
  function fail2(message) {
    throw new TypeError(`[feedback.material.shader] ${message}`);
  }
  function fields(value, required, optional = []) {
    if (!value || typeof value !== "object" || Array.isArray(value))
      return fail2("own data record required");
    const prototype = Object.getPrototypeOf(value);
    if (prototype !== Object.prototype && prototype !== null) return fail2("plain record required");
    const keys = Reflect.ownKeys(value);
    const result = /* @__PURE__ */ Object.create(null);
    for (const key of keys) {
      if (typeof key !== "string" || !required.includes(key) && !optional.includes(key))
        return fail2("unknown field");
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!descriptor || !descriptor.enumerable || !("value" in descriptor))
        return fail2("own enumerable data required");
      result[key] = descriptor.value;
    }
    if (required.some((key) => !Object.hasOwn(result, key))) return fail2("missing field");
    return result;
  }
  function dense2(value, expected) {
    if (!Array.isArray(value) || value.length !== expected)
      return fail2("dense array length mismatch");
    if (Object.getPrototypeOf(value) !== Array.prototype) return fail2("plain array required");
    const keys = Reflect.ownKeys(value);
    if (keys.length !== expected + 1) return fail2("dense own data array required");
    const result = [];
    for (let i = 0; i < expected; i++) {
      const entry = Object.getOwnPropertyDescriptor(value, String(i));
      if (!entry || !entry.enumerable || !("value" in entry))
        return fail2("array accessors or holes are unsupported");
      result.push(entry.value);
    }
    return result;
  }
  function integer2(value, min, max) {
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < min || value > max)
      return fail2("integer outside resource budget");
    return value;
  }
  function color(value, opaque = false) {
    const values = dense2(value, 4).map((value2) => {
      if (typeof value2 !== "number" || !Number.isFinite(value2) || value2 < 0 || value2 > 1)
        return fail2("finite RGBA channels in [0,1] required");
      return value2;
    });
    if (opaque && values[3] !== 1) return fail2("opaque fallback required");
    return Object.freeze(values);
  }
  function snapshotShaderPresentation(value) {
    const declaration = fields(value, ["version", "source", "passes", "output", "fallback"]);
    if (declaration.version !== 1) return fail2("unsupported graph version");
    const source = fields(declaration.source, [
      "kind",
      "width",
      "height",
      "pixels",
      "colorSpace",
      "alpha",
      "origin"
    ]);
    if (source.kind !== "owned-pixels" || source.colorSpace !== "linear-srgb" || source.alpha !== "premultiplied" || source.origin !== "top-left")
      return fail2("unsupported source contract");
    const width = integer2(source.width, 1, SHADER_PRESENTATION_LIMITS.maxExtent);
    const height = integer2(source.height, 1, SHADER_PRESENTATION_LIMITS.maxExtent);
    const texels = width * height;
    if (texels > SHADER_PRESENTATION_LIMITS.maxTexels) return fail2("source texel budget exceeded");
    if (!Array.isArray(declaration.passes)) return fail2("ordered passes required");
    const count = integer2(declaration.passes.length, 1, SHADER_PRESENTATION_LIMITS.maxPasses);
    if ((count + 1) * texels * 4 > SHADER_PRESENTATION_LIMITS.maxResourceBytes)
      return fail2("resource byte budget exceeded");
    const pixels = dense2(source.pixels, texels * 4).map((value2) => integer2(value2, 0, 255));
    for (let offset = 0; offset < pixels.length; offset += 4)
      if (pixels.slice(offset, offset + 3).some((channel) => channel > pixels[offset + 3]))
        return fail2("source RGB must be premultiplied by alpha");
    const written = /* @__PURE__ */ new Set(["$source"]);
    const passes = dense2(declaration.passes, count).map((value2) => {
      const pass = fields(value2, ["id", "kernel", "input"], ["tint"]);
      if (typeof pass.id !== "string" || !/^[a-zA-Z][a-zA-Z0-9_-]{0,63}$/.test(pass.id) || written.has(pass.id))
        return fail2("distinct finite pass ID required");
      if (typeof pass.input !== "string" || !written.has(pass.input))
        return fail2("pass input must be a previously produced resource");
      if (pass.kernel !== "copy-rgba8-v1" && pass.kernel !== "tint-rgba8-v1")
        return fail2("unsupported audited kernel");
      if (pass.kernel === "copy-rgba8-v1" && Object.hasOwn(pass, "tint"))
        return fail2("copy does not accept tint");
      if (pass.kernel === "tint-rgba8-v1" && !Object.hasOwn(pass, "tint"))
        return fail2("tint requires its complete uniform");
      const copy = Object.freeze({
        id: pass.id,
        kernel: pass.kernel,
        input: pass.input,
        ...pass.kernel === "tint-rgba8-v1" ? { tint: color(pass.tint) } : {}
      });
      written.add(pass.id);
      return copy;
    });
    if (declaration.output !== passes.at(-1).id)
      return fail2("output must name the final ordered pass");
    return Object.freeze({
      version: 1,
      source: Object.freeze({
        kind: "owned-pixels",
        width,
        height,
        pixels: Object.freeze(pixels),
        colorSpace: "linear-srgb",
        alpha: "premultiplied",
        origin: "top-left"
      }),
      passes: Object.freeze(passes),
      output: declaration.output,
      fallback: color(declaration.fallback, true)
    });
  }

  // packages/adapters/base/src/host/synchronous-steps.ts
  function runAllSteps(steps) {
    let failed = false;
    let firstError;
    for (const step of steps) {
      try {
        step();
      } catch (error) {
        if (!failed) {
          failed = true;
          firstError = error;
        }
      }
    }
    if (failed) throw firstError;
  }

  // packages/adapters/base/src/motion/web-motion-style-ownership.ts
  function createWebMotionStyleOwnership(el, onLoss) {
    const baseline = /* @__PURE__ */ new Map();
    const writes = /* @__PURE__ */ new Map();
    const lost = /* @__PURE__ */ new Set();
    const read3 = (name) => ({
      value: el.style.getPropertyValue(name),
      priority: el.style.getPropertyPriority(name)
    });
    const restore = (name) => {
      const before = baseline.get(name);
      if (before.value) el.style.setProperty(name, before.value, before.priority);
      else el.style.removeProperty(name);
    };
    const owned = (name, value) => el.style.getPropertyValue(name) === value.value && el.style.getPropertyPriority(name) === value.priority;
    const detectLoss = () => {
      for (const [name, value] of writes)
        if (!owned(name, value)) {
          lost.add(name);
          writes.delete(name);
          baseline.delete(name);
          onLoss?.(name);
        }
    };
    const clear = () => {
      for (const [name, value] of writes) if (owned(name, value)) restore(name);
      writes.clear();
      baseline.clear();
    };
    const write = (name, value) => {
      detectLoss();
      if (lost.has(name)) return false;
      if (value === void 0) {
        const old = writes.get(name);
        if (old !== void 0 && owned(name, old)) restore(name);
        writes.delete(name);
        baseline.delete(name);
        return true;
      }
      if (!baseline.has(name)) baseline.set(name, read3(name));
      el.style.setProperty(name, value);
      writes.set(name, read3(name));
      return true;
    };
    return { writes, lost, owned, detectLoss, clear, write };
  }
  function webMotionAncestors(el) {
    const result = [];
    let node = el;
    while (node) {
      result.push(node);
      const root = node.getRootNode();
      node = node.parentElement ?? ("host" in root ? root.host : null);
    }
    return result;
  }

  // packages/modules/base/src/system-caps.ts
  var SYS_CAP = cap("@proto.ui/__sys");

  // packages/modules/base/src/module-base.ts
  var ModuleBase = class {
    protoPhase = "setup";
    instancePhase = "setup";
    mountPhase = "detached";
    caps;
    pending = [];
    constructor(caps) {
      this.caps = caps;
      this.caps.onChange((epoch) => {
        this.onCapsEpoch(epoch);
        this.flushPending();
      });
    }
    get sys() {
      return this.caps.get(SYS_CAP);
    }
    onProtoPhase(phase) {
      this.protoPhase = phase;
    }
    onInstancePhase(phase) {
      this.instancePhase = phase;
    }
    onMountPhase(phase, _epoch) {
      this.mountPhase = phase;
    }
    onCapsEpoch(_epoch) {
    }
    defer(fn) {
      this.pending.push(fn);
    }
    flushPending() {
      if (this.pending.length === 0) return;
      const tasks = this.pending;
      this.pending = [];
      for (const t of tasks) t();
    }
  };

  // packages/modules/base/src/create-module.ts
  function defineModule(def) {
    return def;
  }
  function createModule(args) {
    const { facade, hooks, port } = args.build({
      init: args.init,
      caps: args.caps,
      deps: args.deps
    });
    return {
      name: args.name,
      scope: args.scope,
      facade,
      hooks: hooks ?? {},
      port
    };
  }

  // packages/modules/positioning/src/caps.ts
  var ANCHORED_POSITION_HOST_CAP = cap(
    "@proto.ui/positioning/anchoredHost"
  );
  var AVAILABLE_SPACE_HOST_CAP = cap(
    "@proto.ui/positioning/availableSpaceHost"
  );
  var CONTEXT_MENU_INPUT_HOST_CAP = cap(
    "@proto.ui/positioning/contextMenuInputHost"
  );
  var CONTEXT_MENU_INPUT_RUN_IN_CALLBACK_CAP = cap(
    "@proto.ui/positioning/contextMenuInputCallback"
  );

  // packages/modules/positioning/src/context-menu-input.ts
  var ContextMenuInputModuleImpl = class extends ModuleBase {
    constructor(caps, anatomy) {
      super(caps);
      this.anatomy = anatomy;
    }
    declared = false;
    binding = null;
    disabled = true;
    listener = null;
    subscriptions = [];
    lease = null;
    host = null;
    target = null;
    epoch = 0;
    disposed = false;
    declare() {
      this.sys.ensureSetup("contextMenuInput.declare");
      if (this.declared)
        throw new Error("[ContextMenuInput] One input may be declared per instance.");
      this.declared = true;
      return Object.freeze({
        configure: (binding) => {
          this.sys.ensureSetup("contextMenuInput.configure");
          if (this.binding)
            throw new Error("[ContextMenuInput] Input anatomy is already configured.");
          if (!binding.anatomy.decl.roles[binding.inputRole])
            throw new Error("[ContextMenuInput] Input role must belong to the anatomy family.");
          this.binding = Object.freeze({ ...binding });
          this.subscriptions.push(this.anatomy.subscribeOrder(binding.anatomy, () => this.refresh()));
          this.subscriptions.push(
            this.anatomy.subscribeTargets(binding.anatomy, () => this.refresh())
          );
        },
        on: (listener) => {
          this.sys.ensureSetup("contextMenuInput.on");
          if (this.listener)
            throw new Error("[ContextMenuInput] Input listener is already configured.");
          this.listener = listener;
        },
        sync: ({ disabled }) => {
          this.sys.ensureCallback("contextMenuInput.sync");
          if (this.disabled === disabled) return;
          this.disabled = disabled;
          this.refresh();
        }
      });
    }
    resolveTarget() {
      const binding = this.binding;
      if (!binding || this.anatomy.resolveSelfRole(binding.anatomy) !== binding.inputRole)
        return null;
      const self = this.anatomy.resolveSelfInstance();
      const part = this.anatomy.order.partsOf(binding.anatomy, binding.inputRole, { missing: "empty" }).find((part2) => this.anatomy.resolvePartInstance(part2) === self);
      return part ? this.anatomy.resolvePartTarget(part) : null;
    }
    onCapsEpoch() {
      this.refresh();
    }
    onMountPhase(phase, epoch) {
      super.onMountPhase(phase, epoch);
      this.refresh();
    }
    inCallback(callback) {
      if (this.sys.getCallbackCtx()) callback();
      else this.caps.get(CONTEXT_MENU_INPUT_RUN_IN_CALLBACK_CAP)(callback);
    }
    refresh() {
      if (this.disposed) return;
      const host = this.caps.has(CONTEXT_MENU_INPUT_HOST_CAP) ? this.caps.get(CONTEXT_MENU_INPUT_HOST_CAP) : null;
      const target = host && this.mountPhase === "mounted" ? this.resolveTarget() : null;
      if (this.lease && host === this.host && target === this.target) {
        this.lease.update({ disabled: this.disabled });
        return;
      }
      const epoch = this.disconnect();
      if (epoch !== this.epoch || this.disposed || !host || !target || this.mountPhase !== "mounted")
        return;
      this.host = host;
      this.target = target;
      const current = () => epoch === this.epoch && !this.disposed && this.mountPhase === "mounted";
      const lease = host.attach({
        target,
        disabled: this.disabled,
        onIntent: (intent) => {
          if (!current() || this.disabled || !this.listener || this.sys.isDisposed()) return false;
          let accepted = false;
          this.inCallback(() => {
            if (!current() || this.disabled) return;
            const run2 = this.sys.getCallbackCtx();
            if (!run2) throw new Error("[ContextMenuInput] Intent requires callback scope.");
            accepted = this.listener(run2, intent) === true;
          });
          return current() && !this.disabled && accepted;
        },
        scheduleDelay: (durationMs, callback) => {
          let task = { cancel() {
          } };
          if (current())
            this.inCallback(() => {
              task = delay(durationMs, () => {
                if (current()) callback();
              });
            });
          return task;
        }
      });
      if (!current()) lease.dispose();
      else this.lease = lease;
    }
    disconnect() {
      const epoch = ++this.epoch;
      const lease = this.lease;
      this.lease = null;
      this.host = null;
      this.target = null;
      lease?.dispose();
      return epoch;
    }
    dispose() {
      if (this.disposed) return;
      this.disposed = true;
      this.disconnect();
      this.subscriptions.splice(0).forEach((off) => off());
      this.listener = null;
    }
  };

  // packages/modules/positioning/src/available-layout.ts
  var units = ["logical", "root-text", "available", "available-minus-root-text"];
  var finite2 = (value) => typeof value === "number" && Number.isFinite(value);
  var ratio = (value) => finite2(value) && value >= 0 && value <= 1;
  var record2 = (value) => !!value && typeof value === "object";
  function isAvailableLayoutState(value) {
    return record2(value) && typeof value.get === "function";
  }
  var read = (value) => isAvailableLayoutState(value) ? value.get() : value;
  function validLength(value) {
    return record2(value) && units.includes(value.unit) && finite2(value.value) && value.value >= 0 && (value.unit !== "available" || value.value <= 1);
  }
  function validAvailableLayout(value) {
    return record2(value) && ["top", "right", "bottom", "left"].includes(value.edge) && ["intrinsic", "fraction"].includes(value.extent) && ratio(value.fraction) && validLength(value.minimum) && validLength(value.maximum) && ratio(value.displacement);
  }
  function readAvailableLayout(binding, validateDisabled = false) {
    const value = {
      edge: read(binding.edge),
      extent: read(binding.extent),
      fraction: read(binding.fraction ?? 1),
      minimum: binding.minimum ? { unit: read(binding.minimum.unit), value: read(binding.minimum.value) } : { unit: "logical", value: 0 },
      maximum: binding.maximum ? { unit: read(binding.maximum.unit), value: read(binding.maximum.value) } : { unit: "available", value: 1 },
      displacement: binding.displacement ? binding.displacement.get() : 0
    };
    const enabled = read(binding.enabled ?? true);
    if (typeof enabled !== "boolean") return { status: "invalid" };
    if (!enabled && !validateDisabled) return { status: "disabled" };
    if (!validAvailableLayout(value)) return { status: "invalid" };
    return enabled ? { status: "ready", value } : { status: "disabled" };
  }
  function availableLayoutStates(binding) {
    const values = [
      binding.enabled,
      binding.edge,
      binding.extent,
      binding.fraction,
      binding.minimum?.unit,
      binding.minimum?.value,
      binding.maximum?.unit,
      binding.maximum?.value,
      binding.displacement
    ];
    return [...new Set(values.filter(isAvailableLayoutState))];
  }

  // packages/modules/positioning/src/impl.ts
  var PositioningModuleImpl = class extends ModuleBase {
    constructor(caps, statePort) {
      super(caps);
      this.statePort = statePort;
    }
    connection = null;
    lease = null;
    snapshot = null;
    availableConnection = null;
    availableLease = null;
    availableEpoch = 0;
    availableVersion = 0;
    terminal = false;
    connectionVersion = 0;
    dispatchCallback = (callback) => callback();
    setCallbackDispatcher(dispatch) {
      if (!this.terminal) this.dispatchCallback = dispatch;
    }
    layoutBinding = null;
    layoutWatchOffs = [];
    layoutWatchEpoch = 0;
    clearLayoutWatches() {
      this.layoutWatchEpoch++;
      this.layoutWatchOffs.splice(0).forEach((off) => off());
    }
    watchLayout() {
      this.clearLayoutWatches();
      const binding = this.layoutBinding;
      if (!binding || !this.availableConnection) return;
      const handles = availableLayoutStates(binding);
      if (handles.length && !this.statePort)
        throw new Error("[Positioning] layout State observation unavailable.");
      const epoch = this.layoutWatchEpoch;
      const lease = this.availableLease;
      const current = () => !this.terminal && epoch === this.layoutWatchEpoch && this.availableLease === lease && this.layoutBinding === binding;
      try {
        for (const handle of handles) {
          const off = this.statePort.watch(handle, () => {
            if (!current()) return;
            const frame = readAvailableLayout(binding);
            if (current()) lease?.updateLayout?.(frame);
          });
          if (!current()) {
            off();
            return;
          }
          this.layoutWatchOffs.push(off);
        }
      } catch (error) {
        if (epoch === this.layoutWatchEpoch) this.clearLayoutWatches();
        throw error;
      }
    }
    onCapsEpoch() {
      if (this.terminal) return;
      if (this.connection) this.attach(this.connection);
      if (this.availableConnection) this.attachAvailable(this.availableConnection);
    }
    attachAvailable(connection) {
      const version = ++this.availableVersion;
      this.clearLayoutWatches();
      const previous = this.availableLease;
      this.availableLease = null;
      previous?.dispose();
      if (this.terminal || version !== this.availableVersion || this.availableConnection !== connection)
        return;
      const viewEpoch = ++this.availableEpoch;
      if (!this.caps.has(AVAILABLE_SPACE_HOST_CAP)) return;
      const host = this.caps.get(AVAILABLE_SPACE_HOST_CAP);
      if (!host) return;
      if (this.layoutBinding && !host.supportsLayout) {
        throw new Error("[Positioning] Host does not support constrained available layout.");
      }
      const layout = this.layoutBinding ? readAvailableLayout(this.layoutBinding) : void 0;
      if (this.terminal || version !== this.availableVersion || this.availableConnection !== connection)
        return;
      const lease = host.attach({ ...connection, viewEpoch, layout });
      if (this.layoutBinding && !lease.updateLayout) {
        lease.dispose();
        throw new Error("[Positioning] Host lease does not support constrained available layout.");
      }
      if (this.terminal || version !== this.availableVersion || this.availableConnection !== connection)
        lease.dispose();
      else {
        this.availableLease = lease;
        try {
          this.watchLayout();
        } catch (error) {
          if (this.availableLease === lease) {
            this.availableLease = null;
            lease.dispose();
          }
          throw error;
        }
      }
    }
    availableHandle = {
      bindLayout: (binding) => {
        this.sys.ensureSetup("availableSpace.bindLayout");
        if (readAvailableLayout(binding, true).status === "invalid")
          throw new TypeError("[Positioning] Invalid available layout binding.");
        if (this.terminal) return;
        if (this.availableLease && !this.availableLease.updateLayout)
          throw new Error("[Positioning] Host lease does not support constrained available layout.");
        this.layoutBinding = binding;
        const priorLease = this.availableLease;
        try {
          this.watchLayout();
        } catch (error) {
          if (priorLease && this.availableLease === priorLease) {
            this.availableLease = null;
            priorLease.dispose();
          }
          throw error;
        }
        const lease = this.availableLease;
        const epoch = this.layoutWatchEpoch;
        const frame = readAvailableLayout(binding);
        if (!this.terminal && epoch === this.layoutWatchEpoch && this.layoutBinding === binding && this.availableLease === lease)
          lease?.updateLayout?.(frame);
      },
      connect: (connection) => {
        if (this.terminal) return;
        const same3 = this.availableConnection !== null && this.availableConnection.target === connection.target && this.availableConnection.boundary === connection.boundary;
        this.availableConnection = connection;
        if (same3 && this.availableLease) {
          this.availableLease.requestUpdate();
          return;
        }
        this.attachAvailable(connection);
      },
      requestUpdate: () => {
        if (!this.terminal) this.availableLease?.requestUpdate();
      },
      disconnect: () => {
        this.availableVersion++;
        this.availableEpoch++;
        this.clearLayoutWatches();
        const previous = this.availableLease;
        this.availableLease = null;
        this.availableConnection = null;
        previous?.dispose();
      }
    };
    onProtoPhase(phase) {
      super.onProtoPhase(phase);
      if (phase === "updated") this.availableHandle.requestUpdate();
      if (phase === "unmounted") {
        this.terminal = true;
        this.disconnect();
        this.availableHandle.disconnect();
      }
    }
    getHost() {
      return this.caps.has(ANCHORED_POSITION_HOST_CAP) ? this.caps.get(ANCHORED_POSITION_HOST_CAP) : null;
    }
    bridge(connection, version) {
      const current = () => !this.terminal && version === this.connectionVersion && this.connection === connection;
      return {
        ...connection,
        onSizeMatch: (status) => {
          if (!current()) return;
          const resolved = Object.freeze({ ...status });
          this.dispatchCallback(() => {
            if (current()) connection.onSizeMatch?.(resolved);
          });
        },
        onAlignment: (status) => {
          if (!current()) return;
          const resolved = Object.freeze({ ...status });
          this.dispatchCallback(() => {
            if (current()) connection.onAlignment?.(resolved);
          });
        },
        onResolved: (snapshot) => {
          if (!current() || connection.targetAlignment) return;
          const resolved = Object.freeze({ ...snapshot });
          this.dispatchCallback(() => {
            if (!current()) return;
            this.snapshot = resolved;
            connection.onResolved?.(resolved);
          });
        }
      };
    }
    attach(connection) {
      const version = ++this.connectionVersion;
      const previous = this.lease;
      this.lease = null;
      this.snapshot = null;
      previous?.dispose();
      if (this.terminal || version !== this.connectionVersion || this.connection !== connection)
        return;
      const host = this.getHost();
      if (connection.sizeMatch && !host?.supportsSizeMatch) {
        this.bridge(connection, version).onSizeMatch?.({
          status: "unavailable",
          reason: "unsupported-host"
        });
        return;
      }
      if (connection.targetAlignment && !host?.supportsTargetAlignment) {
        this.bridge(connection, version).onAlignment?.({
          status: "unavailable",
          reason: "unsupported-host"
        });
        return;
      }
      if (!host) return;
      const lease = host.attach(this.bridge(connection, version));
      if (this.terminal || version !== this.connectionVersion || this.connection !== connection)
        lease.dispose();
      else this.lease = lease;
    }
    handle = {
      connect: (connection) => {
        if (this.terminal) return;
        const sameTargets = this.connection && Object.is(this.connection.anchor, connection.anchor) && Object.is(this.connection.floating, connection.floating) && Boolean(this.connection.sizeMatch) === Boolean(connection.sizeMatch) && Boolean(this.connection.targetAlignment) === Boolean(connection.targetAlignment);
        this.connection = connection;
        if (connection.targetAlignment) this.snapshot = null;
        if (sameTargets && this.lease) {
          this.lease.update(this.bridge(connection, ++this.connectionVersion));
          return;
        }
        this.snapshot = null;
        this.attach(connection);
      },
      update: (config) => {
        if (this.terminal || !this.connection) return;
        this.connection = { ...this.connection, config };
        if (this.lease) {
          this.lease.update(this.bridge(this.connection, ++this.connectionVersion));
          return;
        }
        this.attach(this.connection);
      },
      requestUpdate: () => {
        if (!this.terminal) this.lease?.requestUpdate();
      },
      disconnect: () => this.disconnect(),
      getSnapshot: () => this.snapshot
    };
    disconnect() {
      this.connectionVersion++;
      const previous = this.lease;
      this.lease = null;
      this.connection = null;
      this.snapshot = null;
      previous?.dispose();
    }
    dispose() {
      this.terminal = true;
      this.disconnect();
      this.availableHandle.disconnect();
      this.dispatchCallback = () => {
      };
    }
  };

  // packages/modules/positioning/src/create.ts
  function createPositioningModule(ctx) {
    const { init, caps, deps } = ctx;
    const impl = new PositioningModuleImpl(caps, deps.requirePort("state"));
    const input = new ContextMenuInputModuleImpl(caps, deps.requirePort("anatomy"));
    return createModule({
      name: "positioning",
      scope: "instance",
      init,
      caps,
      deps,
      build: () => ({
        facade: {
          declareContextMenuInput: () => input.declare(),
          getAnchoredPosition: () => impl.handle,
          getAvailableSpace: () => impl.availableHandle
        },
        port: {
          setCallbackDispatcher: (dispatch) => impl.setCallbackDispatcher(dispatch),
          getAnchoredPosition: () => impl.handle,
          getAvailableSpace: () => impl.availableHandle
        },
        hooks: {
          onProtoPhase: (phase) => impl.onProtoPhase(phase),
          onMountPhase: (phase, epoch) => input.onMountPhase(phase, epoch),
          dispose: () => {
            input.dispose();
            impl.dispose();
          }
        }
      })
    });
  }
  var PositioningModuleDef = defineModule({
    name: "positioning",
    resourceOwnership: "mixed",
    deps: ["anatomy", "state"],
    create: createPositioningModule
  });

  // packages/modules/positioning/src/web/translation-composition.ts
  var entries = /* @__PURE__ */ new WeakMap();
  var read2 = (target) => ({
    value: target.style.getPropertyValue("translate"),
    priority: target.style.getPropertyPriority("translate")
  });
  var equal = (a, b) => a.value === b.value && a.priority === b.priority;
  var zero = { px: 0, rootText: 0, ownBox: 0 };
  var zeroVector = [zero, zero];
  var format = (percent, px, rem) => {
    if (!rem && !px) return percent ? `${percent}%` : "0px";
    if (!rem && !percent) return `${px}px`;
    if (!px && !percent) return `${rem}rem`;
    return `calc(${percent}% + ${px}px + ${rem}rem)`;
  };
  function acquireWebTranslation(target, role) {
    let entry = entries.get(target);
    if (!entry) {
      const baseline = read2(target);
      const computed = target.ownerDocument.defaultView?.getComputedStyle(target).getPropertyValue("translate") ?? "";
      const neutral = (value) => !value || value === "none" || value === "0px" || value === "0px 0px" || value === "0% 0%";
      entry = {
        baseline,
        written: null,
        lost: !neutral(baseline.value) || !neutral(computed),
        values: /* @__PURE__ */ new Map(),
        owners: /* @__PURE__ */ new Map()
      };
      entries.set(target, entry);
    }
    const owner = Object.freeze({});
    let active = true;
    if (entry.owners.has(role)) throw new Error("[translation] Channel already owned");
    entry.owners.set(role, owner);
    const current = () => {
      if (!active || entry.owners.get(role) !== owner || entry.lost) return false;
      if (!equal(read2(target), entry.written ?? entry.baseline)) {
        entry.lost = true;
        return false;
      }
      return true;
    };
    const project = () => {
      if (!current()) return false;
      const layout = entry.values.get("layout") ?? zeroVector, presentation = entry.values.get("presentation") ?? zeroVector;
      const axis = (i) => {
        const px = layout[i].px + presentation[i].px;
        const rem = layout[i].rootText + presentation[i].rootText;
        const percent = (layout[i].ownBox + presentation[i].ownBox) * 100;
        return format(percent, px, rem);
      };
      target.style.setProperty("translate", `${axis(0)} ${axis(1)}`, entry.baseline.priority);
      entry.written = read2(target);
      return true;
    };
    return {
      canWrite: current,
      set(value) {
        if (!current()) return false;
        if (value.some((axis) => ![axis.px, axis.rootText, axis.ownBox].every(Number.isFinite)))
          return false;
        entry.values.set(
          role,
          Object.freeze(value.map((axis) => Object.freeze({ ...axis })))
        );
        return project();
      },
      release() {
        if (!active) return;
        const owns = current();
        entry.values.delete(role);
        entry.owners.delete(role);
        active = false;
        if (owns) {
          if (!entry.owners.size) {
            if (entry.baseline.value)
              target.style.setProperty("translate", entry.baseline.value, entry.baseline.priority);
            else target.style.removeProperty("translate");
            entry.written = null;
          } else {
            const values = [...entry.values.values()];
            const axis = (i) => format(
              values.reduce((sum, v) => sum + v[i].ownBox, 0) * 100,
              values.reduce((sum, v) => sum + v[i].px, 0),
              values.reduce((sum, v) => sum + v[i].rootText, 0)
            );
            target.style.setProperty("translate", `${axis(0)} ${axis(1)}`, entry.baseline.priority);
            entry.written = read2(target);
          }
        }
        if (!entry.owners.size) entries.delete(target);
      }
    };
  }

  // packages/modules/feedback/src/style/owned-decoration-cap.ts
  var OWNED_DECORATION_CAP = cap("@proto.ui/feedback/owned-decoration-fixed-view");

  // packages/modules/feedback/src/presence/controller.ts
  function createPresenceController(options) {
    const owners = /* @__PURE__ */ new Map();
    const writers = /* @__PURE__ */ new Map();
    const sources2 = /* @__PURE__ */ new WeakSet();
    const subscriptions = /* @__PURE__ */ new Set();
    const reasons = /* @__PURE__ */ new Set();
    let declaration = null;
    let sink = null;
    let view = -1;
    let disposed = false;
    let operation = 0;
    const requireOwner = (writer) => {
      const owner = writers.get(writer);
      if (disposed || !owner) throw new Error("[feedback.presence] Unknown or retired owner writer");
      return owner;
    };
    const active = (owner) => !!owner.frame?.attempt && owner.frame.completion === "presentation";
    const isCurrent = (writer, receipt) => {
      const owner = writers.get(writer), frame = owner?.frame;
      return !disposed && !!owner && owner.pending === receipt && !!frame?.attempt && owner.ref === receipt.owner && owner.binding === receipt.viewBinding && frame.revision === receipt.ownerRevision && owner.targetRevision === receipt.targetRevision && frame.attempt.ownerEpoch === receipt.attempt.ownerEpoch && frame.attempt.phaseAttempt === receipt.attempt.phaseAttempt;
    };
    const finish = (owner, binding, outcome, revision, targetRevision) => {
      const frame = owner.frame;
      if (disposed || !frame?.attempt || frame.revision !== revision || owner.targetRevision !== targetRevision || owner.binding !== binding)
        return;
      if (owner.pending && isCurrent(owner.writer, owner.pending)) return;
      const recipe = declaration;
      const receipt = Object.freeze({
        owner: owner.ref,
        attempt: frame.attempt,
        viewBinding: binding,
        ownerRevision: revision,
        targetRevision,
        channels: Object.freeze([
          ...recipe?.closed.translate ? ["translate"] : [],
          ...recipe?.closed.opacity !== void 0 ? ["opacity"] : [],
          ...recipe?.closed.blockSize !== void 0 ? ["blockSize"] : []
        ]),
        outcome
      });
      reasons.add(outcome);
      owner.pending = receipt;
      options.dispatch(() => {
        if (isCurrent(owner.writer, receipt))
          owner.callback?.(options.callbackContext(), Object.freeze({ receipt }));
      });
    };
    const resolve = (endpoint2) => {
      let translate;
      if (endpoint2.translate) {
        if (Array.isArray(endpoint2.translate)) translate = endpoint2.translate;
        else {
          const selection = endpoint2.translate;
          const value = selection.source.get();
          if (typeof value !== "string" || !Object.hasOwn(selection.cases, value)) return null;
          translate = selection.cases[value];
        }
      }
      return Object.freeze({
        ...translate ? { translate } : {},
        ...endpoint2.opacity !== void 0 ? { opacity: endpoint2.opacity } : {},
        ...endpoint2.blockSize !== void 0 ? { blockSize: endpoint2.blockSize } : {}
      });
    };
    const release = (advance = true) => {
      if (advance) operation++;
      const old = sink, oldView = view;
      sink = null;
      for (const owner of owners.values()) {
        owner.binding = null;
        owner.pending = null;
        owner.targetKey = null;
      }
      old?.release(oldView);
    };
    const facade = {
      registerSource(source) {
        options.setup("feedback.presence.registerSource");
        sources2.add(source);
      },
      owner() {
        options.setup("def.feedback.presence.owner");
        const ref = Object.freeze({}), writer = Object.freeze({});
        const owner = {
          ref,
          writer,
          frame: null,
          callback: null,
          binding: null,
          targetRevision: 0,
          targetKey: null,
          pending: null
        };
        owners.set(ref, owner);
        writers.set(writer, owner);
        return Object.freeze({
          ref,
          writer,
          onCompletionRequest(callback) {
            options.setup("def.feedback.presence.owner.onCompletionRequest");
            if (typeof callback !== "function" || owner.callback)
              throw new Error("[feedback.presence] One completion receiver is required");
            owner.callback = callback;
          }
        });
      },
      publish(writer, value) {
        options.runtime("run.feedback.presence.publish");
        const owner = requireOwner(writer);
        const frame = snapshotPresentationOwnerFrame(value);
        if (frame.owner !== owner.ref || owner.frame && frame.revision <= owner.frame.revision)
          throw new Error("[feedback.presence] Foreign owner or nonmonotonic revision");
        owner.pending = null;
        owner.frame = frame;
        options.invalidate();
      },
      isCurrent,
      settle(writer, outcome) {
        options.runtime("run.feedback.presence.settle");
        const owner = requireOwner(writer);
        if (!active(owner)) return;
        if (declaration?.owner === owner.ref && sink) {
          sink.settle(outcome);
          return;
        }
        owner.binding ??= Object.freeze({});
        finish(
          owner,
          owner.binding,
          outcome === "finished" ? "missing-capability" : outcome,
          owner.frame.revision,
          owner.targetRevision
        );
      }
    };
    return {
      facade,
      declare(value) {
        options.setup("def.feedback.style.presence");
        if (disposed || declaration)
          throw new Error("[feedback.presence] One declaration per surface");
        const copy = snapshotPresencePresentation(value);
        if (!owners.has(copy.owner)) throw new Error("[feedback.presence] Unknown owner reference");
        const sourceSet = /* @__PURE__ */ new Set();
        for (const endpoint2 of [copy.closed, copy.entered]) {
          if (endpoint2.translate && !Array.isArray(endpoint2.translate)) {
            const source = endpoint2.translate.source;
            if (!sources2.has(source))
              throw new Error("[feedback.presence] Unknown selection State reference");
            sourceSet.add(source);
          }
        }
        const installed = [];
        try {
          for (const source of sourceSet) {
            const off = options.watch(source, options.invalidate);
            installed.push(off);
            subscriptions.add(off);
          }
        } catch (error) {
          for (const off of installed) {
            subscriptions.delete(off);
            off();
          }
          throw error;
        }
        declaration = copy;
        options.invalidate();
        return () => {
          options.setup("def.feedback.style.presence:dispose");
          if (declaration !== copy) return;
          declaration = null;
          for (const off of installed) {
            subscriptions.delete(off);
            off();
          }
          options.invalidate();
        };
      },
      get declared() {
        return !!declaration;
      },
      commit(style, epoch, revision) {
        if (disposed || !declaration) return false;
        const owner = owners.get(declaration.owner);
        if (!owner.frame) {
          options.fallback(style);
          return true;
        }
        const op = ++operation, recipe = declaration, ownerFrame = owner.frame;
        if (epoch !== view) {
          release(false);
          if (disposed || operation !== op || declaration !== recipe || owner.frame !== ownerFrame)
            return true;
          view = epoch;
        }
        const current = () => !disposed && operation === op && declaration === recipe && owner.frame === ownerFrame;
        const closed = resolve(declaration.closed), entered = resolve(declaration.entered);
        if (!current()) return true;
        const targetKey = JSON.stringify([closed, entered, recipe.easing]);
        if (targetKey !== owner.targetKey) {
          owner.targetKey = targetKey;
          owner.targetRevision++;
          owner.pending = null;
        }
        const targetRevision = owner.targetRevision;
        const nextSink = options.sink();
        if (!current()) return true;
        if (nextSink !== sink) {
          const old = sink;
          sink = null;
          owner.binding = null;
          owner.pending = null;
          old?.release(view);
          if (!current()) return true;
          sink = nextSink;
        }
        if (!closed || !entered || !sink) {
          sink?.cancel();
          if (!current()) return true;
          options.fallback(style);
          if (!current()) return true;
          if (active(owner)) {
            owner.binding ??= Object.freeze({});
            finish(
              owner,
              owner.binding,
              !closed || !entered ? "unresolved-input" : "missing-capability",
              owner.frame.revision,
              targetRevision
            );
          }
          return true;
        }
        const frame = owner.frame, sinkAtCommit = sink;
        sink.commit(
          Object.freeze({
            view: epoch,
            revision,
            targetRevision,
            style,
            owner: frame,
            closed,
            entered,
            easing: declaration.easing,
            bind(binding) {
              if (!disposed && sink === sinkAtCommit && owner.frame === frame && owner.targetRevision === targetRevision)
                owner.binding = binding;
            },
            complete(binding, outcome) {
              if (sink === sinkAtCommit)
                finish(owner, binding, outcome, frame.revision, targetRevision);
            }
          })
        );
        return true;
      },
      release,
      dispose() {
        if (disposed) return;
        disposed = true;
        let failed = false;
        let error;
        const cleanup = (callback) => {
          try {
            callback();
          } catch (failure) {
            if (!failed) {
              failed = true;
              error = failure;
            }
          }
        };
        const unsubs = [...subscriptions];
        subscriptions.clear();
        declaration = null;
        cleanup(release);
        for (const off of unsubs) cleanup(off);
        owners.clear();
        writers.clear();
        if (failed) throw error;
      },
      diagnostics: () => Object.freeze([...reasons, ...sink?.diagnostics?.() ?? []])
    };
  }

  // packages/modules/feedback/src/style/owned-decoration-registry.ts
  var OwnedDecorationRegistryModel = class {
    phase = "declaring";
    binding = false;
    generation = 0;
    targets = /* @__PURE__ */ new Map();
    contributions = /* @__PURE__ */ new Map();
    isDisposed() {
      return this.phase === "disposed";
    }
    live() {
      if (this.phase === "disposed") throw new Error("owned-decoration: disposed");
    }
    declaring() {
      this.live();
      if (this.phase !== "declaring") throw new Error("owned-decoration: declarations closed");
    }
    bindable() {
      this.live();
      if (this.phase !== "declaring" && this.phase !== "suspended")
        throw new Error("owned-decoration: declarations closed");
    }
    target(identity) {
      this.live();
      const value = this.targets.get(identity);
      if (!value) throw new Error("owned-decoration: foreign or unknown target");
      return value;
    }
    contribution(identity) {
      this.live();
      const value = this.contributions.get(identity);
      if (!value) throw new Error("owned-decoration: foreign or unknown contribution");
      return value;
    }
    declareTarget() {
      this.declaring();
      const identity = Object.freeze({});
      this.targets.set(identity, { revision: 0 });
      return identity;
    }
    /** Stable declaration order, not update arrival order, determines precedence. */
    declareContribution(target, origin) {
      this.declaring();
      this.target(target);
      if (origin !== "setup" && origin !== "rule") throw new Error("owned-decoration: origin");
      const identity = Object.freeze({});
      this.contributions.set(identity, { target, origin, handles: [] });
      return identity;
    }
    replace(identity, ...handles) {
      const owner = this.contribution(identity);
      const copied = handles.map((h) => {
        if (!h || h.kind !== "tw" || !Array.isArray(h.tokens))
          throw new Error("owned-decoration: invalid style handle");
        return { kind: "tw", tokens: [...h.tokens] };
      });
      const validation = new FeedbackStyleRecorder();
      validation.use(...copied);
      this.contribution(identity);
      owner.handles = copied;
      if (this.phase === "bound") this.publish(owner.target);
    }
    withdraw(identity) {
      this.replace(identity);
    }
    snapshot(target) {
      this.target(target);
      const recorder = new FeedbackStyleRecorder();
      for (const origin of ["setup", "rule"])
        for (const item of this.contributions.values()) {
          if (item.target !== target || item.origin !== origin) continue;
          if (origin === "setup") recorder.use(...item.handles);
          else recorder.useRuntime(...item.handles);
        }
      return Object.freeze({ kind: "tw", tokens: Object.freeze(recorder.export().tokens) });
    }
    /**
     * Validate the entire required set before invoking ANY callback. Adapters
     * independently prove physical ownership. A live bound lease cannot rebind;
     * explicit suspension permits a new complete lease for the same logical set.
     */
    bindAll(bindings) {
      this.bindable();
      const generation = this.generation;
      if (this.binding) throw new Error("owned-decoration: reentrant binding");
      this.binding = true;
      try {
        const checked = /* @__PURE__ */ new Map();
        for (const binding of bindings) {
          const target = binding.target;
          const sink = binding.sink;
          this.target(target);
          if (checked.has(target)) throw new Error("owned-decoration: duplicate binding");
          if (typeof sink !== "function") throw new Error("owned-decoration: unsupported sink");
          checked.set(target, sink);
        }
        this.bindable();
        if (generation !== this.generation)
          throw new Error("owned-decoration: stale binding generation");
        if (checked.size !== this.targets.size) throw new Error("owned-decoration: unbound target");
        for (const [identity, sink] of checked) this.targets.get(identity).sink = sink;
        this.phase = "bound";
      } finally {
        this.binding = false;
      }
      this.flush();
      if (generation !== this.generation || this.phase !== "bound")
        throw new Error("owned-decoration: binding generation retired");
    }
    /** Revoke physical leases while preserving owner-lived targets and contributions. */
    suspendBindings() {
      this.live();
      this.generation += 1;
      for (const target of this.targets.values()) {
        target.sink = void 0;
        target.published = void 0;
        target.revision += 1;
      }
      this.phase = "suspended";
    }
    publish(identity) {
      const target = this.target(identity);
      if (this.phase !== "bound" || !target.sink) throw new Error("owned-decoration: unbound target");
      const value = this.snapshot(identity);
      const key = JSON.stringify(value.tokens);
      if (target.published === key) return;
      const previous = target.published;
      const revision = ++target.revision;
      target.published = key;
      try {
        target.sink(value);
      } catch (error) {
        if (!this.isDisposed() && target.revision === revision) target.published = previous;
        throw error;
      }
    }
    flush() {
      this.live();
      if (this.phase !== "bound") throw new Error("owned-decoration: unbound target");
      const generation = this.generation;
      for (const identity of this.targets.keys()) {
        if (this.phase !== "bound" || this.generation !== generation) break;
        this.publish(identity);
      }
    }
    dispose() {
      if (this.phase === "disposed") return;
      this.phase = "disposed";
      this.generation += 1;
      this.targets.clear();
      this.contributions.clear();
    }
  };

  // packages/modules/feedback/src/presence/sink.ts
  var PRESENCE_PRESENTATION_SINK_CAP = cap(
    "@proto.ui/feedback/presence-presentation-v1"
  );
  var PRESENCE_RUN_IN_CALLBACK_CAP = cap(
    "@proto.ui/feedback/presence-callback-v1"
  );

  // packages/modules/feedback/src/motion/sink.ts
  var RESIDENT_MOTION_SINK_CAP = cap(
    "@proto.ui/feedback/resident-motion-v1"
  );

  // packages/modules/feedback/src/caps.ts
  var EFFECTS_CAP = cap("@proto.ui/feedback/effects");

  // packages/modules/feedback/src/material/shared-sink.ts
  var VISUAL_FEEDBACK_SINK_CAP = cap(
    "@proto.ui/feedback/visual-sink-v2"
  );

  // packages/modules/feedback/src/material/declaration-id.ts
  var OWNED_MATERIAL_ID = "experimental/feedback-material-v1";

  // packages/modules/feedback/src/shader/sink.ts
  var SHADER_PRESENTATION_SINK_CAP = cap(
    "@proto.ui/feedback/shader-presentation-v1"
  );

  // packages/modules/feedback/src/material/runtime-cap.ts
  var MATERIAL_BINDING_FACTORY_CAP = cap(
    "@proto.ui/feedback/experimental-material-runtime"
  );

  // packages/modules/feedback/src/material/final-style-sink.ts
  function snapshotFinalStyle(style) {
    const entries2 = "entries" in style ? style.entries : void 0;
    return Object.freeze({
      kind: "tw",
      tokens: Object.freeze([...style.tokens]),
      ...entries2 ? { entries: Object.freeze(entries2.map((entry) => Object.freeze({ ...entry }))) } : {}
    });
  }
  var FINAL_STYLE_SINK_CAP = cap(
    "@proto.ui/feedback/experimental-final-style-sink"
  );
  function finalStyleFrame(style, view, revision, material = null) {
    return Object.freeze({
      view,
      revision,
      material,
      style: snapshotFinalStyle(style)
    });
  }

  // packages/modules/feedback/src/create.ts
  function createFeedbackModule(ctx) {
    const { init, caps, deps } = ctx;
    return createModule({
      name: "feedback",
      scope: "instance",
      init,
      caps,
      deps,
      build: ({ init: init2, caps: caps2 }) => {
        class Impl extends ModuleBase {
          decoration = new OwnedDecorationRegistryModel();
          decorationRules = /* @__PURE__ */ new Map();
          decorationBound = false;
          decorationTerminal = false;
          decorationLease = null;
          hasDecorationTargets() {
            return this.decorationRules.size > 0;
          }
          captureDecorationLease() {
            if (!this.decorationLease || this.decorationTerminal)
              throw new Error("[feedback] decoration view is not active");
            return this.decorationLease;
          }
          declareDecoration() {
            this.ensureSetup("def.feedback.style.declareDecoration");
            if (!this.caps.has(OWNED_DECORATION_CAP))
              throw new Error("[feedback] owned-decoration unsupported by this adapter");
            const target = this.decoration.declareTarget();
            this.decorationRules.set(target, this.decoration.declareContribution(target, "rule"));
            return target;
          }
          useDecoration(target, handles) {
            this.ensureSetup("def.feedback.style.to.use");
            const owner = this.decoration.declareContribution(target, "setup");
            this.decoration.replace(owner, ...handles);
            return () => {
              this.ensureSetup("def.feedback.style.to.use:dispose");
              this.decoration.withdraw(owner);
            };
          }
          validateDecorationTemplate(targets) {
            if (!targets.length && !this.decorationRules.size) return;
            this.ensureNotDisposed("decoration.template");
            if (!this.caps.has(OWNED_DECORATION_CAP))
              throw new Error("[feedback] owned-decoration unsupported by this adapter");
            if (this.decorationTerminal)
              throw new Error("[feedback] decoration structural rebind unsupported");
            const seen = /* @__PURE__ */ new Set();
            for (const target of targets) {
              this.decoration.snapshot(target);
              if (seen.has(target)) throw new Error("[feedback] duplicate decoration binding");
              seen.add(target);
            }
            if (seen.size !== this.decorationRules.size)
              throw new Error("[feedback] missing decoration binding");
          }
          bindDecorations(bindings, lease) {
            if (!bindings.length && !this.decorationRules.size) return;
            const checkLease = () => {
              if (this.decorationBound)
                throw new Error("[feedback] decoration structural rebind unsupported");
              if (!lease || lease !== this.decorationLease || this.decorationTerminal)
                throw new Error("[feedback] stale decoration view lease");
            };
            checkLease();
            const copied = bindings.map((binding) => ({
              target: binding.target,
              sink: binding.sink
            }));
            for (const binding of copied)
              if (typeof binding.sink !== "function")
                throw new Error("[feedback] invalid decoration sink");
            checkLease();
            this.validateDecorationTemplate(copied.map((binding) => binding.target));
            checkLease();
            this.decorationBound = true;
            this.decoration.bindAll(copied);
          }
          snapshotDecorationFrame(frames) {
            const next = /* @__PURE__ */ new Map();
            for (const frame of frames) {
              const target = frame.target;
              this.decoration.snapshot(target);
              if (next.has(target)) throw new Error("[feedback] duplicate decoration frame");
              const handles = frame.handles.map((h) => ({ kind: h.kind, tokens: [...h.tokens] }));
              const validator = new FeedbackStyleRecorder();
              validator.use(...handles);
              next.set(target, handles);
            }
            return next;
          }
          replaceDecorationFrame(next) {
            if (this.decorationTerminal) {
              if (next.size) throw new Error("[feedback] decoration lifetime ended");
              return;
            }
            for (const [target, owner] of this.decorationRules)
              this.decoration.replace(owner, ...next.get(target) ?? []);
          }
          presence = createPresenceController({
            setup: (op) => this.ensureSetup(op),
            runtime: (op) => {
              this.ensureRuntime(op);
              this.sys?.ensureCallback(op);
            },
            invalidate: () => {
              this.markDirty();
              if (this.sys?.execPhase() === "callback" && this.sys.deferAfterCallback)
                this.sys.deferAfterCallback(() => {
                  if (!this.disposed) this.flushIfPossible();
                });
              else this.flushIfPossible();
            },
            callbackContext: () => this.sys?.getCallbackCtx(),
            dispatch: (callback) => {
              if (this.sys?.execPhase() === "callback") callback();
              else if (this.caps.has(PRESENCE_RUN_IN_CALLBACK_CAP))
                this.caps.get(PRESENCE_RUN_IN_CALLBACK_CAP)(callback);
              else throw new Error("[feedback.presence] Callback scope capability unavailable");
            },
            watch: (source, callback) => {
              const state = deps.tryPort("state");
              if (!state) throw new Error("[feedback.presence] State registry unavailable");
              return state.watch(
                source,
                (_run, event) => {
                  if (event.type === "next") callback();
                }
              );
            },
            sink: () => this.caps.has(PRESENCE_PRESENTATION_SINK_CAP) ? this.caps.get(PRESENCE_PRESENTATION_SINK_CAP) : null,
            fallback: (style) => {
              if (this.caps.has(EFFECTS_CAP)) {
                const effects = this.caps.get(EFFECTS_CAP);
                effects.queueStyle(style);
                effects.requestFlush();
              }
            }
          });
          presenceFacade() {
            return this.presence.facade;
          }
          declarePresence(value) {
            if (this.shaderDeclaration)
              throw new Error("[feedback.shader] Combined presence projection unavailable");
            if (this.motionDeclarations.size)
              throw new Error("[feedback.presence] Resident/presence channel ownership overlap");
            return this.presence.declare(value);
          }
          motionDeclarations = /* @__PURE__ */ new Set();
          motionSink = null;
          motionView = 0;
          declareMotion(declaration) {
            this.ensureSetup("def.feedback.style.transition");
            if (this.shaderDeclaration)
              throw new Error("[feedback.shader] Combined resident motion projection unavailable");
            if (this.presence.declared)
              throw new Error("[feedback.presence] Resident/presence channel ownership overlap");
            const copy = snapshotResidentMotion(declaration);
            if ([...this.motionDeclarations].some(
              (existing) => existing.properties.some((p) => copy.properties.includes(p))
            ))
              throw new Error("[feedback.motion] Overlapping channel declarations");
            this.motionDeclarations.add(copy);
            this.markDirty();
            return () => {
              this.ensureSetup("def.feedback.style.transition:dispose");
              this.motionDeclarations.delete(copy);
              this.markDirty();
            };
          }
          releaseMotionSink() {
            const sink = this.motionSink;
            this.motionSink = null;
            sink?.release(this.motionView);
          }
          recorder = new FeedbackStyleRecorder();
          dirty = false;
          disposed = false;
          viewEpoch = 0;
          visualRevision = 0;
          visualSink = null;
          visualSinkKind = null;
          visualSinkView = 0;
          pendingProjection = null;
          material = null;
          materialFactory = null;
          sharedSlot = null;
          materialContributions = /* @__PURE__ */ new Map();
          shaderDeclaration = null;
          shaderSink = null;
          // Physical shader bindings also change when a capability is replaced
          // within one mounted view. Never reuse a released binding generation.
          shaderSinkView = 0;
          declareShader(declaration) {
            this.ensureSetup("def.feedback.material.shader");
            const available = () => {
              if (this.shaderDeclaration || this.sharedSlot || this.material || init2.declarations.some((item) => item.id === OWNED_MATERIAL_ID))
                throw new Error("[feedback.shader] One material owner per instance");
              if (this.presence.declared || this.motionDeclarations.size)
                throw new Error("[feedback.shader] Combined motion projection unavailable");
            };
            available();
            const owned = snapshotShaderPresentation(declaration);
            available();
            this.shaderDeclaration = owned;
            this.markDirty();
            return () => {
              this.ensureSetup("def.feedback.material.shader:dispose");
              if (this.shaderDeclaration !== owned) return;
              this.shaderDeclaration = null;
              this.markDirty();
            };
          }
          shaderDiagnostics() {
            if (!this.shaderDeclaration) return Object.freeze([]);
            return Object.freeze(
              this.caps.has(SHADER_PRESENTATION_SINK_CAP) ? [...this.shaderSink?.diagnostics?.() ?? []] : ["shader-host-unavailable"]
            );
          }
          releaseShaderSink() {
            const sink = this.shaderSink;
            this.shaderSink = null;
            sink?.release(this.shaderSinkView);
          }
          declareMaterial(slot) {
            this.ensureSetup("def.feedback.material.declare");
            if (this.shaderDeclaration || this.sharedSlot || init2.declarations.some((item) => item.id === OWNED_MATERIAL_ID))
              throw new Error("One material slot per instance; private and shared slots cannot mix");
            const owned = snapshotMaterialSlot(slot);
            this.sharedSlot = owned;
            this.markDirty();
            return () => {
              this.ensureSetup("def.feedback.material.declare:dispose");
              if (this.sharedSlot !== owned) return;
              this.sharedSlot = null;
              this.materialContributions.clear();
              this.markDirty();
            };
          }
          useMaterial(candidate) {
            this.ensureSetup("def.feedback.material.use");
            if (!this.sharedSlot) throw new Error("Declare the material slot before contributing");
            const key = {};
            this.materialContributions.set(key, [snapshotMaterialCandidate(candidate)]);
            this.markDirty();
            return () => {
              this.ensureSetup("def.feedback.material.use:dispose");
              if (this.materialContributions.delete(key)) this.markDirty();
            };
          }
          exportMaterialFrame() {
            return Object.freeze({
              slot: this.sharedSlot,
              candidates: Object.freeze(
                this.sharedSlot ? [...this.materialContributions.values()].flat() : []
              )
            });
          }
          motionDiagnostics() {
            return Object.freeze(
              this.motionDeclarations.size && !this.caps.has(RESIDENT_MOTION_SINK_CAP) ? ["resident-motion-host-unavailable"] : [...this.motionSink?.diagnostics?.() ?? []]
            );
          }
          materialDiagnostics() {
            return Object.freeze(
              this.sharedSlot && !this.caps.has(VISUAL_FEEDBACK_SINK_CAP) ? ["material-host-unavailable"] : []
            );
          }
          replaceVisualRuntime(previous, handles, candidates, decorations = []) {
            this.ensureRuntime("rule.feedback.visual.replace");
            const decorationFrame = this.snapshotDecorationFrame(decorations);
            if (candidates.length && !this.sharedSlot)
              throw new Error("Material Rule requires a declared slot");
            const copied = candidates.map(snapshotMaterialCandidate);
            const unUse = handles.length ? this.recorder.useRuntime(...handles) : null;
            const key = {};
            previous?.({ flush: false });
            if (copied.length) this.materialContributions.set(key, copied);
            this.replaceDecorationFrame(decorationFrame);
            this.markDirty();
            try {
              this.flushIfPossible();
            } catch (error) {
              queueMicrotask(() => {
                throw error;
              });
            }
            if (!unUse && !copied.length && !decorationFrame.size) return null;
            let removed = false;
            return (options = {}) => {
              if (this.disposed || removed) return;
              removed = true;
              unUse?.();
              if (options.flush !== false) this.replaceDecorationFrame(/* @__PURE__ */ new Map());
              this.materialContributions.delete(key);
              this.markDirty();
              if (options.flush !== false) this.flushIfPossible();
            };
          }
          /** setup-only */
          useStyle(handles) {
            this.ensureSetup("def.feedback.style.use");
            const unUse = this.recorder.use(...handles);
            this.markDirty();
            return () => {
              this.ensureSetup("def.feedback.style.unUse");
              unUse();
              this.markDirty();
            };
          }
          /** internal runtime base style contribution, used by rule execution */
          useStyleRuntime(handles) {
            const op = "rule.feedback.style.use";
            this.ensureNotDisposed(op);
            if (this.protoPhase === "setup") {
              throw illegalPhase(op, this.protoPhase, {
                prototypeName: init2.prototypeName,
                hint: `Use 'def' only during setup.`
              });
            }
            const unUse = this.recorder.useRuntime(...handles);
            this.markDirty();
            this.flushIfPossible();
            return this.createRuntimeStyleDisposer(unUse);
          }
          replaceStyleRuntime(previous, handles) {
            const op = "rule.feedback.style.replace";
            this.ensureNotDisposed(op);
            if (this.protoPhase === "setup") {
              throw illegalPhase(op, this.protoPhase, {
                prototypeName: init2.prototypeName,
                hint: `Use 'def' only during setup.`
              });
            }
            previous?.({ flush: false });
            const next = handles.length > 0 ? this.recorder.useRuntime(...handles) : null;
            this.markDirty();
            try {
              this.flushIfPossible();
            } catch (error) {
              if (this.mountPhase === "mounting") {
                next?.();
                this.markDirty();
                throw error;
              }
              queueMicrotask(() => {
                throw error;
              });
            }
            return next ? this.createRuntimeStyleDisposer(next) : null;
          }
          /** runtime-only public patch API */
          patchStyle(handles) {
            const op = "run.feedback.style.patch";
            this.ensureRuntime(op);
            this.recorder.patch(...handles);
            this.markDirty();
            this.flushIfPossible();
          }
          /** runtime-only public suppress API */
          suppressStyle(handles) {
            const op = "run.feedback.style.suppress";
            this.ensureRuntime(op);
            this.recorder.suppress(...handles);
            this.markDirty();
            this.flushIfPossible();
          }
          /** runtime-only public clear API */
          clearStylePatch() {
            const op = "run.feedback.style.clearPatch";
            this.ensureRuntime(op);
            this.recorder.clearPatch();
            this.markDirty();
            this.flushIfPossible();
          }
          /** internal: record tokens without v0 validation (setup or runtime) */
          useStyleUnsafe(handles) {
            this.ensureNotDisposed("feedback.style.useUnsafe");
            const unUse = this.recorder.useUnsafe(...handles);
            this.markDirty();
            this.flushIfPossible();
            return () => {
              if (this.disposed) return;
              unUse();
              this.markDirty();
              this.flushIfPossible();
            };
          }
          /** pure snapshot */
          shouldRetainStyleRule(tokens) {
            if (this.sharedSlot || this.shaderDeclaration || this.motionDeclarations.size)
              return true;
            return this.material !== null && tokens.some((token) => /^(bg-|backdrop-|shadow|rounded|text-)/.test(token));
          }
          exportMerged() {
            const { tokens } = this.recorder.export();
            return { kind: "tw", tokens };
          }
          onProtoPhase(phase) {
            super.onProtoPhase(phase);
            if (phase === "mounted") this.flushIfPossible();
          }
          onInstancePhase(phase) {
            super.onInstancePhase(phase);
            if (phase === "disposing" || phase === "disposed") {
              this.decorationTerminal = true;
              this.decorationLease = null;
              this.decorationBound = false;
              this.decoration.dispose();
            }
          }
          onMountPhase(phase, epoch) {
            if (epoch < this.viewEpoch) return;
            super.onMountPhase(phase, epoch);
            if (phase === "unmounting" || phase === "detached") this.decorationLease = null;
            else if (phase === "mounting" && (epoch > this.viewEpoch || !this.decorationLease))
              this.decorationLease = Object.freeze({});
            if (this.decorationBound && epoch >= this.viewEpoch && (phase === "unmounting" || phase === "detached" || epoch > this.viewEpoch)) {
              this.decorationBound = false;
              this.decoration.suspendBindings();
            }
            const oldEpoch = this.viewEpoch;
            this.viewEpoch = epoch;
            if (phase === "unmounting" || phase === "detached" || epoch !== oldEpoch) {
              this.markDirty();
              try {
                this.releaseVisualSink();
              } finally {
                try {
                  this.releaseMotionSink();
                } finally {
                  try {
                    this.presence.release();
                  } finally {
                    this.releaseShaderSink();
                  }
                }
              }
            }
            if (phase === "mounting") {
              this.ensureMaterialBinding();
              this.material?.connect();
              this.afterRenderCommit();
            }
          }
          onCapsEpoch(_epoch) {
            if (this.disposed) return;
            this.markDirty();
            if (this.shaderSink && (!this.caps.has(SHADER_PRESENTATION_SINK_CAP) || this.shaderSink !== this.caps.get(SHADER_PRESENTATION_SINK_CAP)))
              this.releaseShaderSink();
            this.ensureMaterialBinding();
            if (this.motionSink && (!this.caps.has(RESIDENT_MOTION_SINK_CAP) || this.motionSink !== this.caps.get(RESIDENT_MOTION_SINK_CAP)))
              this.releaseMotionSink();
            const shaderSelected = this.shaderDeclaration && this.caps.has(SHADER_PRESENTATION_SINK_CAP);
            const next = shaderSelected ? null : this.caps.has(VISUAL_FEEDBACK_SINK_CAP) ? this.caps.get(VISUAL_FEEDBACK_SINK_CAP) : this.caps.has(FINAL_STYLE_SINK_CAP) ? this.caps.get(FINAL_STYLE_SINK_CAP) : null;
            const nextKind = shaderSelected ? null : this.caps.has(VISUAL_FEEDBACK_SINK_CAP) ? "visual" : this.caps.has(FINAL_STYLE_SINK_CAP) ? "final" : null;
            this.markDirty();
            if (this.visualSink && (this.visualSink !== next || this.visualSinkKind !== nextKind))
              this.releaseVisualSink();
            this.flushIfPossible();
          }
          hasOutput() {
            return this.shaderDeclaration !== null && this.caps.has(SHADER_PRESENTATION_SINK_CAP) || this.caps.has(PRESENCE_PRESENTATION_SINK_CAP) || this.caps.has(RESIDENT_MOTION_SINK_CAP) || this.caps.has(VISUAL_FEEDBACK_SINK_CAP) || this.caps.has(FINAL_STYLE_SINK_CAP) || this.caps.has(EFFECTS_CAP);
          }
          ensureMaterialBinding() {
            if (!this.caps.has(MATERIAL_BINDING_FACTORY_CAP)) return;
            const factory = this.caps.get(MATERIAL_BINDING_FACTORY_CAP);
            if (this.materialFactory) {
              if (this.materialFactory !== factory)
                throw new Error("Material semantics cannot change within an instance");
              return;
            }
            const material = factory(init2.declarations, deps, () => {
              this.markDirty();
              this.flushIfPossible();
            });
            if (material && this.shaderDeclaration) {
              material.dispose();
              throw new Error("[feedback.shader] One material owner per instance");
            }
            this.material = material;
            this.materialFactory = factory;
            if (this.canProject()) this.material?.connect();
          }
          releaseVisualSink() {
            const sink = this.visualSink;
            const view = this.visualSinkView;
            this.visualSink = null;
            this.visualSinkKind = null;
            if (sink) sink.release(view);
          }
          markDirty() {
            this.dirty = true;
            this.pendingProjection = null;
          }
          projectFinalStyle(handle) {
            const revision = ++this.visualRevision;
            const style = snapshotFinalStyle(handle);
            const pending = { ...style, tokens: [...style.tokens] };
            try {
              if (this.shaderDeclaration && this.caps.has(SHADER_PRESENTATION_SINK_CAP)) {
                this.releaseVisualSink();
                if (this.disposed || revision !== this.visualRevision) return;
                if (!this.caps.has(SHADER_PRESENTATION_SINK_CAP)) {
                  this.markDirty();
                  return;
                }
                const sink = this.caps.get(SHADER_PRESENTATION_SINK_CAP);
                if (this.shaderSink !== sink) {
                  this.shaderSink = sink;
                  this.shaderSinkView = Math.max(this.shaderSinkView + 1, this.viewEpoch);
                }
                sink.commit(
                  Object.freeze({
                    view: this.shaderSinkView,
                    revision,
                    style,
                    declaration: this.shaderDeclaration
                  })
                );
              } else if (this.presence.declared) {
                if (this.sharedSlot || this.material)
                  throw new Error("[feedback.presence] Combined material projection unavailable");
                this.presence.commit(pending, this.viewEpoch, revision);
              } else if (this.motionDeclarations.size && this.caps.has(RESIDENT_MOTION_SINK_CAP)) {
                if (this.sharedSlot || this.material)
                  throw new Error("[feedback.motion] Combined material projection unavailable");
                const sink = this.caps.get(RESIDENT_MOTION_SINK_CAP);
                this.motionSink = sink;
                this.motionView = this.viewEpoch;
                sink.commit(
                  Object.freeze({
                    view: this.viewEpoch,
                    revision,
                    style: pending,
                    declarations: Object.freeze([...this.motionDeclarations])
                  })
                );
              } else if (this.caps.has(VISUAL_FEEDBACK_SINK_CAP)) {
                const sink = this.caps.get(VISUAL_FEEDBACK_SINK_CAP);
                this.visualSink = sink;
                this.visualSinkKind = "visual";
                this.visualSinkView = this.viewEpoch;
                sink.commit(
                  Object.freeze({
                    view: this.viewEpoch,
                    revision,
                    style,
                    material: this.exportMaterialFrame()
                  })
                );
              } else if (this.caps.has(FINAL_STYLE_SINK_CAP)) {
                const sink = this.caps.get(FINAL_STYLE_SINK_CAP);
                this.visualSink = sink;
                this.visualSinkKind = "final";
                this.visualSinkView = this.viewEpoch;
                sink.commit(
                  finalStyleFrame(handle, this.viewEpoch, revision, this.material?.snapshot() ?? null)
                );
              } else {
                const effects = this.caps.get(EFFECTS_CAP);
                effects.queueStyle(handle);
                effects.requestFlush();
              }
              if (revision === this.visualRevision) this.pendingProjection = null;
            } catch (error) {
              if (!this.disposed && revision === this.visualRevision) {
                this.dirty = true;
                this.pendingProjection = pending;
              }
              throw error;
            }
          }
          flushIfPossible() {
            if (this.protoPhase === "setup") return;
            if (!this.canProject()) return;
            if (!this.dirty) return;
            if (!this.hasOutput()) {
              return;
            }
            const merged = this.pendingProjection ?? this.recorder.exportRootEffect();
            this.dirty = false;
            this.projectFinalStyle(merged);
          }
          /** runtime: apply merged style directly (rule / adapter) */
          applyMergedStyle(handle) {
            if (this.protoPhase === "setup" || !this.canProject()) return;
            if (!this.hasOutput()) {
              const epoch = this.viewEpoch;
              this.defer(() => {
                if (!this.disposed && epoch === this.viewEpoch) this.applyMergedStyle(handle);
              });
              return;
            }
            const merged = this.recorder.exportRootEffect(handle);
            this.projectFinalStyle(merged);
          }
          afterRenderCommit() {
            if (!this.canProject()) return;
            if (!this.hasOutput()) return;
            this.projectFinalStyle(this.recorder.exportRootEffect());
          }
          /** optional: runtime/adapter can call this after flush tick */
          onEffectsFlushed() {
            if (!this.canProject()) return;
            if (this.dirty && (this.shaderDeclaration !== null && this.caps.has(SHADER_PRESENTATION_SINK_CAP) || this.caps.has(VISUAL_FEEDBACK_SINK_CAP) || this.caps.has(FINAL_STYLE_SINK_CAP))) {
              this.flushIfPossible();
              return;
            }
            if (this.dirty && this.caps.has(EFFECTS_CAP)) {
              this.caps.get(EFFECTS_CAP).requestFlush();
            }
          }
          dispose() {
            if (this.disposed) return;
            this.disposed = true;
            this.decorationTerminal = true;
            this.decorationLease = null;
            this.decoration.dispose();
            try {
              try {
                try {
                  this.presence.dispose();
                } finally {
                  this.releaseVisualSink();
                }
              } finally {
                try {
                  this.releaseMotionSink();
                } finally {
                  this.releaseShaderSink();
                }
              }
            } finally {
              try {
                this.material?.dispose();
              } finally {
                this.recorder = new FeedbackStyleRecorder();
                this.sharedSlot = null;
                this.shaderDeclaration = null;
                this.materialContributions.clear();
                this.dirty = false;
                this.pendingProjection = null;
                this.flushPending();
              }
            }
          }
          canProject() {
            return !this.disposed && this.instancePhase !== "disposing" && this.instancePhase !== "disposed" && (this.mountPhase === "mounting" || this.mountPhase === "mounted");
          }
          ensureNotDisposed(op) {
            if (this.disposed) throw new Error(`[feedback] disposed. op=${op}`);
            this.sys?.ensureNotDisposed(op);
          }
          ensureSetup(op) {
            this.ensureNotDisposed(op);
            this.sys?.ensureSetup(op);
            if (!this.sys && this.protoPhase !== "setup") {
              throw illegalPhase(op, this.protoPhase, {
                prototypeName: init2.prototypeName,
                hint: `Use 'run' inside runtime callbacks, not 'def'.`
              });
            }
          }
          ensureRuntime(op) {
            this.ensureNotDisposed(op);
            this.sys?.ensureRuntime(op);
            if (!this.sys && this.protoPhase === "setup") {
              throw illegalPhase(op, this.protoPhase, {
                prototypeName: init2.prototypeName,
                hint: `Use 'run' only after setup.`
              });
            }
          }
          createRuntimeStyleDisposer(unUse) {
            return (options = {}) => {
              if (this.disposed) return;
              unUse();
              this.markDirty();
              if (options.flush !== false) this.flushIfPossible();
            };
          }
        }
        const impl = new Impl(caps2);
        const facade = {
          presence: impl.presenceFacade(),
          material: {
            shader: (declaration) => impl.declareShader(declaration),
            declare: (slot) => impl.declareMaterial(slot),
            use: (candidate) => impl.useMaterial(candidate)
          },
          style: {
            declareDecoration: () => impl.declareDecoration(),
            to: (target) => ({ use: (...handles) => impl.useDecoration(target, handles) }),
            hasDecorationTargets: () => impl.hasDecorationTargets(),
            captureDecorationLease: () => impl.captureDecorationLease(),
            validateDecorationTemplate: (targets) => impl.validateDecorationTemplate(targets),
            transition: (declaration) => impl.declareMotion(declaration),
            presence: (declaration) => impl.declarePresence(declaration),
            use: (...handles) => impl.useStyle(handles),
            patch: (...handles) => impl.patchStyle(handles),
            suppress: (...handles) => impl.suppressStyle(handles),
            clearPatch: () => impl.clearStylePatch(),
            exportMerged: () => impl.exportMerged()
          }
        };
        return {
          facade,
          port: {
            supportsOwnedDecoration: true,
            hasDecorationTargets: () => impl.hasDecorationTargets(),
            captureDecorationLease: () => impl.captureDecorationLease(),
            bindDecorations: (bindings, lease) => impl.bindDecorations(bindings, lease),
            replaceVisualRuntime: (previous, handles, candidates, decorations) => impl.replaceVisualRuntime(previous, handles, candidates, decorations),
            exportMaterialFrame: () => impl.exportMaterialFrame(),
            materialDiagnostics: () => impl.materialDiagnostics(),
            shaderDiagnostics: () => impl.shaderDiagnostics(),
            motionDiagnostics: () => impl.motionDiagnostics(),
            shouldRetainStyleRule: (tokens) => impl.shouldRetainStyleRule(tokens),
            applyMergedStyle: (h) => impl.applyMergedStyle(h),
            useStyleRuntime: (...handles) => impl.useStyleRuntime(handles),
            replaceStyleRuntime: (previous, ...handles) => impl.replaceStyleRuntime(previous, handles),
            patchStyle: (...handles) => impl.patchStyle(handles),
            suppressStyle: (...handles) => impl.suppressStyle(handles),
            clearStylePatch: () => impl.clearStylePatch(),
            useStyleUnsafe: (...handles) => impl.useStyleUnsafe(handles)
          },
          hooks: {
            dispose: () => impl.dispose(),
            onInstancePhase: (p) => impl.onInstancePhase(p),
            onMountPhase: (p, epoch) => impl.onMountPhase(p, epoch),
            onProtoPhase: (p) => impl.onProtoPhase(p),
            afterRenderCommit: () => impl.afterRenderCommit(),
            // 非 ModuleHooks 标准字段：先用 any 过渡
            // 后续你若要把它纳入统一的 module driver，就把它变成 port 或标准 hook
            flushIfPossible: () => impl.flushIfPossible(),
            onEffectsFlushed: () => impl.onEffectsFlushed()
          }
        };
      }
    });
  }
  var FeedbackModuleDef = defineModule({
    name: "feedback",
    resourceOwnership: "mixed",
    deps: [],
    optionalDeps: ["expose", "state"],
    create: createFeedbackModule
  });

  // packages/modules/feedback/src/motion/sampler.ts
  var same = (a, b) => a.length === b.length && a.every((v, i) => v === b[i]);
  var snapshotVector = (input) => {
    if (!Array.isArray(input) || !input.length) throw new Error("[feedback.motion] Invalid value");
    const values = [];
    for (let i = 0; i < input.length; i++) {
      const entry = Object.getOwnPropertyDescriptor(input, String(i));
      if (!entry || !("value" in entry) || typeof entry.value !== "number" || !Number.isFinite(entry.value))
        throw new Error("[feedback.motion] Invalid value");
      values.push(entry.value);
    }
    return Object.freeze(values);
  };
  var clamp = (n) => Math.max(0, Math.min(1, n));
  function cubicProgress(x, curve) {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    const cubic = (t, a, b) => 3 * (1 - t) * (1 - t) * t * a + 3 * (1 - t) * t * t * b + t * t * t;
    let lo = 0, hi = 1;
    for (let i = 0; i < 48; i++) {
      const mid = (lo + hi) / 2;
      if (cubic(mid, curve[0], curve[2]) < x) lo = mid;
      else hi = mid;
    }
    return cubic((lo + hi) / 2, curve[1], curve[3]);
  }
  function createResidentMotionSampler(config) {
    config = snapshotResidentMotion({ ...config, properties: ["translate"] });
    let target = null, from = [], reversingStart = [];
    let start = 0, duration = 0, factor = 1, lastTime = -Infinity, active = false, disposed = false;
    function time(now) {
      if (!Number.isFinite(now) || now < lastTime)
        throw new Error("[feedback.motion] Nonmonotonic time");
      lastTime = now;
    }
    function read3(now) {
      if (!target) return null;
      if (!active) return target;
      const p = clamp((now - start) / duration);
      const e = cubicProgress(p, config.easing);
      const value = Object.freeze(target.map((v, i) => from[i] + (v - from[i]) * e));
      if (p === 1) active = false;
      return value;
    }
    return {
      target(next, now, animate = true, presented) {
        if (disposed) return null;
        time(now);
        next = snapshotVector(next);
        if (!target || !animate || !config.durationMs || target.length !== next.length) {
          target = next;
          from = next;
          reversingStart = next;
          active = false;
          factor = 1;
          return next;
        }
        if (presented && presented.length !== next.length)
          throw new Error("[feedback.motion] Invalid presented value");
        const current = presented ? snapshotVector(presented) : read3(now);
        if (same(target, next)) return current;
        let nextFactor = 1;
        if (active && same(reversingStart, next)) {
          let axis = -1, largest = 0;
          target.forEach((v, i) => {
            const delta = Math.abs(v - from[i]);
            if (delta > largest) {
              largest = delta;
              axis = i;
            }
          });
          const e = presented && axis >= 0 ? (current[axis] - from[axis]) / (target[axis] - from[axis]) : cubicProgress(clamp((now - start) / duration), config.easing);
          nextFactor = clamp(Math.abs(e * factor + 1 - factor));
          reversingStart = target;
        } else reversingStart = current;
        from = current;
        target = next;
        start = now;
        factor = nextFactor;
        duration = config.durationMs * factor;
        active = duration > 0 && !same(from, target);
        return active ? current : target;
      },
      sample(now) {
        if (disposed) return null;
        time(now);
        return read3(now);
      },
      settle(now) {
        if (disposed) return null;
        time(now);
        active = false;
        factor = 1;
        return target;
      },
      get active() {
        return active && !disposed;
      },
      dispose() {
        disposed = true;
        active = false;
        target = null;
        from = [];
        reversingStart = [];
      }
    };
  }

  // packages/modules/feedback/src/presence/projector.ts
  var same2 = (a, b) => !!a && a.length === b.length && a.every((n, i) => n === b[i]);
  var attemptKey = (f) => `${f.view}:${f.owner.attempt?.ownerEpoch}:${f.owner.attempt?.phaseAttempt}:${f.owner.phase}`;
  function resolveTranslation(value, env) {
    const result = [];
    for (let i = 0; i < 2; i++) {
      const v = value[i];
      const box = i === 0 ? env.width : env.height;
      if (v.ownBox !== 0 && box === null || v.rootText !== 0 && env.rootFontPx === null)
        return null;
      const n = v.px + v.rootText * (env.rootFontPx ?? 0) + v.ownBox * (box ?? 0);
      if (!Number.isFinite(n)) return null;
      result.push(n);
    }
    return result;
  }
  function vector(endpoint2, env) {
    const translation2 = endpoint2.translate ? resolveTranslation(endpoint2.translate, env) : [0, 0];
    if (!translation2) return null;
    const size = endpoint2.blockSize === "intrinsic" ? env.intrinsicBlockSize : endpoint2.blockSize ?? 0;
    if (typeof size !== "number" || !Number.isFinite(size) || size < 0) return null;
    return Object.freeze([translation2[0], translation2[1], endpoint2.opacity ?? 1, size]);
  }
  var channelsOf = (candidate) => [
    ...candidate.closed.translate ? ["translate"] : [],
    ...candidate.closed.opacity !== void 0 ? ["opacity"] : [],
    ...candidate.closed.blockSize !== void 0 ? ["blockSize"] : []
  ];
  function createPresencePresentationProjector(host) {
    let frame = null;
    let view = null;
    let key = null;
    let generation = 0;
    let operation = 0;
    let ticket = null;
    let retired = false;
    let off = null;
    let acknowledged = null;
    let target = null;
    let sampler = null;
    let samplerConfig = "";
    let cold = true;
    let awaitingInitialFrame = false;
    let completed = false;
    let preparedFrame = null;
    let preparingFrame = null;
    let commitDepth = 0;
    let completionDepth = 0;
    let releasing = false;
    let pendingTick = false;
    let pendingFrameTick = null;
    let pendingSettlement = null;
    let completedTarget = null;
    let pendingCompletion = null;
    const reasons = /* @__PURE__ */ new Set();
    const cancel = () => {
      const old = ticket;
      ticket = null;
      generation++;
      if (old !== null) {
        try {
          host.cancelFrame(old);
        } catch {
          reasons.add("cancellation-failed");
        }
      }
    };
    const current = (candidate, token) => !retired && frame === candidate && token === generation;
    const sameAttempt = (left, right) => left.owner.owner === right.owner.owner && attemptKey(left) === attemptKey(right);
    const currentSettlement = (queued) => !retired && !!frame && queued.token === generation && sameAttempt(queued.frame, frame);
    const releaseHost = () => {
      if (releasing) return;
      releasing = true;
      completionDepth++;
      try {
        host.release();
      } finally {
        completionDepth--;
        releasing = false;
      }
    };
    const render = (candidate, value, token) => {
      if (!current(candidate, token)) return false;
      const sample2 = {
        ...candidate.closed.translate ? { translate: [value[0], value[1]] } : {},
        ...candidate.closed.opacity !== void 0 ? { opacity: Math.max(0, Math.min(1, value[2])) } : {},
        ...candidate.closed.blockSize !== void 0 ? { blockSize: Math.max(0, value[3]) } : {}
      };
      let accepted = false;
      try {
        accepted = host.project(candidate.style, sample2, () => current(candidate, token));
      } catch {
        reasons.add("projection-failed");
      }
      if (!current(candidate, token)) return false;
      if (accepted) acknowledged = Object.freeze([...value]);
      return accepted;
    };
    const complete = (candidate, reason, token, notify = true) => {
      if (!current(candidate, token) || completed && completedTarget === candidate.targetRevision)
        return;
      if (completionDepth) {
        pendingCompletion = { frame: candidate, token, outcome: reason, notify };
        return;
      }
      completed = true;
      completedTarget = candidate.targetRevision;
      reasons.add(reason);
      completionDepth++;
      try {
        try {
          releaseHost();
        } catch {
          reason = "projection-failed";
          reasons.add(reason);
        }
        const latest = frame;
        if (retired || !latest || token !== generation || !sameAttempt(candidate, latest) || latest.targetRevision !== candidate.targetRevision)
          return;
        if (preparedFrame !== latest) {
          reason = "projection-failed";
          reasons.add(reason);
        }
        if (notify && latest.owner.attempt) latest.complete(host.binding, reason);
      } finally {
        completionDepth--;
        flushPendingWork();
      }
    };
    const settle = (outcome) => {
      if (!frame || retired) return false;
      if (completed && completedTarget === frame.targetRevision) return false;
      if (commitDepth || completionDepth) {
        if (!pendingSettlement || !currentSettlement(pendingSettlement))
          pendingSettlement = { frame, token: generation, outcome };
        return false;
      }
      const op = ++operation;
      cancel();
      if (retired || operation !== op || !frame) return false;
      const candidate = frame, token = generation;
      if (!current(candidate, token)) return false;
      if (preparedFrame !== candidate) {
        complete(candidate, "projection-failed", token);
        return false;
      }
      const env = host.environment(channelsOf(candidate));
      if (!current(candidate, token)) return false;
      const endpoint2 = candidate.owner.phase === "leaving" || candidate.owner.phase === "closed" ? candidate.closed : candidate.entered;
      const value = vector(endpoint2, env);
      sampler?.dispose();
      sampler = null;
      samplerConfig = "";
      awaitingInitialFrame = false;
      const accepted = value !== null && render(candidate, value, token);
      if (!current(candidate, token)) return false;
      complete(candidate, accepted ? outcome : "projection-failed", token);
      return accepted;
    };
    function flushPendingWork() {
      if (commitDepth || completionDepth) return;
      const completion = pendingCompletion;
      const settlement = pendingSettlement;
      const delivered = pendingFrameTick;
      const requested = pendingTick;
      pendingCompletion = null;
      pendingSettlement = null;
      pendingFrameTick = null;
      pendingTick = false;
      if (completion && current(completion.frame, completion.token))
        complete(completion.frame, completion.outcome, completion.token, completion.notify);
      else if (settlement && currentSettlement(settlement) && preparedFrame === frame)
        settle(settlement.outcome);
      else if (requested) tick(!!delivered && current(delivered.frame, delivered.token));
    }
    function schedule() {
      if (retired || !frame || ticket !== null || completed) return;
      const token = generation;
      try {
        const next = host.requestFrame(() => {
          if (retired || token !== generation) return;
          ticket = null;
          tick(true);
        });
        if (!retired && token === generation) ticket = next;
        else if (next != null) host.cancelFrame(next);
        if (next == null && token === generation) settle("scheduler-failed");
      } catch {
        settle("scheduler-failed");
      }
    }
    function tick(fromFrame = false) {
      if (retired || !frame) return;
      if (commitDepth || completionDepth) {
        pendingTick = true;
        if (fromFrame) pendingFrameTick = { frame, token: generation };
        return;
      }
      if (preparedFrame !== frame) return;
      const candidate = frame, token = generation;
      if (completed && completedTarget === candidate.targetRevision) return;
      const enteredNeutral = (candidate.entered.opacity === void 0 || candidate.entered.opacity === 1) && (candidate.closed.blockSize === void 0 || candidate.closed.blockSize === 0 && candidate.entered.blockSize === "intrinsic") && (!candidate.entered.translate || candidate.entered.translate.every(
        (axis) => axis.px === 0 && axis.rootText === 0 && axis.ownBox === 0
      ));
      if (!enteredNeutral) {
        const op = ++operation;
        cancel();
        if (retired || operation !== op || frame !== candidate) return;
        const failedToken = generation;
        reasons.add("unsupported-endpoint");
        try {
          host.project(candidate.style, {}, () => current(candidate, failedToken));
        } catch {
          reasons.add("projection-failed");
        }
        if (!current(candidate, failedToken)) return;
        complete(candidate, "unsupported-endpoint", failedToken, !!candidate.owner.attempt);
        return;
      }
      if (candidate.owner.completion === "presentation" && candidate.owner.timeoutMs !== null && candidate.owner.durationMs >= candidate.owner.timeoutMs) {
        settle("invalid-policy");
        return;
      }
      const env = host.environment(channelsOf(candidate));
      if (!current(candidate, token)) return;
      if (env.preference !== "no-preference") {
        settle(env.preference === "reduce" ? "reduced-motion" : "unknown-preference");
        return;
      }
      if (!env.visible) {
        settle("hidden");
        return;
      }
      const channels = channelsOf(candidate);
      if (channels.some((channel) => !env.supported.includes(channel))) {
        settle("missing-capability");
        return;
      }
      const endpoint2 = candidate.owner.phase === "leaving" || candidate.owner.phase === "closed" ? candidate.closed : candidate.entered;
      const next = vector(endpoint2, env);
      const initial = vector(
        candidate.owner.phase === "leaving" && acknowledged === null ? candidate.entered : candidate.closed,
        env
      );
      if (!next || !initial) {
        settle("unresolved-units");
        return;
      }
      const animated = candidate.owner.completion === "presentation" && !!candidate.owner.attempt && (candidate.owner.phase === "entering" || candidate.owner.phase === "leaving");
      if (!animated || completed) {
        const accepted = render(candidate, next, token);
        if (!current(candidate, token)) return;
        if (!accepted) reasons.add("projection-failed");
        target = next;
        complete(candidate, accepted ? "finished" : "projection-failed", token, animated);
        return;
      }
      if (candidate.owner.durationMs === 0) {
        settle("zero-duration");
        return;
      }
      const now = host.now();
      const config = JSON.stringify([candidate.owner.durationMs, candidate.easing]);
      if (!sampler || samplerConfig !== config) {
        sampler?.dispose();
        sampler = createResidentMotionSampler({
          durationMs: candidate.owner.durationMs,
          easing: candidate.easing
        });
        samplerConfig = config;
        sampler.target(acknowledged ?? initial, now, false);
      }
      if (cold && candidate.owner.phase === "entering") {
        if (!awaitingInitialFrame) {
          if (!render(candidate, initial, token)) {
            if (current(candidate, token)) settle("projection-failed");
            return;
          }
          awaitingInitialFrame = true;
          target = next;
          schedule();
          return;
        }
        if (!fromFrame) {
          schedule();
          return;
        }
        if (!render(candidate, acknowledged ?? initial, token)) {
          if (current(candidate, token)) settle("projection-failed");
          return;
        }
        cold = false;
        awaitingInitialFrame = false;
        sampler.target(next, now, true, acknowledged);
        target = next;
        schedule();
        return;
      }
      cold = false;
      if (!same2(target, next)) {
        sampler.target(next, now, true, acknowledged ?? void 0);
        target = next;
      }
      const sample2 = fromFrame ? sampler.sample(now) : acknowledged;
      if (sample2 && !render(candidate, sample2, token)) {
        if (current(candidate, token)) settle("projection-failed");
        return;
      }
      if (!current(candidate, token)) return;
      if (!sampler.active) {
        if (!render(candidate, next, token)) {
          if (current(candidate, token)) settle("projection-failed");
          return;
        }
        complete(candidate, "finished", token);
      } else schedule();
    }
    return {
      commit(next) {
        if (retired) return;
        if (preparingFrame === next) {
          pendingTick = true;
          return;
        }
        commitDepth++;
        try {
          const op = ++operation;
          if (view !== null && next.view !== view) {
            cancel();
            if (retired || operation !== op) return;
            acknowledged = null;
            target = null;
            sampler?.dispose();
            sampler = null;
            cold = true;
          }
          const changed = key !== attemptKey(next);
          if (changed) {
            cancel();
            if (retired || operation !== op) return;
            completed = false;
            awaitingInitialFrame = false;
          }
          view = next.view;
          if (frame !== next) preparedFrame = null;
          frame = next;
          key = attemptKey(next);
          next.bind(host.binding);
          if (retired || frame !== next || operation !== op) return;
          if (preparedFrame !== next) {
            const token = generation;
            const previousPreparation = preparingFrame;
            preparingFrame = next;
            let accepted = false;
            try {
              accepted = host.project(next.style, {}, () => current(next, token));
            } catch {
              reasons.add("projection-failed");
            } finally {
              preparingFrame = previousPreparation;
            }
            if (!current(next, token) || operation !== op) return;
            if (!accepted) {
              reasons.add("projection-failed");
              cancel();
              if (retired || frame !== next || operation !== op) return;
              sampler?.dispose();
              sampler = null;
              samplerConfig = "";
              awaitingInitialFrame = false;
              complete(next, "projection-failed", generation, !!next.owner.attempt);
              return;
            }
            preparedFrame = next;
          }
          if (!off) {
            const nextOff = host.subscribe(() => tick());
            if (retired || operation !== op) {
              nextOff();
              return;
            }
            off = nextOff;
          }
          if (operation === op) tick();
        } finally {
          commitDepth--;
          flushPendingWork();
        }
      },
      settle,
      cancel() {
        const op = ++operation;
        cancel();
        if (retired || operation !== op) return;
        frame = null;
        preparedFrame = null;
        sampler?.dispose();
        sampler = null;
        samplerConfig = "";
        acknowledged = null;
        target = null;
        cold = true;
        completed = false;
        awaitingInitialFrame = false;
        try {
          releaseHost();
        } finally {
          flushPendingWork();
        }
      },
      release(epoch) {
        if (view !== epoch || retired) return;
        retired = true;
        operation++;
        cancel();
        frame = null;
        preparedFrame = null;
        acknowledged = null;
        target = null;
        sampler?.dispose();
        sampler = null;
        try {
          off?.();
        } finally {
          off = null;
          try {
            releaseHost();
          } finally {
            flushPendingWork();
          }
        }
      },
      diagnostics: () => [...reasons]
    };
  }

  // packages/adapters/base/src/platform/web-preference-source.ts
  var WEB_PREFERENCE_QUERIES = {
    "preference.reducedMotion": ["prefers-reduced-motion", ["no-preference", "reduce"]],
    "preference.reducedTransparency": ["prefers-reduced-transparency", ["no-preference", "reduce"]],
    "preference.contrast": ["prefers-contrast", ["no-preference", "less", "more", "custom"]],
    "preference.forcedColors": ["forced-colors", ["none", "active"]]
  };
  var sources = /* @__PURE__ */ new WeakMap();
  function queries(doc, key) {
    const view = doc.defaultView;
    if (typeof view?.matchMedia !== "function") return [];
    const [feature, values] = WEB_PREFERENCE_QUERIES[key];
    try {
      return values.map((value) => ({ value, media: view.matchMedia(`(${feature}: ${value})`) }));
    } catch {
      return [];
    }
  }
  function sample(entries2) {
    const matches = entries2.filter((entry) => entry.media.matches);
    return matches.length === 1 ? matches[0].value : "unknown";
  }
  function readWebPreference(doc, key) {
    if (!Object.prototype.hasOwnProperty.call(WEB_PREFERENCE_QUERIES, key)) return void 0;
    if (!doc) return "unknown";
    const typedKey = key;
    return sources.get(doc)?.read(typedKey) ?? sample(queries(doc, typedKey));
  }
  function createDocumentSource(doc) {
    const listeners = /* @__PURE__ */ new Set();
    const observed = /* @__PURE__ */ new Map();
    let generation = 0;
    let pending = false;
    function reconcileQueries() {
      const needed = new Set([...listeners].flatMap((listener) => [...listener.keys]));
      for (const [key, state] of observed) {
        if (needed.has(key)) continue;
        observed.delete(key);
        for (const { media } of state.entries) media.removeEventListener("change", state.onChange);
      }
      for (const key of needed) {
        if (observed.has(key)) continue;
        const entries2 = queries(doc, key);
        const observable = entries2.length > 0 && entries2.every(
          ({ media }) => typeof media.addEventListener === "function" && typeof media.removeEventListener === "function"
        );
        const state = {
          entries: observable ? entries2 : [],
          value: "unknown",
          onChange: () => {
          }
        };
        state.value = sample(state.entries);
        const current = generation;
        state.onChange = () => {
          if (current !== generation || observed.get(key) !== state || pending) return;
          pending = true;
          queueMicrotask(() => {
            if (current !== generation) return;
            pending = false;
            const changed = /* @__PURE__ */ new Set();
            for (const [activeKey, active] of observed) {
              const next = sample(active.entries);
              if (next !== active.value) {
                active.value = next;
                changed.add(activeKey);
              }
            }
            for (const listener of [...listeners]) {
              if (!listeners.has(listener) || !listener.keys.some((k) => changed.has(k))) continue;
              try {
                listener.invalidate();
              } catch (error) {
                queueMicrotask(() => {
                  throw error;
                });
              }
            }
          });
        };
        observed.set(key, state);
        for (const { media } of state.entries) media.addEventListener("change", state.onChange);
      }
    }
    return {
      read(key) {
        const state = observed.get(key);
        return state ? sample(state.entries) : sample(queries(doc, key));
      },
      subscribe(keys, invalidate) {
        const listener = {
          keys: [...new Set(keys)].filter(
            (key) => Object.prototype.hasOwnProperty.call(WEB_PREFERENCE_QUERIES, key)
          ),
          invalidate
        };
        listeners.add(listener);
        reconcileQueries();
        return () => {
          if (!listeners.delete(listener)) return;
          if (listeners.size === 0) {
            ++generation;
            pending = false;
          }
          reconcileQueries();
        };
      }
    };
  }
  function createDefaultWebPreferenceSource(getter, doc = typeof document === "undefined" ? void 0 : document) {
    if (!doc) return void 0;
    let source = sources.get(doc);
    if (!source) {
      source = createDocumentSource(doc);
      sources.set(doc, source);
    }
    return { getter, subscribe: source.subscribe };
  }

  // packages/adapters/base/src/motion/web-presence-presentation.ts
  var zeroOpacityOwners = /* @__PURE__ */ new WeakMap();
  function createWebPresencePresentationSink(el, effects, options = {}) {
    let document2 = el.ownerDocument;
    let current = null;
    let frame = null;
    let view = null;
    let binding = Object.freeze({});
    let retired = false, suspended = false, installing = false;
    let off = null;
    let retirementDepth = 0;
    let pendingReady = null;
    const reasons = /* @__PURE__ */ new Set();
    const safe = (operation, reason = "document-cleanup-failed") => {
      try {
        operation();
      } catch {
        reasons.add(reason);
      }
    };
    const create = () => {
      const captured = document2;
      return createDocumentPresenceSink(
        el,
        effects,
        binding,
        () => !retired && !suspended && document2 === captured && el.ownerDocument === captured,
        refresh
      );
    };
    function retireDocument(nextDocument) {
      if (retired) return;
      suspended = true;
      if (document2 === nextDocument) return;
      const old = current, previous = frame, previousView = view;
      current = null;
      document2 = nextDocument;
      binding = Object.freeze({});
      retirementDepth++;
      safe(() => previous?.bind(binding), "document-binding-failed");
      safe(() => {
        for (const reason of old?.diagnostics?.() ?? []) reasons.add(reason);
      });
      reasons.add("document-rebound");
      if (old && previousView !== null) safe(() => old.release(previousView));
      retirementDepth--;
      if (!retirementDepth && pendingReady) {
        const ready = pendingReady;
        pendingReady = null;
        admitDocument(ready);
      }
    }
    function admitDocument(nextDocument) {
      if (retired || document2 !== nextDocument || el.ownerDocument !== nextDocument) return;
      if (retirementDepth) {
        pendingReady = nextDocument;
        return;
      }
      suspended = false;
      current ??= create();
      if (frame) current.commit(frame);
    }
    function refresh() {
      if (retired || suspended || document2 === el.ownerDocument) return;
      const nextDocument = el.ownerDocument;
      retireDocument(nextDocument);
      admitDocument(nextDocument);
    }
    const documentChanged = (nextDocument, phase) => {
      if (phase === "retire") retireDocument(nextDocument);
      else if (suspended) admitDocument(nextDocument);
    };
    return {
      commit(next) {
        if (retired) return;
        frame = next;
        view = next.view;
        if (suspended || installing) return;
        if (!off && options.subscribeDocumentChange) {
          installing = true;
          let cleanup = null;
          safe(() => {
            cleanup = options.subscribeDocumentChange(documentChanged);
          }, "document-subscription-failed");
          installing = false;
          if (retired) {
            if (cleanup) safe(cleanup);
            return;
          }
          off = cleanup;
        }
        if (suspended || !frame) return;
        if (document2 !== el.ownerDocument) {
          refresh();
          return;
        }
        current ??= create();
        current.commit(frame);
      },
      cancel() {
        frame = null;
        current?.cancel();
      },
      settle(outcome) {
        refresh();
        return current?.settle(outcome) ?? false;
      },
      release(epoch) {
        if (retired || view !== epoch) return;
        retired = true;
        const old = current, cleanup = off;
        current = null;
        frame = null;
        off = null;
        if (cleanup) safe(cleanup);
        if (old) safe(() => old.release(epoch));
      },
      diagnostics: () => [...reasons, ...current?.diagnostics?.() ?? []]
    };
  }
  function createDocumentPresenceSink(el, effects, binding, live, refresh) {
    const doc = el.ownerDocument, win = doc.defaultView;
    let translation2 = null;
    const {
      writes,
      lost,
      owned,
      detectLoss,
      clear: clearOwnedStyles,
      write: writeOwnedStyle
    } = createWebMotionStyleOwnership(el, (name) => {
      if (name === "opacity") clearZeroOpacityOwner();
    });
    const ownsZeroOpacity = () => {
      const opacity = writes.get("opacity");
      return live() && !!opacity && Number.parseFloat(opacity.value) === 0 && owned("opacity", opacity);
    };
    const clearZeroOpacityOwner = () => {
      if (zeroOpacityOwners.get(el) === ownsZeroOpacity) zeroOpacityOwners.delete(el);
    };
    let styleRevision = 0;
    const clear = () => {
      styleRevision++;
      clearZeroOpacityOwner();
      translation2?.release();
      translation2 = null;
      clearOwnedStyles();
    };
    const write = (name, value) => {
      styleRevision++;
      if (!writeOwnedStyle(name, value)) return false;
      if (name === "opacity") {
        if (Number.parseFloat(value) === 0 && ownsZeroOpacity())
          zeroOpacityOwners.set(el, ownsZeroOpacity);
        else clearZeroOpacityOwner();
      }
      return true;
    };
    const px = (value) => value && /^-?(?:\d+\.?\d*|\.\d+)px$/.test(value) ? Number.parseFloat(value) : null;
    const intrinsicBlockSize = () => {
      const lease = writes.get("block-size");
      if (lost.has("block-size") || lease && !owned("block-size", lease)) return null;
      const revision = styleRevision;
      if (lease && !writeOwnedStyle("block-size", void 0)) return null;
      const semantic = {
        value: el.style.getPropertyValue("block-size"),
        priority: el.style.getPropertyPriority("block-size")
      };
      try {
        const css = win?.getComputedStyle(el);
        const vertical = css?.writingMode?.startsWith("vertical") || css?.writingMode?.startsWith("sideways");
        const value = px(css?.blockSize) ?? px(vertical ? css?.width : css?.height);
        return value !== null && Number.isFinite(value) && value >= 0 ? value : null;
      } finally {
        if (lease && live() && revision === styleRevision && !writes.has("block-size")) {
          if (owned("block-size", semantic)) {
            writeOwnedStyle("block-size", lease.value);
          } else {
            lost.add("block-size");
          }
        }
      }
    };
    return createPresencePresentationProjector({
      binding,
      now: () => win?.performance.now() ?? performance.now(),
      environment(channels = []) {
        detectLoss();
        const css = win?.getComputedStyle(el);
        const dimension = (axis) => {
          let value = px(css?.[axis]);
          if (value === null) return null;
          if (css?.boxSizing !== "border-box") {
            const keys = axis === "width" ? ["paddingLeft", "paddingRight", "borderLeftWidth", "borderRightWidth"] : ["paddingTop", "paddingBottom", "borderTopWidth", "borderBottomWidth"];
            for (const key of keys) {
              const extra = px(css?.[key]);
              if (extra === null) return null;
              value += extra;
            }
          }
          return Number.isFinite(value) && value >= 0 ? value : null;
        };
        const preference = readWebPreference(doc, "preference.reducedMotion");
        return {
          preference: preference === "no-preference" || preference === "reduce" ? preference : "unknown",
          visible: el.isConnected && doc.visibilityState !== "hidden" && !webMotionAncestors(el).some(
            (node) => node.matches("[hidden],[data-pui-view-pending],[data-pui-view-detached]")
          ),
          width: dimension("width"),
          height: dimension("height"),
          rootFontPx: px(win?.getComputedStyle(doc.documentElement).fontSize),
          intrinsicBlockSize: channels.includes("blockSize") ? intrinsicBlockSize() : null,
          supported: ["translate", "opacity", "blockSize"].filter(
            (name) => !lost.has(name) && (name !== "translate" || !!win?.CSS?.supports?.("translate", "1px")) && (name !== "blockSize" || !lost.has("block-size") && !lost.has("overflow") && !!win?.CSS?.supports?.("block-size", "1px"))
          )
        };
      },
      subscribe(invalidate) {
        const callback = () => {
          if (live()) invalidate();
          else refresh();
        };
        const off = createDefaultWebPreferenceSource(
          (key) => readWebPreference(doc, key),
          doc
        )?.subscribe(["preference.reducedMotion"], callback);
        const resize = win?.ResizeObserver ? new win.ResizeObserver(callback) : null;
        resize?.observe(el);
        const mutation = win?.MutationObserver ? new win.MutationObserver(callback) : null;
        for (const node of webMotionAncestors(el))
          mutation?.observe(node, {
            attributes: true,
            attributeFilter: ["hidden", "data-pui-view-pending", "data-pui-view-detached"]
          });
        doc.addEventListener("visibilitychange", callback);
        return () => {
          runAllSteps([
            () => off?.(),
            () => resize?.disconnect(),
            () => mutation?.disconnect(),
            () => doc.removeEventListener("visibilitychange", callback)
          ]);
        };
      },
      requestFrame: (callback) => win?.requestAnimationFrame(() => {
        if (live()) callback();
        else refresh();
      }) ?? null,
      cancelFrame: (ticket) => {
        if (typeof ticket === "number") win?.cancelAnimationFrame(ticket);
      },
      project(style, sample2, current) {
        if (!live()) {
          refresh();
          return false;
        }
        if (!current() || !live()) return false;
        effects.queueStyle(style);
        if (!current() || !live()) return false;
        effects.requestFlush();
        if (!current() || !live()) return false;
        detectLoss();
        if (sample2.opacity !== void 0) {
          if (lost.has("opacity")) return false;
          if (!writes.has("opacity")) {
            const inline = el.style.getPropertyValue("opacity");
            const computed = win?.getComputedStyle(el).opacity ?? "";
            if (inline && inline !== "1" || computed && computed !== "1") return false;
          }
        }
        if (sample2.translate) {
          translation2 ??= acquireWebTranslation(el, "presentation");
          if (!translation2.canWrite()) return false;
        }
        if (sample2.blockSize !== void 0 && (lost.has("block-size") || lost.has("overflow")))
          return false;
        if (sample2.translate && !translation2.set([
          { px: sample2.translate[0], rootText: 0, ownBox: 0 },
          { px: sample2.translate[1], rootText: 0, ownBox: 0 }
        ]))
          return false;
        if (!current() || !live()) return false;
        if (sample2.opacity !== void 0 && !write("opacity", String(sample2.opacity))) return false;
        if (sample2.blockSize !== void 0) {
          if (!write("overflow", "hidden")) return false;
          if (!current() || !live()) return false;
          if (!write("block-size", `${sample2.blockSize}px`)) return false;
        }
        return current() && live();
      },
      release: clear
    });
  }

  // ../bootstrap-initial-leave-diagnostic/registration-fixture.ts
  async function run(mode) {
    const report = { mode, status: "running", assertions: [], frames: [] };
    const check = (label, value) => {
      report.assertions.push({ label, passed: !!value });
      if (!value) throw new Error(label);
    };
    const el = document.createElement("div");
    Object.assign(el.style, { width: "320px", height: "200px", boxSizing: "border-box" });
    document.body.append(el);
    const nativeRaf = window.requestAnimationFrame.bind(window);
    const nativeCancel = window.cancelAnimationFrame.bind(window);
    const raf = window.requestAnimationFrame;
    const cancel = window.cancelAnimationFrame;
    const pending = /* @__PURE__ */ new Set();
    window.requestAnimationFrame = (callback) => {
      const id = nativeRaf((time) => {
        pending.delete(id);
        report.frames.push({ time, opacityBefore: Number(getComputedStyle(el).opacity) });
        callback(time);
      });
      pending.add(id);
      return id;
    };
    window.cancelAnimationFrame = (id) => {
      pending.delete(id);
      nativeCancel(id);
    };
    let styleApplications = 0, subscriptions = 0, cleanups = 0;
    const outcomes = [];
    const owner = Object.freeze({});
    let sink;
    const frame = (phase) => ({
      view: 1,
      revision: 1,
      targetRevision: 1,
      style: tw("bg-background"),
      owner: {
        owner,
        revision: 1,
        phase,
        attempt: { ownerEpoch: 1, phaseAttempt: 1 },
        completion: "presentation",
        durationMs: 500,
        timeoutMs: 1e3
      },
      closed: { opacity: 0 },
      entered: { opacity: 1 },
      easing: [0.32, 0.72, 0, 1],
      bind() {
      },
      complete(_binding, outcome) {
        outcomes.push({ outcome, at: performance.now() });
        el.hidden = true;
      }
    });
    try {
      sink = createWebPresencePresentationSink(el, {
        queueStyle() {
          styleApplications++;
        },
        requestFlush() {
        }
      }, { subscribeDocumentChange() {
        subscriptions++;
        report.atSubscription = {
          inline: el.style.opacity,
          computed: getComputedStyle(el).opacity,
          styleApplications,
          pending: pending.size
        };
        if (mode === "registration-before-first-application") sink.commit(frame("leaving"));
        return () => {
          cleanups++;
        };
      } });
      const started = performance.now();
      sink.commit(frame("entering"));
      report.afterEnteringCall = {
        inline: el.style.opacity,
        computed: getComputedStyle(el).opacity,
        styleApplications,
        pending: pending.size,
        outcomes: [...outcomes]
      };
      check("one adoption subscription", subscriptions === 1);
      check("registration precedes all semantic or transient applications", report.atSubscription.styleApplications === 0);
      check("registration sees the actual neutral semantic opacity", report.atSubscription.computed === "1" && report.atSubscription.inline === "");
      if (mode === "registration-before-first-application") {
        check("superseding first enter has not applied a closed sample", el.style.opacity === "");
        check("the first admitted leave remains active", outcomes.length === 0 && pending.size === 1);
        while (!outcomes.length && performance.now() - started < 1e3) {
          await new Promise((resolve) => nativeRaf(() => resolve()));
        }
        check("exactly one successful completion", outcomes.length === 1 && outcomes[0].outcome === "finished");
        report.elapsedMs = outcomes[0].at - started;
        check("completion follows the original duration before its deadline", report.elapsedMs >= 500 && report.elapsedMs < 1e3);
        check("native frames observe intermediate opacity", report.frames.some((f) => f.opacityBefore > 0 && f.opacityBefore < 1));
      } else {
        check("the original entering frame applied zero", el.style.opacity === "0");
        sink.commit(frame("leaving"));
        check("reversal of applied zero finishes synchronously", outcomes.length === 1 && outcomes[0].outcome === "finished");
        check("no native frame was needed to reverse zero", report.frames.length === 0);
      }
      check("terminal owner hides the surface", el.hidden);
      check("terminal presentation has no outstanding RAF", pending.size === 0);
      sink.release(1);
      check("subscription cleanup occurs once", cleanups === 1);
      check("release leaves no outstanding RAF", pending.size === 0);
      report.outcomes = outcomes;
      report.status = "passed";
    } catch (error) {
      report.status = "failed";
      report.error = String(error.stack ?? error);
    } finally {
      sink?.release(1);
      for (const id of pending) nativeCancel(id);
      window.requestAnimationFrame = raf;
      window.cancelAnimationFrame = cancel;
      el.remove();
    }
    return report;
  }
  return __toCommonJS(registration_fixture_exports);
})();
