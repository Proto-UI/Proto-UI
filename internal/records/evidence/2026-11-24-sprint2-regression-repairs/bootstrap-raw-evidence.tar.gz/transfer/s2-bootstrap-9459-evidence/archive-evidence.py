#!/usr/bin/env python3
"""Preserve original Bootstrap runs and bounded observations without relabeling failures."""
from pathlib import Path
import hashlib, io, json, tarfile, gzip

R = Path('/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202')
OUT = R / 'transfer/s2-bootstrap-9459-evidence'
OUT.mkdir(parents=True, exist_ok=True)
selected = [
    'bootstrap-initial-leave-diagnostic/registration-fixture.ts',
    'bootstrap-initial-leave-diagnostic/registration-run.mjs',
    'bootstrap-initial-leave-diagnostic/bootstrap-registration-pair-9cd-01.job.json',
    'bootstrap-initial-leave-diagnostic/bootstrap-registration-pair-96d-01.job.json',
    'evidence/bootstrap-registration-pair-9cd-01',
    'evidence/bootstrap-registration-pair-96d-01',
    'results/bootstrap-registration-pair-96d-01',
    'evidence/bootstrap-four-web-terminal-9459',
    'evidence/bootstrap-four-web-aligned-9459-01',
    'results/bootstrap-four-web-aligned-9459-01',
    'evidence/bootstrap-four-web-aligned-9459-quiet-02',
    'results/bootstrap-four-web-aligned-9459-quiet-02',
    'bootstrap-initial-leave-diagnostic/bootstrap-four-web-aligned-9459-01.job.json',
    'bootstrap-initial-leave-diagnostic/bootstrap-four-web-aligned-9459-quiet-02.job.json',
    'bootstrap-initial-leave-diagnostic/bootstrap-four-web-aligned-9459-01.source.json',
    'Proto-UI-publisher/.cache/s2-bootstrap-reversal-oracle-9459/bootstrap-collapse-browser.mjs',
    'bootstrap-initial-leave-diagnostic/vue-close-observe-9459-01.mjs',
    'bootstrap-initial-leave-diagnostic/bootstrap-vue-close-observe-9459-01.job.json',
    'evidence/bootstrap-vue-close-observe-9459-01',
    'results/bootstrap-vue-close-observe-9459-01',
    'bootstrap-endpoint-calibration-9459-01',
    'evidence/bootstrap-endpoint-calibration-9459-01',
    'results/bootstrap-endpoint-calibration-9459-01',
    'bootstrap-endpoint-calibration-8bf-02',
    'evidence/bootstrap-endpoint-calibration-8bf-02',
    'results/bootstrap-endpoint-calibration-8bf-02',
    'transfer/s2-bootstrap-9459-evidence/reversal-oracle.patch',
    'transfer/s2-bootstrap-9459-evidence/handoff.json',
    'transfer/s2-bootstrap-9459-evidence/endpoint-contract-oracle.patch',
    'transfer/s2-bootstrap-9459-evidence/endpoint-handoff.json',
    'transfer/s2-bootstrap-9459-evidence/bootstrap-collapse-browser.endpoint.mjs',
    'transfer/s2-bootstrap-9459-evidence/archive-evidence.py',
]
sha = lambda raw: hashlib.sha256(raw).hexdigest()
files = {}
for relative in selected:
    source = R / relative
    assert source.exists(), f'Missing original: {relative}'
    for item in sorted(source.rglob('*')) if source.is_dir() else [source]:
        assert not item.is_symlink(), f'Unexpected link: {item}'
        if not item.is_file():
            continue
        key = item.relative_to(R).as_posix()
        raw = item.read_bytes()
        if key in files:
            assert files[key] == raw
        files[key] = raw

def counts(relative):
    report = json.loads(files[relative])
    cases = report['cases']
    return {'executed': len(cases), 'passed': sum(case['status'] == 'passed' for case in cases), 'failed': sum(case['status'] == 'failed' for case in cases)}

observed = {
    'original9459': counts('evidence/bootstrap-four-web-terminal-9459/browser/report.json'),
    'aligned01': counts('results/bootstrap-four-web-aligned-9459-01/browser/report.json'),
    'alignedQuiet02': counts('results/bootstrap-four-web-aligned-9459-quiet-02/browser/report.json'),
}
assert observed['original9459'] == {'executed': 40, 'passed': 38, 'failed': 2}
assert observed['aligned01'] == {'executed': 40, 'passed': 38, 'failed': 2}
assert observed['alignedQuiet02'] == {'executed': 40, 'passed': 39, 'failed': 1}
single = json.loads(files['results/bootstrap-vue-close-observe-9459-01/report.json'])
assert single['summary'] == {'passed': 12, 'failed': 0, 'driverError': False, 'traceError': False}
assert single['source']['sourceStable'] is True
endpoint = json.loads(files['results/bootstrap-endpoint-calibration-8bf-02/report.json'])
assert endpoint['summary'] == {'cases':6,'passed':6,'failed':0,'assertionsPassed':44,'assertionsFailed':0}
assert endpoint['source']['sourceStable'] is True
assert endpoint['source']['head'] == '8bf1bef48c7bae707c842ece3d3db90084c4d60b'
assert endpoint['source']['bundleSourceHead'] == '9459bb786b2a0e8de1a48f0940ac14eeba2f2733'
for case in endpoint['cases']:
    assert case['status'] == 'passed' and not case['pageErrors'] and not case.get('cleanupError')
    if case['mode'] == 'observe':
        assert case['endpoint']['accepted'] and not case['endpoint']['mutationPerformed']
    else:
        assert not case['endpoint']['accepted'] and case['endpoint']['mutationPerformed']
assert sha(files['Proto-UI-publisher/.cache/s2-bootstrap-reversal-oracle-9459/bootstrap-collapse-browser.mjs']) == '2813fed0425eac50392e978d229f97a628d4f782e79295b65df103ae5a829bba'
assert sha(files['bootstrap-initial-leave-diagnostic/vue-close-observe-9459-01.mjs']) == '7853e7e12f3522142e7f9f6df7abd5b9cdb7773e7691ea9b6fbb9fd8f2a0b71b'
assert sha(files['transfer/s2-bootstrap-9459-evidence/reversal-oracle.patch']) == '98d8a7049064637c55aa820a678382c3be251a10a727e26575713637e38ade18'
assert sha(files['transfer/s2-bootstrap-9459-evidence/endpoint-contract-oracle.patch']) == 'f42f0aa4602ca6b7f42f740ea4645005fdd05defb7e5c0bad478c6f122366909'
assert sha(files['transfer/s2-bootstrap-9459-evidence/bootstrap-collapse-browser.endpoint.mjs']) == '97a827748271666c4ab84f91a3672838581c9a5a763acb0fcbe4adbecffb45a6'
assert sha(files['bootstrap-endpoint-calibration-8bf-02/bootstrap-collapse-endpoint-oracle.mjs']) == '0984ee83fe85b0006609e8e8d929e85c493760cf0d7c3c496fa46f5eada3ae75'
manifest = {
    'kind': 'bootstrap-reversal-and-native-observation-raw-evidence',
    'source': '9459bb786b2a0e8de1a48f0940ac14eeba2f2733',
    'registrationSource': '96d295e90369aeb8ff681010f920c71caf34a8a0',
    'fullRuns': observed,
    'boundedFreshVueDiagnostic': single['summary'],
    'endpointCalibration': endpoint['summary'],
    'endpointCalibrationSource': endpoint['source'],
    'controlledObserverInterruption': 'evidence/bootstrap-endpoint-calibration-9459-01/controlled-interruption.json',
    'fullMatrixStatus': 'failed; the isolated diagnostic does not replace its last row',
    'files': [{'path': key, 'bytes': len(raw), 'sha256': sha(raw)} for key, raw in sorted(files.items())],
}
manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode='wb', filename='', mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w|', format=tarfile.PAX_FORMAT) as archive:
        for key, raw in [('manifest.json', manifest_raw), *sorted(files.items())]:
            entry = tarfile.TarInfo(key)
            entry.size = len(raw)
            entry.mode = 0o644
            entry.mtime = 0
            archive.addfile(entry, io.BytesIO(raw))
raw_archive = buffer.getvalue()
with tarfile.open(fileobj=io.BytesIO(raw_archive), mode='r:gz') as archive:
    assert len(archive.getmembers()) == len(files) + 1
    for member in archive.getmembers():
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        expected = manifest_raw if member.name == 'manifest.json' else files[member.name]
        assert archive.extractfile(member).read() == expected

def exact_write(target, raw):
    if target.exists():
        assert target.read_bytes() == raw, f'Refusing to replace a differing archive: {target}'
    else:
        target.write_bytes(raw)

exact_write(OUT / 'raw-evidence.tar.gz', raw_archive)
exact_write(OUT / 'manifest.json', manifest_raw)
receipt = {
    'kind': 'bootstrap-native-evidence-archive-complete',
    'archive': str(OUT / 'raw-evidence.tar.gz'),
    'bytes': len(raw_archive), 'sha256': sha(raw_archive),
    'manifestSha256': sha(manifest_raw),
    'verifiedPayloads': len(files), 'verifiedTarMembers': len(files) + 1,
    'originalRuns': observed,
    'boundedDiagnostic': single['summary'],
    'endpointCalibration': endpoint['summary'],
    'fullMatrixStatus': manifest['fullMatrixStatus'],
    'status': 'complete-and-verified',
}
exact_write(OUT / 'archive-complete.json', (json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps(receipt))
