import type { EffectsPort, StyleHandle } from '@proto.ui/core';
import { assertTwTokenV0 } from '@proto.ui/core';
import {
  mergeRootStyleEntries,
  readRootStyleEntries,
  resolveRootStyleEntry,
  type RootStyleEntry,
} from '@proto.ui/core/internal';
import { createOwnedTwTokenApplier, PUI_STYLE_ATTR } from './feedback-style';
import { stripShadowCssComments, type ShadowStyleArtifactV1 } from './shadow-style-artifact';

export const SHADOW_SPLIT_ROOT_STYLE_ATTR = 'data-pui-split-root-style';
export const SHADOW_SPLIT_SURFACE_ATTR = 'data-pui-split-surface';
const activeBindings = new WeakSet<HTMLElement>();
const splitPaintOwners = new WeakMap<
  Element,
  { containsCurrentTokens(): boolean; ownsZeroOpacity(): boolean }
>();

export function hasCurrentSplitSurfacePaint(surface: Element): boolean {
  return splitPaintOwners.get(surface)?.containsCurrentTokens() ?? false;
}

export function hasOwnedSplitZeroOpacity(surface: Element): boolean {
  return splitPaintOwners.get(surface)?.ownsZeroOpacity() ?? false;
}

const COMPOSITES = new Set(['block', 'flex', 'grid', 'inline-flex']);
const NATIVE_TEXT_ATTR = 'data-pui-split-text-control';
const SPLIT_COMPILED_RECEIPT = '--pui-split-compiled-receipt';

type Projection = { root: string; surface: string[]; borderWidths: string };
type CompiledStyleRule = Readonly<{
  selector: string;
  branches: readonly string[];
  declarations: string;
}>;

// Cache only this module's pure v1 rule analysis, never a recipe verdict or an
// owner/DOM result. Count source and derived strings in UTF-16 code units.
const COMPILED_RULE_CACHE_ENTRIES = 32;
const COMPILED_RULE_CACHE_CHARACTERS = 4 * 1024 * 1024;
const compiledRuleCache = new Map<
  string,
  { rules: readonly CompiledStyleRule[]; characters: number }
>();
let compiledRuleCharacters = 0;

function splitCompiledReceipt(selector: string, declarations: string): string {
  const input = `${selector.replace(/\s/g, '')}{${declarations.replace(/\s/g, '')}}`;
  let hash = 2166136261;
  for (let index = 0; index < input.length; index += 1) {
    hash = Math.imul(hash ^ input.charCodeAt(index), 16777619);
  }
  return (hash >>> 0).toString(36);
}

// The v1 artifact is a plain value, so this is an integrity receipt for the
// generated companion rather than authentication of adversarial CSS.
function hasValidDeclarationReceipt(rule: CompiledStyleRule): boolean {
  const marker = new RegExp(
    `(?:^|;)\\s*${SPLIT_COMPILED_RECEIPT}\\s*:\\s*([a-z0-9]+)\\s*;\\s*$`
  ).exec(rule.declarations);
  if (!marker || marker.index === undefined) return false;
  const declarations = rule.declarations.slice(
    0,
    marker.index + (marker[0]!.startsWith(';') ? 1 : 0)
  );
  return (
    !declarations.includes(SPLIT_COMPILED_RECEIPT) &&
    marker[1] === splitCompiledReceipt(rule.selector, declarations)
  );
}

function declarationsBeforeReceipt(rule: CompiledStyleRule): string | null {
  const marker = new RegExp(
    `(?:^|;)\\s*${SPLIT_COMPILED_RECEIPT}\\s*:\\s*[a-z0-9]+\\s*;\\s*$`
  ).exec(rule.declarations);
  if (!marker || marker.index === undefined) return null;
  return rule.declarations
    .slice(0, marker.index + (marker[0]!.startsWith(';') ? 1 : 0))
    .replace(/\s/g, '');
}

// Canonical recipes affecting boundary sizing or scrolling are Adapter trust
// anchors. A new generated spelling requires an Adapter update and parity evidence.
function hasCanonicalProjectionRecipe(rule: CompiledStyleRule, entry: RootStyleEntry): boolean {
  const expected =
    entry.authorToken === 'w-full'
      ? 'width:100%;'
      : entry.authorToken === 'min-h-16'
        ? 'min-height:4rem;'
        : entry.authorToken === 'overflow-y-auto'
          ? 'overflow-y:auto;'
          : null;
  if (!expected) return true;
  return declarationsBeforeReceipt(rule) === expected;
}

function nextCssBoundary(
  cssText: string,
  start: number
): { index: number; character: '{' | ';' } | null {
  let quote = '';
  let parenDepth = 0;
  let bracketDepth = 0;
  for (let index = start; index < cssText.length; index += 1) {
    const character = cssText[index]!;
    if (character === '\\') {
      index += 1;
      continue;
    }
    if (quote) {
      if (character === quote) quote = '';
      continue;
    }
    if (character === '"' || character === "'") {
      quote = character;
      continue;
    }
    if (character === '(') parenDepth += 1;
    else if (character === ')') parenDepth = Math.max(0, parenDepth - 1);
    else if (character === '[') bracketDepth += 1;
    else if (character === ']') bracketDepth = Math.max(0, bracketDepth - 1);
    else if (!parenDepth && !bracketDepth && (character === '{' || character === ';')) {
      return { index, character };
    }
  }
  return null;
}

function cssBlockEnd(cssText: string, open: number): number {
  let depth = 1;
  let quote = '';
  for (let index = open + 1; index < cssText.length; index += 1) {
    const character = cssText[index]!;
    if (character === '\\') {
      index += 1;
      continue;
    }
    if (quote) {
      if (character === quote) quote = '';
      continue;
    }
    if (character === '"' || character === "'") {
      quote = character;
      continue;
    }
    if (character === '{') depth += 1;
    else if (character === '}' && --depth === 0) return index;
  }
  return -1;
}

function directCssDeclarations(cssText: string): string {
  let cursor = 0;
  let declarations = '';
  while (cursor < cssText.length) {
    const boundary = nextCssBoundary(cssText, cursor);
    if (!boundary) return declarations + cssText.slice(cursor);
    if (boundary.character === ';') {
      declarations += cssText.slice(cursor, boundary.index + 1);
      cursor = boundary.index + 1;
      continue;
    }
    const close = cssBlockEnd(cssText, boundary.index);
    if (close < 0) return declarations;
    cursor = close + 1;
  }
  return declarations;
}

function collectUnconditionallyAvailableRules(cssText: string): CompiledStyleRule[] {
  const rules: CompiledStyleRule[] = [];
  let cursor = 0;
  while (cursor < cssText.length) {
    const boundary = nextCssBoundary(cssText, cursor);
    if (!boundary) break;
    if (boundary.character === ';') {
      cursor = boundary.index + 1;
      continue;
    }
    const close = cssBlockEnd(cssText, boundary.index);
    if (close < 0) break;
    const prelude = cssText.slice(cursor, boundary.index).trim();
    const body = cssText.slice(boundary.index + 1, close);
    // A layer-name list is valid only in statement form. Recursing into an
    // invalid list-form block would treat rules the browser discards as usable
    // preflight evidence. Generated companions use one simple named layer;
    // anonymous blocks are accepted as well.
    if (/^@layer(?:\s+[-_a-zA-Z][-_a-zA-Z0-9]*(?:\.[-_a-zA-Z][-_a-zA-Z0-9]*)*)?$/i.test(prelude)) {
      rules.push(...collectUnconditionallyAvailableRules(body));
    } else if (prelude && !prelude.startsWith('@')) {
      const selector = prelude.replace(/\s/g, '');
      rules.push(
        Object.freeze({
          selector,
          branches: Object.freeze(splitSelectorBranches(selector)),
          declarations: directCssDeclarations(body),
        })
      );
    }
    cursor = close + 1;
  }
  return rules;
}

function compiledRules(cssText: string): readonly CompiledStyleRule[] {
  const cacheable = typeof cssText === 'string';
  const cached = cacheable ? compiledRuleCache.get(cssText) : undefined;
  if (cached) return cached.rules;
  const uncommented = stripShadowCssComments(cssText);
  const rules = Object.freeze(collectUnconditionallyAvailableRules(uncommented));
  if (!cacheable) return rules;
  const characters = rules.reduce(
    (total, rule) =>
      total +
      rule.selector.length +
      rule.declarations.length +
      rule.branches.reduce((length, branch) => length + branch.length, 0),
    cssText.length + uncommented.length
  );
  if (characters > COMPILED_RULE_CACHE_CHARACTERS) return rules;
  while (
    compiledRuleCache.size >= COMPILED_RULE_CACHE_ENTRIES ||
    compiledRuleCharacters + characters > COMPILED_RULE_CACHE_CHARACTERS
  ) {
    const oldest = compiledRuleCache.keys().next().value!;
    compiledRuleCharacters -= compiledRuleCache.get(oldest)!.characters;
    compiledRuleCache.delete(oldest);
  }
  compiledRuleCache.set(cssText, { rules, characters });
  compiledRuleCharacters += characters;
  return rules;
}

function verifiedShadowSplitBaseRule(
  rules: readonly CompiledStyleRule[]
): CompiledStyleRule | null {
  const baseSelector = `:host([${SHADOW_SPLIT_ROOT_STYLE_ATTR}])`;
  const baseRule = rules.find(({ selector }) => selector === baseSelector);
  return baseRule && hasValidDeclarationReceipt(baseRule) ? baseRule : null;
}

/** Private registration preflight shared with the connection-time effects owner. */
export function hasVerifiedShadowSplitBaseRecipe(
  artifact: ShadowStyleArtifactV1,
  recipe: string,
  version: string
): boolean {
  const rules = compiledRules(artifact.cssText);
  const baseRule = verifiedShadowSplitBaseRule(rules);
  return (
    !!baseRule &&
    baseRule.declarations.replace(/\s/g, '').includes(`--pui-split-${recipe}-recipe:${version};`)
  );
}

function splitReceiptVariants(token: string): string[] {
  const parts: string[] = [];
  let current = '';
  let depth = 0;
  for (const character of token) {
    if (character === '[') depth += 1;
    else if (character === ']') depth = Math.max(0, depth - 1);
    if (character === ':' && depth === 0) {
      parts.push(current);
      current = '';
    } else current += character;
  }
  parts.push(current);
  return parts.filter(Boolean);
}

function compiledReceiptSelector(
  token: string,
  target: 'host' | 'element' = 'host'
): string | null {
  const escaped = token.replaceAll('\\', '\\\\').replaceAll('"', '\\"');
  let selector = `[${SHADOW_SPLIT_ROOT_STYLE_ATTR}~="${escaped}"]`;
  let dark = false;
  const variants = splitReceiptVariants(token).slice(0, -1);
  for (const variant of variants) {
    if (variant === 'dark') dark = true;
    // Static paint targets (selection and the finite admitted placeholder
    // colors) keep their pseudo-element target. Author admission already
    // bounded the payload, so this variant adds no host condition and is never
    // a wrapper-box contribution.
    else if (
      variants.length === 1 &&
      ((variant === 'selection' && token.startsWith('selection:')) ||
        (variant === 'placeholder' && token.startsWith('placeholder:')))
    )
      continue;
    else if (['hover', 'active', 'disabled', 'focus-visible'].includes(variant))
      selector += `:${variant}`;
    else {
      const notData = /^not-\[data-([a-zA-Z0-9-]+)\]$/.exec(variant);
      const data = /^data-\[(.+)\]$/.exec(variant);
      if (notData) selector += `:not([data-${notData[1]}])`;
      else if (variant.startsWith('aria-')) selector += `[${variant}='true']`;
      else if (data) {
        const body = data[1]!;
        const equal = body.indexOf('=');
        if (equal < 0) selector += `[data-${body}]`;
        else {
          const name = body.slice(0, equal);
          const value = body
            .slice(equal + 1)
            .replace(/^['"]|['"]$/g, '')
            .replaceAll('\\', '\\\\')
            .replaceAll('"', '\\"');
          selector += `[data-${name}='${value}']`;
        }
      } else return null;
    }
  }
  if (target === 'element') return dark ? `[data-pui-color-scheme='dark']${selector}` : selector;
  return `${dark ? ":where(:host([data-pui-color-scheme='dark']))" : ''}:host(${selector})`;
}

function splitSelectorBranches(selector: string): string[] {
  const branches: string[] = [];
  let start = 0;
  let parenDepth = 0;
  let bracketDepth = 0;
  let quote = '';
  for (let index = 0; index < selector.length; index += 1) {
    const character = selector[index]!;
    if (character === '\\') {
      index += 1;
      continue;
    }
    if (quote) {
      if (character === quote) quote = '';
      continue;
    }
    if (character === '"' || character === "'") {
      quote = character;
      continue;
    }
    if (character === '[') bracketDepth += 1;
    else if (character === ']') bracketDepth = Math.max(0, bracketDepth - 1);
    else if (!bracketDepth && character === '(') parenDepth += 1;
    else if (!bracketDepth && character === ')') parenDepth = Math.max(0, parenDepth - 1);
    else if (!parenDepth && !bracketDepth && character === ',') {
      branches.push(selector.slice(start, index).trim());
      start = index + 1;
    }
  }
  branches.push(selector.slice(start).trim());
  return branches;
}

function hasExactCompiledReceipt(
  rules: readonly CompiledStyleRule[],
  entry: RootStyleEntry
): boolean {
  const token = entry.token;
  const receipt = compiledReceiptSelector(token);
  if (!receipt) return false;
  const escaped = token.replaceAll('\\', '\\\\').replaceAll('"', '\\"');
  const selection = token.startsWith('selection:');
  const placeholder = token.startsWith('placeholder:');
  const surface = `${receipt}>[${SHADOW_SPLIT_SURFACE_ATTR}][data-pui-style~="${escaped}"]`;
  const allowed = new Set(
    entry.authorToken === 'overflow-y-auto'
      ? [surface]
      : selection
        ? [`${receipt}>[${SHADOW_SPLIT_SURFACE_ATTR}][data-pui-style~="${escaped}"]::selection`]
        : placeholder
          ? [`${receipt}>[${SHADOW_SPLIT_SURFACE_ATTR}][data-pui-style~="${escaped}"]::placeholder`]
          : [
              receipt,
              `${receipt}:host([data-pui-split-text-control])`,
              `${receipt}>[${SHADOW_SPLIT_SURFACE_ATTR}]:not(input,textarea)`,
              surface,
            ]
  );
  const candidates = rules.filter(({ selector }) => selector.includes(receipt));
  const matching = candidates.filter(
    ({ branches }) => branches.length === 1 && allowed.has(branches[0]!)
  );
  return (
    matching.length === candidates.length &&
    matching.length > 0 &&
    ((!selection && !placeholder && entry.roleSource === 'fallback') ||
      matching.every(
        (rule) => hasValidDeclarationReceipt(rule) && hasCanonicalProjectionRecipe(rule, entry)
      ))
  );
}

// Fixed border widths are supported by H1. CSS rounds animated border widths
// to device pixels but interpolates compensating margins continuously. Until
// a recipe preserves that used-value rounding, reject such transitions under K.
function borderWidthCandidates(entries: readonly RootStyleEntry[]): number[][] {
  const base = Array.from({ length: 4 }, () => new Set<number>()); // top, right, bottom, left
  const conditional: Array<{ sides: number[]; width: number }> = [];
  for (const entry of entries) {
    const match = /^border(?:-([trbl]))?(?:-(\d+))?$/.exec(entry.authorToken);
    if (!match) continue;
    const sides = match[1] ? ['trbl'.indexOf(match[1])] : [0, 1, 2, 3];
    const width = Number(match[2] ?? 1);
    if (entry.token !== entry.authorToken) conditional.push({ sides, width });
    else for (const side of sides) base[side]!.add(width);
  }
  return base.map((widths, side) =>
    [
      ...new Set([
        ...(widths.size ? widths : [0]),
        ...conditional.filter((c) => c.sides.includes(side)).map((c) => c.width),
      ]),
    ].sort()
  );
}

/** Private E1 binding. Validation precedes all DOM writes; no layout measurement. */
export function createShadowSplitEffectsPort({
  host,
  surface,
  artifact,
  prototypeName,
}: {
  host: HTMLElement;
  surface: HTMLElement;
  artifact: ShadowStyleArtifactV1;
  prototypeName: string;
}): EffectsPort & { dispose(): void } {
  const invalid = (reason: string) => new Error(`[${prototypeName}]${reason}`);
  const nativeText = surface.localName === 'input' || surface.localName === 'textarea';
  if (!host.shadowRoot || surface.parentNode !== host.shadowRoot) {
    throw invalid('surface-parent');
  }
  if (
    activeBindings.has(host) ||
    host.hasAttribute(SHADOW_SPLIT_ROOT_STYLE_ATTR) ||
    surface.hasAttribute(SHADOW_SPLIT_SURFACE_ATTR) ||
    (nativeText && host.hasAttribute(NATIVE_TEXT_ATTR))
  ) {
    throw invalid('projection-owned');
  }
  const rules = compiledRules(artifact.cssText);
  const baseRule = verifiedShadowSplitBaseRule(rules);
  if (!baseRule) {
    throw invalid('sizing-recipe');
  }
  const baseDeclarations = baseRule.declarations.replace(/\s/g, '');
  const hasRecipe = (name: string, version: string) =>
    baseDeclarations.includes(`--pui-split-${name}-recipe:${version};`);
  if (nativeText && !hasRecipe('native-text', 'l1')) throw invalid('native-text-recipe');
  activeBindings.add(host);
  const applier = createOwnedTwTokenApplier(surface);
  let latest: Projection | null = null;
  let applied: Projection | null = null;
  let disposed = false;
  let flushing = false;
  let flushRequested = false;
  let zeroOpacityTransition: { animation: CSSTransition; target: string | null } | null = null;
  let hoveredZero: { projection: Projection; tokens: string[] } | null = null;
  const isLiveSurfaceToken = (token: string) => {
    const selector = compiledReceiptSelector(token, 'element');
    return (
      selector !== null &&
      host.matches(selector) &&
      surface.getAttribute(PUI_STYLE_ATTR)?.split(/\s+/).includes(token)
    );
  };
  const ownsZeroOpacity = () =>
    applied?.surface.some(
      (token) =>
        (token === 'opacity-0' || token.endsWith(':opacity-0')) && isLiveSurfaceToken(token)
    ) ?? false;
  const isCurrentOpacityTarget = (target: string | null) =>
    target !== null
      ? isLiveSurfaceToken(target) === true
      : !!applied &&
        !applied.surface.some(
          (token) => /(?:^|:)opacity-/.test(token) && isLiveSurfaceToken(token)
        ) &&
        applied.surface.some(
          (token) => /(?:^|:)transition-(?:opacity|all)$/.test(token) && isLiveSurfaceToken(token)
        );
  const ownsZeroOpacityAnimation = (direction: 'in' | 'out') => {
    const hasPaint = (name: string) =>
      applied?.surface.some(
        (token) => (token === name || token.endsWith(`:${name}`)) && isLiveSurfaceToken(token)
      );
    if (!hasPaint(`animate-${direction}`) || !hasPaint(`fade-${direction}-0`)) return false;
    const view = surface.ownerDocument.defaultView;
    if (!view?.CSSAnimation || !view.KeyframeEffect || !surface.getAnimations) return false;
    return surface.getAnimations().some((animation) => {
      const effect = animation.effect;
      return (
        animation instanceof view.CSSAnimation &&
        animation.animationName ===
          (direction === 'in' ? 'pui-split-paint-enter' : 'pui-split-paint-exit') &&
        effect instanceof view.KeyframeEffect &&
        effect.target === surface &&
        !effect.pseudoElement &&
        effect.getTiming().fill === 'both' &&
        effect.getComputedTiming().progress === (direction === 'in' ? 0 : 1) &&
        effect.getKeyframes().at(direction === 'in' ? 0 : -1)?.opacity === '0'
      );
    });
  };
  splitPaintOwners.set(surface, {
    containsCurrentTokens() {
      if (applied && host.getAttribute(SHADOW_SPLIT_ROOT_STYLE_ATTR) !== applied.root) return false;
      const owned = applier.getOwned();
      if (owned.size === 0) return true;
      const live = new Set(surface.getAttribute(PUI_STYLE_ATTR)?.split(/\s+/));
      return [...owned].every((token) => live.has(token));
    },
    ownsZeroOpacity() {
      if (surface.parentNode !== host.shadowRoot) return false;
      if (ownsZeroOpacity() || ownsZeroOpacityAnimation('in') || ownsZeroOpacityAnimation('out'))
        return true;
      if (
        zeroOpacityTransition &&
        !surface.getAnimations().includes(zeroOpacityTransition.animation)
      )
        zeroOpacityTransition = null;
      const transition = zeroOpacityTransition;
      return (
        !!transition &&
        isCurrentOpacityTarget(transition.target) &&
        (transition.animation.pending || transition.animation.playState === 'running') &&
        captureZeroOpacityTransition([transition.target], [])?.animation === transition.animation &&
        !surface.getAnimations().some((animation) => {
          if (animation === transition.animation) return false;
          const effect = animation.effect;
          const view = surface.ownerDocument.defaultView;
          return (
            !!view?.KeyframeEffect &&
            effect instanceof view.KeyframeEffect &&
            effect.target === surface &&
            !effect.pseudoElement &&
            effect.getComputedTiming().progress !== null &&
            effect.getKeyframes().some((frame) => frame.opacity !== undefined)
          );
        })
      );
    },
  });

  const captureZeroOpacityTransition = (
    eligible: readonly (string | null)[],
    before: readonly Animation[]
  ): { animation: CSSTransition; target: string | null } | null => {
    const view = surface.ownerDocument.defaultView;
    if (!view?.CSSTransition || !view.KeyframeEffect) return null;
    for (const animation of surface.getAnimations()) {
      if (
        !(animation instanceof view.CSSTransition) ||
        animation.transitionProperty !== 'opacity' ||
        before.includes(animation)
      )
        continue;
      const effect = animation.effect;
      if (
        !(effect instanceof view.KeyframeEffect) ||
        effect.target !== surface ||
        effect.pseudoElement
      )
        continue;
      const keyframes = effect.getKeyframes();
      if (keyframes[0]?.opacity !== '0') continue;
      const finalOpacity = Number(keyframes.at(-1)?.opacity);
      const target = eligible.find(
        (token) =>
          (token === null
            ? finalOpacity === 1
            : Number(/(?:^|:)opacity-(\d+)$/.exec(token)?.[1]) / 100 === finalOpacity) &&
          isCurrentOpacityTarget(token)
      );
      if (target !== undefined) return { animation, target };
    }
    return null;
  };

  const observeHoveredZero = (event: PointerEvent) => {
    if (!event.isTrusted || event.target !== host) return;
    const tokens = applied?.surface.filter(
      (token) =>
        token.endsWith(':opacity-0') &&
        splitReceiptVariants(token).includes('hover') &&
        isLiveSurfaceToken(token)
    );
    hoveredZero = applied && tokens?.length ? { projection: applied, tokens } : null;
  };
  const observeHoverExit = (event: PointerEvent) => {
    const witness = hoveredZero;
    // Consume this input edge even when it produces no eligible transition.
    // A later foreign stylesheet withdrawal cannot reuse old hover history.
    hoveredZero = null;
    if (
      !event.isTrusted ||
      event.target !== host ||
      !witness ||
      witness.projection !== applied ||
      disposed ||
      surface.parentNode !== host.shadowRoot ||
      host.matches(':hover') ||
      !witness.tokens.some((token) => !isLiveSurfaceToken(token)) ||
      !isCurrentOpacityTarget(null)
    )
      return;
    const candidate = captureZeroOpacityTransition([null], []);
    zeroOpacityTransition =
      candidate?.animation.effect?.getComputedTiming().progress === 0 ? candidate : null;
  };
  host.addEventListener('pointerenter', observeHoveredZero);
  host.addEventListener('pointermove', observeHoveredZero);
  host.addEventListener('pointerleave', observeHoverExit);

  const fail = (entry: RootStyleEntry, reason: string): never => {
    throw invalid(
      `${entry.origin} token ${JSON.stringify(entry.authorToken)}:${reason}; fix: companion or change/remove token`
    );
  };
  const prepare = (handle: StyleHandle): Projection => {
    if (!('entries' in handle)) {
      throw invalid('root-provenance');
    }
    const entries = mergeRootStyleEntries(readRootStyleEntries(handle, 'setup'));
    if (
      entries.some((entry) =>
        ['animate-in', 'animate-out', '-translate-x-1/2', '-translate-y-1/2'].includes(
          entry.authorToken
        )
      )
    ) {
      const slide = entries.find((entry) => /^slide-(in|out)-/.test(entry.authorToken));
      if (slide) fail(slide, 'K1 slide');
    }
    const intrinsicTokens = ['inline-flex', 'flex-1', 'whitespace-nowrap'];
    if (intrinsicTokens.every((token) => entries.some((entry) => entry.authorToken === token))) {
      const flex = entries.find((entry) => entry.authorToken === 'flex-1')!;
      if (!hasRecipe('intrinsic-nowrap', 'v1')) fail(flex, 'intrinsic recipe');
      if (
        intrinsicTokens.some((token) =>
          entries.some((entry) => entry.authorToken === token && entry.token !== token)
        ) ||
        entries.some((entry) => /^(?:w-|min-w-|max-w-|size-)/.test(entry.authorToken))
      )
        fail(flex, 'intrinsic operands');
    }
    for (const entry of entries) {
      if (nativeText && entry.authorToken === 'overflow-y-auto') fail(entry, 'native scrollport');
      if (
        nativeText &&
        /^(?:(?:min-|max-)?[wh]-|size-|aspect-)/.test(entry.authorToken) &&
        !['w-full', 'min-h-16'].includes(entry.authorToken)
      )
        fail(entry, 'native-size');
      if (!['setup', 'rule', 'runtime'].includes(entry.origin) || !entry.authorToken) {
        fail(entry, 'author-origin');
      }
      try {
        assertTwTokenV0(entry.authorToken);
      } catch {
        fail(entry, 'author-origin');
      }
      const canonical = resolveRootStyleEntry(entry.authorToken, entry.origin);
      if (
        entry.role !== canonical.role ||
        entry.roleSource !== canonical.roleSource ||
        (entry.token !== entry.authorToken && !entry.token.endsWith(`:${entry.authorToken}`))
      ) {
        fail(entry, 'canonical-origin');
      }
      if (entry.role === 'unresolved') fail(entry, 'unresolved-role');
      const needsK1 = [
        '-translate-x-1/2',
        '-translate-y-1/2',
        'animate-in',
        'animate-out',
      ].includes(entry.authorToken);
      if (needsK1 && !hasRecipe('dialog-motion', 'k1')) fail(entry, 'K1 recipe');
      const needsI1 = entry.authorToken === 'hidden' || entry.authorToken === 'relative';
      if (needsI1 && !hasRecipe('participation-coordinate', 'i1')) fail(entry, 'I1 recipe');
      if (
        ((entry.role === 'root-geometry' && !needsI1 && !needsK1) ||
          entry.role === 'hit-testing' ||
          entry.authorToken === 'transition-all') &&
        !hasRecipe('motion', 'h1')
      )
        fail(entry, 'H1 recipe');
      if (entry.role === 'composite' && !COMPOSITES.has(entry.authorToken))
        fail(entry, 'composite');
      if (entry.role === 'composite' && entry.token !== entry.authorToken)
        fail(entry, 'conditional-composite');
      if (!hasExactCompiledReceipt(rules, entry)) {
        fail(entry, 'missing token');
      }
    }
    const logicalPadding = entries.find((entry) => /^(?:px|py)-/.test(entry.authorToken));
    if (logicalPadding) {
      const unsupported = entries.find(
        (entry) =>
          /^(?:p[trbl])-/.test(entry.authorToken) || /^border-[trbl](?:-|$)/.test(entry.authorToken)
      );
      if (unsupported)
        fail(logicalPadding, `directional:${JSON.stringify(unsupported.authorToken)}`);
    }
    const widths = borderWidthCandidates(entries);
    const borderWidths = JSON.stringify(widths);
    const animated = entries.find((e) => e.authorToken === 'transition-all');
    // H1 coordinates timing but does not reconcile animated border used-value
    // rounding with continuously interpolated surface margins.
    if (
      animated &&
      (widths.some((values) => values.length > 1) ||
        (applied && applied.borderWidths !== borderWidths))
    ) {
      fail(animated, 'used-value-rounding');
    }
    return {
      borderWidths,
      root: entries.map((e) => e.token).join(' '),
      surface: entries
        .filter(
          (e) =>
            e.role === 'surface' ||
            e.role === 'composite' ||
            (nativeText && ['w-full', 'min-h-16'].includes(e.authorToken))
        )
        .map((e) => e.token),
    };
  };
  const assertActive = () => {
    if (disposed) throw invalid('disposed');
  };
  const flush = () => {
    assertActive();
    if (!latest) return;
    if (flushing) {
      flushRequested = true;
      return;
    }
    flushing = true;
    const previous = applied;
    const next = latest;
    const suppressInitialTransition = !previous;
    try {
      // The surface is already connected, so the first opacity publication
      // would otherwise transition from the unpainted value. Settle it first.
      if (suppressInitialTransition)
        surface.style.setProperty('transition-property', 'none', 'important');
      // Removing the final owned opacity token also transitions to default 1.
      // Capture only the native transition created by this owned write.
      // Subsequent equal projections must not acquire a different animation.
      const eligible =
        ownsZeroOpacity() &&
        next.surface.some((token) => /(?:^|:)transition-(?:opacity|all)$/.test(token))
          ? next.surface.some((token) => /(?:^|:)opacity-/.test(token))
            ? next.surface.filter((token) => /(?:^|:)opacity-[1-9]\d*$/.test(token))
            : [null]
          : [];
      const before = eligible.length && surface.getAnimations ? surface.getAnimations() : null;
      hoveredZero = null;
      host.setAttribute(SHADOW_SPLIT_ROOT_STYLE_ATTR, next.root);
      if (nativeText) host.setAttribute(NATIVE_TEXT_ATTR, '');
      surface.setAttribute(SHADOW_SPLIT_SURFACE_ATTR, '');
      applier.apply(next.surface);
      applied = next;
      if (suppressInitialTransition) {
        void surface.ownerDocument.defaultView?.getComputedStyle(surface).opacity;
        surface.style.removeProperty('transition-property');
      }
      if (before) zeroOpacityTransition = captureZeroOpacityTransition(eligible, before);
      else if (zeroOpacityTransition && !isCurrentOpacityTarget(zeroOpacityTransition.target))
        zeroOpacityTransition = null;
    } catch (error) {
      // Restore both owned projections even when the failing target mutated before throwing.
      // DOM rollback itself may fail on a broken host; retain the original failure.
      try {
        applier.apply(previous?.surface ?? []);
      } catch {}
      try {
        if (previous) host.setAttribute(SHADOW_SPLIT_ROOT_STYLE_ATTR, previous.root);
        else host.removeAttribute(SHADOW_SPLIT_ROOT_STYLE_ATTR);
      } catch {}
      try {
        if (!previous) surface.removeAttribute(SHADOW_SPLIT_SURFACE_ATTR);
        if (!previous && nativeText) host.removeAttribute(NATIVE_TEXT_ATTR);
      } catch {}
      applied = latest = previous;
      zeroOpacityTransition = null;
      flushRequested = false;
      if (suppressInitialTransition) {
        try {
          surface.style.removeProperty('transition-property');
        } catch {}
      }
      throw error;
    } finally {
      flushing = false;
    }
    if (flushRequested) {
      flushRequested = false;
      // A same-projection request raised by a DOM callback needs no replay.
      if (!disposed && latest !== applied) flush();
    }
  };
  return {
    queueStyle(handle) {
      assertActive();
      latest = prepare(handle);
    },
    requestFlush: flush,
    flushNow: flush,
    dispose() {
      if (disposed) return;
      disposed = true;
      hoveredZero = null;
      host.removeEventListener('pointerenter', observeHoveredZero);
      host.removeEventListener('pointermove', observeHoveredZero);
      host.removeEventListener('pointerleave', observeHoverExit);
      activeBindings.delete(host);
      splitPaintOwners.delete(surface);
      const errors: unknown[] = [];
      const cleanup = (action: () => void) => {
        try {
          action();
        } catch (error) {
          errors.push(error);
        }
      };
      cleanup(() => applier.clear());
      cleanup(() => {
        if (applied && host.getAttribute(SHADOW_SPLIT_ROOT_STYLE_ATTR) === applied.root)
          host.removeAttribute(SHADOW_SPLIT_ROOT_STYLE_ATTR);
      });
      cleanup(() => {
        if (applied && surface.getAttribute(SHADOW_SPLIT_SURFACE_ATTR) === '')
          surface.removeAttribute(SHADOW_SPLIT_SURFACE_ATTR);
      });
      cleanup(() => {
        if (nativeText && applied && host.getAttribute(NATIVE_TEXT_ATTR) === '')
          host.removeAttribute(NATIVE_TEXT_ATTR);
      });
      zeroOpacityTransition = null;
      applied = latest = null;
      if (errors.length) throw errors[0];
    },
  };
}
