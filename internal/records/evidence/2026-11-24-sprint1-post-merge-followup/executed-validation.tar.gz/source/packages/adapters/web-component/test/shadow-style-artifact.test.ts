import { describe, expect, it, vi } from 'vitest';

import { renderProtoShadowStyleArtifact } from '../../../cli/src/services/proto-style-css';
import { createShadowOwnerShell } from '../src/shadow-owner-shell';
import {
  createShadowStyleArtifactOwner,
  SHADOW_STYLE_ARTIFACT_ENVIRONMENT,
  SHADOW_STYLE_ARTIFACT_KIND,
  SHADOW_STYLE_ARTIFACT_VERSION,
  validateShadowStyleArtifact,
} from '../src/shadow-style-artifact';

const SHADOW_CSS = `@layer proto-ui {
  :host([data-pui-color-scheme='dark']) :where([data-pui-style~="dark:bg-input/30"]) {
    background-color: color-mix(in oklab, var(--pui-input) 30%, transparent);
  }
}`;

function artifact(cssText = SHADOW_CSS) {
  return {
    kind: SHADOW_STYLE_ARTIFACT_KIND,
    version: SHADOW_STYLE_ARTIFACT_VERSION,
    cssText,
    environment: SHADOW_STYLE_ARTIFACT_ENVIRONMENT,
  };
}

function createShell() {
  const host = document.createElement('x-shadow-style-artifact');
  return createShadowOwnerShell(host.attachShadow({ mode: 'open' }));
}

// Count the real comment scanner without a timing threshold or a cache API.
function withCommentScanCount(cssText: string, run: (count: () => number) => void) {
  const indexOf = String.prototype.indexOf;
  let scans = 0;
  const spy = vi.spyOn(String.prototype, 'indexOf').mockImplementation(function (
    this: string,
    search: string,
    position?: number
  ) {
    if (this === cssText && search === '*/' && position === 2) scans += 1;
    return indexOf.call(this, search, position);
  });
  try {
    run(() => scans);
  } finally {
    spy.mockRestore();
  }
}

describe('adapter-web-component Shadow style artifact', () => {
  it('accepts the exact v1 shape as a frozen canonical copy', () => {
    const input = artifact();
    const validated = validateShadowStyleArtifact(input);

    expect(validated).toEqual(input);
    expect(validated).not.toBe(input);
    expect(Object.isFrozen(validated)).toBe(true);
  });

  it('validates and copies the same accessor-backed CSS snapshot', () => {
    let reads = 0;
    const input = artifact();
    Object.defineProperty(input, 'cssText', {
      enumerable: true,
      get: () => (++reads < 3 ? SHADOW_CSS : `[data-pui-style~='dark:bg-primary'] {}`),
    });

    const validated = validateShadowStyleArtifact(input);

    expect(reads).toBe(1);
    expect(validated.cssText).toBe(SHADOW_CSS);
  });

  it('reuses successful CSS analysis while returning a fresh canonical copy', () => {
    const cssText = `/* shared selector analysis */${SHADOW_CSS}`;
    withCommentScanCount(cssText, (scans) => {
      const first = validateShadowStyleArtifact(artifact(cssText));
      const second = validateShadowStyleArtifact(artifact(cssText));
      expect(scans()).toBe(1);
      expect(second).toEqual(first);
      expect(second).not.toBe(first);
      expect(Object.isFrozen(second)).toBe(true);
    });
  });

  it('reads keys and every field in order even for frozen inputs with cached CSS', () => {
    const reads: string[] = [];
    const values: Record<string, unknown> = artifact(`/* live artifact fields */${SHADOW_CSS}`);
    const input = Object.freeze(
      new Proxy(
        Object.defineProperties(
          {},
          Object.fromEntries(
            Object.keys(values).map((key) => [
              key,
              { enumerable: true, get: () => (reads.push(key), values[key]) },
            ])
          )
        ),
        {
          ownKeys(target) {
            reads.push('keys');
            return Reflect.ownKeys(target);
          },
        }
      )
    );
    const expected = ['keys', 'kind', 'version', 'cssText', 'environment'];
    for (let index = 0; index < 2; index += 1) {
      reads.length = 0;
      expect(validateShadowStyleArtifact(input).cssText).toBe(values.cssText);
      expect(reads).toEqual(expected);
    }
    for (const [field, value] of [
      ['kind', 'other'],
      ['version', 2],
      ['environment', 'other'],
      ['cssText', null],
    ] as const) {
      const previous = values[field];
      values[field] = value;
      reads.length = 0;
      expect(() => validateShadowStyleArtifact(input)).toThrow(`invalid shadow-style:${field}`);
      expect(reads).toEqual(expected);
      values[field] = previous;
    }
    values.cssText = `[data-pui-style~='dark:bg-primary'] {}`;
    reads.length = 0;
    expect(() => validateShadowStyleArtifact(input)).toThrow('invalid shadow-style:dark');
    expect(reads).toEqual(expected);

    const get = vi.fn();
    const extra = new Proxy({ ...artifact(), extra: true }, { get });
    expect(() => validateShadowStyleArtifact(extra)).toThrow('invalid shadow-style:fields');
    expect(get).not.toHaveBeenCalled();
  });

  it('checks changed CSS and does not retain a failed selector analysis', () => {
    const prefix = '/* changed selector analysis */';
    validateShadowStyleArtifact(artifact(`${prefix}${SHADOW_CSS}`));
    const invalid = `${prefix}[data-pui-style~='dark:bg-primary'] {}`;
    withCommentScanCount(invalid, (scans) => {
      for (let index = 0; index < 2; index += 1)
        expect(() => validateShadowStyleArtifact(artifact(invalid))).toThrow(
          'invalid shadow-style:dark'
        );
      expect(scans()).toBe(2);
    });
  });

  it('bounds successful selector analysis by entry count', () => {
    const cssText = '/* selector entry budget first */.first {}';
    withCommentScanCount(cssText, (scans) => {
      validateShadowStyleArtifact(artifact(cssText));
      for (let index = 0; index < 32; index += 1)
        validateShadowStyleArtifact(artifact(`/* selector entry budget ${index} */.next {}`));
      validateShadowStyleArtifact(artifact(cssText));
      expect(scans()).toBe(2);
    });
  });

  it('bounds successful selector analysis by total characters', () => {
    const padding = 'x'.repeat(600 * 1024);
    const cssText = `/* selector character budget first ${padding} */.first {}`;
    withCommentScanCount(cssText, (scans) => {
      validateShadowStyleArtifact(artifact(cssText));
      validateShadowStyleArtifact(
        artifact(`/* selector character budget next ${padding} */.next {}`)
      );
      validateShadowStyleArtifact(artifact(cssText));
      expect(scans()).toBe(2);
    });
  });

  it('validates oversized CSS on every call without retaining it', () => {
    const cssText = `/* oversized selector analysis ${'x'.repeat(1024 * 1024)} */.large {}`;
    withCommentScanCount(cssText, (scans) => {
      expect(validateShadowStyleArtifact(artifact(cssText)).cssText).toBe(cssText);
      expect(validateShadowStyleArtifact(artifact(cssText)).cssText).toBe(cssText);
      expect(scans()).toBe(2);
    });
  });

  it('accepts the artifact produced by the CLI Shadow renderer', () => {
    const generated = renderProtoShadowStyleArtifact(['dark:bg-input/30']);
    const validated = validateShadowStyleArtifact(generated);

    expect(validated).toEqual(generated);
    expect(validated.cssText).toContain(
      `:where(:host([data-pui-color-scheme='dark'])) :where([data-pui-style~="dark:bg-input/30"])`
    );
  });

  it('accepts equivalent quoted dark token selectors under the positive host scope', () => {
    expect(() =>
      validateShadowStyleArtifact(
        artifact(
          `:host([data-pui-color-scheme="dark"]) [ data-pui-style ~= 'dark:bg-input/30' ] { color: red; }`
        )
      )
    ).not.toThrow();
  });

  it('accepts a host-dark-scoped functional selector list', () => {
    expect(() =>
      validateShadowStyleArtifact(
        artifact(
          `:where(:host([data-pui-color-scheme="dark"])) :is([data-pui-style~="dark:bg-primary"], [data-pui-style~="dark:text-primary"]) { color: red; }`
        )
      )
    ).not.toThrow();
  });

  it.each([
    ['host class name with a dark prefix', `.dark-mode`],
    ['case-distinct Dark host class', `.Dark`],
    ['case-distinct LIGHT host class', `.LIGHT`],
    ['host class name with an escaped suffix', String.raw`.dark\:active`],
    ['host class name with an escaped hyphen', String.raw`.dark\2d mode`],
    ['host class name with an escaped dot', String.raw`.\.dark`],
    ['theme-like text in a quoted attribute', `[data-label='.dark, .light, [data-theme=dark]']`],
    ['a different theme-like attribute name', `[data-theme-label='dark']`],
    ['nested functional quoted text', `:is(:where([data-label='.dark']), .supported)`],
    [
      'a functional selector containing quoted theme text',
      `:is([data-label='.dark'], [data-label='[data-theme=dark]'])`,
    ],
  ])('accepts %s beside the host marker', (_label, hostSuffix) => {
    expect(() =>
      validateShadowStyleArtifact(
        artifact(
          `:host([data-pui-color-scheme='dark'])${hostSuffix} [data-pui-style~='dark:bg-primary'] { color: red; }`
        )
      )
    ).not.toThrow();
  });

  it.each([
    ['dark descendant class', ` .dark`],
    ['light descendant class', ` .light`],
    ['descendant theme attribute', ` [data-theme='dark']`],
    ['child combinator', `>.dark`],
    ['descendant functional selector list', ` :is(.dark, .light, [data-theme='dark'])`],
  ])('accepts an unrelated Shadow-local %s', (_label, descendant) => {
    expect(() =>
      validateShadowStyleArtifact(
        artifact(
          `:host([data-pui-color-scheme='dark'])${descendant} [data-pui-style~='dark:bg-primary'] { color: red; }`
        )
      )
    ).not.toThrow();
  });

  it.each([
    ['plain dark class', `.dark`],
    ['plain light class', `.light`],
    ['hex-escaped dark class initial', String.raw`.\64 ark`],
    ['hex-escaped dark class letter', String.raw`.d\61 rk`],
    ['six-digit escaped dark class initial', String.raw`.\000064ark`],
    ['simple-escaped dark class letter', String.raw`.dar\k`],
    ['theme attribute', `[data-theme='dark']`],
    ['theme attribute presence', `[ data-theme ]`],
    ['escaped theme attribute', String.raw`[data\2d theme='dark']`],
    ['functional dark class gate', `:is(.dark)`],
    ['nested functional dark class gate', `:is(:where(.dark))`],
    ['functional dark class gate after argument whitespace', `:is(.supported, .dark)`],
    ['functional theme attribute gate', `:where([data-theme='dark'])`],
  ])('rejects a second %s beside the host marker', (_label, hostSuffix) => {
    expect(() =>
      validateShadowStyleArtifact(
        artifact(
          `:host([data-pui-color-scheme='dark'])${hostSuffix} [data-pui-style~='dark:bg-primary'] { color: red; }`
        )
      )
    ).toThrow('invalid shadow-style:');
  });

  it('accepts document marker text inside a Shadow-local attribute value', () => {
    expect(() =>
      validateShadowStyleArtifact(
        artifact(`[data-label=':root'] [data-pui-style~='block'] { display: block; }`)
      )
    ).not.toThrow();
    expect(() =>
      validateShadowStyleArtifact(
        artifact(`[data-pui-style~='block'] { --generated-label: ':root'; display: block; }`)
      )
    ).not.toThrow();
    expect(() =>
      validateShadowStyleArtifact(
        artifact(`@supports selector(:root) { [data-pui-style~='block'] { display: block; } }`)
      )
    ).not.toThrow();
  });

  it.each([
    ['missing', undefined],
    ['wrong kind', { ...artifact(), kind: 'proto-ui.document-style' }],
    ['wrong version', { ...artifact(), version: 2 }],
    ['wrong environment', { ...artifact(), environment: 'document-color-scheme-v1' }],
    ['non-string cssText', { ...artifact(), cssText: null }],
    ['extra field', { ...artifact(), nonce: 'not-part-of-v1' }],
    [
      'document dark selectors',
      artifact(`:where(.dark) :where([data-pui-style~="dark:bg-input/30"]) { color: red; }`),
    ],
    [
      'host-context document dark class beside the host marker',
      artifact(
        `:host([data-pui-color-scheme='dark']):host-context(.dark) [data-pui-style~='dark:bg-primary'] { color: red; }`
      ),
    ],
    [
      'host-context document theme attribute beside the host marker',
      artifact(
        `:host([data-pui-color-scheme='dark']):host-context([data-theme='dark']) [data-pui-style~='dark:bg-primary'] { color: red; }`
      ),
    ],
    [
      'escaped host-context pseudo beside the host marker',
      artifact(
        `:host([data-pui-color-scheme='dark']):host-con\\74 ext(.dark) [data-pui-style~='dark:bg-primary'] { color: red; }`
      ),
    ],
    [
      'system dark media without optional whitespace',
      artifact(
        `@media(prefers-color-scheme:dark) { :host([data-pui-color-scheme='dark']) [data-pui-style~='dark:bg-input/30'] { color: red; } }`
      ),
    ],
    [
      'compound system dark media with equivalent casing',
      artifact(
        `@MEDIA screen and (PREFERS-COLOR-SCHEME : DARK) { :host([data-pui-color-scheme='dark']) [data-pui-style~='dark:bg-input/30'] { color: red; } }`
      ),
    ],
    [
      'system light media around a host-dark rule',
      artifact(
        `@media (prefers-color-scheme: light) { :host([data-pui-color-scheme='dark']) [data-pui-style~='dark:bg-input/30'] { color: red; } }`
      ),
    ],
    [
      'negated system color-scheme media around a host-dark rule',
      artifact(
        `@media not (prefers-color-scheme: light) { :host([data-pui-color-scheme='dark']) [data-pui-style~='dark:bg-input/30'] { color: red; } }`
      ),
    ],
    [
      'hex-escaped hyphen in a system color-scheme media feature',
      artifact(
        `@media (prefers\\2d color-scheme: light) { :host([data-pui-color-scheme='dark']) [data-pui-style~='dark:bg-input/30'] { color: red; } }`
      ),
    ],
    [
      'hex-escaped letter in a system color-scheme media feature',
      artifact(
        `@media (prefers-color-sch\\65 me: light) { :host([data-pui-color-scheme='dark']) [data-pui-style~='dark:bg-input/30'] { color: red; } }`
      ),
    ],
    [
      'hex-escaped letter in the media at-keyword',
      artifact(
        `@m\\65 dia (prefers-color-scheme: dark) { :host([data-pui-color-scheme='dark']) [data-pui-style~='dark:bg-input/30'] { color: red; } }`
      ),
    ],
    [
      'dark rule without the host marker',
      artifact(`:where([data-pui-style~="dark:bg-input/30"]) { color: red; }`),
    ],
    [
      'single-quoted dark rule without the host marker',
      artifact(`:where([data-pui-style~='dark:bg-input/30']) { color: red; }`),
    ],
    [
      'whitespace-normalized dark rule without the host marker',
      artifact(`:where([ data-pui-style ~= "dark:bg-input/30" ]) { color: red; }`),
    ],
    [
      'class descendant dark rule without the host marker',
      artifact(`.wrapper [data-pui-style~='dark:bg-input/30'] { color: red; }`),
    ],
    [
      'element descendant dark rule without the host marker',
      artifact(`section [data-pui-style~="dark:bg-input/30"] { color: red; }`),
    ],
    [
      'dark token after another token attribute',
      artifact(`[data-pui-style~="p-2"][data-pui-style~="dark:bg-input/30"] { color: red; }`),
    ],
    [
      'case-insensitive dark token selector',
      artifact(`[data-pui-style~="DARK:bg-input/30" i] { color: red; }`),
    ],
    [
      'escaped dark token selector',
      artifact(`[data-pui-style~='d\\000061rk:bg-input/30'] { color: red; }`),
    ],
    [
      'escaped style attribute selector',
      artifact(`[data-pui-st\\000079le~='dark:bg-input/30'] { color: red; }`),
    ],
    [
      'escaped hyphen in style attribute selector',
      artifact(`[data\\-pui-style~='dark:bg-input/30'] { color: red; }`),
    ],
    [
      'hex-escaped hyphen in style attribute selector',
      artifact(`[data\\2d pui-style~='dark:bg-input/30'] { color: red; }`),
    ],
    [
      'unscoped dark rule beside an unrelated host marker',
      artifact(`${SHADOW_CSS}\n:where([data-pui-style~="dark:bg-input/30"]) { color: red; }`),
    ],
    [
      'dark rule under a negated host marker',
      artifact(
        `:not(:host([data-pui-color-scheme='dark'])) :where([data-pui-style~="dark:bg-input/30"]) { color: red; }`
      ),
    ],
    [
      'dark rule beside a comment-only host marker',
      artifact(
        `/* :host([data-pui-color-scheme='dark']) */ :where([data-pui-style~="dark:bg-input/30"]) { color: red; }`
      ),
    ],
    [
      'unscoped dark rule between quoted comment delimiters',
      artifact(`[data-x="/*"][data-pui-style~="dark:bg-primary"][data-y="*/"] { color: red; }`),
    ],
    [
      'dark rule beside a string-only host marker',
      artifact(
        `[data-proof=":host([data-pui-color-scheme='dark'])"] :where([data-pui-style~="dark:bg-input/30"]) { color: red; }`
      ),
    ],
    [
      'dark rule with an optional host-marker branch',
      artifact(
        `:is(:host([data-pui-color-scheme='dark']), :host) :where([data-pui-style~="dark:bg-input/30"]) { color: red; }`
      ),
    ],
    [
      'top-level unscoped branch beside a scoped functional selector list',
      artifact(
        `:where(:host([data-pui-color-scheme='dark'])) :is([data-pui-style~='dark:bg-primary'], [data-pui-style~='dark:text-primary']), [data-pui-style~='dark:border-primary'] { color: red; }`
      ),
    ],
  ])('rejects %s', (_label, input) => {
    expect(() => validateShadowStyleArtifact(input)).toThrow('invalid shadow-style:');
  });

  it('installs and deterministically updates a stable owner stylesheet', () => {
    const shell = createShell();
    const owner = createShadowStyleArtifactOwner(shell, artifact());
    const element = owner.stylesheet.element;
    const nextCss = ':where([data-pui-style~="block"]) { display: block; }';
    const sameOwner = createShadowStyleArtifactOwner(shell, artifact(nextCss));

    expect(sameOwner).toBe(owner);
    expect(sameOwner.stylesheet.element).toBe(element);
    expect(sameOwner.artifact.cssText).toBe(nextCss);
    expect(sameOwner.stylesheet.cssText).toBe(nextCss);
    expect(element.textContent).toBe(nextCss);
    expect(shell.root.querySelectorAll('[data-pui-shadow-stylesheet]')).toHaveLength(1);
  });

  it('validates an update before mutating the installed artifact or stylesheet', () => {
    const shell = createShell();
    const owner = createShadowStyleArtifactOwner(shell, artifact());
    const previousArtifact = owner.artifact;
    const previousCss = owner.stylesheet.cssText;

    expect(() => owner.update({ ...artifact(), version: 2 })).toThrow('invalid shadow-style');
    expect(owner.artifact).toBe(previousArtifact);
    expect(owner.stylesheet.cssText).toBe(previousCss);
  });

  it('survives view-epoch content replacement and disposes owner resources idempotently', () => {
    const shell = createShell();
    const owner = createShadowStyleArtifactOwner(shell, artifact());
    const first = document.createElement('div');
    const second = document.createElement('span');

    shell.replaceRenderedChildren([first]);
    shell.clearRenderedChildren();
    shell.replaceRenderedChildren([second]);

    expect(shell.root.firstChild).toBe(owner.stylesheet.element);
    expect(shell.root.lastChild).toBe(second);

    owner.dispose();
    owner.dispose();
    expect(owner.stylesheet.element.parentNode).toBeNull();
    expect(() => owner.update(artifact())).toThrow(/shadow-style:disposed/);

    const nextOwner = createShadowStyleArtifactOwner(shell, artifact());
    expect(nextOwner).not.toBe(owner);
    expect(nextOwner.stylesheet.element).not.toBe(owner.stylesheet.element);
  });
});
