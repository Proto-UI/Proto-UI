import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { describe, expect, it } from 'vitest';

import { scanRuleStateReads } from '../src/services/lowered-hook-coverage';
import { collectProtoStyleTokensFromFiles } from '../src/services/prototype-style-tokens';

type TokenMapFixture = {
  declarations: string;
  argument: string;
  constants?: string;
};

const template = (member: string, suffix: string) =>
  String.fromCharCode(96) + '$' + '{' + member + '} ' + suffix + String.fromCharCode(96);

async function observeTokenMap({ declarations, argument, constants }: TokenMapFixture) {
  const directory = await mkdtemp(path.join(tmpdir(), 'lowered-token-map-'));
  try {
    const producer = path.join(directory, 'producer.ts');
    const file = path.join(directory, 'consumer.proto.ts');
    await writeFile(
      producer,
      [
        "import { defineAsHook } from '@proto.ui/core';",
        'export const asTokenMapState = defineAsHook({',
        "  name: 'token-map-state',",
        "  setup(def) { def.state.bool('ready', false); },",
        '  projectHandle: (result) => ({ ready: result.stateHandles.ready }),',
        '});',
      ].join('\n')
    );
    if (constants !== undefined) await writeFile(path.join(directory, 'tokens.ts'), constants);
    const source = [
      "import { definePrototype, tw } from '@proto.ui/core';",
      "import { asTokenMapState } from './producer';",
      ...(constants === undefined ? [] : ["import { TOKENS } from './tokens';"]),
      'export default definePrototype({',
      "  name: 'token-map-consumer',",
      '  setup(def) {',
      '    const { ready } = asTokenMapState();',
      declarations,
      '    def.rule({',
      '      when: (w) => w.state(ready).eq(true),',
      '      intent: (i) => i.feedback.style.use(tw(' + argument + ')),',
      '    });',
      '  },',
      '});',
    ].join('\n');
    await writeFile(file, source);
    // Assert the actual prefixed collector output, not the unprefixed inventory.
    const tokens = (await collectProtoStyleTokensFromFiles([file])).filter((token) =>
      token.startsWith('data-[ready]:')
    );
    return { scan: scanRuleStateReads(source, file), tokens, producer };
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
}

describe.sequential('lowered literal token-map coverage agrees with actual collection', () => {
  const literal = "const TOKENS = { active: 'bg-primary' };";
  for (const [name, fixture, expectedTokens] of [
    [
      'literal element control',
      { declarations: literal, argument: "TOKENS['active']" },
      ['bg-primary'],
    ],
    ['literal dot', { declarations: literal, argument: 'TOKENS.active' }, ['bg-primary']],
    [
      'literal dot inside a template',
      { declarations: literal, argument: template('TOKENS.active', 'ring-2') },
      ['bg-primary', 'ring-2'],
    ],
    [
      'literal dot in a variadic tw',
      { declarations: literal, argument: "TOKENS.active, 'ring-2'" },
      ['bg-primary', 'ring-2'],
    ],
    [
      'nested literal dot',
      {
        declarations: "const TOKENS = { palette: { active: 'bg-primary' } };",
        argument: 'TOKENS.palette.active',
      },
      ['bg-primary'],
    ],
    [
      'relative named constant dot',
      {
        declarations: '',
        constants: "export const TOKENS = { active: 'bg-primary' };",
        argument: 'TOKENS.active',
      },
      ['bg-primary'],
    ],
    [
      'relative named constant dot inside a template',
      {
        declarations: '',
        constants: "export const TOKENS = { active: 'bg-primary' };",
        argument: template('TOKENS.active', 'ring-2'),
      },
      ['bg-primary', 'ring-2'],
    ],
  ] as const) {
    it(name, async () => {
      const { scan, tokens, producer } = await observeTokenMap(fixture);
      expect(tokens).toEqual(expectedTokens.map((token) => 'data-[ready]:' + token).sort());
      expect(scan.unresolved).toEqual([]);
      expect(scan.exposedLocals).toEqual([]);
      expect(
        scan.usages.map(({ hook, state, provenance }) => ({
          hook,
          state,
          declaredName: provenance?.declaredName,
          owner: provenance?.owner.file,
          declaration: provenance?.declaration.file,
        }))
      ).toEqual([
        {
          hook: 'asTokenMapState',
          state: 'ready',
          declaredName: 'ready',
          owner: producer,
          declaration: producer,
        },
      ]);
    });
  }

  for (const [name, declarations, argument, inventory] of [
    ['missing own member', literal, 'TOKENS.missing', []],
    ['primitive receiver', "const TOKENS = 'bg-primary';", 'TOKENS.active', []],
    [
      'getter member',
      "const TOKENS = { get active() { return 'bg-primary'; } };",
      'TOKENS.active',
      [],
    ],
    [
      'opaque spread',
      "const TOKENS = { active: 'bg-primary', ...opaque };",
      'TOKENS.active',
      ['bg-primary'],
    ],
    ['unknown member write', literal + '\nTOKENS.active = getTokens();', 'TOKENS.active', []],
    [
      'owner escapes to unknown code',
      literal + '\nmutate(TOKENS);',
      'TOKENS.active',
      ['bg-primary'],
    ],
    [
      'unknown index before dot',
      "const TOKENS = { palette: { active: 'bg-primary' } };",
      'TOKENS[key].active',
      ['bg-primary'],
    ],
  ] as const) {
    it('withholds complete coverage for ' + name, async () => {
      const { scan, tokens } = await observeTokenMap({ declarations, argument });
      // Known inventory may survive an opaque overwrite or escape. That is not
      // proof that every runtime token is available to the lowered rule.
      expect(tokens).toEqual(inventory.map((token) => 'data-[ready]:' + token).sort());
      expect(scan.usages).toEqual([]);
      expect(scan.exposedLocals).toEqual([]);
      expect(scan.unresolved.map(({ reason }) => reason)).toEqual(['intent']);
    });
  }
});
