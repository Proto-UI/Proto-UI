from pathlib import Path
import subprocess,json,os,datetime
root=Path('/home/ezra/proto-ui-sprint1-validation-3148794d');out=Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation')
node='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/node/bin/node';env=os.environ.copy();env.update({'PATH':str(Path(node).parent)+os.pathsep+env['PATH'],'NODE_OPTIONS':'--max-old-space-size=768'})


pnpm='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/pnpm/bin/pnpm.cjs'
def run(name,inner,seconds):
 args=['systemd-run','--user','--scope','--property=MemoryMax=1536M','--property=MemorySwapMax=0','--','/home/ezra/.omp/agent/bin/agent-heavy','timeout','--signal=TERM','--kill-after=5s',str(seconds)+'s',*inner]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/(name+'.receipt.json')).write_text(json.dumps({'args':args,'exit':p.returncode,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'mergeHead':subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=root,text=True).strip()},indent=2)+'\n')
 print(name,p.returncode,flush=True);return p.returncode

env['TMPDIR']=str(out/'task-temp')
assert Path(env['TMPDIR']).is_dir()
selection=json.loads(subprocess.check_output([node,'--input-type=module','-e',"import {SPRINT1_INTEGRATION_UNIT_SUITES as integration,SPRINT1_NODE_SUITES as controls} from './scripts/test/sprint1-evidence.mjs'; console.log(JSON.stringify({integration,controls}));"],cwd=root,env=env,text=True))
changed=subprocess.check_output(['git','diff','--name-only','824f7b12d828a179670e1d751f5f2c14d97d995d'],cwd=root,text=True).splitlines()
formats=[p for p in changed if Path(p).suffix in ['.ts','.mjs','.yml'] and '/generated/' not in p]
formats.append('packages/cli/test/lowered-token-map-coverage.test.ts')
def vi(name,files):return [node,'node_modules/vitest/vitest.mjs','run',*files,'--no-file-parallelism','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/(name+'-vitest.json'))]
(out/'postmerge-isolated-temp-context.json').write_text(json.dumps({'TMPDIR':env['TMPDIR'],'reason':'Shared /tmp is a 4 GiB full tmpfs; repo filesystem has >200 GiB available. No shared files removed. Original ENOSPC attempt retained. Test inventories/timeouts unchanged.'},indent=2)+'\n')
jobs=[
 ('postmerge-source-format',[node,'node_modules/prettier/bin/prettier.cjs','--write',*formats],90),
 ('postmerge-ci-controls-green',[node,'--test','--test-reporter=tap','scripts/ci/test/ci-scheduling-policy.test.mjs'],90),
 ('postmerge-node-controls-green',[node,'--test','--test-reporter=tap',*selection['controls']],90),
 ('postmerge-integration-isolated-tmp',vi('postmerge-integration-isolated-tmp',selection['integration']),90),
 ('token-map-paired-red',vi('token-map-paired-red',['packages/cli/test/lowered-token-map-coverage.test.ts']),90),
 ('postmerge-lowered-current-witness',vi('postmerge-lowered-current-witness',['packages/cli/test/lowered-hook-coverage.test.ts']),120),
]
for job in jobs:run(*job)
