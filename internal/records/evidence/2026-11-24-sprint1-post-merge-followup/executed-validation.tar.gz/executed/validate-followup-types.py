from pathlib import Path
import subprocess,json,os,datetime
root=Path('/home/ezra/proto-ui-sprint1-postmerge-20261124-56f6684');out=Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation');node='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/node/bin/node'
env=os.environ.copy();env.update({'PATH':str(Path(node).parent)+os.pathsep+env['PATH'],'NODE_OPTIONS':'--max-old-space-size=768','TMPDIR':str(out/'task-temp')})
assert subprocess.check_output(['git','write-tree'],cwd=root,text=True).strip()=='10d59b5ffec0b3ea08ffe0305153e342bb17b72e'
args=['systemd-run','--user','--scope','--property=MemoryMax=1536M','--property=MemorySwapMax=0','--','/home/ezra/.omp/agent/bin/agent-heavy','timeout','--signal=TERM','--kill-after=5s','300s',node,'node_modules/typescript/bin/tsc','-p','tsconfig.workspace.json','--noEmit'];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/'followup-workspace-types.log').open('w') as log:p=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'followup-workspace-types.receipt.json').write_text(json.dumps({'args':args,'exit':p.returncode,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':'824f7b12d828a179670e1d751f5f2c14d97d995d','sourceTree':'10d59b5ffec0b3ea08ffe0305153e342bb17b72e','TMPDIR':env['TMPDIR']},indent=2)+'\n');print('followup-workspace-types',p.returncode,flush=True)
