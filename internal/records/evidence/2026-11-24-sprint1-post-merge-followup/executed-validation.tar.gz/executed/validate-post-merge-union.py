from pathlib import Path
import subprocess,json,os,datetime
root=Path('/home/ezra/proto-ui-sprint1-validation-3148794d');out=Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation')
node='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/node/bin/node';env=os.environ.copy();env.update({'PATH':str(Path(node).parent)+os.pathsep+env['PATH'],'NODE_OPTIONS':'--max-old-space-size=768'})


pnpm='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/pnpm/bin/pnpm.cjs'
def run(name,inner,seconds):
 args=['systemd-run','--user','--scope','--property=MemoryMax=1536M','--property=MemorySwapMax=0','--','/home/ezra/.omp/agent/bin/agent-heavy','timeout','--signal=TERM','--kill-after=5s',str(seconds)+'s',*inner]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/(name+'.receipt.json')).write_text(json.dumps({'args':args,'exit':p.returncode,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'mergeHead':subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=root,text=True).strip()},indent=2)+'\n')
 print(name,p.returncode,flush=True);return p.returncode
assert subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=root,text=True).strip()=='824f7b12d828a179670e1d751f5f2c14d97d995d'
if run('postmerge-frozen-offline-install',[node,pnpm,'install','--frozen-lockfile','--offline'],600):raise SystemExit('dependency install failed; tests not run')
selection=json.loads(subprocess.check_output([node,'--input-type=module','-e',"import {SPRINT1_INTEGRATION_UNIT_SUITES as integration,SPRINT1_NODE_SUITES as controls} from './scripts/test/sprint1-evidence.mjs'; console.log(JSON.stringify({integration,controls}));"],cwd=root,env=env,text=True))
cli=['packages/cli/test/'+x+'.test.ts' for x in ['hook-source-export-patterns','hook-source-receiver-mutation','hook-source-write-index','hook-source-projector-scope','prototype-style-tokens','hook-source-resolution-mode','hook-source-collision-order','hook-source-lexical-index','hook-source-projection-accessors']]
def vi(name,files):return [node,'node_modules/vitest/vitest.mjs','run',*files,'--no-file-parallelism','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/(name+'-vitest.json'))]
jobs=[
 ('postmerge-ci-controls-red',[node,'--test','--test-reporter=tap','scripts/ci/test/ci-scheduling-policy.test.mjs'],90),
 ('postmerge-cli-related',vi('postmerge-cli-related',cli),90),
 ('postmerge-sprint1-integration',vi('postmerge-sprint1-integration',selection['integration']),90),
 ('postmerge-sprint1-node',[node,'--test','--test-reporter=tap',*selection['controls']],90),
 ('postmerge-lowered',vi('postmerge-lowered',['packages/cli/test/lowered-hook-coverage.test.ts']),120),
 ('postmerge-styles-generate',[node,pnpm,'run','styles:preset:generate'],600),
 ('postmerge-styles-check',[node,pnpm,'run','check:styles:preset'],600),
 ('postmerge-coverage-source',[node,'scripts/coverage-matrices/check-coverage-matrices.mjs'],600),
]
for job in jobs:run(*job)
