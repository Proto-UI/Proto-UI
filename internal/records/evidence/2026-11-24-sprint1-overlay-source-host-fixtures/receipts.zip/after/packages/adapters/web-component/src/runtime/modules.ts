import { subscribeScrollTarget } from './scroll-target';
import { createWebPresencePresentationSink } from '@proto.ui/adapter-base';
import { createWebShaderPresentationSink } from '@proto.ui/adapter-base';
import { SHADER_PRESENTATION_SINK_CAP } from '@proto.ui/module-feedback';
import {
  PRESENCE_PRESENTATION_SINK_CAP,
  PRESENCE_RUN_IN_CALLBACK_CAP,
  type PresencePresentationSink,
} from '@proto.ui/module-feedback';
import { createWebResidentMotionSink, type WebResidentMotionOptions } from '@proto.ui/adapter-base';
import { RESIDENT_MOTION_SINK_CAP, OWNED_DECORATION_CAP } from '@proto.ui/module-feedback';
import {
  NATIVE_LINK_HOST_CAP,
  NATIVE_LINK_RUN_IN_CALLBACK_CAP,
  createWebNativeLinkHost,
} from '@proto.ui/module-native-link';
import { AXIS_INPUT_HOST_CAP, AXIS_INPUT_RUN_IN_CALLBACK_CAP } from '@proto.ui/module-axis-input';
import { createWebAxisInputHost } from '@proto.ui/adapter-base';
import { isWebFocusTargetActive, orderFocusTargetsByDocument } from '@proto.ui/adapter-base';
import {
  CONTROL_LABEL_HOST_CAP,
  CONTROL_LABEL_RUN_IN_CALLBACK_CAP,
  createWebControlLabelHost,
} from '@proto.ui/module-control-label';
import {
  cancelWebEventDefaultAction,
  createCapsWiring,
  retainWebPortalDirection,
  createWebMoveGestureHost,
  type HostSurfaceProjection,
  type LogicalInstanceToken,
} from '@proto.ui/adapter-base';
import {
  HOST_ELEMENT_CAP,
  type CapEntries,
  type EffectsPort,
  type FocusEntryConfig,
  type FocusRequestOptions,
  type ScrollProjectionPreference,
} from '@proto.ui/core';
import {
  createDomOrderObserver,
  ANATOMY_GET_PROTO_CAP,
  ANATOMY_INSTANCE_TOKEN_CAP,
  ANATOMY_ORDER_OBSERVER_CAP,
  ANATOMY_PARENT_CAP,
  ANATOMY_ROOT_TARGET_CAP,
} from '@proto.ui/module-anatomy';
import {
  AS_TRIGGER_GET_PROTO_CAP,
  AS_TRIGGER_GET_GROUP_EVENT_TARGET_CAP,
  AS_TRIGGER_INSTANCE_CAP,
  AS_TRIGGER_MERGE_GROUP_CAP,
  AS_TRIGGER_PARENT_CAP,
} from '@proto.ui/module-as-trigger';
import { A11Y_PROJECT_CAP, createWebA11yProjector } from '@proto.ui/module-a11y';
import { createWebBoundaryHostBridge, BOUNDARY_HOST_BRIDGE_CAP } from '@proto.ui/module-boundary';
import { CONTEXT_INSTANCE_TOKEN_CAP, CONTEXT_PARENT_CAP } from '@proto.ui/module-context';
import {
  EFFECTS_CAP,
  VISUAL_FEEDBACK_SINK_CAP,
  type VisualFeedbackSink,
} from '@proto.ui/module-feedback';
import {
  MATERIAL_BINDING_FACTORY_CAP,
  type MaterialBindingFactory,
} from '@proto.ui/module-feedback/internal/runtime-cap';
import {
  FINAL_STYLE_SINK_CAP,
  type FinalStyleSink,
} from '@proto.ui/module-feedback/internal/final-style-sink';
import {
  EVENT_CANCEL_DEFAULT_ACTION_CAP,
  EVENT_GLOBAL_TARGET_CAP,
  EVENT_GLOBAL_INPUT_SCOPE_CAP,
  EVENT_ROOT_TARGET_CAP,
} from '@proto.ui/module-event';
import { EXPOSE_EVENT_SINK_CAP } from '@proto.ui/module-expose-event';
import { EXPOSES_RECORD_SINK_CAP } from '@proto.ui/module-expose-state';
import {
  createExposeStateWebNameMap,
  createExposeStateWebNativeVariantPolicy,
  EXPOSE_STATE_WEB_MAP_CAP,
  EXPOSE_STATE_WEB_MIRROR_TARGETS_CAP,
  EXPOSE_STATE_WEB_MODE_CAP,
} from '@proto.ui/module-expose-state-web';
import {
  FOCUS_BLUR_CAP,
  FOCUS_RELEASE_PENDING_CAP,
  type FocusRequestKind,
  FOCUS_INSTANCE_TOKEN_CAP,
  FOCUS_IS_NATIVELY_FOCUSABLE_CAP,
  FOCUS_ORDER_CAP,
  FOCUS_PARENT_CAP,
  FOCUS_RESOLVE_ENTRY_TARGET_CAP,
  FOCUS_REQUEST_FOCUS_CAP,
  FOCUS_ROOT_TARGET_CAP,
  FOCUS_RUN_IN_CALLBACK_CAP,
  FOCUS_SET_ENTRY_FOCUSABLE_CAP,
  FOCUS_SET_FOCUSABLE_CAP,
  FOCUS_TARGET_READY_CAP,
  FOCUS_SAMPLE_SCOPE_TARGETS_CAP,
} from '@proto.ui/module-focus';
import {
  createWebHitParticipationHostBridge,
  HIT_PARTICIPATION_HOST_BRIDGE_CAP,
} from '@proto.ui/module-hit-participation';
import {
  OVERLAY_GLOBAL_MOUNT_CAP,
  OVERLAY_LAYER_SCHEDULER_CAP,
  OVERLAY_MODAL_CAP,
  createWebOverlayModal,
  type OverlayModal,
  type OverlayLayerScheduler,
} from '@proto.ui/module-overlay';
import {
  CONTEXT_MENU_INPUT_HOST_CAP,
  CONTEXT_MENU_INPUT_RUN_IN_CALLBACK_CAP,
  createWebContextMenuInputHost,
  AVAILABLE_SPACE_HOST_CAP,
  createWebAvailableSpaceHost,
  ANCHORED_POSITION_HOST_CAP,
  createFloatingUiAnchoredPositionHost,
} from '@proto.ui/module-positioning';
import {
  createWebTextControlHost,
  TEXT_CONTROL_HOST_CAP,
  TEXT_CONTROL_RUN_IN_CALLBACK_CAP,
  type WebTextControl,
} from '@proto.ui/module-text-control';
import {
  createWebImageViewHost,
  IMAGE_VIEW_HOST_CAP,
  IMAGE_VIEW_RUN_IN_CALLBACK_CAP,
} from '@proto.ui/module-image-view';
import { type RawPropsSource, RAW_PROPS_SOURCE_CAP } from '@proto.ui/module-props';
import { RULE_EXPOSE_STATE_WEB_NATIVE_VARIANT_POLICY_CAP } from '@proto.ui/module-rule-expose-state-web';
import {
  RULE_META_GET_CAP,
  RULE_META_COLOR_SCHEME_SOURCE_CAP,
  RULE_META_PREFERENCE_SOURCE_CAP,
  RULE_META_STYLE_SUPPORT_SOURCE_CAP,
  RULE_META_VIEWPORT_SOURCE_CAP,
  type StyleSupportInvalidationSource,
  type ViewportInvalidationSource,
  type PreferenceInvalidationSource,
  type ColorSchemeInvalidationSource,
} from '@proto.ui/module-rule-meta';
import { createBoundWebScrollSurfaceHost, SCROLL_SURFACE_HOST_CAP } from '@proto.ui/module-scroll';
import { type PropsBaseType } from '@proto.ui/types';
import {
  createWebComponentPortalMount,
  getWebComponentPortalProjectionForOrigin,
  isWebComponentPortaled,
  isWebComponentPortalTargetOwnedBy,
} from '../portal-mount';
import {
  composedParentElement,
  hasWebComponentScopeDescendant,
  observeWebComponentRadioFocus,
  sampleWebComponentScopeTargets,
} from '../focus-scope-targets';

import {
  getLogicalEventTarget,
  getLogicalParent,
  getLogicalPrototype,
  getLogicalRoot,
  getLogicalTriggerSurfaceRoot,
  releaseTriggerSurface,
  mergeLogicalTriggerGroup,
  subscribeLogicalTriggerSurface,
  subscribeFocusSurfaceReady,
  isNativeFocusTargetReady,
} from '../platform/instance-tree';

const TRIGGER_OWNER_MARK = Symbol.for('@proto.ui/as-trigger/confirm-owner');
const WEB_COMPONENT_CONTROL_HOST_OPTIONS = Object.freeze({ stopPropagation: true });

// attachShadow() produces no MutationObserver record, so an open root that an
// already-upgraded descendant attaches after observation started is invisible
// to DOM observation and to upgrade watches alike. While at least one caller
// observes a region, wrap the window's attachShadow once (reference-counted)
// and report late open roots to every subscriber; the original method is
// restored when the last subscriber unsubscribes.
type LateAttachShadowSubscriber = {
  contains(host: Element): boolean;
  onLateRoot(): void;
};
const lateAttachShadowWatches = new WeakMap<
  Window,
  {
    count: number;
    original: Element['attachShadow'];
    patched: Element['attachShadow'];
    subscribers: Set<LateAttachShadowSubscriber>;
  }
>();

function watchLateAttachShadow(
  view: (Window & typeof globalThis) | null,
  contains: (host: Element) => boolean,
  onLateRoot: () => void
): (() => void) | null {
  const ElementCtor = view?.Element;
  if (!ElementCtor) return null;
  let watch = lateAttachShadowWatches.get(view as Window);
  if (!watch) {
    const subscribers = new Set<LateAttachShadowSubscriber>();
    const original = ElementCtor.prototype.attachShadow;
    const patched = function (this: Element, init: ShadowRootInit): ShadowRoot {
      const root = original.call(this, init);
      // Defer past the attaching turn so callers that populate the root
      // synchronously (e.g. connectedCallback) are sampled with content.
      if (root.mode === 'open' && subscribers.size > 0) {
        const host = this;
        queueMicrotask(() => {
          for (const subscriber of subscribers) {
            if (subscriber.contains(host)) subscriber.onLateRoot();
          }
        });
      }
      return root;
    };
    ElementCtor.prototype.attachShadow = patched as typeof original;
    watch = { count: 0, original, patched: patched as typeof original, subscribers };
    lateAttachShadowWatches.set(view as Window, watch);
  }
  const subscriber: LateAttachShadowSubscriber = { contains, onLateRoot };
  watch.subscribers.add(subscriber);
  watch.count += 1;
  return () => {
    const current = lateAttachShadowWatches.get(view as Window);
    if (!current) return;
    current.subscribers.delete(subscriber);
    current.count -= 1;
    if (current.count === 0) {
      // Ownership-safe restore: page code or an independently bundled copy may
      // have wrapped attachShadow after this watch. Never clobber a method
      // installed after ours; in that case our empty pass-through wrapper
      // stays in the chain rather than silently deleting the newer patch.
      if (ElementCtor.prototype.attachShadow === current.patched) {
        ElementCtor.prototype.attachShadow = current.original;
      }
      lateAttachShadowWatches.delete(view as Window);
    }
  };
}

type EntryStyleMethodPatch = {
  target: Record<string, unknown>;
  key: string;
  original: (...args: unknown[]) => unknown;
  patched: (...args: unknown[]) => unknown;
};

type EntryStyleSetterPatch = {
  target: object;
  key: string;
  original?: PropertyDescriptor;
  patched: NonNullable<PropertyDescriptor['set']>;
};

const entryStyleWatches = new WeakMap<
  Window,
  {
    subscribers: Set<(inlineOnly: boolean) => void>;
    inlineSubscribers: Set<(inlineOnly: boolean) => void>;
    methodPatches: EntryStyleMethodPatch[];
    setterPatches: EntryStyleSetterPatch[];
    observer: MutationObserver;
    stopEvents: () => void;
  }
>();

function isEntryStylesheetElement(node: Node | null): node is Element {
  return (
    !!node && node.nodeType === 1 && (node as Element).matches('style,link[rel~="stylesheet"]')
  );
}

function containsEntryStylesheetElement(node: Node): boolean {
  return (
    isEntryStylesheetElement(node) ||
    (node.nodeType === 1 && !!(node as Element).querySelector('style,link[rel~="stylesheet"]'))
  );
}

function invalidatesEntryStyles(record: MutationRecord): boolean {
  if (record.type === 'characterData') {
    return isEntryStylesheetElement(record.target.parentElement);
  }
  if (record.type === 'attributes') return isEntryStylesheetElement(record.target);
  return (
    isEntryStylesheetElement(record.target as Node) ||
    [...record.addedNodes, ...record.removedNodes].some(containsEntryStylesheetElement)
  );
}

function isNamedRadioForEntry(node: Node, names: ReadonlySet<string>): boolean {
  if (node.nodeType !== 1) return false;
  const element = node as Element;
  if (element.namespaceURI === 'http://www.w3.org/1999/xhtml' && element.localName === 'input') {
    const input = element as HTMLInputElement;
    if (input.type === 'radio' && names.has(input.name)) return true;
  }
  return [...element.querySelectorAll<HTMLInputElement>('input[type="radio"][name]')].some(
    (radio) => names.has(radio.name)
  );
}

function containsReferencedRadioForm(node: Node, formIds: ReadonlySet<string>): boolean {
  if (node.nodeType !== 1 || formIds.size === 0) return false;
  const element = node as Element;
  if (
    element.namespaceURI === 'http://www.w3.org/1999/xhtml' &&
    element.localName === 'form' &&
    formIds.has(element.id)
  ) {
    return true;
  }
  return [...element.querySelectorAll<HTMLFormElement>('form[id]')].some((form) =>
    formIds.has(form.id)
  );
}

function invalidatesEntryRadioGroup(
  record: MutationRecord,
  names: ReadonlySet<string>,
  formIds: ReadonlySet<string>
): boolean {
  if (record.type === 'childList') {
    return [...record.addedNodes, ...record.removedNodes].some(
      (node) => isNamedRadioForEntry(node, names) || containsReferencedRadioForm(node, formIds)
    );
  }
  if (record.target.nodeType !== 1) return false;
  const element = record.target as Element;
  if (element.namespaceURI === 'http://www.w3.org/1999/xhtml' && element.localName === 'form') {
    return (
      record.attributeName === 'id' &&
      (formIds.has(element.id) || formIds.has(record.oldValue ?? ''))
    );
  }
  if (element.namespaceURI !== 'http://www.w3.org/1999/xhtml' || element.localName !== 'input') {
    return false;
  }
  const input = element as HTMLInputElement;
  const currentOrPreviousNameMatches =
    names.has(input.name) || (record.attributeName === 'name' && names.has(record.oldValue ?? ''));
  if (!currentOrPreviousNameMatches) return false;
  const currentOrPreviousTypeIsRadio =
    input.type === 'radio' ||
    (record.attributeName === 'type' && (record.oldValue ?? '').toLowerCase() === 'radio');
  return currentOrPreviousTypeIsRadio;
}

function listenToEntryEvents(
  targets: Iterable<EventTarget>,
  types: readonly string[],
  listener: EventListener
) {
  for (const target of targets)
    for (const type of types) target.addEventListener(type, listener, true);
  return () => {
    for (const target of targets)
      for (const type of types) target.removeEventListener(type, listener, true);
  };
}

function propertyAffectsEntryEligibility(property: string): boolean {
  return (
    property === 'visibility' ||
    property === 'display' ||
    property === 'content-visibility' ||
    property.startsWith('--')
  );
}

function animationAffectsEntryEligibility(animation: Animation): boolean {
  const effect = animation.effect;
  if (!effect || typeof (effect as KeyframeEffect).getKeyframes !== 'function') return true;
  try {
    return (effect as KeyframeEffect)
      .getKeyframes()
      .some((keyframe) =>
        Object.keys(keyframe).some(
          (property) =>
            property === 'contentVisibility' || propertyAffectsEntryEligibility(property)
        )
      );
  } catch {
    // An opaque animation is correctness-sensitive. Sampling it is bounded to
    // this entry region and ends with the animation or the view epoch.
    return true;
  }
}

function matchingSelectorParen(selector: string, open: number): number {
  let depth = 1;
  let quote = '';
  for (let index = open + 1; index < selector.length; index += 1) {
    const character = selector[index]!;
    if (character === '\\') {
      index += 1;
      continue;
    }
    if (quote) {
      if (character === quote) quote = '';
      continue;
    }
    if (character === '"' || character === "'") {
      quote = character;
      continue;
    }
    if (character === '(') depth += 1;
    else if (character === ')' && --depth === 0) return index;
  }
  return -1;
}

// These scans ignore the same escaped, quoted and attribute-selector input.
// Return its final index without allocating tokens or substring copies.
function skipSelectorLiteral(selector: string, index: number, character: string): number | null {
  if (character === '\\') return index + 1;
  if (character === '"' || character === "'") {
    for (let end = index + 1; end < selector.length; end += 1) {
      if (selector[end] === '\\') end += 1;
      else if (selector[end] === character) return end;
    }
    return selector.length;
  }
  if (character === ']') return index;
  if (character !== '[') return null;
  let depth = 1;
  let quote = '';
  for (let end = index + 1; end < selector.length; end += 1) {
    const next = selector[end]!;
    if (next === '\\') end += 1;
    else if (quote) {
      if (next === quote) quote = '';
    } else if (next === '"' || next === "'") quote = next;
    else if (next === '[') depth += 1;
    else if (next === ']' && --depth === 0) return end;
  }
  return selector.length;
}

function containsDocumentRootSelectorList(selector: string): boolean {
  let depth = 0;
  let compoundStart = 0;
  const matchesLastCompound = (end: number) =>
    containsDocumentRootCompound(selector.slice(compoundStart, end));
  for (let index = 0; index < selector.length; index += 1) {
    const character = selector[index]!;
    const literalEnd = skipSelectorLiteral(selector, index, character);
    if (literalEnd !== null) {
      index = literalEnd;
      continue;
    }
    if (character === '(') depth += 1;
    else if (character === ')') depth = Math.max(0, depth - 1);
    else if (!depth && character === ',') {
      if (matchesLastCompound(index)) return true;
      compoundStart = index + 1;
    } else if (
      !depth &&
      (character === '>' || character === '+' || character === '~' || /\s/.test(character))
    ) {
      compoundStart = index + 1;
    }
  }
  return matchesLastCompound(selector.length);
}

function containsDocumentRootCompound(selector: string): boolean {
  for (let index = 0; index < selector.length; index += 1) {
    const character = selector[index]!;
    const literalEnd = skipSelectorLiteral(selector, index, character);
    if (literalEnd !== null) {
      index = literalEnd;
      continue;
    }
    if (character === ':') {
      let end = index + 1;
      while (/[\w-]/.test(selector[end] ?? '')) end += 1;
      const name = selector.slice(index + 1, end).toLowerCase();
      if (name === 'root' && selector[end] !== '(') return true;
      if (selector[end] === '(') {
        const close = matchingSelectorParen(selector, end);
        if (close < 0) return false;
        if (
          (name === 'is' || name === 'where') &&
          containsDocumentRootSelectorList(selector.slice(end + 1, close))
        )
          return true;
        // Root-looking tokens inside :not(), :has(), attribute-like custom
        // pseudos or other functions do not make the current subject a root.
        index = close;
      }
      continue;
    }
    if (!/[a-zA-Z_]/.test(character)) continue;
    const previous = selector[index - 1];
    if (previous && !/[\s,>+~(]/.test(previous)) continue;
    let end = index + 1;
    while (/[\w-]/.test(selector[end] ?? '')) end += 1;
    const name = selector.slice(index, end).toLowerCase();
    if (name === 'html' || name === 'body') return true;
    index = end - 1;
  }
  return false;
}

function hasDocumentRootRelationalSubject(selector: string): boolean {
  let depth = 0;
  const compoundStarts = [0];
  for (let index = 0; index < selector.length; index += 1) {
    const character = selector[index]!;
    const literalEnd = skipSelectorLiteral(selector, index, character);
    if (literalEnd !== null) {
      index = literalEnd;
      continue;
    }
    if (character === ':' && selector.slice(index + 1, index + 4).toLowerCase() === 'has') {
      let open = index + 4;
      while (/\s/.test(selector[open] ?? '')) open += 1;
      if (
        selector[open] === '(' &&
        containsDocumentRootCompound(selector.slice(compoundStarts[depth] ?? 0, index))
      )
        return true;
    }
    // A relational condition inside a negative or positional predicate may
    // govern a root compound outside that predicate's argument.
    if (
      character === ':' &&
      nonMonotonicEntryHasEnd(selector, index) >= 0 &&
      containsDocumentRootCompound(selector)
    )
      return true;
    if (character === '(') {
      depth += 1;
      compoundStarts[depth] = index + 1;
    } else if (character === ')') {
      compoundStarts.length = depth;
      depth = Math.max(0, depth - 1);
    } else if (character === ',' || character === '>' || character === '+' || character === '~') {
      compoundStarts[depth] = index + 1;
    } else if (/\s/.test(character)) {
      compoundStarts[depth] = index + 1;
    }
  }
  return false;
}

function collectSiblingDependencySubjects(
  selector: string,
  externalSubjects: readonly Element[],
  candidates: readonly Element[]
): Element[] {
  let depth = 0;
  const siblingPositions: number[] = [];
  const dependencies = new Set<Element>();
  const firstCompound = (suffix: string) => {
    let innerDepth = 0;
    for (let index = 0; index < suffix.length; index += 1) {
      const character = suffix[index]!;
      const literalEnd = skipSelectorLiteral(suffix, index, character);
      if (literalEnd !== null) {
        index = literalEnd;
        continue;
      }
      if (character === '(') innerDepth += 1;
      else if (character === ')') innerDepth = Math.max(0, innerDepth - 1);
      else if (
        !innerDepth &&
        (character === '>' || character === '+' || character === '~' || /\s/.test(character))
      )
        return suffix.slice(0, index);
    }
    return suffix;
  };
  const collectBranch = (branchEnd: number) => {
    for (const position of siblingPositions) {
      const suffix = selector.slice(position + 1, branchEnd).trim();
      if (!suffix) continue;
      try {
        const subject = firstCompound(suffix);
        const matchingSubjects = subject
          ? externalSubjects.filter((candidate) => candidate.matches(subject))
          : [];
        if (
          matchingSubjects.length > 0 &&
          candidates.some((candidate) => candidate.matches(suffix))
        )
          for (const candidate of matchingSubjects) dependencies.add(candidate);
      } catch {
        // A sibling-bearing selector that cannot be safely probed remains
        // correctness-sensitive. Observe sibling branches at every bounded
        // external subject rather than falling back to the whole document.
        for (const candidate of externalSubjects) dependencies.add(candidate);
      }
    }
  };
  for (let index = 0; index < selector.length; index += 1) {
    const character = selector[index]!;
    const literalEnd = skipSelectorLiteral(selector, index, character);
    if (literalEnd !== null) {
      index = literalEnd;
      continue;
    }
    if (character === '(') depth += 1;
    else if (character === ')') depth = Math.max(0, depth - 1);
    else if (!depth && (character === '+' || character === '~')) siblingPositions.push(index);
    else if (!depth && character === ',') {
      collectBranch(index);
      siblingPositions.length = 0;
    }
  }
  collectBranch(selector.length);
  return [...dependencies];
}

function styleRuleCanAffectEntryEligibility(rule: CSSStyleRule): boolean {
  const style = rule.style;
  if (!style) return false;
  for (let index = 0; index < style.length; index += 1) {
    const property = style.item(index);
    if (propertyAffectsEntryEligibility(property)) return true;
  }
  return false;
}

function canSkipEntryRelationalRule(rule: CSSStyleRule, observesResize: boolean): boolean {
  const style = rule.style;
  if (!style?.length || rule.cssRules?.length) return false;
  for (let index = 0; index < style.length; index += 1) {
    const property = style.item(index);
    if (
      property !== 'background-color' &&
      !/^scroll-(?:margin|padding)(?:-|$)/.test(property) &&
      !(observesResize && property === 'grid-template-columns')
    )
      return false;
  }
  return true;
}

function nonMonotonicEntryHasEnd(selector: string, index: number): number {
  const predicate = /^:(?:not|nth-child|nth-last-child)\(/.exec(selector.slice(index));
  if (!predicate) return -1;
  const open = index + predicate[0].length - 1;
  const close = matchingSelectorParen(selector, open);
  return close >= 0 && selector.slice(open + 1, close).includes(':has(') ? close : -1;
}

function relaxEntryHasConditions(selector: string): string {
  let result = '';
  let start = 0;
  for (let index = 0; index < selector.length; index += 1) {
    const literalEnd = skipSelectorLiteral(selector, index, selector[index]!);
    if (literalEnd !== null) {
      index = literalEnd;
      continue;
    }
    if (selector[index] !== ':') continue;
    const isHas = selector.startsWith(':has(', index);
    const close = isHas
      ? matchingSelectorParen(selector, index + 4)
      : nonMonotonicEntryHasEnd(selector, index);
    if (close < 0) {
      if (isHas) return selector;
      continue;
    }
    // Relax the enclosing predicate, not an inner :has. An always-true
    // argument would otherwise make :not(:has(...)) reject every candidate.
    result += selector.slice(start, index) + ':where(*)';
    start = close + 1;
    index = close;
  }
  return result + selector.slice(start);
}

function scopedNegatedEntrySubject(selector: string) {
  const start = selector.indexOf(':not(:has(');
  // Only scope a single, top-level condition whose relative selector cannot
  // reach siblings. Complex branches retain the conservative ancestor watch.
  if (
    start < 0 ||
    selector.indexOf(':has(') !== start + 5 ||
    selector.indexOf(':has(', start + 6) !== -1
  )
    return null;
  const close = matchingSelectorParen(selector, start + 4);
  const relativeOpen = start + 9;
  if (
    close < 0 ||
    matchingSelectorParen(selector, relativeOpen) !== close - 1 ||
    /[,+~]/.test(selector.slice(relativeOpen + 1, close - 1))
  )
    return null;
  let depth = 0;
  let prefix = '';
  let prefixStart = 0;
  let subject: string | null = null;
  const positionSubjects: string[] = [];
  for (let index = 0; index < selector.length; index += 1) {
    if (index === start) {
      if (depth !== 0) return null;
      subject = prefix + selector.slice(prefixStart, start) + ':where(*)';
      prefix = subject;
      prefixStart = close + 1;
      index = close;
      continue;
    }
    const character = selector[index]!;
    const literalEnd = skipSelectorLiteral(selector, index, character);
    if (literalEnd !== null) {
      if (subject === null && literalEnd >= start) return null;
      index = literalEnd;
    } else if (character === '(') depth += 1;
    else if (character === ')') depth -= 1;
    else if (subject !== null && depth === 0 && /[>\s]/.test(character)) break;
    else if (character === ':') {
      const position =
        /^:(?:(?:first|last|only)-(?:child|of-type)\b|nth-(?:last-)?(?:child|of-type)\()/i.exec(
          selector.slice(index)
        );
      if (!position) continue;
      if (depth !== 0) return null;
      let end = index + position[0].length;
      if (position[0].endsWith('(')) {
        const close = matchingSelectorParen(selector, end - 1);
        // A selector-filtered sibling list can also depend on sibling state.
        if (close < 0 || /\bof\b/i.test(selector.slice(end, close))) return null;
        end = close + 1;
      }
      // Register the dependency even when the subject starts out of position.
      prefix += selector.slice(prefixStart, index) + ':where(*)';
      positionSubjects.push(prefix);
      prefixStart = end;
      index = end - 1;
    }
  }
  const probe = prefix + selector.slice(prefixStart);
  // Simple nth formulas have already been removed. A sibling combinator or
  // selector list elsewhere still needs the conservative ancestor watch.
  return subject === null || /[,+~]/.test(probe) ? null : { subject, probe, positionSubjects };
}

const entryPositionCondition =
  /:(?:(?:first|last|only)-(?:child|of-type)\b|nth-(?:last-)?(?:child|of-type)\()/i;
const filteredEntryPositionCondition = /:nth-(?:last-)?child\([^)]*\bof\b/i;

function potentialEntryPositionSubjects(selector: string, candidates: readonly Element[]) {
  type PositionSubject = { probe: string; filtered: boolean; watchesDefinition: boolean };
  const subjects: PositionSubject[] = [];
  const branchSubjects: PositionSubject[] = [];
  let copyFrom = 0;
  let probe = '';
  const collect = (end: number) => {
    if (!branchSubjects.length) return;
    const relaxed = probe + selector.slice(copyFrom, end);
    if (candidates.some((candidate) => candidate.matches(relaxed)))
      subjects.push(...branchSubjects);
  };
  for (let index = 0; index < selector.length; index += 1) {
    const character = selector[index]!;
    const literalEnd = skipSelectorLiteral(selector, index, character);
    if (literalEnd !== null) {
      if (character === '[') {
        // A filtered position can start outside the entry attribute allowlist.
        probe += selector.slice(copyFrom, index) + ':where(*)';
        copyFrom = literalEnd + 1;
      }
      index = literalEnd;
    } else if (character === ',') {
      collect(index);
      copyFrom = index + 1;
      probe = '';
      branchSubjects.length = 0;
    } else if (character === ':') {
      let end = index + (selector[index + 1] === ':' ? 2 : 1);
      while (/[\w-]/.test(selector[end] ?? '')) end += 1;
      if (selector[end] === '(') {
        const close = matchingSelectorParen(selector, end);
        if (close < 0) break;
        end = close + 1;
      }
      // Dependency discovery must include currently inactive states, including
      // position tests nested in a functional pseudo such as :not().
      probe += selector.slice(copyFrom, index) + ':where(*)';
      const predicate = selector.slice(index, end);
      if (entryPositionCondition.test(predicate))
        branchSubjects.push({
          probe,
          filtered: filteredEntryPositionCondition.test(predicate),
          watchesDefinition: /:defined\b/i.test(predicate),
        });
      copyFrom = end;
      index = end - 1;
    }
  }
  collect(selector.length);
  return subjects;
}

function collectEntryStyleDependencies(
  view: Window & typeof globalThis,
  roots: Iterable<Document | ShadowRoot>,
  target: HTMLElement,
  ancestors: readonly Element[],
  observesResize: boolean,
  observedRoots: ReadonlySet<Node>
) {
  const queries = new Set<string>();
  const visitedSheets = new Set<CSSStyleSheet>();
  let relational = 0;
  const siblingSubjects = new Set<Element>();
  const relationalSubjects = new Set<Element>();
  const positionParents = new Set<Node>();
  const filteredPositionParents = new Map<Element | ShadowRoot, boolean>();
  const externalSubjects = [target, ...ancestors];
  const candidates = [...externalSubjects, ...target.querySelectorAll('*')];
  let positionalCandidates: Element[] | undefined;
  let unfilteredPositionCandidates: Element[] | undefined;
  const getPositionalCandidates = () =>
    (positionalCandidates ??= [
      ...candidates,
      ...Array.from(observedRoots)
        .filter((root) => root !== target)
        .flatMap((root) => [
          ...(root.nodeType === 1 ? [root as Element] : []),
          ...(root as HTMLElement | ShadowRoot).querySelectorAll('*'),
        ]),
    ]);
  const collectMedia = (media: MediaList | null | undefined) => {
    const query = media?.mediaText;
    if (query) queries.add(query);
  };
  const visitRule = (rule: CSSRule) => {
    if (rule.type === 3 || rule.type === 4)
      collectMedia((rule as CSSImportRule | CSSMediaRule).media);
    if (rule.type === 3) {
      const imported = (rule as CSSImportRule).styleSheet;
      if (imported) visitSheet(imported);
    }
    if (rule.type === 1) {
      let selector = (rule as CSSStyleRule).selectorText;
      if (rule.parentRule?.type === 1)
        selector = selector.replaceAll(
          '&',
          `:is(${(rule.parentRule as CSSStyleRule).selectorText})`
        );
      if (/[+~](?!=)/.test(selector) && styleRuleCanAffectEntryEligibility(rule as CSSStyleRule))
        for (const subject of collectSiblingDependencySubjects(
          selector,
          externalSubjects,
          candidates
        ))
          siblingSubjects.add(subject);
      // Paint and anchor offsets do not change eligibility. Grid track sizes
      // are covered by the entry's resize observer, including container-query
      // changes. Keep watching mixed declarations and nested rules.
      const relationalSelector = selector.includes(':has(');
      const positional = relationalSelector && entryPositionCondition.test(selector);
      if (
        (relational !== 2 || positional) &&
        relationalSelector &&
        !canSkipEntryRelationalRule(rule as CSSStyleRule, observesResize)
      ) {
        try {
          let foundPositionParent = false;
          if (relational !== 2 && hasDocumentRootRelationalSubject(selector)) relational = 2;
          if (relational !== 2) {
            const scoped = scopedNegatedEntrySubject(selector);
            const probe = scoped?.probe ?? relaxEntryHasConditions(selector);
            // The bounded ancestor fallback skips body and html. A known
            // sibling-position dependency still needs its direct parent.
            if (
              (!relational || scoped?.positionSubjects.length) &&
              candidates.some((candidate) => candidate.matches(probe))
            ) {
              const matches = scoped
                ? candidates.filter((candidate) => candidate.matches(scoped.subject))
                : [];
              if (!matches.length) relational = 1;
              else for (const candidate of matches) relationalSubjects.add(candidate);
              for (const subject of scoped?.positionSubjects ?? [])
                for (const candidate of externalSubjects)
                  if (candidate.parentNode && candidate.matches(subject)) {
                    positionParents.add(candidate.parentNode);
                    foundPositionParent = true;
                  }
            }
          }
          // A document-wide observer cannot cover a separate shadow tree,
          // and local attribute filters cannot observe arbitrary peer state.
          if (
            positional &&
            (!foundPositionParent || filteredEntryPositionCondition.test(selector))
          ) {
            const possible = getPositionalCandidates();
            for (const {
              probe: subject,
              filtered,
              watchesDefinition,
            } of potentialEntryPositionSubjects(selector, possible)) {
              relational ||= 1;
              for (const candidate of filtered
                ? possible
                : (unfilteredPositionCandidates ??= [
                    ...externalSubjects,
                    ...Array.from(observedRoots).filter(
                      (root): root is Element => root.nodeType === 1 && root !== target
                    ),
                  ])) {
                const parent = candidate.parentNode;
                if (!parent || !candidate.matches(subject)) continue;
                if (
                  filtered &&
                  (parent.nodeType === 1 ||
                    (parent.nodeType === 11 && !!(parent as ShadowRoot).host))
                ) {
                  positionParents.add(parent);
                  const root = parent as Element | ShadowRoot;
                  filteredPositionParents.set(
                    root,
                    watchesDefinition || filteredPositionParents.get(root) === true
                  );
                } else if (
                  parent === target.ownerDocument.body ||
                  parent === target.ownerDocument.documentElement ||
                  observedRoots.has(candidate)
                ) {
                  positionParents.add(parent);
                }
              }
            }
          }
        } catch {
          // Unknown selector syntax is correctness-sensitive: retain a bounded
          // external-chain fallback rather than silently missing a change.
          relational ||= 1;
        }
      }
    }
    if ('cssRules' in rule)
      for (const nested of (rule as CSSGroupingRule).cssRules) visitRule(nested);
  };
  const visitSheet = (sheet: CSSStyleSheet) => {
    if (visitedSheets.has(sheet)) return;
    visitedSheets.add(sheet);
    collectMedia(sheet.media);
    try {
      for (const rule of sheet.cssRules) visitRule(rule);
    } catch {
      // Cross-origin sheets remain opaque; their owner media still applies.
      relational ||= 1;
    }
  };
  for (const root of roots)
    for (const sheet of [...(root.styleSheets ?? []), ...(root.adoptedStyleSheets ?? [])])
      visitSheet(sheet);
  return [
    Array.from(queries, (query) => view.matchMedia(query)),
    relational,
    siblingSubjects,
    relationalSubjects,
    positionParents,
    filteredPositionParents,
  ] as const;
}

function watchEntryStyleInvalidation(
  view: (Window & typeof globalThis) | null,
  onInvalidate: (inlineOnly: boolean) => void
): { observeInline(enabled: boolean): void; dispose(): void } | null {
  const Sheet = view?.CSSStyleSheet;
  const StyleSheetCtor = view?.StyleSheet;
  const Declaration = view?.CSSStyleDeclaration;
  const DocumentCtor = view?.Document;
  const ShadowRootCtor = view?.ShadowRoot;
  const Grouping = (
    view as unknown as {
      CSSGroupingRule?: { prototype: Record<string, unknown> };
    }
  )?.CSSGroupingRule;
  const CustomStateSetCtor = (
    view as unknown as {
      CustomStateSet?: { prototype: Record<string, unknown> };
    }
  )?.CustomStateSet;
  const Observer = view?.MutationObserver;
  const doc = view?.document;
  if (!view || !Sheet || !Declaration || !Observer || !doc?.documentElement) return null;
  let watch = entryStyleWatches.get(view as Window);
  if (!watch) {
    const subscribers = new Set<(inlineOnly: boolean) => void>();
    const inlineSubscribers = new Set<(inlineOnly: boolean) => void>();
    let pending: 'inline' | 'stylesheet' | null = null;
    const schedule = (inlineOnly: boolean) => {
      if (inlineOnly && !inlineSubscribers.size) return;
      if (pending) {
        if (!inlineOnly) pending = 'stylesheet';
        return;
      }
      pending = inlineOnly ? 'inline' : 'stylesheet';
      queueMicrotask(() => {
        const inlineOnly = pending === 'inline';
        pending = null;
        for (const subscriber of inlineOnly ? inlineSubscribers : subscribers)
          subscriber(inlineOnly);
      });
    };
    const notify = () => schedule(false);
    const methodPatches: EntryStyleMethodPatch[] = [];
    const customStateSize = CustomStateSetCtor
      ? Object.getOwnPropertyDescriptor(CustomStateSetCtor.prototype, 'size')?.get
      : undefined;
    const readCustomStateSize = (receiver: unknown) => {
      if (!customStateSize) return undefined;
      try {
        const size: unknown = customStateSize.call(receiver);
        return typeof size === 'number' ? size : undefined;
      } catch {
        // The mutator below must report its own native receiver/argument error.
        return undefined;
      }
    };
    // Inline declarations already deliver style-attribute records to the
    // entry's DOM observers. Only rule declarations need the window-wide
    // stylesheet invalidation, which rebuilds every entry's dependencies.
    const isInlineDeclaration = (target: object, receiver: unknown) =>
      target === Declaration.prototype && (receiver as CSSStyleDeclaration).parentRule === null;
    const patchMethods = (target: Record<string, unknown>, keys: readonly string[]) => {
      for (const key of keys) {
        const original = target[key];
        if (typeof original !== 'function') continue;
        const customState = target === CustomStateSetCtor?.prototype;
        const readsCustomStateSize = customState && key !== 'delete';
        const patched = function (this: unknown, ...args: unknown[]) {
          const previousSize =
            readsCustomStateSize && subscribers.size > 0 ? readCustomStateSize(this) : undefined;
          const result = Reflect.apply(original, this, args);
          if (customState && subscribers.size === 0) return result;
          // Native set mutators preserve membership on a repeated add, missing
          // delete or empty clear. Do not turn those no-ops into refresh loops.
          if (
            customState &&
            ((key === 'delete' && result === false) ||
              (key === 'clear' && previousSize === 0) ||
              (key === 'add' &&
                previousSize !== undefined &&
                readCustomStateSize(this) === previousSize))
          )
            return result;
          if (isInlineDeclaration(target, this)) schedule(true);
          else if (
            key === 'replace' &&
            result &&
            typeof (result as PromiseLike<unknown>).then === 'function'
          )
            Promise.resolve(result).then(notify, () => {});
          else notify();
          return result;
        };
        target[key] = patched;
        methodPatches.push({
          target,
          key,
          original: original as (...args: unknown[]) => unknown,
          patched,
        });
      }
    };
    for (const [target, keys] of [
      [Sheet.prototype, ['insertRule', 'deleteRule', 'replaceSync', 'replace']],
      [Grouping, ['insertRule', 'deleteRule']],
      [Declaration.prototype, ['setProperty', 'removeProperty']],
      [view.MediaList?.prototype, ['appendMedium', 'deleteMedium']],
      [CustomStateSetCtor?.prototype, ['add', 'delete', 'clear']],
    ] as const) {
      if (target) patchMethods(target as unknown as Record<string, unknown>, keys);
    }
    for (const FormControl of [
      view.HTMLButtonElement,
      view.HTMLFieldSetElement,
      view.HTMLInputElement,
      view.HTMLObjectElement,
      view.HTMLOutputElement,
      view.HTMLSelectElement,
      view.HTMLTextAreaElement,
    ]) {
      if (FormControl)
        patchMethods(FormControl.prototype as unknown as Record<string, unknown>, [
          'setCustomValidity',
        ]);
    }
    if (view.HTMLInputElement)
      patchMethods(view.HTMLInputElement.prototype as unknown as Record<string, unknown>, [
        'stepUp',
        'stepDown',
      ]);
    const ElementInternalsCtor = (
      view as unknown as {
        ElementInternals?: { prototype: Record<string, unknown> };
      }
    ).ElementInternals;
    if (ElementInternalsCtor) patchMethods(ElementInternalsCtor.prototype, ['setValidity']);

    const setterPatches: EntryStyleSetterPatch[] = [];
    const patchSetter = (target: object, key: string, cssName?: string) => {
      const original = Object.getOwnPropertyDescriptor(target, key);
      if (original ? !original.configurable || !original.set : !cssName) return;
      const patched = function (this: unknown, value: unknown) {
        if (original?.set) original.set.call(this, value);
        else (this as CSSStyleDeclaration).setProperty(cssName!, String(value));
        schedule(isInlineDeclaration(target, this));
      };
      Object.defineProperty(target, key, {
        configurable: true,
        enumerable: original?.enumerable ?? true,
        get:
          original?.get ??
          function (this: CSSStyleDeclaration) {
            return this.getPropertyValue(cssName!);
          },
        set: patched,
      });
      setterPatches.push({ target, key, original, patched });
    };
    patchSetter(Declaration.prototype, 'visibility', 'visibility');
    patchSetter(Declaration.prototype, 'display', 'display');
    patchSetter(Declaration.prototype, 'contentVisibility', 'content-visibility');
    patchSetter(Declaration.prototype, 'cssText');
    if (StyleSheetCtor) patchSetter(StyleSheetCtor.prototype, 'disabled');
    if (DocumentCtor) patchSetter(DocumentCtor.prototype, 'adoptedStyleSheets');
    if (ShadowRootCtor) patchSetter(ShadowRootCtor.prototype, 'adoptedStyleSheets');
    for (const [Ctor, keys] of [
      [view.CSSStyleRule, ['selectorText']],
      [view.MediaList, ['mediaText']],
      [view.HTMLInputElement, ['checked', 'indeterminate', 'value']],
      [view.HTMLTextAreaElement, ['value']],
      [view.HTMLOptionElement, ['selected']],
      [view.HTMLSelectElement, ['selectedIndex']],
    ] as const) {
      if (Ctor) for (const key of keys) patchSetter(Ctor.prototype, key);
    }

    const observer = new Observer((records) => {
      if (records.some(invalidatesEntryStyles)) notify();
    });
    observer.observe(doc.documentElement, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: ['href', 'rel', 'media', 'disabled', 'type'],
    });
    const onLoad = (event: Event) => {
      if (isEntryStylesheetElement(event.target as Node | null)) notify();
    };
    const stopLoadEvents = listenToEntryEvents([doc], ['load'], onLoad);
    const stopHashEvents = listenToEntryEvents([view], ['hashchange'], notify);
    const stopEvents = () => {
      stopLoadEvents();
      stopHashEvents();
    };
    watch = {
      subscribers,
      inlineSubscribers,
      methodPatches,
      setterPatches,
      observer,
      stopEvents,
    };
    entryStyleWatches.set(view as Window, watch);
  }
  watch.subscribers.add(onInvalidate);
  const current = watch;
  const dispose = () => {
    current.inlineSubscribers.delete(onInvalidate);
    if (!current.subscribers.delete(onInvalidate) || current.subscribers.size > 0) return;
    current.observer.disconnect();
    current.stopEvents();
    for (const patch of current.methodPatches) {
      if (patch.target[patch.key] === patch.patched) patch.target[patch.key] = patch.original;
    }
    for (const patch of current.setterPatches) {
      const descriptor = Object.getOwnPropertyDescriptor(patch.target, patch.key);
      if (descriptor?.set === patch.patched) {
        if (patch.original) Object.defineProperty(patch.target, patch.key, patch.original);
        else delete (patch.target as Record<string, unknown>)[patch.key];
      }
    }
    entryStyleWatches.delete(view as Window);
  };
  return {
    observeInline(enabled) {
      if (enabled) current.inlineSubscribers.add(onInvalidate);
      else current.inlineSubscribers.delete(onInvalidate);
    },
    dispose,
  };
}

export function createRebindableWebOverlayModal(doc: Document) {
  let currentDocument = doc;
  let current = createWebOverlayModal(doc);
  let locked = false;
  return {
    lock() {
      locked = true;
      current.lock();
    },
    unlock() {
      locked = false;
      current.unlock();
    },
    adoptDocument(nextDocument: Document) {
      if (currentDocument === nextDocument) return;
      current.unlock();
      currentDocument = nextDocument;
      current = createWebOverlayModal(nextDocument);
      if (locked) current.lock();
    },
  } satisfies OverlayModal & { adoptDocument(doc: Document): void };
}

function resolveWebComponentTriggerSurface(
  root: HTMLElement,
  logicalSurface: HTMLElement | null
): HTMLElement | null {
  if (!(root as unknown as Record<symbol, unknown>)[TRIGGER_OWNER_MARK]) {
    return logicalSurface;
  }

  let surface = root;
  while (true) {
    let next: HTMLElement | null = null;
    for (const candidate of surface.querySelectorAll<HTMLElement>('[data-pui-root]')) {
      if (!(candidate as unknown as Record<symbol, unknown>)[TRIGGER_OWNER_MARK]) continue;
      let parent = candidate.parentElement;
      while (parent && parent !== surface && !parent.hasAttribute('data-pui-root')) {
        parent = parent.parentElement;
      }
      if (parent === surface) {
        next = candidate;
        break;
      }
    }
    if (!next) return surface;
    surface = next;
  }
}

type WebComponentOwnerModulesArgs<Props extends PropsBaseType> = {
  el: HTMLElement;
  splitSurface?: boolean;
  instanceToken: LogicalInstanceToken;
  rawPropsSource: RawPropsSource<Props>;
  textControlTarget: WebTextControl | null;
  imageViewTarget: HTMLImageElement | null;
  nativeLinkTarget?: HTMLAnchorElement | null;
  getMeta: (key: string) => unknown;
  colorSchemeSource?: ColorSchemeInvalidationSource;
  preferenceSource?: PreferenceInvalidationSource;
  styleSupportSource?: StyleSupportInvalidationSource;
  viewportSource?: ViewportInvalidationSource;
  exposeStateWebMode?: {
    allowContinuousAttr?: boolean;
    allowStringVar?: boolean;
  };
  setExposes: (record: Record<string, unknown>) => void;
  runInCallbackScope: (fn: () => void) => void;
  overlayLayerScheduler?: OverlayLayerScheduler;
};

function createControlWiring<Props extends PropsBaseType>(
  args: WebComponentOwnerModulesArgs<Props>,
  rawPropsSource: RawPropsSource<Props>,
  physicalControl: () => WebTextControl | null,
  physicalImage: () => HTMLImageElement | null,
  getControlLabelSurface: () => HTMLElement | null,
  subscribeControlLabelSurface?: (listener: () => void) => () => void
) {
  return createCapsWiring()
    .use('control-label', [
      [
        CONTROL_LABEL_HOST_CAP,
        createWebControlLabelHost(getControlLabelSurface, subscribeControlLabelSurface),
      ],
      [CONTROL_LABEL_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
    ])
    .use('text-control', [
      [
        TEXT_CONTROL_HOST_CAP,
        createWebTextControlHost(physicalControl, WEB_COMPONENT_CONTROL_HOST_OPTIONS),
      ],
      [TEXT_CONTROL_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
    ])
    .use('native-link', [
      [NATIVE_LINK_HOST_CAP, createWebNativeLinkHost(() => args.nativeLinkTarget ?? null)],
      [NATIVE_LINK_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
    ])
    .use('image-view', [
      [
        IMAGE_VIEW_HOST_CAP,
        createWebImageViewHost(physicalImage, WEB_COMPONENT_CONTROL_HOST_OPTIONS),
      ],
      [IMAGE_VIEW_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
    ])
    .use('props', [[RAW_PROPS_SOURCE_CAP, rawPropsSource]]);
}

function createExposeEventSink(el: HTMLElement) {
  return (key: string, payload?: unknown, options?: Record<string, unknown>) => {
    el.dispatchEvent(
      new CustomEvent(key, {
        detail: payload,
        bubbles: true,
        cancelable: true,
        ...options,
      })
    );
  };
}

function addExposeStateModule(
  wiring: ReturnType<typeof createCapsWiring>,
  setExposes: (record: Record<string, unknown>) => void
) {
  return wiring.use('expose-state', [
    [
      EXPOSES_RECORD_SINK_CAP,
      (record: Record<string, unknown>) => {
        setExposes(record ?? {});
      },
    ],
  ]);
}

// Owner and view wiring share these logical capabilities. Only materialized
// views install native Anatomy order observation; preserve that distinction.
function addLogicalModules(
  wiring: ReturnType<typeof createCapsWiring>,
  instanceToken: LogicalInstanceToken,
  getMeta: (key: string) => unknown,
  colorSchemeSource: ColorSchemeInvalidationSource | undefined,
  preferenceSource: PreferenceInvalidationSource | undefined,
  styleSupportSource: StyleSupportInvalidationSource | undefined,
  viewportSource: ViewportInvalidationSource | undefined,
  orderObserver?: typeof createDomOrderObserver
) {
  const anatomy: CapEntries[number][] = [
    [ANATOMY_INSTANCE_TOKEN_CAP, instanceToken],
    [ANATOMY_PARENT_CAP, getLogicalParent],
    [ANATOMY_GET_PROTO_CAP, getLogicalPrototype],
    [ANATOMY_ROOT_TARGET_CAP, getLogicalRoot],
  ];
  if (orderObserver) anatomy.push([ANATOMY_ORDER_OBSERVER_CAP, orderObserver]);

  return wiring
    .use('context', [
      [CONTEXT_INSTANCE_TOKEN_CAP, instanceToken],
      [CONTEXT_PARENT_CAP, getLogicalParent],
    ])
    .use('anatomy', anatomy)
    .use('as-trigger', [
      [AS_TRIGGER_INSTANCE_CAP, instanceToken],
      [AS_TRIGGER_PARENT_CAP, getLogicalParent],
      [AS_TRIGGER_MERGE_GROUP_CAP, mergeLogicalTriggerGroup],
      [AS_TRIGGER_GET_GROUP_EVENT_TARGET_CAP, getLogicalEventTarget],
      [AS_TRIGGER_GET_PROTO_CAP, getLogicalPrototype],
    ])
    .use('rule-meta', [
      [RULE_META_GET_CAP, getMeta],
      ...(colorSchemeSource
        ? [[RULE_META_COLOR_SCHEME_SOURCE_CAP, colorSchemeSource] as const]
        : []),
      ...(preferenceSource ? [[RULE_META_PREFERENCE_SOURCE_CAP, preferenceSource] as const] : []),
      ...(viewportSource ? [[RULE_META_VIEWPORT_SOURCE_CAP, viewportSource] as const] : []),
      ...(styleSupportSource
        ? [[RULE_META_STYLE_SUPPORT_SOURCE_CAP, styleSupportSource] as const]
        : []),
    ])
    .use('rule-expose-state-web', [
      [RULE_EXPOSE_STATE_WEB_NATIVE_VARIANT_POLICY_CAP, createExposeStateWebNativeVariantPolicy],
    ]);
}

/** Owner/instance capabilities that remain valid without rendered children. */
export function createWebComponentOwnerModules<Props extends PropsBaseType>(
  args: WebComponentOwnerModulesArgs<Props>
) {
  const {
    el,
    instanceToken,
    rawPropsSource,
    getMeta,
    colorSchemeSource,
    preferenceSource,
    styleSupportSource,
    viewportSource,
    setExposes,
  } = args;
  const getControlLabelSurface = () => {
    if (args.textControlTarget) return args.textControlTarget;
    if (args.imageViewTarget) return args.imageViewTarget;
    if (args.nativeLinkTarget) return args.nativeLinkTarget;
    return resolveWebComponentTriggerSurface(el, getLogicalTriggerSurfaceRoot(instanceToken));
  };
  const getTriggerSurface = () => {
    const surface = getControlLabelSurface();
    return surface?.isConnected ? surface : null;
  };
  const normalizeOwnedSurface = () => {
    const surface = getTriggerSurface();
    if (surface && surface !== el) releaseTriggerSurface(el);
  };
  subscribeLogicalTriggerSurface(instanceToken, normalizeOwnedSurface);
  queueMicrotask(() => queueMicrotask(normalizeOwnedSurface));
  // The custom element is the persistent owner shell, so semantic and
  // expose-state projection remain valid while its internal view is absent.
  const physicalControl = () => args.textControlTarget;
  const physicalImage = () => args.imageViewTarget;

  let presenceSink: PresencePresentationSink | null = null;
  let presenceSurface: HTMLElement | null = null;
  let presenceView: number | null = null;
  const wiring = createControlWiring(
    args,
    rawPropsSource,
    physicalControl,
    physicalImage,
    getControlLabelSurface
  )
    // Eligibility is an owner capability available during setup; physical
    // bindings are still acquired only after the complete first view stages.
    .use('feedback', [
      ...((!el.shadowRoot || args.splitSurface) &&
      !args.textControlTarget &&
      !args.imageViewTarget &&
      !args.nativeLinkTarget
        ? [[OWNED_DECORATION_CAP, true] as const]
        : []),
    ])
    .use('a11y', [
      [
        A11Y_PROJECT_CAP,
        createWebA11yProjector(getTriggerSurface, (listener) =>
          subscribeLogicalTriggerSurface(instanceToken, listener)
        ),
      ],
    ])
    .use('expose-event', [[EXPOSE_EVENT_SINK_CAP, createExposeEventSink(el)]])
    .use('focus', [
      [FOCUS_INSTANCE_TOKEN_CAP, instanceToken],
      [FOCUS_PARENT_CAP, getLogicalParent],
      [FOCUS_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
    ]);
  addExposeStateModule(wiring, setExposes).use('expose-state-web', () => [
    [HOST_ELEMENT_CAP, el],
    [EXPOSE_STATE_WEB_MAP_CAP, createExposeStateWebNameMap],
    ...(args.exposeStateWebMode
      ? [[EXPOSE_STATE_WEB_MODE_CAP, args.exposeStateWebMode] as const]
      : []),
  ]);

  return addLogicalModules(
    wiring,
    instanceToken,
    getMeta,
    colorSchemeSource,
    preferenceSource,
    styleSupportSource,
    viewportSource
  )
    .use('overlay', () => [
      ...(args.overlayLayerScheduler
        ? [[OVERLAY_LAYER_SCHEDULER_CAP, args.overlayLayerScheduler] as const]
        : []),
    ])
    .build();
}

// Kept by the logical Adapter owner, across replaceable view providers.
export type FocusIntentState = {
  options?: FocusRequestOptions;
  kind?: FocusRequestKind;
};

export function createWebComponentModules<Props extends PropsBaseType>(args: {
  el: HTMLElement;
  splitSurface?: boolean;
  surfaceProjection: HostSurfaceProjection<HTMLElement>;
  /** Presentation surface may differ from the accessibility/event target in Shadow. */
  feedbackSurfaceProjection?: HostSurfaceProjection<HTMLElement>;
  instanceToken: LogicalInstanceToken;
  router: {
    rootTarget: EventTarget;
    globalTarget: EventTarget;
  };
  rawPropsSource: RawPropsSource<Props>;
  effectsPort: EffectsPort;
  /** Optional V2 visual provider for this physical view; absence retains ordinary style. */
  visualFeedbackSink?: VisualFeedbackSink;
  residentMotion?: WebResidentMotionOptions;
  finalStyleSink?: FinalStyleSink;
  materialBindingFactory?: MaterialBindingFactory;
  textControlTarget: WebTextControl | null;
  imageViewTarget: HTMLImageElement | null;
  nativeLinkTarget?: HTMLAnchorElement | null;
  getMeta: (key: string) => unknown;
  colorSchemeSource?: ColorSchemeInvalidationSource;
  preferenceSource?: PreferenceInvalidationSource;
  styleSupportSource?: StyleSupportInvalidationSource;
  viewportSource?: ViewportInvalidationSource;
  exposeStateWebMode?: {
    allowContinuousAttr?: boolean;
    allowStringVar?: boolean;
  };
  scrollProjection?: ScrollProjectionPreference;
  setExposes: (record: Record<string, unknown>) => void;
  runInCallbackScope: (fn: () => void) => void;
  isViewReady: () => boolean;
  isEntryAcquisitionReady: (target: HTMLElement) => boolean;
  focusIntentState?: FocusIntentState;
  onFocusIntent?: () => void;
  onFocusAcquired?: () => void;
  onFocusPendingReleased?: () => void;
  subscribeTargetReady: (listener: () => void) => () => void;
  subscribeDocumentChange?: (
    listener: (document: Document, phase: 'retire' | 'ready') => void
  ) => () => void;
  retryTargetReady: () => void;
  overlayLayerScheduler?: OverlayLayerScheduler;
  overlayModal?: OverlayModal;
}) {
  let motionSurface: HTMLElement | null = null;
  let motionSink: import('@proto.ui/module-feedback').ResidentMotionSink | null = null;
  let motionView: number | null = null;
  const {
    el,
    instanceToken,
    router,
    rawPropsSource,
    effectsPort,
    getMeta,
    colorSchemeSource,
    preferenceSource,
    styleSupportSource,
    viewportSource,
    exposeStateWebMode,
    scrollProjection,
    setExposes,
  } = args;

  const getPhysicalTriggerSurface = () =>
    args.nativeLinkTarget ??
    resolveWebComponentTriggerSurface(el, getLogicalTriggerSurfaceRoot(instanceToken));
  const getConnectedTriggerSurface = () => {
    const surface = getPhysicalTriggerSurface();
    return surface?.isConnected ? surface : null;
  };
  // A11y must project while the rematerialized host is still behind the reveal
  // barrier; focus remains gated until that host is ready for interaction.
  const request = args.focusIntentState ?? {};
  const getTriggerSurface = () => (args.isViewReady() ? getConnectedTriggerSurface() : null);
  let entryObserver: MutationObserver | null = null;
  let entryImageObserver: MutationObserver | null = null;
  let entryExternalStyleObserver: MutationObserver | null = null;
  let entryRadioGroupObserver: MutationObserver | null = null;
  let entryResizeObserver: ResizeObserver | null = null;
  let stopEntryRadioStateWatch: (() => void) | null = null;
  let stopEntryImageStateWatch: (() => void) | null = null;
  let stopEntryAttachShadowWatch: (() => void) | null = null;
  let entryStyleWatch: ReturnType<typeof watchEntryStyleInvalidation> = null;
  let stopEntryMotionWatch: (() => void) | null = null;
  let stopEntrySlotWatch: (() => void) | null = null;
  let stopEntryUpgradeWatch: (() => void) | null = null;
  let entryObserverGeneration = 0;
  let radioFocusHistory: ReturnType<typeof observeWebComponentRadioFocus> | null = null;
  const stopEntryObserver = () => {
    entryObserverGeneration += 1;
    entryObserver?.disconnect();
    entryImageObserver?.disconnect();
    entryExternalStyleObserver?.disconnect();
    entryRadioGroupObserver?.disconnect();
    entryObserver =
      entryImageObserver =
      entryExternalStyleObserver =
      entryRadioGroupObserver =
        null;
    entryResizeObserver?.disconnect();
    entryResizeObserver = null;
    stopEntryRadioStateWatch?.();
    stopEntryImageStateWatch?.();
    stopEntryAttachShadowWatch?.();
    entryStyleWatch?.dispose();
    entryStyleWatch = null;
    stopEntryMotionWatch?.();
    stopEntrySlotWatch?.();
    stopEntryUpgradeWatch?.();
    stopEntryRadioStateWatch =
      stopEntryImageStateWatch =
      stopEntryAttachShadowWatch =
      stopEntryMotionWatch =
      stopEntrySlotWatch =
      stopEntryUpgradeWatch =
        null;
  };
  const subscribeFocusTarget = (listener: () => void) => {
    const history = observeWebComponentRadioFocus(el);
    const offReady = args.subscribeTargetReady(() => {
      history.rebind();
      listener();
    });
    const offSurface = subscribeFocusSurfaceReady(instanceToken, listener);
    radioFocusHistory = history;
    return () => {
      history.dispose();
      // An old epoch's cleanup owns its captured listener, not a successor's
      // native focus history or entry observation.
      if (radioFocusHistory === history) {
        radioFocusHistory = null;
        stopEntryObserver();
      }
      offReady();
      offSurface();
    };
  };
  const physicalControl = () => args.textControlTarget;
  const physicalImage = () => args.imageViewTarget;
  const getAccessibilitySurface = () => {
    const surface = args.surfaceProjection.getSurfaceTarget();
    return surface === el ? getConnectedTriggerSurface() : surface;
  };
  const getControlLabelSurface = () => {
    if (!args.isViewReady()) return null;
    const surface = args.surfaceProjection.getSurfaceTarget();
    return surface === el ? getPhysicalTriggerSurface() : surface;
  };
  const subscribeControlLabelSurface = (listener: () => void) => {
    const offSurface = args.surfaceProjection.subscribeSurfaceTarget(listener);
    const offReady = subscribeFocusTarget(listener);
    return () => {
      offSurface();
      offReady();
    };
  };
  // Keep canonical instance-facing state markers on the custom-element
  // boundary while mirroring only the generated selector context needed by
  // translated feedback.style tokens on a split presentation surface.
  const presentationSurface =
    args.textControlTarget ?? args.imageViewTarget ?? args.nativeLinkTarget ?? el;
  const portalMount = createWebComponentPortalMount();
  let releasePortalDirection: (() => void) | null = null;

  let presenceSink: PresencePresentationSink | null = null;
  let presenceSurface: HTMLElement | null = null;
  let presenceView: number | null = null;
  const wiring = createControlWiring(
    args,
    rawPropsSource,
    physicalControl,
    physicalImage,
    getControlLabelSurface,
    subscribeControlLabelSurface
  )
    .use('feedback', [
      ...((!el.shadowRoot || args.splitSurface) &&
      !args.textControlTarget &&
      !args.imageViewTarget &&
      !args.nativeLinkTarget
        ? [[OWNED_DECORATION_CAP, true] as const]
        : []),
      [EFFECTS_CAP, effectsPort],
      [
        SHADER_PRESENTATION_SINK_CAP,
        createWebShaderPresentationSink(
          () => (args.feedbackSurfaceProjection ?? args.surfaceProjection).getSurfaceTarget(),
          effectsPort
        ),
      ],
      [PRESENCE_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
      [
        PRESENCE_PRESENTATION_SINK_CAP,
        {
          commit(frame: import('@proto.ui/module-feedback').PresencePresentationFrame) {
            const surface = (
              args.feedbackSurfaceProjection ?? args.surfaceProjection
            ).getSurfaceTarget();
            if (!surface) {
              effectsPort.queueStyle(frame.style);
              effectsPort.requestFlush();
              return;
            }
            if (presenceSurface !== surface) {
              if (presenceSink && presenceView !== null) presenceSink.release(presenceView);
              presenceSurface = surface;
              presenceSink = createWebPresencePresentationSink(surface, effectsPort, {
                subscribeDocumentChange: args.subscribeDocumentChange,
              });
            }
            presenceView = frame.view;
            presenceSink!.commit(frame);
          },
          cancel() {
            presenceSink?.cancel();
          },
          settle(outcome: import('@proto.ui/core').PresentationOutcome) {
            return presenceSink?.settle(outcome) ?? false;
          },
          release(view: number) {
            presenceSink?.release(view);
            presenceSink = null;
            presenceSurface = null;
            presenceView = null;
          },
          diagnostics: () => presenceSink?.diagnostics?.() ?? [],
        },
      ],
      [
        RESIDENT_MOTION_SINK_CAP,
        {
          diagnostics: () => motionSink?.diagnostics?.() ?? [],
          commit(frame: import('@proto.ui/module-feedback').ResidentMotionFrame) {
            const surface = (
              args.feedbackSurfaceProjection ?? args.surfaceProjection
            ).getSurfaceTarget();
            if (!surface) {
              effectsPort.queueStyle(frame.style);
              effectsPort.requestFlush();
              return;
            }
            if (motionSurface !== surface) {
              if (motionSink && motionView !== null) motionSink.release(motionView);
              motionSurface = surface;
              motionSink = createWebResidentMotionSink(surface, effectsPort, args.residentMotion);
            }
            motionView = frame.view;
            motionSink!.commit(frame);
          },
          release(view: number) {
            motionSink?.release(view);
            motionSink = null;
            motionSurface = null;
            motionView = null;
          },
        },
      ],
      ...(args.visualFeedbackSink
        ? [[VISUAL_FEEDBACK_SINK_CAP, args.visualFeedbackSink] as const]
        : []),
      ...(args.materialBindingFactory
        ? [[MATERIAL_BINDING_FACTORY_CAP, args.materialBindingFactory] as const]
        : []),
      ...(args.finalStyleSink ? [[FINAL_STYLE_SINK_CAP, args.finalStyleSink] as const] : []),
    ])
    .use('a11y', [
      [
        A11Y_PROJECT_CAP,
        createWebA11yProjector(getAccessibilitySurface, (listener) => {
          const offSurface = args.surfaceProjection.subscribeSurfaceTarget(listener);
          const offTrigger = subscribeLogicalTriggerSurface(instanceToken, listener);
          return () => {
            offSurface();
            offTrigger();
          };
        }),
      ],
    ])
    .use('event', [
      [EVENT_ROOT_TARGET_CAP, () => router.rootTarget],
      [EVENT_GLOBAL_TARGET_CAP, () => router.globalTarget],
      [EVENT_GLOBAL_INPUT_SCOPE_CAP, () => el.ownerDocument],
      [EVENT_CANCEL_DEFAULT_ACTION_CAP, cancelWebEventDefaultAction],
    ])
    .use('expose-event', [[EXPOSE_EVENT_SINK_CAP, createExposeEventSink(el)]])
    .use('focus', [
      [FOCUS_INSTANCE_TOKEN_CAP, instanceToken],
      [FOCUS_PARENT_CAP, getLogicalParent],
      [FOCUS_TARGET_READY_CAP, subscribeFocusTarget],
      [FOCUS_RELEASE_PENDING_CAP, () => args.onFocusPendingReleased?.()],
      [
        FOCUS_SAMPLE_SCOPE_TARGETS_CAP,
        (container: HTMLElement, direction?: 'next' | 'prev') =>
          sampleWebComponentScopeTargets(
            container,
            isNativelyFocusable,
            direction,
            (radio) => radioFocusHistory?.order(radio) ?? 0,
            () => radioFocusHistory?.recent() ?? null
          ),
      ],
      [FOCUS_ROOT_TARGET_CAP, () => physicalControl() ?? getTriggerSurface()],
      [FOCUS_IS_NATIVELY_FOCUSABLE_CAP, isNativelyFocusable],
      [FOCUS_ORDER_CAP, orderFocusTargetsByDocument],
      [
        FOCUS_SET_FOCUSABLE_CAP,
        (target: HTMLElement, enabled: boolean, options?: { programmatic?: boolean }) => {
          // Explicit focus-target policy owns both tabindex=0 and the
          // programmatic-only tabindex=-1; a previous entry observer must not
          // overwrite it after the target becomes enabled.
          if (options?.programmatic) stopEntryObserver();
          const surface = physicalControl() ?? getLogicalTriggerSurfaceRoot(instanceToken);
          projectFocusable(target, enabled && (!surface || surface === target), options);
        },
      ],
      [FOCUS_RESOLVE_ENTRY_TARGET_CAP, resolveFocusEntryTarget],
      [
        FOCUS_SET_ENTRY_FOCUSABLE_CAP,
        (target: HTMLElement, config: FocusEntryConfig, enabled: boolean) => {
          stopEntryObserver();
          if (!enabled) {
            projectFocusable(target, false);
            return;
          }

          const observerGeneration = entryObserverGeneration;
          const isCurrentEntryObservation = () =>
            entryObserverGeneration === observerGeneration && entryObserver !== null;
          let projectedTargetTabIndex = target.getAttribute('tabindex');
          const projectEntry = () => {
            // A host selected as the substituted Tab stop must remain a valid
            // focus target for the duration of that focus. Once focus leaves,
            // the ordinary descendant-first result is restored immediately.
            const usesSelf =
              target.ownerDocument.activeElement === target ||
              (config.fallback === 'self' &&
                (config.strategy === 'self' ||
                  !hasWebComponentScopeDescendant(target, isNativelyFocusable)));
            projectFocusable(target, usesSelf);
            projectedTargetTabIndex = target.getAttribute('tabindex');
          };
          const projectCurrent = () => {
            if (isCurrentEntryObservation()) projectEntry();
          };
          projectEntry();
          // Entry policy can be projected before descendant custom elements
          // restore their tabindex on reveal. Track the same DOM inputs used
          // by the resolver, without requesting focus or manufacturing facts.
          const Observer = target.ownerDocument.defaultView?.MutationObserver;
          if (config.strategy === 'descendant-first' && Observer) {
            const view = target.ownerDocument.defaultView;
            const Resize = view?.ResizeObserver;
            if (Resize) entryResizeObserver = new Resize(projectCurrent);
            // The late-attach watch below is installed once but must always
            // consult the currently observed region, so the root set lives
            // outside observeTree() and is refreshed on every resample
            // instead of being captured from the first scan.
            const observedRoots = new Set<Node>();
            let entryRelationalSubjects = new Set<Element>();
            let hasExternalStyleInputs = false;
            let pendingEntryRefresh: boolean | undefined;
            const scheduleEntrySample = (refresh: boolean) => {
              if (pendingEntryRefresh !== undefined) {
                pendingEntryRefresh ||= refresh;
                return;
              }
              pendingEntryRefresh = refresh;
              // Other observers can still write in this delivery. Sample
              // their final DOM together before the next rendering step.
              queueMicrotask(() => {
                const rebuild = pendingEntryRefresh;
                pendingEntryRefresh = undefined;
                if (!isCurrentEntryObservation()) return;
                if (rebuild) refreshTree();
                else projectEntry();
              });
            };
            const belongsToObservedEntryTree = (node: Node) => {
              for (const root of observedRoots) {
                if (root === node || root.contains(node)) return true;
              }
              return false;
            };
            const pendingUpgrades = new Map<string, [(() => void) | null]>();
            stopEntryUpgradeWatch = () => {
              for (const subscription of pendingUpgrades.values()) subscription[0] = null;
              pendingUpgrades.clear();
            };
            const observeTree = () => {
              if (!isCurrentEntryObservation()) return;
              entryObserver?.disconnect();
              entryImageObserver?.disconnect();
              entryExternalStyleObserver?.disconnect();
              entryRadioGroupObserver?.disconnect();
              entryResizeObserver?.disconnect();
              stopEntryRadioStateWatch?.();
              stopEntryImageStateWatch?.();
              stopEntrySlotWatch?.();
              stopEntryMotionWatch?.();
              stopEntryRadioStateWatch =
                stopEntryImageStateWatch =
                stopEntrySlotWatch =
                stopEntryMotionWatch =
                  null;
              let hasArea = false;
              const radioTrees = new Set<Document | ShadowRoot>();
              const mediaRoots = new Set<Document | ShadowRoot>([target.ownerDocument]);
              const radioNames = new Set<string>();
              const radioFormIds = new Set<string>();
              const options: MutationObserverInit = {
                childList: true,
                subtree: true,
                characterData: true,
                attributes: true,
                attributeOldValue: true,
                attributeFilter: [
                  'tabindex',
                  'disabled',
                  'aria-disabled',
                  'hidden',
                  'inert',
                  'aria-hidden',
                  'href',
                  'contenteditable',
                  'controls',
                  'type',
                  'open',
                  'usemap',
                  'src',
                  'srcset',
                  'slot',
                  'name',
                  'form',
                  'checked',
                  // Reflected constraint/default attributes can change
                  // :required, :read-only, validity and placeholder styling
                  // without input/change events or a resize.
                  'required',
                  'readonly',
                  'min',
                  'max',
                  'step',
                  'minlength',
                  'maxlength',
                  'pattern',
                  'multiple',
                  'value',
                  'placeholder',
                  'id',
                  'class',
                  'style',
                ],
              };
              // attachShadow() itself produces no light-tree record, so a
              // descendant custom element that upgrades (or otherwise attaches
              // an open root) after observation starts would keep the host
              // fallback forever. Upgrade notifications are the bounded
              // readiness signal: resample once per newly defined name.
              const registry = target.ownerDocument.defaultView?.customElements;
              const watchUpgrade = (element: Element, includeBuiltIn = false) => {
                const name = element.localName.includes('-')
                  ? element.localName
                  : includeBuiltIn
                    ? element.getAttribute('is')
                    : null;
                if (
                  !registry ||
                  !name?.includes('-') ||
                  pendingUpgrades.has(name) ||
                  registry.get(name)
                )
                  return;
                const subscription: [() => void] = [
                  () => {
                    pendingUpgrades.delete(name);
                    refreshTree();
                  },
                ];
                pendingUpgrades.set(name, subscription);
                registry.whenDefined(name).then(
                  () => subscription.pop()?.(),
                  () => subscription.pop()
                );
              };
              observedRoots.clear();
              const observe = (root: HTMLElement | ShadowRoot) => {
                if (observedRoots.has(root)) return;
                observedRoots.add(root);
                if (root.nodeType === 11) mediaRoots.add(root as ShadowRoot);
                entryObserver?.observe(root, options);
                if (root.nodeType === 1) entryResizeObserver?.observe(root as HTMLElement);
                hasArea ||= !!root.querySelector('area');
                // A portal stays logically beneath its origin marker while its
                // physical projection lives elsewhere (normally document.body).
                // Follow those markers so eligibility mutations in the moved
                // branch participate in the same refreshable observation graph.
                const originWalker = target.ownerDocument.createTreeWalker(
                  root,
                  view!.NodeFilter.SHOW_COMMENT
                );
                let originMarker: Node | null;
                while ((originMarker = originWalker.nextNode())) {
                  const projection = getWebComponentPortalProjectionForOrigin(originMarker);
                  if (projection) observe(projection);
                }
                // Radio-group ownership never crosses a Document/ShadowRoot
                // boundary. Observe only trees containing a relevant named
                // radio instead of every document hosting a Focus Entry.
                for (const radio of root.querySelectorAll<HTMLInputElement>(
                  'input[type="radio"][name]'
                )) {
                  radioNames.add(radio.name);
                  const formId = radio.getAttribute('form') || radio.form?.id;
                  if (formId) radioFormIds.add(formId);
                  const tree = radio.getRootNode();
                  if (tree.nodeType === 9 || (tree.nodeType === 11 && !!(tree as ShadowRoot).host))
                    radioTrees.add(tree as Document | ShadowRoot);
                }
                if (root.nodeType === 1 && (root as HTMLElement).shadowRoot)
                  observe((root as HTMLElement).shadowRoot!);
                for (const descendant of root.querySelectorAll<HTMLElement>('*')) {
                  entryResizeObserver?.observe(descendant);
                  if (descendant.shadowRoot) observe(descendant.shadowRoot);
                  else watchUpgrade(descendant);
                }
              };
              observe(target);
              // Named radio peers and image-map images can depend on inline
              // style outside the entry's observed DOM, including ancestors.
              hasExternalStyleInputs = hasArea || radioTrees.size > 0;
              entryStyleWatch?.observeInline(hasExternalStyleInputs);
              entryExternalStyleObserver ??= new Observer((records) => {
                if (!isCurrentEntryObservation()) return;
                if (
                  records.some((record) => {
                    if (
                      !belongsToObservedEntryTree(record.target) ||
                      invalidatesEntryStyles(record)
                    )
                      return true;
                    for (const subject of entryRelationalSubjects)
                      if (subject.contains(record.target)) return true;
                    return false;
                  })
                )
                  scheduleEntrySample(false);
              });
              // The entry region can itself be slotted or nested below
              // selector-bearing ancestors outside its owned subtree. Their
              // Arbitrary author attributes can participate in descendant
              // selectors, so observe every attribute on only this bounded
              // composed chain instead of guessing a global allowlist.
              let externalAncestor = composedParentElement(target);
              const externalAncestors: Element[] = [];
              const externalSlots = new Set<HTMLSlotElement>();
              const externalStyleRoots = new Set<ShadowRoot>();
              const motionTargets = new Set<Element>([target]);
              const shadowAnimationTargets = new Set<EventTarget>(
                [...observedRoots].filter((root) => root.nodeType === 11)
              );
              // Owned portals retain logical ancestry while their stylesheet
              // scope follows the physical projection's containing root.
              for (const root of observedRoots) {
                const physicalRoot = root.getRootNode();
                if (
                  physicalRoot.nodeType === 11 &&
                  !!(physicalRoot as ShadowRoot).host &&
                  !observedRoots.has(physicalRoot)
                ) {
                  externalStyleRoots.add(physicalRoot as ShadowRoot);
                  mediaRoots.add(physicalRoot as ShadowRoot);
                }
              }
              while (externalAncestor) {
                externalAncestors.push(externalAncestor);
                motionTargets.add(externalAncestor);
                // Container-query eligibility can change solely because a
                // composed ancestor crosses a size threshold. Reuse the
                // view-epoch observer over this already bounded chain.
                entryResizeObserver?.observe(externalAncestor);
                entryObserver?.observe(externalAncestor, {
                  attributes: true,
                  attributeOldValue: true,
                });
                const externalRoot = externalAncestor.getRootNode();
                if (
                  externalRoot.nodeType === 11 &&
                  !!(externalRoot as ShadowRoot).host &&
                  !observedRoots.has(externalRoot)
                ) {
                  externalStyleRoots.add(externalRoot as ShadowRoot);
                  mediaRoots.add(externalRoot as ShadowRoot);
                }
                if (
                  externalAncestor.namespaceURI === 'http://www.w3.org/1999/xhtml' &&
                  externalAncestor.localName === 'slot'
                )
                  externalSlots.add(externalAncestor as HTMLSlotElement);
                externalAncestor = composedParentElement(externalAncestor);
              }
              const [
                mediaQueries,
                relationalDependency,
                siblingSubjects,
                relationalSubjects,
                positionParents,
                filteredPositionParents,
              ] = collectEntryStyleDependencies(
                view!,
                mediaRoots,
                target,
                externalAncestors,
                !!entryResizeObserver && !hasExternalStyleInputs,
                observedRoots
              );
              entryRelationalSubjects = relationalSubjects;
              for (const parent of positionParents) {
                const filtered = filteredPositionParents.has(parent as Element | ShadowRoot);
                if (filtered || !belongsToObservedEntryTree(parent))
                  entryObserver?.observe(
                    parent,
                    filtered && observedRoots.has(parent)
                      ? { ...options, attributeFilter: undefined }
                      : { childList: true, attributes: true, attributeOldValue: true }
                  );
              }
              // A filtered position can be gated by selectors above its
              // parent, including the physical chain of an owned portal.
              const filteredPositionAncestors = new Set<Element>();
              for (const parent of filteredPositionParents.keys()) {
                let followsPortal =
                  parent.nodeType === 1 && isWebComponentPortaled(parent as HTMLElement);
                for (
                  let ancestor = parent.parentElement;
                  ancestor && (followsPortal || belongsToObservedEntryTree(ancestor));
                  ancestor = ancestor.parentElement
                ) {
                  if (filteredPositionAncestors.has(ancestor)) break;
                  filteredPositionAncestors.add(ancestor);
                  followsPortal ||= isWebComponentPortaled(ancestor as HTMLElement);
                  if (!filteredPositionParents.has(ancestor))
                    entryObserver?.observe(
                      ancestor,
                      observedRoots.has(ancestor)
                        ? { ...options, attributeFilter: undefined }
                        : { attributes: true, attributeOldValue: true }
                    );
                }
              }
              for (const subject of entryRelationalSubjects) {
                entryExternalStyleObserver.observe(subject, {
                  childList: true,
                  subtree: true,
                  attributes: true,
                });
              }
              const siblingStateTargets = new Set<EventTarget>();
              const observeSibling = (sibling: Element) => {
                if (siblingStateTargets.has(sibling)) return;
                siblingStateTargets.add(sibling);
                entryObserver?.observe(sibling, {
                  childList: true,
                  subtree: true,
                  characterData: true,
                  attributes: true,
                  attributeOldValue: true,
                });
              };
              // The positional subject can also change its own membership,
              // including through attributes outside the entry allowlist.
              for (const [parent, watchesDefinition] of filteredPositionParents) {
                for (const sibling of parent.children) {
                  observeSibling(sibling);
                  if (!watchesDefinition) continue;
                  watchUpgrade(sibling, true);
                  for (const descendant of sibling.querySelectorAll('*'))
                    watchUpgrade(descendant, true);
                }
              }
              for (const subject of siblingSubjects) {
                if (subject.parentNode && !positionParents.has(subject.parentNode))
                  entryObserver?.observe(subject.parentNode, {
                    childList: true,
                  });
                let sibling = subject.previousElementSibling;
                while (sibling) {
                  observeSibling(sibling);
                  sibling = sibling.previousElementSibling;
                }
              }
              if (relationalDependency === 1) {
                for (const ancestor of externalAncestors) {
                  if (
                    ancestor === target.ownerDocument.body ||
                    ancestor === target.ownerDocument.documentElement
                  )
                    continue;
                  entryExternalStyleObserver.observe(ancestor, {
                    childList: true,
                    subtree: true,
                    attributes: true,
                  });
                }
              }
              if (relationalDependency === 2) {
                entryExternalStyleObserver.observe(target.ownerDocument.documentElement, {
                  childList: true,
                  subtree: true,
                  attributes: true,
                });
              }
              const stopEntryEnvironmentEvents = listenToEntryEvents(
                [view!, ...mediaQueries],
                ['resize', 'change'],
                projectCurrent
              );
              const onFormReset = (event: Event) => {
                const form = event.composedPath()[0];
                if (!(form instanceof view!.HTMLFormElement)) return;
                const filteredParents = [...filteredPositionParents.keys()];
                if (
                  [...form.elements].some(
                    (control) =>
                      belongsToObservedEntryTree(control) ||
                      filteredParents.some((parent) => parent.contains(control))
                  )
                )
                  queueMicrotask(projectCurrent);
              };
              const stopFormResetEvents = listenToEntryEvents(
                new Set<EventTarget>([
                  target.ownerDocument,
                  target.getRootNode(),
                  ...observedRoots,
                ]),
                ['reset'],
                onFormReset
              );
              const stopSiblingStateEvents = listenToEntryEvents(
                siblingStateTargets,
                ['toggle'],
                projectCurrent
              );
              // Keyboard modality can change :focus-visible matching on an
              // already-focused external selector subject without focus or DOM
              // mutation. Capture keydown so fallback projection is current
              // before the browser performs substituted Tab traversal.
              let keyboardTraversalPending = false;
              let keyboardTraversalTimer = 0;
              const onKeyboardModality = (event: Event) => {
                const key = event as KeyboardEvent;
                if (key.key === 'Tab' && !key.altKey && !key.ctrlKey && !key.metaKey) {
                  keyboardTraversalPending = true;
                  if (keyboardTraversalTimer) view!.clearTimeout(keyboardTraversalTimer);
                  keyboardTraversalTimer = view!.setTimeout(() => {
                    keyboardTraversalTimer = 0;
                    keyboardTraversalPending = false;
                    projectCurrent();
                  });
                }
                projectCurrent();
              };
              const stopKeyboardModalityEvents = listenToEntryEvents(
                [target.ownerDocument],
                ['keydown'],
                onKeyboardModality
              );
              const projectionEvents = [
                'transitionstart',
                'transitionend',
                'transitioncancel',
                'animationstart',
                'animationend',
                'animationcancel',
                'toggle',
                'input',
                'change',
                'pointerover',
                'pointerout',
                'focusin',
                'focusout',
              ];
              const eligibilityAnimations = new Set<Animation>();
              let eligibilityAnimationFrame = 0;
              const sampleEligibilityAnimations = () => {
                eligibilityAnimationFrame = 0;
                for (const animation of eligibilityAnimations) {
                  if (animation.playState === 'finished' || animation.playState === 'idle')
                    eligibilityAnimations.delete(animation);
                }
                if (!eligibilityAnimations.size || !isCurrentEntryObservation()) return;
                projectCurrent();
                eligibilityAnimationFrame = view!.requestAnimationFrame(
                  sampleEligibilityAnimations
                );
              };
              const trackEligibilityAnimation = (event: AnimationEvent) => {
                const eventTarget = event.composedPath()[0];
                if (!(eventTarget instanceof view!.Element)) return;
                const animations = eventTarget.getAnimations();
                const named = animations.filter(
                  (animation) =>
                    (animation as Animation & { animationName?: string }).animationName ===
                    event.animationName
                );
                // The animationstart event and the Web Animations list can be
                // observed on adjacent browser checkpoints. If the named CSS
                // animation is not exposed yet, conservatively inspect every
                // animation on the event target.
                for (const animation of named.length ? named : animations) {
                  if (animationAffectsEntryEligibility(animation))
                    eligibilityAnimations.add(animation);
                }
                if (eligibilityAnimations.size && !eligibilityAnimationFrame)
                  eligibilityAnimationFrame = view!.requestAnimationFrame(
                    sampleEligibilityAnimations
                  );
              };
              const onProjectionEvent = (event: Event) => {
                // Keep the substituted fallback stable while the browser is
                // consuming the same Tab default action. The subsequent task
                // resamples after focus-visible/focus state settles.
                if (
                  keyboardTraversalPending &&
                  (event.type === 'focusin' || event.type === 'focusout')
                )
                  return;
                if (event.type.startsWith('transition')) {
                  const propertyName = (event as TransitionEvent).propertyName;
                  if (!propertyAffectsEntryEligibility(propertyName)) return;
                  const path = event.composedPath();
                  const origin = path[0];
                  if (
                    event.isTrusted &&
                    !hasExternalStyleInputs &&
                    origin instanceof view!.Element
                  ) {
                    let related = path.includes(target) || belongsToObservedEntryTree(origin);
                    // Portals and slotted regions can have physical or composed
                    // ancestors outside the container. Consult their live paths.
                    for (const root of observedRoots) {
                      if (related) break;
                      if (isWebComponentPortalTargetOwnedBy(root, origin)) {
                        related = true;
                        break;
                      }
                      let ancestor: Node | null = root;
                      while (ancestor) {
                        if (ancestor === origin) {
                          related = true;
                          break;
                        }
                        ancestor =
                          (ancestor as Node & { assignedSlot?: HTMLSlotElement | null })
                            .assignedSlot ??
                          ancestor.parentNode ??
                          (ancestor.nodeType === 11 && 'host' in ancestor
                            ? (ancestor as ShadowRoot).host
                            : null);
                      }
                    }
                    if (!related) return;
                  }
                }
                if (event.type === 'animationstart')
                  trackEligibilityAnimation(event as AnimationEvent);
                projectCurrent();
              };
              const stopProjectionEvents = listenToEntryEvents(
                motionTargets,
                projectionEvents,
                onProjectionEvent
              );
              const stopShadowAnimationEvents = listenToEntryEvents(
                shadowAnimationTargets,
                [
                  'transitionstart',
                  'transitionend',
                  'transitioncancel',
                  'animationstart',
                  'animationend',
                  'animationcancel',
                ],
                onProjectionEvent
              );
              const onExternalStyleEvent = (event: Event) => {
                if (isEntryStylesheetElement(event.composedPath()[0] as Node)) refreshTree();
              };
              const stopExternalStyleEvents = listenToEntryEvents(
                externalStyleRoots,
                ['load', 'error'],
                onExternalStyleEvent
              );
              stopEntryMotionWatch = () => {
                if (eligibilityAnimationFrame)
                  view!.cancelAnimationFrame(eligibilityAnimationFrame);
                eligibilityAnimationFrame = 0;
                eligibilityAnimations.clear();
                stopEntryEnvironmentEvents();
                stopFormResetEvents();
                stopSiblingStateEvents();
                if (keyboardTraversalTimer) view!.clearTimeout(keyboardTraversalTimer);
                keyboardTraversalTimer = 0;
                keyboardTraversalPending = false;
                stopKeyboardModalityEvents();
                stopProjectionEvents();
                stopShadowAnimationEvents();
                stopExternalStyleEvents();
              };
              if (externalStyleRoots.size > 0) {
                for (const root of externalStyleRoots) {
                  entryExternalStyleObserver.observe(root, {
                    subtree: true,
                    childList: true,
                    characterData: true,
                    attributes: true,
                    attributeFilter: ['href', 'rel', 'media', 'disabled', 'type'],
                  });
                }
              }
              if (externalSlots.size > 0) {
                stopEntrySlotWatch = listenToEntryEvents(
                  externalSlots,
                  ['slotchange'],
                  refreshTree
                );
              }
              // An already-upgraded descendant can still attach an open root
              // later (from a method, timer, or state transition), which is
              // invisible to both DOM mutation records and upgrade watches.
              // While this region is observed, wrap the window's attachShadow
              // with a reference-counted watch that resamples once a late open
              // root lands inside an already-observed root.
              stopEntryAttachShadowWatch ??= watchLateAttachShadow(
                target.ownerDocument.defaultView,
                belongsToObservedEntryTree,
                refreshTree
              );
              // Both entry resolvers consult document-level image-map bindings.
              // Only regions with areas need this extra observation; unrelated
              // document mutations must not resample ordinary entry regions.
              if (hasArea) {
                entryImageObserver ??= new Observer((records) => {
                  if (!isCurrentEntryObservation()) return;
                  const containsImage = (node: Node) =>
                    node.nodeType === 1 &&
                    ((node as Element).localName === 'img' ||
                      !!(node as Element).querySelector('img'));
                  if (
                    records.some((record) =>
                      record.type === 'childList'
                        ? [...record.addedNodes, ...record.removedNodes].some(containsImage)
                        : containsImage(record.target)
                    )
                  )
                    projectEntry();
                });
                entryImageObserver.observe(target.ownerDocument, {
                  subtree: true,
                  childList: true,
                  attributes: true,
                  attributeFilter: [
                    'usemap',
                    'src',
                    'srcset',
                    'hidden',
                    'inert',
                    'aria-hidden',
                    'open',
                    'class',
                    'style',
                  ],
                });
                for (const image of target.ownerDocument.querySelectorAll('img[usemap]'))
                  entryResizeObserver?.observe(image);
                const onImageState = (event: Event) => {
                  const image = event.target;
                  if (
                    isCurrentEntryObservation() &&
                    !!image &&
                    typeof image === 'object' &&
                    (image as Node).nodeType === 1 &&
                    (image as Element).localName === 'img' &&
                    (image as Element).hasAttribute('usemap')
                  )
                    projectEntry();
                };
                stopEntryImageStateWatch = listenToEntryEvents(
                  [target.ownerDocument],
                  ['load', 'error'],
                  onImageState
                );
              }
              // Native radio checkedness is property state: a click on a group
              // member outside this entry region, or a form reset, need not
              // produce any MutationObserver record. Observe only the DOM
              // trees that own named radios in the region and re-evaluate
              // after the native state transition has settled.
              if (radioTrees.size > 0) {
                entryRadioGroupObserver = new Observer((records) => {
                  if (!isCurrentEntryObservation()) return;
                  if (
                    records.some(
                      (record) =>
                        !belongsToObservedEntryTree(record.target) &&
                        invalidatesEntryRadioGroup(record, radioNames, radioFormIds)
                    )
                  ) {
                    refreshTree();
                  }
                });
                for (const tree of radioTrees) {
                  entryRadioGroupObserver.observe(tree, {
                    subtree: true,
                    childList: true,
                    attributes: true,
                    attributeOldValue: true,
                    attributeFilter: ['name', 'form', 'type', 'disabled', 'id'],
                  });
                }
                const eventOrigin = (event: Event) => event.composedPath()[0] ?? event.target;
                const onRadioState = (event: Event) => {
                  const origin = eventOrigin(event);
                  if (
                    !origin ||
                    typeof origin !== 'object' ||
                    (origin as Node).nodeType !== 1 ||
                    (origin as Element).namespaceURI !== 'http://www.w3.org/1999/xhtml'
                  )
                    return;
                  const element = origin as HTMLInputElement;
                  if (
                    event.type === 'change'
                      ? element.localName !== 'input' || element.type !== 'radio' || !element.name
                      : element.localName !== 'form'
                  )
                    return;
                  queueMicrotask(projectCurrent);
                };
                stopEntryRadioStateWatch = listenToEntryEvents(
                  radioTrees,
                  ['change', 'reset'],
                  onRadioState
                );
              }
            };
            function refreshTree() {
              if (!isCurrentEntryObservation()) return;
              projectEntry();
              observeTree();
            }
            entryObserver = new Observer((records) => {
              if (!isCurrentEntryObservation()) return;
              if (
                records.some((record) => {
                  if (record.type !== 'attributes') return true;
                  const current = (record.target as Element).getAttributeNS(
                    record.attributeNamespace,
                    record.attributeName!
                  );
                  // Same-valued writes do not change this selector input.
                  // Check each record: a later B -> A in an A -> B -> A batch
                  // or an author callback's separate mutation still refreshes.
                  if (record.oldValue === current) return false;
                  return (
                    record.target !== target ||
                    record.attributeNamespace !== null ||
                    record.attributeName !== 'tabindex' ||
                    current !== projectedTargetTabIndex
                  );
                })
              ) {
                // Ignore unchanged attributes and the Adapter's projected target value.
                // A delegated surface can also receive an author/runtime write;
                // a different value must be resampled and restored exactly once.
                // New native descendants can own open roots. A single DOM
                // subtree observation never crosses those boundaries.
                scheduleEntrySample(true);
              }
            });
            if (view)
              entryStyleWatch = watchEntryStyleInvalidation(view, (inlineOnly) => {
                // DOM and stylesheet invalidation can share one observer
                // checkpoint. Use the same pending sample instead of rebuilding
                // the dependency graph once here and again for the DOM signal.
                if (!inlineOnly) scheduleEntrySample(true);
                else projectCurrent();
              });
            observeTree();
          }
        },
      ],
      [
        FOCUS_REQUEST_FOCUS_CAP,
        (target: HTMLElement, options: FocusRequestOptions | undefined, kind: FocusRequestKind) => {
          if (request.options !== options || request.kind !== kind) {
            request.options = options;
            request.kind = kind;
            args.onFocusIntent?.();
          }
          if (
            !target.isConnected ||
            (kind === 'native' && !isNativeFocusTargetReady(target)) ||
            (kind === 'entry' && !args.isEntryAcquisitionReady(target))
          )
            return false;
          target.focus(
            typeof options?.preventScroll === 'boolean'
              ? { preventScroll: options.preventScroll }
              : undefined
          );
          // Native focus scrolling does not reach every custom-element scroll
          // container (observed: a flex custom-element list with overflow-x
          // auto never moves for a focused custom-element member). An explicit
          // nearest reveal is a no-op where native focus already scrolled.
          if (options?.preventScroll !== true)
            target.scrollIntoView({ block: 'nearest', inline: 'nearest' });
          const applied = isWebFocusTargetActive(target);
          // Native focus can synchronously issue a newer request. Only the
          // still-current intent owns success or retry-budget accounting.
          if (request.options === options && request.kind === kind) {
            if (applied) args.onFocusAcquired?.();
            else args.retryTargetReady();
          }
          return applied;
        },
      ],
      [FOCUS_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
      [
        FOCUS_BLUR_CAP,
        (target: HTMLElement) => {
          target.blur();
        },
      ],
    ]);
  addExposeStateModule(wiring, setExposes).use('expose-state-web', () => [
    [HOST_ELEMENT_CAP, el],
    [EXPOSE_STATE_WEB_MAP_CAP, createExposeStateWebNameMap],
    [
      EXPOSE_STATE_WEB_MIRROR_TARGETS_CAP,
      () => (presentationSurface === el ? [] : [presentationSurface]),
    ],
    ...(exposeStateWebMode ? [[EXPOSE_STATE_WEB_MODE_CAP, exposeStateWebMode] as const] : []),
  ]);

  return addLogicalModules(
    wiring,
    instanceToken,
    getMeta,
    colorSchemeSource,
    preferenceSource,
    styleSupportSource,
    viewportSource,
    createDomOrderObserver
  )
    .use('hit-participation', [
      [HOST_ELEMENT_CAP, el],
      [HIT_PARTICIPATION_HOST_BRIDGE_CAP, createWebHitParticipationHostBridge()],
    ])
    .use('boundary', [
      [HOST_ELEMENT_CAP, el],
      [BOUNDARY_HOST_BRIDGE_CAP, createWebBoundaryHostBridge()],
    ])
    .use('positioning', [
      [ANCHORED_POSITION_HOST_CAP, createFloatingUiAnchoredPositionHost()],
      [CONTEXT_MENU_INPUT_HOST_CAP, createWebContextMenuInputHost()],
      [CONTEXT_MENU_INPUT_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
      [AVAILABLE_SPACE_HOST_CAP, createWebAvailableSpaceHost()],
    ])
    .use('axis-input', [
      [AXIS_INPUT_HOST_CAP, createWebAxisInputHost()],
      [AXIS_INPUT_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
    ])
    .use('scroll', [
      [
        SCROLL_SURFACE_HOST_CAP,
        createBoundWebScrollSurfaceHost({
          boundary: el,
          getTarget: () =>
            (args.feedbackSurfaceProjection ?? args.surfaceProjection).getSurfaceTarget(),
          isReady: args.isViewReady,
          subscribeTarget: (listener) =>
            subscribeScrollTarget(
              (fn) =>
                (args.feedbackSurfaceProjection ?? args.surfaceProjection).subscribeSurfaceTarget(
                  fn
                ),
              args.subscribeTargetReady,
              listener
            ),
          subscribeDocumentChange: args.subscribeDocumentChange,
          moveGestureHost: createWebMoveGestureHost(),
          preference: scrollProjection,
        }),
      ],
    ])
    .use('overlay', () => [
      [HOST_ELEMENT_CAP, el],
      [
        OVERLAY_GLOBAL_MOUNT_CAP,
        {
          mount(target: HTMLElement) {
            if (!releasePortalDirection && target.parentElement !== target.ownerDocument.body) {
              const origin = target.parentNode;
              releasePortalDirection = retainWebPortalDirection(target, () => origin);
            }
            try {
              portalMount.mount(target);
            } catch (error) {
              const release = releasePortalDirection;
              releasePortalDirection = null;
              release?.();
              throw error;
            }
          },
          unmount(target: HTMLElement) {
            const release = releasePortalDirection;
            releasePortalDirection = null;
            try {
              release?.();
            } finally {
              portalMount.unmount(target);
            }
          },
        },
      ],
      [OVERLAY_MODAL_CAP, args.overlayModal ?? createWebOverlayModal(el.ownerDocument)],
      ...(args.overlayLayerScheduler
        ? [[OVERLAY_LAYER_SCHEDULER_CAP, args.overlayLayerScheduler] as const]
        : []),
    ])
    .build();
}

function isNativelyFocusable(el: HTMLElement): boolean {
  const tag = el.tagName.toLowerCase();
  if (tag === 'button' || tag === 'select' || tag === 'textarea' || tag === 'iframe') {
    return true;
  }
  if (tag === 'input') return (el as HTMLInputElement).type !== 'hidden';
  if (tag === 'a') return el.hasAttribute('href');
  if (tag === 'area') {
    const map = el.closest('map');
    if (!el.hasAttribute('href') || !map?.name || !el.isConnected) return false;
    for (const image of el.ownerDocument.querySelectorAll('img[usemap]')) {
      if (
        image.getAttribute('usemap') === `#${map.name}` &&
        !image.closest('[hidden],[inert],[aria-hidden="true"]')
      )
        return true;
    }
    return false;
  }
  if (tag === 'audio' || tag === 'video') return el.hasAttribute('controls');
  if (tag === 'summary') {
    const parent = el.parentElement;
    if (parent?.tagName.toLowerCase() !== 'details') return false;
    for (const child of parent.children) {
      if (child.tagName.toLowerCase() === 'summary') return child === el;
    }
  }
  return false;
}

function projectFocusable(
  target: HTMLElement,
  enabled: boolean,
  options?: { programmatic?: boolean }
): void {
  const tabIndex = enabled
    ? '0'
    : options?.programmatic || isNativelyFocusable(target)
      ? '-1'
      : null;
  // Other entry regions observe this attribute for external selector changes.
  // Rewriting an unchanged value can keep their projections notifying each other.
  if (target.getAttribute('tabindex') === tabIndex) return;
  if (tabIndex === null) target.removeAttribute('tabindex');
  else target.setAttribute('tabindex', tabIndex);
}

function resolveFocusEntryTarget(
  container: HTMLElement,
  config: { strategy: 'self' | 'descendant-first'; fallback: 'self' | 'none' }
): HTMLElement | null {
  if (config.strategy === 'descendant-first') {
    const descendant = sampleWebComponentScopeTargets(
      container,
      isNativelyFocusable,
      'next',
      undefined,
      undefined,
      true
    ).targets.find((target) => target !== container);
    if (descendant) return descendant;
  }

  if (config.fallback === 'self') return container;
  return null;
}
