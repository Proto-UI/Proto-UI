import { writeFileSync } from 'node:fs';
import { expect, it, vi } from 'vitest';
import { AdaptToWebComponent, setElementProps } from '../src';
import * as sampler from '../src/focus-scope-targets';
import { popoverRoot, popoverTrigger, popoverContent, popoverTitle } from '../../../prototypes/base/src/popover';

it('records the actual Popover entry resolver inputs without replacing its result', async () => {
  const trace: unknown[] = [];
  const original = sampler.sampleWebComponentScopeTargets;
  const sample = (element: HTMLElement) => ({
    tag: element.localName,
    parent: element.parentElement?.localName,
    attrs: Object.fromEntries(Array.from(element.attributes, (a) => [a.name, a.value])),
    style: ['display', 'visibility', 'contentVisibility'].map((key) => [key, (getComputedStyle(element) as any)[key]]),
    children: Array.from(element.children, (child) => ({
      tag: child.localName, attrs: Object.fromEntries(Array.from(child.attributes, (a) => [a.name,a.value])),
      tabIndex: (child as HTMLElement).tabIndex,
      style: ['display', 'visibility', 'contentVisibility'].map((key) => [key, (getComputedStyle(child) as any)[key]]),
    })),
  });
  vi.spyOn(sampler, 'sampleWebComponentScopeTargets').mockImplementation((...args) => {
    const result = original(...args);
    trace.push({ type: 'sample', state: sample(args[0]), targets: result.targets.map((target) => target.localName) });
    return result;
  });
  const nodes = [popoverRoot, popoverTrigger, popoverContent, popoverTitle].map((proto, index) => {
    const C = AdaptToWebComponent(proto, { registerAs: `sprint1-entry-diagnostic-${index}` });
    return new C();
  });
  const [root, trigger, content, title] = nodes;
  const link = document.createElement('a');
  link.href = '#settings';
  link.textContent = 'Settings';
  setElementProps(content, { enterDuration: 0, leaveDuration: 0 });
  for (const element of [link, content]) {
    const nativeFocus = element.focus.bind(element);
    vi.spyOn(element, 'focus').mockImplementation((options) => {
      trace.push({ type: 'focus', state: sample(element), options });
      nativeFocus(options);
    });
  }
  content.append(title, link);
  root.append(trigger, content);
  const flush = async () => { for (let index = 0; index < 20; index++) await Promise.resolve(); };
  try {
    document.body.append(root);
    await flush();
    trace.push({ type: 'before-open', state: sample(content) });
    trigger.click();
    await flush();
    trace.push({ type: 'after-open', state: sample(content), active: document.activeElement?.localName });
    expect(document.activeElement).toBe(link);
  } finally {
    writeFileSync('/workspace/scratch/62ffef219b8e/lifecycle-evidence/popover-entry-diagnostic.json', JSON.stringify(trace,null,2));
    for (const node of nodes) node.remove();
    await flush();
    vi.restoreAllMocks();
  }
});
