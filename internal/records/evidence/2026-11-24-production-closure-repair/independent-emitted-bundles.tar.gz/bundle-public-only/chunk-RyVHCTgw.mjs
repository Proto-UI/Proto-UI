function freezeFamilyDecl(decl) {
  if (!decl || typeof decl !== "object") {
    throw new Error(`[Anatomy] family declaration is required.`);
  }
  if (!decl.roles || typeof decl.roles !== "object") {
    throw new Error(`[Anatomy] family declaration must define roles.`);
  }
  if (!decl.roles.root) {
    throw new Error(`[Anatomy] family declaration must define a root role.`);
  }
  const roles = Object.freeze(
    Object.fromEntries(
      Object.entries(decl.roles ?? {}).map(([role, roleDecl]) => [
        role,
        Object.freeze({
          ...roleDecl,
          cardinality: Object.freeze({ ...roleDecl.cardinality }),
          requires: roleDecl.requires ? Object.freeze([...roleDecl.requires]) : void 0
        })
      ])
    )
  );
  const profiles = decl.profiles ? Object.freeze(
    Object.fromEntries(
      Object.entries(decl.profiles).map(([name, profileDecl]) => [
        name,
        Object.freeze({
          ...profileDecl,
          roles: profileDecl.roles ? Object.freeze(
            Object.fromEntries(
              Object.entries(profileDecl.roles).map(([role, roleDecl]) => [
                role,
                Object.freeze({
                  ...roleDecl,
                  cardinality: roleDecl.cardinality ? Object.freeze({ ...roleDecl.cardinality }) : void 0,
                  requires: roleDecl.requires ? Object.freeze([...roleDecl.requires]) : void 0
                })
              ])
            )
          ) : void 0,
          relations: profileDecl.relations ? Object.freeze([...profileDecl.relations]) : void 0
        })
      ])
    )
  ) : void 0;
  return Object.freeze({
    roles,
    relations: decl.relations ? Object.freeze([...decl.relations]) : void 0,
    profiles
  });
}
function createAnatomyFamily(debugName, decl) {
  if (debugName.length === 0) {
    throw new Error(`[Anatomy] debugName must be a non-empty string.`);
  }
  return Object.freeze({
    __brand: "AnatomyFamily",
    debugName,
    decl: freezeFamilyDecl(decl)
  });
}
const semanticObjectRefs = /* @__PURE__ */ new WeakSet();
function createA11ySemanticObjectRef() {
  const value = Object.freeze({});
  const ref = value;
  semanticObjectRefs.add(ref);
  return ref;
}
function isA11ySemanticObjectRef(value) {
  return typeof value === "object" && value !== null && semanticObjectRefs.has(value);
}
const entries = /* @__PURE__ */ new WeakMap();
function prepareMaterialPaintReservationPart(target) {
  const entry = entries.get(target);
  if (!entry || entry.owner.disposed)
    throw new Error("[feedback.material] unknown or disposed paint reservation");
  const serial = ++entry.serial;
  return (part) => {
    if (entry.owner.disposed || serial < entry.boundSerial) return () => {
    };
    const retained = part.identity && entry.binding?.identity === part.identity ? entry.binding : null;
    if (retained) {
      entry.boundSerial = serial;
      return () => {
        if (entry.boundSerial !== serial || entry.binding !== retained) return;
        const release2 = entry.disconnect;
        entry.disconnect = null;
        entry.binding = null;
        entry.target = null;
        entry.inlineSizeFrom = null;
        entry.outlineFrom = null;
        entry.generation = null;
        release2?.();
      };
    }
    const previous = entry.disconnect;
    entry.disconnect = null;
    entry.binding = part;
    entry.target = null;
    entry.inlineSizeFrom = null;
    entry.outlineFrom = null;
    entry.generation = null;
    entry.boundSerial = serial;
    previous?.();
    if (entry.boundSerial === serial && entry.binding === part) entry.owner.refreshEntry(entry);
    return () => {
      if (entry.boundSerial !== serial || entry.binding !== part) return;
      const release2 = entry.disconnect;
      entry.disconnect = null;
      entry.binding = null;
      entry.target = null;
      entry.inlineSizeFrom = null;
      entry.outlineFrom = null;
      entry.generation = null;
      release2?.();
    };
  };
}
function generatedIdAuthority() {
  const key = Symbol.for("@proto.ui/a11y/generated-id/v1");
  const descriptor = Object.getOwnPropertyDescriptor(globalThis, key);
  if (descriptor) {
    const service2 = descriptor.value;
    if (descriptor.get || descriptor.set || descriptor.configurable || descriptor.writable || !service2 || !Object.isFrozen(service2) || service2.version !== 1 || typeof service2.own !== "function" || typeof service2.retain !== "function")
      throw new TypeError("[A11y] incompatible same-realm generated-ID ABI; expected v1");
    return service2;
  }
  const entries2 = /* @__PURE__ */ new WeakMap();
  const lease = (element, id, entry) => {
    const owner = {};
    entry.owners.add(owner);
    return Object.freeze({
      dispose() {
        if (!entry.owners.delete(owner) || entry.owners.size) return;
        const byId = entries2.get(element);
        if (byId?.get(id) !== entry) return;
        byId.delete(id);
        if (!byId.size) entries2.delete(element);
        if (element.getAttribute("id") !== id) return;
        try {
          if (entry.baseline === null) element.removeAttribute("id");
          else element.setAttribute("id", entry.baseline);
        } catch (error) {
          try {
            if (element.getAttribute("id") === id && !entry.owners.size && !entries2.get(element)?.has(id)) {
              let retry = entries2.get(element);
              if (!retry) entries2.set(element, retry = /* @__PURE__ */ new Map());
              retry.set(id, entry);
            }
          } catch {
          }
          throw error;
        }
      }
    });
  };
  const service = Object.freeze({
    version: 1,
    own(element, id, baseline) {
      const current = element.getAttribute("id");
      if (!id || current !== id && current !== baseline)
        throw new Error("[A11y] generated-ID ownership requires the current physical baseline");
      let byId = entries2.get(element);
      if (!byId) entries2.set(element, byId = /* @__PURE__ */ new Map());
      let entry = byId.get(id);
      if (!entry) byId.set(id, entry = { baseline, owners: /* @__PURE__ */ new Set() });
      const receipt = lease(element, id, entry);
      try {
        if (current !== id) element.setAttribute("id", id);
        if (element.getAttribute("id") !== id)
          throw new Error("[A11y] generated-ID write was superseded by the host");
        return receipt;
      } catch (error) {
        try {
          receipt.dispose();
        } catch {
        }
        throw error;
      }
    },
    retain(element, id) {
      if (!id || element.getAttribute("id") !== id) return null;
      const entry = entries2.get(element)?.get(id);
      return entry ? lease(element, id, entry) : null;
    }
  });
  Object.defineProperty(globalThis, key, { value: service });
  return service;
}
function ownGeneratedId(element, id, baseline) {
  return generatedIdAuthority().own(element, id, baseline);
}
function retainGeneratedId(element, id) {
  return generatedIdAuthority().retain(element, id);
}
const ARIA_STATE_ATTRS = {
  atomic: "aria-atomic",
  autocomplete: "aria-autocomplete",
  current: "aria-current",
  sort: "aria-sort",
  busy: "aria-busy",
  checked: "aria-checked",
  disabled: "aria-disabled",
  expanded: "aria-expanded",
  hasPopup: "aria-haspopup",
  invalid: "aria-invalid",
  live: "aria-live",
  orientation: "aria-orientation",
  pressed: "aria-pressed",
  rowCount: "aria-rowcount",
  columnCount: "aria-colcount",
  rowIndex: "aria-rowindex",
  columnIndex: "aria-colindex",
  rowSpan: "aria-rowspan",
  columnSpan: "aria-colspan",
  readOnly: "aria-readonly",
  required: "aria-required",
  selected: "aria-selected",
  modal: "aria-modal",
  multiSelectable: "aria-multiselectable",
  valueMin: "aria-valuemin",
  valueMax: "aria-valuemax",
  valueNow: "aria-valuenow",
  valueText: "aria-valuetext",
  level: "aria-level",
  posInSet: "aria-posinset",
  setSize: "aria-setsize"
};
const TABLE_COUNT_STATE_KEYS = /* @__PURE__ */ new Set(["rowCount", "columnCount", "setSize"]);
const POSITIVE_INTEGER_STATE_KEYS = /* @__PURE__ */ new Set([
  "rowIndex",
  "columnIndex",
  "rowSpan",
  "columnSpan",
  "level",
  "posInSet"
]);
const ARIA_RELATION_ATTRS = {
  activeDescendant: "aria-activedescendant",
  controls: "aria-controls",
  describedBy: "aria-describedby",
  errorMessage: "aria-errormessage",
  labelledBy: "aria-labelledby"
};
function createWebA11yProjectionRegistry(options = {}) {
  const idPrefix = options.idPrefix?.trim().replace(/\s+/g, "-") || "pui-a11y";
  const dependentSourcesByRef = /* @__PURE__ */ new Map();
  const recordsByRef = /* @__PURE__ */ new Map();
  const projectedTargets = /* @__PURE__ */ new WeakSet();
  const reservedIdsByDocument = /* @__PURE__ */ new Map();
  const reservedIdsByRef = /* @__PURE__ */ new Map();
  const scalarAttributeRefs = /* @__PURE__ */ new WeakMap();
  const relationOwnerships = /* @__PURE__ */ new WeakMap();
  const pendingIdWrites = /* @__PURE__ */ new WeakMap();
  const logicalIdentities = /* @__PURE__ */ new Map();
  const releaseLogicalIdentity = (ref) => {
    if (!ref) return;
    const identity = logicalIdentities.get(ref);
    if (identity && --identity.projectors === 0) logicalIdentities.delete(ref);
  };
  const documentObservers = /* @__PURE__ */ new Map();
  const rememberIdWrite = (target) => {
    if (target.isConnected && documentObservers.has(target.ownerDocument)) {
      pendingIdWrites.set(target, target.getAttribute("id"));
    } else pendingIdWrites.delete(target);
  };
  const rememberProjectedTarget = (target) => {
    for (let current = target; current; ) {
      projectedTargets.add(current);
      const root = current.getRootNode();
      current = root.nodeType === 11 && "host" in root ? root.host : null;
    }
  };
  const touchesIdentity = (node) => {
    if (node.nodeType !== 1) return false;
    const element = node;
    if (projectedTargets.has(element) || element.hasAttribute("id")) return true;
    if (!element.firstElementChild) return false;
    const descendants = element.ownerDocument.createTreeWalker(element, 1);
    for (let current = descendants.nextNode(); current; current = descendants.nextNode()) {
      const child = current;
      if (projectedTargets.has(child) || child.hasAttribute("id")) return true;
    }
    return false;
  };
  const unobserve = (record) => {
    const document = record.observedDocument;
    if (!document) return;
    record.observedDocument = null;
    const entry = documentObservers.get(document);
    entry.records.delete(record);
    if (entry.records.size) return;
    entry.observer.disconnect();
    documentObservers.delete(document);
  };
  const observe = (record) => {
    if (record.snapshot?.viewEpoch === void 0) return;
    const document = record.target?.ownerDocument;
    if (!document || record.observedDocument === document) return;
    unobserve(record);
    let entry = documentObservers.get(document);
    if (!entry) {
      const records = /* @__PURE__ */ new Set();
      const Observer = document.defaultView?.MutationObserver ?? globalThis.MutationObserver;
      if (!Observer) return;
      const observer = new Observer((mutations) => {
        let reconcile = false;
        const ownedWrites = /* @__PURE__ */ new Map();
        for (const mutation of mutations) {
          if (mutation.type === "childList") {
            if (!reconcile)
              reconcile = [...mutation.addedNodes, ...mutation.removedNodes].some(touchesIdentity);
            continue;
          }
          if (mutation.type !== "attributes" || mutation.attributeName !== "id") continue;
          reconcile = true;
          const target = mutation.target;
          if (!pendingIdWrites.has(target)) continue;
          ownedWrites.set(target, pendingIdWrites.get(target));
          pendingIdWrites.delete(target);
        }
        const refs = /* @__PURE__ */ new Set();
        for (const owner of [...records]) {
          if (!owner.snapshot || owner.disposed || owner.detached) continue;
          if (reconcileIdentityChange(owner, ownedWrites) || owner.target?.ownerDocument !== document)
            reconcile = true;
          if (owner.objectRef) refs.add(owner.objectRef);
        }
        if (reconcile) reconcileDependents(refs);
      });
      observer.observe(document, {
        subtree: true,
        childList: true,
        attributes: true,
        attributeFilter: ["id"]
      });
      entry = { observer, records };
      documentObservers.set(document, entry);
    }
    entry.records.add(record);
    record.observedDocument = document;
  };
  const releaseScalarAttribute = (record, attr) => {
    const target = record.target;
    if (!target) return;
    const byAttribute = scalarAttributeRefs.get(target);
    if (!byAttribute) return;
    const ownership = byAttribute.get(attr);
    if (!ownership) return;
    const value = record.scalarAttributes.get(attr);
    const count = ownership.counts.get(value);
    if (!count || !record.scalarAttributes.delete(attr)) return;
    if (count === 1) ownership.counts.delete(value);
    else ownership.counts.set(value, count - 1);
    const current = target.getAttribute(attr);
    if (current !== ownership.projectedValue) {
      ownership.baseline = current;
      ownership.projectedValue = void 0;
    } else if (count === 1 && current === (value ?? null)) {
      const remaining = [...ownership.counts.keys()];
      const next = remaining.length > 0 ? remaining[remaining.length - 1] ?? null : ownership.baseline;
      if (next !== current) {
        if (next === null) target.removeAttribute(attr);
        else target.setAttribute(attr, next);
        if (attr === "id") rememberIdWrite(target);
      }
      ownership.projectedValue = next;
    }
    if (ownership.counts.size === 0) byAttribute.delete(attr);
    if (byAttribute.size === 0) scalarAttributeRefs.delete(target);
  };
  const releaseScalarAttributes = (record, removeOwned = true) => {
    if (!removeOwned) return;
    const affectedIdRefs = record.scalarAttributes.has("id") && record.target ? scalarAttributeRefs.get(record.target)?.get("id")?.affectedIdRefs : void 0;
    for (const attr of record.scalarAttributes.keys()) releaseScalarAttribute(record, attr);
    return affectedIdRefs;
  };
  const canRetainScalarAttributes = (record, target, attributes) => {
    if (!attributes.size || attributes.size !== record.scalarAttributes.size || attributes.has("id"))
      return false;
    const owners = scalarAttributeRefs.get(target);
    for (const [attr, value] of attributes) {
      const owner = owners?.get(attr);
      if (!record.scalarAttributes.has(attr) || record.scalarAttributes.get(attr) !== value || owner?.counts.size !== 1 || owner.counts.get(value) !== 1 || owner.projectedValue !== (value ?? null) || target.getAttribute(attr) !== owner.projectedValue)
        return false;
    }
    return true;
  };
  const acquireScalarAttributes = (record, target, snapshot, attributes, affectedIdRefs) => {
    const identity = logicalIdentities.get(snapshot.objectRef);
    if (snapshot.viewEpoch !== void 0 && identity?.supersededId !== void 0) {
      if (identity.supersededId === snapshot.id) attributes.delete("id");
      else delete identity.supersededId;
    }
    if (attributes.has("id")) {
      const reservation = reservedIdsByDocument.get(target.ownerDocument)?.get(target.id);
      const owners = reservation && recordsByRef.get(reservation.objectRef);
      if (owners) {
        for (const owner of owners) {
          if (owner.ownedIdTarget !== target) continue;
          if (owner !== record && owner.objectRef) {
            (affectedIdRefs ??= /* @__PURE__ */ new Set()).add(owner.objectRef);
          }
          releaseOwnedId(owner);
        }
      }
    }
    let byAttribute = scalarAttributeRefs.get(target);
    for (const [attr, value] of attributes) {
      if (!byAttribute) {
        byAttribute = /* @__PURE__ */ new Map();
        scalarAttributeRefs.set(target, byAttribute);
      }
      const current = target.getAttribute(attr);
      let ownership = byAttribute.get(attr);
      if (!ownership) {
        ownership = { baseline: current, projectedValue: current, counts: /* @__PURE__ */ new Map() };
        byAttribute.set(attr, ownership);
      } else if (current !== ownership.projectedValue) ownership.baseline = current;
      ownership.counts.set(value, (ownership.counts.get(value) ?? 0) + 1);
      ownership.projectedValue = value ?? null;
      if (affectedIdRefs && attr === "id") {
        if (!ownership.affectedIdRefs) ownership.affectedIdRefs = affectedIdRefs;
        else if (ownership.affectedIdRefs !== affectedIdRefs) {
          for (const ref of affectedIdRefs) ownership.affectedIdRefs.add(ref);
        }
      }
    }
    record.scalarAttributes = attributes;
    return attributes;
  };
  let nextId = 1;
  const unindex = (record) => {
    if (!record.objectRef) return;
    const indexed = recordsByRef.get(record.objectRef);
    if (!indexed) return;
    indexed.delete(record);
    if (indexed.size === 0) recordsByRef.delete(record.objectRef);
  };
  const releaseOwnedId = (record) => {
    const target = record.ownedIdTarget;
    const lease = record.generatedIdLease;
    record.ownedIdTarget = null;
    record.ownedIdBaseline = null;
    record.generatedIdLease = null;
    const before = target?.getAttribute("id");
    lease?.dispose();
    if (target && target.getAttribute("id") !== before) rememberIdWrite(target);
  };
  const releaseReservation = (record) => {
    releaseOwnedId(record);
    const { objectRef, reservedDocument, reservedId } = record;
    if (objectRef && reservedDocument && reservedId) {
      const documentReservations = reservedIdsByDocument.get(reservedDocument);
      const reservation = documentReservations?.get(reservedId);
      if (reservation?.objectRef === objectRef && --reservation.count === 0) {
        documentReservations.delete(reservedId);
        if (documentReservations.size === 0) reservedIdsByDocument.delete(reservedDocument);
        const refReservations = reservedIdsByRef.get(objectRef);
        if (refReservations?.get(reservedDocument) === reservation) {
          refReservations.delete(reservedDocument);
          if (refReservations.size === 0) reservedIdsByRef.delete(objectRef);
        }
      }
    }
    record.reservedDocument = null;
    record.reservedId = null;
  };
  const clearProjection = (record, key) => {
    const projection = record.projections.get(key);
    if (!projection) return;
    const { target, attr, tokens } = projection;
    const byAttribute = relationOwnerships.get(target);
    const ownership = byAttribute.get(attr);
    const currentValue = target.getAttribute(attr);
    const canRestore = ownership.projectedValue !== void 0 && currentValue === ownership.projectedValue;
    for (const token of tokens) {
      const count = ownership.counts.get(token) - 1;
      if (count) ownership.counts.set(token, count);
      else ownership.counts.delete(token);
    }
    ownership.projections.delete(projection);
    if (canRestore) {
      const visible = [...ownership.baseline];
      let value;
      for (const owner of ownership.projections) {
        if (owner.mode === "replace") {
          visible.length = 0;
          value = owner.value;
        } else value = void 0;
        visible.push(...owner.tokens);
      }
      if (value !== void 0) setOptionalAttr(target, attr, value);
      else setTokenListAttr(target, attr, visible);
      ownership.projectedValue = target.getAttribute(attr);
    } else {
      const previousBaseline = ownership.baseline;
      ownership.baseline = new Set(
        readTokens(currentValue).filter(
          (token) => !ownership.counts.has(token) || previousBaseline.has(token)
        )
      );
      ownership.projectedValue = void 0;
    }
    if (ownership.projections.size === 0) {
      byAttribute.delete(attr);
      if (byAttribute.size === 0) relationOwnerships.delete(target);
    }
    record.projections.delete(key);
  };
  const clearProjections = (record) => {
    for (const key of [...record.projections.keys()]) clearProjection(record, key);
  };
  const removeDependencies = (record) => {
    for (const ref of record.dependencyRefs) {
      const sources = dependentSourcesByRef.get(ref);
      if (!sources) continue;
      sources.delete(record);
      if (sources.size === 0) dependentSourcesByRef.delete(ref);
    }
    record.dependencyRefs.clear();
  };
  const updateDependencies = (record, snapshot) => {
    removeDependencies(record);
    for (const key of Object.keys(ARIA_RELATION_ATTRS)) {
      const relation = snapshot.relations[key];
      if (!Array.isArray(relation)) continue;
      for (const ref of relation) {
        if (!isA11ySemanticObjectRef(ref) || record.dependencyRefs.has(ref)) continue;
        record.dependencyRefs.add(ref);
        const sources = dependentSourcesByRef.get(ref) ?? /* @__PURE__ */ new Set();
        sources.add(record);
        dependentSourcesByRef.set(ref, sources);
      }
    }
  };
  const structuredRelationsChanged = (previous, next) => {
    if (previous?.viewEpoch !== next.viewEpoch || previous?.partRelationships !== next.partRelationships)
      return true;
    for (const key of Object.keys(ARIA_RELATION_ATTRS)) {
      const previousRelation = previous?.relations[key];
      const nextRelation = next.relations[key];
      const previousIsStructured = Array.isArray(previousRelation);
      const nextIsStructured = Array.isArray(nextRelation);
      if (previousIsStructured !== nextIsStructured) return true;
      if (!previousIsStructured || !nextIsStructured) continue;
      if (previousRelation.length !== nextRelation.length) return true;
      if (previousRelation.some((ref, index) => ref !== nextRelation[index])) return true;
      if ((previous?.relationModes?.[key] ?? "replace") !== (next.relationModes?.[key] ?? "replace")) {
        return true;
      }
    }
    return false;
  };
  const idIsAvailable = (document, id, target, objectRef) => {
    const reservation = reservedIdsByDocument.get(document)?.get(id);
    if (reservation && reservation.objectRef !== objectRef) return false;
    const selector = /^[a-zA-Z_][\w-]*$/.test(id) ? `#${id}` : "[id]";
    for (const element of document.querySelectorAll(selector)) {
      if (element.id === id && element !== target) return false;
    }
    return true;
  };
  const reserveId = (record, id) => {
    const { objectRef, target } = record;
    if (!objectRef || !target) return;
    const document = target.ownerDocument;
    const documentReservations = reservedIdsByDocument.get(document) ?? /* @__PURE__ */ new Map();
    const reservation = documentReservations.get(id) ?? { id, objectRef, count: 0 };
    reservation.count += 1;
    documentReservations.set(id, reservation);
    reservedIdsByDocument.set(document, documentReservations);
    const refReservations = reservedIdsByRef.get(objectRef) ?? /* @__PURE__ */ new Map();
    refReservations.set(document, reservation);
    reservedIdsByRef.set(objectRef, refReservations);
    record.reservedDocument = document;
    record.reservedId = id;
    record.lastTargetId = id;
    if (!record.generatedIdLease) {
      record.generatedIdLease = retainGeneratedId(target, id);
      if (record.generatedIdLease) record.ownedIdTarget = target;
    }
  };
  const writeGeneratedId = (record, target, id) => {
    if (record.generatedIdLease) releaseOwnedId(record);
    const baseline = target.getAttribute("id");
    const objectRef = record.objectRef;
    const lease = ownGeneratedId(target, id, baseline);
    if (record.disposed || record.detached || record.target !== target || record.objectRef !== objectRef) {
      lease.dispose();
      return false;
    }
    record.generatedIdLease = lease;
    record.ownedIdBaseline = baseline;
    record.ownedIdTarget = target;
    rememberIdWrite(target);
    return true;
  };
  const ensureTargetId = (record) => {
    const { target, objectRef } = record;
    if (!target || !objectRef) return null;
    const document = target.ownerDocument;
    if (record.reservedDocument && record.reservedDocument !== document) {
      releaseReservation(record);
    }
    if (!record.reservedId) {
      const reservation = reservedIdsByRef.get(objectRef)?.get(document);
      if (reservation) {
        reservation.count += 1;
        record.reservedDocument = document;
        record.reservedId = reservation.id;
      }
    }
    if (record.reservedId) {
      if (target.id && target.id !== record.reservedId) return null;
      if (!idIsAvailable(document, record.reservedId, target, objectRef)) return null;
      if (!target.id) {
        if (!writeGeneratedId(record, target, record.reservedId)) return null;
      } else if (!record.generatedIdLease) {
        record.generatedIdLease = retainGeneratedId(target, record.reservedId);
        if (record.generatedIdLease) record.ownedIdTarget = target;
      }
      const refReservations = reservedIdsByRef.get(objectRef);
      if (refReservations?.get(document)?.id !== record.reservedId) {
        const current = refReservations ?? /* @__PURE__ */ new Map();
        current.set(document, reservedIdsByDocument.get(document).get(record.reservedId));
        reservedIdsByRef.set(objectRef, current);
      }
      record.lastTargetId = record.reservedId;
      return record.reservedId;
    }
    if (target.id) {
      if (!idIsAvailable(document, target.id, target, objectRef)) return null;
      reserveId(record, target.id);
      return target.id;
    }
    let candidate = `${idPrefix}-${nextId++}`;
    while (!idIsAvailable(document, candidate, target, objectRef)) {
      candidate = `${idPrefix}-${nextId++}`;
    }
    if (!writeGeneratedId(record, target, candidate)) return null;
    reserveId(record, candidate);
    return candidate;
  };
  const resolveTargets = (source, refs, key) => {
    if (!source.target || refs.length === 0) return null;
    const lease = source.snapshot?.partRelationships?.find((part) => part.relation === key);
    if (lease && (lease.source !== source.objectRef || lease.sourceEpoch !== source.snapshot?.viewEpoch)) {
      return null;
    }
    const ids = [];
    const seen = /* @__PURE__ */ new Set();
    for (const ref of refs) {
      if (seen.has(ref)) continue;
      seen.add(ref);
      const candidates = [...recordsByRef.get(ref) ?? []].filter(
        (record) => record.target?.ownerDocument === source.target?.ownerDocument && (!lease || lease.target === ref && lease.targetEpoch === record.snapshot?.viewEpoch)
      );
      if (candidates.length !== 1) return null;
      const id = ensureTargetId(candidates[0]);
      if (!id) return null;
      ids.push(id);
    }
    return ids;
  };
  const applyRelationProjection = (record, key, attr, mode, tokens, value) => {
    const current = record.projections.get(key);
    if (current && current.target === record.target && current.mode === mode && current.value === value && tokens && current.tokens.length === tokens.length && current.tokens.every((token, index) => token === tokens[index]))
      return;
    clearProjection(record, key);
    if (!record.target || !tokens || tokens.length === 0 && (value === void 0 || mode === "append"))
      return;
    const target = record.target;
    const previousValue = target.getAttribute(attr);
    const previousTokens = readTokens(previousValue);
    let byAttribute = relationOwnerships.get(target);
    if (!byAttribute) {
      byAttribute = /* @__PURE__ */ new Map();
      relationOwnerships.set(target, byAttribute);
    }
    let ownership = byAttribute.get(attr);
    if (!ownership) {
      ownership = {
        baseline: /* @__PURE__ */ new Set(),
        counts: /* @__PURE__ */ new Map(),
        projections: /* @__PURE__ */ new Set(),
        projectedValue: void 0
      };
      byAttribute.set(attr, ownership);
    }
    if (previousValue !== ownership.projectedValue) {
      const previousBaseline = ownership.baseline;
      ownership.baseline = new Set(
        previousTokens.filter(
          (token) => !ownership.counts.has(token) || previousBaseline.has(token)
        )
      );
    }
    const projection = { target, attr, mode, tokens, value };
    for (const token of tokens) ownership.counts.set(token, (ownership.counts.get(token) ?? 0) + 1);
    ownership.projections.add(projection);
    if (mode === "replace" && value !== void 0) setOptionalAttr(target, attr, value);
    else
      setTokenListAttr(target, attr, mode === "append" ? [...previousTokens, ...tokens] : tokens);
    ownership.projectedValue = target.getAttribute(attr);
    record.projections.set(key, projection);
  };
  const reconcileSource = (record) => {
    const active = /* @__PURE__ */ new Set();
    if (record.target && record.snapshot) {
      for (const [key, attr] of Object.entries(ARIA_RELATION_ATTRS)) {
        const relation = record.snapshot.relations[key];
        if (!Array.isArray(relation)) continue;
        active.add(key);
        const refs = relation.filter(isA11ySemanticObjectRef);
        const tokens = refs.length === relation.length ? resolveTargets(record, refs, key) : null;
        applyRelationProjection(
          record,
          key,
          attr,
          record.snapshot.relationModes?.[key] ?? "replace",
          tokens
        );
      }
    }
    for (const [key, projection] of record.projections) {
      if (projection.value === void 0 && !active.has(key)) clearProjection(record, key);
    }
  };
  const reconcileDependents = (refs, alreadyReconciled) => {
    const affected = /* @__PURE__ */ new Set();
    for (const ref of refs) {
      for (const source of dependentSourcesByRef.get(ref) ?? []) affected.add(source);
    }
    if (alreadyReconciled) affected.delete(alreadyReconciled);
    for (const source of affected) reconcileSource(source);
  };
  const reconcileHostId = (record) => {
    const { target, objectRef, snapshot } = record;
    if (!target || !objectRef || !snapshot) return;
    for (const source of dependentSourcesByRef.get(objectRef) ?? []) {
      for (const [key, relation] of Object.entries(source.snapshot?.relations ?? {})) {
        if (Array.isArray(relation) && relation.includes(objectRef)) clearProjection(source, key);
      }
    }
    if (snapshot.id !== void 0) {
      logicalIdentities.get(objectRef).supersededId = snapshot.id;
      if (record.scalarAttributes.has("id")) releaseScalarAttribute(record, "id");
    }
    releaseReservation(record);
    const id = target.id || null;
    if (id && idIsAvailable(target.ownerDocument, id, target, objectRef)) reserveId(record, id);
    record.lastTargetId = id;
  };
  const reconcileIdentityChange = (record, ownedWrites) => {
    const target = record.target;
    if (!target || (target.id || null) === record.lastTargetId) return false;
    const current = target.getAttribute("id");
    const scalar = scalarAttributeRefs.get(target)?.get("id");
    if (ownedWrites.has(target) && ownedWrites.get(target) === current || scalar && scalar.projectedValue === current) {
      record.lastTargetId = target.id || null;
    } else reconcileHostId(record);
    return true;
  };
  const update = (record, snapshot, forceStructured = false, reactivating = false) => {
    if (record.disposed || record.detached) return;
    if (snapshot.viewEpoch !== void 0 && record.snapshot?.viewEpoch !== void 0 && snapshot.viewEpoch < record.snapshot.viewEpoch)
      return;
    const nextTarget = record.getTarget();
    const nextDocument = nextTarget?.ownerDocument ?? record.targetDocument;
    const targetChanged = nextTarget !== record.target;
    const documentChanged = nextDocument !== record.targetDocument;
    const refChanged = snapshot.objectRef !== record.objectRef;
    if (refChanged) {
      releaseLogicalIdentity(record.objectRef);
      const identity = logicalIdentities.get(snapshot.objectRef) ?? { projectors: 0 };
      identity.projectors += 1;
      logicalIdentities.set(snapshot.objectRef, identity);
    }
    const previousSnapshot = record.snapshot;
    const previousRef = record.objectRef;
    const bindingReplaced = targetChanged || documentChanged || refChanged;
    const identityChanged = !refChanged && !reactivating && snapshot.viewEpoch !== void 0 && reconcileIdentityChange(record, pendingIdWrites);
    const previousTargetId = record.lastTargetId;
    const structuredChanged = forceStructured || bindingReplaced || identityChanged || structuredRelationsChanged(previousSnapshot, snapshot);
    const nextScalars = nextTarget ? projectedScalarAttributes(snapshot, false) : void 0;
    const retainScalars = !bindingReplaced && !forceStructured && !reactivating && !identityChanged && snapshot.viewEpoch === previousSnapshot?.viewEpoch && nextTarget && nextScalars && canRetainScalarAttributes(record, nextTarget, nextScalars);
    const releasedIdRefs = retainScalars ? void 0 : releaseScalarAttributes(record);
    if (bindingReplaced) {
      unobserve(record);
      clearProjections(record);
      unindex(record);
      releaseOwnedId(record);
      if (documentChanged || refChanged) releaseReservation(record);
    } else {
      for (const key of [...record.projections.keys()]) {
        if (!Array.isArray(snapshot.relations[key])) clearProjection(record, key);
      }
    }
    record.target = nextTarget;
    record.targetDocument = nextDocument;
    record.snapshot = snapshot;
    record.objectRef = snapshot.objectRef;
    if ((bindingReplaced || reactivating) && snapshot.viewEpoch !== void 0 && snapshot.id !== void 0 && nextTarget?.id && nextTarget.id !== snapshot.id) {
      logicalIdentities.get(snapshot.objectRef).supersededId = snapshot.id;
    }
    if (structuredChanged) updateDependencies(record, snapshot);
    if (nextTarget && nextScalars) {
      if (bindingReplaced || forceStructured || reactivating) rememberProjectedTarget(nextTarget);
      const indexed = recordsByRef.get(snapshot.objectRef) ?? /* @__PURE__ */ new Set();
      indexed.add(record);
      recordsByRef.set(snapshot.objectRef, indexed);
      if (!retainScalars) {
        const attributes = acquireScalarAttributes(
          record,
          nextTarget,
          snapshot,
          nextScalars,
          bindingReplaced ? void 0 : releasedIdRefs
        );
        applySnapshot(nextTarget, snapshot, void 0, attributes, false);
        if (attributes.has("id")) rememberIdWrite(nextTarget);
      }
      if ((bindingReplaced || reactivating) && snapshot.viewEpoch !== void 0 && reservedIdsByRef.get(snapshot.objectRef)?.has(nextDocument)) {
        ensureTargetId(record);
      }
      observe(record);
      for (const [key, attr] of Object.entries(ARIA_RELATION_ATTRS)) {
        if (!Object.prototype.hasOwnProperty.call(snapshot.relations, key)) continue;
        const relation = snapshot.relations[key];
        if (Array.isArray(relation)) continue;
        const value = typeof relation === "string" ? relation : "";
        applyRelationProjection(
          record,
          key,
          attr,
          snapshot.relationModes?.[key] ?? "replace",
          readTokens(value),
          value
        );
      }
    }
    const currentTargetId = nextTarget?.id || null;
    if (!targetChanged && !reactivating && record.reservedId && nextTarget && currentTargetId !== previousTargetId && currentTargetId !== record.reservedId) {
      releaseReservation(record);
      if (currentTargetId && idIsAvailable(nextTarget.ownerDocument, currentTargetId, nextTarget, snapshot.objectRef)) {
        reserveId(record, currentTargetId);
      }
    }
    const bindingChanged = forceStructured || bindingReplaced || identityChanged || currentTargetId !== previousTargetId || previousSnapshot?.viewEpoch !== snapshot.viewEpoch;
    record.lastTargetId = currentTargetId;
    if (structuredChanged) reconcileSource(record);
    const currentIdRefs = record.scalarAttributes.has("id") && nextTarget ? scalarAttributeRefs.get(nextTarget)?.get("id")?.affectedIdRefs : void 0;
    if (bindingChanged || releasedIdRefs || currentIdRefs) {
      const affectedRefs = new Set(releasedIdRefs);
      if (currentIdRefs && currentIdRefs !== releasedIdRefs) {
        for (const ref of currentIdRefs) affectedRefs.add(ref);
      }
      if (previousRef) affectedRefs.add(previousRef);
      affectedRefs.add(snapshot.objectRef);
      reconcileDependents(affectedRefs, structuredChanged ? record : void 0);
    }
  };
  const registry = {
    createProjector(getTarget, subscribeTargetChange) {
      const controlLabelSources = /* @__PURE__ */ new Set();
      const record = {
        getTarget,
        target: null,
        targetDocument: null,
        snapshot: null,
        objectRef: null,
        reservedId: null,
        reservedDocument: null,
        ownedIdTarget: null,
        ownedIdBaseline: null,
        generatedIdLease: null,
        observedDocument: null,
        lastTargetId: null,
        scalarAttributes: /* @__PURE__ */ new Map(),
        dependencyRefs: /* @__PURE__ */ new Set(),
        projections: /* @__PURE__ */ new Map(),
        detached: false,
        disposed: false
      };
      const onTargetChange = () => {
        if (record.snapshot) update(record, record.snapshot);
      };
      let unsubscribe = subscribeTargetChange?.(onTargetChange);
      let needsReplay = false;
      const detach = (removeOwned = false) => {
        if (record.disposed || record.detached) return;
        if (record.snapshot?.viewEpoch !== void 0) {
          reconcileIdentityChange(record, pendingIdWrites);
        }
        const affectedRef = record.objectRef;
        unobserve(record);
        const releasedIdRefs = releaseScalarAttributes(record, removeOwned);
        record.detached = true;
        unsubscribe?.();
        unsubscribe = void 0;
        clearProjections(record);
        removeDependencies(record);
        unindex(record);
        releaseOwnedId(record);
        for (const dispose of [...controlLabelSources]) dispose();
        record.lastTargetId = record.target?.id || null;
        if (affectedRef || releasedIdRefs) {
          const affectedRefs = new Set(releasedIdRefs);
          if (affectedRef) affectedRefs.add(affectedRef);
          reconcileDependents(affectedRefs);
        }
      };
      const projector = (snapshot) => {
        if (record.disposed || record.detached) return;
        const replay = needsReplay;
        needsReplay = false;
        update(record, snapshot, replay, replay);
        if (!unsubscribe) unsubscribe = subscribeTargetChange?.(onTargetChange);
      };
      projector.detach = detach;
      projector.isBound = () => !record.disposed && !record.detached && record.target !== null;
      projector.acquireControlLabelSource = (semanticRef, view) => {
        const owner = record.target;
        const Element = owner?.ownerDocument.defaultView?.HTMLElement;
        if (!Element || !(view.identity instanceof Element)) return null;
        const label = view.identity;
        const current = () => !record.disposed && !record.detached && record.target === owner && record.getTarget() === owner && owner.isConnected && label.isConnected && label.ownerDocument === owner.ownerDocument && label.getRootNode() === view.scope && owner.getRootNode() === view.scope;
        if (!current()) return null;
        const localRecords = () => [...recordsByRef.get(semanticRef) ?? []].filter(
          (candidate) => !candidate.disposed && !candidate.detached && candidate.target?.ownerDocument === owner.ownerDocument
        );
        const candidates = localRecords();
        if (candidates.length) {
          if (candidates.length !== 1 || candidates[0].target !== label || !isA11ySemanticObjectRef(semanticRef))
            return null;
          let active2 = true;
          return {
            objectRef: semanticRef,
            isActive: () => {
              const bindings = localRecords();
              return active2 && current() && bindings.length === 1 && bindings[0].target === label;
            },
            dispose() {
              active2 = false;
            }
          };
        }
        let active = true;
        const objectRef = createA11ySemanticObjectRef();
        const source = registry.createProjector(() => active && current() ? label : null);
        try {
          source({ objectRef, states: {}, actions: {}, relations: {} });
        } catch (error) {
          active = false;
          try {
            source.dispose?.();
          } catch {
          }
          throw error;
        }
        const dispose = () => {
          if (!active) return;
          active = false;
          controlLabelSources.delete(dispose);
          source.dispose?.();
        };
        controlLabelSources.add(dispose);
        return {
          objectRef,
          isActive: () => active && current() && source.isBound?.() === true,
          dispose
        };
      };
      projector.hasAuthoredName = () => {
        const target = record.target;
        if (!target) return true;
        const scalar = scalarAttributeRefs.get(target)?.get("aria-label");
        const currentName = target.getAttribute("aria-label");
        const authoredName = scalar && currentName === scalar.projectedValue ? scalar.baseline : currentName;
        if (authoredName?.trim()) return true;
        const relation = relationOwnerships.get(target)?.get("aria-labelledby");
        const currentRelation = target.getAttribute("aria-labelledby");
        if (relation && currentRelation === relation.projectedValue)
          return relation.baseline.size > 0;
        return !!currentRelation?.trim();
      };
      projector.reactivate = () => {
        if (record.disposed || !record.detached) return;
        record.detached = false;
        needsReplay = true;
      };
      projector.clearHeadingLevel = () => {
        if (record.snapshot && hasProjectedHeadingLevel(record.snapshot)) {
          releaseScalarAttribute(record, "aria-level");
          record.snapshot = { ...record.snapshot, level: void 0 };
        }
      };
      projector.dispose = () => {
        if (record.disposed) return;
        const releasedIdRefs = record.detached ? releaseScalarAttributes(record, true) : void 0;
        if (!record.detached) detach(true);
        record.disposed = true;
        releaseLogicalIdentity(record.objectRef);
        releaseReservation(record);
        record.snapshot = null;
        record.target = null;
        record.targetDocument = null;
        record.lastTargetId = null;
        record.objectRef = null;
        if (releasedIdRefs) reconcileDependents(releasedIdRefs);
      };
      return projector;
    }
  };
  return registry;
}
createWebA11yProjectionRegistry();
function hasProjectedHeadingLevel(snapshot) {
  const level = snapshot.level;
  return snapshot.role === "heading" && typeof level === "number" && Number.isInteger(level) && level >= 1 && level <= 6;
}
function projectedScalarAttributes(snapshot, includeRelations = true) {
  const attrs = /* @__PURE__ */ new Map();
  if (snapshot.id !== void 0) attrs.set("id", snapshot.id || void 0);
  if (snapshot.role !== void 0) attrs.set("role", snapshot.role || void 0);
  if (hasProjectedHeadingLevel(snapshot)) attrs.set("aria-level", String(snapshot.level));
  if (snapshot.name?.kind === "text")
    attrs.set("aria-label", readTextTarget(snapshot.name.value) || void 0);
  if (snapshot.description) {
    attrs.set(
      "aria-description",
      snapshot.description.kind === "text" ? readTextTarget(snapshot.description.value) || void 0 : void 0
    );
  }
  for (const [key, attr] of Object.entries(ARIA_STATE_ATTRS)) {
    if (!Object.prototype.hasOwnProperty.call(snapshot.states, key)) continue;
    if (key === "level" && snapshot.level !== void 0) continue;
    attrs.set(attr, projectedStateAttributeValue(key, snapshot.states[key]));
  }
  if (Object.prototype.hasOwnProperty.call(snapshot.states, "hidden")) {
    attrs.set("aria-hidden", projectedAttributeValue(snapshot.states.hidden));
    attrs.set("hidden", snapshot.states.hidden === true ? "" : void 0);
  }
  if (includeRelations) {
    for (const [key, attr] of Object.entries(ARIA_RELATION_ATTRS)) {
      if (!Object.prototype.hasOwnProperty.call(snapshot.relations, key)) continue;
      const relation = snapshot.relations[key];
      if (!Array.isArray(relation) && snapshot.relationModes?.[key] !== "append") {
        attrs.set(attr, typeof relation === "string" ? relation || void 0 : void 0);
      }
    }
  }
  const actionKeys = Object.keys(snapshot.actions).sort();
  if (actionKeys.length) attrs.set("data-pui-a11y-actions", actionKeys.join(" ") || void 0);
  if (snapshot.tree) {
    if (Object.prototype.hasOwnProperty.call(snapshot.tree, "hidden")) {
      attrs.set("aria-hidden", projectedAttributeValue(snapshot.tree.hidden));
    }
    if (Object.prototype.hasOwnProperty.call(snapshot.tree, "mergeChildren")) {
      attrs.set(
        "data-pui-a11y-merge-children",
        projectedAttributeValue(snapshot.tree.mergeChildren)
      );
    }
  }
  return attrs;
}
function projectedStateAttributeValue(key, value) {
  if (key === "multiSelectable") return typeof value === "boolean" ? String(value) : void 0;
  if (key === "autocomplete")
    return typeof value === "string" && ["none", "inline", "list", "both"].includes(value) ? value : void 0;
  if (key === "sort")
    return typeof value === "string" && ["none", "ascending", "descending", "other"].includes(value) ? value : void 0;
  if (key === "current")
    return typeof value === "boolean" ? String(value) : typeof value === "string" && ["false", "true", "page", "step", "location", "date", "time"].includes(value) ? value : void 0;
  if (key === "valueMin" || key === "valueMax" || key === "valueNow") {
    if (typeof value === "string" && /^-?(?:0|[1-9][0-9]*)(?:[.][0-9]+)?(?:[eE][+-]?[0-9]+)?$/.test(value) && Number.isFinite(Number(value)))
      return value;
    return typeof value === "number" && Number.isFinite(value) ? String(value) : void 0;
  }
  if (key === "valueText") return typeof value === "string" && value !== "" ? value : void 0;
  if (TABLE_COUNT_STATE_KEYS.has(key)) {
    return typeof value === "number" && Number.isSafeInteger(value) && (value === -1 || value > 0) ? String(value) : void 0;
  }
  if (POSITIVE_INTEGER_STATE_KEYS.has(key)) {
    return typeof value === "number" && Number.isSafeInteger(value) && value > 0 ? String(value) : void 0;
  }
  return projectedAttributeValue(value);
}
function projectedAttributeValue(value) {
  if (value === void 0 || value === null || value === "") return void 0;
  return typeof value === "boolean" ? value ? "true" : "false" : String(value);
}
function applySnapshot(el, snapshot, previousSnapshot, attributes, includeRelations = true) {
  for (const [attr, value] of attributes) {
    if (attr !== "id" && el.getAttribute(attr) === (value ?? null)) continue;
    if (value === void 0) el.removeAttribute(attr);
    else el.setAttribute(attr, value);
  }
  if (!attributes.has("aria-level") && previousSnapshot) ;
  if (!includeRelations) return;
  for (const [key, attr] of Object.entries(ARIA_RELATION_ATTRS)) {
    if (Object.prototype.hasOwnProperty.call(snapshot.relations, key) && !Array.isArray(snapshot.relations[key]) && snapshot.relationModes?.[key] === "append") {
      const previousOwned = [];
      setTokenListAttr(el, attr, [
        ...withoutTokens(readTokens(el.getAttribute(attr)), previousOwned),
        ...relationTokens(snapshot, key)
      ]);
    }
  }
}
function relationTokens(snapshot, key) {
  return readTokens(snapshot.relations[key]);
}
function readTokens(value) {
  if (typeof value !== "string") return [];
  return [...new Set(value.trim().split(/\s+/).filter(Boolean))];
}
function withoutTokens(current, removed) {
  const removal = new Set(removed);
  return current.filter((token) => !removal.has(token));
}
function setTokenListAttr(el, attr, tokens) {
  setOptionalAttr(el, attr, [...new Set(tokens)].join(" "));
}
function setOptionalAttr(el, attr, value) {
  if (value === void 0 || value === "") {
    el.removeAttribute(attr);
    return;
  }
  el.setAttribute(attr, value);
}
function readTextTarget(value) {
  if (typeof value === "string") return value;
  if (value && typeof value === "object" && typeof value.get === "function") {
    const next = value.get();
    return typeof next === "string" ? next : void 0;
  }
  return void 0;
}
createAnatomyFamily("base-table", {
  roles: {
    root: { cardinality: { min: 1, max: 1 } },
    caption: { cardinality: { min: 0, max: 1 } },
    row: { cardinality: { min: 1, max: "*" } },
    headerCell: { cardinality: { min: 1, max: "*" } },
    cell: { cardinality: { min: 1, max: "*" } }
  },
  relations: [
    { kind: "contains", parent: "root", child: "caption" },
    { kind: "contains", parent: "root", child: "row" },
    { kind: "contains", parent: "row", child: "headerCell" },
    { kind: "contains", parent: "row", child: "cell" }
  ]
});
const byTarget = /* @__PURE__ */ new WeakMap();
const byPart = /* @__PURE__ */ new WeakMap();
const partAcquisition = /* @__PURE__ */ new WeakMap();
function owns(lease) {
  return lease.active && lease.ownerCurrent() && byPart.get(lease.part) === lease;
}
function put(lease, property, value) {
  if (!owns(lease)) return false;
  const { part, styles } = lease;
  let owned = styles.get(property);
  if (!owned) {
    owned = {
      previous: part.style.getPropertyValue(property),
      priority: part.style.getPropertyPriority(property),
      value: ""
    };
    if (!owns(lease)) return false;
    styles.set(property, owned);
  }
  if (part.style.getPropertyValue(property) === value && part.style.getPropertyPriority(property) === "") {
    if (!owns(lease)) return false;
    owned.value = value;
    return true;
  }
  if (!owns(lease)) return false;
  part.style.setProperty(property, value);
  if (!owns(lease)) return false;
  owned.value = part.style.getPropertyValue(property);
  return owns(lease);
}
function release(lease) {
  if (!lease.active) return;
  lease.active = false;
  lease.footprint = null;
  byTarget.get(lease.target)?.delete(lease);
  if (byPart.get(lease.part) !== lease) return;
  const acquisition = partAcquisition.get(lease.part);
  byPart.delete(lease.part);
  let failed = false;
  let first;
  for (const [property, owned] of lease.styles) {
    if (partAcquisition.get(lease.part) !== acquisition || byPart.has(lease.part)) break;
    try {
      if (lease.part.style.getPropertyValue(property) !== owned.value || lease.part.style.getPropertyPriority(property) !== "")
        continue;
      if (partAcquisition.get(lease.part) !== acquisition || byPart.has(lease.part)) break;
      if (owned.previous) lease.part.style.setProperty(property, owned.previous, owned.priority);
      else lease.part.style.removeProperty(property);
    } catch (error) {
      if (!failed) first = error;
      failed = true;
    }
  }
  lease.styles.clear();
  if (failed) throw first;
}
function connectWebMaterialPaintReservation(target, part, generation, ownerCurrent = () => true, inlineSizeFrom = null, outlineFrom = null) {
  if (target === part || target.ownerDocument !== part.ownerDocument) return () => {
  };
  const acquisition = Object.freeze({});
  partAcquisition.set(part, acquisition);
  const previous = byPart.get(part);
  if (previous) release(previous);
  if (partAcquisition.get(part) !== acquisition || !ownerCurrent()) return () => {
  };
  const lease = {
    target,
    part,
    generation,
    active: true,
    ownerCurrent,
    inlineSizeFrom,
    outlineFrom,
    styles: /* @__PURE__ */ new Map(),
    basis: null,
    footprint: null,
    pendingSize: null
  };
  let targets = byTarget.get(target);
  if (!targets) byTarget.set(target, targets = /* @__PURE__ */ new Set());
  targets.add(lease);
  byPart.set(part, lease);
  try {
    put(lease, "display", "block");
    if (owns(lease)) put(lease, "box-sizing", "content-box");
  } catch (error) {
    try {
      release(lease);
    } catch {
    }
    throw error;
  }
  return () => release(lease);
}
function createWebMaterialPaintReservationRef(target) {
  const bind = prepareMaterialPaintReservationPart(target);
  let current = null;
  let disconnect = null;
  return (part) => {
    if (part === current) return;
    const previous = disconnect;
    disconnect = null;
    current = part;
    previous?.();
    if (!part || current !== part) return;
    const releasePart = bind({
      identity: part,
      connect(physicalTarget, generation, ownerCurrent, inlineSizeFrom, outlineFrom) {
        const win = part.ownerDocument.defaultView;
        if (!win || !(physicalTarget instanceof win.HTMLElement)) return () => {
        };
        if (inlineSizeFrom !== null && !(inlineSizeFrom instanceof win.HTMLElement))
          return () => {
          };
        if (outlineFrom !== null && !(outlineFrom instanceof win.HTMLElement)) return () => {
        };
        return connectWebMaterialPaintReservation(
          physicalTarget,
          part,
          generation,
          ownerCurrent,
          inlineSizeFrom,
          outlineFrom
        );
      }
    });
    if (current === part) disconnect = releasePart;
    else releasePart();
  };
}
export {
  createWebMaterialPaintReservationRef as a,
  connectWebMaterialPaintReservation as c
};
