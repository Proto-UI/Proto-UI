import { g as getWebMaterialPaintReservationLeases, p as put, o as owns } from "./chunk-DFTpkUNa.mjs";
import { c, a } from "./chunk-DFTpkUNa.mjs";
const transparent = (color) => color === "transparent" || /^rgba\([^)]*,\s*0\)$/.test(color) || /\/\s*0(?:%|\.0*)?\s*\)$/.test(color);
const px = (value) => {
  if (value === "" || value === "0") return 0;
  if (!/^\d+(?:\.\d+)?px$/.test(value)) return null;
  const result = Number.parseFloat(value);
  return Number.isFinite(result) ? result : null;
};
function radius(value) {
  if (!value.trim()) return null;
  const terms = value.trim().split(/\s+/);
  if (terms.length > 2) return null;
  const x = px(terms[0] ?? "");
  const y = px(terms[1] ?? terms[0] ?? "");
  return x === null || y === null ? null : { x, y };
}
function readBorderOutline(element) {
  const win = element.ownerDocument.defaultView;
  if (!win) return { status: "unsupported" };
  const css = win.getComputedStyle(element);
  if (css.boxShadow && css.boxShadow !== "none" || css.borderImageSource && css.borderImageSource !== "none" || css.outlineStyle && css.outlineStyle !== "none" && css.outlineStyle !== "hidden" && !transparent(css.outlineColor) && css.outlineWidth !== "0px" || ["transform", "rotate", "scale", "translate"].some((key) => {
    const value = css.getPropertyValue(key);
    return value && value !== "none";
  }))
    return { status: "unsupported" };
  const sides = ["top", "right", "bottom", "left"];
  const widths = sides.map((side) => px(css.getPropertyValue(`border-${side}-width`)));
  const styles = sides.map((side) => css.getPropertyValue(`border-${side}-style`));
  const colors = sides.map((side) => css.getPropertyValue(`border-${side}-color`));
  if (widths.some((width) => width === null)) return { status: "unsupported" };
  const painted = widths.some(
    (width, i) => width > 0 && styles[i] !== "none" && styles[i] !== "hidden" && !transparent(colors[i])
  );
  const base = JSON.stringify({ widths, styles, colors });
  if (!painted) return { status: "clear", signature: base, blockClearance: { top: 0, bottom: 0 } };
  const outer = [
    css.borderTopLeftRadius,
    css.borderTopRightRadius,
    css.borderBottomRightRadius,
    css.borderBottomLeftRadius
  ].map(radius);
  if (outer.some((corner) => corner === null)) return { status: "unsupported" };
  const box = element.getBoundingClientRect();
  if (![box.left, box.top, box.width, box.height].every(Number.isFinite) || box.width <= 0 || box.height <= 0)
    return { status: "unsupported" };
  const [tl, tr, br, bl] = outer;
  const scale = Math.min(
    1,
    ...[
      [box.width, tl.x + tr.x],
      [box.width, bl.x + br.x],
      [box.height, tl.y + bl.y],
      [box.height, tr.y + br.y]
    ].filter(([, sum]) => sum > 0).map(([extent, sum]) => extent / sum)
  );
  const [top, right, bottom, left] = widths;
  const inset = (corner, x, y) => ({
    x: Math.max(0, corner.x * scale - x),
    y: Math.max(0, corner.y * scale - y)
  });
  const corners = {
    tl: inset(tl, left, top),
    tr: inset(tr, right, top),
    br: inset(br, right, bottom),
    bl: inset(bl, left, bottom)
  };
  const dpr = win.devicePixelRatio;
  if (!Number.isFinite(dpr) || dpr <= 0) return { status: "unsupported" };
  const blockClearance = {
    top: Math.max(corners.tl.y, corners.tr.y) + 1 / dpr,
    bottom: Math.max(corners.bl.y, corners.br.y) + 1 / dpr
  };
  const signature = JSON.stringify({ base, corners, dpr, blockClearance });
  return {
    status: "border",
    signature,
    blockClearance,
    border: {
      bounds: {
        left: box.left + left,
        top: box.top + top,
        right: box.right - right,
        bottom: box.bottom - bottom
      },
      corners,
      signature,
      blockClearance
    }
  };
}
function rectangleInsideBorder(rect, border) {
  const b = border.bounds;
  if (![rect.left, rect.top, rect.right, rect.bottom, b.left, b.top, b.right, b.bottom].every(
    Number.isFinite
  ) || rect.right < rect.left || rect.bottom < rect.top || rect.left < b.left || rect.right > b.right || rect.top < b.top || rect.bottom > b.bottom)
    return false;
  const { tl, tr, br, bl } = border.corners;
  const inside = (x, y, corner, cx, cy) => corner.x === 0 || corner.y === 0 || ((x - cx) / corner.x) ** 2 + ((y - cy) / corner.y) ** 2 <= 1;
  return (rect.left >= b.left + tl.x || rect.top >= b.top + tl.y || inside(rect.left, rect.top, tl, b.left + tl.x, b.top + tl.y)) && (rect.right <= b.right - tr.x || rect.top >= b.top + tr.y || inside(rect.right, rect.top, tr, b.right - tr.x, b.top + tr.y)) && (rect.right <= b.right - br.x || rect.bottom <= b.bottom - br.y || inside(rect.right, rect.bottom, br, b.right - br.x, b.bottom - br.y)) && (rect.left >= b.left + bl.x || rect.bottom <= b.bottom - bl.y || inside(rect.left, rect.bottom, bl, b.left + bl.x, b.bottom - bl.y));
}
const unavailable = (reason) => ({
  status: "unavailable",
  reason
});
function composedContains(part, target) {
  let node = target;
  while (node) {
    if (node === part) return true;
    if (node instanceof target.ownerDocument.defaultView.Element && node.assignedSlot)
      node = node.assignedSlot;
    else if (node.parentNode) node = node.parentNode;
    else {
      const root = node.getRootNode();
      node = root instanceof target.ownerDocument.defaultView.ShadowRoot ? root.host : null;
    }
  }
  return false;
}
const near = (a2, b) => Math.abs(a2 - b) <= 0.02;
function current(lease) {
  return owns(lease) && lease.target.isConnected && lease.part.isConnected && lease.target.ownerDocument === lease.part.ownerDocument && composedContains(lease.part, lease.target) && owns(lease) && getWebMaterialPaintReservationLeases(lease.target)?.size === 1;
}
function updateWebMaterialPaintReservation(target, footprint) {
  const leases = getWebMaterialPaintReservationLeases(target);
  if (!leases || leases.size !== 1)
    return unavailable(leases?.size ? "paint-reservation-ambiguous" : "paint-reservation-missing");
  const lease = [...leases][0];
  if (!current(lease)) return unavailable("paint-reservation-owner-unavailable");
  if (!footprint || !Number.isSafeInteger(footprint.view) || footprint.view < 0 || !Number.isSafeInteger(footprint.revision) || footprint.revision < 0 || typeof footprint.profile !== "string" || !footprint.profile || !footprint.edges || ["top", "right", "bottom", "left"].some((edge) => {
    const value = footprint.edges[edge];
    return !Number.isFinite(value) || value < 0 || value > 165;
  }))
    return unavailable("paint-footprint-unavailable");
  if (lease.footprint && (footprint.view < lease.footprint.view || footprint.view === lease.footprint.view && footprint.revision < lease.footprint.revision))
    return unavailable("paint-footprint-stale");
  for (const [property, owned] of lease.styles) {
    if (lease.part.style.getPropertyValue(property) !== owned.value || lease.part.style.getPropertyPriority(property))
      return unavailable("paint-reservation-style-conflict");
  }
  const box = target.getBoundingClientRect();
  const part = lease.part.getBoundingClientRect();
  if (![box.x, box.y, box.width, box.height, part.x, part.y, part.width, part.height].every(
    Number.isFinite
  ) || box.width <= 0 || box.height <= 0)
    return unavailable("paint-reservation-geometry-unavailable");
  const css = target.ownerDocument.defaultView.getComputedStyle(lease.part);
  if (css.display !== "block" || css.boxSizing !== "content-box" || ["transform", "rotate", "scale", "translate"].some(
    (property) => css.getPropertyValue(property) && css.getPropertyValue(property) !== "none"
  ) || ["overflow", "overflow-x", "overflow-y"].some(
    (property) => css.getPropertyValue(property) && css.getPropertyValue(property) !== "visible"
  ))
    return unavailable("paint-reservation-layout-unsupported");
  const footprintEdges = footprint.edges;
  let outlineSignature = null;
  let extraTop = 0, extraBottom = 0;
  if (lease.outlineFrom) {
    const outline = lease.outlineFrom;
    if (!outline.isConnected || outline.ownerDocument !== target.ownerDocument || outline === lease.part || !composedContains(outline, lease.part))
      return unavailable("paint-reservation-outline-unavailable");
    const read = readBorderOutline(outline);
    if (read.status === "unsupported") return unavailable("paint-reservation-outline-unsupported");
    outlineSignature = read.signature;
    extraTop = read.blockClearance.top;
    extraBottom = read.blockClearance.bottom;
    if (![extraTop, extraBottom].every(
      (value) => Number.isFinite(value) && value >= 0 && value <= 165
    ))
      return unavailable("paint-reservation-outline-budget-unavailable");
  }
  const edges = {
    ...footprintEdges,
    top: footprintEdges.top + extraTop,
    bottom: footprintEdges.bottom + extraBottom
  };
  let referenceWidth = null;
  if (lease.inlineSizeFrom) {
    const reference = lease.inlineSizeFrom;
    if (!reference.isConnected || reference.ownerDocument !== target.ownerDocument || composedContains(lease.part, reference) || !composedContains(reference, lease.part))
      return unavailable("paint-reservation-inline-reference-unavailable");
    const referenceCss = target.ownerDocument.defaultView.getComputedStyle(reference);
    const referenceBox = reference.getBoundingClientRect();
    referenceWidth = referenceBox.width - ["padding-left", "padding-right", "border-left-width", "border-right-width"].reduce(
      (sum, property) => sum + (parseFloat(referenceCss.getPropertyValue(property)) || 0),
      0
    );
    if (!Number.isFinite(referenceWidth) || referenceWidth <= 0)
      return unavailable("paint-reservation-inline-reference-unavailable");
  }
  if (!current(lease)) return unavailable("paint-reservation-owner-unavailable");
  if (lease.pendingSize && lease.pendingSize.outlineSignature !== outlineSignature)
    return unavailable("paint-reservation-outline-feedback");
  if (lease.pendingSize && lease.pendingSize.referenceWidth !== referenceWidth)
    return unavailable("paint-reservation-inline-reference-feedback");
  if (lease.pendingSize && (!near(box.width, lease.pendingSize.width) || lease.pendingSize.height !== null && !near(box.height, lease.pendingSize.height)))
    return unavailable("paint-reservation-constraints-unavailable");
  if (!lease.basis) {
    if (!near(part.width, box.width) || !near(part.height, box.height))
      return unavailable("paint-reservation-part-not-exact");
    if (["top", "right", "bottom", "left"].some(
      (edge) => parseFloat(css.getPropertyValue(`padding-${edge}`) || "0") !== 0
    ))
      return unavailable("paint-reservation-consumer-padding");
    lease.basis = {
      width: box.width,
      height: box.height,
      referenceInset: referenceWidth === null ? null : referenceWidth - box.width
    };
  }
  const basisWidth = referenceWidth === null ? lease.basis.width : referenceWidth - lease.basis.referenceInset;
  if (!Number.isFinite(basisWidth) || basisWidth <= 0)
    return unavailable("paint-reservation-inline-reference-unavailable");
  const next = {
    width: `${basisWidth}px`,
    "padding-top": `${edges.top}px`,
    "padding-right": `${edges.right}px`,
    "padding-bottom": `${edges.bottom}px`,
    "padding-left": `${edges.left}px`
  };
  const changed = Object.entries(next).some(
    ([property, value]) => lease.part.style.getPropertyValue(property) !== value
  );
  if (changed) {
    if (!current(lease)) return unavailable("paint-reservation-owner-unavailable");
    lease.pendingSize = {
      width: basisWidth,
      height: near(basisWidth, box.width) ? box.height : null,
      referenceWidth,
      outlineSignature
    };
    for (const [property, value] of Object.entries(next))
      if (!put(lease, property, value)) return unavailable("paint-reservation-owner-unavailable");
    if (!current(lease)) return unavailable("paint-reservation-owner-unavailable");
    lease.footprint = Object.freeze({ ...footprint, edges: Object.freeze({ ...footprintEdges }) });
    return unavailable("paint-reservation-layout-pending");
  }
  if (!near(box.width, basisWidth) || !near(part.width, box.width + edges.left + edges.right) || !near(part.height, box.height + edges.top + edges.bottom) || !near(box.left - part.left, edges.left) || !near(box.top - part.top, edges.top))
    return unavailable("paint-reservation-constraints-unavailable");
  if (lease.outlineFrom) {
    const read = readBorderOutline(lease.outlineFrom);
    if (read.status === "unsupported" || read.signature !== outlineSignature || read.status === "border" && !rectangleInsideBorder(
      {
        left: box.left - footprintEdges.left,
        right: box.right + footprintEdges.right,
        top: box.top - footprintEdges.top,
        bottom: box.bottom + footprintEdges.bottom
      },
      read.border
    ))
      return unavailable("paint-reservation-outline-overlap");
  }
  if (!current(lease)) return unavailable("paint-reservation-owner-unavailable");
  lease.pendingSize = null;
  lease.footprint = Object.freeze({ ...footprint, edges: Object.freeze({ ...footprintEdges }) });
  const admitted = lease.footprint;
  return {
    status: "ready",
    footprint: admitted,
    current() {
      if (!current(lease) || getWebMaterialPaintReservationLeases(target)?.size !== 1) return false;
      const latest = lease.footprint;
      if (!latest || latest.view !== admitted.view || latest.revision < admitted.revision || latest.profile !== admitted.profile || ["top", "right", "bottom", "left"].some(
        (edge) => latest.edges[edge] !== admitted.edges[edge]
      ))
        return false;
      for (const [property, owned] of lease.styles)
        if (lease.part.style.getPropertyValue(property) !== owned.value || lease.part.style.getPropertyPriority(property))
          return false;
      const now = target.getBoundingClientRect();
      const nowPart = lease.part.getBoundingClientRect();
      let sameReference = true;
      if (lease.inlineSizeFrom) {
        const ref = lease.inlineSizeFrom;
        const refBox = ref.getBoundingClientRect();
        const refCss = target.ownerDocument.defaultView.getComputedStyle(ref);
        const width = refBox.width - ["padding-left", "padding-right", "border-left-width", "border-right-width"].reduce(
          (sum, property) => sum + (parseFloat(refCss.getPropertyValue(property)) || 0),
          0
        );
        sameReference = ref.isConnected && ref.ownerDocument === target.ownerDocument && !composedContains(lease.part, ref) && composedContains(ref, lease.part) && width === referenceWidth;
      }
      let sameOutline = true;
      if (lease.outlineFrom) {
        const outline = lease.outlineFrom;
        const read = readBorderOutline(outline);
        sameOutline = outline.isConnected && outline.ownerDocument === target.ownerDocument && composedContains(outline, lease.part) && read.status !== "unsupported" && read.signature === outlineSignature && (read.status !== "border" || rectangleInsideBorder(
          {
            left: now.left - admitted.edges.left,
            right: now.right + admitted.edges.right,
            top: now.top - admitted.edges.top,
            bottom: now.bottom + admitted.edges.bottom
          },
          read.border
        ));
      }
      return near(now.width, box.width) && near(now.height, box.height) && near(nowPart.width, now.width + edges.left + edges.right) && near(nowPart.height, now.height + edges.top + edges.bottom) && near(now.left - nowPart.left, edges.left) && near(now.top - nowPart.top, edges.top) && sameReference && sameOutline && current(lease) && lease.footprint === latest;
    }
  };
}
function releaseWebMaterialPaintFootprint(target, view) {
  for (const lease of getWebMaterialPaintReservationLeases(target) ?? []) {
    if (lease.footprint?.view === view) lease.footprint = null;
  }
}
export {
  c as connectWebMaterialPaintReservation,
  a as createWebMaterialPaintReservationRef,
  releaseWebMaterialPaintFootprint,
  updateWebMaterialPaintReservation
};
