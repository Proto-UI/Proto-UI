# Independent technical review: production graph and material lease split

## Disposition and exact scope

No blocking technical finding was found in the seven-file, two-commit range reviewed here. This is a local source and targeted execution review, not a GitHub review disposition, full-site acceptance, or promotion of the draft material capability.

- Base: `85901dada6420c42f03aac57ba5f8f4c042d70fa`
- Graph repair: `20ef5b2464ca5da4bf938ef05ef4a06c8df695c7`
- Candidate: `88589aded9e0d556f6821b31999eb5fca50e70f8`
- Checkout: `/tmp/pui-40da-compiler`
- Source bindings: `source-binding.json`, SHA-256 for all seven changed files
- Invocation: independently established `human-assisted` / `current-user`; local technical review only

The source hashes remained unchanged throughout the review, the working tree is clean, and `git diff --check` passed. No source, tests, contracts, permissions, or generated files were edited by the reviewer.

## Governing boundaries

`internal/website/self-hosting-coverage-matrix.md` rule 6 retains exact reviewed facade/shared-renderer ownership, the permitted Base/Web Component closure, and lazy React/Vue acquisition. The review checked the finite newly admitted helper paths against that existing boundary; it did not infer a directory-wide Adapter permission.

`C-MATERIAL-PAINT-RESERVATION-0001` and `T-MATERIAL-PAINT-RESERVATION-0001` remain **draft**. Their lease direction requires current-generation ownership, no stale cleanup against successors, invalidation before cleanup, and attempts at every owned cleanup while retaining the first error. Geometry, optical readiness, native input, accessibility, and four-host acceptance remain distinct and unproved by this review.

## What was checked

### Production graph metadata

The new `moduleRenderInfo` validator checks the exact per-chunk map, exact record keys, nonnegative safe-integer lengths, unique string export lists, and disjoint retained/removed exports. Missing evidence conservatively retains the module in emitted checks. Malformed evidence produces a graph failure. Only a valid record with zero rendered length and no retained exports is removed from the relevant emitted-module iteration.

I verified that retained code or exports in a sibling record or dynamic chunk remain visible. A complete zero record does not authorize a different module, a malformed peer, a query-mismatched record, or an adjacent unreviewed Adapter path. Original module IDs and source import edges are retained for provenance checks.

The newly admitted structural owner remains limited to the reviewed bridge placement. The original `material/paint-reservation.ts` geometry source remains forbidden when retained in an ordinary shell. The same is true of neighboring material providers. The three reconciled WC leaves have their existing direct source owners and no runtime imports of their own.

### Shared material lifetime and compatibility

The physical lease state and operations moved into `platform/web-material-paint-reservation.ts`. The lazy geometry module obtains its leases and style operations from that one owner; it no longer contains a separate registry. Public `createWebMaterialPaintReservationRef` and legacy re-exports preserve exact function identity.

The existing suite and independent controls covered same-node replacement, different-target replacement on one part, stale release, revocation, collision, and restoration. An independent cleanup control threw the falsy value `0` during the first style cleanup: the next owned cleanup was still attempted, the first thrown value was retained, and the logical association was already absent. Another control acquired and released a successor during restoration and verified that the older cleanup did not resume against the successor's remaining styles. Neutral structural ownership did not add role, hidden, inert, or tabindex attributes or replace the target node.

### Actual Vite output and executed bundles

Two independent fixtures used the actual Astro-resolved Vite and the exact canonical `websiteBundleGraphPlugin` and `websiteManualChunk` functions from the candidate:

1. Public reservation exports only: two emitted chunks, one retained physical owner, no retained geometry module.
2. The same public exports plus an explicit dynamic geometry import: three chunks, one retained physical owner, and one dynamic geometry chunk outside the static closure.

I wrote these emitted outputs to the evidence directory and imported them in Node. In the second fixture, the dynamically imported legacy geometry module's ref and connect exports were identical to the static entry's exports. A connection installed through the static entry was visible to the lazy geometry updater, and the static disconnect removed that same association. This checks emitted module identity and registry sharing, rather than relying only on source import spelling.

The three unique geometry diagnostic strings were absent from both static closures and present in the actual lazy geometry output. Output hashes, canonical producer hash, complete graphs, and emitted files are retained. This is bounded output evidence, not a general audit of every emitted byte or the full Website.

Both actual canonical graphs were also passed to `collectWebsiteProductionBundleIssues`. Their per-chunk metadata produced zero validation issues. The exact normalized ID `packages/adapters/base/src/material/shader-scene-host.ts` remained recorded with `renderedLength: 0`, `renderedExports: []`, and both shader exports in `removedExports`. `canonical-graph-validation.json` retains these observations and the expected missing Website inventory/owner issues from the standalone fixtures; those partial graphs were not represented as fully accepted Website graphs.

## Independent execution results

Environment: Node `v24.22.3`, Linux x64, Astro-resolved Vite `6.4.1`, TypeScript `5.9.3`, Happy DOM `15.11.7`. Heap limit: 768 MiB.

| Check | Result | Evidence |
| --- | --- | --- |
| Existing production graph suite | 2355 tests passed; zero failed/skipped | `graph-suite.log` |
| Existing material reservation suite | 9 tests passed | `material-suite.log` |
| Independent metadata/placement controls | 17 passed | `boundary-controls.mjs`, `.json`, `.log` |
| Independent source identity/cleanup controls | 5 cases passed | `material-controls.mts`, `.json`, `.log` |
| Actual Vite builds and emitted-bundle identity/registry control | Both scenarios passed | `bundle-controls.mjs`, `.json`, `.log`, `bundle-public-*` directories |
| Actual canonical graph metadata and exact normalized zero record | Both scenarios passed | `canonical-graph-validation.json` |
| Static versus lazy geometry markers in emitted output | Both scenarios passed | `emitted-geometry-controls.json` |
| Exact diff and source binding | Passed; no source drift | `source-binding.json` |

The installed Vitest/esbuild combination emitted the existing `Unrecognized target environment ES2024` warnings. The material suite completed successfully; these warnings were not relabeled as product failures or as TypeScript validation.

## Retained limitations

The zero-render rule is scoped. Existing `runtimeFamilyModulesInClosure` and global `forbiddenModulesByChunk` checks still use all source module IDs for their preexisting demonstration-family/acquisition and orphan-ownership policies. An independent control confirms that a complete zero-render React record can still trigger that global ownership failure. This review does not claim that all zero-render records are universally exempt; no new in-scope bypass was found from this distinction.

No full Astro Website build, full generated-site graph acceptance, native browser geometry/optical run, four-host reservation acceptance, package size gate, or independent strict TypeScript run was performed here. The original implementation's reported checks were read as supporting context and were not counted as the reviewer's own execution. The targeted Vite fixtures do not satisfy the full site's required demonstration inventory.

## Reproduction

Run from `/tmp/pui-40da-compiler`:

```sh
NODE_OPTIONS=--max-old-space-size=768 node --test scripts/coverage-matrices/test/check-website-production-bundle.test.mjs
NODE_OPTIONS=--max-old-space-size=768 node node_modules/vitest/vitest.mjs run packages/adapters/base/test/material-paint-reservation.test.ts --maxWorkers=1 --minWorkers=1
NODE_OPTIONS=--max-old-space-size=768 node /tmp/pui-production-review/boundary-controls.mjs
NODE_OPTIONS=--max-old-space-size=768 node --import tsx /tmp/pui-production-review/material-controls.mts
NODE_OPTIONS=--max-old-space-size=768 node /tmp/pui-production-review/bundle-controls.mjs
```

No external state was written. Exact-head integration and final Website acceptance remain with the parent task.
