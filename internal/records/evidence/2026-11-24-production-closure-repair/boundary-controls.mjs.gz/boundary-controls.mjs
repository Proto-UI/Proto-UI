import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';

const root = '/tmp/pui-40da-compiler';
const require = createRequire(`${root}/package.json`);
const ts = require('typescript');
const { collectWebsiteProductionBundleIssues: collect } = await import(pathToFileURL(`${root}/scripts/coverage-matrices/check-website-production-bundle.mjs`));
const testPath = `${root}/scripts/coverage-matrices/test/check-website-production-bundle.test.mjs`;
const parsed = ts.createSourceFile(testPath, fs.readFileSync(testPath, 'utf8'), ts.ScriptTarget.Latest, true);
const names = new Set(['HOME_DEMO_FACADE', 'PREVIEWER_FACADE', 'PREVIEWER_CLIENT_FACADE', 'STYLE_ISOLATION_FACADE', 'RECONCILED_DEMO_FACADES', 'chunk', 'graphFixture']);
const statements = parsed.statements.filter(node =>
  (ts.isFunctionDeclaration(node) && names.has(node.name?.text)) ||
  (ts.isVariableStatement(node) && node.declarationList.declarations.some(decl => names.has(decl.name.getText(parsed))))
);
const fixture = vm.runInNewContext(`${statements.map(node => node.getText(parsed)).join('\n')}\ngraphFixture;`);
const fresh = () => JSON.parse(JSON.stringify(fixture()));
const zero = () => ({ renderedLength: 0, renderedExports: [], removedExports: [] });
const retained = () => ({ renderedLength: 20, renderedExports: [], removedExports: [] });
const bridge = graph => graph.chunks.find(chunk => chunk.fileName === '_astro/site-shadcn-controls.js');
const shader = 'packages/adapters/base/src/material/shader-scene-host.ts';
const material = 'packages/adapters/base/src/material/paint-reservation.ts';
const owner = 'packages/adapters/base/src/platform/web-material-paint-reservation.ts';
const outcomes = [];
function record(chunk, overrides = {}) {
  chunk.moduleRenderInfo = Object.fromEntries(chunk.moduleIds.map(id => [id, overrides[id] ?? retained()]));
}
function run(name, mutate, predicate) {
  const graph = fresh();
  mutate(graph);
  const issues = collect({ graph });
  assert.ok(predicate(issues), `${name}: ${JSON.stringify(issues)}`);
  outcomes.push({ name, issues });
}
run('baseline has no issues', () => {}, issues => issues.length === 0);
for (const source of [shader, material]) {
  run(`exact removed material record: ${source}`, graph => {
    bridge(graph).moduleIds.push(source);
    record(bridge(graph), { [source]: zero() });
  }, issues => issues.length === 0);
  run(`removed record plus retained dependency: ${source}`, graph => {
    const b = bridge(graph);
    b.moduleIds.push(source, `${source}?retained`);
    record(b, { [source]: zero() });
  }, issues => issues.some(issue => issue.includes(`${source}?retained`)));
  run(`zero length retained export: ${source}`, graph => {
    bridge(graph).moduleIds.push(source);
    record(bridge(graph), { [source]: { ...zero(), renderedExports: ['used'] } });
  }, issues => issues.some(issue => issue.includes(source)));
  run(`dynamic retained sibling cannot borrow zero: ${source}`, graph => {
    const b = bridge(graph);
    b.moduleIds.push(source);
    record(b, { [source]: zero() });
    const sibling = { fileName: '_astro/independent-retained.js', name: 'independent', isEntry: false, isDynamicEntry: true, facadeModuleId: null, imports: [], dynamicImports: [], moduleIds: [source] };
    record(sibling);
    graph.chunks.push(sibling);
    graph.chunks[0].dynamicImports.push(sibling.fileName);
  }, issues => issues.some(issue => issue.includes('dynamically reaches forbidden') && issue.includes(source)));
}
for (const id of [owner, `${owner}?used`]) {
  run(`structural owner in bridge: ${id}`, graph => bridge(graph).moduleIds.push(id), issues => issues.length === 0);
  run(`structural owner outside bridge: ${id}`, graph => graph.chunks[0].moduleIds.push(id), issues => issues.some(issue => issue.includes('statically reaches forbidden') && issue.includes(id)));
}
run('unknown adjacent structural path has no permission', graph => bridge(graph).moduleIds.push(owner.replace('.ts', '-neighbor.ts')), issues => issues.some(issue => issue.includes('-neighbor.ts')));
run('valid zero cannot hide invalid peer metadata', graph => {
  const b = bridge(graph);
  b.moduleIds.push(shader);
  record(b, { [shader]: zero() });
  b.moduleRenderInfo[b.moduleIds[0]].renderedLength = Number.MAX_SAFE_INTEGER + 1;
}, issues => issues.some(issue => issue.includes('invalid moduleRenderInfo')));
run('duplicate exact inventory IDs invalidate complete metadata', graph => {
  const b = bridge(graph);
  b.moduleIds.push(shader, shader);
  record(b, { [shader]: zero() });
}, issues => issues.some(issue => issue.includes('moduleRenderInfo must cover its exact moduleIds')));
run('framework-zero retains the preexisting global ownership gate', graph => {
  const b = bridge(graph);
  const id = 'node_modules/react/jsx-runtime.js';
  b.moduleIds.push(id);
  record(b, { [id]: zero() });
}, issues => issues.some(issue => issue.includes('forbidden framework chunk')));
fs.writeFileSync('/tmp/pui-production-review/boundary-controls.json', JSON.stringify({ sourceHead: '88589aded9e0d556f6821b31999eb5fca50e70f8', tests: outcomes.length, passed: outcomes.length, outcomes }, null, 2) + '\n');
console.log(JSON.stringify({ tests: outcomes.length, passed: outcomes.length }));
