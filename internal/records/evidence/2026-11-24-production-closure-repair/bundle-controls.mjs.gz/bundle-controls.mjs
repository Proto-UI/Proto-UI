import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';

const root = '/tmp/pui-40da-compiler';
const evidence = '/tmp/pui-production-review';
const require = createRequire(`${root}/package.json`);
const ts = require('typescript');
const astroRequire = createRequire(createRequire(`${root}/apps/www/package.json`).resolve('astro'));
const { build } = await import(pathToFileURL(astroRequire.resolve('vite')));
const { Window } = require('happy-dom');
const { createProtoUiSourcePlugin } = await import(pathToFileURL(`${root}/apps/www/src/utils/proto-ui-source.mjs`));
const configPath = `${root}/apps/www/astro.config.mjs`;
const config = ts.createSourceFile(configPath, fs.readFileSync(configPath, 'utf8'), ts.ScriptTarget.Latest, true);
const names = new Set(['normalizedBundleModuleId', 'websiteManualChunk', 'websiteBundleGraphPlugin']);
const functions = config.statements.filter(node => ts.isFunctionDeclaration(node) && names.has(node.name?.text));
assert.equal(functions.length, 3);
const { websiteManualChunk, websiteBundleGraphPlugin } = new Function('path', 'repositoryRoot', `${functions.map(node => node.getText(config)).join('\n')}\nreturn {websiteManualChunk,websiteBundleGraphPlugin};`)(path, root);
const owner = 'packages/adapters/base/src/platform/web-material-paint-reservation.ts';
const geometry = 'packages/adapters/base/src/material/paint-reservation.ts';
const shader = 'packages/adapters/base/src/material/shader-scene-host.ts';
const outcomes = [];
for (const lazy of [false, true]) {
  const mode = lazy ? 'public-with-lazy-geometry' : 'public-only';
  const id = `virtual:independent-reservation-${mode}`;
  const source = `export {createWebMaterialPaintReservationRef as publicRef} from ${JSON.stringify(`${root}/packages/adapters/base/src/index.ts`)};\nexport {connectWebMaterialPaintReservation as connect} from ${JSON.stringify(`${root}/${owner}`)};\n${lazy ? `export const loadGeometry = () => import(${JSON.stringify(`${root}/${geometry}`)});` : ''}`;
  const built = await build({
    root: `${root}/apps/www`, configFile: false, logLevel: 'error', base: './',
    plugins: [
      { name: 'independent-entry', resolveId(value) { if (value === id) return `\0${id}`; }, load(value) { if (value === `\0${id}`) return source; } },
      createProtoUiSourcePlugin({ repositoryRoot: root }), websiteBundleGraphPlugin(),
    ],
    build: { target: 'es2022', minify: false, write: false, emptyOutDir: false, modulePreload: false,
      rollupOptions: { input: id, preserveEntrySignatures: 'strict', output: { manualChunks: websiteManualChunk, entryFileNames: 'entry.mjs', chunkFileNames: 'chunk-[hash].mjs' } },
    },
  });
  const graph = JSON.parse(built.output.find(file => file.type === 'asset' && file.fileName === 'proto-ui-bundle-graph.json').source);
  const chunks = new Map(graph.chunks.map(chunk => [chunk.fileName, chunk]));
  const entry = graph.chunks.find(chunk => chunk.isEntry);
  assert.ok(entry);
  const staticFiles = new Set(), pending = [entry.fileName];
  while (pending.length) { const file = pending.pop(); if (staticFiles.has(file)) continue; staticFiles.add(file); pending.push(...chunks.get(file).imports); }
  const emitted = (chunk, module) => {
    const info = chunk.moduleRenderInfo[module];
    return info && (info.renderedLength > 0 || info.renderedExports.length > 0);
  };
  const ownerChunks = graph.chunks.filter(chunk => emitted(chunk, owner));
  const geometryChunks = graph.chunks.filter(chunk => emitted(chunk, geometry));
  assert.equal(ownerChunks.length, 1);
  assert.ok(staticFiles.has(ownerChunks[0].fileName));
  for (const file of staticFiles) {
    assert.ok(!emitted(chunks.get(file), geometry));
    assert.ok(!emitted(chunks.get(file), shader));
  }
  assert.equal(geometryChunks.length, lazy ? 1 : 0);
  if (lazy) {
    assert.equal(geometryChunks[0].isDynamicEntry, true);
    assert.ok(!staticFiles.has(geometryChunks[0].fileName));
  }
  const outDir = `${evidence}/bundle-${mode}`;
  fs.mkdirSync(outDir, { recursive: true });
  for (const file of built.output) {
    const destination = path.resolve(outDir, file.fileName);
    assert.ok(destination.startsWith(`${outDir}/`));
    fs.mkdirSync(path.dirname(destination), { recursive: true });
    fs.writeFileSync(destination, file.type === 'chunk' ? file.code : file.source);
  }
  const bundle = await import(pathToFileURL(`${outDir}/${entry.fileName}`));
  assert.equal(typeof bundle.publicRef, 'function');
  if (lazy) {
    const material = await bundle.loadGeometry();
    assert.equal(material.createWebMaterialPaintReservationRef, bundle.publicRef);
    assert.equal(material.connectWebMaterialPaintReservation, bundle.connect);
    const window = new Window();
    try {
      const part = window.document.createElement('div');
      const target = window.document.createElement('button');
      part.append(target); window.document.body.append(part);
      const disconnect = bundle.connect(target, part, {});
      assert.equal(material.updateWebMaterialPaintReservation(target, null).reason, 'paint-footprint-unavailable');
      disconnect();
      assert.equal(material.updateWebMaterialPaintReservation(target, null).reason, 'paint-reservation-missing');
    } finally { await window.happyDOM.close(); }
  }
  outcomes.push({ mode, chunks: graph.chunks.length, moduleRecords: graph.modules.length, staticFiles: [...staticFiles], ownerChunks: ownerChunks.map(chunk => chunk.fileName), geometryChunks: geometryChunks.map(chunk => chunk.fileName), outputHashes: Object.fromEntries(built.output.filter(file => file.type === 'chunk').map(file => [file.fileName, createHash('sha256').update(file.code).digest('hex')])), bundledPublicIdentityAndSharedRegistry: lazy ? 'passed' : 'not-applicable', fullSiteAcceptance: false });
}
fs.writeFileSync(`${evidence}/bundle-controls.json`, JSON.stringify({ sourceHead: '88589aded9e0d556f6821b31999eb5fca50e70f8', canonicalProducerSha256: createHash('sha256').update(fs.readFileSync(configPath)).digest('hex'), outcomes }, null, 2) + '\n');
console.log(JSON.stringify(outcomes, null, 2));
