import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createRequire } from 'node:module';
import { createWebMaterialPaintReservationRef as publicRef } from '/tmp/pui-40da-compiler/packages/adapters/base/src/index.ts';
import * as physical from '/tmp/pui-40da-compiler/packages/adapters/base/src/platform/web-material-paint-reservation.ts';
import * as geometry from '/tmp/pui-40da-compiler/packages/adapters/base/src/material/paint-reservation.ts';
const require = createRequire('/tmp/pui-40da-compiler/package.json');
const { Window } = require('happy-dom');
const window = new Window();
const document = window.document;
let cases = 0;
const fixture = () => { const part = document.createElement('div'), target = document.createElement('button'); part.append(target); document.body.append(part); return {part,target}; };
try {
  assert.equal(publicRef, physical.createWebMaterialPaintReservationRef);
  assert.equal(publicRef, geometry.createWebMaterialPaintReservationRef);
  assert.equal(physical.connectWebMaterialPaintReservation, geometry.connectWebMaterialPaintReservation);
  cases++;
  {
    const {part,target} = fixture();
    const nextTarget = document.createElement('button'); part.append(nextTarget);
    const first = physical.connectWebMaterialPaintReservation(target,part,{});
    const next = geometry.connectWebMaterialPaintReservation(nextTarget,part,{});
    first();
    assert.equal(geometry.updateWebMaterialPaintReservation(target,null).reason,'paint-reservation-missing');
    assert.equal(geometry.updateWebMaterialPaintReservation(nextTarget,null).reason,'paint-footprint-unavailable');
    assert.equal(part.style.display,'block'); next();
    assert.equal(part.style.display,''); cases++;
  }
  {
    const {part,target} = fixture();
    const release = physical.connectWebMaterialPaintReservation(target,part,{});
    const remove = part.style.removeProperty.bind(part.style); const attempted:string[]=[];
    part.style.removeProperty = ((property:string) => { attempted.push(property); if(property==='display') throw 0; return remove(property); }) as any;
    let caught = false; try { release(); } catch(error) { caught=true; assert.equal(error,0); }
    assert.equal(caught,true); assert.ok(attempted.includes('box-sizing'));
    assert.equal(part.style.boxSizing,'');
    assert.equal(geometry.updateWebMaterialPaintReservation(target,null).reason,'paint-reservation-missing');
    release(); cases++;
  }
  {
    const {part,target} = fixture();
    part.style.display='inline'; part.style.boxSizing='border-box'; part.style.width='3px';
    const release = geometry.connectWebMaterialPaintReservation(target,part,{});
    const firstLease = [...physical.getWebMaterialPaintReservationLeases(target)!][0];
    assert.equal(physical.writeWebMaterialPaintReservationStyle(firstLease,'width','20px'),true);
    const set = part.style.setProperty.bind(part.style); let reentered=false;
    part.style.setProperty = ((property:string,value:string,priority?:string) => {
      set(property,value,priority);
      if(property==='display' && !reentered) {
        reentered=true;
        const next=physical.connectWebMaterialPaintReservation(target,part,{});
        const lease=[...physical.getWebMaterialPaintReservationLeases(target)!][0];
        assert.equal(physical.writeWebMaterialPaintReservationStyle(lease,'width','80px'),true);
        next();
      }
    }) as any;
    release();
    assert.equal(reentered,true);
    assert.equal(part.style.width,'20px');
    assert.equal(part.style.boxSizing,'content-box');
    assert.equal(geometry.updateWebMaterialPaintReservation(target,null).reason,'paint-reservation-missing');
    cases++;
  }
  {
    const {part,target} = fixture(); let current=true;
    const release=physical.connectWebMaterialPaintReservation(target,part,{},()=>current);
    assert.equal(part.hasAttribute('role'),false); assert.equal(part.hasAttribute('inert'),false); assert.equal(part.hasAttribute('hidden'),false); assert.equal(part.hasAttribute('tabindex'),false);
    assert.equal(target.parentNode,part); current=false;
    assert.equal(geometry.updateWebMaterialPaintReservation(target,null).reason,'paint-reservation-owner-unavailable');
    release(); assert.equal(part.style.display,''); cases++;
  }
  console.log(JSON.stringify({cases,passed:cases}));
  fs.writeFileSync('/tmp/pui-production-review/material-controls.json',JSON.stringify({head:'88589aded9e0d556f6821b31999eb5fca50e70f8',cases,passed:cases,scope:'Source module identity, shared registry, different-target successor, cleanup falsy failure, reentrant acquire-and-release, owner revocation; Happy DOM, no native geometry'},null,2)+'\n');
} finally { await window.happyDOM.close(); }
