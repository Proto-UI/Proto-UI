from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys

ROOT = Path('/workspace/scratch/40da939bdb35/anatomy-recovered')
OUT = Path(__file__).parent
EXPECTED = 'a6f77761a1130dd1170af028d1c9f5ec191d59f8'
ENV = dict(os.environ, NODE_OPTIONS='--max-old-space-size=1536', CI='true')
RECEIPTS = []


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT, text=True).strip()


def stage(name, command, seconds, json_output=False):
    before = git('status', '--porcelain=v1', '--untracked-files=all')
    assert git('rev-parse', 'HEAD') == EXPECTED
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    stdout_path = OUT / ('report.json' if json_output else name + '.log')
    stderr_path = OUT / (name + '.stderr.log')
    timed_out = False
    with stdout_path.open('w') as stdout, stderr_path.open('w') as stderr:
        child = subprocess.Popen(command, cwd=ROOT, env=ENV, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            result = child.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGTERM)
            try:
                result = child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                result = child.wait(timeout=5)
    receipt = {
        'stage': name,
        'sourceRevision': EXPECTED,
        'command': command,
        'startedAt': started,
        'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'exitCode': result,
        'timedOut': timed_out,
        'timeoutSeconds': seconds,
        'stdout': stdout_path.name,
        'stderr': stderr_path.name,
        'trackedAndUntrackedStatusBefore': before,
        'trackedAndUntrackedStatusAfter': git('status', '--porcelain=v1', '--untracked-files=all'),
    }
    RECEIPTS.append(receipt)
    (OUT / 'steps.json').write_text(json.dumps(RECEIPTS, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)
    return result == 0 and not timed_out


assert git('rev-parse', 'HEAD') == EXPECTED
assert not git('status', '--porcelain=v1', '--untracked-files=all')
setup = {
    'sourceRevision': EXPECTED,
    'lockfileSha256': hashlib.sha256((ROOT / 'pnpm-lock.yaml').read_bytes()).hexdigest(),
    'node': subprocess.check_output(['node', '--version'], text=True).strip(),
    'pnpm': subprocess.check_output(['corepack', 'pnpm@10.32.1', '--version'], text=True).strip(),
    'NODE_OPTIONS': ENV['NODE_OPTIONS'],
    'execution': 'Local official workflow-equivalent stages; not a hosted GitHub Actions run.',
    'setupDifference': 'Frozen installation additionally uses --offline and the existing pnpm store. No resolution or ceiling changes.',
}
(OUT / 'environment.json').write_text(json.dumps(setup, indent=2) + '\n')
try:
    if not stage('dependencies', ['corepack', 'pnpm@10.32.1', 'install', '--offline', '--frozen-lockfile', '--store-dir', '/workspace/.pnpm-store'], 480):
        raise RuntimeError('Frozen installation failed; later canonical stages not executed.')
    if not stage('build', ['corepack', 'pnpm@10.32.1', 'build:packages'], 900):
        raise RuntimeError('Complete public package graph build failed; later canonical stages not executed.')
    if not stage('manifests', ['corepack', 'pnpm@10.32.1', 'check:package-manifests'], 300):
        raise RuntimeError('Public manifest controls failed.')
    if not stage('policy-controls', ['corepack', 'pnpm@10.32.1', 'test:package-budget-policy'], 300):
        raise RuntimeError('Measurement controls failed.')
    passed = stage('gate', ['node', 'scripts/analysis/package-budgets.mjs', '--json', '--require-clean', '--expected-sha', EXPECTED], 300, json_output=True)
    report = json.loads((OUT / 'report.json').read_text())
    source = report.get('source', {})
    original_verified = all([
        report.get('exitCode') == 0,
        source.get('head') == EXPECTED,
        source.get('expectedSha') == EXPECTED,
        source.get('requireClean') is True,
        source.get('workingTreeClean') is True,
        source.get('measuredSourceMatchesHead') is True,
        source.get('stableDuringMeasurement') is True,
    ])
    terminal = {
        'sourceRevision': EXPECTED,
        'status': 'passed' if passed and original_verified else 'failed',
        'workflow': '.github/workflows/package-budget-evidence.yml',
        'execution': setup['execution'],
        'originalReportExitCode': report.get('exitCode'),
        'source': source,
        'rows': [{key: row.get(key) for key in ['name', 'gzipBytes', 'budget', 'overBudgetBytes', 'pass']} for row in report.get('results', [])],
        'steps': RECEIPTS,
    }
except Exception as error:
    terminal = {'sourceRevision': EXPECTED, 'status': 'failed', 'error': str(error), 'steps': RECEIPTS, 'execution': setup['execution']}
terminal['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(OUT / 'terminal.json').write_text(json.dumps(terminal, indent=2) + '\n')
print(json.dumps(terminal), flush=True)
sys.exit(0 if terminal['status'] == 'passed' else 1)
