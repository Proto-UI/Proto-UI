// @vitest-environment node
import { describe, expect, it } from 'vitest';
import { parsePrototype } from '../src/parser';
import { validateIR } from '../src/ir-validation';

const source = (hook: string, argument: string, field: string) => `
  import { defineAsHook, definePrototype } from '@proto.ui/core';
  const asProbe = defineAsHook({ name: 'presence-probe', ${hook} });
  export default definePrototype({ name: 'presence-owner', setup(def) {
    const flag = def.state.bool('flag', false);
    const facade = asProbe(${argument});
    const copied = facade.${field};
    if (!copied) def.expose.method('late', () => flag.setDefault(true));
  } });
`;

describe('copied capture members retain their actual presence', () => {
  it.each(['getState', 'getMethod', 'getAsHook', 'getAsHookHandle', 'methods', 'artifacts'])(
    'checks the real empty-capture absence branch for %s',
    (field) => {
      // The native finish_capture protocol omits all of these fields when empty.
      // A fabricated truthy getter/record would hide this reachable illegal call.
      expect(parsePrototype(source('setup() {}', '', field))).toMatchObject({
        ok: false,
        diagnostics: [{ code: 'PUI1007', message: expect.stringContaining('state.setDefault') }],
      });
    }
  );

  it('keeps conditional absence after a method-map join', () => {
    expect(parsePrototype(source(
      "setup(def, present: boolean) { if (present) def.expose.method('read', () => 7); }",
      'flag.get()',
      'getMethod'
    ))).toMatchObject({
      ok: false,
      diagnostics: [{ code: 'PUI1007', message: expect.stringContaining('state.setDefault') }],
    });
  });

  it('does not visit a dead absence branch for a proven nonempty capture', () => {
    const parsed = parsePrototype(source(
      "setup(def) { def.expose.method('read', () => 7); }",
      '',
      'getMethod'
    ));
    expect(parsed.ok, JSON.stringify(parsed.ok ? null : parsed.diagnostics)).toBe(true);
    if (parsed.ok)
      expect(validateIR(JSON.parse(JSON.stringify(parsed.value)))).toMatchObject({ ok: true });
  });
});
