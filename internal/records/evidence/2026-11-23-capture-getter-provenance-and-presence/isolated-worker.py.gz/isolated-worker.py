#!/usr/bin/env python3
from pathlib import Path
import os, sys, json, hashlib, subprocess, time, datetime, fcntl, tempfile, shutil, traceback
ROOT=Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a')
OPS=Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a-ops/capture-getter-provenance')
TREE=Path('/tank/shared/projects/proto-ui-agent/sprint3-callable-75d5e28a')
BASE='db747e1b81cbbfaf2b37dd8af3de48108f036a04'
NODE=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin')
COREPACK='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/corepack-cache'
BASE_HASH='ff32f98da35b7181d2724001b8b1279d1c31853ee23d4057f669bd4953f64475'
CANDIDATE_HASH='dd70756fea96046f0edccf8b868f9ecf21f5f1678bf4d97306f3a98278f24f9c'
IR_HASH='b8ef32a38d694348ffc221dff7df643110795d4918ada24f4060cc856731e535'
FILES=[
 'packages/compiler/test/capture-facade.test.ts',
 'packages/compiler/test/value-ir.test.ts',
 'packages/compiler/test/capture-lookup-integrity.test.ts',
 'packages/compiler/test/authored-hook-language.test.ts',
 'packages/compiler/test/mutable-callable-orders.test.ts',
 'packages/compiler/test/module-helper-capture-boundary.test.ts',
 'packages/compiler/test/privileged-capture-metadata.test.ts',
]
status={'state':'starting','pid':os.getpid(),'base':BASE,'tree':str(TREE),'commands':[],'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'testsChanged':False,'rootLiveChanged':False,'cargoInvoked':False}
def save():
 (OPS/'isolated-status.json').write_text(json.dumps(status,indent=2)+'\n')
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def command(argv,name,cwd=ROOT,timeout=600):
 status['phase']=name;save()
 begin=time.monotonic()
 with (OPS/(name+'.log')).open('w') as output:
  completed=subprocess.run(argv,cwd=cwd,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=timeout)
 row={'name':name,'command':argv,'cwd':str(cwd),'exitCode':completed.returncode,'elapsedSeconds':round(time.monotonic()-begin,3)}
 status['commands'].append(row);save()
 return completed.returncode
def vector(path):
 data=json.loads(path.read_text())
 return {Path(file['name']).name+'::'+test['fullName']:{'status':test['status'],'failureMessages':test.get('failureMessages',[])} for file in data['testResults'] for test in file.get('assertionResults',[])}
lock=(OPS/'isolated.lock').open('w')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
env=os.environ.copy()
env['PATH']=str(NODE)+os.pathsep+env.get('PATH','')
env['COREPACK_HOME']=COREPACK
tmp=Path(tempfile.mkdtemp(prefix='cg75-',dir='/var/tmp'))
env['TMPDIR']=str(tmp)
status['tmpdir']=str(tmp);save()
try:
 if TREE.exists(): raise RuntimeError('Own isolated tree already exists; refusing overwrite or duplicate worker')
 assert sha(OPS/'before-callable-effects.ts')==BASE_HASH
 assert sha(OPS/'r2-callable-effects.ts')==CANDIDATE_HASH
 assert command(['git','worktree','add','--detach',str(TREE),BASE],'create-worktree',timeout=600)==0
 own=TREE/'packages/compiler/src/callable-effects.ts'
 ir=TREE/'packages/compiler/src/ir-validation.ts'
 assert sha(own)==BASE_HASH,('baseline callable source drift',sha(own))
 source=ir.read_text()
 before='const source = objectFields(value);'
 after='const source = checkedSpreadFields(value, captureFields);'
 assert source.count(before)==1,('IR alignment anchor',source.count(before))
 ir.write_text(source.replace(before,after,1))
 assert sha(ir)==IR_HASH,('IR alignment not equal to reviewed one-line source',sha(ir))
 modules=TREE/'node_modules'
 assert not modules.exists() and not modules.is_symlink()
 modules.symlink_to(ROOT/'node_modules',target_is_directory=True)
 source_inputs=FILES+['packages/compiler/src/callable-effects.ts','packages/compiler/src/parser.ts','packages/compiler/src/capture-types.ts','packages/compiler/src/capture-analysis.ts','packages/compiler/src/operations.ts','packages/compiler/src/ir.ts','packages/compiler/src/ir-validation.ts','packages/compiler/src/value-types.ts']
 status['beforeSources']={name:sha(TREE/name) for name in source_inputs};save()
 for label in ['before','after']:
  if label=='after':
   own.write_bytes((OPS/'r2-callable-effects.ts').read_bytes())
   assert sha(own)==CANDIDATE_HASH
  report=OPS/('isolated-'+label+'.json')
  cmd=['corepack','pnpm@10.32.1','exec','vitest','run','--maxWorkers=1','--minWorkers=1','--reporter=json','--outputFile='+str(report)]+FILES
  command(cmd,'isolated-'+label,cwd=TREE,timeout=300)
  assert report.exists(),('missing actual report',label)
  data=json.loads(report.read_text())
  status[label]={'passed':data['numPassedTests'],'failed':data['numFailedTests'],'pending':data.get('numPendingTests'),'report':str(report),'reportSha256':sha(report)}
  status[label+'Sources']={name:sha(TREE/name) for name in source_inputs};save()
 old=vector(OPS/'isolated-before.json');new=vector(OPS/'isolated-after.json')
 assert set(old)==set(new),'test inventory changed'
 delta={'before':status['before'],'after':status['after'],'inventoryStable':True,
  'recovered':[name for name in old if old[name]['status']=='failed' and new[name]['status']=='passed'],
  'regressed':[name for name in old if old[name]['status']=='passed' and new[name]['status']!='passed'],
  'remainingFailures':[{'test':name,**new[name]} for name in new if new[name]['status']=='failed']}
 (OPS/'isolated-differential.json').write_text(json.dumps(delta,indent=2)+'\n')
 for name in source_inputs:
  if name!='packages/compiler/src/callable-effects.ts':
   assert status['beforeSources'][name]==status['afterSources'][name],('source drift',name)
 assert status['beforeSources']['packages/compiler/src/callable-effects.ts']==BASE_HASH
 assert status['afterSources']['packages/compiler/src/callable-effects.ts']==CANDIDATE_HASH
 diff=subprocess.run(['git','diff','--binary'],cwd=TREE,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
 (OPS/'isolated-actual.patch').write_text(diff.stdout)
 status['actualPatchSha256']=sha(OPS/'isolated-actual.patch')
 status['sourceStable']=True
 status['state']='completed' if status['after']['failed']==0 and not delta['regressed'] else 'candidate-failed'
except Exception as error:
 status['state']='worker-error';status['error']=repr(error);status['traceback']=traceback.format_exc()
finally:
 status['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 status['tmpRemoved']=False
 if tmp.exists():
  shutil.rmtree(tmp);status['tmpRemoved']=True
 save()
