from pathlib import Path
import os,sys,json,hashlib,subprocess,datetime,tempfile,shutil,fcntl
p=Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a-ops/capture-getter-provenance')
tree=Path('/tank/shared/projects/proto-ui-agent/sprint3-callable-75d5e28a')
source=tree/'packages/compiler/src/callable-effects.ts'
test=tree/'packages/compiler/test/capture-getter-presence.test.ts'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
lock=(p/'presence-r2b.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
status={'state':'running','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'sourceBefore':sha(source),'testSha256':sha(test),'scope':'new 8 actual absence/phase controls; original 98 source and reports unchanged'}
(p/'presence-r2b-status.json').write_text(json.dumps(status,indent=2)+'\n')
assert status['sourceBefore']=='dd70756fea96046f0edccf8b868f9ecf21f5f1678bf4d97306f3a98278f24f9c'
env=os.environ.copy();env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env.get('PATH','');env['COREPACK_HOME']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/corepack-cache'
tmp=Path(tempfile.mkdtemp(prefix='cgp75-',dir='/var/tmp'));env['TMPDIR']=str(tmp)
try:
 cmd=['corepack','pnpm@10.32.1','exec','vitest','run','--maxWorkers=1','--minWorkers=1','--reporter=json','--outputFile='+str(p/'presence-r2b.json'),'packages/compiler/test/capture-getter-presence.test.ts']
 status['command']=cmd
 with (p/'presence-r2b.log').open('w') as log: result=subprocess.run(cmd,cwd=tree,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 status['exitCode']=result.returncode;status['sourceAfter']=sha(source);status['testAfter']=sha(test)
 if (p/'presence-r2b.json').exists():
  report=json.loads((p/'presence-r2b.json').read_text());status['passed']=report['numPassedTests'];status['failed']=report['numFailedTests'];status['pending']=report.get('numPendingTests')
 status['state']='completed'
except Exception as error:
 status['state']='error';status['error']=repr(error)
finally:
 shutil.rmtree(tmp);status['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(p/'presence-r2b-status.json').write_text(json.dumps(status,indent=2)+'\n')
