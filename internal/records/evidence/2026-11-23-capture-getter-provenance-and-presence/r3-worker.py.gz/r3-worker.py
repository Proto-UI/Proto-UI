from pathlib import Path
import os,json,hashlib,subprocess,datetime,tempfile,shutil,fcntl,difflib
p=Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a-ops/capture-getter-provenance')
tree=Path('/tank/shared/projects/proto-ui-agent/sprint3-callable-75d5e28a')
source=tree/'packages/compiler/src/callable-effects.ts'
candidate=p/'r3-callable-effects.ts'
test=tree/'packages/compiler/test/capture-getter-presence.test.ts'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
lock=(p/'r3-worker.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
status={'state':'preparing','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'sourceBefore':sha(source),'testBefore':sha(test),'scope':'own detached db747 tree only, inherited one-line IR b8ef; no root live/Cargo/generated changes'}
def save(): (p/'r3-verified-status.json').write_text(json.dumps(status,indent=2)+'\n')
save()
env=os.environ.copy()
env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env.get('PATH','')
env['COREPACK_HOME']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/corepack-cache'
tmp=Path(tempfile.mkdtemp(prefix='cgp75-',dir='/var/tmp'));env['TMPDIR']=str(tmp)
def run(name,command,timeout):
 status['phase']=name;status['command']=command;save()
 with (p/(name+'.log')).open('w') as log:
  result=subprocess.run(command,cwd=tree,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 status[name]={'exitCode':result.returncode}
 if (p/(name+'.json')).exists():
  r=json.loads((p/(name+'.json')).read_text())
  status[name].update(passed=r.get('numPassedTests'),failed=r.get('numFailedTests'),pending=r.get('numPendingTests'),todo=r.get('numTodoTests'))
 save()
 if result.returncode: raise RuntimeError(name+' failed')
try:
 assert status['sourceBefore']=='dd70756fea96046f0edccf8b868f9ecf21f5f1678bf4d97306f3a98278f24f9c'
 assert status['testBefore']=='8aab4ca2bdaa64cf5f7dd7d83e4a0f448e5d8d8bc25ff341c8cc02ecfa471d60'
 assert sha(candidate)=='9cfdb4dc226d652ba688cc6ccd3b0493e614d2254907ab0221c0ae22524a43f8'
 source.write_bytes(candidate.read_bytes())
 run('r3-format',['corepack','pnpm@10.32.1','exec','prettier','--write','packages/compiler/src/callable-effects.ts'],120)
 (p/'r3-formatted-callable-effects.ts').write_bytes(source.read_bytes())
 status['testedSourceSha256']=sha(source);status['state']='testing';save()
 tests=['capture-facade.test.ts','value-ir.test.ts','capture-lookup-integrity.test.ts','authored-hook-language.test.ts','mutable-callable-orders.test.ts','module-helper-capture-boundary.test.ts','privileged-capture-metadata.test.ts']
 status['originalTestsBefore']={t:sha(tree/'packages/compiler/test'/t) for t in tests};save()
 for name,files in [('r3-presence',['capture-getter-presence.test.ts']),('r3-original98',tests)]:
  run(name,['corepack','pnpm@10.32.1','exec','vitest','run','--maxWorkers=1','--minWorkers=1','--reporter=json','--outputFile='+str(p/(name+'.json'))]+['packages/compiler/test/'+t for t in files],240)
 status['originalTestsAfter']={t:sha(tree/'packages/compiler/test'/t) for t in tests}
 assert status['originalTestsAfter']==status['originalTestsBefore']
 assert sha(source)==status['testedSourceSha256']
 assert sha(test)==status['testBefore']
 raw=subprocess.run(['git','diff','--','packages/compiler/src/callable-effects.ts'],cwd=tree,capture_output=True,text=True,check=True).stdout
 (p/'r3-tested-candidate.patch').write_text(raw)
 status['actualPatchSha256']=sha(p/'r3-tested-candidate.patch')
 status['state']='completed'
except Exception as error:
 status['state']='failed';status['error']=repr(error)
finally:
 status['sourceAfter']=sha(source);status['testAfter']=sha(test);status['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 shutil.rmtree(tmp);save()
