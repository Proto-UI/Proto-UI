# Root source review: callable capture getter provenance r4c

Observed at 2026-11-23 20:05 UTC. Scope: source review, not a GitHub approval or an independent execution claim.

## Exact reviewed inputs

- Complete final source-and-tests patch: 2a2bbd9f6471c7ed6ab94200bca2ba5c0e70578a2c6773c4962ab3ca4f9a1bbe (32343 bytes), read in full by root.
- Formatted callable-effects.ts: 3608dbdd18ce3748cbebb67d83cf1fd113639f5f323f7a6e18f27060e367f7ca (70818 bytes).
- Formatted capture-getter-presence.test.ts: 401ba3ab0ace392f82388c8bcee02f512d691906ff24d09071024cee2b6c56de (3971 bytes).
- Formatted capture-host-presence.test.ts: e549d60efb5e428642194d6974959cc3b05365277e2bf7735b4dab1712df5c23 (2366 bytes).
- All three final file hashes above independently read back with omp_hash by root. The existing IR spread validation one-line change is outside this three-file patch.

## Findings

No remaining source blocker found in this scoped review.

1. Bound capture getters originate from an actual reached capture and share direct-operation lookup and phase validation. Field spelling, callable signatures, serialized lookup metadata, and pending or privileged placeholders do not create native callable authority. Returned methods and children retain the actual capture graph and outward callback execution checks.
2. Capture member presence is derived from executed state/event/method/child contributions. Presence survives store copying, joins, delta application and fingerprints; a nonempty map of conditional members is not treated as proof of a present member.
3. Own-key absence is separate from an own undefined value. Property reads turn absence into undefined, while repeated object spread retains the preceding callable on absent branches and overwrites it on an own undefined branch. Optional host records preserve value, undefined and absence alternatives; required host fields still prove overwrite.
4. The pre-contribution exception edge and the original post-operation edge are both preserved. State and unresolved capture lookups retain exception paths.
5. The new cases assert the relevant PUI1007 state.setDefault/state.bool phase diagnosis, rather than accepting any parse rejection. Direct truth branches avoid the preexisting conservative unary-! path. Positive cases also validate JSON-roundtripped IR. Empty and conditional capture members, repeated spread, own undefined, optional host absence and required overwrite all have distinct controls.
6. The unsuccessful Object.assign/static-void fixture attempts are not represented as regression evidence. Their original admission failures remain in the work record; the final host controls use admitted object-spread syntax.

## Execution boundary

Root read the r4c runner receipt showing the same final 15 fixtures at r3: 14 passed / 1 failed (optional host absent key wrongly accepted), then r4c: 15 passed / 0 failed. The original seven-file regression run reports 98 passed / 0 failed. Both final runs report zero pending or todo. Workspace type checking was still running at review time; its final outcome must be recorded separately. The final S5 integration must retain the two independently added official Input capture-facade cases and validate the merged source. Prior r2b unsafe counterexamples and earlier fixture setup failures must remain intact.

