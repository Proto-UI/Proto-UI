from pathlib import Path
import os,json,hashlib,subprocess,datetime,tempfile,shutil,fcntl,difflib
p=Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a-ops/capture-getter-provenance')
tree=Path('/tank/shared/projects/proto-ui-agent/sprint3-callable-75d5e28a')
source=tree/'packages/compiler/src/callable-effects.ts';candidate=p/'r4-callable-effects.ts'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
lock=(p/'r4b-worker.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
status={'state':'preparing','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'sourceBefore':sha(source),'scope':'same own db747 detached tree; native/root/S5 live remain untouched'}
def save(): (p/'r4b-verified-status.json').write_text(json.dumps(status,indent=2)+'\n')
save()
env=os.environ.copy();env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env.get('PATH','')
env['COREPACK_HOME']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/corepack-cache'
tmp=Path(tempfile.mkdtemp(prefix='cgp75-',dir='/var/tmp'));env['TMPDIR']=str(tmp)
def run(name,command,timeout,allow_failure=False):
 status['phase']=name;status['command']=command;save()
 started=datetime.datetime.now(datetime.timezone.utc)
 with (p/(name+'.log')).open('w') as log:
  result=subprocess.run(command,cwd=tree,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 status[name]={'exitCode':result.returncode,'elapsedSeconds':(datetime.datetime.now(datetime.timezone.utc)-started).total_seconds()}
 if (p/(name+'.json')).exists():
  r=json.loads((p/(name+'.json')).read_text())
  status[name].update(passed=r.get('numPassedTests'),failed=r.get('numFailedTests'),pending=r.get('numPendingTests'),todo=r.get('numTodoTests'))
 save()
 if result.returncode and not allow_failure: raise RuntimeError(name+' failed')
 return result.returncode
def vitest(name,files,allow_failure=False):
 return run(name,['corepack','pnpm@10.32.1','exec','vitest','run','--maxWorkers=1','--minWorkers=1','--reporter=json','--outputFile='+str(p/(name+'.json'))]+['packages/compiler/test/'+t for t in files],240,allow_failure)
try:
 assert json.loads((p/'r3-verified-status.json').read_text())['state']=='completed'
 assert status['sourceBefore']=='8c68dd542b7e583640f605fec7f4112ba55b7fc3316cacef79d5de737bced404'
 assert sha(candidate)=='e3281a1c24a3162325bff989ce6e6ed3946eecac353f7ef0a506de94c4b6cc44'
 assert sha(tree/'packages/compiler/test/capture-getter-presence.test.ts')=='e7b14ab9a60ada988dc4fd8300d5eccaf910d21b919d0390d7064bb071c2e749'
 assert sha(tree/'packages/compiler/test/capture-host-presence.test.ts')=='8085e0988ecc35691805c29385d05945c93e67eb5398783202213e9ed60f28a9'
 testfiles=['capture-getter-presence.test.ts','capture-host-presence.test.ts']
 for artifact,target in [('presence-test-r4b.ts',testfiles[0]),('host-test-r4b.ts',testfiles[1])]:
  (tree/'packages/compiler/test'/target).write_bytes((p/artifact).read_bytes())
 run('r4b-format-tests',['corepack','pnpm@10.32.1','exec','prettier','--write']+['packages/compiler/test/'+t for t in testfiles],120)
 status['testsBefore']={t:sha(tree/'packages/compiler/test'/t) for t in testfiles}
 for t in testfiles:(p/('r4b-formatted-'+t)).write_bytes((tree/'packages/compiler/test'/t).read_bytes())
 status['state']='counterfactual';save()
 code=vitest('r4b-before',testfiles,True)
 report=json.loads((p/'r4b-before.json').read_text())
 failures=[t for suite in report['testResults'] for t in suite['assertionResults'] if t['status']=='failed']
 status['counterfactualFailures']=[{'title':t['title'],'message':t['failureMessages'][0]} for t in failures];save()
 assert code==1 and report['numPassedTests']==14 and report['numFailedTests']==1 and report['numPendingTests']==0, 'unexpected counterfactual: inspect raw diagnostics before applying'
 assert failures[0]['title']=='retains the preceding authored callable when an optional host key is absent'
 assert 'ok: true' in failures[0]['failureMessages'][0], 'counterfactual was not an incorrect accepted input'
 assert sha(source)==status['sourceBefore']
 source.write_bytes(candidate.read_bytes())
 run('r4b-format-source',['corepack','pnpm@10.32.1','exec','prettier','--write','packages/compiler/src/callable-effects.ts'],120)
 (p/'r4b-formatted-callable-effects.ts').write_bytes(source.read_bytes())
 status['testedSourceSha256']=sha(source);status['state']='testing';save()
 original=['capture-facade.test.ts','value-ir.test.ts','capture-lookup-integrity.test.ts','authored-hook-language.test.ts','mutable-callable-orders.test.ts','module-helper-capture-boundary.test.ts','privileged-capture-metadata.test.ts']
 status['originalTestsBefore']={t:sha(tree/'packages/compiler/test'/t) for t in original};save()
 vitest('r4b-presence15',testfiles)
 vitest('r4b-original98',original)
 run('r4b-workspace-types',['corepack','pnpm@10.32.1','exec','tsc','-p','tsconfig.workspace.json','--noEmit','--pretty','false'],240)
 status['originalTestsAfter']={t:sha(tree/'packages/compiler/test'/t) for t in original}
 status['testsAfter']={t:sha(tree/'packages/compiler/test'/t) for t in testfiles}
 assert status['originalTestsBefore']==status['originalTestsAfter'] and status['testsBefore']==status['testsAfter']
 assert sha(source)==status['testedSourceSha256']
 raw=subprocess.run(['git','diff','--','packages/compiler/src/callable-effects.ts'],cwd=tree,capture_output=True,text=True,check=True).stdout
 for t in testfiles:
  target='packages/compiler/test/'+t
  raw+='diff --git a/'+target+' b/'+target+'\nnew file mode 100644\n'+''.join(difflib.unified_diff([], (tree/target).read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+target))
 (p/'r4b-tested-candidate.patch').write_text(raw)
 status['actualPatchSha256']=sha(p/'r4b-tested-candidate.patch')
 status['state']='completed'
except Exception as error:
 status['state']='failed';status['error']=repr(error)
finally:
 status['sourceAfter']=sha(source);status['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 shutil.rmtree(tmp);save()
