import ts from 'typescript';
import type { HookSourceSummaryContext } from './hook-source-summary.js';

/** A deliberately closed first slice: private same-file function declarations,
 * used only by direct calls in source-proven Core setup functions. The call
 * arguments are not proved here; the scanner captures them when each call is
 * visited. Export, escape, reassignment, spread, recursion and unknown callers
 * keep the original independent declaration scan. */
export function closedLocalRuleHelpers(
  source: ts.SourceFile,
  summary: HookSourceSummaryContext
): ReadonlySet<ts.FunctionDeclaration> {
  const candidates: ts.FunctionDeclaration[] = [];
  let dynamicScope = false;
  const unwrap = (node: ts.Node): ts.Node =>
    ts.isParenthesizedExpression(node) ||
    ts.isAsExpression(node) ||
    ts.isTypeAssertionExpression(node) ||
    ts.isNonNullExpression(node) ||
    ts.isSatisfiesExpression(node)
      ? unwrap(node.expression)
      : node;
  const containsRule = (node: ts.Node): boolean => {
    if (ts.isTypeNode(node)) return false;
    if (ts.isCallExpression(node)) {
      const target = unwrap(node.expression);
      if (
        (ts.isPropertyAccessExpression(target) && target.name.text === 'rule') ||
        (ts.isElementAccessExpression(target) &&
          ts.isStringLiteralLike(target.argumentExpression) &&
          target.argumentExpression.text === 'rule')
      )
        return true;
    }
    return ts.forEachChild(node, (child) => containsRule(child) || undefined) === true;
  };
  const collect = (node: ts.Node): void => {
    if (ts.isTypeNode(node)) return;
    if (
      ts.isWithStatement(node) ||
      (ts.isCallExpression(node) &&
        ts.isIdentifier(unwrap(node.expression)) &&
        (unwrap(node.expression) as ts.Identifier).text === 'eval')
    )
      dynamicScope = true;
    if (
      ts.isFunctionDeclaration(node) &&
      node.name &&
      node.body &&
      containsRule(node.body) &&
      !node.asteriskToken &&
      !node.modifiers?.some((modifier) =>
        [
          ts.SyntaxKind.ExportKeyword,
          ts.SyntaxKind.DefaultKeyword,
          ts.SyntaxKind.AsyncKeyword,
        ].includes(modifier.kind)
      ) &&
      node.parameters.every(
        (parameter) =>
          ts.isIdentifier(parameter.name) && !parameter.initializer && !parameter.dotDotDotToken
      ) &&
      summary.resolveSourceFunction(node.name, source) === node &&
      !summary.isAuthoredSetup(node, source)
    )
      candidates.push(node);
    ts.forEachChild(node, collect);
  };
  collect(source);
  if (dynamicScope) return new Set();

  const result = new Set<ts.FunctionDeclaration>();
  for (const candidate of candidates) {
    let calls = 0;
    let closed = true;
    const inspect = (node: ts.Node): void => {
      if (!closed || ts.isTypeNode(node)) return;
      if (ts.isIdentifier(node) && node.text === candidate.name!.text && node !== candidate.name) {
        const parent = node.parent;
        // Property labels do not read the identifier's lexical binding.
        if (
          (ts.isPropertyAccessExpression(parent) && parent.name === node) ||
          (ts.isPropertyAssignment(parent) && parent.name === node) ||
          (ts.isMethodDeclaration(parent) && parent.name === node)
        )
          return;
        if (summary.resolveSourceFunction(node, source) === candidate) {
          let reference: ts.Node = node;
          while (reference.parent && unwrap(reference.parent) === node)
            reference = reference.parent;
          const call = reference.parent;
          const owner = ts.findAncestor(node, ts.isFunctionLike);
          if (
            !call ||
            !ts.isCallExpression(call) ||
            call.expression !== reference ||
            call.arguments.some(ts.isSpreadElement) ||
            call.arguments.length !== candidate.parameters.length ||
            call.getStart(source) <= candidate.end ||
            !owner ||
            !summary.isAuthoredSetup(owner, source)
          ) {
            closed = false;
            return;
          }
          calls++;
        }
      }
      ts.forEachChild(node, inspect);
    };
    inspect(source);
    if (closed && calls > 0) result.add(candidate);
  }
  return result;
}
