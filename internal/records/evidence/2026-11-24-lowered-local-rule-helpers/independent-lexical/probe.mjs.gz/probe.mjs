// Run from the checkout: node --import tsx --input-type=module < ../closed-helper-review/probe.mjs
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import ts from 'typescript';
import { scanRuleStateReads } from './packages/cli/src/services/lowered-hook-coverage.ts';
import { closedLocalRuleHelpers } from './packages/cli/src/services/closed-rule-helpers.ts';
import { createHookSourceSummaryContext } from './packages/cli/src/services/hook-source-summary.ts';

const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'closed-helper-independent-'));
const producer = `import { defineAsHook } from '@proto.ui/core';
export const source = defineAsHook({ name: 'source', setup(def) { def.state.bool('actual', false); }, projectHandle: captured => ({ ready: captured.stateHandles.actual }) });`;
await fs.writeFile(path.join(directory, 'producer.ts'), producer);
const helper = `function paint(def, facts) { def.rule({ when: w => w.state(facts.ready).eq(true), intent: i => i.feedback.style.use(tw('bg-primary')) }); }`;
const call = 'paint(def, source());';
const cases = [
  { name: 'ordinary private direct call', tail: '', expectedClosed: true, expectedStates: ['actual'], expectedUnresolved: 0 },
  { name: 'shorthand escape', tail: 'opaque({ paint });', expectedClosed: false, expectedStates: [], expectedUnresolved: 1 },
  { name: 'computed key escape', tail: 'opaque({ [paint]: 1 });', expectedClosed: false, expectedStates: [], expectedUnresolved: 1 },
  { name: 'nested deferred return escape', tail: 'opaque(() => paint);', expectedClosed: false, expectedStates: [], expectedUnresolved: 1 },
  { name: 'default export identity escape', tail: 'export { paint as default };', expectedClosed: false, expectedStates: [], expectedUnresolved: 1 },
  { name: 'destructuring reassignment', tail: '({ replacement: paint } = opaque);', expectedClosed: false, expectedStates: [], expectedUnresolved: 1 },
  { name: 'array reassignment', tail: '[paint] = opaque;', expectedClosed: false, expectedStates: [], expectedUnresolved: 1 },
  { name: 'outer-call inside ordinary nested callback', setup: 'opaque(() => paint(def, source()));', expectedClosed: false, expectedStates: [], expectedUnresolved: 1 },
  { name: 'same-name object label is not escape', tail: 'opaque({ paint: 1 });', expectedClosed: true, expectedStates: ['actual'], expectedUnresolved: 0 },
  { name: 'same-name shadow function is separate', tail: 'function separate(paint) { opaque(paint); }', expectedClosed: true, expectedStates: ['actual'], expectedUnresolved: 0 },
  { name: 'same-name shadow variable is separate', tail: '{ const paint = opaque; consume(paint); }', expectedClosed: true, expectedStates: ['actual'], expectedUnresolved: 0 },
  { name: 'Core factory shadow keeps raw helper', setup: call, prefix: 'function assemble(definePrototype) {', suffix: '}', expectedClosed: false, expectedStates: [], expectedUnresolved: 1 },
  { name: 'parameter shadow does not borrow outer Context-like bag', setup: 'const facts = source(); { const facts = unknownContext; paint(def, facts); }', expectedClosed: true, expectedStates: [], expectedUnresolved: 1 },
  { name: 'helper local shadow does not borrow parameter bag', helper: helper.replace('def.rule(', '{ const facts = unknownContext; def.rule(').replace('; }', '; } }'), expectedClosed: true, expectedStates: [], expectedUnresolved: 1 },
];
const outcomes=[];
try {
 for (const test of cases) {
   const text = `import { definePrototype, tw } from '@proto.ui/core';\nimport { source } from './producer';\n${test.helper ?? helper}\n${test.prefix ?? ''}\nconst prototype = definePrototype({ name: 'consumer', setup(def) { ${test.setup ?? call} } });\n${test.suffix ?? ''}\n${test.tail ?? ''}`;
   const file=path.join(directory,test.name.replaceAll(/[^a-zA-Z0-9]+/g,'-')+'.proto.ts');
   await fs.writeFile(file,text);
   const ast=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true);
   const context=createHookSourceSummaryContext(); context.registerSource(ast);
   const closed=[...closedLocalRuleHelpers(ast,context)].map(fn=>fn.name.text);
   const scan=scanRuleStateReads(text,file);
   const states=scan.usages.map(x=>x.state);
   const success=closed.includes('paint')===test.expectedClosed && JSON.stringify(states)===JSON.stringify(test.expectedStates) && scan.unresolved.length===test.expectedUnresolved;
   outcomes.push({name:test.name,success,closed,states,unresolved:scan.unresolved,expected:{closed:test.expectedClosed,states:test.expectedStates,unresolved:test.expectedUnresolved},source:text});
 }
 console.log(JSON.stringify({cases:outcomes.length,passed:outcomes.filter(x=>x.success).length,outcomes},null,2));
 if(outcomes.some(x=>!x.success)) process.exitCode=1;
} finally { await fs.rm(directory,{recursive:true,force:true}); }
