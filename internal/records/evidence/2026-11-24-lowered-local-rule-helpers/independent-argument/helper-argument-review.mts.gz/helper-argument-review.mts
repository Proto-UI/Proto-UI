import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { scanRuleStateReads } from '/workspace/scratch/62ffef219b8e/proto-ui-sprint1/packages/cli/src/services/lowered-hook-coverage.ts';
const producer=`import { defineAsHook } from '@proto.ui/core';
export const asA=defineAsHook({name:'a',setup(d){d.state.bool('alpha',false);},projectHandle:r=>({ready:r.stateHandles.alpha})});
export const asB=defineAsHook({name:'b',setup(d){d.state.bool('beta',false);},projectHandle:r=>({ready:r.stateHandles.beta})});
export const asC=defineAsHook({name:'c',setup(d){d.state.bool('gamma',false);},projectHandle:r=>({ready:r.stateHandles.gamma})});`;
const cases=[
 ['own assignment','let facts=asA(); paint(def,(facts=asB()));','facts.ready',false,['beta']],
 ['own comma rebind','let facts=asA(); paint(def,(facts=asB(), facts));','facts.ready',false,['beta']],
 ['captured scalar survives later write','const facts=asA(); paint(def,facts.ready,Object.assign(facts,asB()));','facts',true,['alpha']],
 ['own comma scalar read after write','const facts=asA(); paint(def,(Object.assign(facts,asB()),facts.ready));','facts',false,['beta']],
 ['captured literal copy survives later write','const facts=asA(); paint(def,{ready:facts.ready},Object.assign(facts,asB()));','facts.ready',true,['alpha']],
 ['captured spread copy survives later write','const facts=asA(); paint(def,{...facts},Object.assign(facts,asB()));','facts.ready',true,['alpha']],
 ['own Object.assign result','const facts=asA(); paint(def,Object.assign(facts,asB()));','facts.ready',false,['beta']],
 ['opaque mutation of captured container','const facts=asA(); paint(def,facts,mutate(facts));','facts.ready',true,[]],
 ['conditional partial unknown','paint(def, flag ? asA() : opaque);','facts.ready',false,['alpha']],
 ['own conditional rebind scalar','let facts=asA(); paint(def,(facts=asB()) ? facts.ready : facts.ready);','facts',false,['beta']],
 ['own logical rebind scalar','let facts=asA(); paint(def,(facts=asB()) && facts.ready);','facts',false,['beta']],
];
const dir=await mkdtemp(path.join(tmpdir(),'helper-arg-review-'));
try {
 await writeFile(path.join(dir,'producer.ts'),producer);
 const out=[];
 for(const [name,setup,read,third,expect] of cases){
  const text=`import {definePrototype,tw} from '@proto.ui/core'; import {asA,asB,asC} from './producer';
function paint(def,facts${third?',ignored':''}){def.rule({when:w=>w.state(${read}).eq(true),intent:i=>i.feedback.style.use(tw('bg-primary'))});}
export default definePrototype({name:'consumer',setup(def){${setup}}});
const independent=definePrototype({name:'independent',setup(def){const ready=asC().ready;def.rule({when:w=>w.state(ready).eq(true),intent:i=>i.feedback.style.use(tw('underline'))});}});`;
  const file=path.join(dir,'consumer.proto.ts');await writeFile(file,text);
  const scan=scanRuleStateReads(text,file);
  out.push({name,setup,read,expected:expect,states:scan.usages.map(x=>x.state),unresolved:scan.unresolved});
 }
 console.log(JSON.stringify(out,null,2));
}finally{await rm(dir,{recursive:true,force:true});}
