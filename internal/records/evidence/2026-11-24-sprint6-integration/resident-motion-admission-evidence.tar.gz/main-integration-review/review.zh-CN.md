# main 0fbb 与 Sprint 6 84ef：固定对象只读整合建议

## 建议

**保留 `84ef7893e732a316388aeb730af1758b96f703e8` 的普通 merge 历史，再整合冻结的 main `0fbb52ef832cc27c78e24c28c59a55a16f51d7fe`。** 84ef 已包含旧 main 0adde，不需要重做这次合并或重复 cherry-pick 它的上游提交。0fbb 仅比 0adde 多出一个 CLI 修复和其 merge commit；这 4 个文件与 84ef 自 0adde 的增量没有路径交叠，固定 Git blob 三方比较未发现新增内容冲突。实际本地未提交修改仍由 root 在自己的工作树保留、审查与合入。

本任务只读 Git 对象、GitHub primary compare 和已有原报告，没有执行 checkout、merge、测试、测量、fetch、device control 或 GitHub mutation。下面的通过结果都是所读原证据的范围，不是新的全套验收。

## 0adde → 0fbb 的真实改动

GitHub primary compare 和本地对象一致：ahead 2 / behind 0。

- `2f5b87a8a8f9f188b33d2b0ca63918543b495713`：`fix(cli): keep the members a partly observed hook projection proved`。
- `0fbb52ef832cc27c78e24c28c59a55a16f51d7fe`：merge PR #1751；第一 parent 为 0adde，第二 parent 为 2f5b。

只有四个路径：

| 路径 | 改动与边界 |
|---|---|
| `packages/cli/src/services/hook-source-summary.ts` | 不再整份丢弃带 uncertainKeys 的 hook projection；保留已经来源证明的 member。没有观测到的 member 继续 unknown，成员集合继续 uncertain。 |
| `packages/cli/src/generated/brutalist-style-tokens.ts` | 仅新增 `data-[focus-visible]:ring-black`，恢复真实 Input projection 里的黑色焦点 ring。 |
| `packages/cli/test/hook-source-projection-accessors.test.ts` | 覆盖作者自定义 state handle、部分可观察 projection、getter/setter 等未证明成员仍 unknown；不以同名 built-in state 表代替真实作者声明。 |
| `packages/cli/test/brutalist-reference-tokens.test.ts` | 要求 token、生成 selector 和 `--pui-ring-color: #000000;` 同时出现。 |

源码进一步核实 `sourceMembersProven()` 对 uncertainKeys 仍返回 false；`memberValue()` 未找到字段仍返回 `UNKNOWN(missing member ...)`；未知 spread 仍使可能被覆盖的字段失效。因此此次是静态来源分析的精度修复，不是将完整性假设、运行权限或外部操作权限放宽。保留上游原修复即可，本任务不需要替原型改 Compiler/IR。

0adde 与 0fbb 的 `.github`、`.agents`、`apps`、`scripts`、`spec`、`internal`、core/runtime/modules/adapters/prototypes/compiler 子树 SHA 完全一致；25 个另行读取的关键路径字节 SHA256 也一致，其中包括 lockfile、package manifest、budget script/policy/evidence workflow、frame workflow/probes、fixture、harness、material browser assertions、handoff schema、skills registry 和 contributor rules。治理语义与授权来源没有新增变化。

## 24e → 84ef 的作者、合并与证据

84ef 的 Git author / committer 字段均为 `cyjin-yl`，author / commit 时间为 `2026-11-24T03:56:13+08:00`；正文有对应 Signed-off-by。这里只记录真实 Git metadata，不将作者字段当作独立身份认证、DCO 门禁或平台许可。

其 parents 精确为：

1. `24e553961e7a898b74b959792d35f49364f35efc`。
2. `0adde15d1e5dacb112cdad4d8d7811e015cc4456`。

以真实共同祖先 457d27f7 做逐路径比较：

| 三方类别 | 路径数 | 84ef 中结果 |
|---|---:|---|
| 仅 S6 改动 | 87 | 87 个原 S6 blob 全部保留 |
| 仅 main 改动 | 265 | 265 个原 main blob 全部保留 |
| 两侧都改但结果相同 | 13 | 保留相同结果 |
| 两侧实际不同 | 1 | HC-CONTROL-LABEL 使用 main 完整文件 |
| merge 新增文件 | 3 | integration record、manifest、source-validation archive |

没有其他源码合成、意外覆盖或新增产品改动。main 对历史 JSON/证据的既有格式变化按 main 原 blob 继承，不能把这些差异当作此 merge 新执行的测试。

唯一冲突 `spec/host-caps/HC-CONTROL-LABEL-0001.yaml` 在 84ef 的 blob 与 main 完全相同，保留 `HC-CONTROL-LABEL-0001-GPUI` 和 `HC-CONTROL-LABEL-0001-GPUI-PROVIDER` 两个不同 criterion ID 及原段落。最终 SHA256 为 `c893ca5d8ff4944e3140ad2e1e4171f48effdacde8ea76fa88fd5337f2fa6dad`。

### 新归档的核验

`source-validation.tar.gz` 实际 25,783 B，SHA256 `b922737c9e94823850707a9c35cada22c13b702ea024bd3ddf7ceaca67ef9fbb`，与 manifest 一致；4 个原成员大小及 SHA256 均匹配。`source.json` 与 `source.log` 一致记录 **11 文件、99/99、0 failed、0 pending**，99 个 assertion 全部 passed。范围是 SVG primitives / owned-template 和指定 spec schema/graph。

来源绑定不止依赖正文：`merge-inputs.json` 的 266 个三方路径收据与真实 parents / 84ef blob 逐个吻合。将 84ef 的 3 个新增 evidence carrier 在内存 Git tree 模型中剔除，重算 tree SHA 恰为其声明的已解析产品 index tree：`6775db17d8770bd607d33ef0d27687ec06d96080`。完整 84ef tree 为 `7c33f1f9205afa86230d3621bc6550fb242ba5de`。

TypeScript exit 0 有作者 manifest / record 声明，但原 `type-contracts.log` 是 0 bytes，归档未包含独立进程 exit receipt。应写“作者归档记录 exit 0”，不要写成此审查重新执行并独立验证了退出码。manifest 明确 `fullWorkspaceNativePackageAcceptance: pending`；99 个源测试不是最终组合的全部浏览器、native 或包体接受。

## 帧输入、成本与权限交叠

root 的原“9 项帧输入”清单尚未送达，本报告没有自造九项清单或把扩展核对集合冒充原清单。更宽的实际证据是：0adde→0fbb 的全部改动都在 4 个 CLI 路径，frame workflow、完整 scripts 子树、apps 子树、material adapter 子树、lockfile 均未变化；`audit.json` 已列上述 25 个关键路径在 457 / 0adde / 0fbb / 24e / 84ef 五个固定版本的 blob 和 SHA256。正式最终 source admission 仍应使用原固定清单，并读取实际候选 source / environment。

读取旧 canonical 包体原报告 457 / 34cb 的全部九入口 closure 后，这四个改动文件在 **18 个历史 entry closure 中都不存在**，这些 closure 也都没有 `packages/cli/` 输入。可以据此判断 0adde→0fbb 不带来已知直接入口 source 增长；这不是新的字节测量，也不是最终组合成本通过。84ef 首次引入 main 的 owned SVG validator 优化，它会影响 core 及上层入口成本；最终报告必须绑定最终整合 SHA，不能用 34cb 数值预选 cap，不能把孤立 gzip 增减相加。

0fbb 没有改预算、measurement shape、external boundary、lock、manifest、skills、handoff schema、授权或权限策略。因此无需凭这次上游推进增加产品接受或人工确认步骤；原 current-user / human-assisted envelope、实际权限、独立 review、DCO、exact-head CI 和原预算事务证据要求仍保持原样。静态代码中的 setup capability / projection proof 不等于 GitHub mutation authority。

## 可操作整合次序

1. 在 root 自己的隔离工作树保留当前未提交 S6 修复；以 84ef 为原分支已提交事实，避免重复完成 24e + 0adde 合并。
2. 普通合并冻结的 0fbb，保留两个作者/提交来源。与 84ef 的 merge-base 为 0adde，新增 CLI 四路径没有双侧改动；实际执行时仍检查工作树冲突和已存修复。
3. 保留上游生成 token，不手改生成文件来消除差异。实际组合可在既有 validation 中纳入 `hook-source-projection-accessors.test.ts`、`brutalist-reference-tokens.test.ts` 及相关 preset freshness；本次没有运行这些测试。
4. source/control 修改定稿后再冻结最终 SHA/tree。把 root 的源修复、所需 Bootstrap/Modal/Select 原断言、完整 canonical package 和适用 clean-source frame 证据绑定这个版本；不要用 84ef 的 selected99 或 24e 的 frame success 替代。
5. 若最终成本需要有界数字事务，使用已准备的真实 schema 五项输入 handoff，补入最终 candidate/report/terminal/source，继续 pui-validate→pui-package-budget；此报告不提出 cap 或新通过结论。

## 可直接沿用的 24e 历史帧记录

> 历史 clean-source run 45249737653 / job 137955881999 / artifact 14856263012 对照 baseline 457d27f7 与 candidate 24e5539。13,660,661 B ZIP 的 SHA256 为 7d2aee46c18ad47e8929ca6c9efc40e3cb9869d37c4218e6db9a95b74aacc987，API digest / size / 244-member CRC 核验一致。两侧各 static60 + dynamic60 均完整解决，输入归属、光学状态和清理断言通过。static listener p95 12.105→6.305 ms，candidate 58 次 exact-image reuse、2 次 decode；dynamic 没有 reuse，p95 24.215→20.030 ms，p99 44.369→46.825 ms、max44.9→48.3 ms，>40ms 均2/60。candidate 所有 fresh-press 区间和12窗口 readback allocation 增量为0。1MiB / 2idle image cache 与4MiB readPixels backing 分别核对。所选浏览器5pass/1诊断skip，release11场景cleanup归零；job success不表示动态10ms达标。该证据早于main0adde整合，不能重标成84ef或最终组合的验收。旧25dd→831的16.375→48.110ms回归与原红继续保留。

详细原分析：`/workspace/scratch/0246b139defb/liquid-frame-24e5539-45249737653/analysis/review.zh-CN.md`；审计 JSON SHA256 为 `e7ba908f191cf2c24b35df2b3c7f6acb7f8af6bb39b4b3cac74bb33c20da5a75`。

## 新 main 四文件内容哈希

| 路径 | 0fbb 内容 SHA256 |
|---|---|
| generated/brutalist-style-tokens.ts | `47e2b395e769b328d58e48779815ecd6d7557a9f0656439fde4b920fb7c4eeaa` |
| services/hook-source-summary.ts | `3943d9af060dcc72133bfd50fe4b583b2ba82605c637e16d0ea32aeb1b9a6130` |
| test/brutalist-reference-tokens.test.ts | `319b27a19dafff84100a1063a9e969687faaa73865bf7eee20d487f3177c4f72` |
| test/hook-source-projection-accessors.test.ts | `3a758d31a644b4afab0c5c5519886779adaddbb40ac0bf1964156bf38f6bae66` |

完整路径、前后 blob / SHA256、critical path hashes、两份 GitHub compare、三方路径分类、archive 核对和旧原报告 closure 列表见 `audit.json` 与 `manifest.json`。
