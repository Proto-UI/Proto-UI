import { afterEach, describe, expect, it, vi } from 'vitest';
import { createWebResidentMotionSink } from "/tank/shared/projects/proto-ui-agent/sprint6-0246/repo/packages/adapters/base/src/motion/web-resident-motion.ts";
import { createRootStyleEffect, resolveRootStyleEntry } from '@proto.ui/core/internal';
import type { StyleHandle } from '@proto.ui/core';
import { renderProtoStyleTokenCss } from "/tank/shared/projects/proto-ui-agent/sprint6-0246/repo/packages/cli/src/services/proto-style-css.ts";

const cleanups: (() => void)[] = [];
afterEach(() => {
  for (const off of cleanups.splice(0)) off();
  vi.restoreAllMocks();
  document.body.replaceChildren();
});
function fixture(scope: 'document' | 'shadow' = 'document') {
  const parent = document.createElement('div');
  parent.style.display = 'block';
  const el = document.createElement('div');
  el.style.display = 'block';
  el.style.cssFloat = 'left';
  if (scope === 'shadow') {
    const bridge = document.createElement('div');
    bridge.style.display = 'contents';
    bridge.attachShadow({ mode: 'open' }).append(el);
    parent.append(bridge);
  } else parent.append(el);
  document.body.append(parent);
  const sheet = document.createElement('style');
  // Finite CSSOM host evidence. Percentage ownership is tested in the module,
  // runtime contract and real Progress browser suite, not Happy DOM layout.
  sheet.textContent = renderProtoStyleTokenCss(
    [0, 80, 100, 200, 300, 400, 600].map((value) => `w-[${value}px]`)
  )
    .replace(/@layer proto-ui \{\n([\s\S]*)\n\}\n$/, '$1')
    .replace(
      /(\[data-pui-style~=")([^"]+)("\])/g,
      (_match, prefix: string, token: string, suffix: string) =>
        prefix + token.replace(/[\[\]]/g, '\\$&') + suffix
    );
  const tree = el.getRootNode();
  (tree instanceof ShadowRoot ? tree : document.head).append(sheet);
  cleanups.push(() => sheet.remove());
  vi.spyOn(window.CSS, 'supports').mockReturnValue(true);
  let now = 0,
    revision = 0,
    next = 0;
  vi.spyOn(window.performance, 'now').mockImplementation(() => now);
  let reduced = false;
  const preferenceListeners = new Set<() => void>();
  vi.spyOn(window, 'matchMedia').mockImplementation(((query: string) => ({
    get matches() {
      return query.includes(': reduce') ? reduced : !reduced;
    },
    media: query,
    addEventListener: (_key: string, listener: () => void) => preferenceListeners.add(listener),
    removeEventListener: (_key: string, listener: () => void) =>
      preferenceListeners.delete(listener),
  })) as any);
  let resize = (() => {}) as ResizeObserverCallback;
  const observed = new Set<Element>();
  const old = window.ResizeObserver;
  window.ResizeObserver = class {
    constructor(callback: ResizeObserverCallback) {
      resize = callback;
    }
    observe(target: Element) {
      observed.add(target);
    }
    unobserve(target: Element) {
      observed.delete(target);
    }
    disconnect() {
      observed.clear();
    }
  } as typeof ResizeObserver;
  cleanups.push(() => {
    window.ResizeObserver = old;
  });
  const frames = new Map<number, FrameRequestCallback>();
  vi.spyOn(window, 'requestAnimationFrame').mockImplementation((callback) => {
    frames.set(++next, callback);
    return next;
  });
  vi.spyOn(window, 'cancelAnimationFrame').mockImplementation((id) => {
    frames.delete(id);
  });
  let pending: StyleHandle | undefined;
  const queueStyle = vi.fn((style: StyleHandle) => {
    pending = style;
  });
  const sink = createWebResidentMotionSink(el, {
    queueStyle,
    requestFlush() {
      if (pending) el.setAttribute('data-pui-style', pending.tokens.join(' '));
    },
  });
  cleanups.push(() => sink.release(1));
  const commit = (widthPx: number, tokens = [`w-[${widthPx}px]`]) => {
    sink.commit({
      view: 1,
      revision: ++revision,
      style: createRootStyleEffect(tokens.map((token) => resolveRootStyleEntry(token, 'rule'))),
      declarations: [{ properties: ['width'], durationMs: 100, easing: [0, 0, 1, 1] }],
    });
  };
  const frame = (time: number) => {
    now = time;
    for (const [id, callback] of [...frames]) {
      frames.delete(id);
      callback(time);
    }
  };
  const measure = (target: Element, width: number) => {
    resize(
      [
        {
          target,
          contentBoxSize: [{ inlineSize: width, blockSize: 20 }],
          borderBoxSize: [{ inlineSize: width, blockSize: 20 }],
          contentRect: { width, height: 20 },
        },
      ] as any,
      {} as any
    );
  };
  return {
    el,
    parent,
    sink,
    frames,
    queueStyle,
    commit,
    frame,
    measure,
    observed,
    reduce() {
      reduced = true;
      preferenceListeners.forEach((listener) => listener());
    },
  };
}

describe('independent stale Web width-frame rejection', () => {
  it('retains a width animation after a stale frame with the same declarations', () => {
    const h = fixture();
    h.commit(100); h.measure(h.parent, 400); h.frame(0); h.commit(300);
    expect(h.el.style.width).toBe('100px');
    h.sink.commit({ view: 1, revision: 1,
      style: createRootStyleEffect([resolveRootStyleEntry('w-[100px]', 'rule')]),
      declarations: [{properties: ['width'], durationMs:100, easing:[0,0,1,1]}] });
    h.frame(50);
    expect(h.el.style.width).toBe('200px');
    expect(h.frames.size).toBe(1);
  });
  it('does not let a rejected older view change the current width capability', () => {
    const h = fixture();
    h.commit(100); h.measure(h.parent, 400); h.frame(0); h.commit(300);
    expect(h.el.style.width).toBe('100px');
    h.sink.commit({ view: 0, revision: 1,
      style: createRootStyleEffect([resolveRootStyleEntry('w-[100px]', 'rule')]),
      declarations: [{properties: ['translate'], durationMs:100, easing:[0,0,1,1]}] });
    h.frame(50);
    expect(h.el.style.width).toBe('200px');
    expect(h.frames.size).toBe(1);
  });
});
