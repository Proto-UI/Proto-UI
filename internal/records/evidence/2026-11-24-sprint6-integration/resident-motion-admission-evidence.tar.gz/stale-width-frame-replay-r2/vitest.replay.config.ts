import base from '/tank/shared/projects/proto-ui-agent/sprint6-0246/repo/vitest.config.ts';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';

const repository = fs.realpathSync('/tank/shared/projects/proto-ui-agent/sprint6-0246/repo');
const evidence = '/tank/shared/projects/proto-ui-agent/sprint6-0246/evidence/stale-width-frame-replay-r2';
const sources = new Map<string, { sha256: string; bytes: number; ids: string[] }>();
const changed: string[] = [];
const errors: string[] = [];
const foreignProjectSources = new Set<string>();
const save = (finalized: boolean) => {
  fs.writeFileSync(path.join(evidence, `module-bindings-${process.pid}.json`), JSON.stringify({
    scope: 'Observed Vite transforms; no resolution override or code transformation',
    pid: process.pid, finalized, sources: Object.fromEntries(sources), changed, errors,
    foreignProjectSources: [...foreignProjectSources],
  }, null, 2) + '\n');
};
process.once('exit', () => save(true));

export default {
  ...base,
  plugins: [...(base.plugins ?? []), {
    name: 'stale-width-actual-source-observer',
    enforce: 'post' as const,
    transform(_code: string, id: string) {
      let filename = id.split('?')[0];
      if (filename.startsWith('/@fs/')) filename = filename.slice(4);
      if (!path.isAbsolute(filename) || !fs.existsSync(filename)) return null;
      try {
        const physical = fs.realpathSync(filename);
        if (physical.startsWith('/workspace/scratch/') || physical.startsWith('/dev/shm/'))
          foreignProjectSources.add(physical);
        if (!physical.startsWith(repository + path.sep) || physical.includes('/node_modules/'))
          return null;
        const bytes = fs.readFileSync(physical);
        const relative = path.relative(repository, physical);
        const sha256 = createHash('sha256').update(bytes).digest('hex');
        const previous = sources.get(relative);
        if (previous && previous.sha256 !== sha256) changed.push(relative);
        sources.set(relative, { sha256, bytes: bytes.length, ids: [...new Set([...(previous?.ids ?? []), id])] });
      } catch (error) {
        errors.push(`${id}: ${String(error)}`);
      }
      return null;
    },
    closeBundle() { save(false); },
  }],
  test: {
    ...base.test,
    include: [path.join(evidence, 'stale-width-frame.review.test.ts')],
    maxWorkers: 1,
    minWorkers: 1,
    fileParallelism: false,
    cache: false,
  },
};
