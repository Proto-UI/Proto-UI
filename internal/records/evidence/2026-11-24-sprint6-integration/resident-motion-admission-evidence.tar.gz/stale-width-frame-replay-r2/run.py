from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time, traceback

w = Path('/tank/shared/projects/proto-ui-agent/sprint6-0246')
r = w / 'repo'
e = w / 'evidence/stale-width-frame-replay-r2'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(data): return hashlib.sha256(data).hexdigest()
def save(name, value): (e / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def receipt(file): return {'path': str(file), 'bytes': file.stat().st_size, 'sha256': sha(file.read_bytes())}

fd = os.open(e / 'invocation.lock', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, 'w') as lock:
    json.dump({'pid': os.getpid(), 'claimedAt': now(), 'argv': sys.argv, 'runner': receipt(Path(__file__))}, lock, indent=2)
    lock.write('\n')
    lock.flush()
    os.fsync(lock.fileno())
assert not (e / 'run.json').exists(), 'Refusing to overwrite an existing run'
env = os.environ.copy()
env['PATH'] = str(w / 'toolchain/node_modules/node-linux-x64/bin') + ':' + str(w / 'toolchain/node_modules/.bin') + ':' + env.get('PATH', '')
env['TMPDIR'] = str(w / 'tmp')
env['COREPACK_HOME'] = str(w / 'corepack-cache')
env['GIT_OPTIONAL_LOCKS'] = '0'

def git(*args, allowed=(0,)):
    result = subprocess.run(['git', *args], cwd=r, env=env, capture_output=True)
    if result.returncode not in allowed:
        raise RuntimeError({'git': args, 'exitCode': result.returncode, 'stderr': result.stderr.decode(errors='replace')})
    return result

PRIMARY = [
    'packages/adapters/base/src/motion/web-resident-motion.ts',
    'packages/modules/feedback/src/motion/projector.ts',
    'packages/cli/src/services/proto-style-css.ts',
    'vitest.config.ts',
    'pnpm-lock.yaml',
]
def snapshot(observed=False):
    started = now()
    names = set(PRIMARY)
    if observed:
        for file in e.glob('module-bindings-*.json'):
            names.update(json.loads(file.read_text())['sources'])
    sources = {name: sha((r / name).read_bytes()) for name in sorted(names)}
    head = git('rev-parse', 'HEAD').stdout.decode().strip()
    merge = git('rev-parse', '--verify', 'MERGE_HEAD', allowed=(0, 128))
    return {'observedFrom': started, 'observedUntil': now(), 'sourceSha256': sources,
            'metadata': {'head': head, 'mergeHead': merge.stdout.decode().strip() if merge.returncode == 0 else None},
            'qualification': 'Before: only three primary sources, repository Vitest config and lockfile. After: same files plus actual observed Vite repository modules. Normal commit metadata may change independently.'}

run = {'status': 'initializing', 'startedAt': now(), 'executionStarted': False,
       'scope': 'Unmodified two-case stale-width reviewer probe replayed through the actual repository dependency closure',
       'sourceWrites': False, 'indexWrites': False, 'nativeBrowserAcceptance': False,
       'gitMetadataMayChange': True, 'driverTimeoutSeconds': None}
save('run.json', run)
started = time.monotonic()
errors = []
before = None
exit_code = None
try:
    transport = json.loads((e / 'transport.json').read_text())
    original = (e / 'original-test.ts.txt').read_bytes()
    transported = (e / 'stale-width-frame.review.test.ts').read_bytes()
    assert sha(original) == transport['originalSha256']
    assert sha(transported) == transport['transportedSha256']
    restored = transported.decode()
    for change in transport['replacements']:
        assert restored.count(change['to']) == 1
        restored = restored.replace(change['to'], change['from'], 1)
    assert restored.encode() == original, 'Transport must change only the two imports'
    before = snapshot()
    save('source-before.json', before)
    node = w / 'toolchain/node_modules/node-linux-x64/bin/node'
    version = subprocess.check_output([str(node), '--version'], cwd=r, env=env, text=True).strip()
    assert version.startswith('v24.'), version
    command = [str(node), 'node_modules/vitest/vitest.mjs', 'run', '--config', str(e / 'vitest.replay.config.ts'),
               '--pool=forks', '--maxWorkers=1', '--minWorkers=1', '--no-file-parallelism',
               '--reporter=default', '--reporter=json', '--outputFile=' + str(e / 'vitest.json')]
    run.update({'status': 'running', 'executionStarted': True, 'executionStartedAt': now(),
                'command': command, 'nodeVersion': version, 'transport': transport,
                'sourceBefore': receipt(e / 'source-before.json')})
    save('run.json', run)
    with (e / 'vitest.log').open('wb') as log:
        process = subprocess.run(command, cwd=r, env=env, stdout=log, stderr=subprocess.STDOUT)
    exit_code = process.returncode
    (e / 'vitest.exit.txt').write_text(str(exit_code) + '\n')
except BaseException as error:
    errors.append({'stage': 'execution', 'error': repr(error), 'traceback': traceback.format_exc()})
finally:
    try:
        after = snapshot(observed=True)
        save('source-after.json', after)
        if before:
            run['primarySourceStable'] = all(after['sourceSha256'].get(name) == value for name, value in before['sourceSha256'].items())
            run['repositoryMetadataBefore'] = before['metadata']
            run['repositoryMetadataAfter'] = after['metadata']
            run['repositoryMetadataStable'] = before['metadata'] == after['metadata']
            if not run['primarySourceStable']: errors.append({'stage': 'source-binding', 'error': 'Primary source/config/lock bytes changed'})
    except BaseException as error:
        errors.append({'stage': 'source-after', 'error': repr(error)})

try:
    report = json.loads((e / 'vitest.json').read_text())
    run['summary'] = {key: report.get(key) for key in ['numTotalTests', 'numPassedTests', 'numFailedTests', 'numPendingTests', 'numTodoTests', 'success']}
    files = report.get('testResults', [])
    assert len(files) == 1 and Path(files[0]['name']) == e / 'stale-width-frame.review.test.ts'
    cases = files[0].get('assertionResults', [])
    expected = ['retains a width animation after a stale frame with the same declarations',
                'does not let a rejected older view change the current width capability']
    assert len(cases) == 2 and sorted(case['title'] for case in cases) == sorted(expected)
    assert all(case['status'] in {'passed', 'failed'} for case in cases)
    assert report['numTotalTests'] == 2 and report['numPendingTests'] == 0 and report['numTodoTests'] == 0
    run['cases'] = cases
except BaseException as error:
    errors.append({'stage': 'actual-execution-inventory', 'error': repr(error)})

try:
    graphs = sorted(e.glob('module-bindings-*.json'))
    assert graphs, 'No observed dependency graph'
    observed = {}
    for file in graphs:
        graph = json.loads(file.read_text())
        assert graph['finalized'] and not graph['errors'] and not graph['changed'] and not graph['foreignProjectSources'], graph
        for name, fact in graph['sources'].items():
            assert after['sourceSha256'].get(name) == fact['sha256'], name
            if name in before['sourceSha256']: assert before['sourceSha256'][name] == fact['sha256'], name
            observed[name] = fact
    for required in ['packages/adapters/base/src/motion/web-resident-motion.ts', 'packages/cli/src/services/proto-style-css.ts', 'packages/modules/feedback/src/motion/projector.ts']:
        assert required in observed, required
    assert any(name.startswith('packages/core/src/') for name in observed), 'Actual core modules absent'
    run['actualDependencyStable'] = True
    run['actualDependencyBinding'] = {'sourceCount': len(observed), 'sources': observed, 'records': [receipt(file) for file in graphs],
                                    'qualification': 'Observed repository transforms; third-party dependencies are additionally constrained by the recorded lockfile and repository configuration, not claimed as a complete external dependency hash.'}
except BaseException as error:
    run['actualDependencyStable'] = False
    errors.append({'stage': 'actual-dependency-binding', 'error': repr(error)})

run['sourceStable'] = bool(run.get('primarySourceStable') and run.get('actualDependencyStable'))
run.update({'status': 'completed' if not errors else 'invalid-replay', 'finishedAt': now(), 'elapsedSeconds': time.monotonic() - started,
            'vitestExitCode': exit_code, 'executionIntegrityErrors': errors,
            'executionIntegrityPassed': not errors,
            'testResult': 'passed' if exit_code == 0 and not errors else 'failed',
            'artifacts': [receipt(e / name) for name in ['vitest.log', 'vitest.json', 'vitest.exit.txt', 'source-before.json', 'source-after.json', 'transport.json', 'transport.diff'] if (e / name).exists()]})
save('run.json', run)
driver_exit = 1 if errors or exit_code != 0 else 0
(e / 'exit.txt').write_text(str(driver_exit) + '\n')
print(json.dumps({'status': run['status'], 'testResult': run['testResult'], 'summary': run.get('summary'), 'sourceStable': run.get('sourceStable'),
                  'executionIntegrityPassed': not errors, 'errors': errors}))
sys.exit(driver_exit)
