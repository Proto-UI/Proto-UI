import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';

const root = '/workspace/scratch/1494db44bb7b/sprint4-shader';
const require = createRequire(path.join(root, 'package.json'));
const { build } = require('esbuild');
const baseline = '4009346439913420769db1fa777354c6479f4846';
const files = ['packages/adapters/base/src/material/shader-webgl2.ts', 'packages/adapters/base/src/material/shader-webgl2-host.ts', 'packages/core/src/shader-presentation.ts'];
const digest = (s) => createHash('sha256').update(s).digest('hex');
const currentHashes = Object.fromEntries(files.map((file) => [file,digest(readFileSync(path.join(root,file)))]));
const originals = new Map(files.map((file) => [path.join(root,file),execFileSync('git',['show',`${baseline}:${file}`],{cwd:root,encoding:'utf8'})]));
const results = {};
const declaration = () => ({ version: 1, source: {kind:'owned-pixels',width:1,height:1,pixels:[0,0,0,255],colorSpace:'linear-srgb',alpha:'premultiplied',origin:'top-left'},passes:[{id:'copy',kernel:'copy-rgba8-v1',input:'$source'}],output:'copy',fallback:[0,0,0,1] });
const frame = (extra={}) => ({view:1,revision:1,style:{tokens:[]},declaration:declaration(),...extra});
for (const version of ['baseline','candidate']) {
  const bundled = await build({entryPoints:[path.join(root,files[0])],absWorkingDir:root,bundle:true,platform:'node',format:'cjs',write:false,metafile:true,logLevel:'silent',plugins:version==='baseline'?[{name:'exact-original-source-overlay',setup(builder){builder.onLoad({filter:/\.ts$/},(args)=>originals.has(args.path)?{contents:originals.get(args.path),loader:'ts',resolveDir:path.dirname(args.path)}:undefined);}}]:[]});
  const module={exports:{}};new Function('module','exports','require',bundled.outputFiles[0].text)(module,module.exports,require);
  const setup=()=>{ const counts={root:0,style:0,flush:0}; const sink=module.exports.createWebShaderPresentationSink(()=>{counts.root++;return null;},{queueStyle(){counts.style++;},requestFlush(){counts.flush++;}});return{counts,sink};};
  const observations={};
  for(const [name,first] of [['invalidRevision',frame({revision:Infinity})],['invalidDeclaration',frame({view:2,declaration:{...declaration(),output:'missing'}})]]) {
    const {counts,sink}=setup();let error=null;try{sink.commit(first);}catch(e){error=e.message;}
    sink.commit(frame());observations[name]={firstError:error,afterRecovery:counts,diagnostics:sink.diagnostics()};
  }
  const {counts,sink}=setup();sink.commit(frame({view:2}));sink.commit(frame());observations.staleFrame={counts,diagnostics:sink.diagnostics()};
  results[version]={observations,closure:{retainsDiagnosticFactory:bundled.outputFiles[0].text.includes('function createWebShaderDevice('),retainsSceneImplementation:bundled.outputFiles[0].text.includes('function createWebShaderScenePresenter(')}};
}
const output={kind:'bounded old owned-pixels sink compatibility probe without DOM or GPU',baseline,candidateSourceHashes:currentHashes,productBrowserJourneysExecuted:0,results};
const destination='/workspace/scratch/1494db44bb7b/ir10-semantics-evidence/owned-pixels-compatibility-probe.json';writeFileSync(destination,JSON.stringify(output,null,2)+'\n');console.log(JSON.stringify(output,null,2));
