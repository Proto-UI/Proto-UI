import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const root=process.env.PUI_REVIEW_REPO || '/workspace/scratch/1494db44bb7b/sprint4-shader';
const req=createRequire(root+'/package.json'),ts=req('typescript');
const {snapshotShaderPresentation}=await import(pathToFileURL(root+'/packages/core/src/shader-presentation.ts').href);
const sink=fs.readFileSync(root+'/packages/adapters/base/src/material/shader-webgl2.ts','utf8');
const physical=fs.readFileSync(root+'/packages/adapters/base/src/material/shader-webgl2-host.ts','utf8');
const core=fs.readFileSync(root+'/packages/core/src/shader-presentation.ts','utf8');
async function load(source:string){const code=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText;return import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));}
const physicalApi=await load(physical);
globalThis.__reviewSnapshot=snapshotShaderPresentation;
globalThis.__reviewValidate=physicalApi.validateWebShaderPublication;
const transformed=sink.replace(/import\s*\{\s*snapshotShaderPresentation\s*\}\s*from '@proto.ui\/core';/,'const snapshotShaderPresentation = globalThis.__reviewSnapshot;').replace(/import\s*\{[\s\S]*?\}\s*from '\.\/shader-webgl2-host';/,'const createWebShaderPresenter = options => globalThis.__reviewPhysical(options); const validateWebShaderPublication = globalThis.__reviewValidate;');
const sinkApi=await load(transformed);
const results=[];
const effects={queueStyle(){},flushNow(){},requestFlush(){}};
function frame(view:number,revision:number,kind:string){return{view,revision,declaration:{version:1,source:kind==='owned-scene'?{kind,slot:'canvas'}:{kind,width:1,height:1,pixels:[0,0,0,255],colorSpace:'linear-srgb',alpha:'premultiplied',origin:'top-left'},passes:[{id:'copy',kernel:'copy-rgba8-v1',input:'$source'}],output:'copy',fallback:[1,1,1,1]},style:{tokens:[]}};}
for(const replacement of [{view:2,revision:2},{view:1,revision:2}]){
 const calls=[],cap={commits:0,disposes:0};let owner;
 globalThis.__reviewPhysical=()=>({commit(publication,program){calls.push({view:publication.view,revision:publication.revision,program:!!program});},release(){},dispose(){},diagnostics(){return[];}});
 const host={createScenePresenter(){owner.commit(frame(replacement.view,replacement.revision,'owned-pixels'));return{commit(){cap.commits++;},release(){},dispose(){cap.disposes++;},diagnostics(){return[];}};}};
 owner=sinkApi.createWebShaderPresentationSink(()=>null,effects,host);
 try{
  owner.commit(frame(1,1,'owned-scene'));
  assert.deepEqual(calls,[{...replacement,program:true}]);
  assert.equal(cap.commits,0,'superseded scene acquisition must not commit after the nested owned-pixel frame');
  assert.equal(cap.disposes,1,'superseded acquired capability must be retired');
  results.push({name:`scene acquisition reentered with owned-pixels view=${replacement.view} revision=${replacement.revision}`,pass:true,calls,cap:{...cap}});
 }catch(error){results.push({name:`scene acquisition reentered with owned-pixels view=${replacement.view} revision=${replacement.revision}`,pass:false,message:error.message,actual:error.actual,expected:error.expected,calls,cap:{...cap}});}
 finally{owner.release(replacement.view);}
}
const sha=(text:string)=>crypto.createHash('sha256').update(text).digest('hex');
const report={sourceHashes:{runtimeSink:sha(sink),physicalValidator:sha(physical),coreSnapshot:sha(core)},stableFinal:false,procedure:'Actual Runtime sink with actual Core snapshot and actual physical ordinal validator; only physical publication is a recorded stub. Explicit host factory synchronously sends a newer owned-pixel frame. No browser paint claim.',counts:{total:results.length,pass:results.filter(x=>x.pass).length,fail:results.filter(x=>!x.pass).length},results};
const basename=process.argv[2] || 'mixed-source-factory-probe';
fs.writeFileSync(new URL('./'+basename+'.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
fs.writeFileSync(new URL('./'+basename+'.sink.snapshot.ts',import.meta.url),sink);
console.log(JSON.stringify(report,null,2));if(report.counts.fail)process.exitCode=1;
