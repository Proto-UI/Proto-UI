import type { EffectsPort } from '@proto.ui/core';
import { snapshotShaderPresentation } from '@proto.ui/core';
import type { ShaderPresentationFrame, ShaderPresentationSink } from '@proto.ui/module-feedback';
import { createWebShaderPresenter, type NativeShaderResource, type NativeShaderSource, type WebShaderDevice } from './shader-webgl2-host';
import type { WebShaderHostOptions, WebShaderScenePresenter } from './shader-scene-host';

/** Existing material Feedback entry, realized through an exclusive physical paint lease. */
export function createWebShaderPresentationSink(
  getRoot: () => HTMLElement | null,
  effects: EffectsPort,
  host?: WebShaderHostOptions
): ShaderPresentationSink {
  const presenter = createWebShaderPresenter({
    root: getRoot,
    prepare() {},
  });
  let scene: WebShaderScenePresenter | undefined;
  let last: { view: number; revision: number } | undefined;
  let turn = 0, releasedView = -1;
  return {
    commit(frame) {
      if (frame.view <= releasedView || (last && (frame.view < last.view ||
          (frame.view === last.view && frame.revision < last.revision)))) return;
      const operation = ++turn;
      last = { view: frame.view, revision: frame.revision };
      const input = snapshotShaderPresentation(frame.declaration);
      const key = JSON.stringify(input);
      const program = (device: WebShaderDevice, source: NativeShaderSource) => {
        const values = new Map<string, NativeShaderResource>([['$source', device.upload(source)]]);
        for (const pass of input.passes) {
          const resource = values.get(pass.input)!;
          values.set(pass.id, pass.kernel === 'copy-rgba8-v1' ? device.copy(resource) : device.tint(resource, pass.tint!));
        }
        return values.get(input.output)!;
      };
      const publication = { view: frame.view, revision: frame.revision, key, fallback: input.fallback };
      const prepare = () => {
        effects.queueStyle({ kind: 'tw', tokens: [...frame.style.tokens] });
        if (effects.flushNow) effects.flushNow();
        else effects.requestFlush();
      };
      if (input.source.kind === 'owned-scene') {
        if (!scene) {
          let acquired: WebShaderScenePresenter | undefined;
          try { acquired = host?.createScenePresenter({ root: getRoot, prepare() {} }); }
          catch {
            if (operation === turn) presenter.commit(publication, null, prepare, undefined, 'shader-scene-host-failed');
            return;
          }
          if (operation !== turn || frame.view <= releasedView) {
            acquired?.dispose();
            return;
          }
          scene = acquired;
        }
        if (scene) scene.commit({ ...publication, slot: input.source.slot, resources: input.passes.length + 1 }, program, prepare);
        else presenter.commit(publication, null, prepare, undefined, 'shader-scene-capability-unavailable');
      } else {
        const source = input.source;
        presenter.commit(publication, device => program(device, source), prepare);
      }
    },
    release(view) {
      if (last?.view !== view) return;
      turn++;
      releasedView = Math.max(view, releasedView);
      presenter.release(view);
      scene?.release(view);
    },
    diagnostics: () => Object.freeze([...new Set([...presenter.diagnostics(), ...(scene?.diagnostics() ?? [])])]),
  };
}
