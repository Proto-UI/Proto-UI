import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
const root='/workspace/scratch/1494db44bb7b/sprint4-shader';
const require=createRequire(path.join(root,'package.json'));
const {build}=require('esbuild');
const relative='packages/adapters/base/src/material/shader-webgl2-host.ts';
const filename=path.join(root,relative), baseline='4009346439913420769db1fa777354c6479f4846';
const prior=execFileSync('git',['show',`${baseline}:${relative}`],{cwd:root,encoding:'utf8'});
const scenarios={};
function environment(mode) {
  let next=0,device; const events=[],listeners=new Map(),objects=[];
  const make=(kind)=>{const value={kind,id:++next};objects.push(value);events.push(['create',kind,value.id]);return value;};
  const remove=(kind,value)=>{events.push(['delete',kind,value?.id]);if(mode==='cleanup-reentry') { device.dispose();if(kind==='Framebuffer')throw Error('first-framebuffer-cleanup');if(kind==='Texture')throw Error('second-texture-cleanup'); }};
  const constants={NO_ERROR:0,FRAMEBUFFER_COMPLETE:1};let constant=10;
  const gl=new Proxy({
    isContextLost:()=>false,
    getError:()=>mode==='initial-check-failure'?99:0,
    checkFramebufferStatus:()=>1,
    getShaderParameter:()=>true,getProgramParameter:()=>true,
    getUniformLocation:(_p,key)=>({key}),
    readPixels:(_x,_y,_w,_h,_format,_type,buffer)=>{events.push(['readPixels',buffer.length]);buffer.set([7,11,13,255]);},
    createVertexArray:()=>make('VertexArray'),createTexture:()=>make('Texture'),createFramebuffer:()=>make('Framebuffer'),createShader:()=>make('Shader'),createProgram:()=>make('Program'),
    deleteVertexArray:(v)=>{events.push(['delete','VertexArray',v?.id]);if(mode==='initial-check-failure')throw Error('secondary-cleanup-error');if(mode==='cleanup-reentry')device.dispose();},
    deleteTexture:(v)=>remove('Texture',v),deleteFramebuffer:(v)=>remove('Framebuffer',v),deleteShader:(v)=>remove('Shader',v),deleteProgram:(v)=>remove('Program',v),
  },{get(target,key){if(key in target)return target[key];if(typeof key==='string'&&key===key.toUpperCase())return constants[key]??=(++constant);return(...args)=>{events.push([String(key),...args.map(v=>v&&typeof v==='object'&&'id'in v?v.id:typeof v)]);};}});
  const canvas={width:0,height:0,getContext:()=>gl,toDataURL:()=> 'data:image/png;base64,fixture',addEventListener:(type,fn)=>listeners.set(type,fn),removeEventListener:(type)=>listeners.delete(type)};
  return {document:{createElement(name){assert.equal(name,'canvas');return canvas;}},events,listeners,canvas,setDevice(value){device=value;}};
}
const capture=(fn)=>{try{return {value:fn(),error:null};}catch(e){return {error:e.message};}};
for(const version of ['baseline','candidate']) {
 const bundle=await build({entryPoints:[filename],absWorkingDir:root,bundle:true,platform:'node',format:'cjs',write:false,logLevel:'silent',plugins:version==='baseline'?[{name:'exact-baseline-host',setup(builder){builder.onLoad({filter:/shader-webgl2-host\.ts$/},()=>({contents:prior,loader:'ts',resolveDir:path.dirname(filename)}));}}]:[]});
 const module={exports:{}};new Function('module','exports','require',bundle.outputFiles[0].text)(module,module.exports,require);
 const observed={};
 for(const mode of ['ordinary','cleanup-reentry','initial-check-failure']) {
   const env=environment(mode);let device;
   const setup=capture(()=>{device=module.exports.createWebShaderDevice(env.document,()=>{});env.setDevice(device);return Object.keys(device).sort();});
   const row={setup};
   if(device){
     const resource=device.upload({width:1,height:1,pixels:[0,0,0,255]});
     row.read=capture(()=>Array.from(device.read(resource)));
     row.foreign=capture(()=>device.read({}));
     row.dispose=capture(()=>device.dispose());
     row.secondDispose=capture(()=>device.dispose());
     row.afterDispose=capture(()=>device.read(resource));
   }
   row.events=env.events;row.listeners=env.listeners.size;row.canvas=[env.canvas.width,env.canvas.height];observed[mode]=row;
 }
 scenarios[version]=observed;
}
const comparisons=Object.keys(scenarios.baseline).map(name=>{try{assert.deepEqual(scenarios.candidate[name],scenarios.baseline[name]);return{name,matched:true};}catch(e){return{name,matched:false,error:e.message};}});
const report={kind:'diagnostic-device and private resource cleanup compatibility with deterministic host-call stubs; no GPU or browser evidence',baseline,candidateSourceSha256:createHash('sha256').update(readFileSync(filename)).digest('hex'),scenarios,comparisons};
const output='/workspace/scratch/1494db44bb7b/ir10-semantics-evidence/owned-pixels-device-probe.json';writeFileSync(output,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({output,comparisons},null,2));
