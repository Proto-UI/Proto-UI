from pathlib import Path
import subprocess,json,base64,hashlib,tarfile,io,http.server,functools,threading,os,datetime
root=Path('/tank/shared/projects/proto-ui-agent/s7-browser-20261124-0d7d');stage=root/'button-primary-observation-01';stage.mkdir()
refs=['3cdf7ec845529bf2c629beeeb65f7b70d1c15ce2','ca00475992f28f1f52c80efc7463caf3474669a6','ec00f2b7c585d03ad68ea6762ee9c12f3c57e606'];parts=[]
for ref in refs:
 d=json.loads(subprocess.check_output(['gh','api','repos/Proto-UI/Proto-UI/git/blobs/'+ref]));raw=base64.b64decode(d['content']);assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==ref;parts.append(raw)
data=b''.join(parts);assert hashlib.sha256(data).hexdigest()=='88433f66f5da8fef4dd25ea9357c3d8bf5099e6cc7aa7484830f42cf19448900';(stage/'input.tar.gz').write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:t.extractall(stage,filter='data')
op=root/'button-common-03/operator-root';observer=op/'scripts/analysis/button-projection-study/observe.mjs';assert hashlib.sha256(observer.read_bytes()).hexdigest()=='91d6604b33732c7596e33a36af6c0996ac0dc8cb27c00b27d3e91bd9db615937'
node='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin/node';env={**os.environ,'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'CHROME_PATH':'/home/ezra/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome','TMPDIR':'/tank/shared/projects/proto-ui-agent/t0d7d'}
records=[]
for name in ['deterministic-1','clean-generative-1','deterministic-2','clean-generative-2','deterministic-3','clean-generative-3']:
 cell=stage/'button-primary-01'/name
 class Handler(http.server.SimpleHTTPRequestHandler):
  def do_GET(self):
   if self.path=='/favicon.ico':self.send_response(204);self.end_headers();return
   super().do_GET()
 server=http.server.ThreadingHTTPServer(('127.0.0.1',19759),functools.partial(Handler,directory=str(cell/'clean-consumer/dist')));threading.Thread(target=server.serve_forever,daemon=True).start()
 args=[node,'--import','tsx',str(observer),str(cell),'http://127.0.0.1:19759/'];rec={'name':name,'command':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceArchiveSha256':hashlib.sha256(data).hexdigest(),'sandbox':True}
 try:
  with (stage/(name+'.log')).open('w') as f:p=subprocess.run(args,cwd=op,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=70)
  rec['exitCode']=p.returncode
 except subprocess.TimeoutExpired:rec['exitCode']=124
 finally:server.shutdown();server.server_close()
 result=cell/'operator/browser/result.json'
 if result.exists():
  d=json.loads(result.read_text());rec.update({'status':d.get('status'),'failure':d.get('failure'),'checkpoints':len(d.get('checkpoints',[])),'gestures':len(d.get('gestures',[])),'errors':d.get('errors'),'spaceActivationEdge':d.get('spaceActivationEdge')})
 rec['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();records.append(rec);(stage/'results.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(rec),flush=True)
