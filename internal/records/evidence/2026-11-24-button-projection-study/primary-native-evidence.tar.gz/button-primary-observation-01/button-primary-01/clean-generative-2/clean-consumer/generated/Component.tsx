import type { ReactNode } from 'react';

export interface GeneratedButtonProps {
  children: ReactNode;
  disabled?: boolean;
  onClick: () => void;
}

/** A single native button action, including native keyboard and disabled behavior. */
export function GeneratedButton({
  children,
  disabled = false,
  onClick,
}: GeneratedButtonProps) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={() => {
        if (!disabled) onClick();
      }}
    >
      {children}
    </button>
  );
}
