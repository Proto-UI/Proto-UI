import type { ReactNode } from 'react';

export interface GeneratedButtonProps {
  children: ReactNode;
  disabled?: boolean;
  onClick: () => void;
}

export function GeneratedButton({
  children,
  disabled = false,
  onClick,
}: GeneratedButtonProps) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={() => {
        if (!disabled) onClick();
      }}
      style={{ minWidth: '2.5rem', minHeight: '2.5rem', padding: '0.5rem 1rem', font: 'inherit' }}
    >
      {children}
    </button>
  );
}
