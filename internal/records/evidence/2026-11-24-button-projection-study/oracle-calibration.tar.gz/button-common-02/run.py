from pathlib import Path
import subprocess,json,hashlib,shutil,http.server,functools,threading,os,datetime
base=Path('/tank/shared/projects/proto-ui-agent/s7-browser-20261124-0d7d/button-common-02');op=base/'operator-root';repo=Path('/tank/shared/projects/proto-ui-agent/s7-complete-20261124-0d7d')
links={op/'apps':repo/'apps',op/'scripts/benchmark':repo/'scripts/benchmark',op/'scripts/analysis/invisible-consumption':repo/'scripts/analysis/invisible-consumption',op/'node_modules':repo/'node_modules'}
for src,dst in links.items():
 if src.is_symlink():assert src.resolve()==dst.resolve()
 else:src.symlink_to(dst,target_is_directory=True)
node='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin/node';chrome='/home/ezra/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome'
env={**os.environ,'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'CHROME_PATH':chrome,'TMPDIR':'/tank/shared/projects/proto-ui-agent/t0d7d'}
observer=op/'scripts/analysis/button-projection-study/observe.mjs';assert hashlib.sha256(observer.read_bytes()).hexdigest()=='91d6604b33732c7596e33a36af6c0996ac0dc8cb27c00b27d3e91bd9db615937'
subprocess.run([node,str(op/'scripts/analysis/button-projection-study/prepare-calibration.mjs'),str(base/'controls')],cwd=op,env=env,check=True)
generated=base/'controls/generated-existing';generated.mkdir();original=base.parent/'s7-button-artifact-01'
shutil.copyfile(original/'clean-consumer.json',generated/'clean-consumer.json');shutil.copytree(original/'clean-consumer/dist',generated/'clean-consumer/dist')
records=[]
for name in ['generated-existing','legal-native','legal-aria','late-duplicate','disabled-ignored','reset-leak','missing-role','unlisted-asset','space-double','space-missing','tab-unreachable','disabled-keyboard-leak','reenable-stuck']:
 cell=base/'controls'/name;(cell/'operator').mkdir()
 class Handler(http.server.SimpleHTTPRequestHandler):
  def do_GET(self):
   if self.path=='/favicon.ico':self.send_response(204);self.end_headers();return
   super().do_GET()
 server=http.server.ThreadingHTTPServer(('127.0.0.1',19749),functools.partial(Handler,directory=str(cell/'clean-consumer/dist')));threading.Thread(target=server.serve_forever,daemon=True).start()
 args=[node,'--import','tsx',str(observer),str(cell),'http://127.0.0.1:19749/']
 rec={'name':name,'command':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expected':'pass' if name in ['generated-existing','legal-native','legal-aria'] else 'fail'}
 try:
  with (base/(name+'.log')).open('w') as f:p=subprocess.run(args,cwd=op,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=70)
  rec['exitCode']=p.returncode
 except subprocess.TimeoutExpired:rec['exitCode']=124
 finally:server.shutdown();server.server_close()
 result=cell/'operator/browser/result.json'
 if result.exists():
  d=json.loads(result.read_text());rec.update({'status':d.get('status'),'failure':d.get('failure'),'checkpoints':len(d.get('checkpoints',[])),'gestures':len(d.get('gestures',[])),'errors':d.get('errors')})
 rec['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();records.append(rec);(base/'results.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(rec),flush=True)
