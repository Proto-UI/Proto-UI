# Generated Button

This is an editable local source distribution for React 19.2.6, not a registry package. Copy the entire generated directory, including its hidden helper directories, into your project. Install the declared dependencies:

`npm install react@19.2.6 react-dom@19.2.6`

Import `{ GeneratedButton }` from `./generated/Component`. Supply label content as children, a boolean `disabled`, and `onClick` for an activation. Keep supporting files and provenance with the source. The Base control has no promised visual-family paint; inspect the generated source and use ordinary consumer styling. Editing output makes the original compiler maps/provenance historical; keep a preimage and build fresh consumer maps.

This distribution's exact behavioral bounds must accompany its independently admitted evidence. Source provenance is retained unchanged.
