// @vitest-environment happy-dom
import path from 'node:path';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
import { createRequire } from 'node:module';
import { fileURLToPath, URL as NodeURL } from 'node:url';
import { afterEach, describe, expect, it } from 'vitest';
import { parsePrototype } from './parser';
import { emitWebComponentSource } from './web-component-source';

const floatingUi = createRequire(
  fileURLToPath(new NodeURL('../../modules/positioning/package.json', import.meta.url))
)('@floating-ui/dom');

interface StateProjection<T> {
  get(): T;
  subscribe(callback: (event: { prev: T; next: T; reason?: unknown }) => void): () => void;
  unsubscribe(off: () => void): void;
}
interface NativeElement extends HTMLElement {
  logicalOwner: symbol | null;
  viewEpoch: number;
  present: boolean;
  connectedCallback(): void;
  update(): void;
  setProps(props: Record<string, unknown>): void;
  getExposes(): {
    count?: StateProjection<number>;
    mounts?: StateProjection<number>;
    unmounts?: StateProjection<number>;
    inputs?: StateProjection<number>;
    focused?: StateProjection<boolean>;
    focusable?: StateProjection<boolean>;
    bump?: (next: number) => void;
    disable?: (next: boolean) => void;
    arm?: () => void;
    consume?: () => void;
    read?: () => number;
    snapshot?: () => number;
    post?: () => number;
    pre?: () => number;
    id?: string;
    allocate?: () => string;
    resetTrace?: () => void;
    readTrace?: () => string;
    falsy?: (tag: number) => boolean;
    uncaughtFalsy?: (tag: number) => void;
    sameRecord?: () => boolean;
    sameArray?: () => boolean;
    codeDiscrimination?: () => boolean;
    rethrowRecord?: () => boolean;
    returnAfterCleanup?: () => string;
    returnTraceBeforeFinally?: () => string;
    finalReturn?: () => string;
    finalThrow?: () => boolean;
    replaceThrow?: () => boolean;
    caughtScope?: () => boolean;
    propertyError?: () => boolean;
    stringUnits?: () => boolean;
    bareCatch?: () => boolean;
  };
  dispose(): void;
}
let nextTag = 0;
const mounted: NativeElement[] = [];
afterEach(() => {
  for (const element of mounted.splice(0)) {
    element.dispose();
    element.remove();
  }
});

function create(source: string, shadow = true, exportName = 'default'): NativeElement {
  const parsed = parsePrototype(source, { fileName: 'independent.proto.ts', exportName });
  if (!parsed.ok) throw new Error(JSON.stringify(parsed.diagnostics));
  const emitted = emitWebComponentSource(parsed.value, { shadow });
  if (!emitted.ok) throw new Error(JSON.stringify(emitted.diagnostics));
  // Execute the generated consumer, not authored input and not an IR interpreter.
  const sources = new Map(
    (emitted.value.supportingFiles ?? []).map((file) => [file.path, file.contents])
  );
  sources.set('component.ts', emitted.value.code);
  const modules = new Map<string, Record<string, unknown>>();
  function load(file: string): Record<string, unknown> {
    const name = path.posix.normalize(file);
    const existing = modules.get(name);
    if (existing) return existing;
    const source = sources.get(name);
    if (source === undefined) throw new Error(`Missing generated module: ${name}`);
    const exports: Record<string, unknown> = {};
    modules.set(name, exports);
    const program = ts.transpileModule(source, {
      fileName: name,
      compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
    }).outputText;
    new Function('exports', 'require', program)(exports, (specifier: string) => {
      if (specifier === '@floating-ui/dom') return floatingUi;
      if (!specifier.startsWith('.')) throw new Error(`Unexpected native dependency: ${specifier}`);
      const target = path.posix.join(path.posix.dirname(name), specifier);
      return load(target.endsWith('.ts') ? target : `${target}.ts`);
    });
    return exports;
  }
  const register = load('component.ts').register as (name: string) => CustomElementConstructor;
  const tag = `x-native-compiler-${++nextTag}`;
  if (!register) throw new Error('Registration API missing');
  register(tag);
  const element = document.createElement(tag) as NativeElement;
  mounted.push(element);
  return element;
}
const stateSource = `import {definePrototype} from '@proto.ui/core';
export default definePrototype({name:'independent-counter', setup(def){
  const count = def.state.numberDiscrete('counter.value', 0);
  def.expose.state('count', count);
  def.expose.method('bump', (next: number) => {count.set(next);});
  def.lifecycle.onCreated(() => {count.set(1);});
  def.lifecycle.onMounted(() => {count.set(2);});
  return (renderer) => renderer.el('p', count.get());
}});`;
const presenceSource = `import {definePrototype} from '@proto.ui/core';
export default definePrototype({name:'independent-view', setup(def){
  def.props.define({visible:{type:'boolean',default:true}, count:{type:'number',default:0}});
  const count = def.state.numberDiscrete('view.count', 0);
  const mounts = def.state.numberDiscrete('view.mounts', 0);
  const unmounts = def.state.numberDiscrete('view.unmounts', 0);
  def.expose.state('count', count);
  def.expose.state('mounts', mounts);
  def.expose.state('unmounts', unmounts);
  def.expose.method('bump', (next: number) => {count.set(next);});
  def.props.watch(['visible'], (run, next) => {run.lifecycle.setPresent(next.visible);});
  def.props.watch(['count'], (run, next) => {count.set(next.count);run.update();});
  def.lifecycle.onMounted(() => {mounts.set(mounts.get()+1);});
  def.lifecycle.onUnmounted(() => {unmounts.set(unmounts.get()+1);});
  return (renderer) => renderer.el('section', [renderer.el('p', count.get()), renderer.slot()]);
}});`;
const defaultViewSource = `import {definePrototype} from '@proto.ui/core';
export default definePrototype({name:'default-view-reconnect',setup(def){
  def.props.define({label:{type:'string',default:'default'}});
  const count=def.state.numberDiscrete('reconnect.created',0);
  const mounts=def.state.numberDiscrete('reconnect.mounts',0);
  const unmounts=def.state.numberDiscrete('reconnect.unmounts',0);
  def.expose.state('count',count);
  def.expose.state('mounts',mounts);
  def.expose.state('unmounts',unmounts);
  def.expose.method('bump',(next:number)=>{count.set(next);});
  def.lifecycle.onCreated(()=>{count.set(count.get()+1);});
  def.lifecycle.onMounted(()=>{mounts.set(mounts.get()+1);});
  def.lifecycle.onUnmounted(()=>{unmounts.set(unmounts.get()+1);});
  return (r)=>r.el('section',[r.el('p',r.read.props.get().label),r.el('output',count.get()),r.slot()]);
}});`;

// These regressions exercise externally observable ownership, update, disposal and slot contracts.
describe('native Web Component semantic source', () => {
  it('retains arbitrary thrown data, code discrimination and caught closure identity', () => {
    const source = readFileSync(new NodeURL('../test/fixtures/exception-flow.proto.ts', import.meta.url), 'utf8');
    const element = create(source);
    document.body.append(element);
    const methods = element.getExposes();
    for (let tag = 0; tag < 5; tag++) expect(methods.falsy?.(tag)).toBe(true);
    expect(methods.sameRecord?.()).toBe(true);
    expect(methods.sameArray?.()).toBe(true);
    expect(methods.codeDiscrimination?.()).toBe(true);
    expect(methods.caughtScope?.()).toBe(true);
    expect(methods.propertyError?.()).toBe(true);
    expect(methods.stringUnits?.()).toBe(true);
  });

  it('runs finalizers once, honors their abrupt completion and preserves uncaught falsy values', () => {
    const source = readFileSync(new NodeURL('../test/fixtures/exception-flow.proto.ts', import.meta.url), 'utf8');
    const element = create(source);
    document.body.append(element);
    const methods = element.getExposes();
    methods.resetTrace?.();
    expect(methods.rethrowRecord?.()).toBe(true);
    expect(methods.readTrace?.()).toBe('body;inner;inner-final;outer;outer-final;');
    methods.resetTrace?.();
    expect(methods.returnAfterCleanup?.()).toBe('before');
    expect(methods.readTrace?.()).toBe('try;finally;');
    methods.resetTrace?.();
    expect(methods.returnTraceBeforeFinally?.()).toBe('');
    expect(methods.readTrace?.()).toBe('after;');
    methods.resetTrace?.();
    expect(methods.finalReturn?.()).toBe('override');
    expect(methods.readTrace?.()).toBe('try;finally;');
    expect(methods.finalThrow?.()).toBe(true);
    expect(methods.replaceThrow?.()).toBe(true);
    methods.resetTrace?.();
    expect(methods.bareCatch?.()).toBe(true);
    expect(methods.readTrace?.()).toBe('catch;finally;');
    const values = [0, false, null, undefined, ''];
    for (const [tag, expected] of values.entries()) {
      methods.resetTrace?.();
      let failed = false;
      let thrown: unknown;
      try {
        methods.uncaughtFalsy?.(tag);
      } catch (error) {
        failed = true;
        thrown = error;
      }
      expect(failed).toBe(true);
      expect(thrown).toBe(expected);
      expect(methods.readTrace?.()).toBe('unhandled-final;');
      expect(methods.sameRecord?.()).toBe(true);
    }
  });

  it('commits only the renderer result selected by finally', async () => {
    const source = readFileSync(new NodeURL('../test/fixtures/exception-flow.proto.ts', import.meta.url), 'utf8');
    const element = create(source, true, 'FinallyRenderer');
    document.body.append(element);
    await Promise.resolve();
    expect(element.shadowRoot?.querySelectorAll('output')).toHaveLength(1);
    expect(element.shadowRoot?.querySelector('output')?.textContent).toBe('visible');
    expect(element.shadowRoot?.querySelector('p')).toBeNull();
  });

  it('retains private lexical cells without notifying or rendering and snapshots const aliases', async () => {
    const source = readFileSync(new NodeURL('../test/fixtures/lexical-values.proto.ts', import.meta.url), 'utf8');
    const first = create(source);
    const second = document.createElement(first.localName) as NativeElement;
    mounted.push(second);
    document.body.append(first, second);
    const a = first.getExposes(), b = second.getExposes();
    a.arm?.();
    a.consume?.();
    // Compound assignment reads the old 1 before change() writes 20 and returns 2.
    expect(a.read?.()).toBe(3);
    expect(a.snapshot?.()).toBe(1);
    expect(b.read?.()).toBe(1);
    expect(first.shadowRoot?.textContent).toBe('ready');
    expect(a.post?.()).toBe(3);
    expect(a.pre?.()).toBe(5);
    first.update();
    await Promise.resolve();
    expect(first.shadowRoot?.textContent).toBe('used');
    expect(second.shadowRoot?.textContent).toBe('ready');
    first.remove();
    document.body.append(first);
    expect(first.getExposes().read?.()).toBe(5);
    first.dispose();
    expect(() => a.read?.()).toThrow(/disposed/);
    expect(b.read?.()).toBe(1);
  });

  it('clears a private arm flag before a synchronous public State observer reenters', () => {
    const element = create(`import {definePrototype} from '@proto.ui/core';
      export default definePrototype({name:'private-reentrant-arm',setup(def){
        let armed=false;
        const count=def.state.numberDiscrete('count',0);
        def.expose.state('count',count);
        def.expose.method('arm',()=>{armed=true;});
        def.expose.method('consume',()=>{if(!armed)return;armed=false;count.set(count.get()+1);});
      }});`);
    document.body.append(element);
    const api = element.getExposes();
    const transitions: number[] = [];
    api.count?.subscribe(({next}) => {
      transitions.push(next);
      api.consume?.();
    });
    api.arm?.();
    api.consume?.();
    api.consume?.();
    expect(transitions).toEqual([1]);
    expect(api.count?.get()).toBe(1);
  });

  it('shares module lexical allocation across live owners and retained detach', () => {
    const source = readFileSync(new NodeURL('../test/fixtures/module-lexical-values.proto.ts', import.meta.url), 'utf8');
    const first = create(source);
    const second = document.createElement(first.localName) as NativeElement;
    mounted.push(second);
    document.body.append(first, second);
    expect(first.getExposes().id).toBe('owner-1');
    expect(second.getExposes().id).toBe('owner-2');
    expect(first.getExposes().allocate?.()).toBe('owner-3');
    first.remove();
    document.body.append(first);
    expect(first.getExposes().id).toBe('owner-1');
    expect(second.getExposes().allocate?.()).toBe('owner-4');
    first.dispose();
    expect(second.getExposes().allocate?.()).toBe('owner-5');
  });

  it('binds semantic module helpers to the calling owner while retaining their private closures', () => {
    const source = readFileSync(new NodeURL('../test/fixtures/module-lexical-values.proto.ts', import.meta.url), 'utf8');
    const first = create(source, true, 'WithState');
    const second = document.createElement(first.localName) as NativeElement;
    mounted.push(second);
    document.body.append(first, second);
    first.getExposes().bump?.(2);
    expect(first.getExposes().read?.()).toBe(2);
    expect(first.getExposes().count?.get()).toBe(2);
    expect(second.getExposes().read?.()).toBe(0);
    expect(second.getExposes().count?.get()).toBe(0);
    first.dispose();
    second.getExposes().bump?.(3);
    expect(second.getExposes().read?.()).toBe(3);
  });

  it('does not render state writes until an explicit update, and invalidates exposed handles on disposal', async () => {
    const element = create(stateSource);
    document.body.appendChild(element);
    const exposes = element.getExposes();
    expect(element.shadowRoot?.textContent).toBe('1');
    expect(exposes.count?.get()).toBe(2);
    exposes.bump?.(5);
    expect(element.shadowRoot?.textContent).toBe('1');
    element.update();
    await Promise.resolve();
    expect(element.shadowRoot?.textContent).toBe('5');
    element.dispose();
    expect(element.shadowRoot?.textContent).toBe('');
    expect(() => exposes.bump?.(6)).toThrow(/disposed/);
    expect(() => exposes.count?.get()).toThrow(/disposed/);
  });

  it('serializes reentrant exposed state notifications and stops subscriptions at terminal disposal', () => {
    const element = create(stateSource);
    document.body.appendChild(element);
    const exposes = element.getExposes();
    const observed: string[] = [];
    exposes.count?.subscribe(({ next }) => {
      observed.push(`a:${next}`);
      if (next === 5) exposes.bump?.(6);
    });
    exposes.count?.subscribe(({ next }) => observed.push(`b:${next}`));
    exposes.bump?.(5);
    expect(observed).toEqual(['a:5', 'b:5', 'a:6', 'b:6']);
    element.dispose();
    expect(() => exposes.count?.subscribe(() => {})).toThrow(/disposed/);
  });

  it('clamps range defaults but rejects out-of-range writes without mutating the published value', () => {
    const element = create(`import {definePrototype} from '@proto.ui/core';
      export default definePrototype({name:'range-boundary',setup(def){
        const count=def.state.numberRange('range.value',-2,{min:0,max:10,clamp:true});
        def.expose.state('count',count);
        def.expose.method('bump',(next:number)=>{count.set(next);});
        return (renderer)=>renderer.el('p',count.get());
      }});`);
    document.body.appendChild(element);
    const exposes = element.getExposes();
    expect(exposes.count?.get()).toBe(0);
    expect(() => exposes.bump?.(11)).toThrow(/range/);
    expect(exposes.count?.get()).toBe(0);
    exposes.bump?.(5);
    expect(exposes.count?.get()).toBe(5);
  });

  it('preserves the logical owner and external subscriptions across view epochs, with native slot projection', async () => {
    const element = create(presenceSource);
    element.style.display = 'inline-flex';
    const content = document.createElement('strong');
    content.textContent = 'projected';
    element.append(content);
    document.body.appendChild(element);
    const identity = element.logicalOwner;
    const epoch = element.viewEpoch;
    const exposes = element.getExposes();
    const events: number[] = [];
    exposes.count?.subscribe(({ next }) => events.push(next));
    expect(element.shadowRoot?.querySelector('slot')?.assignedNodes()).toEqual([content]);
    element.setProps({ visible: false, count: 4 });
    await Promise.resolve();
    expect(element.present).toBe(false);
    expect(getComputedStyle(element).display).toBe('none');
    expect(element.shadowRoot?.childNodes.length).toBe(0);
    expect(element.logicalOwner).toBe(identity);
    expect(exposes.unmounts?.get()).toBe(1);
    exposes.bump?.(7);
    element.setProps({ visible: true, count: 4 });
    await Promise.resolve();
    expect(element.logicalOwner).toBe(identity);
    expect(element.viewEpoch).toBeGreaterThan(epoch);
    expect(getComputedStyle(element).display).toBe('inline-flex');
    expect(element.shadowRoot?.querySelector('p')?.textContent).toBe('7');
    expect(element.shadowRoot?.querySelector('slot')?.assignedNodes()).toEqual([content]);
    expect(exposes.mounts?.get()).toBe(2);
    expect(events).toEqual([4, 7]);
    element.update();
    await Promise.resolve();
    expect(element.childNodes).toHaveLength(1);
    expect(element.firstChild).toBe(content);
  });

  it('uses full raw snapshots: invalid input retains a previous valid candidate, omission returns to defaults', async () => {
    const element = create(presenceSource);
    document.body.appendChild(element);
    element.setProps({ visible: true, count: 4 });
    await Promise.resolve();
    expect(element.shadowRoot?.querySelector('p')?.textContent).toBe('4');
    element.setProps({ visible: true, count: 'invalid' });
    await Promise.resolve();
    expect(element.getExposes().count?.get()).toBe(4);
    element.setProps({ visible: true });
    await Promise.resolve();
    expect(element.getExposes().count?.get()).toBe(0);
    expect(element.shadowRoot?.querySelector('p')?.textContent).toBe('0');
  });

  it('requests callback-time updates after state writes and emits declared native events', async () => {
    const element = create(`import {definePrototype} from '@proto.ui/core';
      export default definePrototype({name:'callback-update',setup(def){
        def.props.define({value:{type:'number',default:0}});
        const count = def.state.numberDiscrete('callback.count',0);
        def.expose.state('count',count);
        def.expose.event('changed');
        def.props.watch(['value'],(run,next)=>{
          count.set(next.value);run.expose.emit('changed');run.update();
        });
        return (renderer)=>renderer.el('output',count.get());
      }});`);
    document.body.appendChild(element);
    const observed: number[] = [];
    element.addEventListener('changed', () => {
      observed.push(element.getExposes().count?.get() ?? -1);
      expect(element.shadowRoot?.textContent).toBe('0');
    });
    element.setProps({ value: 9 });
    expect(observed).toEqual([9]);
    await Promise.resolve();
    expect(element.shadowRoot?.textContent).toBe('9');
  });

  it.each(['light', 'shadow'] as const)(
    'reconciles a preconfigured %s owner after its first connection reaction arrives while disconnected',
    async (mode) => {
      const element = create(defaultViewSource, mode === 'shadow');
      element.setProps({ label: 'configured before connection' });
      const content = document.createElement('strong');
      content.textContent = 'consumer slot';
      element.append(content);
      // Drive the permitted native reaction ordering explicitly: a light-slot commit
      // can remove a child before its already-enqueued connection callback is delivered.
      // Execute the real generated callback, then reconnect through actual DOM insertion.
      element.connectedCallback();
      const identity = element.logicalOwner;
      expect(identity).not.toBeNull();
      expect(element.present).toBe(false);
      expect(element.viewEpoch).toBe(0);
      await Promise.resolve();
      const parent = create(
        `import {definePrototype} from '@proto.ui/core';
        export default definePrototype({name:'light-slot-parent',setup(){}});`,
        false
      );
      parent.append(element);
      document.body.append(parent);
      await Promise.resolve();
      const root = element.shadowRoot ?? element;
      const frame = root.querySelector('section');
      const exposes = element.getExposes();
      expect(element.logicalOwner).toBe(identity);
      expect(element.present).toBe(true);
      expect(element.viewEpoch).toBe(1);
      expect(frame).not.toBeNull();
      expect(root.querySelector('p')?.textContent).toBe('configured before connection');
      expect(root.querySelector('output')?.textContent).toBe('1');
      expect(element.contains(content)).toBe(true);
      expect(exposes.count?.get()).toBe(1);
      expect(exposes.mounts?.get()).toBe(1);
      expect(exposes.unmounts?.get()).toBe(0);
      const events: number[] = [];
      exposes.count?.subscribe(({ next }) => events.push(next));
      exposes.bump?.(7);
      element.remove();
      document.body.append(element);
      element.connectedCallback();
      await Promise.resolve();
      expect(element.logicalOwner).toBe(identity);
      expect(element.viewEpoch).toBe(1);
      expect(root.querySelector('section')).toBe(frame);
      expect(root.querySelector('output')?.textContent).toBe('1');
      expect(element.getExposes().count).toBe(exposes.count);
      expect(exposes.count?.get()).toBe(7);
      expect(events).toEqual([7]);
      expect(exposes.mounts?.get()).toBe(1);
      expect(exposes.unmounts?.get()).toBe(0);
    }
  );

  it('does not reenter a light-slot commit when child acceptance synchronously moves its parent', async () => {
    const parent = create(defaultViewSource, false);
    const child = create(`import {definePrototype} from '@proto.ui/core';
      export default definePrototype({name:'child-acceptance-move',setup(def){
        def.expose.event('accepted');
        def.lifecycle.onCreated((run)=>{run.expose.emit('accepted');});
        return (r)=>r.el('span','accepted child');
      }});`);
    const destination = document.createElement('div');
    document.body.append(destination);
    parent.append(child);
    const observations: { owner: symbol | null; present: boolean }[] = [];
    parent.addEventListener('accepted', () => {
      observations.push({ owner: parent.logicalOwner, present: parent.present });
      destination.append(parent);
    });
    try {
      document.body.append(parent);
      const frame = parent.querySelector('section');
      await Promise.resolve();
      const exposes = parent.getExposes();
      expect(observations).toEqual([{ owner: parent.logicalOwner, present: false }]);
      expect(parent.logicalOwner).not.toBeNull();
      expect(parent.parentNode).toBe(destination);
      expect(parent.present).toBe(true);
      expect(parent.viewEpoch).toBe(1);
      expect(parent.querySelector('section')).toBe(frame);
      expect(child.present).toBe(true);
      expect(child.shadowRoot?.textContent).toBe('accepted child');
      expect(exposes.count?.get()).toBe(1);
      expect(exposes.mounts?.get()).toBe(1);
      expect(exposes.unmounts?.get()).toBe(0);
    } finally {
      destination.remove();
    }
  });

  it('does not materialize a queued connection after terminal disposal', async () => {
    const element = create(defaultViewSource);
    element.connectedCallback();
    document.body.append(element);
    const exposes = element.getExposes();
    expect(element.present).toBe(false);
    expect(exposes.count?.get()).toBe(1);
    expect(exposes.mounts?.get()).toBe(0);
    element.dispose();
    await Promise.resolve();
    expect(element.logicalOwner).toBeNull();
    expect(element.present).toBe(false);
    expect(element.shadowRoot?.childNodes).toHaveLength(0);
    expect(() => exposes.count?.get()).toThrow(/disposed/);
    element.remove();
    document.body.append(element);
    await Promise.resolve();
    expect(element.logicalOwner).toBeNull();
    expect(element.present).toBe(false);
  });

  it('keeps synchronous DOM moves alive, disposes settled disconnections, and does not revive explicitly disposed elements', async () => {
    const element = create(stateSource);
    document.body.appendChild(element);
    const firstOwner = element.logicalOwner;
    const stale = element.getExposes();
    stale.bump?.(5);
    element.remove();
    document.body.appendChild(element);
    await Promise.resolve();
    expect(element.logicalOwner).toBe(firstOwner);
    expect(stale.count?.get()).toBe(5);
    element.remove();
    await Promise.resolve();
    expect(element.logicalOwner).toBeNull();
    expect(() => stale.bump?.(8)).toThrow(/disposed/);
    document.body.appendChild(element);
    expect(element.logicalOwner).not.toBe(firstOwner);
    expect(element.getExposes().count?.get()).toBe(2);
    element.dispose();
    element.remove();
    document.body.appendChild(element);
    await Promise.resolve();
    expect(element.logicalOwner).toBeNull();
    expect(element.getExposes()).toEqual({});
  });

  it('does not route outward click/input signals back into raw or semantic input handlers', () => {
    const element = create(`import {definePrototype} from '@proto.ui/core';
      import {asTrigger} from '@proto.ui/hooks';
      export default definePrototype({name:'input-loopback',setup(def){
        asTrigger();
        const count=def.state.numberDiscrete('input.count',0);
        const inputs=def.state.numberDiscrete('input.inputs',0);
        def.expose.state('count',count);def.expose.state('inputs',inputs);
        def.expose.event('click');def.expose.event('input');
        def.event.on('host:click',()=>{count.set(count.get()+10);});
        def.event.on('input',()=>{inputs.set(inputs.get()+1);});
        def.event.on('press.commit',(run,event)=>{
          count.set(count.get()+1);
          run.expose.emit('click');run.expose.emit('input');
          event.control.requestDefaultActionPrevention();
        });
        return (r)=>r.el('output',count.get());
      }});`);
    document.body.appendChild(element);
    const outward: string[] = [];
    for (const type of ['click', 'input'])
      element.addEventListener(type, (event) => {
        if (event instanceof CustomEvent) outward.push(event.type);
      });
    expect(
      element.dispatchEvent(
        new MouseEvent('click', { button: 0, detail: 1, bubbles: true, cancelable: true })
      )
    ).toBe(false);
    expect(outward).toEqual(['click', 'input']);
    expect(element.getExposes().count?.get()).toBe(11);
    expect(element.getExposes().inputs?.get()).toBe(0);
    element.dispatchEvent(new Event('input', { bubbles: true }));
    expect(element.getExposes().inputs?.get()).toBe(1);
    expect(element.shadowRoot?.textContent).toBe('0');
  });

  it('publishes readonly focus facts, refreshes Root projections without rendering, and releases detached listeners', async () => {
    const element = create(`import {definePrototype,tw} from '@proto.ui/core';
      import {asTrigger,asFocusable,asAccessible} from '@proto.ui/hooks';
      export default definePrototype({name:'focus-view',setup(def){
        def.props.define({visible:{type:'boolean',default:true}});
        asTrigger();const focus=asFocusable();const focused=focus.focused;
        focus.configure({disabled:true});
        const accessible=asAccessible();accessible.role('button');accessible.state('selected',focused);
        def.feedback.style.use(tw('bg-white'));
        def.rule({when:(w)=>w.state(focused).eq(true),intent:(i)=>i.feedback.style.use(tw('bg-black'))});
        const count=def.state.numberDiscrete('focus.count',0);
        def.expose.state('count',count);def.expose.state('focused',focused);def.expose.state('focusable',focus.focusable);
        def.expose.method('disable',(next:boolean)=>{focus.setDisabled(next);});
        def.props.watch(['visible'],(run,next)=>{run.lifecycle.setPresent(next.visible);});
        def.event.on('press.commit',()=>{count.set(count.get()+1);});
        return (r)=>r.el('output',count.get());
      }});`);
    document.body.appendChild(element);
    const exposes = element.getExposes();
    const child = element.shadowRoot?.querySelector('output');
    const identity = element.logicalOwner;
    const facts: boolean[] = [];
    exposes.focused?.subscribe(({ next }) => facts.push(next));
    expect(exposes.focusable?.get()).toBe(false);
    expect(element.getAttribute('tabindex')).toBe('-1');
    expect(element.getAttribute('role')).toBe('button');
    exposes.disable?.(false);
    expect(exposes.focusable?.get()).toBe(true);
    element.dispatchEvent(new FocusEvent('focus'));
    expect(exposes.focused?.get()).toBe(true);
    expect(element.getAttribute('aria-selected')).toBe('true');
    expect(element.getAttribute('data-pui-style')).toBe('bg-black');
    await Promise.resolve();
    expect(element.shadowRoot?.querySelector('output')).toBe(child);
    expect(element.shadowRoot?.textContent).toBe('0');
    element.setProps({ visible: false });
    await Promise.resolve();
    expect(exposes.focused?.get()).toBe(false);
    expect(facts).toEqual([true, false]);
    expect(element.getAttribute('role')).toBeNull();
    element.dispatchEvent(new MouseEvent('click', { button: 0, detail: 1 }));
    expect(exposes.count?.get()).toBe(0);
    element.setProps({ visible: true });
    await Promise.resolve();
    element.remove();
    document.body.appendChild(element);
    await Promise.resolve();
    expect(element.logicalOwner).toBe(identity);
    element.dispatchEvent(new MouseEvent('click', { button: 0, detail: 1 }));
    expect(exposes.count?.get()).toBe(1);
    element.remove();
    await Promise.resolve();
    expect(() => exposes.focused?.get()).toThrow(/dispos/);
    expect(() => exposes.focused?.subscribe(() => {})).toThrow(/dispos/);
  });

  it('rejects an illegal portable semantic input type before producing native output', () => {
    const parsed = parsePrototype(`import {definePrototype} from '@proto.ui/core';
      export default definePrototype({name:'unsupported-input',setup(def){
        def.event.on('click', (run,event)=>{event.control.requestDefaultActionPrevention();});
      }});`);
    if (!parsed.ok) throw new Error(JSON.stringify(parsed.diagnostics));
    const rejected = emitWebComponentSource(parsed.value);
    expect(rejected).toMatchObject({
      ok: false,
      diagnostics: [{ code: 'PUI_NATIVE_INTERACTION_UNSUPPORTED', category: 'unsupported-input' }],
    });
    expect(emitWebComponentSource(parsed.value)).toEqual(rejected);
  });
});

describe('generated range accessibility facts', () => {
  it('projects updates and removes stale range attributes on view detach', async () => {
    const element = create(`import { definePrototype } from '@proto.ui/core';
      import { asAccessible } from '@proto.ui/hooks';
      export default definePrototype({ name: 'range-facts', setup(def) {
        const min = def.state.numberDiscrete('range.min', -10);
        const max = def.state.numberDiscrete('range.max', 10);
        const now = def.state.numberDiscrete('range.now', 0);
        const text = def.state.string('range.text', 'Zero');
        const accessible = asAccessible();
        accessible.role('slider');
        accessible.state('valueMin', min);
        accessible.state('valueMax', max);
        accessible.state('valueNow', now);
        accessible.state('valueText', text);
        def.expose.method('bump', (value: number) => { now.set(value); text.set(''); });
        return (renderer) => renderer.el('div', 'Range');
      }});`);
    document.body.append(element);
    await Promise.resolve();
    const target = element;
    expect(target.getAttribute('aria-valuemin')).toBe('-10');
    expect(target.getAttribute('aria-valuemax')).toBe('10');
    expect(target.getAttribute('aria-valuenow')).toBe('0');
    expect(target.getAttribute('aria-valuetext')).toBe('Zero');
    element.getExposes().bump!(5);
    await Promise.resolve();
    expect(target.getAttribute('aria-valuenow')).toBe('5');
    expect(target.hasAttribute('aria-valuetext')).toBe(false);
    element.remove();
    await Promise.resolve();
    expect(target.hasAttribute('aria-valuenow')).toBe(false);
  });
});

describe('generated tree positional accessibility', () => {
  it('projects positive logical depth and set membership from emitted source', async () => {
    const element = create(`import { definePrototype } from '@proto.ui/core';
      import { asAccessible } from '@proto.ui/hooks';
      export default definePrototype({ name: 'tree-facts', setup(def) {
        const level = def.state.numberDiscrete('tree.level', 2);
        const position = def.state.numberDiscrete('tree.position', 3);
        const size = def.state.numberDiscrete('tree.size', -1);
        const accessible = asAccessible();
        accessible.role('treeitem');
        accessible.state('level', level);
        accessible.state('posInSet', position);
        accessible.state('setSize', size);
        return (renderer) => renderer.el('span', 'Node');
      }});`);
    document.body.append(element);
    await Promise.resolve();
    expect(element.getAttribute('aria-level')).toBe('2');
    expect(element.getAttribute('aria-posinset')).toBe('3');
    expect(element.getAttribute('aria-setsize')).toBe('-1');
  });
});

describe('generated nullable current range value', () => {
  it('projects a numeric string and withdraws an indeterminate empty string', async () => {
    const element = create(`import { definePrototype } from '@proto.ui/core';
      import { asAccessible } from '@proto.ui/hooks';
      export default definePrototype({ name: 'nullable-range-value', setup(def) {
        const now = def.state.string('range.now', '-2.5');
        const accessible = asAccessible();
        accessible.role('progressbar');
        accessible.state('valueNow', now);
        def.expose.method('clear', () => { now.set(''); });
        return (renderer) => renderer.el('span', 'Progress');
      }});`);
    document.body.append(element);
    await Promise.resolve();
    expect(element.getAttribute('aria-valuenow')).toBe('-2.5');
    (element.getExposes() as { clear(): void }).clear();
    await Promise.resolve();
    expect(element.hasAttribute('aria-valuenow')).toBe(false);
  });
});

describe('generated search, navigation and sort accessibility', () => {
  it('projects finite states and withdraws invalid values in the emitted consumer', async () => {
    const element = create(`import { definePrototype } from '@proto.ui/core';
      import { asAccessible } from '@proto.ui/hooks';
      export default definePrototype({ name: 'search-sort-facts', setup(def) {
        const autocomplete = def.state.string('autocomplete', 'list');
        const current = def.state.string('current', 'page');
        const sort = def.state.string('sort', 'ascending');
        const accessible = asAccessible();
        accessible.state('autocomplete', autocomplete);
        accessible.state('current', current);
        accessible.state('sort', sort);
        def.expose.method('clear', () => { autocomplete.set('invalid'); current.set(''); sort.set('invalid'); });
        return (renderer) => renderer.el('span', 'Facts');
      }});`);
    document.body.append(element);
    await Promise.resolve();
    expect(element.getAttribute('aria-autocomplete')).toBe('list');
    expect(element.getAttribute('aria-current')).toBe('page');
    expect(element.getAttribute('aria-sort')).toBe('ascending');
    (element.getExposes() as { clear(): void }).clear();
    await Promise.resolve();
    for (const key of ['autocomplete', 'current', 'sort'])
      expect(element.hasAttribute(`aria-${key}`)).toBe(false);
  });
});
