import { emitCapturedWebOperation } from './capture-effects';
import { pruneDeadValues } from './demand-pruning';
import {
  nativePublicCallsArtifact,
  nativeAuthoredCallablesArtifact,
  hasPublicCallable,
  emitPublicValue,
  emitPublicMethodProjection,
} from './native-public-values';
import { nativeHostAtomPlan, emitNativeHostAtom, type NativeHostAtomPlan } from './native-async';
import {
  nativeAuthoredHooksArtifact,
  emitAuthoredHookDefinition,
  emitPrivilegedHookCall,
} from './native-authored-hooks';
import {
  createJavaScriptValueReader,
  planJavaScriptCallBoundaries,
  emitJavaScriptMember,
  emitJavaScriptRecord,
  emitJavaScriptValue,
  emitJavaScriptParameters,
  emitUninvokedJavaScriptFunction,
  formatJavaScriptValueType,
  emitOptionalOperation,
} from './native-value-lowering';
import { emitRecordedNotification, emitNotificationDrain } from './notification-plan';
import { observableSemantics } from './observable-semantics';
import { emitUndeclaredInstanceAssociations } from './native-instance-associations';
import {
  unsupportedControlLabel,
  unsupportedControlLabelAnatomy,
  unsupportedPointerFacts,
} from './pointer-facts-admission';
import {
  nativeShape,
  NativeLexicalScope,
  moduleLexicalScope,
  type NativeShape,
} from './template-shape';
import { partitionModuleBindings } from './source-module-bindings';
import { dataTypeEqual, formatDataType } from './data-types';
import { isDataValueType } from './ir';
import { validateIR, validIdentifier } from './ir-validation';
import { FOCUS_OPTIONS_TYPE, OPERATION_RULES } from './operations';
import { checkTargetOperations, resolveTargetProfile } from './targets';
import { buildNativeContextArtifacts, emitNativeContextValidation } from './native-context';
import { emitNativeStyleHandle, emitNativeRule, nativeStyleArtifact } from './native-style';
import { nativeSupportArtifacts, planNativeSupport } from './native-interaction';
import { buildNativeStaticDeclarations } from './native-static-declarations';
import {
  ssrStyleDependencies,
  ssrStyleEnvironmentError,
  type SsrStyleEnvironment,
} from './web-component-ssr-style';
import { webComponentSsrSupport } from './web-component-ssr-support';
import { webComponentBrowserSupport } from './web-component-browser-support';
import { createHash } from 'node:crypto';
import { renderProtoStyleTokenCss } from '../../cli/src/services/proto-style-css';
import type {
  CompileResult,
  ExpressionIR,
  FunctionIR,
  ParameterIR,
  GeneratedModule,
  PrototypeIR,
  StatementIR,
  ValueType,
} from './ir';

const SUPPORTED: Record<string, true> = {
  'run.update': true,
  'render.read.props.get': true,
  'props.define': true,
  'props.setDefaults': true,
  'props.watch': true,
  'props.get': true,
  'props.watchAll': true,
  'props.watchRaw': true,
  'props.watchRawAll': true,
  'props.getRaw': true,
  'props.isProvided': true,
  'render.read.props.getRaw': true,
  'render.read.props.isProvided': true,
  'state.bool': true,
  'state.string': true,
  'state.numberDiscrete': true,
  'state.numberRange': true,
  'state.get': true,
  'state.set': true,
  'expose.state': true,
  'expose.event': true,
  'expose.method': true,
  'expose.emit': true,
  'lifecycle.setPresent': true,
  'lifecycle.onCreated': true,
  'lifecycle.onMounted': true,
  'lifecycle.onUpdated': true,
  'lifecycle.onUnmounted': true,
  'lifecycle.onBeforeDispose': true,
  'render.el': true,
  'render.slot': true,
  'context.provide': true,
  'context.subscribe': true,
  'context.trySubscribe': true,
  'context.read': true,
  'context.tryRead': true,
  'context.update': true,
  'context.tryUpdate': true,
  'render.read.context.read': true,
  'render.read.context.tryRead': true,
  'feedback.style.use': true,
  'feedback.style.release': true,
  'feedback.style.patch': true,
  'feedback.style.suppress': true,
  'feedback.style.clearPatch': true,
  'rule.dispose': true,
  'hook.asTrigger': true,
  'hook.asFocusable': true,
  'hook.asAccessible': true,
  'event.on': true,
  'event.onGlobal': true,
  'event.requestDefaultActionPrevention': true,
  'eventControl.requestDefaultActionPrevention': true,
  'focus.configure': true,
  'focus.setDisabled': true,
  'focus.focusSelf': true,
  'accessible.state': true,
  'accessible.action': true,
  'accessible.role': true,
  'accessible.nameFromContent': true,
};

/** Direct native DOM source. The emitted helper kernel owns resources; it never interprets IR. */
export function emitWebComponentSource(
  input: PrototypeIR,
  options: {
    className?: string;
    tagName?: string;
    ssr?: boolean;
    /** Internal hydration experiment; public SSR profile admission remains disabled. */
    controlLabelHydration?: 'client-only';
    shadow?: boolean;
    propsUpdatePolicy?: import('./observable-semantics').PropsUpdatePolicy;
    styleEnvironment?: SsrStyleEnvironment;
  } = {}
): CompileResult<GeneratedModule> {
  const checked = validateIR(input);
  if (!checked.ok) return checked;
  const ir = pruneDeadValues(checked.value);
  const readValue = createJavaScriptValueReader(ir, typeName);
  const callBoundaries = planJavaScriptCallBoundaries(ir);
  const moduleParts = partitionModuleBindings(
    ir,
    undefined,
    (value) => value.kind === 'call' && callBoundaries.calls.has(value)
  );
  if (
    options.controlLabelHydration !== undefined &&
    (!options.ssr || options.controlLabelHydration !== 'client-only')
  )
    return {
      ok: false,
      diagnostics: [
        {
          code: 'PUI3301',
          category: 'unsupported-input',
          message:
            'The client-only ControlLabel hydration option requires the explicit internal SSR experiment.',
          span: ir.setup.span,
        },
      ],
    };
  const clientOnlyControlLabel = options.controlLabelHydration === 'client-only';
  if (options.ssr) {
    const controlLabelDiagnostics = clientOnlyControlLabel
      ? unsupportedControlLabelAnatomy(ir, 'web-component-source client-only hydration')
      : unsupportedControlLabel(ir, 'web-component-source SSR');
    if (controlLabelDiagnostics.length) return { ok: false, diagnostics: controlLabelDiagnostics };
    const pointerDiagnostics = unsupportedPointerFacts(ir, 'web-component-source SSR');
    if (pointerDiagnostics.length) return { ok: false, diagnostics: pointerDiagnostics };
  }
  const selected = resolveTargetProfile('web-component-source-v1');
  if (!selected.ok) return selected;
  const admitted = checkTargetOperations(ir, selected.value);
  if (!admitted.ok) return admitted;
  const supportPlan = planNativeSupport(ir, admitted.value, {
    ownership: admitted.value.operations.includes('expose.emit'),
  });
  const eventSupport = supportPlan.features.includes('event');
  const controlLabel = admitted.value.operations.includes('hook.asControlLabel');
  const reachedFunctions = new Set(admitted.value.functions);
  const reachedHooks = new Set(admitted.value.authoredHooks);
  const interacting =
    ir.moduleDeclarations.length > 0 ||
    admitted.value.operations.some((operation) =>
      /^(hook\.|event\.|focus\.|accessible\.|anatomy\.)/.test(operation)
    );
  const outwardEvents = admitted.value.operations.includes('expose.emit');
  const interactionArtifact = interacting || outwardEvents;
  const className = options.className ?? 'CompiledElement';
  const tagName = options.tagName ?? 'pui-compiled-element';
  const profile = options.ssr ? 'web-component-ssr-v1' : 'web-component-source-v1';
  const reject = (message: string, span = ir.setup.span): CompileResult<GeneratedModule> => ({
    ok: false,
    diagnostics: [{ code: 'PUI3301', category: 'unsupported-input', message, span }],
  });
  if (
    !validIdentifier(className) ||
    [
      'GeneratedProps',
      'GeneratedExposes',
      'register',
      'HTMLElement',
      'Node',
      'ShadowRoot',
      'CustomElementRegistry',
      'CustomEvent',
      'customElements',
      'queueMicrotask',
      'Object',
      'Number',
      'Array',
      'Set',
      'Map',
      'Symbol',
      'Error',
      'Math',
      'String',
      'Function',
      'Readonly',
      'Record',
      'Partial',
      'undefined',
    ].includes(className) ||
    (options.ssr &&
      [
        'createHydrationOwner',
        'assertNoInstanceAssociations',
        'validateNativeInstanceAssociations',
        'hydrationBinding',
        'hydrationArtifacts',
        'hydrationCssText',
        'hydrationEnvironmentCssText',
        'checkInitialProps',
        'checkStylesheet',
        'checkCarrierHost',
        'defaultTagName',
        'HydrationOwner',
        'Carrier',
        'BrowserPort',
        'HostPort',
        'Presentation',
        'HydrationMismatch',
        'AggregateError',
        'createBrowserPort',
        'readCarrier',
        'checkCarrier',
        'decodeRaw',
        'pendingProviderDefinition',
        'hydrate',
        'renderToString',
        'renderWithScope',
      ].includes(className))
  ) {
    return reject('Choose a valid, non-reserved custom element class identifier.');
  }
  if (
    !/^[a-z][a-z0-9._-]*-[a-z0-9._-]+$/.test(tagName) ||
    [
      'annotation-xml',
      'color-profile',
      'font-face',
      'font-face-src',
      'font-face-uri',
      'font-face-format',
      'font-face-name',
      'missing-glyph',
    ].includes(tagName)
  ) {
    return reject('Choose a valid lowercase autonomous custom element tag name.');
  }
  const names = new Set<string>([className]);
  let styled = false;
  const cssTokens = new Set<string>();
  const unsupported: { message: string; span: PrototypeIR['setup']['span'] }[] = [];
  const scanned = new Set<object>();
  function scan(value: unknown): void {
    if (value && typeof value === 'object') {
      if (scanned.has(value)) return;
      scanned.add(value);
    }
    if (Array.isArray(value)) {
      for (const entry of value) {
        scan(entry);
        if (entry && typeof entry === 'object' && entry.kind === 'return') break;
      }
      return;
    }
    if (!value || typeof value !== 'object') return;
    const node = value as Record<string, unknown>;
    if (node.kind === 'function' && !reachedFunctions.has(node.function as FunctionIR)) return;
    if (node.kind === 'style-handle')
      for (const token of (node.handle as { tokens: string[] }).tokens) cssTokens.add(token);
    if (node.kind === 'rule')
      for (const op of (
        node.declaration as { intent: { ops: { handles: { tokens: string[] }[] }[] } }
      ).intent.ops)
        for (const handle of op.handles) for (const token of handle.tokens) cssTokens.add(token);
    if (
      node.kind === 'style-handle' ||
      node.kind === 'rule' ||
      (node.kind === 'operation' &&
        (String(node.operation).startsWith('feedback.style.') ||
          node.operation === 'feedback.material.shader'))
    )
      styled = true;
    if (node.kind === 'operation' && node.operation === 'render.el') {
      const args = node.arguments as ExpressionIR[];
      const tag = args[0];
      if (tag.kind === 'literal' && typeof tag.value === 'string' && tag.value.includes('-')) {
        unsupported.push({
          message:
            'web-component-source-v1 does not implement stable custom-element template child reconciliation; compose generated owners through native light DOM and slots.',
          span: tag.span,
        });
      }
      const props = args.length > 2 ? args[1] : args[1]?.kind === 'record' ? args[1] : undefined;
      if (
        props &&
        (props.kind !== 'record' ||
          props.entries.length > 1 ||
          props.entries.some(
            (entry) =>
              entry.key !== 'style' ||
              entry.value.type !== 'style-handle' ||
              !['style-handle', 'reference'].includes(entry.value.kind)
          ))
      ) {
        unsupported.push({
          message:
            'web-component-source-v1 supports only one static tw handle under TemplateProps.style.',
          span: props.span,
        });
      }
    }
    for (const [key, item] of Object.entries(node)) {
      if (key === 'name' && typeof item === 'string') names.add(item);
      scan(item);
    }
  }
  for (const reached of admitted.value.functions) {
    for (const parameter of reached.parameters) names.add(parameter.name);
    for (const statement of reached.body) {
      scan(statement);
      if (statement.kind === 'return') break;
    }
  }
  if (unsupported.length)
    return {
      ok: false,
      diagnostics: unsupported.map(({ message, span }) => ({
        code: 'PUI3302',
        category: 'unsupported-input',
        message,
        span,
      })),
    };
  let prefix = '__wc';
  while ([...names].some((name) => name.startsWith(prefix))) prefix += '_';
  const context = buildNativeContextArtifacts(ir);
  const staticDeclarations = buildNativeStaticDeclarations(
    ir.staticDeclarations,
    ir.moduleDeclarations
  );
  const staticNames = new Map<string, string>();
  let staticSequence = 0;
  const staticImports = [...staticDeclarations.capabilities]
    .map(([id, entry]) => {
      const name = `${prefix}Static${staticSequence++}`;
      staticNames.set(id, name);
      return `import { declaration as ${name} } from ${JSON.stringify('./' + entry.file.replace(/\.ts$/, ''))};`;
    })
    .join('\n');
  const keyNames = new Map(ir.contextKeys.map((key, index) => [key.id, `${prefix}Key${index}`]));
  const contextTypes = new Map(ir.contextKeys.map((key) => [key.id, formatDataType(key.type)]));
  const contextImports = context
    ? `import {createContextScope as ${prefix}CreateContextScope, ownerScopes as ${prefix}OwnerScopes, acceptsContextValue as ${prefix}Accepts, type ContextScope as ${prefix}ContextScope} from ${JSON.stringify(context.scopeFile.replace(/\.ts$/, ''))};\n${[...context.keys].map(([id, key]) => `import {key as ${keyNames.get(id)}} from ${JSON.stringify(key.file.replace(/\.ts$/, ''))};`).join('\n')}\n${interacting ? `import type { NativeModuleCapability as ${prefix}NativeModuleCapability } from './${supportPlan.modulesPath.slice(0, -3)}';\n` : ''}`
    : '';
  const contextValidation = context
    ? emitNativeContextValidation(ir, keyNames, `${prefix}Accepts`)
    : '';
  const atoms = nativeHostAtomPlan(
    admitted.value.operations,
    prefix,
    admitted.value.ruleMetaKeys,
    admitted.value.shaderKernels
  );
  const hasAuthoredHooks = admitted.value.authoredHooks.length > 0;
  const publicCalls =
    callBoundaries.calls.size > 0 ||
    ir.exposes.some(
      (entry) =>
        (entry.kind === 'value' && hasPublicCallable(entry.type)) ||
        (entry.kind === 'method' && hasPublicCallable(entry.returnType))
    );
  const hooks = new Map(ir.hooks.map((hook, index) => [hook.id, `${prefix}Hook${index}`]));
  function typeName(type: ValueType): string {
    const atom = atoms.typeName(type, `${prefix}Run`);
    if (atom) return atom;
    if (typeof type === 'string' && type.startsWith('lexical:')) return type.slice(8);
    if (typeof type !== 'string' && !isDataValueType(type))
      return formatJavaScriptValueType(type, typeName);
    if (type === 'context-key')
      return "{readonly __brand: 'ContextKey'; readonly debugName?: string}";
    if (type === 'exception' || type === 'unknown') return 'unknown';
    if (typeof type !== 'string') return formatJavaScriptValueType(type, typeName);
    if (isDataValueType(type))
      return interacting && dataTypeEqual(type, FOCUS_OPTIONS_TYPE)
        ? `${prefix}NativeFocusOptions`
        : formatDataType(type);
    if (typeof type === 'string' && type.startsWith('nullable:'))
      return `${typeName(type.slice(9) as ValueType)} | null`;
    if (typeof type === 'string' && type.startsWith('optional:'))
      return `${typeName(type.slice(9) as ValueType)} | undefined`;
    if (
      !interacting &&
      (['focus', 'accessible', 'event', 'event-control', 'event-or-control'].includes(type) ||
        type.startsWith('observed:'))
    )
      return 'unknown';
    if (!styled && ['style-handle', 'rule-handle', 'template-props'].includes(type))
      return 'unknown';
    if (type.startsWith('borrowed:'))
      return `${prefix}State<${type.slice(9)}> & {watch(callback: (run: ${prefix}Run, event: {type:'next';prev:${type.slice(9)};next:${type.slice(9)};reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}`;
    if (type.startsWith('state-event:') || type.startsWith('state-next:'))
      return `{type:'next';prev:${type.split(':')[1]};next:${type.split(':')[1]};reason?:unknown}${type.startsWith('state-event:') ? "|{type:'disconnect';reason:'unmount'}" : ''}`;
    if (type === 'state-disconnect') return `{type:'disconnect';reason:'unmount'}`;
    if (type === 'def') return `${prefix}Def`;
    if (type === 'run') return `${prefix}Run`;
    if (type === 'render') return `${prefix}Renderer`;
    if (!options.ssr && type === 'template') return '(()=>Node)';
    if (type.startsWith('state:')) return `${prefix}State<${type.slice(6)}>`;
    if (type.startsWith('observed:')) return `${prefix}NativeObservedState<${type.slice(9)}>`;
    if (type === 'focus') return `${prefix}NativeFocus`;
    if (type === 'accessible') return `${prefix}NativeAccessible`;
    if (type === 'event') return `${prefix}NativeInput`;
    if (type === 'event-control') return `${prefix}NativeInput['control']`;
    if (type === 'event-or-control')
      return `(${prefix}NativeInput | ${prefix}NativeInput['control'])`;
    if (type === 'host-event') return 'Event';
    if (type === 'props') return `${prefix}PropsSnapshot`;
    if (type === 'record') return 'Record<string, unknown>';
    if (type === 'array') return 'unknown[]';
    if (type === 'style-handle') return `${prefix}NativeStyleHandle`;
    if (type === 'rule-handle') return `${prefix}NativeRuleHandle`;
    return interacting
      ? `${prefix}NativeModuleCapability<${JSON.stringify(type)}, ${prefix}Run>`
      : 'unknown';
  }
  // Lexical shape information stays in the compiler; it is never delivered as IR.
  let nativeScope = moduleLexicalScope(ir);
  let nativeSequence = 0;
  function nativeBinding(name: string): ExpressionIR | undefined {
    return nativeScope.lookup(name)?.value;
  }
  function appendShape(shape: NativeShape, value: string, parent: string, frame: string): string {
    if (shape.kind === 'node' || shape.kind === 'legacy-template')
      return `${parent}.appendChild((${value} as ()=>Node)());`;
    if (shape.kind === 'text')
      return `${parent}.appendChild(${frame}.document.createTextNode(String(${value})));`;
    if (shape.kind === 'null') return '';
    if (shape.kind === 'invalid' || shape.kind === 'undefined')
      return `throw new TypeError('Invalid template child');`;
    if (shape.kind === 'array') {
      const item = `${prefix}Item${nativeSequence++}`;
      return `for(const ${item} of (${value} as unknown[])){${appendShape({ kind: 'union', items: shape.items }, item, parent, frame)}}`;
    }
    if (shape.kind !== 'union') throw new Error('Unknown native construction shape');
    const flattened: NativeShape[] = [];
    const flatten = (item: NativeShape) => {
      if (item.kind === 'union') item.items.forEach(flatten);
      else flattened.push(item);
    };
    shape.items.forEach(flatten);
    const kinds = new Set(flattened.map((item) => item.kind));
    const clauses: string[] = [];
    if (kinds.has('node') || kinds.has('legacy-template'))
      clauses.push(
        `if(typeof ${value}==='function'){${appendShape({ kind: 'node' }, value, parent, frame)}}`
      );
    if (kinds.has('text'))
      clauses.push(
        `if(typeof ${value}==='string'||typeof ${value}==='number'){${appendShape({ kind: 'text' }, value, parent, frame)}}`
      );
    if (kinds.has('null')) clauses.push(`if(${value}===null){}`);
    const arrays = flattened.filter(
      (item): item is Extract<NativeShape, { kind: 'array' }> => item.kind === 'array'
    );
    if (arrays.length)
      clauses.push(
        `if(Array.isArray(${value})){${appendShape({ kind: 'array', items: arrays.flatMap((item) => item.items) }, value, parent, frame)}}`
      );
    // Each branch follows a finite statically inferred union; no tag/IR or unknown
    // recursive Template tree is passed to a general runtime dispatcher.
    return clauses.length
      ? clauses.join(' else ') + ` else {throw new TypeError('Invalid template child');}`
      : `throw new TypeError('Invalid template child');`;
  }
  function nativeAppend(
    expression: ExpressionIR | undefined,
    value: string,
    parent: string,
    frame: string
  ): string {
    if (!expression) return `throw new TypeError('Invalid template child');`;
    const shape = nativeShape(expression, nativeScope);
    if (!shape)
      throw new Error(
        `WC native candidate: unresolved ${expression.kind}/${JSON.stringify(expression.type)} at ${expression.span.line}`
      );
    return appendShape(shape, value, parent, frame);
  }
  function nativeElement(
    node: Extract<ExpressionIR, { kind: 'operation' }>,
    depth: number
  ): string {
    const receiver = `${prefix}Receiver${nativeSequence++}`,
      tag = `${prefix}Tag${nativeSequence++}`;
    const a = `${prefix}Arg${nativeSequence++}`,
      b = `${prefix}Arg${nativeSequence++}`,
      element = `${prefix}Element${nativeSequence++}`;
    const args = node.arguments;
    const props =
      args.length > 2
        ? args[1]
        : args[1]?.type === 'template-props' ||
            (typeof args[1]?.type === 'object' &&
              args[1].type.kind === 'record' &&
              args[1].type.fields.length === 0)
          ? args[1]
          : undefined;
    const child = args.length > 2 ? args[2] : props ? undefined : args[1];
    const value = args.length > 2 ? b : a;
    const style = props?.type === 'template-props';
    const tokens = `${prefix}Tokens${nativeSequence++}`;
    return `((${receiver}: ${prefix}Renderer, ${tag}: string, ${a}?: unknown, ${b}?: unknown) => {
      if(!/^[A-Za-z][A-Za-z0-9:_-]*$/.test(${tag}))throw new TypeError('Invalid template tag');
      ${style ? `const ${tokens}=${prefix}TemplateStyleTokens((${a} as {style:${prefix}NativeStyleHandle}).style);` : ''}
      return () => {const ${element}=${receiver}.nativeFrame.document.createElement(${tag});
        ${style ? `${element}.setAttribute('data-pui-style',${tokens});` : ''}
        ${child ? nativeAppend(child, `(${value} as ${child.type === 'template' ? '()=>Node' : child.kind === 'array' ? 'unknown[]' : child.type === 'string' ? 'string' : child.type === 'number' ? 'number' : 'unknown'})`, element, `${receiver}.nativeFrame`) : ''}
        return ${element};};
    })(${expr(node.receiver!, depth)}, ${args.map((arg) => expr(arg, depth)).join(', ')})`;
  }

  function parameters(values: readonly ParameterIR[]): string {
    return emitJavaScriptParameters(values, (value) => expr(value, 0), typeName);
  }

  function fn(node: FunctionIR, depth: number): string {
    if (!reachedFunctions.has(node)) return emitUninvokedJavaScriptFunction(node);
    const savedNativeScope = nativeScope;
    for (const parameter of node.parameters)
      nativeScope = nativeScope.bind(parameter.name, {
        kind: 'reference',
        name: '\0formal-' + parameter.name,
        type: parameter.type,
        span: node.span,
      });
    try {
      // Render-context callbacks may omit their unused renderer. Explicitly
      // typed renderer helpers also retain their native TemplateChildren path.
      const implicitRenderer =
        !options.ssr && node.context === 'render' && node.parameters.length === 0
          ? `${prefix}RendererArgument${nativeSequence++}`
          : undefined;
      const renderer =
        !options.ssr && (node.context === 'render' || node.parameters[0]?.type === 'render')
          ? (node.parameters[0]?.name ?? implicitRenderer)
          : undefined;
      const nativeParameters = implicitRenderer
        ? `${implicitRenderer}: ${prefix}Renderer`
        : emitJavaScriptParameters(node.parameters, (item) => expr(item, depth), typeName);
      const callable = `(${nativeParameters})${node.context === 'helper' && !['function', 'unknown', 'template'].includes(node.returnType as string) ? `: ${typeName(node.returnType)}` : ''} => {\n${statements(node.body, depth + 1, renderer)}${renderer ? `${'  '.repeat(depth + 1)}return ${renderer}.nativeFrame.document.createDocumentFragment();\n` : ''}${'  '.repeat(depth)}}`;
      return callBoundaries.authored.has(node)
        ? `${prefix}MarkAuthoredCallable(${callable})`
        : callable;
    } finally {
      nativeScope = savedNativeScope;
    }
  }

  function expr(node: ExpressionIR, depth: number, captureEffects = true): string {
    if (hasAuthoredHooks && captureEffects) {
      if (node.kind === 'operation') {
        const captured = emitCapturedWebOperation({
          value: node,
          prefix: prefix,
          manager: `${prefix}Authored`,
          interaction: `${prefix}Interaction`,
          emit: (item, capture = true) => expr(item, depth, capture),
          declaration: (_item, name, initializer, argumentIndex) => {
            const type =
              node.operation === 'props.define' && argumentIndex === 0
                ? `Parameters<typeof ${prefix}CaptureReceiver.props.define>[0]`
                : undefined;
            return `const ${name}${type ? `: ${type}` : ''} = ${initializer};`;
          },
        });
        if (captured !== undefined) return captured;
      }
      if (node.kind === 'rule') return `${prefix}Authored.rule(${expr(node, depth, false)})`;
    }
    switch (node.kind) {
      case 'narrow':
      case 'member-write':
      case 'element':
      case 'conditional':
      case 'call':
      case 'intrinsic':
      case 'object-spread':
        return emitJavaScriptValue(node, (item) => expr(item, depth), typeName, true, {
          plan: callBoundaries,
          wrap: `${prefix}WrapPublic`,
          prefix: prefix,
          isAuthored: `${prefix}IsAuthoredCallable`,
        })!;
      case 'undefined':
        return '(void 0)';
      case 'literal':
        return JSON.stringify(node.value);
      case 'reference':
        return readValue(node, node.name);
      case 'lexical-cell':
        return expr(node.value, depth);
      case 'lexical-read':
        return readValue(node, expr(node.cell, depth));
      case 'lexical-write':
        return `(${expr(node.cell, depth)} = ${expr(node.value, depth)})`;
      case 'lexical-update': {
        const cell = expr(node.cell, depth),
          operator = node.delta === 1 ? '++' : '--';
        return `(${node.prefix ? operator + cell : cell + operator})`;
      }
      case 'context-key':
        return `(${keyNames.get(node.keyId)} as ${prefix}ContextKey<${contextTypes.get(node.keyId)}>)`;
      case 'style-handle':
        return emitNativeStyleHandle(node.handle);
      case 'rule':
        return emitNativeRule(
          node,
          (value) => expr(value, depth),
          `${prefix}Style`,
          `${prefix}OwnerProps()`
        );
      case 'member':
        return emitJavaScriptMember(node, (item) => expr(item, depth), typeName, true, readValue);
      case 'unary':
        return `(${node.operator}${expr(node.operand, depth)})`;
      case 'binary':
        return `(${expr(node.left, depth)} ${node.operator} ${expr(node.right, depth)})`;
      case 'array':
        return `[${node.elements.map((value) => expr(value, depth)).join(', ')}]`;
      case 'record':
        return emitJavaScriptRecord(node, (item) => expr(item, depth), typeName);
      case 'function':
        return fn(node.function, depth);
      case 'helper-call':
        return `${node.name}(${node.arguments.map((value) => expr(value, depth)).join(', ')})`;
      case 'authored-hook':
        return `${hooks.get(node.hookId)}(${(node.arguments ?? []).map((item) => expr(item, depth)).join(', ')})`;
      case 'static-capability':
        return staticNames.get(node.declarationId)!;
      case 'operation': {
        const optional = emitOptionalOperation(
          node,
          (item) => expr(item, depth),
          `${prefix}OptionalReceiver`,
          typeName
        );
        if (optional !== undefined) return optional;
        const atom = emitNativeHostAtom(node, (item) => expr(item, depth), prefix);
        if (atom !== undefined) return atom;
        if (hasAuthoredHooks && node.operation.startsWith('hook.'))
          return emitPrivilegedHookCall({
            value: node,
            manager: `${prefix}Authored`,
            callee: `${prefix}Interaction.${OPERATION_RULES[node.operation].path}`,
            prefix: prefix,
            emit: (item) => expr(item, depth),
            typeName,
            typed: true,
          });
        if (node.operation === 'expose.value' && hasPublicCallable(node.arguments[1].type))
          return `${expr(node.receiver!, depth)}.expose.value(${expr(node.arguments[0], depth)}, ${emitPublicValue({ value: expr(node.arguments[1], depth), type: node.arguments[1].type, wrap: `${prefix}WrapPublic`, prefix: prefix, typeName, typed: true })})`;
        if (node.operation === 'expose.method') {
          const projection = emitPublicMethodProjection(node.arguments[1].type, {
            wrap: `${prefix}WrapPublic`,
            prefix: prefix,
            typeName,
            typed: true,
          });
          if (projection)
            return `${expr(node.receiver!, depth)}.expose.method(${node.arguments.map((item) => expr(item, depth)).join(', ')}, ${projection})`;
        }
        if (node.operation.startsWith('capture.'))
          return `(${expr(node.receiver!, depth)}.${OPERATION_RULES[node.operation].path}?.(${node.arguments.map((item) => expr(item, depth)).join(', ')}) as ${typeName(node.type)})`;
        if (!options.ssr && node.operation === 'render.el') return nativeElement(node, depth);
        const args = node.arguments.map((value) => expr(value, depth)).join(', ');
        if (node.operation === 'state.get')
          return `(${expr(node.receiver!, depth)}.get() as ${typeName(node.type)})`;
        if (OPERATION_RULES[node.operation].path === 'call')
          return `${expr(node.receiver!, depth)}(${args})`;
        if (node.operation.startsWith('hook.') || node.operation.startsWith('anatomy.'))
          return `${prefix}Interaction.${OPERATION_RULES[node.operation].path}(${args})`;
        if (
          [
            'context.read',
            'context.tryRead',
            'render.read.context.read',
            'render.read.context.tryRead',
          ].includes(node.operation)
        )
          return `(${expr(node.receiver!, depth)}.${OPERATION_RULES[node.operation].path}(${args}) as ${typeName(node.type)})`;
        return `${expr(node.receiver!, depth)}.${OPERATION_RULES[node.operation].path}(${args})`;
      }
    }
  }
  function statements(
    body: readonly StatementIR[],
    depth: number,
    nativeRenderer?: string
  ): string {
    const indent = '  '.repeat(depth);
    const terminator = body.findIndex(
      (statement) => statement.kind === 'return' || statement.kind === 'throw'
    );
    const deadBindings = new Set<string>();
    return body
      .slice(0, terminator < 0 ? body.length : terminator + 1)
      .map((statement) => {
        const sourceFile = JSON.stringify(statement.span.file)
          .replaceAll('\u2028', '\\u2028')
          .replaceAll('\u2029', '\\u2029');
        const origin = `${indent}// Source ${sourceFile}:${statement.span.line}:${statement.span.column}\n`;
        switch (statement.kind) {
          case 'const':
            nativeScope = nativeScope.bind(statement.name, statement.value);
            return `${origin}${indent}${statement.value.kind === 'lexical-cell' ? 'let' : 'const'} ${statement.name}${['lexical-cell', 'record', 'object-spread', 'array'].includes(statement.value.kind) ? `: ${typeName(statement.value.type)}` : ''} = ${expr(statement.value, depth)};\n`;
          case 'effect':
            return `${origin}${indent}${expr(statement.expression, depth)};\n`;
          case 'return':
            if (nativeRenderer) {
              const output = `${prefix}Output${nativeSequence++}`,
                fragment = `${prefix}Fragment${nativeSequence++}`;
              const frame = `${nativeRenderer}.nativeFrame`;
              return `${origin}${indent}const ${output}=${statement.value ? expr(statement.value, depth) : 'undefined'};\n${indent}const ${fragment}=${frame}.document.createDocumentFragment();\nif(${output}!==undefined){${nativeAppend(statement.value, output, fragment, frame)}}\n${indent}return ${fragment};\n`;
            }
            return `${origin}${indent}return${statement.value ? ` ${expr(statement.value, depth)}` : ''};\n`;
          case 'throw':
            return `${origin}${indent}throw ${expr(statement.value, depth)};\n`;
          case 'try': {
            const branch = (items: readonly StatementIR[], name?: string) => {
              const saved = nativeScope;
              try {
                if (name) nativeScope = nativeScope.parameter(name, undefined, nativeScope, null);
                return statements(items, depth + 1, nativeRenderer);
              } finally {
                nativeScope = saved;
              }
            };
            return `${origin}${indent}try {\n${branch(statement.body)}${indent}}${statement.catch ? ` catch${statement.catch.name ? ` (${statement.catch.name})` : ''} {\n${branch(statement.catch.body, statement.catch.name)}${indent}}` : ''}${statement.finally ? ` finally {\n${branch(statement.finally)}${indent}}` : ''}\n`;
          }
          case 'if': {
            const branch = (body: readonly StatementIR[]) => {
              const savedNativeScope = nativeScope;
              try {
                return statements(body, depth + 1, nativeRenderer);
              } finally {
                nativeScope = savedNativeScope;
              }
            };
            return `${origin}${indent}if (${expr(statement.condition, depth)}) {\n${branch(statement.then)}${indent}}${statement.otherwise.length ? ` else {\n${branch(statement.otherwise)}${indent}}` : ''}\n`;
          }
        }
      })
      .join('');
  }
  const hookCode =
    statements(moduleParts.owned, 2) +
    ir.hooks
      .filter((hook) => reachedHooks.has(hook.id))
      .map(
        (hook) =>
          '    ' +
          emitAuthoredHookDefinition({
            hook,
            name: hooks.get(hook.id)!,
            manager: `${prefix}Authored`,
            def: `${prefix}Def`,
            emit: (value) => fn(value, 2),
            typeName,
          })
      )
      .join('\n');
  const props = ir.props
    .map((prop) => `  ${JSON.stringify(prop.name)}?: ${typeName(prop.type)} | null;`)
    .join('\n');
  const resolvedProps = ir.props
    .map((prop) => `  readonly ${JSON.stringify(prop.name)}: ${typeName(prop.type)};`)
    .join('\n');
  const exposes = ir.exposes
    .filter((entry) => entry.kind !== 'event')
    .map((entry) => {
      const type =
        entry.kind === 'state'
          ? `${prefix}ExternalState<${entry.type}>`
          : entry.kind === 'value'
            ? typeName(entry.type)
            : `(${entry.parameters.map((parameter) => `${parameter.name}${parameter.optional ? '?' : ''}: ${typeName(parameter.type)}`).join(', ')}) => ${typeName(entry.returnType)}`;
      return `  ${JSON.stringify(entry.name)}: ${type};`;
    })
    .join('\n');
  if (options.ssr) {
    // This remains an internal experiment: public profile admission stays in targets.ts.
    // The existing CSS renderer supplies the exact same static rules before and after adoption.
    const cssText = renderProtoStyleTokenCss([...cssTokens].sort());
    if (cssText.includes('Unsupported Proto UI style tokens:'))
      return reject(
        'SSR requires a complete CSS artifact; one or more authored tokens have no CSS lowering.'
      );
    const environment = options.styleEnvironment;
    if (
      environment &&
      (!/^[a-z][a-z0-9-]*$/.test(environment.id) || typeof environment.cssText !== 'string')
    )
      return reject('SSR stylesheet environment requires a named canonical CSS artifact.');
    const environmentError = environment ? ssrStyleEnvironmentError(environment.cssText) : null;
    if (environmentError)
      return reject('Unsupported closed SSR stylesheet environment: ' + environmentError + '.');
    const styleDependencies = ssrStyleDependencies(cssText, environment?.cssText);
    if (styleDependencies.invalid.length)
      return reject(
        'Unsupported SSR stylesheet dependency syntax: ' +
          styleDependencies.invalid.join(', ') +
          '.'
      );
    if (styleDependencies.cyclic.length)
      return reject(
        'SSR stylesheet environment has cyclic custom property dependencies: ' +
          styleDependencies.cyclic.join(', ') +
          '.'
      );
    if (styleDependencies.missing.length)
      return reject(
        'SSR stylesheet environment must declare: ' +
          styleDependencies.missing.join(', ') +
          '. The consumer owns these values.'
      );
    const hash = (value: string) => createHash('sha256').update(value).digest('hex');
    const helpers = [
      ...atoms.files,
      ...(publicCalls ? [nativePublicCallsArtifact] : []),
      ...(callBoundaries.authored.size ? [nativeAuthoredCallablesArtifact] : []),
      ...(hasAuthoredHooks ? [nativeAuthoredHooksArtifact] : []),
      ...context.files,
      ...staticDeclarations.files,
      ...(styled ? [nativeStyleArtifact] : []),
      ...nativeSupportArtifacts(supportPlan),
    ];
    const ownerCode = nativeHelpers(
      prefix,
      contextValidation,
      styled,
      interacting,
      eventSupport,
      outwardEvents,
      true,
      JSON.stringify(ir.moduleDeclarations.map(({ id, config }) => ({ id, config }))),
      staticNames.get('@proto.ui/module-table-structure#TABLE_STRUCTURE_FAMILY') ?? 'undefined',
      false,
      atoms,
      hasAuthoredHooks,
      publicCalls,
      controlLabel
    );
    const binding = '__PUI_SSR_ARTIFACT_BINDING__';
    const artifacts = {
      source: ir.source.sha256,
      helpers: hash(
        JSON.stringify(helpers) +
          ownerCode +
          JSON.stringify(
            webComponentSsrSupport({ className, tagName, binding: '', supportPlan, controlLabel })
              .files
          )
      ),
      css: hash(cssText),
      environment: environment ? hash(environment.cssText) : '',
    };
    const imports = `${atoms.imports}
${controlLabel ? `import {validateNativeInstanceAssociations as ${prefix}ValidateAssociations} from './.proto-ui/interaction/control-label-v1';` : ''}
${publicCalls ? `import { createNativePublicCalls as ${prefix}CreatePublicCalls } from './.proto-ui/owner/public-callables-v1';` : ''}
${callBoundaries.authored.size ? `import { markNativeAuthoredCallable as ${prefix}MarkAuthoredCallable, isNativeAuthoredCallable as ${prefix}IsAuthoredCallable } from './.proto-ui/owner/authored-callables-v1';` : ''}\n${hasAuthoredHooks ? `import { createNativeAuthoredHooks as ${prefix}CreateAuthored } from './.proto-ui/owner/authored-hooks-v1';` : ''}\n${contextImports}${styled ? `import {createNativeStyle as ${prefix}CreateNativeStyle, templateStyleTokens as ${prefix}TemplateStyleTokens, type NativeStyle as ${prefix}Style, type NativeStyleHandle as ${prefix}NativeStyleHandle, type NativeRuleHandle as ${prefix}NativeRuleHandle} from './.proto-ui/style/native-v1';\n` : ''}${
      interacting
        ? `import type {NativeInteraction as ${prefix}NativeInteraction, NativeFocus as ${prefix}NativeFocus, NativeAccessible as ${prefix}NativeAccessible, NativeObservedState as ${prefix}NativeObservedState, NativeInput as ${prefix}NativeInput, NativeFocusOptions as ${prefix}NativeFocusOptions} from './${supportPlan.interactionPath.slice(0, -3)}';
\n`
        : ''
    }`;
    const support = webComponentSsrSupport({
      className,
      tagName,
      binding,
      artifacts,
      cssText,
      supportPlan,
      environmentCssText: environment?.cssText,
      controlLabel,
    });
    const code = `// web-component-ssr-v1: direct semantic statements; no browser globals at module evaluation.
// Helper cost: guarded owner, presentation serialization/adoption, per-request Context and AX intent.
${imports}${support.imports}
${staticImports}
${statements(moduleParts.shared, 0)}
export type GeneratedProps = {\n${props}\n};
const ${prefix}PropTypes = ${JSON.stringify(Object.fromEntries(ir.props.map((prop) => [prop.name, prop.type])))};
type ${prefix}PropsSnapshot = {\n${resolvedProps}\n};
export type GeneratedExposes = {\n${exposes}\n};
${ownerCode}
export type HydrationOwner = ${prefix}Owner;
export function createHydrationOwner(port: HostPort, raw: Record<string, unknown>${controlLabel ? ', getAssociations?: () => unknown' : ''}): ${prefix}Owner {
  assertNoInstanceAssociations(raw, 'hydration props');
${controlLabel ? "  if (port.server && getAssociations !== undefined) throw new TypeError('[ControlLabel SSR] instance associations are supported only after client hydration');\n" : ''}  const owner = ${prefix}CreateOwner(port${controlLabel ? ', getAssociations ?? (() => undefined)' : ''});
  const ${prefix}Def = owner.def;
${publicCalls ? `    const ${prefix}WrapPublic = owner.wrapPublic;` : ''}
${hasAuthoredHooks ? `    const ${prefix}Authored = owner.authored;` : ''}
${atoms.shader ? `    const ${prefix}Shader = owner.shader;` : ''}${atoms.delay ? `    const ${prefix}Delay = owner.delay;` : ''}${atoms.presence ? `    const ${prefix}Presence = owner.presence;` : ''}${atoms.meta ? `    const ${prefix}Meta = owner.meta;` : ''}
${styled ? `  const ${prefix}Style = owner.style;\n  const ${prefix}OwnerProps = owner.props;\n` : ''}${interacting ? `  const ${prefix}Interaction = owner.interaction;\n` : ''}${hookCode}
  try {
    owner.render = (${fn(ir.setup, 2)})(${ir.setup.parameters.length === 0 ? '' : `${prefix}Def`});
    owner.hydrate(raw);
    owner.created();
    return owner;
  } catch (error) { try { owner.dispose(true); } catch { /* Preserve the initiating setup/created failure. */ } throw error; }
}
${support.server}
`;
    const files = [
      ...helpers,
      ...support.files,
      { path: 'Component.css', kind: 'style' as const, contents: cssText },
      ...(environment
        ? [
            {
              path: 'Component.environment.css',
              kind: 'style' as const,
              contents: environment.cssText,
            },
          ]
        : []),
    ];
    // Include source graph, direct generated statements, helper bytes and CSS in one deterministic receipt.
    // The sentinel avoids a circular self-hash. This is compatibility binding, not authentication.
    const receipt = hash(
      JSON.stringify({
        profile,
        ir,
        code,
        files,
        styleEnvironment: environment
          ? { id: environment.id, requiredCustomProperties: styleDependencies.required }
          : null,
      })
    );
    return {
      ok: true,
      value: {
        code: code.replaceAll(binding, receipt),
        profile: 'web-component-ssr-v1',
        supportingFiles: files.map((file) => ({
          ...file,
          contents: file.contents.replaceAll(binding, receipt),
        })),
        dependencies: selected.value.dependencies.filter(
          (dependency) =>
            supportPlan.packages.includes(dependency.name) || dependency.name !== '@floating-ui/dom'
        ),
        provenance: {
          source: ir.source,
          irVersion: ir.schemaVersion,
          backend: 'web-component-ssr-v1',
          nativeSupport: {
            version: 2 as const,
            id: supportPlan.id,
            features: [...supportPlan.features],
          },
          ...(environment
            ? {
                styleEnvironment: {
                  id: environment.id,
                  artifact: 'Component.environment.css',
                  sha256: artifacts.environment,
                  requiredCustomProperties: styleDependencies.required,
                },
              }
            : {}),
        },
      },
    };
  }
  const code = `// Native web-component-source-v1: no Proto-UI Runtime/Core/Adapter dependency.
// Helper cost: owner/callback guards, scalar state + subscriptions, prop fallback/watch,
// microtask update/ViewIntent reconciliation, native shadow DOM template construction.
${context ? '// Context cost: shared reference-key modules, owner scopes, checked JSON records, dynamic logical DOM ancestry.\n' : ''}// Context ancestry follows registered generated owners, never tag names or CSS markers.
// setProps is a full raw snapshot. No automatic state-write rendering.
// Synchronous DOM moves retain the owner; settled disconnection disposes it.
// setPresent detaches only the view; explicit dispose permanently closes this element.
${contextImports}
${staticImports}
${atoms.imports}
${controlLabel ? `import {validateNativeInstanceAssociations as ${prefix}ValidateAssociations} from './.proto-ui/interaction/control-label-v1';` : ''}
${publicCalls ? `import { createNativePublicCalls as ${prefix}CreatePublicCalls } from './.proto-ui/owner/public-callables-v1';` : ''}
${callBoundaries.authored.size ? `import { markNativeAuthoredCallable as ${prefix}MarkAuthoredCallable, isNativeAuthoredCallable as ${prefix}IsAuthoredCallable } from './.proto-ui/owner/authored-callables-v1';` : ''}
${hasAuthoredHooks ? `import { createNativeAuthoredHooks as ${prefix}CreateAuthored } from './.proto-ui/owner/authored-hooks-v1';` : ''}
${statements(moduleParts.shared, 0)}
import { createNativeBrowserPort, type NativeBrowserPort, type NativeFrameBuilder } from './.proto-ui/web-component/browser-v1';
type BrowserPort = NativeBrowserPort<${interacting ? `typeof ${prefix}CreateNativeInteraction` : 'undefined'}>;
type HostPort = BrowserPort;
const ${prefix}PropTypes = ${JSON.stringify(Object.fromEntries(ir.props.map((prop) => [prop.name, prop.type])))};
${styled ? `import {createNativeStyle as ${prefix}CreateNativeStyle, templateStyleTokens as ${prefix}TemplateStyleTokens, type NativeStyle as ${prefix}Style, type NativeStyleHandle as ${prefix}NativeStyleHandle, type NativeRuleHandle as ${prefix}NativeRuleHandle} from './.proto-ui/style/native-v1';\n` : ''}
${interactionArtifact ? `import {${interacting ? `createNativeInteraction as ${prefix}CreateNativeInteraction, type NativeInteraction as ${prefix}NativeInteraction, type NativeFocus as ${prefix}NativeFocus, type NativeAccessible as ${prefix}NativeAccessible, type NativeObservedState as ${prefix}NativeObservedState, type NativeInput as ${prefix}NativeInput, type NativeFocusOptions as ${prefix}NativeFocusOptions, ` : ''}${outwardEvents ? `markNativeExposeEvent as ${prefix}MarkNativeExposeEvent` : ''}} from './${supportPlan.interactionPath.slice(0, -3)}';\n` : ''}
export type GeneratedProps = {
${props}
};
type ${prefix}PropsSnapshot = {
${resolvedProps}
};
export type GeneratedExposes = {
${exposes}
};
${nativeHelpers(prefix, contextValidation, styled, interacting, eventSupport, outwardEvents, true, JSON.stringify(ir.moduleDeclarations.map(({ id, config }) => ({ id, config }))), staticNames.get('@proto.ui/module-table-structure#TABLE_STRUCTURE_FAMILY') ?? 'undefined', true, atoms, hasAuthoredHooks, publicCalls, controlLabel)}
export class ${className} extends HTMLElement {
  private ${prefix}Owner: ${prefix}Owner | null = null;
  private ${prefix}Port: BrowserPort | null = null;
  private ${prefix}Raw: Record<string, unknown> = {};
  private ${prefix}Disconnect = 0;
  private ${prefix}Closed = false;
  private ${prefix}Associations: Readonly<{ controlLabel?: object | null }> | undefined;
  get instanceAssociations(): Readonly<{ controlLabel?: object | null }> | undefined { return this.${prefix}Associations; }
  set instanceAssociations(value: Readonly<{ controlLabel?: object | null }> | undefined) {
    if (this.${prefix}Closed) throw new Error('Custom element is disposed');
${controlLabel ? `    const accepted = ${prefix}ValidateAssociations(value);` : emitUndeclaredInstanceAssociations('value', `${prefix}InputAssociations`)}
    this.${prefix}Associations = ${controlLabel ? 'accepted' : 'value'};
${controlLabel ? `    this.${prefix}Owner?.interaction.refresh();` : ''}
  }
  static get observedAttributes(): string[] { return ['instance-associations', 'instanceassociations']; }
  attributeChangedCallback(name: string, _previous: string | null, value: string | null): void {
    if (value !== null) throw new TypeError('[InstanceAssociations] use the instanceAssociations property, not an attribute string');
  }
  get logicalOwner(): symbol | null { return this.${prefix}Owner?.identity ?? null; }
  get viewEpoch(): number { return this.${prefix}Owner?.epoch ?? 0; }
  get present(): boolean { return this.${prefix}Owner?.view ?? false; }
  connectedCallback(): void {
    ++this.${prefix}Disconnect;
    if (this.${prefix}Closed) return;
    if (this.${prefix}Owner) {
      const owner = this.${prefix}Owner;
      if (!owner.view) {
        const version = this.${prefix}Disconnect;
        // Finish an enclosing native slot commit before retrying a retained owner.
        queueMicrotask(() => {
          if (this.${prefix}Closed || owner !== this.${prefix}Owner || version !== this.${prefix}Disconnect || !this.isConnected || owner.view) return;
          owner.reconcile();
        });
      }
      return;
    }
    const port = createNativeBrowserPort(this, ${options.shadow ? 'true' : 'false'}, ${interacting ? `${prefix}CreateNativeInteraction` : 'undefined'}, ${outwardEvents ? `${prefix}MarkNativeExposeEvent` : 'undefined'});
    this.${prefix}Port = port;
    const owner = ${prefix}CreateOwner(port${controlLabel ? `, () => this.${prefix}Associations` : ''});
    this.${prefix}Owner = owner;
    const ${prefix}Def = owner.def;
${publicCalls ? `    const ${prefix}WrapPublic = owner.wrapPublic;` : ''}
${hasAuthoredHooks ? `    const ${prefix}Authored = owner.authored;` : ''}
${atoms.shader ? `    const ${prefix}Shader = owner.shader;` : ''}${atoms.delay ? `    const ${prefix}Delay = owner.delay;` : ''}${atoms.presence ? `    const ${prefix}Presence = owner.presence;` : ''}${atoms.meta ? `    const ${prefix}Meta = owner.meta;` : ''}
${styled ? `    const ${prefix}Style = owner.style;\n    const ${prefix}OwnerProps = owner.props;\n` : ''}
${interacting ? `    const ${prefix}Interaction = owner.interaction;\n` : ''}
${hookCode}    try {
      owner.render = (${fn(ir.setup, 3)})(${ir.setup.parameters.length === 0 ? '' : `${prefix}Def`});
      owner.hydrate(this.${prefix}Raw);
      owner.created();
      owner.reconcile();
      port.accept();
    } catch (error) {
      try { owner.dispose(); }
      finally { port.dispose(); this.${prefix}Port = null; this.${prefix}Owner = null; }
      throw error;
    }
  }
  disconnectedCallback(): void {
    const version = ++this.${prefix}Disconnect;
    const owner = this.${prefix}Owner;
    queueMicrotask(() => {
      if (version !== this.${prefix}Disconnect || this.isConnected || !owner || owner !== this.${prefix}Owner) return;
      this.${prefix}Owner = null;
      try { owner.dispose(); } finally { this.${prefix}Port?.dispose(); this.${prefix}Port = null; }
    });
  }
  setProps(next: GeneratedProps & Record<string, unknown>): void {
    if (this.${prefix}Closed) throw new Error('Custom element is disposed');
${options.propsUpdatePolicy === 'host' ? `    const changed = Object.keys({ ...this.${prefix}Raw, ...next }).some(key => Object.hasOwn(this.${prefix}Raw, key) !== Object.hasOwn(next, key) || !Object.is(this.${prefix}Raw[key], next[key]));` : ''}
    if (Object.prototype.hasOwnProperty.call(next, 'instanceAssociations')) throw new TypeError('[InstanceAssociations] use the instanceAssociations property, outside Props');
    this.${prefix}Raw = { ...next };
    const owner = this.${prefix}Owner;
    if (owner) {
      owner.hydrate(this.${prefix}Raw);
${options.propsUpdatePolicy === 'host' ? `      if (changed && !this.${prefix}Closed && this.${prefix}Owner === owner) owner.update();` : ''}
    }
  }
  update(): void {
    if (this.${prefix}Closed) throw new Error('Custom element is disposed');
    this.${prefix}Owner?.update();
  }
  getExposes(): Partial<GeneratedExposes> {
    return this.isConnected && this.${prefix}Owner ? { ...this.${prefix}Owner.exposes } as Partial<GeneratedExposes> : {};
  }
  dispose(): void {
    if (this.${prefix}Closed) return;
    this.${prefix}Closed = true;
    ++this.${prefix}Disconnect;
    const owner = this.${prefix}Owner;
    this.${prefix}Owner = null;
    try { owner?.dispose(); } finally { this.${prefix}Port?.dispose(); this.${prefix}Port = null; }
  }
}
export function register(tagName = ${JSON.stringify(tagName)}, registry: CustomElementRegistry = customElements): typeof ${className} {
  const existing = registry.get(tagName);
  if (existing && existing !== ${className}) throw new Error('Custom element tag already registered: ' + tagName);
  if (!existing) registry.define(tagName, ${className});
  return ${className};
}
export default ${className};
`;
  return {
    ok: true,
    value: {
      code,
      profile: 'web-component-source-v1',
      supportingFiles: [
        ...atoms.files,
        ...(publicCalls ? [nativePublicCallsArtifact] : []),
        ...(callBoundaries.authored.size ? [nativeAuthoredCallablesArtifact] : []),
        ...(hasAuthoredHooks ? [nativeAuthoredHooksArtifact] : []),
        ...context.files,
        ...staticDeclarations.files,
        ...(styled ? [nativeStyleArtifact] : []),
        ...(interactionArtifact ? nativeSupportArtifacts(supportPlan) : []),
        webComponentBrowserSupport,
      ],
      dependencies: selected.value.dependencies.filter(
        (dependency) =>
          supportPlan.packages.includes(dependency.name) || dependency.name !== '@floating-ui/dom'
      ),
      provenance: {
        source: ir.source,
        irVersion: ir.schemaVersion,
        backend: 'web-component-source-v1',
        ...(interactionArtifact
          ? {
              nativeSupport: {
                version: 2 as const,
                id: supportPlan.id,
                features: [...supportPlan.features],
              },
            }
          : {}),
      },
    },
  };
}

function nativeHelpers(
  p: string,
  contextValidation: string,
  styled: boolean,
  interacting: boolean,
  eventSupport: boolean,
  outwardEvents: boolean,
  ssr = false,
  declarations = '[]',
  tableFamily = 'undefined',
  nativeBrowser = false,
  atoms: NativeHostAtomPlan,
  hasAuthoredHooks: boolean,
  publicCalls: boolean,
  controlLabel = false
): string {
  const context = !!contextValidation;
  const contextTypes = context
    ? `type ${p}ContextKey<T> = object & {readonly __contextValue?: T};
type ${p}ContextRead = Readonly<{read<T>(key: ${p}ContextKey<T>): T; tryRead<T>(key: ${p}ContextKey<T>): T | null}>;
type ${p}ContextRun = ${p}ContextRead & {update<T>(key: ${p}ContextKey<T>, next: T | ((prev: T) => T)): void; tryUpdate<T>(key: ${p}ContextKey<T>, next: T | ((prev: T) => T)): boolean};
type ${p}ContextDef = {provide<T>(key: ${p}ContextKey<T>, value: T): void; subscribe<T>(key: ${p}ContextKey<T>, callback?: (run: ${p}Run, next: T, prev: T) => void): () => void; trySubscribe<T>(key: ${p}ContextKey<T>, callback?: (run: ${p}Run, next: T | null, prev: T | null) => void): () => void};
${
  ssr
    ? ''
    : `function ${p}ContextParent(host: HTMLElement): ${p}ContextScope | null {
  if (!host.isConnected) return null;
  let node: Node | null = host;
  while (node) {
    const slot: HTMLSlotElement | null = node instanceof Element ? node.assignedSlot : null;
    node = slot ?? (node instanceof ShadowRoot ? node.host : node.parentNode);
    if (node) {
      const scope = ${p}OwnerScopes.get(node);
      if (scope) return scope;
    }
  }
  return null;
}`
}
`
    : '';
  return `type ${p}ExternalState<T> = { get(): T; subscribe(cb: (event: {type: 'next'; prev: T; next: T; reason?: unknown}) => void): () => void; unsubscribe(off: () => void): void; spec: Readonly<${p}StateOptions & {kind: string}> };
type ${p}Scalar = string | number | boolean | null;
type ${p}Snapshot = Readonly<Record<string, unknown>>;
type ${p}PropSpec = {type: string; schema?: Parameters<typeof ${p}Accepts>[0]; default?: unknown; options?: readonly string[]; empty?: 'accept' | 'fallback' | 'error'; range?: {min?: number; max?: number}};
type ${p}StateOptions = {options?: readonly ${p}Scalar[]; min?: number; max?: number; step?: number; clamp?: boolean};
type ${p}State<T extends ${p}Scalar = ${p}Scalar> = {get(): T; setDefault(next: T): void; set(next: T, reason?: unknown): void; external: ${p}ExternalState<T>; subscribers: Set<Function>};
${contextTypes}type ${p}PropsRead = Readonly<{get(): ${p}PropsSnapshot; getRaw(): Readonly<Record<string, unknown>>; isProvided(key: string): boolean}>;
type ${p}Run = {host: {get(): HTMLElement | null}; ${styled ? `readonly feedback: {readonly style: ${p}Style}; ` : ''}${context ? `readonly context: ${p}ContextRun; ` : ''}update(): void; props: ${p}PropsRead; lifecycle: {setPresent(next: boolean): void}; expose: {emit(key: string, payload?: unknown, options?: CustomEventInit): void}};
type ${p}Renderer = {${nativeBrowser ? '' : `el(tag: string, a?: unknown, b?: unknown): ${ssr ? 'Presentation' : 'Node'};`} slot(): ${nativeBrowser ? '(()=>Node)' : ssr ? 'Presentation' : 'Node'}; ${nativeBrowser ? 'readonly nativeFrame:NativeFrameBuilder; ' : ''}readonly props: ${p}PropsRead; readonly read: Readonly<{readonly props: ${p}PropsRead${context ? `; readonly context: ${p}ContextRead` : ''}}>};
type ${p}Def = {
${styled ? `  readonly feedback: {readonly style: ${p}Style};\n` : ''}
${eventSupport ? `  readonly event: ${p}NativeInteraction<${p}Run>['event'];\n` : ''}
${context ? `  context: ${p}ContextDef;\n` : ''}  props: {define(input: Record<string, ${p}PropSpec>): void; setDefaults(input: Record<string, unknown>): void; watch(keys: string[], fn: Function): () => void; watchAll(fn: Function): () => void; watchRaw(keys: string[], fn: Function): () => void; watchRawAll(fn: Function): () => void};
  state: {bool(s: string, v: boolean): ${p}State<boolean>; enum(s: string, v: string, o: ${p}StateOptions): ${p}State<string>; string(s: string, v: string, o?: ${p}StateOptions): ${p}State<string>; numberDiscrete(s: string, v: number, o?: ${p}StateOptions): ${p}State<number>; numberRange(s: string, v: number, o: ${p}StateOptions): ${p}State<number>};
  expose: {value(key: string, value: unknown): void; state(key: string, handle: ${p}State${interacting ? ` | ${p}NativeObservedState<boolean | string | number>` : ''}): void; method<A extends unknown[], R>(key: string, fn: (...args: A) => R, project?: (value: R) => R): void; event(key: string, spec?: object): void};
  lifecycle: {onCreated(fn: Function): void; onMounted(fn: Function): void; onUpdated(fn: Function): void; onUnmounted(fn: Function): void; onBeforeDispose(fn: Function): void};
};
type ${p}Owner = {${atoms.shader ? `shader: ReturnType<typeof ${p}CreateShader>; ` : ''}${publicCalls ? `wrapPublic: ReturnType<typeof ${p}CreatePublicCalls>; ` : ''}${hasAuthoredHooks ? `authored: ReturnType<typeof ${p}CreateAuthored>; ` : ''}${atoms.delay ? `delay: ReturnType<typeof ${p}CreateDelay>; ` : ''}${atoms.presence ? `presence: ReturnType<typeof ${p}CreatePresence<${p}Run>>; ` : ''}${atoms.meta ? 'meta: (key: string) => unknown; ' : ''}identity: symbol; def: ${p}Def; exposes: Record<string, unknown>; render?: Function | void; readonly epoch: number; readonly view: boolean; ${ssr && !nativeBrowser ? 'serialize(): void; validateHydration(): void; ' : ''}${interacting ? `readonly interaction: ${p}NativeInteraction<${p}Run>; ` : ''}${styled ? `readonly style: ${p}Style; props(): ${p}PropsSnapshot; ` : ''}hydrate(input: Record<string, unknown>): void; update(): void; reconcile(): void; created(): void; dispose(${ssr ? 'exhaustive?: boolean' : ''}): void};
function ${p}CreateOwner(host: ${ssr ? 'HostPort' : 'HTMLElement, root: ShadowRoot'}${controlLabel ? ', getAssociations: () => unknown' : ''}): ${p}Owner {
  let alive = true, disposing = false, setup = true, callbackDepth = 0;
${
  interacting
    ? `  let currentRun: ${p}Run | undefined;
  const observedProjections = new Map<object, {external: ${p}ExternalState<unknown>; subscribers: Set<Function>}>();
  const observedSubscriptions: (() => void)[] = [];\n`
    : ''
}
  let intent = true, view = false, epoch = 0, queued = false, dirty = false, hostScheduled = false;
${ssr ? '' : '  let detachedDisplay: {value: string; priority: string} | undefined;'}
  let propsWindow: {raw: Readonly<Record<string, unknown>>; resolved: ${p}Snapshot} | null = null;
  let resolved: ${p}Snapshot = Object.freeze({}), raw: Readonly<Record<string, unknown>> = Object.freeze({}), hydrated = false;
  const specs: Record<string, ${p}PropSpec> = Object.create(null), previous: Record<string, unknown> = Object.create(null), defaults: Record<string, unknown>[] = [];
  const watchers: {keys: string[] | null; fn: Function; active: boolean; raw: boolean}[] = [], states: ${p}State[] = [], emissions: (() => void)[] = [];
  let emitting = false;
  const exposes: Record<string, unknown> = Object.create(null), events = new Set<string>();
  const lifecycle: Record<string, Function[]> = {created: [], mounted: [], updated: [], unmounted: [], beforeDispose: []};
  const own = (obj: object, key: string) => Object.prototype.hasOwnProperty.call(obj, key);
  const ensure = () => { if (!alive) throw new Error('Logical owner is disposed'); };
  const ensureExternal = () => { ensure(); if (disposing) throw new Error('Logical owner is disposing'); };
  const ensureSetup = () => { ensure(); if (!setup) throw new Error('Setup capability is closed'); };
  const runtime = () => { ensure(); if (setup || !callbackDepth) throw new Error('State writes require a live callback scope'); };
  ${atoms.owner({ setup: 'ensureSetup()', runtime: 'runtime()', alive: 'alive', invoke: 'invoke(callback, [], false)', invokeRun: 'invoke(callback)', document: ssr ? "host.root?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document)" : 'host.ownerDocument', run: `${p}Run`, root: ssr ? 'host.root' : 'host', prepare: styled ? `${p}Style.refresh();` : '' })}
${
  hasAuthoredHooks
    ? `  const ${p}AuthoredWatchCleanups: (() => void)[] = [];
  const ${p}Authored = ${p}CreateAuthored({setup: ensureSetup, borrow(value) {
    const state = value as ${p}State<${p}Scalar>;
    const borrowed = Object.freeze({get: () => state.get(), setDefault: (value: ${p}Scalar) => state.setDefault(value), set: (value: ${p}Scalar, reason?: unknown) => state.set(value, reason), watch(callback: (run: ${p}Run, event: unknown) => void) { ensureSetup(); const off = state.external.subscribe(event => { invoke(callback, [event]); }); ${p}AuthoredWatchCleanups.push(off); return off; }});
    ${atoms.registerSource('borrowed')}
    return borrowed;
  }});`
    : ''
}
${
  context
    ? `  const context = ${p}CreateContextScope({getParent: () => ${ssr ? 'host.parentContext()' : `${p}ContextParent(host)`}, isAlive: () => alive,
    invoke: <T>(callback: () => T): T => invoke(callback, [], false) as T, validate: ${contextValidation}});
`
    : ''
}
${
  styled
    ? `  const ${p}Style = ${p}CreateNativeStyle({ensureSetup, ensureRuntime: runtime, isAlive: () => alive,
    ${atoms.ruleMeta(ssr ? 'host.document' : 'host.ownerDocument')}
    project(tokens) { ${ssr ? "host.attribute('data-pui-style', tokens.length ? tokens.join(' ') : null);" : "if (tokens.length) host.setAttribute('data-pui-style', tokens.join(' ')); else host.removeAttribute('data-pui-style');"} }});\n`
    : ''
}
${
  interacting
    ? `  const ${p}Interaction: ${p}NativeInteraction<${p}Run> = ${ssr ? 'host.createInteraction' : `${p}CreateNativeInteraction`}<${p}Run>({
    ensureSetup, ensureRuntime: runtime, ensureEvent: runtime, isAlive: () => alive, isSetupComplete: () => !setup, isReady: () => !setup && view && intent && !disposing && host.isConnected,
    invoke: <T>(callback: () => T): T => invoke(callback, [], false) as T,
    getRun() { ensure(); if (!currentRun) throw new Error('Interaction requires a live callback scope'); return currentRun; },
    getResolvedProps: () => resolved,
${controlLabel ? '    getAssociations,\n' : ''}
    getRoot: () => view && !disposing${ssr ? ' && !host.server' : ''} ? ${ssr ? 'host.root' : 'physicalRoot'} : null,
    getHost: () => ${ssr ? 'host.host' : 'host'},
    identity: context, getLogicalParent: () => ${ssr ? 'host.parentContext()' : `${p}ContextParent(host)`},
    declarations: ${declarations}, tableFamily: ${tableFamily},
    getExposes: () => exposes,
    registerExpose(key, value) {
      if (value && typeof value === 'object' && 'external' in value) expose(key, value.external);
      else if (typeof value === 'function') expose(key, (...args: unknown[]) => { ensureExternal(); return invoke(value, args, false); });
      else expose(key, value);
    },
    createOwnedState: (name, value, spec) => state(spec?.kind ?? (typeof value === 'boolean' ? 'bool' : typeof value === 'number' ? 'number.discrete' : 'string'), name, value, spec),
    watchState<T>(handle: {get():T}, fn: (run: ${p}Run, event: {type:'next';prev:T;next:T;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void) {
      ensureSetup();
      const external = ('external' in handle ? handle.external : observedProjections.get(handle)?.external) as ${p}ExternalState<T> | undefined;
      if (!external) throw new Error('Unknown owner State watch target');
      const off = external.subscribe(event => invoke(fn, [event]) as void); observedSubscriptions.push(off); return off;
    },
    subscribeState(handle, callback) {
      const source = 'external' in handle ? (handle as {external:${p}ExternalState<unknown>}).external : handle as ${p}NativeObservedState<unknown>;
      return source.subscribe(callback);
    },
    isPropProvided: key => own(raw, key),
    emit: key => { runtime(); currentRun!.expose.emit(key); },
    setPresent: value => { runtime(); if (disposing) throw new Error('Terminal presence is locked'); intent = value; schedule(false); },
    requestHostUpdate() {
      if (hostScheduled || disposing) return;
      hostScheduled = true;
      queueMicrotask(() => { hostScheduled = false; if (alive && !disposing && view) projectHost(); });
    },
    registerGenericObservedState(handle) {
      if (observedProjections.has(handle)) return;
      const subscribers = new Set<Function>();
      const external: ${p}ExternalState<boolean | string | number> = Object.freeze({
        get() { ensureExternal(); return handle.get(); }, spec: Object.freeze({kind: typeof handle.get() === 'boolean' ? 'bool' : typeof handle.get() === 'number' ? 'number.discrete' : 'string'}),
        subscribe(fn: Function) { ensureExternal(); const registration = (event: unknown) => fn(event); subscribers.add(registration); return () => { subscribers.delete(registration); }; },
        unsubscribe(off: () => void) { ensureExternal(); off(); },
      });
      observedProjections.set(handle, {external, subscribers});
      ${atoms.registerSource('handle')}
      observedSubscriptions.push(handle.subscribe((event) => {
${styled ? `        ${p}Style.refresh();\n` : ''}${atoms.refresh}
        ${p}Interaction.refresh();
        ${emitRecordedNotification({ queue: 'emissions', draining: 'emitting', subscribers: 'subscribers', deliver: 'invoke(subscriber, [event], false)', alive: 'alive && !disposing', drain: false })}
        drainEmissions();
      }));
    },
  });\n`
    : ''
}
  ${publicCalls ? `const ${p}WrapPublic = ${p}CreatePublicCalls({alive: ensureExternal, invoke: <T>(callback: () => T): T => invoke(callback, [], false) as T});` : ''}
  function invoke(fn: Function, args: unknown[] = [], withRun = true): unknown {
    ensure();
    const check = () => runtime();
    const run: ${p}Run = {
      host: { get() { check(); return view && !disposing ? ${ssr ? 'host.root' : 'host'} : null; } },
${styled ? `      feedback: {style: ${p}Style},\n` : ''}
${
  context
    ? `      context: Object.freeze({
        read<T>(key: ${p}ContextKey<T>): T { check(); return context.read(key) as T; },
        tryRead<T>(key: ${p}ContextKey<T>): T | null { check(); return context.tryRead(key) as T | null; },
        update<T>(key: ${p}ContextKey<T>, next: T | ((prev: T) => T)) { check(); runtime(); context.update(key, next); },
        tryUpdate<T>(key: ${p}ContextKey<T>, next: T | ((prev: T) => T)) { check(); runtime(); return context.tryUpdate(key, next); },
      }),\n`
    : ''
}      update() { check(); if (!disposing) schedule(true); },
      props: Object.freeze({get() { check(); return (propsWindow?.resolved ?? resolved) as ${p}PropsSnapshot; }, getRaw() { check(); return propsWindow?.raw ?? raw; }, isProvided(key: string) { check(); return own(propsWindow?.raw ?? raw, key); }}),
      lifecycle: {setPresent(next: boolean) { check(); if (disposing) return; intent = next; schedule(false); }},
      expose: {emit(key: string, payload?: unknown, options?: CustomEventInit) { check(); if (!events.has(key)) throw new Error('Undeclared exposed event: ' + key); ${ssr ? 'host.emit(key, payload, options);' : `host.dispatchEvent(${outwardEvents ? `${p}MarkNativeExposeEvent(` : ''}new CustomEvent(key, {detail: payload, bubbles: true, cancelable: true, ...options})${outwardEvents ? ')' : ''});`} }},
    };
${interacting ? `    const previousRun = currentRun; currentRun = run;\n` : ''}
    ++callbackDepth;
    try { return fn(...(withRun ? [run, ...args] : args)); }
    finally { --callbackDepth; ${interacting ? 'currentRun = previousRun; ' : ''}}
  }
${
  context
    ? `  ${p}OwnerScopes.set(host, context);
${ssr ? '  host.bindContext(context);\n' : ''}
  const contextRead: ${p}ContextRead = Object.freeze({
    read<T>(key: ${p}ContextKey<T>): T { ensure(); if (setup) throw new Error('Context reads require runtime scope'); return context.read(key) as T; },
    tryRead<T>(key: ${p}ContextKey<T>): T | null { ensure(); if (setup) throw new Error('Context reads require runtime scope'); return context.tryRead(key) as T | null; },
  });\n`
    : ''
}  function fire(name: string): void {
    if (name === 'unmounted') { ${atoms.detach} }
${
  ssr
    ? `    try { for (const fn of lifecycle[name]) invoke(fn); }
    finally { if (name === 'unmounted') { ${atoms.detach} } }`
    : `    let error: unknown;
    try { for (const fn of lifecycle[name]) { try { invoke(fn); } catch (caught) { error ??= caught; } } }
    finally { if (name === 'unmounted') { ${atoms.detach} } }
    if (error !== undefined) throw error;`
}
  }
  function valid(spec: ${p}PropSpec, value: unknown): boolean {
    if (spec.schema === undefined) throw new Error('Missing checked Props schema');
    return ${p}Accepts(spec.schema, value) && (!spec.options || spec.options.includes(value as string)) &&
      (!spec.range || (typeof value === 'number' && value >= (spec.range.min ?? -Infinity) && value <= (spec.range.max ?? Infinity)));
  }
  function resolve(strict: boolean): ${p}Snapshot {
    const next: Record<string, unknown> = Object.create(null);
    for (const key of Object.keys(specs)) {
      const spec = specs[key], provided = own(raw, key), value = raw[key];
      const requireValue = strict && spec.empty === 'error';
      if (provided && value != null && valid(spec, value)) { next[key] = value; previous[key] = value; continue; }
      if (provided && value == null && spec.empty === 'accept') { next[key] = null; continue; }
      let candidate: unknown;
      if (provided && own(previous, key) && valid(spec, previous[key])) candidate = previous[key];
      if (candidate === undefined) for (const layer of defaults) {
        if (!own(layer, key)) continue;
        const value = layer[key];
        if ((value === null && !requireValue) || (value != null && valid(spec, value))) { candidate = value; break; }
      }
      if (candidate === undefined && own(spec, 'default')) {
        const value = spec.default;
        if ((value === null && !requireValue) || (value != null && valid(spec, value))) candidate = value;
      }
      if (candidate === undefined) {
        if (requireValue) throw new Error('Prop has no valid fallback: ' + key);
        candidate = null;
      }
      next[key] = candidate;
      if (provided && next[key] != null) previous[key] = next[key];
    }
    return Object.freeze(next);
  }
  function hydrate(input: Record<string, unknown>): void {
    ensure();
    const prev = resolved, previousRaw = raw;
    raw = Object.freeze({...input});
    resolved = resolve(true);
${styled ? `    ${p}Style.refresh();\n` : ''}
${interacting ? `    ${p}Interaction.refresh();\n` : ''}
    if (!hydrated) { hydrated = true; return; }
    const changed = Object.keys(specs).filter((key) => !Object.is(prev[key], resolved[key]));
    const rawChanged = watchers.some((watcher) => watcher.raw && watcher.active) ? [...new Set([...Object.keys(previousRaw), ...Object.keys(raw)])].filter((key) => !Object.is(previousRaw[key], raw[key])) : changed;
    const next = resolved, nextRaw = raw;
    const previousWindow = propsWindow; propsWindow = {raw: nextRaw, resolved: next};
    try { for (let group = 0; group < 3; ++group) for (const watcher of [...watchers]) {
      if ((watcher.raw ? watcher.keys === null ? 0 : 1 : 2) !== group) continue;
      const all = watcher.raw ? rawChanged : changed;
      const matched = watcher.keys === null ? all : all.filter((key) => watcher.keys!.includes(key));
      if (watcher.active && matched.length) {
        if (watcher.raw) console.warn('[Props] raw watchers are an adapter-snapshot escape hatch; avoid in official prototypes.');
        invoke(watcher.fn, [watcher.raw ? nextRaw : next, watcher.raw ? previousRaw : prev, {changedKeysAll: all, changedKeysMatched: matched}]);
      }
    } } finally { propsWindow = previousWindow; }
  }
  function drainEmissions(): void {
    ${emitNotificationDrain({ queue: 'emissions', draining: 'emitting', alive: 'alive && !disposing' })}
  }
  function state<T extends ${p}Scalar>(kind: string, semantic: string, initial: T, options: ${p}StateOptions = {}): ${p}State<T> {
    ensureSetup();
${hasAuthoredHooks ? `    ${p}Authored.claimState(semantic);` : ''}
    if (typeof semantic !== 'string' || semantic.length === 0) throw new Error('Invalid state semantic');
    const spec = Object.freeze({...options, kind});
    function validate(value: unknown): void {
      const type = kind === 'bool' ? 'boolean' : kind === 'string' || kind === 'enum' ? 'string' : 'number';
      if (typeof value !== type || (type === 'number' && Number.isNaN(value))) throw new Error('Invalid state value');
      if (options.options?.length && !options.options.includes(value as ${p}Scalar)) throw new Error('State value outside options');
      if (kind === 'number.range' || (kind === 'number.discrete' && !options.options?.length)) {
        const numeric = typeof value === 'number' ? value : NaN;
        if (numeric < (options.min ?? -Infinity) || numeric > (options.max ?? Infinity)) throw new Error('State value outside range');
        if (kind === 'number.discrete' && options.step !== undefined && options.step > 0 && !Number.isInteger((numeric - (options.min ?? 0)) / options.step)) throw new Error('State value violates step');
      }
    }
    if (kind === 'number.range' && options.clamp) initial = Math.max(options.min ?? -Infinity, Math.min(options.max ?? Infinity, initial as number)) as T;
    validate(initial);
    let value = initial;
    const subscribers = new Set<Function>();
    const external = Object.freeze({
      get() { ensureExternal(); return value; }, spec,
      subscribe(fn: Function) { ensureExternal(); const registration = (event: unknown) => fn(event); subscribers.add(registration); return () => subscribers.delete(registration); },
      unsubscribe(off: () => void) { ensureExternal(); off(); },
    });
    const handle = {external, subscribers,
      get() { ensure(); return value; },
      setDefault(next: T) { ensureSetup(); validate(next); value = next; },
      set(next: T, reason?: unknown) {
        runtime(); validate(next); if (Object.is(value, next)) return;
        const prev = value; value = next;
${styled ? `        ${p}Style.refresh();\n` : ''}${atoms.refresh}

${interacting ? `        ${p}Interaction.refresh();\n` : ''}
        ${emitRecordedNotification({ queue: 'emissions', draining: 'emitting', subscribers: 'subscribers', deliver: "invoke(subscriber, [{type: 'next', prev, next, reason}], false)", alive: 'alive && !disposing', drain: false })}
        drainEmissions();
      },
    };
    states.push(handle); ${hasAuthoredHooks ? `${p}Authored.state(semantic, handle);` : ''} ${atoms.registerSource('handle')} return handle;
  }
${
  ssr
    ? `${
        nativeBrowser
          ? `  let slotUsed = false;
${interacting ? '  let interactionAdopted = false;\n' : ''}
  function render(): void {
    slotUsed = false;
    const nativeFrame=host.createFrame();
    const props: ${p}PropsRead=Object.freeze({get:()=>resolved as ${p}PropsSnapshot,getRaw:()=>raw,isProvided:(key:string)=>own(raw,key)});
    const renderer: ${p}Renderer={nativeFrame,slot(){if(slotUsed)throw new Error('Multiple slots are unsupported');slotUsed=true;return ()=>nativeFrame.slot();},props,read:Object.freeze({props${context ? ', context: contextRead' : ''}})};
    projectHost();
    let fragment:DocumentFragment;
    if(typeof owner.render==='function')fragment=(owner.render(renderer) as DocumentFragment|null|undefined)??nativeFrame.document.createDocumentFragment();
    else {fragment=nativeFrame.document.createDocumentFragment();fragment.appendChild(renderer.slot()());}
    host.commit(nativeFrame.finish(fragment));
  }
`
          : `  function element(tag: string, a?: unknown, b?: unknown): Presentation {
    const props = arguments.length > 2 ? a : a != null && typeof a === 'object' && !Array.isArray(a) && !isPresentation(a) ? a : undefined;
    const children = arguments.length === 1 ? null : arguments.length > 2 ? b : props === undefined ? a : null;
    return presentationElement(tag, ${styled ? `props && Object.hasOwn(props, 'style') ? ${p}TemplateStyleTokens((props as {style: ${p}NativeStyleHandle}).style) : undefined` : 'undefined'}, children);
  }
  let slotUsed = false;
${interacting ? '  let interactionAdopted = false;\n' : ''}
  function render(): void {
    slotUsed = false;
    const props: ${p}PropsRead = Object.freeze({get: () => resolved as ${p}PropsSnapshot, getRaw: () => raw, isProvided: (key: string) => own(raw, key)});
    const renderer: ${p}Renderer = {el: element, slot() { if (slotUsed) throw new Error('Multiple slots are unsupported'); slotUsed = true; return {kind: 'slot'}; }, props, read: Object.freeze({props${context ? ', context: contextRead' : ''}})};
    projectHost();
    host.commit(presentationChildren(typeof owner.render === 'function' ? owner.render(renderer) : renderer.slot()));
  }
`
      }  function projectHost(): void {
    host.projectRoot(${interacting ? `${p}Interaction.rootTag(), ${p}Interaction.rootProperties(), host.server ? null : ${p}Interaction.portalTarget()` : 'null, {}, null'});
  }
  function detach(): void {
    host.visible(false);
    if (!view) return;
    view = false; ++epoch;
    let error: unknown;
${interacting ? `    try { ${p}Interaction.unmount(); } catch (caught) { error = caught; }\n` : ''}${styled ? `    try { ${p}Style.unmount(); host.attribute('data-pui-style', null); } catch (caught) { error ??= caught; }\n` : ''}    try { fire('unmounted'); } catch (caught) { error ??= caught; } finally { host.clear(); }
    if (error !== undefined) throw error;
  }
  function reconcile(): void {
    if (!alive || disposing || !host.isConnected || host.server) return;
    if (!intent) { detach(); return; }
    host.visible(true);
    if (!view) {
      ++epoch; render(); view = true; dirty = false;
${styled ? `      ${p}Style.mount();\n` : ''}      ${atoms.mount}
${
  interacting
    ? `      if (!interactionAdopted && host.hydrationAttributes) {
        ${p}Interaction.adoptAttributes(host.hydrationAttributes, host.hydrationBaselines);
        interactionAdopted = true;
      }
      ${p}Interaction.mount();\n`
    : ''
}      fire('mounted');
    } else if (dirty) { dirty = false; render(); fire('updated'); }
  }
  function schedule(update: boolean): void {
    ensure(); dirty ||= update;
    if (host.server || queued || disposing) return;
    queued = true;
    queueMicrotask(() => {
      queued = false;
      if (!alive || disposing) return;
      // Detached dirty work is retained until the next actual view commit.
      if (host.isConnected) reconcile();
    });
  }
`
    : `  function element(tag: string, a?: unknown, b?: unknown): Node {
    const node = host.ownerDocument.createElement(tag);
${
  styled
    ? `    const props = arguments.length > 2 ? a : a != null && typeof a === 'object' && !Array.isArray(a) && !(a instanceof Node) ? a : undefined;
    if (props && Object.hasOwn(props, 'style')) node.setAttribute('data-pui-style', ${p}TemplateStyleTokens((props as {style: ${p}NativeStyleHandle}).style));\n`
    : ''
}
    const children = arguments.length === 1 ? null : arguments.length > 2 ? b : a != null && typeof a === 'object' && !Array.isArray(a) && !(a instanceof Node) ? null : a;
    append(node, children); return node;
  }
  let slotUsed = false;
  function append(parent: Node, children: unknown): void {
    if (children === null) return;
    if (Array.isArray(children)) { for (const child of children) append(parent, child); return; }
    if (children instanceof Node) { parent.appendChild(children); return; }
    if (typeof children === 'string' || typeof children === 'number') { parent.appendChild(host.ownerDocument.createTextNode(String(children))); return; }
    throw new Error('Invalid template child');
  }
  function render(): void {
    slotUsed = false;
    const props: ${p}PropsRead = Object.freeze({get: () => resolved as ${p}PropsSnapshot, getRaw: () => raw, isProvided: (key: string) => own(raw, key)});
    const renderer: ${p}Renderer = {el: element, slot() { if (slotUsed) throw new Error('Multiple slots are unsupported'); slotUsed = true; return host.ownerDocument.createElement('slot'); }, props, read: Object.freeze({props${context ? ', context: contextRead' : ''}})};
    const fragment = host.ownerDocument.createDocumentFragment();
    if (typeof owner.render === 'function') append(fragment, owner.render(renderer));
    root.replaceChildren(fragment);
  }
  function detach(): void {
    if (!detachedDisplay) detachedDisplay = {value: host.style.getPropertyValue('display'), priority: host.style.getPropertyPriority('display')};
    host.style.setProperty('display', 'none', 'important');
    if (!view) return;
    view = false; ++epoch;
    let error: unknown;
${interacting ? `    try { ${p}Interaction.unmount(); } catch (caught) { error = caught; }\n` : ''}
${styled ? `    try { ${p}Style.unmount(); host.removeAttribute('data-pui-style'); } catch (caught) { error ??= caught; }\n` : ''}
    try { fire('unmounted'); } catch (caught) { error ??= caught; } finally { root.replaceChildren(); }
    if (error !== undefined) throw error;
  }
  function reconcile(): void {
    if (!alive || disposing || !host.isConnected) return;
    if (!intent) { detach(); return; }
    if (detachedDisplay) {
      if (host.style.getPropertyValue('display') === 'none' && host.style.getPropertyPriority('display') === 'important') {
        if (detachedDisplay.value) host.style.setProperty('display', detachedDisplay.value, detachedDisplay.priority);
        else host.style.removeProperty('display');
      }
      detachedDisplay = undefined;
    }
    if (!view) { ++epoch; render(); view = true; ${styled ? `${p}Style.mount(); ` : ''}${atoms.mount}${interacting ? `${p}Interaction.mount(); ` : ''}fire('mounted'); }
    else if (dirty) { render(); fire('updated'); }
  }
  function schedule(update: boolean): void {
    ensure(); dirty ||= update; if (queued || disposing) return;
    queued = true;
    queueMicrotask(() => {
      queued = false; if (!alive || disposing) return;
      const shouldUpdate = dirty; dirty = false;
      if (!intent) detach();
      else if (host.isConnected) { if (!view) reconcile(); else if (shouldUpdate) { render(); fire('updated'); } }
    });
  }
`
}
  function expose(key: string, value: unknown): void { ensureSetup(); if (own(exposes, key) || events.has(key)) throw new Error('Duplicate expose: ' + key); exposes[key] = value; }
  const def: ${p}Def = {
${styled ? `    feedback: {style: ${p}Style},\n` : ''}
${eventSupport ? `    event: ${p}Interaction.event,\n` : ''}
${
  context
    ? `    context: {
      provide(key, value) { ensureSetup(); context.provide(key, value); },
      subscribe(key, callback) { ensureSetup(); return context.subscribe(key, 'required', callback ? (next, prev) => { invoke(callback, [next, prev]); } : undefined); },
      trySubscribe(key, callback) { ensureSetup(); return context.subscribe(key, 'optional', callback ? (next, prev) => { invoke(callback, [next, prev]); } : undefined); },
    },\n`
    : ''
}    props: {
      define(input: Record<string, ${p}PropSpec>) {
        ensureSetup();
        const merged = {...specs};
        for (const key of Object.keys(input)) {
          const next = input[key], prev = specs[key];
          if (!['boolean', 'number', 'string', 'enum', 'object', 'any'].includes(next.type)) throw new Error('Unsupported prop type');
          if (next.empty !== undefined && !['accept', 'fallback', 'error'].includes(next.empty)) throw new Error('Invalid prop empty policy');
          if (next.range && ((next.range.min !== undefined && (typeof next.range.min !== 'number' || Number.isNaN(next.range.min))) || (next.range.max !== undefined && (typeof next.range.max !== 'number' || Number.isNaN(next.range.max))))) throw new Error('Invalid prop range');
          if (prev && (prev.type !== next.type || (prev.range && next.range && ((next.range.min ?? -Infinity) > (prev.range.min ?? -Infinity) || (next.range.max ?? Infinity) < (prev.range.max ?? Infinity))))) throw new Error('Conflicting prop declaration');
          const rank = (empty: string) => empty === 'accept' ? 0 : empty === 'error' ? 2 : 1;
          if (prev && next.empty !== undefined && rank(next.empty) > rank(prev.empty ?? 'fallback')) throw new Error('Conflicting prop empty policy');
          merged[key] = {...prev, ...next, schema: (${p}PropTypes as Record<string, Parameters<typeof ${p}Accepts>[0]>)[key], empty: prev?.empty ?? next.empty ?? 'fallback', range: next.range ?? prev?.range, ...(prev && own(prev, 'default') ? {default: prev.default} : {})};
        }
        Object.assign(specs, merged);
        resolved = resolve(false);
${interacting ? `        ${p}Interaction.refresh();\n` : ''}
      },
      setDefaults(input: Record<string, unknown>) { ensureSetup(); for (const key of Object.keys(input)) if (!own(specs, key)) throw new Error('Undeclared prop default: ' + key); defaults.unshift({...input}); resolved = resolve(false); ${interacting ? `${p}Interaction.refresh(); ` : ''}},
      watch(keys: string[], fn: Function) { ensureSetup(); const watcher = {keys: [...keys], fn, active: true, raw: false}; watchers.push(watcher); return () => { watcher.active = false; }; },
      watchAll(fn: Function) { ensureSetup(); const watcher = {keys: null, fn, active: true, raw: false}; watchers.push(watcher); return () => { watcher.active = false; }; },
      watchRaw(keys: string[], fn: Function) { ensureSetup(); const watcher = {keys: [...keys], fn, active: true, raw: true}; watchers.push(watcher); return () => { watcher.active = false; }; },
      watchRawAll(fn: Function) { ensureSetup(); const watcher = {keys: null, fn, active: true, raw: true}; watchers.push(watcher); return () => { watcher.active = false; }; },
    },
    state: {bool: (s: string, v: boolean) => state('bool', s, v), enum: (s: string, v: string, o: ${p}StateOptions) => state('enum', s, v, o), string: (s: string, v: string, o?: ${p}StateOptions) => state('string', s, v, o), numberDiscrete: (s: string, v: number, o?: ${p}StateOptions) => state('number.discrete', s, v, o), numberRange: (s: string, v: number, o: ${p}StateOptions) => state('number.range', s, v, o)},
    expose: {
      value: expose,
      state(key: string, handle: ${p}State${interacting ? ` | ${p}NativeObservedState<boolean | string | number>` : ''}) { ${interacting ? `const external = observedProjections.get(handle as ${p}NativeObservedState<boolean | string | number>)?.external ?? ('external' in handle ? handle.external : undefined); if (!external) throw new Error('Unknown external state projection'); expose(key, external);` : 'expose(key, handle.external);'} ${hasAuthoredHooks ? `${p}Authored.introduceObserved(handle);` : ''} },
      method<A extends unknown[], R>(key: string, fn: (...args: A) => R, project?: (value: R) => R) {  expose(key, (...args: unknown[]) => { ensureExternal(); const result = invoke(fn, args, false) as R; return project ? project(result) : result; }); },
      event(key: string) { ensureSetup(); if (own(exposes, key) || events.has(key)) throw new Error('Duplicate expose: ' + key); events.add(key); },
    },
    lifecycle: {onCreated(fn) { ensureSetup(); lifecycle.created.push(fn); }, onMounted(fn) { ensureSetup(); lifecycle.mounted.push(fn); }, onUpdated(fn) { ensureSetup(); lifecycle.updated.push(fn); }, onUnmounted(fn) { ensureSetup(); lifecycle.unmounted.push(fn); }, onBeforeDispose(fn) { ensureSetup(); lifecycle.beforeDispose.push(fn); }},
  };
  const owner: ${p}Owner = {
    ${publicCalls ? `wrapPublic: ${p}WrapPublic,` : ''}
    ${hasAuthoredHooks ? `authored: ${p}Authored,` : ''}
    ${atoms.shader ? `shader: ${p}Shader,` : ''}${atoms.delay ? `delay: ${atoms.names.delay},` : ''}${atoms.presence ? `presence: ${atoms.names.presence},` : ''}${atoms.meta ? `meta: ${atoms.names.meta},` : ''}
    identity: Symbol('compiled-logical-owner'), def, exposes, render: undefined,
${interacting ? `    interaction: ${p}Interaction,\n` : ''}
${styled ? `    style: ${p}Style, props: () => resolved as ${p}PropsSnapshot,\n` : ''}
    get epoch() { return epoch; }, get view() { return view; },
    hydrate, update: () => schedule(true), reconcile,
${
  ssr && !nativeBrowser
    ? `    validateHydration() {
      host.validateInitial?.({present: intent, attributes: {${styled ? "'data-pui-style': intent ? " + p + "Style.serverTokens().join(' ') || null : null," : ''}${interacting ? '...' + p + 'Interaction.projectAttributes()' : ''}}});
    },
    serialize() {
      ensure();
      if (!host.server) throw new Error('serialize requires a server owner');
      host.visible(intent);
      if (intent) render(); else host.commit([]);
${styled ? `      host.attribute('data-pui-style', intent ? ${p}Style.serverTokens().join(' ') || null : null);\n` : ''}${interacting ? `      if (intent) host.projectInteraction(${p}Interaction.projectAttributes());\n` : ''}      dirty = false;
    },\n`
    : ''
}
    created() { setup = false; fire('created'); },
    dispose(${ssr ? 'exhaustive = false' : ''}) {
      if (!alive || disposing) return; disposing = true;
      ${hasAuthoredHooks ? `for (const off of ${p}AuthoredWatchCleanups.splice(0)) off();` : ''}
      let error: { value: unknown } | undefined;
      try { detach(); } catch (caught) { error = { value: caught }; }
      try {
${
  ssr
    ? `        if (exhaustive) {
          for (const callback of lifecycle.beforeDispose) {
            try { invoke(callback); } catch (caught) { error ??= { value: caught }; }
          }
        } else `
    : ''
}        fire('beforeDispose');
      } catch (caught) { error ??= { value: caught }; }
      finally {
${
  interacting
    ? `        try { ${p}Interaction.dispose(); } catch (caught) { error ??= { value: caught }; }
        for (const off of observedSubscriptions.splice(0)) off();
        for (const projection of observedProjections.values()) projection.subscribers.clear();
        observedProjections.clear();\n`
    : ''
}
${styled ? `        ${p}Style.dispose(); ${ssr ? "host.attribute('data-pui-style', null);" : "host.removeAttribute('data-pui-style');"}\n` : ''}
${context ? `        ${p}OwnerScopes.delete(host); context.dispose(); ${ssr ? 'host.bindContext(null);' : ''}\n` : ''}        ${atoms.dispose}${hasAuthoredHooks ? `${p}Authored.dispose();` : ''} alive = false; ++epoch; dirty = false; watchers.length = 0; emissions.length = 0;
        for (const handle of states) handle.subscribers.clear();
        for (const callbacks of Object.values(lifecycle)) callbacks.length = 0;
${
  ssr
    ? '        host.clear();'
    : `        root.replaceChildren();
        if (detachedDisplay && host.style.getPropertyValue('display') === 'none' && host.style.getPropertyPriority('display') === 'important') {
          if (detachedDisplay.value) host.style.setProperty('display', detachedDisplay.value, detachedDisplay.priority);
          else host.style.removeProperty('display');
        }
        detachedDisplay = undefined;`
}
      }
      if (error) throw error.value;
    },
  };
  return owner;
}
`;
}
