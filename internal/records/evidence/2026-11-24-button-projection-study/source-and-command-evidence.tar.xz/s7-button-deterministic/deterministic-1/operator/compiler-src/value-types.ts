import { dataTypeEqual, isAssignable, parseDataType, type DataType } from './data-types';
import { memberDataType } from './expression-types';
import {
  isDataValueType,
  isCapabilityAssignable,
  type ExpressionIR,
  type FunctionIR,
  type ParameterIR,
  type ValueType,
} from './ir';

export type CallableType = Extract<ValueType, { kind: 'callable' }>;
export type ObjectValueType = Extract<ValueType, { kind: 'object' }>;

/** The shared child domain applies to operation arguments and ordinary formals. */
export function isTemplateChildType(type: ValueType): boolean {
  if (typeof type === 'string')
    return ['array', 'template', 'string', 'number', 'null'].includes(type);
  switch (type.kind) {
    case 'union':
    case 'value-union':
      return type.members.every(isTemplateChildType);
    case 'array':
      return isTemplateChildType(type.element);
    case 'literal':
      return (
        type.value === null || typeof type.value === 'string' || typeof type.value === 'number'
      );
    default:
      return false;
  }
}

export function functionValueType(fn: Pick<FunctionIR, 'parameters' | 'returnType'>): CallableType {
  return {
    kind: 'callable',
    parameters: fn.parameters.map(({ name, type, optional, default: value }) => ({
      name,
      type,
      ...(optional || value ? { optional: true } : {}),
    })),
    returnType: fn.returnType,
  };
}

/** A default accepts undefined at its input, even before a later required slot. */
export function parameterArgumentType(parameter: ParameterIR): ValueType {
  return parameter.optional || parameter.default
    ? joinValueTypes([parameter.type, 'void'])
    : parameter.type;
}

export function minimumArgumentCount(parameters: readonly ParameterIR[]): number {
  return parameters.reduce(
    (last, parameter, index) => (parameter.optional || parameter.default ? last : index + 1),
    0
  );
}

export function valueTypeEqual(a: ValueType, b: ValueType): boolean {
  if (a === b) return true;
  if (isDataValueType(a) && isDataValueType(b)) return dataTypeEqual(a, b);
  if (typeof a === 'string' || typeof b === 'string' || a.kind !== b.kind) return false;
  if (a.kind === 'capture' && b.kind === 'capture') return a.hookId === b.hookId;
  if (a.kind === 'cell' && b.kind === 'cell') return valueTypeEqual(a.value, b.value);
  if (a.kind === 'value-union' && b.kind === 'value-union')
    return (
      a.members.length === b.members.length &&
      a.members.every((member) => b.members.some((other) => valueTypeEqual(member, other)))
    );
  if (a.kind === 'object' && b.kind === 'object')
    return (
      (a.index === undefined
        ? b.index === undefined
        : b.index !== undefined && valueTypeEqual(a.index, b.index)) &&
      a.fields.length === b.fields.length &&
      a.fields.every((field) =>
        b.fields.some(
          (other) =>
            field.name === other.name &&
            !!field.optional === !!other.optional &&
            !!field.readonly === !!other.readonly &&
            field.accessor === other.accessor &&
            valueTypeEqual(field.type, other.type)
        )
      )
    );
  if (a.kind === 'callable' && b.kind === 'callable')
    return (
      (a.lookup === undefined
        ? b.lookup === undefined
        : b.lookup !== undefined &&
          a.lookup.length === b.lookup.length &&
          a.lookup.every((entry) =>
            b.lookup!.some(
              (other) => entry.key === other.key && valueTypeEqual(entry.type, other.type)
            )
          )) &&
      a.parameters.length === b.parameters.length &&
      a.parameters.every(
        (parameter, index) =>
          !!parameter.optional === !!b.parameters[index].optional &&
          valueTypeEqual(parameter.type, b.parameters[index].type)
      ) &&
      valueTypeEqual(a.returnType, b.returnType)
    );
  return false;
}

export function valueAlternatives(type: ValueType): ValueType[] {
  return typeof type !== 'string' && (type.kind === 'union' || type.kind === 'value-union')
    ? type.members.flatMap(valueAlternatives)
    : [type];
}

export function joinValueTypes(types: readonly ValueType[]): ValueType {
  const members: ValueType[] = [];
  for (const type of types.flatMap(valueAlternatives))
    if (!members.some((other) => valueTypeEqual(type, other))) members.push(type);
  if (members.length === 1) return members[0];
  if (members.every(isDataValueType)) return parseDataType({ kind: 'union', members });
  return { kind: 'value-union', members };
}

/** A structural type view never removes fields from the runtime object. */
export function containsRuntimeAuthority(type: ValueType): boolean {
  if (isDataValueType(type)) return false;
  if (typeof type === 'string') return true;
  if (type.kind === 'object')
    return (
      (type.index !== undefined && containsRuntimeAuthority(type.index)) ||
      type.fields.some((field) => !!field.accessor || containsRuntimeAuthority(field.type))
    );
  if (type.kind === 'value-union') return type.members.some(containsRuntimeAuthority);
  return true;
}

/** Data width subtyping is safe; dropping a hidden closure or owner capability is not. */
export function erasesRuntimeAuthority(actual: ValueType, expected: ValueType): boolean {
  if (expected === 'unknown' || valueTypeEqual(actual, expected)) return false;
  const originals = valueAlternatives(actual),
    targets = valueAlternatives(expected);
  if (originals.length > 1) return originals.some((type) => erasesRuntimeAuthority(type, expected));
  if (targets.length > 1) return targets.every((type) => erasesRuntimeAuthority(actual, type));
  const from = objectFields(actual),
    to = objectFields(expected);
  if (from && to) {
    const index =
      typeof expected !== 'string' && expected.kind === 'object' ? expected.index : undefined;
    if (
      typeof actual !== 'string' &&
      actual.kind === 'object' &&
      actual.index !== undefined &&
      index === undefined &&
      containsRuntimeAuthority(actual.index)
    )
      return true;
    return from.some((field) => {
      const destinationField = to.find((other) => other.name === field.name);
      // A scalar getter is still executable authority. A structural view must
      // retain that fact even when its return value is ordinary public data.
      if (field.accessor && field.accessor !== destinationField?.accessor) return true;
      const destination = destinationField?.type ?? index;
      return destination === undefined
        ? containsRuntimeAuthority(field.type)
        : erasesRuntimeAuthority(field.type, destination);
    });
  }
  if (
    typeof actual !== 'string' &&
    actual.kind === 'callable' &&
    typeof expected !== 'string' &&
    expected.kind === 'callable'
  )
    return (
      (expected.returnType === 'void'
        ? containsRuntimeAuthority(actual.returnType)
        : erasesRuntimeAuthority(actual.returnType, expected.returnType)) ||
      actual.parameters.some(
        (parameter, index) =>
          expected.parameters[index] !== undefined &&
          erasesRuntimeAuthority(expected.parameters[index].type, parameter.type)
      )
    );
  return containsRuntimeAuthority(actual) && isDataValueType(expected);
}

export function valueAssignable(actual: ValueType, expected: ValueType): boolean {
  // Unknown erases knowledge. Reading it still cannot grant a callable or capability type.
  if (expected === 'unknown') return true;
  if (valueTypeEqual(actual, expected) || isCapabilityAssignable(actual, expected)) return true;
  if (erasesRuntimeAuthority(actual, expected)) return false;
  if (expected === 'template' && isTemplateChildType(actual)) return true;
  if (typeof actual !== 'string' && (actual.kind === 'value-union' || actual.kind === 'union'))
    return actual.members.every((member) => valueAssignable(member, expected));
  if (
    typeof expected !== 'string' &&
    (expected.kind === 'value-union' || expected.kind === 'union')
  )
    return expected.members.some((member) => valueAssignable(actual, member));
  if (isDataValueType(actual) && isDataValueType(expected)) return isAssignable(actual, expected);
  const aFields = objectFields(actual),
    bFields = objectFields(expected);
  if (aFields && bFields) {
    const aIndex =
      typeof actual !== 'string' && actual.kind === 'object' ? actual.index : undefined;
    const bIndex =
      typeof expected !== 'string' && expected.kind === 'object' ? expected.index : undefined;
    if (
      bIndex !== undefined &&
      ((aIndex !== undefined && !valueAssignable(aIndex, bIndex)) ||
        aFields.some((field) => !valueAssignable(field.type, bIndex)))
    )
      return false;
    return bFields.every((field) => {
      const source = aFields.find((other) => other.name === field.name);
      return source
        ? (!source.optional || !!field.optional) &&
            (!source.readonly || !!field.readonly) &&
            valueAssignable(source.type, field.type)
        : !!field.optional;
    });
  }
  if (
    typeof actual !== 'string' &&
    actual.kind === 'callable' &&
    typeof expected !== 'string' &&
    expected.kind === 'callable'
  ) {
    // A precise lookup result is authority supplied by the actual capture getter,
    // never by an arbitrary function with a superficially compatible signature.
    // The map is complete: checkedCall interprets an absent key as undefined.
    // Dropping entries would therefore erase real return values and capabilities.
    if (
      expected.lookup !== undefined &&
      (actual.lookup === undefined ||
        actual.lookup.length !== expected.lookup.length ||
        !expected.lookup.every((entry) =>
          actual.lookup!.some(
            (other) => entry.key === other.key && valueTypeEqual(entry.type, other.type)
          )
        ))
    )
      return false;
    if (minimumArgumentCount(actual.parameters) > minimumArgumentCount(expected.parameters))
      return false;
    return (
      actual.parameters.every(
        (parameter, index) =>
          !expected.parameters[index] ||
          valueAssignable(
            parameterArgumentType(expected.parameters[index]),
            parameterArgumentType(parameter)
          )
      ) &&
      (expected.returnType === 'void' || valueAssignable(actual.returnType, expected.returnType))
    );
  }
  return expected === 'function' && typeof actual !== 'string' && actual.kind === 'callable';
}

export function objectFields(
  type: ValueType
): readonly ObjectValueType['fields'][number][] | undefined {
  return typeof type !== 'string' && (type.kind === 'object' || type.kind === 'record')
    ? type.fields
    : undefined;
}

export function objectValueType(fields: ObjectValueType['fields']): ValueType {
  return fields.every((field) => isDataValueType(field.type) && !field.readonly && !field.accessor)
    ? {
        kind: 'record',
        fields: fields.map(({ name, type, optional }) => ({
          name,
          type: type as DataType,
          ...(optional ? { optional: true } : {}),
        })),
      }
    : { kind: 'object', fields };
}

/** Copy invokes source getters; an absent optional field does not replace an existing getter. */
export function spreadObjectField(
  previous: ObjectValueType['fields'][number] | undefined,
  incoming: ObjectValueType['fields'][number]
): ObjectValueType['fields'][number] {
  const { readonly: _readonly, accessor: _accessor, ...field } = incoming;
  if (incoming.optional && previous?.accessor)
    return {
      name: field.name,
      type: joinValueTypes([previous.type, field.type, 'void']),
      readonly: true,
      accessor: 'get',
    };
  return field;
}

/** Prove an outward JSON snapshot without erasing the expression's readonly view.
 * Capabilities, callbacks, open dictionaries and nested undefined are never data. */
export function dataBoundaryType(type: ValueType, top = true): DataType | undefined {
  if (typeof type === 'string')
    return ['boolean', 'number', 'string', 'null'].includes(type) || (top && type === 'void')
      ? (type as DataType)
      : undefined;
  if (type.kind === 'literal') return type;
  if (type.kind === 'array') {
    const element = dataBoundaryType(type.element, false);
    return element ? { kind: 'array', element } : undefined;
  }
  if (type.kind === 'union' || type.kind === 'value-union') {
    const members = type.members.map((member) => dataBoundaryType(member, top));
    return members.every((member): member is DataType => member !== undefined)
      ? { kind: 'union', members }
      : undefined;
  }
  if (
    (type.kind === 'record' || type.kind === 'object') &&
    !('index' in type && type.index !== undefined)
  ) {
    const fields: { name: string; type: DataType; optional?: boolean }[] = [];
    for (const field of type.fields) {
      const value = dataBoundaryType(field.type, false);
      if (!value) return undefined;
      fields.push({ name: field.name, type: value, ...(field.optional ? { optional: true } : {}) });
    }
    return { kind: 'record', fields };
  }
  return undefined;
}

/** JSON publication copies data; readonly source fields do not carry authority. */
export function publishedDataType(type: ValueType): DataType | undefined {
  if (isDataValueType(type)) return type;
  if (typeof type === 'string') return undefined;
  if (type.kind === 'object' && type.index === undefined) {
    const fields: { name: string; type: DataType; optional?: boolean }[] = [];
    for (const field of type.fields) {
      // A readonly data field is copyable; a getter still carries executable authority.
      if (field.accessor) return undefined;
      const data = publishedDataType(field.type);
      if (!data) return undefined;
      fields.push({ name: field.name, type: data, ...(field.optional ? { optional: true } : {}) });
    }
    return { kind: 'record', fields };
  }
  return undefined;
}

export function memberValueType(owner: ValueType, key: string, optional = false): ValueType {
  const types = valueAlternatives(owner).map((type) => {
    if (type === 'null' || type === 'void') {
      if (optional) return 'void' as const;
      throw new TypeError(`Cannot read ${key} on a nullish value.`);
    }
    if (isDataValueType(type)) return memberDataType(type, key, { optional });
    // Opaque snapshots expose keys without proving their presence or value shape.
    if (type === 'record') return 'unknown';
    const field = objectFields(type)?.find((field) => field.name === key);
    if (!field) {
      if (typeof type !== 'string' && type.kind === 'object' && type.index !== undefined)
        return joinValueTypes([type.index, 'void']);
      throw new TypeError(`Undeclared object member ${key}.`);
    }
    return field.optional ? joinValueTypes([field.type, 'void']) : field.type;
  });
  return joinValueTypes(types);
}

export function callableValue(type: ValueType, optional = false): CallableType {
  const members = valueAlternatives(type).filter(
    (member) => !optional || (member !== 'null' && member !== 'void')
  );
  const first = members[0];
  if (
    !first ||
    typeof first === 'string' ||
    first.kind !== 'callable' ||
    !members.every((member) => valueTypeEqual(member, first))
  )
    throw new TypeError('Call requires a statically typed callable value.');
  return first;
}

export function checkedCall(
  type: ValueType,
  args: readonly ValueType[],
  optional = false
): ValueType {
  const fn = callableValue(type, optional);
  const required = minimumArgumentCount(fn.parameters);
  if (args.length < required || args.length > fn.parameters.length)
    throw new TypeError('Callable argument count mismatch.');
  args.forEach((argument, index) => {
    if (erasesRuntimeAuthority(argument, fn.parameters[index].type))
      throw new TypeError(
        'A callable argument cannot hide runtime callable or capability fields behind a structural type view.'
      );
    if (
      !(argument === 'void' && fn.parameters[index].optional) &&
      !valueAssignable(argument, fn.parameters[index].type)
    )
      throw new TypeError(`Callable argument ${index + 1} type mismatch.`);
  });
  const keys = args[0] === undefined ? [] : valueAlternatives(args[0]);
  const result =
    fn.lookup &&
    keys.length &&
    keys.every(
      (key) => typeof key !== 'string' && key.kind === 'literal' && typeof key.value === 'string'
    )
      ? joinValueTypes(
          keys.map(
            (key) =>
              fn.lookup!.find(
                (entry) => entry.key === (key as { kind: 'literal'; value: string }).value
              )?.type ?? 'void'
          )
        )
      : fn.returnType;
  return optional &&
    valueAlternatives(type).some((member) => member === 'null' || member === 'void')
    ? joinValueTypes([result, 'void'])
    : result;
}

/** Every supplies these three values even when the callback declares fewer formals. */
export function arrayEveryCallbackParameters(
  array: Extract<ValueType, { kind: 'array' }>
): CallableType['parameters'] {
  return [
    { name: 'value', type: array.element },
    { name: 'index', type: 'number' },
    { name: 'array', type: array },
  ];
}

export function intrinsicResult(
  name: string,
  args: readonly ValueType[],
  expressions?: readonly ExpressionIR[]
): ValueType {
  if (name === 'object.assign') {
    if (!args.length || !expressions || expressions.length !== args.length)
      throw new TypeError('Object.assign requires a checked fresh target and own-data records.');
    const fields = new Map<string, ValueType>();
    const copyRecord = (value: ExpressionIR, type: ValueType, source = false): void => {
      if (
        value.kind !== 'record' ||
        typeof type === 'string' ||
        (type.kind !== 'record' && !(source && type.kind === 'object')) ||
        !objectFields(type)?.every((field) => isDataValueType(field.type)) ||
        value.entries.some(
          (entry) =>
            entry.key === '__proto__' ||
            (entry.accessor
              ? !source ||
                entry.value.kind !== 'function' ||
                !isDataValueType(entry.value.function.returnType)
              : !isDataValueType(entry.value.type))
        )
      )
        throw new TypeError(
          'Object.assign requires a fresh data target and direct finite record sources without __proto__; source getters must return data.'
        );
      for (const field of objectFields(type)!) fields.set(field.name, field.type);
    };
    const target = expressions[0];
    const error = target.kind === 'intrinsic' && target.name === 'error' && args[0] === 'exception';
    if (!error) copyRecord(target, args[0]);
    for (let index = 1; index < expressions.length; index++)
      copyRecord(expressions[index], args[index], true);
    return error
      ? 'exception'
      : objectValueType([...fields].map(([name, type]) => ({ name, type })));
  }
  if (
    name === 'array.includes' &&
    args.length === 2 &&
    typeof args[0] !== 'string' &&
    args[0].kind === 'array' &&
    valueAlternatives(args[0].element).length > 0 &&
    valueAlternatives(args[0].element).every(
      (type) =>
        typeof type !== 'string' && type.kind === 'literal' && typeof type.value === 'string'
    )
  )
    return 'boolean';
  if (name === 'typeof' && args.length === 1) return 'string';
  if (name === 'number') {
    if (
      args.length <= 1 &&
      args.every((type) =>
        valueAlternatives(type).every(
          (member) =>
            member === 'number' ||
            member === 'string' ||
            member === 'boolean' ||
            member === 'null' ||
            member === 'void' ||
            (typeof member !== 'string' && member.kind === 'literal')
        )
      )
    )
      return 'number';
    throw new TypeError('Number requires zero or one scalar data operand.');
  }
  if (name === 'string') {
    if (
      args.length <= 1 &&
      args.every((type) =>
        valueAlternatives(type).every((member) => member === 'unknown' || isDataValueType(member))
      )
    )
      return 'string';
    throw new TypeError('String requires zero or one data or opaque unknown operand.');
  }
  if (name === 'error' && args.length <= 1 && (args.length === 0 || args[0] === 'string'))
    return 'exception';
  if (name === 'number.isFinite' && args.length === 1 && isDataValueType(args[0])) return 'boolean';
  if (
    (name === 'math.round' || name === 'math.floor') &&
    args.length === 1 &&
    valueAssignable(args[0], 'number')
  )
    return 'number';
  if (name === 'string' && args.length === 1 && (isDataValueType(args[0]) || args[0] === 'unknown'))
    return 'string';
  if (name === 'object.freeze' && args.length === 1 && objectFields(args[0])) return args[0];
  if (
    name === 'object.hasOwn' &&
    args.length === 2 &&
    objectFields(args[0]) &&
    (args[1] === 'string' || args[1] === 'number')
  )
    return 'boolean';
  if (
    name === 'array.every' &&
    args.length === 2 &&
    typeof args[0] !== 'string' &&
    args[0].kind === 'array'
  ) {
    const fn = callableValue(args[1]);
    checkedCall(
      fn,
      arrayEveryCallbackParameters(args[0])
        .slice(0, fn.parameters.length)
        .map((parameter) => parameter.type)
    );
    return 'boolean';
  }
  throw new TypeError(`Invalid intrinsic ${name} arguments.`);
}

export function parameterValueType(parameter: ParameterIR): ValueType {
  return parameter.optional && !parameter.default
    ? joinValueTypes([parameter.type, 'void'])
    : parameter.type;
}

/** Erased assertions may remove alternatives, never invent an authority-bearing field. */
export function canNarrowValue(source: ValueType, target: ValueType): boolean {
  if (valueAssignable(source, target)) return true;
  if (isDataValueType(source) && isDataValueType(target)) return valueAssignable(target, source);
  const originals = valueAlternatives(source),
    targets = valueAlternatives(target);
  return targets.every((target) =>
    originals.some(
      (original) =>
        valueTypeEqual(original, target) ||
        (isDataValueType(original) && isDataValueType(target) && valueAssignable(target, original))
    )
  );
}
