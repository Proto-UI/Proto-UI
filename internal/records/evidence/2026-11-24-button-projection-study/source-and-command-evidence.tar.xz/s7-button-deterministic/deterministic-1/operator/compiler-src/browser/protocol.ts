import type { CompilerDiagnostic, GeneratedModule, PrototypeIR } from '../ir';
import type { CompileOptions } from '../memory';

export const BROWSER_COMPILER_LIMITS = Object.freeze({
  inputBytes: 256 * 1024,
  outputCharacters: 8 * 1024 * 1024,
  memoryBytes: 128 * 1024 * 1024,
  stackBytes: 2 * 1024 * 1024,
  initializationMs: 30_000,
  compilationMs: 30_000,
  workerResponseMs: 35_000,
});

export interface BrowserCompileRequest {
  format: 1;
  revision: string;
  source: string;
  /** Closed virtual graph and an explicit versioned target; no host filesystem options. */
  options: Omit<CompileOptions, 'nativeSdkPath' | 'gpuiDependency' | 'profile' | 'fileName'> & {
    profile: NonNullable<CompileOptions['profile']>;
    fileName: string;
  };
  /** Transpile only checked generated Web source for the isolated preview. */
  preview?: boolean;
}

export interface BrowserPreviewArtifact {
  format: 1;
  entry: string;
  modules: Record<string, string>;
  styles: string[];
  /** Checked outward event names for ordinary target listener wiring. */
  events: string[];
  /** Applies only to the preview copies, never to canonical generated source. */
  executionBudget: '100000-checkpoints-per-task-v1';
}

export type BrowserCompileResult =
  | {
      ok: true;
      revision: string;
      requestSha256: string;
      source: PrototypeIR['source'];
      output: GeneratedModule;
      preview?: BrowserPreviewArtifact;
    }
  | {
      ok: false;
      revision: string;
      requestSha256: string;
      phase: 'compile';
      diagnostics: CompilerDiagnostic[];
    }
  | {
      ok: false;
      revision: string;
      phase: 'host';
      requestSha256?: string;
      error: {
        code:
          | 'invalid-request'
          | 'input-limit'
          | 'execution-limit'
          | 'wasm-execution'
          | 'preview-policy'
          | 'disposed';
        message: string;
      };
    };

export interface BrowserCompilerBuild {
  format: 1;
  /** Digest of the actual trusted compiler bundle, distinct from authored source identity. */
  compilerSha256: string;
  typescriptVersion: string;
  execution: 'quickjs-wasm';
}

export interface CompilerWorkerRequest {
  type: 'compile';
  id: number;
  request: BrowserCompileRequest;
}

export interface CompilerWorkerResponse {
  type: 'compiled';
  id: number;
  requestSha256: string;
  result: BrowserCompileResult;
  build: BrowserCompilerBuild;
  elapsedMs: number;
}

export type CompilerWorkerInput =
  | CompilerWorkerRequest
  | {
      type: 'initialize';
      bundle: string;
      build: BrowserCompilerBuild;
    };

export type CompilerWorkerOutput =
  | CompilerWorkerResponse
  | { type: 'ready'; build: BrowserCompilerBuild }
  | { type: 'initialization-error'; message: string };
