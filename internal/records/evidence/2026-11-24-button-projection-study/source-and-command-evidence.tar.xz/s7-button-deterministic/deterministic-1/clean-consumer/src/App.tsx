import * as React from 'react';
import { GeneratedButton } from '../generated/Component';
export function App() {
  const [count, setCount] = React.useState(0);
  const [disabled, setDisabled] = React.useState(false);
  return <main><h1>Artifact preflight</h1><GeneratedButton disabled={disabled} onClick={() => setCount(value => value + 1)}>Save preference</GeneratedButton><output aria-label="Activations">{count}</output><label><input type="checkbox" checked={disabled} onChange={event => setDisabled(event.target.checked)} />Disable action</label></main>;
}
