export type NativeAnatomyFamily = {
    debugName: string;
    roles: Readonly<Record<string, {
        cardinality: {
            min: number;
            max: number | '*';
        };
        requires?: readonly {
            kind: string;
            name: string;
        }[];
    }>>;
    relations?: readonly unknown[];
    profiles?: Readonly<Record<string, unknown>>;
};
export type NativeControlLabelAnatomyPair = Readonly<{
    family: NativeAnatomyFamily;
    labelRole: string;
    targetRole: string;
}>;
export type NativeControlLabelRequest = Readonly<{
    source: 'pointer' | 'accessibility';
    isCurrent(): boolean;
}>;
export type NativeControlLabelHandle = Readonly<{
    sync(options: Readonly<{
        naming: boolean;
        activation: boolean;
    }>): void;
}>;
export type NativeControlLabel<Run = unknown> = Readonly<{
    label(pair?: NativeControlLabelAnatomyPair): NativeControlLabelHandle;
    target(activate: (run: Run, request: NativeControlLabelRequest) => void, pair?: NativeControlLabelAnatomyPair): NativeControlLabelHandle;
}>;
