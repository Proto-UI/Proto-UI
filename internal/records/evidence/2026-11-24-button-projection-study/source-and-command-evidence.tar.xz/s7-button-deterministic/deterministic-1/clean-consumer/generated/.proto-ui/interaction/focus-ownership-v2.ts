import type { Owner, NativeFocusRequest } from './ownership-v2';
export const focusState: { scopeRevision: number; focusRequestEpoch: number; scopeEntryIntent: ScopeEntryIntent | undefined } = { scopeRevision: 0, focusRequestEpoch: 0, scopeEntryIntent: undefined };
export const activeScopes: Owner[] = [];
export type ScopeEntryIntent = {
    cancel(): void;
};
/** Internal request bookkeeping shared with the native-only Focus bridge. */
export function noteNativeFocusRequest(owner?: ScopeEntryIntent): boolean {
    const epoch = ++focusState.focusRequestEpoch, previous = focusState.scopeEntryIntent;
    focusState.scopeEntryIntent = owner;
    if (previous !== owner)
        previous?.cancel();
    return epoch === focusState.focusRequestEpoch && focusState.scopeEntryIntent === owner;
}
