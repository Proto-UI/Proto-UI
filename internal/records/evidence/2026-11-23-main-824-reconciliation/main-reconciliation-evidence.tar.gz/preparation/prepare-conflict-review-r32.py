from pathlib import Path
import json,subprocess,hashlib,re
T=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/continuation-root-4deb/selector-integration-r5-6e2cebee');K=Path('/dev/shm/pui-publish-4deb-r6-el3agft4/repository');E=T/'main-conflict-review-r32';E.mkdir(exist_ok=True)
r=json.loads((T/'main-integration-prep-r30/receipt.json').read_text());raw=(T/'main-integration-prep-r30/merge-tree.stdout').read_text()
paths=sorted({line.split('\t',1)[1] for line in raw.splitlines() if re.match(r'^100[0-9]{3} [0-9a-f]{40} [123]\t',line)})
def git(*args):return subprocess.check_output(['git',*args],cwd=K,text=True)
review=[]
for i,path in enumerate(paths):
 d={'path':path,'base':git('show',r['mergeBase']+':'+path),'current':git('show',r['head']+':'+path),'upstream':git('show',r['upstream']+':'+path),'proposed':git('show',r['proposedTree']+':'+path),'currentDiff':git('diff',r['mergeBase'],r['head'],'--',path),'upstreamDiff':git('diff',r['mergeBase'],r['upstream'],'--',path)}
 dest=E/(str(i)+'.json');dest.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');review.append({'path':path,'artifact':str(dest),'bytes':dest.stat().st_size})
(E/'index.json').write_text(json.dumps(review,indent=2)+'\n')
(E/'delta-stat.txt').write_text(git('diff','--stat',r['head'],r['proposedTree']))
(E/'delta-paths.txt').write_text(git('diff','--name-status',r['head'],r['proposedTree']))
(E/'receipt.json').write_text(json.dumps({'state':'completed','conflictCount':len(paths),'review':review},indent=2)+'\n')
