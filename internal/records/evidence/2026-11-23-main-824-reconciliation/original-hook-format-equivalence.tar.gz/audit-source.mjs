import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
const B='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono',T='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/continuation-root-4deb/selector-integration-r5-6e2cebee',K='/dev/shm/pui-publish-4deb-r6-el3agft4/repository',E=path.join(T,'main-format-audit-r38');
fs.mkdirSync(E);const require=createRequire(import.meta.url);
const ts=require(path.join(B,'continuation-root-analysis-4deb/node_modules/typescript'));
const yaml=require(path.join(B,'continuation-root-analysis-4deb/node_modules/yaml'));
const previous=JSON.parse(fs.readFileSync(path.join(T,'main-integration-r36/receipt.json'),'utf8'));
const s={state:'running',startedAt:new Date().toISOString(),publicWrites:0,typescript:ts.version,files:[]};
const save=()=>fs.writeFileSync(path.join(E,'receipt.json'),JSON.stringify(s,null,2)+'\n');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const git=(...a)=>execFileSync('git',a,{cwd:K,maxBuffer:32*1024*1024});
const canonical=x=>Array.isArray(x)?x.map(canonical):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,canonical(x[k])])):x;
function syntax(text,filename){
 const sf=ts.createSourceFile(filename,text,ts.ScriptTarget.Latest,true);
 if(sf.parseDiagnostics.length)throw new Error('parse diagnostics '+filename);
 function visit(node){
  if(ts.isParenthesizedExpression(node))return visit(node.expression);
  const children=[];ts.forEachChild(node,child=>{children.push(visit(child));});
  const value={kind:node.kind,flags:node.flags,children};
  for(const name of ['text','rawText','isTypeOnly','isExportEquals'])
   if((typeof node[name]==='string'||typeof node[name]==='boolean') && !ts.isSourceFile(node))value[name]=node[name];
  return value;
 }
 return JSON.stringify(visit(sf));
}
save();
try{
 if(previous.state!=='staged-and-formatted')throw new Error('unexpected merge preparation state');
 for(const filename of previous.hookChangedPaths){
  const before=git('show',previous.treeBeforeOriginalHook+':'+filename);
  const after=git('show',previous.treeAfterOriginalHook+':'+filename);
  for(const [label,content]of[['before',before],['after',after]]){
   const dest=path.join(E,'sources',label,filename);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,content);
  }
  const item={path:filename,beforeSha256:sha(before),afterSha256:sha(after)};
  if(filename.endsWith('.json')){item.kind='json-data';item.equal=JSON.stringify(canonical(JSON.parse(before)))===JSON.stringify(canonical(JSON.parse(after)));}
  else if(/\.ya?ml$/.test(filename)){item.kind='yaml-data';item.equal=JSON.stringify(canonical(yaml.parse(before.toString())))===JSON.stringify(canonical(yaml.parse(after.toString())));}
  else if(/\.[cm]?[jt]sx?$/.test(filename)){item.kind='typescript-syntax';const a=syntax(before.toString(),filename),b=syntax(after.toString(),filename);item.equal=a===b;item.beforeSyntaxSha256=sha(a);item.afterSyntaxSha256=sha(b);if(!item.equal){fs.writeFileSync(path.join(E,sha(filename)+'.before-syntax.json'),a);fs.writeFileSync(path.join(E,sha(filename)+'.after-syntax.json'),b);}}
  else{item.kind='prose';item.equal=null;}
  s.files.push(item);save();
 }
 s.state=s.files.some(x=>x.equal===false)?'difference-needs-review':'syntax-data-equal-prose-review-pending';
 s.finishedAt=new Date().toISOString();save();
}catch(e){s.state='failed';s.error=String(e);s.stack=e.stack;save();throw e;}
