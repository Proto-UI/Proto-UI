# 独立只读审查：预算提交复用与 Header optional scene 分块

日期：2026-11-24  
审查者：本轮独立子任务 `budget_audit`  
范围：只读审查、内存 Rollup 对照及临时诊断证据；没有修改生产源码、预算常量或并行 lane 的工作树。

## 结论

1. 支持原样复用预算原提交 `024bc193c35ca74d1893b4c479b148707a8cdd9a`，通过正常 merge 纳入本轮修复。原提交已经是独立 numeric transaction，保留作者、DCO、原始 canonical 报告和数值决定。未发现必须独立开 PR 或禁止当前已授权修复复用该提交的约束。
2. 对九个 whole-entry 的全部 3,840 个唯一输入文件进行了 Git blob 核对：原预算报告的输入与 `06d4f20249d8128575d6e0e13385e9dcf540c84c`、`4a556a37acdda77e2cbbc59bb9f10c259b8b5036` 均逐文件一致。这证明历史数值决定的源码依据仍适用，不将历史测量改称新 head 的通过结果。
3. Header 的局部替代方案“仅给 shader-scene-host 命名 chunk”通过最初的两个 fixture，但在合法的纯 re-export 动态入口上重新产生 eager scene。`hoistTransitiveImports: false` 和 `preserveEntrySignatures: 'strict'` 均不能修复该变体。推荐保留仅作用于 client 的 `onlyExplicitManualChunks: true`，如实记录已观察到的 chunk 和字节成本。
4. 本文不是 GitHub APPROVE、canonical review packet 或所有 CI 的通过证明。第五节已补充本审查者对最新合并 head 的 raw strict report、receipt 和原始 Git commit 对象的独立只读核验；没有重新运行预算测量，也不将远端 strict 执行等同于已完成的 GitHub canonical check。

## 一、预算原提交的来源和独立性

### 实际读取的提交

| 对象 | 核验结果 |
| --- | --- |
| 原 numeric commit | `024bc193c35ca74d1893b4c479b148707a8cdd9a` |
| 原提交父节点 | `248f8270dd3458d1fcbc507e618337f98b9fde96` |
| 原作者 / 提交者 | `Codex <codex@openai.com>` |
| DCO trailer | `Signed-off-by: Codex <codex@openai.com>` |
| 并行 root 挑选提交 | `1c17caa89a89b27859fce9ae4f575daee84136cf`；正文保留 `(cherry picked from commit 024bc193c35ca74d1893b4c479b148707a8cdd9a)` |
| 审查时本轮 head | `4a556a37acdda77e2cbbc59bb9f10c259b8b5036` |
| 本轮 head 与原 numeric commit 的 merge-base | `248f8270dd3458d1fcbc507e618337f98b9fde96` |

`git rev-list --count 4a556a37acdda77e2cbbc59bb9f10c259b8b5036..024bc193c35ca74d1893b4c479b148707a8cdd9a` 的结果为 **1**。两侧相对 merge-base 的改动路径交集为空。复用原提交不会顺带带入并行 repair 分支的 CLI、Portal 或其他后续提交。

原提交只修改以下四个文件：

- `scripts/analysis/package-budgets.mjs`
- `internal/records/2026-11-24-main-sprint6-package-budget.json`
- `internal/records/evidence/2026-11-24-main-sprint6-package-budget/canonical-before-b939.json.gz`
- `internal/records/evidence/2026-11-24-main-sprint6-package-budget/canonical-capability-041.json.gz`

脚本差异仅为五个 ceiling 常量和解释性注释；没有改变入口、bundling/minification、压缩、external 依赖、diagnostic profile、strict/advisory policy 或 pass/fail 语义。原提交 `git diff --check` 通过。

### 适用的仓库要求

本次读取了 `AGENTS.md`、`.agents/skills/pui-dev/SKILL.md` 的 package-budget 规则和 `.agents/skills/pui-package-budget/SKILL.md`。规则允许已授权开发任务对已接受能力的成本作有依据的 bounded numeric transaction，要求 **dedicated commit 或 focused PR**，并要求最终候选验证、独立 review 和正常集成条件。它不要求每笔事务必须另开 PR。

并行 lane 的已有 `implementation-authorization.json` 限定五个常量及其证据，明确禁止 source/policy 改动；`final-handoff.json` 记录 numeric commit 的局部 strict 9/9，并将最终集成、canonical CI 和独立 review 留给集成方。该 handoff 不是当前 head 的通过证明，也不是外部写入权限的替代品。

基于当前用户要求核实并修复这三项问题的范围，原样复用已完成的 numeric commit 有来源依据。未修改并行 lane 的工作树，也未重新制定任何阈值。

## 二、九个入口的源码和工具绑定

### 核验方法

读取历史 clean report：

`/workspace/scratch/f9b031b72bbf/budget-candidate-024bc193.json`

其 SHA256 为：

`b7cf238df326e6029ddbe0f7e73d404180c81bde23e881142d990d40f0fbda02`

从九个 `results[].closure.inputs` 收集全部 **3,840 个唯一输入路径**。用 `git ls-tree -r -z` 比较三个 revision 的 blob 身份，再用 `git cat-file --batch` 读取 `4a556a37` 的 blob，逐一核对历史报告中的 `sourceBytes` 和 `sourceSha256`。

- `024bc193` 对 `06d4f202`：零缺失，零输入内容差异。
- `024bc193` 对 `4a556a37`：零缺失，零输入内容差异。
- `4a556a37` 的全部输入内容与报告的 bytes / SHA256：零不一致。
- 检查包含 rendered length 为零的输入，不只覆盖 retained 模块。

下表是 **024bc193 的历史实测结果**。各入口共享输入，表内输入数不可相加当作唯一文件数。

| 入口 | 输入数 | retained 输入数 | 历史 gzip bytes | 原 numeric commit ceiling | 历史余量 |
| --- | ---: | ---: | ---: | ---: | ---: |
| lucide/icons/x | 53 | 8 | 1,797 | 3,000 | 1,203 |
| lucide root | 3,453 | 3,450 | 635,846 | 700,000 | 64,154 |
| core root | 49 | 27 | 12,967 | 13,100 | 133 |
| runtime root | 298 | 180 | 106,822 | 107,400 | 578 |
| adapter-react root | 353 | 249 | 179,944 | 180,900 | 956 |
| adapter-vue root | 352 | 248 | 178,760 | 179,700 | 940 |
| adapter-web-component root | 381 | 277 | 216,252 | 217,400 | 1,148 |
| prototypes-base/button | 75 | 27 | 4,311 | 6,000 | 1,689 |
| prototypes-shadcn/button | 84 | 33 | 6,739 | 7,900 | 1,161 |

### Manifest、policy 和版本核验

以下文件在 `024bc193` 与 `4a556a37` 上的 Git blob 相同：

- `pnpm-lock.yaml`
- `pnpm-workspace.yaml`
- `tsconfig.json`
- `scripts/analysis/package-budget-policy.mjs`
- `scripts/analysis/package-budget-evidence.mjs`
- `internal/coverage-matrices/prototype-coverage-matrix.json`

各 package manifest 没有变化。根 `package.json` 只有 `scripts.test:runtime` 增加 process owner 测试的变化；dependency 及其余 manifest 字段没有改变。`248f8270` 之后确有 CLI、compiler、Bootstrap 源文件变化，但这些文件不在九入口已记录的输入集合中。

历史报告与本次检查时的本地工具版本一致：

| 工具 / 环境 | 值 |
| --- | --- |
| Node | `v24.22.3` |
| esbuild | `0.25.12` |
| zlib | `1.3.2.1-motley-285e94b` |
| OS / architecture | `linux` / `x64` |
| bundle / minify / treeShaking | `true` / `true` / `true` |
| format / platform / target | `esm` / `browser` / `es2020` |
| gzip level | `9` |
| external list SHA256 | `6a8bd56596b933f9a9d941db2a9e325789b44886af2648d6a9795f022787c253` |

总体 `source.fingerprintSha256` 覆盖整个 source scope，不只覆盖这九个实际输入闭包。因为根 package script 和 scope 内其他文件已经改变，不能复用原 fingerprint 冒充新 head 身份。源码输入一致也不代替新候选测量。

## 三、canonical 原件及历史通过边界

独立重新解压了原提交中的两份 gzip 档案，SHA256 如下：

| 档案 | gzip 文件 SHA256 | 解压后原报告 SHA256 |
| --- | --- | --- |
| canonical-before-b939.json.gz | `35bd0edbc93237b252af698f74aae2fe19459bc1ec1b823662aedfa40227d402` | `7260777668efe6d4c124abd054e52103ad576fbbbbf749a4114e16f23840df85` |
| canonical-capability-041.json.gz | `9eae71609f44a36cf0f7acd2c2b4f618c5bf708d6a98178849017f9af6c006db` | `5057530f47d74d1eecb7769a1b72beaa72aa0e0346116a7196f7cf559b2b132a` |

事务记录绑定的 canonical 来源：

- before：`b939afe35d30a1a436766d80beea7093a46e4fb2`；[run 45350394271](https://github.com/Proto-UI/Proto-UI/actions/runs/45350394271)，job `138295094772`，artifact `14899589101`。原 strict 8/9，Vue 超 78 B，React 余量 1 B；原失败仍保留。
- accepted capability：`041277b4ec781e0ce737edeaf6911c5a15f9e9b8`；[run 45365822387](https://github.com/Proto-UI/Proto-UI/actions/runs/45365822387)，job `138347165668`，artifact `14906683210`。原 strict 4/9，五入口超预算；原失败仍保留。

本次逐项比较了 canonical `041277b4` 与 `024bc193` 报告的九项 name / entry / minified bytes / minified SHA256 / gzip bytes / 完整 closure，以及 environment 和 measurement，全部相同。这支持 numeric transaction 对已接受 S6 能力成本的依据；不代表其他 source、browser、release facet 已通过。

合并后所需的 exact-head strict 命令为：

```bash
node scripts/analysis/package-budgets.mjs --json --require-clean --expected-sha <实际合并SHA>
```

应在记录准确版本的环境中运行，保留完整 JSON、实际 exit code、report SHA256、clean/matchesHead/stable 标记及新的 source fingerprint。最终 canonical CI 与独立 review 仍按正常路径处理；不把一次本地或远端诊断等同于已执行的 GitHub check。

## 四、Header optional scene 替代方案审查

### 最初观察与生产代价

独立读取以下已生成报告：

- `remote-evidence/header-baseline-graph-report.json`：head `06d4f20249d8128575d6e0e13385e9dcf540c84c`，graph SHA256 `149a42d091f0ce4c66894ae6f6befd45fc62492849726f291ffc424239a95030`。
- `remote-evidence/failed-ssr/header-candidate-graph-report.json`：head `c554496421759dcafbf0924fbf9777358bb9bba2`，graph SHA256 `eadfab294cd3a405731c0e9e7ab9b996aa950f3017e3423e95a81b3aff186c37`。这是此前 candidate 的 client 诊断产物，不宣称其 full docs build / SSR 通过。

| 已记录的 client graph | Header 静态闭包 chunk 数 | JS 文件原始字节总和 |
| --- | ---: | ---: |
| baseline 06d4f | 22 | 1,411,700 B |
| c554 explicit client 诊断 | 82 | 1,461,180 B |
| 差值 | +60 | +49,480 B，约 +3.5% |

这是静态闭包内 JS 文件的原始字节总和，不是 gzip 或首次网络流量。baseline 的 scene module record 为 `renderedLength: 0`，没有 scene-specific implementation marker。不能把修复描述为删除了已经运行的 scene 引擎，或首屏 payload 下降。

读取 `remote-evidence/baseline-controls/result.json` 后，将三个主题的 loadedScripts 与 baseline 22 个静态 chunk URL 求交，均为 22/22。三个完整 WC→React→WC 交互序列的总脚本数分别为 shadcn 161、brutalist 143、bootstrap 137；这些总数不是首屏 Header 请求数。此前 candidate 的 82 是 graph 文件数，没有据此宣称浏览器实测多发了 60 个网络请求。

### 可重跑的内存 probe

临时文件：

- `/workspace/scratch/080997012d40/optional-scene-probe.mjs`
- `/workspace/scratch/080997012d40/optional-scene-probe-result.json`

Node `v24.22.3`，真实安装的 Rollup `4.60.1`。probe 读取 actual website classifier；对共享 host 使用真实路径 `packages/adapters/base/src/material/shader-webgl2-host.ts`，确认其分类为 `site-shadcn-controls`。增加 eager paint/Core 共享依赖控制，并分别测试 unused、`export const render = scene` 和纯 `export { scene as render }` 动态入口。

源代码核验：实际 `shader-scene-host.ts` 唯一 runtime import 是 `./shader-webgl2-host`，不是未分类的 Core helper。该 shared host 已精确分配给 control chunk。因此这里发现的失败不是测试错误地把共享 host 留给自动分组造成的。

初始两 fixture 表明“仅对 exact scene 返回独立 chunk 名”可以保持 unused 场景的 Header eager emitted code/hash，scene 留在无人引用的 1 B empty chunk；对 `export const` lazy consumer 也能保持 scene 仅动态到达。但进一步的纯 re-export 控制否定了其一般性。

| 纯 re-export 动态入口的策略 | Header eager chunk 数 | fixture eager 字节 | scene 是否静态可达 |
| --- | ---: | ---: | --- |
| 原 implicit | 2 | 550 | 是 |
| 仅命名 exact scene | 3 | 691 | 是 |
| exact scene + preserveEntrySignatures: strict | 3 | 691 | 是 |
| exact scene + hoistTransitiveImports: false | 3 | 691 | 是 |
| onlyExplicitManualChunks，scene 不被强行命名 | 3 | 577 | 否 |
| scene 与特定 lazy consumer 同名分组 | 2 | 367 | 否 |

失败变体的 emitted Header 同时静态 import scene，并将原动态 import 改为 `Promise.resolve().then(...)` 返回一个包含 scene 的 namespace object；其 `dynamicImports` 为空。Promise 返回仍异步，不能据此声称模块加载仍 lazy。raw emitted code/imports/hash 均保留在 probe result。

`onlyExplicitManualChunks: true` 且 scene 留给自动分块时，Header 保留真实 `import('./preview-material-scene-....js')`，scene 的正长度实现位于该动态 chunk。`hoistTransitiveImports: false` 和 strict entry signatures 没有挽救 exact named scene 策略。

将 scene 和确切 lazy consumer 合并为一个手动 chunk 只在已知该 consumer 时成立；当前网站没有 `createWebShaderHost` 的实际消费，probe 的 preview 路径不是现存 production owner，不能硬编码 fixture 路径冒充一般保障。把全部 `material/` 放同一个桶也不可取：eager paint reservation 会把同桶 scene 再次带入 Header。

结论：不以当前字节成本换取已复现的 lazy 边界退化。保留 client-only explicit 策略，建议将正长度控制扩展为 const 与纯 re-export 两种入口；继续保留禁止 positive material eager 泄漏的断言。生产 chunk 成本如实记录，若另做优化，须再用完整 production graph 与实际浏览器验证。

## 五、最终 957c strict 报告的独立只读核验

首版只转述 root 的执行报告；本节现已用独立工具读取和核验替代该来源限制。经 `devices_list` 确认 `doesvm-3f08` 在线后，本审查者读取了 root 放在工具允许目录内的原件副本：

`/tank/shared/projects/proto-ui/.git/agent-transfers/header-080997012d40/final-budget-audit/`

本次没有重新运行测量，没有修改该设备的文件。原始 `.local/state` 路径未由本审查者读取；下列完整文件哈希用于绑定收到的副本，而非仅信任文件名或 root 的文字摘要。

| 独立读取的文件 | 实际字节数 | 独立计算 / 读取的 SHA256 |
| --- | ---: | --- |
| final-package-budgets.json | 1,568,060 | `d10242281c2bbd4d3927b91f47ae4d39b015475891667249b99ace9b26d33bae` |
| final-package-budgets-receipt.json | 364 | `97853d85506e0eb8ee9bc58739b6f6cbe5a85dae02006ee44b3f77ef50f54bb4` |
| 957c-commit.raw | 691 | `4a6c43d5cb61bfe5135b3dfe7674ce2d96c444b30809ac6a6187b54ebee120a0` |

### 原始报告与 receipt

对 raw JSON 进行解析与断言，确认以下值：

| 字段 | 独立读取的结果 |
| --- | --- |
| schemaVersion | `2` |
| source.head / source.expectedSha | `957c5ddf0f818a3d91014590a4c2d29c051b1018` |
| source.tree | `dbcc2325fe50ff833b79b4837cdcd0a8a52056fe` |
| source.fingerprintSha256 | `a0d7b4bdb647ad1e3834cdbf8633ae764ba2539239fe4a45a14a70aa72dac7e6` |
| source.fileCount | `7973` |
| source.statusSha256 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| workingTreeClean / measuredSourceMatchesHead | `true` / `true` |
| stableDuringMeasurement / requireClean | `true` / `true` |
| policy.mode / policy.scope | `strict` / `whole-entry package budgets` |
| withinBudgets / exitCode | `true` / `0` |

环境仍为 Node `v24.22.3`、esbuild `0.25.12`、zlib `1.3.2.1-motley-285e94b`、Linux x64；bundle、minify、treeShaking、ESM/browser/es2020、gzip level 9 及 external SHA256 均与前述历史测量一致。

九项 name / entry 集合完整，没有缺项或重复替代；全部 `pass: true`、`overBudgetBytes: 0`。逐项的 `blocking: false` 表示当前没有阻断性超预算失败；源码 policy 明确按 `!pass` 计算该字段，不表示 strict 被关闭。

| 最终 957c 入口 | minified bytes | gzip bytes | ceiling | 结果 |
| --- | ---: | ---: | ---: | --- |
| lucide/icons/x | 4,765 | 1,797 | 3,000 | 通过 |
| lucide root | 4,083,517 | 635,846 | 700,000 | 通过 |
| core root | 40,953 | 12,967 | 13,100 | 通过 |
| runtime root | 410,164 | 106,822 | 107,400 | 通过 |
| adapter-react root | 628,699 | 179,944 | 180,900 | 通过 |
| adapter-vue root | 624,091 | 178,760 | 179,700 | 通过 |
| adapter-web-component root | 736,254 | 216,252 | 217,400 | 通过 |
| prototypes-base/button | 14,562 | 4,311 | 6,000 | 通过 |
| prototypes-shadcn/button | 30,590 | 6,739 | 7,900 | 通过 |

独立比对新报告和 `budget-candidate-024bc193.json`，九项的 minified bytes、minified SHA256、gzip bytes、ceiling、closure fingerprint 和 inputCount 均相同。新的整体 source fingerprint 与旧报告不同，符合 source scope 内已有变化，未将旧 fingerprint 复用为新 head 身份。

receipt 的 command、head、exitCode 和 report SHA256 与 raw 一致；记录耗时 `2.323` 秒，命令为：

```bash
node scripts/analysis/package-budgets.mjs --json --require-clean --expected-sha 957c5ddf0f818a3d91014590a4c2d29c051b1018
```

这是对已经执行并保存的 strict 测量的独立复核，不是本审查者重新执行该命令。

### 原始 Git commit 对象绑定

从 `957c-commit.raw` 的实际内容按 Git 对象规则计算 `SHA1("commit " + byteLength + NUL + rawBytes)`，得到：

`957c5ddf0f818a3d91014590a4c2d29c051b1018`

文本读取工具省略末尾换行；补回该换行后的 691 B 内容已与设备 `omp_hash` 返回的完整文件 SHA256 精确匹配，再计算 Git object SHA1。该校验确认读取内容与远端文件的原始字节一致，没有仅凭重排后的字段猜测 commit identity。

原 commit 中的 tree 与报告一致，双 parent 为：

- `fcc4776cc0695dc04dad4d058e3858ac0808c759`
- `024bc193c35ca74d1893b4c479b148707a8cdd9a`

subject 为 `Merge reviewed Sprint 6 package budget transaction`，保留 `Signed-off-by: Codex <codex@openai.com>`。这独立确认了新测量绑定的 source commit/tree，以及原 numeric commit 通过正常 merge 保留在其父链中。

结论边界：最终 957c 的已保存 strict 报告现已独立核验为 9/9 通过；未重新测量，也未声称据此完成所有 GitHub CI、独立发布 review 或最终远端集成。历史 canonical 红报告仍保持原身份和结果。
