import assert from 'node:assert/strict';
import {defineAsHook,definePrototype} from '/tmp/pui-40da-cli-gate/packages/core/src/index.ts';
import {createRuntimeInstance} from '/tmp/pui-40da-cli-gate/packages/runtime/src/index.ts';
function observe(borrowedMode:boolean){
 const events:string[]=[];let seen:any;let armed=false;
 const asFacts=defineAsHook({name:'gate-runtime-same-name',setup(def:any){events.push('facts');def.state.bool('selected',false);}});
 const asReplacement=defineAsHook({name:'gate-runtime-same-name',setup(def:any){events.push('replacement');def.state.bool('other',false);}});
 const borrowed=definePrototype({name:'borrowed-source',setup(def:any){def.props.define({});def.props.setDefaults({});seen=asFacts().stateHandles;}});
 const root=borrowedMode?definePrototype({name:'borrowing-root',setup(def:any){def.props.define({gate:{type:'string',default:'armed',validator(){events.push(armed?'validator:armed':'validator:unarmed');if(armed)asReplacement();return true;}}});armed=true;events.push('borrowed:start');borrowed.setup(def);}}):borrowed;
 const instance=createRuntimeInstance(root);
 try{return {borrowedMode,events,selected:!!seen?.selected,other:!!seen?.other};}finally{instance.dispose();}
}
const fresh=observe(false),borrowed=observe(true); console.log(JSON.stringify({fresh,borrowed},null,2));
assert.equal(fresh.selected,true);assert.equal(fresh.other,false);
assert.equal(borrowed.selected,false);assert.equal(borrowed.other,true);
