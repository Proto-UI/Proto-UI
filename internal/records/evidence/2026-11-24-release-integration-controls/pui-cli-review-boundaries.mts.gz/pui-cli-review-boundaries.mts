import assert from 'node:assert/strict';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {scanRuleStateReads} from '/tmp/pui-40da-integration/packages/cli/src/services/lowered-hook-coverage.ts';
import {collectProtoStyleTokensFromFiles} from '/tmp/pui-40da-integration/packages/cli/src/services/prototype-style-tokens.ts';
const base=await mkdtemp(path.join(os.tmpdir(),'pui-cli-review-'));
const producer="import {defineAsHook} from '@proto.ui/core'; export const asFacts=defineAsHook({name:'review-shared',setup(def){def.state.bool('selected',false)},projectHandle:r=>({selected:r.stateHandles.selected})}); export const asReplacement=defineAsHook({name:'review-shared',setup(def){def.state.bool('other',false)},projectHandle:r=>({selected:r.stateHandles.other})});";
try {
  await writeFile(path.join(base,'facts.ts'),producer);
  const cases=[
    ['dot-positive',"const TOKENS={active:'bg-accent'};",'TOKENS.active',true],
    ['deferred-mutation',"const TOKENS={active:'bg-accent'}; function later(){TOKENS.active=readUnknown();}",'TOKENS.active',false],
    ['destructuring-write',"const TOKENS={active:'bg-accent'}; ({x:TOKENS.active}=readUnknown());",'TOKENS.active',false],
    ['for-of-write',"const TOKENS={active:'bg-accent'}; for(TOKENS.active of readUnknown()){}",'TOKENS.active',false],
    ['deep-alias',"const TOKENS={palette:{active:'bg-accent'}}; const escaped=TOKENS.palette; mutate(escaped);",'TOKENS.palette.active',false],
    ['optional-read',"const TOKENS={active:'bg-accent'};",'TOKENS?.active',true],
    ['template-positive',"const TOKENS={active:'bg-accent'};",'`${TOKENS.active} ring-2`',true],
  ];
  for(const [name,declarations,arg,expected] of cases){
    const source=`import {definePrototype,tw} from '@proto.ui/core'; import {asFacts} from './facts'; export default definePrototype({name:'review',setup(def){const {selected}=asFacts(); ${declarations} def.rule({when:w=>w.state(selected).eq(true),intent:i=>i.feedback.style.use(tw(${arg}))});}});`;
    const file=path.join(base,`${name}.proto.ts`);await writeFile(file,source);
    const scan=scanRuleStateReads(source,file);const tokens=await collectProtoStyleTokensFromFiles([file]);
    const result={name,usages:scan.usages.length,unresolved:scan.unresolved.map(x=>x.reason),variants:tokens.filter(x=>x.startsWith('data-'))};
    console.log(JSON.stringify(result));
    assert.equal(scan.unresolved.length===0,expected,name);
  }
  const prefixes=[
    ['fresh-props-positive','def.props.setDefaults({});',true],
    ['own-proto-member-replacement','def.props.define = () => asReplacement(); def.props.setDefaults({});',false],
    ['closed-prefix-then-getter',"def.props.setDefaults({}); ({get x(){asReplacement();return 0}}).x;",false],
    ['closed-prefix-then-array-spread',"def.props.setDefaults({}); [...{[Symbol.iterator](){asReplacement();return [0][Symbol.iterator]();}}];",false],
  ];
  for(const[name,prefix,expected]of prefixes){
    const source=`import {definePrototype,tw} from '@proto.ui/core';import{asFacts,asReplacement}from'./facts';export default definePrototype({name:'review',setup(def){${prefix} const bag=asFacts();def.rule({when:w=>w.state(bag.selected).eq(true),intent:i=>i.feedback.style.use(tw('bg-accent'))});}});`;
    const file=path.join(base,`${name}.proto.ts`);await writeFile(file,source);
    const tokens=await collectProtoStyleTokensFromFiles([file]); const matches=tokens.filter(x=>x.startsWith('data-'));
    console.log(JSON.stringify({name,variants:matches}));assert.equal(tokens.includes('data-[selected]:bg-accent'),expected,name);
  }
} finally {await rm(base,{recursive:true,force:true});}
