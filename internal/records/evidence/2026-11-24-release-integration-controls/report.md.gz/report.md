# Remaining CLI shipped-source gate: bounded classification

## Result and binding

The whole shipped Rule-source gate remains a release blocker. This investigation found several distinct source-analysis capability gaps, and proved that the ordinary Props-prefix uncertainty cannot be removed generally. No production code, test assertion, source inventory, or contract was changed.

The isolated checkout is `/tmp/pui-40da-cli-gate`, branch `fix/cli-shipped-source-coverage`, at exact commit `eb7421bd90283c4c58180e1a29348858e3d98f07`. Its working tree is clean. `triage.json` binds the three CLI services, gate test, and nine representative source files by SHA-256. The three services and gate test have no diff from reviewed source commit `58e43642dd598c0c7d445838581e339d500ccf9b`.

The supplied full-run result is 983 assertions, 980 passed, 3 failed, 0 pending. One failure is the lowered-source gate with 1081 unresolved records. The other two are family snapshot failures being handled separately by the parent. I did not rerun the complete inventory or independently establish that today's full 1081-record set equals the earlier baseline set.

## Independent bounded evidence

Nine actual shipped-source entry/declaration probes produced 63 unresolved records: 50 `subject`, 5 `intent`, 4 `condition`, 3 `comparison`, and 1 `spec`. These are the counts of these probes only, **not the category distribution of the full 1081 failures**. Exported-helper declaration probes do not discharge every caller context, and the same source can appear in different inventory contexts.

All source paths in this table are relative to `packages/prototypes/`.

| Representative | Authored hook capture | Scoped result | Exact boundary |
| --- | --- | --- | --- |
| `brutalist/src/toggle/toggle.proto.ts` | `asToggle()` at line 47: unknown | 11 subject misses | Props calls at lines 37 and 44 precede capture |
| `bootstrap-2-3-2/src/button/button.proto.ts` | `asButton()` at line 49: unknown | 3 subject misses | Props calls at lines 31 and 42 precede capture |
| `liquid-glass/src/button/button.proto.ts` | `asButton()` at line 33: unknown | 8 subject misses | Props calls at lines 27 and 32 precede capture |
| `shadcn/src/tabs/trigger.proto.ts` | `asTabsTrigger()` at line 23: unknown | 0 evaluated misses in this bounded probe | This probe establishes capture uncertainty only; it is not counted as a demonstrated contributor to the 1081 |
| `shadcn/src/textarea/root.proto.ts` | `asTextareaRoot()` at line 13: result | 5 recognized usages; 9 subject, 1 condition, 1 intent misses | Its visual helper obtains a private State from another ordinary helper, uses an optional-State ternary, and uses profile-indexed tokens |
| `bootstrap-2-3-2/src/autocomplete/trigger.proto.ts` | `asAutocompleteTrigger()` at line 17: result | 1 recognized usage; 2 intent misses | Imported exported token maps at lines 38 and 48 |
| `bootstrap-2-3-2/src/button/visual.ts` | No authored hook call in helper declaration | 4 subject and 3 condition misses | Optional State parameters and ternaries at lines 42, 57, and 74 |
| `shadcn/src/calendar/visual.ts` | No authored hook call in helper declaration | 15 subject, 3 comparison, 2 intent misses | Helper parameters plus imported profile iteration at line 99, comparisons at lines 111/127/144, table lookups at lines 102/106 |
| `shadcn/src/popover/command-paint.ts` | No authored hook call in helper declaration | 1 spec miss | Optional callable relay at line 72 passes `rule` to `def.rule(rule)` |

The raw outputs are `pui-cli-gate-probe.log` and `pui-cli-gate-categories.log`. The script uses the actual source filenames and `scanRuleStateReadInventory([file])`, so relative imports are resolved through the isolated checkout rather than through invented fixture locations.

## 1. Prior Props calls: causal source control and real Runtime counterexample

Three in-memory diagnostic controls removed only the preceding `def.props.define` and `def.props.setDefaults` statements in the Toggle and two Button sources above. In all three, the same actual imported hook call changed from `unknown` with `unproved registration result` to `result`. The source files were not edited. Removing these calls would remove legal component behavior and is **not an implementation proposal**.

The cause cannot be fixed by broadly treating native Props calls as harmless. An actual Core/Runtime control uses the same borrowed setup body in two contexts:

```ts
def.props.define({});
def.props.setDefaults({});
seen = asFacts().stateHandles;
```

Both hooks in the control use the same configured hook identity. `asFacts` declares `selected`; a second hook declares `other`. The fresh root has no prior Props schema. The borrowing root installs a prop validator, arms it, and invokes the borrowed setup. Recomputing the existing schema calls that validator, which registers the second hook before the visible `asFacts()` call. Actual observations:

| Context | Hook setup events | Returned State bag |
| --- | --- | --- |
| Fresh Runtime root | `facts` | `selected` present; `other` absent |
| Borrowed setup with preexisting Props validator | `replacement`; no `facts` | `selected` absent; `other` present |

Assertions passed in both arms. This requires neither a getter nor an opaque external object, and even the two empty Props calls are sufficient. The final passing output is in `pui-cli-gate-runtime-boundary.log`.

Source authority supports retaining this distinction. Active `spec/contracts/C-PROPS-0007.yaml` permits validator addition and incremental declarations. `packages/modules/props/src/kernel/kernel.ts:86` and `:114` recompute resolved values after `define` and `setDefaults`; line 344 invokes the existing validator. The observed same-identity behavior is also described by the currently **draft** `C-AS-HOOK-0004` contract; the control directly tests the implemented Runtime behavior rather than assuming the draft status proves it.

`packages/cli/src/services/hook-source-summary.ts:2092` admits the initialization prefix only for the specifically bound standard Runtime Root style context. Ordinary source queries correctly remain outside that context. The unknown result is returned at line 4366. `projectStandardRuntimeRootStyleTokens` at line 685 intentionally exports only final strings; using it as ordinary source provenance would widen its meaning beyond its existing proof.

**Required direction:** preserve the ordinary unknown. To prove fresh-root behavior, a future change must explicitly bind the root definition, fresh Props state, complete prior evaluation, and capture to that scenario. An alternative is a separately specified real Runtime inventory channel with its own exact-input and acceptance contract. Neither can silently turn context-free source inventory rows into universally proved provenance.

## 2. Ordinary helper-returned and helper-parameter State

Textarea is a useful separating control: its authored base hook already resolves and five State usages are recognized, yet its visual helper still has nine `style` subject misses. `shadcn/src/textarea/visual.ts:47` calls `setupShadcnStyleSelection`; `shadcn/src/style-scope/selection.ts:35` creates the State and line 54 returns it. This is an ordinary compositional helper, not an authored-hook result. Calendar and Button helper declarations also need the actual caller's supplied State identities to be proved.

This is separate from the preceding Props-capture problem. Resolving every authored hook capture would not automatically prove these helper returns and parameters. Type annotations such as `State`, a familiar function name, or the visible downstream selector cannot supply missing origin proof.

**Required direction:** bounded interprocedural State provenance with exact helper identity, argument binding, return binding, writes/escapes, and every evaluated caller context. Standalone declaration observations must remain distinct from proved calls.

## 3. Token-table intents and finite profile domains

Autocomplete also separates mechanisms: its base capture resolves, but the two imported map-member intents do not. The definitions are exported objects in `bootstrap-2-3-2/src/button/paint.ts:17` and `:26`. The restored private-map proof in `lowered-hook-coverage.ts:3682` does not establish immutability of exported imported objects. `as const` alone is not a runtime immutability proof.

Textarea and Calendar combine table-member intents with profile iteration. Calendar's helper declaration has three unresolved comparisons involving `profile`; its loop starts at `shadcn/src/calendar/visual.ts:99`. These require a proved finite iterable and exact row binding in the evaluated context, as well as safe table lookup. Resolving a State subject alone does not close them.

**Required direction:** source-bound module/object stability and finite-row proofs, including export/alias/write and iterator-effect controls. Preserve unknown imported data and unknown iteration; do not certify every string that could appear in the resource inventory as the intent of a particular Rule.

## 4. Conditional When builders

Textarea's optional `invalid` argument controls which `w.all(...)` expression its When callback returns (`textarea/visual.ts:72`). The Button helper similarly branches on the presence of optional State parameters. These produce `condition` records before a subject-only repair could help.

**Required direction:** exact caller argument/presence propagation and branch-sensitive When construction for a closed admitted shape. A truthy type annotation cannot select a branch, and dropping the branch would remove legal source behavior.

## 5. Callable Rule-spec relay

`shadcn/src/popover/command-paint.ts:72` chooses an optional supplied `defaultRule` or a wrapper that calls `def.rule(rule)`. The source inventory retains the dynamic spec call as a `spec` miss. A Rule callback type does not prove which callable is selected or which object reaches it.

**Required direction:** prove the callable and actual literal spec at a concrete caller, with reassignment/escape and optional callback controls. Do not treat the declared function type or `def.rule` spelling as proof of the relayed object.

## Classification and closure decision

The representative evidence supports a current 0.3 source-analysis/acceptance capability gap across several independent boundaries. It does not support another single private-token-map merge-restoration patch as a way to close the gate. The current three service files and the gate test are unchanged after `58e43642d`; the parent's earlier full run reported the same 1081 count. Exact population equality with that historical run was not established here, so this report does not assert that every current record has the same historical cause.

Some categories can be addressed through new bounded analyses without altering public semantics. The general Props relaxation is specifically disproved by Runtime. There is no justified small implementation in this investigation that closes the remaining gate while preserving the existing proof meaning. Therefore the gate at `packages/cli/test/lowered-hook-coverage.test.ts:5725` and its fail-closed empty-unresolved assertion remain unchanged and red. Successful style resource generation, selected Runtime controls, or a differently scoped fresh-root observation cannot stand in for this gate.

## Reproduction and limits

Run from `/tmp/pui-40da-cli-gate`:

```sh
NODE_OPTIONS=--max-old-space-size=768 node --import tsx /tmp/pui-cli-gate-runtime-boundary.mts
NODE_OPTIONS=--max-old-space-size=768 node --import tsx /tmp/pui-cli-gate-prefix-diagnostic.mts
NODE_OPTIONS=--max-old-space-size=768 node --import tsx /tmp/pui-cli-gate-probe.mts packages/prototypes/shadcn/src/textarea/root.proto.ts
```

The direct Node loader avoids the `tsx` CLI's IPC-listen attempt, which this execution environment rejects. The two control commands above were rerun successfully against the bound checkout. Nine source probes, three prefix controls, and two Runtime arms were run with a 768 MiB heap. No full-inventory rerun, generated-snapshot conclusion, release approval, or external write is included in this report.
