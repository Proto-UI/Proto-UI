import { spawn } from 'node:child_process';
import { once } from 'node:events';
import * as draft from './draft/runtime-process-tree.mjs';
import * as baseline from './baseline/runtime-process-tree.mjs';
import { processFact } from './draft/linux-process-ownership.mjs';
const args=['-u','PROTO_UI_RUNTIME_PROCESS_OWNER',process.execPath,'-e',"process.stdout.write('ready\\n');setInterval(()=>{},1000)"];
for (const [name, spawnChild, owner] of [['baseline',spawn,baseline],['draft',draft.spawnOwnedProcess,draft]]) {
 const child=spawnChild('/usr/bin/env',args,{detached:true,stdio:['ignore','pipe','ignore']});
 const closed=once(child,'close');
 let tree;
 try {
  await once(child.stdout,'data');
  const identity=processFact(child.pid);
  tree=owner.ownProcessTree(child,{label:'unmarked-live-child',sampleMs:60000,graceMs:40,killWaitMs:200});
  const captured=await tree.capture();
  const receipt=await tree.stop();
  const current=processFact(child.pid);
  console.log(JSON.stringify({name,capturedPids:captured.map(x=>x.pid),verified:receipt.verified,errors:receipt.errors,signals:receipt.signals,stillSameLiveChild:current?.started===identity?.started&&!['Z','X'].includes(current?.state),childExitCode:child.exitCode,childSignalCode:child.signalCode}));
 } finally {
  await tree?.stop();
  if(child.exitCode===null&&child.signalCode===null)child.kill('SIGKILL');
  await closed;
 }
}
