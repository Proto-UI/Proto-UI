import { execFileSync, spawn } from 'node:child_process';
import { once } from 'node:events';
const sha='4aaac6ac60348dc99896c34cd1186abcda98ff0d';
const source=execFileSync('git',['show',sha+':scripts/test/runtime-process-tree.mjs'],{encoding:'utf8'});
const { ownProcessTree,readProcessTable }=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const leafSource="process.on('SIGTERM',()=>{});setInterval(()=>{},1000)";
const producerSource=`const {spawn}=require('node:child_process');process.send({ready:true});process.on('message',()=>{const leaf=spawn(process.execPath,['-e',${JSON.stringify(leafSource)}],{detached:true,stdio:'ignore'});leaf.unref();process.send({leaf:leaf.pid},()=>process.exit(0));});`;
const child=spawn(process.execPath,['-e',producerSource],{detached:true,stdio:['ignore','ignore','ignore','ipc']});
let leaf=null, tree=null;
const kill=pid=>{try{process.kill(pid,'SIGKILL')}catch(e){if(e.code!=='ESRCH')throw e}};
try {
 await once(child,'message');
 tree=ownProcessTree(child,{label:'unsampled-detached-default500ms',graceMs:150,killWaitMs:1000});
 const initial=await tree.capture();
 const started=Date.now();
 const report=once(child,'message');const exit=once(child,'exit');child.send('spawn');
 [{leaf}]=await report;await exit;
 const receipt=await tree.stop();
 const row=(await readProcessTable()).find(r=>r.pid===leaf&&!r.state.startsWith('Z'));
 console.log(JSON.stringify({sha,defaultSampleMs:500,elapsedSinceCaptureMs:Date.now()-started,initialOwned:initial.map(r=>r.pid),leaf,leafStillLive:!!row,leafState:row??null,receipt},null,2));
} finally {
 if(leaf)kill(-leaf);
 kill(-child.pid);
 await tree?.stop();
 if(leaf){const left=(await readProcessTable()).some(r=>r.pid===leaf&&!r.state.startsWith('Z'));console.log(JSON.stringify({fixtureCleanupLive: left}));}
}