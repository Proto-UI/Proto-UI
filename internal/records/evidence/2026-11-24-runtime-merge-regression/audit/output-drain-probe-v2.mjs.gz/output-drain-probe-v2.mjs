import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { createHash } from 'node:crypto';
import { chmodSync, cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';

const audit = path.dirname(fileURLToPath(import.meta.url));
const sources = path.join(audit, 'probe-exact-sources');
const payloadBytes = 4 * 1024 * 1024;
const readerDelayMs = 500;
const expectedSha256 = createHash('sha256').update(Buffer.alloc(payloadBytes, 65)).digest('hex');
const results = [];

function fact(pid) {
  try {
    const text = readFileSync(`/proc/${pid}/stat`, 'utf8');
    const f = text.slice(text.lastIndexOf(')') + 2).split(' ');
    return { pid, state: f[0], startTicks: f[19] };
  } catch { return null; }
}

function cleanIdentity(saved) {
  const current = saved && fact(saved.pid);
  if (!current || current.startTicks !== saved.startTicks || ['Z', 'X'].includes(current.state)) return;
  try { process.kill(saved.pid, 'SIGKILL'); } catch (error) { if (error.code !== 'ESRCH') throw error; }
}

async function run({ label, sha, draft = false, signal = 'SIGTERM', readerDelayMs = 500, psFailure = false }) {
  const directory = mkdtempSync(path.join(audit, `output-probe-${label}-`));
  cpSync(path.join(sources, sha, 'scripts'), path.join(directory, 'scripts'), { recursive: true });
  if (draft) {
    for (const name of ['run-runtime-tests.mjs', 'runtime-process-tree.mjs', 'linux-process-ownership.mjs'])
      cpSync(path.join(audit, existsSync(path.join(audit, 'draft-v2', name)) ? 'draft-v2' : 'draft', name), path.join(directory, 'scripts/test', name));
  }
  const fixture = path.join(directory, 'node_modules/vitest');
  mkdirSync(fixture, { recursive: true });
  const readyPath = path.join(directory, 'producer-ready.json');
  const completePath = path.join(directory, 'producer-output-complete.json');
  writeFileSync(path.join(fixture, 'vitest.mjs'), `import { writeFileSync } from 'node:fs';
let finishing = false;
process.on('SIGTERM', () => {
  if (finishing) return;
  finishing = true;
  process.stdout.write(Buffer.alloc(${payloadBytes}, 65), () => {
    writeFileSync(process.env.PUI_DRAIN_PROBE_COMPLETE, JSON.stringify({ pid: process.pid, bytes: ${payloadBytes} }));
    process.exit(0);
  });
});
writeFileSync(process.env.PUI_DRAIN_PROBE_READY, JSON.stringify({ pid: process.pid }));
setInterval(() => {}, 1000);
`);
  const env = { ...process.env, PUI_DRAIN_PROBE_READY: readyPath, PUI_DRAIN_PROBE_COMPLETE: completePath };
  delete env.PROTO_UI_RUNTIME_PHASE;
  delete env.PROTO_UI_RUNTIME_SHARD;
  delete env.PROTO_UI_RUNTIME_EVIDENCE_DIR;
  if (psFailure) {
    const bin = path.join(directory, 'bin');
    mkdirSync(bin);
    writeFileSync(path.join(bin, 'ps'), '#!/bin/sh\necho controlled-signal-observation-failure >&2\nexit 1\n');
    chmodSync(path.join(bin, 'ps'), 0o755);
    env.PATH = `${bin}:${env.PATH}`;
  }
  const runner = spawn(process.execPath, ['scripts/test/run-runtime-tests.mjs', 'probe.test.ts'], {
    cwd: directory, env, detached: true, stdio: ['ignore', 'pipe', 'pipe'],
  });
  const runnerIdentity = fact(runner.pid);
  let producerIdentity;
  let readerTimer;
  let deadlineTimer;
  let receivedBytes = 0;
  let stderr = '';
  let signalAt;
  let exitElapsedMs;
  const receivedHash = createHash('sha256');
  runner.stdout.on('data', (chunk) => { receivedBytes += chunk.length; receivedHash.update(chunk); });
  runner.stdout.pause();
  runner.stderr.on('data', (chunk) => { stderr += chunk.toString(); });
  const exited = once(runner, 'exit').then(([code, terminationSignal]) => {
    exitElapsedMs = Date.now() - signalAt;
    return { code, signal: terminationSignal };
  });
  const closed = once(runner, 'close');
  try {
    const readyDeadline = Date.now() + 4000;
    while (!existsSync(readyPath) && Date.now() < readyDeadline && runner.exitCode === null) await delay(10);
    if (!existsSync(readyPath)) throw new Error(`Producer never became ready: ${stderr}`);
    producerIdentity = fact(JSON.parse(readFileSync(readyPath, 'utf8')).pid);
    if (!producerIdentity) throw new Error('Producer identity not available');
    signalAt = Date.now();
    runner.kill(signal);
    readerTimer = setTimeout(() => runner.stdout.resume(), readerDelayMs);
    const completion = Promise.all([exited, closed]);
    const [{ code, signal: terminationSignal }] = await Promise.race([
      completion,
      new Promise((_, reject) => { deadlineTimer = setTimeout(() => reject(new Error('Bounded probe exceeded 10 seconds')), 10_000); }),
    ]);
    const receipts = stderr.split('\n').filter((row) => row.startsWith('[test:runtime] process cleanup '))
      .map((row) => JSON.parse(row.slice('[test:runtime] process cleanup '.length)));
    const result = {
      label, sourceSha: sha, draft, psFailure, interruption: signal, directory,
      node: process.version, platform: process.platform, payloadBytes, readerDelayMs, expectedSha256,
      exitCode: code, terminationSignal, exitElapsedMs, receivedBytes,
      receivedSha256: receivedHash.digest('hex'),
      producerCompletedWrite: existsSync(completePath),
      producerStillLiveAtRunnerExit: Boolean(producerIdentity && fact(producerIdentity.pid)?.startTicks === producerIdentity.startTicks && !['Z','X'].includes(fact(producerIdentity.pid)?.state)),
      producerCompletion: existsSync(completePath) ? JSON.parse(readFileSync(completePath, 'utf8')) : null,
      cleanupReceipts: receipts,
      finalOutputDrainPresent: Boolean(receipts.at(-1)?.outputDrain),
    };
    writeFileSync(path.join(directory, 'stderr.log'), stderr);
    writeFileSync(path.join(directory, 'result.json'), JSON.stringify(result, null, 2) + '\n');
    results.push(result);
    return result;
  } finally {
    clearTimeout(readerTimer);
    clearTimeout(deadlineTimer);
    runner.stdout.resume();
    cleanIdentity(producerIdentity);
    cleanIdentity(runnerIdentity);
    await Promise.race([closed, delay(1000)]);
    const producerNow = producerIdentity && fact(producerIdentity.pid);
    const runnerNow = runnerIdentity && fact(runnerIdentity.pid);
    const survivors = [producerNow, runnerNow].filter((entry) => entry && !['Z', 'X'].includes(entry.state));
    writeFileSync(path.join(directory, 'cleanup.json'), JSON.stringify({ survivors }, null, 2) + '\n');
    if (survivors.length) throw new Error('Fixture cleanup left a live process');
  }
}

for (const input of [
  { label: 'v2-delayed-reader', sha: '4aaac6ac60348dc99896c34cd1186abcda98ff0d', draft: true },
  { label: 'v2-blocked-reader', sha: '4aaac6ac60348dc99896c34cd1186abcda98ff0d', draft: true, readerDelayMs: 3500 },
  { label: 'v2-live-producer-ps-failure', sha: '4aaac6ac60348dc99896c34cd1186abcda98ff0d', draft: true, psFailure: true },
]) {
  const result = await run(input);
  console.log(JSON.stringify({ label: result.label, exitCode: result.exitCode, exitElapsedMs: result.exitElapsedMs,
    payloadBytes, receivedBytes: result.receivedBytes, readerDelayMs: result.readerDelayMs,
    producerCompletedWrite: result.producerCompletedWrite, producerStillLiveAtRunnerExit: result.producerStillLiveAtRunnerExit,
    finalOutputDrainPresent: result.finalOutputDrainPresent, lastReceipt: result.cleanupReceipts.at(-1), directory: result.directory }));
}
writeFileSync(path.join(audit, 'output-drain-probe-v2-results.json'), JSON.stringify(results, null, 2) + '\n');
