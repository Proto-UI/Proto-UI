import datetime, hashlib, json, os, subprocess, sys, time
from pathlib import Path

base = Path('/home/ezra/.local/state/proto-ui-header-080997012d40')
work = base / 'post-merge-4aa'
run_name = sys.argv[1]
assert run_name.isalnum() or all(c.isalnum() or c in '-_' for c in run_name)
out = base / run_name
out.mkdir(exist_ok=False)
node = '/home/ezra/.npm/_npx/e492a4414fcaa974/node_modules/.bin/node'
env = os.environ.copy()
env['PATH'] = str(Path(node).parent) + ':' + env['PATH']
env['TMPDIR'] = str(base / 'tmp')
paths = ['scripts/test/runtime-process-tree.mjs', 'scripts/test/runtime-process-tree.test.mjs', 'scripts/test/run-runtime-tests.mjs', 'scripts/test/run-runtime-tests.test.mjs', 'scripts/test/linux-process-ownership.mjs']
def snapshot():
    return {p: hashlib.sha256((work / p).read_bytes()).hexdigest() for p in paths}
before = snapshot()
expected = json.loads((base / 'post-merge-candidate-v2.json').read_text())['files']
assert all(before[p] == digest for p, digest in expected.items())
command = [node, '--test', '--test-reporter=tap', 'scripts/test/run-runtime-tests.test.mjs']
receipt = {
    'command': command,
    'cwd': str(work),
    'baseHead': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip(),
    'treeState': 'working tree candidate; source hashes bind the execution',
    'sourceBefore': before,
    'node': subprocess.check_output([node, '--version'], text=True).strip(),
    'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat()
}
assert receipt['baseHead'] == '4aaac6ac60348dc99896c34cd1186abcda98ff0d'
assert receipt['node'] == 'v24.22.3'
start = time.monotonic()
try:
    with (out / 'runtime-tests.stdout.log').open('w') as stdout, (out / 'runtime-tests.stderr.log').open('w') as stderr:
        completed = subprocess.run(command, cwd=work, env=env, stdout=stdout, stderr=stderr, timeout=180)
        receipt['exitCode'] = completed.returncode
except BaseException as exc:
    receipt['error'] = repr(exc)
    receipt['exitCode'] = 124 if isinstance(exc, subprocess.TimeoutExpired) else 1
finally:
    receipt['elapsedSeconds'] = round(time.monotonic() - start, 3)
    receipt['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    receipt['sourceAfter'] = snapshot()
    receipt['sourceStable'] = receipt['sourceAfter'] == before
    receipt['gitStatus'] = subprocess.check_output(['git', 'status', '--porcelain'], cwd=work, text=True)
    receipt['logs'] = {p.name: {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in out.glob('*.log')}
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))
sys.exit(receipt['exitCode'] if receipt['sourceStable'] else 1)
