declare const content: {getExposes(): Record<string, unknown>};
declare function expect(value: unknown): {toBe(expected: unknown): void};
    const transitionState = content.getExposes().transitionState;
    if (
      typeof transitionState !== 'object' ||
      transitionState === null ||
      !('get' in transitionState) ||
      typeof transitionState.get !== 'function'
    )
      throw new TypeError('Dialog Content must expose a readable transitionState.');
    expect(transitionState.get()).toBe('closed');

