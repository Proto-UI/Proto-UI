import {createRequire} from 'node:module';
import {readFileSync,writeFileSync} from 'node:fs';
import path from 'node:path';
const R=process.env.PUI_SOURCE_ROOT,E=process.env.PUI_CHECK_EVIDENCE;
const require=createRequire(path.join(R,'package.json')),ts=require('typescript');
const text=readFileSync(path.join(R,'packages/adapters/web-component/test/portal-conceal.test.ts'),'utf8');
const start=text.indexOf('    const transitionState = content.getExposes().transitionState;');
const end=text.indexOf("    expect(content.hasAttribute('data-pui-view-detached'))",start);
if(start<0||end<0)throw Error('missing exact narrowed fixture expression');
const declarations="declare const content: {getExposes(): Record<string, unknown>};\ndeclare function expect(value: unknown): {toBe(expected: unknown): void};\n";
const samples={negative:"expect(content.getExposes().transitionState.get()).toBe('closed');",positive:text.slice(start,end)};
const report={typescript:ts.version,scope:'Exact unknown-valued expose reader; isolated strict expression proof, not whole-workspace typecheck.',cases:[]};
for(const [name,body] of Object.entries(samples)){
 const file=path.join(E,name+'.ts');writeFileSync(file,declarations+body+'\n');
 const program=ts.createProgram([file],{strict:true,noEmit:true,target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,moduleResolution:ts.ModuleResolutionKind.Bundler,types:[]});
 const diagnostics=ts.getPreEmitDiagnostics(program).map(d=>({code:d.code,message:ts.flattenDiagnosticMessageText(d.messageText,'\n')}));
 report.cases.push({name,diagnostics});
}
writeFileSync(path.join(E,'typecheck.json'),JSON.stringify(report,null,2)+'\n');
if(report.cases[0].diagnostics.length!==1||report.cases[0].diagnostics[0].code!==2571||report.cases[1].diagnostics.length)throw Error('unexpected static control outcome');
