declare const content: {getExposes(): Record<string, unknown>};
declare function expect(value: unknown): {toBe(expected: unknown): void};
expect(content.getExposes().transitionState.get()).toBe('closed');
