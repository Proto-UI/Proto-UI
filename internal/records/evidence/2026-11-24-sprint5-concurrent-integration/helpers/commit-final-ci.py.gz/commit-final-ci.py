#!/usr/bin/env python3
import os,pathlib,json,subprocess,hashlib,datetime,traceback,re
T=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a');O=pathlib.Path(str(T)+'-ops/ci-final-followup');O.mkdir(exist_ok=False)
E=dict(os.environ);E['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+E.get('PATH','')
E['TMPDIR']='/var/tmp/s5g75d5';E['NODE_OPTIONS']='--max-old-space-size=4096'
assert E.get('HUSKY')!='0'
S={'phase':'initial','started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
def save(p=None):
 if p:S['phase']=p
 (O/'status.json').write_text(json.dumps(S,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=T,env=E,text=True,timeout=60).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(n,a,timeout=180,trace=False):
 save(n);env=dict(E)
 if trace:env['GIT_TRACE2_EVENT']=str(O/(n+'.trace.jsonl'))
 with (O/(n+'.log')).open('wb') as f:r=subprocess.run(a,cwd=T,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 S['commands'].append({'name':n,'argv':a,'exitCode':r.returncode});save()
 assert r.returncode==0,n
 return (O/(n+'.log')).read_text()
try:
 base='e470d1b0c21fc40e99e71cd7c49a76470444c6e7'; f='.github/workflows/compiler-browser-acceptance.yml'
 assert git('rev-parse','HEAD')==base
 assert git('diff','--name-only')==f and git('diff','--cached','--name-only')==''
 assert sha(T/f)=='ff661d051d908d64006a711b4bb15492eba4a1861ddf374cd443b8c3b7a563f3'
 (O/'candidate.patch').write_text(git('diff','--',f)+'\n')
 (O/'candidate-workflow.yml').write_bytes((T/f).read_bytes())
 (O/'original-workflow.yml').write_text(git('show','HEAD:'+f)+'\n')
 S['sourceHead']=base;S['workflowBefore']=sha(O/'original-workflow.yml');S['workflowAfter']=sha(T/f)
 files=['capture-facade','value-ir','capture-lookup-integrity','authored-hook-language','mutable-callable-orders','module-helper-capture-boundary','privileged-capture-metadata','capture-getter-presence','capture-host-presence']
 S['explicitSourceHashes']={x:sha(T/('packages/compiler/test/'+x+'.test.ts')) for x in files}
 S['mergeBase']=git('merge-base','HEAD','0fbb52ef832cc27c78e24c28c59a55a16f51d7fe')
 for name,files,expected in [
 ('ci-policy',['scripts/ci/test/ci-scheduling-policy.test.mjs'],31),
 ('ci-cycle',['scripts/ci/test/cycle-job-inventory.test.mjs','scripts/ci/test/cycle-report.test.mjs'],28)]:
  log=run(name,['node','--test','--test-reporter=tap',*files])
  counts={k:int(v) for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$',log,re.M)}
  assert counts.get('tests')==expected and counts.get('pass')==expected and counts.get('fail')==0 and counts.get('skipped')==0,counts
  S[name]=counts
 run('ci-schedule',['node','scripts/ci/check-ci-schedule.mjs'])
 run('format-check',['corepack','pnpm@10.32.1','exec','prettier','--check',f])
 run('diff-check',['git','diff','--check'])
 assert sha(T/f)==S['workflowAfter']
 assert git('diff','--name-only')==f and git('diff','--cached','--name-only')==''
 run('stage-workflow',['git','add','--',f])
 prepared=git('write-tree');S['preparedTree']=prepared
 msg=O/'commit-message.txt';msg.write_text('ci: retain capture presence and specification authoring acceptance\n\nKeep the manual source lane bounded while covering copied capture getters,\nown-key presence, and the actual main merge-base authoring contract.\n')
 run('commit',['git','commit','--signoff','--file',str(msg)],timeout=900,trace=True)
 assert git('rev-parse','HEAD^{tree}')==prepared
 assert git('status','--porcelain=v1')==''
 assert sha(T/f)==S['workflowAfter']
 ev=[json.loads(x) for x in (O/'commit.trace.jsonl').read_text().splitlines()]
 S['preCommitEvents']=[x for x in ev if x.get('event')=='child_start' and x.get('hook_name')=='pre-commit']
 assert len(S['preCommitEvents'])==1
 S['finalHead']=git('rev-parse','HEAD');S['finalTree']=git('rev-parse','HEAD^{tree}')
 assert git('diff','--name-only',base,'HEAD')==f
 S['onlyWorkflowChanged']=True;S['clean']=True;S['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 save('committed')
except BaseException as e:
 S['error']=repr(e);S['traceback']=traceback.format_exc();save('failed');raise
