#!/usr/bin/env python3
import pathlib,subprocess,json,os,datetime,traceback,hashlib
root=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
ops=pathlib.Path(str(root)+'-ops');out=ops/'native52c-integration';mainOut=ops/'main0fbb-integration';mainOut.mkdir(exist_ok=False)
rootOps=pathlib.Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a-ops')
env=os.environ.copy();env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env['PATH'];env['TMPDIR']='/tank/shared/projects/proto-ui-agent/s5at75d5'
state={'phase':'starting','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
expected='68b813973cf5877123f87a2ca68025ff64c1cc74';native='52c87232f593d85a28cbd04ad205f0d5fe6f03a3';main='0fbb52ef832cc27c78e24c28c59a55a16f51d7fe'
def save():(out/'resolve-commit-main-status.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,args,timeout=180,okay=(0,),folder=out):
 state['phase']=label;save()
 p=subprocess.run(args,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
 (folder/(label+'.log')).write_text(p.stdout);state['commands'].append({'label':label,'args':args,'exitCode':p.returncode});save()
 if p.returncode not in okay:raise RuntimeError(label+' exit '+str(p.returncode))
 return p.stdout.strip()
def sha(b):return hashlib.sha256(b).hexdigest()
def tracked_records(ref,path):
 lines=run('records-'+ref[:8]+'-'+path.replace('/','__'),['git','ls-tree','-r',ref,'--',path],90)
 return {line.split('\t',1)[1]:line.split('\t',1)[0].split()[2] for line in lines.splitlines()}
try:
 assert json.loads((out/'status.json').read_text())['phase']=='native-merge-conflicts-ready'
 assert run('native-resolve-head',['git','rev-parse','HEAD'],30)==expected
 assert run('native-resolve-merge-head',['git','rev-parse','MERGE_HEAD'],30)==native
 packet=json.loads((rootOps/'external-0b7-native-union/status.json').read_text())
 assert packet['base']==native and packet['externalHead']=='0b7b212d3193ea5c7ae219c0501036ee1255e3f2'
 paths={f['path'] for f in packet['files']}
 assert set(run('native-current-conflicts',['git','diff','--name-only','--diff-filter=U'],90).splitlines())==paths
 prepared={}
 for entry in packet['files']:
  path=entry['path'];data=pathlib.Path(entry['candidatePath']).read_bytes();assert sha(data)==entry['candidateSha256']
  assert sha(subprocess.check_output(['git','show',native+':'+path],cwd=root,timeout=90))==entry['beforeSha256']
  for stage,ref in [(2,expected),(3,native)]:
   assert run('native-index-'+str(stage)+'-'+path.replace('/','__'),['git','rev-parse',':'+str(stage)+':'+path],30)==run('native-ref-'+str(stage)+'-'+path.replace('/','__'),['git','rev-parse',ref+':'+path],30)
  prepared[path]=data
 unchanged={
 'packages/compiler/src/gpui-native-owner.ts':'41c7ad5a4bc33882e2c88b1db02d1f8dd2dce0e3c480ac2f7a93bfa6e2e538ce',
 'packages/compiler/src/gpui-native-modules.ts':'b47fa0305395ccfb389dbaa7c20b3e5ff620ea75d3848980e1e842f4bed5ce94',
 'packages/compiler/src/gpui-native-hover.ts':'596bfd58f0241d7ee377837f2469019f61e09688710af21d05f59f7b8bc3c7a1',
 'packages/compiler/src/gpui-native-a11y.ts':'ed7bf3e7c768590b09dfcd118b2d67598cbb4fe0332f3a2fdc43d149f07926d5',
 'packages/compiler/src/ir-validation.ts':'b8ef32a38d694348ffc221dff7df643110795d4918ada24f4060cc856731e535',
 'packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs':'b2fbd8b237443d210bea88173b56867619a71324b6243fada0d52bc10d6b272d',
 'packages/compiler/test/fixtures/gpui-ordinary-values/a11y-activation-consumer.rs':'5dca2833f234ee6fc832246000d475e6531f5c9327593c70b43c2b8ee4fc11cd'}
 assert {p:sha((root/p).read_bytes()) for p in unchanged}==unchanged
 docs=json.loads((ops/'external-0b7-union-candidates/status.json').read_text())
 for path,entry in docs['files'].items():
  if not (path.startswith('internal/') or path.startswith('spec/')):continue
  assert sha((root/path).read_bytes())==entry['baseSha256'],path
  data=pathlib.Path(entry['candidatePath']).read_bytes();assert sha(data)==entry['candidateSha256'];prepared[path]=data
 state['appliedSourceHashes']={p:sha(b) for p,b in prepared.items()};state['unchangedNativeHashes']=unchanged;save()
 for path,data in prepared.items():(root/path).write_bytes(data)
 run('native-resolved-add',['git','add','--',*prepared.keys()],90)
 assert not run('native-remaining-conflicts',['git','diff','--name-only','--diff-filter=U'],90)
 run('native-docs-format',['corepack','pnpm@10.32.1','exec','prettier','--check',*prepared.keys()],180)
 run('native-diff-check',['git','diff','--cached','--check'],90)
 assert {p:sha((root/p).read_bytes()) for p in unchanged}==unchanged
 assert {p:sha((root/p).read_bytes()) for p in prepared}==state['appliedSourceHashes']
 protected=tracked_records(expected,'internal/records')
 protected.update(tracked_records(native,'internal/records/evidence/2026-11-24-gpui-native-composition-recovery'))
 protected.update(tracked_records(native,'internal/records/2026-11-24-gpui-native-composition-recovery.md'))
 staged=run('native-record-index',['git','ls-files','--stage','--','internal/records'],90)
 actual={line.split('\t',1)[1]:line.split('\t',1)[0].split()[1] for line in staged.splitlines() if line.split('\t',1)[0].split()[2]=='0'}
 mismatches={p:{'before':b,'after':actual.get(p)} for p,b in protected.items() if actual.get(p)!=b}
 (out/'record-retention.json').write_text(json.dumps({'count':len(protected),'mismatches':mismatches},indent=2)+'\n');assert not mismatches,str(mismatches)[:3000]
 externalCommits=['ecb6ec0d9ed0c631baeb36648bdb22a0f12601b6','b177e05b5cd07a123172d45ccfd7d227b43f8dfa','b80282546b5db036c87695dddaf5fc0f725d3776','143bce4d7253e015438116fbb3fbb191b593b6f4','f1760614090cb39fa91a07a1fb87a5077ea09c3a','c868f0c1802757f3cd1a507fb540f9568523f0e8','0b7b212d3193ea5c7ae219c0501036ee1255e3f2']
 externalPaths=set()
 for commit in externalCommits:externalPaths.update(subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',commit],cwd=root,text=True,timeout=90).splitlines())
 exceptions=set(unchanged)|set(prepared)|set(json.loads((ops/'external-0b7-integration/resolution-status.json').read_text())['sourceAfter'])
 retained={}
 for path in sorted(externalPaths-exceptions):
  expectedBlob=subprocess.check_output(['git','rev-parse','0b7b212d3193ea5c7ae219c0501036ee1255e3f2:'+path],cwd=root,text=True,timeout=30).strip()
  actualBlob=subprocess.check_output(['git','rev-parse',':'+path],cwd=root,text=True,timeout=30).strip()
  assert expectedBlob==actualBlob,path
  retained[path]=actualBlob
 (out/'external-retention.json').write_text(json.dumps({'verifiedCount':len(retained),'exactExternalBlobs':retained,'explicitReviewedUnions':sorted(exceptions)},indent=2)+'\n')
 state['preparedTree']=run('native-prepared-tree',['git','write-tree'],90)
 msg=out/'native-merge-message.txt';msg.write_text('Merge verified native composition and preserve concurrent lease controls\n\nRetain the source-bound 52c native recovery and its original receipts.\nPreserve the concurrent physical-request control, Scroll readiness and\ndetach fixes, and independent source and consumer additions. Clarify\nretained cached-view proof without widening the draft host boundary.\n\nThe earlier 61/72 native results remain bound to 52c. The combined\n62/74 expectation and merged Adapter controls await actual execution.\n')
 run('native-signedoff-commit',['git','commit','--signoff','--file',str(msg)],900)
 state['nativeMergeHead']=run('native-committed-head',['git','rev-parse','HEAD'],30)
 assert run('native-committed-tree',['git','rev-parse','HEAD^{tree}'],30)==state['preparedTree']
 assert run('native-committed-parents',['git','show','-s','--format=%P','HEAD'],30).split()==[expected,native]
 assert not run('native-committed-unstaged',['git','diff','--name-only'],90)
 state['sourceFreezeHashes']={p:sha((root/p).read_bytes()) for p in set(unchanged)|set(prepared)|set(json.loads((ops/'external-0b7-integration/resolution-status.json').read_text())['sourceAfter'])}
 state['phase']='native-committed';save()
 assert run('main-ref-check',['git','rev-parse','refs/s5-integration/main-20261124-0fbb'],30,folder=mainOut)==main
 run('normal-merge-main0fbb',['git','merge','--no-commit','--no-ff','--signoff',main],600,(0,1),mainOut)
 conflicts=run('main-conflicts',['git','diff','--name-only','--diff-filter=U'],90,folder=mainOut).splitlines()
 state['mainConflicts']=conflicts;assert not conflicts,conflicts
 mainPaths=set(run('main-changed-paths',['git','diff','--cached','--name-only'],90,folder=mainOut).splitlines())
 expectedPaths={'packages/cli/src/generated/brutalist-style-tokens.ts','packages/cli/src/services/hook-source-summary.ts','packages/cli/test/brutalist-reference-tokens.test.ts','packages/cli/test/hook-source-projection-accessors.test.ts'}
 assert mainPaths==expectedPaths,mainPaths
 assert {p:sha((root/p).read_bytes()) for p in state['sourceFreezeHashes']}==state['sourceFreezeHashes']
 run('main-diff-check',['git','diff','--cached','--check'],90,folder=mainOut)
 state['mainPreparedTree']=run('main-prepared-tree',['git','write-tree'],90,folder=mainOut)
 msg=mainOut/'message.txt';msg.write_text('Merge current main while retaining verified Sprint 5 source\n\nKeep the current CLI projection summary and generated focus-visible\ntokens. The reviewed native, Adapter, bundle gate and docs bytes are\nunchanged by this four-file integration.\n')
 run('main-signedoff-commit',['git','commit','--signoff','--file',str(msg)],900,folder=mainOut)
 state['finalHead']=run('final-head',['git','rev-parse','HEAD'],30,folder=mainOut)
 state['finalTree']=run('final-tree',['git','rev-parse','HEAD^{tree}'],30,folder=mainOut)
 assert state['finalTree']==state['mainPreparedTree']
 assert run('final-parents',['git','show','-s','--format=%P','HEAD'],30,folder=mainOut).split()==[state['nativeMergeHead'],main]
 assert {p:sha((root/p).read_bytes()) for p in state['sourceFreezeHashes']}==state['sourceFreezeHashes']
 assert not run('final-tracked-status',['git','status','--porcelain=v1','--untracked-files=no'],240,folder=mainOut)
 state['callableEffectsSha256']=sha((root/'packages/compiler/src/callable-effects.ts').read_bytes())
 state['phase']='combined-committed-tracked-clean'
except Exception as e:state['phase']='failed';state['error']=repr(e);state['traceback']=traceback.format_exc()
finally:
 state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 (mainOut/'status.json').write_text(json.dumps(state,indent=2)+'\n')
