#!/usr/bin/env python3
import pathlib,subprocess,json,os,datetime,traceback,signal,hashlib,gzip,re
root=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
out=pathlib.Path(str(root)+'-ops/combined-docs-ci-8768');out.mkdir(exist_ok=False)
tmp=pathlib.Path('/var/tmp/s5g75d5');tmp.mkdir(exist_ok=True)
env=os.environ.copy();env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env['PATH'];env['TMPDIR']=str(tmp);env['NODE_OPTIONS']='--max-old-space-size=4096'
state={'phase':'starting','sourceHead':'8768ffaaccfcf49158287c632a06318b675ac842','base':'0fbb52ef832cc27c78e24c28c59a55a16f51d7fe','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
def save():(out/'status.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,args,timeout=240):
 state['phase']=label;save()
 with (out/(label+'.log')).open('wb') as log:
  p=subprocess.Popen(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  entry={'label':label,'args':args,'pid':p.pid,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};state['commands'].append(entry);save()
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   entry['timeoutSeconds']=timeout
   os.killpg(p.pid,signal.SIGTERM)
   try:code=p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=10)
  entry['exitCode']=code;entry['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 if code!=0 or 'timeoutSeconds' in entry:raise RuntimeError(label+' failed '+str(code))
 return (out/(label+'.log')).read_text().strip()
try:
 assert run('source-head',['git','rev-parse','HEAD'],30)==state['sourceHead']
 assert not run('source-tracked-status',['git','status','--porcelain=v1','--untracked-files=no'],180)
 scope=['spec','packages/spec','scripts/spec','scripts/ci','package.json','pnpm-lock.yaml']
 before=run('relevant-source-blobs',['git','ls-tree','-r','HEAD','--',*scope],60);state['relevantSourceSha256']=hashlib.sha256(before.encode()).hexdigest();save()
 loader=out/'spec-loader-diagnostic.mjs'
 loader.write_text("""import path from 'node:path';\nimport fs from 'node:fs/promises';\nimport assert from 'node:assert/strict';\nimport { loadSpecWorkspaceFromDirectory } from '"""+str(root/'packages/spec/engine/src/node.ts')+"""';\nconst root="""+json.dumps(str(root))+""";\nconst workspace=await loadSpecWorkspaceFromDirectory(path.join(root,'spec'));\nconst result={sourceHead:"""+json.dumps(state['sourceHead'])+""",entityCount:workspace.entities.length,issues:workspace.issues};\nawait fs.writeFile("""+json.dumps(str(out/'spec-loader-result.json'))+""",JSON.stringify(result,null,2)+'\\n');\nconsole.log(JSON.stringify(result));\nassert.deepEqual(workspace.issues,[]);\n""")
 run('spec-authoring',['corepack','pnpm@10.32.1','check:spec-authoring','--','--base',state['base']],240)
 run('spec-loader',['node','--import','tsx',str(loader)],240)
 run('ci-scheduling',['node','--test','--test-reporter=tap','scripts/ci/test/ci-scheduling-policy.test.mjs'],180)
 run('ci-cycle',['node','--test','--test-reporter=tap','scripts/ci/test/cycle-job-inventory.test.mjs','scripts/ci/test/cycle-report.test.mjs'],180)
 run('ci-ledger',['node','--test','--test-reporter=tap','scripts/ci/test/release-source-ledger-checkpoints.test.mjs'],180)
 run('ci-schedule-check',['node','scripts/ci/check-ci-schedule.mjs'],120)
 assert run('source-head-after',['git','rev-parse','HEAD'],30)==state['sourceHead']
 after=run('relevant-source-blobs-after',['git','ls-tree','-r','HEAD','--',*scope],60);assert before==after
 assert not run('relevant-unstaged',['git','diff','--name-only','HEAD','--',*scope],60)
 state['counts']={}
 for name in ('ci-scheduling','ci-cycle','ci-ledger'):
  state['counts'][name]={k:int(v) for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$',(out/(name+'.log')).read_text(),re.M)}
 state['phase']='validated';save()
 # Download the fixed older job's original text; this is historical evidence,
 # distinct from the combined candidate's pending native acceptance.
 historic=out/'external-native-0b7-job-137955391702.log'
 with historic.open('wb') as log,(out/'external-log-download.stderr').open('wb') as err:
  p=subprocess.run(['gh','api','repos/Proto-UI/Proto-UI/actions/jobs/137955391702/logs'],cwd=root,env=env,stdout=log,stderr=err,timeout=90)
 state['historicalLogDownloadExitCode']=p.returncode
 if p.returncode==0:
  data=historic.read_bytes();text=data.decode()
  assert text.count('error[E0433]')==2 and 'external_scroll' in text
  packed=gzip.compress(data,mtime=0);assert gzip.decompress(packed)==data
  (out/(historic.name+'.gz')).write_bytes(packed)
  state['historicalNativeLog']={'sourceHead':'0b7b212d3193ea5c7ae219c0501036ee1255e3f2','runId':45249588810,'jobId':137955391702,'rawBytes':len(data),'rawSha256':hashlib.sha256(data).hexdigest(),'gzipBytes':len(packed),'gzipSha256':hashlib.sha256(packed).hexdigest(),'rustCompileErrors':2,'ordinaryTestsExecuted':0}
 state['phase']='validated-with-historical-log' if p.returncode==0 else 'validated-historical-download-pending'
except Exception as e:state['phase']='failed';state['error']=repr(e);state['traceback']=traceback.format_exc()
finally:state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
