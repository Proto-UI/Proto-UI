#!/usr/bin/env python3
import pathlib,subprocess,json,hashlib,zipfile,datetime,traceback,re
B=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a-ops')
O=B/'formal-2df-evidence';O.mkdir(exist_ok=False)
ARTS=[{"id":14860895880,"name":"compiler-source-regressions-2df421b1fc55cc0649be6675c0ee46a69ad9316f-45259712127","bytes":91180,"sha256":"382630283f003e7932c9fd859bf80906570a60380f37d7275ecd10be2fff8943","head":"2df421b1fc55cc0649be6675c0ee46a69ad9316f","label":"source"},{"id":14859968084,"name":"compiler-browser-acceptance-2df421b1fc55cc0649be6675c0ee46a69ad9316f-45259712127","bytes":2012052,"sha256":"24f0c13f7d841a162eb9173885a3efa851b3be68d3b5a9375f9b6306964fab3e","head":"2df421b1fc55cc0649be6675c0ee46a69ad9316f","label":"browser"},{"id":14858984928,"name":"compiler-production-build-2df421b1fc55cc0649be6675c0ee46a69ad9316f-45259712127","bytes":425332,"sha256":"7cfd2b5a4094c33a3da7799fb4add37ecbae361be6b568663ae852601a2ee1e4","head":"2df421b1fc55cc0649be6675c0ee46a69ad9316f","label":"production"}]
S={'phase':'initial','runId':45259712127,'head':'2df421b1fc55cc0649be6675c0ee46a69ad9316f','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'artifacts':[]}
def save(p=None):
 if p:S['phase']=p
 (O/'status.json').write_text(json.dumps(S,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
try:
 for a in ARTS:
  save('download-'+a['label'])
  p=O/(a['label']+'.zip')
  with p.open('wb') as f,(O/(a['label']+'-download.stderr')).open('wb') as err:
   r=subprocess.run(['gh','api','repos/Proto-UI/Proto-UI/actions/artifacts/'+str(a['id'])+'/zip'],stdout=f,stderr=err,timeout=180)
  assert r.returncode==0
  raw=p.read_bytes();actual=sha(raw)
  assert len(raw)==a['bytes'] and actual==a['sha256'],(a,actual,len(raw))
  q=O/'extracted'/a['label'];q.mkdir(parents=True)
  with zipfile.ZipFile(p) as z:
   assert z.testzip() is None
   for n in z.namelist():
    assert not pathlib.PurePosixPath(n).is_absolute() and '..' not in pathlib.PurePosixPath(n).parts,n
   z.extractall(q)
  txt=(q/'source-sha.txt').read_text().strip();assert txt==S['head'],(a['label'],txt)
  a['sourceShaReadback']=txt;a['verifiedSha256']=actual;a['verifiedBytes']=len(raw)
  S['artifacts'].append(a);save()
 browser=O/'extracted/browser';receipt=json.loads((browser/'receipt.json').read_text());index=json.loads((browser/'verified-delivery.json').read_text())
 assert receipt['head']==S['head'] and receipt['service']['mode']=='runner-owned-production-static'
 assert receipt['cases'] and all(c['status']=='passed' for c in receipt['cases'])
 rows=[r for p in index['pages'] for r in p.get('targets',[])]
 assert len(rows)==8 and all(r['status']=='browser-executed-awaiting-independent-acceptance' for r in rows)
 S['browser']={'caseCount':len(receipt['cases']),'passed':len(receipt['cases']),'serviceMode':receipt['service']['mode'],'receiptSha256':sha((browser/'receipt.json').read_bytes()),'verifiedDeliverySha256':sha((browser/'verified-delivery.json').read_bytes()),'verifiedRows':len(rows),'caseNames':[c.get('name',c.get('id')) for c in receipt['cases']]}
 src=O/'extracted/source';v=json.loads((src/'vitest.json').read_text());S['source']={k:v.get(k) for k in ['numTotalTestSuites','numPassedTestSuites','numFailedTestSuites','numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests','success']}
 assert v['success'] and v['numFailedTests']==0 and v['numPendingTests']==0
 S['source']['specBaseSha']=(src/'spec-base-sha.txt').read_text().strip()
 S['source']['typesTail']=(src/'types.log').read_text()[-3000:]
 S['source']['specAuthoringTail']=(src/'spec-authoring.log').read_text()[-1500:]
 prod=O/'extracted/production';graph=prod/'proto-ui-bundle-graph.json'
 gh=sha(graph.read_bytes());expected=(prod/'production-graph.sha256').read_text().split()[0];assert gh==expected
 S['production']={'graphSha256':gh,'graphBytes':graph.stat().st_size,'buildTail':(prod/'production-build.log').read_text()[-3000:]}
 log=(prod/'bundle-gate-controls.log').read_text();S['production']['gateCounts']={k:int(v) for k,v in re.findall(r'^[#ℹ] (tests|pass|fail|cancelled|skipped|todo) (\d+)$',log,re.M)}
 assert S['production']['gateCounts']['pass']==2150 and S['production']['gateCounts']['fail']==0
 S['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save('verified-artifacts')
except BaseException as e:
 S['error']=repr(e);S['traceback']=traceback.format_exc();save('failed');raise
