#!/usr/bin/env python3
import pathlib,subprocess,json,os,datetime,traceback,re,hashlib
root=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
ops=pathlib.Path(str(root)+'-ops');out=ops/'external-0b7-integration';native=ops/'native52c-integration';native.mkdir(exist_ok=False)
env=os.environ.copy();env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env['PATH'];env['TMPDIR']='/tank/shared/projects/proto-ui-agent/s5at75d5'
state={'phase':'starting','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
def save():(out/'commit-and-native-status.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,args,timeout=180,okay=(0,),folder=out):
 state['phase']=label;save()
 p=subprocess.run(args,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
 (folder/(label+'.log')).write_text(p.stdout);state['commands'].append({'label':label,'args':args,'exitCode':p.returncode});save()
 if p.returncode not in okay:raise RuntimeError(label+' exit '+str(p.returncode))
 return p.stdout.strip()
def sha(path):return hashlib.sha256((root/path).read_bytes()).hexdigest()
try:
 ready=json.loads((out/'resolution-status.json').read_text());assert ready['phase']=='resolved-validated-ready-to-commit'
 assert run('commit-before-head',['git','rev-parse','HEAD'],30)=='0bee7dc9fb100085960f765a20ab9e8e0dc584e2'
 assert run('commit-before-merge-head',['git','rev-parse','MERGE_HEAD'],30)=='0b7b212d3193ea5c7ae219c0501036ee1255e3f2'
 assert run('commit-before-tree',['git','write-tree'],90)==ready['preparedTree']
 assert not run('commit-before-unstaged',['git','diff','--name-only'],90)
 state['gateCounts']={k:int(v) for k,v in re.findall(r'^(?:#|ℹ) (tests|pass|fail|cancelled|skipped|todo) (\d+)$',(out/'gate-union-controls.log').read_text(),re.M)}
 assert state['gateCounts']=={'tests':2150,'pass':2150,'fail':0,'cancelled':0,'skipped':0,'todo':0}
 assert {p:sha(p) for p in ready['sourceAfter']}==ready['sourceAfter']
 msg=out/'commit-message.txt'
 msg.write_text('Merge concurrent Sprint 5 follow-up and retain both regression suites\n\nPreserve remote 0b7 owner-retirement, native consumer, IR and CI work.\nCombine both exact percentage-boundary test sets and both Adapter\nreadOnly control sets without widening runtime permissions.\n\nThe merged bundle controls pass 2150/2150 with zero skips. The original\nproduction graph is unchanged and replays with no issues. Final native\nand browser acceptance remain pending the complete combined source.\n')
 run('normal-signedoff-commit',['git','commit','--signoff','--file',str(msg)],900)
 state['committedHead']=run('committed-head',['git','rev-parse','HEAD'],30)
 state['committedTree']=run('committed-tree',['git','rev-parse','HEAD^{tree}'],30)
 assert state['committedTree']==ready['preparedTree']
 state['parents']=run('committed-parents',['git','show','-s','--format=%P','HEAD'],30).split()
 assert state['parents']==['0bee7dc9fb100085960f765a20ab9e8e0dc584e2','0b7b212d3193ea5c7ae219c0501036ee1255e3f2']
 assert {p:sha(p) for p in ready['sourceAfter']}==ready['sourceAfter']
 assert not run('committed-tracked-status',['git','status','--porcelain=v1','--untracked-files=no'],240)
 state['phase']='remote-merge-committed-clean';save()
 nativeSource='52c87232f593d85a28cbd04ad205f0d5fe6f03a3'
 state['nativeHead']=nativeSource
 run('normal-merge-native52c',['git','merge','--no-commit','--no-ff','--signoff',nativeSource],600,(0,1),native)
 conflicts=run('native-unmerged-paths',['git','diff','--name-only','--diff-filter=U'],90,folder=native).splitlines()
 state['nativeConflicts']=conflicts
 stages=native/'conflict-stages';stages.mkdir(exist_ok=True)
 for path in conflicts:
  for stage in (1,2,3):
   p=subprocess.run(['git','show',':'+str(stage)+':'+path],cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
   if p.returncode==0:(stages/(path.replace('/','__')+'.stage'+str(stage))).write_bytes(p.stdout)
 run('native-merge-cc',['git','diff','--cc'],90,folder=native)
 run('native-staged-stat',['git','diff','--cached','--stat'],90,folder=native)
 state['phase']='native-merge-conflicts-ready' if conflicts else 'native-merge-prepared'
except Exception as e:state['phase']='failed';state['error']=repr(e);state['traceback']=traceback.format_exc()
finally:
 state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 (native/'status.json').write_text(json.dumps(state,indent=2)+'\n')
