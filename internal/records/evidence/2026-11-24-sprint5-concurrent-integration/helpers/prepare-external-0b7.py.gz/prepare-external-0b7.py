#!/usr/bin/env python3
import subprocess,pathlib,json,os,datetime,traceback
root=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
out=pathlib.Path(str(root)+'-ops/external-0b7-integration')
out.mkdir(parents=True,exist_ok=True)
env=os.environ.copy()
env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env['PATH']
env['TMPDIR']='/tank/shared/projects/proto-ui-agent/s5at75d5'
env['GIT_OPTIONAL_LOCKS']='0'
expected='0bee7dc9fb100085960f765a20ab9e8e0dc584e2'
state={'phase':'starting','expectedHead':expected,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
def save():
 (out/'status.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,args,timeout=180,okay=(0,)):
 state['phase']=label;save()
 p=subprocess.run(args,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
 (out/(label+'.log')).write_text(p.stdout)
 state['commands'].append({'label':label,'args':args,'exitCode':p.returncode});save()
 if p.returncode not in okay:raise RuntimeError(label+' exit '+str(p.returncode))
 return p.stdout.strip()
try:
 assert run('head',['git','rev-parse','HEAD'],30)==expected
 tracked=run('tracked-status',['git','status','--porcelain=v1','--untracked-files=no'],240)
 assert not tracked,tracked
 untracked=run('untracked-status',['git','ls-files','--others','--exclude-standard'],240)
 assert not untracked,untracked
 run('fetch',['git','fetch','--no-tags','origin','refs/heads/fix/sprint5-preview-input-bundle-20261123-75d5:refs/s5-integration/parallel-20261124-0b7','refs/heads/main:refs/s5-integration/main-20261124-0fbb'],180)
 state['remoteHead']=run('remote-head',['git','rev-parse','refs/s5-integration/parallel-20261124-0b7'],30)
 state['mainHead']=run('main-head',['git','rev-parse','refs/s5-integration/main-20261124-0fbb'],30)
 run('current-vs-remote-names',['git','diff','--name-status','HEAD',state['remoteHead']],60)
 run('current-vs-remote-stat',['git','diff','--stat','HEAD',state['remoteHead']],60)
 run('adapter-ours-remote',['git','diff','HEAD',state['remoteHead'],'--','native/gpui/crates/proto-ui-gpui/src/a11y.rs','native/gpui/crates/proto-ui-gpui/src/host.rs','native/gpui/crates/proto-ui-gpui/tests/a11y_projection.rs'],60)
 assert state['remoteHead']=='0b7b212d3193ea5c7ae219c0501036ee1255e3f2',state['remoteHead']
 assert state['mainHead']=='0fbb52ef832cc27c78e24c28c59a55a16f51d7fe',state['mainHead']
 state['phase']='fetched-clean-review-ready'
except Exception as error:
 state['phase']='failed';state['error']=repr(error);state['traceback']=traceback.format_exc()
finally:
 state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
