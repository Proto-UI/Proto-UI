#!/usr/bin/env python3
import subprocess,pathlib,json,os,datetime,traceback,hashlib
root=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
ops=pathlib.Path(str(root)+'-ops');out=ops/'external-0b7-integration'
env=os.environ.copy();env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env['PATH'];env['TMPDIR']='/tank/shared/projects/proto-ui-agent/s5at75d5'
state={'phase':'starting','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
def save():(out/'resolution-status.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,args,timeout=180,okay=(0,)):
 state['phase']=label;save()
 p=subprocess.run(args,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
 (out/(label+'.log')).write_text(p.stdout);state['commands'].append({'label':label,'args':args,'exitCode':p.returncode});save()
 if p.returncode not in okay:raise RuntimeError(label+' exit '+str(p.returncode))
 return p.stdout.strip()
def sha(b):return hashlib.sha256(b).hexdigest()
try:
 initial=json.loads((out/'merge-status.json').read_text());assert initial['phase']=='merge-conflicts-ready'
 assert run('resolve-head',['git','rev-parse','HEAD'],30)==initial['expectedHead']
 assert run('resolve-merge-head',['git','rev-parse','MERGE_HEAD'],30)==initial['mergeHead']
 current=run('resolve-conflicts',['git','diff','--name-only','--diff-filter=U'],60).splitlines()
 assert set(current)==set(initial['conflicts'])
 candidate={}
 for directory in ('external-0b7-union-candidates','external-0b7-gate-union'):
  packet=json.loads((ops/directory/'status.json').read_text());assert packet['phase']=='prepared-review-only'
  for path,entry in packet['files'].items():
   if path.startswith('internal/') or path.startswith('spec/'):continue
   contents=pathlib.Path(entry['candidatePath']).read_bytes();assert sha(contents)==entry['candidateSha256']
   candidate[path]=contents
 for path in current:
  for stage,ref in [(2,initial['expectedHead']),(3,initial['mergeHead'])]:
   expected=run('stage-'+str(stage)+'-'+path.replace('/','__'),['git','rev-parse',ref+':'+path],30)
   actual=run('index-'+str(stage)+'-'+path.replace('/','__'),['git','rev-parse',':'+str(stage)+':'+path],30)
   assert actual==expected,path
 projection='native/gpui/crates/proto-ui-gpui/tests/a11y_projection.rs'
 assert (root/projection).read_bytes()==candidate[projection],'auto-merged projection differs from reviewed union'
 state['beforeWriteHashes']={p:sha((root/p).read_bytes()) for p in candidate};save()
 for path,contents in candidate.items():(root/path).write_bytes(contents)
 run('resolved-add',['git','add','--',*candidate.keys()],90)
 assert not run('resolved-unmerged',['git','diff','--name-only','--diff-filter=U'],60)
 formatted=['scripts/coverage-matrices/check-website-production-bundle.mjs','scripts/coverage-matrices/test/check-website-production-bundle.test.mjs']
 run('gate-format-before',['corepack','pnpm@10.32.1','exec','prettier','--check',*formatted],180,(0,1))
 if state['commands'][-1]['exitCode']==1:
  run('gate-format-write',['corepack','pnpm@10.32.1','exec','prettier','--write',*formatted],180)
  run('gate-format-after',['corepack','pnpm@10.32.1','exec','prettier','--check',*formatted],180)
  run('gate-format-add',['git','add','--',*formatted],90)
 run('resolved-diff-check',['git','diff','--cached','--check'],90)
 protected=json.loads((out/'protected-record-blobs-before.json').read_text())
 index=run('record-blobs-after',['git','ls-files','--stage','--','internal/records'],90)
 actual={}
 for line in index.splitlines():
  meta,path=line.split('\t',1);mode,blob,stage=meta.split()
  if stage=='0':actual[path]=blob
 mismatches={p:{'before':b,'after':actual.get(p)} for p,b in protected.items() if actual.get(p)!=b}
 (out/'protected-record-comparison.json').write_text(json.dumps({'count':len(protected),'mismatches':mismatches},indent=2)+'\n')
 assert not mismatches, str(mismatches)[:4000]
 state['sourceBefore']={p:sha((root/p).read_bytes()) for p in candidate};save()
 run('gate-union-controls',['node','--test','scripts/coverage-matrices/test/check-website-production-bundle.test.mjs'],240)
 graph=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-db747-hosted-75d5e28a/production/proto-ui-bundle-graph.json')
 expectedGraph='08aa327638f6f19eb6cef4721ede8b4508ce928ff79e334fd262946a59b89881'
 assert sha(graph.read_bytes())==expectedGraph
 replay=out/'gate-original-graph-replay.mjs'
 replay.write_text("""import fs from 'node:fs';\nimport crypto from 'node:crypto';\nimport { collectWebsiteProductionBundleIssues } from '"""+str(root/ formatted[0])+"""';\nconst path="""+json.dumps(str(graph))+""";\nconst data=fs.readFileSync(path);\nconst issues=collectWebsiteProductionBundleIssues({graph:JSON.parse(data.toString())});\nconsole.log(JSON.stringify({graphPath:path,graphSha256:crypto.createHash('sha256').update(data).digest('hex'),issues},null,2));\nif(issues.length)process.exitCode=1;\n""")
 run('gate-original-graph-replay',['node',str(replay)],90)
 assert sha(graph.read_bytes())==expectedGraph
 state['sourceAfter']={p:sha((root/p).read_bytes()) for p in candidate}
 assert state['sourceBefore']==state['sourceAfter']
 state['preparedTree']=run('resolved-tree',['git','write-tree'],90)
 run('resolved-staged-stat',['git','diff','--cached','--stat'],90)
 state['phase']='resolved-validated-ready-to-commit'
except Exception as e:state['phase']='failed';state['error']=repr(e);state['traceback']=traceback.format_exc()
finally:state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
