#!/usr/bin/env python3
import subprocess,pathlib,json,os,datetime,traceback,hashlib
root=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
out=pathlib.Path(str(root)+'-ops/external-0b7-integration')
env=os.environ.copy()
env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env['PATH']
env['TMPDIR']='/tank/shared/projects/proto-ui-agent/s5at75d5'
expected='0bee7dc9fb100085960f765a20ab9e8e0dc584e2'
remote='0b7b212d3193ea5c7ae219c0501036ee1255e3f2'
state={'phase':'starting','expectedHead':expected,'mergeHead':remote,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
def save():
 (out/'merge-status.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,args,timeout=180,okay=(0,)):
 state['phase']=label;save()
 p=subprocess.run(args,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
 (out/(label+'.log')).write_text(p.stdout)
 state['commands'].append({'label':label,'args':args,'exitCode':p.returncode});save()
 if p.returncode not in okay:raise RuntimeError(label+' exit '+str(p.returncode))
 return p.stdout.strip()
try:
 prior=json.loads((out/'status.json').read_text())
 assert prior['phase']=='fetched-clean-review-ready'
 assert prior['remoteHead']==remote
 assert run('merge-before-head',['git','rev-parse','HEAD'],30)==expected
 assert run('merge-ref',['git','rev-parse','refs/s5-integration/parallel-20261124-0b7'],30)==remote
 assert not run('merge-before-tracked',['git','status','--porcelain=v1','--untracked-files=no'],240)
 records=run('record-blobs-before',['git','ls-tree','-r','HEAD','--','internal/records'],90)
 protected={}
 for line in records.splitlines():
  meta,path=line.split('\t',1)
  if path.endswith('.gz') or path.endswith('/manifest.json'):protected[path]=meta.split()[2]
 (out/'protected-record-blobs-before.json').write_text(json.dumps(protected,indent=2)+'\n')
 state['protectedRecordCount']=len(protected);save()
 run('normal-merge-0b7',['git','merge','--no-commit','--no-ff','--signoff',remote],600,(0,1))
 conflicts=run('unmerged-paths',['git','diff','--name-only','--diff-filter=U'],90).splitlines()
 state['conflicts']=conflicts
 stages=out/'conflict-stages';stages.mkdir(exist_ok=True)
 for path in conflicts:
  for stage in (1,2,3):
   p=subprocess.run(['git','show',':'+str(stage)+':'+path],cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
   if p.returncode==0:(stages/(path.replace('/','__')+'.stage'+str(stage))).write_bytes(p.stdout)
 run('normal-merge-cc',['git','diff','--cc'],90)
 run('normal-merge-staged-stat',['git','diff','--cached','--stat'],90)
 state['phase']='merge-conflicts-ready' if conflicts else 'merge-prepared'
except Exception as error:
 state['phase']='failed';state['error']=repr(error);state['traceback']=traceback.format_exc()
finally:
 state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
