#!/usr/bin/env python3
import pathlib,os,json,subprocess,datetime,time,traceback
T=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a');O=pathlib.Path(str(T)+'-ops/publish-final-candidate');O.mkdir(exist_ok=False)
E=dict(os.environ);E['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+E.get('PATH','')
assert E.get('HUSKY')!='0'
S={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'initial','commands':[],'dispatchIssued':False}
def save(p=None):
 if p:S['phase']=p
 (O/'status.json').write_text(json.dumps(S,indent=2)+'\n')
def run(n,a,timeout=180):
 save(n)
 with (O/(n+'.log')).open('wb') as f:r=subprocess.run(a,cwd=T,env=E,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 S['commands'].append({'name':n,'argv':a,'exitCode':r.returncode});save()
 assert r.returncode==0,n
 return (O/(n+'.log')).read_text()
def git(*a):return subprocess.check_output(['git',*a],cwd=T,env=E,text=True,timeout=60).strip()
def api(n,p):return json.loads(run(n,['gh','api',p]))
repo='Proto-UI/Proto-UI';branch='fix/sprint5-preview-input-bundle-20261123-75d5'
endpoint='repos/'+repo+'/actions/workflows/compiler-gpui-source-consumers.yml/runs?event=workflow_dispatch&branch='+branch+'&per_page=30'
try:
 ci=json.loads(pathlib.Path(str(T)+'-ops/ci-final-followup/status.json').read_text());assert ci['phase']=='committed'
 head=ci['finalHead'];assert git('rev-parse','HEAD')==head and git('status','--porcelain=v1')==''
 S['head']=head;S['tree']=git('rev-parse','HEAD^{tree}')
 assert git('diff','--name-only','e470d1b0c21fc40e99e71cd7c49a76470444c6e7','HEAD')=='.github/workflows/compiler-browser-acceptance.yml'
 pr=api('pr-before','repos/'+repo+'/pulls/1738')
 assert pr['state']=='open' and not pr['merged'] and pr['draft'] and pr['head']['ref']==branch
 assert pr['head']['sha']=='00781c057590255074dc0f7651b8051801f41616','new concurrent PR head requires review'
 main=api('main-before','repos/'+repo+'/branches/main')
 S['observedMain']=main['commit']['sha']
 assert S['observedMain']=='0fbb52ef832cc27c78e24c28c59a55a16f51d7fe','new main requires impact review'
 remote=run('remote-before',['git','ls-remote','origin','refs/heads/'+branch]).split()[0]
 assert remote==pr['head']['sha']
 run('remote-is-ancestor',['git','merge-base','--is-ancestor',remote,head])
 run('push',['git','push','origin','HEAD:refs/heads/'+branch],timeout=900)
 published=api('pr-after','repos/'+repo+'/pulls/1738')
 assert published['head']['sha']==head and published['state']=='open' and published['draft'],'unexpected PR state after push'
 S['publishedHead']=published['head']['sha'];S['publishedDraft']=published['draft'];save('published')
 runs=api('runs-before-dispatch',endpoint)
 matching=[r for r in runs['workflow_runs'] if r['head_sha']==head]
 if matching:
  S['run']={k:matching[0].get(k) for k in ['id','html_url','head_sha','event','status','conclusion']}
  S['dispatchReusedExisting']=True;save('existing-exact-head-run')
 else:
  run('dispatch',['gh','workflow','run','compiler-gpui-source-consumers.yml','--repo',repo,'--ref',branch,'-f','browser_acceptance=true','-f','adapter_acceptance=true'])
  S['dispatchIssued']=True;S['dispatchInputs']={'browser_acceptance':True,'adapter_acceptance':True};save('dispatch-issued-awaiting-readback')
  for i in range(8):
   time.sleep(3)
   runs=api('runs-readback-'+str(i),endpoint)
   matching=[r for r in runs['workflow_runs'] if r['head_sha']==head]
   if matching:
    S['run']={k:matching[0].get(k) for k in ['id','html_url','head_sha','event','status','conclusion']}
    save('dispatched-exact-head');break
  else:save('dispatch-issued-awaiting-readback')
 S['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
except BaseException as e:
 S['error']=repr(e);S['traceback']=traceback.format_exc();save('failed');raise
