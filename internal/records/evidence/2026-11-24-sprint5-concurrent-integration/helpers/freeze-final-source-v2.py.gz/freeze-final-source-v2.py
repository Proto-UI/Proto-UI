#!/usr/bin/env python3
import os,json,pathlib,subprocess,hashlib,datetime,traceback
T=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
O=pathlib.Path(str(T)+'-ops/final-source-freeze-v2')
O.mkdir(exist_ok=False)
E=dict(os.environ); E['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+E.get('PATH','')
assert E.get('HUSKY')!='0'
E['NODE_OPTIONS']='--max-old-space-size=4096'; E['TMPDIR']='/var/tmp/s5g75d5'
pathlib.Path(E['TMPDIR']).mkdir(exist_ok=True)
S={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'initial','commands':[]}
def save(phase=None):
 if phase:S['phase']=phase
 (O/'status.json').write_text(json.dumps(S,indent=2)+'\n')
def cmd(name,argv,allowed=(0,),timeout=900,trace=False):
 save(name); env=dict(E)
 if trace:env['GIT_TRACE2_EVENT']=str(O/(name+'.trace.jsonl'))
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (O/(name+'.log')).open('wb') as f:
  r=subprocess.run(argv,cwd=T,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 S['commands'].append({'name':name,'argv':argv,'started':start,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode})
 save()
 if r.returncode not in allowed:raise RuntimeError(name+' exit '+str(r.returncode))
 return (O/(name+'.log')).read_text(errors='replace')
def git(*a):
 return subprocess.check_output(['git',*a],cwd=T,env=E,text=True,timeout=60).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def clean():assert git('status','--porcelain=v1')=='','worktree not clean'
def commit(name,message):
 (O/(name+'.message.txt')).write_text(message+'\n')
 prepared=git('write-tree')
 cmd(name,['git','commit','--signoff','--file',str(O/(name+'.message.txt'))],trace=True)
 actual=git('rev-parse','HEAD^{tree}')
 assert actual==prepared,'hook modified prepared tree'
 ev=[json.loads(x) for x in (O/(name+'.trace.jsonl')).read_text().splitlines()]
 hooks=[x for x in ev if x.get('event')=='child_start' and x.get('child_class')=='hook']
 assert any(x.get('hook_name')=='pre-commit' for x in hooks),'missing actual pre-commit invocation'
 S[name]={'head':git('rev-parse','HEAD'),'tree':actual,'preparedTree':prepared,'hookEvents':hooks}
 save()
try:
 assert git('rev-parse','HEAD')=='8768ffaaccfcf49158287c632a06318b675ac842'
 clean()
 S['initialHead']=git('rev-parse','HEAD')
 S['hooksBefore']={str(p):(T/p).exists() for p in [pathlib.Path('.husky/_/pre-commit'),pathlib.Path('.husky/_/h')]}
 cmd('initialize-project-husky',['corepack','pnpm@10.32.1','run','prepare'],timeout=180)
 assert git('config','--get','core.hooksPath')=='.husky/_'
 S['hooksAfter']={str(p):{'exists':(T/p).exists(),'executable':os.access(T/p,os.X_OK),'sha256':sha(T/p)} for p in [pathlib.Path('.husky/_/pre-commit'),pathlib.Path('.husky/_/h'),pathlib.Path('.husky/pre-commit')]}
 assert all(x['exists'] for x in S['hooksAfter'].values())
 assert S['hooksAfter']['.husky/_/pre-commit']['executable']
 assert os.access(T/'.husky/_/h',os.R_OK)
 assert '. \"$(dirname \"$0\")/h\"' in (T/'.husky/_/pre-commit').read_text()
 target='packages/compiler/src/targets.ts'
 original=(T/target).read_bytes()
 assert hashlib.sha256(original).hexdigest()=='2fd07e809c8b740303e8ea7b23a119e6d529cbf79425d2ce526488ac0b475e58'
 assert original.count(b"'scroll.sync'")==1
 old='0b7b212d3193ea5c7ae219c0501036ee1255e3f2'
 remote='00781c057590255074dc0f7651b8051801f41616'
 cmd('fetch-public-00781',['git','fetch','--no-tags','origin','refs/heads/fix/sprint5-preview-input-bundle-20261123-75d5:refs/remotes/s5-75d5/final-remote-00781'])
 assert git('rev-parse','refs/remotes/s5-75d5/final-remote-00781')==remote,'remote advanced; inspect before merge'
 changed=git('diff','--name-only',old,remote).splitlines()
 assert len(changed)==6 and target in changed
 assert all(git('rev-parse','HEAD:'+p)==git('rev-parse',remote+':'+p) for p in changed if p!=target),'non-target concurrent delta not already integrated'
 diff=git('diff','--unified=0',old,remote,'--',target)
 (O/'remote-targets.patch').write_text(diff+'\n')
 removed=[x[1:] for x in diff.splitlines() if x.startswith('-') and not x.startswith('---')]
 added=[x for x in diff.splitlines() if x.startswith('+') and not x.startswith('+++')]
 assert len(removed)==1 and removed[0].strip()=="'scroll.sync'," and not added
 assert git('show',remote+':'+target).count("'scroll.sync'")==1
 S['remoteDelta']={'head':remote,'paths':changed,'targetsRemoved':removed}
 cmd('merge-public-00781',['git','merge','--no-ff','--no-commit','--signoff',remote],allowed=(0,1))
 unresolved=git('diff','--name-only','--diff-filter=U').splitlines()
 assert set(unresolved)<=set([target]),unresolved
 (O/'automatic-merge-targets.ts').write_bytes((T/target).read_bytes())
 S['automaticScrollOccurrences']=(T/target).read_text().count("'scroll.sync'")
 (T/target).write_bytes(original)
 cmd('stage-unique-scroll',['git','add','--',target])
 assert git('diff','--cached','--name-only')=='','unexpected staged source diff in remote convergence merge'
 cmd('remote-diff-check',['git','diff','--cached','--check'])
 commit('commit-public-00781','merge: preserve unique GPUI scroll admission across concurrent S5 updates')
 clean()
 retained=[
 'packages/compiler/src/gpui-native-owner.ts','packages/compiler/src/gpui-native-modules.ts',
 'packages/compiler/src/gpui-native-hover.ts','packages/compiler/src/gpui-native-a11y.ts',
 'packages/compiler/src/gpui-native-control-label.ts','packages/compiler/src/gpui-native-scroll.ts',
 'packages/compiler/src/ir-validation.ts','packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs',
 'packages/compiler/test/fixtures/gpui-ordinary-values/a11y-activation-consumer.rs',
 'native/gpui/crates/proto-ui-gpui/src/a11y.rs','native/gpui/crates/proto-ui-gpui/src/host.rs',
 'native/gpui/crates/proto-ui-gpui/tests/a11y_projection.rs',
 'internal/compiler/gpui-control-label.md','spec/host-caps/HC-CONTROL-LABEL-0001.yaml',
 'scripts/coverage-matrices/check-website-production-bundle.mjs',
 'scripts/coverage-matrices/test/check-website-production-bundle.test.mjs',
 target,'.github/workflows/compiler-browser-acceptance.yml',
 'packages/compiler/test/capture-facade.test.ts','packages/compiler/test/value-ir.test.ts',
 'packages/compiler/test/capture-lookup-integrity.test.ts','packages/compiler/test/authored-hook-language.test.ts',
 'packages/compiler/test/mutable-callable-orders.test.ts','packages/compiler/test/module-helper-capture-boundary.test.ts',
 'packages/compiler/test/privileged-capture-metadata.test.ts'
 ]
 S['retainedBefore']={p:sha(T/p) for p in retained}
 parser='2d339a2da68568627a80265147b5133ae36331d7'
 assert git('rev-parse',parser+'^')=='52c87232f593d85a28cbd04ad205f0d5fe6f03a3'
 expected=git('diff-tree','--no-commit-id','--name-only','-r',parser).splitlines()
 assert len(expected)==98
 cmd('merge-capture-provenance',['git','merge','--no-ff','--no-commit','--signoff',parser])
 assert not git('diff','--name-only','--diff-filter=U')
 assert sorted(git('diff','--cached','--name-only').splitlines())==sorted(expected)
 required={
 'packages/compiler/src/callable-effects.ts':'3608dbdd18ce3748cbebb67d83cf1fd113639f5f323f7a6e18f27060e367f7ca',
 'packages/compiler/test/capture-getter-presence.test.ts':'401ba3ab0ace392f82388c8bcee02f512d691906ff24d09071024cee2b6c56de',
 'packages/compiler/test/capture-host-presence.test.ts':'e549d60efb5e428642194d6974959cc3b05365277e2bf7735b4dab1712df5c23'}
 assert all(sha(T/p)==v for p,v in required.items())
 cmd('capture-merge-diff-check',['git','diff','--cached','--check'])
 commit('commit-capture-provenance','merge: retain bounded capture getter provenance and presence controls')
 clean()
 S['retainedAfter']={p:sha(T/p) for p in retained}
 assert S['retainedBefore']==S['retainedAfter']
 S['captureSources']={p:sha(T/p) for p in required}
 S['finalHead']=git('rev-parse','HEAD');S['finalTree']=git('rev-parse','HEAD^{tree}')
 S['trackedAndUntrackedClean']=git('status','--porcelain=v1')==''
 S['finalUniqueScrollOccurrences']=(T/target).read_text().count("'scroll.sync'")
 assert S['finalUniqueScrollOccurrences']==1
 S['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 save('clean-product-combination')
except BaseException as exc:
 S['error']=repr(exc);S['traceback']=traceback.format_exc()
 try:S['observedHead']=git('rev-parse','HEAD');S['observedStatus']=git('status','--porcelain=v1')
 except BaseException:pass
 save('failed')
 raise
