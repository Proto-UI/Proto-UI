<!-- agent-s5-current:2df421b1fc55 -->

## 当前公开候选：并发修复已完整汇合，正式验收进行中

公开 head：`2df421b1fc55cc0649be6675c0ee46a69ad9316f`，tree `67e54cae53ee5a8f9f3da7206e1b1dc03c6aef20`。发布前重新核实了公开 `00781c057590255074dc0f7651b8051801f41616` 和 main `0fbb52ef832cc27c78e24c28c59a55a16f51d7fe`；通过正常合并保留并行会话 `0b7` / `00781`、本地原生修复 `52c8723` 和 capture 修复 `2d339a2`，保留作者与签署历史，使用普通 non-force push。

正式 [Compiler GPUI source consumers · 45259712127](https://github.com/Proto-UI/Proto-UI/actions/runs/45259712127) 已**单次**触发并独立读回 exact head。手动输入为 `browser_acceptance=true`、`adapter_acceptance=true`，因此 browser、source、production、Linux/macOS native、Flutter 和 Adapter 路线均已选择。package-budget / website-shader 两个额外 opt-in 保持默认 false，实际 skipped；它们不计作通过。当前继续保持 **Draft**。

### 本次组合的实质变化

- **原生 SDK 与真实生命周期并集**：保留唯一 ControlLabel/module 定义、App 所属 owner 登记、Scroll 外部 handle 与 reader/pause 的已有语义；恢复官方 producer 中遗漏的 `external_scroll`。ControlLabel 同时保留 immutable action snapshot、实际唯一物理 view/role 的证明、cached view 与 Drop 的生命周期边界、歧义拒绝，以及并发新增的物理替换控制。Scroll 合入并发的 unlaid/foreign readiness 与 detach 清理，原 pending epoch receipt 保留。
- **Adapter readOnly**：只接受已支持的 exact boolean state，以 `Option<bool>` 区分缺省与 true/false，真实 AccessKit node 能设置及清除状态；unsupported residual 拒绝、checked/mixed 原语义、官方 fixture 均保留。两边独立 projection/node 控制完整并集。
- **capture getter provenance / presence**：copied getters 绑定真实 capture 身份；actual own-key absence 与显式 undefined 分开传播，保留 phase、throw、escape、未知 getter/metadata 与原 IR 边界。没有按名字或静态类型扩大 native authority。并发新增的两条官方 Input source-free IR 控制保留。
- **有限 production graph owner**：既有 exact WC bridge 的一个内部 percentage helper 与两条 exact diagnostic producer 材料边界保留；原 2,138 个控制叠加并发 12 个独立依赖桥控制，没有覆盖或删除旧负控。
- **避免并发重复清理的实际回归**：两边分别删除重复 `scroll.sync` 的不同一处，Git 自动合并曾使出现次数变成 0；该自动结果已保留，最终恢复为当前主线原有的唯一 GPUI 专属声明，没有扩大其它 profile。
- **正式 source 门槛**：原测试列表保留并加入 9 个 capture 文件；另用 `git merge-base HEAD origin/main` 留存完整 SHA，再运行原官方 spec-authoring 脚本。原 inputs、权限、job 期限、250ms preview retirement、sandbox 与真实 receipt 检查均不变。

### 已执行结果与当前边界

| 绑定来源 | 已实际结果 | 尚不能外推的部分 |
| --- | --- | --- |
| 合并时的 exact checker/test 字节，随后至当前 head 不变 | **2,150/2,150** bundle controls，0 failed / skipped；原 db747 production graph SHA-256 `08aa327638f6f19eb6cef4721ede8b4508ce928ff79e334fd262946a59b89881` 未改，重放 **0 issues** | 当前 head 的真实新 production build 仍在正式 run 中执行 |
| `8768ffa`，相关 spec/engine/script 字节保留 | 官方 spec-authoring **exit 0**；完整 loader **1,319 entities、0 issues**；scheduling/cycle/ledger **31 + 28 + 21 全绿** | 未把旧 head 执行改写为新 head 重新执行；正式 source job 会再次验 authoring |
| `2d339a2` 的精确 3 源并入 `e470d1b` | 原 **98/98** + 新 presence **15/15**，原失败与 absence 反例保留 | 隔离旧 base 的 workspace types 曾在 240s 无输出超时，**不计绿**；最终完整 workspace/docs types 由本次正式 source job 承接 |
| 最终产品源码 `e470d1b`；之后当前公开 head 仅追加 CI 配置 | 本地 SDK **62/62，0 failed / ignored** 已读回 | 新组合 18-file source、六 consumer、numeric / official consumer 和 Adapter 的其余结果仍在执行，逐项读回后追加 |
| 当前 workflow 候选字节 `ff661d05…`，正常提交前后相同 | scheduling **31/31**、cycle **28/28**，schedule / Prettier / diff **exit 0** | 这些轻控不替代正式 browser、native 或 types |

旧公开 `0b7` 的托管 native 原 log 已实际下载并核验：`ordinary.rs:575/597` 两个 E0433 都来自缺失 `external_scroll` crate；测试 crate 尚未编译，**0 ordinary tests 执行**。其 browser 为 **skipped**，不提供 250ms 成败证据。原 db747 的 99 Rust errors、Adapter 13/14，以及 d995 的真实 250ms 失败和 observed 17/19 诊断全部保留；不会把它们自动外推至当前组合，也不会凭 source 测试宣布浏览器问题已解决。

本次正常提交前补齐了当前 worktree 缺少的官方 Husky wrapper，实际 Git trace 与 lint-staged/Prettier 日志确认后续 merge/CI commit 执行了 pre-commit，prepared tree 等于 committed tree。更早的隔离提交仅保留“普通 signed-off 与显式格式检查”的真实结论，不反向声称不存在的 hook 曾运行。

当前正式 browser 已通过原 production receipt controls 和字体准备，进入真实 Chromium SSR owner-retirement 步骤；完整 production journey / 250ms acknowledgement 尚待终态。独立源码审阅不是 GitHub `APPROVED`。本 PR 不执行 merge/release，Ready 仍以相关真实验收及剩余已知失败的解决情况评估。

已提交的原生与 capture 原始证据分别随 `52c87232f593d85a28cbd04ad205f0d5fe6f03a3`、`2d339a2da68568627a80265147b5133ae36331d7` 完整保留；本轮合并控制、正常 hook 和发布回执正在追加归档。

<details>
<summary>此前公开候选与全部历史说明（原文保留）</summary>

<!-- agent-s5-current:db747e1b81cb -->

## 当前公开候选：组合控制通过，正式验收发现后续集成阻塞

公开 head：`db747e1b81cbbfaf2b37dd8af3de48108f036a04`。发布前重新读取并保留了远端原 head `d9958d1` 与当前主线 `457d27f7fe554f398970a836ee9c95edb4846f47`；所有更新均为正常合并、签署提交与非 force push。

正式 [Compiler GPUI source consumers · 45228171867](https://github.com/Proto-UI/Proto-UI/actions/runs/45228171867) 已**单次**触发，并读回 exact head `db747e1`。本次显式手动设置 `browser_acceptance=true`、`adapter_acceptance=true`，保留原 native、Flutter、source、production 和 browser 路线。目前继续保持 **Draft**。

### 正式托管结果读回（2026-11-23 17:51 UTC）

| 路线 | 当前实际结果 |
| --- | --- |
| Source regressions | **success**；source、relocation 与 configuration 控制通过，完整 workspace/docs 类型检查最终 **1,330 files，0 errors，0 warnings** |
| Flutter Scroll | **success**，实际 Widget consumer 与证据完整性检查通过 |
| Production build | 网站 **684 pages 已完成**；旧 `style-tint-source.ts` 四项错误消失。Gate 现在对新 `web-component/src/shadow-percentage-source.ts` 报 **49 项精确归属错误**；完整原图已保留，正在复核 public WC source owner 与既有 bridge placement |
| Ubuntu / macOS native | 源码生成与锁定依赖图均已通过；实际 default published SDK 编译 **failure，99 Rust errors**，首错为重复生成的 `ControlLabelGroup` 等定义；保留原失败继续定位 |
| Browser acceptance | 原 receipt/cleanup controls **35/35**；安装 61.2 MB 中文字体时达到原 **3 分钟 timeout**。页面 production journey **skipped，未执行**，因此这次没有新的 250ms cleanup 成败证据 |
| Adapter macOS | 官方 fixture freshness 已通过；随后实际 `a11y_projection` **13 pass / 1 fail**，Checkbox 新的 `readOnly: false` 状态未映射为 AccessKit 属性。原 checked/mixed 断言与官方 JSON 保留，后续修复需验证真实节点读回 |

自动 [CI · 45228177965](https://github.com/Proto-UI/Proto-UI/actions/runs/45228177965) 的 lockstep、package plan、test plan 与 CI config audit 四个实际 job 均 **success**，其余路线 skipped。该 exact head 的 **DCO success**；Vercel deployment 仍 pending。轻 CI 与 DCO 不替代上表正式验收。

### 本次实质修复与上游整合

- **材料生产图**：只把新的 `material/style-tint-source.ts` 加入两个 exact diagnostic producer 的有限模块表；补充 18 个同模块归属、static/dynamic 旁路、普通 shell 与缺失 program ownership 控制。原真实 production graph SHA-256 `822cb367cf0eb8addece00c3e97154626530b7a8d3624ca962cdb744ad88c975` 不变，原 checker **4 issue**，候选 **0 issue**。
- **GPUI 公开入口与真实生成器**：保留已经实现的 GPUI-only `scroll.sync` 准入，新增公开编译正反控制并加入正式 source 列表。主线 PR #1742 已独立合入同一行准入，本分支通过正常 merge 保留一次。原 lifecycle 断言不变；生成器只删除第二次重复的 Scroll reader 注册，保留首个 consumer 和全部原 native targets。
- **Adapter fixture**：官方原 freshness check 仅报 Checkbox stale；正式 generator 更新这一份 JSON，之后同一 check 通过，其余四份 fixture 字节不变。没有手写生成产物。
- **CI 调度**：正常承接 #1739 的后续修正，保留当前 main 的 manual-only browser 决策；仅 Adapter 可复用，browser 是 optional boolean/default false 的手动入口。旧双输入假设与其失败证据保留，未扩大自动 CI。

### 已实际执行的组合控制

| 执行 source | 范围 | 结果 |
| --- | --- | --- |
| `c0e5bc91c47589d64080af974d0c98edd308099c` | 正式 24-file source 列表，单 worker | **401/401，0 failed，0 pending** |
| 同 source | 完整 production bundle controls | **2,082/2,082，0 failed，0 skipped** |
| 同 source | 已提交版本的官方 GPUI session fixture check | **exit 0** |
| `ff5b83bddd07a4f76282d327ee7d22093076cf81` | scheduling / cycle / ledger controls | **31/31 + 28/28 + 21/21，均 0 skipped** |
| 同 source | CI schedule 与整合差异检查 | **exit 0** |

CI-only cherry-pick 后，source、测试、workflow、target、producer、gate 和 Checkbox 的保留输入哈希全部重新核对一致；随后公开 head 只追加完整证据。没有把旧 head 上执行的测试改写成新 head 上重新运行。

真实 producer 已生成 **37 个独立模块**，**38 份 Cargo manifests** 通过解析。原 receipt 的 135 次文件记录检查与去重后的 132 次检查，覆盖相同 **132 个独立 emitted artifact paths**，字节完全相同；没有删除三份独立生成文件。这仍属于生成验证，实际 Cargo/native 结果由本次托管路线单独读回。

### 浏览器与 Ready 边界

旧 d995 的真实 hosted browser 仍有 250ms cleanup acknowledgement 与后续 journey 失败；原完整 receipt/log 在本 PR 中保留。此前本地无 observer d995 仅在 Astro startup 处失败，没有到达浏览器 journey。输入 guard 的单元控制和当前 source 全绿都不能替代完整浏览器验收；新 head 的 browser 在字体下载前置步骤失败，实际 journey 没有执行；不宣告原清理问题已解决。

[本轮完整组合证据](https://github.com/Proto-UI/Proto-UI/blob/db747e1b81cbbfaf2b37dd8af3de48108f036a04/internal/records/2026-11-23-sprint5-combined-validation.md) · [材料精确归属](https://github.com/Proto-UI/Proto-UI/blob/db747e1b81cbbfaf2b37dd8af3de48108f036a04/internal/records/2026-11-23-sprint5-tint-source-boundary.md) · [GPUI 公开入口与生成器](https://github.com/Proto-UI/Proto-UI/blob/db747e1b81cbbfaf2b37dd8af3de48108f036a04/internal/records/2026-11-23-gpui-scroll-profile-integration.md) · [官方 Checkbox refresh](https://github.com/Proto-UI/Proto-UI/blob/db747e1b81cbbfaf2b37dd8af3de48108f036a04/internal/records/2026-11-23-gpui-checkbox-session-refresh.md)

独立源码审阅已完成并记录；它不是 GitHub `APPROVED`。本 PR 不执行 merge 或 release，DCO、正式 CI、required review 与其余平台验收分别读回。

<details>
<summary>前一公开候选与初始说明（完整保留）</summary>

<!-- agent-s5-current:d9958d163436 -->

## 当前候选：保留真实失败，继续修复

公开 head：`d9958d163436ea08d4a19b325d9e7f5dad3dc951`，tree `ea426866a21cd2cca2c5d166b4b0c2abfdd2f05c`。已正常合并主线 `824f7b12d828a179670e1d751f5f2c14d97d995d`，原作者与签署提交完整保留。

- 本 head 的 frozen install、完整 bundle gate、5 个 input/lifecycle 文件、production receipt controls、格式与差异检查均已实际 exit 0；对应控制为 **2,064 / 32 / 34 项**。此前两个集成夹具失败、第一版精确字符串失败，以及旧 main 临时仓库遗漏依赖导致的 27 个 import 失败全部留存。
- 本地无 observer 的 canonical development browser 已返回 **exit 1**，Chromium 145 的 setup 因 Astro 启动超时失败（2 个结果：1 pass / 1 fail）。HEAD、tree 与关键源码前后完全相同；这次没有抵达实际浏览器 journey，不能作为清理成功或清理失败的证据。
- 正式 [Compiler GPUI source consumers · 45216953529](https://github.com/Proto-UI/Proto-UI/actions/runs/45216953529) 已单次触发并读回 exact head `d9958d1`，`browser_acceptance=true`、`adapter_acceptance=true`。**production browser 仍失败**：edit-reject-recover 的真实 iframe cleanup acknowledgement 超过原 250ms 期限，cancel/reopen 与后续 Worker 完整性控制也失败。输入同值 guard 的控制测试通过不等于完整浏览器问题已解决。
- 同一托管 run 的 production build 已完成，但 gate 对新增 `packages/adapters/base/src/material/style-tint-source.ts` 报 **4 个归属问题**（两个 exact diagnostic owner 各两项）。原 production graph 已原样下载并核验 SHA-256 `822cb367cf0eb8addece00c3e97154626530b7a8d3624ca962cdb744ad88c975`；后续修复会保留 exact producer、旁路及 ordinary-shell 拒绝。
- source-regressions 实际 **385/386，1 failed**，Ubuntu native producer 同因 `PUI4003: scroll.sync` 失败：GPUI target profile 漏接已存在的 callback lowering。独立候选正在做公开 compile 正控、未知/非法操作及其他 profile 拒绝的红绿验证；原 lifecycle 断言保留。Flutter native lane 已成功，其余路线按实际终态单独记录。
- 本 head 的轻 CI [ci-config-audit](https://github.com/Proto-UI/Proto-UI/actions/runs/45216958587/job/137840587774) 实际 **24/31，7 failed**。共享 scheduling fixture 的显式 opt-in 边界及重复 Scroll workflow 步骤正在独立 PR #1739 修复；本 PR 尚未包含该后续修复，不宣称 CI 全绿。

[完整集成红绿控制与原始档案](https://github.com/Proto-UI/Proto-UI/blob/df1e94cbf61728ce583e6c87dc2de21c232d2307/internal/records/2026-11-23-sprint5-integrated-regression-controls.md)。当前继续保持 Draft，等待已知实际失败修复与终验；Ready、GitHub approval、merge 和 release 分别记录。

<details>
<summary>初始后续 PR 说明与原条件（完整保留）</summary>

<!-- agent-sprint5-regression-followup:75d5e28a -->

## 问题与承接

原 [Sprint 5 PR #1715](https://github.com/Proto-UI/Proto-UI/pull/1715) 已由并行会话于 2026-11-23 16:08 UTC 合入，合并提交为 `fb0456c39a7423eb363433fd20eaaefa6367c4af`。本 PR 保留其全部历史，继续交付两个在合入前已真实复现、完成独立源码审阅的修复；不改写原失败，也不把旧 PR 的合并当作新修复的验收。

当前候选：`cf3fede0a13e0479a118665cf176bd3e7efff386`，tree `dec199ef7b4d4213b009c214e0a75787c1267c20`。已正常合并当前主线 `7c66b9b39c9064346887957bc7292c3dc997f82a`；原作者、签署提交与并发内容完整保留。

## 修复内容

- **重复 source input 的实际产品修复**：只有选中文件的内容确实变化才创建新 source revision。相同内容的重复 input 不再反复退休预览、重置 debounce 或清除诊断；真实修改、撤销以及显式 Run 重试继续生效。原 sandbox、身份校验、真实 disposed 回执和 250ms 退役期限保持不变。
- **两条材料诊断路由的生产图修复**：逐 emitted chunk 核验既有 site-control bridge，要求唯一且位于 static closure，并验证 exact site-control API 的真实 module 进口链。原始 diagnostic source closure 仍拒绝直接/间接 Web Component、React、Vue 或未审阅 Base 旁路；六个材料模块仍须属于该 exact producer。动态专用 bridge、跨 chunk 拷贝、身份仿冒、断边和全局 server-only 入口继续拒绝。
- **可回放证据与正式 CI**：保留原真实生产图与失败、红绿 DOM 控制、原完整 canonical 失败和独立 observer trace；把新 source-input 控制加入正式显式测试列表。主线新 production browser、真实 Worker/chunk 哈希及服务 owner 验收完整保留。

## 已执行证据与当前状态

| 证据 | 精确范围与结果 |
| --- | --- |
| 输入回归旧源码负控 | 有效真实 DOM fixture 上 1/4 通过、3/4 失败；另一次早期 Option 环境 fixture 失败单独保留，不冒充产品负控 |
| 输入修复及生命周期控制 | `fc18f35549e9bf95b68467953728f6af65cb2d9b` 所记录源码：4/4 输入控制、组合 32/32，0 skipped |
| 生产图控制 | `3ec5a6d9680901444d59cd468ef044366b84af9a` 所记录源码：1,945/1,945，0 skipped |
| 原真实生产图重放 | 原图 SHA-256 `be5da61fbdfefb64c4aff7e76cc865e28201ef74d01d86b8db567852e8f9cad1` 完全不变；d985 checker 2 issue，第一版 03c5 checker 292 issue，修正 checker 0 issue |
| 本候选合并后验证 | 正在执行新的 frozen install、完整 gate、32 项输入/生命周期控制、production receipt 控制、格式及差异检查 |
| 本候选实际浏览器 | 无 observer 的 canonical development journey 已排在同一可观察本地作业中，保留 Chromium OS sandbox 和原期限；结果尚未返回 |
| 本候选正式 hosted | 将对发布后的 exact head 单次触发原注册工作流，包含正式 production browser、source、native 与 Adapter 路线；未执行/未结束不得算通过 |

源码与证据记录：

- [输入事件与 preview retirement](https://github.com/Proto-UI/Proto-UI/blob/fc18f35549e9bf95b68467953728f6af65cb2d9b/internal/records/2026-11-23-browser-source-input-retirement.md)
- [真实材料诊断生产图重放](https://github.com/Proto-UI/Proto-UI/blob/3ec5a6d9680901444d59cd468ef044366b84af9a/internal/records/2026-11-23-sprint5-material-diagnostic-replay.md)

## 审阅与保留边界

输入 guard/test 与 gate/test 已由团队其他 agent 独立阅读实际源码和原始证据，没有源码阻断发现；这不是 GitHub `APPROVED`。当前保持 Draft，待真实完整浏览器结果回读后再评估 Ready。DCO、正式 CI、required review 与原十条 Issue、完整站点/应用、物理输入及辅助技术验收仍各自成立；本 PR 不宣称发布、全 Sprint 或 0.3 完成，不执行合并。

Agent: ChatGPT / Codex，按当前用户继续推进到 Ready 的授权实施和记录。

</details>


</details>


</details>
