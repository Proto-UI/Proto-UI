# Browser input and preview retirement: independent source review

Date: 2026-11-23 UTC. Reviewer: sprint3_ready. This is a read-only source and retained-receipt review. No browser, Cargo, source test suite, or product mutation was performed in this review. It is not a fresh canonical acceptance receipt or GitHub approval.

## Conclusion

The 331 input callbacks are supported as real Chromium input events for this retained experiment; neither a duplicate v3 listener nor an untrusted CustomEvent echo explains them. The source revision guard works. The original evidence does demonstrate that the old preview acknowledgement arrived after a long synchronous input interval and after the parent had removed its iframe. It does not locate the expensive JavaScript or rendering work, and does not establish that the final production combination fails.

V3 observation was read-only but not cost-free. Its per-event DOM reads, path construction and queued snapshots can perturb timing. The separate lightweight probe still reproduced 688.7 ms between first and last input on the actual page, without the v3-specific whole-document MutationObserver, queued panel snapshots, path labeling, full-source binding transport, or per-batch filesystem writes. This rules out those v3-only features as necessary to the slow interval. It does not isolate all observer cost, product listener cost, page layout, or resource scheduling.

## Frozen sources and custody

Reviewed immutable commit: 8768ffaaccfcf49158287c632a06318b675ac842. The four files below were obtained with git show from that object, not read from an active checkout. All four SHA-256 values exactly match the before/after source table retained by the d995 diagnostic.

| File | SHA-256 |
| --- | --- |
| apps/www/src/components/PrototypePreviewer/browser-compiler-panel.ts | 13b9bbdffefe45434ce733f652d0600023651cc474d352daf26b9427710706c9 |
| apps/www/src/components/PrototypePreviewer/compiled-revision-session.ts | 89d572e8fd2ae2d700194075718e07cc6ab8de3231c83144f1b48611ea4365bc |
| apps/www/src/components/PrototypePreviewer/compiled-preview-sandbox.ts | f159da1722e8c7b7e9e3ebf4772c077c841e60275cde2a8e1f482e5379df153e |
| scripts/analysis/browser-compiler-browser.mts | 81c264aada7399a13373aa763da419a52b562a5cf9917582ecdb2b582a716c50 |

The old diagnostic source was d9958d163436ea08d4a19b325d9e7f5dad3dc951, tree ea426866a21cd2cca2c5d166b4b0c2abfdd2f05c. Its status records clean before/after, all 11 input hashes stable, owned child retired and private temporary directory removed. Old mode was development, Chrome 145.0.7632.6 / Playwright 1.58.2. Source equality for these four files does not equate the rest of the website, mode, artifacts, scheduling, or final combined head.

Original trace was independently reread and hashed: 719253 bytes, e10e00477c9df8dd37dadc34877681238f52dc5dcf07676020d25d1b8ef0d6d9. Single-fill comparison was independently reread and hashed: 416009 bytes, 7c0ddab4dd4cd9ce503766a546c3b8e738822dd2f24a3f15d5e179514badcc58. The v3 CJS observer was obtained as exact bytes and matches the recorded 7520-byte digest 7eaab639169bfdeb832f2e99c0c4ada79aefb3c482c5d70ac13114e9dcbcba8a.

Root ops originals: /tank/shared/projects/proto-ui-agent/root-browser-retirement-75d5e28a-ops. S5 archived repository entry: internal/records/2026-11-23-sprint5-browser-retirement-diagnostic.md, with evidence/2026-11-23-sprint5-browser-retirement-diagnostic/manifest.json and raw children. No original receipt was overwritten.

## Counting audit

The runner requires observer-v3.cjs once. The wrapper calls page.addInitScript once for each newly created page. The canonical script creates one page and subsequently navigates it. The injected code registers a single window capture listener for each distinct event type; only the outer document registers input observation. It does not register a second input listener on the textarea, panel, or bubble phase, and does not dispatch input or edit values.

The raw trace has one launch, 145 rows with 145 distinct sequence numbers, and one document-init for each document. The document containing both fills has one outer init. For the first fill, all 331 records have eventConstructor InputEvent, isTrusted true, raw target textarea, current target window, inputType insertText, and the same observed textarea path. The first input has revision 11 and byteEqual false; the other 330 have revision 12 and byteEqual true. No untrusted-input stack was collected for these events.

Stronger corroboration comes from the independent lightweight probe. Each of its three pages installs exactly one capture/passive input listener directly on its textarea and performs one locator.fill. In all three retained event arrays, the entire event.data sequence exactly matches the input's 152 nonempty text segments alternating with its 179 newline entries represented as null. The total is 331. This was checked against the complete stored input, not just a prefix or length. The 6724-byte bad input has SHA-256 31cdc45eb20475366ca7ea0162d9e72b3425273629db5e10fc5d608549ad2035.

Therefore the event multiplicity already exists on a bare textarea without product listeners. A generic repeated observation of one event cannot account for the distinct, ordered line/null payload sequence in the bare and actual lightweight probes. V3 itself did not record an Event-object identity or event.timeStamp, so it is not an independent formal identity-deduplication trace; the single-registration source and separate payload sequence provide the corroboration.

## One fill and the installed input path

The canonical edit at browser-compiler-browser.mts 418 calls locator.fill once for the initial invalid source; recovery is a later, separate fill. The diagnostic helper increments fillCalls once and makes one fill call for each case. The installed Playwright 1.58.2 implementation was read directly: textarea injected.fill selects the text and returns needsinput; server dom._fill then calls keyboard.insertText; input.insertText delegates to raw.sendText; Chromium raw.sendText sends Input.insertText once. This is the successful source path, not a separate recorded CDP wire count. It is not the per-character type method, and the textarea branch does not synthesize dispatchEvent input.

Installed implementation digests: dom.js 33f502d6319a4e2539a4020c4983045f30d3d1cbed5d7610a32d9f89cbf8823d; input.js 9bab3cbf128c2338d3eee76996ea9cd7044d27cd9b0c6bf7b1786669354e9d1a; chromium/crInput.js 3dcad19b8f52f3f1f9787c5fff350607e242cd0d0c6911223c9d44bed9a75432; generated/injectedScriptSource.js ea0889cc1b0efba61511dd640e658ca965aa8d5ae20eef8e608fd651b85390ca.

## Product input and retirement path

BrowserCompilerPanel.connectedCallback uses its bound flag to install the listener once per element. The input callback reads the selected file and textarea value, returns when files[file] already equals that value, and otherwise stores the value then calls changed(). There are no textarea value, selection, or editor-replacement writes in changed or renderState. The two value writes are source installation and the selected-file change handler.

changed increments the source revision, synchronously calls session.invalidate, then resets the compile debounce. invalidate retires the old owner before reporting idle. retire clears this.owner before calling owner.dispose and chains its actual promise into retirement. mountCompiledPreview.dispose is idempotent through retirePromise, hides the old iframe, starts the unchanged 250 ms timer and sends dispose once when the child listener handshake is known. The remaining 330 same-value callbacks still do the initial scoped queries/value comparison, but return before changed: they neither invalidate again nor reset the debounce.

Child cleanup and its disposed acknowledgement are asynchronous message work. The source therefore permits a synchronous page input task to occupy the event loop while the fixed retirement deadline has already started. That is a scheduling exposure, not proof of which callback or native operation consumed the time.

| Retained v3 observation, relative to first textarea input | Time |
| --- | ---: |
| First input observed in window capture listener | 0 ms |
| Idle r12; old revision-11 iframe observed hidden and connected | +5.1 ms |
| Last of 331 input callbacks | +662.2 ms |
| Child observer receives dispose for revision 11 | +703.7 ms |
| Parent snapshot first shows old iframe absent | +754.0 ms |
| Parent observer receives disposed; source frame no longer found | +761.3 ms |

The outer long task starts 246.8 ms before the first input and lasts 911 ms, enclosing the full input interval. A timeout-callback start and postMessage-send timestamp were not instrumented. The +703.7 ms measurement is child receipt, not 703.7 ms spent executing cleanup. The following 57.6 ms also includes message scheduling and observer work; it is not an isolated cleanup duration.

The first invalid compile still produces the expected PUI1004. CompiledRevisionSession returns compiler diagnostics before awaiting retirement, while retaining a failed retirement promise. A later valid recovery reaches await this.retirement and exposes the earlier cleanup rejection. The canonical receipt consequently reports the edit/recovery case failed on the retained 250 ms acknowledgement error, then cancel/reopen times out. This is consistent with the source and avoids incorrectly attributing the first PUI1004 rejection itself to cleanup.

## Observation overhead and limits

V3 does synchronous closest/querySelector calls, reads textarea contents, compares source strings, walks and labels the composed path, allocates an action record, reads scrollY, and queues snapshot for every observed input. snapshot performs further selectors, text/frame reads and JSON serialization even when the eventual state is unchanged. A whole-document MutationObserver and scroll listener can also invoke it. The observer creates no trusted events, but those operations can consume time. Read-only does not mean zero timing impact, and these reads do not establish that a layout flush occurred.

Trace transport is batched after 200 ms rather than a filesystem write for each input. Child message observations flush immediately. The untrusted stack code is capped at six and is inactive for the 331 trusted events. These limits reduce some costs but do not measure or subtract total observer overhead.

| Lightweight probe | Input count | First-to-last input interval | Whole fill call |
| --- | ---: | ---: | ---: |
| Bare textarea | 331 | 4.8 ms | 333.6 ms |
| Bare textarea with selected matching computed styles | 331 | 2.9 ms | 243.8 ms |
| Actual d995 page and compiler panel | 331 | 688.7 ms | 991.6 ms |

The matching-style control copies selected textarea properties, not the surrounding website, ancestors, all CSS, listener graph, or current resource load. It cannot identify a particular style/layout or JavaScript cause. The lightweight observer still reads the value and panel dataset; there was no same-page no-observer timing A/B. The actual probe only validates input behavior and PUI1004 rejection. Its empty message list is not evidence of successful retirement.

The subsequent CPU/layout profile attempt reached neither fill nor a valid profile because its 45-second panel precondition timed out. No CPU hotspot evidence exists in that artifact. The historical 17/19 receipt and this failed setup remain failures and are not acceptance of the new combined head.

## Minimum next step

Let S5 complete the unchanged canonical browser gate against the final production head. These old development measurements do not justify a speculative product change. If that actual head reproduces the same cleanup error, one separately labeled, bounded current-head diagnostic can capture CPU/native rendering attribution for the same single fill after a verified ready precondition. Prefer the lightweight counter over v3's repeated DOM snapshots, and include a bounded Event identity/timeStamp counter plus CDP method count if exact counting remains relevant. Preserve the original input, sandbox, immediate invalidation, acknowledgement requirement and 250 ms limit. A diagnostic profile would still be separate from acceptance.

No new product defect is localized by this source review beyond the already retained long-input/late-ack failure. No timeout increase, delayed invalidation, synthetic input shortcut, or new acceptance claim is proposed.
