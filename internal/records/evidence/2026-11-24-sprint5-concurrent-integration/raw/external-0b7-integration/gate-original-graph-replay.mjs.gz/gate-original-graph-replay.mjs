import fs from 'node:fs';
import crypto from 'node:crypto';
import { collectWebsiteProductionBundleIssues } from '/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a/scripts/coverage-matrices/check-website-production-bundle.mjs';
const path="/tank/shared/projects/proto-ui-agent/sprint5-db747-hosted-75d5e28a/production/proto-ui-bundle-graph.json";
const data=fs.readFileSync(path);
const issues=collectWebsiteProductionBundleIssues({graph:JSON.parse(data.toString())});
console.log(JSON.stringify({graphPath:path,graphSha256:crypto.createHash('sha256').update(data).digest('hex'),issues},null,2));
if(issues.length)process.exitCode=1;
