import sys,subprocess,time,json,hashlib,pathlib,os,signal
out=pathlib.Path(sys.argv[1]); out.mkdir(parents=True,exist_ok=True)
cmd=sys.argv[2:]
def source():
 def git(*args): return subprocess.check_output(['git',*args])
 return {'head':git('rev-parse','HEAD').decode().strip(),'patchSha256':hashlib.sha256(git('diff','--binary','HEAD')).hexdigest(),'status':git('status','--porcelain').decode(),'files':{p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in git('diff','--name-only','HEAD').decode().splitlines() if pathlib.Path(p).is_file()}}
record={'command':cmd,'cwd':os.getcwd(),'startedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'sourceBefore':source()}
(out/'status.json').write_text(json.dumps(record,indent=2)+'\n')
t=time.monotonic()
with (out/'stdout.log').open('wb') as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try: code=p.wait()
 except KeyboardInterrupt:
  os.killpg(p.pid,signal.SIGINT); code=p.wait()
record.update({'exitCode':code,'durationSeconds':time.monotonic()-t,'finishedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'sourceAfter':source()})
record['sourceStable']=record['sourceBefore']==record['sourceAfter']
(out/'status.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'directory':str(out),'exitCode':code,'sourceStable':record['sourceStable'],'durationSeconds':record['durationSeconds']}))
sys.exit(code)
