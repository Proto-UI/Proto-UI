import os,json,hashlib,subprocess,shutil,time
from pathlib import Path
repo=Path('/home/ezra/proto-ui-browser-current-cb5d')
control=Path(str(repo)+'-control')
packet=json.loads(Path('/tank/shared/projects/proto-ui/node_modules/.cache/proto-ui-ci-transfer-cb5d/browser/liquid-clean-cli-packet.json').read_text())
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def sha(b):return hashlib.sha256(b).hexdigest()
env=dict(os.environ);env['PATH']='/home/ezra/proto-ui-release-gate-cb5d-control/tools/node_modules/node/bin:/home/ezra/proto-ui-release-gate-cb5d-control/tools/node_modules/.bin:'+env['PATH']
report={'head':git('rev-parse','HEAD').decode().strip(),'scope':'Official draft generator with clean committed CLI source, baseline and exactly eight Liquid source overlays; not formal browser acceptance','phases':[]}
report['beforeStatus']=git('status','--porcelain').decode()
assert report['head']==packet['base']
assert report['beforeStatus']=='',report['beforeStatus']
cli_paths=git('ls-files','packages/cli/src','scripts/styles').decode().splitlines()
report['cleanCliInputs']=[]
for p in cli_paths:
 b=(repo/p).read_bytes();base=git('show','HEAD:'+p);assert b==base,p
 report['cleanCliInputs'].append({'path':p,'sha256':sha(b)})
out='packages/cli/src/generated/draft-family-style-tokens.ts'
original=(repo/out).read_bytes();(control/'liquid-draft-original-124e.ts').write_bytes(original)
sources=git('ls-files','packages/prototypes/bootstrap-2-3-2/src','packages/prototypes/liquid-glass/src').decode().splitlines()
def phase(label):
 p={'label':label,'sources':[{'path':p,'sha256':sha((repo/p).read_bytes())} for p in sources],'commands':[]};report['phases'].append(p)
 for flag in [[],['--check']]:
  name=label+('-check' if flag else '-generate')
  cmd=['node','--import','tsx','scripts/styles/generate-draft-family-style-tokens.ts',*flag]
  begin=time.monotonic()
  with (control/(name+'.log')).open('wb') as log:r=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  p['commands'].append({'command':cmd,'exitCode':r.returncode,'elapsedMs':round((time.monotonic()-begin)*1000),'log':name+'.log'})
  assert r.returncode==0,name
 generated=(repo/out).read_bytes()
 (control/(label+'.ts')).write_bytes(generated)
 p['generated']={'path':label+'.ts','sha256':sha(generated),'bytes':len(generated)}
 (control/(label+'.diff')).write_bytes(git('diff','--',out))
 p['diffPath']=label+'.diff'
 (control/'liquid-clean-cli-closure.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 phase('liquid-clean-cli-baseline')
 (repo/out).write_bytes(original)
 for f in packet['files']:
  b=f['content'].encode();assert sha(b)==f['sha256'],f['path']
  (repo/f['path']).write_bytes(b)
 report['overlays']=[{'path':f['path'],'sha256':f['sha256']} for f in packet['files']]
 phase('liquid-clean-cli-candidate')
 for p in cli_paths:
  if p==out:continue
  assert (repo/p).read_bytes()==git('show','HEAD:'+p),p
 report['afterStatus']=git('status','--porcelain').decode()
 report['success']=True
 (control/'liquid-clean-cli-closure.exit').write_text('0\n')
except Exception as e:
 report['success']=False;report['error']=repr(e)
 (control/'liquid-clean-cli-closure.exit').write_text('1\n')
 raise
finally:
 (control/'liquid-clean-cli-closure.json').write_text(json.dumps(report,indent=2)+'\n')
