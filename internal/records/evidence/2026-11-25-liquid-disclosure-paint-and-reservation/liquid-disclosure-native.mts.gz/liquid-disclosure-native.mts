import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { observeLiquidToggleSnapshot } from '/home/ezra/proto-ui-browser-gate-cb5d/apps/www/src/content/docs/zh-cn/liquid-toggle-snapshot.ts';
import { isUnpaintedBootstrapBoxShadow } from '/home/ezra/proto-ui-browser-gate-cb5d/apps/www/src/content/docs/zh-cn/bootstrap-disabled-paint.ts';

const root = '/home/ezra/proto-ui-browser-gate-cb5d';
const control = '/home/ezra/proto-ui-browser-gate-cb5d-control';
const label = process.argv[2] || 'liquid-disclosure-candidate';
const { chromium } = createRequire(path.join(root, 'apps/www/package.json'))('playwright-core');
const hash = (value) => crypto.createHash('sha256').update(value).digest('hex');
const sources = [
  'packages/prototypes/liquid-glass/src/button/button.proto.ts',
  'packages/prototypes/liquid-glass/src/form/submit.proto.ts',
  'packages/prototypes/liquid-glass/src/form/reset.proto.ts',
  'packages/prototypes/liquid-glass/src/select/trigger-visual.ts',
  'packages/prototypes/liquid-glass/src/collapsible/trigger.proto.ts',
  'packages/prototypes/liquid-glass/src/accordion/trigger.proto.ts',
  'packages/prototypes/liquid-glass/src/accordion/heading.proto.ts',
  'packages/adapters/base/src/material/paint-reservation.ts',
  'apps/www/src/pages/en/test/liquid-glass-hover.astro',
  'apps/www/src/content/docs/zh-cn/liquid-hover-fixture.ts',
  'apps/www/src/content/docs/zh-cn/demo-liquid-glass-hover.browser.test.ts',
];
const report = {
  scope: 'Focused real-route native diagnostic; not official Actions acceptance. The official beforeAll guard, exact-head and clean-source checks remain unchanged.',
  sourceHead: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(),
  inputs: Object.fromEntries(sources.map((name) => [name, hash(fs.readFileSync(path.join(root, name)))])),
  cases: [],
  pageErrors: [],
};
const clean = (value) => JSON.parse(JSON.stringify(value, (_key, item) =>
  typeof item === 'string' && item.includes('data:image/png;base64,') ? `image-sha256:${hash(item)}` : item
));
const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, chromiumSandbox: true, args: ['--disable-dev-shm-usage'] });
report.browser = browser.version();
const started = Date.now();
try {
  for (const runtime of ['wc', 'react', 'vue', 'vue2']) for (const theme of ['light', 'dark']) {
    const context = await browser.newContext({ viewport: { width: 1440, height: 1100 }, hasTouch: true });
    const page = await context.newPage();
    page.on('pageerror', error => report.pageErrors.push({ runtime, theme, error: String(error) }));
    const cdp = await context.newCDPSession(page);
    await cdp.send('Emulation.setEmulatedMedia', { features: Object.entries({
      'prefers-color-scheme': theme, 'prefers-reduced-motion': 'no-preference', 'prefers-reduced-transparency': 'no-preference', 'prefers-contrast': 'no-preference', 'forced-colors': 'none',
    }).map(([name, value]) => ({ name, value })) });
    await page.goto(`http://127.0.0.1:4347/en/test/liquid-glass-hover/?runtime=${runtime}&theme=${theme}`, { waitUntil: 'networkidle', timeout: 60000 });
    await page.waitForFunction(() => document.documentElement.dataset.liquidHoverReady === 'true', null, { timeout: 60000 });
    await page.evaluate(() => window.liquidHoverFixture.pause(true));
    for (const part of ['collapsible', 'accordion', 'accordion-blocked', 'accordion-tight']) {
      const record = { runtime, theme, part, observations: [], success: false };
      report.cases.push(record);
      const target = page.locator(`[data-hover-host="${runtime}-${part}"] [data-demo-ref="subject"]`);
      const entry = page.locator(`[data-focus-start="${runtime}-${part}"]`);
      const fixture = (operation, ...args) => page.evaluate(({ runtime, part, operation, args }) => window.liquidHoverFixture[operation](runtime, part, ...args), { runtime, part, operation, args });
      const sample = async (stage, quality, contact) => {
        if (quality || contact) await page.waitForFunction(({ runtime, part, quality, contact }) => {
          const el = document.querySelector(`[data-hover-host="${runtime}-${part}"] [data-demo-ref="subject"]`);
          return el && (!quality || el.dataset.materialQuality === quality) && (!contact || el.dataset.materialContact === contact);
        }, { runtime, part, quality, contact }, { timeout: 8000 });
        await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
        const facts = await target.evaluate(observeLiquidToggleSnapshot);
        const raw = await target.evaluate((el, { runtime, part }) => {
          const css = getComputedStyle(el), box = el.getBoundingClientRect();
          const destination = el.closest('[data-material-scene]').querySelector(':scope > [data-material-overlay-mount]').getBoundingClientRect();
          const center = document.elementFromPoint(box.x + box.width / 2, box.y + box.height / 2);
          return {
            documentX: box.x + scrollX, documentY: box.y + scrollY, width: box.width, height: box.height,
            gap: destination.top - box.bottom, transform: css.transform, scale: css.scale, translate: css.translate,
            hit: center === el || el.contains(center), slotText: el.querySelector('[data-liquid-hover-slot]').textContent,
            ring: Object.fromEntries(['--pui-ring-width', '--pui-ring-inset', '--pui-ring-color', '--pui-ring-offset-width'].map(name => [name, css.getPropertyValue(name).trim()])),
            themeRing: css.getPropertyValue('--pui-ring').trim(),
            states: Object.fromEntries(['hovered','pressed','focusVisible','disabled','expanded','collapseBlocked'].map(name => [name, window.liquidHoverFixture.state(runtime, part, name)])),
            requests: window.liquidHoverFixture.requests(runtime, part),
          };
        }, { runtime, part });
        const value = { stage, facts, raw };
        record.observations.push(clean(value));
        return value;
      };
      const opaque = ({ facts }) => {
        assert.equal(facts.quality, 'opaque-fallback'); assert.ok(facts.reason); assert.equal(facts.uri, null);
        assert.equal(facts.carrier.marker, null); assert.equal(facts.background[3], 255); assert.equal(facts.foreground[3], 255);
        assert.equal(facts.opacity, '1'); assert.ok(facts.fallbackContrast >= 4.5);
      };
      const optical = ({ facts, raw }) => {
        assert.ok(raw.gap > facts.paint.paintOutset); assert.equal(facts.quality, 'self-optical'); assert.equal(facts.source, 'visible-app-canvas');
        assert.equal(facts.backdropFilter, 'none'); assert.equal(facts.childCanvases, 0); assert.equal(facts.carrier.marker, 'contact-v1');
        assert.equal(facts.carrier.pointerEvents, 'none'); assert.equal(facts.paint.committed, true); assert.equal(facts.paint.geometryMatches, true);
        assert.equal(facts.snapshot.verifiedAfterDecode, true); assert.match(facts.receipt.frame, /^\d+$/); assert.match(facts.receipt.sourceRevision, /^\d+$/);
        assert.ok(facts.pixels.content.contentPixels > 0); assert.ok(facts.pixels.content.validPixels > 0);
        assert.equal(facts.pixels.content.opaquePixels, facts.pixels.content.contentPixels); assert.equal(facts.pixels.content.partialAlphaPixels, 0);
        assert.equal(facts.pixels.content.transparentPixels, 0); assert.ok(facts.pixels.content.minForegroundContrast >= 4.5);
      };
      const same = (before, after) => {
        for (const key of ['documentX','documentY','width','height','slotText']) assert.equal(after.raw[key], before.raw[key], key);
        assert.equal(after.facts.radius, before.facts.radius); assert.equal(after.raw.transform,'none'); assert.ok(['none','1'].includes(after.raw.scale));
        assert.ok(['none','0px'].includes(after.raw.translate)); assert.equal(after.raw.hit,true);
      };
      try {
        await page.mouse.move(0,0); await target.scrollIntoViewIfNeeded();
        if (part === 'collapsible' || part === 'accordion') {
          const idle = await sample('idle','self-optical','rest'); optical(idle);
          await target.hover(); const hover = await sample('hover'); optical(hover); same(idle,hover); assert.equal(hover.raw.ring['--pui-ring-width'],'1px');
          await page.mouse.down(); const down = await sample('down',undefined,'held'); optical(down); same(idle,down); assert.equal(down.raw.states.pressed,true);
          await page.mouse.up(); const up = await sample('release',undefined,'rest'); optical(up); same(idle,up); assert.equal(up.raw.requests.length,1);
          await page.mouse.move(0,0); await entry.focus(); await page.keyboard.press('Tab');
          const focus = await sample('focus'); assert.equal(focus.raw.states.focusVisible,true); assert.equal(focus.raw.ring['--pui-ring-width'],'2px');
          await entry.focus(); await target.hover(); await page.mouse.down(); await sample('disable-held',undefined,'held');
          record.fallbackFrames = await target.evaluate(async (el, { runtime, part }) => {
            const frames = [], begin = performance.now(), canvas = new OffscreenCanvas(1,1), context = canvas.getContext('2d');
            let fallbackFrames = 0;
            const read = () => { const css = getComputedStyle(el); context.clearRect(0,0,1,1);context.fillStyle=css.backgroundColor;context.fillRect(0,0,1,1);return {elapsed:performance.now()-begin,quality:el.dataset.materialQuality,background:Array.from(context.getImageData(0,0,1,1).data),opacity:css.opacity}; };
            frames.push(read()); window.liquidHoverFixture.setProps(runtime,part,part==='accordion'?'item':'subject',{disabled:true});
            do { await new Promise(requestAnimationFrame); const value=read();frames.push(value);if(value.quality==='opaque-fallback')fallbackFrames++; } while(fallbackFrames<2 && performance.now()-begin<8000);
            return frames;
          }, {runtime,part});
          assert.ok(record.fallbackFrames.some(frame=>frame.quality==='opaque-fallback'));
          for(const frame of record.fallbackFrames.filter(frame=>frame.quality==='opaque-fallback')) { assert.equal(frame.background[3],255);assert.equal(frame.opacity,'1'); }
          const disabled = await sample('disabled','opaque-fallback'); opaque(disabled); assert.equal(disabled.raw.states.disabled,true);assert.equal(disabled.raw.states.pressed,false);assert.equal(isUnpaintedBootstrapBoxShadow(disabled.facts.shadow),true);
        } else if (part === 'accordion-blocked') {
          const idle = await sample('blocked','opaque-fallback'); opaque(idle); assert.equal(idle.raw.states.collapseBlocked,true);
          for(const [stage,action] of [['hover',()=>target.hover()],['down',()=>page.mouse.down()],['up',()=>page.mouse.up()]]) {
            await action();const value=await sample(stage);opaque(value);assert.deepEqual(value.raw.ring,idle.raw.ring);assert.equal(value.facts.shadow,idle.facts.shadow);same(idle,value);
          }
          await page.mouse.move(0,0);await entry.focus();await page.keyboard.press('Tab'); const focus=await sample('focus');
          assert.equal(focus.raw.states.focusVisible,true);assert.equal(focus.raw.ring['--pui-ring-width'],'2px');assert.equal(focus.raw.ring['--pui-ring-color'],focus.raw.themeRing);assert.equal(focus.raw.ring['--pui-ring-inset'],'');
          const screenshot=path.join(control,`${label}-${runtime}-${theme}-focus.png`);await target.screenshot({path:screenshot});record.focusScreenshot={path:screenshot,sha256:hash(fs.readFileSync(screenshot))};
          await target.hover();const focusHover=await sample('focus-hover');assert.deepEqual(focusHover.raw.ring,focus.raw.ring);
          await entry.focus();const blurred=await sample('blur');assert.equal(blurred.raw.states.focusVisible,false);assert.deepEqual(blurred.raw.ring,idle.raw.ring);assert.deepEqual(blurred.raw.requests,[]);same(idle,blurred);
        } else {
          const idle=await sample('negative-idle','opaque-fallback');opaque(idle);assert.equal(idle.facts.reason,'source-overlapping-content');assert.ok(Math.abs(idle.raw.gap-1)<.005);assert.ok(idle.raw.gap>0&&idle.raw.gap<idle.facts.paint.paintOutset);
          for(const [stage,action] of [['hover',()=>target.hover()],['down',()=>page.mouse.down()],['up',()=>page.mouse.up()]]) {await action();const value=await sample(stage);opaque(value);assert.deepEqual(value.facts.background,idle.facts.background);assert.deepEqual(value.facts.foreground,idle.facts.foreground);}
        }
        record.success=true;
      } catch(error) { record.error=String(error.stack||error); }
      finally { await page.mouse.move(0,0);await page.mouse.up(); }
      console.log(runtime,theme,part,record.success?'PASS':record.error.split('\n')[0]);
    }
    await context.close();
  }
} catch(error) {report.error=String(error.stack||error);}
finally {
  await browser.close();report.durationMs=Date.now()-started;report.passed=report.cases.filter(x=>x.success).length;report.failed=report.cases.filter(x=>!x.success).length;
  fs.writeFileSync(path.join(control,`${label}.json`),JSON.stringify(report,null,2)+'\n');
  fs.writeFileSync(path.join(control,`${label}.exit`),String(report.error||report.failed||report.pageErrors.length?1:0)+'\n');
  console.log('TOTAL',report.passed,report.failed,report.durationMs);
}
