import { rootOwners, logicalOwners, exposeSignals } from './ownership-v2';
// Native DOM interaction v1. No Proto package, interpreter or template rendering dependency.
import { createNativeControlLabel } from './control-label-v1';
import { type NativeControlLabel, createNativeAdapterModules, type NativeAccessibleExtension, type NativeModuleCapabilities, type NativeAdapterModuleOptions, type NativeStateEvent, type NativeOwnedState, type NativeOwnedStateSpec } from "./modules-461853a2ea8dc587-v2";
export type { NativeModuleCapability, NativeAnatomy, NativeAnatomyFamily, NativeAnatomyPart, NativeAnatomyOrder, NativeAnatomy as NativeAnatomyChannel } from "./modules-461853a2ea8dc587-v2";
export type NativeState<T = unknown> = {
    get(): T;
};
export type NativeObservedState<T> = NativeState<T> & {
    watch<R>(callback: (run: R, event: NativeStateEvent<T>) => void): () => void;
    subscribe(callback: (event: {
        type: 'next';
        prev: T;
        next: T;
        reason?: unknown;
    }) => void): () => void;
};
export type NativeInput = Readonly<{
    type: string;
    pointerType?: 'mouse' | 'touch' | 'pen' | 'unknown';
    pointerButtons?: 'none' | 'active' | 'unknown';
    key?: string;
    ctrlKey?: boolean;
    metaKey?: boolean;
    altKey?: boolean;
    shiftKey?: boolean;
    repeat?: boolean;
    control: Readonly<{
        requestDefaultActionPrevention(options?: {
            reason?: string;
            source?: string;
        }): void;
    }>;
}>;
export type NativeHostOptions = Readonly<{
    capture?: boolean;
    once?: boolean;
    passive?: boolean;
}>;
export type NativeFocusOptions = Readonly<{
    reason?: 'programmatic' | 'keyboard' | 'pointer';
    preventScroll?: boolean;
}>;
export type NativeFocus = {
    focused: NativeObservedState<boolean>;
    focusVisible: NativeObservedState<boolean>;
    focusable: NativeObservedState<boolean>;
    configure(patch: {
        scopeKey?: object;
        groupKey?: object;
        autoFocus?: boolean;
        disabled?: boolean;
        navParticipation?: 'auto' | 'none';
        meta?: Readonly<Record<string, unknown>>;
    }): void;
    setDisabled(disabled: boolean): void;
    focus(options?: NativeFocusOptions): void;
    focusSelf(options?: NativeFocusOptions): void;
    blur(): void;
    isFocused(): boolean;
    setNavParticipation(value: 'auto' | 'none'): void;
    setRovingStatus(status: {
        selected?: boolean;
        active?: boolean;
    }): void;
};
export type NativeAccessible = {
    state(key: string, state: NativeState, options?: {
        when?: NativeState<boolean>;
    }): void;
    action(key: string, spec?: {
        event?: string;
    }): void;
    role(role: string | NativeState<string>): void;
} & NativeAccessibleExtension;
export type NativeListenerToken = {
    readonly id: string;
    readonly meta: {
        kind: 'root' | 'global';
        type: string;
        options?: NativeHostOptions;
        label?: string;
    };
    desc(text: string): NativeListenerToken;
};
export type NativeEventChannel<Run> = {
    on<Type extends string>(type: Type, callback: (run: Run, event: Type extends `host:${string}` ? Event : NativeInput) => void, options?: NativeHostOptions): NativeListenerToken;
    onGlobal<Type extends string>(type: Type, callback: (run: Run, event: Type extends `host:${string}` ? Event : NativeInput) => void, options?: NativeHostOptions): NativeListenerToken;
};
export type NativeInteraction<Run = unknown> = {
    /** Internal capture receipt: release only a token registered by this owner. */
    releaseListener(token: NativeListenerToken): void;
    asAccessible(): NativeAccessible;
    asControlLabel(): NativeControlLabel<Run>;
    projectAttributes(): Readonly<Record<string, string | null>>;
    adoptAttributes(snapshot: Readonly<Record<string, string | null>>, baselines?: Readonly<Record<string, string | null>>): void;
    refresh(): void;
    mount(): void;
    unmount(): void;
    dispose(): void;
} & Omit<NativeModuleCapabilities<Run>, 'projectAttributes' | 'refresh' | 'mount' | 'unmount' | 'dispose' | 'setFocusDisabled' | 'canFocus' | 'adoptControlState' | 'hasAuthoredControlLabelName' | 'beginControlLabelName' | 'controlLabelAnatomyScope' | 'subscribeControlLabelAnatomy'>;
type Registration<Run> = {
    active: boolean;
    type: string;
    kind: 'root' | 'global';
    callback: (run: Run, event: NativeInput | Event) => void;
    options?: NativeHostOptions;
};
const stateAttributes: Record<string, string> = { "atomic": "aria-atomic", "autocomplete": "aria-autocomplete", "current": "aria-current", "sort": "aria-sort", "busy": "aria-busy", "checked": "aria-checked", "disabled": "aria-disabled", "expanded": "aria-expanded", "hasPopup": "aria-haspopup", "invalid": "aria-invalid", "live": "aria-live", "orientation": "aria-orientation", "pressed": "aria-pressed", "rowCount": "aria-rowcount", "columnCount": "aria-colcount", "rowIndex": "aria-rowindex", "columnIndex": "aria-colindex", "rowSpan": "aria-rowspan", "columnSpan": "aria-colspan", "readOnly": "aria-readonly", "required": "aria-required", "selected": "aria-selected", "modal": "aria-modal", "hidden": "aria-hidden", "valueMin": "aria-valuemin", "valueMax": "aria-valuemax", "valueNow": "aria-valuenow", "valueText": "aria-valuetext", "level": "aria-level", "posInSet": "aria-posinset", "setSize": "aria-setsize" };
/** Mark ONLY an outward Expose signal before dispatching it on the host. */
export function markNativeExposeEvent<T extends Event>(event: T): T { exposeSignals.add(event); return event; }
/**
 * The emitter owns execution/lifetime: guards use its exact callback scopes, invoke enters
 * its owner scope, getRun/getResolvedProps return current stable runtime/resolved props,
 * and getRoot returns the active physical Root. getHost is the canonical owner
 * boundary when a custom element realizes a separate native control target.
 * Call mount after Root binding and before mounted callbacks; unmount before Root removal
 * and unmounted callbacks; dispose on terminal or failed setup. Call refresh synchronously
 * after owned-state and resolved-props transitions, not through run.update. subscribeState
 * is optional if those transitions always refresh. registerObservedState adapts readonly
 * focus facts to the emitter's Expose external-state boundary. No outward Expose dispatch
 * is routed back into Proto input; accessible.action is metadata, not an input handler.
 * isSetupComplete gates observer callbacks, independently of physical input readiness:
 * setup initializes facts silently; a live owner still publishes resets after view detach.
 */
export function createNativeInteraction<Run>(options: {
    ensureSetup(operation: string): void;
    ensureRuntime(operation: string): void;
    ensureEvent(operation: string): void;
    isAlive(): boolean;
    isSetupComplete(): boolean;
    isReady?(): boolean;
    invoke<T>(callback: () => T): T;
    getRun(): Run;
    getResolvedProps(): Readonly<Record<string, unknown>>;
    getRoot(): HTMLElement | null;
    getHost?(): HTMLElement | null;
    subscribeState?(state: NativeState, callback: () => void): () => void;
    registerObservedState?(state: NativeObservedState<boolean>): void;
    declarations?: readonly {
        id: string;
        config: Readonly<Record<string, unknown>>;
    }[];
    identity?: object;
    getAssociations?(): unknown;
    getLogicalParent?(): object | null;
    tableFamily?: import("./modules-461853a2ea8dc587-v2").NativeAnatomyFamily;
    getExposes?(): Readonly<Record<string, unknown>>;
    setPresent?(value: boolean): void;
    requestHostUpdate?(): void;
    emit?(key: string): void;
    createOwnedState?<T extends boolean | string | number>(name: string, initial: T, spec?: NativeOwnedStateSpec): NativeOwnedState<T>;
    watchState?<T>(state: {
        get(): T;
    }, callback: (run: Run, event: NativeStateEvent<T>) => void): () => void;
    isPropProvided?(key: string): boolean;
    getMeta?(key: string): unknown;
    registerExpose?(key: string, value: unknown): void;
    registerGenericObservedState?<T extends boolean | string | number>(state: NativeObservedState<T>): void;
}): NativeInteraction<Run> {
    let disposed = false;
    let root: HTMLElement | null = null;
    let host: HTMLElement | null = null;
    let generation = 0;
    let trigger = false;
    let role: string | NativeState<string> | undefined;
    const identity = options.identity ?? {};
    const capturedListeners = new WeakMap<NativeListenerToken, Registration<Run>>();
    const removals: (() => void)[] = [];
    const subscriptions: (() => void)[] = [];
    const states = new Map<string, NativeState>();
    const stateConditions = new Map<string, NativeState<boolean>>();
    const actions = new Map<string, {
        event?: string;
    }>();
    const attributes = new Map<string, {
        baseline: string | null;
        projected: string | null;
    }>();
    function alive() {
        if (disposed || !options.isAlive())
            throw new Error('[Interaction] invalid after terminal disposal.');
    }
    function active(epoch = generation, target = root) { return !disposed && options.isAlive() && !!target && target === root && options.getRoot() === target && generation === epoch && rootOwners.get(target)?.identity === identity; }
    function project(name: string, value: string | null) {
        if (!root)
            return;
        let ownership = attributes.get(name);
        const current = root.getAttribute(name);
        if (!ownership) {
            ownership = { baseline: current, projected: current };
            attributes.set(name, ownership);
        }
        else if (current !== ownership.projected)
            ownership.baseline = current;
        if (current !== value) {
            if (value === null)
                root.removeAttribute(name);
            else
                root.setAttribute(name, value);
        }
        ownership.projected = value;
    }
    function clearProjection(target: HTMLElement) {
        for (const [name, ownership] of attributes) {
            if (target.getAttribute(name) !== ownership.projected)
                continue;
            if (ownership.baseline === null)
                target.removeAttribute(name);
            else
                target.setAttribute(name, ownership.baseline);
        }
        attributes.clear();
    }
    function read<T>(value: T | NativeState<T>): T { return typeof value === 'object' && value !== null && 'get' in value ? (value as NativeState<T>).get() : value as T; }
    function scalar(key: string, value: unknown): string | null {
        if (key === 'autocomplete')
            return typeof value === 'string' && ['none', 'inline', 'list', 'both'].includes(value) ? value : null;
        if (key === 'sort')
            return typeof value === 'string' && ['none', 'ascending', 'descending', 'other'].includes(value) ? value : null;
        if (key === 'current')
            return typeof value === 'boolean' ? String(value) : typeof value === 'string' && ['false', 'true', 'page', 'step', 'location', 'date', 'time'].includes(value) ? value : null;
        if (value === null || value === undefined || value === '')
            return null;
        if (['valueMin', 'valueMax', 'valueNow'].includes(key) && typeof value === 'string' && /^-?(?:0|[1-9][0-9]*)(?:[.][0-9]+)?(?:[eE][+-]?[0-9]+)?$/.test(value) && Number.isFinite(Number(value)))
            return value;
        if (['valueMin', 'valueMax', 'valueNow'].includes(key))
            return typeof value === 'number' && Number.isFinite(value) ? String(value) : null;
        if (key === 'valueText')
            return typeof value === 'string' ? value : null;
        if (key === 'rowCount' || key === 'columnCount' || key === 'setSize')
            return typeof value === 'number' && Number.isSafeInteger(value) && (value === -1 || value > 0) ? String(value) : null;
        if (['rowIndex', 'columnIndex', 'rowSpan', 'columnSpan', 'level', 'posInSet'].includes(key))
            return typeof value === 'number' && Number.isSafeInteger(value) && value > 0 ? String(value) : null;
        return String(value);
    }
    function visitProjection(write: (name: string, value: string | null) => void): void {
        {
            if (role !== undefined)
                write('role', read(role) || null);
            for (const [key, state] of states) {
                if (!Object.hasOwn(stateAttributes, key))
                    continue;
                const value = state.get();
                if (stateConditions.has(key) && stateConditions.get(key)!.get() !== true)
                    continue;
                write(stateAttributes[key], scalar(key, value));
                if (key === 'hidden')
                    write('hidden', value === true ? '' : null);
            }
            if (actions.size)
                write('data-pui-a11y-actions', [...actions.keys()].sort().join(' '));
        }
    }
    function projectAttributes(): Readonly<Record<string, string | null>> {
        alive();
        const result: Record<string, string | null> = Object.create(null);
        visitProjection((name, value) => { result[name] = value; });
        return result;
    }
    function adoptAttributes(snapshot: Readonly<Record<string, string | null>>, baselines?: Readonly<Record<string, string | null>>): void {
        alive();
        if (root || attributes.size)
            throw new Error('[Interaction] hydration attributes must be adopted before first projection.');
        const target = options.getRoot();
        if (!target)
            throw new Error('[Interaction] hydration requires the adopted current Root.');
        for (const name of Object.keys(snapshot)) {
            const value = snapshot[name];
            if (target.getAttribute(name) !== value)
                continue;
            const baseline = baselines && Object.hasOwn(baselines, name) ? baselines[name] : null;
            attributes.set(name, { baseline, projected: value });
        }
        modules.adoptControlState();
    }
    function refresh() {
        if (!active())
            return;
        const next = combinedProjectAttributes();
        for (const [name, ownership] of attributes)
            if (!Object.hasOwn(next, name)) {
                if (root!.getAttribute(name) === ownership.projected) {
                    if (ownership.baseline === null)
                        root!.removeAttribute(name);
                    else
                        root!.setAttribute(name, ownership.baseline);
                }
                attributes.delete(name);
            }
        for (const [name, value] of Object.entries(next))
            project(name, value);
    }
    function subscribe(state: NativeState, callback: () => void): (() => void) | undefined {
        if (options.subscribeState)
            return options.subscribeState(state, callback);
        if ('subscribe' in state && typeof state.subscribe === 'function')
            return (state as NativeObservedState<unknown>).subscribe(callback);
        return undefined;
    }
    function watch(state: NativeState) {
        const off = subscribe(state, refresh);
        if (off)
            subscriptions.push(off);
    }
    const accessibleBase: Omit<NativeAccessible, keyof NativeAccessibleExtension> = {
        state(key, state, condition) {
            options.ensureSetup('accessible.state');
            const when = condition?.when;
            if (when !== undefined && typeof when.get() !== 'boolean')
                throw new Error('[Accessible] when must be a Boolean State.');
            states.set(key, state);
            stateConditions.delete(key);
            if (when !== undefined)
                stateConditions.set(key, when);
            refresh();
        },
        action(key, spec = {}) { options.ensureSetup('accessible.action'); actions.set(key, { ...spec }); refresh(); },
        role(value) {
            options.ensureSetup('accessible.role');
            role = value;
            if (typeof value !== 'string')
                watch(value);
            refresh();
        },
    };
    function unmount() {
        // Invalidate first: even a retained callback or a failing physical removal is inert.
        generation++;
        const previous = root, previousHost = host;
        root = null;
        host = null;
        if (previous && rootOwners.get(previous)?.identity === identity)
            rootOwners.delete(previous);
        if (previousHost && rootOwners.get(previousHost)?.identity === identity)
            rootOwners.delete(previousHost);
        logicalOwners.delete(identity);
        let failure: unknown;
        for (const remove of removals.splice(0)) {
            try {
                remove();
            }
            catch (error) {
                failure ??= error;
            }
        }
        if (previous)
            clearProjection(previous);
        if (failure)
            throw failure;
    }
    function mount() {
        alive();
        const candidate = options.getRoot();
        if (root === candidate && active()) {
            refresh();
            return;
        }
        unmount();
        alive();
        if (!candidate)
            return;
        const target: HTMLElement = candidate;
        root = target;
        host = options.getHost?.() ?? target;
        const rootOwner = { identity, parent: options.getLogicalParent ?? (() => null), trigger: () => trigger, target };
        rootOwners.set(target, rootOwner);
        rootOwners.set(host, rootOwner);
        logicalOwners.set(identity, rootOwner);
        {
            const epoch = generation;
            const notify = () => {
                if (active(epoch, target))
                    refresh();
            };
            for (const state of new Set([...states.values(), ...stateConditions.values()])) {
                const off = subscribe(state, notify);
                if (off)
                    removals.push(off);
            }
        }
        refresh();
    }
    const modules: NativeModuleCapabilities<Run> = createNativeAdapterModules<Run>({
        ensureSetup: options.ensureSetup, ensureRuntime: options.ensureRuntime, ensureEvent: options.ensureEvent,
        isAlive: () => !disposed && options.isAlive(), isSetupComplete: options.isSetupComplete, isReady: options.isReady, invoke: options.invoke, getRun: options.getRun,
        getResolvedProps: options.getResolvedProps, getRoot: options.getRoot, getHost: options.getHost,
        declarations: options.declarations ?? [],
        identity,
        getLogicalParent: options.getLogicalParent ?? (() => null),
        tableFamily: options.tableFamily,
        registerObservedState: options.registerGenericObservedState,
        getExposes: options.getExposes,
        setPresent: options.setPresent,
        requestHostUpdate: options.requestHostUpdate,
        emit: options.emit,
        createOwnedState: options.createOwnedState,
        watchState: options.watchState,
        isPropProvided: options.isPropProvided,
        getMeta: options.getMeta,
        registerExpose: options.registerExpose,
        baseFocus: undefined,
        cancelPendingFocus() {
        },
        getAccessibleRole: () => role === undefined ? null : read(role) || null,
        requestAttributeRefresh: refresh,
        getAttributeBaseline: (name) => attributes.has(name) ? attributes.get(name)!.baseline : root?.getAttribute(name) ?? null,
        subscribeState: options.subscribeState,
    } satisfies NativeAdapterModuleOptions<Run>);
    function combinedProjectAttributes(): Readonly<Record<string, string | null>> {
        const base = projectAttributes();
        const extended = modules.projectAttributes();
        return Object.freeze({ ...base, ...extended });
    }
    const accessible: NativeAccessible = Object.freeze({ ...accessibleBase, ...modules.accessible });
    const controlLabel = createNativeControlLabel<Run>({
        identity, ensureSetup: options.ensureSetup, isAlive: () => !disposed && options.isAlive(), isSetupComplete: options.isSetupComplete, isReady: options.isReady,
        getRoot: options.getRoot, getAssociations: options.getAssociations ?? (() => undefined), getRun: options.getRun, invoke: options.invoke,
        hasAuthoredName: () => modules.hasAuthoredControlLabelName!(), beginNameProjection: () => modules.beginControlLabelName!(), resolveAnatomy: (pair, kind) => modules.controlLabelAnatomyScope!(pair, kind),
        subscribeAnatomy: callback => modules.subscribeControlLabelAnatomy!(callback),
    });
    return {
        releaseListener(token) {
            options.ensureSetup('asHook.disposer');
            const registration = capturedListeners.get(token);
            if (!registration)
                throw new Error('[Event] listener token belongs to a different owner.');
            registration.active = false;
        },
        asAccessible() { options.ensureSetup('hook.asAccessible'); return accessible; },
        asControlLabel() {
            options.ensureSetup('hook.asControlLabel');
            if (!controlLabel)
                throw new Error('[ControlLabel] undeclared native association channel');
            return controlLabel.facade;
        },
        anatomy: modules.anatomy, accessible: modules.accessible,
        rootTag: () => modules.rootTag(), rootProperties: () => modules.rootProperties(), portalTarget: () => modules.portalTarget(),
        commitHost: () => modules.commitHost(),
        projectAttributes: combinedProjectAttributes, adoptAttributes,
        refresh() {
            modules.refresh();
            refresh();
            controlLabel?.refresh();
        },
        mount() {
            mount();
            modules.mount();
            controlLabel?.mount();
        },
        unmount() {
            let failed = false, failure: unknown;
            const attempt = (cleanup: () => void) => {
                try {
                    cleanup();
                }
                catch (error) {
                    if (!failed) {
                        failed = true;
                        failure = error;
                    }
                }
            };
            attempt(() => controlLabel?.unmount());
            attempt(() => modules.unmount());
            attempt(unmount);
            if (failed)
                throw failure;
        },
        dispose() {
            if (disposed)
                return;
            disposed = true;
            let failed = false, failure: unknown;
            const attempt = (cleanup: () => void) => {
                try {
                    cleanup();
                }
                catch (error) {
                    if (!failed) {
                        failed = true;
                        failure = error;
                    }
                }
            };
            attempt(() => controlLabel?.dispose());
            attempt(() => modules.unmount());
            attempt(unmount);
            attempt(() => modules.dispose());
            for (const off of subscriptions.splice(0))
                attempt(off);
            {
                states.clear();
                stateConditions.clear();
                actions.clear();
            }
            if (failed)
                throw failure;
        }
    };
}
