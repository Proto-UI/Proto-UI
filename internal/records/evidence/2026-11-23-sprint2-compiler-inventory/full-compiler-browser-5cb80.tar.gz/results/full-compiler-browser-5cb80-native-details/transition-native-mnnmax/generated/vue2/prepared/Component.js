// Editable generated Vue 2.6.14 component options. Profile: vue2-source-v1.
// Inline native-lowering helpers: logical owner, prop resolution, state, semantic templates.
// No Proto-UI Core, Runtime, Hooks or Adapter dependency; optional native helpers are emitted artifacts.
// Source graph SHA-256: 5030006b1ea816075b6ee6421c1931c4bccc57778d98439a86a8de9d41cb2309
import { createNativeDelay as __pui_CreateDelay } from './.proto-ui/async/delay-web-v1';
/** @typedef {import('./.proto-ui/async/delay-web-v1').NativeDelayTask} __pui_DelayTask */
import { createNativePresence as __pui_CreatePresence, snapshotNativeCompletion as __pui_SnapshotCompletion } from './.proto-ui/async/presence-owner-v1';
/** @template Run @typedef {import('./.proto-ui/async/presence-owner-v1').NativePresenceOwner<Run>} __pui_PresenceOwner */
import { readNativeWebMeta as __pui_ReadMeta } from './.proto-ui/meta/web-snapshot-v1';
import { createNativePublicCalls as __pui_CreatePublicCalls } from './.proto-ui/owner/public-callables-v1';

import { createNativeAuthoredHooks as __pui_CreateAuthored } from './.proto-ui/owner/authored-hooks-v1';
import { createContextScope as __pui_CreateContextScope, scopeKey as __pui_ScopeKey, acceptsContextValue as __pui_AcceptsContextValue } from './.proto-ui/context/scope-v1';


// Source "transition/as-transition.proto.ts":23:1
const __puiModule1 = /** @param {((__pui_OwnedState<string> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<string>) => void): () => void}) | (undefined))} value @param {"transitionState"} name @returns {__pui_OwnedState<string> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<string>) => void): () => void}} */ (value, name) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule2 = /** @param {((__pui_OwnedState<boolean> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void}) | (undefined))} value @param {"isPresent"} name @returns {__pui_OwnedState<boolean> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void}} */ (value, name) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule3 = /** @param {((() => ((() => void) | (null))) | (undefined))} value @param {"capturePreparation"} name @returns {() => ((() => void) | (null))} */ (value, name) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule4 = /** @param {((() => void) | (undefined))} value @param {"enter"} name @returns {() => void} */ (value, name) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule5 = /** @param {((() => void) | (undefined))} value @param {"leave"} name @returns {() => void} */ (value, name) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule6 = /** @param {((() => void) | (undefined))} value @param {"complete"} name @returns {() => void} */ (value, name) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule7 = /** @param {((__pui_OwnedState<boolean> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void}) | (undefined))} value @param {"transitionAppearDefault"} name @returns {__pui_OwnedState<boolean> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void}} */ (value, name) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule8 = /** @param {((__pui_OwnedState<number> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<number>) => void): () => void}) | (undefined))} value @param {"transitionEnterDurationDefault"} name @returns {__pui_OwnedState<number> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<number>) => void): () => void}} */ (value, name) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule9 = /** @param {((__pui_OwnedState<number> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<number>) => void): () => void}) | (undefined))} value @param {"transitionLeaveDurationDefault"} name @returns {__pui_OwnedState<number> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<number>) => void): () => void}} */ (value, name) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule10 = /** @param {((__pui_OwnedState<string> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<string>) => void): () => void}) | (undefined))} value @param {"transitionInterruptDefault"} name @returns {__pui_OwnedState<string> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<string>) => void): () => void}} */ (value, name) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule11 = /** @param {((__pui_OwnedState<boolean> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void}) | (undefined))} value @param {"transitionColdEntryPreparation"} name @returns {__pui_OwnedState<boolean> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void}} */ (value, name) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule12 = /** @param {(((config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void) | (undefined))} value @param {"configurePresentation"} name @returns {(config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void} */ (value, name) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule13 = /** @param {((() => Readonly<object>) | (undefined))} value @param {"getPresentationOwner"} name @returns {() => Readonly<object>} */ (value, name) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule14 = /** @param {(((source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void) | (undefined))} value @param {"bindInitialOpen"} name @returns {(source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void} */ (value, name) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule15 = /** @param {(((source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void) | (undefined))} value @param {"bindOpenContext"} name @returns {(source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void} */ (value, name) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule16 = /** @param {(((retained: boolean) => void) | (undefined))} value @param {"retainClosedView"} name @returns {(retained: boolean) => void} */ (value, name) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};


/** @typedef {{
  "open"?: boolean | null;
  "defaultOpen"?: boolean | null;
  "appear"?: boolean | null;
  "enterDuration"?: number | null;
  "leaveDuration"?: number | null;
  "interrupt"?: "reverse" | "wait" | "immediate" | null;
}} GeneratedProps */
/** @typedef {Readonly<{
  readonly "open": boolean | null;
  readonly "defaultOpen": boolean;
  readonly "appear": boolean;
  readonly "enterDuration": number;
  readonly "leaveDuration": number;
  readonly "interrupt": "reverse" | "wait" | "immediate";
} & Record<string, unknown>>} __pui_ResolvedProps */
/** @typedef {{
  "bindInitialOpen": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void;
  "getPresentationOwner": () => Readonly<object>;
  "configurePresentation": (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void;
  "bindOpenContext": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void;
  "retainClosedView": (retained: boolean) => void;
  "transitionState": __pui_ExternalState<string>;
  "isPresent": __pui_ExternalState<boolean>;
  "enter": () => void;
  "leave": () => void;
  "complete": () => void;
  "capturePreparation": () => ((() => void) | (null));
  "controls": { "enter": () => void; "leave": () => void; "complete": () => void; "capturePreparation": () => ((() => void) | (null)) };
}} GeneratedExposes */
/** @typedef {Array<import('vue').VNode | string>} __pui_NativeChildren */
/** @typedef {{ used: boolean }} __pui_NativeSlotFrame */
/** @typedef {(h: import('vue').CreateElement, vm: import('vue').default, slots: __pui_NativeSlotFrame) => __pui_NativeChildren} __pui_NativePaint */
/** @typedef {{
 * slot: () => __pui_NativePaint,
 * read: {
 *   props: {
 *     get: () => __pui_ResolvedProps,
 *     getRaw: () => Readonly<Record<string, unknown>>,
 *     isProvided: (key: PropertyKey) => boolean
 *   },
 *   context: {
 *     read: (key: object) => ReturnType<import('./.proto-ui/context/scope-v1').ContextScope['read']>,
 *     tryRead: (key: object) => ReturnType<import('./.proto-ui/context/scope-v1').ContextScope['tryRead']>
 *   }
 * }
 * }} __pui_NativeRenderer */


/**
 * @template T
 * @typedef {{ get: () => T, subscribe: (callback: (event: { type: 'next', prev: T, next: T, reason?: unknown } | { type: 'disconnect', reason: 'unmount' }) => void) => (() => void), unsubscribe: (off: () => void) => void, spec: Readonly<Record<string, unknown>> }} __pui_ExternalState
 */
/** @template T @typedef {{ type: 'next', prev: T, next: T, reason?: unknown } | { type: 'disconnect', reason: 'unmount' }} __pui_StateEvent */
/** @template T @typedef {{ get: () => T, setDefault: (value: T) => void, set: (value: T, reason?: unknown) => void, external: __pui_ExternalState<T>, dispose: () => void }} __pui_OwnedState */
/** @typedef {'boolean' | 'number' | 'string' | 'null' | 'void' | { kind: 'literal', value: string | number | boolean | null } | { kind: 'array', element: __pui_DataType } | { kind: 'union', members: readonly __pui_DataType[] } | { kind: 'record', fields: readonly { name: string, type: __pui_DataType, optional?: boolean }[] }} __pui_DataType */
/** @typedef {Readonly<Record<string, unknown>>} __pui_RawProps */
/** @typedef {{ type: 'boolean' | 'number' | 'string' | 'object' | 'any' | 'enum', empty?: 'accept' | 'fallback' | 'error', default?: unknown, options?: readonly string[], range?: { min?: number, max?: number }, validator?: (value: never) => boolean }} __pui_PropSpec */
/** @typedef {{ options?: readonly (boolean | string | number)[], min?: unknown, max?: unknown, step?: unknown, clamp?: boolean } & Record<string, unknown>} __pui_StateConfiguration */
/** @typedef {'bool' | 'string' | 'enum' | 'number.discrete' | 'number.range'} __pui_StateKind */
/** @typedef {ReturnType<typeof __pui_CreateOwner>} __pui_Owner */
/** @typedef {Parameters<Parameters<__pui_Owner['def']['props']['watch']>[1]>[0]} __pui_Run */
/** @typedef {import('vue').default & { readonly instanceAssociations?: Readonly<{controlLabel?: object | null}>; readonly __pui_ParentScope?: import('./.proto-ui/context/scope-v1').ContextScope | null }} __pui_OwnerInstance */
/** @typedef {(renderer: __pui_NativeRenderer) => __pui_NativePaint} __pui_RenderFunction */
/** @typedef {{ changedKeysAll: string[], changedKeysMatched: string[] }} __pui_PropsWatchInfo */
/** @template Run @template Snapshot @typedef {(run: Run, next: Snapshot, previous: Snapshot, info: __pui_PropsWatchInfo) => void} __pui_PropsWatchCallback */
/** @template Run @typedef {{ kind: 'resolved' | 'resolved-all', keys: readonly string[] | null, fn: __pui_PropsWatchCallback<Run, __pui_ResolvedProps> } | { kind: 'raw' | 'raw-all', keys: readonly string[] | null, fn: __pui_PropsWatchCallback<Run, __pui_RawProps> }} __pui_PropsWatchRegistration */
/** @typedef {"created" | "mounted" | "updated" | "unmounted" | "beforeDispose"} __pui_LifecycleKind */
/** @template Run @typedef {(run: Run) => void} __pui_LifecycleCallback */
/** @template Run @typedef {__pui_PropsWatchRegistration<Run> & { active: boolean }} __pui_PropsWatcher */
/** @typedef {{ epoch: number, revision: number, kind: 'update' }} __pui_PendingCommit */
/** @typedef {{ epoch: number, version: number, present: boolean, vnode: import('vue').VNode, kind: 'mount' | 'update' | 'none' | 'detach', revision?: number | null }} __pui_RenderedCommit */
/** @param {unknown} value @param {PropertyKey} key */
const __pui_Own = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
// Keep native relational coercion in all three open-schema comparisons.
/** @template T @param {T} left @param {T} right */
const __pui_Before = (left, right) => left < right;

/** @param {__pui_DataType} type @param {unknown} value @returns {boolean} */
function __pui_Accepts(type, value) {
  if (typeof type === 'string') return type === 'null' ? value === null : typeof value === type && (type !== 'number' || Number.isFinite(value));
  if (type.kind === 'literal') return Object.is(value, type.value);
  if (type.kind === 'union') return type.members.some((member) => __pui_Accepts(member, value));
  if (type.kind === 'array') return Array.isArray(value) && value.every((item) => __pui_Accepts(type.element, item));
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false;
  const record = /** @type {Record<string, unknown>} */ (value);
  return type.fields.every((field) =>
    __pui_Own(record, field.name) ? __pui_Accepts(field.type, record[field.name]) : field.optional === true);
}
/** @param {unknown} value @param {Set<object>} [seen] @returns {boolean} */
function __pui_Json(value, seen = new Set()) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return true;
  if (typeof value === 'number') return Number.isFinite(value);
  if (typeof value !== 'object' || seen.has(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  if (!Array.isArray(value) && prototype !== Object.prototype && prototype !== null) return false;
  if (Array.isArray(value) && (Object.keys(value).length !== value.length || !Object.keys(value).every((key) => /^(0|[1-9]\d*)$/.test(key) && Number(key) < value.length))) return false;
  seen.add(value);
  const valid = Object.values(value).every((item) => __pui_Json(item, seen));
  seen.delete(value);
  return valid;
}


/** @param {__pui_OwnerInstance} vm @param {(owner: __pui_Owner) => __pui_RenderFunction | void} setup @param {Record<string, __pui_DataType>} types @param {string} rootTag @param {boolean} autoUpdate */
function __pui_CreateOwner(vm, setup, types, rootTag, autoUpdate) {
  
  let phase = 'setup';
  let terminal = false;
  let disposed = false;
  let hydrated = false;
  let nativeMounted = false;
  let hostActive = true;
  let present = true;
  let viewActive = false;
  let epoch = 0;
  let revision = 0;
  let commitVersion = 0;
  let queued = false;
  /** @type {__pui_PendingCommit | null} */
  let pending = null;
  /** @type {__pui_RenderedCommit | null} */
  let renderedCommit = null;
  
  
  /** @type {__pui_NativePaint | null} */
  let template = null;
  /** @type {__pui_RenderFunction | null | void} */
  let renderFunction;
  /** @type {(() => void) | undefined} */
  let unwatch;
  /** @type {__pui_RawProps} */
  let raw = Object.freeze({});
  /** @type {__pui_ResolvedProps} */
  let resolved = /** @type {__pui_ResolvedProps} */ (Object.freeze({}));
  /** @type {Record<string, unknown>} */
  let previousValid = Object.create(null);
  /** @type {Record<string, __pui_PropSpec>} */
  let specs = Object.create(null);
  /** @type {__pui_RawProps[]} */
  const defaults = [];
  /** @type {Array<__pui_PropsWatcher<typeof run>>} */
  const watchers = [];
  /** @type {Array<{ dispose: () => void }>} */
  const states = [];
  /** @type {Record<string, unknown>} */
  const exposed = Object.create(null);
  /** @type {Record<string, unknown>} */
  const eventDeclarations = Object.create(null);
  /** @param {string} key @param {unknown} value */
  const declareExpose = (key, value) => {
    setupOnly();
    if (typeof key !== 'string' || !key || __pui_Own(exposed, key))
      throw new Error('[Expose] empty or duplicate declaration: ' + key);
    exposed[key] = value;
  };
  /** @type {Record<__pui_LifecycleKind, Array<__pui_LifecycleCallback<typeof run>>>} */
  const lifecycle = { "created": [], "mounted": [], "updated": [], "unmounted": [], "beforeDispose": [] };
  /** @type {Array<() => void>} */
  const notifications = [];
  
  let notifying = false;
  let dispatchingProps = false;
  /** @type {{raw: __pui_RawProps; resolved: __pui_ResolvedProps} | null} */
  let propsWindow = null;
  const alive = () => { if (disposed) throw new Error('[Vue2 native] logical instance has been disposed.'); };
  const publicAlive = () => { if (terminal) throw new Error('[Vue2 native] exposed target has been terminally invalidated.'); };
  const callback = () => { alive(); if (phase !== 'callback') throw new Error('[Vue2 native] mutation requires callback scope.'); };
  const setupOnly = () => { alive(); if (phase !== 'setup') throw new Error('[Vue2 native] declaration requires setup scope.'); };

  /** @returns {__pui_RawProps} */
  const hostRaw = () => {
    
    // Full snapshots preserve omission and explicit undefined. Vue Boolean casting and
    // default materialization never participate in the semantic prop contract.
    const out = Object.create(null);
    /** @type {Record<string, unknown>} */
    const input = { ...(vm.$attrs || {}), ...((vm.$options && vm.$options.propsData) || {}) };
    /** @type {Readonly<Record<string, unknown>>} */
    const provided = /** @type {Readonly<Record<string, unknown>>} */ ((vm.$options && vm.$options.propsData) || {});
    for (const key of Object.keys(types)) {
      const hostKey = key.replace(/-(\w)/g, (_match, letter) => letter.toUpperCase());
      // Track native prop notifications, but keep values/presence from the raw snapshot.
      if (vm.$props) void (/** @type {Readonly<Record<string, unknown>>} */ (vm.$props))[hostKey];
      if (__pui_Own(provided, hostKey)) input[key] = provided[hostKey];
    }
    for (const key of Object.keys(input)) if (key !== 'instanceAssociations' && key !== 'instance-associations') out[key] = input[key];
    return Object.freeze(out);
  };
  /** @param {__pui_RawProps} a @param {__pui_RawProps} b */
  const same = (a, b) => {
    const keys = Object.keys(a);
    return keys.length === Object.keys(b).length && keys.every((key) => __pui_Own(b, key) && Object.is(a[key], b[key]));
  };
  /** @param {string} key @param {unknown} value */
  const validValue = (key, value) => {
    const spec = specs[key];
    if (!__pui_Json(value) || !__pui_Accepts(types[key], value)) return false;
    if (spec.type === 'enum' && (typeof value !== 'string' || !spec.options?.includes(value))) return false;
    if (spec.range && !(typeof value === 'number' && value >= (spec.range.min ?? -Infinity) && value <= (spec.range.max ?? Infinity))) return false;
    try { return spec.validator ? !!spec.validator(/** @type {never} */ (value)) : true; }
    catch { return false; }
  };
  /** @param {__pui_RawProps} input @param {boolean} strict */
  const resolveProps = (input, strict) => {
    /** @type {Record<string, unknown>} */
    const out = Object.create(null);
    const nextValid = { ...previousValid };
    /** @type {{ providedKeys: string[], emptyKeys: string[], invalidKeys: string[], usedFallbackKeys: string[], acceptedEmptyKeys: string[] }} */
    const meta = { providedKeys: [], emptyKeys: [], invalidKeys: [], usedFallbackKeys: [], acceptedEmptyKeys: [] };
    for (const key of Object.keys(specs)) {
      const spec = specs[key];
      const provided = __pui_Own(input, key);
      const value = input[key] === undefined ? null : input[key];
      const empty = spec.empty ?? 'fallback';
      if (provided) meta.providedKeys.push(key);
      if (provided && value !== null && validValue(key, value)) {
        out[key] = value; nextValid[key] = value; continue;
      }
      if (provided && value === null) {
        meta.emptyKeys.push(key);
        if (empty === 'accept') { out[key] = null; meta.acceptedEmptyKeys.push(key); continue; }
      } else if (provided) meta.invalidKeys.push(key);
      let found = false;
      /** @type {unknown} */
      let selected = null;
      let usedDefault = true;
      /** @param {unknown} candidate @param {boolean} fromDefault */
      const take = (candidate, fromDefault) => {
        if (found || candidate === undefined || strict && empty === 'error' && candidate === null) return;
        if (candidate !== null && !validValue(key, candidate)) return;
        found = true; selected = candidate; usedDefault = fromDefault;
      };
      if (provided && __pui_Own(previousValid, key)) take(previousValid[key], false);
      for (const layer of defaults) if (__pui_Own(layer, key)) take(layer[key], true);
      if (__pui_Own(spec, 'default')) take(spec.default, true);
      if (!found && strict && empty === 'error') throw new Error('[Vue2 native] prop ' + key + ' requires a non-empty valid value or fallback.');
      out[key] = selected;
      if (usedDefault) meta.usedFallbackKeys.push(key);
      if (provided && selected !== null) nextValid[key] = selected;
    }
    previousValid = nextValid;
    /** @type {__pui_ResolvedProps} */
    const snapshot = /** @type {__pui_ResolvedProps} */ (Object.freeze(out));
    return { snapshot, meta };
  };
  /** @template T @param {() => T} fn @param {boolean} [sync] @returns {T} */
  const invoke = (fn, sync = true) => {
    alive();
    const previousPhase = phase;
    phase = 'callback';
    try { if (sync && !terminal ) syncHost(false); return fn(); }
    finally { phase = previousPhase; }
  };
  /** @param {boolean} request */
  const syncHost = (request) => {
    if (terminal) return;
{ const __pui_Associations = vm.instanceAssociations;
    if (__pui_Associations !== undefined) {
      if (__pui_Associations === null || typeof __pui_Associations !== 'object' || Object.getPrototypeOf(__pui_Associations) !== Object.prototype)
        throw new TypeError('[InstanceAssociations] expected a plain record');
      for (const key of Reflect.ownKeys(__pui_Associations)) if (key !== 'controlLabel')
        throw new TypeError('[InstanceAssociations] unknown association key');
      if (Object.prototype.hasOwnProperty.call(__pui_Associations, 'controlLabel') && Reflect.get(__pui_Associations, 'controlLabel') != null)
        throw new Error('[ControlLabel] this Prototype has not declared Label or target participation');
    }
  }
    const nextRaw = hostRaw();
    if (hydrated && same(raw, nextRaw)) return;
    const previousRaw = raw;
    const previous = resolved;
    const next = resolveProps(nextRaw, true);
    raw = nextRaw; resolved = next.snapshot;
    if (!hydrated) { hydrated = true;  return; }
    const changedKeys = Object.keys(specs).filter((key) => !Object.is(previous[key], resolved[key]));
    const changedRawKeys = watchers.some((watch) => watch.active && (watch.kind === 'raw' || watch.kind === 'raw-all'))
      ? [...new Set([...Object.keys(previousRaw), ...Object.keys(raw)])].filter((key) => !Object.is(previousRaw[key], raw[key])) : [];
    
    if ((changedKeys.length || changedRawKeys.length) && !dispatchingProps) {
      dispatchingProps = true;
      const previousWindow = propsWindow; propsWindow = {raw: nextRaw, resolved: next.snapshot};
      try {
        invoke(() => {
          // Raw-all precedes raw-keyed; resolved-all and keyed share declaration order.
          const snapshot = watchers.slice();
          for (let group = 0; group < 3; ++group) {
            for (const watch of snapshot) {
              if (!watch.active || (watch.kind === 'raw-all' ? 0 : watch.kind === 'raw' ? 1 : 2) !== group) continue;
              const isRaw = group < 2;
              const changedKeysAll = isRaw ? changedRawKeys : changedKeys;
              const changedKeysMatched = watch.keys === null ? changedKeysAll : watch.keys.filter((key) => changedKeysAll.includes(key));
              if (changedKeysMatched.length) {
                const info = { changedKeysAll: [...changedKeysAll], changedKeysMatched: [...changedKeysMatched] };
                // The registration discriminant preserves the raw/resolved callback
                // relation; the host group order and snapshot copies stay unchanged.
                if (watch.kind === 'raw' || watch.kind === 'raw-all') {
                  console.warn('[Props] raw watchers are an adapter-snapshot escape hatch; avoid in official prototypes.');
                  watch.fn(run, nextRaw, previousRaw, info);
                }
                else watch.fn(run, next.snapshot, previous, info);
              }
            }
          }
        }, false);
      } finally { propsWindow = previousWindow; dispatchingProps = false; }
    }
    if (request && autoUpdate) update();
  };
  const renderSemantic = () => {
    if (!renderFunction) throw new Error('[Vue2 native] renderer is unavailable outside the initialized instance lifetime.');
    const previousPhase = phase;
    phase = 'render';
    try { template = renderFunction(renderer); }
    finally { phase = previousPhase; }
  };
  const force = () => { if (!terminal && nativeMounted) vm.$forceUpdate(); };
  const update = () => {
    if (terminal) return;
    invoke(() => {}, true);
    if (!nativeMounted || !hostActive || !present || !viewActive) return;
    if (pending) { queued = true; return; }
    renderSemantic();
    pending = { epoch, revision: ++revision, kind: 'update' };
    force();
  };
  /** @param {boolean} next */
  const setPresent = (next) => {
    callback();
    if (terminal) throw new Error('[Vue2 native] presence is locked for terminal disposal.');
    if (typeof next !== 'boolean') throw new TypeError('[Vue2 native] presence must be boolean.');
    if (present === next) return;
    present = next; ++epoch; pending = null; renderedCommit = null; queued = false;
    const requestedEpoch = epoch, failures = [];
    // Vue must patch at the owned anchor, not leave its replacement comment
    // in the Portal host and later resurrect the already-removed Root.
    
    if (!terminal && epoch === requestedEpoch && present === next) {
      
      if (!terminal && epoch === requestedEpoch && present === next) {
        // A newer presence request or terminal disposal always wins reentry.
        try {
          if (next && nativeMounted && hostActive && viewActive) renderSemantic();
          force();
        } catch (error) { failures.push(error); }
      }
    }
    if (failures.length) throw failures.length === 1 ? failures[0]
      : new AggregateError(failures, '[Vue2 native] presence withdrawal failed.');
  };

  /** @type {Map<object, (value: unknown) => boolean>} */
  const contextChecks = new Map(/** @type {Array<[object, (value: unknown) => boolean]>} */ ([

  ]));
  const contextScope = __pui_CreateContextScope({
    getParent: () => vm["__pui_ParentScope"] || null,
    isAlive: () => !disposed,
    invoke: (fn) => invoke(fn, false),
    validate: (key, value) => contextChecks.get(key)?.(value) === true,
  });
  const contextRead = Object.freeze({ read: (/** @param {object} key */ (key) => { alive(); return contextScope.read(key); }), tryRead: (/** @param {object} key */ (key) => { alive(); return contextScope.tryRead(key); }) });

  const __pui_Delay = __pui_CreateDelay({ runtime: () => { callback(); }, alive: () => !disposed, invoke: callback => { invoke(callback, false); }, report: error => console.error('[Delay] callback failed', error) });
const __pui_Presence = __pui_CreatePresence({ setup: () => { setupOnly(); }, runtime: () => { callback(); }, alive: () => !disposed, invoke: callback => { invoke(() => callback(run), false); } });
const __pui_Meta = /** @param {string} key */ (key) => __pui_ReadMeta(vm.$el?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), key);
  /** @type {(() => void)[]} */ const __pui_AuthoredWatchCleanups = [];
  const __pui_Authored = __pui_CreateAuthored({setup: setupOnly, borrow(/** @type {unknown} */ value) {
    
    const state = /** @type {__pui_OwnedState<unknown>} */ (value);
    const borrowed = Object.freeze({get: () => state.get(), setDefault: (/** @type {unknown} */ value) => state.setDefault(value), set: (/** @param {unknown} value @param {unknown} [reason] */ (value, reason) => state.set(value, reason)), watch: (/** @type {(run: __pui_Run, event: __pui_StateEvent<unknown>) => void} */ fn) => { setupOnly(); const off = state.external.subscribe(event => invoke(() => fn(run, event), false)); __pui_AuthoredWatchCleanups.push(off); return off; }});
    
    return borrowed;
    
  }});
  const __pui_WrapPublic = __pui_CreatePublicCalls({alive: publicAlive, invoke});
  const run = {
    context: { ...contextRead, update: (/** @param {object} key @param {unknown} value */ (key, value) => { callback(); contextScope.update(key, value); }), tryUpdate: (/** @param {object} key @param {unknown} value */ (key, value) => { callback(); return contextScope.tryUpdate(key, value); }) },
    
    update: () => { callback(); update(); },
    props: {
      get: () => { alive(); return propsWindow?.resolved ?? resolved; },
      getRaw: () => { alive(); return propsWindow?.raw ?? raw; },
      isProvided: (/** @param {PropertyKey} key */ (key) => { alive(); return __pui_Own(propsWindow?.raw ?? raw, key); }),
    },
    lifecycle: { setPresent },
    expose: { emit: (/** @param {string} key @param {unknown} [payload] @param {unknown} [options] */ (key, payload, options) => {
      callback();
      if (!__pui_Own(eventDeclarations, key)) throw new Error('[Vue2 native] undeclared expose event: ' + key);
      const listener = vm.$attrs && (/** @type {Readonly<Record<string, unknown>>} */ (vm.$attrs))['on' + key[0].toUpperCase() + key.slice(1)];
      // Host sink failures do not re-enter authored callbacks, matching the Vue2 sink.
      try { if (typeof listener === 'function') listener(payload, options); } catch {}
      try { vm.$emit(key, payload, options); } catch {}
    }) },
  };
  
  /** @type {__pui_NativeRenderer} */
  const renderer = { 
    slot: () => /** @type {__pui_NativePaint} */ ((_h, nativeVm, slots) => {
      if (slots.used) throw new Error('[Vue2 native] only one default slot is supported.');
      slots.used = true;
      const scoped = nativeVm.$scopedSlots.default;
      return (scoped ? scoped({}) : nativeVm.$slots.default) || [];
    }),
    read: Object.freeze({ props: Object.freeze({ get: () => { alive(); return resolved; }, getRaw: () => { alive(); return raw; }, isProvided: (/** @param {PropertyKey} key */ (key) => { alive(); return __pui_Own(raw, key); }) }) , context: contextRead }) };
  /**
   * @template T
   * @param {T} initial
   * @param {Readonly<Record<string, unknown>>} spec
   * @param {(value: T, initialValue?: boolean) => T} check
   * @returns {__pui_OwnedState<T>}
   */
  const createStateCell = (initial, spec, check) => {
    let value = check(initial, true);
    /** @type {Set<(event: __pui_StateEvent<T>) => void>} */
    const subscribers = new Set();
    /** @type {__pui_OwnedState<T>} */
    const handle = {
      get: () => { alive(); return value; },
      setDefault: next => { setupOnly(); value = check(next, true); },
      set: (next, reason) => {
        callback();
        next = check(next);
        if (Object.is(value, next)) return;
        const previous = value; value = next;
        
        /** @type {__pui_StateEvent<T>} */
        const event = { type: 'next', prev: previous, next, reason };
        for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(notifications, notifications.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!notifying) {
  notifying = true;
  /** @type {unknown[]} */ const notificationFailures = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < notifications.length) {
      try { notifications[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { notifications.length = 0; notifying = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
      },
      external: {
        get: () => { publicAlive(); return handle.get(); },
        subscribe: (fn) => { publicAlive(); /** @type {typeof fn} */ const registration = (/** @type {Parameters<typeof fn>[0]} */ event) => fn(event); subscribers.add(registration); return () => subscribers.delete(registration); },
        unsubscribe: (off) => { publicAlive(); if (typeof off === 'function') off(); },
        spec,
      },
      dispose: () => {
        try { for (const fn of Array.from(subscribers)) fn({ type: 'disconnect', reason: 'unmount' }); }
        finally { subscribers.clear(); }
      },
    };
    
    states.push(handle);
    
    return handle;
  };
  /** @template {boolean | string | number} T @param {__pui_StateKind} kind @param {string} key @param {T} initial @param {__pui_StateConfiguration} [configuration] @returns {__pui_OwnedState<T>} */
  const createState = (kind, key, initial, configuration = {}) => {
    setupOnly();
    const spec = Object.freeze({ ...configuration, kind });
    /** @param {T} value @param {boolean} [initialValue] @returns {T} */
    const check = (value, initialValue = false) => {
      const expected = kind === 'bool' ? 'boolean' : kind === 'string' || kind === 'enum' ? 'string' : 'number';
      if (typeof value !== expected || expected === 'number' && !Number.isFinite(value)) throw new TypeError('[Vue2 native] invalid state value: ' + key);
      if (spec.options && spec.options.length && !spec.options.includes(value)) throw new Error('[Vue2 native] state value not in options: ' + key);
      // Numeric-family schemas prove these numeric views. Other families keep
      // their structurally admitted extra fields and native relational coercion.
      if (kind === 'number.range' && initialValue && spec.clamp) value = /** @type {T} */ (Math.min(/** @type {number} */ (spec.max), Math.max(/** @type {number} */ (spec.min), /** @type {number} */ (value))));
      if (!(kind === 'number.discrete' && spec.options && spec.options.length) && (spec.min !== undefined && __pui_Before(value, spec.min) || spec.max !== undefined && __pui_Before(spec.max, value))) throw new Error('[Vue2 native] state value out of range: ' + key);
      if (kind === 'number.discrete' && !(spec.options && spec.options.length) && __pui_Before(0, spec.step) && !Number.isInteger((/** @type {number} */ (value) - /** @type {number} */ (spec.min ?? 0)) / /** @type {number} */ (spec.step))) throw new Error('[Vue2 native] state value violates step: ' + key);
      return value;
    };
    __pui_Authored.claimState(key);
    const handle = createStateCell(initial, spec, check);
    __pui_Authored.state(key, handle);
    return handle;
  };
  /** @param {Record<string, __pui_PropSpec>} input */
  const defineProps = (input) => {
    setupOnly();
    const next = { ...specs };
    const rank = { accept: 0, fallback: 1, error: 2 };
    for (const key of Object.keys(input)) {
      const spec = input[key];
      if (!spec || !['boolean', 'number', 'string', 'object', 'any', 'enum'].includes(spec.type)) throw new Error('[Vue2 native] invalid prop declaration: ' + key);
      if (spec.empty !== undefined && !__pui_Own(rank, spec.empty)) throw new Error('[Vue2 native] invalid empty behavior: ' + key);
      if (spec.type === 'enum' && (!Array.isArray(spec.options) || !spec.options.length || !spec.options.every((value) => typeof value === 'string'))) throw new Error('[Vue2 native] invalid enum options: ' + key);
      if (spec.type !== 'enum' && __pui_Own(spec, 'options')) throw new Error('[Vue2 native] only enum props accept options: ' + key);
      if (__pui_Own(spec, 'default') && !__pui_Json(spec.default)) throw new Error('[Vue2 native] non-JSON prop default: ' + key);
      const prior = next[key];
      if (prior) {
        if (prior.validator && prior.validator !== spec.validator) throw new Error('[Vue2 native] validator replacement or removal is disallowed: ' + key);
        if (prior.type !== spec.type || __pui_Own(spec, 'empty') && spec.empty !== undefined && rank[spec.empty] > rank[prior.empty ?? 'fallback']) throw new Error('[Vue2 native] conflicting prop declaration: ' + key);
        if (prior.options && !prior.options.every((value) => spec.options && spec.options.includes(value))) throw new Error('[Vue2 native] prop options cannot narrow: ' + key);
        if (prior.range && spec.range && ((spec.range.min ?? -Infinity) > (prior.range.min ?? -Infinity) || (spec.range.max ?? Infinity) < (prior.range.max ?? Infinity))) throw new Error('[Vue2 native] prop range cannot narrow: ' + key);
        next[key] = { ...prior, ...spec, empty: prior.empty ?? 'fallback', range: spec.range ?? prior.range };
        if (__pui_Own(prior, 'default')) next[key].default = prior.default;
      } else next[key] = { ...spec };
    }
    specs = next; resolved = resolveProps(raw, false).snapshot;
  };
  /** @param {__pui_PropsWatcher<typeof run>} watch */
  const registerPropsWatch = (watch) => {
    setupOnly();
    const { kind, keys } = watch;
    if (keys !== null && (!keys.length || keys.some((key) => typeof key !== 'string'
      || kind === 'resolved' && !__pui_Own(specs, key)))) throw new Error('[Vue2 native] watch requires non-empty valid prop keys.');
    watch.keys = keys === null ? null : [...keys];
    watchers.push(watch);
    return () => { watch.active = false; };
  };
  /** @type {readonly __pui_LifecycleKind[]} */
  const lifecycleKeys = ["created","mounted","updated","unmounted","beforeDispose"];
  const def = {
    context: { provide: (/** @param {object} key @param {unknown} value */ (key, value) => { setupOnly(); contextScope.provide(key, value); }), subscribe: (/** @param {object} key @param {(run: __pui_Run, next: unknown, previous: unknown) => void} [fn] */ (key, fn) => { setupOnly(); return contextScope.subscribe(key, 'required', fn ? (next, prev) => fn(run, next, prev) : undefined); }), trySubscribe: (/** @param {object} key @param {(run: __pui_Run, next: unknown, previous: unknown) => void} [fn] */ (key, fn) => { setupOnly(); return contextScope.subscribe(key, 'optional', fn ? (next, prev) => fn(run, next, prev) : undefined); }) },
    
    
    props: {
      define: defineProps,
      setDefaults: (/** @param {__pui_RawProps} layer */ (layer) => {
        setupOnly();
        for (const key of Object.keys(layer)) if (!__pui_Own(specs, key) || !__pui_Json(layer[key])) throw new Error('[Vue2 native] invalid prop default: ' + key);
        defaults.unshift({ ...layer }); resolved = resolveProps(raw, false).snapshot;
      }),
      /** @param {readonly string[]} keys @param {__pui_PropsWatchCallback<typeof run, __pui_ResolvedProps>} fn */
      watch: (keys, fn) => registerPropsWatch({ kind: 'resolved', keys, fn, active: true }),
      /** @param {__pui_PropsWatchCallback<typeof run, __pui_ResolvedProps>} fn */
      watchAll: (fn) => registerPropsWatch({ kind: 'resolved-all', keys: null, fn, active: true }),
      /** @param {readonly string[]} keys @param {__pui_PropsWatchCallback<typeof run, __pui_RawProps>} fn */
      watchRaw: (keys, fn) => registerPropsWatch({ kind: 'raw', keys, fn, active: true }),
      /** @param {__pui_PropsWatchCallback<typeof run, __pui_RawProps>} fn */
      watchRawAll: (fn) => registerPropsWatch({ kind: 'raw-all', keys: null, fn, active: true }),
    },
    state: {
      /** @param {string} key @param {boolean} value */
      bool: (key, value) => createState('bool', key, value),
      /** @param {string} key @param {string} value @param {__pui_StateConfiguration} [spec] */
      string: (key, value, spec) => createState('string', key, value, spec),
      /** @param {string} key @param {string} value @param {__pui_StateConfiguration} [spec] */
      enum: (key, value, spec) => createState('enum', key, value, spec),
      /** @param {string} key @param {number} value @param {__pui_StateConfiguration} [spec] */
      numberDiscrete: (key, value, spec) => createState('number.discrete', key, value, spec),
      /** @param {string} key @param {number} value @param {__pui_StateConfiguration} spec */
      numberRange: (key, value, spec) => createState('number.range', key, value, spec),
    },
    expose: {
      /** @param {string} key @param {unknown} value */
      value: declareExpose,
      /** @template T @param {string} key @param {{ external: __pui_ExternalState<T> }} handle */
      state: (key, handle) => { declareExpose(key, handle.external); __pui_Authored.introduceObserved(handle); },
      /** @template {unknown[]} Args @template Result @param {string} key @param {(...args: Args) => Result} fn @param {(value: Result) => Result} [project] */
      method: (key, fn, project) => { declareExpose(key, (/** @param {Args} args */ (...args) => { publicAlive(); const result = invoke(() => fn(...args)); return project ? project(result) : result; })); },
      /** @param {string} key @param {unknown} [spec] */
      event: (key, spec) => { declareExpose(key, Object.freeze({kind:'event'})); eventDeclarations[key] = spec; },
    },
    lifecycle: Object.fromEntries(lifecycleKeys.map((key) => {
      /** @type {[string, (fn: __pui_LifecycleCallback<typeof run>) => void]} */
      const entry = ['on' + key[0].toUpperCase() + key.slice(1), (fn) => { setupOnly(); lifecycle[key].push(fn); }];
      return entry;
    })),
  };
  /** @param {__pui_LifecycleKind} kind */
  const fire = (kind) => invoke(() => { if (kind === 'unmounted') { { let failed = false, first; for (const release of [() => { __pui_Delay.cancelView(); }, () => { __pui_Presence.detach(); }]) { try { release(); } catch (error) { if (!failed) { failed = true; first = error; } } } if (failed) throw first; } } try { for (const fn of lifecycle[kind]) fn(run); } finally { if (kind === 'unmounted') { { let failed = false, first; for (const release of [() => { __pui_Delay.cancelView(); }, () => { __pui_Presence.detach(); }]) { try { release(); } catch (error) { if (!failed) { failed = true; first = error; } } } if (failed) throw first; } } } }, !terminal);
  const detach = () => {
    if (!viewActive) return;
    viewActive = false; pending = null; queued = false;
    
    
    
    
    fire('unmounted');
  };
  const afterCommit = () => {
    if (terminal) return;
    syncHost(true);
    const commit = renderedCommit;
    if (!commit) return;
    renderedCommit = null;
    const target = vm.$el;
    // Removal has already committed when Vue calls updated. Do not postpone its
    // unmount notification into a tick which may belong to a replacement view.
    if (!commit.present && commit.vnode.elm === target) { detach(); return; }
    vm.$nextTick(() => {
      if (terminal || commit.epoch !== epoch || commit.version !== commitVersion || vm.$el !== target || commit.vnode.elm !== target) return;
      if (!present || !hostActive) return;
      
      
      const kind = commit.kind;
      if (kind === 'mount' && !viewActive) {
        viewActive = true;
        
        
        
        
        
        fire('mounted');
        
      } else if (viewActive) {
        
        
        if (kind !== 'update' || !pending || pending.revision !== commit.revision) return;
        pending = null;
        const again = queued; queued = false;
        fire('updated');
        if (again && present && viewActive && !terminal && !pending) update();
      }
    });
  };
  const owner = {
    wrapPublic: __pui_WrapPublic,
    authored: __pui_Authored,
    delay: __pui_Delay,presence: __pui_Presence,meta: __pui_Meta,
    contextScope,
    host() { return viewActive && present && hostActive && !terminal ? vm.$el : null; },
    
    def,
    get resolvedProps() { return resolved; },
    
    initialize() {
      
      try {
        renderFunction = setup(owner);
        if (typeof renderFunction !== 'function') renderFunction = (renderer) => renderer.slot();
        phase = 'idle';
        syncHost(false);
        fire('created');
         unwatch = vm.$watch(() => hostRaw(), () => syncHost(true), { deep: true });
      } catch (error) {
        
        terminal = true;
        
        
        try { contextScope.dispose(); } catch {}
        disposed = true;
        phase = 'idle';
        throw error;
      }
    },
    hostMounted() {  nativeMounted = true; afterCommit(); },
    afterCommit,
    /** @param {import('vue').CreateElement} h */
    render(h) {
      
      if (terminal || !present || !hostActive) {
        const vnode = h();
        renderedCommit = { epoch, version: ++commitVersion, present: false, vnode, kind: 'detach' };
        return vnode;
      }
      if (!viewActive) renderSemantic();
      const tag = rootTag;
      const children = template ? template(h, vm, { used: false }) : [];
      if (['input', 'textarea', 'img'].includes(tag) && children.length) throw new Error('[Template] physical control Root requires empty children.');
      const rootData = { pre: true, attrs: { 'data-pui-root': '' } };
      const vnode = h(tag, rootData, children);
      renderedCommit = { epoch, version: ++commitVersion, present: true, vnode, kind: !viewActive ? 'mount' : pending ? 'update' : 'none', revision: pending && pending.revision };
      return vnode;
    },
    update,
    getExposes() { if (terminal) return {}; return { ...exposed }; },
    /** @template T @param {() => T} fn @returns {T} */
    invokePublic(fn) { publicAlive(); return invoke(fn); },
    deactivate() {
      if (terminal || !hostActive) return;
      hostActive = false; ++epoch; renderedCommit = null; pending = null; queued = false;
      detach();
    },
    activate() {
      if (terminal || hostActive) return;
      hostActive = true; ++epoch; pending = null; renderedCommit = null;
      vm.$forceUpdate();
    },
    dispose() {
      if (terminal) return;
      terminal = true; ++epoch; renderedCommit = null; pending = null; queued = false;
      for (const off of __pui_AuthoredWatchCleanups.splice(0)) off();
      unwatch?.(); unwatch = undefined;
      /** @type {{ error: unknown } | undefined} */ let failure;
      try { detach(); } catch (error) { failure = { error }; }
       try {
        fire('beforeDispose');
      } catch (error) { failure ??= { error }; }
      for (const state of states) {
        try { state.dispose(); } catch (error) { failure ??= { error }; }
      }
      try { contextScope.dispose(); } catch (error) { failure ??= { error }; }
      
      
      { let failed = false, first; for (const release of [() => { __pui_Delay.dispose(); }, () => { __pui_Presence.dispose(); }]) { try { release(); } catch (error) { if (!failed) { failed = true; first = error; } } } if (failed) throw first; }__pui_Authored.dispose();
      disposed = true; phase = 'idle';
      watchers.length = 0; notifications.length = 0; states.length = 0; defaults.length = 0;
      for (const callbacks of Object.values(lifecycle)) callbacks.length = 0;
      for (const key of Object.keys(exposed)) delete exposed[key];
      for (const key of Object.keys(eventDeclarations)) delete eventDeclarations[key];
      specs = Object.create(null); previousValid = Object.create(null); raw = Object.freeze({}); resolved = /** @type {__pui_ResolvedProps} */ (Object.freeze({})); template = renderFunction = null;
      
      if (failure) throw failure.error;
    },
  };
  return owner;
}


/** @param {__pui_Owner} __pui_Owner */
function __pui_Setup(__pui_Owner) {
  const __pui_WrapPublic = __pui_Owner.wrapPublic;
  const __pui_Authored = __pui_Owner.authored;
  const __pui_Delay = __pui_Owner.delay;  const __pui_Presence = __pui_Owner.presence;  const __pui_Meta = __pui_Owner.meta;
  // Source "transition/machine.ts":42:1
  const __puiModule0 = /** @param {{ "getState": () => "closed" | "preparing" | "entering" | "entered" | "leaving"; "setState": (state: "closed" | "preparing" | "entering" | "entered" | "leaving") => void; "getInterrupt": () => "reverse" | "wait" | "immediate"; "requiresColdPreparation"?: () => boolean; "getCompletion"?: () => (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number })); "publishPresentation"?: (frame: { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) => void; "settlePresentation"?: (outcome: "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed") => void; "getDuration": (state: "entering" | "leaving") => number; "schedule": (durationMs: number, callback: () => void) => __pui_DelayTask; "setViewPresent": (present: boolean) => void; "emit": (event: "beforeEnter" | "afterEnter" | "beforeLeave" | "afterLeave") => void }} driver @returns {{ "initialize": (open: boolean, appear: boolean) => void; "setTarget": (open: boolean) => void; "enter": () => void; "leave": () => void; "complete": () => void; "completePresentation": (attempt: { readonly "ownerEpoch": number; readonly "phaseAttempt": number }, isCurrent?: () => boolean) => boolean; "capturePreparation": () => ((() => void) | (null)); "mounted": () => void; "unmounted": () => void; "dispose": () => void }} */ (driver) => {
    // Source "transition/machine.ts":43:7
    /** @type {boolean} */
    let targetOpen = false;
    // Source "transition/machine.ts":44:7
    /** @type {boolean} */
    let viewMounted = false;
    // Source "transition/machine.ts":45:7
    /** @type {"enter" | "leave" | null} */
    let queuedIntent = /** @type {"enter" | "leave" | null} */ (null);
    // Source "transition/machine.ts":46:7
    /** @type {((__pui_DelayTask) | (null))} */
    let pendingTask = /** @type {((__pui_DelayTask) | (null))} */ (null);
    // Source "transition/machine.ts":47:7
    /** @type {number} */
    let generation = 0;
    // Source "transition/machine.ts":48:7
    /** @type {number} */
    let ownerEpoch = 0;
    // Source "transition/machine.ts":49:7
    /** @type {number} */
    let phaseAttempt = 0;
    // Source "transition/machine.ts":50:7
    /** @type {number} */
    let revision = 0;
    // Source "transition/machine.ts":51:7
    /** @type {boolean} */
    let publishing = false;
    // Source "transition/machine.ts":52:7
    /** @type {"closed" | "preparing" | "entering" | "entered" | "leaving" | null} */
    let stagedState = /** @type {"closed" | "preparing" | "entering" | "entered" | "leaving" | null} */ (null);
    // Source "transition/machine.ts":53:7
    /** @type {boolean} */
    let acknowledged = false;
    // Source "transition/machine.ts":54:7
    /** @type {((() => boolean) | (null))} */
    let acknowledgementCurrent = /** @type {((() => boolean) | (null))} */ (null);
    // Source "transition/machine.ts":55:7
    /** @type {boolean} */
    let invalidDuration = false;
    // Source "transition/machine.ts":56:7
    /** @type {boolean} */
    let publicationFailed = false;
    // Source "transition/machine.ts":57:7
    /** @type {(({ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) | (null))} */
    let activePresentation = /** @type {(({ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) | (null))} */ (null);
    // Source "transition/machine.ts":58:9
    const sameAttempt = /** @param {{ readonly "ownerEpoch": number; readonly "phaseAttempt": number }} attempt @returns {boolean} */ (attempt) => {
      // Source "transition/machine.ts":59:5
      return (((!terminal) && (((activePresentation)?.["attempt"])?.["ownerEpoch"] === (attempt)["ownerEpoch"])) && (((/** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (activePresentation))["attempt"])["phaseAttempt"] === (attempt)["phaseAttempt"]));
    };
    // Source "transition/machine.ts":62:9
    const cancelTask = /**  @returns {void} */ () => {
      // Source "transition/machine.ts":63:11
      const task = pendingTask;
      // Source "transition/machine.ts":64:5
      (pendingTask = null);
      // Source "transition/machine.ts":65:5
      try {
        // Source "transition/machine.ts":66:7
        ((__pui_OptionalReceiver) => __pui_OptionalReceiver == null ? undefined : __pui_OptionalReceiver.cancel())(task);
      } catch {
      }
    };
    // Source "transition/machine.ts":71:7
    /** @type {boolean} */
    let terminal = false;
    // Source "transition/machine.ts":72:7
    /** @type {number} */
    let operationVersion = 0;
    // Source "transition/machine.ts":73:7
    /** @type {{ "kind": "enter" | "leave"; "version": number } | null} */
    let starting = /** @type {{ "kind": "enter" | "leave"; "version": number } | null} */ (null);
    // Source "transition/machine.ts":74:9
    const currentOperation = /** @param {number} version @returns {boolean} */ (version) => {
      // Source "transition/machine.ts":74:49
      return ((!terminal) && (operationVersion === version));
    };
    // Source "transition/machine.ts":75:9
    const updateTarget = /** @param {boolean} open @returns {void} */ (open) => {
      // Source "transition/machine.ts":76:5
      if ((targetOpen !== open)) {
        // Source "transition/machine.ts":76:30
        (operationVersion = (operationVersion + 1));
      }
      // Source "transition/machine.ts":77:5
      (targetOpen = open);
    };
    // Source "transition/machine.ts":85:7
    /** @type {{ "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean } | null} */
    let preparation = /** @type {{ "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean } | null} */ (null);
    // Source "transition/machine.ts":87:9
    const cancelPreparation = /**  @returns {void} */ () => {
      // Source "transition/machine.ts":88:5
      (preparation = null);
    };
    // Source "transition/machine.ts":90:9
    const isPreparing = /** @param {{ "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }} attempt @returns {boolean} */ (attempt) => {
      // Source "transition/machine.ts":91:5
      return ((((!terminal) && targetOpen) && (preparation === attempt)) && (((driver)["getState"])() === "preparing"));
    };
    // Source "transition/machine.ts":93:9
    const finishPreparation = /** @param {{ "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }} attempt @returns {void} */ (attempt) => {
      // Source "transition/machine.ts":94:5
      if ((((((!(isPreparing)(attempt)) || (!(attempt)["presentRequested"])) || (!viewMounted)) || (!(attempt)["ready"])) || (attempt)["finishing"])) {
        // Source "transition/machine.ts":101:7
        return;
      }
      // Source "transition/machine.ts":102:5
      ((attempt)["finishing"] = true);
      // Source "transition/machine.ts":103:5
      if ((!(attempt)["animate"])) {
        // Source "transition/machine.ts":104:7
        (preparation = null);
        // Source "transition/machine.ts":105:7
        (setState)("entered");
        // Source "transition/machine.ts":106:7
        return;
      }
      // Source "transition/machine.ts":108:5
      ((driver)["emit"])("beforeEnter");
      // Source "transition/machine.ts":109:5
      if (((!(isPreparing)(attempt)) || (!viewMounted))) {
        // Source "transition/machine.ts":109:48
        return;
      }
      // Source "transition/machine.ts":110:11
      const frame = (setState)("entering");
      // Source "transition/machine.ts":111:5
      if (((((frame && (activePresentation === /** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (frame))) && (!terminal)) && viewMounted) && (((driver)["getState"])() === "entering"))) {
        // Source "transition/machine.ts":118:7
        if ((preparation === attempt)) {
          // Source "transition/machine.ts":118:36
          (preparation = null);
        }
        // Source "transition/machine.ts":119:7
        (armCompletion)("entering");
        // Source "transition/machine.ts":120:7
        return;
      }
      // Source "transition/machine.ts":122:5
      if ((((((preparation !== attempt) || terminal) || (!targetOpen)) || (!viewMounted)) || (((driver)["getState"])() !== "entering"))) {
        // Source "transition/machine.ts":129:7
        if ((preparation === attempt)) {
          // Source "transition/machine.ts":129:36
          (preparation = null);
        }
        // Source "transition/machine.ts":130:7
        return;
      }
      // Source "transition/machine.ts":132:5
      (preparation = null);
      // Source "transition/machine.ts":133:5
      (armCompletion)("entering");
    };
    // Source "transition/machine.ts":136:9
    const beginPreparation = /** @param {boolean} animate @returns {void} */ (animate) => {
      // Source "transition/machine.ts":137:11
      const operation = (++operationVersion);
      // Source "transition/machine.ts":138:5
      (invalidateCompletion)();
      // Source "transition/machine.ts":139:5
      if ((!((!terminal) && (operationVersion === operation)))) {
        // Source "transition/machine.ts":139:39
        return;
      }
      // Source "transition/machine.ts":140:5
      (queuedIntent = null);
      // Source "transition/machine.ts":141:11
      const attempt = /** @type {{ "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }} */ ({ ["ready"]: false, ["finishing"]: false, ["animate"]: animate, ["presentRequested"]: false });
      // Source "transition/machine.ts":147:5
      (preparation = attempt);
      // Source "transition/machine.ts":148:5
      (setState)("preparing");
      // Source "transition/machine.ts":149:5
      if ((!(isPreparing)(attempt))) {
        // Source "transition/machine.ts":149:32
        return;
      }
      // Source "transition/machine.ts":150:5
      ((driver)["setViewPresent"])(true);
      // Source "transition/machine.ts":151:5
      if ((!(isPreparing)(attempt))) {
        // Source "transition/machine.ts":151:32
        return;
      }
      // Source "transition/machine.ts":152:5
      ((attempt)["presentRequested"] = true);
      // Source "transition/machine.ts":153:5
      (finishPreparation)(attempt);
    };
    // Source "transition/machine.ts":156:9
    const invalidateCompletion = /**  @returns {void} */ () => {
      // Source "transition/machine.ts":157:5
      (generation = (generation + 1));
      // Source "transition/machine.ts":158:5
      (activePresentation = null);
      // Source "transition/machine.ts":159:5
      (acknowledged = false);
      // Source "transition/machine.ts":160:5
      (acknowledgementCurrent = null);
      // Source "transition/machine.ts":161:5
      (cancelTask)();
    };
    // Source "transition/machine.ts":164:9
    const setState = /** @param {"closed" | "preparing" | "entering" | "entered" | "leaving"} state @returns {(({ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) | (undefined))} */ (state) => {
      // Source "transition/machine.ts":165:11
      const policy = (((driver)["getCompletion"])?.() ?? "timer");
      // Source "transition/machine.ts":166:5
      if ((policy === "timer")) {
        // Source "transition/machine.ts":167:7
        ((driver)["setState"])(state);
        // Source "transition/machine.ts":168:7
        return;
      }
      // Source "transition/machine.ts":170:11
      const moving = ((state === "entering") || (/** @type {"closed" | "preparing" | "entered" | "leaving"} */ (state) === "leaving"));
      // Source "transition/machine.ts":171:11
      const duration = (moving ? ((driver)["getDuration"])(/** @type {"entering" | "leaving"} */ (state)) : 0);
      // Source "transition/machine.ts":172:5
      (invalidDuration = (((!Number.isFinite(duration)) || (duration < 0)) || (moving && (duration >= (/** @type {{ readonly "kind": "presentation"; readonly "timeoutMs": number }} */ (policy))["timeoutMs"]))));
      // Source "transition/machine.ts":174:5
      (publicationFailed = false);
      // Source "transition/machine.ts":175:11
      const frame = /** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ ((/** @type {{ "revision": number; "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; "attempt": { "ownerEpoch": number; "phaseAttempt": number } | null; "completion": "presentation"; "durationMs": number | 0; "timeoutMs": number }} */ (Object.freeze({ ["revision"]: (++revision), ["phase"]: state, ["attempt"]: (moving ? (/** @type {{ "ownerEpoch": number; "phaseAttempt": number }} */ (Object.freeze({ ["ownerEpoch"]: ownerEpoch, ["phaseAttempt"]: (++phaseAttempt) }))) : null), ["completion"]: "presentation", ["durationMs"]: ((Number.isFinite(duration) && (duration >= 0)) ? duration : (/** @type {{ readonly "kind": "presentation"; readonly "timeoutMs": number }} */ (policy))["timeoutMs"]), ["timeoutMs"]: (/** @type {{ readonly "kind": "presentation"; readonly "timeoutMs": number }} */ (policy))["timeoutMs"] }))));
      // Source "transition/machine.ts":184:5
      (activePresentation = (moving ? frame : null));
      // Source "transition/machine.ts":185:5
      (acknowledged = false);
      // Source "transition/machine.ts":186:11
      const operation = operationVersion;
      // Source "transition/machine.ts":187:11
      const previousStage = stagedState;
      // Source "transition/machine.ts":188:5
      (stagedState = state);
      // Source "transition/machine.ts":189:5
      (publishing = true);
      // Source "transition/machine.ts":190:5
      try {
        // Source "transition/machine.ts":191:7
        try {
          // Source "transition/machine.ts":192:9
          ((driver)["publishPresentation"])?.(frame);
        } catch {
          // Source "transition/machine.ts":194:9
          (publicationFailed = true);
        }
        // Source "transition/machine.ts":196:13
        const waitingOnSameAttempt = (((moving && (activePresentation === frame)) && (((driver)["getInterrupt"])() === "wait")) && (!terminal));
        // Source "transition/machine.ts":198:7
        if ((((!((!terminal) && (operationVersion === operation))) && (!waitingOnSameAttempt)) || (moving && (activePresentation !== frame)))) {
          // Source "transition/machine.ts":204:9
          if ((((!terminal) && moving) && (activePresentation === frame))) {
            // Source "transition/machine.ts":205:17
            const repairOperation = operationVersion;
            // Source "transition/machine.ts":206:11
            (invalidateCompletion)();
            // Source "transition/machine.ts":207:11
            if ((!((!terminal) && (operationVersion === repairOperation)))) {
              // Source "transition/machine.ts":207:51
              return;
            }
            // Source "transition/machine.ts":208:17
            const actual = ((driver)["getState"])();
            // Source "transition/machine.ts":209:17
            const repaired = (setState)(actual);
            // Source "transition/machine.ts":210:11
            if (((repaired && (activePresentation === /** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (repaired))) && ((actual === "entering") || (/** @type {"closed" | "preparing" | "entered" | "leaving"} */ (actual) === "leaving")))) {
              // Source "transition/machine.ts":215:13
              (armCompletion)(/** @type {"entering" | "leaving"} */ (actual));
            }
          }
          // Source "transition/machine.ts":217:9
          return;
        }
        // Source "transition/machine.ts":219:7
        ((driver)["setState"])(state);
      } finally {
        // Source "transition/machine.ts":221:7
        (stagedState = previousStage);
        // Source "transition/machine.ts":222:7
        (publishing = (previousStage !== null));
      }
      // Source "transition/machine.ts":224:5
      if (((((((((moving && acknowledged) && (activePresentation === frame)) && (!terminal)) && (((driver)["getState"])() === state)) && (acknowledgementCurrent)?.()) && (/** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (activePresentation) === frame)) && (!terminal)) && (((driver)["getState"])() === state))) {
        // Source "transition/machine.ts":235:7
        (completeCurrent)(true);
      }
      // Source "transition/machine.ts":236:5
      return frame;
    };
    // Source "transition/machine.ts":239:9
    const settlePresentation = /** @param {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} frame @param {"finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed"} outcome @returns {void} */ (frame, outcome) => {
      // Source "transition/machine.ts":240:5
      if (((!(frame)["attempt"]) || (!(sameAttempt)((/** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (frame))["attempt"])))) {
        // Source "transition/machine.ts":240:56
        return;
      }
      // Source "transition/machine.ts":241:5
      try {
        // Source "transition/machine.ts":242:7
        ((driver)["settlePresentation"])?.(outcome);
      } catch {
      }
      // Source "transition/machine.ts":246:5
      if ((sameAttempt)((/** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (frame))["attempt"])) {
        // Source "transition/machine.ts":246:37
        (completeCurrent)(true);
      }
    };
    // Source "transition/machine.ts":249:9
    const armCompletion = /** @param {"entering" | "leaving"} state @returns {void} */ (state) => {
      // Source "transition/machine.ts":250:11
      const frame = activePresentation;
      // Source "transition/machine.ts":251:5
      if ((frame)?.["attempt"]) {
        // Source "transition/machine.ts":252:7
        if (invalidDuration) {
          // Source "transition/machine.ts":253:9
          (settlePresentation)(/** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (frame), "invalid-policy");
          // Source "transition/machine.ts":254:9
          return;
        }
        // Source "transition/machine.ts":256:7
        if (publicationFailed) {
          // Source "transition/machine.ts":257:9
          (settlePresentation)(/** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (frame), "projection-failed");
          // Source "transition/machine.ts":258:9
          return;
        }
        // Source "transition/machine.ts":260:7
        if (((/** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (frame))["durationMs"] === 0)) {
          // Source "transition/machine.ts":261:9
          (settlePresentation)(/** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": 0; readonly "timeoutMs": number | null }} */ (frame), "zero-duration");
          // Source "transition/machine.ts":262:9
          return;
        }
        // Source "transition/machine.ts":264:7
        try {
          // Source "transition/machine.ts":265:15
          const task = ((driver)["schedule"])(/** @type {number} */ ((/** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (frame))["timeoutMs"]), /**  @returns {void} */ () => {
            // Source "transition/machine.ts":266:11
            if (((!(/** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (frame))["attempt"]) || (!(sameAttempt)((/** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (frame))["attempt"])))) {
              // Source "transition/machine.ts":266:62
              return;
            }
            // Source "transition/machine.ts":267:11
            (pendingTask = null);
            // Source "transition/machine.ts":268:11
            (settlePresentation)(/** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (frame), "deadline");
          });
          // Source "transition/machine.ts":270:9
          if ((sameAttempt)((/** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (frame))["attempt"])) {
            // Source "transition/machine.ts":270:41
            (pendingTask = task);
          } else {
            // Source "transition/machine.ts":272:11
            try {
              // Source "transition/machine.ts":273:13
              task.cancel();
            } catch {
            }
          }
        } catch {
          // Source "transition/machine.ts":277:9
          (settlePresentation)(/** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (frame), "scheduler-failed");
        }
        // Source "transition/machine.ts":279:7
        return;
      }
      // Source "transition/machine.ts":281:5
      (invalidateCompletion)();
      // Source "transition/machine.ts":282:11
      const activeGeneration = generation;
      // Source "transition/machine.ts":283:5
      (pendingTask = ((driver)["schedule"])(((driver)["getDuration"])(state), /**  @returns {void} */ () => {
        // Source "transition/machine.ts":284:7
        if (((activeGeneration !== generation) || (((driver)["getState"])() !== state))) {
          // Source "transition/machine.ts":284:75
          return;
        }
        // Source "transition/machine.ts":285:7
        (pendingTask = null);
        // Source "transition/machine.ts":286:7
        (completeCurrent)(true);
      }));
    };
    // Source "transition/machine.ts":290:9
    const beginEnter = /** @param {boolean} cold @returns {void} */ (cold = true) => {
      // Source "transition/machine.ts":291:5
      if ((terminal || (!targetOpen))) {
        // Source "transition/machine.ts":291:34
        return;
      }
      // Source "transition/machine.ts":292:5
      if ((((starting)?.["kind"] === "enter") && (currentOperation)((/** @type {{ "kind": "enter"; "version": number }} */ (starting))["version"]))) {
        // Source "transition/machine.ts":292:75
        return;
      }
      // Source "transition/machine.ts":293:5
      if ((cold && ((driver)["requiresColdPreparation"])?.())) {
        // Source "transition/machine.ts":294:7
        (beginPreparation)(true);
        // Source "transition/machine.ts":295:7
        return;
      }
      // Source "transition/machine.ts":297:11
      /** @type {{ "kind": "enter"; "version": number }} */
      const operation = { ["kind"]: "enter", ["version"]: (++operationVersion) };
      // Source "transition/machine.ts":298:5
      (starting = operation);
      // Source "transition/machine.ts":299:11
      const current = /**  @returns {boolean} */ () => {
        // Source "transition/machine.ts":299:27
        return ((currentOperation)((operation)["version"]) && targetOpen);
      };
      // Source "transition/machine.ts":300:5
      try {
        // Source "transition/machine.ts":301:7
        ((driver)["setViewPresent"])(true);
        // Source "transition/machine.ts":302:7
        if (((!(current)()) || (!viewMounted))) {
          // Source "transition/machine.ts":302:39
          return;
        }
        // Source "transition/machine.ts":303:7
        (queuedIntent = null);
        // Source "transition/machine.ts":304:7
        ((driver)["emit"])("beforeEnter");
        // Source "transition/machine.ts":305:7
        if (((!(current)()) || (!viewMounted))) {
          // Source "transition/machine.ts":305:39
          return;
        }
        // Source "transition/machine.ts":306:7
        (invalidateCompletion)();
        // Source "transition/machine.ts":307:7
        if ((!(current)())) {
          // Source "transition/machine.ts":307:23
          return;
        }
        // Source "transition/machine.ts":308:13
        const frame = (setState)("entering");
        // Source "transition/machine.ts":309:7
        if ((((((frame && (activePresentation === /** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (frame))) && ((/** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (activePresentation))?.["phase"] === "entering")) && (!terminal)) && viewMounted) && (((driver)["getState"])() === "entering"))) {
          // Source "transition/machine.ts":317:9
          (armCompletion)("entering");
          // Source "transition/machine.ts":318:9
          return;
        }
        // Source "transition/machine.ts":320:7
        if ((((!(current)()) || (!viewMounted)) || (((driver)["getState"])() !== "entering"))) {
          // Source "transition/machine.ts":320:75
          return;
        }
        // Source "transition/machine.ts":321:7
        (armCompletion)("entering");
      } finally {
        // Source "transition/machine.ts":323:7
        if ((starting === operation)) {
          // Source "transition/machine.ts":323:35
          (starting = null);
        }
      }
    };
    // Source "transition/machine.ts":327:9
    const beginLeave = /**  @returns {void} */ () => {
      // Source "transition/machine.ts":328:5
      if ((terminal || targetOpen)) {
        // Source "transition/machine.ts":328:33
        return;
      }
      // Source "transition/machine.ts":329:11
      /** @type {{ "kind": "leave"; "version": number }} */
      const operation = { ["kind"]: "leave", ["version"]: (++operationVersion) };
      // Source "transition/machine.ts":330:5
      (starting = operation);
      // Source "transition/machine.ts":331:11
      const current = /**  @returns {boolean} */ () => {
        // Source "transition/machine.ts":331:27
        return ((currentOperation)((operation)["version"]) && (!targetOpen));
      };
      // Source "transition/machine.ts":332:5
      try {
        // Source "transition/machine.ts":333:7
        (queuedIntent = null);
        // Source "transition/machine.ts":334:7
        ((driver)["emit"])("beforeLeave");
        // Source "transition/machine.ts":335:7
        if ((!(current)())) {
          // Source "transition/machine.ts":335:23
          return;
        }
        // Source "transition/machine.ts":336:7
        (invalidateCompletion)();
        // Source "transition/machine.ts":337:7
        if ((!(current)())) {
          // Source "transition/machine.ts":337:23
          return;
        }
        // Source "transition/machine.ts":338:13
        const frame = (setState)("leaving");
        // Source "transition/machine.ts":339:7
        if (((((frame && (activePresentation === /** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (frame))) && ((/** @type {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} */ (activePresentation))?.["phase"] === "leaving")) && (!terminal)) && (((driver)["getState"])() === "leaving"))) {
          // Source "transition/machine.ts":346:9
          (armCompletion)("leaving");
          // Source "transition/machine.ts":347:9
          return;
        }
        // Source "transition/machine.ts":349:7
        if (((!(current)()) || (((driver)["getState"])() !== "leaving"))) {
          // Source "transition/machine.ts":349:58
          return;
        }
        // Source "transition/machine.ts":350:7
        (armCompletion)("leaving");
      } finally {
        // Source "transition/machine.ts":352:7
        if ((starting === operation)) {
          // Source "transition/machine.ts":352:35
          (starting = null);
        }
      }
    };
    // Source "transition/machine.ts":356:9
    const consumeQueuedIntent = /**  @returns {void} */ () => {
      // Source "transition/machine.ts":357:11
      const next = queuedIntent;
      // Source "transition/machine.ts":358:5
      (queuedIntent = null);
      // Source "transition/machine.ts":359:5
      if ((next === "enter")) {
        // Source "transition/machine.ts":359:27
        (enter)();
      } else {
        // Source "transition/machine.ts":360:10
        if ((/** @type {"leave" | null} */ (next) === "leave")) {
          // Source "transition/machine.ts":360:32
          (leave)();
        }
      }
    };
    // Source "transition/machine.ts":363:9
    const completeCurrent = /** @param {boolean} consumeQueue @returns {boolean} */ (consumeQueue) => {
      // Source "transition/machine.ts":364:11
      const current = ((driver)["getState"])();
      // Source "transition/machine.ts":365:5
      if (((current !== "entering") && (/** @type {"closed" | "preparing" | "entered" | "leaving"} */ (current) !== "leaving"))) {
        // Source "transition/machine.ts":365:58
        return false;
      }
      // Source "transition/machine.ts":366:11
      const operation = (++operationVersion);
      // Source "transition/machine.ts":367:5
      (invalidateCompletion)();
      // Source "transition/machine.ts":368:5
      if ((!((!terminal) && (operationVersion === operation)))) {
        // Source "transition/machine.ts":368:39
        return false;
      }
      // Source "transition/machine.ts":370:5
      if ((/** @type {"entering" | "leaving"} */ (current) === "entering")) {
        // Source "transition/machine.ts":371:7
        (setState)("entered");
        // Source "transition/machine.ts":372:7
        if (((!((!terminal) && (operationVersion === operation))) || (((driver)["getState"])() !== "entered"))) {
          // Source "transition/machine.ts":372:76
          return false;
        }
        // Source "transition/machine.ts":373:7
        ((driver)["emit"])("afterEnter");
      } else {
        // Source "transition/machine.ts":375:7
        (setState)("closed");
        // Source "transition/machine.ts":376:7
        if (((!((!terminal) && (operationVersion === operation))) || (((driver)["getState"])() !== "closed"))) {
          // Source "transition/machine.ts":376:75
          return false;
        }
        // Source "transition/machine.ts":377:7
        ((driver)["emit"])("afterLeave");
        // Source "transition/machine.ts":378:7
        if (((!((!terminal) && (operationVersion === operation))) || (((driver)["getState"])() !== "closed"))) {
          // Source "transition/machine.ts":378:75
          return false;
        }
        // Source "transition/machine.ts":379:7
        ((driver)["setViewPresent"])(false);
      }
      // Source "transition/machine.ts":382:5
      if ((consumeQueue && ((!terminal) && (operationVersion === operation)))) {
        // Source "transition/machine.ts":382:54
        (consumeQueuedIntent)();
      }
      // Source "transition/machine.ts":383:5
      return ((!terminal) && (operationVersion === operation));
    };
    // Source "transition/machine.ts":386:9
    const enter = /**  @returns {void} */ () => {
      // Source "transition/machine.ts":387:5
      if (terminal) {
        // Source "transition/machine.ts":387:19
        return;
      }
      // Source "transition/machine.ts":388:5
      (updateTarget)(true);
      // Source "transition/machine.ts":389:5
      if ((((starting)?.["kind"] === "enter") && (currentOperation)((/** @type {{ "kind": "enter"; "version": number }} */ (starting))["version"]))) {
        // Source "transition/machine.ts":389:75
        return;
      }
      // Source "transition/machine.ts":390:11
      const current = (stagedState ?? ((driver)["getState"])());
      // Source "transition/machine.ts":391:5
      if (((current === "entered") || (/** @type {"closed" | "preparing" | "entering" | "leaving"} */ (current) === "preparing"))) {
        // Source "transition/machine.ts":391:59
        return;
      }
      // Source "transition/machine.ts":393:5
      if ((/** @type {"closed" | "entering" | "leaving"} */ (current) === "closed")) {
        // Source "transition/machine.ts":394:7
        (beginEnter)();
        // Source "transition/machine.ts":395:7
        return;
      }
      // Source "transition/machine.ts":398:5
      if ((/** @type {"entering" | "leaving"} */ (current) === "entering")) {
        // Source "transition/machine.ts":399:7
        if ((((((/** @type {{ "kind": "leave"; "version": number } | null | { "kind": "enter"; "version": number }} */ (starting))?.["kind"] === "leave") && (!activePresentation)) && (((driver)["getCompletion"])?.() !== "timer")) && (driver)["getCompletion"])) {
          // Source "transition/machine.ts":405:9
          (beginEnter)(false);
          // Source "transition/machine.ts":406:9
          return;
        }
        // Source "transition/machine.ts":408:7
        if ((((driver)["getInterrupt"])() === "wait")) {
          // Source "transition/machine.ts":408:45
          (queuedIntent = null);
        }
        // Source "transition/machine.ts":409:7
        return;
      }
      // Source "transition/machine.ts":412:11
      const interrupt = ((driver)["getInterrupt"])();
      // Source "transition/machine.ts":413:5
      if ((interrupt === "wait")) {
        // Source "transition/machine.ts":414:7
        (queuedIntent = "enter");
      } else {
        // Source "transition/machine.ts":415:12
        if ((/** @type {"reverse" | "immediate"} */ (interrupt) === "immediate")) {
          // Source "transition/machine.ts":416:7
          if ((completeCurrent)(false)) {
            // Source "transition/machine.ts":416:35
            (beginEnter)(false);
          }
        } else {
          // Source "transition/machine.ts":418:7
          (beginEnter)(false);
        }
      }
    };
    // Source "transition/machine.ts":422:9
    const leave = /**  @returns {void} */ () => {
      // Source "transition/machine.ts":423:5
      if (terminal) {
        // Source "transition/machine.ts":423:19
        return;
      }
      // Source "transition/machine.ts":424:5
      (updateTarget)(false);
      // Source "transition/machine.ts":425:5
      if ((((starting)?.["kind"] === "leave") && (currentOperation)((/** @type {{ "kind": "leave"; "version": number }} */ (starting))["version"]))) {
        // Source "transition/machine.ts":425:75
        return;
      }
      // Source "transition/machine.ts":426:11
      const current = (stagedState ?? ((driver)["getState"])());
      // Source "transition/machine.ts":427:5
      if ((current === "preparing")) {
        // Source "transition/machine.ts":428:7
        (cancelPreparation)();
        // Source "transition/machine.ts":429:7
        (invalidateCompletion)();
        // Source "transition/machine.ts":430:7
        (queuedIntent = null);
        // Source "transition/machine.ts":431:7
        (setState)("closed");
        // Source "transition/machine.ts":432:7
        if (((!targetOpen) && (((driver)["getState"])() === "closed"))) {
          // Source "transition/machine.ts":432:58
          ((driver)["setViewPresent"])(false);
        }
        // Source "transition/machine.ts":433:7
        return;
      }
      // Source "transition/machine.ts":436:5
      if ((/** @type {"closed" | "entering" | "entered" | "leaving"} */ (current) === "closed")) {
        // Source "transition/machine.ts":437:7
        ((driver)["setViewPresent"])(false);
        // Source "transition/machine.ts":438:7
        return;
      }
      // Source "transition/machine.ts":441:5
      if ((/** @type {"entering" | "entered" | "leaving"} */ (current) === "leaving")) {
        // Source "transition/machine.ts":442:7
        if ((((((/** @type {{ "kind": "enter"; "version": number } | null | { "kind": "leave"; "version": number }} */ (starting))?.["kind"] === "enter") && (!activePresentation)) && (((driver)["getCompletion"])?.() !== "timer")) && (driver)["getCompletion"])) {
          // Source "transition/machine.ts":448:9
          (beginLeave)();
          // Source "transition/machine.ts":449:9
          return;
        }
        // Source "transition/machine.ts":451:7
        if ((((driver)["getInterrupt"])() === "wait")) {
          // Source "transition/machine.ts":451:45
          (queuedIntent = null);
        }
        // Source "transition/machine.ts":452:7
        return;
      }
      // Source "transition/machine.ts":455:5
      if ((/** @type {"entering" | "entered"} */ (current) === "entered")) {
        // Source "transition/machine.ts":456:7
        (beginLeave)();
        // Source "transition/machine.ts":457:7
        return;
      }
      // Source "transition/machine.ts":460:11
      const interrupt = ((driver)["getInterrupt"])();
      // Source "transition/machine.ts":461:5
      if ((interrupt === "wait")) {
        // Source "transition/machine.ts":462:7
        (queuedIntent = "leave");
      } else {
        // Source "transition/machine.ts":463:12
        if ((/** @type {"reverse" | "immediate"} */ (interrupt) === "immediate")) {
          // Source "transition/machine.ts":464:7
          if ((completeCurrent)(false)) {
            // Source "transition/machine.ts":464:35
            (beginLeave)();
          }
        } else {
          // Source "transition/machine.ts":466:7
          (beginLeave)();
        }
      }
    };
    // Source "transition/machine.ts":470:9
    const initialize = /** @param {boolean} open @param {boolean} appear @returns {void} */ (open, appear) => {
      // Source "transition/machine.ts":471:5
      if (terminal) {
        // Source "transition/machine.ts":471:19
        return;
      }
      // Source "transition/machine.ts":472:11
      const operation = (++operationVersion);
      // Source "transition/machine.ts":473:5
      (ownerEpoch = (ownerEpoch + 1));
      // Source "transition/machine.ts":474:5
      (cancelPreparation)();
      // Source "transition/machine.ts":475:5
      (targetOpen = open);
      // Source "transition/machine.ts":476:5
      (queuedIntent = null);
      // Source "transition/machine.ts":477:5
      (invalidateCompletion)();
      // Source "transition/machine.ts":478:5
      if ((!((!terminal) && (operationVersion === operation)))) {
        // Source "transition/machine.ts":478:39
        return;
      }
      // Source "transition/machine.ts":480:5
      if ((!open)) {
        // Source "transition/machine.ts":481:7
        (setState)("closed");
        // Source "transition/machine.ts":482:7
        if (((!((!terminal) && (operationVersion === operation))) || targetOpen)) {
          // Source "transition/machine.ts":482:55
          return;
        }
        // Source "transition/machine.ts":483:7
        ((driver)["setViewPresent"])(false);
        // Source "transition/machine.ts":484:7
        return;
      }
      // Source "transition/machine.ts":487:5
      if (((driver)["requiresColdPreparation"])?.()) {
        // Source "transition/machine.ts":488:7
        (beginPreparation)(appear);
        // Source "transition/machine.ts":489:7
        return;
      }
      // Source "transition/machine.ts":491:5
      ((driver)["setViewPresent"])(true);
      // Source "transition/machine.ts":492:5
      if (((!((!terminal) && (operationVersion === operation))) || (!targetOpen))) {
        // Source "transition/machine.ts":492:54
        return;
      }
      // Source "transition/machine.ts":493:5
      if ((!appear)) {
        // Source "transition/machine.ts":493:18
        (setState)("entered");
      }
    };
    // Source "transition/machine.ts":496:9
    const mounted = /**  @returns {void} */ () => {
      // Source "transition/machine.ts":497:5
      if (terminal) {
        // Source "transition/machine.ts":497:19
        return;
      }
      // Source "transition/machine.ts":498:5
      (viewMounted = true);
      // Source "transition/machine.ts":499:5
      if (preparation) {
        // Source "transition/machine.ts":500:7
        (finishPreparation)(/** @type {{ "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }} */ (preparation));
        // Source "transition/machine.ts":501:7
        return;
      }
      // Source "transition/machine.ts":503:5
      if ((targetOpen && (((driver)["getState"])() === "closed"))) {
        // Source "transition/machine.ts":503:55
        (beginEnter)();
      }
    };
    // Source "transition/machine.ts":506:9
    const unmounted = /**  @returns {void} */ () => {
      // Source "transition/machine.ts":507:5
      (ownerEpoch = (ownerEpoch + 1));
      // Source "transition/machine.ts":508:11
      const operation = (++operationVersion);
      // Source "transition/machine.ts":509:5
      (cancelPreparation)();
      // Source "transition/machine.ts":510:5
      (viewMounted = false);
      // Source "transition/machine.ts":511:5
      (invalidateCompletion)();
      // Source "transition/machine.ts":512:5
      if ((!((!terminal) && (operationVersion === operation)))) {
        // Source "transition/machine.ts":512:39
        return;
      }
      // Source "transition/machine.ts":513:5
      (queuedIntent = null);
      // Source "transition/machine.ts":514:5
      if ((((driver)["getState"])() !== "closed")) {
        // Source "transition/machine.ts":514:41
        (setState)("closed");
      }
    };
    // Source "transition/machine.ts":517:9
    const dispose = /**  @returns {void} */ () => {
      // Source "transition/machine.ts":518:5
      (terminal = true);
      // Source "transition/machine.ts":519:5
      (ownerEpoch = (ownerEpoch + 1));
      // Source "transition/machine.ts":520:5
      (operationVersion = (operationVersion + 1));
      // Source "transition/machine.ts":521:5
      (cancelPreparation)();
      // Source "transition/machine.ts":522:5
      (viewMounted = false);
      // Source "transition/machine.ts":523:5
      (queuedIntent = null);
      // Source "transition/machine.ts":524:5
      (invalidateCompletion)();
    };
    // Source "transition/machine.ts":527:3
    return { ["initialize"]: initialize, ["setTarget"]: /** @param {boolean} open @returns {void} */ (open) => {
      // Source "transition/machine.ts":530:7
      if (terminal) {
        // Source "transition/machine.ts":530:21
        return;
      }
      // Source "transition/machine.ts":531:7
      if ((open === targetOpen)) {
        // Source "transition/machine.ts":531:32
        return;
      }
      // Source "transition/machine.ts":532:7
      if (open) {
        // Source "transition/machine.ts":532:17
        (enter)();
      } else {
        // Source "transition/machine.ts":533:12
        (leave)();
      }
    }, ["enter"]: enter, ["leave"]: leave, ["complete"]: /**  @returns {void} */ () => {
      // Source "transition/machine.ts":538:7
      if ((!terminal)) {
        // Source "transition/machine.ts":538:22
        (completeCurrent)(true);
      }
    }, ["completePresentation"]: /** @param {{ readonly "ownerEpoch": number; readonly "phaseAttempt": number }} attempt @param {() => boolean} isCurrent @returns {boolean} */ (attempt, isCurrent = /**  @returns {boolean} */ () => {
      // Source "transition/machine.ts":540:55
      return true;
    }) => {
      // Source "transition/machine.ts":541:13
      const validate = /**  @returns {boolean} */ () => {
        // Source "transition/machine.ts":542:9
        try {
          // Source "transition/machine.ts":543:11
          return (isCurrent)();
        } catch {
          // Source "transition/machine.ts":545:11
          return false;
        }
      };
      // Source "transition/machine.ts":548:7
      if ((((!(sameAttempt)(attempt)) || (!(validate)())) || (!(sameAttempt)(attempt)))) {
        // Source "transition/machine.ts":548:74
        return false;
      }
      // Source "transition/machine.ts":549:7
      if (publishing) {
        // Source "transition/machine.ts":550:9
        (acknowledged = true);
        // Source "transition/machine.ts":551:9
        (acknowledgementCurrent = validate);
        // Source "transition/machine.ts":552:9
        return true;
      }
      // Source "transition/machine.ts":554:7
      return (completeCurrent)(true);
    }, ["capturePreparation"]: /**  @returns {((() => void) | (null))} */ () => {
      // Source "transition/machine.ts":557:13
      const attempt = preparation;
      // Source "transition/machine.ts":558:7
      if (((!attempt) || (!(isPreparing)(/** @type {{ "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }} */ (attempt))))) {
        // Source "transition/machine.ts":558:46
        return null;
      }
      // Source "transition/machine.ts":559:7
      return /**  @returns {void} */ () => {
        // Source "transition/machine.ts":560:9
        if (((!(isPreparing)(/** @type {{ "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }} */ (attempt))) || (/** @type {{ "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }} */ (attempt))["finishing"])) {
          // Source "transition/machine.ts":560:57
          return;
        }
        // Source "transition/machine.ts":561:9
        ((/** @type {{ "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }} */ (attempt))["ready"] = true);
        // Source "transition/machine.ts":562:9
        (finishPreparation)(/** @type {{ "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }} */ (attempt));
      };
    }, ["mounted"]: mounted, ["unmounted"]: unmounted, ["dispose"]: dispose };
  };
  const __pui_Hook0 = /** @param {unknown} [options] */ (options) => /** @type {{ "transitionState": __pui_OwnedState<string> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<string>) => void): () => void}; "isPresent": __pui_OwnedState<boolean> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void}; "controls": { "capturePreparation": () => ((() => void) | (null)); "enter": () => void; "leave": () => void; "complete": () => void }; "configure": (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void; "bindInitialOpen": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void; "bindOpenContext": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void; "retainClosedView": (retained: boolean) => void; "presentationOwner": Readonly<object> }} */ (__pui_Authored.install({name: "asTransition", mode: "once", setup: (options, api) => (/** @param {__pui_Owner['def']} def */ (def) => {
    // Source "transition/as-transition.proto.ts":42:5
    (() => {
const __pui_CaptureReceiver = def;
/** @type {Parameters<typeof __pui_CaptureReceiver.props.define>[0]} */ const __pui_CaptureArg0 = { ["open"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["defaultOpen"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["appear"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["enterDuration"]: { ["type"]: "number", ["empty"]: "fallback" }, ["leaveDuration"]: { ["type"]: "number", ["empty"]: "fallback" }, ["interrupt"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["reverse", "wait", "immediate"] } };
const __pui_CaptureResult = __pui_CaptureReceiver.props.define(__pui_CaptureArg0); __pui_Authored.effect("props", {"op": "define", "specMap": __pui_CaptureArg0}); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":54:5
    (() => {
const __pui_CaptureReceiver = def;
/** @type {{ "defaultOpen": boolean; "appear": boolean; "enterDuration": number; "leaveDuration": number; "interrupt": string }} */ const __pui_CaptureArg0 = { ["defaultOpen"]: false, ["appear"]: false, ["enterDuration"]: 300, ["leaveDuration"]: 200, ["interrupt"]: "reverse" };
const __pui_CaptureResult = __pui_CaptureReceiver.props.setDefaults(__pui_CaptureArg0); __pui_Authored.effect("props", {"op": "setDefaults", "partial": __pui_CaptureArg0}); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":62:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "beforeEnter";
/** @type {{ "payload": "void" }} */ const __pui_CaptureArg1 = { ["payload"]: "void" };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.event(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("event", {"op": "expose.event", "key": __pui_CaptureArg0, "spec": __pui_CaptureArg1}); __pui_Authored.eventKey(__pui_CaptureArg0); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":63:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "afterEnter";
/** @type {{ "payload": "void" }} */ const __pui_CaptureArg1 = { ["payload"]: "void" };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.event(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("event", {"op": "expose.event", "key": __pui_CaptureArg0, "spec": __pui_CaptureArg1}); __pui_Authored.eventKey(__pui_CaptureArg0); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":64:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "beforeLeave";
/** @type {{ "payload": "void" }} */ const __pui_CaptureArg1 = { ["payload"]: "void" };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.event(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("event", {"op": "expose.event", "key": __pui_CaptureArg0, "spec": __pui_CaptureArg1}); __pui_Authored.eventKey(__pui_CaptureArg0); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":65:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "afterLeave";
/** @type {{ "payload": "void" }} */ const __pui_CaptureArg1 = { ["payload"]: "void" };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.event(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("event", {"op": "expose.event", "key": __pui_CaptureArg0, "spec": __pui_CaptureArg1}); __pui_Authored.eventKey(__pui_CaptureArg0); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":67:11
    const transitionState = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "transitionState";
const __pui_CaptureArg1 = "closed";
/** @type {{ "options": ReadonlyArray<"closed" | "preparing" | "entering" | "entered" | "leaving"> }} */ const __pui_CaptureArg2 = { ["options"]: ["closed", "preparing", "entering", "entered", "leaving"] };
const __pui_CaptureResult = __pui_CaptureReceiver.state.enum(__pui_CaptureArg0, __pui_CaptureArg1, __pui_CaptureArg2); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":72:11
    const isPresent = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "isPresent";
const __pui_CaptureArg1 = false;
const __pui_CaptureResult = __pui_CaptureReceiver.state.bool(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":73:11
    const appearDefault = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "transitionAppearDefault";
const __pui_CaptureArg1 = false;
const __pui_CaptureResult = __pui_CaptureReceiver.state.bool(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":74:11
    const coldEntryPreparation = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "transitionColdEntryPreparation";
const __pui_CaptureArg1 = false;
const __pui_CaptureResult = __pui_CaptureReceiver.state.bool(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":75:11
    const enterDurationDefault = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "transitionEnterDurationDefault";
const __pui_CaptureArg1 = 300;
const __pui_CaptureResult = __pui_CaptureReceiver.state.numberDiscrete(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":76:11
    const leaveDurationDefault = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "transitionLeaveDurationDefault";
const __pui_CaptureArg1 = 200;
const __pui_CaptureResult = __pui_CaptureReceiver.state.numberDiscrete(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":77:11
    const interruptDefault = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "transitionInterruptDefault";
const __pui_CaptureArg1 = "reverse";
/** @type {{ "options": ReadonlyArray<"reverse" | "wait" | "immediate"> }} */ const __pui_CaptureArg2 = { ["options"]: ["reverse", "wait", "immediate"] };
const __pui_CaptureResult = __pui_CaptureReceiver.state.enum(__pui_CaptureArg0, __pui_CaptureArg1, __pui_CaptureArg2); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":83:9
    /** @type {(({ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) | (null))} */
    let initialOpenSource = /** @type {(({ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) | (null))} */ (null);
    // Source "transition/as-transition.proto.ts":85:9
    /** @type {(({ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) | (null))} */
    let openContextSource = /** @type {(({ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) | (null))} */ (null);
    // Source "transition/as-transition.proto.ts":87:11
    const closedViewRetained = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "transitionClosedViewRetained";
const __pui_CaptureArg1 = false;
const __pui_CaptureResult = __pui_CaptureReceiver.state.bool(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":88:11
    const bindInitialOpen = /** @param {{ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }} source @returns {void} */ (source) => {
      // Source "transition/as-transition.proto.ts":90:7
      appearDefault.setDefault(/** @type {boolean} */ (appearDefault.get()));
      // Source "transition/as-transition.proto.ts":91:7
      if ((((((!source) || ((typeof (source)["field"]) !== "string")) || (!(source)["field"])) || (!(source)["context"])) || (((source)["context"])["__brand"] !== "ContextKey"))) {
        // Source "transition/as-transition.proto.ts":98:9
        throw new Error("[asTransition] initial open source requires a ContextKey and direct field.");
      }
      // Source "transition/as-transition.proto.ts":102:7
      if (initialOpenSource) {
        // Source "transition/as-transition.proto.ts":103:9
        if ((((/** @type {{ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }} */ (initialOpenSource))["context"] === (source)["context"]) && ((/** @type {{ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }} */ (initialOpenSource))["field"] === (source)["field"]))) {
          // Source "transition/as-transition.proto.ts":107:11
          return;
        }
        // Source "transition/as-transition.proto.ts":108:9
        throw new Error("[asTransition] initial open source is already bound.");
      }
      // Source "transition/as-transition.proto.ts":110:7
      (initialOpenSource = (/** @type {{ "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; "field": string }} */ (Object.freeze({ ["context"]: (source)["context"], ["field"]: (source)["field"] }))));
    };
    // Source "transition/as-transition.proto.ts":112:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "bindInitialOpen";
const __pui_CaptureArg1 = bindInitialOpen;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":114:11
    const presentation = (void (def), __pui_Presence.owner());
    // Source "transition/as-transition.proto.ts":115:9
    /** @type {(("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }))} */
    let completion = /** @type {(("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }))} */ ("timer");
    // Source "transition/as-transition.proto.ts":116:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "getPresentationOwner";
const __pui_CaptureArg1 = /**  @returns {Readonly<object>} */ () => {
      // Source "transition/as-transition.proto.ts":116:53
      return (presentation)["ref"];
    };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":117:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "configurePresentation";
const __pui_CaptureArg1 = /** @param {{ "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }} config @returns {void} */ (config) => {
      // Source "transition/as-transition.proto.ts":118:7
      appearDefault.setDefault(/** @type {boolean} */ (appearDefault.get()));
      // Source "transition/as-transition.proto.ts":119:13
      const policy = __pui_SnapshotCompletion(((config)["completion"] ?? completion));
      // Source "transition/as-transition.proto.ts":120:13
      const enter = ((config)["enterDuration"] ?? /** @type {number} */ (enterDurationDefault.get()));
      // Source "transition/as-transition.proto.ts":121:13
      const leave = ((config)["leaveDuration"] ?? /** @type {number} */ (leaveDurationDefault.get()));
      // Source "transition/as-transition.proto.ts":122:7
      if ((!([enter, leave]).every(/** @param {number} value @returns {boolean} */ (value) => {
        // Source "transition/as-transition.proto.ts":122:44
        return (Number.isFinite(value) && (value >= 0));
      }))) {
        // Source "transition/as-transition.proto.ts":123:9
        throw new Error("[asTransition] durations must be finite non-negative numbers.");
      }
      // Source "transition/as-transition.proto.ts":124:7
      if (((policy !== "timer") && ((enter >= (/** @type {{ readonly "kind": "presentation"; readonly "timeoutMs": number }} */ (policy))["timeoutMs"]) || (leave >= (/** @type {{ readonly "kind": "presentation"; readonly "timeoutMs": number }} */ (policy))["timeoutMs"])))) {
        // Source "transition/as-transition.proto.ts":125:9
        throw new Error("[asTransition] presentation duration must be shorter than timeoutMs.");
      }
      // Source "transition/as-transition.proto.ts":126:7
      (completion = policy);
    };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":128:9
    /** @type {((__pui_Run) | (null))} */
    let currentRun = /** @type {((__pui_Run) | (null))} */ (null);
    // Source "transition/as-transition.proto.ts":132:9
    /** @type {boolean} */
    let phaseViewRequested = false;
    // Source "transition/as-transition.proto.ts":133:11
    const getProps = /**  @returns {((__pui_ResolvedProps) | (undefined))} */ () => {
      // Source "transition/as-transition.proto.ts":133:28
      return ((__pui_OptionalReceiver) => __pui_OptionalReceiver == null ? undefined : __pui_OptionalReceiver.props.get())(currentRun);
    };
    // Source "transition/as-transition.proto.ts":135:11
    const driver = /** @type {{ "getState": () => "closed" | "preparing" | "entering" | "entered" | "leaving"; "setState": (state: "closed" | "preparing" | "entering" | "entered" | "leaving") => void; "getInterrupt": () => "reverse" | "wait" | "immediate"; "requiresColdPreparation"?: () => boolean; "getCompletion"?: () => (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number })); "publishPresentation"?: (frame: { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) => void; "settlePresentation"?: (outcome: "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed") => void; "getDuration": (state: "entering" | "leaving") => number; "schedule": (durationMs: number, callback: () => void) => __pui_DelayTask; "setViewPresent": (present: boolean) => void; "emit": (event: "beforeEnter" | "afterEnter" | "beforeLeave" | "afterLeave") => void }} */ ({ ["getState"]: /**  @returns {"closed" | "preparing" | "entering" | "entered" | "leaving"} */ () => {
      // Source "transition/as-transition.proto.ts":136:23
      return /** @type {"closed" | "preparing" | "entering" | "entered" | "leaving"} */ (transitionState.get());
    }, ["setState"]: /** @param {"closed" | "preparing" | "entering" | "entered" | "leaving"} state @returns {void} */ (state) => {
      // Source "transition/as-transition.proto.ts":138:9
      transitionState.set(state, ("reason: asTransition => " + state));
      // Source "transition/as-transition.proto.ts":140:9
      if ((!currentRun)) {
        // Source "transition/as-transition.proto.ts":140:26
        return;
      }
      // Source "transition/as-transition.proto.ts":142:15
      const currentState = /** @type {"closed" | "preparing" | "entering" | "entered" | "leaving"} */ (transitionState.get());
      // Source "transition/as-transition.proto.ts":143:9
      isPresent.set((currentState !== "closed"), ("reason: asTransition presence => " + currentState));
    }, ["requiresColdPreparation"]: /**  @returns {boolean} */ () => {
      // Source "transition/as-transition.proto.ts":148:38
      return /** @type {boolean} */ (coldEntryPreparation.get());
    }, ["getCompletion"]: /**  @returns {(("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }))} */ () => {
      // Source "transition/as-transition.proto.ts":149:28
      return completion;
    }, ["publishPresentation"]: /** @param {{ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }} frame @returns {void} */ (frame) => {
      // Source "transition/as-transition.proto.ts":151:9
      return ((__pui_OptionalReceiver) => __pui_OptionalReceiver == null ? undefined : (void (__pui_OptionalReceiver), __pui_Presence.publish((presentation)["writer"], ({ ...(frame), ["owner"]: (presentation)["ref"] }))))(currentRun);
    }, ["settlePresentation"]: /** @param {"finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed"} outcome @returns {void} */ (outcome) => {
      // Source "transition/as-transition.proto.ts":156:9
      return ((__pui_OptionalReceiver) => __pui_OptionalReceiver == null ? undefined : (void (__pui_OptionalReceiver), __pui_Presence.settle((presentation)["writer"], outcome)))(currentRun);
    }, ["getInterrupt"]: /**  @returns {"reverse" | "wait" | "immediate"} */ () => {
      // Source "transition/as-transition.proto.ts":158:9
      return (((__pui_OptionalReceiver) => __pui_OptionalReceiver == null ? undefined : __pui_OptionalReceiver.props.isProvided("interrupt"))(currentRun) ? (((getProps)())?.["interrupt"] ?? /** @type {"reverse" | "wait" | "immediate"} */ (interruptDefault.get())) : /** @type {"reverse" | "wait" | "immediate"} */ (interruptDefault.get()));
    }, ["getDuration"]: /** @param {"entering" | "leaving"} state @returns {number} */ (state) => {
      // Source "transition/as-transition.proto.ts":165:9
      if ((((__pui_OptionalReceiver) => __pui_OptionalReceiver == null ? undefined : (void (__pui_OptionalReceiver), __pui_Meta("reducedMotion")))(currentRun) === "reduce")) {
        // Source "transition/as-transition.proto.ts":165:66
        return 0;
      }
      // Source "transition/as-transition.proto.ts":166:9
      return ((state === "entering") ? (((__pui_OptionalReceiver) => __pui_OptionalReceiver == null ? undefined : __pui_OptionalReceiver.props.isProvided("enterDuration"))(currentRun) ? (((getProps)())?.["enterDuration"] ?? /** @type {number} */ (enterDurationDefault.get())) : /** @type {number} */ (enterDurationDefault.get())) : (((__pui_OptionalReceiver) => __pui_OptionalReceiver == null ? undefined : __pui_OptionalReceiver.props.isProvided("leaveDuration"))(currentRun) ? (((getProps)())?.["leaveDuration"] ?? /** @type {number} */ (leaveDurationDefault.get())) : /** @type {number} */ (leaveDurationDefault.get())));
    }, ["schedule"]: /** @param {number} durationMs @param {() => void} callback @returns {__pui_DelayTask} */ (durationMs, callback) => {
      // Source "transition/as-transition.proto.ts":174:43
      return __pui_Delay.schedule(durationMs, callback);
    }, ["setViewPresent"]: /** @param {boolean} present @returns {void} */ (present) => {
      // Source "transition/as-transition.proto.ts":176:9
      if ((!currentRun)) {
        // Source "transition/as-transition.proto.ts":177:11
        throw new Error("[asTransition] runtime lifecycle handle is not available.");
      }
      // Source "transition/as-transition.proto.ts":179:9
      (phaseViewRequested = present);
      // Source "transition/as-transition.proto.ts":180:9
      /** @type {__pui_Run} */ (currentRun).lifecycle.setPresent((phaseViewRequested || /** @type {boolean} */ (closedViewRetained.get())));
    }, ["emit"]: /** @param {"beforeEnter" | "afterEnter" | "beforeLeave" | "afterLeave"} event @returns {void} */ (event) => {
      // Source "transition/as-transition.proto.ts":183:9
      ((__pui_OptionalReceiver) => __pui_OptionalReceiver == null ? undefined : __pui_OptionalReceiver.expose.emit(event))(currentRun);
    } });
    // Source "transition/as-transition.proto.ts":186:11
    const machine = __puiModule0(driver);
    // Source "transition/as-transition.proto.ts":187:5
    presentation.onCompletionRequest(/** @param {__pui_Run} run @param {{ readonly "receipt": { readonly "owner": Readonly<object>; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "viewBinding": Readonly<object>; readonly "ownerRevision": number; readonly "targetRevision": number; readonly "channels": ReadonlyArray<"translate" | "opacity">; readonly "outcome": "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed" } }} request */ (run, request) => {
      // Source "transition/as-transition.proto.ts":188:7
      if ((!currentRun)) {
        // Source "transition/as-transition.proto.ts":188:24
        return;
      }
      // Source "transition/as-transition.proto.ts":189:7
      if ((!(void (run), __pui_Presence.isCurrent((presentation)["writer"], (request)["receipt"])))) {
        // Source "transition/as-transition.proto.ts":189:83
        return;
      }
      // Source "transition/as-transition.proto.ts":190:7
      ((machine)["completePresentation"])(((request)["receipt"])["attempt"], /**  @returns {boolean} */ () => {
        // Source "transition/as-transition.proto.ts":192:15
        return ((!(!currentRun)) && (void (run), __pui_Presence.isCurrent((presentation)["writer"], (request)["receipt"])));
      });
    });
    // Source "transition/as-transition.proto.ts":196:11
    /** @type {{ "enter": () => void; "leave": () => void; "complete": () => void; "capturePreparation": () => ((() => void) | (null)) }} */
    const controls = { ["enter"]: /**  @returns {void} */ () => {
      // Source "transition/as-transition.proto.ts":198:9
      if (openContextSource) {
        // Source "transition/as-transition.proto.ts":199:11
        if (currentRun) {
          // Source "transition/as-transition.proto.ts":199:27
          ((machine)["setTarget"])((contextOpen)(/** @type {__pui_Run} */ (currentRun), /** @type {{ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }} */ (openContextSource)));
        }
      } else {
        // Source "transition/as-transition.proto.ts":200:16
        ((machine)["enter"])();
      }
    }, ["leave"]: /**  @returns {void} */ () => {
      // Source "transition/as-transition.proto.ts":203:9
      if (openContextSource) {
        // Source "transition/as-transition.proto.ts":204:11
        if (currentRun) {
          // Source "transition/as-transition.proto.ts":204:27
          ((machine)["setTarget"])((contextOpen)(/** @type {__pui_Run} */ (currentRun), /** @type {{ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }} */ (openContextSource)));
        }
      } else {
        // Source "transition/as-transition.proto.ts":205:16
        ((machine)["leave"])();
      }
    }, ["complete"]: /**  @returns {void} */ () => {
      // Source "transition/as-transition.proto.ts":207:23
      return ((machine)["complete"])();
    }, ["capturePreparation"]: /**  @returns {((() => void) | (null))} */ () => {
      // Source "transition/as-transition.proto.ts":209:9
      if ((!currentRun)) {
        // Source "transition/as-transition.proto.ts":210:11
        throw new Error("[asTransition] preparation capture requires a live runtime.");
      }
      // Source "transition/as-transition.proto.ts":211:9
      return ((machine)["capturePreparation"])();
    } };
    // Source "transition/as-transition.proto.ts":214:11
    const contextOpen = /** @param {__pui_Run} run @param {{ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }} source @returns {boolean} */ (run, source) => {
      // Source "transition/as-transition.proto.ts":218:13
      const value = run.context.read((source)["context"]);
      // Source "transition/as-transition.proto.ts":219:13
      const target = (value)[(source)["field"]];
      // Source "transition/as-transition.proto.ts":220:7
      if (((!Object.hasOwn(value, (source)["field"])) || ((typeof target) !== "boolean"))) {
        // Source "transition/as-transition.proto.ts":221:9
        throw new Error("[asTransition] open context field must be a required boolean.");
      }
      // Source "transition/as-transition.proto.ts":222:7
      return /** @type {boolean} */ (target);
    };
    // Source "transition/as-transition.proto.ts":224:11
    const bindOpenContext = /** @param {{ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }} source @returns {void} */ (source) => {
      // Source "transition/as-transition.proto.ts":225:7
      appearDefault.setDefault(/** @type {boolean} */ (appearDefault.get()));
      // Source "transition/as-transition.proto.ts":226:7
      if ((((((!source) || ((typeof (source)["field"]) !== "string")) || (!(source)["field"])) || (!(source)["context"])) || (((source)["context"])["__brand"] !== "ContextKey"))) {
        // Source "transition/as-transition.proto.ts":233:9
        throw new Error("[asTransition] open context source requires a ContextKey and direct field.");
      }
      // Source "transition/as-transition.proto.ts":236:7
      if (openContextSource) {
        // Source "transition/as-transition.proto.ts":237:9
        if ((((/** @type {{ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }} */ (openContextSource))["context"] === (source)["context"]) && ((/** @type {{ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }} */ (openContextSource))["field"] === (source)["field"]))) {
          // Source "transition/as-transition.proto.ts":241:11
          return;
        }
        // Source "transition/as-transition.proto.ts":242:9
        throw new Error("[asTransition] open context source is already bound.");
      }
      // Source "transition/as-transition.proto.ts":244:7
      (openContextSource = (/** @type {{ "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; "field": string }} */ (Object.freeze({ ["context"]: (source)["context"], ["field"]: (source)["field"] }))));
      // Source "transition/as-transition.proto.ts":245:7
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = (source)["context"];
const __pui_CaptureArg1 = /** @param {__pui_Run} run */ (run) => {
        // Source "transition/as-transition.proto.ts":246:9
        (currentRun = run);
        // Source "transition/as-transition.proto.ts":247:9
        ((machine)["setTarget"])((contextOpen)(run, /** @type {{ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }} */ (openContextSource)));
      };
const __pui_CaptureResult = __pui_CaptureReceiver.context.subscribe(__pui_CaptureArg0, /** @type {(run: __pui_Run, next: unknown, previous: unknown) => void} */ (__pui_CaptureArg1)); __pui_Authored.effect("context", {"op": "subscribe", "key": __pui_CaptureArg0, "off": __pui_CaptureResult}); __pui_Authored.disposer("context", __pui_CaptureResult); return __pui_CaptureResult; })();
    };
    // Source "transition/as-transition.proto.ts":250:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "bindOpenContext";
const __pui_CaptureArg1 = bindOpenContext;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":251:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "retainClosedView";
const __pui_CaptureArg1 = /** @param {boolean} retained @returns {void} */ (retained) => {
      // Source "transition/as-transition.proto.ts":252:7
      closedViewRetained.set((!(!retained)), "reason: transition closed-view retention policy");
      // Source "transition/as-transition.proto.ts":253:7
      if ((!currentRun)) {
        // Source "transition/as-transition.proto.ts":253:24
        return;
      }
      // Source "transition/as-transition.proto.ts":254:7
      /** @type {__pui_Run} */ (currentRun).lifecycle.setPresent((phaseViewRequested || /** @type {boolean} */ (closedViewRetained.get())));
    };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":257:5
    def.lifecycle.onCreated(/** @param {__pui_Run} run */ (run) => {
      // Source "transition/as-transition.proto.ts":258:7
      (currentRun = run);
      // Source "transition/as-transition.proto.ts":259:13
      const props = run.props.get();
      // Source "transition/as-transition.proto.ts":260:13
      const controlled = run.props.isProvided("open");
      // Source "transition/as-transition.proto.ts":261:11
      /** @type {boolean} */
      let open = (controlled ? (!(!(props)["open"])) : (!(!(props)["defaultOpen"])));
      // Source "transition/as-transition.proto.ts":262:7
      if (openContextSource) {
        // Source "transition/as-transition.proto.ts":263:9
        (open = (contextOpen)(run, /** @type {{ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }} */ (openContextSource)));
      } else {
        // Source "transition/as-transition.proto.ts":264:14
        if ((((!controlled) && (!run.props.isProvided("defaultOpen"))) && initialOpenSource)) {
          // Source "transition/as-transition.proto.ts":265:15
          const value = run.context.read((/** @type {{ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }} */ (initialOpenSource))["context"]);
          // Source "transition/as-transition.proto.ts":266:15
          const initialOpen = (value)[(/** @type {{ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }} */ (initialOpenSource))["field"]];
          // Source "transition/as-transition.proto.ts":267:9
          if (((!Object.hasOwn(value, (/** @type {{ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }} */ (initialOpenSource))["field"])) || ((typeof initialOpen) !== "boolean"))) {
            // Source "transition/as-transition.proto.ts":268:11
            throw new Error("[asTransition] initial open context field must be a required boolean.");
          }
          // Source "transition/as-transition.proto.ts":270:9
          (open = /** @type {boolean} */ (initialOpen));
        }
      }
      // Source "transition/as-transition.proto.ts":272:13
      const appear = (run.props.isProvided("appear") ? (!(!(props)["appear"])) : /** @type {boolean} */ (appearDefault.get()));
      // Source "transition/as-transition.proto.ts":273:7
      ((machine)["initialize"])(open, appear);
    });
    // Source "transition/as-transition.proto.ts":276:5
    def.lifecycle.onMounted(/** @param {__pui_Run} run */ (run) => {
      // Source "transition/as-transition.proto.ts":277:7
      (currentRun = run);
      // Source "transition/as-transition.proto.ts":278:7
      ((machine)["mounted"])();
    });
    // Source "transition/as-transition.proto.ts":281:5
    def.lifecycle.onUnmounted(/** @param {__pui_Run} run */ (run) => {
      // Source "transition/as-transition.proto.ts":282:7
      (currentRun = run);
      // Source "transition/as-transition.proto.ts":283:7
      ((machine)["unmounted"])();
    });
    // Source "transition/as-transition.proto.ts":286:5
    def.lifecycle.onBeforeDispose(() => {
      // Source "transition/as-transition.proto.ts":287:7
      ((machine)["dispose"])();
      // Source "transition/as-transition.proto.ts":288:7
      (currentRun = null);
    });
    // Source "transition/as-transition.proto.ts":291:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = ["open", "interrupt", "enterDuration", "leaveDuration"];
const __pui_CaptureArg1 = /** @param {__pui_Run} run @param {__pui_ResolvedProps} next */ (run, next) => {
      // Source "transition/as-transition.proto.ts":292:7
      (currentRun = run);
      // Source "transition/as-transition.proto.ts":293:7
      if ((openContextSource || (!run.props.isProvided("open")))) {
        // Source "transition/as-transition.proto.ts":293:63
        return;
      }
      // Source "transition/as-transition.proto.ts":294:7
      ((machine)["setTarget"])((!(!(next)["open"])));
    };
const __pui_CaptureResult = __pui_CaptureReceiver.props.watch(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("props", {"op": "watch", "keys": __pui_CaptureArg0, "off": __pui_CaptureResult}); __pui_Authored.disposer("props", __pui_CaptureResult); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":297:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "transitionState";
const __pui_CaptureArg1 = transitionState;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.state(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", {"op": "expose.state", "key": __pui_CaptureArg0, "handle": __pui_CaptureArg1}); __pui_Authored.introduceObserved(__pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":298:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "isPresent";
const __pui_CaptureArg1 = isPresent;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.state(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", {"op": "expose.state", "key": __pui_CaptureArg0, "handle": __pui_CaptureArg1}); __pui_Authored.introduceObserved(__pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":299:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "enter";
const __pui_CaptureArg1 = (controls)["enter"];
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":300:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "leave";
const __pui_CaptureArg1 = (controls)["leave"];
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":301:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "complete";
const __pui_CaptureArg1 = (controls)["complete"];
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":302:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "capturePreparation";
const __pui_CaptureArg1 = (controls)["capturePreparation"];
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1, (__pui_PublicResult) => ((__pui_PublicValue0) => (typeof __pui_PublicValue0 === 'function' ? __pui_WrapPublic(__pui_PublicValue0) : (__pui_PublicValue0)))(__pui_PublicResult)); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
    // Source "transition/as-transition.proto.ts":303:5
    (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "controls";
const __pui_CaptureArg1 = controls;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.value(__pui_CaptureArg0, ((__pui_PublicValue0) => (__pui_PublicValue0 !== null && typeof __pui_PublicValue0 === 'object' ? __pui_WrapPublic.record(__pui_PublicValue0, __pui_PublicValue0Record => { if (Object.hasOwn(__pui_PublicValue0, "enter")) Object.defineProperty(__pui_PublicValue0Record, "enter", { value: ((__pui_PublicValue1) => (typeof __pui_PublicValue1 === 'function' ? __pui_WrapPublic(__pui_PublicValue1, __pui_PublicValue0) : (__pui_PublicValue1)))(/** @type {() => void} */ (__pui_PublicValue0["enter"])), enumerable: true, configurable: true, writable: true }); if (Object.hasOwn(__pui_PublicValue0, "leave")) Object.defineProperty(__pui_PublicValue0Record, "leave", { value: ((__pui_PublicValue2) => (typeof __pui_PublicValue2 === 'function' ? __pui_WrapPublic(__pui_PublicValue2, __pui_PublicValue0) : (__pui_PublicValue2)))(/** @type {() => void} */ (__pui_PublicValue0["leave"])), enumerable: true, configurable: true, writable: true }); if (Object.hasOwn(__pui_PublicValue0, "complete")) Object.defineProperty(__pui_PublicValue0Record, "complete", { value: ((__pui_PublicValue3) => (typeof __pui_PublicValue3 === 'function' ? __pui_WrapPublic(__pui_PublicValue3, __pui_PublicValue0) : (__pui_PublicValue3)))(/** @type {() => void} */ (__pui_PublicValue0["complete"])), enumerable: true, configurable: true, writable: true }); if (Object.hasOwn(__pui_PublicValue0, "capturePreparation")) Object.defineProperty(__pui_PublicValue0Record, "capturePreparation", { value: ((__pui_PublicValue4) => (typeof __pui_PublicValue4 === 'function' ? __pui_WrapPublic(__pui_PublicValue4, __pui_PublicValue0, (__pui_PublicValue4Result) => ((__pui_PublicValue5) => (typeof __pui_PublicValue5 === 'function' ? __pui_WrapPublic(__pui_PublicValue5) : (__pui_PublicValue5)))(__pui_PublicValue4Result), "7f8ad435c936065d") : (__pui_PublicValue4)))(/** @type {() => ((() => void) | (null))} */ (__pui_PublicValue0["capturePreparation"])), enumerable: true, configurable: true, writable: true }); }) : __pui_PublicValue0))(__pui_CaptureArg1)); __pui_Authored.effect("context", {"op": "expose.value", "key": __pui_CaptureArg0, "value": __pui_CaptureArg1}); return __pui_CaptureResult; })();
  })(__pui_Owner.def), project: /** @param {{ readonly stateHandles?: Readonly<Record<string, unknown>>; readonly getState?: (name: string) => unknown; readonly getMethod?: (name: string) => unknown; readonly getAsHook?: (name: string) => unknown; readonly getAsHookHandle?: (name: string) => unknown; readonly render?: unknown }} result @returns {{ "transitionState": __pui_OwnedState<string> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<string>) => void): () => void}; "isPresent": __pui_OwnedState<boolean> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void}; "controls": { "capturePreparation": () => ((() => void) | (null)); "enter": () => void; "leave": () => void; "complete": () => void }; "configure": (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void; "bindInitialOpen": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void; "bindOpenContext": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void; "retainClosedView": (retained: boolean) => void; "presentationOwner": Readonly<object> }} */ (result) => {
    // Source "transition/as-transition.proto.ts":306:11
    const transitionState = __puiModule1(/** @type {((__pui_OwnedState<string> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<string>) => void): () => void}) | (undefined))} */ (result.getState?.("transitionState")), "transitionState");
    // Source "transition/as-transition.proto.ts":310:11
    const isPresent = __puiModule2(/** @type {((__pui_OwnedState<boolean> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void}) | (undefined))} */ (result.getState?.("isPresent")), "isPresent");
    // Source "transition/as-transition.proto.ts":311:11
    /** @type {{ "capturePreparation": () => ((() => void) | (null)); "enter": () => void; "leave": () => void; "complete": () => void }} */
    const controls = { ["capturePreparation"]: __puiModule3(/** @type {((() => ((() => void) | (null))) | (undefined))} */ (result.getMethod?.("capturePreparation")), "capturePreparation"), ["enter"]: __puiModule4(/** @type {((() => void) | (undefined))} */ (result.getMethod?.("enter")), "enter"), ["leave"]: __puiModule5(/** @type {((() => void) | (undefined))} */ (result.getMethod?.("leave")), "leave"), ["complete"]: __puiModule6(/** @type {((() => void) | (undefined))} */ (result.getMethod?.("complete")), "complete") };
    // Source "transition/as-transition.proto.ts":330:11
    const appearDefault = __puiModule7(/** @type {((__pui_OwnedState<boolean> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void}) | (undefined))} */ (result.getState?.("transitionAppearDefault")), "transitionAppearDefault");
    // Source "transition/as-transition.proto.ts":334:11
    const enterDurationDefault = __puiModule8(/** @type {((__pui_OwnedState<number> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<number>) => void): () => void}) | (undefined))} */ (result.getState?.("transitionEnterDurationDefault")), "transitionEnterDurationDefault");
    // Source "transition/as-transition.proto.ts":338:11
    const leaveDurationDefault = __puiModule9(/** @type {((__pui_OwnedState<number> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<number>) => void): () => void}) | (undefined))} */ (result.getState?.("transitionLeaveDurationDefault")), "transitionLeaveDurationDefault");
    // Source "transition/as-transition.proto.ts":342:11
    const interruptDefault = __puiModule10(/** @type {((__pui_OwnedState<string> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<string>) => void): () => void}) | (undefined))} */ (result.getState?.("transitionInterruptDefault")), "transitionInterruptDefault");
    // Source "transition/as-transition.proto.ts":347:11
    const coldEntryPreparation = __puiModule11(/** @type {((__pui_OwnedState<boolean> & {watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void}) | (undefined))} */ (result.getState?.("transitionColdEntryPreparation")), "transitionColdEntryPreparation");
    // Source "transition/as-transition.proto.ts":352:11
    const configurePresentation = __puiModule12(/** @type {(((config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void) | (undefined))} */ (result.getMethod?.("configurePresentation")), "configurePresentation");
    // Source "transition/as-transition.proto.ts":358:11
    const getPresentationOwner = __puiModule13(/** @type {((() => Readonly<object>) | (undefined))} */ (result.getMethod?.("getPresentationOwner")), "getPresentationOwner");
    // Source "transition/as-transition.proto.ts":362:11
    const configure = /** @param {{ "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }} config @returns {void} */ (config) => {
      // Source "transition/as-transition.proto.ts":364:7
      (configurePresentation)(config);
      // Source "transition/as-transition.proto.ts":365:11
      /** @type {boolean} */
      let configured = false;
      // Source "transition/as-transition.proto.ts":366:7
      if (((typeof (config)["coldEntryPreparation"]) !== "undefined")) {
        // Source "transition/as-transition.proto.ts":367:9
        coldEntryPreparation.setDefault((/** @type {{ "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation": boolean; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }} */ (config))["coldEntryPreparation"]);
        // Source "transition/as-transition.proto.ts":368:9
        (configured = true);
      }
      // Source "transition/as-transition.proto.ts":370:7
      if (((typeof (config)["appear"]) !== "undefined")) {
        // Source "transition/as-transition.proto.ts":371:9
        appearDefault.setDefault((/** @type {{ "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear": boolean; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }} */ (config))["appear"]);
        // Source "transition/as-transition.proto.ts":372:9
        (configured = true);
      }
      // Source "transition/as-transition.proto.ts":374:7
      if (((typeof (config)["enterDuration"]) !== "undefined")) {
        // Source "transition/as-transition.proto.ts":375:9
        if (((!Number.isFinite((/** @type {{ "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration": number; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }} */ (config))["enterDuration"])) || ((/** @type {{ "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration": number; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }} */ (config))["enterDuration"] < 0))) {
          // Source "transition/as-transition.proto.ts":376:11
          throw new Error("[asTransition] enterDuration must be a finite non-negative number.");
        }
        // Source "transition/as-transition.proto.ts":378:9
        enterDurationDefault.setDefault((/** @type {{ "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration": number; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }} */ (config))["enterDuration"]);
        // Source "transition/as-transition.proto.ts":379:9
        (configured = true);
      }
      // Source "transition/as-transition.proto.ts":381:7
      if (((typeof (config)["leaveDuration"]) !== "undefined")) {
        // Source "transition/as-transition.proto.ts":382:9
        if (((!Number.isFinite((/** @type {{ "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration": number; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }} */ (config))["leaveDuration"])) || ((/** @type {{ "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration": number; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }} */ (config))["leaveDuration"] < 0))) {
          // Source "transition/as-transition.proto.ts":383:11
          throw new Error("[asTransition] leaveDuration must be a finite non-negative number.");
        }
        // Source "transition/as-transition.proto.ts":385:9
        leaveDurationDefault.setDefault((/** @type {{ "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration": number; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }} */ (config))["leaveDuration"]);
        // Source "transition/as-transition.proto.ts":386:9
        (configured = true);
      }
      // Source "transition/as-transition.proto.ts":388:7
      if (((typeof (config)["interrupt"]) !== "undefined")) {
        // Source "transition/as-transition.proto.ts":389:9
        interruptDefault.setDefault((/** @type {{ "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt": "reverse" | "wait" | "immediate" }} */ (config))["interrupt"]);
        // Source "transition/as-transition.proto.ts":390:9
        (configured = true);
      }
      // Source "transition/as-transition.proto.ts":393:7
      if ((!/** @type {true | boolean} */ (configured))) {
        // Source "transition/as-transition.proto.ts":393:24
        appearDefault.setDefault(/** @type {boolean} */ (appearDefault.get()));
      }
    };
    // Source "transition/as-transition.proto.ts":396:11
    const bindInitialOpen = __puiModule14(/** @type {(((source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void) | (undefined))} */ (result.getMethod?.("bindInitialOpen")), "bindInitialOpen");
    // Source "transition/as-transition.proto.ts":400:11
    const bindOpenContext = __puiModule15(/** @type {(((source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void) | (undefined))} */ (result.getMethod?.("bindOpenContext")), "bindOpenContext");
    // Source "transition/as-transition.proto.ts":404:11
    const retainClosedView = __puiModule16(/** @type {(((retained: boolean) => void) | (undefined))} */ (result.getMethod?.("retainClosedView")), "retainClosedView");
    // Source "transition/as-transition.proto.ts":408:5
    return { ["transitionState"]: transitionState, ["isPresent"]: isPresent, ["controls"]: controls, ["configure"]: configure, ["bindInitialOpen"]: bindInitialOpen, ["bindOpenContext"]: bindOpenContext, ["retainClosedView"]: retainClosedView, ["presentationOwner"]: (getPresentationOwner)() };
  }}, options));
  /** @type {((renderer: __pui_NativeRenderer) => ((__pui_NativePaint))) | void} */
  const __pui_AuthoredRenderer = (() => {
    // Source "entry.proto.ts":4:3
    ((__pui_Hook0())["configure"])({ ["coldEntryPreparation"]: true, ["appear"]: false, ["enterDuration"]: 200, ["leaveDuration"]: 500 });
    // Source "entry.proto.ts":5:3
    return /** @param {__pui_NativeRenderer} r */ (r) => {
      // Source "entry.proto.ts":5:13
      return (/** @param {unknown} __pui_Receiver0 @param {string} __pui_Tag1 @param {Array<((string | number) | __pui_NativePaint)>} __pui_Arg2 */ (__pui_Receiver0, __pui_Tag1, __pui_Arg2) => {
      
      return /** @type {__pui_NativePaint} */ ((__pui_H5, __pui_Vm6, __pui_Slots7) => {
        /** @type {__pui_NativeChildren} */ const __pui_Children8 = [];
        for (const __pui_Child10 of __pui_Arg2) { if (typeof __pui_Child10 === 'function') { __pui_Children8.push(.../** @type {__pui_NativePaint} */ (__pui_Child10)(__pui_H5, __pui_Vm6, __pui_Slots7)); } else if (typeof __pui_Child10 === 'string' || typeof __pui_Child10 === 'number') { __pui_Children8.push('' + (__pui_Child10)); } else { throw new TypeError('[Vue2 native] invalid template child.'); } }
        /** @type {import('vue').VNodeData & { pre: true }} */ const __pui_Data9 = { pre: true };
        return [__pui_H5(__pui_Tag1, __pui_Data9, __pui_Children8)];
      });
    })(r, "section", ["Transition view ", (/** @param {unknown} __pui_Receiver11 */ (__pui_Receiver11) =>
      /** @type {__pui_NativePaint} */ ((__pui_H12, __pui_Vm13, __pui_Slots14) => {
        if (__pui_Slots14.used) throw new Error('[Vue2 native] only one default slot is supported.');
        __pui_Slots14.used = true;
        const scoped = __pui_Vm13.$scopedSlots.default;
        return (scoped ? scoped({}) : __pui_Vm13.$slots.default) || [];
      }))(r)]);
    };
  })();
  if (typeof __pui_AuthoredRenderer !== 'function') return __pui_AuthoredRenderer;
  return (/** @param {__pui_NativeRenderer} __pui_Renderer */ (__pui_Renderer) => (/** @param {((__pui_NativePaint))} __pui_Committed15 */ (__pui_Committed15) => /** @type {__pui_NativePaint} */ ((__pui_H16, __pui_Vm17, __pui_Slots18) => {
      /** @type {__pui_NativeChildren} */ const __pui_Children19 = [];
      if (typeof __pui_Committed15 === 'function') { __pui_Children19.push(.../** @type {__pui_NativePaint} */ (__pui_Committed15)(__pui_H16, __pui_Vm17, __pui_Slots18)); } else { throw new TypeError('[Vue2 native] invalid template child.'); }
      return __pui_Children19;
    }))(__pui_AuthoredRenderer(__pui_Renderer)));
}

/** @typedef {import('vue').default & { readonly "__pui_Owner": ReturnType<typeof __pui_CreateOwner>; readonly "__pui_ParentScope"?: ReturnType<typeof __pui_CreateContextScope> | null }} __pui_NativeInstance */
export const CompiledComponent = {
  name: "browser-transition-prepared",
  inheritAttrs: false,
  props: { instanceAssociations: { type: Object, default: undefined }, ["open"]: {}, ["defaultOpen"]: {}, ["appear"]: {}, ["enterDuration"]: {}, ["leaveDuration"]: {}, ["interrupt"]: {} },
  inject: { ["__pui_ParentScope"]: { from: __pui_ScopeKey, default: null } },
  /** @this {__pui_NativeInstance} */
  provide() { return { [__pui_ScopeKey]: this["__pui_Owner"].contextScope }; },
  /** @this {__pui_NativeInstance} */
  beforeCreate() {
    Object.defineProperty(this, "__pui_Owner", { value: __pui_CreateOwner(this, __pui_Setup, {"open":"boolean","defaultOpen":"boolean","appear":"boolean","enterDuration":"number","leaveDuration":"number","interrupt":{"kind":"union","members":[{"kind":"literal","value":"reverse"},{"kind":"literal","value":"wait"},{"kind":"literal","value":"immediate"}]}}, "div", true) });
    
  },
  /** @this {__pui_NativeInstance} */
  created() { this["__pui_Owner"].initialize(); },
  /** @this {__pui_NativeInstance} */
  mounted() { this["__pui_Owner"].hostMounted(); },
  /** @this {__pui_NativeInstance} */
  updated() { this["__pui_Owner"].afterCommit(); },
  /** @this {__pui_NativeInstance} */
  activated() { this["__pui_Owner"].activate(); },
  /** @this {__pui_NativeInstance} */
  deactivated() { this["__pui_Owner"].deactivate(); },
  /** @this {__pui_NativeInstance} */
  beforeDestroy() { this["__pui_Owner"].dispose(); },
  methods: {
    /** @this {__pui_NativeInstance} */
    update() { this["__pui_Owner"].update(); },
    /** @this {__pui_NativeInstance} */
    getExposes() { return this["__pui_Owner"].getExposes(); },
    /** @this {__pui_NativeInstance} @template T @param {() => T} callback */
    invokeInCallbackScope(callback) { return this["__pui_Owner"].invokePublic(callback); },
  },
  /** @this {__pui_NativeInstance} @param {import('vue').CreateElement} h */
  render(h) { return this["__pui_Owner"].render(h); },
};
export default CompiledComponent;


//# sourceMappingURL=Component.js.map
