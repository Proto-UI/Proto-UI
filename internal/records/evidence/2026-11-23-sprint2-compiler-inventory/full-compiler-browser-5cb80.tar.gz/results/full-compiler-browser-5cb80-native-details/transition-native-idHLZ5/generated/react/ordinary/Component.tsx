// Editable generated React DOM source. Profile: react-dom-source-v1.
// Inline owner lowering and emitted shared checked-data/Context helpers v1; no Proto-UI Runtime/Core/Adapter dependencies.
// Source graph SHA-256: 9a882481b587669e560b652879d04b517a0c8a79a9eeea8c386df889dd50f050
import * as __pui_React from 'react';
import { createNativeDelay as __pui_CreateDelay, type NativeDelayTask as __pui_DelayTask } from './.proto-ui/async/delay-web-v1';
import { createNativePresence as __pui_CreatePresence, snapshotNativeCompletion as __pui_SnapshotCompletion, type NativePresenceOwner as __pui_PresenceOwner } from './.proto-ui/async/presence-owner-v1';
import { readNativeWebMeta as __pui_ReadMeta } from './.proto-ui/meta/web-snapshot-v1';
import { createNativePublicCalls as __pui_CreatePublicCalls } from './.proto-ui/owner/public-callables-v1';

import { createNativeAuthoredHooks as __pui_CreateAuthored } from './.proto-ui/owner/authored-hooks-v1';




import { createContextScope as __pui_CreateContextScope, acceptsContextValue as __pui_Accepts } from "./.proto-ui/context/scope-v1";
import type { ContextScope as __pui_ContextScope } from "./.proto-ui/context/scope-v1";
import { ContextTransport as __pui_ContextTransport } from './.proto-ui/context/react-v1';







// Source "transition/as-transition.proto.ts":23:1
const __puiModule1 = (value: ((__pui_State<string> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<string>) => void): () => void }) | (undefined)), name: "transitionState"): __pui_State<string> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<string>) => void): () => void } => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule2 = (value: ((__pui_State<boolean> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void }) | (undefined)), name: "isPresent"): __pui_State<boolean> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void } => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule3 = (value: ((() => ((() => void) | (null))) | (undefined)), name: "capturePreparation"): () => ((() => void) | (null)) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule4 = (value: ((() => void) | (undefined)), name: "enter"): () => void => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule5 = (value: ((() => void) | (undefined)), name: "leave"): () => void => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule6 = (value: ((() => void) | (undefined)), name: "complete"): () => void => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule7 = (value: ((__pui_State<boolean> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void }) | (undefined)), name: "transitionAppearDefault"): __pui_State<boolean> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void } => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule8 = (value: ((__pui_State<number> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<number>) => void): () => void }) | (undefined)), name: "transitionEnterDurationDefault"): __pui_State<number> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<number>) => void): () => void } => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule9 = (value: ((__pui_State<number> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<number>) => void): () => void }) | (undefined)), name: "transitionLeaveDurationDefault"): __pui_State<number> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<number>) => void): () => void } => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule10 = (value: ((__pui_State<string> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<string>) => void): () => void }) | (undefined)), name: "transitionInterruptDefault"): __pui_State<string> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<string>) => void): () => void } => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule11 = (value: ((__pui_State<boolean> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void }) | (undefined)), name: "transitionColdEntryPreparation"): __pui_State<boolean> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void } => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule12 = (value: (((config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void) | (undefined)), name: "configurePresentation"): (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule13 = (value: ((() => Readonly<object>) | (undefined)), name: "getPresentationOwner"): () => Readonly<object> => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule14 = (value: (((source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void) | (undefined)), name: "bindInitialOpen"): (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule15 = (value: (((source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void) | (undefined)), name: "bindOpenContext"): (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule16 = (value: (((retained: boolean) => void) | (undefined)), name: "retainClosedView"): (retained: boolean) => void => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};


export type GeneratedProps = {
  "open"?: boolean | null;
  "defaultOpen"?: boolean | null;
  "appear"?: boolean | null;
  "enterDuration"?: number | null;
  "leaveDuration"?: number | null;
  "interrupt"?: "immediate" | "reverse" | "wait" | null;
};
export type GeneratedExposes = {
  "beforeEnter": { readonly kind: 'event'; readonly payload: "void" };
  "afterEnter": { readonly kind: 'event'; readonly payload: "void" };
  "beforeLeave": { readonly kind: 'event'; readonly payload: "void" };
  "afterLeave": { readonly kind: 'event'; readonly payload: "void" };
  "bindInitialOpen": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void;
  "getPresentationOwner": () => Readonly<object>;
  "configurePresentation": (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void;
  "bindOpenContext": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void;
  "retainClosedView": (retained: boolean) => void;
  "transitionState": __pui_ExternalState<string>;
  "isPresent": __pui_ExternalState<boolean>;
  "enter": () => void;
  "leave": () => void;
  "complete": () => void;
  "capturePreparation": () => ((() => void) | (null));
  "controls": { "enter": () => void; "leave": () => void; "complete": () => void; "capturePreparation": () => ((() => void) | (null)) };
};
export type GeneratedComponentProps = GeneratedProps & Omit<__pui_React.HTMLAttributes<HTMLElement>, keyof GeneratedProps | 'dangerouslySetInnerHTML' | "onBeforeEnter" | "onAfterEnter" | "onBeforeLeave" | "onAfterLeave"> & {
  children?: __pui_React.ReactNode;
  /** The physical element is a target affordance, never a portable Proto expose. */
  hostRef?: __pui_React.Ref<HTMLElement>;
  hostProps?: Omit<__pui_React.AllHTMLAttributes<HTMLElement> & __pui_React.AnchorHTMLAttributes<HTMLElement>, 'children' | 'dangerouslySetInnerHTML'>;
  instanceAssociations?: Readonly<{ controlLabel?: object | null }>;
  "onBeforeEnter"?: () => void;
  "onAfterEnter"?: () => void;
  "onBeforeLeave"?: () => void;
  "onAfterLeave"?: () => void;
  [event: `on${string}`]: unknown;
};
export interface GeneratedHandle {
  update(): void;
  getElement(): HTMLElement | null;
  getExposes(): GeneratedExposes;
  invokeInCallbackScope<T>(callback: () => T): T;
}
type __pui_ResolvedProps = Readonly<{ "open": boolean | null; "defaultOpen": boolean; "appear": boolean; "enterDuration": number; "leaveDuration": number; "interrupt": "reverse" | "wait" | "immediate" }>;
type __pui_StateEvent<T> = { type: 'next'; prev: T; next: T; reason?: unknown } | { type: 'disconnect'; reason: 'unmount' };
type __pui_ExternalState<T> = {
  get(): T;
  subscribe(callback: (event: __pui_StateEvent<T>) => void): () => void;
  unsubscribe(off: () => void): void;
  readonly spec: Readonly<__pui_StateSpec>;
};
type __pui_State<T> = { get(): T; setDefault(value: T): void; set(value: T, reason?: unknown): void };
type __pui_StateSpec = { kind: 'bool' | 'enum' | 'string' | 'number.discrete' | 'number.range'; options?: readonly (string | number)[]; min?: number; max?: number; step?: number; clamp?: boolean };
type __pui_DataSchema = string | { kind: string; fields?: readonly { name: string; type: __pui_DataSchema; optional?: boolean }[]; element?: __pui_DataSchema; members?: readonly __pui_DataSchema[]; value?: unknown };
type __pui_PropSpec = { type: __pui_DataSchema; default?: unknown; empty?: 'accept' | 'fallback' | 'error'; options?: readonly string[]; range?: { min?: number; max?: number }; validator?: (value: never) => boolean };
type __pui_Run = {
  update(): void;

  props: { get(): __pui_ResolvedProps; getRaw(): Readonly<Record<string, unknown>>; isProvided(key: string): boolean };
  context: {
    read<T>(key: object): T;
    tryRead<T>(key: object): T | null;
    tryReadAncestor<T>(key: object): T | null;
    update<T>(key: object, next: T | ((prev: T) => T)): void;
    tryUpdate<T>(key: object, next: T | ((prev: T) => T)): boolean;
  };
  expose: { emit(key: string, payload?: unknown, options?: Record<string, unknown>): void };
  lifecycle: { setPresent(present: boolean): void };
};
type __pui_Frame = { revision: number; epoch: number; kind: 'mount' | 'update' | 'detach'; node: __pui_React.ReactNode };
type __pui_Owner = {
  handle: GeneratedHandle;
  scope: __pui_ContextScope;
  getHostProjection(): { tag: string; properties: Readonly<Record<string, string | number | boolean | null>>; portalTarget: HTMLElement | null };
  bindRoot(root: HTMLElement | null): void;
  connect(): void;
  start(): void;
  applyProps(props: GeneratedComponentProps): void;
  accept(frame: __pui_Frame): boolean;
  disconnect(): void;

};

const __pui_Slots = new WeakSet<object>();
const __pui_PortablePropNames = new Set<string>(["open","defaultOpen","appear","enterDuration","leaveDuration","interrupt"]);
const __pui_OutwardEventNames = new Set<string>(["onBeforeEnter","onAfterEnter","onBeforeLeave","onAfterLeave"]);
function __pui_HostProperties(props: GeneratedComponentProps): Record<string, unknown> {
  const result: Record<string, unknown> = { ...props.hostProps };
  for (const [key, value] of Object.entries(props)) {
    if (__pui_PortablePropNames.has(key) || __pui_OutwardEventNames.has(key)
      || ['children', 'hostRef', 'hostProps', 'instanceAssociations', 'key', 'ref', 'dangerouslySetInnerHTML'].includes(key)) continue;
    result[key] = value;
  }
  // Explicit native host fields cannot create a second subscriber to an outward
  // Proto signal, replace the slot tree, or steal the compiler's physical ref.
  for (const key of [...__pui_OutwardEventNames, 'children', 'ref', 'key', 'dangerouslySetInnerHTML']) delete result[key];
  return result;
}
function __pui_AssignHostRef(ref: __pui_React.Ref<HTMLElement> | undefined, element: HTMLElement | null): void {
  if (typeof ref === 'function') ref(element);
  else if (ref) (ref as __pui_React.MutableRefObject<HTMLElement | null>).current = element;
}
function __pui_BindSlots(node: __pui_React.ReactNode, slot: __pui_React.ReactNode): __pui_React.ReactNode {
  if (Array.isArray(node)) {
    let result: __pui_React.ReactNode[] | null = null;
    for (let index = 0; index < node.length; index++) {
      const child = __pui_BindSlots(node[index], slot);
      if (child !== node[index]) { result ??= node.slice(); result[index] = child; }
    }
    return result ?? node;
  }
  if (!__pui_React.isValidElement(node)) return node;
  const element = node as __pui_React.ReactElement<{ children?: __pui_React.ReactNode }>;
  if (__pui_Slots.has(element)) return __pui_React.createElement(__pui_React.Fragment, { key: element.key }, slot);
  const previous = element.props.children, next = __pui_BindSlots(previous, slot);
  return previous === next ? node : __pui_React.cloneElement(element, undefined, next);
}
function __pui_RootProperties(properties: Readonly<Record<string, unknown>>, initial = false): Record<string, unknown> {
  const result: Record<string, unknown> = { ...properties };
  // Only server/initial hydration markup projects the canonical value through
  // defaultValue. A live native TextControl owns editing and its reset default;
  // its commit hook restores those fields after React's host reconciliation.
  if (Object.hasOwn(result, 'value')) { result.defaultValue = initial ? result.value : undefined; delete result.value; }
  if (typeof result.style === 'string') {
    const style: Record<string, string> = {};
    for (const declaration of result.style.split(';')) {
      const colon = declaration.indexOf(':');
      if (colon < 1) continue;
      const name = declaration.slice(0, colon).trim();
      style[name.startsWith('--') ? name : name.replace(/-([a-z])/g, (_match, letter: string) => letter.toUpperCase())] = declaration.slice(colon + 1).trim();
    }
    result.style = style;
  }
  return result;
}
function __pui_HasRootContent(node: __pui_React.ReactNode): boolean {
  if (node === null || node === undefined || typeof node === 'boolean' || node === '') return false;
  if (Array.isArray(node)) return node.some(__pui_HasRootContent);
  if (__pui_React.isValidElement(node) && node.type === __pui_React.Fragment)
    return __pui_HasRootContent((node.props as { children?: __pui_React.ReactNode }).children);
  return true;
}
function __pui_RenderRoot(tag: string, attributes: Record<string, unknown>, children: __pui_React.ReactNode): __pui_React.ReactElement {
  if (['input', 'textarea', 'img', 'area', 'base', 'br', 'col', 'embed', 'hr', 'link', 'meta', 'param', 'source', 'track', 'wbr'].includes(tag)) {
    if (__pui_HasRootContent(children)) throw new TypeError('[Template] this physical control Root cannot contain semantic children.');
    return __pui_React.createElement(tag, attributes);
  }
  return __pui_React.createElement(tag, attributes, children);
}

function __pui_ResolveProps(
  specs: Readonly<Record<string, __pui_PropSpec>>,
  defaults: readonly Readonly<Record<string, unknown>>[],
  previousValid: Record<string, unknown>,
  raw: Readonly<Record<string, unknown>>,
  strict: boolean
): __pui_ResolvedProps {
  const next: Record<string, unknown> = Object.create(null);
  for (const key of Object.keys(specs)) {
    const spec = specs[key];
    const provided = Object.hasOwn(raw, key);
    const value = raw[key];
    const empty = value === null || value === undefined;
    const valid = (candidate: unknown) => {
      if (!__pui_Accepts(spec.type, candidate) || spec.range && !(typeof candidate === 'number'
        && candidate >= (spec.range.min ?? -Infinity) && candidate <= (spec.range.max ?? Infinity))) return false;
      // The checked schema establishes the validator's declared argument domain.
      // A throwing validator rejects this candidate, as in ordinary Props.
      try { return spec.validator ? !!spec.validator(candidate as never) : true; }
      catch { return false; }
    };
    if (provided && !empty && valid(value)) {
      next[key] = value;
      previousValid[key] = value;
      continue;
    }
    if (provided && empty && spec.empty === 'accept') { next[key] = null; continue; }
    const nonEmpty = strict && spec.empty === 'error';
    let found = false;
    const take = (candidate: unknown) => {
      if (candidate === undefined || nonEmpty && candidate === null) return false;
      if (candidate !== null && !valid(candidate)) return false;
      next[key] = candidate;
      found = true;
      return true;
    };
    if (provided && Object.hasOwn(previousValid, key)) take(previousValid[key]);
    if (!found) for (const layer of defaults) if (Object.hasOwn(layer, key) && take(layer[key])) break;
    if (!found && Object.hasOwn(spec, 'default')) take(spec.default);
    if (!found) {
      if (nonEmpty) throw new Error('[Props] missing, empty or invalid prop without non-empty fallback: ' + key);
      next[key] = null;
    }
    if (provided && next[key] !== null) previousValid[key] = next[key];
  }
  return Object.freeze(next) as __pui_ResolvedProps;
}

function __pui_CompleteSteps(steps: readonly (() => void)[]): void {
  let failure: { error: unknown } | undefined;
  for (const step of steps) { try { step(); } catch (error) { failure ??= { error }; } }
  if (failure) throw failure.error;
}

function __pui_CreateOwner(initial: GeneratedComponentProps, publish: (frame: __pui_Frame) => void, getParent: () => __pui_ContextScope | null, publishHost: () => void): __pui_Owner {
  let phase: 'setup' | 'callback' | 'render' | 'idle' = 'setup';
  let lifetime: 'alive' | 'disposing' | 'disposed' = 'alive';
  let connected = true;
  let cleanupVersion = 0;
  let desiredPresent = true;
  let mounted = false;
  let epoch = 0;
  let revision = 0;
  let acceptedRevision = 0;
  let latest: __pui_Frame | null = null;
  let dirty = false;
  let updateQueued = false;
  let scheduled = false;
  let hostScheduled = false;
  let callbackDepth = 0;
  let slotUsed = false;
  let elementSequence = 0;
  let hostProps = initial;
  let root: HTMLElement | null = null;
  let rootGeneration = 0;
  let rootBinding: 'retiring' | 'binding' | null = null;
  let pendingRoot: { value: HTMLElement | null } | undefined;
  function consumePendingRoot(): { value: HTMLElement | null } | undefined {
    const request = pendingRoot; pendingRoot = undefined; return request;
  }

  let raw: Readonly<Record<string, unknown>> = Object.freeze({});
  let resolved: __pui_ResolvedProps;
  let hydrated = false;
  let propsWindow: { raw: Readonly<Record<string, unknown>>; resolved: __pui_ResolvedProps } | null = null;
  const specs: Record<string, __pui_PropSpec> = Object.create(null);
  const defaults: Readonly<Record<string, unknown>>[] = [];
  const previousValid: Record<string, unknown> = Object.create(null);
  const stateNames = new Set<string>();
  // Reserve before setup; only successful setup publishes a reusable opaque result.

  const stateSubscribers = new Set<Set<(event: __pui_StateEvent<unknown>) => void>>();
  const pendingStateEvents: (() => void)[] = [];
  const authorStateWatchCleanups: (() => void)[] = [];
  let emittingState = false;
  type __pui_ResolvedWatcher = { active: boolean; keys: readonly string[] | null; callback: (run: __pui_Run, next: __pui_ResolvedProps, prev: __pui_ResolvedProps, info: Readonly<Record<string, unknown>>) => void };
  type __pui_RawWatcher = { active: boolean; keys: readonly string[] | null; callback: (run: __pui_Run, next: Readonly<Record<string, unknown>>, prev: Readonly<Record<string, unknown>>, info: Readonly<Record<string, unknown>>) => void };
  const watchers: __pui_ResolvedWatcher[] = [];
  const rawWatchers: __pui_RawWatcher[] = [], rawAllWatchers: __pui_RawWatcher[] = [];
  const exposes: Record<string, unknown> = Object.create(null);
  const methodSchemas: Record<string, { args(args: unknown[]): boolean; result(value: unknown): boolean }> = {
    "bindInitialOpen": { args: (args: unknown[]) => args.length <= 1 && (args[0] !== null && typeof args[0] === 'object' && !Array.isArray(args[0]) && (Object.getOwnPropertyDescriptor(args[0], "context") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(args[0], "context")!, 'value') && (Object.getOwnPropertyDescriptor(args[0], "context")!.value !== null && typeof Object.getOwnPropertyDescriptor(args[0], "context")!.value === 'object' && Object.getOwnPropertyDescriptor(Object.getOwnPropertyDescriptor(args[0], "context")!.value, '__brand')?.value === 'ContextKey')) && (Object.getOwnPropertyDescriptor(args[0], "field") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(args[0], "field")!, 'value') && __pui_Accepts("string", Object.getOwnPropertyDescriptor(args[0], "field")!.value))), result: (result: unknown) => __pui_Accepts("void", result) },
    "getPresentationOwner": { args: (args: unknown[]) => args.length <= 0, result: (result: unknown) => (result !== null && typeof result === 'object' && !Array.isArray(result)) },
    "configurePresentation": { args: (args: unknown[]) => args.length <= 1 && (args[0] !== null && typeof args[0] === 'object' && !Array.isArray(args[0]) && (Object.getOwnPropertyDescriptor(args[0], "completion") === undefined || (Object.getOwnPropertyDescriptor(args[0], "completion") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(args[0], "completion")!, 'value') && (__pui_Accepts({"kind":"literal","value":"timer"}, Object.getOwnPropertyDescriptor(args[0], "completion")!.value) || (Object.getOwnPropertyDescriptor(args[0], "completion")!.value !== null && typeof Object.getOwnPropertyDescriptor(args[0], "completion")!.value === 'object' && !Array.isArray(Object.getOwnPropertyDescriptor(args[0], "completion")!.value) && (Object.getOwnPropertyDescriptor(Object.getOwnPropertyDescriptor(args[0], "completion")!.value, "kind") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(Object.getOwnPropertyDescriptor(args[0], "completion")!.value, "kind")!, 'value') && __pui_Accepts({"kind":"literal","value":"presentation"}, Object.getOwnPropertyDescriptor(Object.getOwnPropertyDescriptor(args[0], "completion")!.value, "kind")!.value)) && (Object.getOwnPropertyDescriptor(Object.getOwnPropertyDescriptor(args[0], "completion")!.value, "timeoutMs") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(Object.getOwnPropertyDescriptor(args[0], "completion")!.value, "timeoutMs")!, 'value') && __pui_Accepts("number", Object.getOwnPropertyDescriptor(Object.getOwnPropertyDescriptor(args[0], "completion")!.value, "timeoutMs")!.value))) || __pui_Accepts("void", Object.getOwnPropertyDescriptor(args[0], "completion")!.value)))) && (Object.getOwnPropertyDescriptor(args[0], "coldEntryPreparation") === undefined || (Object.getOwnPropertyDescriptor(args[0], "coldEntryPreparation") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(args[0], "coldEntryPreparation")!, 'value') && __pui_Accepts({"kind":"union","members":["boolean","void"]}, Object.getOwnPropertyDescriptor(args[0], "coldEntryPreparation")!.value))) && (Object.getOwnPropertyDescriptor(args[0], "appear") === undefined || (Object.getOwnPropertyDescriptor(args[0], "appear") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(args[0], "appear")!, 'value') && __pui_Accepts({"kind":"union","members":["boolean","void"]}, Object.getOwnPropertyDescriptor(args[0], "appear")!.value))) && (Object.getOwnPropertyDescriptor(args[0], "enterDuration") === undefined || (Object.getOwnPropertyDescriptor(args[0], "enterDuration") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(args[0], "enterDuration")!, 'value') && __pui_Accepts({"kind":"union","members":["number","void"]}, Object.getOwnPropertyDescriptor(args[0], "enterDuration")!.value))) && (Object.getOwnPropertyDescriptor(args[0], "leaveDuration") === undefined || (Object.getOwnPropertyDescriptor(args[0], "leaveDuration") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(args[0], "leaveDuration")!, 'value') && __pui_Accepts({"kind":"union","members":["number","void"]}, Object.getOwnPropertyDescriptor(args[0], "leaveDuration")!.value))) && (Object.getOwnPropertyDescriptor(args[0], "interrupt") === undefined || (Object.getOwnPropertyDescriptor(args[0], "interrupt") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(args[0], "interrupt")!, 'value') && __pui_Accepts({"kind":"union","members":[{"kind":"literal","value":"reverse"},{"kind":"literal","value":"wait"},{"kind":"literal","value":"immediate"},"void"]}, Object.getOwnPropertyDescriptor(args[0], "interrupt")!.value)))), result: (result: unknown) => __pui_Accepts("void", result) },
    "bindOpenContext": { args: (args: unknown[]) => args.length <= 1 && (args[0] !== null && typeof args[0] === 'object' && !Array.isArray(args[0]) && (Object.getOwnPropertyDescriptor(args[0], "context") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(args[0], "context")!, 'value') && (Object.getOwnPropertyDescriptor(args[0], "context")!.value !== null && typeof Object.getOwnPropertyDescriptor(args[0], "context")!.value === 'object' && Object.getOwnPropertyDescriptor(Object.getOwnPropertyDescriptor(args[0], "context")!.value, '__brand')?.value === 'ContextKey')) && (Object.getOwnPropertyDescriptor(args[0], "field") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(args[0], "field")!, 'value') && __pui_Accepts("string", Object.getOwnPropertyDescriptor(args[0], "field")!.value))), result: (result: unknown) => __pui_Accepts("void", result) },
    "retainClosedView": { args: (args: unknown[]) => args.length <= 1 && __pui_Accepts("boolean", args[0]), result: (result: unknown) => __pui_Accepts("void", result) },
    "enter": { args: (args: unknown[]) => args.length <= 0, result: (result: unknown) => __pui_Accepts("void", result) },
    "leave": { args: (args: unknown[]) => args.length <= 0, result: (result: unknown) => __pui_Accepts("void", result) },
    "complete": { args: (args: unknown[]) => args.length <= 0, result: (result: unknown) => __pui_Accepts("void", result) },
    "capturePreparation": { args: (args: unknown[]) => args.length <= 0, result: (result: unknown) => ((typeof result === 'function') || __pui_Accepts("null", result)) },
  };
  const eventSchemas: Record<string, __pui_DataSchema> = {
    "beforeEnter": "void",
    "afterEnter": "void",
    "beforeLeave": "void",
    "afterLeave": "void",
  };
  const propSchemas: Record<string, __pui_DataSchema> = {
    "open": "boolean",
    "defaultOpen": "boolean",
    "appear": "boolean",
    "enterDuration": "number",
    "leaveDuration": "number",
    "interrupt": {"kind":"union","members":[{"kind":"literal","value":"reverse"},{"kind":"literal","value":"wait"},{"kind":"literal","value":"immediate"}]},
  };
  const callbacks = {
    created: [] as ((run: __pui_Run) => void)[], mounted: [] as ((run: __pui_Run) => void)[],
    updated: [] as ((run: __pui_Run) => void)[], unmounted: [] as ((run: __pui_Run) => void)[],
    beforeDispose: [] as ((run: __pui_Run) => void)[],
  };
  function ensureAlive() {
    if (lifetime === 'disposed' || !connected && phase !== 'callback')
      throw new Error('Generated handle is invalid after terminal disposal.');
  }
  function ensurePhase(expected: typeof phase) {
    ensureAlive();
    if (phase !== expected) throw new Error('Illegal generated operation phase: ' + phase + '; expected ' + expected);
  }
  function ensureExternal() {
    if (!connected || lifetime !== 'alive') throw new Error('Generated handle is invalid after terminal disposal begins.');
  }
  function invoke<T>(callback: () => T): T {
    ensureAlive();
    if (phase === 'render' || phase === 'setup') throw new Error('Cannot enter callback scope from ' + phase);
    const previous = phase;
    phase = 'callback';
    ++callbackDepth;
    try { return callback(); }
    finally { phase = previous; --callbackDepth; if (!callbackDepth) schedule(); }
  }
  const __pui_Delay = __pui_CreateDelay({ runtime: () => { ensurePhase('callback'); }, alive: () => lifetime !== 'disposed', invoke: callback => { invoke(callback); }, report: error => console.error('[Delay] callback failed', error) });
const __pui_Presence = __pui_CreatePresence<__pui_Run>({ setup: () => { ensurePhase('setup'); }, runtime: () => { ensurePhase('callback'); }, alive: () => lifetime !== 'disposed', invoke: callback => { invoke(() => callback(__pui_RunHandle)); } });
const __pui_Meta = (key: string) => __pui_ReadMeta(root?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), key);
  const __pui_Authored = __pui_CreateAuthored({setup: () => ensurePhase('setup'), borrow(value) {
    const state = value as __pui_State<unknown>, external = externalStates.get(state) as __pui_ExternalState<unknown> | undefined;
    if (!external) throw new Error('[State] borrowed state must belong to this instance.');
    const borrowed = Object.freeze({ get: () => state.get(), setDefault: (value: unknown) => state.setDefault(value), set: (value: unknown, reason?: unknown) => state.set(value, reason), watch(callback: (run: __pui_Run, event: __pui_StateEvent<unknown>) => void) { ensurePhase('setup'); const off = external.subscribe(event => invoke(() => callback(__pui_RunHandle, event))); authorStateWatchCleanups.push(off); return off; } });
    // A capture borrows the same owner State; native modules must retain its provenance.
    externalStates.set(borrowed, external);

    return borrowed;
  } });
  const __pui_WrapPublic = __pui_CreatePublicCalls({alive: ensureExternal, invoke});
  const context = __pui_CreateContextScope({
    getParent, isAlive: () => lifetime !== 'disposed', invoke,
    validate: (key: object, value: unknown): boolean => false,
  });
  function dispatch(list: readonly ((run: __pui_Run) => void)[]) {
    if (list === callbacks.unmounted) {
      __pui_CompleteSteps([() => { { let failed = false, first; for (const release of [() => { __pui_Delay.cancelView(); }, () => { __pui_Presence.detach(); }]) { try { release(); } catch (error) { if (!failed) { failed = true; first = error; } } } if (failed) throw first; } },
        () => invoke(() => { for (const callback of list) callback(__pui_RunHandle); }),
        () => { { let failed = false, first; for (const release of [() => { __pui_Delay.cancelView(); }, () => { __pui_Presence.detach(); }]) { try { release(); } catch (error) { if (!failed) { failed = true; first = error; } } } if (failed) throw first; } }]);
      return;
    }
    invoke(() => { for (const callback of list) callback(__pui_RunHandle); });
  }
  function detachView() {
    const wasMounted = mounted; mounted = false;
    __pui_CompleteSteps([
      () => { if (wasMounted) dispatch(callbacks.unmounted); else { { let failed = false, first; for (const release of [() => { __pui_Delay.cancelView(); }, () => { __pui_Presence.detach(); }]) { try { release(); } catch (error) { if (!failed) { failed = true; first = error; } } } if (failed) throw first; } } },
    ]);
  }
  function schedule() {
    if (scheduled || callbackDepth || !connected || lifetime !== 'alive') return;
    if (!updateQueued && desiredPresent === mounted && !(!desiredPresent && root) && !(latest && latest.revision > acceptedRevision)) return;
    scheduled = true;
    queueMicrotask(() => {
      scheduled = false;
      if (!connected || lifetime !== 'alive') return;
      if (latest && latest.revision > acceptedRevision) return;
      if (!desiredPresent) {
        if (mounted || root) deliver('detach');
        else { dirty = dirty || updateQueued; updateQueued = false; }
      } else if (!mounted) deliver('mount');
      else if (updateQueued) deliver('update');
    });
  }
  function deliver(kind: __pui_Frame['kind']) {
    updateQueued = false;
    let node: __pui_React.ReactNode = null;
    if (kind === 'mount') ++epoch;
    if (kind !== 'detach') {
      slotUsed = false;
      elementSequence = 0;
      phase = 'render';
      try { node = normalize(render(__pui_Renderer));  }
      finally { phase = 'idle'; }
      dirty = false;
    }
    latest = { revision: ++revision, epoch, kind, node };
    publish(latest);
  }
  function normalize(value: unknown): __pui_React.ReactNode {
    if (value === null) return null;
    if (Array.isArray(value)) return value.flatMap((item) => {
      const child = normalize(item);
      return child === null ? [] : [child];
    });
    if (typeof value === 'string' || typeof value === 'number' && Number.isFinite(value) || __pui_React.isValidElement(value)) return value;
    throw new Error('[Template] child must be null, text, a finite number or an authored element/slot.');
  }
  function __pui_Element(tag: string, ...args: unknown[]) {
    ensurePhase('render');
    if (!tag || typeof tag !== 'string') throw new Error('[Template] native elements require a tag string.');
    let children: unknown = null;
    let props: Record<string, unknown> = {};
    if (args.length === 1) {
      const argument = args[0];
      if (argument !== null && typeof argument === 'object' && !Array.isArray(argument) && !__pui_React.isValidElement(argument)) {
        props = argument as Record<string, unknown>;
      } else children = argument;
    } else if (args.length === 2) {
      if (!args[0] || typeof args[0] !== 'object' || Array.isArray(args[0]))
        throw new Error('[Template] native template props must be a record.');
      props = args[0] as Record<string, unknown>;
      children = args[1];
    }
    if (Object.keys(props).some((key) => key !== 'style'))
      throw new Error('[Template] native template props support only style.');
    if (Object.hasOwn(props, 'style')) throw new Error('[Template] style requires an admitted style handle.');
    const tokens = '';
    const normalized = normalize(children);
    return __pui_React.createElement(tag, { key: elementSequence++, ...(tokens ? { 'data-pui-style': tokens } : {}) }, ...(Array.isArray(normalized) ? normalized : [normalized]));
  }
  const __pui_Renderer = {
    read: Object.freeze({
      props: Object.freeze({
        get() { ensurePhase('render'); return resolved; },
        getRaw() { ensurePhase('render'); return raw; },
        isProvided(key: string) { ensurePhase('render'); return Object.hasOwn(raw, key); },
      }),
      context: Object.freeze({
        read<T>(key: object): T { ensurePhase('render'); return context.read<T>(key); },
        tryRead<T>(key: object): T | null { ensurePhase('render'); return context.tryRead<T>(key); },
      }),
    }),
    el: __pui_Element,


    slot: () => {
      ensurePhase('render');
      if (slotUsed) throw new Error('[Template] multiple anonymous slots are not supported.');
      slotUsed = true;
      const slot = __pui_React.createElement(__pui_React.Fragment, { key: elementSequence++ });
      __pui_Slots.add(slot);
      return slot;
    },
  };
  function __pui_CreateState<T extends boolean | string | number>(name: string, initialValue: T, spec: __pui_StateSpec): __pui_State<T> {
    ensurePhase('setup');
    __pui_Authored.claimState(name);
    spec = Object.freeze({ ...spec, ...(spec.options ? { options: Object.freeze([...spec.options]) } : {}) });
    const type = spec.kind === 'bool' ? 'boolean' : spec.kind === 'string' || spec.kind === 'enum' ? 'string' : 'number';
    if (spec.options?.some((option) => typeof option !== type || typeof option === 'number' && !Number.isFinite(option)))
      throw new Error('[State] invalid state options: ' + name);
    if (spec.kind === 'number.range' && (!Number.isFinite(spec.min) || !Number.isFinite(spec.max))
      || spec.min !== undefined && !Number.isFinite(spec.min) || spec.max !== undefined && !Number.isFinite(spec.max)
      || spec.min !== undefined && spec.max !== undefined && spec.min > spec.max
      || spec.step !== undefined && !Number.isFinite(spec.step))
      throw new Error('[State] invalid numeric domain: ' + name);
    function validate(next: T) {
      if (typeof next !== type || typeof next === 'number' && !Number.isFinite(next))
        throw new TypeError('[State] invalid state value: ' + name);
      if (spec.kind === 'enum' && !spec.options?.includes(next as string)) throw new Error('[State] enum value outside options: ' + name);
      if (spec.options?.length && (spec.kind === 'enum' || spec.kind === 'string' || spec.kind === 'number.discrete')) {
        if (!spec.options.includes(next as string | number)) throw new Error('[State] state value outside options: ' + name);
        return;
      }
      if (typeof next !== 'number') return;
      if (next < (spec.min ?? -Infinity) || next > (spec.max ?? Infinity))
        throw new Error('[State] state value outside range: ' + name);
      if (spec.kind === 'number.discrete' && spec.step !== undefined && spec.step > 0
        && !Number.isInteger((next - (spec.min ?? 0)) / spec.step))
        throw new Error('[State] state value violates step: ' + name);
    }
    let value = initialValue;
    // Core range clamping normalizes definition defaults only, never callback writes.
    if (spec.kind === 'number.range' && spec.clamp && typeof value === 'number' && Number.isFinite(value))
      value = Math.min(spec.max!, Math.max(spec.min!, value)) as T;
    validate(value);
    stateNames.add(name);
    const subscribers = new Set<(event: __pui_StateEvent<T>) => void>();
    stateSubscribers.add(subscribers as Set<(event: __pui_StateEvent<unknown>) => void>);
    const state = {
      get() { ensureAlive(); return value; },
      setDefault(next: T) { ensurePhase('setup'); validate(next); value = next; },
      set(next: T, reason?: unknown) {
        ensurePhase('callback');
        validate(next);
        if (Object.is(value, next)) return;
        const event: __pui_StateEvent<T> = { type: 'next', prev: value, next, reason };
        value = next;

        
        for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(pendingStateEvents, pendingStateEvents.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!emittingState) {
  emittingState = true;
  const notificationFailures: unknown[] = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < pendingStateEvents.length) {
      try { pendingStateEvents[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { pendingStateEvents.length = 0; emittingState = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
      },
    };
    const external: __pui_ExternalState<T> = Object.freeze({
      get() { ensureExternal(); return state.get(); },
      subscribe(callback: (event: __pui_StateEvent<T>) => void) {
        ensureExternal(); const registration: typeof callback = event => callback(event); subscribers.add(registration); return () => { subscribers.delete(registration); };
      },
      unsubscribe(off: () => void) { off(); },
      spec: Object.freeze(spec),
    });
    externalStates.set(state, external);
    
    __pui_Authored.state(name, state);
    return state;
  }
  const externalStates = new WeakMap<object, unknown>();
  const __pui_RunHandle: __pui_Run = {

    update() {
      ensurePhase('callback');
      if (lifetime !== 'alive') return;
      dirty = true;
      if (desiredPresent && mounted) updateQueued = true;
      schedule();
    },
    props: {
      get() { ensureAlive(); return propsWindow?.resolved ?? resolved; },
      getRaw() { ensureAlive(); return propsWindow?.raw ?? raw; },
      isProvided(key: string) { ensureAlive(); return Object.hasOwn(propsWindow?.raw ?? raw, key); },
    },
    context: Object.freeze({
      read<T>(key: object): T { ensurePhase('callback'); return context.read<T>(key); },
      tryRead<T>(key: object): T | null { ensurePhase('callback'); return context.tryRead<T>(key); },
      tryReadAncestor<T>(key: object): T | null { ensurePhase('callback'); return context.tryReadAncestor<T>(key); },
      update<T>(key: object, next: T | ((prev: T) => T)) { ensurePhase('callback'); context.update(key, next); },
      tryUpdate<T>(key: object, next: T | ((prev: T) => T)) { ensurePhase('callback'); return context.tryUpdate(key, next); },
    }),
    expose: { emit(key, payload, options) {
      ensurePhase('callback');
      const declaration = exposes[key] as { kind?: string; payload: __pui_DataSchema } | undefined;
      if (declaration?.kind !== 'event') throw new Error('[Expose] event was not declared: ' + key);
      if (!__pui_Accepts(declaration.payload, payload)) throw new TypeError('[Expose] invalid event payload: ' + key);
      const sink = (hostProps as Record<string, unknown>)['on' + key.charAt(0).toUpperCase() + key.slice(1)];
      if (typeof sink === 'function') { try { sink(payload, options); } catch { /* Host sink failures do not re-enter prototype execution. */ } }
    } },
    lifecycle: { setPresent(present) {
      ensurePhase('callback');
      if (lifetime !== 'alive') throw new Error('[Lifecycle] cannot update view presence after terminal disposal begins.');
      if (typeof present !== 'boolean') throw new Error('[Lifecycle] view presence must be boolean.');
      if (desiredPresent === present) return;
      desiredPresent = present;
      schedule();
    } },
  };
  function registerExpose(key: string, value: unknown) {
    ensurePhase('setup');
    if (!key || Object.hasOwn(exposes, key)) throw new Error('[Expose] empty or duplicate declaration: ' + key);
    exposes[key] = value;
  }
  const __pui_Def = {

    context: Object.freeze({
      provide<T>(key: object, value: T) { ensurePhase('setup'); context.provide(key, value); },
      subscribe<T>(key: object, callback?: (run: __pui_Run, next: T, prev: T) => void) {
        ensurePhase('setup');
        return context.subscribe<T>(key, 'required', callback ? (next, prev) => callback(__pui_RunHandle, next as T, prev as T) : undefined);
      },
      trySubscribe<T>(key: object, callback?: (run: __pui_Run, next: T | null, prev: T | null) => void) {
        ensurePhase('setup');
        return context.subscribe<T>(key, 'optional', callback ? (next, prev) => callback(__pui_RunHandle, next, prev) : undefined);
      },
      trySubscribeAncestor<T>(key: object, callback?: (run: __pui_Run, next: T | null, prev: T | null) => void) {
        ensurePhase('setup');
        return context.subscribe<T>(key, 'optional', callback ? (next, prev) => callback(__pui_RunHandle, next, prev) : undefined, 'ancestor');
      },
    }),
    props: {
      define(incoming: Record<string, Omit<__pui_PropSpec, 'type'> & { type: __pui_DataSchema | 'enum' | 'object' | 'any' }>) {
        ensurePhase('setup');
        const next = { ...specs };
        for (const [key, authored] of Object.entries(incoming)) {
          const schema = propSchemas[key];
          if (!schema) throw new Error('[Props] missing checked declaration: ' + key);
          const spec: __pui_PropSpec = { ...authored, type: schema };
          const previous = specs[key];
          if (!previous) { next[key] = { ...spec }; continue; }
          if (previous.validator && previous.validator !== spec.validator)
            throw new Error('[Props] validator replacement or removal is disallowed: ' + key);
          const rank = (empty: __pui_PropSpec['empty']) => empty === 'accept' ? 0 : empty === 'error' ? 2 : 1;
          if (JSON.stringify(previous.type) !== JSON.stringify(spec.type) || Object.hasOwn(spec, 'empty') && rank(spec.empty) > rank(previous.empty)
            || previous.range && spec.range && ((spec.range.min ?? -Infinity) > (previous.range.min ?? -Infinity)
              || (spec.range.max ?? Infinity) < (previous.range.max ?? Infinity)))
            throw new Error('[Props] conflicting or stricter prop definition: ' + key);
          next[key] = { ...previous, ...spec, empty: previous.empty ?? 'fallback', range: spec.range ?? previous.range };
          if (Object.hasOwn(previous, 'default')) next[key].default = previous.default;
        }
        Object.assign(specs, next);
        resolved = __pui_ResolveProps(specs, defaults, previousValid, raw, false);
      },
      setDefaults(partial: Record<string, unknown>) {
        ensurePhase('setup');
        for (const key of Object.keys(partial)) if (!Object.hasOwn(specs, key)) throw new Error('[Props] undeclared default key: ' + key);
        defaults.unshift({ ...partial });
        resolved = __pui_ResolveProps(specs, defaults, previousValid, raw, false);
      },
      watch(keys: readonly string[], callback: (run: __pui_Run, next: __pui_ResolvedProps, prev: __pui_ResolvedProps, info: Readonly<Record<string, unknown>>) => void) {
        ensurePhase('setup');
        if (!keys.length || keys.some((key) => !Object.hasOwn(specs, key))) throw new Error('[Props] watchers require declared keys.');
        const watcher = { keys: [...keys], callback, active: true };
        watchers.push(watcher);
        return () => { watcher.active = false; };
      },
      watchAll(callback: __pui_ResolvedWatcher['callback']) {
        ensurePhase('setup');
        const watcher: __pui_ResolvedWatcher = { keys: null, callback, active: true };
        watchers.push(watcher);
        return () => { watcher.active = false; };
      },
      watchRaw(keys: readonly string[], callback: __pui_RawWatcher['callback']) {
        ensurePhase('setup');
        if (!keys.length || keys.some(key => typeof key !== 'string' || !key.length)) throw new Error('[Props] raw watchers require nonempty keys.');
        const watcher: __pui_RawWatcher = { keys: [...keys], callback, active: true };
        rawWatchers.push(watcher);
        return () => { watcher.active = false; };
      },
      watchRawAll(callback: __pui_RawWatcher['callback']) {
        ensurePhase('setup');
        const watcher: __pui_RawWatcher = { keys: null, callback, active: true };
        rawAllWatchers.push(watcher);
        return () => { watcher.active = false; };
      },
    },
    state: {
      bool: (name: string, value: boolean) => __pui_CreateState(name, value, { kind: 'bool' }),
      string: (name: string, value: string, spec: Omit<__pui_StateSpec, 'kind'> = {}) => __pui_CreateState(name, value, { kind: 'string', ...spec }),
      enum: (name: string, value: string, spec: { options: readonly string[] }) => __pui_CreateState(name, value, { kind: 'enum', ...spec }),
      numberDiscrete: (name: string, value: number, spec: Omit<__pui_StateSpec, 'kind'> = {}) => __pui_CreateState(name, value, { kind: 'number.discrete', ...spec }),
      numberRange: (name: string, value: number, spec: Omit<__pui_StateSpec, 'kind'>) => __pui_CreateState(name, value, { kind: 'number.range', ...spec }),
    },
    expose: {
      value: registerExpose,
      state(key: string, state: object) {
        const external = externalStates.get(state);
        if (!external) throw new Error('[Expose] state must belong to this instance.');
        registerExpose(key, external);
        __pui_Authored.introduceObserved(state);
      },
      event(key: string, _spec: { payload?: 'void' | 'any' | 'json'; options?: Readonly<Record<string, unknown>> } = {}) {
        if (!Object.hasOwn(eventSchemas, key)) throw new Error('[Expose] missing checked event schema: ' + key);
        registerExpose(key, Object.freeze({ kind: 'event', payload: eventSchemas[key] }));
      },
      method<A extends unknown[], R>(key: string, callback: (...args: A) => R, project?: (value: R) => R) {

        registerExpose(key, (...args: A): R => {
          ensureExternal();
          return invoke(() => {
          const schema = methodSchemas[key];
          if (!schema || !schema.args(args))
            throw new TypeError('[Expose] invalid method arguments: ' + key);
          const result = callback(...args);
          if (!schema.result(result)) throw new TypeError('[Expose] invalid method result: ' + key);
          return project ? project(result) : result;
          });
        });
      },
    },
    lifecycle: {
      onCreated(callback: (run: __pui_Run) => void) { ensurePhase('setup'); callbacks.created.push(callback); },
      onMounted(callback: (run: __pui_Run) => void) { ensurePhase('setup'); callbacks.mounted.push(callback); },
      onUpdated(callback: (run: __pui_Run) => void) { ensurePhase('setup'); callbacks.updated.push(callback); },
      onUnmounted(callback: (run: __pui_Run) => void) { ensurePhase('setup'); callbacks.unmounted.push(callback); },
      onBeforeDispose(callback: (run: __pui_Run) => void) { ensurePhase('setup'); callbacks.beforeDispose.push(callback); },
    },
  };
  // Source "transition/machine.ts":42:1
  const __puiModule0 = (driver: { "getState": () => "closed" | "preparing" | "entering" | "entered" | "leaving"; "setState": (state: "closed" | "preparing" | "entering" | "entered" | "leaving") => void; "getInterrupt": () => "reverse" | "wait" | "immediate"; "requiresColdPreparation"?: () => boolean; "getCompletion"?: () => (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number })); "publishPresentation"?: (frame: { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) => void; "settlePresentation"?: (outcome: "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed") => void; "getDuration": (state: "entering" | "leaving") => number; "schedule": (durationMs: number, callback: () => void) => __pui_DelayTask; "setViewPresent": (present: boolean) => void; "emit": (event: "beforeEnter" | "afterEnter" | "beforeLeave" | "afterLeave") => void }): { "initialize": (open: boolean, appear: boolean) => void; "setTarget": (open: boolean) => void; "enter": () => void; "leave": () => void; "complete": () => void; "completePresentation": (attempt: { readonly "ownerEpoch": number; readonly "phaseAttempt": number }, isCurrent?: () => boolean) => boolean; "capturePreparation": () => ((() => void) | (null)); "mounted": () => void; "unmounted": () => void; "dispose": () => void } => {
    // Source "transition/machine.ts":43:7
    let targetOpen: boolean = false;
    // Source "transition/machine.ts":44:7
    let viewMounted: boolean = false;
    // Source "transition/machine.ts":45:7
    let queuedIntent: "enter" | "leave" | null = (null as "enter" | "leave" | null);
    // Source "transition/machine.ts":46:7
    let pendingTask: ((__pui_DelayTask) | (null)) = (null as ((__pui_DelayTask) | (null)));
    // Source "transition/machine.ts":47:7
    let generation: number = 0;
    // Source "transition/machine.ts":48:7
    let ownerEpoch: number = 0;
    // Source "transition/machine.ts":49:7
    let phaseAttempt: number = 0;
    // Source "transition/machine.ts":50:7
    let revision: number = 0;
    // Source "transition/machine.ts":51:7
    let publishing: boolean = false;
    // Source "transition/machine.ts":52:7
    let stagedState: "closed" | "preparing" | "entering" | "entered" | "leaving" | null = (null as "closed" | "preparing" | "entering" | "entered" | "leaving" | null);
    // Source "transition/machine.ts":53:7
    let acknowledged: boolean = false;
    // Source "transition/machine.ts":54:7
    let acknowledgementCurrent: ((() => boolean) | (null)) = (null as ((() => boolean) | (null)));
    // Source "transition/machine.ts":55:7
    let invalidDuration: boolean = false;
    // Source "transition/machine.ts":56:7
    let publicationFailed: boolean = false;
    // Source "transition/machine.ts":57:7
    let activePresentation: (({ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) | (null)) = (null as (({ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) | (null)));
    // Source "transition/machine.ts":58:9
    const sameAttempt = (attempt: { readonly "ownerEpoch": number; readonly "phaseAttempt": number }): boolean => {
      // Source "transition/machine.ts":59:5
      return (((!terminal) && (((activePresentation)?.["attempt"])?.["ownerEpoch"] === (attempt)["ownerEpoch"])) && ((((activePresentation as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"])["phaseAttempt"] === (attempt)["phaseAttempt"]));
    };
    // Source "transition/machine.ts":62:9
    const cancelTask = (): void => {
      // Source "transition/machine.ts":63:11
      const task = pendingTask;
      // Source "transition/machine.ts":64:5
      (pendingTask = null);
      // Source "transition/machine.ts":65:5
      try {
        // Source "transition/machine.ts":66:7
        ((__pui_OptionalReceiver: ((__pui_DelayTask) | (null))) => __pui_OptionalReceiver == null ? undefined : __pui_OptionalReceiver.cancel())(task);
      } catch {
      }
    };
    // Source "transition/machine.ts":71:7
    let terminal: boolean = false;
    // Source "transition/machine.ts":72:7
    let operationVersion: number = 0;
    // Source "transition/machine.ts":73:7
    let starting: { "kind": "enter" | "leave"; "version": number } | null = (null as { "kind": "enter" | "leave"; "version": number } | null);
    // Source "transition/machine.ts":74:9
    const currentOperation = (version: number): boolean => {
      // Source "transition/machine.ts":74:49
      return ((!terminal) && (operationVersion === version));
    };
    // Source "transition/machine.ts":75:9
    const updateTarget = (open: boolean): void => {
      // Source "transition/machine.ts":76:5
      if ((targetOpen !== open)) {
        // Source "transition/machine.ts":76:30
        (operationVersion = (operationVersion + 1));
      }
      // Source "transition/machine.ts":77:5
      (targetOpen = open);
    };
    // Source "transition/machine.ts":85:7
    let preparation: { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean } | null = (null as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean } | null);
    // Source "transition/machine.ts":87:9
    const cancelPreparation = (): void => {
      // Source "transition/machine.ts":88:5
      (preparation = null);
    };
    // Source "transition/machine.ts":90:9
    const isPreparing = (attempt: { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }): boolean => {
      // Source "transition/machine.ts":91:5
      return ((((!terminal) && targetOpen) && (preparation === attempt)) && (((driver)["getState"])() === "preparing"));
    };
    // Source "transition/machine.ts":93:9
    const finishPreparation = (attempt: { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }): void => {
      // Source "transition/machine.ts":94:5
      if ((((((!(isPreparing)(attempt)) || (!(attempt)["presentRequested"])) || (!viewMounted)) || (!(attempt)["ready"])) || (attempt)["finishing"])) {
        // Source "transition/machine.ts":101:7
        return;
      }
      // Source "transition/machine.ts":102:5
      ((attempt)["finishing"] = true);
      // Source "transition/machine.ts":103:5
      if ((!(attempt)["animate"])) {
        // Source "transition/machine.ts":104:7
        (preparation = null);
        // Source "transition/machine.ts":105:7
        (setState)("entered");
        // Source "transition/machine.ts":106:7
        return;
      }
      // Source "transition/machine.ts":108:5
      ((driver)["emit"])("beforeEnter");
      // Source "transition/machine.ts":109:5
      if (((!(isPreparing)(attempt)) || (!viewMounted))) {
        // Source "transition/machine.ts":109:48
        return;
      }
      // Source "transition/machine.ts":110:11
      const frame = (setState)("entering");
      // Source "transition/machine.ts":111:5
      if (((((frame && (activePresentation === (frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))) && (!terminal)) && viewMounted) && (((driver)["getState"])() === "entering"))) {
        // Source "transition/machine.ts":118:7
        if ((preparation === attempt)) {
          // Source "transition/machine.ts":118:36
          (preparation = null);
        }
        // Source "transition/machine.ts":119:7
        (armCompletion)("entering");
        // Source "transition/machine.ts":120:7
        return;
      }
      // Source "transition/machine.ts":122:5
      if ((((((preparation !== attempt) || terminal) || (!targetOpen)) || (!viewMounted)) || (((driver)["getState"])() !== "entering"))) {
        // Source "transition/machine.ts":129:7
        if ((preparation === attempt)) {
          // Source "transition/machine.ts":129:36
          (preparation = null);
        }
        // Source "transition/machine.ts":130:7
        return;
      }
      // Source "transition/machine.ts":132:5
      (preparation = null);
      // Source "transition/machine.ts":133:5
      (armCompletion)("entering");
    };
    // Source "transition/machine.ts":136:9
    const beginPreparation = (animate: boolean): void => {
      // Source "transition/machine.ts":137:11
      const operation = (++operationVersion);
      // Source "transition/machine.ts":138:5
      (invalidateCompletion)();
      // Source "transition/machine.ts":139:5
      if ((!((!terminal) && (operationVersion === operation)))) {
        // Source "transition/machine.ts":139:39
        return;
      }
      // Source "transition/machine.ts":140:5
      (queuedIntent = null);
      // Source "transition/machine.ts":141:11
      const attempt = ({ ["ready"]: false, ["finishing"]: false, ["animate"]: animate, ["presentRequested"]: false } as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean });
      // Source "transition/machine.ts":147:5
      (preparation = attempt);
      // Source "transition/machine.ts":148:5
      (setState)("preparing");
      // Source "transition/machine.ts":149:5
      if ((!(isPreparing)(attempt))) {
        // Source "transition/machine.ts":149:32
        return;
      }
      // Source "transition/machine.ts":150:5
      ((driver)["setViewPresent"])(true);
      // Source "transition/machine.ts":151:5
      if ((!(isPreparing)(attempt))) {
        // Source "transition/machine.ts":151:32
        return;
      }
      // Source "transition/machine.ts":152:5
      ((attempt)["presentRequested"] = true);
      // Source "transition/machine.ts":153:5
      (finishPreparation)(attempt);
    };
    // Source "transition/machine.ts":156:9
    const invalidateCompletion = (): void => {
      // Source "transition/machine.ts":157:5
      (generation = (generation + 1));
      // Source "transition/machine.ts":158:5
      (activePresentation = null);
      // Source "transition/machine.ts":159:5
      (acknowledged = false);
      // Source "transition/machine.ts":160:5
      (acknowledgementCurrent = null);
      // Source "transition/machine.ts":161:5
      (cancelTask)();
    };
    // Source "transition/machine.ts":164:9
    const setState = (state: "closed" | "preparing" | "entering" | "entered" | "leaving"): (({ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) | (undefined)) => {
      // Source "transition/machine.ts":165:11
      const policy = (((driver)["getCompletion"])?.() ?? "timer");
      // Source "transition/machine.ts":166:5
      if ((policy === "timer")) {
        // Source "transition/machine.ts":167:7
        ((driver)["setState"])(state);
        // Source "transition/machine.ts":168:7
        return;
      }
      // Source "transition/machine.ts":170:11
      const moving = ((state === "entering") || ((state as "closed" | "preparing" | "entered" | "leaving") === "leaving"));
      // Source "transition/machine.ts":171:11
      const duration = (moving ? ((driver)["getDuration"])((state as "entering" | "leaving")) : 0);
      // Source "transition/machine.ts":172:5
      (invalidDuration = (((!Number.isFinite(duration)) || (duration < 0)) || (moving && (duration >= ((policy as { readonly "kind": "presentation"; readonly "timeoutMs": number }))["timeoutMs"]))));
      // Source "transition/machine.ts":174:5
      (publicationFailed = false);
      // Source "transition/machine.ts":175:11
      const frame = ((Object.freeze({ ["revision"]: (++revision), ["phase"]: state, ["attempt"]: (moving ? (Object.freeze({ ["ownerEpoch"]: ownerEpoch, ["phaseAttempt"]: (++phaseAttempt) }) as { "ownerEpoch": number; "phaseAttempt": number }) : null), ["completion"]: "presentation", ["durationMs"]: ((Number.isFinite(duration) && (duration >= 0)) ? duration : ((policy as { readonly "kind": "presentation"; readonly "timeoutMs": number }))["timeoutMs"]), ["timeoutMs"]: ((policy as { readonly "kind": "presentation"; readonly "timeoutMs": number }))["timeoutMs"] }) as { "revision": number; "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; "attempt": { "ownerEpoch": number; "phaseAttempt": number } | null; "completion": "presentation"; "durationMs": number | 0; "timeoutMs": number }) as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null });
      // Source "transition/machine.ts":184:5
      (activePresentation = (moving ? frame : null));
      // Source "transition/machine.ts":185:5
      (acknowledged = false);
      // Source "transition/machine.ts":186:11
      const operation = operationVersion;
      // Source "transition/machine.ts":187:11
      const previousStage = stagedState;
      // Source "transition/machine.ts":188:5
      (stagedState = state);
      // Source "transition/machine.ts":189:5
      (publishing = true);
      // Source "transition/machine.ts":190:5
      try {
        // Source "transition/machine.ts":191:7
        try {
          // Source "transition/machine.ts":192:9
          ((driver)["publishPresentation"])?.(frame);
        } catch {
          // Source "transition/machine.ts":194:9
          (publicationFailed = true);
        }
        // Source "transition/machine.ts":196:13
        const waitingOnSameAttempt = (((moving && (activePresentation === frame)) && (((driver)["getInterrupt"])() === "wait")) && (!terminal));
        // Source "transition/machine.ts":198:7
        if ((((!((!terminal) && (operationVersion === operation))) && (!waitingOnSameAttempt)) || (moving && (activePresentation !== frame)))) {
          // Source "transition/machine.ts":204:9
          if ((((!terminal) && moving) && (activePresentation === frame))) {
            // Source "transition/machine.ts":205:17
            const repairOperation = operationVersion;
            // Source "transition/machine.ts":206:11
            (invalidateCompletion)();
            // Source "transition/machine.ts":207:11
            if ((!((!terminal) && (operationVersion === repairOperation)))) {
              // Source "transition/machine.ts":207:51
              return;
            }
            // Source "transition/machine.ts":208:17
            const actual = ((driver)["getState"])();
            // Source "transition/machine.ts":209:17
            const repaired = (setState)(actual);
            // Source "transition/machine.ts":210:11
            if (((repaired && (activePresentation === (repaired as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))) && ((actual === "entering") || ((actual as "closed" | "preparing" | "entered" | "leaving") === "leaving")))) {
              // Source "transition/machine.ts":215:13
              (armCompletion)((actual as "entering" | "leaving"));
            }
          }
          // Source "transition/machine.ts":217:9
          return;
        }
        // Source "transition/machine.ts":219:7
        ((driver)["setState"])(state);
      } finally {
        // Source "transition/machine.ts":221:7
        (stagedState = previousStage);
        // Source "transition/machine.ts":222:7
        (publishing = (previousStage !== null));
      }
      // Source "transition/machine.ts":224:5
      if (((((((((moving && acknowledged) && (activePresentation === frame)) && (!terminal)) && (((driver)["getState"])() === state)) && (acknowledgementCurrent)?.()) && ((activePresentation as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) === frame)) && (!terminal)) && (((driver)["getState"])() === state))) {
        // Source "transition/machine.ts":235:7
        (completeCurrent)(true);
      }
      // Source "transition/machine.ts":236:5
      return frame;
    };
    // Source "transition/machine.ts":239:9
    const settlePresentation = (frame: { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }, outcome: "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed"): void => {
      // Source "transition/machine.ts":240:5
      if (((!(frame)["attempt"]) || (!(sameAttempt)(((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"])))) {
        // Source "transition/machine.ts":240:56
        return;
      }
      // Source "transition/machine.ts":241:5
      try {
        // Source "transition/machine.ts":242:7
        ((driver)["settlePresentation"])?.(outcome);
      } catch {
      }
      // Source "transition/machine.ts":246:5
      if ((sameAttempt)(((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"])) {
        // Source "transition/machine.ts":246:37
        (completeCurrent)(true);
      }
    };
    // Source "transition/machine.ts":249:9
    const armCompletion = (state: "entering" | "leaving"): void => {
      // Source "transition/machine.ts":250:11
      const frame = activePresentation;
      // Source "transition/machine.ts":251:5
      if ((frame)?.["attempt"]) {
        // Source "transition/machine.ts":252:7
        if (invalidDuration) {
          // Source "transition/machine.ts":253:9
          (settlePresentation)((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }), "invalid-policy");
          // Source "transition/machine.ts":254:9
          return;
        }
        // Source "transition/machine.ts":256:7
        if (publicationFailed) {
          // Source "transition/machine.ts":257:9
          (settlePresentation)((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }), "projection-failed");
          // Source "transition/machine.ts":258:9
          return;
        }
        // Source "transition/machine.ts":260:7
        if ((((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["durationMs"] === 0)) {
          // Source "transition/machine.ts":261:9
          (settlePresentation)((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": 0; readonly "timeoutMs": number | null }), "zero-duration");
          // Source "transition/machine.ts":262:9
          return;
        }
        // Source "transition/machine.ts":264:7
        try {
          // Source "transition/machine.ts":265:15
          const task = ((driver)["schedule"])((((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["timeoutMs"] as number), (): void => {
            // Source "transition/machine.ts":266:11
            if (((!((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"]) || (!(sameAttempt)(((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"])))) {
              // Source "transition/machine.ts":266:62
              return;
            }
            // Source "transition/machine.ts":267:11
            (pendingTask = null);
            // Source "transition/machine.ts":268:11
            (settlePresentation)((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }), "deadline");
          });
          // Source "transition/machine.ts":270:9
          if ((sameAttempt)(((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"])) {
            // Source "transition/machine.ts":270:41
            (pendingTask = task);
          } else {
            // Source "transition/machine.ts":272:11
            try {
              // Source "transition/machine.ts":273:13
              task.cancel();
            } catch {
            }
          }
        } catch {
          // Source "transition/machine.ts":277:9
          (settlePresentation)((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }), "scheduler-failed");
        }
        // Source "transition/machine.ts":279:7
        return;
      }
      // Source "transition/machine.ts":281:5
      (invalidateCompletion)();
      // Source "transition/machine.ts":282:11
      const activeGeneration = generation;
      // Source "transition/machine.ts":283:5
      (pendingTask = ((driver)["schedule"])(((driver)["getDuration"])(state), (): void => {
        // Source "transition/machine.ts":284:7
        if (((activeGeneration !== generation) || (((driver)["getState"])() !== state))) {
          // Source "transition/machine.ts":284:75
          return;
        }
        // Source "transition/machine.ts":285:7
        (pendingTask = null);
        // Source "transition/machine.ts":286:7
        (completeCurrent)(true);
      }));
    };
    // Source "transition/machine.ts":290:9
    const beginEnter = (cold: boolean = true): void => {
      // Source "transition/machine.ts":291:5
      if ((terminal || (!targetOpen))) {
        // Source "transition/machine.ts":291:34
        return;
      }
      // Source "transition/machine.ts":292:5
      if ((((starting)?.["kind"] === "enter") && (currentOperation)(((starting as { "kind": "enter"; "version": number }))["version"]))) {
        // Source "transition/machine.ts":292:75
        return;
      }
      // Source "transition/machine.ts":293:5
      if ((cold && ((driver)["requiresColdPreparation"])?.())) {
        // Source "transition/machine.ts":294:7
        (beginPreparation)(true);
        // Source "transition/machine.ts":295:7
        return;
      }
      // Source "transition/machine.ts":297:11
      const operation: { "kind": "enter"; "version": number } = { ["kind"]: "enter", ["version"]: (++operationVersion) };
      // Source "transition/machine.ts":298:5
      (starting = operation);
      // Source "transition/machine.ts":299:11
      const current = (): boolean => {
        // Source "transition/machine.ts":299:27
        return ((currentOperation)((operation)["version"]) && targetOpen);
      };
      // Source "transition/machine.ts":300:5
      try {
        // Source "transition/machine.ts":301:7
        ((driver)["setViewPresent"])(true);
        // Source "transition/machine.ts":302:7
        if (((!(current)()) || (!viewMounted))) {
          // Source "transition/machine.ts":302:39
          return;
        }
        // Source "transition/machine.ts":303:7
        (queuedIntent = null);
        // Source "transition/machine.ts":304:7
        ((driver)["emit"])("beforeEnter");
        // Source "transition/machine.ts":305:7
        if (((!(current)()) || (!viewMounted))) {
          // Source "transition/machine.ts":305:39
          return;
        }
        // Source "transition/machine.ts":306:7
        (invalidateCompletion)();
        // Source "transition/machine.ts":307:7
        if ((!(current)())) {
          // Source "transition/machine.ts":307:23
          return;
        }
        // Source "transition/machine.ts":308:13
        const frame = (setState)("entering");
        // Source "transition/machine.ts":309:7
        if ((((((frame && (activePresentation === (frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))) && (((activePresentation as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))?.["phase"] === "entering")) && (!terminal)) && viewMounted) && (((driver)["getState"])() === "entering"))) {
          // Source "transition/machine.ts":317:9
          (armCompletion)("entering");
          // Source "transition/machine.ts":318:9
          return;
        }
        // Source "transition/machine.ts":320:7
        if ((((!(current)()) || (!viewMounted)) || (((driver)["getState"])() !== "entering"))) {
          // Source "transition/machine.ts":320:75
          return;
        }
        // Source "transition/machine.ts":321:7
        (armCompletion)("entering");
      } finally {
        // Source "transition/machine.ts":323:7
        if ((starting === operation)) {
          // Source "transition/machine.ts":323:35
          (starting = null);
        }
      }
    };
    // Source "transition/machine.ts":327:9
    const beginLeave = (): void => {
      // Source "transition/machine.ts":328:5
      if ((terminal || targetOpen)) {
        // Source "transition/machine.ts":328:33
        return;
      }
      // Source "transition/machine.ts":329:11
      const operation: { "kind": "leave"; "version": number } = { ["kind"]: "leave", ["version"]: (++operationVersion) };
      // Source "transition/machine.ts":330:5
      (starting = operation);
      // Source "transition/machine.ts":331:11
      const current = (): boolean => {
        // Source "transition/machine.ts":331:27
        return ((currentOperation)((operation)["version"]) && (!targetOpen));
      };
      // Source "transition/machine.ts":332:5
      try {
        // Source "transition/machine.ts":333:7
        (queuedIntent = null);
        // Source "transition/machine.ts":334:7
        ((driver)["emit"])("beforeLeave");
        // Source "transition/machine.ts":335:7
        if ((!(current)())) {
          // Source "transition/machine.ts":335:23
          return;
        }
        // Source "transition/machine.ts":336:7
        (invalidateCompletion)();
        // Source "transition/machine.ts":337:7
        if ((!(current)())) {
          // Source "transition/machine.ts":337:23
          return;
        }
        // Source "transition/machine.ts":338:13
        const frame = (setState)("leaving");
        // Source "transition/machine.ts":339:7
        if (((((frame && (activePresentation === (frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))) && (((activePresentation as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))?.["phase"] === "leaving")) && (!terminal)) && (((driver)["getState"])() === "leaving"))) {
          // Source "transition/machine.ts":346:9
          (armCompletion)("leaving");
          // Source "transition/machine.ts":347:9
          return;
        }
        // Source "transition/machine.ts":349:7
        if (((!(current)()) || (((driver)["getState"])() !== "leaving"))) {
          // Source "transition/machine.ts":349:58
          return;
        }
        // Source "transition/machine.ts":350:7
        (armCompletion)("leaving");
      } finally {
        // Source "transition/machine.ts":352:7
        if ((starting === operation)) {
          // Source "transition/machine.ts":352:35
          (starting = null);
        }
      }
    };
    // Source "transition/machine.ts":356:9
    const consumeQueuedIntent = (): void => {
      // Source "transition/machine.ts":357:11
      const next = queuedIntent;
      // Source "transition/machine.ts":358:5
      (queuedIntent = null);
      // Source "transition/machine.ts":359:5
      if ((next === "enter")) {
        // Source "transition/machine.ts":359:27
        (enter)();
      } else {
        // Source "transition/machine.ts":360:10
        if (((next as "leave" | null) === "leave")) {
          // Source "transition/machine.ts":360:32
          (leave)();
        }
      }
    };
    // Source "transition/machine.ts":363:9
    const completeCurrent = (consumeQueue: boolean): boolean => {
      // Source "transition/machine.ts":364:11
      const current = ((driver)["getState"])();
      // Source "transition/machine.ts":365:5
      if (((current !== "entering") && ((current as "closed" | "preparing" | "entered" | "leaving") !== "leaving"))) {
        // Source "transition/machine.ts":365:58
        return false;
      }
      // Source "transition/machine.ts":366:11
      const operation = (++operationVersion);
      // Source "transition/machine.ts":367:5
      (invalidateCompletion)();
      // Source "transition/machine.ts":368:5
      if ((!((!terminal) && (operationVersion === operation)))) {
        // Source "transition/machine.ts":368:39
        return false;
      }
      // Source "transition/machine.ts":370:5
      if (((current as "entering" | "leaving") === "entering")) {
        // Source "transition/machine.ts":371:7
        (setState)("entered");
        // Source "transition/machine.ts":372:7
        if (((!((!terminal) && (operationVersion === operation))) || (((driver)["getState"])() !== "entered"))) {
          // Source "transition/machine.ts":372:76
          return false;
        }
        // Source "transition/machine.ts":373:7
        ((driver)["emit"])("afterEnter");
      } else {
        // Source "transition/machine.ts":375:7
        (setState)("closed");
        // Source "transition/machine.ts":376:7
        if (((!((!terminal) && (operationVersion === operation))) || (((driver)["getState"])() !== "closed"))) {
          // Source "transition/machine.ts":376:75
          return false;
        }
        // Source "transition/machine.ts":377:7
        ((driver)["emit"])("afterLeave");
        // Source "transition/machine.ts":378:7
        if (((!((!terminal) && (operationVersion === operation))) || (((driver)["getState"])() !== "closed"))) {
          // Source "transition/machine.ts":378:75
          return false;
        }
        // Source "transition/machine.ts":379:7
        ((driver)["setViewPresent"])(false);
      }
      // Source "transition/machine.ts":382:5
      if ((consumeQueue && ((!terminal) && (operationVersion === operation)))) {
        // Source "transition/machine.ts":382:54
        (consumeQueuedIntent)();
      }
      // Source "transition/machine.ts":383:5
      return ((!terminal) && (operationVersion === operation));
    };
    // Source "transition/machine.ts":386:9
    const enter = (): void => {
      // Source "transition/machine.ts":387:5
      if (terminal) {
        // Source "transition/machine.ts":387:19
        return;
      }
      // Source "transition/machine.ts":388:5
      (updateTarget)(true);
      // Source "transition/machine.ts":389:5
      if ((((starting)?.["kind"] === "enter") && (currentOperation)(((starting as { "kind": "enter"; "version": number }))["version"]))) {
        // Source "transition/machine.ts":389:75
        return;
      }
      // Source "transition/machine.ts":390:11
      const current = (stagedState ?? ((driver)["getState"])());
      // Source "transition/machine.ts":391:5
      if (((current === "entered") || ((current as "closed" | "preparing" | "entering" | "leaving") === "preparing"))) {
        // Source "transition/machine.ts":391:59
        return;
      }
      // Source "transition/machine.ts":393:5
      if (((current as "closed" | "entering" | "leaving") === "closed")) {
        // Source "transition/machine.ts":394:7
        (beginEnter)();
        // Source "transition/machine.ts":395:7
        return;
      }
      // Source "transition/machine.ts":398:5
      if (((current as "entering" | "leaving") === "entering")) {
        // Source "transition/machine.ts":399:7
        if (((((((starting as { "kind": "leave"; "version": number } | null | { "kind": "enter"; "version": number }))?.["kind"] === "leave") && (!activePresentation)) && (((driver)["getCompletion"])?.() !== "timer")) && (driver)["getCompletion"])) {
          // Source "transition/machine.ts":405:9
          (beginEnter)(false);
          // Source "transition/machine.ts":406:9
          return;
        }
        // Source "transition/machine.ts":408:7
        if ((((driver)["getInterrupt"])() === "wait")) {
          // Source "transition/machine.ts":408:45
          (queuedIntent = null);
        }
        // Source "transition/machine.ts":409:7
        return;
      }
      // Source "transition/machine.ts":412:11
      const interrupt = ((driver)["getInterrupt"])();
      // Source "transition/machine.ts":413:5
      if ((interrupt === "wait")) {
        // Source "transition/machine.ts":414:7
        (queuedIntent = "enter");
      } else {
        // Source "transition/machine.ts":415:12
        if (((interrupt as "reverse" | "immediate") === "immediate")) {
          // Source "transition/machine.ts":416:7
          if ((completeCurrent)(false)) {
            // Source "transition/machine.ts":416:35
            (beginEnter)(false);
          }
        } else {
          // Source "transition/machine.ts":418:7
          (beginEnter)(false);
        }
      }
    };
    // Source "transition/machine.ts":422:9
    const leave = (): void => {
      // Source "transition/machine.ts":423:5
      if (terminal) {
        // Source "transition/machine.ts":423:19
        return;
      }
      // Source "transition/machine.ts":424:5
      (updateTarget)(false);
      // Source "transition/machine.ts":425:5
      if ((((starting)?.["kind"] === "leave") && (currentOperation)(((starting as { "kind": "leave"; "version": number }))["version"]))) {
        // Source "transition/machine.ts":425:75
        return;
      }
      // Source "transition/machine.ts":426:11
      const current = (stagedState ?? ((driver)["getState"])());
      // Source "transition/machine.ts":427:5
      if ((current === "preparing")) {
        // Source "transition/machine.ts":428:7
        (cancelPreparation)();
        // Source "transition/machine.ts":429:7
        (invalidateCompletion)();
        // Source "transition/machine.ts":430:7
        (queuedIntent = null);
        // Source "transition/machine.ts":431:7
        (setState)("closed");
        // Source "transition/machine.ts":432:7
        if (((!targetOpen) && (((driver)["getState"])() === "closed"))) {
          // Source "transition/machine.ts":432:58
          ((driver)["setViewPresent"])(false);
        }
        // Source "transition/machine.ts":433:7
        return;
      }
      // Source "transition/machine.ts":436:5
      if (((current as "closed" | "entering" | "entered" | "leaving") === "closed")) {
        // Source "transition/machine.ts":437:7
        ((driver)["setViewPresent"])(false);
        // Source "transition/machine.ts":438:7
        return;
      }
      // Source "transition/machine.ts":441:5
      if (((current as "entering" | "entered" | "leaving") === "leaving")) {
        // Source "transition/machine.ts":442:7
        if (((((((starting as { "kind": "enter"; "version": number } | null | { "kind": "leave"; "version": number }))?.["kind"] === "enter") && (!activePresentation)) && (((driver)["getCompletion"])?.() !== "timer")) && (driver)["getCompletion"])) {
          // Source "transition/machine.ts":448:9
          (beginLeave)();
          // Source "transition/machine.ts":449:9
          return;
        }
        // Source "transition/machine.ts":451:7
        if ((((driver)["getInterrupt"])() === "wait")) {
          // Source "transition/machine.ts":451:45
          (queuedIntent = null);
        }
        // Source "transition/machine.ts":452:7
        return;
      }
      // Source "transition/machine.ts":455:5
      if (((current as "entering" | "entered") === "entered")) {
        // Source "transition/machine.ts":456:7
        (beginLeave)();
        // Source "transition/machine.ts":457:7
        return;
      }
      // Source "transition/machine.ts":460:11
      const interrupt = ((driver)["getInterrupt"])();
      // Source "transition/machine.ts":461:5
      if ((interrupt === "wait")) {
        // Source "transition/machine.ts":462:7
        (queuedIntent = "leave");
      } else {
        // Source "transition/machine.ts":463:12
        if (((interrupt as "reverse" | "immediate") === "immediate")) {
          // Source "transition/machine.ts":464:7
          if ((completeCurrent)(false)) {
            // Source "transition/machine.ts":464:35
            (beginLeave)();
          }
        } else {
          // Source "transition/machine.ts":466:7
          (beginLeave)();
        }
      }
    };
    // Source "transition/machine.ts":470:9
    const initialize = (open: boolean, appear: boolean): void => {
      // Source "transition/machine.ts":471:5
      if (terminal) {
        // Source "transition/machine.ts":471:19
        return;
      }
      // Source "transition/machine.ts":472:11
      const operation = (++operationVersion);
      // Source "transition/machine.ts":473:5
      (ownerEpoch = (ownerEpoch + 1));
      // Source "transition/machine.ts":474:5
      (cancelPreparation)();
      // Source "transition/machine.ts":475:5
      (targetOpen = open);
      // Source "transition/machine.ts":476:5
      (queuedIntent = null);
      // Source "transition/machine.ts":477:5
      (invalidateCompletion)();
      // Source "transition/machine.ts":478:5
      if ((!((!terminal) && (operationVersion === operation)))) {
        // Source "transition/machine.ts":478:39
        return;
      }
      // Source "transition/machine.ts":480:5
      if ((!open)) {
        // Source "transition/machine.ts":481:7
        (setState)("closed");
        // Source "transition/machine.ts":482:7
        if (((!((!terminal) && (operationVersion === operation))) || targetOpen)) {
          // Source "transition/machine.ts":482:55
          return;
        }
        // Source "transition/machine.ts":483:7
        ((driver)["setViewPresent"])(false);
        // Source "transition/machine.ts":484:7
        return;
      }
      // Source "transition/machine.ts":487:5
      if (((driver)["requiresColdPreparation"])?.()) {
        // Source "transition/machine.ts":488:7
        (beginPreparation)(appear);
        // Source "transition/machine.ts":489:7
        return;
      }
      // Source "transition/machine.ts":491:5
      ((driver)["setViewPresent"])(true);
      // Source "transition/machine.ts":492:5
      if (((!((!terminal) && (operationVersion === operation))) || (!targetOpen))) {
        // Source "transition/machine.ts":492:54
        return;
      }
      // Source "transition/machine.ts":493:5
      if ((!appear)) {
        // Source "transition/machine.ts":493:18
        (setState)("entered");
      }
    };
    // Source "transition/machine.ts":496:9
    const mounted = (): void => {
      // Source "transition/machine.ts":497:5
      if (terminal) {
        // Source "transition/machine.ts":497:19
        return;
      }
      // Source "transition/machine.ts":498:5
      (viewMounted = true);
      // Source "transition/machine.ts":499:5
      if (preparation) {
        // Source "transition/machine.ts":500:7
        (finishPreparation)((preparation as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }));
        // Source "transition/machine.ts":501:7
        return;
      }
      // Source "transition/machine.ts":503:5
      if ((targetOpen && (((driver)["getState"])() === "closed"))) {
        // Source "transition/machine.ts":503:55
        (beginEnter)();
      }
    };
    // Source "transition/machine.ts":506:9
    const unmounted = (): void => {
      // Source "transition/machine.ts":507:5
      (ownerEpoch = (ownerEpoch + 1));
      // Source "transition/machine.ts":508:11
      const operation = (++operationVersion);
      // Source "transition/machine.ts":509:5
      (cancelPreparation)();
      // Source "transition/machine.ts":510:5
      (viewMounted = false);
      // Source "transition/machine.ts":511:5
      (invalidateCompletion)();
      // Source "transition/machine.ts":512:5
      if ((!((!terminal) && (operationVersion === operation)))) {
        // Source "transition/machine.ts":512:39
        return;
      }
      // Source "transition/machine.ts":513:5
      (queuedIntent = null);
      // Source "transition/machine.ts":514:5
      if ((((driver)["getState"])() !== "closed")) {
        // Source "transition/machine.ts":514:41
        (setState)("closed");
      }
    };
    // Source "transition/machine.ts":517:9
    const dispose = (): void => {
      // Source "transition/machine.ts":518:5
      (terminal = true);
      // Source "transition/machine.ts":519:5
      (ownerEpoch = (ownerEpoch + 1));
      // Source "transition/machine.ts":520:5
      (operationVersion = (operationVersion + 1));
      // Source "transition/machine.ts":521:5
      (cancelPreparation)();
      // Source "transition/machine.ts":522:5
      (viewMounted = false);
      // Source "transition/machine.ts":523:5
      (queuedIntent = null);
      // Source "transition/machine.ts":524:5
      (invalidateCompletion)();
    };
    // Source "transition/machine.ts":527:3
    return { ["initialize"]: initialize, ["setTarget"]: (open: boolean): void => {
      // Source "transition/machine.ts":530:7
      if (terminal) {
        // Source "transition/machine.ts":530:21
        return;
      }
      // Source "transition/machine.ts":531:7
      if ((open === targetOpen)) {
        // Source "transition/machine.ts":531:32
        return;
      }
      // Source "transition/machine.ts":532:7
      if (open) {
        // Source "transition/machine.ts":532:17
        (enter)();
      } else {
        // Source "transition/machine.ts":533:12
        (leave)();
      }
    }, ["enter"]: enter, ["leave"]: leave, ["complete"]: (): void => {
      // Source "transition/machine.ts":538:7
      if ((!terminal)) {
        // Source "transition/machine.ts":538:22
        (completeCurrent)(true);
      }
    }, ["completePresentation"]: (attempt: { readonly "ownerEpoch": number; readonly "phaseAttempt": number }, isCurrent: () => boolean = (): boolean => {
      // Source "transition/machine.ts":540:55
      return true;
    }): boolean => {
      // Source "transition/machine.ts":541:13
      const validate = (): boolean => {
        // Source "transition/machine.ts":542:9
        try {
          // Source "transition/machine.ts":543:11
          return (isCurrent)();
        } catch {
          // Source "transition/machine.ts":545:11
          return false;
        }
      };
      // Source "transition/machine.ts":548:7
      if ((((!(sameAttempt)(attempt)) || (!(validate)())) || (!(sameAttempt)(attempt)))) {
        // Source "transition/machine.ts":548:74
        return false;
      }
      // Source "transition/machine.ts":549:7
      if (publishing) {
        // Source "transition/machine.ts":550:9
        (acknowledged = true);
        // Source "transition/machine.ts":551:9
        (acknowledgementCurrent = validate);
        // Source "transition/machine.ts":552:9
        return true;
      }
      // Source "transition/machine.ts":554:7
      return (completeCurrent)(true);
    }, ["capturePreparation"]: (): ((() => void) | (null)) => {
      // Source "transition/machine.ts":557:13
      const attempt = preparation;
      // Source "transition/machine.ts":558:7
      if (((!attempt) || (!(isPreparing)((attempt as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }))))) {
        // Source "transition/machine.ts":558:46
        return null;
      }
      // Source "transition/machine.ts":559:7
      return (): void => {
        // Source "transition/machine.ts":560:9
        if (((!(isPreparing)((attempt as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }))) || ((attempt as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }))["finishing"])) {
          // Source "transition/machine.ts":560:57
          return;
        }
        // Source "transition/machine.ts":561:9
        (((attempt as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }))["ready"] = true);
        // Source "transition/machine.ts":562:9
        (finishPreparation)((attempt as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }));
      };
    }, ["mounted"]: mounted, ["unmounted"]: unmounted, ["dispose"]: dispose };
  };
  const __pui_Hook0 = (options?: unknown) => (__pui_Authored.install({name: "asTransition", mode: "once", setup: (options, api) => ((def: typeof __pui_Def) => {
      // Source "transition/as-transition.proto.ts":42:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0: Parameters<typeof __pui_CaptureReceiver.props.define>[0] = { ["open"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["defaultOpen"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["appear"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["enterDuration"]: { ["type"]: "number", ["empty"]: "fallback" }, ["leaveDuration"]: { ["type"]: "number", ["empty"]: "fallback" }, ["interrupt"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["reverse", "wait", "immediate"] } };
const __pui_CaptureResult = __pui_CaptureReceiver.props.define(__pui_CaptureArg0); __pui_Authored.effect("props", {"op": "define", "specMap": __pui_CaptureArg0}); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":54:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = { ["defaultOpen"]: false, ["appear"]: false, ["enterDuration"]: 300, ["leaveDuration"]: 200, ["interrupt"]: "reverse" };
const __pui_CaptureResult = __pui_CaptureReceiver.props.setDefaults(__pui_CaptureArg0); __pui_Authored.effect("props", {"op": "setDefaults", "partial": __pui_CaptureArg0}); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":62:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "beforeEnter";
const __pui_CaptureArg1: Parameters<typeof __pui_CaptureReceiver.expose.event>[1] = { ["payload"]: "void" };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.event(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("event", {"op": "expose.event", "key": __pui_CaptureArg0, "spec": __pui_CaptureArg1}); __pui_Authored.eventKey(__pui_CaptureArg0); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":63:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "afterEnter";
const __pui_CaptureArg1: Parameters<typeof __pui_CaptureReceiver.expose.event>[1] = { ["payload"]: "void" };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.event(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("event", {"op": "expose.event", "key": __pui_CaptureArg0, "spec": __pui_CaptureArg1}); __pui_Authored.eventKey(__pui_CaptureArg0); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":64:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "beforeLeave";
const __pui_CaptureArg1: Parameters<typeof __pui_CaptureReceiver.expose.event>[1] = { ["payload"]: "void" };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.event(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("event", {"op": "expose.event", "key": __pui_CaptureArg0, "spec": __pui_CaptureArg1}); __pui_Authored.eventKey(__pui_CaptureArg0); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":65:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "afterLeave";
const __pui_CaptureArg1: Parameters<typeof __pui_CaptureReceiver.expose.event>[1] = { ["payload"]: "void" };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.event(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("event", {"op": "expose.event", "key": __pui_CaptureArg0, "spec": __pui_CaptureArg1}); __pui_Authored.eventKey(__pui_CaptureArg0); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":67:11
      const transitionState = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "transitionState";
const __pui_CaptureArg1 = "closed";
const __pui_CaptureArg2 = { ["options"]: ["closed", "preparing", "entering", "entered", "leaving"] };
const __pui_CaptureResult = __pui_CaptureReceiver.state.enum(__pui_CaptureArg0, __pui_CaptureArg1, __pui_CaptureArg2); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":72:11
      const isPresent = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "isPresent";
const __pui_CaptureArg1 = false;
const __pui_CaptureResult = __pui_CaptureReceiver.state.bool(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":73:11
      const appearDefault = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "transitionAppearDefault";
const __pui_CaptureArg1 = false;
const __pui_CaptureResult = __pui_CaptureReceiver.state.bool(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":74:11
      const coldEntryPreparation = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "transitionColdEntryPreparation";
const __pui_CaptureArg1 = false;
const __pui_CaptureResult = __pui_CaptureReceiver.state.bool(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":75:11
      const enterDurationDefault = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "transitionEnterDurationDefault";
const __pui_CaptureArg1 = 300;
const __pui_CaptureResult = __pui_CaptureReceiver.state.numberDiscrete(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":76:11
      const leaveDurationDefault = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "transitionLeaveDurationDefault";
const __pui_CaptureArg1 = 200;
const __pui_CaptureResult = __pui_CaptureReceiver.state.numberDiscrete(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":77:11
      const interruptDefault = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "transitionInterruptDefault";
const __pui_CaptureArg1 = "reverse";
const __pui_CaptureArg2 = { ["options"]: ["reverse", "wait", "immediate"] };
const __pui_CaptureResult = __pui_CaptureReceiver.state.enum(__pui_CaptureArg0, __pui_CaptureArg1, __pui_CaptureArg2); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":83:9
      let initialOpenSource: (({ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) | (null)) = (null as (({ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) | (null)));
      // Source "transition/as-transition.proto.ts":85:9
      let openContextSource: (({ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) | (null)) = (null as (({ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) | (null)));
      // Source "transition/as-transition.proto.ts":87:11
      const closedViewRetained = (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "transitionClosedViewRetained";
const __pui_CaptureArg1 = false;
const __pui_CaptureResult = __pui_CaptureReceiver.state.bool(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", __pui_CaptureResult); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":88:11
      const bindInitialOpen = (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }): void => {
        // Source "transition/as-transition.proto.ts":90:7
        appearDefault.setDefault((appearDefault.get() as boolean));
        // Source "transition/as-transition.proto.ts":91:7
        if ((((((!source) || ((typeof (source)["field"]) !== "string")) || (!(source)["field"])) || (!(source)["context"])) || (((source)["context"])["__brand"] !== "ContextKey"))) {
          // Source "transition/as-transition.proto.ts":98:9
          throw new Error("[asTransition] initial open source requires a ContextKey and direct field.");
        }
        // Source "transition/as-transition.proto.ts":102:7
        if (initialOpenSource) {
          // Source "transition/as-transition.proto.ts":103:9
          if (((((initialOpenSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["context"] === (source)["context"]) && (((initialOpenSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["field"] === (source)["field"]))) {
            // Source "transition/as-transition.proto.ts":107:11
            return;
          }
          // Source "transition/as-transition.proto.ts":108:9
          throw new Error("[asTransition] initial open source is already bound.");
        }
        // Source "transition/as-transition.proto.ts":110:7
        (initialOpenSource = (Object.freeze({ ["context"]: (source)["context"], ["field"]: (source)["field"] }) as { "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; "field": string }));
      };
      // Source "transition/as-transition.proto.ts":112:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "bindInitialOpen";
const __pui_CaptureArg1 = bindInitialOpen;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":114:11
      const presentation = (void (def), __pui_Presence.owner());
      // Source "transition/as-transition.proto.ts":115:9
      let completion: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number })) = ("timer" as (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number })));
      // Source "transition/as-transition.proto.ts":116:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "getPresentationOwner";
const __pui_CaptureArg1 = (): Readonly<object> => {
        // Source "transition/as-transition.proto.ts":116:53
        return (presentation)["ref"];
      };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":117:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "configurePresentation";
const __pui_CaptureArg1 = (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }): void => {
        // Source "transition/as-transition.proto.ts":118:7
        appearDefault.setDefault((appearDefault.get() as boolean));
        // Source "transition/as-transition.proto.ts":119:13
        const policy = __pui_SnapshotCompletion(((config)["completion"] ?? completion));
        // Source "transition/as-transition.proto.ts":120:13
        const enter = ((config)["enterDuration"] ?? (enterDurationDefault.get() as number));
        // Source "transition/as-transition.proto.ts":121:13
        const leave = ((config)["leaveDuration"] ?? (leaveDurationDefault.get() as number));
        // Source "transition/as-transition.proto.ts":122:7
        if ((!([enter, leave]).every((value: number): boolean => {
          // Source "transition/as-transition.proto.ts":122:44
          return (Number.isFinite(value) && (value >= 0));
        }))) {
          // Source "transition/as-transition.proto.ts":123:9
          throw new Error("[asTransition] durations must be finite non-negative numbers.");
        }
        // Source "transition/as-transition.proto.ts":124:7
        if (((policy !== "timer") && ((enter >= ((policy as { readonly "kind": "presentation"; readonly "timeoutMs": number }))["timeoutMs"]) || (leave >= ((policy as { readonly "kind": "presentation"; readonly "timeoutMs": number }))["timeoutMs"])))) {
          // Source "transition/as-transition.proto.ts":125:9
          throw new Error("[asTransition] presentation duration must be shorter than timeoutMs.");
        }
        // Source "transition/as-transition.proto.ts":126:7
        (completion = policy);
      };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":128:9
      let currentRun: ((__pui_Run) | (null)) = (null as ((__pui_Run) | (null)));
      // Source "transition/as-transition.proto.ts":132:9
      let phaseViewRequested: boolean = false;
      // Source "transition/as-transition.proto.ts":133:11
      const getProps = (): ((__pui_ResolvedProps) | (undefined)) => {
        // Source "transition/as-transition.proto.ts":133:28
        return ((__pui_OptionalReceiver: ((__pui_Run) | (null))) => __pui_OptionalReceiver == null ? undefined : __pui_OptionalReceiver.props.get())(currentRun);
      };
      // Source "transition/as-transition.proto.ts":135:11
      const driver = ({ ["getState"]: (): "closed" | "preparing" | "entering" | "entered" | "leaving" => {
        // Source "transition/as-transition.proto.ts":136:23
        return (transitionState.get() as "closed" | "preparing" | "entering" | "entered" | "leaving");
      }, ["setState"]: (state: "closed" | "preparing" | "entering" | "entered" | "leaving"): void => {
        // Source "transition/as-transition.proto.ts":138:9
        transitionState.set(state, ("reason: asTransition => " + state));
        // Source "transition/as-transition.proto.ts":140:9
        if ((!currentRun)) {
          // Source "transition/as-transition.proto.ts":140:26
          return;
        }
        // Source "transition/as-transition.proto.ts":142:15
        const currentState = (transitionState.get() as "closed" | "preparing" | "entering" | "entered" | "leaving");
        // Source "transition/as-transition.proto.ts":143:9
        isPresent.set((currentState !== "closed"), ("reason: asTransition presence => " + currentState));
      }, ["requiresColdPreparation"]: (): boolean => {
        // Source "transition/as-transition.proto.ts":148:38
        return (coldEntryPreparation.get() as boolean);
      }, ["getCompletion"]: (): (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number })) => {
        // Source "transition/as-transition.proto.ts":149:28
        return completion;
      }, ["publishPresentation"]: (frame: { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }): void => {
        // Source "transition/as-transition.proto.ts":151:9
        return ((__pui_OptionalReceiver: ((__pui_Run) | (null))) => __pui_OptionalReceiver == null ? undefined : (void (__pui_OptionalReceiver), __pui_Presence.publish((presentation)["writer"], ({ ...(frame), ["owner"]: (presentation)["ref"] }))))(currentRun);
      }, ["settlePresentation"]: (outcome: "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed"): void => {
        // Source "transition/as-transition.proto.ts":156:9
        return ((__pui_OptionalReceiver: ((__pui_Run) | (null))) => __pui_OptionalReceiver == null ? undefined : (void (__pui_OptionalReceiver), __pui_Presence.settle((presentation)["writer"], outcome)))(currentRun);
      }, ["getInterrupt"]: (): "reverse" | "wait" | "immediate" => {
        // Source "transition/as-transition.proto.ts":158:9
        return (((__pui_OptionalReceiver: ((__pui_Run) | (null))) => __pui_OptionalReceiver == null ? undefined : __pui_OptionalReceiver.props.isProvided("interrupt"))(currentRun) ? (((getProps)())?.["interrupt"] ?? (interruptDefault.get() as "reverse" | "wait" | "immediate")) : (interruptDefault.get() as "reverse" | "wait" | "immediate"));
      }, ["getDuration"]: (state: "entering" | "leaving"): number => {
        // Source "transition/as-transition.proto.ts":165:9
        if ((((__pui_OptionalReceiver: ((__pui_Run) | (null))) => __pui_OptionalReceiver == null ? undefined : (void (__pui_OptionalReceiver), __pui_Meta("reducedMotion")))(currentRun) === "reduce")) {
          // Source "transition/as-transition.proto.ts":165:66
          return 0;
        }
        // Source "transition/as-transition.proto.ts":166:9
        return ((state === "entering") ? (((__pui_OptionalReceiver: ((__pui_Run) | (null))) => __pui_OptionalReceiver == null ? undefined : __pui_OptionalReceiver.props.isProvided("enterDuration"))(currentRun) ? (((getProps)())?.["enterDuration"] ?? (enterDurationDefault.get() as number)) : (enterDurationDefault.get() as number)) : (((__pui_OptionalReceiver: ((__pui_Run) | (null))) => __pui_OptionalReceiver == null ? undefined : __pui_OptionalReceiver.props.isProvided("leaveDuration"))(currentRun) ? (((getProps)())?.["leaveDuration"] ?? (leaveDurationDefault.get() as number)) : (leaveDurationDefault.get() as number)));
      }, ["schedule"]: (durationMs: number, callback: () => void): __pui_DelayTask => {
        // Source "transition/as-transition.proto.ts":174:43
        return __pui_Delay.schedule(durationMs, callback);
      }, ["setViewPresent"]: (present: boolean): void => {
        // Source "transition/as-transition.proto.ts":176:9
        if ((!currentRun)) {
          // Source "transition/as-transition.proto.ts":177:11
          throw new Error("[asTransition] runtime lifecycle handle is not available.");
        }
        // Source "transition/as-transition.proto.ts":179:9
        (phaseViewRequested = present);
        // Source "transition/as-transition.proto.ts":180:9
        (currentRun as __pui_Run).lifecycle.setPresent((phaseViewRequested || (closedViewRetained.get() as boolean)));
      }, ["emit"]: (event: "beforeEnter" | "afterEnter" | "beforeLeave" | "afterLeave"): void => {
        // Source "transition/as-transition.proto.ts":183:9
        ((__pui_OptionalReceiver: ((__pui_Run) | (null))) => __pui_OptionalReceiver == null ? undefined : __pui_OptionalReceiver.expose.emit(event))(currentRun);
      } } as { "getState": () => "closed" | "preparing" | "entering" | "entered" | "leaving"; "setState": (state: "closed" | "preparing" | "entering" | "entered" | "leaving") => void; "getInterrupt": () => "reverse" | "wait" | "immediate"; "requiresColdPreparation"?: () => boolean; "getCompletion"?: () => (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number })); "publishPresentation"?: (frame: { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) => void; "settlePresentation"?: (outcome: "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed") => void; "getDuration": (state: "entering" | "leaving") => number; "schedule": (durationMs: number, callback: () => void) => __pui_DelayTask; "setViewPresent": (present: boolean) => void; "emit": (event: "beforeEnter" | "afterEnter" | "beforeLeave" | "afterLeave") => void });
      // Source "transition/as-transition.proto.ts":186:11
      const machine = __puiModule0(driver);
      // Source "transition/as-transition.proto.ts":187:5
      presentation.onCompletionRequest((run: __pui_Run, request: { readonly "receipt": { readonly "owner": Readonly<object>; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "viewBinding": Readonly<object>; readonly "ownerRevision": number; readonly "targetRevision": number; readonly "channels": ReadonlyArray<"translate" | "opacity">; readonly "outcome": "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed" } }) => {
        // Source "transition/as-transition.proto.ts":188:7
        if ((!currentRun)) {
          // Source "transition/as-transition.proto.ts":188:24
          return;
        }
        // Source "transition/as-transition.proto.ts":189:7
        if ((!(void (run), __pui_Presence.isCurrent((presentation)["writer"], (request)["receipt"])))) {
          // Source "transition/as-transition.proto.ts":189:83
          return;
        }
        // Source "transition/as-transition.proto.ts":190:7
        ((machine)["completePresentation"])(((request)["receipt"])["attempt"], (): boolean => {
          // Source "transition/as-transition.proto.ts":192:15
          return ((!(!currentRun)) && (void (run), __pui_Presence.isCurrent((presentation)["writer"], (request)["receipt"])));
        });
      });
      // Source "transition/as-transition.proto.ts":196:11
      const controls: { "enter": () => void; "leave": () => void; "complete": () => void; "capturePreparation": () => ((() => void) | (null)) } = { ["enter"]: (): void => {
        // Source "transition/as-transition.proto.ts":198:9
        if (openContextSource) {
          // Source "transition/as-transition.proto.ts":199:11
          if (currentRun) {
            // Source "transition/as-transition.proto.ts":199:27
            ((machine)["setTarget"])((contextOpen)((currentRun as __pui_Run), (openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string })));
          }
        } else {
          // Source "transition/as-transition.proto.ts":200:16
          ((machine)["enter"])();
        }
      }, ["leave"]: (): void => {
        // Source "transition/as-transition.proto.ts":203:9
        if (openContextSource) {
          // Source "transition/as-transition.proto.ts":204:11
          if (currentRun) {
            // Source "transition/as-transition.proto.ts":204:27
            ((machine)["setTarget"])((contextOpen)((currentRun as __pui_Run), (openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string })));
          }
        } else {
          // Source "transition/as-transition.proto.ts":205:16
          ((machine)["leave"])();
        }
      }, ["complete"]: (): void => {
        // Source "transition/as-transition.proto.ts":207:23
        return ((machine)["complete"])();
      }, ["capturePreparation"]: (): ((() => void) | (null)) => {
        // Source "transition/as-transition.proto.ts":209:9
        if ((!currentRun)) {
          // Source "transition/as-transition.proto.ts":210:11
          throw new Error("[asTransition] preparation capture requires a live runtime.");
        }
        // Source "transition/as-transition.proto.ts":211:9
        return ((machine)["capturePreparation"])();
      } };
      // Source "transition/as-transition.proto.ts":214:11
      const contextOpen = (run: __pui_Run, source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }): boolean => {
        // Source "transition/as-transition.proto.ts":218:13
        const value = run.context.read<{ [key: string]: unknown }>((source)["context"]);
        // Source "transition/as-transition.proto.ts":219:13
        const target = (value)[(source)["field"]];
        // Source "transition/as-transition.proto.ts":220:7
        if (((!Object.hasOwn(value, (source)["field"])) || ((typeof target) !== "boolean"))) {
          // Source "transition/as-transition.proto.ts":221:9
          throw new Error("[asTransition] open context field must be a required boolean.");
        }
        // Source "transition/as-transition.proto.ts":222:7
        return (target as boolean);
      };
      // Source "transition/as-transition.proto.ts":224:11
      const bindOpenContext = (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }): void => {
        // Source "transition/as-transition.proto.ts":225:7
        appearDefault.setDefault((appearDefault.get() as boolean));
        // Source "transition/as-transition.proto.ts":226:7
        if ((((((!source) || ((typeof (source)["field"]) !== "string")) || (!(source)["field"])) || (!(source)["context"])) || (((source)["context"])["__brand"] !== "ContextKey"))) {
          // Source "transition/as-transition.proto.ts":233:9
          throw new Error("[asTransition] open context source requires a ContextKey and direct field.");
        }
        // Source "transition/as-transition.proto.ts":236:7
        if (openContextSource) {
          // Source "transition/as-transition.proto.ts":237:9
          if (((((openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["context"] === (source)["context"]) && (((openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["field"] === (source)["field"]))) {
            // Source "transition/as-transition.proto.ts":241:11
            return;
          }
          // Source "transition/as-transition.proto.ts":242:9
          throw new Error("[asTransition] open context source is already bound.");
        }
        // Source "transition/as-transition.proto.ts":244:7
        (openContextSource = (Object.freeze({ ["context"]: (source)["context"], ["field"]: (source)["field"] }) as { "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; "field": string }));
        // Source "transition/as-transition.proto.ts":245:7
        (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = (source)["context"];
const __pui_CaptureArg1 = (run: __pui_Run) => {
          // Source "transition/as-transition.proto.ts":246:9
          (currentRun = run);
          // Source "transition/as-transition.proto.ts":247:9
          ((machine)["setTarget"])((contextOpen)(run, (openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string })));
        };
const __pui_CaptureResult = __pui_CaptureReceiver.context.subscribe(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "subscribe", "key": __pui_CaptureArg0, "off": __pui_CaptureResult}); __pui_Authored.disposer("context", __pui_CaptureResult); return __pui_CaptureResult; })();
      };
      // Source "transition/as-transition.proto.ts":250:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "bindOpenContext";
const __pui_CaptureArg1 = bindOpenContext;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":251:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "retainClosedView";
const __pui_CaptureArg1 = (retained: boolean): void => {
        // Source "transition/as-transition.proto.ts":252:7
        closedViewRetained.set((!(!retained)), "reason: transition closed-view retention policy");
        // Source "transition/as-transition.proto.ts":253:7
        if ((!currentRun)) {
          // Source "transition/as-transition.proto.ts":253:24
          return;
        }
        // Source "transition/as-transition.proto.ts":254:7
        (currentRun as __pui_Run).lifecycle.setPresent((phaseViewRequested || (closedViewRetained.get() as boolean)));
      };
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":257:5
      def.lifecycle.onCreated((run: __pui_Run) => {
        // Source "transition/as-transition.proto.ts":258:7
        (currentRun = run);
        // Source "transition/as-transition.proto.ts":259:13
        const props = run.props.get();
        // Source "transition/as-transition.proto.ts":260:13
        const controlled = run.props.isProvided("open");
        // Source "transition/as-transition.proto.ts":261:11
        let open: boolean = (controlled ? (!(!(props)["open"])) : (!(!(props)["defaultOpen"])));
        // Source "transition/as-transition.proto.ts":262:7
        if (openContextSource) {
          // Source "transition/as-transition.proto.ts":263:9
          (open = (contextOpen)(run, (openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string })));
        } else {
          // Source "transition/as-transition.proto.ts":264:14
          if ((((!controlled) && (!run.props.isProvided("defaultOpen"))) && initialOpenSource)) {
            // Source "transition/as-transition.proto.ts":265:15
            const value = run.context.read<{ [key: string]: unknown }>(((initialOpenSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["context"]);
            // Source "transition/as-transition.proto.ts":266:15
            const initialOpen = (value)[((initialOpenSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["field"]];
            // Source "transition/as-transition.proto.ts":267:9
            if (((!Object.hasOwn(value, ((initialOpenSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["field"])) || ((typeof initialOpen) !== "boolean"))) {
              // Source "transition/as-transition.proto.ts":268:11
              throw new Error("[asTransition] initial open context field must be a required boolean.");
            }
            // Source "transition/as-transition.proto.ts":270:9
            (open = (initialOpen as boolean));
          }
        }
        // Source "transition/as-transition.proto.ts":272:13
        const appear = (run.props.isProvided("appear") ? (!(!(props)["appear"])) : (appearDefault.get() as boolean));
        // Source "transition/as-transition.proto.ts":273:7
        ((machine)["initialize"])(open, appear);
      });
      // Source "transition/as-transition.proto.ts":276:5
      def.lifecycle.onMounted((run: __pui_Run) => {
        // Source "transition/as-transition.proto.ts":277:7
        (currentRun = run);
        // Source "transition/as-transition.proto.ts":278:7
        ((machine)["mounted"])();
      });
      // Source "transition/as-transition.proto.ts":281:5
      def.lifecycle.onUnmounted((run: __pui_Run) => {
        // Source "transition/as-transition.proto.ts":282:7
        (currentRun = run);
        // Source "transition/as-transition.proto.ts":283:7
        ((machine)["unmounted"])();
      });
      // Source "transition/as-transition.proto.ts":286:5
      def.lifecycle.onBeforeDispose(() => {
        // Source "transition/as-transition.proto.ts":287:7
        ((machine)["dispose"])();
        // Source "transition/as-transition.proto.ts":288:7
        (currentRun = null);
      });
      // Source "transition/as-transition.proto.ts":291:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = ["open", "interrupt", "enterDuration", "leaveDuration"];
const __pui_CaptureArg1 = (run: __pui_Run, next: __pui_ResolvedProps) => {
        // Source "transition/as-transition.proto.ts":292:7
        (currentRun = run);
        // Source "transition/as-transition.proto.ts":293:7
        if ((openContextSource || (!run.props.isProvided("open")))) {
          // Source "transition/as-transition.proto.ts":293:63
          return;
        }
        // Source "transition/as-transition.proto.ts":294:7
        ((machine)["setTarget"])((!(!(next)["open"])));
      };
const __pui_CaptureResult = __pui_CaptureReceiver.props.watch(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("props", {"op": "watch", "keys": __pui_CaptureArg0, "off": __pui_CaptureResult}); __pui_Authored.disposer("props", __pui_CaptureResult); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":297:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "transitionState";
const __pui_CaptureArg1 = transitionState;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.state(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", {"op": "expose.state", "key": __pui_CaptureArg0, "handle": __pui_CaptureArg1}); __pui_Authored.introduceObserved(__pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":298:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "isPresent";
const __pui_CaptureArg1 = isPresent;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.state(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("state", {"op": "expose.state", "key": __pui_CaptureArg0, "handle": __pui_CaptureArg1}); __pui_Authored.introduceObserved(__pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":299:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "enter";
const __pui_CaptureArg1 = (controls)["enter"];
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":300:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "leave";
const __pui_CaptureArg1 = (controls)["leave"];
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":301:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "complete";
const __pui_CaptureArg1 = (controls)["complete"];
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":302:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "capturePreparation";
const __pui_CaptureArg1 = (controls)["capturePreparation"];
const __pui_CaptureResult = __pui_CaptureReceiver.expose.method(__pui_CaptureArg0, __pui_CaptureArg1, (__pui_PublicResult: ((() => void) | (null))) => ((__pui_PublicValue0: ((() => void) | (null))) => (typeof __pui_PublicValue0 === 'function' ? __pui_WrapPublic(__pui_PublicValue0) : (__pui_PublicValue0)))(__pui_PublicResult)); __pui_Authored.effect("context", {"op": "expose.method", "key": __pui_CaptureArg0, "fn": __pui_CaptureArg1}); __pui_Authored.method(__pui_CaptureArg0, __pui_CaptureArg1); return __pui_CaptureResult; })();
      // Source "transition/as-transition.proto.ts":303:5
      (() => {
const __pui_CaptureReceiver = def;
const __pui_CaptureArg0 = "controls";
const __pui_CaptureArg1 = controls;
const __pui_CaptureResult = __pui_CaptureReceiver.expose.value(__pui_CaptureArg0, ((__pui_PublicValue0: { "enter": () => void; "leave": () => void; "complete": () => void; "capturePreparation": () => ((() => void) | (null)) }) => (__pui_PublicValue0 !== null && typeof __pui_PublicValue0 === 'object' ? __pui_WrapPublic.record(__pui_PublicValue0, __pui_PublicValue0Record => { if (Object.hasOwn(__pui_PublicValue0, "enter")) Object.defineProperty(__pui_PublicValue0Record, "enter", { value: ((__pui_PublicValue1: () => void) => (typeof __pui_PublicValue1 === 'function' ? __pui_WrapPublic(__pui_PublicValue1, __pui_PublicValue0) : (__pui_PublicValue1)))(((__pui_PublicValue0 as unknown as Record<string, unknown>)["enter"] as () => void)), enumerable: true, configurable: true, writable: true }); if (Object.hasOwn(__pui_PublicValue0, "leave")) Object.defineProperty(__pui_PublicValue0Record, "leave", { value: ((__pui_PublicValue2: () => void) => (typeof __pui_PublicValue2 === 'function' ? __pui_WrapPublic(__pui_PublicValue2, __pui_PublicValue0) : (__pui_PublicValue2)))(((__pui_PublicValue0 as unknown as Record<string, unknown>)["leave"] as () => void)), enumerable: true, configurable: true, writable: true }); if (Object.hasOwn(__pui_PublicValue0, "complete")) Object.defineProperty(__pui_PublicValue0Record, "complete", { value: ((__pui_PublicValue3: () => void) => (typeof __pui_PublicValue3 === 'function' ? __pui_WrapPublic(__pui_PublicValue3, __pui_PublicValue0) : (__pui_PublicValue3)))(((__pui_PublicValue0 as unknown as Record<string, unknown>)["complete"] as () => void)), enumerable: true, configurable: true, writable: true }); if (Object.hasOwn(__pui_PublicValue0, "capturePreparation")) Object.defineProperty(__pui_PublicValue0Record, "capturePreparation", { value: ((__pui_PublicValue4: () => ((() => void) | (null))) => (typeof __pui_PublicValue4 === 'function' ? __pui_WrapPublic(__pui_PublicValue4, __pui_PublicValue0, (__pui_PublicValue4Result: ((() => void) | (null))) => ((__pui_PublicValue5: ((() => void) | (null))) => (typeof __pui_PublicValue5 === 'function' ? __pui_WrapPublic(__pui_PublicValue5) : (__pui_PublicValue5)))(__pui_PublicValue4Result), "7f8ad435c936065d") : (__pui_PublicValue4)))(((__pui_PublicValue0 as unknown as Record<string, unknown>)["capturePreparation"] as () => ((() => void) | (null)))), enumerable: true, configurable: true, writable: true }); }) : __pui_PublicValue0))(__pui_CaptureArg1)); __pui_Authored.effect("context", {"op": "expose.value", "key": __pui_CaptureArg0, "value": __pui_CaptureArg1}); return __pui_CaptureResult; })();
    })(__pui_Def), project: (result: { readonly stateHandles?: Readonly<Record<string, unknown>>; readonly getState?: (name: string) => unknown; readonly getMethod?: (name: string) => unknown; readonly getAsHook?: (name: string) => unknown; readonly getAsHookHandle?: (name: string) => unknown; readonly render?: unknown }): { "transitionState": __pui_State<string> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<string>) => void): () => void }; "isPresent": __pui_State<boolean> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void }; "controls": { "capturePreparation": () => ((() => void) | (null)); "enter": () => void; "leave": () => void; "complete": () => void }; "configure": (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void; "bindInitialOpen": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void; "bindOpenContext": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void; "retainClosedView": (retained: boolean) => void; "presentationOwner": Readonly<object> } => {
      // Source "transition/as-transition.proto.ts":306:11
      const transitionState = __puiModule1((result.getState?.("transitionState") as ((__pui_State<string> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<string>) => void): () => void }) | (undefined))), "transitionState");
      // Source "transition/as-transition.proto.ts":310:11
      const isPresent = __puiModule2((result.getState?.("isPresent") as ((__pui_State<boolean> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void }) | (undefined))), "isPresent");
      // Source "transition/as-transition.proto.ts":311:11
      const controls: { "capturePreparation": () => ((() => void) | (null)); "enter": () => void; "leave": () => void; "complete": () => void } = { ["capturePreparation"]: __puiModule3((result.getMethod?.("capturePreparation") as ((() => ((() => void) | (null))) | (undefined))), "capturePreparation"), ["enter"]: __puiModule4((result.getMethod?.("enter") as ((() => void) | (undefined))), "enter"), ["leave"]: __puiModule5((result.getMethod?.("leave") as ((() => void) | (undefined))), "leave"), ["complete"]: __puiModule6((result.getMethod?.("complete") as ((() => void) | (undefined))), "complete") };
      // Source "transition/as-transition.proto.ts":330:11
      const appearDefault = __puiModule7((result.getState?.("transitionAppearDefault") as ((__pui_State<boolean> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void }) | (undefined))), "transitionAppearDefault");
      // Source "transition/as-transition.proto.ts":334:11
      const enterDurationDefault = __puiModule8((result.getState?.("transitionEnterDurationDefault") as ((__pui_State<number> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<number>) => void): () => void }) | (undefined))), "transitionEnterDurationDefault");
      // Source "transition/as-transition.proto.ts":338:11
      const leaveDurationDefault = __puiModule9((result.getState?.("transitionLeaveDurationDefault") as ((__pui_State<number> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<number>) => void): () => void }) | (undefined))), "transitionLeaveDurationDefault");
      // Source "transition/as-transition.proto.ts":342:11
      const interruptDefault = __puiModule10((result.getState?.("transitionInterruptDefault") as ((__pui_State<string> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<string>) => void): () => void }) | (undefined))), "transitionInterruptDefault");
      // Source "transition/as-transition.proto.ts":347:11
      const coldEntryPreparation = __puiModule11((result.getState?.("transitionColdEntryPreparation") as ((__pui_State<boolean> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void }) | (undefined))), "transitionColdEntryPreparation");
      // Source "transition/as-transition.proto.ts":352:11
      const configurePresentation = __puiModule12((result.getMethod?.("configurePresentation") as (((config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void) | (undefined))), "configurePresentation");
      // Source "transition/as-transition.proto.ts":358:11
      const getPresentationOwner = __puiModule13((result.getMethod?.("getPresentationOwner") as ((() => Readonly<object>) | (undefined))), "getPresentationOwner");
      // Source "transition/as-transition.proto.ts":362:11
      const configure = (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }): void => {
        // Source "transition/as-transition.proto.ts":364:7
        (configurePresentation)(config);
        // Source "transition/as-transition.proto.ts":365:11
        let configured: boolean = false;
        // Source "transition/as-transition.proto.ts":366:7
        if (((typeof (config)["coldEntryPreparation"]) !== "undefined")) {
          // Source "transition/as-transition.proto.ts":367:9
          coldEntryPreparation.setDefault(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation": boolean; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["coldEntryPreparation"]);
          // Source "transition/as-transition.proto.ts":368:9
          (configured = true);
        }
        // Source "transition/as-transition.proto.ts":370:7
        if (((typeof (config)["appear"]) !== "undefined")) {
          // Source "transition/as-transition.proto.ts":371:9
          appearDefault.setDefault(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear": boolean; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["appear"]);
          // Source "transition/as-transition.proto.ts":372:9
          (configured = true);
        }
        // Source "transition/as-transition.proto.ts":374:7
        if (((typeof (config)["enterDuration"]) !== "undefined")) {
          // Source "transition/as-transition.proto.ts":375:9
          if (((!Number.isFinite(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration": number; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["enterDuration"])) || (((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration": number; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["enterDuration"] < 0))) {
            // Source "transition/as-transition.proto.ts":376:11
            throw new Error("[asTransition] enterDuration must be a finite non-negative number.");
          }
          // Source "transition/as-transition.proto.ts":378:9
          enterDurationDefault.setDefault(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration": number; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["enterDuration"]);
          // Source "transition/as-transition.proto.ts":379:9
          (configured = true);
        }
        // Source "transition/as-transition.proto.ts":381:7
        if (((typeof (config)["leaveDuration"]) !== "undefined")) {
          // Source "transition/as-transition.proto.ts":382:9
          if (((!Number.isFinite(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration": number; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["leaveDuration"])) || (((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration": number; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["leaveDuration"] < 0))) {
            // Source "transition/as-transition.proto.ts":383:11
            throw new Error("[asTransition] leaveDuration must be a finite non-negative number.");
          }
          // Source "transition/as-transition.proto.ts":385:9
          leaveDurationDefault.setDefault(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration": number; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["leaveDuration"]);
          // Source "transition/as-transition.proto.ts":386:9
          (configured = true);
        }
        // Source "transition/as-transition.proto.ts":388:7
        if (((typeof (config)["interrupt"]) !== "undefined")) {
          // Source "transition/as-transition.proto.ts":389:9
          interruptDefault.setDefault(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt": "reverse" | "wait" | "immediate" }))["interrupt"]);
          // Source "transition/as-transition.proto.ts":390:9
          (configured = true);
        }
        // Source "transition/as-transition.proto.ts":393:7
        if ((!(configured as true | boolean))) {
          // Source "transition/as-transition.proto.ts":393:24
          appearDefault.setDefault((appearDefault.get() as boolean));
        }
      };
      // Source "transition/as-transition.proto.ts":396:11
      const bindInitialOpen = __puiModule14((result.getMethod?.("bindInitialOpen") as (((source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void) | (undefined))), "bindInitialOpen");
      // Source "transition/as-transition.proto.ts":400:11
      const bindOpenContext = __puiModule15((result.getMethod?.("bindOpenContext") as (((source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void) | (undefined))), "bindOpenContext");
      // Source "transition/as-transition.proto.ts":404:11
      const retainClosedView = __puiModule16((result.getMethod?.("retainClosedView") as (((retained: boolean) => void) | (undefined))), "retainClosedView");
      // Source "transition/as-transition.proto.ts":408:5
      return { ["transitionState"]: transitionState, ["isPresent"]: isPresent, ["controls"]: controls, ["configure"]: configure, ["bindInitialOpen"]: bindInitialOpen, ["bindOpenContext"]: bindOpenContext, ["retainClosedView"]: retainClosedView, ["presentationOwner"]: (getPresentationOwner)() };
    }}, options) as { "transitionState": __pui_State<string> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<string>) => void): () => void }; "isPresent": __pui_State<boolean> & { watch(callback: (run: __pui_Run, event: __pui_StateEvent<boolean>) => void): () => void }; "controls": { "capturePreparation": () => ((() => void) | (null)); "enter": () => void; "leave": () => void; "complete": () => void }; "configure": (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void; "bindInitialOpen": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void; "bindOpenContext": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void; "retainClosedView": (retained: boolean) => void; "presentationOwner": Readonly<object> });
  let render: (renderer: typeof __pui_Renderer) => unknown;
  try {
    render = (() => {
    // Source "entry.proto.ts":4:3
    ((__pui_Hook0())["configure"])({ ["coldEntryPreparation"]: false, ["appear"]: false, ["enterDuration"]: 200, ["leaveDuration"]: 500 });
    // Source "entry.proto.ts":5:3
    return (r: typeof __pui_Renderer) => {
      // Source "entry.proto.ts":5:13
      return r.el("section", ["Transition view ", r.slot()]);
    };
  })() ?? (() => __pui_Renderer.slot());
    if (typeof render !== 'function') throw new Error('[Prototype] setup must return a render function or void.');
  } catch (error) { try { disposeNow(false, false); } catch {} throw error; }
  phase = 'idle';
  function applyProps(nextHost: GeneratedComponentProps) {
    ensureAlive();
    hostProps = nextHost;
{ const __pui_Associations = nextHost.instanceAssociations;
    if (__pui_Associations !== undefined) {
      if (__pui_Associations === null || typeof __pui_Associations !== 'object' || Object.getPrototypeOf(__pui_Associations) !== Object.prototype)
        throw new TypeError('[InstanceAssociations] expected a plain record');
      for (const key of Reflect.ownKeys(__pui_Associations)) if (key !== 'controlLabel')
        throw new TypeError('[InstanceAssociations] unknown association key');
      if (Object.prototype.hasOwnProperty.call(__pui_Associations, 'controlLabel') && Reflect.get(__pui_Associations, 'controlLabel') != null)
        throw new Error('[ControlLabel] this Prototype has not declared Label or target participation');
    }
  }
    const nextRaw: Record<string, unknown> = Object.create(null);
    for (const [key, value] of Object.entries(nextHost)) {
      if (key === 'children' || key === 'instanceAssociations' || key === 'hostRef' || key === 'hostProps' || !Object.hasOwn(specs, key) && (['class', 'className', 'hostClass', 'surfaceClass', 'style', 'hostStyle', 'surfaceStyle'].includes(key) || /^on[A-Z]/.test(key) && typeof value === 'function')) continue;
      nextRaw[key] = value;
    }
    if (hydrated && Object.keys(raw).length === Object.keys(nextRaw).length
      && Object.keys(nextRaw).every((key) => Object.hasOwn(raw, key) && Object.is(raw[key], nextRaw[key]))) return false;
    const previous = resolved;
    const previousRaw = raw;
    raw = Object.freeze(nextRaw);
    resolved = __pui_ResolveProps(specs, defaults, previousValid, raw, true);

    if (!hydrated) { hydrated = true; return false; }
    const nextResolved = resolved, nextRawSnapshot = raw;
    invoke(() => {
      const previousWindow = propsWindow;
      propsWindow = { raw: nextRawSnapshot, resolved: nextResolved };
      try {
      if (rawAllWatchers.length || rawWatchers.length) {
        const changedRaw = [...new Set([...Object.keys(previousRaw), ...Object.keys(nextRawSnapshot)])].filter(key => !Object.is(previousRaw[key], nextRawSnapshot[key]));
        if (changedRaw.length) for (let groupIndex = 0; groupIndex < 2; ++groupIndex) for (const watcher of groupIndex === 0 ? rawAllWatchers : rawWatchers) {
          if (!watcher.active) continue;
          const changedKeysMatched = watcher.keys ? watcher.keys.filter(key => changedRaw.includes(key)) : changedRaw;
          if (!changedKeysMatched.length) continue;
          console.warn('[Props] raw watchers are an adapter-snapshot escape hatch; avoid in official prototypes.');
          watcher.callback(__pui_RunHandle, nextRawSnapshot, previousRaw, { changedKeysAll: changedRaw, changedKeysMatched });
        }
      }
      const changedKeysAll = Object.keys(specs).filter((key) => !Object.is(previous[key as keyof GeneratedProps], nextResolved[key as keyof GeneratedProps]));
      for (const watcher of watchers) {
        if (!watcher.active) continue;
        const changedKeysMatched = watcher.keys ? watcher.keys.filter((key) => changedKeysAll.includes(key)) : changedKeysAll;
        if (changedKeysMatched.length) watcher.callback(__pui_RunHandle, nextResolved, previous, { changedKeysAll, changedKeysMatched });
      }
      } finally { propsWindow = previousWindow; }
    });
    return true;
  }
  const handle: GeneratedHandle = Object.freeze({
    update() { ensureExternal(); invoke(() => __pui_RunHandle.update()); },
    getElement() { return lifetime === 'alive' && connected ? root : null; },
    getExposes() { ensureExternal(); return { ...exposes } as GeneratedExposes; },
    invokeInCallbackScope<T>(callback: () => T): T { ensureExternal(); return invoke(callback); },
  });
  function disposeNow(exhaustive = false, authored = true) {
    if (lifetime !== 'alive') return;
    lifetime = 'disposing'; connected = false; ++cleanupVersion; ++rootGeneration; phase = 'callback';
    __pui_CompleteSteps([
      ...authorStateWatchCleanups.splice(0),
      () => detachView(),
      () => {
        if (!authored) return;
        if (exhaustive) __pui_CompleteSteps(callbacks.beforeDispose.map(callback => () => invoke(() => callback(__pui_RunHandle))));
        else dispatch(callbacks.beforeDispose);
      },
      () => context.dispose(),
      () => { { let failed = false, first; for (const release of [() => { __pui_Delay.dispose(); }, () => { __pui_Presence.dispose(); }]) { try { release(); } catch (error) { if (!failed) { failed = true; first = error; } } } if (failed) throw first; } },
      () => __pui_Authored.dispose(),
      () => {
        root = null; lifetime = 'disposed'; phase = 'idle';
        for (const subscribers of stateSubscribers) subscribers.clear();
        pendingStateEvents.length = 0; watchers.length = 0; rawWatchers.length = 0; rawAllWatchers.length = 0;
        for (const list of Object.values(callbacks)) list.length = 0;
        for (const key of Object.keys(exposes)) delete exposes[key];
      },
    ]);
  }
  return {
    handle,
    scope: context,
    getHostProjection() { return { tag: "div", properties: {}, portalTarget: null }; },

    bindRoot(nextRoot) {
      if (lifetime !== 'alive') return;
      if (rootBinding) {
        if (rootBinding === 'binding' && root === nextRoot && !pendingRoot) return;
        pendingRoot = { value: nextRoot }; ++rootGeneration;
        return;
      }
      if (root === nextRoot) return;
      let next = nextRoot;
      let failure: { error: unknown } | undefined;
      try {
        for (;;) {
          // Cleanup owns the previous Root and all of its reached resources.
          // Reentrant requests coalesce until that complete transaction returns.
          rootBinding = 'retiring'; ++rootGeneration;
          const previousRoot = root;
          try { __pui_CompleteSteps([
          ]); } catch (error) { failure ??= { error }; }
          if (lifetime !== 'alive') break;
          const replacement = consumePendingRoot();
          if (replacement) next = replacement.value;
          root = next; rootBinding = 'binding';
          const generation = ++rootGeneration;
          const current = () => generation === rootGeneration && lifetime === 'alive';
          try { __pui_CompleteSteps([
          ]); } catch (error) { failure ??= { error }; }
          const queued = consumePendingRoot();
          if (lifetime !== 'alive' || !queued) break;
          next = queued.value;
        }
      } finally { rootBinding = null; pendingRoot = undefined; }
      if (failure) throw failure.error;
    },
    connect() { connected = true; ++cleanupVersion; },
    start() {
      try {
        applyProps(initial); dispatch(callbacks.created);
        schedule();
      }
      catch (error) { try { disposeNow(true); } catch {} throw error; }
    },
    applyProps,
    accept(frame: __pui_Frame) {
      if (!connected || lifetime !== 'alive' || frame.revision <= acceptedRevision || frame !== latest) return false;
      acceptedRevision = frame.revision;
      if (frame.kind === 'detach') {
        try { detachView(); } finally { schedule(); }
      } else if (!desiredPresent) {
        // Physical materialization is not a published mount. Remove the obsolete
        // Root without manufacturing mounted/unmounted for a never-mounted epoch.
        schedule();
        return false;
      } else if (frame.kind === 'mount') {
        mounted = true;

        // The published mount may predate an explicit update intent. Only
        // after its acknowledgement may that dirty intent enter update flow.
        if (dirty) updateQueued = true;

        
        dispatch(callbacks.mounted);
      } else if (mounted && frame.epoch === epoch) {   dispatch(callbacks.updated); }
      schedule();
      return true;
    },
    disconnect() {
      connected = false;
      const version = ++cleanupVersion;
      queueMicrotask(() => {
        if (connected || cleanupVersion !== version || lifetime !== 'alive') return;
        disposeNow();
      });
    },
  };
}


export const CompiledComponent = __pui_React.forwardRef<GeneratedHandle, GeneratedComponentProps>(function CompiledComponent(props, ref) {
  const ownerRef = __pui_React.useRef<__pui_Owner | null>(null);
  const parentScope = __pui_React.useContext(__pui_ContextTransport);
  const parentRef = __pui_React.useRef<__pui_ContextScope | null>(null);
  const [frame, setFrame] = __pui_React.useState<__pui_Frame | null>(null);
  const [, publishHost] = __pui_React.useReducer((version: number) => version + 1, 0);
  const rootRef = __pui_React.useRef<HTMLElement | null>(null);

  const pendingHostRef = __pui_React.useRef(props.hostRef);
  pendingHostRef.current = props.hostRef;
  const boundHostRef = __pui_React.useRef<__pui_React.Ref<HTMLElement> | undefined>(undefined);
  const bindRoot = __pui_React.useCallback((root: HTMLElement | null) => {
    if (boundHostRef.current !== pendingHostRef.current) __pui_AssignHostRef(boundHostRef.current, null);
    boundHostRef.current = pendingHostRef.current;
    rootRef.current = root;
    ownerRef.current?.bindRoot(root);
    __pui_AssignHostRef(boundHostRef.current, root);
  }, []);
  __pui_React.useLayoutEffect(() => {
    if (boundHostRef.current === props.hostRef) return;
    __pui_AssignHostRef(boundHostRef.current, null);
    boundHostRef.current = props.hostRef;
    __pui_AssignHostRef(boundHostRef.current, rootRef.current);
  }, [props.hostRef]);
  // All irreversible work begins after an accepted shell commit, never during React render.
  __pui_React.useLayoutEffect(() => {
    parentRef.current = parentScope;
    let owner = ownerRef.current;
    if (!owner) {
      owner = __pui_CreateOwner(props, setFrame, () => parentRef.current, publishHost);
      ownerRef.current = owner;
      owner.start();

    } else owner.connect();
  }, []);
  __pui_React.useLayoutEffect(() => { parentRef.current = parentScope; }, [parentScope]);
  // Suspense can disconnect layout effects without unmounting the owner shell.
  // Passive cleanup identifies shell unmount; same-turn StrictMode replay cancels disposal.
  __pui_React.useEffect(() => {
    const owner = ownerRef.current;
    if (!owner) return;
    owner.connect();
    return () => { owner.disconnect(); };
  }, []);
  __pui_React.useLayoutEffect(() => { const owner = ownerRef.current; owner?.applyProps(props); }, [props]);
  __pui_React.useLayoutEffect(() => { if (frame) ownerRef.current!.accept(frame); }, [frame]);

  __pui_React.useImperativeHandle(ref, () => ownerRef.current!.handle, []);
  const template = __pui_React.useMemo(() => __pui_BindSlots(frame?.node, props.children), [frame?.node, props.children]);
  const host = ownerRef.current?.getHostProjection();
  const rootView = frame && frame.kind !== 'detach'
    ? __pui_RenderRoot(host!.tag, { ...__pui_HostProperties(props), ...__pui_RootProperties(host!.properties), 'data-pui-root': '', ref: bindRoot }, template) : null;
  const view = rootView;
  return __pui_React.createElement(__pui_ContextTransport.Provider, { value: ownerRef.current?.scope ?? null }, view);

});
CompiledComponent.displayName = "browser-transition-ordinary";

//# sourceMappingURL=Component.tsx.map
