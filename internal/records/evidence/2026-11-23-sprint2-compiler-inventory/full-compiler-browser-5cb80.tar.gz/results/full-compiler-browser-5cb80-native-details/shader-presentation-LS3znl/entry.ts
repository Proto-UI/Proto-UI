import * as react from "/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202/results/full-compiler-browser-5cb80-native-details/shader-presentation-LS3znl/generated/react/Component.tsx";
import * as vue from "/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202/results/full-compiler-browser-5cb80-native-details/shader-presentation-LS3znl/generated/vue/Component.ts";
import * as vue2 from "/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202/results/full-compiler-browser-5cb80-native-details/shader-presentation-LS3znl/generated/vue2/Component.js";
import * as wc from "/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202/results/full-compiler-browser-5cb80-native-details/shader-presentation-LS3znl/generated/wc/Component.ts";
import {createShaderBrowserFixture} from "/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202/Proto-UI-final/packages/compiler/test/shader-browser-consumer.ts";
export const fixture=createShaderBrowserFixture({react,vue,vue2,wc});
