// Native web-component-source-v1: no Proto-UI Runtime/Core/Adapter dependency.
// Helper cost: owner/callback guards, scalar state + subscriptions, prop fallback/watch,
// microtask update/ViewIntent reconciliation, native shadow DOM template construction.
// Context cost: shared reference-key modules, owner scopes, checked JSON records, dynamic logical DOM ancestry.
// Context ancestry follows registered generated owners, never tag names or CSS markers.
// setProps is a full raw snapshot. No automatic state-write rendering.
// Synchronous DOM moves retain the owner; settled disconnection disposes it.
// setPresent detaches only the view; explicit dispose permanently closes this element.
import {createContextScope as __wcCreateContextScope, ownerScopes as __wcOwnerScopes, acceptsContextValue as __wcAccepts, type ContextScope as __wcContextScope} from "./.proto-ui/context/scope-v1";

import type { NativeModuleCapability as __wcNativeModuleCapability } from './.proto-ui/interaction/modules-e6807d4f71af1465-v2';


import { releaseNativeMeta as __wcReleaseMeta } from './.proto-ui/meta/subscription-v1';
import { readNativeWebMeta as __wcReadMeta } from './.proto-ui/meta/web-snapshot-v1';
import { subscribeNativeRulePreferences as __wcSubscribePreferences, readNativeRulePreference as __wcReadPreference } from './.proto-ui/meta/preference-source-v1';
import {validateNativeInstanceAssociations as __wcValidateAssociations} from './.proto-ui/interaction/control-label-v1';


import { createNativeAuthoredHooks as __wcCreateAuthored } from './.proto-ui/owner/authored-hooks-v1';

import { createNativeBrowserPort, type NativeBrowserPort, type NativeFrameBuilder } from './.proto-ui/web-component/browser-v1';
type BrowserPort = NativeBrowserPort<typeof __wcCreateNativeInteraction>;
type HostPort = BrowserPort;
const __wcPropTypes = {"variant":{"kind":"union","members":[{"kind":"literal","value":"solid"},{"kind":"literal","value":"surface"},{"kind":"literal","value":"destructive"}]},"color":{"kind":"union","members":[{"kind":"literal","value":"main"},{"kind":"literal","value":"mint"},{"kind":"literal","value":"lavender"},{"kind":"literal","value":"coral"},{"kind":"literal","value":"sky"}]},"size":{"kind":"union","members":[{"kind":"literal","value":"default"},{"kind":"literal","value":"sm"},{"kind":"literal","value":"lg"},{"kind":"literal","value":"icon"}]},"wrap":"boolean","disabled":"boolean"};
import {createNativeStyle as __wcCreateNativeStyle, templateStyleTokens as __wcTemplateStyleTokens, type NativeStyle as __wcStyle, type NativeStyleHandle as __wcNativeStyleHandle, type NativeRuleHandle as __wcNativeRuleHandle} from './.proto-ui/style/native-v1';

import {createNativeInteraction as __wcCreateNativeInteraction, type NativeInteraction as __wcNativeInteraction, type NativeFocus as __wcNativeFocus, type NativeAccessible as __wcNativeAccessible, type NativeObservedState as __wcNativeObservedState, type NativeInput as __wcNativeInput, type NativeFocusOptions as __wcNativeFocusOptions, markNativeExposeEvent as __wcMarkNativeExposeEvent} from './.proto-ui/interaction/native-e6807d4f71af1465-v2';

export type GeneratedProps = {
  "variant"?: "solid" | "surface" | "destructive" | null;
  "color"?: "main" | "mint" | "lavender" | "coral" | "sky" | null;
  "size"?: "default" | "sm" | "lg" | "icon" | null;
  "wrap"?: boolean | null;
  "disabled"?: boolean | null;
};
type __wcPropsSnapshot = {
  readonly "variant": "solid" | "surface" | "destructive";
  readonly "color": "main" | "mint" | "lavender" | "coral" | "sky";
  readonly "size": "default" | "sm" | "lg" | "icon";
  readonly "wrap": boolean;
  readonly "disabled": boolean;
};
export type GeneratedExposes = {
  "disabled": __wcExternalState<boolean>;
  "hovered": __wcExternalState<boolean>;
  "focused": __wcExternalState<boolean>;
  "focusVisible": __wcExternalState<boolean>;
  "focusSelf": (options?: { "reason"?: "programmatic" | "keyboard" | "pointer"; "preventScroll"?: boolean }) => void;
  "pressed": __wcExternalState<boolean>;
};
type __wcExternalState<T> = { get(): T; subscribe(cb: (event: {type: 'next'; prev: T; next: T; reason?: unknown}) => void): () => void; unsubscribe(off: () => void): void; spec: Readonly<__wcStateOptions & {kind: string}> };
type __wcScalar = string | number | boolean | null;
type __wcSnapshot = Readonly<Record<string, unknown>>;
type __wcPropSpec = {type: string; schema?: Parameters<typeof __wcAccepts>[0]; default?: unknown; options?: readonly string[]; empty?: 'accept' | 'fallback' | 'error'; range?: {min?: number; max?: number}; validator?: (value: never) => boolean};
type __wcStateOptions = {options?: readonly __wcScalar[]; min?: number; max?: number; step?: number; clamp?: boolean};
type __wcState<T extends __wcScalar = __wcScalar> = {get(): T; setDefault(next: T): void; set(next: T, reason?: unknown): void; external: __wcExternalState<T>; subscribers: Set<Function>};
type __wcContextKey<T> = object & {readonly __contextValue?: T};
type __wcContextRead = Readonly<{read<T>(key: __wcContextKey<T>): T; tryRead<T>(key: __wcContextKey<T>): T | null}>;
type __wcContextRun = __wcContextRead & {tryReadAncestor<T>(key: __wcContextKey<T>): T | null; update<T>(key: __wcContextKey<T>, next: T | ((prev: T) => T)): void; tryUpdate<T>(key: __wcContextKey<T>, next: T | ((prev: T) => T)): boolean};
type __wcContextDef = {provide<T>(key: __wcContextKey<T>, value: T): void; subscribe<T>(key: __wcContextKey<T>, callback?: (run: __wcRun, next: T, prev: T) => void): () => void; trySubscribe<T>(key: __wcContextKey<T>, callback?: (run: __wcRun, next: T | null, prev: T | null) => void): () => void; trySubscribeAncestor<T>(key: __wcContextKey<T>, callback?: (run: __wcRun, next: T | null, prev: T | null) => void): () => void};

type __wcPropsRead = Readonly<{get(): __wcPropsSnapshot; getRaw(): Readonly<Record<string, unknown>>; isProvided(key: string): boolean}>;
type __wcRun = {host: {get(): HTMLElement | null}; readonly feedback: {readonly style: __wcStyle}; readonly context: __wcContextRun; update(): void; props: __wcPropsRead; lifecycle: {setPresent(next: boolean): void}; expose: {emit(key: string, payload?: unknown, options?: CustomEventInit): void}};
type __wcRenderer = { slot(): (()=>Node); readonly nativeFrame:NativeFrameBuilder; readonly props: __wcPropsRead; readonly read: Readonly<{readonly props: __wcPropsRead; readonly context: __wcContextRead}>};
type __wcDef = {
  readonly feedback: {readonly style: __wcStyle};

  readonly event: __wcNativeInteraction<__wcRun>['event'];

  context: __wcContextDef;
  props: {define(input: Record<string, __wcPropSpec>): void; setDefaults(input: Record<string, unknown>): void; watch(keys: string[], fn: Function): () => void; watchAll(fn: Function): () => void; watchRaw(keys: string[], fn: Function): () => void; watchRawAll(fn: Function): () => void};
  state: {bool(s: string, v: boolean): __wcState<boolean>; enum(s: string, v: string, o: __wcStateOptions): __wcState<string>; string(s: string, v: string, o?: __wcStateOptions): __wcState<string>; numberDiscrete(s: string, v: number, o?: __wcStateOptions): __wcState<number>; numberRange(s: string, v: number, o: __wcStateOptions): __wcState<number>};
  expose: {value(key: string, value: unknown): void; state(key: string, handle: __wcState | __wcNativeObservedState<boolean | string | number>): void; method<A extends unknown[], R>(key: string, fn: (...args: A) => R, project?: (value: R) => R): void; event(key: string, spec?: object): void};
  lifecycle: {onCreated(fn: Function): void; onMounted(fn: Function): void; onUpdated(fn: Function): void; onUnmounted(fn: Function): void; onBeforeDispose(fn: Function): void};
};
type __wcOwner = {authored: ReturnType<typeof __wcCreateAuthored>; meta: (key: string) => unknown; identity: symbol; def: __wcDef; exposes: Record<string, unknown>; render?: Function | void; readonly epoch: number; readonly view: boolean; readonly interaction: __wcNativeInteraction<__wcRun>; readonly style: __wcStyle; props(): __wcPropsSnapshot; hydrate(input: Record<string, unknown>): void; update(): void; reconcile(): void; created(): void; dispose(exhaustive?: boolean): void};
function __wcCreateOwner(host: HostPort, getAssociations: () => unknown): __wcOwner {
  let alive = true, disposing = false, setup = true, callbackDepth = 0;
  let currentRun: __wcRun | undefined;
  const observedProjections = new Map<object, {external: __wcExternalState<unknown>; subscribers: Set<Function>}>();
  const observedSubscriptions: (() => void)[] = [];

  let intent = true, view = false, epoch = 0, queued = false, dirty = false, hostScheduled = false;

  let propsWindow: {raw: Readonly<Record<string, unknown>>; resolved: __wcSnapshot} | null = null;
  let resolved: __wcSnapshot = Object.freeze({}), raw: Readonly<Record<string, unknown>> = Object.freeze({}), hydrated = false;
  const specs: Record<string, __wcPropSpec> = Object.create(null), previous: Record<string, unknown> = Object.create(null), defaults: Record<string, unknown>[] = [];
  const watchers: {keys: string[] | null; fn: Function; active: boolean; raw: boolean}[] = [], states: __wcState[] = [], emissions: (() => void)[] = [];
  let emitting = false;
  const exposes: Record<string, unknown> = Object.create(null), events = new Set<string>();
  const lifecycle: Record<string, Function[]> = {created: [], mounted: [], updated: [], unmounted: [], beforeDispose: []};
  const own = (obj: object, key: string) => Object.prototype.hasOwnProperty.call(obj, key);
  const ensure = () => { if (!alive) throw new Error('Logical owner is disposed'); };
  const ensureExternal = () => { ensure(); if (disposing) throw new Error('Logical owner is disposing'); };
  const ensureSetup = () => { ensure(); if (!setup) throw new Error('Setup capability is closed'); };
  const runtime = () => { ensure(); if (setup || !callbackDepth) throw new Error('State writes require a live callback scope'); };
  const __wcMeta = (key: string) => __wcReadMeta(host.root?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), key);
  const __wcAuthoredWatchCleanups: (() => void)[] = [];
  const __wcAuthored = __wcCreateAuthored({setup: ensureSetup, borrow(value) {
    const state = value as __wcState<__wcScalar>;
    const borrowed = Object.freeze({get: () => state.get(), setDefault: (value: __wcScalar) => state.setDefault(value), set: (value: __wcScalar, reason?: unknown) => state.set(value, reason), watch(callback: (run: __wcRun, event: unknown) => void) { ensureSetup(); const off = state.external.subscribe(event => { invoke(callback, [event]); }); __wcAuthoredWatchCleanups.push(off); return off; }});
    
    return borrowed;
  }});
  const context = __wcCreateContextScope({getParent: () => host.parentContext(), isAlive: () => alive,
    invoke: <T>(callback: () => T): T => invoke(callback, [], false) as T, validate: (key: object, value: unknown): boolean => false});

  const __wcStyle = __wcCreateNativeStyle({ensureSetup, ensureRuntime: runtime, isAlive: () => alive,
    getMeta: (key: string) => key.startsWith('preference.') ? __wcReadPreference(host.document, key) : undefined, subscribeMeta: (notify: () => void) => { const leases: (() => void)[] = []; try { leases.push(__wcSubscribePreferences(host.document, ["preference.reducedMotion"], notify)); } catch (error) { __wcReleaseMeta([() => { throw error; }, ...leases]); } return () => __wcReleaseMeta(leases); },
    project(tokens) { host.attribute('data-pui-style', tokens.length ? tokens.join(' ') : null); }});

  const __wcInteraction: __wcNativeInteraction<__wcRun> = host.createInteraction<__wcRun>({
    ensureSetup, ensureRuntime: runtime, ensureEvent: runtime, isAlive: () => alive, isSetupComplete: () => !setup, isReady: () => !setup && view && intent && !disposing && host.isConnected,
    invoke: <T>(callback: () => T): T => invoke(callback, [], false) as T,
    getRun() { ensure(); if (!currentRun) throw new Error('Interaction requires a live callback scope'); return currentRun; },
    getResolvedProps: () => resolved,
    getAssociations,

    getRoot: () => view && !disposing && !host.server ? host.root : null,
    getHost: () => host.host,
    identity: context, getLogicalParent: () => host.parentContext(),
    declarations: [], tableFamily: undefined,
    getExposes: () => alive && !disposing ? exposes : {},
    registerExpose(key, value) {
      if (value && typeof value === 'object' && 'external' in value) expose(key, value.external);
      else if (typeof value === 'function') expose(key, (...args: unknown[]) => { ensureExternal(); return invoke(value, args, false); });
      else expose(key, value);
    },
    createOwnedState: (name, value, spec) => state(spec?.kind ?? (typeof value === 'boolean' ? 'bool' : typeof value === 'number' ? 'number.discrete' : 'string'), name, value, spec),
    watchState<T>(handle: {get():T}, fn: (run: __wcRun, event: {type:'next';prev:T;next:T;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void) {
      ensureSetup();
      const external = ('external' in handle ? handle.external : observedProjections.get(handle)?.external) as __wcExternalState<T> | undefined;
      if (!external) throw new Error('Unknown owner State watch target');
      const off = external.subscribe(event => invoke(fn, [event]) as void); observedSubscriptions.push(off); return off;
    },
    subscribeState(handle, callback) {
      const source = 'external' in handle ? (handle as {external:__wcExternalState<unknown>}).external : handle as __wcNativeObservedState<unknown>;
      return source.subscribe(callback);
    },
    isPropProvided: key => own(raw, key),
    emit: key => { runtime(); currentRun!.expose.emit(key); },
    setPresent: value => { runtime(); if (disposing) throw new Error('Terminal presence is locked'); intent = value; schedule(false); },
    requestHostUpdate() {
      if (hostScheduled || disposing) return;
      hostScheduled = true;
      queueMicrotask(() => { hostScheduled = false; if (alive && !disposing && view) projectHost(); });
    },
    registerGenericObservedState(handle) {
      if (observedProjections.has(handle)) return;
      const subscribers = new Set<Function>();
      const external: __wcExternalState<boolean | string | number> = Object.freeze({
        get() { ensureExternal(); return handle.get(); }, spec: Object.freeze({kind: typeof handle.get() === 'boolean' ? 'bool' : typeof handle.get() === 'number' ? 'number.discrete' : 'string'}),
        subscribe(fn: Function) { ensureExternal(); const registration = (event: unknown) => fn(event); subscribers.add(registration); return () => { subscribers.delete(registration); }; },
        unsubscribe(off: () => void) { ensureExternal(); off(); },
      });
      observedProjections.set(handle, {external, subscribers});
      
      observedSubscriptions.push(handle.subscribe((event) => {
        __wcStyle.refresh();

        __wcInteraction.refresh();
        for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(emissions, emissions.length, {value: () => { if ((alive && !disposing) && subscribers.has(subscriber)) { invoke(subscriber, [event], false); } }, writable:true, enumerable:true, configurable:true});
}

        drainEmissions();
      }));
    },
  });

  
  let ownerRun: __wcRun | undefined;
  function getRunHandle(): __wcRun {
    if (ownerRun) return ownerRun;
    const check = () => runtime();
    return ownerRun = {
      host: { get() { check(); return view && !disposing ? host.root : null; } },
      feedback: {style: __wcStyle},

      context: Object.freeze({
        read<T>(key: __wcContextKey<T>): T { check(); return context.read(key) as T; },
        tryRead<T>(key: __wcContextKey<T>): T | null { check(); return context.tryRead(key) as T | null; },
        tryReadAncestor<T>(key: __wcContextKey<T>): T | null { check(); return context.tryReadAncestor(key) as T | null; },
        update<T>(key: __wcContextKey<T>, next: T | ((prev: T) => T)) { check(); runtime(); context.update(key, next); },
        tryUpdate<T>(key: __wcContextKey<T>, next: T | ((prev: T) => T)) { check(); runtime(); return context.tryUpdate(key, next); },
      }),
      update() { check(); if (!disposing) schedule(true); },
      props: Object.freeze({get() { check(); return (propsWindow?.resolved ?? resolved) as __wcPropsSnapshot; }, getRaw() { check(); return propsWindow?.raw ?? raw; }, isProvided(key: string) { check(); return own(propsWindow?.raw ?? raw, key); }}),
      lifecycle: {setPresent(next: boolean) { check(); if (disposing) throw new Error('Terminal presence is locked'); if (typeof next !== 'boolean') throw new TypeError('View presence must be boolean'); intent = next; schedule(false); }},
      expose: {emit(key: string, payload?: unknown, options?: CustomEventInit) { check(); if (!events.has(key)) throw new Error('Undeclared exposed event: ' + key); host.emit(key, payload, options); }},
    };
  }
  function invoke(fn: Function, args: unknown[] = [], withRun = true): unknown {
    ensure();
    const run = getRunHandle();
    const previousRun = currentRun; currentRun = run;

    ++callbackDepth;
    try { return fn(...(withRun ? [run, ...args] : args)); }
    finally { --callbackDepth; currentRun = previousRun; }
  }
  __wcOwnerScopes.set(host, context);
  host.bindContext(context);

  const contextRead: __wcContextRead = Object.freeze({
    read<T>(key: __wcContextKey<T>): T { ensure(); if (setup) throw new Error('Context reads require runtime scope'); return context.read(key) as T; },
    tryRead<T>(key: __wcContextKey<T>): T | null { ensure(); if (setup) throw new Error('Context reads require runtime scope'); return context.tryRead(key) as T | null; },
  });
  function fire(name: string): void {
    if (name === 'unmounted') {  }
    try { for (const fn of lifecycle[name]) invoke(fn); }
    finally { if (name === 'unmounted') {  } }
  }
  function valid(spec: __wcPropSpec, value: unknown): boolean {
    if (spec.schema === undefined) throw new Error('Missing checked Props schema');
    if (!__wcAccepts(spec.schema, value) || spec.options && !spec.options.includes(value as string) ||
      spec.range && !(typeof value === 'number' && value >= (spec.range.min ?? -Infinity) && value <= (spec.range.max ?? Infinity))) return false;
    try { return spec.validator ? !!spec.validator(value as never) : true; }
    catch { return false; }
  }
  function resolve(strict: boolean): __wcSnapshot {
    const next: Record<string, unknown> = Object.create(null);
    for (const key of Object.keys(specs)) {
      const spec = specs[key], provided = own(raw, key), value = raw[key];
      const requireValue = strict && spec.empty === 'error';
      if (provided && value != null && valid(spec, value)) { next[key] = value; previous[key] = value; continue; }
      if (provided && value == null && spec.empty === 'accept') { next[key] = null; continue; }
      let candidate: unknown;
      if (provided && own(previous, key) && valid(spec, previous[key])) candidate = previous[key];
      if (candidate === undefined) for (const layer of defaults) {
        if (!own(layer, key)) continue;
        const value = layer[key];
        if ((value === null && !requireValue) || (value != null && valid(spec, value))) { candidate = value; break; }
      }
      if (candidate === undefined && own(spec, 'default')) {
        const value = spec.default;
        if ((value === null && !requireValue) || (value != null && valid(spec, value))) candidate = value;
      }
      if (candidate === undefined) {
        if (requireValue) throw new Error('Prop has no valid fallback: ' + key);
        candidate = null;
      }
      next[key] = candidate;
      if (provided && next[key] != null) previous[key] = next[key];
    }
    return Object.freeze(next);
  }
  function hydrate(input: Record<string, unknown>): void {
    ensure();
    const prev = resolved, previousRaw = raw;
    raw = Object.freeze({...input});
    resolved = resolve(true);
    __wcStyle.refresh();

    __wcInteraction.refresh();

    if (!hydrated) { hydrated = true; return; }
    const changed = Object.keys(specs).filter((key) => !Object.is(prev[key], resolved[key]));
    const rawChanged = watchers.some((watcher) => watcher.raw && watcher.active) ? [...new Set([...Object.keys(previousRaw), ...Object.keys(raw)])].filter((key) => !Object.is(previousRaw[key], raw[key])) : changed;
    const next = resolved, nextRaw = raw;
    const previousWindow = propsWindow; propsWindow = {raw: nextRaw, resolved: next};
    try { for (let group = 0; group < 3; ++group) for (const watcher of [...watchers]) {
      if ((watcher.raw ? watcher.keys === null ? 0 : 1 : 2) !== group) continue;
      const all = watcher.raw ? rawChanged : changed;
      const matched = watcher.keys === null ? all : all.filter((key) => watcher.keys!.includes(key));
      if (watcher.active && matched.length) {
        if (watcher.raw) console.warn('[Props] raw watchers are an adapter-snapshot escape hatch; avoid in official prototypes.');
        invoke(watcher.fn, [watcher.raw ? nextRaw : next, watcher.raw ? previousRaw : prev, {changedKeysAll: all, changedKeysMatched: matched}]);
      }
    } } finally { propsWindow = previousWindow; }
  }
  function drainEmissions(): void {
    if (!emitting) {
  emitting = true;
  const notificationFailures: unknown[] = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < emissions.length && (alive && !disposing)) {
      try { emissions[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { emissions.length = 0; emitting = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
  }
  function state<T extends __wcScalar>(kind: string, semantic: string, initial: T, options: __wcStateOptions = {}): __wcState<T> {
    ensureSetup();
    __wcAuthored.claimState(semantic);
    if (typeof semantic !== 'string' || semantic.length === 0) throw new Error('Invalid state semantic');
    const spec = Object.freeze({...options, kind});
    function validate(value: unknown): void {
      const type = kind === 'bool' ? 'boolean' : kind === 'string' || kind === 'enum' ? 'string' : 'number';
      if (typeof value !== type || (type === 'number' && Number.isNaN(value))) throw new Error('Invalid state value');
      if (options.options?.length && !options.options.includes(value as __wcScalar)) throw new Error('State value outside options');
      if (kind === 'number.range' || (kind === 'number.discrete' && !options.options?.length)) {
        const numeric = typeof value === 'number' ? value : NaN;
        if (numeric < (options.min ?? -Infinity) || numeric > (options.max ?? Infinity)) throw new Error('State value outside range');
        if (kind === 'number.discrete' && options.step !== undefined && options.step > 0 && !Number.isInteger((numeric - (options.min ?? 0)) / options.step)) throw new Error('State value violates step');
      }
    }
    if (kind === 'number.range' && options.clamp) initial = Math.max(options.min ?? -Infinity, Math.min(options.max ?? Infinity, initial as number)) as T;
    validate(initial);
    let value = initial;
    const subscribers = new Set<Function>();
    const external = Object.freeze({
      get() { ensureExternal(); return value; }, spec,
      subscribe(fn: Function) { ensureExternal(); const registration = (event: unknown) => fn(event); subscribers.add(registration); return () => subscribers.delete(registration); },
      unsubscribe(off: () => void) { ensureExternal(); off(); },
    });
    const handle = {external, subscribers,
      get() { ensure(); return value; },
      setDefault(next: T) { ensureSetup(); validate(next); value = next; },
      set(next: T, reason?: unknown) {
        runtime(); validate(next); if (Object.is(value, next)) return;
        const prev = value; value = next;
        __wcStyle.refresh();


        __wcInteraction.refresh();

        for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(emissions, emissions.length, {value: () => { if ((alive && !disposing) && subscribers.has(subscriber)) { invoke(subscriber, [{type: 'next', prev, next, reason}], false); } }, writable:true, enumerable:true, configurable:true});
}

        drainEmissions();
      },
    };
    states.push(handle); __wcAuthored.state(semantic, handle);  return handle;
  }
  let slotUsed = false;
  let interactionAdopted = false;

  function render(): void {
    slotUsed = false;
    const nativeFrame=host.createFrame();
    const props: __wcPropsRead=Object.freeze({get:()=>resolved as __wcPropsSnapshot,getRaw:()=>raw,isProvided:(key:string)=>own(raw,key)});
    const renderer: __wcRenderer={nativeFrame,slot(){if(slotUsed)throw new Error('Multiple slots are unsupported');slotUsed=true;return ()=>nativeFrame.slot();},props,read:Object.freeze({props, context: contextRead})};
    projectHost();
    let fragment:DocumentFragment;
    if(typeof owner.render==='function')fragment=(owner.render(renderer) as DocumentFragment|null|undefined)??nativeFrame.document.createDocumentFragment();
    else {fragment=nativeFrame.document.createDocumentFragment();fragment.appendChild(renderer.slot()());}
    host.commit(nativeFrame.finish(fragment));
  }
  function projectHost(): void {
    host.projectRoot(__wcInteraction.rootTag(), __wcInteraction.rootProperties(), host.server ? null : __wcInteraction.portalTarget());
  }
  function detach(): void {
    host.visible(false);
    if (!view) return;
    view = false; ++epoch;
    let error: unknown;
    try { __wcInteraction.unmount(); } catch (caught) { error = caught; }
    try { __wcStyle.unmount(); host.attribute('data-pui-style', null); } catch (caught) { error ??= caught; }
    try { fire('unmounted'); } catch (caught) { error ??= caught; } finally { host.clear(); }
    if (error !== undefined) throw error;
  }
  function reconcile(): void {
    if (!alive || disposing || !host.isConnected || host.server) return;
    if (!intent) { detach(); return; }
    host.visible(true);
    if (!view) {
      ++epoch; render(); view = true; dirty = false;
      __wcStyle.mount();
      
      if (!interactionAdopted && host.hydrationAttributes) {
        __wcInteraction.adoptAttributes(host.hydrationAttributes, host.hydrationBaselines);
        interactionAdopted = true;
      }
      __wcInteraction.mount();
      fire('mounted');
    } else if (dirty) { dirty = false; render(); fire('updated'); }
  }
  function schedule(update: boolean): void {
    ensure(); dirty ||= update;
    if (host.server || queued || disposing) return;
    queued = true;
    queueMicrotask(() => {
      queued = false;
      if (!alive || disposing) return;
      // Detached dirty work is retained until the next actual view commit.
      if (host.isConnected) reconcile();
    });
  }

  function expose(key: string, value: unknown): void { ensureSetup(); if (own(exposes, key) || events.has(key)) throw new Error('Duplicate expose: ' + key); exposes[key] = value; }
  const def: __wcDef = {
    feedback: {style: __wcStyle},

    event: __wcInteraction.event,

    context: {
      provide(key, value) { ensureSetup(); context.provide(key, value); },
      subscribe(key, callback) { ensureSetup(); return context.subscribe(key, 'required', callback ? (next, prev) => { invoke(callback, [next, prev]); } : undefined); },
      trySubscribe(key, callback) { ensureSetup(); return context.subscribe(key, 'optional', callback ? (next, prev) => { invoke(callback, [next, prev]); } : undefined); },
      trySubscribeAncestor(key, callback) { ensureSetup(); return context.subscribe(key, 'optional', callback ? (next, prev) => { invoke(callback, [next, prev]); } : undefined, 'ancestor'); },
    },
    props: {
      define(input: Record<string, __wcPropSpec>) {
        ensureSetup();
        const merged = {...specs};
        for (const key of Object.keys(input)) {
          const next = input[key], prev = specs[key];
          if (prev?.validator && prev.validator !== next.validator) throw new Error('Prop validator replacement or removal is disallowed');
          if (!['boolean', 'number', 'string', 'enum', 'object', 'any'].includes(next.type)) throw new Error('Unsupported prop type');
          if (next.empty !== undefined && !['accept', 'fallback', 'error'].includes(next.empty)) throw new Error('Invalid prop empty policy');
          if (next.range && ((next.range.min !== undefined && (typeof next.range.min !== 'number' || Number.isNaN(next.range.min))) || (next.range.max !== undefined && (typeof next.range.max !== 'number' || Number.isNaN(next.range.max))))) throw new Error('Invalid prop range');
          if (prev && (prev.type !== next.type || (prev.range && next.range && ((next.range.min ?? -Infinity) > (prev.range.min ?? -Infinity) || (next.range.max ?? Infinity) < (prev.range.max ?? Infinity))))) throw new Error('Conflicting prop declaration');
          const rank = (empty: string) => empty === 'accept' ? 0 : empty === 'error' ? 2 : 1;
          if (prev && next.empty !== undefined && rank(next.empty) > rank(prev.empty ?? 'fallback')) throw new Error('Conflicting prop empty policy');
          merged[key] = {...prev, ...next, schema: (__wcPropTypes as Record<string, Parameters<typeof __wcAccepts>[0]>)[key], empty: prev?.empty ?? next.empty ?? 'fallback', range: next.range ?? prev?.range, ...(prev && own(prev, 'default') ? {default: prev.default} : {})};
        }
        Object.assign(specs, merged);
        resolved = resolve(false);
        __wcInteraction.refresh();

      },
      setDefaults(input: Record<string, unknown>) { ensureSetup(); for (const key of Object.keys(input)) if (!own(specs, key)) throw new Error('Undeclared prop default: ' + key); defaults.unshift({...input}); resolved = resolve(false); __wcInteraction.refresh(); },
      watch(keys: string[], fn: Function) { ensureSetup(); const watcher = {keys: [...keys], fn, active: true, raw: false}; watchers.push(watcher); return () => { watcher.active = false; }; },
      watchAll(fn: Function) { ensureSetup(); const watcher = {keys: null, fn, active: true, raw: false}; watchers.push(watcher); return () => { watcher.active = false; }; },
      watchRaw(keys: string[], fn: Function) { ensureSetup(); const watcher = {keys: [...keys], fn, active: true, raw: true}; watchers.push(watcher); return () => { watcher.active = false; }; },
      watchRawAll(fn: Function) { ensureSetup(); const watcher = {keys: null, fn, active: true, raw: true}; watchers.push(watcher); return () => { watcher.active = false; }; },
    },
    state: {bool: (s: string, v: boolean) => state('bool', s, v), enum: (s: string, v: string, o: __wcStateOptions) => state('enum', s, v, o), string: (s: string, v: string, o?: __wcStateOptions) => state('string', s, v, o), numberDiscrete: (s: string, v: number, o?: __wcStateOptions) => state('number.discrete', s, v, o), numberRange: (s: string, v: number, o: __wcStateOptions) => state('number.range', s, v, o)},
    expose: {
      value: expose,
      state(key: string, handle: __wcState | __wcNativeObservedState<boolean | string | number>) { const external = observedProjections.get(handle as __wcNativeObservedState<boolean | string | number>)?.external ?? ('external' in handle ? handle.external : undefined); if (!external) throw new Error('Unknown external state projection'); expose(key, external); __wcAuthored.introduceObserved(handle); },
      method<A extends unknown[], R>(key: string, fn: (...args: A) => R, project?: (value: R) => R) {  expose(key, (...args: unknown[]) => { ensureExternal(); const result = invoke(fn, args, false) as R; return project ? project(result) : result; }); },
      event(key: string) { ensureSetup(); if (own(exposes, key) || events.has(key)) throw new Error('Duplicate expose: ' + key); events.add(key); },
    },
    lifecycle: {onCreated(fn) { ensureSetup(); lifecycle.created.push(fn); }, onMounted(fn) { ensureSetup(); lifecycle.mounted.push(fn); }, onUpdated(fn) { ensureSetup(); lifecycle.updated.push(fn); }, onUnmounted(fn) { ensureSetup(); lifecycle.unmounted.push(fn); }, onBeforeDispose(fn) { ensureSetup(); lifecycle.beforeDispose.push(fn); }},
  };
  const owner: __wcOwner = {
    
    authored: __wcAuthored,
    meta: __wcMeta,
    identity: Symbol('compiled-logical-owner'), def, exposes, render: undefined,
    interaction: __wcInteraction,

    style: __wcStyle, props: () => resolved as __wcPropsSnapshot,

    get epoch() { return epoch; }, get view() { return view; },
    hydrate, update: () => schedule(true), reconcile,

    created() { setup = false; fire('created'); },
    dispose(exhaustive = false) {
      if (!alive || disposing) return; disposing = true;
      for (const off of __wcAuthoredWatchCleanups.splice(0)) off();
      let error: { value: unknown } | undefined;
      try { detach(); } catch (caught) { error = { value: caught }; }
      try {
        if (exhaustive) {
          for (const callback of lifecycle.beforeDispose) {
            try { invoke(callback); } catch (caught) { error ??= { value: caught }; }
          }
        } else         fire('beforeDispose');
      } catch (caught) { error ??= { value: caught }; }
      finally {
        try { __wcInteraction.dispose(); } catch (caught) { error ??= { value: caught }; }
        for (const off of observedSubscriptions.splice(0)) off();
        for (const projection of observedProjections.values()) projection.subscribers.clear();
        observedProjections.clear();

        __wcStyle.dispose(); host.attribute('data-pui-style', null);

        __wcOwnerScopes.delete(host); context.dispose(); host.bindContext(null);
        __wcAuthored.dispose(); alive = false; ++epoch; dirty = false; watchers.length = 0; emissions.length = 0;
        for (const handle of states) handle.subscribers.clear();
        for (const callbacks of Object.values(lifecycle)) callbacks.length = 0;
        host.clear();
      }
      if (error) throw error.value;
    },
  };
  return owner;
}

export class CompiledElement extends HTMLElement {
  private __wcOwner: __wcOwner | null = null;
  private __wcPort: BrowserPort | null = null;
  private __wcRaw: Record<string, unknown> = {};
  private __wcDisconnect = 0;
  private __wcClosed = false;
  private __wcAssociations: Readonly<{ controlLabel?: object | null }> | undefined;
  get instanceAssociations(): Readonly<{ controlLabel?: object | null }> | undefined { return this.__wcAssociations; }
  set instanceAssociations(value: Readonly<{ controlLabel?: object | null }> | undefined) {
    if (this.__wcClosed) throw new Error('Custom element is disposed');
    const accepted = __wcValidateAssociations(value);
    this.__wcAssociations = accepted;
    this.__wcOwner?.interaction.refresh();
  }
  static get observedAttributes(): string[] { return ['instance-associations', 'instanceassociations']; }
  attributeChangedCallback(name: string, _previous: string | null, value: string | null): void {
    if (value !== null) throw new TypeError('[InstanceAssociations] use the instanceAssociations property, not an attribute string');
  }
  get logicalOwner(): symbol | null { return this.__wcOwner?.identity ?? null; }
  get viewEpoch(): number { return this.__wcOwner?.epoch ?? 0; }
  get present(): boolean { return this.__wcOwner?.view ?? false; }
  connectedCallback(): void {
    ++this.__wcDisconnect;
    if (this.__wcClosed) return;
    if (this.__wcOwner) {
      const owner = this.__wcOwner;
      if (!owner.view) {
        const version = this.__wcDisconnect;
        // Finish an enclosing native slot commit before retrying a retained owner.
        queueMicrotask(() => {
          if (this.__wcClosed || owner !== this.__wcOwner || version !== this.__wcDisconnect || !this.isConnected || owner.view) return;
          owner.reconcile();
        });
      }
      return;
    }
    const port = createNativeBrowserPort(this, false, __wcCreateNativeInteraction, __wcMarkNativeExposeEvent);
    this.__wcPort = port;
    const owner = __wcCreateOwner(port, () => this.__wcAssociations);
    this.__wcOwner = owner;
    const __wcDef = owner.def;

    const __wcAuthored = owner.authored;
    const __wcMeta = owner.meta;
    const __wcStyle = owner.style;
    const __wcOwnerProps = owner.props;

    const __wcInteraction = owner.interaction;

    const __wcHook0 = (options?: unknown) => (__wcAuthored.install({name: "as-button", mode: "once", setup: (options, api) => ((def: __wcDef) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":12:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = ({"kind":"tw","tokens":["select-none"],"groups":["content-selection affordance"]} as const);
const __wcCaptureResult = __wcCaptureReceiver.feedback.style.use(__wcCaptureArg0); __wcAuthored.effect("feedback", __wcCaptureResult); __wcAuthored.disposer("feedback", __wcCaptureResult); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":13:9
      const accessible = __wcAuthored.privileged("asAccessible", () => __wcInteraction.asAccessible());
      // Source "packages/prototypes/base/src/button/button.proto.ts":15:3
      __wcAuthored.privileged("asTrigger", () => __wcInteraction.asTrigger());
      // Source "packages/prototypes/base/src/button/button.proto.ts":18:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0: Parameters<typeof __wcCaptureReceiver.props.define>[0] = { ["disabled"]: { ["type"]: "boolean", ["empty"]: "fallback" } };
const __wcCaptureResult = __wcCaptureReceiver.props.define(__wcCaptureArg0); __wcAuthored.effect("props", {"op": "define", "specMap": __wcCaptureArg0}); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":21:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = { ["disabled"]: false };
const __wcCaptureResult = __wcCaptureReceiver.props.setDefaults(__wcCaptureArg0); __wcAuthored.effect("props", {"op": "setDefaults", "partial": __wcCaptureArg0}); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":26:9
      const disabled = (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "disabled";
const __wcCaptureArg1 = false;
const __wcCaptureResult = __wcCaptureReceiver.state.bool(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("state", __wcCaptureResult); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":27:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "disabled";
const __wcCaptureArg1 = disabled;
const __wcCaptureResult = __wcCaptureReceiver.expose.state(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("state", {"op": "expose.state", "key": __wcCaptureArg0, "handle": __wcCaptureArg1}); __wcAuthored.introduceObserved(__wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":28:3
      (() => {
const __wcCaptureReceiver = accessible;
const __wcCaptureArg0 = "disabled";
const __wcCaptureArg1 = disabled;
const __wcCaptureResult = __wcCaptureReceiver.state(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("state", {"op": "a11y.state", "key": __wcCaptureArg0, "handle": __wcCaptureArg1, "options": undefined}); __wcAuthored.introduceObserved(__wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":31:9
      const hovered = (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "hovered";
const __wcCaptureArg1 = false;
const __wcCaptureResult = __wcCaptureReceiver.state.bool(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("state", __wcCaptureResult); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":32:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "hovered";
const __wcCaptureArg1 = hovered;
const __wcCaptureResult = __wcCaptureReceiver.expose.state(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("state", {"op": "expose.state", "key": __wcCaptureArg0, "handle": __wcCaptureArg1}); __wcAuthored.introduceObserved(__wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":35:9
      const focusable = __wcAuthored.privileged("asFocusable", () => __wcInteraction.asFocusable(), ["focused","focusVisible","focusable"]);
      // Source "packages/prototypes/base/src/button/button.proto.ts":36:3
      focusable.configure({ ["disabled"]: false });
      // Source "packages/prototypes/base/src/button/button.proto.ts":38:9
      const focused = (focusable)["focused"];
      // Source "packages/prototypes/base/src/button/button.proto.ts":39:9
      const focusVisible = (focusable)["focusVisible"];
      // Source "packages/prototypes/base/src/button/button.proto.ts":42:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "focused";
const __wcCaptureArg1 = focused;
const __wcCaptureResult = __wcCaptureReceiver.expose.state(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("state", {"op": "expose.state", "key": __wcCaptureArg0, "handle": __wcCaptureArg1}); __wcAuthored.introduceObserved(__wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":43:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "focusVisible";
const __wcCaptureArg1 = focusVisible;
const __wcCaptureResult = __wcCaptureReceiver.expose.state(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("state", {"op": "expose.state", "key": __wcCaptureArg0, "handle": __wcCaptureArg1}); __wcAuthored.introduceObserved(__wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":46:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "focusSelf";
const __wcCaptureArg1 = (options?: { "reason"?: "programmatic" | "keyboard" | "pointer"; "preventScroll"?: boolean }): void => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":47:5
        if ((disabled.get() as boolean)) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":47:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":48:5
        focusable.focusSelf(options);
      };
const __wcCaptureResult = __wcCaptureReceiver.expose.method(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("context", {"op": "expose.method", "key": __wcCaptureArg0, "fn": __wcCaptureArg1}); __wcAuthored.method(__wcCaptureArg0, __wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":52:9
      const pressed = (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "pressed";
const __wcCaptureArg1 = false;
const __wcCaptureResult = __wcCaptureReceiver.state.bool(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("state", __wcCaptureResult); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":53:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "pressed";
const __wcCaptureArg1 = pressed;
const __wcCaptureResult = __wcCaptureReceiver.expose.state(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("state", {"op": "expose.state", "key": __wcCaptureArg0, "handle": __wcCaptureArg1}); __wcAuthored.introduceObserved(__wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":55:9
      const clearTransientInteraction = (reason: string): void => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":56:5
        hovered.set(false, reason);
        // Source "packages/prototypes/base/src/button/button.proto.ts":57:5
        pressed.set(false, reason);
      };
      // Source "packages/prototypes/base/src/button/button.proto.ts":61:3
      def.lifecycle.onUnmounted(() => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":62:5
        (clearTransientInteraction)("reason: button view unmounted => reset transient interaction");
      });
      // Source "packages/prototypes/base/src/button/button.proto.ts":66:9
      const syncDisabled = (nextDisabled: boolean): void => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":67:5
        disabled.set(nextDisabled, "reason: sync disabled");
        // Source "packages/prototypes/base/src/button/button.proto.ts":68:5
        focusable.setDisabled(nextDisabled);
        // Source "packages/prototypes/base/src/button/button.proto.ts":69:5
        if (nextDisabled) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":70:7
          (clearTransientInteraction)("reason: button disabled => reset transient interaction");
        }
      };
      // Source "packages/prototypes/base/src/button/button.proto.ts":73:3
      def.lifecycle.onCreated((run: __wcRun) => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":74:5
        (syncDisabled)((run.props.get())["disabled"]);
      });
      // Source "packages/prototypes/base/src/button/button.proto.ts":76:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = ["disabled"];
const __wcCaptureArg1 = (_run: __wcRun, next: __wcPropsSnapshot) => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":77:5
        (syncDisabled)((next)["disabled"]);
      };
const __wcCaptureResult = __wcCaptureReceiver.props.watch(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("props", {"op": "watch", "keys": __wcCaptureArg0, "off": __wcCaptureResult}); __wcAuthored.disposer("props", __wcCaptureResult); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":81:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "click";
const __wcCaptureArg1 = { ["payload"]: "void" };
const __wcCaptureResult = __wcCaptureReceiver.expose.event(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("event", {"op": "expose.event", "key": __wcCaptureArg0, "spec": __wcCaptureArg1}); __wcAuthored.eventKey(__wcCaptureArg0); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":83:3
      accessible.action("activate", { ["event"]: "click" });
      // Source "packages/prototypes/base/src/button/button.proto.ts":86:3
      accessible.role("button");
      // Source "packages/prototypes/base/src/button/button.proto.ts":89:3
      accessible.nameFromContent();
      // Source "packages/prototypes/base/src/button/button.proto.ts":91:9
      const activate = (run: __wcRun, isCurrent: () => boolean = (): boolean => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":91:83
        return true;
      }): void => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":92:5
        if (((disabled.get() as boolean) || (!(isCurrent)()))) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":92:41
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":93:5
        pressed.set(false, "reason: button activation => pressed");
        // Source "packages/prototypes/base/src/button/button.proto.ts":94:5
        if (((disabled.get() as boolean) || (!(isCurrent)()))) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":94:41
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":95:5
        run.expose.emit("click");
      };
      // Source "packages/prototypes/base/src/button/button.proto.ts":97:3
      __wcAuthored.privileged("asControlLabel", () => __wcInteraction.asControlLabel()).target((run: __wcRun, request: __wcNativeModuleCapability<"control-label-request", __wcRun>) => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":98:11
        const isCurrent = (): boolean => {
          // Source "packages/prototypes/base/src/button/button.proto.ts":98:29
          return ((!(disabled.get() as boolean)) && request.isCurrent());
        };
        // Source "packages/prototypes/base/src/button/button.proto.ts":99:5
        if ((!(isCurrent)())) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":99:23
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":100:5
        focusable.focusSelf({ ["reason"]: (((request)["source"] === "pointer") ? "pointer" : "programmatic") });
        // Source "packages/prototypes/base/src/button/button.proto.ts":101:5
        if ((isCurrent)()) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":101:22
          (activate)(run, isCurrent);
        }
      });
      // Source "packages/prototypes/base/src/button/button.proto.ts":107:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "key.down";
const __wcCaptureArg1 = (_run: __wcRun, ev: __wcNativeInput) => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":108:11
        const detail = ev;
        // Source "packages/prototypes/base/src/button/button.proto.ts":109:5
        if ((disabled.get() as boolean)) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":109:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":110:5
        if ((!(focused.get() as boolean))) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":110:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":111:5
        if (((detail)?.["key"] !== " ")) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":111:30
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":112:5
        ev.control.requestDefaultActionPrevention({ ["reason"]: "button.space-activation", ["source"]: "base-button" });
      };
const __wcCaptureResult = __wcCaptureReceiver.event.onGlobal(__wcCaptureArg0, __wcCaptureArg1); const __wcCaptureOff = () => __wcInteraction.releaseListener(__wcCaptureResult); __wcAuthored.effect("event", {token: __wcCaptureResult, off: __wcCaptureOff}); __wcAuthored.disposer("event", __wcCaptureOff); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":119:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "pointer.enter";
const __wcCaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":120:5
        if ((disabled.get() as boolean)) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":120:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":121:5
        hovered.set(true, "reason: button pointer.enter => hovered");
      };
const __wcCaptureResult = __wcCaptureReceiver.event.on(__wcCaptureArg0, __wcCaptureArg1); const __wcCaptureOff = () => __wcInteraction.releaseListener(__wcCaptureResult); __wcAuthored.effect("event", {token: __wcCaptureResult, off: __wcCaptureOff}); __wcAuthored.disposer("event", __wcCaptureOff); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":123:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "pointer.leave";
const __wcCaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":124:5
        hovered.set(false, "reason: button pointer.leave => hovered");
        // Source "packages/prototypes/base/src/button/button.proto.ts":125:5
        pressed.set(false, "reason: button pointer.leave => pressed");
      };
const __wcCaptureResult = __wcCaptureReceiver.event.on(__wcCaptureArg0, __wcCaptureArg1); const __wcCaptureOff = () => __wcInteraction.releaseListener(__wcCaptureResult); __wcAuthored.effect("event", {token: __wcCaptureResult, off: __wcCaptureOff}); __wcAuthored.disposer("event", __wcCaptureOff); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":127:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "pointer.cancel";
const __wcCaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":128:5
        hovered.set(false, "reason: button pointer.cancel => hovered");
        // Source "packages/prototypes/base/src/button/button.proto.ts":129:5
        pressed.set(false, "reason: button pointer.cancel => pressed");
      };
const __wcCaptureResult = __wcCaptureReceiver.event.on(__wcCaptureArg0, __wcCaptureArg1); const __wcCaptureOff = () => __wcInteraction.releaseListener(__wcCaptureResult); __wcAuthored.effect("event", {token: __wcCaptureResult, off: __wcCaptureOff}); __wcAuthored.disposer("event", __wcCaptureOff); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":132:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "press.cancel";
const __wcCaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":133:5
        (clearTransientInteraction)("reason: button press.cancel => reset transient interaction");
      };
const __wcCaptureResult = __wcCaptureReceiver.event.on(__wcCaptureArg0, __wcCaptureArg1); const __wcCaptureOff = () => __wcInteraction.releaseListener(__wcCaptureResult); __wcAuthored.effect("event", {token: __wcCaptureResult, off: __wcCaptureOff}); __wcAuthored.disposer("event", __wcCaptureOff); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":137:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "pointer.down";
const __wcCaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":138:5
        if ((disabled.get() as boolean)) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":138:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":139:5
        pressed.set(true, "reason: button pointer.down => pressed");
      };
const __wcCaptureResult = __wcCaptureReceiver.event.on(__wcCaptureArg0, __wcCaptureArg1); const __wcCaptureOff = () => __wcInteraction.releaseListener(__wcCaptureResult); __wcAuthored.effect("event", {token: __wcCaptureResult, off: __wcCaptureOff}); __wcAuthored.disposer("event", __wcCaptureOff); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":141:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "pointer.up";
const __wcCaptureArg1 = () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":142:5
        pressed.set(false, "reason: button pointer.up => pressed");
      };
const __wcCaptureResult = __wcCaptureReceiver.event.on(__wcCaptureArg0, __wcCaptureArg1); const __wcCaptureOff = () => __wcInteraction.releaseListener(__wcCaptureResult); __wcAuthored.effect("event", {token: __wcCaptureResult, off: __wcCaptureOff}); __wcAuthored.disposer("event", __wcCaptureOff); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":146:3
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "press.commit";
const __wcCaptureArg1 = (run: __wcRun) => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":147:5
        pressed.set(false, "reason: button press.commit => pressed");
        // Source "packages/prototypes/base/src/button/button.proto.ts":148:5
        (activate)(run);
      };
const __wcCaptureResult = __wcCaptureReceiver.event.on(__wcCaptureArg0, __wcCaptureArg1); const __wcCaptureOff = () => __wcInteraction.releaseListener(__wcCaptureResult); __wcAuthored.effect("event", {token: __wcCaptureResult, off: __wcCaptureOff}); __wcAuthored.disposer("event", __wcCaptureOff); return __wcCaptureResult; })();
    })(__wcDef)}, options) as { readonly stateHandles?: Readonly<Record<string, unknown>>; readonly getState?: (name: string) => unknown; readonly getMethod?: (name: string) => unknown; readonly getAsHook?: (name: string) => unknown; readonly getAsHookHandle?: (name: string) => unknown; readonly render?: unknown });    try {
      owner.render = ((def: __wcDef) => {
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":77:5
        (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0: Parameters<typeof __wcCaptureReceiver.props.define>[0] = { ["variant"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["solid", "surface", "destructive"] }, ["color"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["main", "mint", "lavender", "coral", "sky"] }, ["size"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["default", "sm", "lg", "icon"] }, ["wrap"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["disabled"]: { ["type"]: "boolean", ["empty"]: "fallback" } };
const __wcCaptureResult = __wcCaptureReceiver.props.define(__wcCaptureArg0); __wcAuthored.effect("props", {"op": "define", "specMap": __wcCaptureArg0}); return __wcCaptureResult; })();
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":94:5
        (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = { ["variant"]: "solid", ["color"]: "main", ["size"]: "default", ["wrap"]: false, ["disabled"]: false };
const __wcCaptureResult = __wcCaptureReceiver.props.setDefaults(__wcCaptureArg0); __wcAuthored.effect("props", {"op": "setDefaults", "partial": __wcCaptureArg0}); return __wcCaptureResult; })();
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":103:11
        const buttonState = ((__wcHook0())["stateHandles"] as { readonly "disabled": __wcState<boolean> & {watch(callback: (run: __wcRun, event: {type:'next';prev:boolean;next:boolean;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}; readonly "hovered": __wcState<boolean> & {watch(callback: (run: __wcRun, event: {type:'next';prev:boolean;next:boolean;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}; readonly "focused": __wcNativeObservedState<boolean>; readonly "focusVisible": __wcNativeObservedState<boolean>; readonly "pressed": __wcState<boolean> & {watch(callback: (run: __wcRun, event: {type:'next';prev:boolean;next:boolean;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void} });
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":104:5
        if ((!buttonState)) {
          // Source "packages/prototypes/brutalist/src/button/button.proto.ts":105:7
          throw new Error("[brutalist-button] asButton must project Button state handles.");
        }
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":107:13
        const disabled = (buttonState)["disabled"];
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":107:23
        const hovered = (buttonState)["hovered"];
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":107:32
        const focusVisible = (buttonState)["focusVisible"];
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":107:46
        const pressed = (buttonState)["pressed"];
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":109:5
        (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = ({"kind":"tw","tokens":["group/brutalist-button","inline-flex","shrink-0","items-center","justify-center","gap-2","font-sans","font-medium","rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium"],"groups":["group/brutalist-button","display","shrink-0","items-","justify-","gap-2","font-sans","font weight","rounded","border-width","border-color","shadow-","font-sans","font weight"]} as const);
const __wcCaptureResult = __wcCaptureReceiver.feedback.style.use(__wcCaptureArg0); __wcAuthored.effect("feedback", __wcCaptureResult); __wcAuthored.disposer("feedback", __wcCaptureResult); return __wcCaptureResult; })();
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":114:5
        __wcAuthored.rule(__wcStyle.rule(() => (__wcStyle.meta("preference.reducedMotion") === "no-preference"), [({"kind":"tw","tokens":["transition-all"],"groups":["transition-"]} as const)], ["preference.reducedMotion"]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":118:5
        __wcAuthored.rule(__wcStyle.rule(() => !((__wcStyle.meta("preference.reducedMotion") === "no-preference")), [({"kind":"tw","tokens":["transition-none"],"groups":["transition-"]} as const)], ["preference.reducedMotion"]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
        __wcAuthored.rule(__wcStyle.rule(() => ((__wcOwnerProps()["variant"] === "solid") && (__wcOwnerProps()["color"] === "main")), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-main","text-main-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
        __wcAuthored.rule(__wcStyle.rule(() => ((__wcOwnerProps()["variant"] === "solid") && (__wcOwnerProps()["color"] === "mint")), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-mint","text-mint-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
        __wcAuthored.rule(__wcStyle.rule(() => ((__wcOwnerProps()["variant"] === "solid") && (__wcOwnerProps()["color"] === "lavender")), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-lavender","text-lavender-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
        __wcAuthored.rule(__wcStyle.rule(() => ((__wcOwnerProps()["variant"] === "solid") && (__wcOwnerProps()["color"] === "coral")), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-coral","text-coral-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
        __wcAuthored.rule(__wcStyle.rule(() => ((__wcOwnerProps()["variant"] === "solid") && (__wcOwnerProps()["color"] === "sky")), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-sky","text-sky-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":134:9
        __wcAuthored.rule(__wcStyle.rule(() => (__wcOwnerProps()["variant"] === "surface"), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-secondary-background","text-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":134:9
        __wcAuthored.rule(__wcStyle.rule(() => (__wcOwnerProps()["variant"] === "destructive"), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-destructive","text-destructive-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":143:7
        (false ? __wcAuthored.rule(__wcStyle.rule(() => (__wcOwnerProps()["size"] === "default"), [({"kind":"tw","tokens":["h-10","px-4","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]} as const)])) : __wcAuthored.rule(__wcStyle.rule(() => ((__wcOwnerProps()["size"] === "default") && (__wcOwnerProps()["wrap"] === false)), [({"kind":"tw","tokens":["h-10","px-4","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]} as const)])));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":143:7
        (false ? __wcAuthored.rule(__wcStyle.rule(() => (__wcOwnerProps()["size"] === "sm"), [({"kind":"tw","tokens":["h-9","px-3","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]} as const)])) : __wcAuthored.rule(__wcStyle.rule(() => ((__wcOwnerProps()["size"] === "sm") && (__wcOwnerProps()["wrap"] === false)), [({"kind":"tw","tokens":["h-9","px-3","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]} as const)])));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":143:7
        (false ? __wcAuthored.rule(__wcStyle.rule(() => (__wcOwnerProps()["size"] === "lg"), [({"kind":"tw","tokens":["h-11","px-8","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]} as const)])) : __wcAuthored.rule(__wcStyle.rule(() => ((__wcOwnerProps()["size"] === "lg") && (__wcOwnerProps()["wrap"] === false)), [({"kind":"tw","tokens":["h-11","px-8","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]} as const)])));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":143:7
        (true ? __wcAuthored.rule(__wcStyle.rule(() => (__wcOwnerProps()["size"] === "icon"), [({"kind":"tw","tokens":["size-10","whitespace-nowrap"],"groups":["size-10","whitespace-nowrap"]} as const)])) : __wcAuthored.rule(__wcStyle.rule(() => ((__wcOwnerProps()["size"] === "icon") && (__wcOwnerProps()["wrap"] === false)), [({"kind":"tw","tokens":["size-10","whitespace-nowrap"],"groups":["size-10","whitespace-nowrap"]} as const)])));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":154:7
        __wcAuthored.rule(__wcStyle.rule(() => ((__wcOwnerProps()["size"] === "default") && (__wcOwnerProps()["wrap"] === true)), [({"kind":"tw","tokens":["min-h-10","h-auto","px-4","py-1","text-sm","whitespace-normal","min-w-0","max-w-full","wrap-anywhere","text-center"],"groups":["min-h-","h-","px-","py-","text-size","whitespace-normal","min-w-","max-w-","wrap-anywhere","text-align"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":154:7
        __wcAuthored.rule(__wcStyle.rule(() => ((__wcOwnerProps()["size"] === "sm") && (__wcOwnerProps()["wrap"] === true)), [({"kind":"tw","tokens":["min-h-9","h-auto","px-3","py-1","text-sm","whitespace-normal","min-w-0","max-w-full","wrap-anywhere","text-center"],"groups":["min-h-","h-","px-","py-","text-size","whitespace-normal","min-w-","max-w-","wrap-anywhere","text-align"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":154:7
        __wcAuthored.rule(__wcStyle.rule(() => ((__wcOwnerProps()["size"] === "lg") && (__wcOwnerProps()["wrap"] === true)), [({"kind":"tw","tokens":["min-h-11","h-auto","px-8","py-1","text-sm","whitespace-normal","min-w-0","max-w-full","wrap-anywhere","text-center"],"groups":["min-h-","h-","px-","py-","text-size","whitespace-normal","min-w-","max-w-","wrap-anywhere","text-align"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":161:5
        __wcAuthored.rule((() => { const __puiRuleState0 = hovered; return __wcStyle.rule(() => (__puiRuleState0.get() === true), [({"kind":"tw","tokens":["translate-x-1","translate-y-1","shadow-none","relative","hit-envelope-translate-1"],"groups":["translate-x-","translate-y-","shadow-","relative","hit-envelope-translate-1"]} as const)]); })());
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":167:5
        __wcAuthored.rule((() => { const __puiRuleState0 = pressed; return __wcStyle.rule(() => (__puiRuleState0.get() === true), [({"kind":"tw","tokens":["translate-x-1","translate-y-1","shadow-none","relative","hit-envelope-translate-1"],"groups":["translate-x-","translate-y-","shadow-","relative","hit-envelope-translate-1"]} as const)]); })());
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":173:5
        __wcAuthored.rule((() => { const __puiRuleState0 = focusVisible; return __wcStyle.rule(() => (__puiRuleState0.get() === true), [({"kind":"tw","tokens":["outline-none","ring-2","ring-ring","ring-offset-2","ring-offset-background"],"groups":["outline-none","ring-2","ring-ring","ring-offset-2","ring-offset-background"]} as const)]); })());
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":178:5
        __wcAuthored.rule((() => { const __puiRuleState0 = disabled; return __wcStyle.rule(() => (__puiRuleState0.get() === true), [({"kind":"tw","tokens":["pointer-events-none","opacity-50"],"groups":["pointer-events-none","opacity-"]} as const)]); })());
      })(__wcDef);
      owner.hydrate(this.__wcRaw);
      owner.created();
      owner.reconcile();
      port.accept();
    } catch (error) {
      try { owner.dispose(); }
      finally { port.dispose(); this.__wcPort = null; this.__wcOwner = null; }
      throw error;
    }
  }
  disconnectedCallback(): void {
    const version = ++this.__wcDisconnect;
    const owner = this.__wcOwner;
    queueMicrotask(() => {
      if (version !== this.__wcDisconnect || this.isConnected || !owner || owner !== this.__wcOwner) return;
      this.__wcOwner = null;
      try { owner.dispose(); } finally { this.__wcPort?.dispose(); this.__wcPort = null; }
    });
  }
  setProps(next: GeneratedProps & Record<string, unknown>): void {
    if (this.__wcClosed) throw new Error('Custom element is disposed');

    if (Object.prototype.hasOwnProperty.call(next, 'instanceAssociations')) throw new TypeError('[InstanceAssociations] use the instanceAssociations property, outside Props');
    this.__wcRaw = { ...next };
    const owner = this.__wcOwner;
    if (owner) {
      owner.hydrate(this.__wcRaw);

    }
  }
  update(): void {
    if (this.__wcClosed) throw new Error('Custom element is disposed');
    this.__wcOwner?.update();
  }
  getExposes(): Partial<GeneratedExposes> {
    return this.isConnected && this.__wcOwner ? { ...this.__wcOwner.exposes } as Partial<GeneratedExposes> : {};
  }
  dispose(): void {
    if (this.__wcClosed) return;
    this.__wcClosed = true;
    ++this.__wcDisconnect;
    const owner = this.__wcOwner;
    this.__wcOwner = null;
    try { owner?.dispose(); } finally { this.__wcPort?.dispose(); this.__wcPort = null; }
  }
}
export function register(tagName = "pui-compiled-element", registry: CustomElementRegistry = customElements): typeof CompiledElement {
  const existing = registry.get(tagName);
  if (existing && existing !== CompiledElement) throw new Error('Custom element tag already registered: ' + tagName);
  if (!existing) registry.define(tagName, CompiledElement);
  return CompiledElement;
}
export default CompiledElement;

//# sourceMappingURL=Component.ts.map
