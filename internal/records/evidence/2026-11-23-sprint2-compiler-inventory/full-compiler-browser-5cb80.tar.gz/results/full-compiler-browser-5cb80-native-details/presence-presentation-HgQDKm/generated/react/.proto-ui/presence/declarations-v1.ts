// Neutral declarations; lexical owner/State identity is checked by the canonical controller.

export type State<T> = Readonly<{ get(): T }>;

export interface PresenceOwnerDeclaration<Props = unknown> { readonly ref: PresentationOwnerRef; readonly writer: PresentationOwnerWriter; onCompletionRequest(callback: (run: any, request: CompletionRequest) => void): void; }

export type PresencePhase = 'closed' | 'preparing' | 'entering' | 'entered' | 'leaving';
export type AffineLength = Readonly<{
    px: number;
    rootText: number;
    ownBox: number;
}>;
export type Translation = readonly [
    AffineLength,
    AffineLength
];
export type FiniteSelection<T> = Readonly<{
    source: Pick<State<string>, 'get'>;
    cases: Readonly<Record<string, T>>;
}>;
export type PresenceEndpoint = Readonly<{
    translate?: Translation | FiniteSelection<Translation>;
    opacity?: number;
    /** Named draft extension; intrinsic is measured from the current semantic layout. */
    blockSize?: number | 'intrinsic';
}>;
export type PresentationChannel = 'translate' | 'opacity' | 'blockSize';
export type PresentationOutcome = 'finished' | 'reduced-motion' | 'unknown-preference' | 'hidden' | 'missing-capability' | 'unsupported-endpoint' | 'unresolved-units' | 'unresolved-input' | 'projection-failed' | 'projection-ownership-lost' | 'deadline' | 'zero-duration' | 'invalid-policy' | 'scheduler-failed';
export declare const ownerRefBrand: unique symbol;
export declare const ownerWriterBrand: unique symbol;
export declare const viewBindingBrand: unique symbol;
/** Instance-local symbolic identity. No public constructor or writer capability. */
export type PresentationOwnerRef = Readonly<{
    readonly [ownerRefBrand]: true;
}>;
export type PresentationOwnerWriter = Readonly<{
    readonly [ownerWriterBrand]: true;
}>;
export type PresentationViewBinding = Readonly<{
    readonly [viewBindingBrand]: true;
}>;
export type AttemptToken = Readonly<{
    ownerEpoch: number;
    phaseAttempt: number;
}>;
export type PresentationOwnerFrame = Readonly<{
    owner: PresentationOwnerRef;
    revision: number;
    phase: PresencePhase;
    attempt: AttemptToken | null;
    completion: 'timer' | 'presentation';
    durationMs: number;
    timeoutMs: number | null;
}>;
export type PresentationReceipt = Readonly<{
    owner: PresentationOwnerRef;
    attempt: AttemptToken;
    viewBinding: PresentationViewBinding;
    ownerRevision: number;
    targetRevision: number;
    channels: readonly PresentationChannel[];
    outcome: PresentationOutcome;
}>;
export type PresencePresentationDeclaration = Readonly<{
    owner: PresentationOwnerRef;
    closed: PresenceEndpoint;
    entered: PresenceEndpoint;
    easing: readonly [
        number,
        number,
        number,
        number
    ];
}>;
export type PresentationCompletionConfig = 'timer' | Readonly<{
    kind: 'presentation';
    timeoutMs: number;
}>;
export type CompletionRequest = Readonly<{
    receipt: PresentationReceipt;
}>;
export const fail = (): never => {
    throw new Error('[feedback.presence] Invalid declaration');
};
export function object(value: unknown): object {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        return fail();
    return value;
}
export function field(value: object, key: PropertyKey): unknown {
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor || !('value' in descriptor))
        return fail();
    return descriptor.value;
}
export function shape(value: unknown, allowed: readonly string[], required = allowed): object {
    const result = object(value);
    if (Reflect.ownKeys(result).some((key) => typeof key !== 'string' || !allowed.includes(key)))
        return fail();
    for (const key of required)
        field(result, key);
    return result;
}
export function finite(value: unknown): number {
    if (typeof value !== 'number' || !Number.isFinite(value))
        return fail();
    return value;
}
export function nonnegative(value: unknown): number {
    const n = finite(value);
    if (n < 0)
        return fail();
    return n;
}
export function integer(value: unknown): number {
    const n = nonnegative(value);
    if (!Number.isSafeInteger(n))
        return fail();
    return n;
}
export function dense(value: unknown, length: number): unknown[] {
    if (!Array.isArray(value) ||
        value.length !== length ||
        Reflect.ownKeys(value).some((key) => key !== 'length' && !Array.from({ length }, (_, i) => String(i)).includes(key as string)))
        return fail();
    return Array.from({ length }, (_, i) => field(value, String(i)));
}
export function affine(value: unknown): AffineLength {
    const v = shape(value, ['px', 'rootText', 'ownBox']);
    return Object.freeze({
        px: finite(field(v, 'px')),
        rootText: finite(field(v, 'rootText')),
        ownBox: finite(field(v, 'ownBox')),
    });
}
export function translation(value: unknown): Translation {
    const pair = dense(value, 2);
    return Object.freeze([affine(pair[0]), affine(pair[1])]);
}
export function selectedTranslation(value: unknown): Translation | FiniteSelection<Translation> {
    if (Array.isArray(value))
        return translation(value);
    const v = shape(value, ['source', 'cases']);
    // Never invoke author functions or traverse symbolic reference internals here.
    // The installing module validates this exact handle against its State registry.
    const source = object(field(v, 'source')) as Pick<State<string>, 'get'>;
    const input = object(field(v, 'cases'));
    const keys = Reflect.ownKeys(input);
    if (!keys.length || keys.some((key) => typeof key !== 'string'))
        return fail();
    const cases: Record<string, Translation> = Object.create(null);
    for (const key of keys as string[])
        cases[key] = translation(field(input, key));
    return Object.freeze({ source, cases: Object.freeze(cases) });
}
export function endpoint(value: unknown): PresenceEndpoint {
    const v = shape(value, ['translate', 'opacity', 'blockSize'], []);
    const keys = Reflect.ownKeys(v);
    if (!keys.length)
        return fail();
    const result: {
        translate?: Translation | FiniteSelection<Translation>;
        opacity?: number;
        blockSize?: number | 'intrinsic';
    } = {};
    if (keys.includes('translate'))
        result.translate = selectedTranslation(field(v, 'translate'));
    if (keys.includes('opacity')) {
        const opacity = finite(field(v, 'opacity'));
        if (opacity < 0 || opacity > 1)
            return fail();
        result.opacity = opacity;
    }
    if (keys.includes('blockSize')) {
        const size = field(v, 'blockSize');
        result.blockSize = size === 'intrinsic' ? size : nonnegative(size);
    }
    return Object.freeze(result);
}
export function snapshotPresencePresentation(value: PresencePresentationDeclaration): PresencePresentationDeclaration {
    const v = shape(value, ['owner', 'closed', 'entered', 'easing']);
    const owner = object(field(v, 'owner')) as PresentationOwnerRef;
    const closed = endpoint(field(v, 'closed'));
    const entered = endpoint(field(v, 'entered'));
    if (Object.keys(closed).some((key) => !Object.hasOwn(entered, key)) ||
        Object.keys(closed).length !== Object.keys(entered).length)
        return fail();
    const easing = dense(field(v, 'easing'), 4).map(finite);
    if (easing[0] < 0 || easing[0] > 1 || easing[2] < 0 || easing[2] > 1)
        return fail();
    return Object.freeze({
        owner,
        closed,
        entered,
        easing: Object.freeze(easing) as unknown as PresencePresentationDeclaration['easing'],
    });
}
export function snapshotPresentationCompletionConfig(value: PresentationCompletionConfig): PresentationCompletionConfig {
    if (value === 'timer')
        return value;
    const v = shape(value, ['kind', 'timeoutMs']);
    const timeoutMs = finite(field(v, 'timeoutMs'));
    if (field(v, 'kind') !== 'presentation' || timeoutMs <= 0)
        return fail();
    return Object.freeze({ kind: 'presentation', timeoutMs });
}
export function snapshotPresentationOwnerFrame(value: PresentationOwnerFrame): PresentationOwnerFrame {
    const v = shape(value, [
        'owner',
        'revision',
        'phase',
        'attempt',
        'completion',
        'durationMs',
        'timeoutMs',
    ]);
    const owner = object(field(v, 'owner')) as PresentationOwnerRef;
    const revision = integer(field(v, 'revision'));
    const phase = field(v, 'phase') as PresencePhase;
    if (!['closed', 'preparing', 'entering', 'entered', 'leaving'].includes(phase))
        return fail();
    const completion = field(v, 'completion');
    if (completion !== 'timer' && completion !== 'presentation')
        return fail();
    const durationMs = nonnegative(field(v, 'durationMs'));
    const timeout = field(v, 'timeoutMs');
    const timeoutMs = timeout === null ? null : finite(timeout);
    if ((completion === 'timer' && timeoutMs !== null) ||
        (completion === 'presentation' && (timeoutMs === null || timeoutMs <= 0)))
        return fail();
    const rawAttempt = field(v, 'attempt');
    let attempt: AttemptToken | null = null;
    if (rawAttempt !== null) {
        const a = shape(rawAttempt, ['ownerEpoch', 'phaseAttempt']);
        attempt = Object.freeze({
            ownerEpoch: integer(field(a, 'ownerEpoch')),
            phaseAttempt: integer(field(a, 'phaseAttempt')),
        });
    }
    if ((phase === 'entering' || phase === 'leaving') !== (attempt !== null))
        return fail();
    // A later duration >= timeout is a runtime invalid-policy settlement, not a lost frame.
    return Object.freeze({ owner, revision, phase, attempt, completion, durationMs, timeoutMs });
}

// packages/core/src/spec/feedback/style.ts
/**
 * Style handle (v0)
 * - Only supports Tailwind-flavored tokens
 * - Keep as IR; adapters decide how to realize it.
 */
export type StyleHandle = {
    kind: 'tw';
    tokens: string[];
};

/**
 * EffectsPort (v0)
 * - accepts StyleHandle as IR
 * - host decides how to realize it
 * - MUST NOT trigger structural render/commit
 */
export interface EffectsPort {
    /**
     * Queue a merged style handle into host-side effect buffer.
     * Cheap, no structural commit.
     */
    queueStyle(handle: StyleHandle): void;
    /**
     * Request a flush tick to apply buffered effects to the current host element.
     * MUST NOT trigger structural commit.
     */
    requestFlush(): void;
    /**
     * Optional: flush immediately (useful for tests).
     */
    flushNow?(): void;
}

/** Setup-only persistent style interpolation. This is not presence or State. */
export type ResidentMotionProperty = 'translate' | 'background-color';
export type ResidentMotionDeclaration = Readonly<{
  properties: readonly ResidentMotionProperty[];
  durationMs: number;
  easing: readonly [number, number, number, number];
}>;
export function snapshotResidentMotion(
  value: ResidentMotionDeclaration
): ResidentMotionDeclaration {
  const fail = (): never => {
    throw new Error('[feedback.motion] Invalid declaration');
  };
  const field = (object: object, key: PropertyKey): unknown => {
    const descriptor = Object.getOwnPropertyDescriptor(object, key);
    if (!descriptor || !('value' in descriptor)) return fail();
    return descriptor.value;
  };
  if (!value || typeof value !== 'object') return fail();
  const dense = (input: unknown): unknown[] => {
    if (!Array.isArray(input)) return fail();
    return Array.from({ length: input.length }, (_, i) => field(input, String(i)));
  };
  const properties = dense(field(value, 'properties'));
  const easing = dense(field(value, 'easing'));
  const durationMs = field(value, 'durationMs');
  if (
    !properties.length ||
    new Set(properties).size !== properties.length ||
    properties.some((p) => p !== 'translate' && p !== 'background-color') ||
    typeof durationMs !== 'number' ||
    !Number.isFinite(durationMs) ||
    durationMs < 0 ||
    easing.length !== 4 ||
    easing.some((n) => typeof n !== 'number' || !Number.isFinite(n)) ||
    (easing[0] as number) < 0 ||
    (easing[0] as number) > 1 ||
    (easing[2] as number) < 0 ||
    (easing[2] as number) > 1
  )
    return fail();
  return Object.freeze({
    properties: Object.freeze(properties) as readonly ResidentMotionProperty[],
    durationMs,
    easing: Object.freeze(easing) as unknown as ResidentMotionDeclaration['easing'],
  });
}
