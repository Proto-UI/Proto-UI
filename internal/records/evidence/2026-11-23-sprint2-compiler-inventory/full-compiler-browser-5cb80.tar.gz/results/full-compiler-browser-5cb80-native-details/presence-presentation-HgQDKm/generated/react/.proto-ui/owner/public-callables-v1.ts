/** Public call boundaries preserve raw authored closures and their original receivers. */
export function createNativePublicCalls(options: { alive(): void; invoke<T>(callback: () => T): T }) {
  type Entry = { callable: Function; results: Map<string, (value: unknown) => unknown> };
  const root = Object.freeze({}), cache = new WeakMap<object, WeakMap<Function, Entry>>();
  const records = new WeakMap<object, object>();
  const arrays = new WeakMap<readonly unknown[], unknown[]>();
  const projectedCallables = new WeakMap<Function, Entry>();
  function wrap<T extends Function>(callback: T, receiver: object = root, projectResult?: (value: ReturnType<Extract<T, (...args: never[]) => unknown>>) => unknown, projectionKey = ''): T {
    let callbacks = cache.get(receiver);
    if (!callbacks) { callbacks = new WeakMap(); cache.set(receiver, callbacks); }
    let entry = projectedCallables.get(callback) ?? callbacks.get(callback);
    if (!entry) {
      const results = new Map<string, (value: unknown) => unknown>();
      const callable = function (...args: unknown[]) {
        options.alive();
        const raw = options.invoke(() => Reflect.apply(callback, receiver, args));
        let projected = raw;
        for (const project of results.values()) projected = project(raw);
        return projected;
      };
      entry = { callable, results };
      callbacks.set(callback, entry);
      projectedCallables.set(callable, entry);
    }
    if (projectResult) entry.results.set(projectionKey, value => projectResult(value as ReturnType<Extract<T, (...args: never[]) => unknown>>));
    return entry.callable as T;
  }
  wrap.record = function <T extends object>(source: T, project: (target: T) => void): T {
    let target = records.get(source) as T | undefined;
    if (!target) {
      target = { ...source };
      records.set(source, target);
      records.set(target, target);
    } else if (target !== source) {
      for (const key of Object.keys(target)) if (!Object.hasOwn(source, key)) Reflect.deleteProperty(target, key);
      for (const [key, value] of Object.entries(source)) Object.defineProperty(target, key, {value, enumerable: true, configurable: true, writable: true});
    }
    // Public records remain mutable. Revisit current fields even when this is
    // already our projection; wrap() preserves previously guarded functions.
    project(target);
    return target;
  };
  wrap.array = function <T extends readonly unknown[]>(source: T, project: (target: unknown[]) => void): T {
    let target = arrays.get(source);
    if (!target) {
      target = [];
      arrays.set(source, target);
      arrays.set(target, target);
    }
    if ((target as readonly unknown[]) !== source) {
      target.length = source.length;
      for (const key of Reflect.ownKeys(target))
        if (key !== 'length' && !Object.hasOwn(source, key)) Reflect.deleteProperty(target, key);
      for (let index = 0; index < source.length; index++) {
        const item = Object.getOwnPropertyDescriptor(source, index);
        if (!item) { Reflect.deleteProperty(target, index); continue; }
        if (!Object.hasOwn(item, 'value')) throw new TypeError('[Expose] array accessors are not public data.');
        Object.defineProperty(target, index, { value: item.value, enumerable: true, configurable: true, writable: true });
      }
    }
    // Preserve the original public array identity while refreshing its current
    // elements. The generic return view retains authored readonly permission.
    project(target);
    return target as unknown as T;
  };
  return wrap;
}
