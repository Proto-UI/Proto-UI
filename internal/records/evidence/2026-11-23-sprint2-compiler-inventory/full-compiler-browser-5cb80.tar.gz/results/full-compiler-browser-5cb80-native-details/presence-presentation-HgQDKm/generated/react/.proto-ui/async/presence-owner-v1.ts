export type NativePresentationRef = Readonly<object>;
export type NativePresentationWriter = Readonly<object>;
export type NativeCompletionConfig = 'timer' | Readonly<{ kind: 'presentation'; timeoutMs: number }>;
export type NativeAttempt = Readonly<{ ownerEpoch: number; phaseAttempt: number }>;
export interface NativePresentationFrame {
  readonly owner: NativePresentationRef;
  readonly revision: number;
  readonly phase: 'closed' | 'preparing' | 'entering' | 'entered' | 'leaving';
  readonly attempt: NativeAttempt | null;
  readonly completion: 'timer' | 'presentation';
  readonly durationMs: number;
  readonly timeoutMs: number | null;
}
export type NativePresentationOutcome = 'finished' | 'reduced-motion' | 'unknown-preference' | 'hidden' | 'missing-capability' | 'unsupported-endpoint' | 'unresolved-units' | 'unresolved-input' | 'projection-failed' | 'projection-ownership-lost' | 'deadline' | 'zero-duration' | 'invalid-policy' | 'scheduler-failed';
export interface NativePresentationReceipt {
  readonly owner: NativePresentationRef;
  readonly attempt: NativeAttempt;
  readonly viewBinding: object;
  readonly ownerRevision: number;
  readonly targetRevision: number;
  readonly channels: readonly ('opacity' | 'translate')[];
  readonly outcome: NativePresentationOutcome;
}
export interface NativePresenceOwner<Run> {
  readonly ref: NativePresentationRef;
  readonly writer: NativePresentationWriter;
  onCompletionRequest(callback: (run: Run, request: Readonly<{ receipt: NativePresentationReceipt }>) => void): void;
}
function ownFields(value: unknown, names: readonly string[]): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new TypeError('[Presence] expected a data record');
  const result: Record<string, unknown> = Object.create(null);
  const keys = Reflect.ownKeys(value);
  if (keys.length !== names.length || keys.some(key => typeof key !== 'string' || !names.includes(key))) throw new TypeError('[Presence] unexpected record shape');
  for (const name of names) {
    const field = Object.getOwnPropertyDescriptor(value, name);
    if (!field || !('value' in field)) throw new TypeError('[Presence] own data fields are required');
    result[name] = field.value;
  }
  return result;
}
function finite(value: unknown, positive = false): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || (positive ? value <= 0 : value < 0)) throw new TypeError('[Presence] invalid finite duration');
  return value;
}
function integer(value: unknown): number {
  const result = finite(value);
  if (!Number.isSafeInteger(result)) throw new TypeError('[Presence] invalid revision');
  return result;
}
export function snapshotNativeCompletion(value: NativeCompletionConfig): NativeCompletionConfig {
  if (value === 'timer') return value;
  const fields = ownFields(value, ['kind', 'timeoutMs']);
  if (fields.kind !== 'presentation') throw new TypeError('[Presence] invalid completion kind');
  return Object.freeze({ kind: 'presentation', timeoutMs: finite(fields.timeoutMs, true) });
}
function snapshotFrame(value: NativePresentationFrame): NativePresentationFrame {
  const fields = ownFields(value, ['owner', 'revision', 'phase', 'attempt', 'completion', 'durationMs', 'timeoutMs']);
  if (!fields.owner || typeof fields.owner !== 'object') throw new TypeError('[Presence] invalid owner');
  if (!['closed', 'preparing', 'entering', 'entered', 'leaving'].includes(fields.phase as string)) throw new TypeError('[Presence] invalid phase');
  if (fields.completion !== 'timer' && fields.completion !== 'presentation') throw new TypeError('[Presence] invalid completion');
  const timeoutMs = fields.timeoutMs === null ? null : finite(fields.timeoutMs, true);
  if ((fields.completion === 'timer') !== (timeoutMs === null)) throw new TypeError('[Presence] invalid timeout');
  let attempt: NativeAttempt | null = null;
  if (fields.attempt !== null) {
    const parts = ownFields(fields.attempt, ['ownerEpoch', 'phaseAttempt']);
    attempt = Object.freeze({ ownerEpoch: integer(parts.ownerEpoch), phaseAttempt: integer(parts.phaseAttempt) });
  }
  if ((fields.phase === 'entering' || fields.phase === 'leaving') !== (attempt !== null)) throw new TypeError('[Presence] phase and attempt disagree');
  return Object.freeze({ owner: fields.owner, revision: integer(fields.revision), phase: fields.phase as NativePresentationFrame['phase'], attempt,
    completion: fields.completion, durationMs: finite(fields.durationMs), timeoutMs });
}
export function createNativePresence<Run>(options: {
  setup(): void;
  runtime(): void;
  alive(): boolean;
  invoke(callback: (run: Run) => void): void;
}) {
  type Owner = { ref: object; writer: object; frame: NativePresentationFrame | null; binding: object | null;
    pending: NativePresentationReceipt | null; callback: ((run: Run, request: { receipt: NativePresentationReceipt }) => void) | null };
  const writers = new Map<object, Owner>();
  let disposed = false;
  function requireOwner(writer: object): Owner {
    const owner = writers.get(writer);
    if (disposed || !options.alive() || !owner) throw new Error('[Presence] foreign or disposed writer');
    return owner;
  }
  function isCurrent(writer: object, receipt: NativePresentationReceipt): boolean {
    const owner = writers.get(writer), frame = owner?.frame;
    return !disposed && options.alive() && !!owner && owner.pending === receipt && !!frame?.attempt
      && owner.ref === receipt.owner && owner.binding === receipt.viewBinding && frame.revision === receipt.ownerRevision
      && receipt.targetRevision === 0 && frame.attempt.ownerEpoch === receipt.attempt.ownerEpoch
      && frame.attempt.phaseAttempt === receipt.attempt.phaseAttempt;
  }
  return {
    owner(): NativePresenceOwner<Run> {
      options.setup();
      if (disposed) throw new Error('[Presence] disposed registry');
      const owner: Owner = { ref: Object.freeze({}), writer: Object.freeze({}), frame: null, binding: null, pending: null, callback: null };
      writers.set(owner.writer, owner);
      return Object.freeze({ ref: owner.ref, writer: owner.writer, onCompletionRequest(callback: NonNullable<Owner['callback']>) {
        options.setup(); requireOwner(owner.writer);
        if (owner.callback || typeof callback !== 'function') throw new TypeError('[Presence] exactly one completion receiver is required');
        owner.callback = callback;
      } });
    },
    publish(writer: object, value: NativePresentationFrame): void {
      options.runtime(); const owner = requireOwner(writer); const frame = snapshotFrame(value);
      if (frame.owner !== owner.ref || owner.frame && frame.revision <= owner.frame.revision) throw new Error('[Presence] foreign owner or nonmonotonic revision');
      owner.pending = null; owner.frame = frame;
    },
    isCurrent,
    settle(writer: object, outcome: NativePresentationOutcome): void {
      options.runtime(); const owner = requireOwner(writer), frame = owner.frame;
      if (!frame?.attempt || frame.completion !== 'presentation' || owner.pending && isCurrent(writer, owner.pending)) return;
      owner.binding ??= Object.freeze({});
      // No presentation sink is implicitly installed. The authored owner decides how
      // its current attempt completes after this explicit missing-capability outcome.
      const receipt: NativePresentationReceipt = Object.freeze({ owner: owner.ref, attempt: frame.attempt,
        viewBinding: owner.binding, ownerRevision: frame.revision, targetRevision: 0, channels: Object.freeze([]),
        outcome: outcome === 'finished' ? 'missing-capability' : outcome });
      owner.pending = receipt;
      options.invoke(run => { if (isCurrent(writer, receipt)) owner.callback?.(run, Object.freeze({ receipt })); });
    },
    detach() { for (const owner of writers.values()) { owner.binding = null; owner.pending = null; } },
    dispose() { if (disposed) return; disposed = true; writers.clear(); },
  };
}
