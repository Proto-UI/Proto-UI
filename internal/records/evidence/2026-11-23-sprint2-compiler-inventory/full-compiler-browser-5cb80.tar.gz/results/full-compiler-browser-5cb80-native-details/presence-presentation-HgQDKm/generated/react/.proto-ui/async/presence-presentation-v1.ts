import { createPresenceController } from '../presence/controller-v1';
import { createWebPresencePresentationSink } from '../presence/web-v1';
import type { PresencePresentationDeclaration, PresentationOwnerFrame, PresentationOwnerWriter, PresentationReceipt, PresentationOutcome, State } from '../presence/declarations-v1';
import type { NativePresenceOwner, NativePresentationFrame, NativePresentationReceipt, NativePresentationOutcome } from './presence-owner-v1';

/** Bridge only: the canonical controller/projector remains the presentation policy. */
export function createNativePresencePresentation<Run>(options: {
  setup(): void; runtime(): void; alive(): boolean;
  invoke(callback: (run: Run) => void): void;
  root(): HTMLElement | null;
  tokens(): readonly string[];
  project(tokens: readonly string[]): void;
  watch(source: object, callback: () => void): () => void;
}) {
  let mounted = false, disposed = false, epoch = 0, revision = 0;
  let sink: ReturnType<typeof createWebPresencePresentationSink> | null = null;
  let target: HTMLElement | null = null;
  let callbackRun: Run | undefined;
  const controller = createPresenceController({
    setup() { options.setup(); if (disposed || !options.alive()) throw new Error('[Presence] owner is disposed'); },
    runtime() { options.runtime(); if (disposed || !options.alive()) throw new Error('[Presence] owner is disposed'); },
    invalidate: refresh,
    dispatch(callback) { options.invoke(run => { const previous = callbackRun; callbackRun = run; try { callback(); } finally { callbackRun = previous; } }); },
    callbackContext: () => callbackRun,
    watch: (state, callback) => options.watch(state, callback),
    sink() {
      const root = options.root();
      if (!mounted || !root || disposed || !options.alive()) return null;
      if (target !== root) { sink?.release(epoch); sink = null; target = root; }
      if (!sink) {
        let pending: readonly string[] = [];
        sink = createWebPresencePresentationSink(root, {
          queueStyle(style) { pending = style.tokens; },
          requestFlush() { if (mounted && target === root && options.alive()) options.project(pending); },
        });
      }
      return sink;
    },
    fallback: style => options.project(style.tokens),
  });
  function refresh() {
    if (!mounted || disposed || !options.alive() || !options.root()) return;
    controller.commit({ kind: 'tw', tokens: [...options.tokens()] }, epoch, ++revision);
  }
  function detach() {
    mounted = false;
    try { controller.release(); } finally { sink = null; target = null; }
  }
  return {
    owner(): NativePresenceOwner<Run> { return controller.facade.owner() as unknown as NativePresenceOwner<Run>; },
    registerSource(source: object) { controller.facade.registerSource(source); },
    declare(value: unknown) { return controller.declare(value as PresencePresentationDeclaration); },
    publish(writer: object, frame: NativePresentationFrame) { controller.facade.publish(writer as PresentationOwnerWriter, frame as PresentationOwnerFrame); },
    isCurrent(writer: object, receipt: NativePresentationReceipt) { return controller.facade.isCurrent(writer as PresentationOwnerWriter, receipt as PresentationReceipt); },
    settle(writer: object, outcome: NativePresentationOutcome) { controller.facade.settle(writer as PresentationOwnerWriter, outcome as PresentationOutcome); },
    mount(nextEpoch: number) { if (disposed) return; if (mounted && nextEpoch !== epoch) detach(); epoch = nextEpoch; mounted = true; refresh(); },
    refresh, detach,
    dispose() { if (disposed) return; disposed = true; mounted = false; try { controller.dispose(); } finally { sink = null; target = null; } },
  };
}
