import * as react from "/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202/results/full-compiler-browser-5cb80-native-details/presence-presentation-HgQDKm/generated/react/Component.tsx";
import * as vue from "/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202/results/full-compiler-browser-5cb80-native-details/presence-presentation-HgQDKm/generated/vue/Component.ts";
import * as vue2 from "/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202/results/full-compiler-browser-5cb80-native-details/presence-presentation-HgQDKm/generated/vue2/Component.js";
import * as wc from "/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202/results/full-compiler-browser-5cb80-native-details/presence-presentation-HgQDKm/generated/wc/Component.ts";
import {createPresenceBrowserFixture} from "/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202/Proto-UI-final/packages/compiler/test/presence-browser-consumer.ts";
export const fixture=createPresenceBrowserFixture({react,vue,vue2,wc});
