export interface NativeDelayTask { cancel(): void }
export function createNativeDelay(options: {
  runtime(): void;
  alive(): boolean;
  invoke(callback: () => void): void;
  report(error: unknown): void;
}) {
  const pending = new Set<NativeDelayTask>();
  let disposed = false;
  function cancelPending(): void {
    let failure: { error: unknown } | undefined;
    for (const task of [...pending]) { try { task.cancel(); } catch (error) { failure ??= { error }; } }
    if (failure) throw failure.error;
  }
  return {
    schedule(durationMs: number, callback: () => void): NativeDelayTask {
      options.runtime();
      if (disposed || !options.alive()) throw new Error('[Delay] owner is disposed');
      if (!Number.isFinite(durationMs) || durationMs < 0) throw new Error('[Delay] durationMs must be non-negative and finite');
      if (typeof callback !== 'function') throw new TypeError('[Delay] callback must be a function');
      let active = true;
      let timer: ReturnType<typeof setTimeout>;
      const deadline = performance.now() + durationMs;
      const task: NativeDelayTask = Object.freeze({ cancel() {
        if (!active) return;
        active = false; pending.delete(task); clearTimeout(timer);
      } });
      // A zero duration still crosses the native host scheduling boundary.
      const ready = () => {
        if (!active) return;
        if (disposed || !options.alive()) { task.cancel(); return; }
        const remaining = deadline - performance.now();
        if (remaining > 0) { timer = setTimeout(ready, Math.min(remaining, 2147483647)); return; }
        active = false; pending.delete(task);
        try { options.invoke(callback); } catch (error) { options.report(error); }
      };
      timer = setTimeout(ready, Math.min(durationMs, 2147483647));
      pending.add(task);
      return task;
    },
    cancelView: cancelPending,
    dispose() { if (disposed) return; disposed = true; cancelPending(); },
  };
}
