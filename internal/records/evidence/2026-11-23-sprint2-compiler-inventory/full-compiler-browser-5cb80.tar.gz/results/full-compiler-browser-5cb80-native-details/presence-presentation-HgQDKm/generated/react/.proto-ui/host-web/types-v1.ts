// Neutral host contracts selected from the canonical Core declarations.
export type State<V> = Readonly<{ get(): V }>;
/**
 * A host-local point used only while a move gesture session is active.
 * Units and coordinate spaces are owned by the host and are never author state.
 */
export type MoveGesturePoint = Readonly<{
    x: number;
    y: number;
}>;
export type MoveGestureAxis = 'horizontal' | 'vertical' | 'both';
export type MoveGestureInput = 'mouse' | 'touch' | 'pen' | 'unknown';
/** Directional recognition is an opt-in draft; immediate remains the default consumer policy. */
export type MoveGestureActivation = 'immediate' | 'directional';
export type MoveGestureSample = Readonly<{
    input: MoveGestureInput;
    position: MoveGesturePoint;
    delta: MoveGesturePoint;
    totalDelta: MoveGesturePoint;
    timestamp: number;
    /** Optional finite association into the privileged binding's ordered origin targets. */
    originIndex?: number | null;
}>;
export type MoveGestureCancelReason = 'host-cancel' | 'lost-ownership' | 'target-detached' | 'target-replaced' | 'disposed';
/**
 * Internal host binding for one continuous primary-contact move gesture.
 * It deliberately does not model drag payloads, drop targets, collision, or
 * collection reorder semantics.
 */
export type MoveGestureHostBinding = Readonly<{
    target: unknown;
    axis: MoveGestureAxis;
    activation: MoveGestureActivation;
    /** Privileged hit-test targets; original contact association survives capture. */
    originTargets?: readonly unknown[];
    shouldStart?(sample: MoveGestureSample): boolean;
    onStart(sample: MoveGestureSample): void;
    onMove(sample: MoveGestureSample): void;
    onEnd(sample: MoveGestureSample): void;
    onCancel(reason: MoveGestureCancelReason): void;
}>;
export interface MoveGestureHostLease {
    update(binding: MoveGestureHostBinding): void;
    dispose(): void;
}
export interface MoveGestureHost {
    attach(binding: MoveGestureHostBinding): MoveGestureHostLease;
}
/** Experimental dimensionless input seam. Domain values and keyboard intent stay in the consumer. */
export type AxisInputSample = Readonly<{
    phase: 'start' | 'move' | 'end';
    /** Position clamped to the geometry interval. */
    position: number;
    /** Signed fractions of the start-time displacement basis (geometry span by default); intentionally not clamped. */
    delta: number;
    totalDelta: number;
    /** Opt-in start origin in the declared role's public order; null means input background. */
    originIndex?: number | null;
}> | Readonly<{
    phase: 'cancel';
    reason: AxisInputCancelReason;
}>;
export type AxisInputCancelReason = MoveGestureCancelReason | 'disabled' | 'configuration-changed' | 'invalid-geometry' | 'basis-changed';
export type AxisInputConfig = Readonly<{
    axis: 'horizontal' | 'vertical';
    direction: 'ltr' | 'rtl';
    disabled: boolean;
    readOnly: boolean;
    /** Additional reversal, useful for a vertical value axis increasing upwards. */
    reverse: boolean;
    /** Draft opt-in recognition. Omitted initially means immediate; partial sync retains. */
    activation?: 'immediate' | 'directional';
    /** Omitted initial policy preserves start geometry; partial sync keeps the current policy. */
    contactBasis?: 'preserve-start' | 'cancel-on-extent-change';
}>;
/** Privileged host attachment. Opaque targets are never exposed by AxisInputHandle. */
export type AxisInputHostBinding = Readonly<{
    inputTarget: unknown;
    geometryTarget: unknown;
    /** Host-private presentation geometry; never becomes an input or focus target. */
    travelTarget?: unknown;
    /** Host-private same-owner parts; zero-sized collapsed parts are allowed. */
    deltaBasisTargets?: readonly unknown[];
    /** Privileged ordered targets for originRole; never exposed to a prototype. */
    originTargets?: readonly unknown[];
    config: AxisInputConfig;
    onSample(sample: AxisInputSample): void;
}>;
export interface AxisInputHostLease {
    update(binding: AxisInputHostBinding): void;
    dispose(): void;
}
export interface AxisInputHost {
    attach(binding: AxisInputHostBinding): AxisInputHostLease;
}
/** A host-logical root-content region; no browser or platform objects cross this boundary. */
export type AvailableSpaceRect = Readonly<{
    x: number;
    y: number;
    width: number;
    height: number;
}>;
export type AvailableSpaceFrame = Readonly<{
    rect: AvailableSpaceRect | null;
    revision: number;
    viewEpoch: number;
}>;
export type AvailableSpaceConnection = Readonly<{
    target: unknown;
    boundary: 'root-content';
}>;
/** Neutral constrained layout intent; host measurements never become author State. */
export type AvailableLayoutEdge = 'top' | 'right' | 'bottom' | 'left';
export type AvailableLayoutExtent = 'intrinsic' | 'fraction';
export type AvailableLayoutUnit = 'logical' | 'root-text' | 'available' | 'available-minus-root-text';
export type AvailableLayoutValue<T> = T | State<T>;
export type AvailableLayoutLengthBinding = Readonly<{
    unit: AvailableLayoutValue<AvailableLayoutUnit>;
    value: AvailableLayoutValue<number>;
}>;
export type AvailableLayoutLength = Readonly<{
    unit: AvailableLayoutUnit;
    value: number;
}>;
export type AvailableLayoutBinding = Readonly<{
    enabled?: AvailableLayoutValue<boolean>;
    edge: AvailableLayoutValue<AvailableLayoutEdge>;
    extent: AvailableLayoutValue<AvailableLayoutExtent>;
    fraction?: AvailableLayoutValue<number>;
    minimum?: AvailableLayoutLengthBinding;
    maximum?: AvailableLayoutLengthBinding;
    displacement?: State<number>;
}>;
export type AvailableLayoutSnapshot = Readonly<{
    edge: AvailableLayoutEdge;
    extent: AvailableLayoutExtent;
    fraction: number;
    minimum: AvailableLayoutLength;
    maximum: AvailableLayoutLength;
    displacement: number;
}>;
export type AvailableLayoutFrame = Readonly<{
    status: 'ready';
    value: AvailableLayoutSnapshot;
}> | Readonly<{
    status: 'disabled' | 'invalid';
}>;
export type AvailableSpaceHostConnection = AvailableSpaceConnection & {
    readonly viewEpoch: number;
    readonly layout?: AvailableLayoutFrame;
};
export interface AvailableSpaceHostLease {
    /** Host diagnostics only, never an author geometry State. */
    getLayoutStatus?(): string;
    updateLayout?(layout: AvailableLayoutFrame): void;
    /** Host diagnostics, never a Proto state surface. null means no active/known frame. */
    getFrame?(): AvailableSpaceFrame | null;
    requestUpdate(): void;
    dispose(): void;
}
export interface AvailableSpaceHost {
    readonly supportsLayout?: boolean;
    attach(connection: AvailableSpaceHostConnection): AvailableSpaceHostLease;
}
export type AffineLength = Readonly<{
    px: number;
    rootText: number;
    ownBox: number;
}>;
export type Translation = readonly [
    AffineLength,
    AffineLength
];
