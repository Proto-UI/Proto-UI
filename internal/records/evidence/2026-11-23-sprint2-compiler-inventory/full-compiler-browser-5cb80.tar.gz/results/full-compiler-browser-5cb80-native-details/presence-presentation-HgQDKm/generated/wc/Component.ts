// Native web-component-source-v1: no Proto-UI Runtime/Core/Adapter dependency.
// Helper cost: owner/callback guards, scalar state + subscriptions, prop fallback/watch,
// microtask update/ViewIntent reconciliation, native shadow DOM template construction.
// Context cost: shared reference-key modules, owner scopes, checked JSON records, dynamic logical DOM ancestry.
// Context ancestry follows registered generated owners, never tag names or CSS markers.
// setProps is a full raw snapshot. No automatic state-write rendering.
// Synchronous DOM moves retain the owner; settled disconnection disposes it.
// setPresent detaches only the view; explicit dispose permanently closes this element.
import {createContextScope as __wcCreateContextScope, ownerScopes as __wcOwnerScopes, acceptsContextValue as __wcAccepts, type ContextScope as __wcContextScope} from "./.proto-ui/context/scope-v1";



import { createNativeDelay as __wcCreateDelay, type NativeDelayTask as __wcDelayTask } from './.proto-ui/async/delay-web-v1';
import { createNativePresence as __wcCreatePresence, snapshotNativeCompletion as __wcSnapshotCompletion, type NativePresenceOwner as __wcPresenceOwner } from './.proto-ui/presentation/presence-web-v1';
import { readNativeWebMeta as __wcReadMeta } from './.proto-ui/meta/web-snapshot-v1';

import { createNativePublicCalls as __wcCreatePublicCalls } from './.proto-ui/owner/public-callables-v1';

import { createNativeAuthoredHooks as __wcCreateAuthored } from './.proto-ui/owner/authored-hooks-v1';
// Source "packages/prototypes/base/src/transition/as-transition.proto.ts":23:1
const __puiModule1 = (value: ((__wcState<string> & {watch(callback: (run: __wcRun, event: {type:'next';prev:string;next:string;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}) | (undefined)), name: "transitionState"): __wcState<string> & {watch(callback: (run: __wcRun, event: {type:'next';prev:string;next:string;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void} => {
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":27:3
  return value;
};
// Source "packages/prototypes/base/src/transition/as-transition.proto.ts":23:1
const __puiModule2 = (value: ((__wcState<boolean> & {watch(callback: (run: __wcRun, event: {type:'next';prev:boolean;next:boolean;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}) | (undefined)), name: "isPresent"): __wcState<boolean> & {watch(callback: (run: __wcRun, event: {type:'next';prev:boolean;next:boolean;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void} => {
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":27:3
  return value;
};
// Source "packages/prototypes/base/src/transition/as-transition.proto.ts":23:1
const __puiModule3 = (value: ((() => ((() => void) | (null))) | (undefined)), name: "capturePreparation"): () => ((() => void) | (null)) => {
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":27:3
  return value;
};
// Source "packages/prototypes/base/src/transition/as-transition.proto.ts":23:1
const __puiModule4 = (value: ((() => void) | (undefined)), name: "enter"): () => void => {
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":27:3
  return value;
};
// Source "packages/prototypes/base/src/transition/as-transition.proto.ts":23:1
const __puiModule5 = (value: ((() => void) | (undefined)), name: "leave"): () => void => {
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":27:3
  return value;
};
// Source "packages/prototypes/base/src/transition/as-transition.proto.ts":23:1
const __puiModule6 = (value: ((() => void) | (undefined)), name: "complete"): () => void => {
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":27:3
  return value;
};
// Source "packages/prototypes/base/src/transition/as-transition.proto.ts":23:1
const __puiModule7 = (value: ((__wcState<boolean> & {watch(callback: (run: __wcRun, event: {type:'next';prev:boolean;next:boolean;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}) | (undefined)), name: "transitionAppearDefault"): __wcState<boolean> & {watch(callback: (run: __wcRun, event: {type:'next';prev:boolean;next:boolean;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void} => {
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":27:3
  return value;
};
// Source "packages/prototypes/base/src/transition/as-transition.proto.ts":23:1
const __puiModule8 = (value: ((__wcState<number> & {watch(callback: (run: __wcRun, event: {type:'next';prev:number;next:number;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}) | (undefined)), name: "transitionEnterDurationDefault"): __wcState<number> & {watch(callback: (run: __wcRun, event: {type:'next';prev:number;next:number;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void} => {
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":27:3
  return value;
};
// Source "packages/prototypes/base/src/transition/as-transition.proto.ts":23:1
const __puiModule9 = (value: ((__wcState<number> & {watch(callback: (run: __wcRun, event: {type:'next';prev:number;next:number;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}) | (undefined)), name: "transitionLeaveDurationDefault"): __wcState<number> & {watch(callback: (run: __wcRun, event: {type:'next';prev:number;next:number;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void} => {
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":27:3
  return value;
};
// Source "packages/prototypes/base/src/transition/as-transition.proto.ts":23:1
const __puiModule10 = (value: ((__wcState<string> & {watch(callback: (run: __wcRun, event: {type:'next';prev:string;next:string;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}) | (undefined)), name: "transitionInterruptDefault"): __wcState<string> & {watch(callback: (run: __wcRun, event: {type:'next';prev:string;next:string;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void} => {
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":27:3
  return value;
};
// Source "packages/prototypes/base/src/transition/as-transition.proto.ts":23:1
const __puiModule11 = (value: ((__wcState<boolean> & {watch(callback: (run: __wcRun, event: {type:'next';prev:boolean;next:boolean;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}) | (undefined)), name: "transitionColdEntryPreparation"): __wcState<boolean> & {watch(callback: (run: __wcRun, event: {type:'next';prev:boolean;next:boolean;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void} => {
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":27:3
  return value;
};
// Source "packages/prototypes/base/src/transition/as-transition.proto.ts":23:1
const __puiModule12 = (value: (((config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void) | (undefined)), name: "configurePresentation"): (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void => {
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":27:3
  return value;
};
// Source "packages/prototypes/base/src/transition/as-transition.proto.ts":23:1
const __puiModule13 = (value: ((() => Readonly<object>) | (undefined)), name: "getPresentationOwner"): () => Readonly<object> => {
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":27:3
  return value;
};
// Source "packages/prototypes/base/src/transition/as-transition.proto.ts":23:1
const __puiModule14 = (value: (((source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void) | (undefined)), name: "bindInitialOpen"): (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void => {
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":27:3
  return value;
};
// Source "packages/prototypes/base/src/transition/as-transition.proto.ts":23:1
const __puiModule15 = (value: (((source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void) | (undefined)), name: "bindOpenContext"): (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void => {
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":27:3
  return value;
};
// Source "packages/prototypes/base/src/transition/as-transition.proto.ts":23:1
const __puiModule16 = (value: (((retained: boolean) => void) | (undefined)), name: "retainClosedView"): (retained: boolean) => void => {
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":27:3
  return value;
};

import { createNativeBrowserPort, type NativeBrowserPort, type NativeFrameBuilder } from './.proto-ui/web-component/browser-v1';
type BrowserPort = NativeBrowserPort<undefined>;
type HostPort = BrowserPort;
const __wcPropTypes = {"side":{"kind":"union","members":[{"kind":"literal","value":"left"},{"kind":"literal","value":"right"}]},"open":"boolean","defaultOpen":"boolean","appear":"boolean","enterDuration":"number","leaveDuration":"number","interrupt":{"kind":"union","members":[{"kind":"literal","value":"reverse"},{"kind":"literal","value":"wait"},{"kind":"literal","value":"immediate"}]}};
import {createNativeStyle as __wcCreateNativeStyle, templateStyleTokens as __wcTemplateStyleTokens, type NativeStyle as __wcStyle, type NativeStyleHandle as __wcNativeStyleHandle, type NativeRuleHandle as __wcNativeRuleHandle} from './.proto-ui/style/native-v1';

import {markNativeExposeEvent as __wcMarkNativeExposeEvent} from './.proto-ui/interaction/native-6eaed2f12f730f2c-v2';

export type GeneratedProps = {
  "side"?: "left" | "right" | null;
  "open"?: boolean | null;
  "defaultOpen"?: boolean | null;
  "appear"?: boolean | null;
  "enterDuration"?: number | null;
  "leaveDuration"?: number | null;
  "interrupt"?: "reverse" | "wait" | "immediate" | null;
};
type __wcPropsSnapshot = {
  readonly "side": "left" | "right";
  readonly "open": boolean;
  readonly "defaultOpen": boolean;
  readonly "appear": boolean;
  readonly "enterDuration": number;
  readonly "leaveDuration": number;
  readonly "interrupt": "reverse" | "wait" | "immediate";
};
export type GeneratedExposes = {
  "bindInitialOpen": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void;
  "getPresentationOwner": () => Readonly<object>;
  "configurePresentation": (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void;
  "bindOpenContext": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void;
  "retainClosedView": (retained: boolean) => void;
  "transitionState": __wcExternalState<string>;
  "isPresent": __wcExternalState<boolean>;
  "enter": () => void;
  "leave": () => void;
  "complete": () => void;
  "capturePreparation": () => ((() => void) | (null));
  "controls": { "enter": () => void; "leave": () => void; "complete": () => void; "capturePreparation": () => ((() => void) | (null)) };
};
type __wcExternalState<T> = { get(): T; subscribe(cb: (event: {type: 'next'; prev: T; next: T; reason?: unknown}) => void): () => void; unsubscribe(off: () => void): void; spec: Readonly<__wcStateOptions & {kind: string}> };
type __wcScalar = string | number | boolean | null;
type __wcSnapshot = Readonly<Record<string, unknown>>;
type __wcPropSpec = {type: string; schema?: Parameters<typeof __wcAccepts>[0]; default?: unknown; options?: readonly string[]; empty?: 'accept' | 'fallback' | 'error'; range?: {min?: number; max?: number}; validator?: (value: never) => boolean};
type __wcStateOptions = {options?: readonly __wcScalar[]; min?: number; max?: number; step?: number; clamp?: boolean};
type __wcState<T extends __wcScalar = __wcScalar> = {get(): T; setDefault(next: T): void; set(next: T, reason?: unknown): void; external: __wcExternalState<T>; subscribers: Set<Function>};
type __wcContextKey<T> = object & {readonly __contextValue?: T};
type __wcContextRead = Readonly<{read<T>(key: __wcContextKey<T>): T; tryRead<T>(key: __wcContextKey<T>): T | null}>;
type __wcContextRun = __wcContextRead & {tryReadAncestor<T>(key: __wcContextKey<T>): T | null; update<T>(key: __wcContextKey<T>, next: T | ((prev: T) => T)): void; tryUpdate<T>(key: __wcContextKey<T>, next: T | ((prev: T) => T)): boolean};
type __wcContextDef = {provide<T>(key: __wcContextKey<T>, value: T): void; subscribe<T>(key: __wcContextKey<T>, callback?: (run: __wcRun, next: T, prev: T) => void): () => void; trySubscribe<T>(key: __wcContextKey<T>, callback?: (run: __wcRun, next: T | null, prev: T | null) => void): () => void; trySubscribeAncestor<T>(key: __wcContextKey<T>, callback?: (run: __wcRun, next: T | null, prev: T | null) => void): () => void};

type __wcPropsRead = Readonly<{get(): __wcPropsSnapshot; getRaw(): Readonly<Record<string, unknown>>; isProvided(key: string): boolean}>;
type __wcRun = {host: {get(): HTMLElement | null}; readonly feedback: {readonly style: __wcStyle}; readonly context: __wcContextRun; update(): void; props: __wcPropsRead; lifecycle: {setPresent(next: boolean): void}; expose: {emit(key: string, payload?: unknown, options?: CustomEventInit): void}};
type __wcRenderer = { slot(): (()=>Node); readonly nativeFrame:NativeFrameBuilder; readonly props: __wcPropsRead; readonly read: Readonly<{readonly props: __wcPropsRead; readonly context: __wcContextRead}>};
type __wcDef = {
  readonly feedback: {readonly style: __wcStyle};


  context: __wcContextDef;
  props: {define(input: Record<string, __wcPropSpec>): void; setDefaults(input: Record<string, unknown>): void; watch(keys: string[], fn: Function): () => void; watchAll(fn: Function): () => void; watchRaw(keys: string[], fn: Function): () => void; watchRawAll(fn: Function): () => void};
  state: {bool(s: string, v: boolean): __wcState<boolean>; enum(s: string, v: string, o: __wcStateOptions): __wcState<string>; string(s: string, v: string, o?: __wcStateOptions): __wcState<string>; numberDiscrete(s: string, v: number, o?: __wcStateOptions): __wcState<number>; numberRange(s: string, v: number, o: __wcStateOptions): __wcState<number>};
  expose: {value(key: string, value: unknown): void; state(key: string, handle: __wcState): void; method<A extends unknown[], R>(key: string, fn: (...args: A) => R, project?: (value: R) => R): void; event(key: string, spec?: object): void};
  lifecycle: {onCreated(fn: Function): void; onMounted(fn: Function): void; onUpdated(fn: Function): void; onUnmounted(fn: Function): void; onBeforeDispose(fn: Function): void};
};
type __wcOwner = {wrapPublic: ReturnType<typeof __wcCreatePublicCalls>; authored: ReturnType<typeof __wcCreateAuthored>; delay: ReturnType<typeof __wcCreateDelay>; presence: ReturnType<typeof __wcCreatePresence<__wcRun>>; meta: (key: string) => unknown; identity: symbol; def: __wcDef; exposes: Record<string, unknown>; render?: Function | void; readonly epoch: number; readonly view: boolean; readonly style: __wcStyle; props(): __wcPropsSnapshot; hydrate(input: Record<string, unknown>): void; update(): void; reconcile(): void; created(): void; dispose(exhaustive?: boolean): void};
function __wcCreateOwner(host: HostPort): __wcOwner {
  let alive = true, disposing = false, setup = true, callbackDepth = 0;

  let intent = true, view = false, epoch = 0, queued = false, dirty = false, hostScheduled = false;

  let propsWindow: {raw: Readonly<Record<string, unknown>>; resolved: __wcSnapshot} | null = null;
  let resolved: __wcSnapshot = Object.freeze({}), raw: Readonly<Record<string, unknown>> = Object.freeze({}), hydrated = false;
  const specs: Record<string, __wcPropSpec> = Object.create(null), previous: Record<string, unknown> = Object.create(null), defaults: Record<string, unknown>[] = [];
  const watchers: {keys: string[] | null; fn: Function; active: boolean; raw: boolean}[] = [], states: __wcState[] = [], emissions: (() => void)[] = [];
  let emitting = false;
  const exposes: Record<string, unknown> = Object.create(null), events = new Set<string>();
  const lifecycle: Record<string, Function[]> = {created: [], mounted: [], updated: [], unmounted: [], beforeDispose: []};
  const own = (obj: object, key: string) => Object.prototype.hasOwnProperty.call(obj, key);
  const ensure = () => { if (!alive) throw new Error('Logical owner is disposed'); };
  const ensureExternal = () => { ensure(); if (disposing) throw new Error('Logical owner is disposing'); };
  const ensureSetup = () => { ensure(); if (!setup) throw new Error('Setup capability is closed'); };
  const runtime = () => { ensure(); if (setup || !callbackDepth) throw new Error('State writes require a live callback scope'); };
  const __wcDelay = __wcCreateDelay({ runtime: () => { runtime(); }, alive: () => alive, invoke: callback => { invoke(callback, [], false); }, report: error => console.error('[Delay] callback failed', error) });
const __wcPresence = __wcCreatePresence<__wcRun>({ setup: () => { ensureSetup(); }, runtime: () => { runtime(); }, alive: () => alive, invoke: callback => { invoke(callback); }, root: () => host.root, prepare: () => { __wcStyle.refresh(); } });
const __wcMeta = (key: string) => __wcReadMeta(host.root?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), key);
  const __wcAuthoredWatchCleanups: (() => void)[] = [];
  const __wcAuthored = __wcCreateAuthored({setup: ensureSetup, borrow(value) {
    const state = value as __wcState<__wcScalar>;
    const borrowed = Object.freeze({get: () => state.get(), setDefault: (value: __wcScalar) => state.setDefault(value), set: (value: __wcScalar, reason?: unknown) => state.set(value, reason), watch(callback: (run: __wcRun, event: unknown) => void) { ensureSetup(); const off = state.external.subscribe(event => { invoke(callback, [event]); }); __wcAuthoredWatchCleanups.push(off); return off; }});
    __wcPresence.registerSource(borrowed);
    return borrowed;
  }});
  const context = __wcCreateContextScope({getParent: () => host.parentContext(), isAlive: () => alive,
    invoke: <T>(callback: () => T): T => invoke(callback, [], false) as T, validate: (key: object, value: unknown): boolean => false});

  const __wcStyle = __wcCreateNativeStyle({ensureSetup, ensureRuntime: runtime, isAlive: () => alive,
    
    project(tokens) { host.attribute('data-pui-style', tokens.length ? tokens.join(' ') : null); }});


  const __wcWrapPublic = __wcCreatePublicCalls({alive: ensureExternal, invoke: <T>(callback: () => T): T => invoke(callback, [], false) as T});
  let ownerRun: __wcRun | undefined;
  function getRunHandle(): __wcRun {
    if (ownerRun) return ownerRun;
    const check = () => runtime();
    return ownerRun = {
      host: { get() { check(); return view && !disposing ? host.root : null; } },
      feedback: {style: __wcStyle},

      context: Object.freeze({
        read<T>(key: __wcContextKey<T>): T { check(); return context.read(key) as T; },
        tryRead<T>(key: __wcContextKey<T>): T | null { check(); return context.tryRead(key) as T | null; },
        tryReadAncestor<T>(key: __wcContextKey<T>): T | null { check(); return context.tryReadAncestor(key) as T | null; },
        update<T>(key: __wcContextKey<T>, next: T | ((prev: T) => T)) { check(); runtime(); context.update(key, next); },
        tryUpdate<T>(key: __wcContextKey<T>, next: T | ((prev: T) => T)) { check(); runtime(); return context.tryUpdate(key, next); },
      }),
      update() { check(); if (!disposing) schedule(true); },
      props: Object.freeze({get() { check(); return (propsWindow?.resolved ?? resolved) as __wcPropsSnapshot; }, getRaw() { check(); return propsWindow?.raw ?? raw; }, isProvided(key: string) { check(); return own(propsWindow?.raw ?? raw, key); }}),
      lifecycle: {setPresent(next: boolean) { check(); if (disposing) throw new Error('Terminal presence is locked'); if (typeof next !== 'boolean') throw new TypeError('View presence must be boolean'); intent = next; schedule(false); }},
      expose: {emit(key: string, payload?: unknown, options?: CustomEventInit) { check(); if (!events.has(key)) throw new Error('Undeclared exposed event: ' + key); host.emit(key, payload, options); }},
    };
  }
  function invoke(fn: Function, args: unknown[] = [], withRun = true): unknown {
    ensure();
    const run = getRunHandle();

    ++callbackDepth;
    try { return fn(...(withRun ? [run, ...args] : args)); }
    finally { --callbackDepth; }
  }
  __wcOwnerScopes.set(host, context);
  host.bindContext(context);

  const contextRead: __wcContextRead = Object.freeze({
    read<T>(key: __wcContextKey<T>): T { ensure(); if (setup) throw new Error('Context reads require runtime scope'); return context.read(key) as T; },
    tryRead<T>(key: __wcContextKey<T>): T | null { ensure(); if (setup) throw new Error('Context reads require runtime scope'); return context.tryRead(key) as T | null; },
  });
  function fire(name: string): void {
    if (name === 'unmounted') { { let failed = false, first; for (const release of [() => { __wcDelay.cancelView(); }, () => { __wcPresence.detach(); }]) { try { release(); } catch (error) { if (!failed) { failed = true; first = error; } } } if (failed) throw first; } }
    try { for (const fn of lifecycle[name]) invoke(fn); }
    finally { if (name === 'unmounted') { { let failed = false, first; for (const release of [() => { __wcDelay.cancelView(); }, () => { __wcPresence.detach(); }]) { try { release(); } catch (error) { if (!failed) { failed = true; first = error; } } } if (failed) throw first; } } }
  }
  function valid(spec: __wcPropSpec, value: unknown): boolean {
    if (spec.schema === undefined) throw new Error('Missing checked Props schema');
    if (!__wcAccepts(spec.schema, value) || spec.options && !spec.options.includes(value as string) ||
      spec.range && !(typeof value === 'number' && value >= (spec.range.min ?? -Infinity) && value <= (spec.range.max ?? Infinity))) return false;
    try { return spec.validator ? !!spec.validator(value as never) : true; }
    catch { return false; }
  }
  function resolve(strict: boolean): __wcSnapshot {
    const next: Record<string, unknown> = Object.create(null);
    for (const key of Object.keys(specs)) {
      const spec = specs[key], provided = own(raw, key), value = raw[key];
      const requireValue = strict && spec.empty === 'error';
      if (provided && value != null && valid(spec, value)) { next[key] = value; previous[key] = value; continue; }
      if (provided && value == null && spec.empty === 'accept') { next[key] = null; continue; }
      let candidate: unknown;
      if (provided && own(previous, key) && valid(spec, previous[key])) candidate = previous[key];
      if (candidate === undefined) for (const layer of defaults) {
        if (!own(layer, key)) continue;
        const value = layer[key];
        if ((value === null && !requireValue) || (value != null && valid(spec, value))) { candidate = value; break; }
      }
      if (candidate === undefined && own(spec, 'default')) {
        const value = spec.default;
        if ((value === null && !requireValue) || (value != null && valid(spec, value))) candidate = value;
      }
      if (candidate === undefined) {
        if (requireValue) throw new Error('Prop has no valid fallback: ' + key);
        candidate = null;
      }
      next[key] = candidate;
      if (provided && next[key] != null) previous[key] = next[key];
    }
    return Object.freeze(next);
  }
  function hydrate(input: Record<string, unknown>): void {
    ensure();
    const prev = resolved, previousRaw = raw;
    raw = Object.freeze({...input});
    resolved = resolve(true);
    __wcStyle.refresh();


    if (!hydrated) { hydrated = true; return; }
    const changed = Object.keys(specs).filter((key) => !Object.is(prev[key], resolved[key]));
    const rawChanged = watchers.some((watcher) => watcher.raw && watcher.active) ? [...new Set([...Object.keys(previousRaw), ...Object.keys(raw)])].filter((key) => !Object.is(previousRaw[key], raw[key])) : changed;
    const next = resolved, nextRaw = raw;
    const previousWindow = propsWindow; propsWindow = {raw: nextRaw, resolved: next};
    try { for (let group = 0; group < 3; ++group) for (const watcher of [...watchers]) {
      if ((watcher.raw ? watcher.keys === null ? 0 : 1 : 2) !== group) continue;
      const all = watcher.raw ? rawChanged : changed;
      const matched = watcher.keys === null ? all : all.filter((key) => watcher.keys!.includes(key));
      if (watcher.active && matched.length) {
        if (watcher.raw) console.warn('[Props] raw watchers are an adapter-snapshot escape hatch; avoid in official prototypes.');
        invoke(watcher.fn, [watcher.raw ? nextRaw : next, watcher.raw ? previousRaw : prev, {changedKeysAll: all, changedKeysMatched: matched}]);
      }
    } } finally { propsWindow = previousWindow; }
  }
  function drainEmissions(): void {
    if (!emitting) {
  emitting = true;
  const notificationFailures: unknown[] = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < emissions.length && (alive && !disposing)) {
      try { emissions[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { emissions.length = 0; emitting = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
  }
  function state<T extends __wcScalar>(kind: string, semantic: string, initial: T, options: __wcStateOptions = {}): __wcState<T> {
    ensureSetup();
    __wcAuthored.claimState(semantic);
    if (typeof semantic !== 'string' || semantic.length === 0) throw new Error('Invalid state semantic');
    const spec = Object.freeze({...options, kind});
    function validate(value: unknown): void {
      const type = kind === 'bool' ? 'boolean' : kind === 'string' || kind === 'enum' ? 'string' : 'number';
      if (typeof value !== type || (type === 'number' && Number.isNaN(value))) throw new Error('Invalid state value');
      if (options.options?.length && !options.options.includes(value as __wcScalar)) throw new Error('State value outside options');
      if (kind === 'number.range' || (kind === 'number.discrete' && !options.options?.length)) {
        const numeric = typeof value === 'number' ? value : NaN;
        if (numeric < (options.min ?? -Infinity) || numeric > (options.max ?? Infinity)) throw new Error('State value outside range');
        if (kind === 'number.discrete' && options.step !== undefined && options.step > 0 && !Number.isInteger((numeric - (options.min ?? 0)) / options.step)) throw new Error('State value violates step');
      }
    }
    if (kind === 'number.range' && options.clamp) initial = Math.max(options.min ?? -Infinity, Math.min(options.max ?? Infinity, initial as number)) as T;
    validate(initial);
    let value = initial;
    const subscribers = new Set<Function>();
    const external = Object.freeze({
      get() { ensureExternal(); return value; }, spec,
      subscribe(fn: Function) { ensureExternal(); const registration = (event: unknown) => fn(event); subscribers.add(registration); return () => subscribers.delete(registration); },
      unsubscribe(off: () => void) { ensureExternal(); off(); },
    });
    const handle = {external, subscribers,
      get() { ensure(); return value; },
      setDefault(next: T) { ensureSetup(); validate(next); value = next; },
      set(next: T, reason?: unknown) {
        runtime(); validate(next); if (Object.is(value, next)) return;
        const prev = value; value = next;
        __wcStyle.refresh();
__wcPresence.refresh();


        for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(emissions, emissions.length, {value: () => { if ((alive && !disposing) && subscribers.has(subscriber)) { invoke(subscriber, [{type: 'next', prev, next, reason}], false); } }, writable:true, enumerable:true, configurable:true});
}

        drainEmissions();
      },
    };
    states.push(handle); __wcAuthored.state(semantic, handle); __wcPresence.registerSource(handle); return handle;
  }
  let slotUsed = false;

  function render(): void {
    slotUsed = false;
    const nativeFrame=host.createFrame();
    const props: __wcPropsRead=Object.freeze({get:()=>resolved as __wcPropsSnapshot,getRaw:()=>raw,isProvided:(key:string)=>own(raw,key)});
    const renderer: __wcRenderer={nativeFrame,slot(){if(slotUsed)throw new Error('Multiple slots are unsupported');slotUsed=true;return ()=>nativeFrame.slot();},props,read:Object.freeze({props, context: contextRead})};
    projectHost();
    let fragment:DocumentFragment;
    if(typeof owner.render==='function')fragment=(owner.render(renderer) as DocumentFragment|null|undefined)??nativeFrame.document.createDocumentFragment();
    else {fragment=nativeFrame.document.createDocumentFragment();fragment.appendChild(renderer.slot()());}
    host.commit(nativeFrame.finish(fragment));
  }
  function projectHost(): void {
    host.projectRoot(null, {}, null);
  }
  function detach(): void {
    host.visible(false);
    if (!view) return;
    view = false; ++epoch;
    let error: unknown;
    try { __wcStyle.unmount(); host.attribute('data-pui-style', null); } catch (caught) { error ??= caught; }
    try { fire('unmounted'); } catch (caught) { error ??= caught; } finally { host.clear(); }
    if (error !== undefined) throw error;
  }
  function reconcile(): void {
    if (!alive || disposing || !host.isConnected || host.server) return;
    if (!intent) { detach(); return; }
    host.visible(true);
    if (!view) {
      ++epoch; render(); view = true; dirty = false;
      __wcStyle.mount();
      __wcPresence.mount();
      fire('mounted');
    } else if (dirty) { dirty = false; render(); fire('updated'); }
  }
  function schedule(update: boolean): void {
    ensure(); dirty ||= update;
    if (host.server || queued || disposing) return;
    queued = true;
    queueMicrotask(() => {
      queued = false;
      if (!alive || disposing) return;
      // Detached dirty work is retained until the next actual view commit.
      if (host.isConnected) reconcile();
    });
  }

  function expose(key: string, value: unknown): void { ensureSetup(); if (own(exposes, key) || events.has(key)) throw new Error('Duplicate expose: ' + key); exposes[key] = value; }
  const def: __wcDef = {
    feedback: {style: __wcStyle},


    context: {
      provide(key, value) { ensureSetup(); context.provide(key, value); },
      subscribe(key, callback) { ensureSetup(); return context.subscribe(key, 'required', callback ? (next, prev) => { invoke(callback, [next, prev]); } : undefined); },
      trySubscribe(key, callback) { ensureSetup(); return context.subscribe(key, 'optional', callback ? (next, prev) => { invoke(callback, [next, prev]); } : undefined); },
      trySubscribeAncestor(key, callback) { ensureSetup(); return context.subscribe(key, 'optional', callback ? (next, prev) => { invoke(callback, [next, prev]); } : undefined, 'ancestor'); },
    },
    props: {
      define(input: Record<string, __wcPropSpec>) {
        ensureSetup();
        const merged = {...specs};
        for (const key of Object.keys(input)) {
          const next = input[key], prev = specs[key];
          if (prev?.validator && prev.validator !== next.validator) throw new Error('Prop validator replacement or removal is disallowed');
          if (!['boolean', 'number', 'string', 'enum', 'object', 'any'].includes(next.type)) throw new Error('Unsupported prop type');
          if (next.empty !== undefined && !['accept', 'fallback', 'error'].includes(next.empty)) throw new Error('Invalid prop empty policy');
          if (next.range && ((next.range.min !== undefined && (typeof next.range.min !== 'number' || Number.isNaN(next.range.min))) || (next.range.max !== undefined && (typeof next.range.max !== 'number' || Number.isNaN(next.range.max))))) throw new Error('Invalid prop range');
          if (prev && (prev.type !== next.type || (prev.range && next.range && ((next.range.min ?? -Infinity) > (prev.range.min ?? -Infinity) || (next.range.max ?? Infinity) < (prev.range.max ?? Infinity))))) throw new Error('Conflicting prop declaration');
          const rank = (empty: string) => empty === 'accept' ? 0 : empty === 'error' ? 2 : 1;
          if (prev && next.empty !== undefined && rank(next.empty) > rank(prev.empty ?? 'fallback')) throw new Error('Conflicting prop empty policy');
          merged[key] = {...prev, ...next, schema: (__wcPropTypes as Record<string, Parameters<typeof __wcAccepts>[0]>)[key], empty: prev?.empty ?? next.empty ?? 'fallback', range: next.range ?? prev?.range, ...(prev && own(prev, 'default') ? {default: prev.default} : {})};
        }
        Object.assign(specs, merged);
        resolved = resolve(false);

      },
      setDefaults(input: Record<string, unknown>) { ensureSetup(); for (const key of Object.keys(input)) if (!own(specs, key)) throw new Error('Undeclared prop default: ' + key); defaults.unshift({...input}); resolved = resolve(false); },
      watch(keys: string[], fn: Function) { ensureSetup(); const watcher = {keys: [...keys], fn, active: true, raw: false}; watchers.push(watcher); return () => { watcher.active = false; }; },
      watchAll(fn: Function) { ensureSetup(); const watcher = {keys: null, fn, active: true, raw: false}; watchers.push(watcher); return () => { watcher.active = false; }; },
      watchRaw(keys: string[], fn: Function) { ensureSetup(); const watcher = {keys: [...keys], fn, active: true, raw: true}; watchers.push(watcher); return () => { watcher.active = false; }; },
      watchRawAll(fn: Function) { ensureSetup(); const watcher = {keys: null, fn, active: true, raw: true}; watchers.push(watcher); return () => { watcher.active = false; }; },
    },
    state: {bool: (s: string, v: boolean) => state('bool', s, v), enum: (s: string, v: string, o: __wcStateOptions) => state('enum', s, v, o), string: (s: string, v: string, o?: __wcStateOptions) => state('string', s, v, o), numberDiscrete: (s: string, v: number, o?: __wcStateOptions) => state('number.discrete', s, v, o), numberRange: (s: string, v: number, o: __wcStateOptions) => state('number.range', s, v, o)},
    expose: {
      value: expose,
      state(key: string, handle: __wcState) { expose(key, handle.external); __wcAuthored.introduceObserved(handle); },
      method<A extends unknown[], R>(key: string, fn: (...args: A) => R, project?: (value: R) => R) {  expose(key, (...args: unknown[]) => { ensureExternal(); const result = invoke(fn, args, false) as R; return project ? project(result) : result; }); },
      event(key: string) { ensureSetup(); if (own(exposes, key) || events.has(key)) throw new Error('Duplicate expose: ' + key); events.add(key); },
    },
    lifecycle: {onCreated(fn) { ensureSetup(); lifecycle.created.push(fn); }, onMounted(fn) { ensureSetup(); lifecycle.mounted.push(fn); }, onUpdated(fn) { ensureSetup(); lifecycle.updated.push(fn); }, onUnmounted(fn) { ensureSetup(); lifecycle.unmounted.push(fn); }, onBeforeDispose(fn) { ensureSetup(); lifecycle.beforeDispose.push(fn); }},
  };
  const owner: __wcOwner = {
    wrapPublic: __wcWrapPublic,
    authored: __wcAuthored,
    delay: __wcDelay,presence: __wcPresence,meta: __wcMeta,
    identity: Symbol('compiled-logical-owner'), def, exposes, render: undefined,

    style: __wcStyle, props: () => resolved as __wcPropsSnapshot,

    get epoch() { return epoch; }, get view() { return view; },
    hydrate, update: () => schedule(true), reconcile,

    created() { setup = false; fire('created'); },
    dispose(exhaustive = false) {
      if (!alive || disposing) return; disposing = true;
      for (const off of __wcAuthoredWatchCleanups.splice(0)) off();
      let error: { value: unknown } | undefined;
      try { detach(); } catch (caught) { error = { value: caught }; }
      try {
        if (exhaustive) {
          for (const callback of lifecycle.beforeDispose) {
            try { invoke(callback); } catch (caught) { error ??= { value: caught }; }
          }
        } else         fire('beforeDispose');
      } catch (caught) { error ??= { value: caught }; }
      finally {

        __wcStyle.dispose(); host.attribute('data-pui-style', null);

        __wcOwnerScopes.delete(host); context.dispose(); host.bindContext(null);
        { let failed = false, first; for (const release of [() => { __wcDelay.dispose(); }, () => { __wcPresence.dispose(); }]) { try { release(); } catch (error) { if (!failed) { failed = true; first = error; } } } if (failed) throw first; }__wcAuthored.dispose(); alive = false; ++epoch; dirty = false; watchers.length = 0; emissions.length = 0;
        for (const handle of states) handle.subscribers.clear();
        for (const callbacks of Object.values(lifecycle)) callbacks.length = 0;
        host.clear();
      }
      if (error) throw error.value;
    },
  };
  return owner;
}

export class CompiledElement extends HTMLElement {
  private __wcOwner: __wcOwner | null = null;
  private __wcPort: BrowserPort | null = null;
  private __wcRaw: Record<string, unknown> = {};
  private __wcDisconnect = 0;
  private __wcClosed = false;
  private __wcAssociations: Readonly<{ controlLabel?: object | null }> | undefined;
  get instanceAssociations(): Readonly<{ controlLabel?: object | null }> | undefined { return this.__wcAssociations; }
  set instanceAssociations(value: Readonly<{ controlLabel?: object | null }> | undefined) {
    if (this.__wcClosed) throw new Error('Custom element is disposed');
{ const __wcInputAssociations = value;
    if (__wcInputAssociations !== undefined) {
      if (__wcInputAssociations === null || typeof __wcInputAssociations !== 'object' || Object.getPrototypeOf(__wcInputAssociations) !== Object.prototype)
        throw new TypeError('[InstanceAssociations] expected a plain record');
      for (const key of Reflect.ownKeys(__wcInputAssociations)) if (key !== 'controlLabel')
        throw new TypeError('[InstanceAssociations] unknown association key');
      if (Object.prototype.hasOwnProperty.call(__wcInputAssociations, 'controlLabel') && Reflect.get(__wcInputAssociations, 'controlLabel') != null)
        throw new Error('[ControlLabel] this Prototype has not declared Label or target participation');
    }
  }
    this.__wcAssociations = value;

  }
  static get observedAttributes(): string[] { return ['instance-associations', 'instanceassociations']; }
  attributeChangedCallback(name: string, _previous: string | null, value: string | null): void {
    if (value !== null) throw new TypeError('[InstanceAssociations] use the instanceAssociations property, not an attribute string');
  }
  get logicalOwner(): symbol | null { return this.__wcOwner?.identity ?? null; }
  get viewEpoch(): number { return this.__wcOwner?.epoch ?? 0; }
  get present(): boolean { return this.__wcOwner?.view ?? false; }
  connectedCallback(): void {
    ++this.__wcDisconnect;
    if (this.__wcClosed) return;
    if (this.__wcOwner) {
      const owner = this.__wcOwner;
      if (!owner.view) {
        const version = this.__wcDisconnect;
        // Finish an enclosing native slot commit before retrying a retained owner.
        queueMicrotask(() => {
          if (this.__wcClosed || owner !== this.__wcOwner || version !== this.__wcDisconnect || !this.isConnected || owner.view) return;
          owner.reconcile();
        });
      }
      return;
    }
    const port = createNativeBrowserPort(this, false, undefined, __wcMarkNativeExposeEvent);
    this.__wcPort = port;
    const owner = __wcCreateOwner(port);
    this.__wcOwner = owner;
    const __wcDef = owner.def;
    const __wcWrapPublic = owner.wrapPublic;
    const __wcAuthored = owner.authored;
    const __wcDelay = owner.delay;    const __wcPresence = owner.presence;    const __wcMeta = owner.meta;
    const __wcStyle = owner.style;
    const __wcOwnerProps = owner.props;


    // Source "packages/prototypes/base/src/transition/machine.ts":42:1
    const __puiModule0 = (driver: { "getState": () => "closed" | "preparing" | "entering" | "entered" | "leaving"; "setState": (state: "closed" | "preparing" | "entering" | "entered" | "leaving") => void; "getInterrupt": () => "reverse" | "wait" | "immediate"; "requiresColdPreparation"?: () => boolean; "getCompletion"?: () => (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number })); "publishPresentation"?: (frame: { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) => void; "settlePresentation"?: (outcome: "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed") => void; "getDuration": (state: "entering" | "leaving") => number; "schedule": (durationMs: number, callback: () => void) => __wcDelayTask; "setViewPresent": (present: boolean) => void; "emit": (event: "beforeEnter" | "afterEnter" | "beforeLeave" | "afterLeave") => void }): { "initialize": (open: boolean, appear: boolean) => void; "setTarget": (open: boolean) => void; "enter": () => void; "leave": () => void; "complete": () => void; "completePresentation": (attempt: { readonly "ownerEpoch": number; readonly "phaseAttempt": number }, isCurrent?: () => boolean) => boolean; "capturePreparation": () => ((() => void) | (null)); "mounted": () => void; "unmounted": () => void; "dispose": () => void } => {
      // Source "packages/prototypes/base/src/transition/machine.ts":43:7
      let targetOpen: boolean = false;
      // Source "packages/prototypes/base/src/transition/machine.ts":44:7
      let viewMounted: boolean = false;
      // Source "packages/prototypes/base/src/transition/machine.ts":45:7
      let queuedIntent: "enter" | "leave" | null = (null as "enter" | "leave" | null);
      // Source "packages/prototypes/base/src/transition/machine.ts":46:7
      let pendingTask: ((__wcDelayTask) | (null)) = (null as ((__wcDelayTask) | (null)));
      // Source "packages/prototypes/base/src/transition/machine.ts":47:7
      let generation: number = 0;
      // Source "packages/prototypes/base/src/transition/machine.ts":48:7
      let ownerEpoch: number = 0;
      // Source "packages/prototypes/base/src/transition/machine.ts":49:7
      let phaseAttempt: number = 0;
      // Source "packages/prototypes/base/src/transition/machine.ts":50:7
      let revision: number = 0;
      // Source "packages/prototypes/base/src/transition/machine.ts":51:7
      let publishing: boolean = false;
      // Source "packages/prototypes/base/src/transition/machine.ts":52:7
      let stagedState: "closed" | "preparing" | "entering" | "entered" | "leaving" | null = (null as "closed" | "preparing" | "entering" | "entered" | "leaving" | null);
      // Source "packages/prototypes/base/src/transition/machine.ts":53:7
      let acknowledged: boolean = false;
      // Source "packages/prototypes/base/src/transition/machine.ts":54:7
      let acknowledgementCurrent: ((() => boolean) | (null)) = (null as ((() => boolean) | (null)));
      // Source "packages/prototypes/base/src/transition/machine.ts":55:7
      let invalidDuration: boolean = false;
      // Source "packages/prototypes/base/src/transition/machine.ts":56:7
      let publicationFailed: boolean = false;
      // Source "packages/prototypes/base/src/transition/machine.ts":57:7
      let activePresentation: (({ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) | (null)) = (null as (({ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) | (null)));
      // Source "packages/prototypes/base/src/transition/machine.ts":58:9
      const sameAttempt = (attempt: { readonly "ownerEpoch": number; readonly "phaseAttempt": number }): boolean => {
        // Source "packages/prototypes/base/src/transition/machine.ts":59:5
        return (((!terminal) && (((activePresentation)?.["attempt"])?.["ownerEpoch"] === (attempt)["ownerEpoch"])) && ((((activePresentation as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"])["phaseAttempt"] === (attempt)["phaseAttempt"]));
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":62:9
      const cancelTask = (): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":63:11
        const task = pendingTask;
        // Source "packages/prototypes/base/src/transition/machine.ts":64:5
        (pendingTask = null);
        // Source "packages/prototypes/base/src/transition/machine.ts":65:5
        try {
          // Source "packages/prototypes/base/src/transition/machine.ts":66:7
          ((__wcOptionalReceiver: ((__wcDelayTask) | (null))) => __wcOptionalReceiver == null ? undefined : __wcOptionalReceiver.cancel())(task);
        } catch {
        }
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":71:7
      let terminal: boolean = false;
      // Source "packages/prototypes/base/src/transition/machine.ts":72:7
      let operationVersion: number = 0;
      // Source "packages/prototypes/base/src/transition/machine.ts":73:7
      let starting: { "kind": "enter" | "leave"; "version": number } | null = (null as { "kind": "enter" | "leave"; "version": number } | null);
      // Source "packages/prototypes/base/src/transition/machine.ts":74:9
      const currentOperation = (version: number): boolean => {
        // Source "packages/prototypes/base/src/transition/machine.ts":74:49
        return ((!terminal) && (operationVersion === version));
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":75:9
      const updateTarget = (open: boolean): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":76:5
        if ((targetOpen !== open)) {
          // Source "packages/prototypes/base/src/transition/machine.ts":76:30
          (operationVersion = (operationVersion + 1));
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":77:5
        (targetOpen = open);
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":85:7
      let preparation: { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean } | null = (null as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean } | null);
      // Source "packages/prototypes/base/src/transition/machine.ts":87:9
      const cancelPreparation = (): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":88:5
        (preparation = null);
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":90:9
      const isPreparing = (attempt: { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }): boolean => {
        // Source "packages/prototypes/base/src/transition/machine.ts":91:5
        return ((((!terminal) && targetOpen) && (preparation === attempt)) && (((driver)["getState"])() === "preparing"));
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":93:9
      const finishPreparation = (attempt: { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":94:5
        if ((((((!(isPreparing)(attempt)) || (!(attempt)["presentRequested"])) || (!viewMounted)) || (!(attempt)["ready"])) || (attempt)["finishing"])) {
          // Source "packages/prototypes/base/src/transition/machine.ts":101:7
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":102:5
        ((attempt)["finishing"] = true);
        // Source "packages/prototypes/base/src/transition/machine.ts":103:5
        if ((!(attempt)["animate"])) {
          // Source "packages/prototypes/base/src/transition/machine.ts":104:7
          (preparation = null);
          // Source "packages/prototypes/base/src/transition/machine.ts":105:7
          (setState)("entered");
          // Source "packages/prototypes/base/src/transition/machine.ts":106:7
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":108:5
        ((driver)["emit"])("beforeEnter");
        // Source "packages/prototypes/base/src/transition/machine.ts":109:5
        if (((!(isPreparing)(attempt)) || (!viewMounted))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":109:48
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":110:11
        const frame = (setState)("entering");
        // Source "packages/prototypes/base/src/transition/machine.ts":111:5
        if (((((frame && (activePresentation === (frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))) && (!terminal)) && viewMounted) && (((driver)["getState"])() === "entering"))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":118:7
          if ((preparation === attempt)) {
            // Source "packages/prototypes/base/src/transition/machine.ts":118:36
            (preparation = null);
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":119:7
          (armCompletion)("entering");
          // Source "packages/prototypes/base/src/transition/machine.ts":120:7
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":122:5
        if ((((((preparation !== attempt) || terminal) || (!targetOpen)) || (!viewMounted)) || (((driver)["getState"])() !== "entering"))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":129:7
          if ((preparation === attempt)) {
            // Source "packages/prototypes/base/src/transition/machine.ts":129:36
            (preparation = null);
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":130:7
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":132:5
        (preparation = null);
        // Source "packages/prototypes/base/src/transition/machine.ts":133:5
        (armCompletion)("entering");
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":136:9
      const beginPreparation = (animate: boolean): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":137:11
        const operation = (++operationVersion);
        // Source "packages/prototypes/base/src/transition/machine.ts":138:5
        (invalidateCompletion)();
        // Source "packages/prototypes/base/src/transition/machine.ts":139:5
        if ((!((!terminal) && (operationVersion === operation)))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":139:39
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":140:5
        (queuedIntent = null);
        // Source "packages/prototypes/base/src/transition/machine.ts":141:11
        const attempt = ({ ["ready"]: false, ["finishing"]: false, ["animate"]: animate, ["presentRequested"]: false } as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean });
        // Source "packages/prototypes/base/src/transition/machine.ts":147:5
        (preparation = attempt);
        // Source "packages/prototypes/base/src/transition/machine.ts":148:5
        (setState)("preparing");
        // Source "packages/prototypes/base/src/transition/machine.ts":149:5
        if ((!(isPreparing)(attempt))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":149:32
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":150:5
        ((driver)["setViewPresent"])(true);
        // Source "packages/prototypes/base/src/transition/machine.ts":151:5
        if ((!(isPreparing)(attempt))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":151:32
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":152:5
        ((attempt)["presentRequested"] = true);
        // Source "packages/prototypes/base/src/transition/machine.ts":153:5
        (finishPreparation)(attempt);
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":156:9
      const invalidateCompletion = (): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":157:5
        (generation = (generation + 1));
        // Source "packages/prototypes/base/src/transition/machine.ts":158:5
        (activePresentation = null);
        // Source "packages/prototypes/base/src/transition/machine.ts":159:5
        (acknowledged = false);
        // Source "packages/prototypes/base/src/transition/machine.ts":160:5
        (acknowledgementCurrent = null);
        // Source "packages/prototypes/base/src/transition/machine.ts":161:5
        (cancelTask)();
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":164:9
      const setState = (state: "closed" | "preparing" | "entering" | "entered" | "leaving"): (({ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) | (undefined)) => {
        // Source "packages/prototypes/base/src/transition/machine.ts":165:11
        const policy = (((driver)["getCompletion"])?.() ?? "timer");
        // Source "packages/prototypes/base/src/transition/machine.ts":166:5
        if ((policy === "timer")) {
          // Source "packages/prototypes/base/src/transition/machine.ts":167:7
          ((driver)["setState"])(state);
          // Source "packages/prototypes/base/src/transition/machine.ts":168:7
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":170:11
        const moving = ((state === "entering") || ((state as "closed" | "preparing" | "entered" | "leaving") === "leaving"));
        // Source "packages/prototypes/base/src/transition/machine.ts":171:11
        const duration = (moving ? ((driver)["getDuration"])((state as "entering" | "leaving")) : 0);
        // Source "packages/prototypes/base/src/transition/machine.ts":172:5
        (invalidDuration = (((!Number.isFinite(duration)) || (duration < 0)) || (moving && (duration >= ((policy as { readonly "kind": "presentation"; readonly "timeoutMs": number }))["timeoutMs"]))));
        // Source "packages/prototypes/base/src/transition/machine.ts":174:5
        (publicationFailed = false);
        // Source "packages/prototypes/base/src/transition/machine.ts":175:11
        const frame = ((Object.freeze({ ["revision"]: (++revision), ["phase"]: state, ["attempt"]: (moving ? (Object.freeze({ ["ownerEpoch"]: ownerEpoch, ["phaseAttempt"]: (++phaseAttempt) }) as { "ownerEpoch": number; "phaseAttempt": number }) : null), ["completion"]: "presentation", ["durationMs"]: ((Number.isFinite(duration) && (duration >= 0)) ? duration : ((policy as { readonly "kind": "presentation"; readonly "timeoutMs": number }))["timeoutMs"]), ["timeoutMs"]: ((policy as { readonly "kind": "presentation"; readonly "timeoutMs": number }))["timeoutMs"] }) as { "revision": number; "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; "attempt": { "ownerEpoch": number; "phaseAttempt": number } | null; "completion": "presentation"; "durationMs": number | 0; "timeoutMs": number }) as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null });
        // Source "packages/prototypes/base/src/transition/machine.ts":184:5
        (activePresentation = (moving ? frame : null));
        // Source "packages/prototypes/base/src/transition/machine.ts":185:5
        (acknowledged = false);
        // Source "packages/prototypes/base/src/transition/machine.ts":186:11
        const operation = operationVersion;
        // Source "packages/prototypes/base/src/transition/machine.ts":187:11
        const previousStage = stagedState;
        // Source "packages/prototypes/base/src/transition/machine.ts":188:5
        (stagedState = state);
        // Source "packages/prototypes/base/src/transition/machine.ts":189:5
        (publishing = true);
        // Source "packages/prototypes/base/src/transition/machine.ts":190:5
        try {
          // Source "packages/prototypes/base/src/transition/machine.ts":191:7
          try {
            // Source "packages/prototypes/base/src/transition/machine.ts":192:9
            ((driver)["publishPresentation"])?.(frame);
          } catch {
            // Source "packages/prototypes/base/src/transition/machine.ts":194:9
            (publicationFailed = true);
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":196:13
          const waitingOnSameAttempt = (((moving && (activePresentation === frame)) && (((driver)["getInterrupt"])() === "wait")) && (!terminal));
          // Source "packages/prototypes/base/src/transition/machine.ts":198:7
          if ((((!((!terminal) && (operationVersion === operation))) && (!waitingOnSameAttempt)) || (moving && (activePresentation !== frame)))) {
            // Source "packages/prototypes/base/src/transition/machine.ts":204:9
            if ((((!terminal) && moving) && (activePresentation === frame))) {
              // Source "packages/prototypes/base/src/transition/machine.ts":205:17
              const repairOperation = operationVersion;
              // Source "packages/prototypes/base/src/transition/machine.ts":206:11
              (invalidateCompletion)();
              // Source "packages/prototypes/base/src/transition/machine.ts":207:11
              if ((!((!terminal) && (operationVersion === repairOperation)))) {
                // Source "packages/prototypes/base/src/transition/machine.ts":207:51
                return;
              }
              // Source "packages/prototypes/base/src/transition/machine.ts":208:17
              const actual = ((driver)["getState"])();
              // Source "packages/prototypes/base/src/transition/machine.ts":209:17
              const repaired = (setState)(actual);
              // Source "packages/prototypes/base/src/transition/machine.ts":210:11
              if (((repaired && (activePresentation === (repaired as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))) && ((actual === "entering") || ((actual as "closed" | "preparing" | "entered" | "leaving") === "leaving")))) {
                // Source "packages/prototypes/base/src/transition/machine.ts":215:13
                (armCompletion)((actual as "entering" | "leaving"));
              }
            }
            // Source "packages/prototypes/base/src/transition/machine.ts":217:9
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":219:7
          ((driver)["setState"])(state);
        } finally {
          // Source "packages/prototypes/base/src/transition/machine.ts":221:7
          (stagedState = previousStage);
          // Source "packages/prototypes/base/src/transition/machine.ts":222:7
          (publishing = (previousStage !== null));
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":224:5
        if (((((((((moving && acknowledged) && (activePresentation === frame)) && (!terminal)) && (((driver)["getState"])() === state)) && (acknowledgementCurrent)?.()) && ((activePresentation as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) === frame)) && (!terminal)) && (((driver)["getState"])() === state))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":235:7
          (completeCurrent)(true);
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":236:5
        return frame;
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":239:9
      const settlePresentation = (frame: { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }, outcome: "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed"): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":240:5
        if (((!(frame)["attempt"]) || (!(sameAttempt)(((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"])))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":240:56
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":241:5
        try {
          // Source "packages/prototypes/base/src/transition/machine.ts":242:7
          ((driver)["settlePresentation"])?.(outcome);
        } catch {
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":246:5
        if ((sameAttempt)(((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"])) {
          // Source "packages/prototypes/base/src/transition/machine.ts":246:37
          (completeCurrent)(true);
        }
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":249:9
      const armCompletion = (state: "entering" | "leaving"): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":250:11
        const frame = activePresentation;
        // Source "packages/prototypes/base/src/transition/machine.ts":251:5
        if ((frame)?.["attempt"]) {
          // Source "packages/prototypes/base/src/transition/machine.ts":252:7
          if (invalidDuration) {
            // Source "packages/prototypes/base/src/transition/machine.ts":253:9
            (settlePresentation)((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }), "invalid-policy");
            // Source "packages/prototypes/base/src/transition/machine.ts":254:9
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":256:7
          if (publicationFailed) {
            // Source "packages/prototypes/base/src/transition/machine.ts":257:9
            (settlePresentation)((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }), "projection-failed");
            // Source "packages/prototypes/base/src/transition/machine.ts":258:9
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":260:7
          if ((((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["durationMs"] === 0)) {
            // Source "packages/prototypes/base/src/transition/machine.ts":261:9
            (settlePresentation)((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": 0; readonly "timeoutMs": number | null }), "zero-duration");
            // Source "packages/prototypes/base/src/transition/machine.ts":262:9
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":264:7
          try {
            // Source "packages/prototypes/base/src/transition/machine.ts":265:15
            const task = ((driver)["schedule"])((((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["timeoutMs"] as number), (): void => {
              // Source "packages/prototypes/base/src/transition/machine.ts":266:11
              if (((!((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"]) || (!(sameAttempt)(((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"])))) {
                // Source "packages/prototypes/base/src/transition/machine.ts":266:62
                return;
              }
              // Source "packages/prototypes/base/src/transition/machine.ts":267:11
              (pendingTask = null);
              // Source "packages/prototypes/base/src/transition/machine.ts":268:11
              (settlePresentation)((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }), "deadline");
            });
            // Source "packages/prototypes/base/src/transition/machine.ts":270:9
            if ((sameAttempt)(((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"])) {
              // Source "packages/prototypes/base/src/transition/machine.ts":270:41
              (pendingTask = task);
            } else {
              // Source "packages/prototypes/base/src/transition/machine.ts":272:11
              try {
                // Source "packages/prototypes/base/src/transition/machine.ts":273:13
                task.cancel();
              } catch {
              }
            }
          } catch {
            // Source "packages/prototypes/base/src/transition/machine.ts":277:9
            (settlePresentation)((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }), "scheduler-failed");
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":279:7
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":281:5
        (invalidateCompletion)();
        // Source "packages/prototypes/base/src/transition/machine.ts":282:11
        const activeGeneration = generation;
        // Source "packages/prototypes/base/src/transition/machine.ts":283:5
        (pendingTask = ((driver)["schedule"])(((driver)["getDuration"])(state), (): void => {
          // Source "packages/prototypes/base/src/transition/machine.ts":284:7
          if (((activeGeneration !== generation) || (((driver)["getState"])() !== state))) {
            // Source "packages/prototypes/base/src/transition/machine.ts":284:75
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":285:7
          (pendingTask = null);
          // Source "packages/prototypes/base/src/transition/machine.ts":286:7
          (completeCurrent)(true);
        }));
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":290:9
      const beginEnter = (cold: boolean = true): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":291:5
        if ((terminal || (!targetOpen))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":291:34
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":292:5
        if ((((starting)?.["kind"] === "enter") && (currentOperation)(((starting as { "kind": "enter"; "version": number }))["version"]))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":292:75
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":293:5
        if ((cold && ((driver)["requiresColdPreparation"])?.())) {
          // Source "packages/prototypes/base/src/transition/machine.ts":294:7
          (beginPreparation)(true);
          // Source "packages/prototypes/base/src/transition/machine.ts":295:7
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":297:11
        const operation: { "kind": "enter"; "version": number } = { ["kind"]: "enter", ["version"]: (++operationVersion) };
        // Source "packages/prototypes/base/src/transition/machine.ts":298:5
        (starting = operation);
        // Source "packages/prototypes/base/src/transition/machine.ts":299:11
        const current = (): boolean => {
          // Source "packages/prototypes/base/src/transition/machine.ts":299:27
          return ((currentOperation)((operation)["version"]) && targetOpen);
        };
        // Source "packages/prototypes/base/src/transition/machine.ts":300:5
        try {
          // Source "packages/prototypes/base/src/transition/machine.ts":301:7
          ((driver)["setViewPresent"])(true);
          // Source "packages/prototypes/base/src/transition/machine.ts":302:7
          if (((!(current)()) || (!viewMounted))) {
            // Source "packages/prototypes/base/src/transition/machine.ts":302:39
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":303:7
          (queuedIntent = null);
          // Source "packages/prototypes/base/src/transition/machine.ts":304:7
          ((driver)["emit"])("beforeEnter");
          // Source "packages/prototypes/base/src/transition/machine.ts":305:7
          if (((!(current)()) || (!viewMounted))) {
            // Source "packages/prototypes/base/src/transition/machine.ts":305:39
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":306:7
          (invalidateCompletion)();
          // Source "packages/prototypes/base/src/transition/machine.ts":307:7
          if ((!(current)())) {
            // Source "packages/prototypes/base/src/transition/machine.ts":307:23
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":308:13
          const frame = (setState)("entering");
          // Source "packages/prototypes/base/src/transition/machine.ts":309:7
          if ((((((frame && (activePresentation === (frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))) && (((activePresentation as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))?.["phase"] === "entering")) && (!terminal)) && viewMounted) && (((driver)["getState"])() === "entering"))) {
            // Source "packages/prototypes/base/src/transition/machine.ts":317:9
            (armCompletion)("entering");
            // Source "packages/prototypes/base/src/transition/machine.ts":318:9
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":320:7
          if ((((!(current)()) || (!viewMounted)) || (((driver)["getState"])() !== "entering"))) {
            // Source "packages/prototypes/base/src/transition/machine.ts":320:75
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":321:7
          (armCompletion)("entering");
        } finally {
          // Source "packages/prototypes/base/src/transition/machine.ts":323:7
          if ((starting === operation)) {
            // Source "packages/prototypes/base/src/transition/machine.ts":323:35
            (starting = null);
          }
        }
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":327:9
      const beginLeave = (): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":328:5
        if ((terminal || targetOpen)) {
          // Source "packages/prototypes/base/src/transition/machine.ts":328:33
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":329:11
        const operation: { "kind": "leave"; "version": number } = { ["kind"]: "leave", ["version"]: (++operationVersion) };
        // Source "packages/prototypes/base/src/transition/machine.ts":330:5
        (starting = operation);
        // Source "packages/prototypes/base/src/transition/machine.ts":331:11
        const current = (): boolean => {
          // Source "packages/prototypes/base/src/transition/machine.ts":331:27
          return ((currentOperation)((operation)["version"]) && (!targetOpen));
        };
        // Source "packages/prototypes/base/src/transition/machine.ts":332:5
        try {
          // Source "packages/prototypes/base/src/transition/machine.ts":333:7
          (queuedIntent = null);
          // Source "packages/prototypes/base/src/transition/machine.ts":334:7
          ((driver)["emit"])("beforeLeave");
          // Source "packages/prototypes/base/src/transition/machine.ts":335:7
          if ((!(current)())) {
            // Source "packages/prototypes/base/src/transition/machine.ts":335:23
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":336:7
          (invalidateCompletion)();
          // Source "packages/prototypes/base/src/transition/machine.ts":337:7
          if ((!(current)())) {
            // Source "packages/prototypes/base/src/transition/machine.ts":337:23
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":338:13
          const frame = (setState)("leaving");
          // Source "packages/prototypes/base/src/transition/machine.ts":339:7
          if (((((frame && (activePresentation === (frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))) && (((activePresentation as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))?.["phase"] === "leaving")) && (!terminal)) && (((driver)["getState"])() === "leaving"))) {
            // Source "packages/prototypes/base/src/transition/machine.ts":346:9
            (armCompletion)("leaving");
            // Source "packages/prototypes/base/src/transition/machine.ts":347:9
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":349:7
          if (((!(current)()) || (((driver)["getState"])() !== "leaving"))) {
            // Source "packages/prototypes/base/src/transition/machine.ts":349:58
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":350:7
          (armCompletion)("leaving");
        } finally {
          // Source "packages/prototypes/base/src/transition/machine.ts":352:7
          if ((starting === operation)) {
            // Source "packages/prototypes/base/src/transition/machine.ts":352:35
            (starting = null);
          }
        }
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":356:9
      const consumeQueuedIntent = (): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":357:11
        const next = queuedIntent;
        // Source "packages/prototypes/base/src/transition/machine.ts":358:5
        (queuedIntent = null);
        // Source "packages/prototypes/base/src/transition/machine.ts":359:5
        if ((next === "enter")) {
          // Source "packages/prototypes/base/src/transition/machine.ts":359:27
          (enter)();
        } else {
          // Source "packages/prototypes/base/src/transition/machine.ts":360:10
          if (((next as "leave" | null) === "leave")) {
            // Source "packages/prototypes/base/src/transition/machine.ts":360:32
            (leave)();
          }
        }
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":363:9
      const completeCurrent = (consumeQueue: boolean): boolean => {
        // Source "packages/prototypes/base/src/transition/machine.ts":364:11
        const current = ((driver)["getState"])();
        // Source "packages/prototypes/base/src/transition/machine.ts":365:5
        if (((current !== "entering") && ((current as "closed" | "preparing" | "entered" | "leaving") !== "leaving"))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":365:58
          return false;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":366:11
        const operation = (++operationVersion);
        // Source "packages/prototypes/base/src/transition/machine.ts":367:5
        (invalidateCompletion)();
        // Source "packages/prototypes/base/src/transition/machine.ts":368:5
        if ((!((!terminal) && (operationVersion === operation)))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":368:39
          return false;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":370:5
        if (((current as "entering" | "leaving") === "entering")) {
          // Source "packages/prototypes/base/src/transition/machine.ts":371:7
          (setState)("entered");
          // Source "packages/prototypes/base/src/transition/machine.ts":372:7
          if (((!((!terminal) && (operationVersion === operation))) || (((driver)["getState"])() !== "entered"))) {
            // Source "packages/prototypes/base/src/transition/machine.ts":372:76
            return false;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":373:7
          ((driver)["emit"])("afterEnter");
        } else {
          // Source "packages/prototypes/base/src/transition/machine.ts":375:7
          (setState)("closed");
          // Source "packages/prototypes/base/src/transition/machine.ts":376:7
          if (((!((!terminal) && (operationVersion === operation))) || (((driver)["getState"])() !== "closed"))) {
            // Source "packages/prototypes/base/src/transition/machine.ts":376:75
            return false;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":377:7
          ((driver)["emit"])("afterLeave");
          // Source "packages/prototypes/base/src/transition/machine.ts":378:7
          if (((!((!terminal) && (operationVersion === operation))) || (((driver)["getState"])() !== "closed"))) {
            // Source "packages/prototypes/base/src/transition/machine.ts":378:75
            return false;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":379:7
          ((driver)["setViewPresent"])(false);
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":382:5
        if ((consumeQueue && ((!terminal) && (operationVersion === operation)))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":382:54
          (consumeQueuedIntent)();
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":383:5
        return ((!terminal) && (operationVersion === operation));
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":386:9
      const enter = (): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":387:5
        if (terminal) {
          // Source "packages/prototypes/base/src/transition/machine.ts":387:19
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":388:5
        (updateTarget)(true);
        // Source "packages/prototypes/base/src/transition/machine.ts":389:5
        if ((((starting)?.["kind"] === "enter") && (currentOperation)(((starting as { "kind": "enter"; "version": number }))["version"]))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":389:75
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":390:11
        const current = (stagedState ?? ((driver)["getState"])());
        // Source "packages/prototypes/base/src/transition/machine.ts":391:5
        if (((current === "entered") || ((current as "closed" | "preparing" | "entering" | "leaving") === "preparing"))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":391:59
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":393:5
        if (((current as "closed" | "entering" | "leaving") === "closed")) {
          // Source "packages/prototypes/base/src/transition/machine.ts":394:7
          (beginEnter)();
          // Source "packages/prototypes/base/src/transition/machine.ts":395:7
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":398:5
        if (((current as "entering" | "leaving") === "entering")) {
          // Source "packages/prototypes/base/src/transition/machine.ts":399:7
          if (((((((starting as { "kind": "leave"; "version": number } | null | { "kind": "enter"; "version": number }))?.["kind"] === "leave") && (!activePresentation)) && (((driver)["getCompletion"])?.() !== "timer")) && (driver)["getCompletion"])) {
            // Source "packages/prototypes/base/src/transition/machine.ts":405:9
            (beginEnter)(false);
            // Source "packages/prototypes/base/src/transition/machine.ts":406:9
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":408:7
          if ((((driver)["getInterrupt"])() === "wait")) {
            // Source "packages/prototypes/base/src/transition/machine.ts":408:45
            (queuedIntent = null);
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":409:7
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":412:11
        const interrupt = ((driver)["getInterrupt"])();
        // Source "packages/prototypes/base/src/transition/machine.ts":413:5
        if ((interrupt === "wait")) {
          // Source "packages/prototypes/base/src/transition/machine.ts":414:7
          (queuedIntent = "enter");
        } else {
          // Source "packages/prototypes/base/src/transition/machine.ts":415:12
          if (((interrupt as "reverse" | "immediate") === "immediate")) {
            // Source "packages/prototypes/base/src/transition/machine.ts":416:7
            if ((completeCurrent)(false)) {
              // Source "packages/prototypes/base/src/transition/machine.ts":416:35
              (beginEnter)(false);
            }
          } else {
            // Source "packages/prototypes/base/src/transition/machine.ts":418:7
            (beginEnter)(false);
          }
        }
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":422:9
      const leave = (): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":423:5
        if (terminal) {
          // Source "packages/prototypes/base/src/transition/machine.ts":423:19
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":424:5
        (updateTarget)(false);
        // Source "packages/prototypes/base/src/transition/machine.ts":425:5
        if ((((starting)?.["kind"] === "leave") && (currentOperation)(((starting as { "kind": "leave"; "version": number }))["version"]))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":425:75
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":426:11
        const current = (stagedState ?? ((driver)["getState"])());
        // Source "packages/prototypes/base/src/transition/machine.ts":427:5
        if ((current === "preparing")) {
          // Source "packages/prototypes/base/src/transition/machine.ts":428:7
          (cancelPreparation)();
          // Source "packages/prototypes/base/src/transition/machine.ts":429:7
          (invalidateCompletion)();
          // Source "packages/prototypes/base/src/transition/machine.ts":430:7
          (queuedIntent = null);
          // Source "packages/prototypes/base/src/transition/machine.ts":431:7
          (setState)("closed");
          // Source "packages/prototypes/base/src/transition/machine.ts":432:7
          if (((!targetOpen) && (((driver)["getState"])() === "closed"))) {
            // Source "packages/prototypes/base/src/transition/machine.ts":432:58
            ((driver)["setViewPresent"])(false);
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":433:7
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":436:5
        if (((current as "closed" | "entering" | "entered" | "leaving") === "closed")) {
          // Source "packages/prototypes/base/src/transition/machine.ts":437:7
          ((driver)["setViewPresent"])(false);
          // Source "packages/prototypes/base/src/transition/machine.ts":438:7
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":441:5
        if (((current as "entering" | "entered" | "leaving") === "leaving")) {
          // Source "packages/prototypes/base/src/transition/machine.ts":442:7
          if (((((((starting as { "kind": "enter"; "version": number } | null | { "kind": "leave"; "version": number }))?.["kind"] === "enter") && (!activePresentation)) && (((driver)["getCompletion"])?.() !== "timer")) && (driver)["getCompletion"])) {
            // Source "packages/prototypes/base/src/transition/machine.ts":448:9
            (beginLeave)();
            // Source "packages/prototypes/base/src/transition/machine.ts":449:9
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":451:7
          if ((((driver)["getInterrupt"])() === "wait")) {
            // Source "packages/prototypes/base/src/transition/machine.ts":451:45
            (queuedIntent = null);
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":452:7
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":455:5
        if (((current as "entering" | "entered") === "entered")) {
          // Source "packages/prototypes/base/src/transition/machine.ts":456:7
          (beginLeave)();
          // Source "packages/prototypes/base/src/transition/machine.ts":457:7
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":460:11
        const interrupt = ((driver)["getInterrupt"])();
        // Source "packages/prototypes/base/src/transition/machine.ts":461:5
        if ((interrupt === "wait")) {
          // Source "packages/prototypes/base/src/transition/machine.ts":462:7
          (queuedIntent = "leave");
        } else {
          // Source "packages/prototypes/base/src/transition/machine.ts":463:12
          if (((interrupt as "reverse" | "immediate") === "immediate")) {
            // Source "packages/prototypes/base/src/transition/machine.ts":464:7
            if ((completeCurrent)(false)) {
              // Source "packages/prototypes/base/src/transition/machine.ts":464:35
              (beginLeave)();
            }
          } else {
            // Source "packages/prototypes/base/src/transition/machine.ts":466:7
            (beginLeave)();
          }
        }
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":470:9
      const initialize = (open: boolean, appear: boolean): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":471:5
        if (terminal) {
          // Source "packages/prototypes/base/src/transition/machine.ts":471:19
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":472:11
        const operation = (++operationVersion);
        // Source "packages/prototypes/base/src/transition/machine.ts":473:5
        (ownerEpoch = (ownerEpoch + 1));
        // Source "packages/prototypes/base/src/transition/machine.ts":474:5
        (cancelPreparation)();
        // Source "packages/prototypes/base/src/transition/machine.ts":475:5
        (targetOpen = open);
        // Source "packages/prototypes/base/src/transition/machine.ts":476:5
        (queuedIntent = null);
        // Source "packages/prototypes/base/src/transition/machine.ts":477:5
        (invalidateCompletion)();
        // Source "packages/prototypes/base/src/transition/machine.ts":478:5
        if ((!((!terminal) && (operationVersion === operation)))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":478:39
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":480:5
        if ((!open)) {
          // Source "packages/prototypes/base/src/transition/machine.ts":481:7
          (setState)("closed");
          // Source "packages/prototypes/base/src/transition/machine.ts":482:7
          if (((!((!terminal) && (operationVersion === operation))) || targetOpen)) {
            // Source "packages/prototypes/base/src/transition/machine.ts":482:55
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":483:7
          ((driver)["setViewPresent"])(false);
          // Source "packages/prototypes/base/src/transition/machine.ts":484:7
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":487:5
        if (((driver)["requiresColdPreparation"])?.()) {
          // Source "packages/prototypes/base/src/transition/machine.ts":488:7
          (beginPreparation)(appear);
          // Source "packages/prototypes/base/src/transition/machine.ts":489:7
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":491:5
        ((driver)["setViewPresent"])(true);
        // Source "packages/prototypes/base/src/transition/machine.ts":492:5
        if (((!((!terminal) && (operationVersion === operation))) || (!targetOpen))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":492:54
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":493:5
        if ((!appear)) {
          // Source "packages/prototypes/base/src/transition/machine.ts":493:18
          (setState)("entered");
        }
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":496:9
      const mounted = (): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":497:5
        if (terminal) {
          // Source "packages/prototypes/base/src/transition/machine.ts":497:19
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":498:5
        (viewMounted = true);
        // Source "packages/prototypes/base/src/transition/machine.ts":499:5
        if (preparation) {
          // Source "packages/prototypes/base/src/transition/machine.ts":500:7
          (finishPreparation)((preparation as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }));
          // Source "packages/prototypes/base/src/transition/machine.ts":501:7
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":503:5
        if ((targetOpen && (((driver)["getState"])() === "closed"))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":503:55
          (beginEnter)();
        }
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":506:9
      const unmounted = (): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":507:5
        (ownerEpoch = (ownerEpoch + 1));
        // Source "packages/prototypes/base/src/transition/machine.ts":508:11
        const operation = (++operationVersion);
        // Source "packages/prototypes/base/src/transition/machine.ts":509:5
        (cancelPreparation)();
        // Source "packages/prototypes/base/src/transition/machine.ts":510:5
        (viewMounted = false);
        // Source "packages/prototypes/base/src/transition/machine.ts":511:5
        (invalidateCompletion)();
        // Source "packages/prototypes/base/src/transition/machine.ts":512:5
        if ((!((!terminal) && (operationVersion === operation)))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":512:39
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":513:5
        (queuedIntent = null);
        // Source "packages/prototypes/base/src/transition/machine.ts":514:5
        if ((((driver)["getState"])() !== "closed")) {
          // Source "packages/prototypes/base/src/transition/machine.ts":514:41
          (setState)("closed");
        }
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":517:9
      const dispose = (): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":518:5
        (terminal = true);
        // Source "packages/prototypes/base/src/transition/machine.ts":519:5
        (ownerEpoch = (ownerEpoch + 1));
        // Source "packages/prototypes/base/src/transition/machine.ts":520:5
        (operationVersion = (operationVersion + 1));
        // Source "packages/prototypes/base/src/transition/machine.ts":521:5
        (cancelPreparation)();
        // Source "packages/prototypes/base/src/transition/machine.ts":522:5
        (viewMounted = false);
        // Source "packages/prototypes/base/src/transition/machine.ts":523:5
        (queuedIntent = null);
        // Source "packages/prototypes/base/src/transition/machine.ts":524:5
        (invalidateCompletion)();
      };
      // Source "packages/prototypes/base/src/transition/machine.ts":527:3
      return { ["initialize"]: initialize, ["setTarget"]: (open: boolean): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":530:7
        if (terminal) {
          // Source "packages/prototypes/base/src/transition/machine.ts":530:21
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":531:7
        if ((open === targetOpen)) {
          // Source "packages/prototypes/base/src/transition/machine.ts":531:32
          return;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":532:7
        if (open) {
          // Source "packages/prototypes/base/src/transition/machine.ts":532:17
          (enter)();
        } else {
          // Source "packages/prototypes/base/src/transition/machine.ts":533:12
          (leave)();
        }
      }, ["enter"]: enter, ["leave"]: leave, ["complete"]: (): void => {
        // Source "packages/prototypes/base/src/transition/machine.ts":538:7
        if ((!terminal)) {
          // Source "packages/prototypes/base/src/transition/machine.ts":538:22
          (completeCurrent)(true);
        }
      }, ["completePresentation"]: (attempt: { readonly "ownerEpoch": number; readonly "phaseAttempt": number }, isCurrent: () => boolean = (): boolean => {
        // Source "packages/prototypes/base/src/transition/machine.ts":540:55
        return true;
      }): boolean => {
        // Source "packages/prototypes/base/src/transition/machine.ts":541:13
        const validate = (): boolean => {
          // Source "packages/prototypes/base/src/transition/machine.ts":542:9
          try {
            // Source "packages/prototypes/base/src/transition/machine.ts":543:11
            return (isCurrent)();
          } catch {
            // Source "packages/prototypes/base/src/transition/machine.ts":545:11
            return false;
          }
        };
        // Source "packages/prototypes/base/src/transition/machine.ts":548:7
        if ((((!(sameAttempt)(attempt)) || (!(validate)())) || (!(sameAttempt)(attempt)))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":548:74
          return false;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":549:7
        if (publishing) {
          // Source "packages/prototypes/base/src/transition/machine.ts":550:9
          (acknowledged = true);
          // Source "packages/prototypes/base/src/transition/machine.ts":551:9
          (acknowledgementCurrent = validate);
          // Source "packages/prototypes/base/src/transition/machine.ts":552:9
          return true;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":554:7
        return (completeCurrent)(true);
      }, ["capturePreparation"]: (): ((() => void) | (null)) => {
        // Source "packages/prototypes/base/src/transition/machine.ts":557:13
        const attempt = preparation;
        // Source "packages/prototypes/base/src/transition/machine.ts":558:7
        if (((!attempt) || (!(isPreparing)((attempt as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }))))) {
          // Source "packages/prototypes/base/src/transition/machine.ts":558:46
          return null;
        }
        // Source "packages/prototypes/base/src/transition/machine.ts":559:7
        return (): void => {
          // Source "packages/prototypes/base/src/transition/machine.ts":560:9
          if (((!(isPreparing)((attempt as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }))) || ((attempt as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }))["finishing"])) {
            // Source "packages/prototypes/base/src/transition/machine.ts":560:57
            return;
          }
          // Source "packages/prototypes/base/src/transition/machine.ts":561:9
          (((attempt as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }))["ready"] = true);
          // Source "packages/prototypes/base/src/transition/machine.ts":562:9
          (finishPreparation)((attempt as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }));
        };
      }, ["mounted"]: mounted, ["unmounted"]: unmounted, ["dispose"]: dispose };
    };
    const __wcHook0 = (options?: unknown) => (__wcAuthored.install({name: "asTransition", mode: "once", setup: (options, api) => ((def: __wcDef) => {
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":42:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0: Parameters<typeof __wcCaptureReceiver.props.define>[0] = { ["open"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["defaultOpen"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["appear"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["enterDuration"]: { ["type"]: "number", ["empty"]: "fallback" }, ["leaveDuration"]: { ["type"]: "number", ["empty"]: "fallback" }, ["interrupt"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["reverse", "wait", "immediate"] } };
const __wcCaptureResult = __wcCaptureReceiver.props.define(__wcCaptureArg0); __wcAuthored.effect("props", {"op": "define", "specMap": __wcCaptureArg0}); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":54:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = { ["defaultOpen"]: false, ["appear"]: false, ["enterDuration"]: 300, ["leaveDuration"]: 200, ["interrupt"]: "reverse" };
const __wcCaptureResult = __wcCaptureReceiver.props.setDefaults(__wcCaptureArg0); __wcAuthored.effect("props", {"op": "setDefaults", "partial": __wcCaptureArg0}); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":62:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "beforeEnter";
const __wcCaptureArg1 = { ["payload"]: "void" };
const __wcCaptureResult = __wcCaptureReceiver.expose.event(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("event", {"op": "expose.event", "key": __wcCaptureArg0, "spec": __wcCaptureArg1}); __wcAuthored.eventKey(__wcCaptureArg0); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":63:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "afterEnter";
const __wcCaptureArg1 = { ["payload"]: "void" };
const __wcCaptureResult = __wcCaptureReceiver.expose.event(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("event", {"op": "expose.event", "key": __wcCaptureArg0, "spec": __wcCaptureArg1}); __wcAuthored.eventKey(__wcCaptureArg0); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":64:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "beforeLeave";
const __wcCaptureArg1 = { ["payload"]: "void" };
const __wcCaptureResult = __wcCaptureReceiver.expose.event(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("event", {"op": "expose.event", "key": __wcCaptureArg0, "spec": __wcCaptureArg1}); __wcAuthored.eventKey(__wcCaptureArg0); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":65:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "afterLeave";
const __wcCaptureArg1 = { ["payload"]: "void" };
const __wcCaptureResult = __wcCaptureReceiver.expose.event(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("event", {"op": "expose.event", "key": __wcCaptureArg0, "spec": __wcCaptureArg1}); __wcAuthored.eventKey(__wcCaptureArg0); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":67:11
      const transitionState = (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "transitionState";
const __wcCaptureArg1 = "closed";
const __wcCaptureArg2 = { ["options"]: ["closed", "preparing", "entering", "entered", "leaving"] };
const __wcCaptureResult = __wcCaptureReceiver.state.enum(__wcCaptureArg0, __wcCaptureArg1, __wcCaptureArg2); __wcAuthored.effect("state", __wcCaptureResult); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":72:11
      const isPresent = (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "isPresent";
const __wcCaptureArg1 = false;
const __wcCaptureResult = __wcCaptureReceiver.state.bool(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("state", __wcCaptureResult); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":73:11
      const appearDefault = (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "transitionAppearDefault";
const __wcCaptureArg1 = false;
const __wcCaptureResult = __wcCaptureReceiver.state.bool(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("state", __wcCaptureResult); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":74:11
      const coldEntryPreparation = (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "transitionColdEntryPreparation";
const __wcCaptureArg1 = false;
const __wcCaptureResult = __wcCaptureReceiver.state.bool(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("state", __wcCaptureResult); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":75:11
      const enterDurationDefault = (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "transitionEnterDurationDefault";
const __wcCaptureArg1 = 300;
const __wcCaptureResult = __wcCaptureReceiver.state.numberDiscrete(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("state", __wcCaptureResult); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":76:11
      const leaveDurationDefault = (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "transitionLeaveDurationDefault";
const __wcCaptureArg1 = 200;
const __wcCaptureResult = __wcCaptureReceiver.state.numberDiscrete(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("state", __wcCaptureResult); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":77:11
      const interruptDefault = (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "transitionInterruptDefault";
const __wcCaptureArg1 = "reverse";
const __wcCaptureArg2 = { ["options"]: ["reverse", "wait", "immediate"] };
const __wcCaptureResult = __wcCaptureReceiver.state.enum(__wcCaptureArg0, __wcCaptureArg1, __wcCaptureArg2); __wcAuthored.effect("state", __wcCaptureResult); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":83:9
      let initialOpenSource: (({ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) | (null)) = (null as (({ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) | (null)));
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":85:9
      let openContextSource: (({ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) | (null)) = (null as (({ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) | (null)));
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":87:11
      const closedViewRetained = (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "transitionClosedViewRetained";
const __wcCaptureArg1 = false;
const __wcCaptureResult = __wcCaptureReceiver.state.bool(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("state", __wcCaptureResult); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":88:11
      const bindInitialOpen = (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }): void => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":90:7
        appearDefault.setDefault((appearDefault.get() as boolean));
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":91:7
        if ((((((!source) || ((typeof (source)["field"]) !== "string")) || (!(source)["field"])) || (!(source)["context"])) || (((source)["context"])["__brand"] !== "ContextKey"))) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":98:9
          throw new Error("[asTransition] initial open source requires a ContextKey and direct field.");
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":102:7
        if (initialOpenSource) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":103:9
          if (((((initialOpenSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["context"] === (source)["context"]) && (((initialOpenSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["field"] === (source)["field"]))) {
            // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":107:11
            return;
          }
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":108:9
          throw new Error("[asTransition] initial open source is already bound.");
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":110:7
        (initialOpenSource = (Object.freeze({ ["context"]: (source)["context"], ["field"]: (source)["field"] }) as { "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; "field": string }));
      };
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":112:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "bindInitialOpen";
const __wcCaptureArg1 = bindInitialOpen;
const __wcCaptureResult = __wcCaptureReceiver.expose.method(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("context", {"op": "expose.method", "key": __wcCaptureArg0, "fn": __wcCaptureArg1}); __wcAuthored.method(__wcCaptureArg0, __wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":114:11
      const presentation = (void (def), __wcPresence.owner());
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":115:9
      let completion: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number })) = ("timer" as (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number })));
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":116:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "getPresentationOwner";
const __wcCaptureArg1 = (): Readonly<object> => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":116:53
        return (presentation)["ref"];
      };
const __wcCaptureResult = __wcCaptureReceiver.expose.method(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("context", {"op": "expose.method", "key": __wcCaptureArg0, "fn": __wcCaptureArg1}); __wcAuthored.method(__wcCaptureArg0, __wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":117:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "configurePresentation";
const __wcCaptureArg1 = (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }): void => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":118:7
        appearDefault.setDefault((appearDefault.get() as boolean));
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":119:13
        const policy = __wcSnapshotCompletion(((config)["completion"] ?? completion));
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":120:13
        const enter = ((config)["enterDuration"] ?? (enterDurationDefault.get() as number));
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":121:13
        const leave = ((config)["leaveDuration"] ?? (leaveDurationDefault.get() as number));
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":122:7
        if ((!([enter, leave]).every((value: number): boolean => {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":122:44
          return (Number.isFinite(value) && (value >= 0));
        }))) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":123:9
          throw new Error("[asTransition] durations must be finite non-negative numbers.");
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":124:7
        if (((policy !== "timer") && ((enter >= ((policy as { readonly "kind": "presentation"; readonly "timeoutMs": number }))["timeoutMs"]) || (leave >= ((policy as { readonly "kind": "presentation"; readonly "timeoutMs": number }))["timeoutMs"])))) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":125:9
          throw new Error("[asTransition] presentation duration must be shorter than timeoutMs.");
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":126:7
        (completion = policy);
      };
const __wcCaptureResult = __wcCaptureReceiver.expose.method(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("context", {"op": "expose.method", "key": __wcCaptureArg0, "fn": __wcCaptureArg1}); __wcAuthored.method(__wcCaptureArg0, __wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":128:9
      let currentRun: ((__wcRun) | (null)) = (null as ((__wcRun) | (null)));
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":132:9
      let phaseViewRequested: boolean = false;
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":133:11
      const getProps = (): ((__wcPropsSnapshot) | (undefined)) => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":133:28
        return ((__wcOptionalReceiver: ((__wcRun) | (null))) => __wcOptionalReceiver == null ? undefined : __wcOptionalReceiver.props.get())(currentRun);
      };
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":135:11
      const driver = ({ ["getState"]: (): "closed" | "preparing" | "entering" | "entered" | "leaving" => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":136:23
        return (transitionState.get() as "closed" | "preparing" | "entering" | "entered" | "leaving");
      }, ["setState"]: (state: "closed" | "preparing" | "entering" | "entered" | "leaving"): void => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":138:9
        transitionState.set(state, ("reason: asTransition => " + state));
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":140:9
        if ((!currentRun)) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":140:26
          return;
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":142:15
        const currentState = (transitionState.get() as "closed" | "preparing" | "entering" | "entered" | "leaving");
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":143:9
        isPresent.set((currentState !== "closed"), ("reason: asTransition presence => " + currentState));
      }, ["requiresColdPreparation"]: (): boolean => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":148:38
        return (coldEntryPreparation.get() as boolean);
      }, ["getCompletion"]: (): (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number })) => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":149:28
        return completion;
      }, ["publishPresentation"]: (frame: { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }): void => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":151:9
        return ((__wcOptionalReceiver: ((__wcRun) | (null))) => __wcOptionalReceiver == null ? undefined : (void (__wcOptionalReceiver), __wcPresence.publish((presentation)["writer"], ({ ...(frame), ["owner"]: (presentation)["ref"] }))))(currentRun);
      }, ["settlePresentation"]: (outcome: "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed"): void => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":156:9
        return ((__wcOptionalReceiver: ((__wcRun) | (null))) => __wcOptionalReceiver == null ? undefined : (void (__wcOptionalReceiver), __wcPresence.settle((presentation)["writer"], outcome)))(currentRun);
      }, ["getInterrupt"]: (): "reverse" | "wait" | "immediate" => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":158:9
        return (((__wcOptionalReceiver: ((__wcRun) | (null))) => __wcOptionalReceiver == null ? undefined : __wcOptionalReceiver.props.isProvided("interrupt"))(currentRun) ? (((getProps)())?.["interrupt"] ?? (interruptDefault.get() as "reverse" | "wait" | "immediate")) : (interruptDefault.get() as "reverse" | "wait" | "immediate"));
      }, ["getDuration"]: (state: "entering" | "leaving"): number => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":165:9
        if ((((__wcOptionalReceiver: ((__wcRun) | (null))) => __wcOptionalReceiver == null ? undefined : (void (__wcOptionalReceiver), __wcMeta("reducedMotion")))(currentRun) === "reduce")) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":165:66
          return 0;
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":166:9
        return ((state === "entering") ? (((__wcOptionalReceiver: ((__wcRun) | (null))) => __wcOptionalReceiver == null ? undefined : __wcOptionalReceiver.props.isProvided("enterDuration"))(currentRun) ? (((getProps)())?.["enterDuration"] ?? (enterDurationDefault.get() as number)) : (enterDurationDefault.get() as number)) : (((__wcOptionalReceiver: ((__wcRun) | (null))) => __wcOptionalReceiver == null ? undefined : __wcOptionalReceiver.props.isProvided("leaveDuration"))(currentRun) ? (((getProps)())?.["leaveDuration"] ?? (leaveDurationDefault.get() as number)) : (leaveDurationDefault.get() as number)));
      }, ["schedule"]: (durationMs: number, callback: () => void): __wcDelayTask => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":174:43
        return __wcDelay.schedule(durationMs, callback);
      }, ["setViewPresent"]: (present: boolean): void => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":176:9
        if ((!currentRun)) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":177:11
          throw new Error("[asTransition] runtime lifecycle handle is not available.");
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":179:9
        (phaseViewRequested = present);
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":180:9
        (currentRun as __wcRun).lifecycle.setPresent((phaseViewRequested || (closedViewRetained.get() as boolean)));
      }, ["emit"]: (event: "beforeEnter" | "afterEnter" | "beforeLeave" | "afterLeave"): void => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":183:9
        ((__wcOptionalReceiver: ((__wcRun) | (null))) => __wcOptionalReceiver == null ? undefined : __wcOptionalReceiver.expose.emit(event))(currentRun);
      } } as { "getState": () => "closed" | "preparing" | "entering" | "entered" | "leaving"; "setState": (state: "closed" | "preparing" | "entering" | "entered" | "leaving") => void; "getInterrupt": () => "reverse" | "wait" | "immediate"; "requiresColdPreparation"?: () => boolean; "getCompletion"?: () => (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number })); "publishPresentation"?: (frame: { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) => void; "settlePresentation"?: (outcome: "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed") => void; "getDuration": (state: "entering" | "leaving") => number; "schedule": (durationMs: number, callback: () => void) => __wcDelayTask; "setViewPresent": (present: boolean) => void; "emit": (event: "beforeEnter" | "afterEnter" | "beforeLeave" | "afterLeave") => void });
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":186:11
      const machine = __puiModule0(driver);
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":187:5
      presentation.onCompletionRequest((run: __wcRun, request: { readonly "receipt": { readonly "owner": Readonly<object>; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "viewBinding": Readonly<object>; readonly "ownerRevision": number; readonly "targetRevision": number; readonly "channels": ReadonlyArray<"translate" | "opacity">; readonly "outcome": "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed" } }) => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":188:7
        if ((!currentRun)) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":188:24
          return;
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":189:7
        if ((!(void (run), __wcPresence.isCurrent((presentation)["writer"], (request)["receipt"])))) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":189:83
          return;
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":190:7
        ((machine)["completePresentation"])(((request)["receipt"])["attempt"], (): boolean => {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":192:15
          return ((!(!currentRun)) && (void (run), __wcPresence.isCurrent((presentation)["writer"], (request)["receipt"])));
        });
      });
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":196:11
      const controls: { "enter": () => void; "leave": () => void; "complete": () => void; "capturePreparation": () => ((() => void) | (null)) } = { ["enter"]: (): void => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":198:9
        if (openContextSource) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":199:11
          if (currentRun) {
            // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":199:27
            ((machine)["setTarget"])((contextOpen)((currentRun as __wcRun), (openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string })));
          }
        } else {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":200:16
          ((machine)["enter"])();
        }
      }, ["leave"]: (): void => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":203:9
        if (openContextSource) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":204:11
          if (currentRun) {
            // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":204:27
            ((machine)["setTarget"])((contextOpen)((currentRun as __wcRun), (openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string })));
          }
        } else {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":205:16
          ((machine)["leave"])();
        }
      }, ["complete"]: (): void => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":207:23
        return ((machine)["complete"])();
      }, ["capturePreparation"]: (): ((() => void) | (null)) => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":209:9
        if ((!currentRun)) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":210:11
          throw new Error("[asTransition] preparation capture requires a live runtime.");
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":211:9
        return ((machine)["capturePreparation"])();
      } };
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":214:11
      const contextOpen = (run: __wcRun, source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }): boolean => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":218:13
        const value = (run.context.read((source)["context"]) as { [key: string]: unknown });
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":219:13
        const target = (value)[(source)["field"]];
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":220:7
        if (((!Object.hasOwn(value, (source)["field"])) || ((typeof target) !== "boolean"))) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":221:9
          throw new Error("[asTransition] open context field must be a required boolean.");
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":222:7
        return (target as boolean);
      };
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":224:11
      const bindOpenContext = (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }): void => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":225:7
        appearDefault.setDefault((appearDefault.get() as boolean));
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":226:7
        if ((((((!source) || ((typeof (source)["field"]) !== "string")) || (!(source)["field"])) || (!(source)["context"])) || (((source)["context"])["__brand"] !== "ContextKey"))) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":233:9
          throw new Error("[asTransition] open context source requires a ContextKey and direct field.");
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":236:7
        if (openContextSource) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":237:9
          if (((((openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["context"] === (source)["context"]) && (((openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["field"] === (source)["field"]))) {
            // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":241:11
            return;
          }
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":242:9
          throw new Error("[asTransition] open context source is already bound.");
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":244:7
        (openContextSource = (Object.freeze({ ["context"]: (source)["context"], ["field"]: (source)["field"] }) as { "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; "field": string }));
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":245:7
        (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = (source)["context"];
const __wcCaptureArg1 = (run: __wcRun) => {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":246:9
          (currentRun = run);
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":247:9
          ((machine)["setTarget"])((contextOpen)(run, (openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string })));
        };
const __wcCaptureResult = __wcCaptureReceiver.context.subscribe(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("context", {"op": "subscribe", "key": __wcCaptureArg0, "off": __wcCaptureResult}); __wcAuthored.disposer("context", __wcCaptureResult); return __wcCaptureResult; })();
      };
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":250:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "bindOpenContext";
const __wcCaptureArg1 = bindOpenContext;
const __wcCaptureResult = __wcCaptureReceiver.expose.method(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("context", {"op": "expose.method", "key": __wcCaptureArg0, "fn": __wcCaptureArg1}); __wcAuthored.method(__wcCaptureArg0, __wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":251:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "retainClosedView";
const __wcCaptureArg1 = (retained: boolean): void => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":252:7
        closedViewRetained.set((!(!retained)), "reason: transition closed-view retention policy");
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":253:7
        if ((!currentRun)) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":253:24
          return;
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":254:7
        (currentRun as __wcRun).lifecycle.setPresent((phaseViewRequested || (closedViewRetained.get() as boolean)));
      };
const __wcCaptureResult = __wcCaptureReceiver.expose.method(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("context", {"op": "expose.method", "key": __wcCaptureArg0, "fn": __wcCaptureArg1}); __wcAuthored.method(__wcCaptureArg0, __wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":257:5
      def.lifecycle.onCreated((run: __wcRun) => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":258:7
        (currentRun = run);
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":259:13
        const props = run.props.get();
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":260:13
        const controlled = run.props.isProvided("open");
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":261:11
        let open: boolean = (controlled ? (!(!(props)["open"])) : (!(!(props)["defaultOpen"])));
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":262:7
        if (openContextSource) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":263:9
          (open = (contextOpen)(run, (openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string })));
        } else {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":264:14
          if ((((!controlled) && (!run.props.isProvided("defaultOpen"))) && initialOpenSource)) {
            // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":265:15
            const value = (run.context.read(((initialOpenSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["context"]) as { [key: string]: unknown });
            // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":266:15
            const initialOpen = (value)[((initialOpenSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["field"]];
            // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":267:9
            if (((!Object.hasOwn(value, ((initialOpenSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["field"])) || ((typeof initialOpen) !== "boolean"))) {
              // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":268:11
              throw new Error("[asTransition] initial open context field must be a required boolean.");
            }
            // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":270:9
            (open = (initialOpen as boolean));
          }
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":272:13
        const appear = (run.props.isProvided("appear") ? (!(!(props)["appear"])) : (appearDefault.get() as boolean));
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":273:7
        ((machine)["initialize"])(open, appear);
      });
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":276:5
      def.lifecycle.onMounted((run: __wcRun) => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":277:7
        (currentRun = run);
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":278:7
        ((machine)["mounted"])();
      });
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":281:5
      def.lifecycle.onUnmounted((run: __wcRun) => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":282:7
        (currentRun = run);
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":283:7
        ((machine)["unmounted"])();
      });
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":286:5
      def.lifecycle.onBeforeDispose(() => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":287:7
        ((machine)["dispose"])();
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":288:7
        (currentRun = null);
      });
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":291:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = ["open", "interrupt", "enterDuration", "leaveDuration"];
const __wcCaptureArg1 = (run: __wcRun, next: __wcPropsSnapshot) => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":292:7
        (currentRun = run);
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":293:7
        if ((openContextSource || (!run.props.isProvided("open")))) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":293:63
          return;
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":294:7
        ((machine)["setTarget"])((!(!(next)["open"])));
      };
const __wcCaptureResult = __wcCaptureReceiver.props.watch(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("props", {"op": "watch", "keys": __wcCaptureArg0, "off": __wcCaptureResult}); __wcAuthored.disposer("props", __wcCaptureResult); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":297:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "transitionState";
const __wcCaptureArg1 = transitionState;
const __wcCaptureResult = __wcCaptureReceiver.expose.state(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("state", {"op": "expose.state", "key": __wcCaptureArg0, "handle": __wcCaptureArg1}); __wcAuthored.introduceObserved(__wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":298:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "isPresent";
const __wcCaptureArg1 = isPresent;
const __wcCaptureResult = __wcCaptureReceiver.expose.state(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("state", {"op": "expose.state", "key": __wcCaptureArg0, "handle": __wcCaptureArg1}); __wcAuthored.introduceObserved(__wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":299:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "enter";
const __wcCaptureArg1 = (controls)["enter"];
const __wcCaptureResult = __wcCaptureReceiver.expose.method(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("context", {"op": "expose.method", "key": __wcCaptureArg0, "fn": __wcCaptureArg1}); __wcAuthored.method(__wcCaptureArg0, __wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":300:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "leave";
const __wcCaptureArg1 = (controls)["leave"];
const __wcCaptureResult = __wcCaptureReceiver.expose.method(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("context", {"op": "expose.method", "key": __wcCaptureArg0, "fn": __wcCaptureArg1}); __wcAuthored.method(__wcCaptureArg0, __wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":301:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "complete";
const __wcCaptureArg1 = (controls)["complete"];
const __wcCaptureResult = __wcCaptureReceiver.expose.method(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("context", {"op": "expose.method", "key": __wcCaptureArg0, "fn": __wcCaptureArg1}); __wcAuthored.method(__wcCaptureArg0, __wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":302:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "capturePreparation";
const __wcCaptureArg1 = (controls)["capturePreparation"];
const __wcCaptureResult = __wcCaptureReceiver.expose.method(__wcCaptureArg0, __wcCaptureArg1, (__wcPublicResult: ((() => void) | (null))) => ((__wcPublicValue0: ((() => void) | (null))) => (typeof __wcPublicValue0 === 'function' ? __wcWrapPublic(__wcPublicValue0) : (__wcPublicValue0)))(__wcPublicResult)); __wcAuthored.effect("context", {"op": "expose.method", "key": __wcCaptureArg0, "fn": __wcCaptureArg1}); __wcAuthored.method(__wcCaptureArg0, __wcCaptureArg1); return __wcCaptureResult; })();
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":303:5
      (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "controls";
const __wcCaptureArg1 = controls;
const __wcCaptureResult = __wcCaptureReceiver.expose.value(__wcCaptureArg0, ((__wcPublicValue0: { "enter": () => void; "leave": () => void; "complete": () => void; "capturePreparation": () => ((() => void) | (null)) }) => (__wcPublicValue0 !== null && typeof __wcPublicValue0 === 'object' ? __wcWrapPublic.record(__wcPublicValue0, __wcPublicValue0Record => { if (Object.hasOwn(__wcPublicValue0, "enter")) Object.defineProperty(__wcPublicValue0Record, "enter", { value: ((__wcPublicValue1: () => void) => (typeof __wcPublicValue1 === 'function' ? __wcWrapPublic(__wcPublicValue1, __wcPublicValue0) : (__wcPublicValue1)))(((__wcPublicValue0 as unknown as Record<string, unknown>)["enter"] as () => void)), enumerable: true, configurable: true, writable: true }); if (Object.hasOwn(__wcPublicValue0, "leave")) Object.defineProperty(__wcPublicValue0Record, "leave", { value: ((__wcPublicValue2: () => void) => (typeof __wcPublicValue2 === 'function' ? __wcWrapPublic(__wcPublicValue2, __wcPublicValue0) : (__wcPublicValue2)))(((__wcPublicValue0 as unknown as Record<string, unknown>)["leave"] as () => void)), enumerable: true, configurable: true, writable: true }); if (Object.hasOwn(__wcPublicValue0, "complete")) Object.defineProperty(__wcPublicValue0Record, "complete", { value: ((__wcPublicValue3: () => void) => (typeof __wcPublicValue3 === 'function' ? __wcWrapPublic(__wcPublicValue3, __wcPublicValue0) : (__wcPublicValue3)))(((__wcPublicValue0 as unknown as Record<string, unknown>)["complete"] as () => void)), enumerable: true, configurable: true, writable: true }); if (Object.hasOwn(__wcPublicValue0, "capturePreparation")) Object.defineProperty(__wcPublicValue0Record, "capturePreparation", { value: ((__wcPublicValue4: () => ((() => void) | (null))) => (typeof __wcPublicValue4 === 'function' ? __wcWrapPublic(__wcPublicValue4, __wcPublicValue0, (__wcPublicValue4Result: ((() => void) | (null))) => ((__wcPublicValue5: ((() => void) | (null))) => (typeof __wcPublicValue5 === 'function' ? __wcWrapPublic(__wcPublicValue5) : (__wcPublicValue5)))(__wcPublicValue4Result), "7f8ad435c936065d") : (__wcPublicValue4)))(((__wcPublicValue0 as unknown as Record<string, unknown>)["capturePreparation"] as () => ((() => void) | (null)))), enumerable: true, configurable: true, writable: true }); }) : __wcPublicValue0))(__wcCaptureArg1)); __wcAuthored.effect("context", {"op": "expose.value", "key": __wcCaptureArg0, "value": __wcCaptureArg1}); return __wcCaptureResult; })();
    })(__wcDef), project: (result: { readonly stateHandles?: Readonly<Record<string, unknown>>; readonly getState?: (name: string) => unknown; readonly getMethod?: (name: string) => unknown; readonly getAsHook?: (name: string) => unknown; readonly getAsHookHandle?: (name: string) => unknown; readonly render?: unknown }): { "transitionState": __wcState<string> & {watch(callback: (run: __wcRun, event: {type:'next';prev:string;next:string;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}; "isPresent": __wcState<boolean> & {watch(callback: (run: __wcRun, event: {type:'next';prev:boolean;next:boolean;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}; "controls": { "capturePreparation": () => ((() => void) | (null)); "enter": () => void; "leave": () => void; "complete": () => void }; "configure": (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void; "bindInitialOpen": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void; "bindOpenContext": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void; "retainClosedView": (retained: boolean) => void; "presentationOwner": Readonly<object> } => {
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":306:11
      const transitionState = __puiModule1((result.getState?.("transitionState") as ((__wcState<string> & {watch(callback: (run: __wcRun, event: {type:'next';prev:string;next:string;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}) | (undefined))), "transitionState");
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":310:11
      const isPresent = __puiModule2((result.getState?.("isPresent") as ((__wcState<boolean> & {watch(callback: (run: __wcRun, event: {type:'next';prev:boolean;next:boolean;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}) | (undefined))), "isPresent");
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":311:11
      const controls: { "capturePreparation": () => ((() => void) | (null)); "enter": () => void; "leave": () => void; "complete": () => void } = { ["capturePreparation"]: __puiModule3((result.getMethod?.("capturePreparation") as ((() => ((() => void) | (null))) | (undefined))), "capturePreparation"), ["enter"]: __puiModule4((result.getMethod?.("enter") as ((() => void) | (undefined))), "enter"), ["leave"]: __puiModule5((result.getMethod?.("leave") as ((() => void) | (undefined))), "leave"), ["complete"]: __puiModule6((result.getMethod?.("complete") as ((() => void) | (undefined))), "complete") };
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":330:11
      const appearDefault = __puiModule7((result.getState?.("transitionAppearDefault") as ((__wcState<boolean> & {watch(callback: (run: __wcRun, event: {type:'next';prev:boolean;next:boolean;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}) | (undefined))), "transitionAppearDefault");
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":334:11
      const enterDurationDefault = __puiModule8((result.getState?.("transitionEnterDurationDefault") as ((__wcState<number> & {watch(callback: (run: __wcRun, event: {type:'next';prev:number;next:number;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}) | (undefined))), "transitionEnterDurationDefault");
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":338:11
      const leaveDurationDefault = __puiModule9((result.getState?.("transitionLeaveDurationDefault") as ((__wcState<number> & {watch(callback: (run: __wcRun, event: {type:'next';prev:number;next:number;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}) | (undefined))), "transitionLeaveDurationDefault");
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":342:11
      const interruptDefault = __puiModule10((result.getState?.("transitionInterruptDefault") as ((__wcState<string> & {watch(callback: (run: __wcRun, event: {type:'next';prev:string;next:string;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}) | (undefined))), "transitionInterruptDefault");
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":347:11
      const coldEntryPreparation = __puiModule11((result.getState?.("transitionColdEntryPreparation") as ((__wcState<boolean> & {watch(callback: (run: __wcRun, event: {type:'next';prev:boolean;next:boolean;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}) | (undefined))), "transitionColdEntryPreparation");
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":352:11
      const configurePresentation = __puiModule12((result.getMethod?.("configurePresentation") as (((config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void) | (undefined))), "configurePresentation");
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":358:11
      const getPresentationOwner = __puiModule13((result.getMethod?.("getPresentationOwner") as ((() => Readonly<object>) | (undefined))), "getPresentationOwner");
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":362:11
      const configure = (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }): void => {
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":364:7
        (configurePresentation)(config);
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":365:11
        let configured: boolean = false;
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":366:7
        if (((typeof (config)["coldEntryPreparation"]) !== "undefined")) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":367:9
          coldEntryPreparation.setDefault(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation": boolean; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["coldEntryPreparation"]);
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":368:9
          (configured = true);
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":370:7
        if (((typeof (config)["appear"]) !== "undefined")) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":371:9
          appearDefault.setDefault(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear": boolean; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["appear"]);
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":372:9
          (configured = true);
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":374:7
        if (((typeof (config)["enterDuration"]) !== "undefined")) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":375:9
          if (((!Number.isFinite(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration": number; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["enterDuration"])) || (((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration": number; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["enterDuration"] < 0))) {
            // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":376:11
            throw new Error("[asTransition] enterDuration must be a finite non-negative number.");
          }
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":378:9
          enterDurationDefault.setDefault(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration": number; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["enterDuration"]);
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":379:9
          (configured = true);
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":381:7
        if (((typeof (config)["leaveDuration"]) !== "undefined")) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":382:9
          if (((!Number.isFinite(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration": number; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["leaveDuration"])) || (((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration": number; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["leaveDuration"] < 0))) {
            // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":383:11
            throw new Error("[asTransition] leaveDuration must be a finite non-negative number.");
          }
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":385:9
          leaveDurationDefault.setDefault(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration": number; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["leaveDuration"]);
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":386:9
          (configured = true);
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":388:7
        if (((typeof (config)["interrupt"]) !== "undefined")) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":389:9
          interruptDefault.setDefault(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt": "reverse" | "wait" | "immediate" }))["interrupt"]);
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":390:9
          (configured = true);
        }
        // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":393:7
        if ((!(configured as true | boolean))) {
          // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":393:24
          appearDefault.setDefault((appearDefault.get() as boolean));
        }
      };
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":396:11
      const bindInitialOpen = __puiModule14((result.getMethod?.("bindInitialOpen") as (((source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void) | (undefined))), "bindInitialOpen");
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":400:11
      const bindOpenContext = __puiModule15((result.getMethod?.("bindOpenContext") as (((source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void) | (undefined))), "bindOpenContext");
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":404:11
      const retainClosedView = __puiModule16((result.getMethod?.("retainClosedView") as (((retained: boolean) => void) | (undefined))), "retainClosedView");
      // Source "packages/prototypes/base/src/transition/as-transition.proto.ts":408:5
      return { ["transitionState"]: transitionState, ["isPresent"]: isPresent, ["controls"]: controls, ["configure"]: configure, ["bindInitialOpen"]: bindInitialOpen, ["bindOpenContext"]: bindOpenContext, ["retainClosedView"]: retainClosedView, ["presentationOwner"]: (getPresentationOwner)() };
    }}, options) as { "transitionState": __wcState<string> & {watch(callback: (run: __wcRun, event: {type:'next';prev:string;next:string;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}; "isPresent": __wcState<boolean> & {watch(callback: (run: __wcRun, event: {type:'next';prev:boolean;next:boolean;reason?:unknown}|{type:'disconnect';reason:'unmount'}) => void): () => void}; "controls": { "capturePreparation": () => ((() => void) | (null)); "enter": () => void; "leave": () => void; "complete": () => void }; "configure": (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void; "bindInitialOpen": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void; "bindOpenContext": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void; "retainClosedView": (retained: boolean) => void; "presentationOwner": Readonly<object> });    try {
      owner.render = ((def: __wcDef) => {
        // Source "packages/compiler/test/fixtures/presence-presentation-owner.proto.ts":8:11
        const transition = __wcHook0();
        // Source "packages/compiler/test/fixtures/presence-presentation-owner.proto.ts":9:5
        ((transition)["configure"])({ ["enterDuration"]: 160, ["leaveDuration"]: 160, ["completion"]: { ["kind"]: "presentation", ["timeoutMs"]: 1000 } });
        // Source "packages/compiler/test/fixtures/presence-presentation-owner.proto.ts":14:5
        (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0: Parameters<typeof __wcCaptureReceiver.props.define>[0] = { ["side"]: { ["type"]: "enum", ["options"]: ["left", "right"], ["default"]: "left" } };
const __wcCaptureResult = __wcCaptureReceiver.props.define(__wcCaptureArg0); __wcAuthored.effect("props", {"op": "define", "specMap": __wcCaptureArg0}); return __wcCaptureResult; })();
        // Source "packages/compiler/test/fixtures/presence-presentation-owner.proto.ts":15:11
        const side = (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = "presentationSide";
const __wcCaptureArg1 = "left";
const __wcCaptureArg2 = { ["options"]: ["left", "right"] };
const __wcCaptureResult = __wcCaptureReceiver.state.enum(__wcCaptureArg0, __wcCaptureArg1, __wcCaptureArg2); __wcAuthored.effect("state", __wcCaptureResult); return __wcCaptureResult; })();
        // Source "packages/compiler/test/fixtures/presence-presentation-owner.proto.ts":16:5
        def.lifecycle.onCreated((run: __wcRun) => {
          // Source "packages/compiler/test/fixtures/presence-presentation-owner.proto.ts":16:38
          return side.set((run.props.get())["side"]);
        });
        // Source "packages/compiler/test/fixtures/presence-presentation-owner.proto.ts":17:5
        (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = ["side"];
const __wcCaptureArg1 = (_run: __wcRun, next: __wcPropsSnapshot) => {
          // Source "packages/compiler/test/fixtures/presence-presentation-owner.proto.ts":17:47
          return side.set((next)["side"]);
        };
const __wcCaptureResult = __wcCaptureReceiver.props.watch(__wcCaptureArg0, __wcCaptureArg1); __wcAuthored.effect("props", {"op": "watch", "keys": __wcCaptureArg0, "off": __wcCaptureResult}); __wcAuthored.disposer("props", __wcCaptureResult); return __wcCaptureResult; })();
        // Source "packages/compiler/test/fixtures/presence-presentation-owner.proto.ts":18:5
        (() => {
const __wcCaptureReceiver = def;
const __wcCaptureArg0 = ({"kind":"tw","tokens":["block"],"groups":["display"]} as const);
const __wcCaptureResult = __wcCaptureReceiver.feedback.style.use(__wcCaptureArg0); __wcAuthored.effect("feedback", __wcCaptureResult); __wcAuthored.disposer("feedback", __wcCaptureResult); return __wcCaptureResult; })();
        // Source "packages/compiler/test/fixtures/presence-presentation-owner.proto.ts":19:5
        (void (def), __wcPresence.declare({ ["owner"]: (transition)["presentationOwner"], ["closed"]: { ["opacity"]: 0, ["translate"]: { ["source"]: side, ["cases"]: { ["left"]: [{ ["px"]: 0, ["rootText"]: 0, ["ownBox"]: (-1) }, { ["px"]: 0, ["rootText"]: 0, ["ownBox"]: 0 }], ["right"]: [{ ["px"]: 0, ["rootText"]: 0, ["ownBox"]: 1 }, { ["px"]: 0, ["rootText"]: 0, ["ownBox"]: 0 }] } } }, ["entered"]: { ["opacity"]: 1, ["translate"]: [{ ["px"]: 0, ["rootText"]: 0, ["ownBox"]: 0 }, { ["px"]: 0, ["rootText"]: 0, ["ownBox"]: 0 }] }, ["easing"]: [0, 0, 1, 1] }));
        // Source "packages/compiler/test/fixtures/presence-presentation-owner.proto.ts":46:5
        return (r: __wcRenderer) => {
          // Source "packages/compiler/test/fixtures/presence-presentation-owner.proto.ts":46:19
          const __wcOutput0=((__wcReceiver2: __wcRenderer, __wcTag3: string, __wcArg4?: unknown, __wcArg5?: unknown) => {
      if(!/^[A-Za-z][A-Za-z0-9:_-]*$/.test(__wcTag3))throw new TypeError('Invalid template tag');
      
      return () => {const __wcElement6=__wcReceiver2.nativeFrame.document.createElement(__wcTag3);
        
        for(const __wcItem8 of ((__wcArg4 as unknown[]) as unknown[])){if(typeof __wcItem8==='function'){__wcElement6.appendChild((__wcItem8 as ()=>Node)());} else if(typeof __wcItem8==='string'||typeof __wcItem8==='number'){__wcElement6.appendChild(__wcReceiver2.nativeFrame.document.createTextNode(String(__wcItem8)));} else {throw new TypeError('Invalid template child');}}
        return __wcElement6;};
    })(r, "section", [((transition)["transitionState"].get() as string), r.slot()]);
          const __wcFragment1=r.nativeFrame.document.createDocumentFragment();
if(__wcOutput0!==undefined){__wcFragment1.appendChild((__wcOutput0 as ()=>Node)());}
          return __wcFragment1;
          return r.nativeFrame.document.createDocumentFragment();
        };
      })(__wcDef);
      owner.hydrate(this.__wcRaw);
      owner.created();
      owner.reconcile();
      port.accept();
    } catch (error) {
      try { owner.dispose(); }
      finally { port.dispose(); this.__wcPort = null; this.__wcOwner = null; }
      throw error;
    }
  }
  disconnectedCallback(): void {
    const version = ++this.__wcDisconnect;
    const owner = this.__wcOwner;
    queueMicrotask(() => {
      if (version !== this.__wcDisconnect || this.isConnected || !owner || owner !== this.__wcOwner) return;
      this.__wcOwner = null;
      try { owner.dispose(); } finally { this.__wcPort?.dispose(); this.__wcPort = null; }
    });
  }
  setProps(next: GeneratedProps & Record<string, unknown>): void {
    if (this.__wcClosed) throw new Error('Custom element is disposed');

    if (Object.prototype.hasOwnProperty.call(next, 'instanceAssociations')) throw new TypeError('[InstanceAssociations] use the instanceAssociations property, outside Props');
    this.__wcRaw = { ...next };
    const owner = this.__wcOwner;
    if (owner) {
      owner.hydrate(this.__wcRaw);

    }
  }
  update(): void {
    if (this.__wcClosed) throw new Error('Custom element is disposed');
    this.__wcOwner?.update();
  }
  getExposes(): Partial<GeneratedExposes> {
    return this.isConnected && this.__wcOwner ? { ...this.__wcOwner.exposes } as Partial<GeneratedExposes> : {};
  }
  dispose(): void {
    if (this.__wcClosed) return;
    this.__wcClosed = true;
    ++this.__wcDisconnect;
    const owner = this.__wcOwner;
    this.__wcOwner = null;
    try { owner?.dispose(); } finally { this.__wcPort?.dispose(); this.__wcPort = null; }
  }
}
export function register(tagName = "pui-compiled-element", registry: CustomElementRegistry = customElements): typeof CompiledElement {
  const existing = registry.get(tagName);
  if (existing && existing !== CompiledElement) throw new Error('Custom element tag already registered: ' + tagName);
  if (!existing) registry.define(tagName, CompiledElement);
  return CompiledElement;
}
export default CompiledElement;

//# sourceMappingURL=Component.ts.map
