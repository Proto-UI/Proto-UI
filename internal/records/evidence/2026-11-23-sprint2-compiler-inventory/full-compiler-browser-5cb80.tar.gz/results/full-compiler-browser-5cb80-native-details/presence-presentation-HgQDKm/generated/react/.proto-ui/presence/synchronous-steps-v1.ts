// Canonical neutral presentation: packages/adapters/base/src/host/synchronous-steps.ts
// sha256: 1fc559c9ad68a7a03e2d5511362e41b95e492f245d0eb4a7f1cc16e3b3f5734b
// Finish every step while preserving the first synchronous failure, including falsy values.
export function runAllSteps(steps: Array<() => void>): void {
    let failed = false;
    let firstError: unknown;
    for (const step of steps) {
        try {
            step();
        }
        catch (error) {
            if (!failed) {
                failed = true;
                firstError = error;
            }
        }
    }
    if (failed)
        throw firstError;
}
