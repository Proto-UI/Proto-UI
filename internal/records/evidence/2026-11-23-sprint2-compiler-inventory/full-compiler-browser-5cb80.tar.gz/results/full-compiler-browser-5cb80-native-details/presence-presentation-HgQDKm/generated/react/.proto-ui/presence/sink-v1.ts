import type { PresenceEndpoint, PresentationOwnerFrame, PresentationViewBinding, PresentationOutcome, StyleHandle } from './declarations-v1';
export type ResolvedPresenceEndpoint = Omit<PresenceEndpoint, 'translate'> & {
    translate?: import("./declarations-v1").Translation;
};
export type PresencePresentationFrame = Readonly<{
    view: number;
    revision: number;
    targetRevision: number;
    style: StyleHandle;
    owner: PresentationOwnerFrame;
    closed: ResolvedPresenceEndpoint;
    entered: ResolvedPresenceEndpoint;
    easing: readonly [
        number,
        number,
        number,
        number
    ];
    bind(binding: PresentationViewBinding): void;
    complete(binding: PresentationViewBinding, outcome: PresentationOutcome): void;
}>;
export interface PresencePresentationSink {
    commit(frame: PresencePresentationFrame): void;
    cancel(): void;
    settle(outcome: PresentationOutcome): boolean;
    release(view: number): void;
    diagnostics?(): readonly string[];
}
