import {definePrototype} from '@proto.ui/core';
import {asTransition} from './transition/as-transition.proto';
export default definePrototype({name:'browser-transition-prepared',setup(){
  asTransition().configure({coldEntryPreparation:true,appear:false,enterDuration:200,leaveDuration:500});
  return r=>r.el('section',['Transition view ',r.slot()]);
}});