// Editable Vue 3 source. Profile: vue-source-v1; no Proto Runtime or Adapter dependency.
// Inline native costs: owner/update queue, constrained state subscriptions, prop resolution/watchers,
// public boundary guards, view commit lifecycle and native element/slot composition.
// Source graph SHA-256: 9a882481b587669e560b652879d04b517a0c8a79a9eeea8c386df889dd50f050
import { createNativeDelay as __puiVueCreateDelay, type NativeDelayTask as __puiVueDelayTask } from './.proto-ui/async/delay-web-v1';
import { createNativePresence as __puiVueCreatePresence, snapshotNativeCompletion as __puiVueSnapshotCompletion, type NativePresenceOwner as __puiVuePresenceOwner } from './.proto-ui/async/presence-owner-v1';
import { readNativeWebMeta as __puiVueReadMeta } from './.proto-ui/meta/web-snapshot-v1';
import { createNativePublicCalls as __puiVueCreatePublicCalls } from './.proto-ui/owner/public-callables-v1';

import { createNativeAuthoredHooks as __puiVueCreateAuthored } from './.proto-ui/owner/authored-hooks-v1';
import * as __puiVueVue from 'vue';




import { createContextScope as __puiVueCreateContextScope, scopeKey as __puiVueScopeKey, acceptsContextValue as __puiVueAcceptsContextValue, type ContextScope as __puiVueContextScope } from './.proto-ui/context/scope-v1';


// Source "transition/as-transition.proto.ts":23:1
const __puiModule1 = (value: ((__puiVueState<string> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<string>) => void): () => void}) | (undefined)), name: "transitionState"): __puiVueState<string> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<string>) => void): () => void} => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule2 = (value: ((__puiVueState<boolean> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<boolean>) => void): () => void}) | (undefined)), name: "isPresent"): __puiVueState<boolean> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<boolean>) => void): () => void} => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule3 = (value: ((() => ((() => void) | (null))) | (undefined)), name: "capturePreparation"): () => ((() => void) | (null)) => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule4 = (value: ((() => void) | (undefined)), name: "enter"): () => void => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule5 = (value: ((() => void) | (undefined)), name: "leave"): () => void => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule6 = (value: ((() => void) | (undefined)), name: "complete"): () => void => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule7 = (value: ((__puiVueState<boolean> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<boolean>) => void): () => void}) | (undefined)), name: "transitionAppearDefault"): __puiVueState<boolean> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<boolean>) => void): () => void} => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule8 = (value: ((__puiVueState<number> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<number>) => void): () => void}) | (undefined)), name: "transitionEnterDurationDefault"): __puiVueState<number> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<number>) => void): () => void} => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule9 = (value: ((__puiVueState<number> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<number>) => void): () => void}) | (undefined)), name: "transitionLeaveDurationDefault"): __puiVueState<number> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<number>) => void): () => void} => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule10 = (value: ((__puiVueState<string> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<string>) => void): () => void}) | (undefined)), name: "transitionInterruptDefault"): __puiVueState<string> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<string>) => void): () => void} => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule11 = (value: ((__puiVueState<boolean> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<boolean>) => void): () => void}) | (undefined)), name: "transitionColdEntryPreparation"): __puiVueState<boolean> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<boolean>) => void): () => void} => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule12 = (value: (((config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void) | (undefined)), name: "configurePresentation"): (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule13 = (value: ((() => Readonly<object>) | (undefined)), name: "getPresentationOwner"): () => Readonly<object> => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule14 = (value: (((source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void) | (undefined)), name: "bindInitialOpen"): (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule15 = (value: (((source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void) | (undefined)), name: "bindOpenContext"): (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};
// Source "transition/as-transition.proto.ts":23:1
const __puiModule16 = (value: (((retained: boolean) => void) | (undefined)), name: "retainClosedView"): (retained: boolean) => void => {
  // Source "transition/as-transition.proto.ts":24:3
  if (((typeof value) === "undefined")) {
    // Source "transition/as-transition.proto.ts":25:5
    throw new Error((("[asTransition] missing captured handle: " + name) + "."));
  }
  // Source "transition/as-transition.proto.ts":27:3
  return value;
};



type __puiVueRun = Readonly<{ readonly owner: symbol }>;
type __puiVueStateEvent<T> = { type: 'next'; prev: T; next: T; reason?: unknown } | {type:'disconnect';reason:'unmount'};
type __puiVueSpec = Readonly<{ kind: 'bool' | 'enum' | 'string' | 'number.range' | 'number.discrete'; options?: readonly (string | number)[]; min?: number; max?: number; step?: number; clamp?: boolean }>;
type __puiVuePropSpec = { type: unknown; default?: unknown; empty?: 'accept' | 'fallback' | 'error'; range?: { min?: number; max?: number }; options?: readonly unknown[]; validator?: (value: never) => boolean };
type __puiVueWatchInfo = { changedKeysAll: string[]; changedKeysMatched: string[] };
export type __puiVuePublicState<T> = { get(): T; subscribe(callback: (event: __puiVueStateEvent<T>) => void): () => void; unsubscribe(off: () => void): void; readonly spec: __puiVueSpec };
type __puiVueState<T> = __puiVuePublicState<T> & { setDefault(next: T): void; set(next: T, reason?: unknown): void };
type __puiVueEpoch = { id: number; active: boolean; committed: boolean };
type __puiVueFrame = { epoch: __puiVueEpoch; slotUsed: boolean };
export type GeneratedProps = {
  "open"?: boolean | null;
  "defaultOpen"?: boolean | null;
  "appear"?: boolean | null;
  "enterDuration"?: number | null;
  "leaveDuration"?: number | null;
  "interrupt"?: "reverse" | "wait" | "immediate" | null;
};
export type GeneratedResolvedProps = {
  readonly "open": boolean;
  readonly "defaultOpen": boolean;
  readonly "appear": boolean;
  readonly "enterDuration": number;
  readonly "leaveDuration": number;
  readonly "interrupt": "reverse" | "wait" | "immediate";
};
export type GeneratedExposes = {
  readonly "beforeEnter": { readonly kind: 'event' };
  readonly "afterEnter": { readonly kind: 'event' };
  readonly "beforeLeave": { readonly kind: 'event' };
  readonly "afterLeave": { readonly kind: 'event' };
  readonly "bindInitialOpen": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void;
  readonly "getPresentationOwner": () => Readonly<object>;
  readonly "configurePresentation": (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void;
  readonly "bindOpenContext": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void;
  readonly "retainClosedView": (retained: boolean) => void;
  readonly "transitionState": __puiVuePublicState<string>;
  readonly "isPresent": __puiVuePublicState<boolean>;
  readonly "enter": () => void;
  readonly "leave": () => void;
  readonly "complete": () => void;
  readonly "capturePreparation": () => ((() => void) | (null));
  readonly "controls": { "enter": () => void; "leave": () => void; "complete": () => void; "capturePreparation": () => ((() => void) | (null)) };
};
export type GeneratedHandle = { update(): void; getExposes(): GeneratedExposes };

// The slot is a real Vue child render, so authored Vue children retain native ownership.
const __puiVueSlotView = __puiVueVue.defineComponent({
  name: 'CompiledSlot', inheritAttrs: false,
  props: { read: { type: Function as __puiVueVue.PropType<() => __puiVueVue.VNodeChild>, required: true } },
  setup(props) { return () => props.read!(); },
});

export const CompiledComponent = __puiVueVue.defineComponent({
  name: "browser-transition-ordinary", inheritAttrs: false,
  props: { instanceAssociations: { type: Object as __puiVueVue.PropType<Readonly<{controlLabel?: object | null}>>, default: undefined } },
  emits: ["beforeEnter","afterEnter","beforeLeave","afterLeave"],
  setup(_props, __puiVueContext) {
    // Protocol values intentionally do not enter Vue's reactive state graph.
    const __puiVueInstance = __puiVueVue.getCurrentInstance()!;

    const __puiVueRevision = __puiVueVue.shallowRef(0);
    const __puiVueHostRevision = __puiVueVue.shallowRef(0);
    let __puiVueHostScheduled = false;
    const __puiVuePresent = __puiVueVue.shallowRef(true);
    const __puiVueSlotRevision = __puiVueVue.shallowRef(0);
    let __puiVueDisposed = false, __puiVueDisposing = false, __puiVueInternalTeardown = false;
    let __puiVueQueued = false, __puiVueRequested = false, __puiVueQueueTicket = 0;
    let __puiVueEpochId = 0;
    let __puiVueCurrentEpoch: __puiVueEpoch | undefined;

    const __puiVueLife: Record<'created' | 'mounted' | 'updated' | 'unmounted' | 'beforeDispose', Array<(run: __puiVueRun) => void>> = { created: [], mounted: [], updated: [], unmounted: [], beforeDispose: [] };
    const __puiVueExposes: Record<string, unknown> = Object.create(null);
    const __puiVueStates = new Set<object>();
    const __puiVuePublicStates = new WeakMap<object, object>();
    const __puiVueInternalSubscriptions = new WeakMap<object, (callback: (event: __puiVueStateEvent<unknown>) => void) => () => void>();
    const __puiVueStateCleanup: Array<() => void> = [];
    const __puiVueEvents = new Set<string>();
    const __puiVuePropChecks: Record<string, (value: unknown) => boolean> = {
    ["open"]: (__puiVueValue: unknown) => (typeof __puiVueValue === 'boolean'),
    ["defaultOpen"]: (__puiVueValue: unknown) => (typeof __puiVueValue === 'boolean'),
    ["appear"]: (__puiVueValue: unknown) => (typeof __puiVueValue === 'boolean'),
    ["enterDuration"]: (__puiVueValue: unknown) => (typeof __puiVueValue === 'number' && Number.isFinite(__puiVueValue)),
    ["leaveDuration"]: (__puiVueValue: unknown) => (typeof __puiVueValue === 'number' && Number.isFinite(__puiVueValue)),
    ["interrupt"]: (__puiVueValue: unknown) => (__puiVueValue === "reverse" || __puiVueValue === "wait" || __puiVueValue === "immediate"),
    };
    const __puiVueMethodChecks: Record<string, { args(args: unknown[]): boolean; result(value: unknown): boolean }> = {
    ["bindInitialOpen"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 1 && ((__puiVueArgs[0] !== null && typeof __puiVueArgs[0] === 'object' && !Array.isArray(__puiVueArgs[0]) && (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "context") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "context")!, 'value') && (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "context")!.value !== null && typeof Object.getOwnPropertyDescriptor(__puiVueArgs[0], "context")!.value === 'object' && Object.getOwnPropertyDescriptor(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "context")!.value, '__brand')?.value === 'ContextKey')) && (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "field") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "field")!, 'value') && (typeof Object.getOwnPropertyDescriptor(__puiVueArgs[0], "field")!.value === 'string')))), result: (__puiVueValue: unknown) => __puiVueValue === undefined },
    ["getPresentationOwner"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 0, result: (__puiVueValue: unknown) => (__puiVueValue !== null && typeof __puiVueValue === 'object' && !Array.isArray(__puiVueValue)) },
    ["configurePresentation"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 1 && ((__puiVueArgs[0] !== null && typeof __puiVueArgs[0] === 'object' && !Array.isArray(__puiVueArgs[0]) && (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "completion") === undefined || (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "completion") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "completion")!, 'value') && (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "completion")!.value === "timer" || (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "completion")!.value !== null && typeof Object.getOwnPropertyDescriptor(__puiVueArgs[0], "completion")!.value === 'object' && !Array.isArray(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "completion")!.value) && (Object.getOwnPropertyDescriptor(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "completion")!.value, "kind") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "completion")!.value, "kind")!, 'value') && Object.getOwnPropertyDescriptor(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "completion")!.value, "kind")!.value === "presentation") && (Object.getOwnPropertyDescriptor(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "completion")!.value, "timeoutMs") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "completion")!.value, "timeoutMs")!, 'value') && (typeof Object.getOwnPropertyDescriptor(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "completion")!.value, "timeoutMs")!.value === 'number' && Number.isFinite(Object.getOwnPropertyDescriptor(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "completion")!.value, "timeoutMs")!.value)))) || Object.getOwnPropertyDescriptor(__puiVueArgs[0], "completion")!.value === undefined))) && (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "coldEntryPreparation") === undefined || (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "coldEntryPreparation") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "coldEntryPreparation")!, 'value') && ((typeof Object.getOwnPropertyDescriptor(__puiVueArgs[0], "coldEntryPreparation")!.value === 'boolean') || Object.getOwnPropertyDescriptor(__puiVueArgs[0], "coldEntryPreparation")!.value === undefined))) && (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "appear") === undefined || (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "appear") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "appear")!, 'value') && ((typeof Object.getOwnPropertyDescriptor(__puiVueArgs[0], "appear")!.value === 'boolean') || Object.getOwnPropertyDescriptor(__puiVueArgs[0], "appear")!.value === undefined))) && (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "enterDuration") === undefined || (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "enterDuration") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "enterDuration")!, 'value') && ((typeof Object.getOwnPropertyDescriptor(__puiVueArgs[0], "enterDuration")!.value === 'number' && Number.isFinite(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "enterDuration")!.value)) || Object.getOwnPropertyDescriptor(__puiVueArgs[0], "enterDuration")!.value === undefined))) && (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "leaveDuration") === undefined || (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "leaveDuration") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "leaveDuration")!, 'value') && ((typeof Object.getOwnPropertyDescriptor(__puiVueArgs[0], "leaveDuration")!.value === 'number' && Number.isFinite(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "leaveDuration")!.value)) || Object.getOwnPropertyDescriptor(__puiVueArgs[0], "leaveDuration")!.value === undefined))) && (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "interrupt") === undefined || (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "interrupt") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "interrupt")!, 'value') && (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "interrupt")!.value === "reverse" || Object.getOwnPropertyDescriptor(__puiVueArgs[0], "interrupt")!.value === "wait" || Object.getOwnPropertyDescriptor(__puiVueArgs[0], "interrupt")!.value === "immediate" || Object.getOwnPropertyDescriptor(__puiVueArgs[0], "interrupt")!.value === undefined))))), result: (__puiVueValue: unknown) => __puiVueValue === undefined },
    ["bindOpenContext"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 1 && ((__puiVueArgs[0] !== null && typeof __puiVueArgs[0] === 'object' && !Array.isArray(__puiVueArgs[0]) && (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "context") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "context")!, 'value') && (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "context")!.value !== null && typeof Object.getOwnPropertyDescriptor(__puiVueArgs[0], "context")!.value === 'object' && Object.getOwnPropertyDescriptor(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "context")!.value, '__brand')?.value === 'ContextKey')) && (Object.getOwnPropertyDescriptor(__puiVueArgs[0], "field") !== undefined && Object.hasOwn(Object.getOwnPropertyDescriptor(__puiVueArgs[0], "field")!, 'value') && (typeof Object.getOwnPropertyDescriptor(__puiVueArgs[0], "field")!.value === 'string')))), result: (__puiVueValue: unknown) => __puiVueValue === undefined },
    ["retainClosedView"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 1 && ((typeof __puiVueArgs[0] === 'boolean')), result: (__puiVueValue: unknown) => __puiVueValue === undefined },
    ["enter"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 0, result: (__puiVueValue: unknown) => __puiVueValue === undefined },
    ["leave"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 0, result: (__puiVueValue: unknown) => __puiVueValue === undefined },
    ["complete"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 0, result: (__puiVueValue: unknown) => __puiVueValue === undefined },
    ["capturePreparation"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 0, result: (__puiVueValue: unknown) => ((typeof __puiVueValue === 'function') || __puiVueValue === null) },
    };
    const __puiVueEventChecks: Record<string, (value: unknown) => boolean> = {
    ["beforeEnter"]: (__puiVueValue: unknown) => __puiVueValue === undefined,
    ["afterEnter"]: (__puiVueValue: unknown) => __puiVueValue === undefined,
    ["beforeLeave"]: (__puiVueValue: unknown) => __puiVueValue === undefined,
    ["afterLeave"]: (__puiVueValue: unknown) => __puiVueValue === undefined,
    };
    const __puiVuePropSpecs: Record<string, __puiVuePropSpec> = Object.create(null);
    const __puiVueDefaults: Array<Record<string, unknown>> = [];
    const __puiVuePreviousValid: Record<string, unknown> = Object.create(null);
    // Setup declarations precede hydration; the final snapshot is validated before created.
    let __puiVueProps: Readonly<GeneratedResolvedProps>;
    let __puiVueRawProps: Record<string, unknown> = Object.create(null);
    let __puiVuePropsWindow: {raw: Readonly<Record<string, unknown>>; resolved: Readonly<GeneratedResolvedProps>} | null = null;
    const __puiVueWatchers: Array<{ keys: readonly string[] | null; active: boolean; callback: (run: __puiVueRun, next: Readonly<GeneratedResolvedProps>, previous: Readonly<GeneratedResolvedProps>, info: __puiVueWatchInfo) => void }> = [];

    const __puiVueStateQueue: Array<() => void> = [];
    let __puiVueEmittingState = false;
    let __puiVueSetup = true;
    let __puiVueRootElement: HTMLElement | null = null;
    let __puiVueRootEpoch: __puiVueEpoch | undefined;

    const __puiVueParentScope = __puiVueVue.inject<__puiVueContextScope | null>(__puiVueScopeKey, null);
    const __puiVueContextChecks = new Map<object, (value: unknown) => boolean>([

    ]);
    const __puiVueScope = __puiVueCreateContextScope({
      getParent: () => __puiVueParentScope, isAlive: () => !__puiVueDisposed,
      invoke: (callback) => { __puiVueAlive(); return callback(); },
      validate: (key, value) => __puiVueContextChecks.get(key)?.(value) === true,
    });
    __puiVueVue.provide(__puiVueScopeKey, __puiVueScope);
    function __puiVueReadContext(run: __puiVueRun, key: object, optional: boolean): unknown {
      __puiVueRequireRun(run); return optional ? __puiVueScope.tryRead(key) : __puiVueScope.read(key);
    }
    function __puiVueReadAncestorContext(run: __puiVueRun, key: object): unknown {
      __puiVueRequireRun(run); return __puiVueScope.tryReadAncestor(key);
    }
    function __puiVueUpdateContext(run: __puiVueRun, key: object, value: unknown, optional: boolean): void | boolean {
      __puiVueRequireRun(run); return optional ? __puiVueScope.tryUpdate(key, value) : __puiVueScope.update(key, value);
    }
    function __puiVueReadFrameContext(frame: __puiVueFrame, key: object, optional: boolean): unknown {
      __puiVueActiveFrame(frame); return optional ? __puiVueScope.tryRead(key) : __puiVueScope.read(key);
    }

    let __puiVueCallbackScope: string | undefined;
    function __puiVueInvoke<T>(scope: string, callback: () => T): T {
      __puiVueAlive();
      if (!__puiVueSetup && !__puiVueDisposing && (scope === 'event' || scope === 'expose-method')) __puiVueNotifyProps();
      const previous = __puiVueCallbackScope; __puiVueCallbackScope = scope;
      try { return callback(); } finally { __puiVueCallbackScope = previous; }
    }



    const __puiVueDelay = __puiVueCreateDelay({ runtime: () => { __puiVueAlive(); if (__puiVueSetup || !__puiVueCallbackScope) throw new Error('Operation requires an owned runtime callback'); }, alive: () => !__puiVueDisposed, invoke: callback => { __puiVueInvoke('timer', callback); }, report: error => console.error('[Delay] callback failed', error) });
const __puiVuePresence = __puiVueCreatePresence<__puiVueRun>({ setup: () => { __puiVueAlive(); if (!__puiVueSetup) throw new Error('Setup capability is closed'); }, runtime: () => { __puiVueAlive(); if (__puiVueSetup || !__puiVueCallbackScope) throw new Error('Operation requires an owned runtime callback'); }, alive: () => !__puiVueDisposed, invoke: callback => { __puiVueInvoke('event', () => callback(__puiVueRunValue)); } });
const __puiVueMeta = (key: string) => __puiVueReadMeta(__puiVueRootElement?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), key);
    const __puiVueAuthored = __puiVueCreateAuthored({ setup() { __puiVueAlive(); if (!__puiVueSetup) throw new Error('Setup capability is closed'); }, borrow(value) {
      const state = value as __puiVueState<unknown>;
      const borrowed = Object.freeze({get: () => state.get(), setDefault: (value: unknown) => state.setDefault(value), set: (value: unknown, reason?: unknown) => state.set(value, reason), watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<unknown>) => void) { if (!__puiVueSetup) throw new Error('State watch requires setup'); const off = __puiVueSubscribeInternal(state, event => __puiVueInvoke('state-watch', () => callback(__puiVueRunValue, event))); __puiVueStateCleanup.push(off); return off; }});
      
      return borrowed;
    } });
    const __puiVueWrapPublic = __puiVueCreatePublicCalls({alive: __puiVuePublicAlive, invoke: callback => __puiVueInvoke('expose-method', callback)});
    const __puiVueRunValue: __puiVueRun = Object.freeze({ owner: Symbol("browser-transition-ordinary") });

    function __puiVueIsRecord(value: unknown): value is Record<string, unknown> {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
      const prototype = Object.getPrototypeOf(value);
      return (prototype === Object.prototype || prototype === null) && Reflect.ownKeys(value).every((key) => {
        const descriptor = Object.getOwnPropertyDescriptor(value, key)!;
        return typeof key === 'string' && descriptor.enumerable && Object.hasOwn(descriptor, 'value');
      });
    }
    function __puiVueIsArray(value: unknown): value is unknown[] {
      if (!Array.isArray(value) || Object.keys(value).length !== value.length) return false;
      const prototype = Object.getPrototypeOf(value);
      if (prototype !== Array.prototype && prototype !== null) return false;
      return Reflect.ownKeys(value).every((key) => {
        if (key === 'length') return true;
        const descriptor = Object.getOwnPropertyDescriptor(value, key)!;
        return typeof key === 'string' && /^(0|[1-9]\d*)$/.test(key) && Number(key) < value.length && descriptor.enumerable && Object.hasOwn(descriptor, 'value');
      });
    }

    function __puiVueAlive(): void {
      if (__puiVueDisposed || (__puiVueDisposing && !__puiVueInternalTeardown)) throw new Error('[Vue source] owner is disposed');
    }
    function __puiVuePublicAlive(): void {
      if (__puiVueDisposed || __puiVueDisposing) throw new Error('[Vue source] owner is disposed');
    }
    function __puiVueSubscribeInternal<T>(state: {get(): T}, callback: (event: __puiVueStateEvent<T>) => void): () => void {
      __puiVueAlive();
      const subscribe = __puiVueInternalSubscriptions.get(state);
      if (!subscribe) throw new Error('[State] unknown owner subscription target');
      return subscribe(event => callback(event as __puiVueStateEvent<T>));
    }
    function __puiVueRequireRun(run: __puiVueRun): void {
      __puiVueAlive();
      if (run !== __puiVueRunValue) throw new Error('[Vue source] foreign run handle');
    }
    function __puiVueRequestUpdate(run: __puiVueRun): void {
      __puiVueRequireRun(run);
      if (__puiVueDisposing) return;
      __puiVueRequested = true;

      if (__puiVueQueued) return;
      __puiVueQueued = true;
      const ticket = __puiVueQueueTicket;
      queueMicrotask(() => {
        if (ticket !== __puiVueQueueTicket || __puiVueDisposed || __puiVueDisposing) return;
        __puiVueQueued = false;
        if (!__puiVueRequested) return;
        __puiVueRequested = false;
        if (__puiVuePresent.value) __puiVueRevision.value += 1;
      });
    }
    function __puiVueSetPresent(run: __puiVueRun, present: boolean): void {
      __puiVueRequireRun(run);
      if (__puiVueDisposing) throw new Error('[Vue source] terminal presence is locked');
      if (typeof present !== 'boolean') throw new TypeError('[Vue source] presence must be boolean');
      __puiVuePresent.value = present;
    }
    function __puiVueInvokeLife(kind: keyof typeof __puiVueLife): void {
      if (kind === 'unmounted') { { let failed = false, first; for (const release of [() => { __puiVueDelay.cancelView(); }, () => { __puiVuePresence.detach(); }]) { try { release(); } catch (error) { if (!failed) { failed = true; first = error; } } } if (failed) throw first; } }
      try { for (const callback of __puiVueLife[kind]) callback(__puiVueRunValue); }
      finally { if (kind === 'unmounted') { { let failed = false, first; for (const release of [() => { __puiVueDelay.cancelView(); }, () => { __puiVuePresence.detach(); }]) { try { release(); } catch (error) { if (!failed) { failed = true; first = error; } } } if (failed) throw first; } } }
    }
    function __puiVueUnbindRoot(epoch: __puiVueEpoch): void {
      if (__puiVueRootEpoch !== epoch) return;

      { let failed = false, first; for (const release of [() => { __puiVueDelay.cancelView(); }, () => { __puiVuePresence.detach(); }]) { try { release(); } catch (error) { if (!failed) { failed = true; first = error; } } } if (failed) throw first; }
      __puiVueRootElement = null; __puiVueRootEpoch = undefined;

    }
    function __puiVueCommitUnmount(epoch: __puiVueEpoch): void {
      epoch.active = false;
      __puiVueUnbindRoot(epoch);
      if (!epoch.committed) return;
      epoch.committed = false;
      const previous = __puiVueInternalTeardown;
      __puiVueInternalTeardown = __puiVueDisposing;
      try { __puiVueInvokeLife('unmounted'); } finally { __puiVueInternalTeardown = previous; }
    }
    function __puiVueCreateState(kind: 'bool', semantic: string, initial: boolean): __puiVueState<boolean>;
    function __puiVueCreateState(kind: 'string' | 'enum', semantic: string, initial: string, options?: Omit<__puiVueSpec, 'kind'>): __puiVueState<string>;
    function __puiVueCreateState(kind: 'number.range' | 'number.discrete', semantic: string, initial: number, options?: Omit<__puiVueSpec, 'kind'>): __puiVueState<number>;
    function __puiVueCreateState(kind: __puiVueSpec['kind'], semantic: string, initial: boolean | number | string, options?: Omit<__puiVueSpec, 'kind'>): __puiVueState<boolean | number | string>;
    function __puiVueCreateState(kind: __puiVueSpec['kind'], semantic: string, initial: boolean | number | string, options: Omit<__puiVueSpec, 'kind'> = {}): unknown {
      __puiVueAuthored.claimState(semantic);
      if (typeof semantic !== 'string' || semantic.length === 0) throw new Error('[Vue source] invalid state semantic');
      const spec: __puiVueSpec = Object.freeze({ ...options, ...(options.options ? { options: Object.freeze([...options.options]) } : {}), kind });
      function validate(value: boolean | number | string): void {
        if (kind === 'bool' ? typeof value !== 'boolean' : kind === 'string' || kind === 'enum' ? typeof value !== 'string' : typeof value !== 'number' || !Number.isFinite(value)) throw new TypeError('[Vue source] invalid state value');
        if (spec.options?.length && (typeof value === 'boolean' || !spec.options.includes(value))) throw new RangeError('[Vue source] state value not in options');
        if (typeof value === 'number' && (kind === 'number.range' || (kind === 'number.discrete' && !spec.options?.length)) && (spec.min !== undefined && value < spec.min || spec.max !== undefined && value > spec.max)) throw new RangeError('[Vue source] state value out of range');
        if (typeof value === 'number' && kind === 'number.discrete' && !spec.options?.length && spec.step !== undefined && spec.step > 0 && !Number.isInteger((value - (spec.min ?? 0)) / spec.step)) throw new RangeError('[Vue source] state value violates step');
      }
      if (kind === 'number.range' && (typeof spec.min !== 'number' || typeof spec.max !== 'number' || Number.isNaN(spec.min) || Number.isNaN(spec.max) || spec.min > spec.max)) throw new RangeError('[Vue source] invalid state range');
      let value = initial;
      if (kind === 'number.range' && spec.clamp && typeof value === 'number') value = Math.min(spec.max!, Math.max(spec.min!, value));
      validate(value);
      const subscribers = new Set<(event: __puiVueStateEvent<boolean | number | string>) => void>();
      const handle: __puiVueState<boolean | number | string> = {
        spec,
        get() { __puiVueAlive(); return value; },
        setDefault(next) { __puiVueAlive(); if (!__puiVueSetup) throw new Error('[State] setDefault requires setup'); validate(next); value = next; },
        set(next, reason) {
          __puiVueAlive(); validate(next);
          if (Object.is(value, next)) return;
          const event: __puiVueStateEvent<boolean | number | string> = { type: 'next', prev: value, next, reason };
          value = next;

          

          for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(__puiVueStateQueue, __puiVueStateQueue.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!__puiVueEmittingState) {
  __puiVueEmittingState = true;
  const notificationFailures: unknown[] = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < __puiVueStateQueue.length) {
      try { __puiVueStateQueue[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { __puiVueStateQueue.length = 0; __puiVueEmittingState = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
        },
        subscribe(callback) { __puiVuePublicAlive(); const registration: typeof callback = event => callback(event); subscribers.add(registration); return () => { if (!__puiVueDisposed && !__puiVueDisposing) subscribers.delete(registration); }; },
        unsubscribe(off) { __puiVuePublicAlive(); off(); },
      };
      __puiVueStates.add(handle);
      
      __puiVueInternalSubscriptions.set(handle, callback => {
        const registration: typeof callback = event => callback(event); subscribers.add(registration);
        return () => { subscribers.delete(registration); };
      });
      __puiVueStateCleanup.push(() => subscribers.clear());
      __puiVueAuthored.state(semantic, handle);
      return handle;
    }
    function __puiVueDeclare(key: string, value: unknown): void {
      if (Object.hasOwn(__puiVueExposes, key)) throw new Error('[Vue source] duplicate exposure: ' + key);
      Object.defineProperty(__puiVueExposes, key, { value, enumerable: true });
    }
    function __puiVueExposeState<T>(key: string, handle: __puiVuePublicState<T>): void {
      if (!__puiVueStates.has(handle)) throw new Error('[Vue source] foreign state handle');
      let projection = __puiVuePublicStates.get(handle);
      if (!projection) {

        projection = Object.freeze({ get() { __puiVuePublicAlive(); return handle.get(); }, subscribe: handle.subscribe, unsubscribe: handle.unsubscribe, spec: handle.spec });
        __puiVuePublicStates.set(handle, projection);
      }
      __puiVueDeclare(key, projection);
      __puiVueAuthored.introduceObserved(handle);
    }
    function __puiVueExposeMethod<Args extends unknown[], Result>(key: string, callback: (...args: Args) => Result, project?: (value: Result) => Result): void {

      const boundary = __puiVueMethodChecks[key];
      __puiVueDeclare(key, (...args: unknown[]) => {
        __puiVuePublicAlive();
        if (!boundary.args(args)) throw new TypeError('[Vue source] invalid method arguments: ' + key);
        // The specialized predicate just checked the concrete declared argument tuple.
        const checkedArgs = args as Args;
        const result = __puiVueInvoke('expose-method', () => callback(...checkedArgs));
        if (!boundary.result(result)) throw new TypeError('[Vue source] invalid method result: ' + key);
        return project ? project(result) : result;
      });
    }
    function __puiVueExposeEvent(key: string, _spec?: unknown): void {
      __puiVueEvents.add(key);
      __puiVueDeclare(key, Object.freeze({ kind: 'event' as const }));
    }
    function __puiVueEmit(run: __puiVueRun, key: string, payload?: unknown, options?: unknown): void {
      __puiVueRequireRun(run);
      if (!__puiVueEvents.has(key) || !__puiVueEventChecks[key](payload)) throw new TypeError('[Vue source] undeclared event or invalid payload: ' + key);
      __puiVueContext.emit(key as "beforeEnter" | "afterEnter" | "beforeLeave" | "afterLeave", payload, options);
    }
    function __puiVueValidProp(key: string, value: unknown): boolean {
      const spec = __puiVuePropSpecs[key];
      if (!__puiVuePropChecks[key](value) || spec.options && !spec.options.includes(value) || spec.range && !(typeof value === 'number' && value >= (spec.range.min ?? -Infinity) && value <= (spec.range.max ?? Infinity))) return false;
      try { return spec.validator ? !!spec.validator(value as never) : true; }
      catch { return false; }
    }
    function __puiVueResolveProps(raw: Record<string, unknown>, strict: boolean): Readonly<GeneratedResolvedProps> {
      const next: Record<string, unknown> = Object.create(null);
      for (const key of Object.keys(__puiVuePropSpecs)) {
        const spec = __puiVuePropSpecs[key], provided = Object.hasOwn(raw, key), candidate = raw[key];
        const empty = spec.empty ?? 'fallback';
        if (provided && candidate != null && __puiVueValidProp(key, candidate)) {
          next[key] = candidate; __puiVuePreviousValid[key] = candidate; continue;
        }
        if (provided && candidate == null && empty === 'accept') { next[key] = null; continue; }
        const required = strict && empty === 'error';
        let found = false;
        function take(value: unknown): void {
          if (found || value === undefined || required && value === null || value !== null && !__puiVueValidProp(key, value)) return;
          next[key] = value; found = true;
        }
        if (provided && Object.hasOwn(__puiVuePreviousValid, key)) take(__puiVuePreviousValid[key]);
        for (const layer of __puiVueDefaults) if (Object.hasOwn(layer, key)) take(layer[key]);
        if (Object.hasOwn(spec, 'default')) take(spec.default);
        if (!found && required) throw new TypeError('[Vue source] missing/invalid required prop: ' + key);
        if (!found) next[key] = null;
        if (provided && next[key] !== null) __puiVuePreviousValid[key] = next[key];
      }
      // Every declared key above passed its specialized predicate or canonical null fallback.
      const snapshot = Object.freeze(next) as Readonly<GeneratedResolvedProps>;
      return snapshot;
    }
    function __puiVueDefineProps(declarations: Record<string, __puiVuePropSpec>): void {
      const merged = { ...__puiVuePropSpecs };
      for (const key of Object.keys(declarations)) {
        const incoming = declarations[key], previous = merged[key];
        if (previous?.validator && previous.validator !== incoming.validator) throw new Error('[Vue source] validator replacement or removal is disallowed');
        if (!Object.hasOwn(__puiVuePropChecks, key)) throw new Error('[Vue source] undeclared prop schema');
        const rank = (empty: string) => empty === 'accept' ? 0 : empty === 'error' ? 2 : 1;
        if (previous && incoming.empty && rank(incoming.empty) > rank(previous.empty ?? 'fallback')) throw new Error('[Vue source] props cannot become stricter');
        if (previous?.options && (!incoming.options || previous.options.some((value) => !incoming.options!.includes(value)))) throw new Error('[Vue source] prop options cannot narrow');
        if (previous?.range && ((incoming.range?.min ?? -Infinity) > (previous.range.min ?? -Infinity) || (incoming.range?.max ?? Infinity) < (previous.range.max ?? Infinity))) throw new Error('[Vue source] prop range cannot narrow');
        merged[key] = { ...previous, ...incoming, ...(previous ? { empty: previous.empty ?? 'fallback' } : {}), ...(previous && Object.hasOwn(previous, 'default') ? { default: previous.default } : {}) };
      }
      Object.assign(__puiVuePropSpecs, merged);
      __puiVueProps = __puiVueResolveProps(__puiVueRawProps, false);


    }
    function __puiVueSetDefaults(defaults: Record<string, unknown>): void {
      for (const key of Object.keys(defaults)) if (!Object.hasOwn(__puiVuePropSpecs, key)) throw new Error('[Vue source] defaults require a declared prop');
      __puiVueDefaults.unshift({ ...defaults });
      __puiVueProps = __puiVueResolveProps(__puiVueRawProps, false);


    }
    function __puiVueWatchProps(keys: readonly string[] | null, callback: (run: __puiVueRun, next: Readonly<GeneratedResolvedProps>, previous: Readonly<GeneratedResolvedProps>, info: __puiVueWatchInfo) => void): () => void {
      if (keys && (!keys.length || keys.some((key) => !Object.hasOwn(__puiVuePropSpecs, key)))) throw new Error('[Vue source] watch requires declared prop keys');
      const entry = { keys: keys && [...keys], callback, active: true };
      __puiVueWatchers.push(entry);
      return () => { __puiVueAlive(); entry.active = false; };
    }

    function __puiVueReadProps(run: __puiVueRun): Readonly<GeneratedResolvedProps> { __puiVueRequireRun(run); return __puiVuePropsWindow?.resolved ?? __puiVueProps; }
    function __puiVueReadRawProps(run: __puiVueRun): Readonly<Record<string, unknown>> { __puiVueRequireRun(run); return __puiVuePropsWindow?.raw ?? Object.freeze({ ...__puiVueRawProps }); }
    function __puiVueIsProvided(run: __puiVueRun, key: string): boolean { __puiVueRequireRun(run); return Object.hasOwn(__puiVuePropsWindow?.raw ?? __puiVueRawProps, key); }
    function __puiVueGetHostProps(): Record<string, unknown> {
{ const __puiVueInitialAssociations = _props.instanceAssociations;
    if (__puiVueInitialAssociations !== undefined) {
      if (__puiVueInitialAssociations === null || typeof __puiVueInitialAssociations !== 'object' || Object.getPrototypeOf(__puiVueInitialAssociations) !== Object.prototype)
        throw new TypeError('[InstanceAssociations] expected a plain record');
      for (const key of Reflect.ownKeys(__puiVueInitialAssociations)) if (key !== 'controlLabel')
        throw new TypeError('[InstanceAssociations] unknown association key');
      if (Object.prototype.hasOwnProperty.call(__puiVueInitialAssociations, 'controlLabel') && Reflect.get(__puiVueInitialAssociations, 'controlLabel') != null)
        throw new Error('[ControlLabel] this Prototype has not declared Label or target participation');
    }
  }
      // Read the authored host snapshot, bypassing Vue Boolean casts and camelization.
      const raw: Record<string, unknown> = Object.create(null);
      for (const key of Object.keys(__puiVueInstance.vnode.props ?? {})) {
        const value = __puiVueInstance.vnode.props![key];
        if (['key', 'ref', 'ref_for', 'ref_key', 'instanceAssociations', 'instance-associations'].includes(key) || key.startsWith('onVnode')) continue;
        if (!Object.hasOwn(__puiVuePropChecks, key) && (
          ['class', 'hostClass', 'surfaceClass', 'style', 'hostStyle', 'surfaceStyle'].includes(key) ||
          /^on[A-Z]/.test(key) && typeof value === 'function'
        )) continue;
        raw[key] = value;
      }
      return raw;
    }
    function __puiVueNotifyProps(): void {
      if (__puiVueDisposed || __puiVueDisposing) return;
{ const __puiVueAssociations = _props.instanceAssociations;
    if (__puiVueAssociations !== undefined) {
      if (__puiVueAssociations === null || typeof __puiVueAssociations !== 'object' || Object.getPrototypeOf(__puiVueAssociations) !== Object.prototype)
        throw new TypeError('[InstanceAssociations] expected a plain record');
      for (const key of Reflect.ownKeys(__puiVueAssociations)) if (key !== 'controlLabel')
        throw new TypeError('[InstanceAssociations] unknown association key');
      if (Object.prototype.hasOwnProperty.call(__puiVueAssociations, 'controlLabel') && Reflect.get(__puiVueAssociations, 'controlLabel') != null)
        throw new Error('[ControlLabel] this Prototype has not declared Label or target participation');
    }
  }
      const raw = __puiVueGetHostProps();
      const changed = Object.keys({ ...__puiVueRawProps, ...raw }).some((key) => Object.hasOwn(raw, key) !== Object.hasOwn(__puiVueRawProps, key) || !Object.is(raw[key], __puiVueRawProps[key]));
      if (!changed) return;

      const previous = __puiVueProps;
      const next = __puiVueResolveProps(raw, true);
      __puiVueRawProps = raw; __puiVueProps = next;


      const previousWindow = __puiVuePropsWindow;
      __puiVuePropsWindow = {raw: Object.freeze({...raw}), resolved: next};
      try {
      const all = Object.keys(__puiVuePropSpecs).filter((key) => !Object.is(Reflect.get(previous, key), Reflect.get(next, key)));

      for (const watcher of __puiVueWatchers) {
        if (!watcher.active) continue;
        const matched = watcher.keys ? watcher.keys.filter((key) => all.includes(key)) : all;
        if (matched.length) watcher.callback(__puiVueRunValue, next, previous, { changedKeysAll: all, changedKeysMatched: matched });
      }

      } finally { __puiVuePropsWindow = previousWindow; }
    }
    function __puiVueActiveFrame(frame: __puiVueFrame): void {
      __puiVueAlive();
      if (!frame.epoch.active || frame.epoch !== __puiVueCurrentEpoch || !__puiVuePresent.value) throw new Error('[Vue source] stale view work');
    }
    function __puiVueReadFrameProps(frame: __puiVueFrame): Readonly<GeneratedResolvedProps> { __puiVueActiveFrame(frame); return __puiVueProps; }
    function __puiVueReadFrameRawProps(frame: __puiVueFrame): Readonly<Record<string, unknown>> { __puiVueActiveFrame(frame); return Object.freeze({ ...__puiVueRawProps }); }
    function __puiVueFrameProvided(frame: __puiVueFrame, key: string): boolean { __puiVueActiveFrame(frame); return Object.hasOwn(__puiVueRawProps, key); }
    function __puiVueChildren(input: unknown): __puiVueVue.VNode | string | number | null | __puiVueVue.VNodeArrayChildren {
      if (input === null) return null;
      if (Array.isArray(input)) return input.map(__puiVueChildren);
      if (typeof input === 'string' || typeof input === 'number' || __puiVueVue.isVNode(input)) return input;
      throw new TypeError('[Vue source] invalid template child');
    }
    function __puiVueElement(frame: __puiVueFrame, tag: string, ...args: unknown[]): __puiVueVue.VNode {
      __puiVueActiveFrame(frame);
      let children: unknown = null;
      let attributes: Record<string, string> | null = null;
      if (args.length > 1 || args.length === 1 && args[0] !== null && typeof args[0] === 'object' && !Array.isArray(args[0]) && !__puiVueVue.isVNode(args[0])) {
        if (!__puiVueIsRecord(args[0])) throw new Error('[Vue source] unsupported template props');
        const keys = Object.keys(args[0]);
        if (keys.length) throw new Error('[Vue source] unsupported template props');
        children = args.length > 1 ? args[1] : null;
      } else if (args.length) children = args[0];
      const normalized = __puiVueChildren(children);
      return __puiVueVue.h(tag, attributes, normalized ?? undefined);
    }
    function __puiVueSlot(frame: __puiVueFrame): __puiVueVue.VNode {
      __puiVueActiveFrame(frame);
      if (frame.slotUsed) throw new Error('[Vue source] multiple slots are not supported');
      frame.slotUsed = true;
      return __puiVueVue.h(__puiVueSlotView, { read: () => {
        __puiVueSlotRevision.value;
        if (__puiVueDisposed || __puiVueDisposing || !frame.epoch.active || frame.epoch !== __puiVueCurrentEpoch || !__puiVuePresent.value) return null;
        return __puiVueContext.slots.default?.() ?? null;
      } });
    }

    // Source "transition/machine.ts":42:1
    const __puiModule0 = (driver: { "getState": () => "closed" | "preparing" | "entering" | "entered" | "leaving"; "setState": (state: "closed" | "preparing" | "entering" | "entered" | "leaving") => void; "getInterrupt": () => "reverse" | "wait" | "immediate"; "requiresColdPreparation"?: () => boolean; "getCompletion"?: () => (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number })); "publishPresentation"?: (frame: { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) => void; "settlePresentation"?: (outcome: "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed") => void; "getDuration": (state: "entering" | "leaving") => number; "schedule": (durationMs: number, callback: () => void) => __puiVueDelayTask; "setViewPresent": (present: boolean) => void; "emit": (event: "beforeEnter" | "afterEnter" | "beforeLeave" | "afterLeave") => void }): { "initialize": (open: boolean, appear: boolean) => void; "setTarget": (open: boolean) => void; "enter": () => void; "leave": () => void; "complete": () => void; "completePresentation": (attempt: { readonly "ownerEpoch": number; readonly "phaseAttempt": number }, isCurrent?: () => boolean) => boolean; "capturePreparation": () => ((() => void) | (null)); "mounted": () => void; "unmounted": () => void; "dispose": () => void } => {
      // Source "transition/machine.ts":43:7
      let targetOpen: boolean = false;
      // Source "transition/machine.ts":44:7
      let viewMounted: boolean = false;
      // Source "transition/machine.ts":45:7
      let queuedIntent: "enter" | "leave" | null = (null as "enter" | "leave" | null);
      // Source "transition/machine.ts":46:7
      let pendingTask: ((__puiVueDelayTask) | (null)) = (null as ((__puiVueDelayTask) | (null)));
      // Source "transition/machine.ts":47:7
      let generation: number = 0;
      // Source "transition/machine.ts":48:7
      let ownerEpoch: number = 0;
      // Source "transition/machine.ts":49:7
      let phaseAttempt: number = 0;
      // Source "transition/machine.ts":50:7
      let revision: number = 0;
      // Source "transition/machine.ts":51:7
      let publishing: boolean = false;
      // Source "transition/machine.ts":52:7
      let stagedState: "closed" | "preparing" | "entering" | "entered" | "leaving" | null = (null as "closed" | "preparing" | "entering" | "entered" | "leaving" | null);
      // Source "transition/machine.ts":53:7
      let acknowledged: boolean = false;
      // Source "transition/machine.ts":54:7
      let acknowledgementCurrent: ((() => boolean) | (null)) = (null as ((() => boolean) | (null)));
      // Source "transition/machine.ts":55:7
      let invalidDuration: boolean = false;
      // Source "transition/machine.ts":56:7
      let publicationFailed: boolean = false;
      // Source "transition/machine.ts":57:7
      let activePresentation: (({ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) | (null)) = (null as (({ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) | (null)));
      // Source "transition/machine.ts":58:9
      const sameAttempt = (attempt: { readonly "ownerEpoch": number; readonly "phaseAttempt": number }): boolean => {
        // Source "transition/machine.ts":59:5
        return (((!terminal) && (((activePresentation)?.["attempt"])?.["ownerEpoch"] === (attempt)["ownerEpoch"])) && ((((activePresentation as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"])["phaseAttempt"] === (attempt)["phaseAttempt"]));
      };
      // Source "transition/machine.ts":62:9
      const cancelTask = (): void => {
        // Source "transition/machine.ts":63:11
        const task = pendingTask;
        // Source "transition/machine.ts":64:5
        (pendingTask = null);
        // Source "transition/machine.ts":65:5
        try {
          // Source "transition/machine.ts":66:7
          ((__puiVueOptionalReceiver: ((__puiVueDelayTask) | (null))) => __puiVueOptionalReceiver == null ? undefined : __puiVueOptionalReceiver.cancel())(task);
        } catch {
        }
      };
      // Source "transition/machine.ts":71:7
      let terminal: boolean = false;
      // Source "transition/machine.ts":72:7
      let operationVersion: number = 0;
      // Source "transition/machine.ts":73:7
      let starting: { "kind": "enter" | "leave"; "version": number } | null = (null as { "kind": "enter" | "leave"; "version": number } | null);
      // Source "transition/machine.ts":74:9
      const currentOperation = (version: number): boolean => {
        // Source "transition/machine.ts":74:49
        return ((!terminal) && (operationVersion === version));
      };
      // Source "transition/machine.ts":75:9
      const updateTarget = (open: boolean): void => {
        // Source "transition/machine.ts":76:5
        if ((targetOpen !== open)) {
          // Source "transition/machine.ts":76:30
          (operationVersion = (operationVersion + 1));
        }
        // Source "transition/machine.ts":77:5
        (targetOpen = open);
      };
      // Source "transition/machine.ts":85:7
      let preparation: { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean } | null = (null as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean } | null);
      // Source "transition/machine.ts":87:9
      const cancelPreparation = (): void => {
        // Source "transition/machine.ts":88:5
        (preparation = null);
      };
      // Source "transition/machine.ts":90:9
      const isPreparing = (attempt: { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }): boolean => {
        // Source "transition/machine.ts":91:5
        return ((((!terminal) && targetOpen) && (preparation === attempt)) && (((driver)["getState"])() === "preparing"));
      };
      // Source "transition/machine.ts":93:9
      const finishPreparation = (attempt: { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }): void => {
        // Source "transition/machine.ts":94:5
        if ((((((!(isPreparing)(attempt)) || (!(attempt)["presentRequested"])) || (!viewMounted)) || (!(attempt)["ready"])) || (attempt)["finishing"])) {
          // Source "transition/machine.ts":101:7
          return;
        }
        // Source "transition/machine.ts":102:5
        ((attempt)["finishing"] = true);
        // Source "transition/machine.ts":103:5
        if ((!(attempt)["animate"])) {
          // Source "transition/machine.ts":104:7
          (preparation = null);
          // Source "transition/machine.ts":105:7
          (setState)("entered");
          // Source "transition/machine.ts":106:7
          return;
        }
        // Source "transition/machine.ts":108:5
        ((driver)["emit"])("beforeEnter");
        // Source "transition/machine.ts":109:5
        if (((!(isPreparing)(attempt)) || (!viewMounted))) {
          // Source "transition/machine.ts":109:48
          return;
        }
        // Source "transition/machine.ts":110:11
        const frame = (setState)("entering");
        // Source "transition/machine.ts":111:5
        if (((((frame && (activePresentation === (frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))) && (!terminal)) && viewMounted) && (((driver)["getState"])() === "entering"))) {
          // Source "transition/machine.ts":118:7
          if ((preparation === attempt)) {
            // Source "transition/machine.ts":118:36
            (preparation = null);
          }
          // Source "transition/machine.ts":119:7
          (armCompletion)("entering");
          // Source "transition/machine.ts":120:7
          return;
        }
        // Source "transition/machine.ts":122:5
        if ((((((preparation !== attempt) || terminal) || (!targetOpen)) || (!viewMounted)) || (((driver)["getState"])() !== "entering"))) {
          // Source "transition/machine.ts":129:7
          if ((preparation === attempt)) {
            // Source "transition/machine.ts":129:36
            (preparation = null);
          }
          // Source "transition/machine.ts":130:7
          return;
        }
        // Source "transition/machine.ts":132:5
        (preparation = null);
        // Source "transition/machine.ts":133:5
        (armCompletion)("entering");
      };
      // Source "transition/machine.ts":136:9
      const beginPreparation = (animate: boolean): void => {
        // Source "transition/machine.ts":137:11
        const operation = (++operationVersion);
        // Source "transition/machine.ts":138:5
        (invalidateCompletion)();
        // Source "transition/machine.ts":139:5
        if ((!((!terminal) && (operationVersion === operation)))) {
          // Source "transition/machine.ts":139:39
          return;
        }
        // Source "transition/machine.ts":140:5
        (queuedIntent = null);
        // Source "transition/machine.ts":141:11
        const attempt = ({ ["ready"]: false, ["finishing"]: false, ["animate"]: animate, ["presentRequested"]: false } as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean });
        // Source "transition/machine.ts":147:5
        (preparation = attempt);
        // Source "transition/machine.ts":148:5
        (setState)("preparing");
        // Source "transition/machine.ts":149:5
        if ((!(isPreparing)(attempt))) {
          // Source "transition/machine.ts":149:32
          return;
        }
        // Source "transition/machine.ts":150:5
        ((driver)["setViewPresent"])(true);
        // Source "transition/machine.ts":151:5
        if ((!(isPreparing)(attempt))) {
          // Source "transition/machine.ts":151:32
          return;
        }
        // Source "transition/machine.ts":152:5
        ((attempt)["presentRequested"] = true);
        // Source "transition/machine.ts":153:5
        (finishPreparation)(attempt);
      };
      // Source "transition/machine.ts":156:9
      const invalidateCompletion = (): void => {
        // Source "transition/machine.ts":157:5
        (generation = (generation + 1));
        // Source "transition/machine.ts":158:5
        (activePresentation = null);
        // Source "transition/machine.ts":159:5
        (acknowledged = false);
        // Source "transition/machine.ts":160:5
        (acknowledgementCurrent = null);
        // Source "transition/machine.ts":161:5
        (cancelTask)();
      };
      // Source "transition/machine.ts":164:9
      const setState = (state: "closed" | "preparing" | "entering" | "entered" | "leaving"): (({ readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) | (undefined)) => {
        // Source "transition/machine.ts":165:11
        const policy = (((driver)["getCompletion"])?.() ?? "timer");
        // Source "transition/machine.ts":166:5
        if ((policy === "timer")) {
          // Source "transition/machine.ts":167:7
          ((driver)["setState"])(state);
          // Source "transition/machine.ts":168:7
          return;
        }
        // Source "transition/machine.ts":170:11
        const moving = ((state === "entering") || ((state as "closed" | "preparing" | "entered" | "leaving") === "leaving"));
        // Source "transition/machine.ts":171:11
        const duration = (moving ? ((driver)["getDuration"])((state as "entering" | "leaving")) : 0);
        // Source "transition/machine.ts":172:5
        (invalidDuration = (((!Number.isFinite(duration)) || (duration < 0)) || (moving && (duration >= ((policy as { readonly "kind": "presentation"; readonly "timeoutMs": number }))["timeoutMs"]))));
        // Source "transition/machine.ts":174:5
        (publicationFailed = false);
        // Source "transition/machine.ts":175:11
        const frame = ((Object.freeze({ ["revision"]: (++revision), ["phase"]: state, ["attempt"]: (moving ? (Object.freeze({ ["ownerEpoch"]: ownerEpoch, ["phaseAttempt"]: (++phaseAttempt) }) as { "ownerEpoch": number; "phaseAttempt": number }) : null), ["completion"]: "presentation", ["durationMs"]: ((Number.isFinite(duration) && (duration >= 0)) ? duration : ((policy as { readonly "kind": "presentation"; readonly "timeoutMs": number }))["timeoutMs"]), ["timeoutMs"]: ((policy as { readonly "kind": "presentation"; readonly "timeoutMs": number }))["timeoutMs"] }) as { "revision": number; "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; "attempt": { "ownerEpoch": number; "phaseAttempt": number } | null; "completion": "presentation"; "durationMs": number | 0; "timeoutMs": number }) as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null });
        // Source "transition/machine.ts":184:5
        (activePresentation = (moving ? frame : null));
        // Source "transition/machine.ts":185:5
        (acknowledged = false);
        // Source "transition/machine.ts":186:11
        const operation = operationVersion;
        // Source "transition/machine.ts":187:11
        const previousStage = stagedState;
        // Source "transition/machine.ts":188:5
        (stagedState = state);
        // Source "transition/machine.ts":189:5
        (publishing = true);
        // Source "transition/machine.ts":190:5
        try {
          // Source "transition/machine.ts":191:7
          try {
            // Source "transition/machine.ts":192:9
            ((driver)["publishPresentation"])?.(frame);
          } catch {
            // Source "transition/machine.ts":194:9
            (publicationFailed = true);
          }
          // Source "transition/machine.ts":196:13
          const waitingOnSameAttempt = (((moving && (activePresentation === frame)) && (((driver)["getInterrupt"])() === "wait")) && (!terminal));
          // Source "transition/machine.ts":198:7
          if ((((!((!terminal) && (operationVersion === operation))) && (!waitingOnSameAttempt)) || (moving && (activePresentation !== frame)))) {
            // Source "transition/machine.ts":204:9
            if ((((!terminal) && moving) && (activePresentation === frame))) {
              // Source "transition/machine.ts":205:17
              const repairOperation = operationVersion;
              // Source "transition/machine.ts":206:11
              (invalidateCompletion)();
              // Source "transition/machine.ts":207:11
              if ((!((!terminal) && (operationVersion === repairOperation)))) {
                // Source "transition/machine.ts":207:51
                return;
              }
              // Source "transition/machine.ts":208:17
              const actual = ((driver)["getState"])();
              // Source "transition/machine.ts":209:17
              const repaired = (setState)(actual);
              // Source "transition/machine.ts":210:11
              if (((repaired && (activePresentation === (repaired as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))) && ((actual === "entering") || ((actual as "closed" | "preparing" | "entered" | "leaving") === "leaving")))) {
                // Source "transition/machine.ts":215:13
                (armCompletion)((actual as "entering" | "leaving"));
              }
            }
            // Source "transition/machine.ts":217:9
            return;
          }
          // Source "transition/machine.ts":219:7
          ((driver)["setState"])(state);
        } finally {
          // Source "transition/machine.ts":221:7
          (stagedState = previousStage);
          // Source "transition/machine.ts":222:7
          (publishing = (previousStage !== null));
        }
        // Source "transition/machine.ts":224:5
        if (((((((((moving && acknowledged) && (activePresentation === frame)) && (!terminal)) && (((driver)["getState"])() === state)) && (acknowledgementCurrent)?.()) && ((activePresentation as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) === frame)) && (!terminal)) && (((driver)["getState"])() === state))) {
          // Source "transition/machine.ts":235:7
          (completeCurrent)(true);
        }
        // Source "transition/machine.ts":236:5
        return frame;
      };
      // Source "transition/machine.ts":239:9
      const settlePresentation = (frame: { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }, outcome: "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed"): void => {
        // Source "transition/machine.ts":240:5
        if (((!(frame)["attempt"]) || (!(sameAttempt)(((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"])))) {
          // Source "transition/machine.ts":240:56
          return;
        }
        // Source "transition/machine.ts":241:5
        try {
          // Source "transition/machine.ts":242:7
          ((driver)["settlePresentation"])?.(outcome);
        } catch {
        }
        // Source "transition/machine.ts":246:5
        if ((sameAttempt)(((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"])) {
          // Source "transition/machine.ts":246:37
          (completeCurrent)(true);
        }
      };
      // Source "transition/machine.ts":249:9
      const armCompletion = (state: "entering" | "leaving"): void => {
        // Source "transition/machine.ts":250:11
        const frame = activePresentation;
        // Source "transition/machine.ts":251:5
        if ((frame)?.["attempt"]) {
          // Source "transition/machine.ts":252:7
          if (invalidDuration) {
            // Source "transition/machine.ts":253:9
            (settlePresentation)((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }), "invalid-policy");
            // Source "transition/machine.ts":254:9
            return;
          }
          // Source "transition/machine.ts":256:7
          if (publicationFailed) {
            // Source "transition/machine.ts":257:9
            (settlePresentation)((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }), "projection-failed");
            // Source "transition/machine.ts":258:9
            return;
          }
          // Source "transition/machine.ts":260:7
          if ((((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["durationMs"] === 0)) {
            // Source "transition/machine.ts":261:9
            (settlePresentation)((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": 0; readonly "timeoutMs": number | null }), "zero-duration");
            // Source "transition/machine.ts":262:9
            return;
          }
          // Source "transition/machine.ts":264:7
          try {
            // Source "transition/machine.ts":265:15
            const task = ((driver)["schedule"])((((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["timeoutMs"] as number), (): void => {
              // Source "transition/machine.ts":266:11
              if (((!((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"]) || (!(sameAttempt)(((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"])))) {
                // Source "transition/machine.ts":266:62
                return;
              }
              // Source "transition/machine.ts":267:11
              (pendingTask = null);
              // Source "transition/machine.ts":268:11
              (settlePresentation)((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }), "deadline");
            });
            // Source "transition/machine.ts":270:9
            if ((sameAttempt)(((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))["attempt"])) {
              // Source "transition/machine.ts":270:41
              (pendingTask = task);
            } else {
              // Source "transition/machine.ts":272:11
              try {
                // Source "transition/machine.ts":273:13
                task.cancel();
              } catch {
              }
            }
          } catch {
            // Source "transition/machine.ts":277:9
            (settlePresentation)((frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }), "scheduler-failed");
          }
          // Source "transition/machine.ts":279:7
          return;
        }
        // Source "transition/machine.ts":281:5
        (invalidateCompletion)();
        // Source "transition/machine.ts":282:11
        const activeGeneration = generation;
        // Source "transition/machine.ts":283:5
        (pendingTask = ((driver)["schedule"])(((driver)["getDuration"])(state), (): void => {
          // Source "transition/machine.ts":284:7
          if (((activeGeneration !== generation) || (((driver)["getState"])() !== state))) {
            // Source "transition/machine.ts":284:75
            return;
          }
          // Source "transition/machine.ts":285:7
          (pendingTask = null);
          // Source "transition/machine.ts":286:7
          (completeCurrent)(true);
        }));
      };
      // Source "transition/machine.ts":290:9
      const beginEnter = (cold: boolean = true): void => {
        // Source "transition/machine.ts":291:5
        if ((terminal || (!targetOpen))) {
          // Source "transition/machine.ts":291:34
          return;
        }
        // Source "transition/machine.ts":292:5
        if ((((starting)?.["kind"] === "enter") && (currentOperation)(((starting as { "kind": "enter"; "version": number }))["version"]))) {
          // Source "transition/machine.ts":292:75
          return;
        }
        // Source "transition/machine.ts":293:5
        if ((cold && ((driver)["requiresColdPreparation"])?.())) {
          // Source "transition/machine.ts":294:7
          (beginPreparation)(true);
          // Source "transition/machine.ts":295:7
          return;
        }
        // Source "transition/machine.ts":297:11
        const operation: { "kind": "enter"; "version": number } = { ["kind"]: "enter", ["version"]: (++operationVersion) };
        // Source "transition/machine.ts":298:5
        (starting = operation);
        // Source "transition/machine.ts":299:11
        const current = (): boolean => {
          // Source "transition/machine.ts":299:27
          return ((currentOperation)((operation)["version"]) && targetOpen);
        };
        // Source "transition/machine.ts":300:5
        try {
          // Source "transition/machine.ts":301:7
          ((driver)["setViewPresent"])(true);
          // Source "transition/machine.ts":302:7
          if (((!(current)()) || (!viewMounted))) {
            // Source "transition/machine.ts":302:39
            return;
          }
          // Source "transition/machine.ts":303:7
          (queuedIntent = null);
          // Source "transition/machine.ts":304:7
          ((driver)["emit"])("beforeEnter");
          // Source "transition/machine.ts":305:7
          if (((!(current)()) || (!viewMounted))) {
            // Source "transition/machine.ts":305:39
            return;
          }
          // Source "transition/machine.ts":306:7
          (invalidateCompletion)();
          // Source "transition/machine.ts":307:7
          if ((!(current)())) {
            // Source "transition/machine.ts":307:23
            return;
          }
          // Source "transition/machine.ts":308:13
          const frame = (setState)("entering");
          // Source "transition/machine.ts":309:7
          if ((((((frame && (activePresentation === (frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))) && (((activePresentation as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))?.["phase"] === "entering")) && (!terminal)) && viewMounted) && (((driver)["getState"])() === "entering"))) {
            // Source "transition/machine.ts":317:9
            (armCompletion)("entering");
            // Source "transition/machine.ts":318:9
            return;
          }
          // Source "transition/machine.ts":320:7
          if ((((!(current)()) || (!viewMounted)) || (((driver)["getState"])() !== "entering"))) {
            // Source "transition/machine.ts":320:75
            return;
          }
          // Source "transition/machine.ts":321:7
          (armCompletion)("entering");
        } finally {
          // Source "transition/machine.ts":323:7
          if ((starting === operation)) {
            // Source "transition/machine.ts":323:35
            (starting = null);
          }
        }
      };
      // Source "transition/machine.ts":327:9
      const beginLeave = (): void => {
        // Source "transition/machine.ts":328:5
        if ((terminal || targetOpen)) {
          // Source "transition/machine.ts":328:33
          return;
        }
        // Source "transition/machine.ts":329:11
        const operation: { "kind": "leave"; "version": number } = { ["kind"]: "leave", ["version"]: (++operationVersion) };
        // Source "transition/machine.ts":330:5
        (starting = operation);
        // Source "transition/machine.ts":331:11
        const current = (): boolean => {
          // Source "transition/machine.ts":331:27
          return ((currentOperation)((operation)["version"]) && (!targetOpen));
        };
        // Source "transition/machine.ts":332:5
        try {
          // Source "transition/machine.ts":333:7
          (queuedIntent = null);
          // Source "transition/machine.ts":334:7
          ((driver)["emit"])("beforeLeave");
          // Source "transition/machine.ts":335:7
          if ((!(current)())) {
            // Source "transition/machine.ts":335:23
            return;
          }
          // Source "transition/machine.ts":336:7
          (invalidateCompletion)();
          // Source "transition/machine.ts":337:7
          if ((!(current)())) {
            // Source "transition/machine.ts":337:23
            return;
          }
          // Source "transition/machine.ts":338:13
          const frame = (setState)("leaving");
          // Source "transition/machine.ts":339:7
          if (((((frame && (activePresentation === (frame as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))) && (((activePresentation as { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }))?.["phase"] === "leaving")) && (!terminal)) && (((driver)["getState"])() === "leaving"))) {
            // Source "transition/machine.ts":346:9
            (armCompletion)("leaving");
            // Source "transition/machine.ts":347:9
            return;
          }
          // Source "transition/machine.ts":349:7
          if (((!(current)()) || (((driver)["getState"])() !== "leaving"))) {
            // Source "transition/machine.ts":349:58
            return;
          }
          // Source "transition/machine.ts":350:7
          (armCompletion)("leaving");
        } finally {
          // Source "transition/machine.ts":352:7
          if ((starting === operation)) {
            // Source "transition/machine.ts":352:35
            (starting = null);
          }
        }
      };
      // Source "transition/machine.ts":356:9
      const consumeQueuedIntent = (): void => {
        // Source "transition/machine.ts":357:11
        const next = queuedIntent;
        // Source "transition/machine.ts":358:5
        (queuedIntent = null);
        // Source "transition/machine.ts":359:5
        if ((next === "enter")) {
          // Source "transition/machine.ts":359:27
          (enter)();
        } else {
          // Source "transition/machine.ts":360:10
          if (((next as "leave" | null) === "leave")) {
            // Source "transition/machine.ts":360:32
            (leave)();
          }
        }
      };
      // Source "transition/machine.ts":363:9
      const completeCurrent = (consumeQueue: boolean): boolean => {
        // Source "transition/machine.ts":364:11
        const current = ((driver)["getState"])();
        // Source "transition/machine.ts":365:5
        if (((current !== "entering") && ((current as "closed" | "preparing" | "entered" | "leaving") !== "leaving"))) {
          // Source "transition/machine.ts":365:58
          return false;
        }
        // Source "transition/machine.ts":366:11
        const operation = (++operationVersion);
        // Source "transition/machine.ts":367:5
        (invalidateCompletion)();
        // Source "transition/machine.ts":368:5
        if ((!((!terminal) && (operationVersion === operation)))) {
          // Source "transition/machine.ts":368:39
          return false;
        }
        // Source "transition/machine.ts":370:5
        if (((current as "entering" | "leaving") === "entering")) {
          // Source "transition/machine.ts":371:7
          (setState)("entered");
          // Source "transition/machine.ts":372:7
          if (((!((!terminal) && (operationVersion === operation))) || (((driver)["getState"])() !== "entered"))) {
            // Source "transition/machine.ts":372:76
            return false;
          }
          // Source "transition/machine.ts":373:7
          ((driver)["emit"])("afterEnter");
        } else {
          // Source "transition/machine.ts":375:7
          (setState)("closed");
          // Source "transition/machine.ts":376:7
          if (((!((!terminal) && (operationVersion === operation))) || (((driver)["getState"])() !== "closed"))) {
            // Source "transition/machine.ts":376:75
            return false;
          }
          // Source "transition/machine.ts":377:7
          ((driver)["emit"])("afterLeave");
          // Source "transition/machine.ts":378:7
          if (((!((!terminal) && (operationVersion === operation))) || (((driver)["getState"])() !== "closed"))) {
            // Source "transition/machine.ts":378:75
            return false;
          }
          // Source "transition/machine.ts":379:7
          ((driver)["setViewPresent"])(false);
        }
        // Source "transition/machine.ts":382:5
        if ((consumeQueue && ((!terminal) && (operationVersion === operation)))) {
          // Source "transition/machine.ts":382:54
          (consumeQueuedIntent)();
        }
        // Source "transition/machine.ts":383:5
        return ((!terminal) && (operationVersion === operation));
      };
      // Source "transition/machine.ts":386:9
      const enter = (): void => {
        // Source "transition/machine.ts":387:5
        if (terminal) {
          // Source "transition/machine.ts":387:19
          return;
        }
        // Source "transition/machine.ts":388:5
        (updateTarget)(true);
        // Source "transition/machine.ts":389:5
        if ((((starting)?.["kind"] === "enter") && (currentOperation)(((starting as { "kind": "enter"; "version": number }))["version"]))) {
          // Source "transition/machine.ts":389:75
          return;
        }
        // Source "transition/machine.ts":390:11
        const current = (stagedState ?? ((driver)["getState"])());
        // Source "transition/machine.ts":391:5
        if (((current === "entered") || ((current as "closed" | "preparing" | "entering" | "leaving") === "preparing"))) {
          // Source "transition/machine.ts":391:59
          return;
        }
        // Source "transition/machine.ts":393:5
        if (((current as "closed" | "entering" | "leaving") === "closed")) {
          // Source "transition/machine.ts":394:7
          (beginEnter)();
          // Source "transition/machine.ts":395:7
          return;
        }
        // Source "transition/machine.ts":398:5
        if (((current as "entering" | "leaving") === "entering")) {
          // Source "transition/machine.ts":399:7
          if (((((((starting as { "kind": "leave"; "version": number } | null | { "kind": "enter"; "version": number }))?.["kind"] === "leave") && (!activePresentation)) && (((driver)["getCompletion"])?.() !== "timer")) && (driver)["getCompletion"])) {
            // Source "transition/machine.ts":405:9
            (beginEnter)(false);
            // Source "transition/machine.ts":406:9
            return;
          }
          // Source "transition/machine.ts":408:7
          if ((((driver)["getInterrupt"])() === "wait")) {
            // Source "transition/machine.ts":408:45
            (queuedIntent = null);
          }
          // Source "transition/machine.ts":409:7
          return;
        }
        // Source "transition/machine.ts":412:11
        const interrupt = ((driver)["getInterrupt"])();
        // Source "transition/machine.ts":413:5
        if ((interrupt === "wait")) {
          // Source "transition/machine.ts":414:7
          (queuedIntent = "enter");
        } else {
          // Source "transition/machine.ts":415:12
          if (((interrupt as "reverse" | "immediate") === "immediate")) {
            // Source "transition/machine.ts":416:7
            if ((completeCurrent)(false)) {
              // Source "transition/machine.ts":416:35
              (beginEnter)(false);
            }
          } else {
            // Source "transition/machine.ts":418:7
            (beginEnter)(false);
          }
        }
      };
      // Source "transition/machine.ts":422:9
      const leave = (): void => {
        // Source "transition/machine.ts":423:5
        if (terminal) {
          // Source "transition/machine.ts":423:19
          return;
        }
        // Source "transition/machine.ts":424:5
        (updateTarget)(false);
        // Source "transition/machine.ts":425:5
        if ((((starting)?.["kind"] === "leave") && (currentOperation)(((starting as { "kind": "leave"; "version": number }))["version"]))) {
          // Source "transition/machine.ts":425:75
          return;
        }
        // Source "transition/machine.ts":426:11
        const current = (stagedState ?? ((driver)["getState"])());
        // Source "transition/machine.ts":427:5
        if ((current === "preparing")) {
          // Source "transition/machine.ts":428:7
          (cancelPreparation)();
          // Source "transition/machine.ts":429:7
          (invalidateCompletion)();
          // Source "transition/machine.ts":430:7
          (queuedIntent = null);
          // Source "transition/machine.ts":431:7
          (setState)("closed");
          // Source "transition/machine.ts":432:7
          if (((!targetOpen) && (((driver)["getState"])() === "closed"))) {
            // Source "transition/machine.ts":432:58
            ((driver)["setViewPresent"])(false);
          }
          // Source "transition/machine.ts":433:7
          return;
        }
        // Source "transition/machine.ts":436:5
        if (((current as "closed" | "entering" | "entered" | "leaving") === "closed")) {
          // Source "transition/machine.ts":437:7
          ((driver)["setViewPresent"])(false);
          // Source "transition/machine.ts":438:7
          return;
        }
        // Source "transition/machine.ts":441:5
        if (((current as "entering" | "entered" | "leaving") === "leaving")) {
          // Source "transition/machine.ts":442:7
          if (((((((starting as { "kind": "enter"; "version": number } | null | { "kind": "leave"; "version": number }))?.["kind"] === "enter") && (!activePresentation)) && (((driver)["getCompletion"])?.() !== "timer")) && (driver)["getCompletion"])) {
            // Source "transition/machine.ts":448:9
            (beginLeave)();
            // Source "transition/machine.ts":449:9
            return;
          }
          // Source "transition/machine.ts":451:7
          if ((((driver)["getInterrupt"])() === "wait")) {
            // Source "transition/machine.ts":451:45
            (queuedIntent = null);
          }
          // Source "transition/machine.ts":452:7
          return;
        }
        // Source "transition/machine.ts":455:5
        if (((current as "entering" | "entered") === "entered")) {
          // Source "transition/machine.ts":456:7
          (beginLeave)();
          // Source "transition/machine.ts":457:7
          return;
        }
        // Source "transition/machine.ts":460:11
        const interrupt = ((driver)["getInterrupt"])();
        // Source "transition/machine.ts":461:5
        if ((interrupt === "wait")) {
          // Source "transition/machine.ts":462:7
          (queuedIntent = "leave");
        } else {
          // Source "transition/machine.ts":463:12
          if (((interrupt as "reverse" | "immediate") === "immediate")) {
            // Source "transition/machine.ts":464:7
            if ((completeCurrent)(false)) {
              // Source "transition/machine.ts":464:35
              (beginLeave)();
            }
          } else {
            // Source "transition/machine.ts":466:7
            (beginLeave)();
          }
        }
      };
      // Source "transition/machine.ts":470:9
      const initialize = (open: boolean, appear: boolean): void => {
        // Source "transition/machine.ts":471:5
        if (terminal) {
          // Source "transition/machine.ts":471:19
          return;
        }
        // Source "transition/machine.ts":472:11
        const operation = (++operationVersion);
        // Source "transition/machine.ts":473:5
        (ownerEpoch = (ownerEpoch + 1));
        // Source "transition/machine.ts":474:5
        (cancelPreparation)();
        // Source "transition/machine.ts":475:5
        (targetOpen = open);
        // Source "transition/machine.ts":476:5
        (queuedIntent = null);
        // Source "transition/machine.ts":477:5
        (invalidateCompletion)();
        // Source "transition/machine.ts":478:5
        if ((!((!terminal) && (operationVersion === operation)))) {
          // Source "transition/machine.ts":478:39
          return;
        }
        // Source "transition/machine.ts":480:5
        if ((!open)) {
          // Source "transition/machine.ts":481:7
          (setState)("closed");
          // Source "transition/machine.ts":482:7
          if (((!((!terminal) && (operationVersion === operation))) || targetOpen)) {
            // Source "transition/machine.ts":482:55
            return;
          }
          // Source "transition/machine.ts":483:7
          ((driver)["setViewPresent"])(false);
          // Source "transition/machine.ts":484:7
          return;
        }
        // Source "transition/machine.ts":487:5
        if (((driver)["requiresColdPreparation"])?.()) {
          // Source "transition/machine.ts":488:7
          (beginPreparation)(appear);
          // Source "transition/machine.ts":489:7
          return;
        }
        // Source "transition/machine.ts":491:5
        ((driver)["setViewPresent"])(true);
        // Source "transition/machine.ts":492:5
        if (((!((!terminal) && (operationVersion === operation))) || (!targetOpen))) {
          // Source "transition/machine.ts":492:54
          return;
        }
        // Source "transition/machine.ts":493:5
        if ((!appear)) {
          // Source "transition/machine.ts":493:18
          (setState)("entered");
        }
      };
      // Source "transition/machine.ts":496:9
      const mounted = (): void => {
        // Source "transition/machine.ts":497:5
        if (terminal) {
          // Source "transition/machine.ts":497:19
          return;
        }
        // Source "transition/machine.ts":498:5
        (viewMounted = true);
        // Source "transition/machine.ts":499:5
        if (preparation) {
          // Source "transition/machine.ts":500:7
          (finishPreparation)((preparation as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }));
          // Source "transition/machine.ts":501:7
          return;
        }
        // Source "transition/machine.ts":503:5
        if ((targetOpen && (((driver)["getState"])() === "closed"))) {
          // Source "transition/machine.ts":503:55
          (beginEnter)();
        }
      };
      // Source "transition/machine.ts":506:9
      const unmounted = (): void => {
        // Source "transition/machine.ts":507:5
        (ownerEpoch = (ownerEpoch + 1));
        // Source "transition/machine.ts":508:11
        const operation = (++operationVersion);
        // Source "transition/machine.ts":509:5
        (cancelPreparation)();
        // Source "transition/machine.ts":510:5
        (viewMounted = false);
        // Source "transition/machine.ts":511:5
        (invalidateCompletion)();
        // Source "transition/machine.ts":512:5
        if ((!((!terminal) && (operationVersion === operation)))) {
          // Source "transition/machine.ts":512:39
          return;
        }
        // Source "transition/machine.ts":513:5
        (queuedIntent = null);
        // Source "transition/machine.ts":514:5
        if ((((driver)["getState"])() !== "closed")) {
          // Source "transition/machine.ts":514:41
          (setState)("closed");
        }
      };
      // Source "transition/machine.ts":517:9
      const dispose = (): void => {
        // Source "transition/machine.ts":518:5
        (terminal = true);
        // Source "transition/machine.ts":519:5
        (ownerEpoch = (ownerEpoch + 1));
        // Source "transition/machine.ts":520:5
        (operationVersion = (operationVersion + 1));
        // Source "transition/machine.ts":521:5
        (cancelPreparation)();
        // Source "transition/machine.ts":522:5
        (viewMounted = false);
        // Source "transition/machine.ts":523:5
        (queuedIntent = null);
        // Source "transition/machine.ts":524:5
        (invalidateCompletion)();
      };
      // Source "transition/machine.ts":527:3
      return { ["initialize"]: initialize, ["setTarget"]: (open: boolean): void => {
        // Source "transition/machine.ts":530:7
        if (terminal) {
          // Source "transition/machine.ts":530:21
          return;
        }
        // Source "transition/machine.ts":531:7
        if ((open === targetOpen)) {
          // Source "transition/machine.ts":531:32
          return;
        }
        // Source "transition/machine.ts":532:7
        if (open) {
          // Source "transition/machine.ts":532:17
          (enter)();
        } else {
          // Source "transition/machine.ts":533:12
          (leave)();
        }
      }, ["enter"]: enter, ["leave"]: leave, ["complete"]: (): void => {
        // Source "transition/machine.ts":538:7
        if ((!terminal)) {
          // Source "transition/machine.ts":538:22
          (completeCurrent)(true);
        }
      }, ["completePresentation"]: (attempt: { readonly "ownerEpoch": number; readonly "phaseAttempt": number }, isCurrent: () => boolean = (): boolean => {
        // Source "transition/machine.ts":540:55
        return true;
      }): boolean => {
        // Source "transition/machine.ts":541:13
        const validate = (): boolean => {
          // Source "transition/machine.ts":542:9
          try {
            // Source "transition/machine.ts":543:11
            return (isCurrent)();
          } catch {
            // Source "transition/machine.ts":545:11
            return false;
          }
        };
        // Source "transition/machine.ts":548:7
        if ((((!(sameAttempt)(attempt)) || (!(validate)())) || (!(sameAttempt)(attempt)))) {
          // Source "transition/machine.ts":548:74
          return false;
        }
        // Source "transition/machine.ts":549:7
        if (publishing) {
          // Source "transition/machine.ts":550:9
          (acknowledged = true);
          // Source "transition/machine.ts":551:9
          (acknowledgementCurrent = validate);
          // Source "transition/machine.ts":552:9
          return true;
        }
        // Source "transition/machine.ts":554:7
        return (completeCurrent)(true);
      }, ["capturePreparation"]: (): ((() => void) | (null)) => {
        // Source "transition/machine.ts":557:13
        const attempt = preparation;
        // Source "transition/machine.ts":558:7
        if (((!attempt) || (!(isPreparing)((attempt as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }))))) {
          // Source "transition/machine.ts":558:46
          return null;
        }
        // Source "transition/machine.ts":559:7
        return (): void => {
          // Source "transition/machine.ts":560:9
          if (((!(isPreparing)((attempt as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }))) || ((attempt as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }))["finishing"])) {
            // Source "transition/machine.ts":560:57
            return;
          }
          // Source "transition/machine.ts":561:9
          (((attempt as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }))["ready"] = true);
          // Source "transition/machine.ts":562:9
          (finishPreparation)((attempt as { "ready": boolean; "finishing": boolean; "animate": boolean; "presentRequested": boolean }));
        };
      }, ["mounted"]: mounted, ["unmounted"]: unmounted, ["dispose"]: dispose };
    };
    const __puiVueHook0 = (options?: unknown) => (__puiVueAuthored.install({name: "asTransition", mode: "once", setup: (options, api) => ((def: void) => {
      // Source "transition/as-transition.proto.ts":42:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0: Parameters<typeof __puiVueDefineProps>[0] = { ["open"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["defaultOpen"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["appear"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["enterDuration"]: { ["type"]: "number", ["empty"]: "fallback" }, ["leaveDuration"]: { ["type"]: "number", ["empty"]: "fallback" }, ["interrupt"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["reverse", "wait", "immediate"] } };
const __puiVueCaptureResult = __puiVueDefineProps(__puiVueCaptureArg0); __puiVueAuthored.effect("props", {"op": "define", "specMap": __puiVueCaptureArg0}); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":54:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = { ["defaultOpen"]: false, ["appear"]: false, ["enterDuration"]: 300, ["leaveDuration"]: 200, ["interrupt"]: "reverse" };
const __puiVueCaptureResult = __puiVueSetDefaults(__puiVueCaptureArg0); __puiVueAuthored.effect("props", {"op": "setDefaults", "partial": __puiVueCaptureArg0}); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":62:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "beforeEnter";
const __puiVueCaptureArg1 = { ["payload"]: "void" };
const __puiVueCaptureResult = __puiVueExposeEvent(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("event", {"op": "expose.event", "key": __puiVueCaptureArg0, "spec": __puiVueCaptureArg1}); __puiVueAuthored.eventKey(__puiVueCaptureArg0); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":63:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "afterEnter";
const __puiVueCaptureArg1 = { ["payload"]: "void" };
const __puiVueCaptureResult = __puiVueExposeEvent(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("event", {"op": "expose.event", "key": __puiVueCaptureArg0, "spec": __puiVueCaptureArg1}); __puiVueAuthored.eventKey(__puiVueCaptureArg0); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":64:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "beforeLeave";
const __puiVueCaptureArg1 = { ["payload"]: "void" };
const __puiVueCaptureResult = __puiVueExposeEvent(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("event", {"op": "expose.event", "key": __puiVueCaptureArg0, "spec": __puiVueCaptureArg1}); __puiVueAuthored.eventKey(__puiVueCaptureArg0); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":65:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "afterLeave";
const __puiVueCaptureArg1 = { ["payload"]: "void" };
const __puiVueCaptureResult = __puiVueExposeEvent(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("event", {"op": "expose.event", "key": __puiVueCaptureArg0, "spec": __puiVueCaptureArg1}); __puiVueAuthored.eventKey(__puiVueCaptureArg0); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":67:11
      const transitionState = (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "transitionState";
const __puiVueCaptureArg1 = "closed";
const __puiVueCaptureArg2 = { ["options"]: ["closed", "preparing", "entering", "entered", "leaving"] };
const __puiVueCaptureResult = __puiVueCreateState('enum', __puiVueCaptureArg0, __puiVueCaptureArg1, __puiVueCaptureArg2); __puiVueAuthored.effect("state", __puiVueCaptureResult); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":72:11
      const isPresent = (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "isPresent";
const __puiVueCaptureArg1 = false;
const __puiVueCaptureResult = __puiVueCreateState('bool', __puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("state", __puiVueCaptureResult); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":73:11
      const appearDefault = (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "transitionAppearDefault";
const __puiVueCaptureArg1 = false;
const __puiVueCaptureResult = __puiVueCreateState('bool', __puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("state", __puiVueCaptureResult); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":74:11
      const coldEntryPreparation = (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "transitionColdEntryPreparation";
const __puiVueCaptureArg1 = false;
const __puiVueCaptureResult = __puiVueCreateState('bool', __puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("state", __puiVueCaptureResult); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":75:11
      const enterDurationDefault = (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "transitionEnterDurationDefault";
const __puiVueCaptureArg1 = 300;
const __puiVueCaptureResult = __puiVueCreateState('number.discrete', __puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("state", __puiVueCaptureResult); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":76:11
      const leaveDurationDefault = (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "transitionLeaveDurationDefault";
const __puiVueCaptureArg1 = 200;
const __puiVueCaptureResult = __puiVueCreateState('number.discrete', __puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("state", __puiVueCaptureResult); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":77:11
      const interruptDefault = (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "transitionInterruptDefault";
const __puiVueCaptureArg1 = "reverse";
const __puiVueCaptureArg2 = { ["options"]: ["reverse", "wait", "immediate"] };
const __puiVueCaptureResult = __puiVueCreateState('enum', __puiVueCaptureArg0, __puiVueCaptureArg1, __puiVueCaptureArg2); __puiVueAuthored.effect("state", __puiVueCaptureResult); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":83:9
      let initialOpenSource: (({ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) | (null)) = (null as (({ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) | (null)));
      // Source "transition/as-transition.proto.ts":85:9
      let openContextSource: (({ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) | (null)) = (null as (({ readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) | (null)));
      // Source "transition/as-transition.proto.ts":87:11
      const closedViewRetained = (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "transitionClosedViewRetained";
const __puiVueCaptureArg1 = false;
const __puiVueCaptureResult = __puiVueCreateState('bool', __puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("state", __puiVueCaptureResult); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":88:11
      const bindInitialOpen = (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }): void => {
        // Source "transition/as-transition.proto.ts":90:7
        appearDefault.setDefault((appearDefault.get() as boolean));
        // Source "transition/as-transition.proto.ts":91:7
        if ((((((!source) || ((typeof (source)["field"]) !== "string")) || (!(source)["field"])) || (!(source)["context"])) || (((source)["context"])["__brand"] !== "ContextKey"))) {
          // Source "transition/as-transition.proto.ts":98:9
          throw new Error("[asTransition] initial open source requires a ContextKey and direct field.");
        }
        // Source "transition/as-transition.proto.ts":102:7
        if (initialOpenSource) {
          // Source "transition/as-transition.proto.ts":103:9
          if (((((initialOpenSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["context"] === (source)["context"]) && (((initialOpenSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["field"] === (source)["field"]))) {
            // Source "transition/as-transition.proto.ts":107:11
            return;
          }
          // Source "transition/as-transition.proto.ts":108:9
          throw new Error("[asTransition] initial open source is already bound.");
        }
        // Source "transition/as-transition.proto.ts":110:7
        (initialOpenSource = (Object.freeze({ ["context"]: (source)["context"], ["field"]: (source)["field"] }) as { "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; "field": string }));
      };
      // Source "transition/as-transition.proto.ts":112:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "bindInitialOpen";
const __puiVueCaptureArg1 = bindInitialOpen;
const __puiVueCaptureResult = __puiVueExposeMethod(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("context", {"op": "expose.method", "key": __puiVueCaptureArg0, "fn": __puiVueCaptureArg1}); __puiVueAuthored.method(__puiVueCaptureArg0, __puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":114:11
      const presentation = (void (def), __puiVuePresence.owner());
      // Source "transition/as-transition.proto.ts":115:9
      let completion: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number })) = ("timer" as (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number })));
      // Source "transition/as-transition.proto.ts":116:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "getPresentationOwner";
const __puiVueCaptureArg1 = (): Readonly<object> => {
        // Source "transition/as-transition.proto.ts":116:53
        return (presentation)["ref"];
      };
const __puiVueCaptureResult = __puiVueExposeMethod(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("context", {"op": "expose.method", "key": __puiVueCaptureArg0, "fn": __puiVueCaptureArg1}); __puiVueAuthored.method(__puiVueCaptureArg0, __puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":117:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "configurePresentation";
const __puiVueCaptureArg1 = (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }): void => {
        // Source "transition/as-transition.proto.ts":118:7
        appearDefault.setDefault((appearDefault.get() as boolean));
        // Source "transition/as-transition.proto.ts":119:13
        const policy = __puiVueSnapshotCompletion(((config)["completion"] ?? completion));
        // Source "transition/as-transition.proto.ts":120:13
        const enter = ((config)["enterDuration"] ?? (enterDurationDefault.get() as number));
        // Source "transition/as-transition.proto.ts":121:13
        const leave = ((config)["leaveDuration"] ?? (leaveDurationDefault.get() as number));
        // Source "transition/as-transition.proto.ts":122:7
        if ((!([enter, leave]).every((value: number): boolean => {
          // Source "transition/as-transition.proto.ts":122:44
          return (Number.isFinite(value) && (value >= 0));
        }))) {
          // Source "transition/as-transition.proto.ts":123:9
          throw new Error("[asTransition] durations must be finite non-negative numbers.");
        }
        // Source "transition/as-transition.proto.ts":124:7
        if (((policy !== "timer") && ((enter >= ((policy as { readonly "kind": "presentation"; readonly "timeoutMs": number }))["timeoutMs"]) || (leave >= ((policy as { readonly "kind": "presentation"; readonly "timeoutMs": number }))["timeoutMs"])))) {
          // Source "transition/as-transition.proto.ts":125:9
          throw new Error("[asTransition] presentation duration must be shorter than timeoutMs.");
        }
        // Source "transition/as-transition.proto.ts":126:7
        (completion = policy);
      };
const __puiVueCaptureResult = __puiVueExposeMethod(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("context", {"op": "expose.method", "key": __puiVueCaptureArg0, "fn": __puiVueCaptureArg1}); __puiVueAuthored.method(__puiVueCaptureArg0, __puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":128:9
      let currentRun: ((__puiVueRun) | (null)) = (null as ((__puiVueRun) | (null)));
      // Source "transition/as-transition.proto.ts":132:9
      let phaseViewRequested: boolean = false;
      // Source "transition/as-transition.proto.ts":133:11
      const getProps = (): ((Readonly<GeneratedResolvedProps>) | (undefined)) => {
        // Source "transition/as-transition.proto.ts":133:28
        return ((__puiVueOptionalReceiver: ((__puiVueRun) | (null))) => __puiVueOptionalReceiver == null ? undefined : __puiVueReadProps(__puiVueOptionalReceiver))(currentRun);
      };
      // Source "transition/as-transition.proto.ts":135:11
      const driver = ({ ["getState"]: (): "closed" | "preparing" | "entering" | "entered" | "leaving" => {
        // Source "transition/as-transition.proto.ts":136:23
        return (transitionState.get() as "closed" | "preparing" | "entering" | "entered" | "leaving");
      }, ["setState"]: (state: "closed" | "preparing" | "entering" | "entered" | "leaving"): void => {
        // Source "transition/as-transition.proto.ts":138:9
        transitionState.set(state, ("reason: asTransition => " + state));
        // Source "transition/as-transition.proto.ts":140:9
        if ((!currentRun)) {
          // Source "transition/as-transition.proto.ts":140:26
          return;
        }
        // Source "transition/as-transition.proto.ts":142:15
        const currentState = (transitionState.get() as "closed" | "preparing" | "entering" | "entered" | "leaving");
        // Source "transition/as-transition.proto.ts":143:9
        isPresent.set((currentState !== "closed"), ("reason: asTransition presence => " + currentState));
      }, ["requiresColdPreparation"]: (): boolean => {
        // Source "transition/as-transition.proto.ts":148:38
        return (coldEntryPreparation.get() as boolean);
      }, ["getCompletion"]: (): (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number })) => {
        // Source "transition/as-transition.proto.ts":149:28
        return completion;
      }, ["publishPresentation"]: (frame: { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }): void => {
        // Source "transition/as-transition.proto.ts":151:9
        return ((__puiVueOptionalReceiver: ((__puiVueRun) | (null))) => __puiVueOptionalReceiver == null ? undefined : (void (__puiVueOptionalReceiver), __puiVuePresence.publish((presentation)["writer"], ({ ...(frame), ["owner"]: (presentation)["ref"] }))))(currentRun);
      }, ["settlePresentation"]: (outcome: "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed"): void => {
        // Source "transition/as-transition.proto.ts":156:9
        return ((__puiVueOptionalReceiver: ((__puiVueRun) | (null))) => __puiVueOptionalReceiver == null ? undefined : (void (__puiVueOptionalReceiver), __puiVuePresence.settle((presentation)["writer"], outcome)))(currentRun);
      }, ["getInterrupt"]: (): "reverse" | "wait" | "immediate" => {
        // Source "transition/as-transition.proto.ts":158:9
        return (((__puiVueOptionalReceiver: ((__puiVueRun) | (null))) => __puiVueOptionalReceiver == null ? undefined : __puiVueIsProvided(__puiVueOptionalReceiver, "interrupt"))(currentRun) ? (((getProps)())?.["interrupt"] ?? (interruptDefault.get() as "reverse" | "wait" | "immediate")) : (interruptDefault.get() as "reverse" | "wait" | "immediate"));
      }, ["getDuration"]: (state: "entering" | "leaving"): number => {
        // Source "transition/as-transition.proto.ts":165:9
        if ((((__puiVueOptionalReceiver: ((__puiVueRun) | (null))) => __puiVueOptionalReceiver == null ? undefined : (void (__puiVueOptionalReceiver), __puiVueMeta("reducedMotion")))(currentRun) === "reduce")) {
          // Source "transition/as-transition.proto.ts":165:66
          return 0;
        }
        // Source "transition/as-transition.proto.ts":166:9
        return ((state === "entering") ? (((__puiVueOptionalReceiver: ((__puiVueRun) | (null))) => __puiVueOptionalReceiver == null ? undefined : __puiVueIsProvided(__puiVueOptionalReceiver, "enterDuration"))(currentRun) ? (((getProps)())?.["enterDuration"] ?? (enterDurationDefault.get() as number)) : (enterDurationDefault.get() as number)) : (((__puiVueOptionalReceiver: ((__puiVueRun) | (null))) => __puiVueOptionalReceiver == null ? undefined : __puiVueIsProvided(__puiVueOptionalReceiver, "leaveDuration"))(currentRun) ? (((getProps)())?.["leaveDuration"] ?? (leaveDurationDefault.get() as number)) : (leaveDurationDefault.get() as number)));
      }, ["schedule"]: (durationMs: number, callback: () => void): __puiVueDelayTask => {
        // Source "transition/as-transition.proto.ts":174:43
        return __puiVueDelay.schedule(durationMs, callback);
      }, ["setViewPresent"]: (present: boolean): void => {
        // Source "transition/as-transition.proto.ts":176:9
        if ((!currentRun)) {
          // Source "transition/as-transition.proto.ts":177:11
          throw new Error("[asTransition] runtime lifecycle handle is not available.");
        }
        // Source "transition/as-transition.proto.ts":179:9
        (phaseViewRequested = present);
        // Source "transition/as-transition.proto.ts":180:9
        __puiVueSetPresent((currentRun as __puiVueRun), (phaseViewRequested || (closedViewRetained.get() as boolean)));
      }, ["emit"]: (event: "beforeEnter" | "afterEnter" | "beforeLeave" | "afterLeave"): void => {
        // Source "transition/as-transition.proto.ts":183:9
        ((__puiVueOptionalReceiver: ((__puiVueRun) | (null))) => __puiVueOptionalReceiver == null ? undefined : __puiVueEmit(__puiVueOptionalReceiver, event))(currentRun);
      } } as { "getState": () => "closed" | "preparing" | "entering" | "entered" | "leaving"; "setState": (state: "closed" | "preparing" | "entering" | "entered" | "leaving") => void; "getInterrupt": () => "reverse" | "wait" | "immediate"; "requiresColdPreparation"?: () => boolean; "getCompletion"?: () => (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number })); "publishPresentation"?: (frame: { readonly "revision": number; readonly "phase": "closed" | "preparing" | "entering" | "entered" | "leaving"; readonly "attempt": (({ readonly "ownerEpoch": number; readonly "phaseAttempt": number }) | (null)); readonly "completion": "timer" | "presentation"; readonly "durationMs": number; readonly "timeoutMs": number | null }) => void; "settlePresentation"?: (outcome: "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed") => void; "getDuration": (state: "entering" | "leaving") => number; "schedule": (durationMs: number, callback: () => void) => __puiVueDelayTask; "setViewPresent": (present: boolean) => void; "emit": (event: "beforeEnter" | "afterEnter" | "beforeLeave" | "afterLeave") => void });
      // Source "transition/as-transition.proto.ts":186:11
      const machine = __puiModule0(driver);
      // Source "transition/as-transition.proto.ts":187:5
      presentation.onCompletionRequest((run: __puiVueRun, request: { readonly "receipt": { readonly "owner": Readonly<object>; readonly "attempt": { readonly "ownerEpoch": number; readonly "phaseAttempt": number }; readonly "viewBinding": Readonly<object>; readonly "ownerRevision": number; readonly "targetRevision": number; readonly "channels": ReadonlyArray<"translate" | "opacity">; readonly "outcome": "finished" | "reduced-motion" | "unknown-preference" | "hidden" | "missing-capability" | "unsupported-endpoint" | "unresolved-units" | "unresolved-input" | "projection-failed" | "projection-ownership-lost" | "deadline" | "zero-duration" | "invalid-policy" | "scheduler-failed" } }) => __puiVueInvoke("event", () => {
        // Source "transition/as-transition.proto.ts":188:7
        if ((!currentRun)) {
          // Source "transition/as-transition.proto.ts":188:24
          return;
        }
        // Source "transition/as-transition.proto.ts":189:7
        if ((!(void (run), __puiVuePresence.isCurrent((presentation)["writer"], (request)["receipt"])))) {
          // Source "transition/as-transition.proto.ts":189:83
          return;
        }
        // Source "transition/as-transition.proto.ts":190:7
        ((machine)["completePresentation"])(((request)["receipt"])["attempt"], (): boolean => {
          // Source "transition/as-transition.proto.ts":192:15
          return ((!(!currentRun)) && (void (run), __puiVuePresence.isCurrent((presentation)["writer"], (request)["receipt"])));
        });
      }));
      // Source "transition/as-transition.proto.ts":196:11
      const controls: { "enter": () => void; "leave": () => void; "complete": () => void; "capturePreparation": () => ((() => void) | (null)) } = { ["enter"]: (): void => {
        // Source "transition/as-transition.proto.ts":198:9
        if (openContextSource) {
          // Source "transition/as-transition.proto.ts":199:11
          if (currentRun) {
            // Source "transition/as-transition.proto.ts":199:27
            ((machine)["setTarget"])((contextOpen)((currentRun as __puiVueRun), (openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string })));
          }
        } else {
          // Source "transition/as-transition.proto.ts":200:16
          ((machine)["enter"])();
        }
      }, ["leave"]: (): void => {
        // Source "transition/as-transition.proto.ts":203:9
        if (openContextSource) {
          // Source "transition/as-transition.proto.ts":204:11
          if (currentRun) {
            // Source "transition/as-transition.proto.ts":204:27
            ((machine)["setTarget"])((contextOpen)((currentRun as __puiVueRun), (openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string })));
          }
        } else {
          // Source "transition/as-transition.proto.ts":205:16
          ((machine)["leave"])();
        }
      }, ["complete"]: (): void => {
        // Source "transition/as-transition.proto.ts":207:23
        return ((machine)["complete"])();
      }, ["capturePreparation"]: (): ((() => void) | (null)) => {
        // Source "transition/as-transition.proto.ts":209:9
        if ((!currentRun)) {
          // Source "transition/as-transition.proto.ts":210:11
          throw new Error("[asTransition] preparation capture requires a live runtime.");
        }
        // Source "transition/as-transition.proto.ts":211:9
        return ((machine)["capturePreparation"])();
      } };
      // Source "transition/as-transition.proto.ts":214:11
      const contextOpen = (run: __puiVueRun, source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }): boolean => {
        // Source "transition/as-transition.proto.ts":218:13
        const value = (__puiVueReadContext(run, (source)["context"], false) as { [key: string]: unknown });
        // Source "transition/as-transition.proto.ts":219:13
        const target = (value)[(source)["field"]];
        // Source "transition/as-transition.proto.ts":220:7
        if (((!Object.hasOwn(value, (source)["field"])) || ((typeof target) !== "boolean"))) {
          // Source "transition/as-transition.proto.ts":221:9
          throw new Error("[asTransition] open context field must be a required boolean.");
        }
        // Source "transition/as-transition.proto.ts":222:7
        return (target as boolean);
      };
      // Source "transition/as-transition.proto.ts":224:11
      const bindOpenContext = (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }): void => {
        // Source "transition/as-transition.proto.ts":225:7
        appearDefault.setDefault((appearDefault.get() as boolean));
        // Source "transition/as-transition.proto.ts":226:7
        if ((((((!source) || ((typeof (source)["field"]) !== "string")) || (!(source)["field"])) || (!(source)["context"])) || (((source)["context"])["__brand"] !== "ContextKey"))) {
          // Source "transition/as-transition.proto.ts":233:9
          throw new Error("[asTransition] open context source requires a ContextKey and direct field.");
        }
        // Source "transition/as-transition.proto.ts":236:7
        if (openContextSource) {
          // Source "transition/as-transition.proto.ts":237:9
          if (((((openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["context"] === (source)["context"]) && (((openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["field"] === (source)["field"]))) {
            // Source "transition/as-transition.proto.ts":241:11
            return;
          }
          // Source "transition/as-transition.proto.ts":242:9
          throw new Error("[asTransition] open context source is already bound.");
        }
        // Source "transition/as-transition.proto.ts":244:7
        (openContextSource = (Object.freeze({ ["context"]: (source)["context"], ["field"]: (source)["field"] }) as { "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; "field": string }));
        // Source "transition/as-transition.proto.ts":245:7
        (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = (source)["context"];
const __puiVueCaptureArg1 = (run: __puiVueRun) => __puiVueInvoke("context-watch", () => {
          // Source "transition/as-transition.proto.ts":246:9
          (currentRun = run);
          // Source "transition/as-transition.proto.ts":247:9
          ((machine)["setTarget"])((contextOpen)(run, (openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string })));
        });
const __puiVueCaptureResult = __puiVueScope.subscribe(__puiVueCaptureArg0, 'required', (next, prev) => Reflect.apply(__puiVueCaptureArg1, undefined, [__puiVueRunValue, next, prev])); __puiVueAuthored.effect("context", {"op": "subscribe", "key": __puiVueCaptureArg0, "off": __puiVueCaptureResult}); __puiVueAuthored.disposer("context", __puiVueCaptureResult); return __puiVueCaptureResult; })();
      };
      // Source "transition/as-transition.proto.ts":250:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "bindOpenContext";
const __puiVueCaptureArg1 = bindOpenContext;
const __puiVueCaptureResult = __puiVueExposeMethod(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("context", {"op": "expose.method", "key": __puiVueCaptureArg0, "fn": __puiVueCaptureArg1}); __puiVueAuthored.method(__puiVueCaptureArg0, __puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":251:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "retainClosedView";
const __puiVueCaptureArg1 = (retained: boolean): void => {
        // Source "transition/as-transition.proto.ts":252:7
        closedViewRetained.set((!(!retained)), "reason: transition closed-view retention policy");
        // Source "transition/as-transition.proto.ts":253:7
        if ((!currentRun)) {
          // Source "transition/as-transition.proto.ts":253:24
          return;
        }
        // Source "transition/as-transition.proto.ts":254:7
        __puiVueSetPresent((currentRun as __puiVueRun), (phaseViewRequested || (closedViewRetained.get() as boolean)));
      };
const __puiVueCaptureResult = __puiVueExposeMethod(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("context", {"op": "expose.method", "key": __puiVueCaptureArg0, "fn": __puiVueCaptureArg1}); __puiVueAuthored.method(__puiVueCaptureArg0, __puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":257:5
      __puiVueLife.created.push((run: __puiVueRun) => __puiVueInvoke("created", () => {
        // Source "transition/as-transition.proto.ts":258:7
        (currentRun = run);
        // Source "transition/as-transition.proto.ts":259:13
        const props = __puiVueReadProps(run);
        // Source "transition/as-transition.proto.ts":260:13
        const controlled = __puiVueIsProvided(run, "open");
        // Source "transition/as-transition.proto.ts":261:11
        let open: boolean = (controlled ? (!(!(props)["open"])) : (!(!(props)["defaultOpen"])));
        // Source "transition/as-transition.proto.ts":262:7
        if (openContextSource) {
          // Source "transition/as-transition.proto.ts":263:9
          (open = (contextOpen)(run, (openContextSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string })));
        } else {
          // Source "transition/as-transition.proto.ts":264:14
          if ((((!controlled) && (!__puiVueIsProvided(run, "defaultOpen"))) && initialOpenSource)) {
            // Source "transition/as-transition.proto.ts":265:15
            const value = (__puiVueReadContext(run, ((initialOpenSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["context"], false) as { [key: string]: unknown });
            // Source "transition/as-transition.proto.ts":266:15
            const initialOpen = (value)[((initialOpenSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["field"]];
            // Source "transition/as-transition.proto.ts":267:9
            if (((!Object.hasOwn(value, ((initialOpenSource as { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }))["field"])) || ((typeof initialOpen) !== "boolean"))) {
              // Source "transition/as-transition.proto.ts":268:11
              throw new Error("[asTransition] initial open context field must be a required boolean.");
            }
            // Source "transition/as-transition.proto.ts":270:9
            (open = (initialOpen as boolean));
          }
        }
        // Source "transition/as-transition.proto.ts":272:13
        const appear = (__puiVueIsProvided(run, "appear") ? (!(!(props)["appear"])) : (appearDefault.get() as boolean));
        // Source "transition/as-transition.proto.ts":273:7
        ((machine)["initialize"])(open, appear);
      }));
      // Source "transition/as-transition.proto.ts":276:5
      __puiVueLife.mounted.push((run: __puiVueRun) => __puiVueInvoke("mounted", () => {
        // Source "transition/as-transition.proto.ts":277:7
        (currentRun = run);
        // Source "transition/as-transition.proto.ts":278:7
        ((machine)["mounted"])();
      }));
      // Source "transition/as-transition.proto.ts":281:5
      __puiVueLife.unmounted.push((run: __puiVueRun) => __puiVueInvoke("unmounted", () => {
        // Source "transition/as-transition.proto.ts":282:7
        (currentRun = run);
        // Source "transition/as-transition.proto.ts":283:7
        ((machine)["unmounted"])();
      }));
      // Source "transition/as-transition.proto.ts":286:5
      __puiVueLife.beforeDispose.push(() => __puiVueInvoke("before-dispose", () => {
        // Source "transition/as-transition.proto.ts":287:7
        ((machine)["dispose"])();
        // Source "transition/as-transition.proto.ts":288:7
        (currentRun = null);
      }));
      // Source "transition/as-transition.proto.ts":291:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = ["open", "interrupt", "enterDuration", "leaveDuration"];
const __puiVueCaptureArg1 = (run: __puiVueRun, next: Readonly<GeneratedResolvedProps>) => __puiVueInvoke("props-watch", () => {
        // Source "transition/as-transition.proto.ts":292:7
        (currentRun = run);
        // Source "transition/as-transition.proto.ts":293:7
        if ((openContextSource || (!__puiVueIsProvided(run, "open")))) {
          // Source "transition/as-transition.proto.ts":293:63
          return;
        }
        // Source "transition/as-transition.proto.ts":294:7
        ((machine)["setTarget"])((!(!(next)["open"])));
      });
const __puiVueCaptureResult = __puiVueWatchProps(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("props", {"op": "watch", "keys": __puiVueCaptureArg0, "off": __puiVueCaptureResult}); __puiVueAuthored.disposer("props", __puiVueCaptureResult); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":297:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "transitionState";
const __puiVueCaptureArg1 = transitionState;
const __puiVueCaptureResult = __puiVueExposeState(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("state", {"op": "expose.state", "key": __puiVueCaptureArg0, "handle": __puiVueCaptureArg1}); __puiVueAuthored.introduceObserved(__puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":298:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "isPresent";
const __puiVueCaptureArg1 = isPresent;
const __puiVueCaptureResult = __puiVueExposeState(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("state", {"op": "expose.state", "key": __puiVueCaptureArg0, "handle": __puiVueCaptureArg1}); __puiVueAuthored.introduceObserved(__puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":299:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "enter";
const __puiVueCaptureArg1 = (controls)["enter"];
const __puiVueCaptureResult = __puiVueExposeMethod(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("context", {"op": "expose.method", "key": __puiVueCaptureArg0, "fn": __puiVueCaptureArg1}); __puiVueAuthored.method(__puiVueCaptureArg0, __puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":300:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "leave";
const __puiVueCaptureArg1 = (controls)["leave"];
const __puiVueCaptureResult = __puiVueExposeMethod(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("context", {"op": "expose.method", "key": __puiVueCaptureArg0, "fn": __puiVueCaptureArg1}); __puiVueAuthored.method(__puiVueCaptureArg0, __puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":301:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "complete";
const __puiVueCaptureArg1 = (controls)["complete"];
const __puiVueCaptureResult = __puiVueExposeMethod(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("context", {"op": "expose.method", "key": __puiVueCaptureArg0, "fn": __puiVueCaptureArg1}); __puiVueAuthored.method(__puiVueCaptureArg0, __puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":302:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "capturePreparation";
const __puiVueCaptureArg1 = (controls)["capturePreparation"];
const __puiVueCaptureResult = __puiVueExposeMethod(__puiVueCaptureArg0, __puiVueCaptureArg1, (__puiVuePublicResult: ((() => void) | (null))) => ((__puiVuePublicValue0: ((() => void) | (null))) => (typeof __puiVuePublicValue0 === 'function' ? __puiVueWrapPublic(__puiVuePublicValue0) : (__puiVuePublicValue0)))(__puiVuePublicResult)); __puiVueAuthored.effect("context", {"op": "expose.method", "key": __puiVueCaptureArg0, "fn": __puiVueCaptureArg1}); __puiVueAuthored.method(__puiVueCaptureArg0, __puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "transition/as-transition.proto.ts":303:5
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "controls";
const __puiVueCaptureArg1 = controls;
const __puiVueCaptureResult = __puiVueDeclare(__puiVueCaptureArg0, ((__puiVuePublicValue0: { "enter": () => void; "leave": () => void; "complete": () => void; "capturePreparation": () => ((() => void) | (null)) }) => (__puiVuePublicValue0 !== null && typeof __puiVuePublicValue0 === 'object' ? __puiVueWrapPublic.record(__puiVuePublicValue0, __puiVuePublicValue0Record => { if (Object.hasOwn(__puiVuePublicValue0, "enter")) Object.defineProperty(__puiVuePublicValue0Record, "enter", { value: ((__puiVuePublicValue1: () => void) => (typeof __puiVuePublicValue1 === 'function' ? __puiVueWrapPublic(__puiVuePublicValue1, __puiVuePublicValue0) : (__puiVuePublicValue1)))(((__puiVuePublicValue0 as unknown as Record<string, unknown>)["enter"] as () => void)), enumerable: true, configurable: true, writable: true }); if (Object.hasOwn(__puiVuePublicValue0, "leave")) Object.defineProperty(__puiVuePublicValue0Record, "leave", { value: ((__puiVuePublicValue2: () => void) => (typeof __puiVuePublicValue2 === 'function' ? __puiVueWrapPublic(__puiVuePublicValue2, __puiVuePublicValue0) : (__puiVuePublicValue2)))(((__puiVuePublicValue0 as unknown as Record<string, unknown>)["leave"] as () => void)), enumerable: true, configurable: true, writable: true }); if (Object.hasOwn(__puiVuePublicValue0, "complete")) Object.defineProperty(__puiVuePublicValue0Record, "complete", { value: ((__puiVuePublicValue3: () => void) => (typeof __puiVuePublicValue3 === 'function' ? __puiVueWrapPublic(__puiVuePublicValue3, __puiVuePublicValue0) : (__puiVuePublicValue3)))(((__puiVuePublicValue0 as unknown as Record<string, unknown>)["complete"] as () => void)), enumerable: true, configurable: true, writable: true }); if (Object.hasOwn(__puiVuePublicValue0, "capturePreparation")) Object.defineProperty(__puiVuePublicValue0Record, "capturePreparation", { value: ((__puiVuePublicValue4: () => ((() => void) | (null))) => (typeof __puiVuePublicValue4 === 'function' ? __puiVueWrapPublic(__puiVuePublicValue4, __puiVuePublicValue0, (__puiVuePublicValue4Result: ((() => void) | (null))) => ((__puiVuePublicValue5: ((() => void) | (null))) => (typeof __puiVuePublicValue5 === 'function' ? __puiVueWrapPublic(__puiVuePublicValue5) : (__puiVuePublicValue5)))(__puiVuePublicValue4Result), "7f8ad435c936065d") : (__puiVuePublicValue4)))(((__puiVuePublicValue0 as unknown as Record<string, unknown>)["capturePreparation"] as () => ((() => void) | (null)))), enumerable: true, configurable: true, writable: true }); }) : __puiVuePublicValue0))(__puiVueCaptureArg1)); __puiVueAuthored.effect("context", {"op": "expose.value", "key": __puiVueCaptureArg0, "value": __puiVueCaptureArg1}); return __puiVueCaptureResult; })();
    })(undefined), project: (result: { readonly stateHandles?: Readonly<Record<string, unknown>>; readonly getState?: (name: string) => unknown; readonly getMethod?: (name: string) => unknown; readonly getAsHook?: (name: string) => unknown; readonly getAsHookHandle?: (name: string) => unknown; readonly render?: unknown }): { "transitionState": __puiVueState<string> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<string>) => void): () => void}; "isPresent": __puiVueState<boolean> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<boolean>) => void): () => void}; "controls": { "capturePreparation": () => ((() => void) | (null)); "enter": () => void; "leave": () => void; "complete": () => void }; "configure": (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void; "bindInitialOpen": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void; "bindOpenContext": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void; "retainClosedView": (retained: boolean) => void; "presentationOwner": Readonly<object> } => {
      // Source "transition/as-transition.proto.ts":306:11
      const transitionState = __puiModule1((result.getState?.("transitionState") as ((__puiVueState<string> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<string>) => void): () => void}) | (undefined))), "transitionState");
      // Source "transition/as-transition.proto.ts":310:11
      const isPresent = __puiModule2((result.getState?.("isPresent") as ((__puiVueState<boolean> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<boolean>) => void): () => void}) | (undefined))), "isPresent");
      // Source "transition/as-transition.proto.ts":311:11
      const controls: { "capturePreparation": () => ((() => void) | (null)); "enter": () => void; "leave": () => void; "complete": () => void } = { ["capturePreparation"]: __puiModule3((result.getMethod?.("capturePreparation") as ((() => ((() => void) | (null))) | (undefined))), "capturePreparation"), ["enter"]: __puiModule4((result.getMethod?.("enter") as ((() => void) | (undefined))), "enter"), ["leave"]: __puiModule5((result.getMethod?.("leave") as ((() => void) | (undefined))), "leave"), ["complete"]: __puiModule6((result.getMethod?.("complete") as ((() => void) | (undefined))), "complete") };
      // Source "transition/as-transition.proto.ts":330:11
      const appearDefault = __puiModule7((result.getState?.("transitionAppearDefault") as ((__puiVueState<boolean> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<boolean>) => void): () => void}) | (undefined))), "transitionAppearDefault");
      // Source "transition/as-transition.proto.ts":334:11
      const enterDurationDefault = __puiModule8((result.getState?.("transitionEnterDurationDefault") as ((__puiVueState<number> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<number>) => void): () => void}) | (undefined))), "transitionEnterDurationDefault");
      // Source "transition/as-transition.proto.ts":338:11
      const leaveDurationDefault = __puiModule9((result.getState?.("transitionLeaveDurationDefault") as ((__puiVueState<number> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<number>) => void): () => void}) | (undefined))), "transitionLeaveDurationDefault");
      // Source "transition/as-transition.proto.ts":342:11
      const interruptDefault = __puiModule10((result.getState?.("transitionInterruptDefault") as ((__puiVueState<string> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<string>) => void): () => void}) | (undefined))), "transitionInterruptDefault");
      // Source "transition/as-transition.proto.ts":347:11
      const coldEntryPreparation = __puiModule11((result.getState?.("transitionColdEntryPreparation") as ((__puiVueState<boolean> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<boolean>) => void): () => void}) | (undefined))), "transitionColdEntryPreparation");
      // Source "transition/as-transition.proto.ts":352:11
      const configurePresentation = __puiModule12((result.getMethod?.("configurePresentation") as (((config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void) | (undefined))), "configurePresentation");
      // Source "transition/as-transition.proto.ts":358:11
      const getPresentationOwner = __puiModule13((result.getMethod?.("getPresentationOwner") as ((() => Readonly<object>) | (undefined))), "getPresentationOwner");
      // Source "transition/as-transition.proto.ts":362:11
      const configure = (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }): void => {
        // Source "transition/as-transition.proto.ts":364:7
        (configurePresentation)(config);
        // Source "transition/as-transition.proto.ts":365:11
        let configured: boolean = false;
        // Source "transition/as-transition.proto.ts":366:7
        if (((typeof (config)["coldEntryPreparation"]) !== "undefined")) {
          // Source "transition/as-transition.proto.ts":367:9
          coldEntryPreparation.setDefault(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation": boolean; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["coldEntryPreparation"]);
          // Source "transition/as-transition.proto.ts":368:9
          (configured = true);
        }
        // Source "transition/as-transition.proto.ts":370:7
        if (((typeof (config)["appear"]) !== "undefined")) {
          // Source "transition/as-transition.proto.ts":371:9
          appearDefault.setDefault(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear": boolean; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["appear"]);
          // Source "transition/as-transition.proto.ts":372:9
          (configured = true);
        }
        // Source "transition/as-transition.proto.ts":374:7
        if (((typeof (config)["enterDuration"]) !== "undefined")) {
          // Source "transition/as-transition.proto.ts":375:9
          if (((!Number.isFinite(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration": number; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["enterDuration"])) || (((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration": number; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["enterDuration"] < 0))) {
            // Source "transition/as-transition.proto.ts":376:11
            throw new Error("[asTransition] enterDuration must be a finite non-negative number.");
          }
          // Source "transition/as-transition.proto.ts":378:9
          enterDurationDefault.setDefault(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration": number; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["enterDuration"]);
          // Source "transition/as-transition.proto.ts":379:9
          (configured = true);
        }
        // Source "transition/as-transition.proto.ts":381:7
        if (((typeof (config)["leaveDuration"]) !== "undefined")) {
          // Source "transition/as-transition.proto.ts":382:9
          if (((!Number.isFinite(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration": number; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["leaveDuration"])) || (((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration": number; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["leaveDuration"] < 0))) {
            // Source "transition/as-transition.proto.ts":383:11
            throw new Error("[asTransition] leaveDuration must be a finite non-negative number.");
          }
          // Source "transition/as-transition.proto.ts":385:9
          leaveDurationDefault.setDefault(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration": number; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }))["leaveDuration"]);
          // Source "transition/as-transition.proto.ts":386:9
          (configured = true);
        }
        // Source "transition/as-transition.proto.ts":388:7
        if (((typeof (config)["interrupt"]) !== "undefined")) {
          // Source "transition/as-transition.proto.ts":389:9
          interruptDefault.setDefault(((config as { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt": "reverse" | "wait" | "immediate" }))["interrupt"]);
          // Source "transition/as-transition.proto.ts":390:9
          (configured = true);
        }
        // Source "transition/as-transition.proto.ts":393:7
        if ((!(configured as true | boolean))) {
          // Source "transition/as-transition.proto.ts":393:24
          appearDefault.setDefault((appearDefault.get() as boolean));
        }
      };
      // Source "transition/as-transition.proto.ts":396:11
      const bindInitialOpen = __puiModule14((result.getMethod?.("bindInitialOpen") as (((source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void) | (undefined))), "bindInitialOpen");
      // Source "transition/as-transition.proto.ts":400:11
      const bindOpenContext = __puiModule15((result.getMethod?.("bindOpenContext") as (((source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void) | (undefined))), "bindOpenContext");
      // Source "transition/as-transition.proto.ts":404:11
      const retainClosedView = __puiModule16((result.getMethod?.("retainClosedView") as (((retained: boolean) => void) | (undefined))), "retainClosedView");
      // Source "transition/as-transition.proto.ts":408:5
      return { ["transitionState"]: transitionState, ["isPresent"]: isPresent, ["controls"]: controls, ["configure"]: configure, ["bindInitialOpen"]: bindInitialOpen, ["bindOpenContext"]: bindOpenContext, ["retainClosedView"]: retainClosedView, ["presentationOwner"]: (getPresentationOwner)() };
    }}, options) as { "transitionState": __puiVueState<string> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<string>) => void): () => void}; "isPresent": __puiVueState<boolean> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<boolean>) => void): () => void}; "controls": { "capturePreparation": () => ((() => void) | (null)); "enter": () => void; "leave": () => void; "complete": () => void }; "configure": (config: { "completion"?: (("timer") | ({ readonly "kind": "presentation"; readonly "timeoutMs": number }) | (undefined)); "coldEntryPreparation"?: boolean | undefined; "appear"?: boolean | undefined; "enterDuration"?: number | undefined; "leaveDuration"?: number | undefined; "interrupt"?: "reverse" | "wait" | "immediate" | undefined }) => void; "bindInitialOpen": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void; "bindOpenContext": (source: { readonly "context": {readonly __brand: 'ContextKey'; readonly debugName?: string}; readonly "field": string }) => void; "retainClosedView": (retained: boolean) => void; "presentationOwner": Readonly<object> });
    const __puiVueRenderer = ((): ((frame: __puiVueFrame) => __puiVueVue.VNodeChild) | void => {
      try {
        const renderer = (() => {
        // Source "entry.proto.ts":4:3
        ((__puiVueHook0())["configure"])({ ["coldEntryPreparation"]: false, ["appear"]: false, ["enterDuration"]: 200, ["leaveDuration"]: 500 });
        // Source "entry.proto.ts":5:3
        return (r: __puiVueFrame) => {
          // Source "entry.proto.ts":5:13
          return __puiVueElement(r, "section", ["Transition view ", __puiVueSlot(r)]);
        };
      })();
        __puiVueSetup = false;
        __puiVueRawProps = __puiVueGetHostProps();

        __puiVueProps = __puiVueResolveProps(__puiVueRawProps, true);

        

        __puiVueInvokeLife('created');
        return renderer;
      } catch (error) {
        __puiVueDisposing = true;
        try {  }
        finally {
          try {  }
          finally {
            try { __puiVueScope.dispose(); }
            finally {
              __puiVueDisposed = true; { let failed = false, first; for (const release of [() => { __puiVueDelay.dispose(); }, () => { __puiVuePresence.dispose(); }]) { try { release(); } catch (error) { if (!failed) { failed = true; first = error; } } } if (failed) throw first; }__puiVueAuthored.dispose();
              for (const cleanup of __puiVueStateCleanup) cleanup();
              __puiVueStateQueue.length = 0; __puiVueWatchers.length = 0;
            }
          }
        }
        throw error;
      }
    })();

    const __puiVueHandle: GeneratedHandle = Object.freeze({
      update() { __puiVuePublicAlive(); __puiVueRequestUpdate(__puiVueRunValue); },
      getExposes() { __puiVuePublicAlive(); return __puiVueExposes as GeneratedExposes; },
    });
    __puiVueContext.expose(__puiVueHandle);

    const __puiVueView = __puiVueVue.defineComponent({
      name: 'CompiledView', inheritAttrs: false,
      props: { revision: { type: Number, required: true } },
      setup(viewProps) {
        let epoch: __puiVueEpoch = { id: ++__puiVueEpochId, active: true, committed: false };
        __puiVueCurrentEpoch = epoch;
        const activation = __puiVueVue.shallowRef(0);
        let deactivated = false;

        let drawnRevision = -1, drawnActivation = -1, committedRevision = -1;
        let cached: __puiVueVue.VNodeArrayChildren = [];
        let root: HTMLElement | null = null;
        function bindRoot(element: Element | __puiVueVue.ComponentPublicInstance | null): void {
          if (!element) { __puiVueUnbindRoot(epoch); return; }
          if (!(element instanceof HTMLElement)) throw new TypeError('[Vue source] Root must be an HTMLElement');
          root = element;
          if (epoch !== __puiVueCurrentEpoch || !epoch.active) return;
          if (__puiVueRootEpoch && (__puiVueRootElement !== root || __puiVueRootEpoch !== epoch)) __puiVueUnbindRoot(__puiVueRootEpoch);
          __puiVueRootElement = root; __puiVueRootEpoch = root ? epoch : undefined;
          if (epoch.committed) {

            

          }
        }
        function commit(): void {

          if (__puiVueDisposed || __puiVueDisposing || deactivated || !epoch.active || epoch !== __puiVueCurrentEpoch || !__puiVuePresent.value) return;
          if (!epoch.committed) {

            epoch.committed = true;
            committedRevision = drawnRevision;

            


            __puiVueInvokeLife('mounted');

          }
          else if (committedRevision !== drawnRevision) { committedRevision = drawnRevision; __puiVueInvokeLife('updated'); }
        }
        __puiVueVue.onMounted(commit);
        __puiVueVue.onUpdated(commit);
        __puiVueVue.onBeforeUnmount(() => { epoch.active = false; __puiVueUnbindRoot(epoch); });
        __puiVueVue.onUnmounted(() => { __puiVueCommitUnmount(epoch); });
        __puiVueVue.onDeactivated(() => { deactivated = true; __puiVueCommitUnmount(epoch); });
        __puiVueVue.onActivated(() => {
          if (!deactivated || __puiVueDisposed || __puiVueDisposing) return;
          deactivated = false;
          epoch = { id: ++__puiVueEpochId, active: true, committed: false };
          __puiVueCurrentEpoch = epoch;
          __puiVueRootElement = root; __puiVueRootEpoch = root ? epoch : undefined;
          activation.value += 1;
        });
        return () => {
          __puiVueHostRevision.value;
          const revision = viewProps.revision!, active = activation.value;
          if (__puiVueDisposed || __puiVueDisposing || deactivated || !epoch.active || epoch !== __puiVueCurrentEpoch || !__puiVuePresent.value) return null;
          if (drawnRevision !== revision || drawnActivation !== active) {
            drawnRevision = revision; drawnActivation = active;
            __puiVueRequested = false;
            const frame: __puiVueFrame = { epoch, slotUsed: false };
            const children = typeof __puiVueRenderer === 'function' ? __puiVueChildren(__puiVueRenderer(frame)) : __puiVueSlot(frame);
            cached = children == null ? [] : Array.isArray(children) ? children : [children];
          }
          const tag = 'div';
          if (['input', 'textarea', 'img'].includes(tag) && cached.length) throw new Error('[Template] physical control Root requires empty children');
          const physical = __puiVueVue.h(tag, { 'data-pui-root': '', ref: bindRoot }, cached.length ? cached : undefined);
          return physical;
        };
      },
    });
    __puiVueVue.onBeforeUpdate(() => { __puiVueNotifyProps(); __puiVueSlotRevision.value += 1; });
    __puiVueVue.onBeforeUnmount(() => {
      __puiVueDisposing = true;
      __puiVueQueueTicket += 1;
      __puiVueRequested = false;
      if (__puiVueCurrentEpoch) __puiVueUnbindRoot(__puiVueCurrentEpoch);
      if (__puiVueCurrentEpoch) __puiVueCurrentEpoch.active = false;
    });
    __puiVueVue.onUnmounted(() => {
      __puiVueInternalTeardown = true;
      try { __puiVueInvokeLife('beforeDispose'); }

      finally {
        try { __puiVueScope.dispose(); }

        finally {
          try {  }

          finally {
            try {  }

            finally {
              __puiVueInternalTeardown = false; __puiVueDisposed = true;
              { let failed = false, first; for (const release of [() => { __puiVueDelay.dispose(); }, () => { __puiVuePresence.dispose(); }]) { try { release(); } catch (error) { if (!failed) { failed = true; first = error; } } } if (failed) throw first; }__puiVueAuthored.dispose();
              for (const cleanup of __puiVueStateCleanup) cleanup();
              __puiVueStateQueue.length = 0; __puiVueWatchers.length = 0;
            }
          }
        }
      }
    });
    return () => __puiVuePresent.value && !__puiVueDisposing ? __puiVueVue.h(__puiVueView, { revision: __puiVueRevision.value }) : null;
  },
});

export default CompiledComponent;

//# sourceMappingURL=Component.ts.map
