import {
  require_react
} from "./chunk-3TI7BCXY.js";
export default require_react();
