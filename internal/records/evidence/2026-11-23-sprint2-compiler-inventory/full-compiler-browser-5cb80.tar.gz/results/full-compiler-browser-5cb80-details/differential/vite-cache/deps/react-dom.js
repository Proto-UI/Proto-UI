import {
  require_react_dom
} from "./chunk-3CMPWPZU.js";
import "./chunk-3TI7BCXY.js";
export default require_react_dom();
