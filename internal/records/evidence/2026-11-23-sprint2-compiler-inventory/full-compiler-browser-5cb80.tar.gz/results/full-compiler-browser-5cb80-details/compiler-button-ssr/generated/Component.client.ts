// Browser-only entry. Import Component.ts on the server, never this module.
import {createHydrationOwner, hydrationBinding, hydrationArtifacts, hydrationCssText, hydrationEnvironmentCssText, defaultTagName, type GeneratedProps, type GeneratedExposes, type HydrationOwner} from './Component';
import {type Carrier, type BrowserPort, createBrowserPort, readCarrier, checkCarrier, decodeRaw, pendingProviderDefinition, checkInitialProps, checkStylesheet, checkCarrierHost, assertNoInstanceAssociations, HydrationMismatch} from './.proto-ui/web-component/ssr-e6807d4f71af1465-v2';
import {validateNativeInstanceAssociations} from './.proto-ui/interaction/control-label-v1';

export {HydrationMismatch} from './.proto-ui/web-component/ssr-e6807d4f71af1465-v2';
export class CompiledButton extends HTMLElement {
  private owner: HydrationOwner | null = null;
  private port: BrowserPort | null = null;
  private raw: Record<string, unknown> = {};
  private hasRaw = false;
  private carrier: Carrier | null = null;
  private closed = false;
  private disconnectVersion = 0;
  private recovering = false;
  private initializedCarrier = false;
  private acceptedMode: 'light' | 'shadow' | null = null;
  private failedCarrier: Carrier | null = null;
  private associations: Readonly<{controlLabel?: object | null}> | undefined;
  hydrationStatus: 'pending' | 'adopted' | 'recovered' | 'client' | 'mismatch' = 'pending';
  hydrationDiagnostic: HydrationMismatch | null = null;
  get logicalOwner(): symbol | null { return this.owner?.identity ?? null; }
  get viewEpoch(): number { return this.owner?.epoch ?? 0; }
  get present(): boolean { return this.owner?.view ?? false; }
  get instanceAssociations(): Readonly<{controlLabel?: object | null}> | undefined { return this.associations; }
  set instanceAssociations(value: Readonly<{controlLabel?: object | null}> | undefined) {
    if (this.closed) throw new Error('Custom element is disposed');
    const accepted = validateNativeInstanceAssociations(value);

    this.associations = accepted;
    this.owner?.interaction.refresh();
  }
  static get observedAttributes(): string[] { return ['instance-associations', 'instanceassociations']; }
  attributeChangedCallback(_name: string, _previous: string | null, value: string | null): void {
    if (value !== null) throw new TypeError('[InstanceAssociations] use the instanceAssociations property, not an attribute string');
  }
  connectedCallback(): void {
    ++this.disconnectVersion;
    if (this.closed) return;
    if (this.owner) { this.owner.reconcile(); return; }
    const definition = pendingProviderDefinition(this);
    if (definition) {
      const version = this.disconnectVersion;
      definition.then(() => {
        if (this.closed || version !== this.disconnectVersion || !this.isConnected || this.owner) return;
        this.connectedCallback();
      });
      return;
    }
    try {
      const carrier = this.recovering ? this.failedCarrier : this.carrier ?? (!this.initializedCarrier ? readCarrier(this) : null);
      this.failedCarrier = carrier;
      if (carrier && !this.recovering) checkCarrier(carrier, hydrationBinding, this.localName, hydrationArtifacts);
      if (carrier && !this.recovering) {
        if (this.hasRaw) checkInitialProps(this.raw, carrier);
        checkStylesheet(this, hydrationArtifacts.css, hydrationCssText);
        checkStylesheet(this, hydrationArtifacts.environment, hydrationEnvironmentCssText, 'consumer environment');
      }
      let mode = carrier?.mode ?? this.acceptedMode ?? 'light';
      if (this.recovering) mode = carrier?.mode === 'shadow' || this.shadowRoot || this.querySelector(':scope > template[shadowrootmode="open"]') ? 'shadow' : 'light';
      const port = createBrowserPort(this, mode, carrier && !this.recovering ? carrier : null, this.recovering);
      this.port = port;
      const pending = this.hasRaw ? this.raw : null;
      const initial = carrier && !this.recovering ? decodeRaw(carrier.raw) : this.raw;
      if (!pending) this.raw = {...initial};
      const owner = createHydrationOwner(port, initial, () => this.associations);
      this.owner = owner;
      try { owner.validateHydration(); owner.reconcile(); }
      catch (error) { this.owner = null; try { owner.dispose(); } catch (cleanup) { throw new AggregateError([error, cleanup], 'Hydration and cleanup failed'); } throw error; }
      port.accept();
      if (this.closed || this.owner !== owner) return;
      this.acceptedMode = mode;
      this.initializedCarrier = true;
      this.carrier = null;
      this.failedCarrier = null;
      this.hydrationStatus = this.recovering ? 'recovered' : carrier ? 'adopted' : 'client';
      this.recovering = false;
      // Initial handoff is silent; a newer client snapshot is a real post-commit Props transition.
      if (this.hasRaw && carrier) owner.hydrate(this.raw);
    } catch (error) {
      const owner = this.owner; this.owner = null;
      let failure = error;
      try { owner?.dispose(); } catch (cleanup) { failure = new AggregateError([error, cleanup], 'Initialization and cleanup failed'); }
      finally { this.port?.dispose(); this.port = null; }
      if (error instanceof HydrationMismatch) { this.hydrationStatus = 'mismatch'; this.hydrationDiagnostic = error; }
      throw failure;
    }
  }
  disconnectedCallback(): void {
    const version = ++this.disconnectVersion, owner = this.owner;
    queueMicrotask(() => {
      if (version !== this.disconnectVersion || this.isConnected || !owner || owner !== this.owner) return;
      this.owner = null;
      try { owner.dispose(); } finally { this.port?.dispose(); this.port = null; }
    });
  }
  setProps(next: GeneratedProps & Record<string, unknown>): void {
    if (this.closed) throw new Error('Custom element is disposed');
    assertNoInstanceAssociations(next, 'Props');
    this.hasRaw = true; this.raw = {...next};
    if (this.owner) this.owner.hydrate(this.raw);
  }
  update(): void { if (this.closed) throw new Error('Custom element is disposed'); this.owner?.update(); }
  getExposes(): Partial<GeneratedExposes> { return this.isConnected && this.owner ? {...this.owner.exposes} as Partial<GeneratedExposes> : {}; }
  hydrate(next: Carrier): void {
    if (this.closed) throw new Error('Custom element is disposed');
    checkCarrier(next, hydrationBinding, this.localName, hydrationArtifacts);
    if (this.owner) throw new Error('Custom element already owns a committed instance');
    if (this.initializedCarrier) throw new Error('Carrier has already been adopted');
    this.carrier = next;
    if (this.isConnected) this.connectedCallback();
  }
  /** Recovery is opt-in and reports recovered, never adopted. Existing external slot nodes are preserved. */
  recover(next?: GeneratedProps & Record<string, unknown>): void {
    if (this.closed) throw new Error('Custom element is disposed');
    if (this.hydrationStatus !== 'mismatch') throw new Error('Recovery requires a diagnosed hydration mismatch');
    if (next) { assertNoInstanceAssociations(next, 'Props'); this.raw = {...next}; this.hasRaw = true; }
    this.carrier = this.failedCarrier;
    this.recovering = true;
    if (this.isConnected) this.connectedCallback();
  }
  dispose(): void {
    if (this.closed) return;
    this.closed = true; ++this.disconnectVersion;
    const owner = this.owner; this.owner = null;
    try { owner?.dispose(); } finally { this.port?.dispose(); this.port = null; this.carrier = null; }
  }
}
export function register(tagName = defaultTagName, registry: CustomElementRegistry = customElements): typeof CompiledButton {
  const existing = registry.get(tagName);
  if (existing && existing !== CompiledButton) throw new Error('Custom element tag already registered: ' + tagName);
  if (!existing) registry.define(tagName, CompiledButton);
  return CompiledButton;
}
/** Define first; server carriers auto-adopt on upgrade. This entry also accepts an explicit carrier on a detached element. */
export function hydrate(element: CompiledButton, carrier?: Carrier): CompiledButton {
  if (!(element instanceof CompiledButton)) throw new Error('Register the generated Custom Element before hydrating');
  if (carrier !== undefined) { checkCarrier(carrier, hydrationBinding, element.localName, hydrationArtifacts); checkCarrierHost(element, carrier); }
  if (element.hydrationStatus === 'mismatch') throw element.hydrationDiagnostic;
  if (carrier && element.hydrationStatus === 'pending') element.hydrate(carrier);
  else if (!element.logicalOwner && element.isConnected) element.connectedCallback();
  return element;
}
export default CompiledButton;
