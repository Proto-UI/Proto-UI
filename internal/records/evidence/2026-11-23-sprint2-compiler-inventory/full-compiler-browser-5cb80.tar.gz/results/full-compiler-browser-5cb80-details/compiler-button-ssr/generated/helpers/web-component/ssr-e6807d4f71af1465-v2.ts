// Standalone WC presentation/serialization/adoption helper. Not an IR interpreter.
// No DOM global is accessed at module evaluation or during server rendering.
import { createNativeInteraction, markNativeExposeEvent, type NativeInteraction } from "../interaction/native-e6807d4f71af1465-v2";
import { ownerScopes, type ContextScope } from '../context/scope-v1';
export type Presentation = {
    kind: 'element';
    tag: string;
    style?: string;
    children: Presentation[];
} | {
    kind: 'text';
    text: string;
} | {
    kind: 'slot';
};
export type RawData = [
    string,
    {
        kind: 'undefined';
    } | {
        kind: 'value';
        value: unknown;
    }
][];
export type ControlProjection = {
    tag: string;
    properties: Readonly<Record<string, string | number | boolean | null>>;
    attributes: Record<string, string>;
};
export type ArtifactVersions = {
    source: string;
    helpers: string;
    css: string;
    environment: string;
};
export type Carrier = {
    instanceId: string;
    artifacts: ArtifactVersions;
    version: 1;
    profile: 'web-component-ssr-v1';
    binding: string;
    tagName: string;
    mode: 'light' | 'shadow';
    raw: RawData;
    presentation: Presentation[];
    control: ControlProjection | null;
    attributes: Record<string, string>;
    interactionAttributes: Record<string, string | null>;
    baselines: Record<string, string>;
    present: boolean;
};
export type InteractionOptions<R> = Parameters<typeof createNativeInteraction<R>>[0];
export type HostPort = {
    readonly server: boolean;
    readonly isConnected: boolean;
    readonly root: HTMLElement | null;
    readonly host: HTMLElement | null;
    readonly hydrationAttributes?: Readonly<Record<string, string | null>>;
    validateInitial?(snapshot: {
        present: boolean;
        attributes: Record<string, string | null>;
    }): void;
    readonly hydrationBaselines?: Readonly<Record<string, string | null>>;
    createInteraction<R>(options: InteractionOptions<R>): NativeInteraction<R>;
    projectRoot(tag: string | null, properties: Readonly<Record<string, string | number | boolean | null>>, portal: HTMLElement | null): void;
    attribute(name: string, value: string | null): void;
    projectInteraction(snapshot: Readonly<Record<string, string | null>>): void;
    commit(children: Presentation[]): void;
    clear(): void;
    visible(present: boolean): void;
    emit(key: string, payload?: unknown, options?: CustomEventInit): void;
    parentContext(): ContextScope | null;
    bindContext(scope: ContextScope | null): void;
};
export type ServerParent = {
    readonly context: ContextScope | null;
    readonly alive: boolean;
};
export type ServerOptions = {
    mode?: 'light' | 'shadow';
    slotHtml?: string | ((parent: ServerParent) => string);
    signal?: AbortSignal;
    parent?: ServerParent;
    rootAttributes?: Record<string, string>;
};
/** The identity channel is never portable Props, markup, or a server carrier. */
export function assertNoInstanceAssociations(input: unknown, subject: string): void {
    if (!input || typeof input !== 'object')
        return;
    for (const key of ['instanceAssociations', 'instance-associations', 'instanceassociations'])
        if (Object.prototype.hasOwnProperty.call(input, key))
            throw new TypeError('[InstanceAssociations] ' + subject + ' cannot carry instance associations; SSR association transport is unsupported, use the dedicated client property');
}
function checkServerAssociationInputs(props: unknown, options: ServerOptions): void {
    assertNoInstanceAssociations(props, 'Props');
    assertNoInstanceAssociations(options, 'ServerOptions');
    assertNoInstanceAssociations(options.rootAttributes, 'Root attributes');
}
export class HydrationMismatch extends Error {
    readonly code = 'PUI_WC_HYDRATION_MISMATCH';
    constructor(readonly reason: string, readonly path = 'Root', options?: ErrorOptions) { super('WC hydration mismatch at ' + path + ': ' + reason, options); this.name = 'HydrationMismatch'; }
}
export function isPresentation(value: unknown): value is Presentation {
    return !!value && typeof value === 'object' && ['element', 'text', 'slot'].includes((value as {
        kind: string;
    }).kind);
}
export function presentationChildren(input: unknown): Presentation[] {
    const result: Presentation[] = [];
    function append(value: unknown) {
        if (value === null)
            return;
        if (Array.isArray(value)) {
            for (const child of value)
                append(child);
            return;
        }
        const node = typeof value === 'string' || typeof value === 'number' ? { kind: 'text' as const, text: String(value) } : value;
        if (!isPresentation(node))
            throw new TypeError('Invalid template child');
        if (node.kind === 'text') {
            // HTML parsers coalesce adjacent text; canonicalize without changing the text content.
            if (!node.text)
                return;
            const previous = result[result.length - 1];
            if (previous?.kind === 'text') {
                previous.text += node.text;
                return;
            }
            result.push({ kind: 'text', text: node.text });
        }
        else
            result.push(node);
    }
    append(input);
    return result;
}
export function presentationElement(tag: string, style: string | undefined, children: unknown): Presentation {
    if (!/^[A-Za-z][A-Za-z0-9:_-]*$/.test(tag))
        throw new TypeError('Invalid template tag');
    return { kind: 'element', tag: tag.toLowerCase(), ...(style === undefined ? {} : { style }), children: presentationChildren(children) };
}
/** @param {any} input @returns {any} */
function cloneInitialData(input: any): any {
    const ancestors = new Set();
    let nodes = 0, bytes = 0;
    const encoder = new TextEncoder();
    /** @param {string} detail @returns {never} */
    function fail(detail: string): never { throw new TypeError('[Owner initialization] ' + detail); }
    /** @param {string} value */
    function text(value: string) {
        if (value.length > 1048576)
            fail('byte budget exceeded');
        bytes += encoder.encode(JSON.stringify(value)).length;
        if (bytes > 1048576)
            fail('byte budget exceeded');
    }
    /** @param {any} value @param {number} depth @returns {any} */
    function visit(value: any, depth: number): any {
        if (depth > 64)
            fail('depth budget exceeded');
        if (++nodes > 10000)
            fail('node budget exceeded');
        bytes += 32;
        if (bytes > 1048576)
            fail('byte budget exceeded');
        if (value === null || value === undefined || typeof value === 'boolean')
            return value;
        if (typeof value === 'number') {
            if (!Number.isFinite(value))
                fail('numbers must be finite');
            return value;
        }
        if (typeof value === 'string') {
            text(value);
            return value;
        }
        if (typeof value !== 'object')
            fail('live capabilities are not data');
        if (ancestors.has(value))
            fail('cyclic data');
        const array = Array.isArray(value), prototype = Object.getPrototypeOf(value);
        if (array ? prototype !== Array.prototype : prototype !== Object.prototype && prototype !== null)
            fail('non-data prototype');
        const keys = Reflect.ownKeys(value);
        if (keys.length > 10000)
            fail('node budget exceeded');
        if (array && (value.length > 10000 || keys.length !== value.length + 1))
            fail('sparse or extended array');
        const copy = array ? [] : Object.create(null);
        ancestors.add(value);
        try {
            for (const key of keys) {
                if (array && key === 'length')
                    continue;
                const field = Object.getOwnPropertyDescriptor(value, key);
                if (!field || typeof key !== 'string' || !field.enumerable || !('value' in field))
                    fail('accessor, symbol or nonenumerable field');
                if (array && (!/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= value.length))
                    fail('extended array');
                text(key);
                Object.defineProperty(copy, key, { value: visit(field.value, depth + 1), enumerable: true });
            }
        }
        finally {
            ancestors.delete(value);
        }
        return Object.freeze(copy);
    }
    return visit(input, 0);
}
/** @param {any} input @returns {any} */
function decodeInitialData(input: any): any {
    /** @returns {never} */
    function invalid(): never { throw new TypeError('[Owner initialization] malformed data encoding'); }
    /** @param {any} value @returns {any} */
    function decode(value: any): any {
        if (value === null || typeof value === 'string' || typeof value === 'boolean' || typeof value === 'number' && Number.isFinite(value))
            return value;
        if (!Array.isArray(value))
            return invalid();
        if (value.length === 1 && value[0] === 'undefined')
            return undefined;
        if (value.length === 1 && value[0] === 'negative-zero')
            return -0;
        if (value.length !== 2 || !Array.isArray(value[1]))
            return invalid();
        if (value[0] === 'array')
            return Object.freeze(value[1].map(decode));
        if (value[0] !== 'record')
            return invalid();
        const record = Object.create(null);
        for (const entry of value[1]) {
            if (!Array.isArray(entry) || entry.length !== 2 || typeof entry[0] !== 'string' || Object.hasOwn(record, entry[0]))
                return invalid();
            Object.defineProperty(record, entry[0], { value: decode(entry[1]), enumerable: true });
        }
        return Object.freeze(record);
    }
    return decode(cloneInitialData(input));
}
function checkData(value: unknown, seen = new Set<object>()): void {
    if (!seen.size)
        value = cloneInitialData(value);
    if (value === null || typeof value === 'string' || typeof value === 'boolean')
        return;
    if (typeof value === 'number' && Number.isFinite(value))
        return;
    if (typeof value !== 'object' || seen.has(value))
        throw new TypeError('SSR transport requires finite acyclic JSON data');
    const array = Array.isArray(value), proto = Object.getPrototypeOf(value);
    if (array ? proto !== Array.prototype : proto !== Object.prototype && proto !== null)
        throw new TypeError('SSR transport rejects non-data objects');
    seen.add(value);
    try {
        if (array && Object.keys(value).length !== (value as unknown[]).length)
            throw new TypeError('SSR transport rejects sparse arrays');
        for (const key of Reflect.ownKeys(value)) {
            if (array && key === 'length')
                continue;
            const field = Object.getOwnPropertyDescriptor(value, key)!;
            if (typeof key !== 'string' || !field.enumerable || !('value' in field))
                throw new TypeError('SSR transport rejects accessor/symbol fields');
            checkData(field.value, seen);
        }
    }
    finally {
        seen.delete(value);
    }
}
function encodeRaw(raw: Record<string, unknown>): RawData {
    raw = cloneInitialData(raw);
    function encode(value: unknown, seen = new Set<object>()): unknown {
        if (value === undefined)
            return ['undefined'];
        if (Object.is(value, -0))
            return ['negative-zero'];
        if (value === null || typeof value === 'string' || typeof value === 'boolean' || typeof value === 'number' && Number.isFinite(value))
            return value;
        if (!value || typeof value !== 'object' || seen.has(value))
            throw new TypeError('Non-portable initial data');
        const array = Array.isArray(value), proto = Object.getPrototypeOf(value);
        if (array ? proto !== Array.prototype : proto !== Object.prototype && proto !== null)
            throw new TypeError('Capabilities cannot enter initial data');
        seen.add(value);
        try {
            if (array && Object.keys(value).length !== value.length)
                throw new TypeError('SSR transport rejects sparse arrays');
            for (const key of Reflect.ownKeys(value)) {
                if (array && key === 'length')
                    continue;
                const field = Object.getOwnPropertyDescriptor(value, key)!;
                if (typeof key !== 'string' || !field.enumerable || !('value' in field))
                    throw new TypeError('SSR transport rejects accessor/symbol fields');
            }
            return array ? ['array', value.map(item => encode(item, seen))] : ['record', Object.entries(value).map(([key, item]) => [key, encode(item, seen)])];
        }
        finally {
            seen.delete(value);
        }
    }
    // Own data descriptors are validated without reading accessor values.
    encode(raw);
    return Object.keys(raw).map(key => [key, { kind: 'value', value: encode(raw[key]) }]);
}
export function decodeRaw(data: RawData): Record<string, unknown> {
    data = cloneInitialData(data);
    const decode = decodeInitialData;
    const raw = Object.create(null) as Record<string, unknown>;
    for (const [key, value] of data) {
        if (['instanceAssociations', 'instance-associations', 'instanceassociations'].includes(key))
            throw new HydrationMismatch('instance associations cannot enter serialized Props');
        if (Object.hasOwn(raw, key))
            throw new HydrationMismatch('duplicate raw Prop key');
        raw[key] = value.kind === 'undefined' ? undefined : decode(value.value);
    }
    return raw;
}
export function checkCarrier(carrier: Carrier, binding: string, tag: string, artifacts?: ArtifactVersions): void {
    try {
        checkData(carrier);
    }
    catch (cause) {
        throw new HydrationMismatch('carrier contains non-transport data', 'Root', { cause });
    }
    try {
        assertNoInstanceAssociations(carrier, 'Carrier');
        assertNoInstanceAssociations(carrier?.attributes, 'Root attributes');
        assertNoInstanceAssociations(carrier?.baselines, 'Root baselines');
    }
    catch {
        throw new HydrationMismatch('instance association carrier transport is unsupported');
    }
    if (!carrier || typeof carrier !== 'object')
        throw new HydrationMismatch('invalid carrier');
    if (carrier.version !== 1 || carrier.profile !== 'web-component-ssr-v1' || carrier.binding !== binding || carrier.tagName !== tag)
        throw new HydrationMismatch('source/profile/tag binding differs');
    if (!carrier.artifacts || artifacts && ['source', 'helpers', 'css', 'environment'].some(key => carrier.artifacts[key as keyof ArtifactVersions] !== artifacts[key as keyof ArtifactVersions]))
        throw new HydrationMismatch('source/helper/CSS artifact version differs');
    if (typeof carrier.instanceId !== 'string' || !/^[a-z0-9-]+$/i.test(carrier.instanceId))
        throw new HydrationMismatch('invalid instance identity');
    if (!['light', 'shadow'].includes(carrier.mode) || typeof carrier.present !== 'boolean' || !Array.isArray(carrier.raw) || !Array.isArray(carrier.presentation))
        throw new HydrationMismatch('invalid carrier');
    for (const entry of carrier.raw) {
        if (!Array.isArray(entry) || entry.length !== 2 || typeof entry[0] !== 'string' || !entry[1] || typeof entry[1] !== 'object' || !['undefined', 'value'].includes(entry[1].kind) || entry[1].kind === 'value' && !Object.hasOwn(entry[1], 'value'))
            throw new HydrationMismatch('invalid raw Prop entry');
    }
    for (const snapshot of [carrier.attributes, carrier.interactionAttributes, carrier.baselines]) {
        if (!snapshot || Array.isArray(snapshot) || typeof snapshot !== 'object' || Object.values(snapshot).some(value => value !== null && typeof value !== 'string'))
            throw new HydrationMismatch('invalid Root attribute snapshot');
    }
    let slots = 0;
    function checkChildren(children: Presentation[]) {
        for (const node of children) {
            if (!node || typeof node !== 'object')
                throw new HydrationMismatch('invalid presentation node');
            if (node.kind === 'slot') {
                if (++slots > 1)
                    throw new HydrationMismatch('multiple slot projection');
            }
            else if (node.kind === 'text') {
                if (typeof node.text !== 'string')
                    throw new HydrationMismatch('invalid text projection');
            }
            else if (node.kind === 'element') {
                if (typeof node.tag !== 'string' || !/^[a-z][a-z0-9:_-]*$/.test(node.tag) || node.style !== undefined && typeof node.style !== 'string' || !Array.isArray(node.children))
                    throw new HydrationMismatch('invalid element projection');
                checkChildren(node.children);
            }
            else
                throw new HydrationMismatch('unknown presentation node');
        }
    }
    checkChildren(carrier.presentation);
    try {
        decodeRaw(carrier.raw);
    }
    catch (error) {
        if (error instanceof HydrationMismatch)
            throw error;
        throw new HydrationMismatch('invalid initial data encoding');
    }
}
export function checkInitialProps(raw: Record<string, unknown>, carrier: Carrier): void {
    if (JSON.stringify(encodeRaw(raw)) !== JSON.stringify(carrier.raw))
        throw new HydrationMismatch('client initial props differ from server props');
}
export function checkStylesheet(host: HTMLElement, version: string, cssText: string, subject = 'component'): void {
    if (!cssText)
        return;
    const styles = Array.from(host.ownerDocument.querySelectorAll('style[data-pui-ssr-css]'));
    if (!styles.some(style => style.getAttribute('data-pui-ssr-css') === version && style.textContent === cssText))
        throw new HydrationMismatch('bound first-frame ' + subject + ' CSS artifact is absent or differs');
}
function escapeText(value: string): string { return value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function escapeAttribute(value: string): string { return escapeText(value).replace(/"/g, '&quot;'); }
const voidTags: Record<string, true> = { area: true, base: true, br: true, col: true, embed: true, hr: true, img: true, input: true, link: true, meta: true, param: true, source: true, track: true, wbr: true };
function serialize(children: Presentation[], mode: 'light' | 'shadow', slotHtml: string): string {
    return children.map(node => {
        if (node.kind === 'text')
            return escapeText(node.text);
        if (node.kind === 'slot')
            return mode === 'shadow' ? '<slot></slot>' : '<!--pui-slot-start-->' + slotHtml + '<!--pui-slot-end-->';
        const style = node.style === undefined ? '' : ' data-pui-style="' + escapeAttribute(node.style) + '"';
        if (voidTags[node.tag]) {
            if (node.children.length)
                throw new TypeError('Void template element cannot have children: ' + node.tag);
            return '<' + node.tag + style + '>';
        }
        return '<' + node.tag + style + '>' + serialize(node.children, mode, slotHtml) + '</' + node.tag + '>';
    }).join('');
}
export type ServerPort = HostPort & {
    presentation: Presentation[];
    control: ControlProjection | null;
    attributes: Record<string, string>;
    interactionAttributes: Record<string, string | null>;
    present: boolean;
    parent: ServerParent;
    emissions: {
        key: string;
        payload: unknown;
        options?: CustomEventInit;
    }[];
    close(): void;
};
export function createServerPort(options: ServerOptions): ServerPort {
    checkServerAssociationInputs(undefined, options);
    let alive = true, context: ContextScope | null = null;
    if (options.parent && !options.parent.alive)
        throw new Error('Server logical parent is disposed');
    const parent: ServerParent = { get context() { if (!alive)
            throw new Error('Server owner is disposed'); return context; }, get alive() { return alive; } };
    const port: ServerPort = {
        server: true, get isConnected() { return alive; }, root: null, host: null, parent, control: null,
        presentation: [], attributes: { ...options.rootAttributes }, interactionAttributes: Object.create(null), present: true, emissions: [],
        createInteraction: createNativeInteraction,
        projectRoot(tag, properties) { if (tag && !['input', 'textarea', 'img'].includes(tag))
            throw new Error('Unsupported physical Root tag'); port.control = tag ? { tag, properties, attributes: port.control?.attributes ?? {} } : null; },
        attribute(name, value) { const attributes = port.control?.attributes ?? port.attributes; if (value === null)
            delete attributes[name];
        else
            attributes[name] = value; },
        projectInteraction(snapshot) { port.interactionAttributes = { ...snapshot }; for (const [key, value] of Object.entries(snapshot))
            port.attribute(key, value); },
        commit(children) { if (port.control && children.length)
            throw new Error('[Template] physical control Root requires empty children'); port.presentation = children; }, clear() { port.presentation = []; }, visible(next) { port.present = next; },
        emit(key, payload, eventOptions) { port.emissions.push({ key, payload, options: eventOptions }); },
        parentContext() { if (options.parent && !options.parent.alive)
            throw new Error('Server logical parent is disposed'); return options.parent?.context ?? null; },
        bindContext(next) { context = next; },
        close() { alive = false; context = null; port.presentation = []; port.emissions.length = 0; },
    };
    return port;
}
export function finishServer(port: ServerPort, props: Record<string, unknown>, options: ServerOptions, binding: string, tagName: string, artifacts: ArtifactVersions): {
    html: string;
    carrier: Carrier;
} {
    checkServerAssociationInputs(props, options);
    const mode = options.mode ?? 'light';
    if (mode !== 'light' && mode !== 'shadow')
        throw new TypeError('Invalid server rendering mode');
    const instanceId = 'pui-' + globalThis.crypto.randomUUID();
    const attributes = { ...port.attributes };
    for (const name of ['data-pui-instance', 'data-pui-props', 'data-pui-ssr'])
        if (Object.hasOwn(attributes, name))
            throw new TypeError('Reserved SSR attribute: ' + name);
    attributes.id ??= instanceId;
    attributes['data-pui-instance'] = instanceId;
    attributes['data-pui-props'] = JSON.stringify(encodeRaw(props));
    attributes['data-pui-ssr'] = binding;
    for (const [name, value] of Object.entries(attributes)) {
        if (!/^[A-Za-z_:][A-Za-z0-9_.:-]*$/.test(name) || typeof value !== 'string')
            throw new TypeError('Invalid serialized Root attribute: ' + name);
    }
    if (!port.present)
        attributes.style = (attributes.style ? attributes.style + ';' : '') + 'display:none!important';
    const control = port.control ? { ...port.control, properties: { ...port.control.properties }, attributes: { ...port.control.attributes } } : null;
    const carrier: Carrier = { instanceId, artifacts: { ...artifacts }, version: 1, profile: 'web-component-ssr-v1', binding, tagName, mode, raw: encodeRaw(props), presentation: JSON.parse(JSON.stringify(port.presentation)), control, attributes, interactionAttributes: { ...port.interactionAttributes }, baselines: { ...options.rootAttributes }, present: port.present };
    // Use the actual receiver's complete-envelope boundary before publication.
    checkCarrier(carrier, binding, tagName, artifacts);
    const tokens = Object.entries(attributes).map(([name, value]) => ' ' + name + '="' + escapeAttribute(value) + '"').join('');
    const slotHtml = typeof options.slotHtml === 'function' ? options.slotHtml(port.parent) : options.slotHtml ?? '';
    if (typeof slotHtml !== 'string')
        throw new TypeError('Native server slot must serialize to HTML');
    options.signal?.throwIfAborted();
    let content = serialize(carrier.presentation, mode, slotHtml);
    if (carrier.control && carrier.present) {
        const control = carrier.control, properties = { ...control.properties, ...control.attributes };
        let attrs = ' part="' + (control.tag === 'img' ? 'image' : 'control') + '"';
        for (const [name, value] of Object.entries(properties)) {
            if (value === null || value === false || control.tag === 'textarea' && name === 'value')
                continue;
            attrs += ' ' + name + '="' + escapeAttribute(value === true ? '' : String(value)) + '"';
        }
        content = '<' + control.tag + attrs + '>' + (control.tag === 'textarea' ? escapeText(String(properties.value ?? '')) + '</textarea>' : '');
    }
    function hasSlot(children: Presentation[]): boolean {
        for (const child of children)
            if (child.kind === 'slot' || child.kind === 'element' && hasSlot(child.children))
                return true;
        return false;
    }
    const retained = mode === 'shadow' || !hasSlot(carrier.presentation) ? slotHtml : '';
    const projection = mode === 'shadow' ? '<template shadowrootmode="open">' + content + '</template>' + retained : '<!--pui-root-start-->' + content + '<!--pui-root-end-->' + retained;
    const json = JSON.stringify(carrier).replace(/</g, '\\u003c').replace(/&/g, '\\u0026').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
    return { html: '<' + tagName + tokens + '>' + projection + '<script type="application/json" data-pui-carrier="' + binding + '">' + json + '</script></' + tagName + '>', carrier };
}
type ServerOwner = {
    serialize(): void;
    dispose(): void;
};
export function withServerOwner<O extends ServerOwner, T>(factory: (port: HostPort, raw: Record<string, unknown>) => O, props: Record<string, unknown>, options: ServerOptions, binding: string, tag: string, consume: (result: {
    html: string;
    carrier: Carrier;
}, parent: ServerParent) => T, artifacts: ArtifactVersions): T {
    checkServerAssociationInputs(props, options);
    options.signal?.throwIfAborted();
    props = cloneInitialData(props); // Trusted caller/decoded data only; Proxy traps are not sandboxed.
    encodeRaw(props);
    const port = createServerPort(options);
    let owner: O | undefined, failure: unknown, result: T, failed = false;
    let abortFailure: unknown, abortFailed = false;
    const abort = () => { if (!failed) {
        failure = options.signal!.reason;
        failed = true;
    } try {
        owner?.dispose();
    }
    catch (error) {
        abortFailure = error;
        abortFailed = true;
    }
    finally {
        port.close();
    } };
    options.signal?.addEventListener('abort', abort, { once: true });
    try {
        owner = factory(port, props);
        options.signal?.throwIfAborted();
        // Resolve supplied children while the logical provider is live, before its final projection.
        // Child created callbacks may update the provider; the parent then serializes the latest intent.
        const slotHtml = typeof options.slotHtml === 'function' ? options.slotHtml(port.parent) : options.slotHtml;
        if (slotHtml !== undefined && typeof slotHtml !== 'string')
            throw new TypeError('Native server slot must serialize to HTML');
        options.signal?.throwIfAborted();
        owner.serialize();
        options.signal?.throwIfAborted();
        result = consume(finishServer(port, props, { ...options, slotHtml }, binding, tag, artifacts), port.parent);
        if (result && typeof (result as {
            then?: unknown;
        }).then === 'function')
            throw new TypeError('Server logical scope callback must be synchronous');
        options.signal?.throwIfAborted();
    }
    catch (error) {
        if (!failed) {
            failure = error;
            failed = true;
        }
    }
    finally {
        options.signal?.removeEventListener('abort', abort);
        try {
            owner?.dispose();
        }
        catch (error) {
            if (!failed) {
                failure = options.signal?.aborted ? options.signal.reason : error;
                failed = true;
            }
        }
        port.close();
        if (!failed && options.signal?.aborted) {
            failure = options.signal.reason;
            failed = true;
        }
        if (abortFailed && !failed) {
            failure = abortFailure;
            failed = true;
        }
    }
    if (failed)
        throw failure;
    return result!;
}
export type BrowserPort = HostPort & {
    accept(): void;
    dispose(): void;
};
function marker(node: Node | null, text: string): node is Comment { return !!node && node.nodeType === 8 && node.nodeValue === text; }
function carrierNode(host: HTMLElement): HTMLScriptElement | null {
    const nodes = Array.from(host.children).filter(node => node.localName === 'script' && node.hasAttribute('data-pui-carrier'));
    if (nodes.length > 1)
        throw new HydrationMismatch('multiple transport carriers');
    return nodes[0] as HTMLScriptElement | undefined ?? null;
}
export function readCarrier(host: HTMLElement): Carrier | null {
    const node = carrierNode(host);
    // A marked server frame must never fall through to client-only reconstruction.
    // Check independent markers too, so removing one attribute cannot erase SSR intent.
    const marked = ['data-pui-ssr', 'data-pui-instance', 'data-pui-props'].some(name => host.hasAttribute(name)) ||
        Array.from(host.childNodes).some(node => marker(node, 'pui-root-start') || marker(node, 'pui-root-end'));
    if (!node) {
        if (marked)
            throw new HydrationMismatch('SSR-marked host is missing its carrier');
        return null;
    }
    if (node.getAttribute('type') !== 'application/json')
        throw new HydrationMismatch('carrier script type differs');
    let parsed: unknown;
    try {
        parsed = JSON.parse(node.textContent ?? '');
    }
    catch {
        throw new HydrationMismatch('invalid carrier JSON');
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed))
        throw new HydrationMismatch('carrier must be an object');
    const carrier = parsed as Carrier;
    if (node.getAttribute('data-pui-carrier') !== carrier.binding)
        throw new HydrationMismatch('carrier script binding differs');
    return carrier;
}
export function checkCarrierHost(host: HTMLElement, carrier: Carrier): void {
    if (host.getAttribute('data-pui-instance') !== carrier.instanceId || host.getAttribute('data-pui-ssr') !== carrier.binding)
        throw new HydrationMismatch('physical instance/source binding differs');
    if (host.getAttribute('data-pui-props') !== JSON.stringify(carrier.raw))
        throw new HydrationMismatch('physical initial props differ from carrier');
}
function logicalParent(host: HTMLElement): ContextScope | null {
    if (!host.isConnected)
        return null;
    let node: Node | null = host;
    while (node) {
        const slot: HTMLSlotElement | null = node.nodeType === 1 ? (node as Element).assignedSlot : null;
        node = slot ?? (node.nodeType === 11 && 'host' in node ? (node as ShadowRoot).host : node.parentNode);
        if (node) {
            const scope = ownerScopes.get(node);
            if (scope)
                return scope;
        }
    }
    return null;
}
/** Delay owner construction, not just input delivery, until an actual carrier-bearing provider upgrades. */
export function pendingProviderDefinition(host: HTMLElement): Promise<CustomElementConstructor> | null {
    let node: Node | null = host;
    while (node) {
        const slot: HTMLSlotElement | null = node.nodeType === 1 ? (node as Element).assignedSlot : null;
        node = slot ?? (node.nodeType === 11 && 'host' in node ? (node as ShadowRoot).host : node.parentNode);
        if (node?.nodeType !== 1 || ownerScopes.has(node))
            continue;
        const parent = node as HTMLElement;
        if (!parent.localName.includes('-') || !carrierNode(parent))
            continue;
        const registry = parent.ownerDocument.defaultView!.customElements;
        if (!registry.get(parent.localName))
            return registry.whenDefined(parent.localName);
    }
    return null;
}
export function createBrowserPort(host: HTMLElement, mode: 'light' | 'shadow', carrier: Carrier | null, recovery: boolean): BrowserPort {
    const doc = host.ownerDocument;
    const initialAttributes = Array.from(host.attributes, attribute => [attribute.name, attribute.value] as const);
    const projectedAttributes = carrier?.control?.attributes ?? carrier?.attributes;
    // rootAttributes belong to the host; physical baselines come only from its serialized properties.
    const projectionBaselines: Readonly<Record<string, string>> | undefined = carrier?.control
        ? Object.fromEntries(Object.entries(carrier.control.properties)
            .filter(([name, value]) => value !== null && value !== false && !(carrier.control!.tag === 'textarea' && name === 'value'))
            .map(([name, value]) => [name.toLowerCase(), value === true ? '' : String(value)]))
        : carrier?.baselines;
    let initialControlAttributes: readonly (readonly [
        string,
        string
    ])[] | null = null;
    if (carrier) {
        checkCarrierHost(host, carrier);
        if (Array.from(doc.querySelectorAll('[data-pui-instance]')).filter(node => node.getAttribute('data-pui-instance') === carrier.instanceId).length > 1)
            throw new HydrationMismatch('duplicate instance identity');
        for (const [name, value] of Object.entries(carrier.attributes))
            if (host.getAttribute(name) !== value)
                throw new HydrationMismatch('Root attribute differs: ' + name);
    }
    let root: HTMLElement | ShadowRoot = host;
    if (recovery)
        for (const node of Array.from(host.children))
            if (node.localName === 'script' && node.hasAttribute('data-pui-carrier'))
                node.remove();
    const script = carrierNode(host);
    if (carrier && mode === 'light' && host.shadowRoot)
        throw new HydrationMismatch('light carrier has a physical Shadow Root');
    if (mode === 'shadow') {
        if (host.shadowRoot)
            root = host.shadowRoot;
        else {
            const declarative = Array.from(host.children).find(node => node.localName === 'template' && node.getAttribute('shadowrootmode') === 'open') as HTMLTemplateElement | undefined;
            if (carrier && !declarative)
                throw new HydrationMismatch('declarative Shadow Root is absent');
            root = host.attachShadow({ mode: 'open' });
            if (declarative) {
                root.appendChild(declarative.content);
                declarative.remove();
            }
        }
    }
    let accepted = false, disposed = false, hydrating = !!carrier;
    let control: HTMLElement | null = null;
    let portalAnchor: Comment | null = null, portalParent: ContextScope | null = null;
    const emissions: {
        key: string;
        payload: unknown;
        options?: CustomEventInit;
    }[] = [];
    let owned = new WeakSet<Node>(), projected: Node[] = [], start: Comment | null = null, end: Comment | null = null;
    let rootStart: Comment | null = null, rootEnd: Comment | null = null;
    let observer: MutationObserver | null = null;
    const attributes = new Map<string, {
        baseline: string | null;
        projected: string | null;
    }>();
    let display: {
        value: string;
        priority: string;
    } | null = null;
    if (carrier && !carrier.present) {
        const baseline = doc.createElement('div').style;
        baseline.cssText = carrier.baselines.style ?? '';
        display = { value: baseline.getPropertyValue('display'), priority: baseline.getPropertyPriority('display') };
    }
    let expected: Presentation[] | null = null;
    function slotNodes(): Node[] {
        if (!start || !end || start.parentNode !== end.parentNode)
            return [];
        const nodes: Node[] = [];
        for (let node = start.nextSibling; node && node !== end; node = node.nextSibling)
            nodes.push(node);
        return nodes;
    }
    function matchList(parent: Node, first: Node | null, boundary: Node | null, children: Presentation[], path: string, mark: boolean): void {
        let current = first;
        for (let index = 0; index < children.length; ++index) {
            const expected = children[index], at = path + '/' + index;
            if (!current || current === boundary)
                throw new HydrationMismatch('missing physical node', at);
            if (expected.kind === 'slot' && mode === 'light') {
                if (!marker(current, 'pui-slot-start'))
                    throw new HydrationMismatch('light slot start differs', at);
                const slotStart = current;
                let slotEnd: Node | null = current.nextSibling;
                while (slotEnd && slotEnd !== boundary && !marker(slotEnd, 'pui-slot-end'))
                    slotEnd = slotEnd.nextSibling;
                if (!marker(slotEnd, 'pui-slot-end'))
                    throw new HydrationMismatch('light slot end differs', at);
                if (mark) {
                    start = slotStart;
                    end = slotEnd;
                    owned.add(start);
                    owned.add(end);
                    projected = slotNodes();
                }
                current = slotEnd.nextSibling;
                continue;
            }
            if (expected.kind === 'text') {
                if (current.nodeType !== 3 || current.nodeValue !== expected.text)
                    throw new HydrationMismatch('text differs', at);
            }
            else {
                const tag = expected.kind === 'slot' ? 'slot' : expected.tag;
                if (current.nodeType !== 1 || (current as Element).localName !== tag)
                    throw new HydrationMismatch('element tag differs', at);
                const el = current as Element;
                if (expected.kind === 'element' && (el.getAttribute('data-pui-style') ?? undefined) !== expected.style)
                    throw new HydrationMismatch('template style differs', at);
                matchList(el, el.firstChild, null, expected.kind === 'slot' ? [] : expected.children, at, mark);
            }
            if (mark)
                owned.add(current);
            current = current.nextSibling;
        }
        if (current !== boundary)
            throw new HydrationMismatch('unexpected physical node', path);
    }
    function locateRange(): void {
        if (mode !== 'light')
            return;
        for (const node of Array.from(host.childNodes)) {
            if (marker(node, 'pui-root-start')) {
                if (rootStart)
                    throw new HydrationMismatch('duplicate Root marker');
                rootStart = node;
            }
            if (marker(node, 'pui-root-end')) {
                if (rootEnd)
                    throw new HydrationMismatch('duplicate Root marker');
                rootEnd = node;
            }
        }
        if (carrier && (!rootStart || !rootEnd))
            throw new HydrationMismatch('light Root ownership markers are absent');
    }
    function matchControl(): HTMLElement {
        const candidate = mode === 'light' ? rootStart!.nextSibling : root.firstChild;
        if (candidate?.nodeType !== 1 || (candidate as Element).localName !== carrier!.control!.tag || candidate.nextSibling !== (mode === 'light' ? rootEnd : null) || control && candidate !== control)
            throw new HydrationMismatch('physical control Root differs');
        for (const [name, value] of Object.entries(carrier!.control!.attributes))
            if ((candidate as Element).getAttribute(name) !== value)
                throw new HydrationMismatch('physical control attribute differs: ' + name);
        return candidate as HTMLElement;
    }
    locateRange();
    if (carrier) {
        if (carrier.control && carrier.present) {
            control = matchControl();
            owned.add(control);
            initialControlAttributes = Array.from(control.attributes, attribute => [attribute.name, attribute.value] as const);
        }
        else
            matchList(root, mode === 'light' ? rootStart!.nextSibling : root.firstChild, mode === 'light' ? rootEnd : null, carrier.presentation, 'Root', true);
        expected = carrier.presentation;
    }
    function pool(): Node[] {
        const result = [...projected.filter(node => !!node.parentNode)];
        if (mode === 'light')
            for (const node of Array.from(host.childNodes)) {
                if (node === script || node === rootStart || node === rootEnd || owned.has(node))
                    continue;
                result.push(node);
            }
        return [...new Set(result)];
    }
    function projectNewChildren(): void {
        if (!end?.parentNode || disposed)
            return;
        const inPlace = end.parentNode === host ? new Set(slotNodes()) : null;
        for (const node of Array.from(host.childNodes)) {
            if (node === script || node === rootStart || node === rootEnd || owned.has(node) || node === end || node === start)
                continue;
            // Direct slot range requires no movement; every other external direct child is projected.
            if (inPlace?.has(node))
                continue;
            end.parentNode.insertBefore(node, end);
            if (!projected.includes(node))
                projected.push(node);
        }
        projected = projected.filter(node => !!node.parentNode);
    }
    function observe(): void {
        if (mode !== 'light' || !end)
            return;
        if (!observer) {
            observer = new (doc.defaultView!.MutationObserver)(projectNewChildren);
            observer.observe(host, { childList: true, subtree: true });
        }
    }
    function materialize(parent: Node, children: Presentation[], slotPool: Node[]): void {
        for (const child of children) {
            let node: Node;
            if (child.kind === 'slot' && mode === 'light') {
                start = doc.createComment('pui-slot-start');
                end = doc.createComment('pui-slot-end');
                owned.add(start);
                owned.add(end);
                parent.appendChild(start);
                for (const external of slotPool)
                    parent.appendChild(external);
                parent.appendChild(end);
                projected = slotPool;
                continue;
            }
            if (child.kind === 'text')
                node = doc.createTextNode(child.text);
            else {
                const el = doc.createElement(child.kind === 'slot' ? 'slot' : child.tag);
                if (child.kind === 'element') {
                    if (child.style !== undefined)
                        el.setAttribute('data-pui-style', child.style);
                    materialize(el, child.children, slotPool);
                }
                node = el;
            }
            owned.add(node);
            parent.appendChild(node);
        }
    }
    function ownRootRange(first: Node, last: Node): void {
        if (first.parentNode !== last.parentNode)
            throw new HydrationMismatch('owned range has different physical parents');
        for (let node: Node | null = first; node; node = node.nextSibling) {
            owned.add(node);
            if (node === last)
                return;
        }
        throw new HydrationMismatch('owned range end is unreachable');
    }
    function removeOwned(): void {
        for (const node of Array.from(root.childNodes))
            if (mode === 'shadow' || owned.has(node) || node === rootStart || node === rootEnd)
                node.parentNode?.removeChild(node);
        rootStart = null;
        rootEnd = null;
    }
    const port: BrowserPort = {
        server: false, get isConnected() { return host.isConnected && !disposed; }, host, get root() { return control ?? host; },
        validateInitial(snapshot) {
            if (!carrier)
                return;
            if (snapshot.present !== carrier.present)
                throw new HydrationMismatch('initial presence differs');
            for (const [name, value] of Object.entries(snapshot.attributes))
                if ((projectedAttributes?.[name] ?? null) !== value)
                    throw new HydrationMismatch('fresh client attribute differs: ' + name);
        },
        hydrationAttributes: carrier?.interactionAttributes,
        hydrationBaselines: projectionBaselines,
        createInteraction: createNativeInteraction,
        projectRoot(tag, properties, portal) {
            if (tag && !['input', 'textarea', 'img'].includes(tag))
                throw new Error('Unsupported physical Root tag');
            if (hydrating && (carrier?.control?.tag ?? null) !== tag)
                throw new HydrationMismatch('client physical Root differs from carrier');
            if (tag && !control) {
                control = doc.createElement(tag);
                control.setAttribute('part', tag === 'img' ? 'image' : 'control');
                owned.add(control);
            }
            if (control && control.localName !== tag)
                throw new Error('Physical control declaration cannot change during an owner lifetime');
            if (control && !hydrating)
                for (const [name, value] of Object.entries(properties)) {
                    if (name === 'value') {
                        if (!accepted)
                            (control as HTMLInputElement).value = String(value ?? '');
                        continue;
                    }
                    if (value === null || value === false)
                        control.removeAttribute(name);
                    else
                        control.setAttribute(name, value === true ? '' : String(value));
                }
            if (portal) {
                if (!portalAnchor) {
                    portalParent = logicalParent(host);
                    portalAnchor = doc.createComment('pui-portal');
                    host.parentNode?.insertBefore(portalAnchor, host);
                }
                if (host.parentNode !== portal)
                    portal.appendChild(host);
            }
            else if (portalAnchor) {
                portalAnchor.parentNode?.insertBefore(host, portalAnchor);
                portalAnchor.remove();
                portalAnchor = null;
                portalParent = null;
            }
        },
        projectInteraction(snapshot) { for (const [key, value] of Object.entries(snapshot))
            port.attribute(key, value); },
        attribute(name, value) {
            let entry = attributes.get(name);
            const target = control ?? host;
            const current = target.getAttribute(name);
            if (!entry) {
                const projectedByServer = projectedAttributes && Object.hasOwn(projectedAttributes, name) && current === projectedAttributes[name];
                entry = { baseline: projectedByServer ? projectionBaselines?.[name] ?? null : current, projected: current };
                attributes.set(name, entry);
            }
            else if (current !== entry.projected)
                entry.baseline = current;
            if (current !== value) {
                if (value === null)
                    target.removeAttribute(name);
                else
                    target.setAttribute(name, value);
            }
            entry.projected = value;
        },
        commit(children) {
            if (disposed)
                throw new Error('Browser port is disposed');
            if (hydrating) {
                if (JSON.stringify(children) !== JSON.stringify(expected))
                    throw new HydrationMismatch('fresh client presentation differs from server projection');
                // Validate a second time immediately before semantic commit; never clear on matching adoption.
                if (control)
                    matchControl();
                else
                    matchList(root, mode === 'light' ? rootStart!.nextSibling : root.firstChild, mode === 'light' ? rootEnd : null, children, 'Root', false);
                hydrating = false;
                projectNewChildren();
                observe();
                return;
            }
            if (control) {
                if (children.length)
                    throw new Error('[Template] physical control Root requires empty children');
                if (control.parentNode !== root)
                    root.appendChild(control);
                return;
            }
            const slotPool = mode === 'light' ? pool() : [];
            for (const node of slotPool)
                node.parentNode?.removeChild(node);
            observer?.disconnect();
            observer = null;
            removeOwned();
            owned = new WeakSet();
            projected = [];
            start = null;
            end = null;
            const fragment = doc.createDocumentFragment();
            materialize(fragment, children, slotPool);
            root.appendChild(fragment);
            if (!start)
                for (const node of slotPool)
                    host.appendChild(node);
            observe();
        },
        visible(present) {
            if (!present) {
                if (!display)
                    display = { value: host.style.getPropertyValue('display'), priority: host.style.getPropertyPriority('display') };
                host.style.setProperty('display', 'none', 'important');
            }
            else if (display) {
                if (host.style.getPropertyValue('display') === 'none' && host.style.getPropertyPriority('display') === 'important') {
                    if (display.value)
                        host.style.setProperty('display', display.value, display.priority);
                    else
                        host.style.removeProperty('display');
                }
                display = null;
            }
        },
        clear() {
            if (!accepted && carrier)
                return; // Any failed initial commit must preserve the server tree, even after matching.
            const slotPool = mode === 'light' ? pool().filter(node => node !== control) : [];
            for (const node of slotPool)
                node.parentNode?.removeChild(node);
            observer?.disconnect();
            observer = null;
            removeOwned();
            start = null;
            end = null;
            projected = [];
            for (const node of slotPool)
                host.appendChild(node);
        },
        emit(key, payload, options) {
            if (!accepted) {
                emissions.push({ key, payload, options });
                return;
            }
            host.dispatchEvent(markNativeExposeEvent(new (doc.defaultView!.CustomEvent)(key, { detail: payload, bubbles: true, cancelable: true, ...options })));
        },
        parentContext: () => portalAnchor ? portalParent : logicalParent(host),
        bindContext(scope) { if (scope)
            ownerScopes.set(host, scope);
        else
            ownerScopes.delete(host); },
        accept() {
            if (hydrating && carrier?.present)
                throw new HydrationMismatch('present carrier was not adopted');
            accepted = true;
            if (script)
                script.remove();
            if (carrier && !carrier.present)
                hydrating = false;
            if (rootStart)
                owned.add(rootStart);
            if (rootEnd)
                owned.add(rootEnd);
            for (const emission of emissions.splice(0)) {
                if (disposed)
                    break;
                port.emit(emission.key, emission.payload, emission.options);
            }
        },
        dispose() {
            if (disposed)
                return;
            disposed = true;
            emissions.length = 0;
            observer?.disconnect();
            observer = null;
            const target = control ?? host;
            for (const [name, entry] of attributes)
                if (target.getAttribute(name) === entry.projected) {
                    if (entry.baseline === null)
                        target.removeAttribute(name);
                    else
                        target.setAttribute(name, entry.baseline);
                }
            attributes.clear();
            ownerScopes.delete(host);
            if (portalAnchor) {
                portalAnchor.parentNode?.insertBefore(host, portalAnchor);
                portalAnchor.remove();
                portalAnchor = null;
            }
            if (display) {
                if (display.value)
                    host.style.setProperty('display', display.value, display.priority);
                else
                    host.style.removeProperty('display');
                display = null;
            }
            if (carrier && !accepted) {
                for (const attribute of Array.from(host.attributes))
                    host.removeAttribute(attribute.name);
                for (const [name, value] of initialAttributes)
                    host.setAttribute(name, value);
                if (control && initialControlAttributes) {
                    for (const attribute of Array.from(control.attributes))
                        control.removeAttribute(attribute.name);
                    for (const [name, value] of initialControlAttributes)
                        control.setAttribute(name, value);
                }
            }
        },
    };
    if (recovery) {
        // Known SSR range identifies only owned nodes. Unknown roots are a diagnosed explicit rebuild.
        if (mode === 'light') {
            const walker = doc.createTreeWalker(host, 128);
            for (let node = walker.nextNode(); node; node = walker.nextNode()) {
                if (marker(node, 'pui-slot-start') && !start)
                    start = node;
                else if (marker(node, 'pui-slot-end') && start && node.parentNode === start.parentNode && !end)
                    end = node;
            }
            projected = slotNodes();
        }
        if (rootStart && rootEnd)
            ownRootRange(rootStart, rootEnd);
        else if (mode === 'shadow')
            for (const node of Array.from(root.childNodes))
                owned.add(node);
    }
    return port;
}
