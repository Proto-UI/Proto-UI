var ButtonSsrFixture = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // button-generated:Component.client.ts
  var Component_client_exports = {};
  __export(Component_client_exports, {
    CompiledButton: () => CompiledButton,
    HydrationMismatch: () => HydrationMismatch,
    default: () => Component_client_default,
    hydrate: () => hydrate,
    register: () => register
  });

  // button-generated:.proto-ui/owner/authored-hooks-v1.ts
  function createNativeAuthoredHooks(options) {
    const entries = /* @__PURE__ */ new Map(), frames = [], rootNames = /* @__PURE__ */ new Set();
    const observedNames = /* @__PURE__ */ new WeakMap(), stateNames = /* @__PURE__ */ new WeakMap(), borrowedStates = /* @__PURE__ */ new WeakSet();
    function effect(bucket, value) {
      options.setup();
      const frame = frames.at(-1);
      if (frame) (frame.effects[bucket] ??= []).push(value);
    }
    function disposer(group, value) {
      options.setup();
      const frame = frames.at(-1);
      if (!frame) return;
      if (typeof value !== "function") throw new TypeError("[Hook] captured disposer must be callable");
      (frame.disposers[group] ??= []).push(value);
    }
    function finish(frame, render) {
      const stateHandles = frame.states.size ? Object.freeze(Object.fromEntries([...frame.states].map(([name, state]) => {
        const projected = observedNames.has(state) || borrowedStates.has(state) ? state : options.borrow(state);
        if (!observedNames.has(projected)) borrowedStates.add(projected);
        stateNames.set(projected, name);
        return [name, projected];
      }))) : void 0;
      const methods = frame.methods.size ? Object.freeze(Object.fromEntries(frame.methods)) : void 0;
      const asHooks = frame.children.length ? Object.freeze(frame.children.slice()) : void 0;
      const eventKeys = frame.eventKeys.size ? Object.freeze(Object.fromEntries(frame.eventKeys)) : void 0;
      const effects = Object.fromEntries(Object.entries(frame.effects).map(([name, values]) => [name, values.length === 1 ? values[0] : values.slice()]));
      const groups2 = {}, all = [];
      for (const name of ["props", "context", "rule", "event", "feedback"]) {
        const source = frame.disposers[name];
        if (!source?.length) continue;
        const wrapped = source.map((off) => () => {
          options.setup();
          off();
        });
        groups2[name] = Object.freeze(wrapped);
        all.push(...wrapped);
      }
      return Object.freeze({
        ...effects,
        ...stateHandles ? { stateHandles, getState: (name) => Object.prototype.hasOwnProperty.call(stateHandles, name) ? stateHandles[name] : void 0 } : {},
        ...methods ? { methods, getMethod: (name) => Object.prototype.hasOwnProperty.call(methods, name) ? methods[name] : void 0 } : {},
        ...asHooks ? { asHooks, getAsHook: (name) => asHooks.find((child) => child.name === name), getAsHookHandle: (name) => asHooks.find((child) => child.name === name)?.handle } : {},
        ...stateHandles || methods || eventKeys || asHooks ? { artifacts: Object.freeze({ ...stateHandles ? { stateHandles } : {}, ...methods ? { methods } : {}, ...eventKeys ? { eventKeys } : {}, ...asHooks ? { asHooks } : {} }) } : {},
        ...all.length ? { disposers: Object.freeze({ all: Object.freeze(all), ...groups2 }) } : {},
        ...typeof render === "function" ? { render } : {}
      });
    }
    let order = 0;
    function record(definition, entry, result = entry.result, handle = entry.handle) {
      const parent = frames.at(-1);
      if (parent) parent.children.push(Object.freeze({ name: definition.name, order: entry.order, privileged: false, mode: definition.mode, result, handle }));
    }
    return {
      effect,
      disposer,
      eventKey(name) {
        options.setup();
        frames.at(-1)?.eventKeys.set(name, name);
      },
      rule(handle) {
        const off = () => handle.dispose();
        effect("context", { op: "rule", handle, off });
        disposer("rule", off);
        return handle;
      },
      privileged(name, acquire, observedMembers) {
        options.setup();
        let entry = entries.get(name);
        if (entry && !entry.privileged) throw new Error("[Hook] registration kind conflict: " + name);
        if (entry?.installing) throw new Error("[Hook] recursive installation: " + name);
        if (!entry) {
          const api = Object.freeze({ name, order: order++, store: /* @__PURE__ */ Object.create(null) });
          entry = { order: api.order, mode: "once", api, installing: true, privileged: true };
          entries.set(name, entry);
          const handle = acquire();
          for (const member of observedMembers ?? []) observedNames.set(handle[member], member);
          entry.handle = entry.result = handle;
          entry.installing = false;
        }
        frames.at(-1)?.children.push(Object.freeze({ name, order: entry.order, privileged: true, mode: "once", result: entry.result, handle: entry.handle }));
        return entry.handle;
      },
      claimState(name) {
        options.setup();
        const names = frames.at(-1)?.names ?? rootNames;
        if (typeof name !== "string" || !name || names.has(name)) throw new Error("[State] illegal or duplicate state name in setup frame: " + name);
        names.add(name);
      },
      state(name, state) {
        options.setup();
        stateNames.set(state, name);
        frames.at(-1)?.states.set(name, state);
      },
      introduceObserved(state) {
        const name = observedNames.get(state) ?? stateNames.get(state);
        if (name !== void 0) frames.at(-1)?.states.set(name, state);
      },
      method(name, method) {
        options.setup();
        frames.at(-1)?.methods.set(name, method);
      },
      install(definition, input) {
        options.setup();
        const previous = definition.mode === "multiple" ? void 0 : entries.get(definition.name);
        if (entries.get(definition.name)?.privileged) throw new Error("[Hook] registration kind conflict: " + definition.name);
        const tools = Object.freeze({ warn(message) {
          console.warn("[Hook:" + definition.name + "] " + message);
        }, conflict(message) {
          throw new Error("[Hook:" + definition.name + "] " + message);
        } });
        if (previous) {
          if (previous.mode !== "once" && definition.mode !== "once") definition.configure?.(previous.api, input, tools);
          const result = previous.result ?? {};
          const handle = Object.hasOwn(previous, "handle") ? previous.handle : result;
          record(definition, previous, result, handle);
          return handle;
        }
        const api = Object.freeze({ name: definition.name, order: order++, store: /* @__PURE__ */ Object.create(null) });
        const entry = { order: api.order, mode: definition.mode, api, installing: true, privileged: false };
        if (definition.mode !== "multiple") entries.set(definition.name, entry);
        const frame = { names: /* @__PURE__ */ new Set(), states: /* @__PURE__ */ new Map(), methods: /* @__PURE__ */ new Map(), children: [], effects: {}, disposers: {}, eventKeys: /* @__PURE__ */ new Map() };
        frames.push(frame);
        let captureOpen = true;
        try {
          const render = definition.setup(input, api);
          frames.pop();
          captureOpen = false;
          const capture = finish(frame, render);
          entry.result = capture;
          entry.handle = definition.project ? definition.project(capture) : capture;
          entry.installing = false;
          record(definition, entry);
          if (definition.mode === "configurable") definition.configure?.(api, input, tools);
          return entry.handle;
        } catch (error) {
          if (captureOpen) frames.pop();
          throw error;
        }
      },
      dispose() {
        entries.clear();
        frames.length = 0;
        rootNames.clear();
      }
    };
  }

  // button-generated:.proto-ui/context/scope-v1.ts
  function isData(value, ancestors = /* @__PURE__ */ new Set()) {
    if (value === null || typeof value === "boolean" || typeof value === "string") return true;
    if (typeof value === "number") return Number.isFinite(value);
    if (typeof value !== "object" || ancestors.has(value)) return false;
    const array = Array.isArray(value);
    const prototype = Object.getPrototypeOf(value);
    if (array ? prototype !== Array.prototype : prototype !== Object.prototype && prototype !== null) return false;
    ancestors.add(value);
    try {
      if (array && Object.keys(value).length !== value.length) return false;
      for (const key of Reflect.ownKeys(value)) {
        if (array && key === "length") continue;
        if (typeof key !== "string" || array && !/^(0|[1-9][0-9]*)$/.test(key)) return false;
        const descriptor = Object.getOwnPropertyDescriptor(value, key);
        if (!descriptor.enumerable || !("value" in descriptor) || !isData(descriptor.value, ancestors)) return false;
      }
      return true;
    } finally {
      ancestors.delete(value);
    }
  }
  function acceptsContextValue(type, value, checked = false) {
    if (type === "void") return value === void 0;
    if (!checked && value !== void 0 && !isData(value)) return false;
    if (typeof type === "string") {
      if (type === "null") return value === null;
      return typeof value === type && (type !== "number" || Number.isFinite(value));
    }
    switch (type.kind) {
      case "literal":
        return Object.is(value, type.value);
      case "union":
        return !!type.members?.some((member) => acceptsContextValue(member, value, true));
      case "array":
        return Array.isArray(value) && !!type.element && Object.keys(value).length === value.length && value.every((item) => acceptsContextValue(type.element, item, true));
      case "record":
        return value !== null && typeof value === "object" && !Array.isArray(value) && !!type.fields?.every((field) => !Object.hasOwn(value, field.name) ? !!field.optional : acceptsContextValue(field.type, value[field.name], true));
      default:
        return false;
    }
  }
  var scopeKey = Symbol("ProtoUI.ContextScope");
  var ownerScopes = /* @__PURE__ */ new WeakMap();
  var live = /* @__PURE__ */ new Map();
  var notifications = [];
  var dispatching = false;
  function resolve(record, key, origin = "self") {
    if (!record.isAlive()) return null;
    const parent = origin === "ancestor" ? record.getParent() : null;
    let current2 = origin === "ancestor" ? parent === null ? void 0 : live.get(parent) : record;
    const visited = new Set(origin === "ancestor" ? [record.scope] : []);
    while (current2) {
      if (visited.has(current2.scope)) throw new Error("[Context] cyclic logical scope ancestry.");
      visited.add(current2.scope);
      if (!current2.isAlive()) return null;
      if (current2.providers.has(key)) return current2;
      const parent2 = current2.getParent();
      current2 = parent2 === null ? void 0 : live.get(parent2);
    }
    return null;
  }
  function createContextScope(options) {
    let disposed = false;
    let record;
    function ensureAlive() {
      if (disposed || !options.isAlive()) throw new Error("[Context] scope is invalid after terminal disposal.");
    }
    function subscribed(key, mode, origin = "self") {
      const subscription = (origin === "ancestor" ? record.ancestorSubscriptions : record.subscriptions).get(key);
      if (!subscription || mode && subscription.mode !== mode)
        throw new Error("[Context] operation requires a declared " + (mode ?? "") + " subscription.");
      return subscription;
    }
    function provider(key) {
      const bound = resolve(record, key);
      if (!bound) throw new Error("[Context] provider missing or disconnected.");
      return bound;
    }
    function write(key, next, bound) {
      const prev = bound.providers.get(key);
      const value = typeof next === "function" ? next(prev) : next;
      ensureAlive();
      if (!live.has(bound.scope) || !bound.isAlive()) throw new Error("[Context] provider disconnected during update.");
      if (!options.validate(key, value)) throw new TypeError("[Context] invalid checked Context value.");
      bound.providers.set(key, value);
      for (const participant of live.values()) {
        for (const origin of ["self", "ancestor"]) {
          const subscription = (origin === "ancestor" ? participant.ancestorSubscriptions : participant.subscriptions).get(key);
          if (!subscription || !participant.isAlive() || resolve(participant, key, origin) !== bound) continue;
          for (const callback of subscription.callbacks) if (callback.active)
            notifications.push({ record: participant, provider: bound, key, origin, callback, next: value, prev });
        }
      }
      if (dispatching) return;
      dispatching = true;
      let failed = false;
      let failure;
      try {
        for (let index = 0; index < notifications.length; ++index) {
          const task = notifications[index];
          if (!task.callback.active || !live.has(task.record.scope) || !task.record.isAlive()) continue;
          try {
            if (resolve(task.record, task.key, task.origin) !== task.provider) continue;
            task.record.invoke(() => {
              if (!task.callback.active || !live.has(task.record.scope) || !task.record.isAlive() || resolve(task.record, task.key, task.origin) !== task.provider) return;
              task.callback.call(task.next, task.prev);
            });
          } catch (error) {
            if (!failed) {
              failed = true;
              failure = error;
            }
          }
        }
      } finally {
        notifications.length = 0;
        dispatching = false;
      }
      if (failed) throw failure;
    }
    const scope = {
      provide(key, value) {
        ensureAlive();
        if (record.providers.has(key)) throw new Error("[Context] duplicate provide.");
        if (!options.validate(key, value)) throw new TypeError("[Context] invalid checked Context value.");
        record.providers.set(key, value);
      },
      subscribe(key, mode, callback, origin = "self") {
        ensureAlive();
        if (mode !== "required" && mode !== "optional") throw new Error("[Context] invalid subscription mode.");
        if (origin !== "self" && origin !== "ancestor" || origin === "ancestor" && mode !== "optional") throw new Error("[Context] invalid subscription origin.");
        if (mode === "required") provider(key);
        const subscriptions = origin === "ancestor" ? record.ancestorSubscriptions : record.subscriptions;
        let subscription = subscriptions.get(key);
        if (subscription && subscription.mode !== mode) throw new Error("[Context] subscription mode mismatch.");
        if (!subscription) {
          subscription = { mode, callbacks: [] };
          subscriptions.set(key, subscription);
        }
        const entry = callback ? { active: true, call: (next, prev) => callback(next, prev) } : void 0;
        if (entry) subscription.callbacks.push(entry);
        return () => {
          if (entry) entry.active = false;
        };
      },
      read(key) {
        ensureAlive();
        subscribed(key, "required");
        return provider(key).providers.get(key);
      },
      tryRead(key) {
        ensureAlive();
        subscribed(key, "optional");
        return resolve(record, key)?.providers.get(key) ?? null;
      },
      tryReadAncestor(key) {
        ensureAlive();
        subscribed(key, "optional", "ancestor");
        return resolve(record, key, "ancestor")?.providers.get(key) ?? null;
      },
      update(key, next) {
        ensureAlive();
        if (!record.providers.has(key)) subscribed(key);
        write(key, next, provider(key));
      },
      tryUpdate(key, next) {
        ensureAlive();
        subscribed(key, "optional");
        const bound = resolve(record, key);
        if (!bound) return false;
        write(key, next, bound);
        return true;
      },
      dispose() {
        if (disposed) return;
        disposed = true;
        live.delete(scope);
        record.providers.clear();
        for (const subscriptions of [record.subscriptions, record.ancestorSubscriptions]) {
          for (const subscription of subscriptions.values()) {
            for (const callback of subscription.callbacks) callback.active = false;
            subscription.callbacks.length = 0;
          }
          subscriptions.clear();
        }
      }
    };
    record = { ...options, scope, providers: /* @__PURE__ */ new Map(), subscriptions: /* @__PURE__ */ new Map(), ancestorSubscriptions: /* @__PURE__ */ new Map() };
    live.set(scope, record);
    return Object.freeze(scope);
  }

  // button-generated:.proto-ui/style/native-v1.ts
  function validate(handle) {
    if (!handle || handle.kind !== "tw" || !Array.isArray(handle.tokens) || !Array.isArray(handle.groups) || handle.tokens.length !== handle.groups.length)
      throw new TypeError("[Style] expected a checked single tw handle");
  }
  function templateStyleTokens(handle) {
    validate(handle);
    return handle.tokens.join(" ");
  }
  function completeStyleSteps(steps) {
    let failure;
    for (const step of steps) {
      try {
        step();
      } catch (error) {
        failure ??= { error };
      }
    }
    if (failure) throw failure.error;
  }
  function createNativeStyle(options) {
    const chunks = [], rules = [];
    const patches = /* @__PURE__ */ new Map();
    const decorations = /* @__PURE__ */ new Map();
    let decorationsBound = false;
    let mounted = false, disposed = false, nextRuleId = 1;
    let metaGeneration = 0;
    let acquiringMeta = false, retiringMeta = 0, remountRequested = false;
    let releaseMeta;
    let projected = [];
    const current2 = (generation) => mounted && !disposed && generation === metaGeneration && options.isAlive();
    function remount() {
      if (!remountRequested || acquiringMeta || retiringMeta || disposed) return;
      remountRequested = false;
      style.mount();
    }
    function snapshot(includeRules = mounted) {
      const merged = /* @__PURE__ */ new Map();
      function append(handles) {
        for (const handle of handles) {
          for (let index = 0; index < handle.tokens.length; ++index)
            merged.set(handle.groups[index], handle.tokens[index]);
        }
      }
      for (const chunk of chunks) if (chunk.active) append(chunk.handles);
      if (includeRules) {
        for (const rule of rules) if (rule.active && rule.test()) append(rule.handles);
      }
      for (const group of patches.keys()) merged.delete(group);
      for (const [group, patch] of patches) if (patch.token !== void 0) merged.set(group, patch.token);
      return [...merged.values()];
    }
    function refresh2() {
      if (!mounted || disposed || !options.isAlive()) return;
      const generation = metaGeneration;
      for (const target of decorations.values()) {
        if (!current2(generation)) return;
        target.style.refresh();
      }
      const next = snapshot();
      if (!current2(generation)) return;
      if (next.length === projected.length && next.every((token, index) => token === projected[index])) return;
      projected = next;
      options.project(next);
    }
    function runtime() {
      if (disposed || !options.isAlive()) throw new Error("[Style] owner is terminally disposed");
      options.ensureRuntime();
    }
    function record(handles) {
      for (const handle of handles) validate(handle);
      return { handles, active: true };
    }
    const style = {
      meta(key) {
        if ((key.startsWith("preference.") || key === "viewport.width") && (!mounted || disposed)) return "unknown";
        return options.getMeta?.(key) ?? (mounted && !disposed ? options.meta?.read(key) : void 0);
      },
      metaKeys() {
        return [.../* @__PURE__ */ new Set([
          ...rules.filter((rule) => rule.active).flatMap((rule) => rule.metaKeys),
          ...[...decorations.values()].flatMap((target) => target.style.metaKeys())
        ])];
      },
      use(...handles) {
        options.ensureSetup();
        const chunk = record(handles);
        chunks.push(chunk);
        return () => {
          options.ensureSetup();
          if (!chunk.active) return;
          chunk.active = false;
          refresh2();
        };
      },
      patch(...handles) {
        runtime();
        for (const handle of handles) {
          validate(handle);
          for (let index = 0; index < handle.tokens.length; ++index)
            patches.set(handle.groups[index], { token: handle.tokens[index] });
        }
        refresh2();
      },
      suppress(...handles) {
        runtime();
        for (const handle of handles) {
          validate(handle);
          for (const group of handle.groups) patches.set(group, {});
        }
        refresh2();
      },
      clearPatch() {
        runtime();
        patches.clear();
        refresh2();
      },
      declareDecoration() {
        options.ensureSetup();
        if (disposed || mounted || decorationsBound) throw new Error("[Style] decoration declaration lifetime ended");
        const identity = Object.freeze({});
        const target = { style: null, sink: null };
        target.style = createNativeStyle({
          ensureSetup: options.ensureSetup,
          ensureRuntime: options.ensureRuntime,
          isAlive: () => !disposed && options.isAlive(),
          getMeta: (key) => style.meta(key),
          project(tokens) {
            target.sink?.({ kind: "tw", tokens });
          }
        });
        decorations.set(identity, target);
        return identity;
      },
      to(identity) {
        options.ensureSetup();
        const target = decorations.get(identity);
        if (disposed || !target) throw new Error("[Style] foreign or disposed decoration target");
        return Object.freeze({ use: target.style.use });
      },
      validateDecorations(targets2) {
        if (disposed || !options.isAlive()) throw new Error("[Style] owner is terminally disposed");
        if (new Set(targets2).size !== targets2.length || targets2.length !== decorations.size || targets2.some((target) => !decorations.has(target)))
          throw new Error("[Style] decorations require the complete unique owned target set");
      },
      bindDecorations(bindings) {
        if (decorationsBound) throw new Error("[Style] decoration physical view already bound");
        style.validateDecorations(bindings.map((binding) => binding.target));
        if (bindings.some((binding) => typeof binding.sink !== "function")) throw new Error("[Style] invalid decoration sink");
        decorationsBound = true;
        try {
          for (const binding of bindings) decorations.get(binding.target).sink = binding.sink;
          if (mounted) for (const target of decorations.values()) target.style.mount();
        } catch (error) {
          try {
            style.releaseDecorations();
          } catch {
          }
          throw error;
        }
      },
      releaseDecorations() {
        decorationsBound = false;
        const targets2 = [...decorations.values()];
        for (const target of targets2) target.sink = null;
        completeStyleSteps(targets2.map((target) => () => target.style.unmount()));
      },
      rule(test, handles, metaKeys = [], target) {
        options.ensureSetup();
        if (target !== void 0) {
          const child = decorations.get(target);
          if (disposed || !child) throw new Error("[Style] foreign or disposed decoration target");
          return child.style.rule(test, handles, metaKeys);
        }
        const rule = { ...record(handles), test, metaKeys };
        rules.push(rule);
        return Object.freeze({ id: nextRuleId++, dispose() {
          options.ensureSetup();
          if (!rule.active) return;
          rule.active = false;
          refresh2();
        } });
      },
      refresh: refresh2,
      mount() {
        if (disposed || !options.isAlive()) return;
        if (acquiringMeta || retiringMeta) {
          if (!mounted) remountRequested = true;
          return;
        }
        if (!mounted) {
          mounted = true;
          ++metaGeneration;
        }
        const generation = metaGeneration;
        if (!releaseMeta && (options.subscribeMeta || options.meta)) {
          const releases = [];
          let active = true;
          const release = () => {
            if (!active) return;
            active = false;
            completeStyleSteps(releases.splice(0));
          };
          const acquire = (off) => {
            if (active && current2(generation)) releases.push(off);
            else off();
          };
          const notify = () => {
            if (current2(generation)) refresh2();
          };
          releaseMeta = release;
          acquiringMeta = true;
          let failure;
          try {
            if (options.subscribeMeta) acquire(options.subscribeMeta(notify));
            if (current2(generation) && options.meta) acquire(options.meta.subscribe(notify, style.metaKeys()));
          } catch (error) {
            failure = { error };
            if (releaseMeta === release) releaseMeta = void 0;
            if (generation === metaGeneration) {
              mounted = false;
              ++metaGeneration;
            }
            try {
              release();
            } catch {
            }
          } finally {
            acquiringMeta = false;
          }
          try {
            remount();
          } catch (error) {
            failure ??= { error };
          }
          if (failure) throw failure.error;
          if (!current2(generation)) return;
        }
        const next = snapshot();
        if (!current2(generation)) return;
        projected = next;
        options.project(next);
        if (decorationsBound) for (const target of decorations.values()) {
          if (!current2(generation)) return;
          target.style.mount();
        }
      },
      unmount() {
        mounted = false;
        ++metaGeneration;
        remountRequested = false;
        const release = releaseMeta;
        releaseMeta = void 0;
        projected = [];
        ++retiringMeta;
        let failure;
        try {
          completeStyleSteps([() => style.releaseDecorations(), () => release?.()]);
        } catch (error) {
          failure = { error };
        } finally {
          --retiringMeta;
        }
        try {
          remount();
        } catch (error) {
          failure ??= { error };
        }
        if (failure) throw failure.error;
      },
      tokens() {
        return snapshot();
      },
      readMeta(key) {
        return mounted && !disposed ? options.meta?.read(key) : void 0;
      },
      serverTokens() {
        if (disposed || !options.isAlive()) throw new Error("[Style] owner is terminally disposed");
        return snapshot(true);
      },
      dispose() {
        if (disposed) return;
        disposed = true;
        mounted = false;
        ++metaGeneration;
        remountRequested = false;
        const release = releaseMeta;
        releaseMeta = void 0;
        const targets2 = [...decorations.values()];
        decorations.clear();
        decorationsBound = false;
        for (const target of targets2) target.sink = null;
        chunks.length = 0;
        rules.length = 0;
        patches.clear();
        projected = [];
        completeStyleSteps([...targets2.map((target) => () => target.style.dispose()), () => release?.()]);
      }
    };
    return style;
  }

  // button-generated:.proto-ui/interaction/ownership-v2.ts
  var owners = /* @__PURE__ */ new Map();
  var parts = /* @__PURE__ */ new WeakMap();
  var targets = /* @__PURE__ */ new WeakMap();
  var hostIds = /* @__PURE__ */ new WeakMap();
  function logicalRoot(owner) {
    let current2 = owner;
    const visited = /* @__PURE__ */ new Set();
    while (!visited.has(current2.identity)) {
      visited.add(current2.identity);
      const parent = current2.parent(), candidate = parent ? owners.get(parent) : void 0;
      if (!candidate)
        return current2;
      current2 = candidate;
    }
    throw new Error("[Modules] cyclic logical ancestry.");
  }
  function ancestor(owner, predicate) {
    let current2 = owner;
    const visited = /* @__PURE__ */ new Set();
    while (current2) {
      if (visited.has(current2.identity))
        throw new Error("[Modules] cyclic logical ancestry.");
      visited.add(current2.identity);
      if (!current2.alive())
        return null;
      if (predicate(current2))
        return current2;
      const parent = current2.parent();
      current2 = parent ? owners.get(parent) : void 0;
    }
    return null;
  }
  function descends(owner, parent) {
    return !!ancestor(owner, (candidate) => candidate === parent);
  }
  function hostOrder(a, b) {
    const left = a.host(), right = b.host();
    if (!left || !right || left === right)
      return 0;
    const order = left.compareDocumentPosition(right);
    if (order & 1)
      return 0;
    return order & 4 ? -1 : order & 2 ? 1 : 0;
  }
  var rootOwners = /* @__PURE__ */ new WeakMap();
  var logicalOwners = /* @__PURE__ */ new Map();
  var exposeSignals = /* @__PURE__ */ new WeakSet();
  var defaultPreventedSamples = /* @__PURE__ */ new WeakSet();
  var hostIdState = { nextHostId: 1 };

  // button-generated:.proto-ui/interaction/focus-ownership-v2.ts
  var focusState = { scopeRevision: 0, focusRequestEpoch: 0, scopeEntryIntent: void 0 };
  var activeScopes = [];
  function noteNativeFocusRequest(owner) {
    const epoch = ++focusState.focusRequestEpoch, previous = focusState.scopeEntryIntent;
    focusState.scopeEntryIntent = owner;
    if (previous !== owner)
      previous?.cancel();
    return epoch === focusState.focusRequestEpoch && focusState.scopeEntryIntent === owner;
  }

  // button-generated:.proto-ui/interaction/control-label-v1.ts
  function referenceAuthority() {
    const key = Symbol.for("@proto.ui/control-label/ref/v1");
    const descriptor = Object.getOwnPropertyDescriptor(globalThis, key);
    if (descriptor) {
      const service2 = descriptor.value;
      if (descriptor.get || descriptor.set || descriptor.configurable || descriptor.writable || !service2 || !Object.isFrozen(service2) || service2.version !== 1 || typeof service2.create !== "function" || typeof service2.is !== "function")
        throw new TypeError("[ControlLabel] incompatible same-realm reference ABI; expected v1");
      return service2;
    }
    const references = /* @__PURE__ */ new WeakSet();
    const service = Object.freeze({
      version: 1,
      create() {
        const ref = Object.freeze({
          toJSON() {
            throw new TypeError("[ControlLabel] opaque references cannot be serialized; use an explicit renderer association key");
          }
        });
        references.add(ref);
        return ref;
      },
      is(value) {
        return typeof value === "object" && value !== null && references.has(value);
      }
    });
    Object.defineProperty(globalThis, key, { value: service });
    return service;
  }
  function createControlLabelRef() {
    return referenceAuthority().create();
  }
  function isControlLabelRef(value) {
    return referenceAuthority().is(value);
  }
  var groups = /* @__PURE__ */ new WeakMap();
  function current(group, pair) {
    if (group.pair !== pair)
      return false;
    const label = pair.label.view();
    const target = pair.target.view();
    return group.pair === pair && group.participants.get(pair.label.owner) === pair.label && group.participants.get(pair.target.owner) === pair.target && label?.identity === pair.labelView.identity && target?.identity === pair.targetView.identity && label?.scope === pair.labelView.scope && target?.scope === pair.targetView.scope && pair.label.options().activation === pair.activation && pair.label.options().naming === pair.naming;
  }
  function withdraw(group) {
    const pair = group.pair;
    group.pair = null;
    pair?.nameLease?.dispose();
  }
  function refresh(group) {
    if (group.refreshing) {
      group.dirty = true;
      return;
    }
    group.refreshing = true;
    try {
      do {
        group.dirty = false;
        const revision = group.revision;
        const participants = [...group.participants.values()];
        const live2 = participants.map((participant) => ({ participant, view: participant.view() })).filter((entry) => entry.view !== null);
        if (revision !== group.revision) {
          group.dirty = true;
          continue;
        }
        const labels = live2.filter((entry) => entry.participant.kind === "label");
        const targets2 = live2.filter((entry) => entry.participant.kind === "target");
        let code = labels.length > 1 || targets2.length > 1 ? "duplicate-binding" : labels.length !== 1 || targets2.length !== 1 ? "missing-binding" : labels[0].view.scope !== targets2[0].view.scope ? "foreign-tree-scope" : null;
        if (code) {
          withdraw(group);
        } else {
          const label = labels[0];
          const target = targets2[0];
          const options = label.participant.options();
          const previous = group.pair;
          if (!previous || !current(group, previous) || previous.label !== label.participant || previous.target !== target.participant || previous.naming && !previous.nameLease?.isActive()) {
            withdraw(group);
            if (revision !== group.revision) {
              group.dirty = true;
              continue;
            }
            const pair = {
              label: label.participant,
              target: target.participant,
              labelView: label.view,
              targetView: target.view,
              naming: options.naming,
              activation: options.activation,
              nameLease: null
            };
            group.pair = pair;
            try {
              if (options.naming)
                pair.nameLease = target.participant.name(label.participant.semanticRef, label.view);
            } catch (error) {
              if (group.pair === pair)
                withdraw(group);
              throw error;
            }
            if (!current(group, pair)) {
              withdraw(group);
              group.dirty = true;
              continue;
            }
          }
          if (group.pair?.naming && !group.pair.nameLease?.isActive())
            code = "name-conflict";
        }
        for (const participant of participants)
          participant.diagnostic(code);
      } while (group.dirty);
    } finally {
      group.refreshing = false;
    }
  }
  function bindParticipant(participant) {
    if (!isControlLabelRef(participant.ref))
      throw new TypeError("[ControlLabel] invalid opaque association reference");
    let group = groups.get(participant.ref);
    if (!group) {
      group = { participants: /* @__PURE__ */ new Map(), revision: 0, pair: null, refreshing: false, dirty: false };
      groups.set(participant.ref, group);
    }
    const ownGroup = group;
    ownGroup.participants.set(participant.owner, participant);
    ownGroup.revision += 1;
    try {
      refresh(ownGroup);
    } catch (error) {
      if (ownGroup.participants.get(participant.owner) === participant) {
        ownGroup.participants.delete(participant.owner);
        ownGroup.revision += 1;
        try {
          refresh(ownGroup);
        } catch {
        }
      }
      throw error;
    }
    return {
      refresh() {
        if (ownGroup.participants.get(participant.owner) === participant)
          refresh(ownGroup);
      },
      requestActivation(source = "pointer") {
        if (participant.kind !== "label" || ownGroup.participants.get(participant.owner) !== participant)
          return;
        refresh(ownGroup);
        const pair = ownGroup.pair;
        if (!pair || pair.label !== participant || !pair.activation || !current(ownGroup, pair))
          return;
        pair.target.activate(() => current(ownGroup, pair), source);
      },
      dispose() {
        if (ownGroup.participants.get(participant.owner) !== participant)
          return;
        ownGroup.participants.delete(participant.owner);
        ownGroup.revision += 1;
        refresh(ownGroup);
      }
    };
  }
  function bindControlLabel(participant) {
    const key = Symbol.for("@proto.ui/control-label/pairs/v1");
    const descriptor = Object.getOwnPropertyDescriptor(globalThis, key);
    if (descriptor) {
      const service2 = descriptor.value;
      if (descriptor.get || descriptor.set || descriptor.configurable || descriptor.writable || !service2 || !Object.isFrozen(service2) || service2.version !== 1 || typeof service2.bind !== "function")
        throw new TypeError("[ControlLabel] incompatible same-realm pairing ABI; expected v1");
      return service2.bind(participant);
    }
    const service = Object.freeze({
      version: 1,
      bind: bindParticipant
    });
    Object.defineProperty(globalThis, key, { value: service });
    return service.bind(participant);
  }
  function generatedIdAuthority() {
    const key = Symbol.for("@proto.ui/a11y/generated-id/v1");
    const descriptor = Object.getOwnPropertyDescriptor(globalThis, key);
    if (descriptor) {
      const service2 = descriptor.value;
      if (descriptor.get || descriptor.set || descriptor.configurable || descriptor.writable || !service2 || !Object.isFrozen(service2) || service2.version !== 1 || typeof service2.own !== "function" || typeof service2.retain !== "function")
        throw new TypeError("[A11y] incompatible same-realm generated-ID ABI; expected v1");
      return service2;
    }
    const entries = /* @__PURE__ */ new WeakMap();
    const lease = (element, id, entry) => {
      const owner = {};
      entry.owners.add(owner);
      return Object.freeze({
        dispose() {
          if (!entry.owners.delete(owner) || entry.owners.size)
            return;
          const byId = entries.get(element);
          if (byId?.get(id) !== entry)
            return;
          byId.delete(id);
          if (!byId.size)
            entries.delete(element);
          if (element.getAttribute("id") !== id)
            return;
          try {
            if (entry.baseline === null)
              element.removeAttribute("id");
            else
              element.setAttribute("id", entry.baseline);
          } catch (error) {
            try {
              if (element.getAttribute("id") === id && !entry.owners.size && !entries.get(element)?.has(id)) {
                let retry = entries.get(element);
                if (!retry)
                  entries.set(element, retry = /* @__PURE__ */ new Map());
                retry.set(id, entry);
              }
            } catch {
            }
            throw error;
          }
        }
      });
    };
    const service = Object.freeze({
      version: 1,
      own(element, id, baseline) {
        const current2 = element.getAttribute("id");
        if (!id || current2 !== id && current2 !== baseline)
          throw new Error("[A11y] generated-ID ownership requires the current physical baseline");
        let byId = entries.get(element);
        if (!byId)
          entries.set(element, byId = /* @__PURE__ */ new Map());
        let entry = byId.get(id);
        if (!entry)
          byId.set(id, entry = { baseline, owners: /* @__PURE__ */ new Set() });
        const receipt = lease(element, id, entry);
        try {
          if (current2 !== id)
            element.setAttribute("id", id);
          if (element.getAttribute("id") !== id)
            throw new Error("[A11y] generated-ID write was superseded by the host");
          return receipt;
        } catch (error) {
          try {
            receipt.dispose();
          } catch {
          }
          throw error;
        }
      },
      retain(element, id) {
        if (!id || element.getAttribute("id") !== id)
          return null;
        const entry = entries.get(element)?.get(id);
        return entry ? lease(element, id, entry) : null;
      }
    });
    Object.defineProperty(globalThis, key, { value: service });
    return service;
  }
  function ownGeneratedId(element, id, baseline) {
    return generatedIdAuthority().own(element, id, baseline);
  }
  function retainGeneratedId(element, id) {
    return generatedIdAuthority().retain(element, id);
  }
  var INTERACTIVE = 'a[href],area[href],button,input:not([type="hidden" i]),textarea,select,summary,details,embed,iframe,label,audio[controls],video[controls],img[usemap],img[controls],[contenteditable]:not([contenteditable="false"]),[tabindex]:not([tabindex="-1"])';
  var INTERACTIVE_ROLES = /* @__PURE__ */ new Set([
    "button",
    "checkbox",
    "combobox",
    "grid",
    "gridcell",
    "link",
    "listbox",
    "menu",
    "menubar",
    "menuitem",
    "menuitemcheckbox",
    "menuitemradio",
    "option",
    "radio",
    "radiogroup",
    "scrollbar",
    "searchbox",
    "slider",
    "spinbutton",
    "switch",
    "tab",
    "tablist",
    "textbox",
    "tree",
    "treegrid",
    "treeitem"
  ]);
  function isInteractive(element) {
    return element.matches(INTERACTIVE) || (element.getAttribute("role")?.split(/\s+/).some((role) => INTERACTIVE_ROLES.has(role)) ?? false);
  }
  var observers = /* @__PURE__ */ new WeakMap();
  function observeScope(scope, anchor, notify, nameId) {
    const document = scope.nodeType === 9 ? scope : scope.ownerDocument;
    const Observer = document?.defaultView?.MutationObserver;
    if (!Observer)
      return () => {
      };
    let entry = observers.get(scope);
    if (!entry) {
      const members = /* @__PURE__ */ new Set();
      const observer = new Observer((mutations) => {
        const changedIds = /* @__PURE__ */ new Set();
        const collectIds = (node) => {
          if (node.nodeType !== 1)
            return;
          const element = node, ownId = element.getAttribute("id");
          if (ownId)
            changedIds.add(ownId);
          for (const descendant of element.querySelectorAll("[id]")) {
            const id = descendant.getAttribute("id");
            if (id)
              changedIds.add(id);
          }
        };
        for (const mutation of mutations) {
          if (mutation.type === "attributes" && mutation.attributeName === "id") {
            if (mutation.oldValue)
              changedIds.add(mutation.oldValue);
            const current2 = mutation.target.getAttribute("id");
            if (current2)
              changedIds.add(current2);
          } else if (mutation.type === "childList")
            for (const node of [...mutation.addedNodes, ...mutation.removedNodes])
              collectIds(node);
        }
        for (const member2 of [...members]) {
          const name = member2.nameId?.();
          const affected = Boolean(name && changedIds.has(name)) || mutations.some((mutation) => {
            if (mutation.type === "attributes")
              return mutation.target === member2.anchor;
            return [...mutation.addedNodes, ...mutation.removedNodes].some((node) => node === member2.anchor || node.contains(member2.anchor));
          });
          if (affected && members.has(member2))
            member2.notify();
        }
      });
      observer.observe(scope, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeOldValue: true,
        attributeFilter: ["id", "aria-label", "aria-labelledby"]
      });
      entry = { observer, members };
      observers.set(scope, entry);
    }
    const ownEntry = entry;
    const member = { anchor, notify, nameId };
    ownEntry.members.add(member);
    return () => {
      ownEntry.members.delete(member);
      if (!ownEntry.members.size) {
        ownEntry.observer.disconnect();
        if (observers.get(scope) === ownEntry)
          observers.delete(scope);
      }
    };
  }
  var detachedTrackers = /* @__PURE__ */ new WeakMap();
  function observeDetached(element, notify) {
    const window = element.ownerDocument.defaultView;
    if (!window?.requestAnimationFrame)
      return () => {
      };
    let entry = detachedTrackers.get(window);
    if (!entry) {
      entry = { members: /* @__PURE__ */ new Set(), frame: null };
      detachedTrackers.set(window, entry);
    }
    const ownEntry = entry;
    const member = { element, notify };
    const retire = () => {
      if (ownEntry.frame !== null)
        window.cancelAnimationFrame(ownEntry.frame);
      ownEntry.frame = null;
      if (detachedTrackers.get(window) === ownEntry)
        detachedTrackers.delete(window);
    };
    const schedule = () => {
      if (detachedTrackers.get(window) !== ownEntry || ownEntry.frame !== null || !ownEntry.members.size)
        return;
      ownEntry.frame = window.requestAnimationFrame(() => {
        if (detachedTrackers.get(window) !== ownEntry)
          return;
        ownEntry.frame = null;
        try {
          for (const current2 of [...ownEntry.members]) {
            if (!ownEntry.members.has(current2) || !current2.element.isConnected)
              continue;
            ownEntry.members.delete(current2);
            current2.notify();
          }
        } finally {
          if (!ownEntry.members.size)
            retire();
          else
            schedule();
        }
      });
    };
    ownEntry.members.add(member);
    schedule();
    return () => {
      ownEntry.members.delete(member);
      if (!ownEntry.members.size)
        retire();
    };
  }
  function isTrustedNonPointerLabelActivation(facts) {
    return facts.trusted && (facts.pointerId === void 0 ? facts.detail === 0 : facts.pointerId === -1 && facts.pointerType === "");
  }
  function createWebControlLabelHost(getTarget, subscribeTargetChange) {
    const clickCounts = /* @__PURE__ */ new WeakMap();
    const documentClicks = (document) => {
      let entry = clickCounts.get(document);
      if (!entry)
        clickCounts.set(document, entry = { count: 0, last: null });
      return entry;
    };
    let clicks = 0;
    return {
      attach({ kind, activation, onActivate, onViewChange }) {
        let actionable = kind === "label" && activation;
        let disposed = false;
        let target = null;
        let eventDocument = null;
        let observedChain = [];
        let scopeOffs = [];
        let lastConnected = null;
        let detachedOff = null;
        let cleanListeners = () => {
        };
        let pending = null;
        let capturedClick = null;
        const clearCapturedClick = () => {
          capturedClick?.cancel();
          capturedClick = null;
        };
        const clearPending = () => {
          pending = null;
        };
        const view = () => {
          const current2 = getTarget();
          return !disposed && current2?.isConnected ? { identity: current2, scope: current2.getRootNode() } : null;
        };
        const observeCurrentScopes = (element) => {
          if (element && !element.isConnected && element === lastConnected) {
            detachedOff ??= observeDetached(element, sync);
            return;
          }
          const off2 = detachedOff;
          detachedOff = null;
          off2?.();
          lastConnected = element?.isConnected ? element : null;
          const chain = [];
          const anchors = [];
          let anchor = element;
          while (anchor) {
            const scope = anchor.getRootNode();
            chain.push(scope);
            anchors.push(anchor);
            anchor = "host" in scope ? scope.host : null;
          }
          if (chain.length === observedChain.length && chain.every((scope, i) => scope === observedChain[i]) && element === target)
            return;
          for (const off3 of scopeOffs)
            off3();
          scopeOffs = [];
          observedChain = chain;
          chain.forEach((scope, i) => scopeOffs.push(observeScope(scope, anchors[i], sync)));
        };
        const sync = () => {
          if (disposed)
            return;
          const next = getTarget();
          if (next === target && (next?.ownerDocument ?? null) === eventDocument) {
            observeCurrentScopes(next);
            onViewChange();
            return;
          }
          cleanListeners();
          clearPending();
          clearCapturedClick();
          observeCurrentScopes(next);
          target = next;
          eventDocument = next?.ownerDocument ?? null;
          if (next) {
            const document = next.ownerDocument;
            const eligible = (event) => {
              for (const node of event.composedPath()) {
                if (node === next)
                  return true;
                if (node instanceof document.defaultView.Element && isInteractive(node))
                  return false;
              }
              return false;
            };
            const down = (event) => {
              clearPending();
              clearCapturedClick();
              if (!actionable || event.defaultPrevented || event.button !== 0 || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey || !eligible(event))
                return;
              pending = {
                id: event.pointerId,
                x: event.clientX,
                y: event.clientY,
                root: next.getRootNode(),
                down: event,
                up: null,
                released: false,
                clicksAtRelease: 0
              };
            };
            const countClick = (event) => {
              const entry = documentClicks(document);
              if (entry.last === event)
                return;
              entry.last = event;
              entry.count += 1;
            };
            const move = (event) => {
              if (pending && event.pointerId === pending.id && Math.hypot(event.clientX - pending.x, event.clientY - pending.y) > 6)
                clearPending();
            };
            const cancel = () => {
              clearPending();
              clearCapturedClick();
            };
            const up = (event) => {
              if (!pending || pending.id !== event.pointerId)
                return;
              move(event);
              if (pending) {
                pending.up = event;
                pending.released = eligible(event);
                pending.clicksAtRelease = documentClicks(document).count;
              }
            };
            const captureClick = (event) => {
              countClick(event);
              clearCapturedClick();
              const receipt = {
                event,
                clicksBefore: documentClicks(document).count,
                gesture: pending,
                cancel: () => {
                }
              };
              clearPending();
              capturedClick = receipt;
              const timer = setTimeout(() => {
                if (capturedClick === receipt)
                  capturedClick = null;
              }, 0);
              receipt.cancel = () => clearTimeout(timer);
            };
            const click = (event) => {
              const receipt = capturedClick?.event === event ? capturedClick : null;
              const gesture = receipt?.gesture;
              if (receipt)
                clearCapturedClick();
              if (!actionable || event.button !== 0 || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey || !eligible(event))
                return;
              const nonPointer = isTrustedNonPointerLabelActivation({
                trusted: event.isTrusted,
                detail: event.detail,
                ..."pointerId" in event ? {
                  pointerId: event.pointerId,
                  pointerType: event.pointerType
                } : {}
              });
              const pointer = receipt !== null && gesture != null && gesture.released && event.isTrusted === gesture.down.isTrusted && event.isTrusted === gesture.up?.isTrusted && receipt.clicksBefore - gesture.clicksAtRelease === 1;
              if (!pointer && !nonPointer)
                return;
              const root = next.getRootNode();
              if (disposed || target !== next || getTarget() !== next || !next.isConnected || event.defaultPrevented)
                return;
              if (gesture && gesture.root !== root)
                return;
              onActivate(pointer ? "pointer" : "accessibility");
            };
            if (kind === "label") {
              next.addEventListener("pointerdown", down);
              next.addEventListener("pointerup", up, true);
              document.addEventListener("pointermove", move, true);
              document.addEventListener("pointerup", up, true);
              document.addEventListener("pointercancel", cancel, true);
              document.addEventListener("click", countClick, true);
              next.addEventListener("click", captureClick, true);
              next.addEventListener("click", click);
              cleanListeners = () => {
                next.removeEventListener("pointerdown", down);
                next.removeEventListener("pointerup", up, true);
                document.removeEventListener("pointermove", move, true);
                document.removeEventListener("pointerup", up, true);
                document.removeEventListener("pointercancel", cancel, true);
                document.removeEventListener("click", countClick, true);
                next.removeEventListener("click", captureClick, true);
                next.removeEventListener("click", click);
              };
            }
          }
          onViewChange();
        };
        const off = subscribeTargetChange?.(sync);
        sync();
        return {
          view,
          setActivation(enabled) {
            if (disposed)
              return;
            actionable = kind === "label" && enabled;
            if (!actionable) {
              clearPending();
              clearCapturedClick();
            }
          },
          dispose() {
            if (disposed)
              return;
            disposed = true;
            clearPending();
            clearCapturedClick();
            off?.();
            cleanListeners();
            const stopDetached = detachedOff;
            detachedOff = null;
            stopDetached?.();
            lastConnected = null;
            for (const off2 of scopeOffs)
              off2();
            scopeOffs = [];
            observedChain = [];
            target = null;
          }
        };
      }
    };
  }
  function validateNativeInstanceAssociations(input) {
    if (input === void 0)
      return Object.freeze({ controlLabel: null });
    if (!input || typeof input !== "object" || Object.getPrototypeOf(input) !== Object.prototype)
      throw new TypeError("[ControlLabel] instanceAssociations must be a plain object");
    if (Object.getOwnPropertySymbols(input).length || Object.getOwnPropertyNames(input).some((key) => key !== "controlLabel"))
      throw new TypeError("[ControlLabel] unknown instance association key");
    const ref = Object.hasOwn(input, "controlLabel") ? input.controlLabel : null;
    if (ref != null && !isControlLabelRef(ref))
      throw new TypeError("[ControlLabel] invalid opaque association reference");
    return Object.freeze({ controlLabel: ref ?? null });
  }
  var nextLabelId = 1;
  function idMatches(scope, id) {
    if (!("querySelectorAll" in scope))
      return [];
    const escaped = id.replace(/[\0-\x1f\x7f"\\]/g, (value) => "\\" + value.charCodeAt(0).toString(16) + " ");
    return Array.from(scope.querySelectorAll('[id="' + escaped + '"]'));
  }
  function idTokens(value) {
    return value?.trim().split(/\s+/).filter(Boolean) ?? [];
  }
  function claimNativeControlLabelName(options, source) {
    const target = options.getRoot(), label = source.identity;
    if (!target?.isConnected || !label || label.nodeType !== 1 || !label.isConnected || !label.ownerDocument || label.ownerDocument !== target.ownerDocument || label.getRootNode() !== source.scope || target.getRootNode() !== source.scope)
      return null;
    if (options.hasAuthoredName() || target.getAttribute("aria-label")?.trim() || idTokens(target.getAttribute("aria-labelledby")).length)
      return null;
    const baselineId = label.getAttribute("id"), baselineName = target.getAttribute("aria-labelledby");
    let id = baselineId?.trim() ? baselineId : "", idLease = null;
    let live2 = true, nameInstalled = false;
    let endProjection = null;
    const release = () => {
      if (!live2)
        return;
      live2 = false;
      let failed = false, failure;
      try {
        if (nameInstalled) {
          const current2 = target.getAttribute("aria-labelledby"), tokens = idTokens(current2);
          if (tokens.includes(id)) {
            const remaining = tokens.filter((token) => token !== id);
            if (remaining.length)
              target.setAttribute("aria-labelledby", remaining.join(" "));
            else if (baselineName === null)
              target.removeAttribute("aria-labelledby");
            else
              target.setAttribute("aria-labelledby", baselineName);
          }
        }
      } catch (error) {
        failed = true;
        failure = error;
      }
      try {
        const end = endProjection;
        endProjection = null;
        end?.();
      } catch (error) {
        if (!failed) {
          failed = true;
          failure = error;
        }
      }
      try {
        idLease?.dispose();
      } catch (error) {
        if (!failed) {
          failed = true;
          failure = error;
        }
      }
      if (failed)
        throw failure;
    };
    try {
      if (id) {
        const matches = idMatches(label.getRootNode(), id);
        if (matches.length !== 1 || matches[0] !== label)
          return null;
        idLease = retainGeneratedId(label, id);
      } else {
        do {
          id = "pui-control-label-" + nextLabelId++;
        } while (idMatches(label.getRootNode(), id).length);
        idLease = ownGeneratedId(label, id, baselineId);
      }
      endProjection = options.beginNameProjection();
      if (options.getRoot() !== target || !target.isConnected || !label.isConnected || label.getRootNode() !== source.scope || target.getRootNode() !== source.scope || options.hasAuthoredName() || target.getAttribute("aria-label")?.trim() || idTokens(target.getAttribute("aria-labelledby")).length || label.getAttribute("id") !== id) {
        release();
        return null;
      }
      nameInstalled = true;
      target.setAttribute("aria-labelledby", id);
      return Object.freeze({
        isActive() {
          const tokens = idTokens(target.getAttribute("aria-labelledby"));
          return live2 && options.getRoot() === target && target.isConnected && label.isConnected && target.getRootNode() === source.scope && label.getRootNode() === source.scope && label.getAttribute("id") === id && !options.hasAuthoredName() && !target.getAttribute("aria-label")?.trim() && tokens.length === 1 && tokens[0] === id && idMatches(label.getRootNode(), id).length === 1;
        },
        dispose: release
      });
    } catch (error) {
      try {
        release();
      } catch {
      }
      throw error;
    }
  }
  var anatomyPairs = /* @__PURE__ */ new WeakMap();
  function acquireNativeAnatomyPair(pair, domain) {
    let domains = anatomyPairs.get(pair.family);
    if (!domains)
      anatomyPairs.set(pair.family, domains = /* @__PURE__ */ new WeakMap());
    let pairs = domains.get(domain);
    if (!pairs)
      domains.set(domain, pairs = /* @__PURE__ */ new Map());
    const key = JSON.stringify([pair.labelRole, pair.targetRole]);
    let entry = pairs.get(key);
    if (!entry)
      pairs.set(key, entry = { ref: createControlLabelRef(), count: 0 });
    entry.count++;
    let active = true;
    return { ref: entry.ref, dispose() {
      if (!active)
        return;
      active = false;
      if (--entry.count === 0 && pairs.get(key) === entry)
        pairs.delete(key);
    } };
  }
  function createNativeControlLabel(options) {
    let kind = null, activate = null;
    let settings = { naming: true, activation: false };
    let ref = null, binding = null, host = null;
    let physicalRoot = null, mounted = false, disposed = false, generation = 0;
    let diagnostic = null;
    let sourceWatch = null;
    let pair = null, anatomyDomain = null;
    let anatomyLease = null, anatomyOff = null;
    const alive = () => {
      if (disposed || !options.isAlive())
        throw new Error("[ControlLabel] invalid after terminal disposal");
    };
    const setDiagnostic = (code) => {
      if (diagnostic === code)
        return;
      diagnostic = code;
      if (code && code !== "missing-binding" && code !== "missing-anatomy-domain")
        console.warn("[ControlLabel] " + code);
    };
    function release() {
      const retired = ++generation, oldBinding = binding, oldHost = host, oldSourceWatch = sourceWatch;
      binding = null;
      host = null;
      physicalRoot = null;
      sourceWatch = null;
      let failed = false, failure;
      try {
        oldSourceWatch?.();
      } catch (error) {
        failed = true;
        failure = error;
      }
      try {
        oldBinding?.dispose();
      } catch (error) {
        if (!failed) {
          failed = true;
          failure = error;
        }
      }
      try {
        oldHost?.dispose();
      } catch (error) {
        if (!failed) {
          failed = true;
          failure = error;
        }
      }
      if (failed)
        throw failure;
      return retired;
    }
    function refresh2() {
      if (disposed || !options.isAlive() || !options.isSetupComplete())
        return;
      const association = validateNativeInstanceAssociations(options.getAssociations());
      if (association.controlLabel && !kind)
        throw new Error("[ControlLabel] this Prototype has not declared Label or target participation");
      if (pair && association.controlLabel)
        throw new Error("[ControlLabel] explicit and anatomy association modes are mutually exclusive");
      let nextRef = association.controlLabel;
      if (pair && kind) {
        const domain = options.resolveAnatomy(pair, kind);
        if (domain !== anatomyDomain || domain && !anatomyLease) {
          const epoch2 = release();
          if (disposed || epoch2 !== generation)
            return;
          const previous = anatomyLease;
          anatomyLease = null;
          anatomyDomain = domain;
          ref = null;
          previous?.dispose();
          if (disposed || epoch2 !== generation)
            return;
          if (domain)
            anatomyLease = acquireNativeAnatomyPair(pair, domain);
        }
        nextRef = anatomyLease?.ref ?? null;
        if (!domain)
          setDiagnostic("missing-anatomy-domain");
      }
      const nextRoot = mounted ? options.getRoot() : null;
      if (ref !== nextRef || physicalRoot !== nextRoot && (binding || host)) {
        const epoch2 = release();
        if (disposed || epoch2 !== generation)
          return;
        ref = nextRef;
      }
      if (!kind || !ref || !mounted || !nextRoot || !(options.isReady?.() ?? true)) {
        if (binding || host)
          release();
        if (!pair || ref)
          setDiagnostic(ref ? "missing-binding" : null);
        return;
      }
      if (binding) {
        binding.refresh();
        return;
      }
      const epoch = ++generation;
      try {
        const nextHost = createWebControlLabelHost(() => mounted && !disposed && options.isAlive() && (options.isReady?.() ?? true) ? options.getRoot() : null).attach({
          kind,
          activation: kind === "label" && settings.activation,
          onActivate(source) {
            if (epoch === generation && !disposed)
              binding?.requestActivation(source);
          },
          onViewChange() {
            if (epoch === generation && !disposed)
              binding?.refresh();
          }
        });
        if (disposed || epoch !== generation) {
          nextHost.dispose();
          return;
        }
        host = nextHost;
        physicalRoot = nextRoot;
        const nextBinding = bindControlLabel({
          owner: options.identity,
          kind,
          ref,
          semanticRef: options.identity,
          view: () => epoch === generation && mounted && !disposed && options.isAlive() && (options.isReady?.() ?? true) ? nextHost.view() : null,
          options: () => settings,
          name: (_identity, view) => {
            const previous = sourceWatch;
            sourceWatch = null;
            previous?.();
            const element = view.identity;
            let watching = true, stop = null;
            const retire = () => {
              if (!watching)
                return;
              watching = false;
              if (sourceWatch === retire)
                sourceWatch = null;
              stop?.();
            };
            if (element?.nodeType === 1)
              stop = observeScope(view.scope, element, () => {
                if (epoch === generation && !disposed)
                  binding?.refresh();
              }, () => element.getAttribute("id"));
            sourceWatch = retire;
            let naming;
            try {
              naming = claimNativeControlLabelName(options, view);
            } catch (error) {
              try {
                retire();
              } catch {
              }
              throw error;
            }
            return Object.freeze({
              isActive: () => naming?.isActive() ?? false,
              dispose() {
                let failed = false, failure;
                try {
                  retire();
                } catch (error) {
                  failed = true;
                  failure = error;
                }
                try {
                  naming?.dispose();
                } catch (error) {
                  if (!failed) {
                    failed = true;
                    failure = error;
                  }
                }
                if (failed)
                  throw failure;
              }
            });
          },
          activate(isCurrent, source) {
            if (!isCurrent() || !activate || epoch !== generation || disposed)
              return;
            options.invoke(() => {
              if (!isCurrent() || !activate || epoch !== generation || disposed || !mounted || !options.isAlive())
                return;
              activate(options.getRun(), Object.freeze({ source, isCurrent }));
            });
          },
          diagnostic(code) {
            if (epoch === generation && !disposed)
              setDiagnostic(code);
          }
        });
        if (disposed || epoch !== generation)
          nextBinding.dispose();
        else
          binding = nextBinding;
      } catch (error) {
        if (epoch === generation && !disposed) {
          if (!pair)
            ref = null;
          try {
            release();
          } catch {
          }
        }
        throw error;
      }
    }
    function declare(next, callback, anatomy) {
      alive();
      options.ensureSetup("controlLabel.declare");
      if (kind)
        throw new Error("[ControlLabel] one subject or target declaration per instance");
      if (next === "target" && typeof callback !== "function")
        throw new TypeError("[ControlLabel] target requires an activation callback");
      if (anatomy && (!anatomy.family?.roles || typeof anatomy.labelRole !== "string" || typeof anatomy.targetRole !== "string" || anatomy.labelRole === anatomy.targetRole || !Object.hasOwn(anatomy.family.roles, anatomy.labelRole) || !Object.hasOwn(anatomy.family.roles, anatomy.targetRole) || Reflect.ownKeys(anatomy).some((key) => !["family", "labelRole", "targetRole"].includes(String(key)))))
        throw new TypeError("[ControlLabel] anatomy pair requires one declared family and distinct declared label/target roles");
      kind = next;
      activate = callback;
      pair = anatomy ? Object.freeze({ ...anatomy }) : null;
      if (pair)
        anatomyOff = options.subscribeAnatomy(refresh2);
      return Object.freeze({ sync(nextSettings) {
        alive();
        if (!nextSettings || typeof nextSettings.naming !== "boolean" || typeof nextSettings.activation !== "boolean")
          throw new TypeError("[ControlLabel] naming and activation require explicit booleans");
        if (settings.naming === nextSettings.naming && settings.activation === nextSettings.activation)
          return;
        settings = Object.freeze({ naming: nextSettings.naming, activation: nextSettings.activation });
        host?.setActivation(kind === "label" && settings.activation);
        binding?.refresh();
      } });
    }
    return {
      facade: Object.freeze({ label: (pair2) => declare("label", null, pair2), target: (callback, pair2) => declare("target", callback, pair2) }),
      refresh: refresh2,
      mount() {
        alive();
        mounted = true;
        refresh2();
      },
      unmount() {
        if (disposed)
          return;
        mounted = false;
        release();
      },
      dispose() {
        if (disposed)
          return;
        disposed = true;
        mounted = false;
        activate = null;
        ref = null;
        const ownOff = anatomyOff;
        anatomyOff = null;
        let failed = false, failure;
        const ownAnatomy = anatomyLease;
        anatomyLease = null;
        anatomyDomain = null;
        for (const run of [release, () => ownOff?.(), () => ownAnatomy?.dispose()])
          try {
            run();
          } catch (error) {
            if (!failed) {
              failed = true;
              failure = error;
            }
          }
        if (failed)
          throw failure;
      }
    };
  }

  // button-generated:.proto-ui/interaction/modules-e6807d4f71af1465-v2.ts
  function createNativeAdapterModules(options) {
    let disposed = false;
    let root = null;
    let generation = 0;
    let hostProperties = null;
    let hostPortal = null;
    const cleanups = [];
    const terminalCleanups = [];
    const propertyBaselines = /* @__PURE__ */ new Map();
    const hooks = /* @__PURE__ */ new Set();
    const claims = /* @__PURE__ */ new Map();
    const topologySubscribers = /* @__PURE__ */ new Set();
    const focusConfig = { disabled: false, navParticipation: "auto" };
    const scopeConfig = { trap: false, loop: false, navigation: "tab", orientation: "both", entry: "first", entryFallback: "none", restore: "previous", emptyPolicy: "container" };
    const rovingConfig = { loop: false, navigation: "arrow", orientation: "both", entry: "active", selectOnFocus: false };
    let pendingFocus = null;
    let scopeActivation = 0;
    let ownedEntry;
    const owner = { identity: options.identity, parent: options.getLogicalParent, target: () => root, host: () => root ? options.getHost?.() ?? root : null, alive: () => !disposed && options.isAlive(), hooks, claims, exposes: () => options.getExposes?.() ?? {}, focusConfig, scopeConfig, rovingConfig, selected: false, active: false, scopeDeclared: false, rovingDeclared: false, focusDeclared: false, entryDeclared: false, scopeActive: false, focus: (request) => requestFocus(request), cancelPendingFocus() {
      {
        pendingFocus = null;
        options.cancelPendingFocus?.();
      }
    }, changed: () => {
      const epoch = generation;
      for (const callback of [...topologySubscribers]) {
        if (epoch !== generation || !ready() || !(options.isReady?.() ?? true))
          break;
        if (topologySubscribers.has(callback))
          options.invoke(callback);
      }
      refresh2();
    } };
    if (owners.has(options.identity))
      throw new Error("[Modules] duplicate live owner identity.");
    function alive() {
      if (disposed || !options.isAlive())
        throw new Error("[Modules] owner is terminally disposed.");
    }
    function setup(operation) {
      alive();
      options.ensureSetup(operation);
    }
    function runtime(operation) {
      alive();
      options.ensureRuntime(operation);
    }
    function requestPresentation() {
      if (disposed || !options.isAlive() || !(options.isReady?.() ?? true))
        return;
      const next = rootProperties(), portal = portalTarget();
      const changed = !hostProperties || portal !== hostPortal || Object.keys(next).length !== Object.keys(hostProperties).length || Object.keys(next).some((key) => next[key] !== hostProperties[key]);
      hostProperties = next;
      hostPortal = portal;
      if (changed)
        options.requestHostUpdate?.();
    }
    function ready() {
      return !disposed && options.isAlive() && !!root && root === options.getRoot() && root.isConnected;
    }
    function announceTopology(rootOwner = logicalRoot(owner)) {
      for (const participant of [...owners.values()])
        if (participant.alive() && logicalRoot(participant) === rootOwner)
          participant.changed();
    }
    function requestFocus(request) {
      alive();
      if (focusConfig.disabled || !canFocus())
        return;
      if (!ready() || root.closest("[hidden],[inert],[data-pui-view-detached]")) {
        if (noteNativeFocusRequest())
          pendingFocus = request ?? {};
        return;
      }
      if (options.baseFocus)
        options.invoke(() => options.baseFocus().focusSelf(request));
      else if (noteNativeFocusRequest())
        root.focus({ preventScroll: request?.preventScroll });
    }
    function canFocus() {
      alive();
      for (let index = activeScopes.length - 1; index >= 0; index--) {
        const scope = activeScopes[index];
        if (!scope.alive()) {
          activeScopes.splice(index, 1);
          continue;
        }
        if (scope.target()?.isConnected)
          return descends(owner, scope);
      }
      return true;
    }
    function cancelOwnedEntry(intent = ownedEntry) {
      if (!intent)
        return;
      if (ownedEntry === intent)
        ownedEntry = void 0;
      if (focusState.scopeEntryIntent === intent)
        focusState.scopeEntryIntent = void 0;
    }
    function domain(family, required = true) {
      const found = ancestor(owner, (participant) => participant.claims.get(family)?.role === "root");
      if (!found && required)
        throw new Error("[Anatomy] current owner has no root domain for " + family.debugName);
      return found;
    }
    function anatomyOwners(family, role, ordered = false) {
      const rootOwner = domain(family);
      const found = [];
      for (const participant of owners.values())
        if (participant.alive() && participant.claims.has(family) && (!role || participant.claims.get(family).role === role) && ancestor(participant, (current2) => current2.claims.get(family)?.role === "root") === rootOwner)
          found.push(participant);
      return ordered ? found.sort(hostOrder) : found;
    }
    function currentAnatomyPart(family, part) {
      const participant = parts.get(part), rootOwner = domain(family, false);
      return rootOwner && participant?.alive() && participant.claims.get(family)?.part === part && ancestor(participant, (candidate) => candidate.claims.get(family)?.role === "root") === rootOwner ? participant : null;
    }
    function anatomyDescendants(family, part, role) {
      const participant = currentAnatomyPart(family, part);
      if (!participant)
        return [];
      return anatomyOwners(family, role, true).filter((candidate) => candidate !== participant && descends(candidate, participant)).map((candidate) => candidate.claims.get(family).part);
    }
    const anatomyVersions = /* @__PURE__ */ new Map();
    const anatomyOrder = {
      version(family) {
        alive();
        const members = anatomyOwners(family, void 0, true);
        const previous = anatomyVersions.get(family);
        if (!previous) {
          anatomyVersions.set(family, { members, version: 0 });
          return 0;
        }
        if (members.length !== previous.members.length || members.some((member, index) => member !== previous.members[index])) {
          previous.members = members;
          ++previous.version;
        }
        return previous.version;
      },
      parts(family) {
        alive();
        return anatomyOwners(family, void 0, true).map((participant) => participant.claims.get(family).part);
      },
      partsOf(family, role) {
        alive();
        return anatomyOwners(family, role, true).map((participant) => participant.claims.get(family).part);
      },
      indexOfSelf(family, role) {
        alive();
        return anatomyOwners(family, role, true).indexOf(owner);
      },
      prevOfSelf(family, role) {
        const members = anatomyOwners(family, role, true);
        const index = members.indexOf(owner);
        return index > 0 ? members[index - 1].claims.get(family).part : null;
      },
      nextOfSelf(family, role) {
        const members = anatomyOwners(family, role, true);
        const index = members.indexOf(owner);
        return index >= 0 && index + 1 < members.length ? members[index + 1].claims.get(family).part : null;
      }
    };
    const anatomy = {
      ...anatomyOrder,
      order: anatomyOrder,
      claim(family, declaration) {
        setup("anatomy.claim");
        if (!family?.roles[declaration.role] || claims.has(family))
          throw new Error("[Anatomy] invalid/duplicate family role claim.");
        if (declaration.profile && (declaration.role !== "root" || !family.profiles?.[declaration.profile]))
          throw new Error("[Anatomy] invalid root profile.");
        const exposesAvailable = () => owner.alive() && claims.get(family)?.part === part;
        const part = Object.freeze({ role: declaration.role, hasExpose(key) {
          return exposesAvailable() && Object.hasOwn(owner.exposes(), key);
        }, getExpose(key) {
          return exposesAvailable() ? owner.exposes()[key] ?? null : null;
        }, hasHook(name) {
          return hooks.has(name);
        } });
        claims.set(family, { family, ...declaration, part });
        parts.set(part, owner);
      },
      has(family, role) {
        alive();
        return domain(family, false) !== null && anatomyOwners(family, role).length > 0;
      },
      parts(family) {
        alive();
        return anatomyOwners(family).map((participant) => participant.claims.get(family).part);
      },
      partsOf(family, role) {
        alive();
        return anatomyOwners(family, role).map((participant) => participant.claims.get(family).part);
      },
      descendantsOf(family, part, role) {
        alive();
        if (options.isSetupComplete?.() === false)
          throw new Error("[Anatomy] descendantsOf is runtime-only.");
        return anatomyDescendants(family, part, role);
      },
      subscribeParts(family, role, callback) {
        setup("anatomy.subscribeParts");
        let previous = [];
        const changed = () => {
          if (!domain(family, false))
            return;
          const next = anatomyOrder.partsOf(family, role);
          if (next.length === previous.length && next.every((part, index) => part === previous[index]))
            return;
          previous = next;
          callback(options.getRun(), next);
        };
        topologySubscribers.add(changed);
        return () => {
          setup("anatomy.subscribeParts.off");
          topologySubscribers.delete(changed);
        };
      }
    };
    let explicitId;
    let accessibleName;
    let accessibleDescription;
    let accessibleLevel;
    let accessibleTree = {};
    let controlLabelProjection = null;
    const accessibleSubscriptions = /* @__PURE__ */ new Map();
    const relations = /* @__PURE__ */ new Map();
    const relationAttributes = { labelledBy: "aria-labelledby", describedBy: "aria-describedby", controls: "aria-controls", owns: "aria-owns", activeDescendant: "aria-activedescendant", details: "aria-details", errorMessage: "aria-errormessage", flowTo: "aria-flowto" };
    const readValue = (value) => value && typeof value === "object" && "get" in value && typeof value.get === "function" ? value.get() : value;
    function watchAccessible(key, value) {
      accessibleSubscriptions.get(key)?.();
      accessibleSubscriptions.delete(key);
      if (!value || typeof value !== "object" || !("get" in value) || typeof value.get !== "function")
        return;
      const state = value;
      const off = options.subscribeState ? options.subscribeState(state, refresh2) : state.subscribe?.(refresh2);
      if (off)
        accessibleSubscriptions.set(key, off);
    }
    function hostId(identity) {
      const participant = owners.get(identity);
      const existing = participant?.target()?.id;
      if (existing) {
        hostIds.set(identity, existing);
        return existing;
      }
      let id = hostIds.get(identity);
      if (!id) {
        id = "pui-object-" + hostIdState.nextHostId++;
        hostIds.set(identity, id);
      }
      return id;
    }
    function relationValue(config) {
      const value = readValue(config.target);
      if (typeof value === "string")
        return value || null;
      const references = Array.isArray(value) ? value : value && typeof value === "object" ? [value] : [];
      const ids = [];
      for (const reference of references) {
        const related = parts.get(reference) ?? owners.get(reference);
        if (!related?.alive())
          continue;
        const relatedTarget = related.target();
        if (root && (!relatedTarget?.isConnected || relatedTarget.ownerDocument !== root.ownerDocument))
          continue;
        const id = hostId(related.identity);
        if (!ids.includes(id))
          ids.push(id);
      }
      return ids.length ? ids.join(" ") : null;
    }
    const accessible = {
      objectRef: options.identity,
      id(value) {
        setup("accessible.id");
        explicitId = value;
        watchAccessible("id", value);
        const current2 = readValue(value);
        if (typeof current2 === "string" && current2)
          hostIds.set(options.identity, current2);
      },
      name(value) {
        setup("accessible.name");
        accessibleName = value;
        watchAccessible("name", value);
      },
      nameFromContent() {
        setup("accessible.nameFromContent");
        accessibleName = void 0;
        watchAccessible("name", void 0);
      },
      description(value) {
        setup("accessible.description");
        accessibleDescription = value;
        watchAccessible("description", value);
      },
      relation(kind, spec) {
        setup("accessible.relation");
        if (!Object.hasOwn(relationAttributes, kind))
          throw new Error("[A11y] invalid relationship kind.");
        const mode = String(spec.mode ?? "replace");
        if (mode !== "replace" && mode !== "append")
          throw new Error("[A11y] relation mode must be replace or append.");
        relations.set(kind, { ...spec, mode });
        watchAccessible("relation:" + kind, spec.target);
      },
      tree(config) {
        setup("accessible.tree");
        accessibleTree = { ...accessibleTree, ...config };
        for (const key of Object.keys(config))
          watchAccessible("tree:" + key, config[key]);
      },
      level(value) {
        setup("accessible.level");
        const current2 = readValue(value);
        if (typeof current2 !== "number" || !Number.isInteger(current2) || current2 < 1 || current2 > 6)
          throw new Error("[A11y] heading level must be an integer in range 1-6.");
        accessibleLevel = value;
        watchAccessible("level", value);
      }
    };
    function rootTag() {
      alive();
      return null;
    }
    function adoptControlState() {
      alive();
      if (root)
        throw new Error("[Modules] adopt control state before the first view mount.");
      const target = options.getRoot();
      if (!target)
        throw new Error("[Modules] hydration requires the adopted physical Root.");
      if (target.id)
        hostIds.set(options.identity, target.id);
    }
    function rootProperties() {
      alive();
      const result = /* @__PURE__ */ Object.create(null);
      return result;
    }
    function projectAttributes() {
      alive();
      const result = /* @__PURE__ */ Object.create(null);
      {
        const identity = readValue(explicitId);
        if (explicitId !== void 0 || hostIds.has(options.identity))
          result.id = typeof identity === "string" && identity ? identity : hostIds.has(options.identity) ? hostId(options.identity) : null;
        if (accessibleName !== void 0) {
          const name = readValue(accessibleName);
          result["aria-label"] = typeof name === "string" && name ? name : null;
        }
        if (accessibleDescription !== void 0) {
          const description = readValue(accessibleDescription);
          result["aria-description"] = typeof description === "string" && description ? description : null;
        }
        const level = readValue(accessibleLevel);
        if (accessibleLevel !== void 0 && typeof level === "number" && Number.isInteger(level) && level >= 1 && level <= 6 && (options.getAccessibleRole?.() ?? root?.getAttribute("role")) === "heading")
          result["aria-level"] = String(level);
        else if (accessibleLevel !== void 0)
          result["aria-level"] = null;
        if (accessibleTree.hidden !== void 0) {
          const hidden = Boolean(readValue(accessibleTree.hidden));
          result["aria-hidden"] = String(hidden);
          result.hidden = hidden ? "" : null;
        }
        if (accessibleTree.mergeChildren !== void 0)
          result["data-pui-a11y-merge-children"] = readValue(accessibleTree.mergeChildren) ? "" : null;
        for (const [kind, relation] of relations) {
          {
            const authoredTarget = readValue(relation.target);
            if (kind === "labelledBy" && controlLabelProjection && (authoredTarget == null || typeof authoredTarget === "string" && !authoredTarget.trim()))
              continue;
          }
          const name = relationAttributes[kind], semantic = relationValue(relation);
          const baseline = options.getAttributeBaseline ? options.getAttributeBaseline(name) : attributeBaselines.has(name) ? attributeBaselines.get(name).baseline : root?.getAttribute(name);
          const value = relation.mode === "append" && baseline ? [...new Set((baseline + " " + (semantic ?? "")).trim().split(/\s+/))].join(" ") : semantic;
          if (Object.hasOwn(result, name) && result[name] !== value)
            throw new Error("[A11y] conflicting relation ownership on a shared attribute.");
          result[name] = value;
        }
      }
      if (owner.focusDeclared && focusConfig.navParticipation !== "none") {
        const provider = ancestor(owner, (candidate) => candidate !== owner && candidate.rovingDeclared);
        if (provider) {
          const members = [...owners.values()].filter((candidate) => candidate.focusDeclared && !candidate.focusConfig.disabled && ancestor(candidate, (entry) => entry !== candidate && entry.rovingDeclared) === provider).sort(hostOrder);
          const selected = members.find((candidate) => candidate.active) ?? members.find((candidate) => candidate.selected) ?? members[0];
          result.tabindex = focusConfig.disabled || selected !== owner ? "-1" : "0";
        }
      }
      return result;
    }
    const attributeBaselines = /* @__PURE__ */ new Map();
    function projectModuleAttributes() {
      if (!ready())
        return;
      if (options.requestAttributeRefresh) {
        options.requestAttributeRefresh();
        return;
      }
      for (const [name, value] of Object.entries(projectAttributes())) {
        const current2 = root.getAttribute(name);
        let ownership = attributeBaselines.get(name);
        if (!ownership) {
          ownership = { baseline: current2, projected: current2 };
          attributeBaselines.set(name, ownership);
        } else if (current2 !== ownership.projected)
          ownership.baseline = current2;
        if (current2 !== value) {
          if (value === null)
            root.removeAttribute(name);
          else
            root.setAttribute(name, value);
        }
        ownership.projected = value;
      }
    }
    function refresh2() {
      if (disposed || !options.isAlive())
        return;
      if (!ready()) {
        requestPresentation();
        return;
      }
      projectModuleAttributes();
      if (pendingFocus) {
        const request = pendingFocus;
        pendingFocus = null;
        requestFocus(request);
      }
      requestPresentation();
    }
    function portalTarget() {
      return null;
    }
    function unmount() {
      const previous = root;
      ++generation;
      root = null;
      if (previous && targets.get(previous) === owner)
        targets.delete(previous);
      const failures = [];
      for (const cleanup of cleanups.splice(0))
        try {
          cleanup();
        } catch (error) {
          failures.push(error);
        }
      if (previous) {
        for (const [name, ownership] of attributeBaselines)
          if (previous.getAttribute(name) === ownership.projected) {
            if (ownership.baseline === null)
              previous.removeAttribute(name);
            else
              previous.setAttribute(name, ownership.baseline);
          }
        for (const [name, ownership] of propertyBaselines)
          if (previous.style.getPropertyValue(name) === ownership.projected) {
            if (ownership.value)
              previous.style.setProperty(name, ownership.value);
            else
              previous.style.removeProperty(name);
          }
      }
      attributeBaselines.clear();
      propertyBaselines.clear();
      if (previous) {
        if (options.isAlive() && (options.isReady?.() ?? true)) {
        }
        announceTopology();
      }
      if (failures.length)
        throw new AggregateError(failures, "[Modules] view cleanup failed.");
    }
    function mount() {
      alive();
      const candidate = options.getRoot();
      if (root === candidate && ready()) {
        refresh2();
        return;
      }
      unmount();
      root = candidate;
      if (!root)
        return;
      const mountEpoch = generation;
      targets.set(root, owner);
      if (root.id)
        hostIds.set(options.identity, root.id);
      try {
        const doc = root.ownerDocument;
        refresh2();
        announceTopology();
        if (typeof MutationObserver !== "undefined" && claims.size) {
          const mutation = new MutationObserver((records) => {
            if (!records.some((record) => record.type === "childList"))
              return;
            announceTopology();
          });
          mutation.observe(root, { childList: true, subtree: true });
          cleanups.push(() => mutation.disconnect());
        }
      } catch (error) {
        if (mountEpoch === generation && root === candidate)
          try {
            unmount();
          } catch (cleanup) {
            throw new AggregateError([error, cleanup], "[Modules] mount and cleanup failed.");
          }
        throw error;
      }
    }
    const capabilities = {
      hasAuthoredControlLabelName() {
        const name = readValue(accessibleName), target = readValue(relations.get("labelledBy")?.target);
        return typeof name === "string" && name.trim().length > 0 || (typeof target === "string" ? target.trim().length > 0 : target != null) || Boolean(options.getAttributeBaseline?.("aria-label")?.trim());
      },
      beginControlLabelName() {
        const lease = {};
        controlLabelProjection = lease;
        try {
          projectModuleAttributes();
        } catch (error) {
          if (controlLabelProjection === lease)
            controlLabelProjection = null;
          throw error;
        }
        return () => {
          if (controlLabelProjection === lease)
            controlLabelProjection = null;
        };
      },
      controlLabelAnatomyScope(pair, kind) {
        const expected = kind === "label" ? pair.labelRole : pair.targetRole;
        return claims.get(pair.family)?.role === expected ? domain(pair.family, false)?.identity ?? null : null;
      },
      subscribeControlLabelAnatomy(callback) {
        topologySubscribers.add(callback);
        return () => topologySubscribers.delete(callback);
      },
      anatomy,
      accessible,
      configureFocusable(config) {
        setup("focus.configure");
        owner.focusDeclared = true;
        hooks.add("asFocusable");
        Object.assign(focusConfig, config);
      },
      setFocusDisabled(value) {
        runtime("focus.setDisabled");
        focusConfig.disabled = value;
        if (value)
          pendingFocus = null;
        announceTopology();
      },
      setNavParticipation(value) {
        runtime("focus.setNavParticipation");
        if (!["auto", "none"].includes(value))
          throw new Error("[Focus] invalid navigation participation.");
        focusConfig.navParticipation = value;
        refresh2();
      },
      setRovingStatus(status) {
        runtime("focus.setRovingStatus");
        if (status.selected !== void 0)
          owner.selected = Boolean(status.selected);
        if (status.active !== void 0)
          owner.active = Boolean(status.active);
        refresh2();
      },
      canFocus,
      focus(request) {
        runtime("focus.focus");
        requestFocus(request);
      },
      blur() {
        runtime("focus.blur");
        ++scopeActivation;
        cancelOwnedEntry();
        pendingFocus = null;
        if (ready())
          root.blur();
      },
      rootTag,
      rootProperties,
      projectAttributes,
      portalTarget,
      adoptControlState,
      commitHost() {
      },
      refresh: refresh2,
      mount,
      unmount,
      dispose() {
        if (disposed)
          return;
        const rootOwner = logicalRoot(owner);
        const failures = [];
        try {
          unmount();
        } catch (error) {
          failures.push(error);
        }
        disposed = true;
        owners.delete(options.identity);
        claims.clear();
        hooks.clear();
        topologySubscribers.clear();
        {
          for (const off of accessibleSubscriptions.values())
            try {
              off();
            } catch (error) {
              failures.push(error);
            }
          accessibleSubscriptions.clear();
        }
        for (const cleanup of terminalCleanups.splice(0))
          try {
            cleanup();
          } catch (error) {
            failures.push(error);
          }
        anatomyVersions.clear();
        announceTopology(rootOwner);
        if (failures.length)
          throw new AggregateError(failures, "[Modules] terminal cleanup failed.");
      }
    };
    owners.set(options.identity, owner);
    return capabilities;
  }

  // button-generated:.proto-ui/interaction/native-e6807d4f71af1465-v2.ts
  function readPointerSampleField(native, field) {
    if (!native || typeof native !== "object" && typeof native !== "function")
      return void 0;
    try {
      return native[field];
    } catch {
      return void 0;
    }
  }
  var semanticEvents = { "press.start": true, "press.end": true, "press.cancel": true, "press.commit": true, "key.down": true, "key.up": true, "pointer.down": true, "pointer.move": true, "pointer.up": true, "pointer.cancel": true, "pointer.enter": true, "pointer.leave": true, "nav.focus": true, "nav.blur": true, "text.focus": true, "text.blur": true, "input": true, "change": true, "context.menu": true };
  var stateAttributes = { "atomic": "aria-atomic", "autocomplete": "aria-autocomplete", "current": "aria-current", "sort": "aria-sort", "busy": "aria-busy", "checked": "aria-checked", "disabled": "aria-disabled", "expanded": "aria-expanded", "hasPopup": "aria-haspopup", "invalid": "aria-invalid", "live": "aria-live", "orientation": "aria-orientation", "pressed": "aria-pressed", "rowCount": "aria-rowcount", "columnCount": "aria-colcount", "rowIndex": "aria-rowindex", "columnIndex": "aria-colindex", "rowSpan": "aria-rowspan", "columnSpan": "aria-colspan", "readOnly": "aria-readonly", "required": "aria-required", "selected": "aria-selected", "modal": "aria-modal", "hidden": "aria-hidden", "valueMin": "aria-valuemin", "valueMax": "aria-valuemax", "valueNow": "aria-valuenow", "valueText": "aria-valuetext", "level": "aria-level", "posInSet": "aria-posinset", "setSize": "aria-setsize" };
  function markNativeExposeEvent(event) {
    exposeSignals.add(event);
    return event;
  }
  function createNativeInteraction(options) {
    let disposed = false;
    let root = null;
    let host = null;
    let generation = 0;
    let trigger = false;
    let focusDeclared = false;
    let disabled = false;
    let autoFocus = false;
    let navParticipation = "auto";
    let keyboard = false;
    let pendingFocus;
    let hasPendingFocus = false;
    let didAutoFocus = false;
    let role;
    const identity = options.identity ?? {};
    const registrations = [];
    const capturedListeners = /* @__PURE__ */ new WeakMap();
    const removals = [];
    const subscriptions = [];
    const states = /* @__PURE__ */ new Map();
    const stateConditions = /* @__PURE__ */ new Map();
    const actions = /* @__PURE__ */ new Map();
    const attributes = /* @__PURE__ */ new Map();
    let sequence = 0;
    let suppressKeyboardClick = false;
    let pressKey = null;
    let pointer = null;
    let globalPressKey = null;
    let globalPointer = null;
    let suppressGlobalKeyboardClick = false;
    let keyboardClickVersion = 0;
    let globalKeyboardClickVersion = 0;
    let pointerCancelled = false;
    function alive() {
      if (disposed || !options.isAlive())
        throw new Error("[Interaction] invalid after terminal disposal.");
    }
    function active(epoch = generation, target = root) {
      return !disposed && options.isAlive() && !!target && target === root && options.getRoot() === target && generation === epoch && rootOwners.get(target)?.identity === identity;
    }
    function deliverable(epoch = generation, target = root) {
      return active(epoch, target) && (options.isReady?.() ?? true);
    }
    const nativeNotifications = [];
    let nativeNotifying = false;
    function observed(initial) {
      let value = initial;
      const callbacks = /* @__PURE__ */ new Set();
      const handle = Object.freeze({
        get() {
          alive();
          return value;
        },
        watch(callback) {
          alive();
          options.ensureSetup("state.watch");
          const listener = (event) => callback(options.getRun(), event);
          callbacks.add(listener);
          return () => {
            callbacks.delete(listener);
          };
        },
        subscribe(callback) {
          alive();
          const registration = (event) => callback(event);
          callbacks.add(registration);
          return () => {
            callbacks.delete(registration);
          };
        }
      });
      return { handle, set(next) {
        if (value === next)
          return;
        const prev = value;
        value = next;
        if (!options.isSetupComplete())
          return;
        const event = { type: "next", prev, next, reason: "native-focus" };
        for (const subscriber of Array.from(callbacks)) {
          Object.defineProperty(nativeNotifications, nativeNotifications.length, { value: () => {
            if (!disposed && options.isAlive() && callbacks.has(subscriber)) {
              options.invoke(() => subscriber(event));
            }
          }, writable: true, enumerable: true, configurable: true });
        }
        if (!nativeNotifying) {
          nativeNotifying = true;
          const notificationFailures = [];
          let notificationIndex = 0;
          try {
            while (notificationIndex < nativeNotifications.length && (!disposed && options.isAlive())) {
              try {
                nativeNotifications[notificationIndex++]();
              } catch (error) {
                Object.defineProperty(notificationFailures, notificationFailures.length, { value: error, writable: true, enumerable: true, configurable: true });
              }
            }
          } finally {
            nativeNotifications.length = 0;
            nativeNotifying = false;
          }
          if (notificationFailures.length === 1)
            throw notificationFailures[0];
          if (notificationFailures.length > 1)
            throw new AggregateError(notificationFailures, "[State] subscriber failures");
        }
      }, clear() {
        callbacks.clear();
      } };
    }
    const focused = observed(false);
    const focusVisible = observed(false);
    const focusable = observed(false);
    function project(name, value) {
      if (!root)
        return;
      let ownership = attributes.get(name);
      const current2 = root.getAttribute(name);
      if (!ownership) {
        ownership = { baseline: current2, projected: current2 };
        attributes.set(name, ownership);
      } else if (current2 !== ownership.projected)
        ownership.baseline = current2;
      if (current2 !== value) {
        if (value === null)
          root.removeAttribute(name);
        else
          root.setAttribute(name, value);
      }
      ownership.projected = value;
    }
    function clearProjection(target) {
      for (const [name, ownership] of attributes) {
        if (target.getAttribute(name) !== ownership.projected)
          continue;
        if (ownership.baseline === null)
          target.removeAttribute(name);
        else
          target.setAttribute(name, ownership.baseline);
      }
      attributes.clear();
    }
    function read(value) {
      return typeof value === "object" && value !== null && "get" in value ? value.get() : value;
    }
    function scalar(key, value) {
      if (key === "autocomplete")
        return typeof value === "string" && ["none", "inline", "list", "both"].includes(value) ? value : null;
      if (key === "sort")
        return typeof value === "string" && ["none", "ascending", "descending", "other"].includes(value) ? value : null;
      if (key === "current")
        return typeof value === "boolean" ? String(value) : typeof value === "string" && ["false", "true", "page", "step", "location", "date", "time"].includes(value) ? value : null;
      if (value === null || value === void 0 || value === "")
        return null;
      if (["valueMin", "valueMax", "valueNow"].includes(key) && typeof value === "string" && /^-?(?:0|[1-9][0-9]*)(?:[.][0-9]+)?(?:[eE][+-]?[0-9]+)?$/.test(value) && Number.isFinite(Number(value)))
        return value;
      if (["valueMin", "valueMax", "valueNow"].includes(key))
        return typeof value === "number" && Number.isFinite(value) ? String(value) : null;
      if (key === "valueText")
        return typeof value === "string" ? value : null;
      if (key === "rowCount" || key === "columnCount" || key === "setSize")
        return typeof value === "number" && Number.isSafeInteger(value) && (value === -1 || value > 0) ? String(value) : null;
      if (["rowIndex", "columnIndex", "rowSpan", "columnSpan", "level", "posInSet"].includes(key))
        return typeof value === "number" && Number.isSafeInteger(value) && value > 0 ? String(value) : null;
      return String(value);
    }
    function visitProjection(write) {
      if (focusDeclared)
        write("tabindex", disabled || navParticipation === "none" ? "-1" : "0");
      {
        if (role !== void 0)
          write("role", read(role) || null);
        for (const [key, state] of states) {
          if (!Object.hasOwn(stateAttributes, key))
            continue;
          const value = state.get();
          if (stateConditions.has(key) && stateConditions.get(key).get() !== true)
            continue;
          write(stateAttributes[key], scalar(key, value));
          if (key === "hidden")
            write("hidden", value === true ? "" : null);
        }
        if (actions.size)
          write("data-pui-a11y-actions", [...actions.keys()].sort().join(" "));
      }
    }
    function projectAttributes() {
      alive();
      const result = /* @__PURE__ */ Object.create(null);
      visitProjection((name, value) => {
        result[name] = value;
      });
      return result;
    }
    function adoptAttributes(snapshot, baselines) {
      alive();
      if (root || attributes.size)
        throw new Error("[Interaction] hydration attributes must be adopted before first projection.");
      const target = options.getRoot();
      if (!target)
        throw new Error("[Interaction] hydration requires the adopted current Root.");
      for (const name of Object.keys(snapshot)) {
        const value = snapshot[name];
        if (target.getAttribute(name) !== value)
          continue;
        const baseline = baselines && Object.hasOwn(baselines, name) ? baselines[name] : null;
        attributes.set(name, { baseline, projected: value });
      }
      modules.adoptControlState();
    }
    function refresh2() {
      if (!active())
        return;
      const next = combinedProjectAttributes();
      for (const [name, ownership] of attributes)
        if (!Object.hasOwn(next, name)) {
          if (root.getAttribute(name) === ownership.projected) {
            if (ownership.baseline === null)
              root.removeAttribute(name);
            else
              root.setAttribute(name, ownership.baseline);
          }
          attributes.delete(name);
        }
      for (const [name, value] of Object.entries(next))
        project(name, value);
    }
    function subscribe(state, callback) {
      if (options.subscribeState)
        return options.subscribeState(state, callback);
      if ("subscribe" in state && typeof state.subscribe === "function")
        return state.subscribe(callback);
      return void 0;
    }
    function watch(state) {
      const off = subscribe(state, refresh2);
      if (off)
        subscriptions.push(off);
    }
    function register2(kind, type, callback, hostOptions) {
      options.ensureSetup("event." + (kind === "root" ? "on" : "onGlobal"));
      if (!Object.hasOwn(semanticEvents, type) && !(type.startsWith("host:") && type.length > 5))
        throw new Error("[Event] invalid input type.");
      if (!type.startsWith("host:") && hostOptions !== void 0)
        throw new Error("[Event] options are host:* only.");
      const copied = hostOptions === void 0 ? void 0 : Object.freeze({ ...hostOptions });
      const typedCallback = callback;
      const registration = { kind, type, callback: typedCallback, options: copied, active: true };
      registrations.push(registration);
      const meta = { kind, type, options: copied, label: void 0 };
      const token = { id: "ev_" + ++sequence, meta, desc(text) {
        options.ensureSetup("event.token.desc");
        if (text.trim())
          meta.label = text.trim();
        return token;
      } };
      capturedListeners.set(token, registration);
      return token;
    }
    function emit(kind, type, native, epoch, target) {
      for (const registration of registrations) {
        if (!registration.active || registration.kind !== kind || registration.type !== type || !deliverable(epoch, target))
          continue;
        let deadline = true;
        const payload = { type, control: Object.freeze({
          requestDefaultActionPrevention(_request) {
            options.ensureEvent("event.control.requestDefaultActionPrevention");
            if (!deadline || !deliverable(epoch, target))
              throw new Error("[Event] default-action control is outside its callback window.");
            if (!defaultPreventedSamples.has(native)) {
              native.preventDefault();
              defaultPreventedSamples.add(native);
            }
          }
        }) };
        const source = native;
        if (["pointer.down", "pointer.move", "pointer.up", "pointer.cancel", "pointer.enter", "pointer.leave"].includes(type)) {
          const kind2 = readPointerSampleField(native, "pointerType"), buttons = readPointerSampleField(native, "buttons");
          payload.pointerType = kind2 === "mouse" || kind2 === "touch" || kind2 === "pen" ? kind2 : "unknown";
          payload.pointerButtons = typeof buttons === "number" && Number.isFinite(buttons) && Number.isInteger(buttons) && buttons >= 0 ? buttons === 0 ? "none" : "active" : "unknown";
        }
        if (typeof source.key === "string")
          payload.key = source.key;
        for (const field of ["ctrlKey", "metaKey", "altKey", "shiftKey", "repeat"])
          if (typeof source[field] === "boolean")
            payload[field] = source[field];
        try {
          options.invoke(() => registration.callback(options.getRun(), Object.freeze(payload)));
        } finally {
          deadline = false;
        }
      }
    }
    const focus = {
      focused: focused.handle,
      focusVisible: focusVisible.handle,
      focusable: focusable.handle,
      configure(patch) {
        options.ensureSetup("focus.configure");
        if (patch.autoFocus !== void 0)
          autoFocus = patch.autoFocus;
        if (patch.disabled !== void 0)
          disabled = patch.disabled;
        if (patch.navParticipation !== void 0)
          navParticipation = patch.navParticipation;
        modules.configureFocusable(patch);
        focusable.set(!disabled);
        refresh2();
      },
      setDisabled(next) {
        alive();
        options.ensureRuntime("focus.setDisabled");
        disabled = next;
        modules.setFocusDisabled(next);
        focusable.set(!next);
        if (next) {
          hasPendingFocus = false;
          if (root && root.ownerDocument.activeElement === root)
            root.blur();
          focused.set(false);
          focusVisible.set(false);
        }
        refresh2();
      },
      focusSelf(request) {
        alive();
        options.ensureRuntime("focus.focusSelf");
        if (disabled || !modules.canFocus())
          return;
        if (!noteNativeFocusRequest())
          return;
        if (request?.reason === "keyboard")
          keyboard = true;
        else if (request?.reason === "pointer")
          keyboard = false;
        if (!deliverable() || !root.isConnected || root.closest("[hidden],[inert],[data-pui-view-detached]")) {
          pendingFocus = request;
          hasPendingFocus = true;
          return;
        }
        root.focus({ preventScroll: request?.preventScroll });
      },
      focus(request) {
        modules.focus(request);
      },
      blur() {
        alive();
        options.ensureRuntime("focus.blur");
        hasPendingFocus = false;
        modules.blur();
        focused.set(false);
        focusVisible.set(false);
      },
      isFocused() {
        alive();
        return focused.handle.get();
      },
      setNavParticipation(value) {
        modules.setNavParticipation(value);
        navParticipation = value;
        refresh2();
      },
      setRovingStatus(status) {
        modules.setRovingStatus(status);
      }
    };
    const accessibleBase = {
      state(key, state, condition) {
        options.ensureSetup("accessible.state");
        const when = condition?.when;
        if (when !== void 0 && typeof when.get() !== "boolean")
          throw new Error("[Accessible] when must be a Boolean State.");
        states.set(key, state);
        stateConditions.delete(key);
        if (when !== void 0)
          stateConditions.set(key, when);
        refresh2();
      },
      action(key, spec = {}) {
        options.ensureSetup("accessible.action");
        actions.set(key, { ...spec });
        refresh2();
      },
      role(value) {
        options.ensureSetup("accessible.role");
        role = value;
        if (typeof value !== "string")
          watch(value);
        refresh2();
      }
    };
    function unmount() {
      generation++;
      const previous = root, previousHost = host;
      root = null;
      host = null;
      if (previous && rootOwners.get(previous)?.identity === identity)
        rootOwners.delete(previous);
      if (previousHost && rootOwners.get(previousHost)?.identity === identity)
        rootOwners.delete(previousHost);
      logicalOwners.delete(identity);
      let failure;
      for (const remove of removals.splice(0)) {
        try {
          remove();
        } catch (error) {
          failure ??= error;
        }
      }
      if (previous)
        clearProjection(previous);
      {
        pressKey = null;
        pointer = null;
        pointerCancelled = false;
        suppressKeyboardClick = false;
        globalPressKey = null;
        globalPointer = null;
        suppressGlobalKeyboardClick = false;
      }
      {
        focused.set(false);
        focusVisible.set(false);
      }
      if (failure)
        throw failure;
    }
    function mount() {
      alive();
      const candidate = options.getRoot();
      if (root === candidate && active()) {
        refresh2();
        return;
      }
      unmount();
      alive();
      if (!candidate)
        return;
      const target = candidate;
      root = target;
      host = options.getHost?.() ?? target;
      const rootOwner = { identity, parent: options.getLogicalParent ?? (() => null), trigger: () => trigger, target };
      rootOwners.set(target, rootOwner);
      rootOwners.set(host, rootOwner);
      logicalOwners.set(identity, rootOwner);
      {
        const epoch = generation;
        const notify = () => {
          if (active(epoch, target))
            refresh2();
        };
        for (const state of /* @__PURE__ */ new Set([...states.values(), ...stateConditions.values()])) {
          const off = subscribe(state, notify);
          if (off)
            removals.push(off);
        }
      }
      {
        let listen = function(where, name, callback, hostOptions) {
          let live2 = true;
          const wrapped = (event) => {
            if (live2 && valid() && !exposeSignals.has(event))
              callback(event);
          };
          where.addEventListener(name, wrapped, hostOptions);
          removals.push(() => {
            live2 = false;
            where.removeEventListener(name, wrapped, hostOptions);
          });
        }, owns = function(native) {
          const path = typeof native.composedPath === "function" ? native.composedPath() : [];
          let nearest;
          for (const entry of path) {
            const owner = rootOwners.get(entry);
            if (owner) {
              nearest = entry;
              break;
            }
          }
          if (!nearest && (native.target === global || native.target === target.ownerDocument)) {
            let node = target.ownerDocument.activeElement;
            while (node) {
              if (rootOwners.has(node)) {
                nearest = node;
                break;
              }
              node = node.parentNode;
            }
          }
          if (nearest) {
            if (!trigger)
              return rootOwners.get(nearest)?.identity === identity;
            if (!rootOwners.get(nearest)?.trigger())
              return false;
            const nearestOwner = rootOwners.get(nearest);
            for (const descendant of logicalOwners.values()) {
              if (descendant === nearestOwner || !descendant.trigger())
                continue;
              const visited2 = /* @__PURE__ */ new Set();
              let current3 = descendant;
              while (current3 && !visited2.has(current3.identity)) {
                visited2.add(current3.identity);
                const parent = current3.parent();
                current3 = parent ? logicalOwners.get(parent) : void 0;
                if (current3 === nearestOwner)
                  return false;
                if (current3 && !current3.trigger())
                  break;
              }
            }
            if (nearestOwner.identity === identity)
              return true;
            let current2 = nearestOwner;
            const visited = /* @__PURE__ */ new Set();
            while (current2 && !visited.has(current2.identity)) {
              visited.add(current2.identity);
              const parent = current2.parent();
              current2 = parent ? logicalOwners.get(parent) : void 0;
              if (current2) {
                if (!current2.trigger())
                  return false;
                if (current2.identity === identity)
                  return true;
              }
            }
            return false;
          }
          const hit = native.target;
          if (hit && target.contains(hit))
            return true;
          const activeElement = target.ownerDocument.activeElement;
          return (native.target === global || native.target === target.ownerDocument) && !!activeElement && target.contains(activeElement);
        };
        const epoch = generation, global = target.ownerDocument.defaultView ?? target.ownerDocument;
        const valid = () => deliverable(epoch, target);
        const rootEmit = (type, native) => emit("root", type, native, epoch, target);
        const globalEmit = (type, native) => emit("global", type, native, epoch, target);
        try {
          for (const registration of registrations) {
            if (!registration.active || !registration.type.startsWith("host:"))
              continue;
            const hostType = registration.type.slice(5);
            const where = registration.kind === "root" ? host : global;
            listen(where, hostType, (native) => {
              if (registration.active)
                options.invoke(() => registration.callback(options.getRun(), native));
            }, registration.options);
          }
          if (!focusDeclared && !registrations.some((entry) => !entry.type.startsWith("host:"))) {
            refresh2();
            return;
          }
          for (const [nativeName, semanticName] of [["pointerdown", "pointer.down"], ["pointermove", "pointer.move"], ["pointerup", "pointer.up"], ["pointercancel", "pointer.cancel"], ["pointerenter", "pointer.enter"], ["pointerleave", "pointer.leave"]]) {
            listen(target, nativeName, (native) => {
              if (!owns(native))
                return;
              rootEmit(semanticName, native);
              if (!valid())
                return;
              if (nativeName === "pointerdown") {
                keyboard = false;
                suppressKeyboardClick = false;
                if (!disabled && native.button === 0 && pointer === null) {
                  pointer = native.pointerId;
                  pointerCancelled = false;
                  rootEmit("press.start", native);
                }
              } else if ((nativeName === "pointercancel" || nativeName === "pointerleave") && pointer !== null) {
                pointerCancelled = true;
                rootEmit("press.cancel", native);
                pointer = null;
              } else if (nativeName === "pointerup" && pointer === native.pointerId) {
                rootEmit("press.end", native);
                pointer = null;
              }
            });
          }
          listen(global, "pointerup", (native) => {
            if (pointer === native.pointerId && !owns(native)) {
              rootEmit("press.cancel", native);
              pointer = null;
              pointerCancelled = true;
            }
          });
          listen(global, "pointercancel", (native) => {
            if (pointer === native.pointerId) {
              rootEmit("pointer.cancel", native);
              rootEmit("press.cancel", native);
              pointer = null;
              pointerCancelled = true;
            }
          });
          const handledKeys = /* @__PURE__ */ new WeakSet();
          for (const name of ["keydown", "keyup"]) {
            listen(global, name, (native) => {
              handledKeys.delete(native);
            }, { capture: true });
            listen(target, name, (native) => {
              handledKeys.delete(native);
            }, { capture: true });
          }
          const rootKeyDown = (native) => {
            if (!valid() || !owns(native))
              return;
            handledKeys.add(native);
            keyboard = true;
            rootEmit("key.down", native);
            if (native.key !== "Enter" && native.key !== " ") {
              suppressKeyboardClick = false;
              return;
            }
            if (disabled)
              return;
            if (pressKey === null) {
              pressKey = native.key;
              rootEmit("press.start", native);
            }
            if (!disabled) {
              suppressKeyboardClick = true;
              ++keyboardClickVersion;
              rootEmit("press.commit", native);
            }
          };
          const rootKeyUp = (native) => {
            if (!valid())
              return;
            if (native.key === "Enter" || native.key === " ") {
              const released = keyboardClickVersion;
              queueMicrotask(() => {
                if (valid() && released === keyboardClickVersion)
                  suppressKeyboardClick = false;
              });
            }
            handledKeys.add(native);
            if (owns(native))
              rootEmit("key.up", native);
            if (pressKey === native.key) {
              rootEmit("press.end", native);
              pressKey = null;
            }
          };
          listen(target, "keydown", rootKeyDown);
          listen(target, "keyup", rootKeyUp);
          listen(global, "keydown", (native) => {
            keyboard = true;
            globalEmit("key.down", native);
            if (native.key === "Enter" || native.key === " ") {
              if (globalPressKey === null) {
                globalPressKey = native.key;
                globalEmit("press.start", native);
              }
              suppressGlobalKeyboardClick = true;
              ++globalKeyboardClickVersion;
              globalEmit("press.commit", native);
            } else
              suppressGlobalKeyboardClick = false;
            if (!handledKeys.has(native))
              rootKeyDown(native);
          });
          listen(global, "keyup", (native) => {
            if (native.key === "Enter" || native.key === " ") {
              const released = globalKeyboardClickVersion;
              queueMicrotask(() => {
                if (valid() && released === globalKeyboardClickVersion)
                  suppressGlobalKeyboardClick = false;
              });
            }
            globalEmit("key.up", native);
            if (globalPressKey === native.key) {
              globalEmit("press.end", native);
              globalPressKey = null;
            }
            if (!handledKeys.has(native))
              rootKeyUp(native);
          });
          listen(target, "click", (native) => {
            if (!owns(native) || typeof native.clientX !== "number" || typeof native.button !== "number" || typeof native.detail !== "number")
              return;
            if (suppressKeyboardClick && native.detail === 0) {
              suppressKeyboardClick = false;
              return;
            }
            suppressKeyboardClick = false;
            if (pointerCancelled) {
              pointerCancelled = false;
              return;
            }
            if (!disabled && native.button === 0)
              rootEmit("press.commit", native);
          });
          for (const [name, semantic] of [["contextmenu", "context.menu"], ["input", "input"], ["change", "change"]])
            listen(target, name, (native) => {
              if (owns(native))
                rootEmit(semantic, native);
            });
          listen(target, "focus", (native) => {
            if (focusDeclared && disabled) {
              target.blur();
              return;
            }
            if (focusDeclared && !noteNativeFocusRequest())
              return;
            if (focusDeclared) {
              focused.set(true);
              focusVisible.set(keyboard);
            }
            rootEmit("nav.focus", native);
          });
          listen(target, "blur", (native) => {
            {
              focused.set(false);
              focusVisible.set(false);
            }
            if (pressKey !== null) {
              rootEmit("press.cancel", native);
              pressKey = null;
            }
            rootEmit("nav.blur", native);
          });
          listen(global, "blur", (native) => {
            if (pressKey !== null || pointer !== null)
              rootEmit("press.cancel", native);
            if (globalPressKey !== null || globalPointer !== null)
              globalEmit("press.cancel", native);
            pressKey = null;
            pointer = null;
            globalPressKey = null;
            globalPointer = null;
          });
          for (const [name, semantic] of [["pointerdown", "pointer.down"], ["pointermove", "pointer.move"], ["pointerup", "pointer.up"], ["pointercancel", "pointer.cancel"], ["pointerenter", "pointer.enter"], ["pointerleave", "pointer.leave"], ["contextmenu", "context.menu"], ["input", "input"], ["change", "change"], ["focus", "nav.focus"], ["blur", "nav.blur"]]) {
            const globalPress = name.startsWith("pointer") && registrations.some((entry) => entry.kind === "global" && entry.type.startsWith("press."));
            if (globalPress || registrations.some((entry) => entry.kind === "global" && entry.type === semantic))
              listen(global, name, (native) => {
                globalEmit(semantic, native);
                if (!globalPress)
                  return;
                const event = native;
                if (name === "pointerdown" && event.button === 0 && globalPointer === null) {
                  globalPointer = event.pointerId;
                  globalEmit("press.start", native);
                } else if (name === "pointerup" && globalPointer === event.pointerId) {
                  globalPointer = null;
                  globalEmit("press.end", native);
                } else if (name === "pointercancel" && globalPointer === event.pointerId) {
                  globalPointer = null;
                  globalEmit("press.cancel", native);
                }
              }, { capture: name === "pointerenter" || name === "pointerleave" });
          }
          listen(global, "click", (native) => {
            if (typeof native.clientX !== "number" || typeof native.button !== "number" || typeof native.detail !== "number" || native.button !== 0)
              return;
            if (suppressGlobalKeyboardClick && native.detail === 0) {
              suppressGlobalKeyboardClick = false;
              return;
            }
            suppressGlobalKeyboardClick = false;
            globalEmit("press.commit", native);
          });
          for (const [name, semantic] of [["focusin", "text.focus"], ["focusout", "text.blur"]]) {
            listen(target, name, (native) => {
              if (owns(native))
                rootEmit(semantic, native);
            });
            if (registrations.some((entry) => entry.kind === "global" && entry.type === semantic))
              listen(global, name, (native) => globalEmit(semantic, native));
          }
          refresh2();
          if (focusDeclared && !disabled && (!didAutoFocus && autoFocus || hasPendingFocus)) {
            didAutoFocus = true;
            if (deliverable(epoch, target)) {
              const request = hasPendingFocus ? pendingFocus : void 0;
              hasPendingFocus = false;
              options.invoke(() => focus.focusSelf(request));
            } else
              hasPendingFocus = true;
          }
          if (focusDeclared) {
            const activeFocus = !disabled && target.ownerDocument.activeElement === target;
            focused.set(activeFocus);
            focusVisible.set(activeFocus && keyboard);
          }
        } catch (error) {
          try {
            unmount();
          } catch {
          }
          throw error;
        }
      }
      refresh2();
    }
    const modules = createNativeAdapterModules({
      ensureSetup: options.ensureSetup,
      ensureRuntime: options.ensureRuntime,
      ensureEvent: options.ensureEvent,
      isAlive: () => !disposed && options.isAlive(),
      isSetupComplete: options.isSetupComplete,
      isReady: options.isReady,
      invoke: options.invoke,
      getRun: options.getRun,
      getResolvedProps: options.getResolvedProps,
      getRoot: options.getRoot,
      getHost: options.getHost,
      declarations: options.declarations ?? [],
      identity,
      getLogicalParent: options.getLogicalParent ?? (() => null),
      tableFamily: options.tableFamily,
      registerObservedState: options.registerGenericObservedState,
      getExposes: options.getExposes,
      setPresent: options.setPresent,
      requestHostUpdate: options.requestHostUpdate,
      emit: options.emit,
      createOwnedState: options.createOwnedState,
      watchState: options.watchState,
      isPropProvided: options.isPropProvided,
      getMeta: options.getMeta,
      registerExpose: options.registerExpose,
      baseFocus: () => focus,
      cancelPendingFocus() {
        {
          pendingFocus = void 0;
          hasPendingFocus = false;
        }
      },
      getAccessibleRole: () => role === void 0 ? null : read(role) || null,
      requestAttributeRefresh: refresh2,
      getAttributeBaseline: (name) => attributes.has(name) ? attributes.get(name).baseline : root?.getAttribute(name) ?? null,
      subscribeState: options.subscribeState
    });
    function combinedProjectAttributes() {
      const base = projectAttributes();
      const extended = modules.projectAttributes();
      return Object.freeze({ ...base, ...extended });
    }
    const accessible = Object.freeze({ ...accessibleBase, ...modules.accessible });
    const controlLabel = createNativeControlLabel({
      identity,
      ensureSetup: options.ensureSetup,
      isAlive: () => !disposed && options.isAlive(),
      isSetupComplete: options.isSetupComplete,
      isReady: options.isReady,
      getRoot: options.getRoot,
      getAssociations: options.getAssociations ?? (() => void 0),
      getRun: options.getRun,
      invoke: options.invoke,
      hasAuthoredName: () => modules.hasAuthoredControlLabelName(),
      beginNameProjection: () => modules.beginControlLabelName(),
      resolveAnatomy: (pair, kind) => modules.controlLabelAnatomyScope(pair, kind),
      subscribeAnatomy: (callback) => modules.subscribeControlLabelAnatomy(callback)
    });
    return {
      event: { on: (type, callback, hostOptions) => register2("root", type, callback, hostOptions), onGlobal: (type, callback, hostOptions) => register2("global", type, callback, hostOptions) },
      releaseListener(token) {
        options.ensureSetup("asHook.disposer");
        const registration = capturedListeners.get(token);
        if (!registration)
          throw new Error("[Event] listener token belongs to a different owner.");
        registration.active = false;
      },
      asTrigger() {
        options.ensureSetup("hook.asTrigger");
        trigger = true;
      },
      asFocusable() {
        options.ensureSetup("hook.asFocusable");
        if (!focusDeclared) {
          focusDeclared = true;
          focusable.set(!disabled);
          const register3 = options.registerGenericObservedState ?? options.registerObservedState;
          register3?.(focused.handle);
          register3?.(focusVisible.handle);
          register3?.(focusable.handle);
        }
        modules.configureFocusable({});
        return focus;
      },
      asAccessible() {
        options.ensureSetup("hook.asAccessible");
        return accessible;
      },
      asControlLabel() {
        options.ensureSetup("hook.asControlLabel");
        if (!controlLabel)
          throw new Error("[ControlLabel] undeclared native association channel");
        return controlLabel.facade;
      },
      anatomy: modules.anatomy,
      accessible: modules.accessible,
      configureFocusable: (config) => modules.configureFocusable(config),
      setNavParticipation: (value) => modules.setNavParticipation(value),
      setRovingStatus: (status) => modules.setRovingStatus(status),
      focus: (request) => modules.focus(request),
      blur: () => modules.blur(),
      rootTag: () => modules.rootTag(),
      rootProperties: () => modules.rootProperties(),
      portalTarget: () => modules.portalTarget(),
      commitHost: () => modules.commitHost(),
      projectAttributes: combinedProjectAttributes,
      adoptAttributes,
      refresh() {
        modules.refresh();
        refresh2();
        controlLabel?.refresh();
        if (hasPendingFocus && deliverable() && root.isConnected && !disabled) {
          const request = pendingFocus;
          hasPendingFocus = false;
          options.invoke(() => focus.focusSelf(request));
        }
      },
      mount() {
        mount();
        modules.mount();
        controlLabel?.mount();
      },
      unmount() {
        let failed = false, failure;
        const attempt = (cleanup) => {
          try {
            cleanup();
          } catch (error) {
            if (!failed) {
              failed = true;
              failure = error;
            }
          }
        };
        attempt(() => controlLabel?.unmount());
        attempt(() => modules.unmount());
        attempt(unmount);
        if (failed)
          throw failure;
      },
      dispose() {
        if (disposed)
          return;
        disposed = true;
        let failed = false, failure;
        const attempt = (cleanup) => {
          try {
            cleanup();
          } catch (error) {
            if (!failed) {
              failed = true;
              failure = error;
            }
          }
        };
        attempt(() => controlLabel?.dispose());
        attempt(() => modules.unmount());
        attempt(unmount);
        attempt(() => modules.dispose());
        for (const off of subscriptions.splice(0))
          attempt(off);
        registrations.length = 0;
        {
          states.clear();
          stateConditions.clear();
          actions.clear();
        }
        {
          nativeNotifications.length = 0;
          focused.clear();
          focusVisible.clear();
          focusable.clear();
          hasPendingFocus = false;
        }
        if (failed)
          throw failure;
      }
    };
  }

  // button-generated:.proto-ui/web-component/ssr-e6807d4f71af1465-v2.ts
  function assertNoInstanceAssociations(input, subject) {
    if (!input || typeof input !== "object")
      return;
    for (const key of ["instanceAssociations", "instance-associations", "instanceassociations"])
      if (Object.prototype.hasOwnProperty.call(input, key))
        throw new TypeError("[InstanceAssociations] " + subject + " cannot carry instance associations; SSR association transport is unsupported, use the dedicated client property");
  }
  var HydrationMismatch = class extends Error {
    constructor(reason, path = "Root", options) {
      super("WC hydration mismatch at " + path + ": " + reason, options);
      this.reason = reason;
      this.path = path;
      this.name = "HydrationMismatch";
    }
    code = "PUI_WC_HYDRATION_MISMATCH";
  };
  function isPresentation(value) {
    return !!value && typeof value === "object" && ["element", "text", "slot"].includes(value.kind);
  }
  function presentationChildren(input) {
    const result = [];
    function append(value) {
      if (value === null)
        return;
      if (Array.isArray(value)) {
        for (const child of value)
          append(child);
        return;
      }
      const node = typeof value === "string" || typeof value === "number" ? { kind: "text", text: String(value) } : value;
      if (!isPresentation(node))
        throw new TypeError("Invalid template child");
      if (node.kind === "text") {
        if (!node.text)
          return;
        const previous = result[result.length - 1];
        if (previous?.kind === "text") {
          previous.text += node.text;
          return;
        }
        result.push({ kind: "text", text: node.text });
      } else
        result.push(node);
    }
    append(input);
    return result;
  }
  function presentationElement(tag, style, children) {
    if (!/^[A-Za-z][A-Za-z0-9:_-]*$/.test(tag))
      throw new TypeError("Invalid template tag");
    return { kind: "element", tag: tag.toLowerCase(), ...style === void 0 ? {} : { style }, children: presentationChildren(children) };
  }
  function cloneInitialData(input) {
    const ancestors = /* @__PURE__ */ new Set();
    let nodes = 0, bytes = 0;
    const encoder = new TextEncoder();
    function fail(detail) {
      throw new TypeError("[Owner initialization] " + detail);
    }
    function text(value) {
      if (value.length > 1048576)
        fail("byte budget exceeded");
      bytes += encoder.encode(JSON.stringify(value)).length;
      if (bytes > 1048576)
        fail("byte budget exceeded");
    }
    function visit(value, depth) {
      if (depth > 64)
        fail("depth budget exceeded");
      if (++nodes > 1e4)
        fail("node budget exceeded");
      bytes += 32;
      if (bytes > 1048576)
        fail("byte budget exceeded");
      if (value === null || value === void 0 || typeof value === "boolean")
        return value;
      if (typeof value === "number") {
        if (!Number.isFinite(value))
          fail("numbers must be finite");
        return value;
      }
      if (typeof value === "string") {
        text(value);
        return value;
      }
      if (typeof value !== "object")
        fail("live capabilities are not data");
      if (ancestors.has(value))
        fail("cyclic data");
      const array = Array.isArray(value), prototype = Object.getPrototypeOf(value);
      if (array ? prototype !== Array.prototype : prototype !== Object.prototype && prototype !== null)
        fail("non-data prototype");
      const keys = Reflect.ownKeys(value);
      if (keys.length > 1e4)
        fail("node budget exceeded");
      if (array && (value.length > 1e4 || keys.length !== value.length + 1))
        fail("sparse or extended array");
      const copy = array ? [] : /* @__PURE__ */ Object.create(null);
      ancestors.add(value);
      try {
        for (const key of keys) {
          if (array && key === "length")
            continue;
          const field = Object.getOwnPropertyDescriptor(value, key);
          if (!field || typeof key !== "string" || !field.enumerable || !("value" in field))
            fail("accessor, symbol or nonenumerable field");
          if (array && (!/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= value.length))
            fail("extended array");
          text(key);
          Object.defineProperty(copy, key, { value: visit(field.value, depth + 1), enumerable: true });
        }
      } finally {
        ancestors.delete(value);
      }
      return Object.freeze(copy);
    }
    return visit(input, 0);
  }
  function decodeInitialData(input) {
    function invalid() {
      throw new TypeError("[Owner initialization] malformed data encoding");
    }
    function decode(value) {
      if (value === null || typeof value === "string" || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value))
        return value;
      if (!Array.isArray(value))
        return invalid();
      if (value.length === 1 && value[0] === "undefined")
        return void 0;
      if (value.length === 1 && value[0] === "negative-zero")
        return -0;
      if (value.length !== 2 || !Array.isArray(value[1]))
        return invalid();
      if (value[0] === "array")
        return Object.freeze(value[1].map(decode));
      if (value[0] !== "record")
        return invalid();
      const record = /* @__PURE__ */ Object.create(null);
      for (const entry of value[1]) {
        if (!Array.isArray(entry) || entry.length !== 2 || typeof entry[0] !== "string" || Object.hasOwn(record, entry[0]))
          return invalid();
        Object.defineProperty(record, entry[0], { value: decode(entry[1]), enumerable: true });
      }
      return Object.freeze(record);
    }
    return decode(cloneInitialData(input));
  }
  function checkData(value, seen = /* @__PURE__ */ new Set()) {
    if (!seen.size)
      value = cloneInitialData(value);
    if (value === null || typeof value === "string" || typeof value === "boolean")
      return;
    if (typeof value === "number" && Number.isFinite(value))
      return;
    if (typeof value !== "object" || seen.has(value))
      throw new TypeError("SSR transport requires finite acyclic JSON data");
    const array = Array.isArray(value), proto = Object.getPrototypeOf(value);
    if (array ? proto !== Array.prototype : proto !== Object.prototype && proto !== null)
      throw new TypeError("SSR transport rejects non-data objects");
    seen.add(value);
    try {
      if (array && Object.keys(value).length !== value.length)
        throw new TypeError("SSR transport rejects sparse arrays");
      for (const key of Reflect.ownKeys(value)) {
        if (array && key === "length")
          continue;
        const field = Object.getOwnPropertyDescriptor(value, key);
        if (typeof key !== "string" || !field.enumerable || !("value" in field))
          throw new TypeError("SSR transport rejects accessor/symbol fields");
        checkData(field.value, seen);
      }
    } finally {
      seen.delete(value);
    }
  }
  function encodeRaw(raw) {
    raw = cloneInitialData(raw);
    function encode(value, seen = /* @__PURE__ */ new Set()) {
      if (value === void 0)
        return ["undefined"];
      if (Object.is(value, -0))
        return ["negative-zero"];
      if (value === null || typeof value === "string" || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value))
        return value;
      if (!value || typeof value !== "object" || seen.has(value))
        throw new TypeError("Non-portable initial data");
      const array = Array.isArray(value), proto = Object.getPrototypeOf(value);
      if (array ? proto !== Array.prototype : proto !== Object.prototype && proto !== null)
        throw new TypeError("Capabilities cannot enter initial data");
      seen.add(value);
      try {
        if (array && Object.keys(value).length !== value.length)
          throw new TypeError("SSR transport rejects sparse arrays");
        for (const key of Reflect.ownKeys(value)) {
          if (array && key === "length")
            continue;
          const field = Object.getOwnPropertyDescriptor(value, key);
          if (typeof key !== "string" || !field.enumerable || !("value" in field))
            throw new TypeError("SSR transport rejects accessor/symbol fields");
        }
        return array ? ["array", value.map((item) => encode(item, seen))] : ["record", Object.entries(value).map(([key, item]) => [key, encode(item, seen)])];
      } finally {
        seen.delete(value);
      }
    }
    encode(raw);
    return Object.keys(raw).map((key) => [key, { kind: "value", value: encode(raw[key]) }]);
  }
  function decodeRaw(data) {
    data = cloneInitialData(data);
    const decode = decodeInitialData;
    const raw = /* @__PURE__ */ Object.create(null);
    for (const [key, value] of data) {
      if (["instanceAssociations", "instance-associations", "instanceassociations"].includes(key))
        throw new HydrationMismatch("instance associations cannot enter serialized Props");
      if (Object.hasOwn(raw, key))
        throw new HydrationMismatch("duplicate raw Prop key");
      raw[key] = value.kind === "undefined" ? void 0 : decode(value.value);
    }
    return raw;
  }
  function checkCarrier(carrier, binding, tag, artifacts) {
    try {
      checkData(carrier);
    } catch (cause) {
      throw new HydrationMismatch("carrier contains non-transport data", "Root", { cause });
    }
    try {
      assertNoInstanceAssociations(carrier, "Carrier");
      assertNoInstanceAssociations(carrier?.attributes, "Root attributes");
      assertNoInstanceAssociations(carrier?.baselines, "Root baselines");
    } catch {
      throw new HydrationMismatch("instance association carrier transport is unsupported");
    }
    if (!carrier || typeof carrier !== "object")
      throw new HydrationMismatch("invalid carrier");
    if (carrier.version !== 1 || carrier.profile !== "web-component-ssr-v1" || carrier.binding !== binding || carrier.tagName !== tag)
      throw new HydrationMismatch("source/profile/tag binding differs");
    if (!carrier.artifacts || artifacts && ["source", "helpers", "css", "environment"].some((key) => carrier.artifacts[key] !== artifacts[key]))
      throw new HydrationMismatch("source/helper/CSS artifact version differs");
    if (typeof carrier.instanceId !== "string" || !/^[a-z0-9-]+$/i.test(carrier.instanceId))
      throw new HydrationMismatch("invalid instance identity");
    if (!["light", "shadow"].includes(carrier.mode) || typeof carrier.present !== "boolean" || !Array.isArray(carrier.raw) || !Array.isArray(carrier.presentation))
      throw new HydrationMismatch("invalid carrier");
    for (const entry of carrier.raw) {
      if (!Array.isArray(entry) || entry.length !== 2 || typeof entry[0] !== "string" || !entry[1] || typeof entry[1] !== "object" || !["undefined", "value"].includes(entry[1].kind) || entry[1].kind === "value" && !Object.hasOwn(entry[1], "value"))
        throw new HydrationMismatch("invalid raw Prop entry");
    }
    for (const snapshot of [carrier.attributes, carrier.interactionAttributes, carrier.baselines]) {
      if (!snapshot || Array.isArray(snapshot) || typeof snapshot !== "object" || Object.values(snapshot).some((value) => value !== null && typeof value !== "string"))
        throw new HydrationMismatch("invalid Root attribute snapshot");
    }
    let slots = 0;
    function checkChildren(children) {
      for (const node of children) {
        if (!node || typeof node !== "object")
          throw new HydrationMismatch("invalid presentation node");
        if (node.kind === "slot") {
          if (++slots > 1)
            throw new HydrationMismatch("multiple slot projection");
        } else if (node.kind === "text") {
          if (typeof node.text !== "string")
            throw new HydrationMismatch("invalid text projection");
        } else if (node.kind === "element") {
          if (typeof node.tag !== "string" || !/^[a-z][a-z0-9:_-]*$/.test(node.tag) || node.style !== void 0 && typeof node.style !== "string" || !Array.isArray(node.children))
            throw new HydrationMismatch("invalid element projection");
          checkChildren(node.children);
        } else
          throw new HydrationMismatch("unknown presentation node");
      }
    }
    checkChildren(carrier.presentation);
    try {
      decodeRaw(carrier.raw);
    } catch (error) {
      if (error instanceof HydrationMismatch)
        throw error;
      throw new HydrationMismatch("invalid initial data encoding");
    }
  }
  function checkInitialProps(raw, carrier) {
    if (JSON.stringify(encodeRaw(raw)) !== JSON.stringify(carrier.raw))
      throw new HydrationMismatch("client initial props differ from server props");
  }
  function checkStylesheet(host, version, cssText, subject = "component") {
    if (!cssText)
      return;
    const styles = Array.from(host.ownerDocument.querySelectorAll("style[data-pui-ssr-css]"));
    if (!styles.some((style) => style.getAttribute("data-pui-ssr-css") === version && style.textContent === cssText))
      throw new HydrationMismatch("bound first-frame " + subject + " CSS artifact is absent or differs");
  }
  function marker(node, text) {
    return !!node && node.nodeType === 8 && node.nodeValue === text;
  }
  function carrierNode(host) {
    const nodes = Array.from(host.children).filter((node) => node.localName === "script" && node.hasAttribute("data-pui-carrier"));
    if (nodes.length > 1)
      throw new HydrationMismatch("multiple transport carriers");
    return nodes[0] ?? null;
  }
  function readCarrier(host) {
    const node = carrierNode(host);
    const marked = ["data-pui-ssr", "data-pui-instance", "data-pui-props"].some((name) => host.hasAttribute(name)) || Array.from(host.childNodes).some((node2) => marker(node2, "pui-root-start") || marker(node2, "pui-root-end"));
    if (!node) {
      if (marked)
        throw new HydrationMismatch("SSR-marked host is missing its carrier");
      return null;
    }
    if (node.getAttribute("type") !== "application/json")
      throw new HydrationMismatch("carrier script type differs");
    let parsed;
    try {
      parsed = JSON.parse(node.textContent ?? "");
    } catch {
      throw new HydrationMismatch("invalid carrier JSON");
    }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed))
      throw new HydrationMismatch("carrier must be an object");
    const carrier = parsed;
    if (node.getAttribute("data-pui-carrier") !== carrier.binding)
      throw new HydrationMismatch("carrier script binding differs");
    return carrier;
  }
  function checkCarrierHost(host, carrier) {
    if (host.getAttribute("data-pui-instance") !== carrier.instanceId || host.getAttribute("data-pui-ssr") !== carrier.binding)
      throw new HydrationMismatch("physical instance/source binding differs");
    if (host.getAttribute("data-pui-props") !== JSON.stringify(carrier.raw))
      throw new HydrationMismatch("physical initial props differ from carrier");
  }
  function logicalParent(host) {
    if (!host.isConnected)
      return null;
    let node = host;
    while (node) {
      const slot = node.nodeType === 1 ? node.assignedSlot : null;
      node = slot ?? (node.nodeType === 11 && "host" in node ? node.host : node.parentNode);
      if (node) {
        const scope = ownerScopes.get(node);
        if (scope)
          return scope;
      }
    }
    return null;
  }
  function pendingProviderDefinition(host) {
    let node = host;
    while (node) {
      const slot = node.nodeType === 1 ? node.assignedSlot : null;
      node = slot ?? (node.nodeType === 11 && "host" in node ? node.host : node.parentNode);
      if (node?.nodeType !== 1 || ownerScopes.has(node))
        continue;
      const parent = node;
      if (!parent.localName.includes("-") || !carrierNode(parent))
        continue;
      const registry = parent.ownerDocument.defaultView.customElements;
      if (!registry.get(parent.localName))
        return registry.whenDefined(parent.localName);
    }
    return null;
  }
  function createBrowserPort(host, mode, carrier, recovery) {
    const doc = host.ownerDocument;
    const initialAttributes = Array.from(host.attributes, (attribute) => [attribute.name, attribute.value]);
    const projectedAttributes = carrier?.control?.attributes ?? carrier?.attributes;
    const projectionBaselines = carrier?.control ? Object.fromEntries(Object.entries(carrier.control.properties).filter(([name, value]) => value !== null && value !== false && !(carrier.control.tag === "textarea" && name === "value")).map(([name, value]) => [name.toLowerCase(), value === true ? "" : String(value)])) : carrier?.baselines;
    let initialControlAttributes = null;
    if (carrier) {
      checkCarrierHost(host, carrier);
      if (Array.from(doc.querySelectorAll("[data-pui-instance]")).filter((node) => node.getAttribute("data-pui-instance") === carrier.instanceId).length > 1)
        throw new HydrationMismatch("duplicate instance identity");
      for (const [name, value] of Object.entries(carrier.attributes))
        if (host.getAttribute(name) !== value)
          throw new HydrationMismatch("Root attribute differs: " + name);
    }
    let root = host;
    if (recovery) {
      for (const node of Array.from(host.children))
        if (node.localName === "script" && node.hasAttribute("data-pui-carrier"))
          node.remove();
    }
    const script = carrierNode(host);
    if (carrier && mode === "light" && host.shadowRoot)
      throw new HydrationMismatch("light carrier has a physical Shadow Root");
    if (mode === "shadow") {
      if (host.shadowRoot)
        root = host.shadowRoot;
      else {
        const declarative = Array.from(host.children).find((node) => node.localName === "template" && node.getAttribute("shadowrootmode") === "open");
        if (carrier && !declarative)
          throw new HydrationMismatch("declarative Shadow Root is absent");
        root = host.attachShadow({ mode: "open" });
        if (declarative) {
          root.appendChild(declarative.content);
          declarative.remove();
        }
      }
    }
    let accepted = false, disposed = false, hydrating = !!carrier;
    let control = null;
    let portalAnchor = null, portalParent = null;
    const emissions = [];
    let owned = /* @__PURE__ */ new WeakSet(), projected = [], start = null, end = null;
    let rootStart = null, rootEnd = null;
    let observer = null;
    const attributes = /* @__PURE__ */ new Map();
    let display = null;
    if (carrier && !carrier.present) {
      const baseline = doc.createElement("div").style;
      baseline.cssText = carrier.baselines.style ?? "";
      display = { value: baseline.getPropertyValue("display"), priority: baseline.getPropertyPriority("display") };
    }
    let expected = null;
    function slotNodes() {
      if (!start || !end || start.parentNode !== end.parentNode)
        return [];
      const nodes = [];
      for (let node = start.nextSibling; node && node !== end; node = node.nextSibling)
        nodes.push(node);
      return nodes;
    }
    function matchList(parent, first, boundary, children, path, mark) {
      let current2 = first;
      for (let index = 0; index < children.length; ++index) {
        const expected2 = children[index], at = path + "/" + index;
        if (!current2 || current2 === boundary)
          throw new HydrationMismatch("missing physical node", at);
        if (expected2.kind === "slot" && mode === "light") {
          if (!marker(current2, "pui-slot-start"))
            throw new HydrationMismatch("light slot start differs", at);
          const slotStart = current2;
          let slotEnd = current2.nextSibling;
          while (slotEnd && slotEnd !== boundary && !marker(slotEnd, "pui-slot-end"))
            slotEnd = slotEnd.nextSibling;
          if (!marker(slotEnd, "pui-slot-end"))
            throw new HydrationMismatch("light slot end differs", at);
          if (mark) {
            start = slotStart;
            end = slotEnd;
            owned.add(start);
            owned.add(end);
            projected = slotNodes();
          }
          current2 = slotEnd.nextSibling;
          continue;
        }
        if (expected2.kind === "text") {
          if (current2.nodeType !== 3 || current2.nodeValue !== expected2.text)
            throw new HydrationMismatch("text differs", at);
        } else {
          const tag = expected2.kind === "slot" ? "slot" : expected2.tag;
          if (current2.nodeType !== 1 || current2.localName !== tag)
            throw new HydrationMismatch("element tag differs", at);
          const el = current2;
          if (expected2.kind === "element" && (el.getAttribute("data-pui-style") ?? void 0) !== expected2.style)
            throw new HydrationMismatch("template style differs", at);
          matchList(el, el.firstChild, null, expected2.kind === "slot" ? [] : expected2.children, at, mark);
        }
        if (mark)
          owned.add(current2);
        current2 = current2.nextSibling;
      }
      if (current2 !== boundary)
        throw new HydrationMismatch("unexpected physical node", path);
    }
    function locateRange() {
      if (mode !== "light")
        return;
      for (const node of Array.from(host.childNodes)) {
        if (marker(node, "pui-root-start")) {
          if (rootStart)
            throw new HydrationMismatch("duplicate Root marker");
          rootStart = node;
        }
        if (marker(node, "pui-root-end")) {
          if (rootEnd)
            throw new HydrationMismatch("duplicate Root marker");
          rootEnd = node;
        }
      }
      if (carrier && (!rootStart || !rootEnd))
        throw new HydrationMismatch("light Root ownership markers are absent");
    }
    function matchControl() {
      const candidate = mode === "light" ? rootStart.nextSibling : root.firstChild;
      if (candidate?.nodeType !== 1 || candidate.localName !== carrier.control.tag || candidate.nextSibling !== (mode === "light" ? rootEnd : null) || control && candidate !== control)
        throw new HydrationMismatch("physical control Root differs");
      for (const [name, value] of Object.entries(carrier.control.attributes))
        if (candidate.getAttribute(name) !== value)
          throw new HydrationMismatch("physical control attribute differs: " + name);
      return candidate;
    }
    locateRange();
    if (carrier) {
      if (carrier.control && carrier.present) {
        control = matchControl();
        owned.add(control);
        initialControlAttributes = Array.from(control.attributes, (attribute) => [attribute.name, attribute.value]);
      } else
        matchList(root, mode === "light" ? rootStart.nextSibling : root.firstChild, mode === "light" ? rootEnd : null, carrier.presentation, "Root", true);
      expected = carrier.presentation;
    }
    function pool() {
      const result = [...projected.filter((node) => !!node.parentNode)];
      if (mode === "light")
        for (const node of Array.from(host.childNodes)) {
          if (node === script || node === rootStart || node === rootEnd || owned.has(node))
            continue;
          result.push(node);
        }
      return [...new Set(result)];
    }
    function projectNewChildren() {
      if (!end?.parentNode || disposed)
        return;
      const inPlace = end.parentNode === host ? new Set(slotNodes()) : null;
      for (const node of Array.from(host.childNodes)) {
        if (node === script || node === rootStart || node === rootEnd || owned.has(node) || node === end || node === start)
          continue;
        if (inPlace?.has(node))
          continue;
        end.parentNode.insertBefore(node, end);
        if (!projected.includes(node))
          projected.push(node);
      }
      projected = projected.filter((node) => !!node.parentNode);
    }
    function observe() {
      if (mode !== "light" || !end)
        return;
      if (!observer) {
        observer = new doc.defaultView.MutationObserver(projectNewChildren);
        observer.observe(host, { childList: true, subtree: true });
      }
    }
    function materialize(parent, children, slotPool) {
      for (const child of children) {
        let node;
        if (child.kind === "slot" && mode === "light") {
          start = doc.createComment("pui-slot-start");
          end = doc.createComment("pui-slot-end");
          owned.add(start);
          owned.add(end);
          parent.appendChild(start);
          for (const external of slotPool)
            parent.appendChild(external);
          parent.appendChild(end);
          projected = slotPool;
          continue;
        }
        if (child.kind === "text")
          node = doc.createTextNode(child.text);
        else {
          const el = doc.createElement(child.kind === "slot" ? "slot" : child.tag);
          if (child.kind === "element") {
            if (child.style !== void 0)
              el.setAttribute("data-pui-style", child.style);
            materialize(el, child.children, slotPool);
          }
          node = el;
        }
        owned.add(node);
        parent.appendChild(node);
      }
    }
    function ownRootRange(first, last) {
      if (first.parentNode !== last.parentNode)
        throw new HydrationMismatch("owned range has different physical parents");
      for (let node = first; node; node = node.nextSibling) {
        owned.add(node);
        if (node === last)
          return;
      }
      throw new HydrationMismatch("owned range end is unreachable");
    }
    function removeOwned() {
      for (const node of Array.from(root.childNodes))
        if (mode === "shadow" || owned.has(node) || node === rootStart || node === rootEnd)
          node.parentNode?.removeChild(node);
      rootStart = null;
      rootEnd = null;
    }
    const port = {
      server: false,
      get isConnected() {
        return host.isConnected && !disposed;
      },
      host,
      get root() {
        return control ?? host;
      },
      validateInitial(snapshot) {
        if (!carrier)
          return;
        if (snapshot.present !== carrier.present)
          throw new HydrationMismatch("initial presence differs");
        for (const [name, value] of Object.entries(snapshot.attributes))
          if ((projectedAttributes?.[name] ?? null) !== value)
            throw new HydrationMismatch("fresh client attribute differs: " + name);
      },
      hydrationAttributes: carrier?.interactionAttributes,
      hydrationBaselines: projectionBaselines,
      createInteraction: createNativeInteraction,
      projectRoot(tag, properties, portal) {
        if (tag && !["input", "textarea", "img"].includes(tag))
          throw new Error("Unsupported physical Root tag");
        if (hydrating && (carrier?.control?.tag ?? null) !== tag)
          throw new HydrationMismatch("client physical Root differs from carrier");
        if (tag && !control) {
          control = doc.createElement(tag);
          control.setAttribute("part", tag === "img" ? "image" : "control");
          owned.add(control);
        }
        if (control && control.localName !== tag)
          throw new Error("Physical control declaration cannot change during an owner lifetime");
        if (control && !hydrating)
          for (const [name, value] of Object.entries(properties)) {
            if (name === "value") {
              if (!accepted)
                control.value = String(value ?? "");
              continue;
            }
            if (value === null || value === false)
              control.removeAttribute(name);
            else
              control.setAttribute(name, value === true ? "" : String(value));
          }
        if (portal) {
          if (!portalAnchor) {
            portalParent = logicalParent(host);
            portalAnchor = doc.createComment("pui-portal");
            host.parentNode?.insertBefore(portalAnchor, host);
          }
          if (host.parentNode !== portal)
            portal.appendChild(host);
        } else if (portalAnchor) {
          portalAnchor.parentNode?.insertBefore(host, portalAnchor);
          portalAnchor.remove();
          portalAnchor = null;
          portalParent = null;
        }
      },
      projectInteraction(snapshot) {
        for (const [key, value] of Object.entries(snapshot))
          port.attribute(key, value);
      },
      attribute(name, value) {
        let entry = attributes.get(name);
        const target = control ?? host;
        const current2 = target.getAttribute(name);
        if (!entry) {
          const projectedByServer = projectedAttributes && Object.hasOwn(projectedAttributes, name) && current2 === projectedAttributes[name];
          entry = { baseline: projectedByServer ? projectionBaselines?.[name] ?? null : current2, projected: current2 };
          attributes.set(name, entry);
        } else if (current2 !== entry.projected)
          entry.baseline = current2;
        if (current2 !== value) {
          if (value === null)
            target.removeAttribute(name);
          else
            target.setAttribute(name, value);
        }
        entry.projected = value;
      },
      commit(children) {
        if (disposed)
          throw new Error("Browser port is disposed");
        if (hydrating) {
          if (JSON.stringify(children) !== JSON.stringify(expected))
            throw new HydrationMismatch("fresh client presentation differs from server projection");
          if (control)
            matchControl();
          else
            matchList(root, mode === "light" ? rootStart.nextSibling : root.firstChild, mode === "light" ? rootEnd : null, children, "Root", false);
          hydrating = false;
          projectNewChildren();
          observe();
          return;
        }
        if (control) {
          if (children.length)
            throw new Error("[Template] physical control Root requires empty children");
          if (control.parentNode !== root)
            root.appendChild(control);
          return;
        }
        const slotPool = mode === "light" ? pool() : [];
        for (const node of slotPool)
          node.parentNode?.removeChild(node);
        observer?.disconnect();
        observer = null;
        removeOwned();
        owned = /* @__PURE__ */ new WeakSet();
        projected = [];
        start = null;
        end = null;
        const fragment = doc.createDocumentFragment();
        materialize(fragment, children, slotPool);
        root.appendChild(fragment);
        if (!start)
          for (const node of slotPool)
            host.appendChild(node);
        observe();
      },
      visible(present) {
        if (!present) {
          if (!display)
            display = { value: host.style.getPropertyValue("display"), priority: host.style.getPropertyPriority("display") };
          host.style.setProperty("display", "none", "important");
        } else if (display) {
          if (host.style.getPropertyValue("display") === "none" && host.style.getPropertyPriority("display") === "important") {
            if (display.value)
              host.style.setProperty("display", display.value, display.priority);
            else
              host.style.removeProperty("display");
          }
          display = null;
        }
      },
      clear() {
        if (!accepted && carrier)
          return;
        const slotPool = mode === "light" ? pool().filter((node) => node !== control) : [];
        for (const node of slotPool)
          node.parentNode?.removeChild(node);
        observer?.disconnect();
        observer = null;
        removeOwned();
        start = null;
        end = null;
        projected = [];
        for (const node of slotPool)
          host.appendChild(node);
      },
      emit(key, payload, options) {
        if (!accepted) {
          emissions.push({ key, payload, options });
          return;
        }
        host.dispatchEvent(markNativeExposeEvent(new doc.defaultView.CustomEvent(key, { detail: payload, bubbles: true, cancelable: true, ...options })));
      },
      parentContext: () => portalAnchor ? portalParent : logicalParent(host),
      bindContext(scope) {
        if (scope)
          ownerScopes.set(host, scope);
        else
          ownerScopes.delete(host);
      },
      accept() {
        if (hydrating && carrier?.present)
          throw new HydrationMismatch("present carrier was not adopted");
        accepted = true;
        if (script)
          script.remove();
        if (carrier && !carrier.present)
          hydrating = false;
        if (rootStart)
          owned.add(rootStart);
        if (rootEnd)
          owned.add(rootEnd);
        for (const emission of emissions.splice(0)) {
          if (disposed)
            break;
          port.emit(emission.key, emission.payload, emission.options);
        }
      },
      dispose() {
        if (disposed)
          return;
        disposed = true;
        emissions.length = 0;
        observer?.disconnect();
        observer = null;
        const target = control ?? host;
        for (const [name, entry] of attributes)
          if (target.getAttribute(name) === entry.projected) {
            if (entry.baseline === null)
              target.removeAttribute(name);
            else
              target.setAttribute(name, entry.baseline);
          }
        attributes.clear();
        ownerScopes.delete(host);
        if (portalAnchor) {
          portalAnchor.parentNode?.insertBefore(host, portalAnchor);
          portalAnchor.remove();
          portalAnchor = null;
        }
        if (display) {
          if (display.value)
            host.style.setProperty("display", display.value, display.priority);
          else
            host.style.removeProperty("display");
          display = null;
        }
        if (carrier && !accepted) {
          for (const attribute of Array.from(host.attributes))
            host.removeAttribute(attribute.name);
          for (const [name, value] of initialAttributes)
            host.setAttribute(name, value);
          if (control && initialControlAttributes) {
            for (const attribute of Array.from(control.attributes))
              control.removeAttribute(attribute.name);
            for (const [name, value] of initialControlAttributes)
              control.setAttribute(name, value);
          }
        }
      }
    };
    if (recovery) {
      if (mode === "light") {
        const walker = doc.createTreeWalker(host, 128);
        for (let node = walker.nextNode(); node; node = walker.nextNode()) {
          if (marker(node, "pui-slot-start") && !start)
            start = node;
          else if (marker(node, "pui-slot-end") && start && node.parentNode === start.parentNode && !end)
            end = node;
        }
        projected = slotNodes();
      }
      if (rootStart && rootEnd)
        ownRootRange(rootStart, rootEnd);
      else if (mode === "shadow")
        for (const node of Array.from(root.childNodes))
          owned.add(node);
    }
    return port;
  }

  // button-generated:Component.ts
  var hydrationBinding = "3d40a88e88020aaa8dc00bd1a6c3c02716cadcd17d0f24efaeb141d18d6f2fe8";
  var defaultTagName = "pui-ssr-button";
  var hydrationArtifacts = { "source": "ac49119c91d1f3aa3bba0c6dbbf965f6e86af2bde62a15493939c847d30e2508", "helpers": "ba5ae9c7a9c2e09433c8685e1c34c13c9aff6bb6290f9ad0398ec168203ab417", "css": "a5d1a92362e8beb38aef891211ba9d8ff42cb3c3b2d61543687ad0f30d3bc487", "environment": "2244fb29befc3028cfc5e2e5811c2a406db502417eacf07ba5233ef3970bdd28" };
  var hydrationCssText = '/* This file is auto-generated by @proto.ui/cli (proto-ui tokens). */\n/* Do not edit by hand. */\n\n@layer proto-ui {\n  :where([data-pui-style]),\n  :where([data-pui-style])::before,\n  :where([data-pui-style])::after {\n    box-sizing: border-box;\n  }\n\n  :where([data-pui-style]) {\n    --pui-ring-offset-shadow: initial;\n    --pui-ring-shadow: initial;\n    --pui-shadow: initial;\n    --pui-ring-inset: initial;\n    --pui-ring-width: initial;\n    --pui-ring-offset-width: initial;\n    --pui-ring-color: initial;\n    --pui-ring-offset-color: initial;\n    --pui-translate-x: initial;\n    --pui-translate-y: initial;\n    --pui-scale-x: initial;\n    --pui-scale-y: initial;\n  }\n\n  :where(button[data-pui-style], input[data-pui-style], select[data-pui-style], textarea[data-pui-style]) {\n    font: inherit;\n    font-feature-settings: inherit;\n    font-variation-settings: inherit;\n    letter-spacing: inherit;\n    color: inherit;\n    margin: 0;\n    padding: 0;\n    border: 0;\n    background: transparent;\n    opacity: 1;\n  }\n\n  :where([data-pui-style~="bg-white"]) {\n    background-color: #fff;\n  }\n\n  :where([data-pui-style~="border"]) {\n    border-width: 1px;\n    border-style: solid;\n  }\n\n  :where([data-pui-style~="border-black"]) {\n    border-color: #000;\n  }\n\n  :where([data-pui-style~="inline-flex"]) {\n    display: inline-flex;\n  }\n\n  :where([data-pui-style~="items-center"]) {\n    align-items: center;\n  }\n\n  :where([data-pui-style~="justify-center"]) {\n    justify-content: center;\n  }\n\n  :where([data-pui-style~="opacity-50"]) {\n    opacity: 0.5;\n  }\n\n  :where([data-pui-style~="px-4"]) {\n    padding-inline: 1rem;\n  }\n\n  :where([data-pui-style~="py-2"]) {\n    padding-block: 0.5rem;\n  }\n\n  :where([data-pui-style~="rounded-md"]) {\n    border-radius: var(--pui-radius-md);\n  }\n\n  :where([data-pui-style~="select-none"]) {\n    -webkit-user-select: none;\n    user-select: none;\n  }\n\n  :where([data-pui-style~="select-text"]) {\n    -webkit-user-select: text;\n    user-select: text;\n  }\n\n  :where([data-pui-style~="text-foreground"]) {\n    color: var(--pui-foreground);\n  }\n\n  :where([data-pui-style~="text-sm"]) {\n    font-size: 0.875rem;\n    line-height: 1.25rem;\n  }\n\n  :where([data-pui-style~="leading-normal"]) {\n    line-height: 1.5;\n  }\n\n}\n';
  var hydrationEnvironmentCssText = "@layer theme, proto-ui;\n@layer theme {\n:root {\n    --pui-radius: 0.625rem;\n    --pui-radius-2xl: calc(var(--pui-radius) + 8px);\n    --pui-radius-3xl: calc(var(--pui-radius) + 12px);\n    --pui-radius-4xl: calc(var(--pui-radius) + 16px);\n    --pui-radius-xl: calc(var(--pui-radius) + 4px);\n    --pui-radius-lg: var(--pui-radius);\n    --pui-radius-md: max(calc(var(--pui-radius) - 2px), 0px);\n    --pui-radius-sm: max(calc(var(--pui-radius) - 4px), 0px);\n    --pui-background: lab(100% 0 0);\n    --pui-foreground: lab(2.75381% 0 0);\n    --pui-card: lab(100% 0 0);\n    --pui-card-foreground: lab(2.75381% 0 0);\n    --pui-popover: lab(100% 0 0);\n    --pui-popover-foreground: lab(2.75381% 0 0);\n    --pui-primary: lab(7.78201% -0.0000149012 0);\n    --pui-primary-foreground: lab(98.26% 0 0);\n    --pui-secondary: lab(96.52% -0.0000298023 0.0000119209);\n    --pui-secondary-foreground: lab(7.78201% -0.0000149012 0);\n    --pui-muted: lab(96.52% -0.0000298023 0.0000119209);\n    --pui-muted-foreground: lab(48.496% 0 0);\n    --pui-accent: lab(96.52% -0.0000298023 0.0000119209);\n    --pui-accent-foreground: lab(7.78201% -0.0000149012 0);\n    --pui-destructive: lab(48.4493% 77.4328 61.5452);\n    --pui-destructive-foreground: lab(96.4152% 3.22586 1.14673);\n    --pui-border: lab(90.952% 0 -0.0000119209);\n    --pui-input: lab(90.952% 0 -0.0000119209);\n    --pui-ring: lab(66.128% -0.0000298023 0.0000119209);\n    --pui-chart-1: #93c5fd;\n    --pui-chart-2: #3b82f6;\n    --pui-chart-3: #2563eb;\n    --pui-chart-4: #1d4ed8;\n    --pui-chart-5: #1e40af;\n    --pui-sidebar: lab(98.26% 0 0);\n    --pui-sidebar-foreground: lab(2.75381% 0 0);\n    --pui-sidebar-primary: lab(7.78201% -0.0000149012 0);\n    --pui-sidebar-primary-foreground: lab(98.26% 0 0);\n    --pui-sidebar-accent: lab(96.52% -0.0000298023 0.0000119209);\n    --pui-sidebar-accent-foreground: lab(7.78201% -0.0000149012 0);\n    --pui-sidebar-border: lab(90.952% 0 -0.0000119209);\n    --pui-sidebar-ring: lab(66.128% -0.0000298023 0.0000119209);\n    --pui-surface: lab(97.68% -0.0000298023 0.0000119209);\n    --pui-surface-foreground: var(--pui-foreground);\n    --pui-code: var(--pui-surface);\n    --pui-code-foreground: var(--pui-surface-foreground);\n    --pui-code-highlight: lab(95.36% 0 0);\n    --pui-code-number: lab(48.96% 0 0);\n    --pui-selection: lab(2.75381% 0 0);\n    --pui-selection-foreground: lab(100% 0 0);\n  }\n  \n  :root.dark,\n  :root[data-theme='dark'] {\n    --pui-background: lab(2.75381% 0 0);\n    --pui-foreground: lab(98.26% 0 0);\n    --pui-card: lab(7.78201% -0.0000149012 0);\n    --pui-card-foreground: lab(98.26% 0 0);\n    --pui-popover: lab(7.78201% -0.0000149012 0);\n    --pui-popover-foreground: lab(98.26% 0 0);\n    --pui-primary: lab(90.952% 0 -0.0000119209);\n    --pui-primary-foreground: lab(7.78201% -0.0000149012 0);\n    --pui-secondary: lab(15.204% 0 -0.00000596046);\n    --pui-secondary-foreground: lab(98.26% 0 0);\n    --pui-muted: lab(15.204% 0 -0.00000596046);\n    --pui-muted-foreground: lab(66.128% -0.0000298023 0.0000119209);\n    --pui-accent: lab(27.036% 0 0);\n    --pui-accent-foreground: lab(98.26% 0 0);\n    --pui-destructive: lab(63.7053% 60.745 31.3109);\n    --pui-destructive-foreground: lab(49.0747% 69.3434 49.6251);\n    --pui-border: lab(100% 0 0 / 0.1);\n    --pui-input: lab(100% 0 0 / 0.15);\n    --pui-ring: lab(48.496% 0 0);\n    --pui-chart-1: #93c5fd;\n    --pui-chart-2: #3b82f6;\n    --pui-chart-3: #2563eb;\n    --pui-chart-4: #1d4ed8;\n    --pui-chart-5: #1e40af;\n    --pui-sidebar: lab(7.78201% -0.0000149012 0);\n    --pui-sidebar-foreground: lab(98.26% 0 0);\n    --pui-sidebar-primary: lab(36.9089% 35.0961 -85.6872);\n    --pui-sidebar-primary-foreground: lab(98.26% 0 0);\n    --pui-sidebar-accent: lab(15.204% 0 -0.00000596046);\n    --pui-sidebar-accent-foreground: lab(98.26% 0 0);\n    --pui-sidebar-border: lab(100% 0 0 / 0.1);\n    --pui-sidebar-ring: lab(34.924% 0 0);\n    --pui-surface: lab(7.22637% -0.0000149012 0);\n    --pui-surface-foreground: lab(66.128% -0.0000298023 0.0000119209);\n    --pui-code: var(--pui-surface);\n    --pui-code-foreground: var(--pui-surface-foreground);\n    --pui-code-highlight: lab(15.32% 0 0);\n    --pui-code-number: lab(67.52% -0.0000298023 0);\n    --pui-selection: lab(90.952% 0 -0.0000119209);\n    --pui-selection-foreground: lab(7.78201% 0 0);\n  }\n\n@media (prefers-color-scheme: dark) {\n  :root:not(.dark):not(.light):not([data-theme='dark']):not([data-theme='light']) {\n    --pui-background: lab(2.75381% 0 0);\n    --pui-foreground: lab(98.26% 0 0);\n    --pui-card: lab(7.78201% -0.0000149012 0);\n    --pui-card-foreground: lab(98.26% 0 0);\n    --pui-popover: lab(7.78201% -0.0000149012 0);\n    --pui-popover-foreground: lab(98.26% 0 0);\n    --pui-primary: lab(90.952% 0 -0.0000119209);\n    --pui-primary-foreground: lab(7.78201% -0.0000149012 0);\n    --pui-secondary: lab(15.204% 0 -0.00000596046);\n    --pui-secondary-foreground: lab(98.26% 0 0);\n    --pui-muted: lab(15.204% 0 -0.00000596046);\n    --pui-muted-foreground: lab(66.128% -0.0000298023 0.0000119209);\n    --pui-accent: lab(27.036% 0 0);\n    --pui-accent-foreground: lab(98.26% 0 0);\n    --pui-destructive: lab(63.7053% 60.745 31.3109);\n    --pui-destructive-foreground: lab(49.0747% 69.3434 49.6251);\n    --pui-border: lab(100% 0 0 / 0.1);\n    --pui-input: lab(100% 0 0 / 0.15);\n    --pui-ring: lab(48.496% 0 0);\n    --pui-chart-1: #93c5fd;\n    --pui-chart-2: #3b82f6;\n    --pui-chart-3: #2563eb;\n    --pui-chart-4: #1d4ed8;\n    --pui-chart-5: #1e40af;\n    --pui-sidebar: lab(7.78201% -0.0000149012 0);\n    --pui-sidebar-foreground: lab(98.26% 0 0);\n    --pui-sidebar-primary: lab(36.9089% 35.0961 -85.6872);\n    --pui-sidebar-primary-foreground: lab(98.26% 0 0);\n    --pui-sidebar-accent: lab(15.204% 0 -0.00000596046);\n    --pui-sidebar-accent-foreground: lab(98.26% 0 0);\n    --pui-sidebar-border: lab(100% 0 0 / 0.1);\n    --pui-sidebar-ring: lab(34.924% 0 0);\n    --pui-surface: lab(7.22637% -0.0000149012 0);\n    --pui-surface-foreground: lab(66.128% -0.0000298023 0.0000119209);\n    --pui-code: var(--pui-surface);\n    --pui-code-foreground: var(--pui-surface-foreground);\n    --pui-code-highlight: lab(15.32% 0 0);\n    --pui-code-number: lab(67.52% -0.0000298023 0);\n    --pui-selection: lab(90.952% 0 -0.0000119209);\n    --pui-selection-foreground: lab(7.78201% 0 0);\n  }\n}\n}\n";
  var __wcPropTypes = { "disabled": "boolean" };
  function __wcCreateOwner(host, getAssociations) {
    let alive = true, disposing = false, setup = true, callbackDepth = 0;
    let currentRun;
    const observedProjections = /* @__PURE__ */ new Map();
    const observedSubscriptions = [];
    let intent = true, view = false, epoch = 0, queued = false, dirty = false, hostScheduled = false;
    let propsWindow = null;
    let resolved = Object.freeze({}), raw = Object.freeze({}), hydrated = false;
    const specs = /* @__PURE__ */ Object.create(null), previous = /* @__PURE__ */ Object.create(null), defaults = [];
    const watchers = [], states = [], emissions = [];
    let emitting = false;
    const exposes = /* @__PURE__ */ Object.create(null), events = /* @__PURE__ */ new Set();
    const lifecycle = { created: [], mounted: [], updated: [], unmounted: [], beforeDispose: [] };
    const own = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);
    const ensure = () => {
      if (!alive) throw new Error("Logical owner is disposed");
    };
    const ensureExternal = () => {
      ensure();
      if (disposing) throw new Error("Logical owner is disposing");
    };
    const ensureSetup = () => {
      ensure();
      if (!setup) throw new Error("Setup capability is closed");
    };
    const runtime = () => {
      ensure();
      if (setup || !callbackDepth) throw new Error("State writes require a live callback scope");
    };
    const __wcAuthoredWatchCleanups = [];
    const __wcAuthored = createNativeAuthoredHooks({ setup: ensureSetup, borrow(value) {
      const state2 = value;
      const borrowed = Object.freeze({ get: () => state2.get(), setDefault: (value2) => state2.setDefault(value2), set: (value2, reason) => state2.set(value2, reason), watch(callback) {
        ensureSetup();
        const off = state2.external.subscribe((event) => {
          invoke(callback, [event]);
        });
        __wcAuthoredWatchCleanups.push(off);
        return off;
      } });
      return borrowed;
    } });
    const context = createContextScope({
      getParent: () => host.parentContext(),
      isAlive: () => alive,
      invoke: (callback) => invoke(callback, [], false),
      validate: (key, value) => false
    });
    const __wcStyle = createNativeStyle({
      ensureSetup,
      ensureRuntime: runtime,
      isAlive: () => alive,
      project(tokens) {
        host.attribute("data-pui-style", tokens.length ? tokens.join(" ") : null);
      }
    });
    const __wcInteraction = host.createInteraction({
      ensureSetup,
      ensureRuntime: runtime,
      ensureEvent: runtime,
      isAlive: () => alive,
      isSetupComplete: () => !setup,
      isReady: () => !setup && view && intent && !disposing && host.isConnected,
      invoke: (callback) => invoke(callback, [], false),
      getRun() {
        ensure();
        if (!currentRun) throw new Error("Interaction requires a live callback scope");
        return currentRun;
      },
      getResolvedProps: () => resolved,
      getAssociations,
      getRoot: () => view && !disposing && !host.server ? host.root : null,
      getHost: () => host.host,
      identity: context,
      getLogicalParent: () => host.parentContext(),
      declarations: [],
      tableFamily: void 0,
      getExposes: () => alive && !disposing ? exposes : {},
      registerExpose(key, value) {
        if (value && typeof value === "object" && "external" in value) expose(key, value.external);
        else if (typeof value === "function") expose(key, (...args) => {
          ensureExternal();
          return invoke(value, args, false);
        });
        else expose(key, value);
      },
      createOwnedState: (name, value, spec) => state(spec?.kind ?? (typeof value === "boolean" ? "bool" : typeof value === "number" ? "number.discrete" : "string"), name, value, spec),
      watchState(handle, fn) {
        ensureSetup();
        const external = "external" in handle ? handle.external : observedProjections.get(handle)?.external;
        if (!external) throw new Error("Unknown owner State watch target");
        const off = external.subscribe((event) => invoke(fn, [event]));
        observedSubscriptions.push(off);
        return off;
      },
      subscribeState(handle, callback) {
        const source = "external" in handle ? handle.external : handle;
        return source.subscribe(callback);
      },
      isPropProvided: (key) => own(raw, key),
      emit: (key) => {
        runtime();
        currentRun.expose.emit(key);
      },
      setPresent: (value) => {
        runtime();
        if (disposing) throw new Error("Terminal presence is locked");
        intent = value;
        schedule(false);
      },
      requestHostUpdate() {
        if (hostScheduled || disposing) return;
        hostScheduled = true;
        queueMicrotask(() => {
          hostScheduled = false;
          if (alive && !disposing && view) projectHost();
        });
      },
      registerGenericObservedState(handle) {
        if (observedProjections.has(handle)) return;
        const subscribers = /* @__PURE__ */ new Set();
        const external = Object.freeze({
          get() {
            ensureExternal();
            return handle.get();
          },
          spec: Object.freeze({ kind: typeof handle.get() === "boolean" ? "bool" : typeof handle.get() === "number" ? "number.discrete" : "string" }),
          subscribe(fn) {
            ensureExternal();
            const registration = (event) => fn(event);
            subscribers.add(registration);
            return () => {
              subscribers.delete(registration);
            };
          },
          unsubscribe(off) {
            ensureExternal();
            off();
          }
        });
        observedProjections.set(handle, { external, subscribers });
        observedSubscriptions.push(handle.subscribe((event) => {
          __wcStyle.refresh();
          __wcInteraction.refresh();
          for (const subscriber of Array.from(subscribers)) {
            Object.defineProperty(emissions, emissions.length, { value: () => {
              if (alive && !disposing && subscribers.has(subscriber)) {
                invoke(subscriber, [event], false);
              }
            }, writable: true, enumerable: true, configurable: true });
          }
          drainEmissions();
        }));
      }
    });
    let ownerRun;
    function getRunHandle() {
      if (ownerRun) return ownerRun;
      const check = () => runtime();
      return ownerRun = {
        host: { get() {
          check();
          return view && !disposing ? host.root : null;
        } },
        feedback: { style: __wcStyle },
        context: Object.freeze({
          read(key) {
            check();
            return context.read(key);
          },
          tryRead(key) {
            check();
            return context.tryRead(key);
          },
          tryReadAncestor(key) {
            check();
            return context.tryReadAncestor(key);
          },
          update(key, next) {
            check();
            runtime();
            context.update(key, next);
          },
          tryUpdate(key, next) {
            check();
            runtime();
            return context.tryUpdate(key, next);
          }
        }),
        update() {
          check();
          if (!disposing) schedule(true);
        },
        props: Object.freeze({ get() {
          check();
          return propsWindow?.resolved ?? resolved;
        }, getRaw() {
          check();
          return propsWindow?.raw ?? raw;
        }, isProvided(key) {
          check();
          return own(propsWindow?.raw ?? raw, key);
        } }),
        lifecycle: { setPresent(next) {
          check();
          if (disposing) throw new Error("Terminal presence is locked");
          if (typeof next !== "boolean") throw new TypeError("View presence must be boolean");
          intent = next;
          schedule(false);
        } },
        expose: { emit(key, payload, options) {
          check();
          if (!events.has(key)) throw new Error("Undeclared exposed event: " + key);
          host.emit(key, payload, options);
        } }
      };
    }
    function invoke(fn, args = [], withRun = true) {
      ensure();
      const run = getRunHandle();
      const previousRun = currentRun;
      currentRun = run;
      ++callbackDepth;
      try {
        return fn(...withRun ? [run, ...args] : args);
      } finally {
        --callbackDepth;
        currentRun = previousRun;
      }
    }
    ownerScopes.set(host, context);
    host.bindContext(context);
    const contextRead = Object.freeze({
      read(key) {
        ensure();
        if (setup) throw new Error("Context reads require runtime scope");
        return context.read(key);
      },
      tryRead(key) {
        ensure();
        if (setup) throw new Error("Context reads require runtime scope");
        return context.tryRead(key);
      }
    });
    function fire(name) {
      if (name === "unmounted") {
      }
      try {
        for (const fn of lifecycle[name]) invoke(fn);
      } finally {
        if (name === "unmounted") {
        }
      }
    }
    function valid(spec, value) {
      if (spec.schema === void 0) throw new Error("Missing checked Props schema");
      if (!acceptsContextValue(spec.schema, value) || spec.options && !spec.options.includes(value) || spec.range && !(typeof value === "number" && value >= (spec.range.min ?? -Infinity) && value <= (spec.range.max ?? Infinity))) return false;
      try {
        return spec.validator ? !!spec.validator(value) : true;
      } catch {
        return false;
      }
    }
    function resolve2(strict) {
      const next = /* @__PURE__ */ Object.create(null);
      for (const key of Object.keys(specs)) {
        const spec = specs[key], provided = own(raw, key), value = raw[key];
        const requireValue = strict && spec.empty === "error";
        if (provided && value != null && valid(spec, value)) {
          next[key] = value;
          previous[key] = value;
          continue;
        }
        if (provided && value == null && spec.empty === "accept") {
          next[key] = null;
          continue;
        }
        let candidate;
        if (provided && own(previous, key) && valid(spec, previous[key])) candidate = previous[key];
        if (candidate === void 0) for (const layer of defaults) {
          if (!own(layer, key)) continue;
          const value2 = layer[key];
          if (value2 === null && !requireValue || value2 != null && valid(spec, value2)) {
            candidate = value2;
            break;
          }
        }
        if (candidate === void 0 && own(spec, "default")) {
          const value2 = spec.default;
          if (value2 === null && !requireValue || value2 != null && valid(spec, value2)) candidate = value2;
        }
        if (candidate === void 0) {
          if (requireValue) throw new Error("Prop has no valid fallback: " + key);
          candidate = null;
        }
        next[key] = candidate;
        if (provided && next[key] != null) previous[key] = next[key];
      }
      return Object.freeze(next);
    }
    function hydrate2(input) {
      ensure();
      const prev = resolved, previousRaw = raw;
      raw = Object.freeze({ ...input });
      resolved = resolve2(true);
      __wcStyle.refresh();
      __wcInteraction.refresh();
      if (!hydrated) {
        hydrated = true;
        return;
      }
      const changed = Object.keys(specs).filter((key) => !Object.is(prev[key], resolved[key]));
      const rawChanged = watchers.some((watcher) => watcher.raw && watcher.active) ? [.../* @__PURE__ */ new Set([...Object.keys(previousRaw), ...Object.keys(raw)])].filter((key) => !Object.is(previousRaw[key], raw[key])) : changed;
      const next = resolved, nextRaw = raw;
      const previousWindow = propsWindow;
      propsWindow = { raw: nextRaw, resolved: next };
      try {
        for (let group = 0; group < 3; ++group) for (const watcher of [...watchers]) {
          if ((watcher.raw ? watcher.keys === null ? 0 : 1 : 2) !== group) continue;
          const all = watcher.raw ? rawChanged : changed;
          const matched = watcher.keys === null ? all : all.filter((key) => watcher.keys.includes(key));
          if (watcher.active && matched.length) {
            if (watcher.raw) console.warn("[Props] raw watchers are an adapter-snapshot escape hatch; avoid in official prototypes.");
            invoke(watcher.fn, [watcher.raw ? nextRaw : next, watcher.raw ? previousRaw : prev, { changedKeysAll: all, changedKeysMatched: matched }]);
          }
        }
      } finally {
        propsWindow = previousWindow;
      }
    }
    function drainEmissions() {
      if (!emitting) {
        emitting = true;
        const notificationFailures = [];
        let notificationIndex = 0;
        try {
          while (notificationIndex < emissions.length && (alive && !disposing)) {
            try {
              emissions[notificationIndex++]();
            } catch (error) {
              Object.defineProperty(notificationFailures, notificationFailures.length, { value: error, writable: true, enumerable: true, configurable: true });
            }
          }
        } finally {
          emissions.length = 0;
          emitting = false;
        }
        if (notificationFailures.length === 1) throw notificationFailures[0];
        if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, "[State] subscriber failures");
      }
    }
    function state(kind, semantic, initial, options = {}) {
      ensureSetup();
      __wcAuthored.claimState(semantic);
      if (typeof semantic !== "string" || semantic.length === 0) throw new Error("Invalid state semantic");
      const spec = Object.freeze({ ...options, kind });
      function validate2(value2) {
        const type = kind === "bool" ? "boolean" : kind === "string" || kind === "enum" ? "string" : "number";
        if (typeof value2 !== type || type === "number" && Number.isNaN(value2)) throw new Error("Invalid state value");
        if (options.options?.length && !options.options.includes(value2)) throw new Error("State value outside options");
        if (kind === "number.range" || kind === "number.discrete" && !options.options?.length) {
          const numeric = typeof value2 === "number" ? value2 : NaN;
          if (numeric < (options.min ?? -Infinity) || numeric > (options.max ?? Infinity)) throw new Error("State value outside range");
          if (kind === "number.discrete" && options.step !== void 0 && options.step > 0 && !Number.isInteger((numeric - (options.min ?? 0)) / options.step)) throw new Error("State value violates step");
        }
      }
      if (kind === "number.range" && options.clamp) initial = Math.max(options.min ?? -Infinity, Math.min(options.max ?? Infinity, initial));
      validate2(initial);
      let value = initial;
      const subscribers = /* @__PURE__ */ new Set();
      const external = Object.freeze({
        get() {
          ensureExternal();
          return value;
        },
        spec,
        subscribe(fn) {
          ensureExternal();
          const registration = (event) => fn(event);
          subscribers.add(registration);
          return () => subscribers.delete(registration);
        },
        unsubscribe(off) {
          ensureExternal();
          off();
        }
      });
      const handle = {
        external,
        subscribers,
        get() {
          ensure();
          return value;
        },
        setDefault(next) {
          ensureSetup();
          validate2(next);
          value = next;
        },
        set(next, reason) {
          runtime();
          validate2(next);
          if (Object.is(value, next)) return;
          const prev = value;
          value = next;
          __wcStyle.refresh();
          __wcInteraction.refresh();
          for (const subscriber of Array.from(subscribers)) {
            Object.defineProperty(emissions, emissions.length, { value: () => {
              if (alive && !disposing && subscribers.has(subscriber)) {
                invoke(subscriber, [{ type: "next", prev, next, reason }], false);
              }
            }, writable: true, enumerable: true, configurable: true });
          }
          drainEmissions();
        }
      };
      states.push(handle);
      __wcAuthored.state(semantic, handle);
      return handle;
    }
    function element(tag, a, b) {
      const props = arguments.length > 2 ? a : a != null && typeof a === "object" && !Array.isArray(a) && !isPresentation(a) ? a : void 0;
      const children = arguments.length === 1 ? null : arguments.length > 2 ? b : props === void 0 ? a : null;
      return presentationElement(tag, props && Object.hasOwn(props, "style") ? templateStyleTokens(props.style) : void 0, children);
    }
    let slotUsed = false;
    let interactionAdopted = false;
    function render() {
      slotUsed = false;
      const props = Object.freeze({ get: () => resolved, getRaw: () => raw, isProvided: (key) => own(raw, key) });
      const renderer = { el: element, slot() {
        if (slotUsed) throw new Error("Multiple slots are unsupported");
        slotUsed = true;
        return { kind: "slot" };
      }, props, read: Object.freeze({ props, context: contextRead }) };
      projectHost();
      host.commit(presentationChildren(typeof owner.render === "function" ? owner.render(renderer) : renderer.slot()));
    }
    function projectHost() {
      host.projectRoot(__wcInteraction.rootTag(), __wcInteraction.rootProperties(), host.server ? null : __wcInteraction.portalTarget());
    }
    function detach() {
      host.visible(false);
      if (!view) return;
      view = false;
      ++epoch;
      let error;
      try {
        __wcInteraction.unmount();
      } catch (caught) {
        error = caught;
      }
      try {
        __wcStyle.unmount();
        host.attribute("data-pui-style", null);
      } catch (caught) {
        error ??= caught;
      }
      try {
        fire("unmounted");
      } catch (caught) {
        error ??= caught;
      } finally {
        host.clear();
      }
      if (error !== void 0) throw error;
    }
    function reconcile() {
      if (!alive || disposing || !host.isConnected || host.server) return;
      if (!intent) {
        detach();
        return;
      }
      host.visible(true);
      if (!view) {
        ++epoch;
        render();
        view = true;
        dirty = false;
        __wcStyle.mount();
        if (!interactionAdopted && host.hydrationAttributes) {
          __wcInteraction.adoptAttributes(host.hydrationAttributes, host.hydrationBaselines);
          interactionAdopted = true;
        }
        __wcInteraction.mount();
        fire("mounted");
      } else if (dirty) {
        dirty = false;
        render();
        fire("updated");
      }
    }
    function schedule(update) {
      ensure();
      dirty ||= update;
      if (host.server || queued || disposing) return;
      queued = true;
      queueMicrotask(() => {
        queued = false;
        if (!alive || disposing) return;
        if (host.isConnected) reconcile();
      });
    }
    function expose(key, value) {
      ensureSetup();
      if (own(exposes, key) || events.has(key)) throw new Error("Duplicate expose: " + key);
      exposes[key] = value;
    }
    const def = {
      feedback: { style: __wcStyle },
      event: __wcInteraction.event,
      context: {
        provide(key, value) {
          ensureSetup();
          context.provide(key, value);
        },
        subscribe(key, callback) {
          ensureSetup();
          return context.subscribe(key, "required", callback ? (next, prev) => {
            invoke(callback, [next, prev]);
          } : void 0);
        },
        trySubscribe(key, callback) {
          ensureSetup();
          return context.subscribe(key, "optional", callback ? (next, prev) => {
            invoke(callback, [next, prev]);
          } : void 0);
        },
        trySubscribeAncestor(key, callback) {
          ensureSetup();
          return context.subscribe(key, "optional", callback ? (next, prev) => {
            invoke(callback, [next, prev]);
          } : void 0, "ancestor");
        }
      },
      props: {
        define(input) {
          ensureSetup();
          const merged = { ...specs };
          for (const key of Object.keys(input)) {
            const next = input[key], prev = specs[key];
            if (prev?.validator && prev.validator !== next.validator) throw new Error("Prop validator replacement or removal is disallowed");
            if (!["boolean", "number", "string", "enum", "object", "any"].includes(next.type)) throw new Error("Unsupported prop type");
            if (next.empty !== void 0 && !["accept", "fallback", "error"].includes(next.empty)) throw new Error("Invalid prop empty policy");
            if (next.range && (next.range.min !== void 0 && (typeof next.range.min !== "number" || Number.isNaN(next.range.min)) || next.range.max !== void 0 && (typeof next.range.max !== "number" || Number.isNaN(next.range.max)))) throw new Error("Invalid prop range");
            if (prev && (prev.type !== next.type || prev.range && next.range && ((next.range.min ?? -Infinity) > (prev.range.min ?? -Infinity) || (next.range.max ?? Infinity) < (prev.range.max ?? Infinity)))) throw new Error("Conflicting prop declaration");
            const rank = (empty) => empty === "accept" ? 0 : empty === "error" ? 2 : 1;
            if (prev && next.empty !== void 0 && rank(next.empty) > rank(prev.empty ?? "fallback")) throw new Error("Conflicting prop empty policy");
            merged[key] = { ...prev, ...next, schema: __wcPropTypes[key], empty: prev?.empty ?? next.empty ?? "fallback", range: next.range ?? prev?.range, ...prev && own(prev, "default") ? { default: prev.default } : {} };
          }
          Object.assign(specs, merged);
          resolved = resolve2(false);
          __wcInteraction.refresh();
        },
        setDefaults(input) {
          ensureSetup();
          for (const key of Object.keys(input)) if (!own(specs, key)) throw new Error("Undeclared prop default: " + key);
          defaults.unshift({ ...input });
          resolved = resolve2(false);
          __wcInteraction.refresh();
        },
        watch(keys, fn) {
          ensureSetup();
          const watcher = { keys: [...keys], fn, active: true, raw: false };
          watchers.push(watcher);
          return () => {
            watcher.active = false;
          };
        },
        watchAll(fn) {
          ensureSetup();
          const watcher = { keys: null, fn, active: true, raw: false };
          watchers.push(watcher);
          return () => {
            watcher.active = false;
          };
        },
        watchRaw(keys, fn) {
          ensureSetup();
          const watcher = { keys: [...keys], fn, active: true, raw: true };
          watchers.push(watcher);
          return () => {
            watcher.active = false;
          };
        },
        watchRawAll(fn) {
          ensureSetup();
          const watcher = { keys: null, fn, active: true, raw: true };
          watchers.push(watcher);
          return () => {
            watcher.active = false;
          };
        }
      },
      state: { bool: (s, v) => state("bool", s, v), enum: (s, v, o) => state("enum", s, v, o), string: (s, v, o) => state("string", s, v, o), numberDiscrete: (s, v, o) => state("number.discrete", s, v, o), numberRange: (s, v, o) => state("number.range", s, v, o) },
      expose: {
        value: expose,
        state(key, handle) {
          const external = observedProjections.get(handle)?.external ?? ("external" in handle ? handle.external : void 0);
          if (!external) throw new Error("Unknown external state projection");
          expose(key, external);
          __wcAuthored.introduceObserved(handle);
        },
        method(key, fn, project) {
          expose(key, (...args) => {
            ensureExternal();
            const result = invoke(fn, args, false);
            return project ? project(result) : result;
          });
        },
        event(key) {
          ensureSetup();
          if (own(exposes, key) || events.has(key)) throw new Error("Duplicate expose: " + key);
          events.add(key);
        }
      },
      lifecycle: { onCreated(fn) {
        ensureSetup();
        lifecycle.created.push(fn);
      }, onMounted(fn) {
        ensureSetup();
        lifecycle.mounted.push(fn);
      }, onUpdated(fn) {
        ensureSetup();
        lifecycle.updated.push(fn);
      }, onUnmounted(fn) {
        ensureSetup();
        lifecycle.unmounted.push(fn);
      }, onBeforeDispose(fn) {
        ensureSetup();
        lifecycle.beforeDispose.push(fn);
      } }
    };
    const owner = {
      authored: __wcAuthored,
      identity: Symbol("compiled-logical-owner"),
      def,
      exposes,
      render: void 0,
      interaction: __wcInteraction,
      style: __wcStyle,
      props: () => resolved,
      get epoch() {
        return epoch;
      },
      get view() {
        return view;
      },
      hydrate: hydrate2,
      update: () => schedule(true),
      reconcile,
      validateHydration() {
        host.validateInitial?.({ present: intent, attributes: { "data-pui-style": intent ? __wcStyle.serverTokens().join(" ") || null : null, ...__wcInteraction.projectAttributes() } });
      },
      serialize() {
        ensure();
        if (!host.server) throw new Error("serialize requires a server owner");
        host.visible(intent);
        if (intent) render();
        else host.commit([]);
        host.attribute("data-pui-style", intent ? __wcStyle.serverTokens().join(" ") || null : null);
        if (intent) host.projectInteraction(__wcInteraction.projectAttributes());
        dirty = false;
      },
      created() {
        setup = false;
        fire("created");
      },
      dispose(exhaustive = false) {
        if (!alive || disposing) return;
        disposing = true;
        for (const off of __wcAuthoredWatchCleanups.splice(0)) off();
        let error;
        try {
          detach();
        } catch (caught) {
          error = { value: caught };
        }
        try {
          if (exhaustive) {
            for (const callback of lifecycle.beforeDispose) {
              try {
                invoke(callback);
              } catch (caught) {
                error ??= { value: caught };
              }
            }
          } else fire("beforeDispose");
        } catch (caught) {
          error ??= { value: caught };
        } finally {
          try {
            __wcInteraction.dispose();
          } catch (caught) {
            error ??= { value: caught };
          }
          for (const off of observedSubscriptions.splice(0)) off();
          for (const projection of observedProjections.values()) projection.subscribers.clear();
          observedProjections.clear();
          __wcStyle.dispose();
          host.attribute("data-pui-style", null);
          ownerScopes.delete(host);
          context.dispose();
          host.bindContext(null);
          __wcAuthored.dispose();
          alive = false;
          ++epoch;
          dirty = false;
          watchers.length = 0;
          emissions.length = 0;
          for (const handle of states) handle.subscribers.clear();
          for (const callbacks of Object.values(lifecycle)) callbacks.length = 0;
          host.clear();
        }
        if (error) throw error.value;
      }
    };
    return owner;
  }
  function createHydrationOwner(port, raw, getAssociations) {
    assertNoInstanceAssociations(raw, "hydration props");
    if (port.server && getAssociations !== void 0) throw new TypeError("[ControlLabel SSR] instance associations are supported only after client hydration");
    const owner = __wcCreateOwner(port, getAssociations ?? (() => void 0));
    const __wcDef = owner.def;
    const __wcAuthored = owner.authored;
    const __wcStyle = owner.style;
    const __wcOwnerProps = owner.props;
    const __wcInteraction = owner.interaction;
    const __wcHook0 = (options) => __wcAuthored.install({ name: "as-button", mode: "once", setup: (options2, api) => ((def) => {
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = { "kind": "tw", "tokens": ["select-none"], "groups": ["content-selection affordance"] };
        const __wcCaptureResult = __wcCaptureReceiver.feedback.style.use(__wcCaptureArg0);
        __wcAuthored.effect("feedback", __wcCaptureResult);
        __wcAuthored.disposer("feedback", __wcCaptureResult);
        return __wcCaptureResult;
      })();
      const accessible = __wcAuthored.privileged("asAccessible", () => __wcInteraction.asAccessible());
      __wcAuthored.privileged("asTrigger", () => __wcInteraction.asTrigger());
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = { ["disabled"]: { ["type"]: "boolean", ["empty"]: "fallback" } };
        const __wcCaptureResult = __wcCaptureReceiver.props.define(__wcCaptureArg0);
        __wcAuthored.effect("props", { "op": "define", "specMap": __wcCaptureArg0 });
        return __wcCaptureResult;
      })();
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = { ["disabled"]: false };
        const __wcCaptureResult = __wcCaptureReceiver.props.setDefaults(__wcCaptureArg0);
        __wcAuthored.effect("props", { "op": "setDefaults", "partial": __wcCaptureArg0 });
        return __wcCaptureResult;
      })();
      const disabled = (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "disabled";
        const __wcCaptureArg1 = false;
        const __wcCaptureResult = __wcCaptureReceiver.state.bool(__wcCaptureArg0, __wcCaptureArg1);
        __wcAuthored.effect("state", __wcCaptureResult);
        return __wcCaptureResult;
      })();
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "disabled";
        const __wcCaptureArg1 = disabled;
        const __wcCaptureResult = __wcCaptureReceiver.expose.state(__wcCaptureArg0, __wcCaptureArg1);
        __wcAuthored.effect("state", { "op": "expose.state", "key": __wcCaptureArg0, "handle": __wcCaptureArg1 });
        __wcAuthored.introduceObserved(__wcCaptureArg1);
        return __wcCaptureResult;
      })();
      (() => {
        const __wcCaptureReceiver = accessible;
        const __wcCaptureArg0 = "disabled";
        const __wcCaptureArg1 = disabled;
        const __wcCaptureResult = __wcCaptureReceiver.state(__wcCaptureArg0, __wcCaptureArg1);
        __wcAuthored.effect("state", { "op": "a11y.state", "key": __wcCaptureArg0, "handle": __wcCaptureArg1, "options": void 0 });
        __wcAuthored.introduceObserved(__wcCaptureArg1);
        return __wcCaptureResult;
      })();
      const hovered = (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "hovered";
        const __wcCaptureArg1 = false;
        const __wcCaptureResult = __wcCaptureReceiver.state.bool(__wcCaptureArg0, __wcCaptureArg1);
        __wcAuthored.effect("state", __wcCaptureResult);
        return __wcCaptureResult;
      })();
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "hovered";
        const __wcCaptureArg1 = hovered;
        const __wcCaptureResult = __wcCaptureReceiver.expose.state(__wcCaptureArg0, __wcCaptureArg1);
        __wcAuthored.effect("state", { "op": "expose.state", "key": __wcCaptureArg0, "handle": __wcCaptureArg1 });
        __wcAuthored.introduceObserved(__wcCaptureArg1);
        return __wcCaptureResult;
      })();
      const focusable = __wcAuthored.privileged("asFocusable", () => __wcInteraction.asFocusable(), ["focused", "focusVisible", "focusable"]);
      focusable.configure({ ["disabled"]: false });
      const focused = focusable["focused"];
      const focusVisible = focusable["focusVisible"];
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "focused";
        const __wcCaptureArg1 = focused;
        const __wcCaptureResult = __wcCaptureReceiver.expose.state(__wcCaptureArg0, __wcCaptureArg1);
        __wcAuthored.effect("state", { "op": "expose.state", "key": __wcCaptureArg0, "handle": __wcCaptureArg1 });
        __wcAuthored.introduceObserved(__wcCaptureArg1);
        return __wcCaptureResult;
      })();
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "focusVisible";
        const __wcCaptureArg1 = focusVisible;
        const __wcCaptureResult = __wcCaptureReceiver.expose.state(__wcCaptureArg0, __wcCaptureArg1);
        __wcAuthored.effect("state", { "op": "expose.state", "key": __wcCaptureArg0, "handle": __wcCaptureArg1 });
        __wcAuthored.introduceObserved(__wcCaptureArg1);
        return __wcCaptureResult;
      })();
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "focusSelf";
        const __wcCaptureArg1 = (options3) => {
          if (disabled.get()) {
            return;
          }
          focusable.focusSelf(options3);
        };
        const __wcCaptureResult = __wcCaptureReceiver.expose.method(__wcCaptureArg0, __wcCaptureArg1);
        __wcAuthored.effect("context", { "op": "expose.method", "key": __wcCaptureArg0, "fn": __wcCaptureArg1 });
        __wcAuthored.method(__wcCaptureArg0, __wcCaptureArg1);
        return __wcCaptureResult;
      })();
      const pressed = (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "pressed";
        const __wcCaptureArg1 = false;
        const __wcCaptureResult = __wcCaptureReceiver.state.bool(__wcCaptureArg0, __wcCaptureArg1);
        __wcAuthored.effect("state", __wcCaptureResult);
        return __wcCaptureResult;
      })();
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "pressed";
        const __wcCaptureArg1 = pressed;
        const __wcCaptureResult = __wcCaptureReceiver.expose.state(__wcCaptureArg0, __wcCaptureArg1);
        __wcAuthored.effect("state", { "op": "expose.state", "key": __wcCaptureArg0, "handle": __wcCaptureArg1 });
        __wcAuthored.introduceObserved(__wcCaptureArg1);
        return __wcCaptureResult;
      })();
      const clearTransientInteraction = (reason) => {
        hovered.set(false, reason);
        pressed.set(false, reason);
      };
      def.lifecycle.onUnmounted(() => {
        clearTransientInteraction("reason: button view unmounted => reset transient interaction");
      });
      const syncDisabled = (nextDisabled) => {
        disabled.set(nextDisabled, "reason: sync disabled");
        focusable.setDisabled(nextDisabled);
        if (nextDisabled) {
          clearTransientInteraction("reason: button disabled => reset transient interaction");
        }
      };
      def.lifecycle.onCreated((run) => {
        syncDisabled(run.props.get()["disabled"]);
      });
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = ["disabled"];
        const __wcCaptureArg1 = (_run, next) => {
          syncDisabled(next["disabled"]);
        };
        const __wcCaptureResult = __wcCaptureReceiver.props.watch(__wcCaptureArg0, __wcCaptureArg1);
        __wcAuthored.effect("props", { "op": "watch", "keys": __wcCaptureArg0, "off": __wcCaptureResult });
        __wcAuthored.disposer("props", __wcCaptureResult);
        return __wcCaptureResult;
      })();
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "click";
        const __wcCaptureArg1 = { ["payload"]: "void" };
        const __wcCaptureResult = __wcCaptureReceiver.expose.event(__wcCaptureArg0, __wcCaptureArg1);
        __wcAuthored.effect("event", { "op": "expose.event", "key": __wcCaptureArg0, "spec": __wcCaptureArg1 });
        __wcAuthored.eventKey(__wcCaptureArg0);
        return __wcCaptureResult;
      })();
      accessible.action("activate", { ["event"]: "click" });
      accessible.role("button");
      accessible.nameFromContent();
      const activate = (run, isCurrent = () => {
        return true;
      }) => {
        if (disabled.get() || !isCurrent()) {
          return;
        }
        pressed.set(false, "reason: button activation => pressed");
        if (disabled.get() || !isCurrent()) {
          return;
        }
        run.expose.emit("click");
      };
      __wcAuthored.privileged("asControlLabel", () => __wcInteraction.asControlLabel()).target((run, request) => {
        const isCurrent = () => {
          return !disabled.get() && request.isCurrent();
        };
        if (!isCurrent()) {
          return;
        }
        focusable.focusSelf({ ["reason"]: request["source"] === "pointer" ? "pointer" : "programmatic" });
        if (isCurrent()) {
          activate(run, isCurrent);
        }
      });
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "key.down";
        const __wcCaptureArg1 = (_run, ev) => {
          const detail = ev;
          if (disabled.get()) {
            return;
          }
          if (!focused.get()) {
            return;
          }
          if (detail?.["key"] !== " ") {
            return;
          }
          ev.control.requestDefaultActionPrevention({ ["reason"]: "button.space-activation", ["source"]: "base-button" });
        };
        const __wcCaptureResult = __wcCaptureReceiver.event.onGlobal(__wcCaptureArg0, __wcCaptureArg1);
        const __wcCaptureOff = () => __wcInteraction.releaseListener(__wcCaptureResult);
        __wcAuthored.effect("event", { token: __wcCaptureResult, off: __wcCaptureOff });
        __wcAuthored.disposer("event", __wcCaptureOff);
        return __wcCaptureResult;
      })();
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "pointer.enter";
        const __wcCaptureArg1 = () => {
          if (disabled.get()) {
            return;
          }
          hovered.set(true, "reason: button pointer.enter => hovered");
        };
        const __wcCaptureResult = __wcCaptureReceiver.event.on(__wcCaptureArg0, __wcCaptureArg1);
        const __wcCaptureOff = () => __wcInteraction.releaseListener(__wcCaptureResult);
        __wcAuthored.effect("event", { token: __wcCaptureResult, off: __wcCaptureOff });
        __wcAuthored.disposer("event", __wcCaptureOff);
        return __wcCaptureResult;
      })();
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "pointer.leave";
        const __wcCaptureArg1 = () => {
          hovered.set(false, "reason: button pointer.leave => hovered");
          pressed.set(false, "reason: button pointer.leave => pressed");
        };
        const __wcCaptureResult = __wcCaptureReceiver.event.on(__wcCaptureArg0, __wcCaptureArg1);
        const __wcCaptureOff = () => __wcInteraction.releaseListener(__wcCaptureResult);
        __wcAuthored.effect("event", { token: __wcCaptureResult, off: __wcCaptureOff });
        __wcAuthored.disposer("event", __wcCaptureOff);
        return __wcCaptureResult;
      })();
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "pointer.cancel";
        const __wcCaptureArg1 = () => {
          hovered.set(false, "reason: button pointer.cancel => hovered");
          pressed.set(false, "reason: button pointer.cancel => pressed");
        };
        const __wcCaptureResult = __wcCaptureReceiver.event.on(__wcCaptureArg0, __wcCaptureArg1);
        const __wcCaptureOff = () => __wcInteraction.releaseListener(__wcCaptureResult);
        __wcAuthored.effect("event", { token: __wcCaptureResult, off: __wcCaptureOff });
        __wcAuthored.disposer("event", __wcCaptureOff);
        return __wcCaptureResult;
      })();
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "press.cancel";
        const __wcCaptureArg1 = () => {
          clearTransientInteraction("reason: button press.cancel => reset transient interaction");
        };
        const __wcCaptureResult = __wcCaptureReceiver.event.on(__wcCaptureArg0, __wcCaptureArg1);
        const __wcCaptureOff = () => __wcInteraction.releaseListener(__wcCaptureResult);
        __wcAuthored.effect("event", { token: __wcCaptureResult, off: __wcCaptureOff });
        __wcAuthored.disposer("event", __wcCaptureOff);
        return __wcCaptureResult;
      })();
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "pointer.down";
        const __wcCaptureArg1 = () => {
          if (disabled.get()) {
            return;
          }
          pressed.set(true, "reason: button pointer.down => pressed");
        };
        const __wcCaptureResult = __wcCaptureReceiver.event.on(__wcCaptureArg0, __wcCaptureArg1);
        const __wcCaptureOff = () => __wcInteraction.releaseListener(__wcCaptureResult);
        __wcAuthored.effect("event", { token: __wcCaptureResult, off: __wcCaptureOff });
        __wcAuthored.disposer("event", __wcCaptureOff);
        return __wcCaptureResult;
      })();
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "pointer.up";
        const __wcCaptureArg1 = () => {
          pressed.set(false, "reason: button pointer.up => pressed");
        };
        const __wcCaptureResult = __wcCaptureReceiver.event.on(__wcCaptureArg0, __wcCaptureArg1);
        const __wcCaptureOff = () => __wcInteraction.releaseListener(__wcCaptureResult);
        __wcAuthored.effect("event", { token: __wcCaptureResult, off: __wcCaptureOff });
        __wcAuthored.disposer("event", __wcCaptureOff);
        return __wcCaptureResult;
      })();
      (() => {
        const __wcCaptureReceiver = def;
        const __wcCaptureArg0 = "press.commit";
        const __wcCaptureArg1 = (run) => {
          pressed.set(false, "reason: button press.commit => pressed");
          activate(run);
        };
        const __wcCaptureResult = __wcCaptureReceiver.event.on(__wcCaptureArg0, __wcCaptureArg1);
        const __wcCaptureOff = () => __wcInteraction.releaseListener(__wcCaptureResult);
        __wcAuthored.effect("event", { token: __wcCaptureResult, off: __wcCaptureOff });
        __wcAuthored.disposer("event", __wcCaptureOff);
        return __wcCaptureResult;
      })();
    })(__wcDef) }, options);
    try {
      owner.render = ((def) => {
        __wcHook0();
        (() => {
          const __wcCaptureReceiver = def;
          const __wcCaptureArg0 = { "kind": "tw", "tokens": ["inline-flex", "items-center", "justify-center", "px-4", "py-2", "rounded-md", "border", "border-black", "bg-white", "text-foreground", "text-sm", "leading-normal", "select-text"], "groups": ["display", "items-", "justify-", "px-", "py-", "rounded", "border-width", "border-color", "bg-", "text-color", "text-size", "leading-normal", "content-selection affordance"] };
          const __wcCaptureResult = __wcCaptureReceiver.feedback.style.use(__wcCaptureArg0);
          __wcAuthored.effect("feedback", __wcCaptureResult);
          __wcAuthored.disposer("feedback", __wcCaptureResult);
          return __wcCaptureResult;
        })();
        __wcAuthored.rule(__wcStyle.rule(() => __wcOwnerProps()["disabled"] === true, [{ "kind": "tw", "tokens": ["opacity-50"], "groups": ["opacity-"] }]));
      })(__wcDef);
      owner.hydrate(raw);
      owner.created();
      return owner;
    } catch (error) {
      try {
        owner.dispose(true);
      } catch {
      }
      throw error;
    }
  }

  // button-generated:Component.client.ts
  var CompiledButton = class extends HTMLElement {
    owner = null;
    port = null;
    raw = {};
    hasRaw = false;
    carrier = null;
    closed = false;
    disconnectVersion = 0;
    recovering = false;
    initializedCarrier = false;
    acceptedMode = null;
    failedCarrier = null;
    associations;
    hydrationStatus = "pending";
    hydrationDiagnostic = null;
    get logicalOwner() {
      return this.owner?.identity ?? null;
    }
    get viewEpoch() {
      return this.owner?.epoch ?? 0;
    }
    get present() {
      return this.owner?.view ?? false;
    }
    get instanceAssociations() {
      return this.associations;
    }
    set instanceAssociations(value) {
      if (this.closed) throw new Error("Custom element is disposed");
      const accepted = validateNativeInstanceAssociations(value);
      this.associations = accepted;
      this.owner?.interaction.refresh();
    }
    static get observedAttributes() {
      return ["instance-associations", "instanceassociations"];
    }
    attributeChangedCallback(_name, _previous, value) {
      if (value !== null) throw new TypeError("[InstanceAssociations] use the instanceAssociations property, not an attribute string");
    }
    connectedCallback() {
      ++this.disconnectVersion;
      if (this.closed) return;
      if (this.owner) {
        this.owner.reconcile();
        return;
      }
      const definition = pendingProviderDefinition(this);
      if (definition) {
        const version = this.disconnectVersion;
        definition.then(() => {
          if (this.closed || version !== this.disconnectVersion || !this.isConnected || this.owner) return;
          this.connectedCallback();
        });
        return;
      }
      try {
        const carrier = this.recovering ? this.failedCarrier : this.carrier ?? (!this.initializedCarrier ? readCarrier(this) : null);
        this.failedCarrier = carrier;
        if (carrier && !this.recovering) checkCarrier(carrier, hydrationBinding, this.localName, hydrationArtifacts);
        if (carrier && !this.recovering) {
          if (this.hasRaw) checkInitialProps(this.raw, carrier);
          checkStylesheet(this, hydrationArtifacts.css, hydrationCssText);
          checkStylesheet(this, hydrationArtifacts.environment, hydrationEnvironmentCssText, "consumer environment");
        }
        let mode = carrier?.mode ?? this.acceptedMode ?? "light";
        if (this.recovering) mode = carrier?.mode === "shadow" || this.shadowRoot || this.querySelector(':scope > template[shadowrootmode="open"]') ? "shadow" : "light";
        const port = createBrowserPort(this, mode, carrier && !this.recovering ? carrier : null, this.recovering);
        this.port = port;
        const pending = this.hasRaw ? this.raw : null;
        const initial = carrier && !this.recovering ? decodeRaw(carrier.raw) : this.raw;
        if (!pending) this.raw = { ...initial };
        const owner = createHydrationOwner(port, initial, () => this.associations);
        this.owner = owner;
        try {
          owner.validateHydration();
          owner.reconcile();
        } catch (error) {
          this.owner = null;
          try {
            owner.dispose();
          } catch (cleanup) {
            throw new AggregateError([error, cleanup], "Hydration and cleanup failed");
          }
          throw error;
        }
        port.accept();
        if (this.closed || this.owner !== owner) return;
        this.acceptedMode = mode;
        this.initializedCarrier = true;
        this.carrier = null;
        this.failedCarrier = null;
        this.hydrationStatus = this.recovering ? "recovered" : carrier ? "adopted" : "client";
        this.recovering = false;
        if (this.hasRaw && carrier) owner.hydrate(this.raw);
      } catch (error) {
        const owner = this.owner;
        this.owner = null;
        let failure = error;
        try {
          owner?.dispose();
        } catch (cleanup) {
          failure = new AggregateError([error, cleanup], "Initialization and cleanup failed");
        } finally {
          this.port?.dispose();
          this.port = null;
        }
        if (error instanceof HydrationMismatch) {
          this.hydrationStatus = "mismatch";
          this.hydrationDiagnostic = error;
        }
        throw failure;
      }
    }
    disconnectedCallback() {
      const version = ++this.disconnectVersion, owner = this.owner;
      queueMicrotask(() => {
        if (version !== this.disconnectVersion || this.isConnected || !owner || owner !== this.owner) return;
        this.owner = null;
        try {
          owner.dispose();
        } finally {
          this.port?.dispose();
          this.port = null;
        }
      });
    }
    setProps(next) {
      if (this.closed) throw new Error("Custom element is disposed");
      assertNoInstanceAssociations(next, "Props");
      this.hasRaw = true;
      this.raw = { ...next };
      if (this.owner) this.owner.hydrate(this.raw);
    }
    update() {
      if (this.closed) throw new Error("Custom element is disposed");
      this.owner?.update();
    }
    getExposes() {
      return this.isConnected && this.owner ? { ...this.owner.exposes } : {};
    }
    hydrate(next) {
      if (this.closed) throw new Error("Custom element is disposed");
      checkCarrier(next, hydrationBinding, this.localName, hydrationArtifacts);
      if (this.owner) throw new Error("Custom element already owns a committed instance");
      if (this.initializedCarrier) throw new Error("Carrier has already been adopted");
      this.carrier = next;
      if (this.isConnected) this.connectedCallback();
    }
    /** Recovery is opt-in and reports recovered, never adopted. Existing external slot nodes are preserved. */
    recover(next) {
      if (this.closed) throw new Error("Custom element is disposed");
      if (this.hydrationStatus !== "mismatch") throw new Error("Recovery requires a diagnosed hydration mismatch");
      if (next) {
        assertNoInstanceAssociations(next, "Props");
        this.raw = { ...next };
        this.hasRaw = true;
      }
      this.carrier = this.failedCarrier;
      this.recovering = true;
      if (this.isConnected) this.connectedCallback();
    }
    dispose() {
      if (this.closed) return;
      this.closed = true;
      ++this.disconnectVersion;
      const owner = this.owner;
      this.owner = null;
      try {
        owner?.dispose();
      } finally {
        this.port?.dispose();
        this.port = null;
        this.carrier = null;
      }
    }
  };
  function register(tagName = defaultTagName, registry = customElements) {
    const existing = registry.get(tagName);
    if (existing && existing !== CompiledButton) throw new Error("Custom element tag already registered: " + tagName);
    if (!existing) registry.define(tagName, CompiledButton);
    return CompiledButton;
  }
  function hydrate(element, carrier) {
    if (!(element instanceof CompiledButton)) throw new Error("Register the generated Custom Element before hydrating");
    if (carrier !== void 0) {
      checkCarrier(carrier, hydrationBinding, element.localName, hydrationArtifacts);
      checkCarrierHost(element, carrier);
    }
    if (element.hydrationStatus === "mismatch") throw element.hydrationDiagnostic;
    if (carrier && element.hydrationStatus === "pending") element.hydrate(carrier);
    else if (!element.logicalOwner && element.isConnected) element.connectedCallback();
    return element;
  }
  var Component_client_default = CompiledButton;
  return __toCommonJS(Component_client_exports);
})();
