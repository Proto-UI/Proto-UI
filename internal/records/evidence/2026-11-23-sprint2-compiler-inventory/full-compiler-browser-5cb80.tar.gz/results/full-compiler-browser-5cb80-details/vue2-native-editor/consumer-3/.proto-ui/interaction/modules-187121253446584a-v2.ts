import { owners, targets, hostIds, logicalRoot, ancestor, descends, hostOrder, type Claim, type Owner } from './ownership-v2';
import { activeScopes, type ScopeEntryIntent, noteNativeFocusRequest, focusState } from './focus-ownership-v2';
export type NativeConfig = Readonly<Record<string, unknown>>;
export type NativeStateEvent<T> = {
    type: 'next';
    prev: T;
    next: T;
    reason?: unknown;
} | {
    type: 'disconnect';
    reason: 'unmount';
};
export type NativeObserved<T> = {
    get(): T;
    watch<R>(callback: (run: R, event: NativeStateEvent<T>) => void): () => void;
    subscribe(callback: (event: {
        type: 'next';
        prev: T;
        next: T;
        reason?: unknown;
    }) => void): () => void;
};
export type NativeOwnedState<T> = {
    get(): T;
    set(value: T, reason?: unknown): void;
    setDefault(value: T): void;
};
export type NativeOwnedStateSpec = {
    kind: 'bool' | 'string' | 'enum' | 'number.discrete';
    options?: readonly string[];
};
type NativeStateCell<T> = {
    handle: NativeOwnedState<T>;
    set(value: T): void;
};
export type NativeFocusRequest = {
    reason?: 'programmatic' | 'keyboard' | 'pointer';
    preventScroll?: boolean;
    defer?: boolean;
};
export type NativeFocusScopeActivation = NativeFocusRequest & {
    entry?: 'configured' | 'manual';
};
export type NativeFocusBase = {
    focused: NativeObserved<boolean>;
    focusVisible: NativeObserved<boolean>;
    focusable: NativeObserved<boolean>;
    configure(config: NativeConfig): void;
    setDisabled(value: boolean): void;
    focusSelf(options?: NativeFocusRequest): void;
};
export interface NativeFocusEntry {
    configure(config: NativeConfig): void;
    setDisabled(value: boolean): void;
    focus(options?: NativeFocusRequest): void;
}
export interface NativeFocusRoving {
    active: NativeObserved<boolean>;
    hasFocused: NativeObserved<boolean>;
    configure(config: NativeConfig): void;
    setLoop(value: boolean): void;
    setOrientation(value: string): void;
    focusFirst(options?: NativeFocusRequest): void;
    focusLast(options?: NativeFocusRequest): void;
    focusSelected(options?: NativeFocusRequest): void;
    focusNext(): void;
    focusPrev(): void;
}
export interface NativeFocusScope {
    active: NativeObserved<boolean>;
    hasFocused: NativeObserved<boolean>;
    configure(config: NativeConfig): void;
    focusFirst(): void;
    focusLast(): void;
    focusNext(): void;
    focusPrev(): void;
    focusSelected(): void;
    activate(options?: NativeFocusScopeActivation): void;
    deactivate(options?: NativeFocusRequest): void;
    restoreFocus(): void;
    isActive(): boolean;
    getRoving(): NativeFocusRoving | null;
}
export type NativeAnatomyFamily = {
    debugName: string;
    roles: Readonly<Record<string, {
        cardinality: {
            min: number;
            max: number | '*';
        };
        requires?: readonly {
            kind: string;
            name: string;
        }[];
    }>>;
    relations?: readonly unknown[];
    profiles?: Readonly<Record<string, unknown>>;
};
export interface NativeAnatomyPart {
    readonly role: string;
    hasExpose(key: string): boolean;
    getExpose(key: string): unknown | null;
    hasHook(name: string): boolean;
}
export interface NativeAnatomyOrder {
    version(family: NativeAnatomyFamily): number;
    parts(family: NativeAnatomyFamily): readonly NativeAnatomyPart[];
    partsOf(family: NativeAnatomyFamily, role: string): readonly NativeAnatomyPart[];
    indexOfSelf(family: NativeAnatomyFamily, role: string): number;
    prevOfSelf(family: NativeAnatomyFamily, role: string): NativeAnatomyPart | null;
    nextOfSelf(family: NativeAnatomyFamily, role: string): NativeAnatomyPart | null;
}
export interface NativeAnatomy<Run = unknown> extends NativeAnatomyOrder {
    claim(family: NativeAnatomyFamily, declaration: {
        role: string;
        profile?: string;
    }): void;
    has(family: NativeAnatomyFamily, role: string): boolean;
    descendantsOf(family: NativeAnatomyFamily, ancestor: NativeAnatomyPart, role: string): readonly NativeAnatomyPart[];
    subscribeParts(family: NativeAnatomyFamily, role: string, callback: (run: Run, parts: readonly NativeAnatomyPart[]) => void): () => void;
    readonly order: NativeAnatomyOrder;
}
export type NativeCollectionSnapshot = Readonly<Record<string, unknown> & {
    index: number;
    total: number;
    first: boolean;
    last: boolean;
}>;
export interface NativeCollection {
    readonly count: NativeOwnedState<number>;
    configure(config: NativeConfig): void;
    getItems(): readonly NativeCollectionSnapshot[];
    getCount(): number;
}
export interface NativeCollectionItem {
    readonly collectionIndex: NativeOwnedState<number>;
    readonly collectionTotal: NativeOwnedState<number>;
    readonly collectionFirst: NativeOwnedState<boolean>;
    readonly collectionLast: NativeOwnedState<boolean>;
    configure(config: NativeConfig): void;
    getSnapshot(): NativeCollectionSnapshot;
}
export interface NativeBoundary<Run = unknown> {
    configure(config: NativeConfig): void;
    observe(type: string): void;
    setStackActive(active: boolean): void;
    registerRegion(target: unknown, options?: NativeConfig): () => void;
    unregisterRegion(target: unknown): void;
    classify(sample?: NativeConfig): 'inside' | 'outside' | 'unknown';
    notify(sample?: NativeConfig): 'inside' | 'outside' | 'unknown';
    subscribeOutside(callback: (event: NativeConfig) => void): () => void;
}
export interface NativeHitParticipation {
    configure(config: NativeConfig): void;
    registerSelfRegion(options?: NativeConfig): () => void;
    registerRegion(target: unknown, options?: NativeConfig): () => void;
    unregisterRegion(target: unknown): void;
}
export type NativePositionSnapshot = Readonly<{
    side: string;
    align: string;
    strategy: string;
}>;
export interface NativePositioning {
    connect(connection: NativeConfig): void;
    update(config: NativeConfig): void;
    requestUpdate(): void;
    disconnect(): void;
    getSnapshot(): NativePositionSnapshot | null;
}
export interface NativeOverlay {
    readonly open: NativeObserved<boolean>;
    configure(config: NativeConfig): void;
    isOpen(): boolean;
    openOverlay(reason?: string): void;
    close(reason?: string): void;
    toggle(reason?: string): void;
    updatePosition(config: NativeConfig): void;
    registerTrigger(target: unknown): void;
    registerAnchor(target: unknown): void;
    registerAnchorPart(part: NativeAnatomyPart | null): void;
    registerContent(target: unknown): void;
    getPositionSnapshot(): NativePositionSnapshot | null;
    keepMounted(): void;
    bindPresence(binding: NativeConfig): void;
}
export interface NativeScrollAxis {
    position: NativeObserved<number>;
    visibleRatio: NativeObserved<number>;
    canScrollBefore: NativeObserved<boolean>;
    canScrollAfter: NativeObserved<boolean>;
    atEnd: NativeObserved<boolean>;
}
export type NativeScrollAxisSnapshot = Readonly<{
    position: number;
    visibleRatio: number;
    canScrollBefore: boolean;
    canScrollAfter: boolean;
    atEnd: boolean;
}>;
export type NativeScrollSnapshot = Readonly<{
    axes: string;
    horizontal: NativeScrollAxisSnapshot;
    vertical: NativeScrollAxisSnapshot;
    scrolling: boolean;
    projection: string;
    endFollow: Readonly<{
        state: string;
        requestStatus: string;
    }>;
}>;
export type NativeScrollPositionRequest = {
    kind: 'by';
    axis: 'horizontal' | 'vertical';
    delta: number;
} | {
    kind: 'to' | 'control-drag';
    axis: 'horizontal' | 'vertical';
    position: number;
} | {
    kind: 'page';
    axis: 'horizontal' | 'vertical';
    direction: 'before' | 'after';
} | {
    kind: 'to-end';
    axis: 'horizontal' | 'vertical';
};
export type NativeScrollRequest = NativeScrollPositionRequest | {
    kind: 'reveal';
    axis: 'vertical';
    family: NativeAnatomyFamily;
    part: NativeAnatomyPart;
};
export type NativeScrollRequestOutcome = {
    kind: 'dispatched';
} | {
    kind: 'queued';
} | {
    kind: 'rejected';
    reason: 'not-mounted' | 'not-declared' | 'unavailable';
};
export interface NativeScroll {
    axes: NativeObserved<string>;
    horizontal: NativeScrollAxis;
    vertical: NativeScrollAxis;
    scrolling: NativeObserved<boolean>;
    projection: NativeObserved<string>;
    endFollow: {
        state: NativeObserved<string>;
        requestStatus: NativeObserved<string>;
    };
    configure(config: NativeConfig): void;
    bindComposedChrome(binding: NativeConfig): void;
    request(request: NativeScrollRequest): NativeScrollRequestOutcome;
    pauseFollowing(): NativeScrollRequestOutcome;
    getSnapshot(): NativeScrollSnapshot;
}
export type NativeTextSelection = Readonly<{
    start: number;
    end: number;
    direction: 'forward' | 'backward' | 'none';
}>;
export type NativeTextEvent = Readonly<{
    type: string;
    value: string;
    composing: boolean;
    data: string | null;
    inputType: string | null;
    selection: NativeTextSelection | null;
}>;
export type NativeImageEvent = Readonly<{
    status: string;
    previousStatus: string;
    source: string;
}>;
export interface NativeTextControl<Run = unknown> {
    on(type: string, callback: (run: Run, event: NativeTextEvent) => void): () => void;
    sync(patch: NativeConfig): void;
    resetValue(value?: string): boolean;
    snapshot(): {
        value: string;
        composing: boolean;
        selection: NativeTextSelection | null;
    } | null;
}
export interface NativeImageView<Run = unknown> {
    on(type: string, callback: (run: Run, event: NativeImageEvent) => void): () => void;
    sync(patch: NativeConfig): void;
    snapshot(): {
        source: string;
        loadingStatus: string;
        fit: string;
    } | null;
}
export interface NativeTableStructure {
    readonly role: string;
    readonly states: {
        a11yRole: NativeOwnedState<string>;
        rowCount: NativeOwnedState<number>;
        columnCount: NativeOwnedState<number>;
        row: NativeOwnedState<number>;
        column: NativeOwnedState<number>;
        rowSpan: NativeOwnedState<number>;
        columnSpan: NativeOwnedState<number>;
    };
    configure(patch: NativeConfig): void;
    getObjectRef(): object;
    getSnapshot(): NativeTableSnapshot | null;
}
export type NativeTableCell = Readonly<{
    ref: object;
    kind: 'column-header' | 'row-header' | 'cell';
    row: number;
    column: number;
    rowSpan: number;
    columnSpan: number;
    columnHeaders: readonly object[];
    rowHeaders: readonly object[];
    orderedHeaders: readonly object[];
}>;
export type NativeTableRow = Readonly<{
    ref: object;
    index: number;
    cells: readonly NativeTableCell[];
}>;
export type NativeTableDiagnostic = Readonly<{
    code: string;
    ref?: object;
    row?: number;
    headerKey?: string;
}>;
export type NativeTableSnapshot = Readonly<{
    root: object;
    caption: object | undefined;
    rowCount: number;
    columnCount: number;
    rows: readonly NativeTableRow[];
    valid: boolean;
    diagnostics: readonly NativeTableDiagnostic[];
}>;
export interface NativeAccessibleExtension {
    readonly objectRef: object;
    id(value: string | {
        get(): string | null | undefined;
    }): void;
    name(value: string | {
        get(): string | null | undefined;
    }): void;
    nameFromContent(): void;
    description(value: string | {
        get(): string | null | undefined;
    }): void;
    relation(kind: string, target: NativeConfig): void;
    tree(config: NativeConfig): void;
    level(value: number | {
        get(): number;
    }): void;
}
export type NativeControlLabelAnatomyPair = Readonly<{
    family: NativeAnatomyFamily;
    labelRole: string;
    targetRole: string;
}>;
export type NativeControlLabelRequest = Readonly<{
    source: 'pointer' | 'accessibility';
    isCurrent(): boolean;
}>;
export type NativeControlLabelHandle = Readonly<{
    sync(options: Readonly<{
        naming: boolean;
        activation: boolean;
    }>): void;
}>;
export type NativeControlLabel<Run = unknown> = Readonly<{
    label(pair?: NativeControlLabelAnatomyPair): NativeControlLabelHandle;
    target(activate: (run: Run, request: NativeControlLabelRequest) => void, pair?: NativeControlLabelAnatomyPair): NativeControlLabelHandle;
}>;
export type NativeLinkSnapshot = Readonly<{
    href: string;
    target: string;
    rel: string;
    disabled: boolean;
}>;
export type NativeLinkEvent = Readonly<{
    href: string;
    target: string;
    rel: string;
    modified: boolean;
}>;
export type NativeLink<Run> = {
    sync(config: NativeConfig): void;
    snapshot(): NativeLinkSnapshot | null;
    on(type: string, callback: (run: Run, event: NativeLinkEvent) => void): () => void;
};
export type NativeAxisInputCancelReason = 'host-cancel' | 'lost-ownership' | 'target-detached' | 'target-replaced' | 'disposed' | 'disabled' | 'configuration-changed' | 'invalid-geometry' | 'basis-changed';
export type NativeAxisInputSample = Readonly<{
    phase: 'start' | 'move' | 'end';
    position: number;
    delta: number;
    totalDelta: number;
}> | Readonly<{
    phase: 'cancel';
    reason: NativeAxisInputCancelReason;
}>;
export type NativeAxisInputBinding = Readonly<{
    anatomy: NativeAnatomyFamily;
    inputRole: string;
    geometryRole: string;
    travelRole?: string;
    deltaBasisRole?: string;
}>;
export interface NativeAxisInput<Run = unknown> {
    configure(binding: NativeAxisInputBinding): void;
    on(callback: (run: Run, sample: NativeAxisInputSample) => void): void;
    sync(patch: NativeConfig): void;
}
export type NativeModuleCapability<Kind extends string, Run = unknown> = Kind extends 'control-label' ? NativeControlLabel<Run> : Kind extends 'control-label-handle' ? NativeControlLabelHandle : Kind extends 'control-label-request' ? NativeControlLabelRequest : Kind extends 'binding-disposer' ? () => void : Kind extends 'collection-snapshot' ? NativeConfig : Kind extends 'collection-snapshot-list' ? readonly NativeConfig[] : Kind extends 'focus-entry' ? NativeFocusEntry : Kind extends 'focus-roving' ? NativeFocusRoving : Kind extends 'focus-scope' ? NativeFocusScope : Kind extends 'anatomy-family' ? NativeAnatomyFamily : Kind extends 'anatomy-part' ? NativeAnatomyPart : Kind extends 'anatomy-parts' ? readonly NativeAnatomyPart[] : Kind extends 'anatomy-order' ? NativeAnatomyOrder : Kind extends 'collection' ? NativeCollection : Kind extends 'collection-item' ? NativeCollectionItem : Kind extends 'boundary' ? NativeBoundary<Run> : Kind extends 'hit-participation' ? NativeHitParticipation : Kind extends 'positioning' ? NativePositioning : Kind extends 'overlay' ? NativeOverlay : Kind extends 'scroll' ? NativeScroll : Kind extends 'scroll-axis' ? NativeScrollAxis : Kind extends 'scroll-follow' ? NativeScroll['endFollow'] : Kind extends 'text-control' ? NativeTextControl<Run> : Kind extends 'image-view' ? NativeImageView<Run> : Kind extends 'native-link' ? NativeLink<Run> : Kind extends 'axis-input' ? NativeAxisInput<Run> : Kind extends 'table-structure' ? NativeTableStructure : Kind extends 'table-states' ? NativeTableStructure['states'] : Kind extends 'table-snapshot' ? NativeTableSnapshot : Kind extends 'table-row' ? NativeTableRow : Kind extends 'table-cell' ? NativeTableCell : Kind extends 'table-diagnostic' ? NativeTableDiagnostic : Kind extends 'table-row-list' ? readonly NativeTableRow[] : Kind extends 'table-cell-list' ? readonly NativeTableCell[] : Kind extends 'table-diagnostic-list' ? readonly NativeTableDiagnostic[] : Kind extends 'a11y-ref-list' ? readonly object[] : Kind extends 'subscription-disposer' ? () => void : Kind extends 'host-target' ? Element : Kind extends 'focus-scope-key' | 'focus-roving-key' | 'a11y-ref' ? object : NativeConfig;
export interface NativeModuleCapabilities<Run = unknown> {
    asTextControl(): NativeTextControl<Run>;
    configureFocusable(config: NativeConfig): void;
    setFocusDisabled(value: boolean): void;
    setNavParticipation(value: string): void;
    setRovingStatus(status: NativeConfig): void;
    canFocus(): boolean;
    focus(options?: NativeFocusRequest): void;
    blur(): void;
    rootTag(): string | null;
    rootProperties(): Readonly<Record<string, string | number | boolean | null>>;
    projectAttributes(): Readonly<Record<string, string | null>>;
    portalTarget(): HTMLElement | null;
    adoptControlState(): void;
    commitHost(): void;
    mount(): void;
    unmount(): void;
    refresh(): void;
    dispose(): void;
}
export interface NativeAdapterModuleOptions<Run> {
    ensureSetup(operation: string): void;
    ensureRuntime(operation: string): void;
    ensureEvent(operation: string): void;
    isAlive(): boolean;
    isSetupComplete?(): boolean;
    isReady?(): boolean;
    invoke<T>(callback: () => T): T;
    getRun(): Run;
    getResolvedProps(): Readonly<Record<string, unknown>>;
    getRoot(): HTMLElement | null;
    getHost?(): HTMLElement | null;
    declarations: readonly {
        id: string;
        config: NativeConfig;
    }[];
    getLogicalParent(): object | null;
    identity: object;
    registerObservedState?<T extends boolean | string | number>(state: NativeObserved<T>): void;
    getExposes?(): Readonly<Record<string, unknown>>;
    setPresent?(value: boolean): void;
    requestHostUpdate?(): void;
    baseFocus?(): NativeFocusBase;
    getAccessibleRole?(): string | null;
    /** Internal focus bridge cleanup; never blurs the physical target. */
    cancelPendingFocus?(): void;
    emit?(key: string): void;
    createOwnedState?<T extends boolean | string | number>(name: string, initial: T, spec?: NativeOwnedStateSpec): NativeOwnedState<T>;
    watchState?<T>(state: {
        get(): T;
    }, callback: (run: Run, event: NativeStateEvent<T>) => void): () => void;
    isPropProvided?(key: string): boolean;
    getMeta?(key: string): unknown;
    registerExpose?(key: string, value: unknown): void;
    tableFamily?: NativeAnatomyFamily;
    requestAttributeRefresh?(): void;
    getAttributeBaseline?(name: string): string | null;
    subscribeState?(state: {
        get(): unknown;
    }, callback: () => void): () => void;
}
type NativeTableCellInput = {
    ref: object;
    kind: 'headerCell' | 'cell';
    headerKey?: string;
    headerKind?: unknown;
    headers: readonly string[];
    rowSpan?: number;
    columnSpan?: number;
};
type NativeTableInput = {
    root: object;
    captions: readonly object[];
    rows: readonly {
        ref: object;
        cells: readonly NativeTableCellInput[];
    }[];
    unmatchedCells: readonly object[];
    roleMismatches: readonly object[];
};
type NativePartKey = string | {
    get(): unknown;
};
type NativePartTarget = {
    kind: 'part';
    family: NativeAnatomyFamily;
    role: string;
    key: NativePartKey;
};
type NativePartProjection = {
    view: HTMLElement;
    attribute: string;
    token: string;
};
type NativePartRecord = {
    owner: Owner;
    view: HTMLElement | null;
    epoch: number;
    currentEpoch(): number;
    hostScope: Document | ShadowRoot | null;
    parts: Map<NativeAnatomyFamily, NativePartKey>;
    relations: Map<string, {
        target: NativePartTarget;
        attribute: string;
    }>;
    projections: Map<string, NativePartProjection>;
    diagnostics: Map<string, string>;
    subscriptions: Map<string | NativeAnatomyFamily, () => void>;
    reservation: {
        scope: Document | ShadowRoot;
        id: string;
    } | null;
    binding: {
        view: HTMLElement;
        id: string;
        previous: string | null;
        owned: boolean;
    } | null;
};
type NativePartTokens = {
    baseline: Set<string>;
    leases: Map<object, string>;
    projected: string | null;
};
interface NativePartRelationships {
    part(family: NativeAnatomyFamily, key: NativePartKey): void;
    relation(kind: string, target: NativePartTarget, attribute: string): void;
    removeRelation(kind: string): void;
    refresh(view: HTMLElement | null): void;
    unmount(): void;
    dispose(): void;
}
export function createNativeAdapterModules<Run>(options: NativeAdapterModuleOptions<Run>): NativeModuleCapabilities<Run> {
    let disposed = false;
    let root: HTMLElement | null = null;
    let generation = 0;
    let hostProperties: Readonly<Record<string, string | number | boolean | null>> | null = null;
    let hostPortal: HTMLElement | null = null;
    const cleanups: (() => void)[] = [];
    const terminalCleanups: (() => void)[] = [];
    const propertyBaselines = new Map<string, {
        value: string;
        projected: string;
    }>();
    const hooks = new Set<string>();
    const claims = new Map<object, Claim>();
    const topologySubscribers = new Set<() => void>();
    const focusConfig: Record<string, unknown> = { disabled: false, navParticipation: 'auto' };
    const scopeConfig: Record<string, unknown> = { trap: false, loop: false, navigation: 'tab', orientation: 'both', entry: 'first', entryFallback: 'none', restore: 'previous', emptyPolicy: 'container' };
    const rovingConfig: Record<string, unknown> = { loop: false, navigation: 'arrow', orientation: 'both', entry: 'active', selectOnFocus: false };
    let pendingFocus: NativeFocusRequest | null = null;
    let scopeActivation = 0;
    let ownedEntry: (ScopeEntryIntent & {
        activation: number;
        request: NativeFocusRequest;
        applying: boolean;
    }) | undefined;
    const owner: Owner = { identity: options.identity, parent: options.getLogicalParent, target: () => root, host: () => root ? options.getHost?.() ?? root : null, alive: () => !disposed && options.isAlive(), hooks, claims, exposes: () => options.getExposes?.() ?? {}, focusConfig, scopeConfig, rovingConfig, selected: false, active: false, scopeDeclared: false, rovingDeclared: false, focusDeclared: false, entryDeclared: false, scopeActive: false, focus: request => requestFocus(request), cancelPendingFocus() {
            {
                pendingFocus = null;
                options.cancelPendingFocus?.();
            }
        }, changed: () => {
            const epoch = generation;
            for (const callback of [...topologySubscribers]) {
                if (epoch !== generation || !ready() || !(options.isReady?.() ?? true))
                    break;
                if (topologySubscribers.has(callback))
                    options.invoke(callback);
            }
            refresh();
        } };
    if (owners.has(options.identity))
        throw new Error('[Modules] duplicate live owner identity.');
    function alive() {
        if (disposed || !options.isAlive())
            throw new Error('[Modules] owner is terminally disposed.');
    }
    function setup(operation: string) { alive(); options.ensureSetup(operation); }
    function runtime(operation: string) { alive(); options.ensureRuntime(operation); }
    function requestPresentation() {
        if (disposed || !options.isAlive() || !(options.isReady?.() ?? true))
            return;
        const next = rootProperties(), portal = portalTarget();
        const changed = !hostProperties || portal !== hostPortal || Object.keys(next).length !== Object.keys(hostProperties).length || Object.keys(next).some(key => next[key] !== hostProperties![key]);
        hostProperties = next;
        hostPortal = portal;
        if (changed)
            options.requestHostUpdate?.();
    }
    function ready() { return !disposed && options.isAlive() && !!root && root === options.getRoot() && root.isConnected; }
    function announceTopology(rootOwner = logicalRoot(owner)) {
        for (const participant of [...owners.values()])
            if (participant.alive() && logicalRoot(participant) === rootOwner)
                participant.changed();
    }
    function declare(name: string) { setup('hook.' + name); hooks.add(name); }
    function requestFocus(request?: NativeFocusRequest) {
        alive();
        if (focusConfig.disabled || !canFocus())
            return;
        if (!ready() || root!.closest('[hidden],[inert],[data-pui-view-detached]')) {
            if (noteNativeFocusRequest())
                pendingFocus = request ?? {};
            return;
        }
        if (options.baseFocus)
            options.invoke(() => options.baseFocus!().focusSelf(request));
        else if (noteNativeFocusRequest())
            root!.focus({ preventScroll: request?.preventScroll });
    }
    function canFocus(): boolean {
        alive();
        for (let index = activeScopes.length - 1; index >= 0; index--) {
            const scope = activeScopes[index];
            if (!scope.alive()) {
                activeScopes.splice(index, 1);
                continue;
            }
            if (scope.target()?.isConnected)
                return descends(owner, scope);
        }
        return true;
    }
    function cancelOwnedEntry(intent = ownedEntry) {
        if (!intent)
            return;
        if (ownedEntry === intent)
            ownedEntry = undefined;
        if (focusState.scopeEntryIntent === intent)
            focusState.scopeEntryIntent = undefined;
    }
    const textDeclaration = options.declarations.find(declaration => declaration.id === 'text-control' || declaration.id === '@proto.ui/text-control/declaration');
    if (textDeclaration && (textDeclaration.config.content !== 'plain-text' || textDeclaration.config.engine !== 'host' || !['single', 'multiline'].includes(String(textDeclaration.config.lineMode))))
        throw new Error('[TextControl] unsupported physical declaration.');
    const textListeners = new Map<string, Set<(run: Run, event: NativeTextEvent) => void>>();
    let textDeclared = false;
    let textInitialized = false;
    let textValue = '';
    let textComposing = false;
    let textMode = 'uncontrolled';
    let textEpoch = 0;
    const textCleanups: (() => void)[] = [];
    let textEventGeneration = 0;
    let textCallbackPrelude: {
        epoch: number;
    } | null = null;
    let textPatch: NativeConfig = {};
    let queueTextSelection: (() => void) | null = null;
    let textObservation: {
        epoch: number;
        lease: number;
        ownerValue: string;
    } | null = null;
    function retireText() {
        ++textEpoch;
        queueTextSelection = null;
        textObservation = null;
        for (const cleanup of textCleanups.splice(0))
            cleanup();
    }
    const canonicalText = (value: string) => { const normalized = value.replace(/\r\n?/g, '\n'); return textDeclaration?.config.lineMode === 'single' ? normalized.replace(/\n/g, '') : normalized; };
    function readTextSelection(target: HTMLInputElement | HTMLTextAreaElement, source: string): NativeTextSelection | null {
        try {
            const start = target.selectionStart, end = target.selectionEnd, direction = target.selectionDirection;
            if (typeof start !== 'number' || typeof end !== 'number' || !Number.isInteger(start) || !Number.isInteger(end) || start < 0 || end < start || end > source.length || !['forward', 'backward', 'none'].includes(String(direction)))
                return null;
            return Object.freeze({ start: canonicalText(source.slice(0, start)).length, end: canonicalText(source.slice(0, end)).length, direction: direction as NativeTextSelection['direction'] });
        }
        catch {
            return null;
        }
    }
    function restoreTextValue(target: HTMLInputElement | HTMLTextAreaElement, initialize = false) {
        if ((!initialize && target.value === textValue) || textComposing || textCallbackPrelude?.epoch === generation)
            return;
        const selection = readTextSelection(target, target.value);
        const top = target.scrollTop, left = target.scrollLeft;
        target.value = textValue;
        if (selection)
            target.setSelectionRange(Math.min(selection.start, textValue.length), Math.min(selection.end, textValue.length), selection.direction);
        target.scrollTop = top;
        target.scrollLeft = left;
    }
    function applyText(restoreValue = false, initialize = false) {
        if (!ready() || !textDeclared)
            return;
        if (root!.localName !== 'input' && root!.localName !== 'textarea')
            throw new Error('[TextControl] renderer did not bind the required physical Root.');
        const target = root as HTMLInputElement | HTMLTextAreaElement;
        if (target.localName === 'input' && !['text', 'search', 'tel', 'password'].includes((target as HTMLInputElement).type))
            throw new Error('[TextControl] incompatible input sanitization.');
        for (const [key, value] of Object.entries(textPatch)) {
            if (['value', 'valueMode', 'defaultValue'].includes(key))
                continue;
            if (['disabled', 'readOnly', 'required'].includes(key) && typeof value === 'boolean') {
                Reflect.set(target, key, value);
                continue;
            }
            if (key === 'rows' && target.localName === 'textarea' && typeof value === 'number' && Number.isFinite(value)) {
                Reflect.set(target, key, Math.max(1, Math.trunc(value)));
                continue;
            }
            if ((key === 'minLength' || key === 'maxLength') && typeof value === 'number' && Number.isFinite(value)) {
                if (value < 0)
                    target.removeAttribute(key.toLowerCase());
                else
                    Reflect.set(target, key, Math.trunc(value));
                continue;
            }
            if (['placeholder', 'name', 'autoComplete', 'inputMode', 'enterKeyHint', 'wrap'].includes(key) && typeof value === 'string') {
                if (value === '')
                    target.removeAttribute(key.toLowerCase());
                else
                    target.setAttribute(key.toLowerCase(), value);
            }
        }
        if (typeof textPatch.defaultValue === 'string' && target.defaultValue !== textPatch.defaultValue)
            target.defaultValue = canonicalText(textPatch.defaultValue);
        // Observations may refresh semantic state while an editing callback owns a
        // native candidate. Attribute refresh must not commit or reject that candidate.
        if (restoreValue)
            restoreTextValue(target, initialize);
        queueTextSelection?.();
    }
    const textControl: NativeTextControl<Run> = {
        on(type, callback) {
            setup('textControl.on');
            if (!['input', 'change', 'compositionstart', 'compositionupdate', 'compositionend', 'selectionchange'].includes(type))
                throw new Error('[TextControl] invalid event type.');
            let listeners = textListeners.get(type);
            if (!listeners) {
                listeners = new Set();
                textListeners.set(type, listeners);
            }
            listeners.add(callback);
            return () => { setup('textControl.off'); listeners!.delete(callback); };
        },
        sync(patch) {
            runtime('textControl.sync');
            const previousValue = textValue;
            if (textDeclaration?.config.lineMode === 'single' && (patch.rows !== undefined || patch.wrap !== undefined))
                throw new Error('[TextControl] rows/wrap require multiline declaration.');
            if (!textInitialized) {
                textMode = String(patch.valueMode ?? 'uncontrolled');
                if (!['controlled', 'uncontrolled'].includes(textMode))
                    throw new Error('[TextControl] invalid value mode.');
                textValue = canonicalText(String(textMode === 'controlled' ? patch.value ?? '' : patch.defaultValue ?? ''));
                textInitialized = true;
            }
            textPatch = { ...textPatch, ...patch, valueMode: textMode,
                value: typeof patch.value === 'string' ? canonicalText(patch.value) : textPatch.value,
                defaultValue: typeof patch.defaultValue === 'string' ? canonicalText(patch.defaultValue) : textPatch.defaultValue };
            if (textMode === 'controlled')
                textValue = String(textPatch.value ?? '');
            // A real canonical transition retires the prior candidate window, even if
            // a later explicit transition returns to its original string value.
            if (textValue !== previousValue)
                textObservation = null;
            applyText(!(textObservation?.epoch === generation && textObservation.lease === textEpoch && textObservation.ownerValue === textValue));
            requestPresentation();
        },
        resetValue(value) {
            runtime('textControl.resetValue');
            if (!textDeclared || !textInitialized || !ready() || !(options.isReady?.() ?? true) || value !== undefined && typeof value !== 'string')
                return false;
            const controlled = textMode === 'controlled';
            if (!controlled)
                textValue = canonicalText(value ?? String(textPatch.defaultValue ?? ''));
            ++textEventGeneration;
            textCallbackPrelude = null;
            textComposing = false;
            attachText();
            requestPresentation();
            return !controlled;
        },
        snapshot() { alive(); const target = ready() ? root as HTMLInputElement | HTMLTextAreaElement : null; return textDeclared ? Object.freeze({ value: textValue, composing: textComposing, selection: target && canonicalText(target.value) === textValue ? readTextSelection(target, target.value) : null }) : null; },
    };
    function attachText() {
        retireText();
        if (!textDeclared || !ready())
            return;
        applyText(true, true);
        const target = root as HTMLInputElement | HTMLTextAreaElement, epoch = generation, lease = textEpoch;
        let lastSelection: string | undefined, selectionQueued = false;
        const current = () => lease === textEpoch && epoch === generation && ready() && root === target && (options.isReady?.() ?? true);
        const bind = (eventTarget: EventTarget, type: string, callback: (event: Event) => void) => {
            const guarded = (event: Event) => {
                if (current())
                    callback(event);
            };
            eventTarget.addEventListener(type, guarded);
            textCleanups.push(() => eventTarget.removeEventListener(type, guarded));
        };
        const emitSelection = () => {
            if (!current())
                return;
            const source = target.value, value = canonicalText(source), selection = readTextSelection(target, source);
            const identity = JSON.stringify([value, selection]);
            if (identity === lastSelection)
                return;
            lastSelection = identity;
            const event: NativeTextEvent = Object.freeze({ type: 'selectionchange', value, composing: textComposing, data: null, inputType: null, selection });
            const listeners = textListeners.get('selectionchange');
            const previous = textObservation, observation = value !== textValue ? { epoch, lease, ownerValue: textValue } : null;
            if (observation)
                textObservation = observation;
            try {
                for (const callback of [...listeners ?? []]) {
                    if (!current())
                        break;
                    if (listeners?.has(callback))
                        options.invoke(() => callback(options.getRun(), event));
                }
            }
            finally {
                if (observation && textObservation === observation)
                    textObservation = previous;
            }
        };
        queueTextSelection = () => {
            if (selectionQueued || !current())
                return;
            selectionQueued = true;
            queueMicrotask(() => { selectionQueued = false; emitSelection(); });
        };
        for (const type of ['select', 'selectionchange', 'keyup', 'pointerup', 'focus', 'blur'])
            bind(target, type, emitSelection);
        bind(target.ownerDocument, 'selectionchange', () => {
            if ((target.getRootNode() as Document | ShadowRoot).activeElement === target)
                emitSelection();
        });
        for (const type of ['input', 'change', 'compositionstart', 'compositionupdate', 'compositionend'])
            bind(target, type, native => {
                const editing = native as InputEvent;
                const eventGeneration = ++textEventGeneration;
                if (type === 'compositionstart' || type === 'input' && editing.isComposing)
                    textComposing = true;
                if (type === 'compositionend')
                    textComposing = false;
                const source = target.value, value = canonicalText(source);
                if (textMode === 'uncontrolled' && (type === 'input' || type === 'change'))
                    textValue = value;
                const event: NativeTextEvent = Object.freeze({ type, value, composing: textComposing, data: typeof editing.data === 'string' ? canonicalText(editing.data) : null, inputType: type === 'input' && typeof editing.inputType === 'string' ? editing.inputType : null, selection: readTextSelection(target, source) });
                const previous = textObservation;
                const observation = textMode === 'controlled' && ['input', 'change', 'compositionend'].includes(type) && value !== textValue ? { epoch, lease, ownerValue: textValue } : null;
                if (observation)
                    textObservation = observation;
                const eventCurrent = () => current() && eventGeneration === textEventGeneration;
                const inCurrentCallback = (callback: () => void) => {
                    const previousPrelude = textCallbackPrelude, prelude = { epoch };
                    // Reconcile pending Props without letting the callback prelude overwrite
                    // the native candidate. The observation window then owns the candidate.
                    if (type !== 'change')
                        textCallbackPrelude = prelude;
                    const release = () => {
                        if (textCallbackPrelude === prelude)
                            textCallbackPrelude = previousPrelude;
                    };
                    try {
                        options.invoke(() => {
                            release();
                            if (eventCurrent())
                                callback();
                        });
                    }
                    finally {
                        release();
                    }
                };
                try {
                    inCurrentCallback(() => {
                        const listeners = textListeners.get(type);
                        for (const callback of [...listeners ?? []]) {
                            if (!eventCurrent())
                                break;
                            if (listeners?.has(callback))
                                callback(options.getRun(), event);
                        }
                    });
                    if (textMode === 'controlled' && (type === 'compositionend' || (type === 'input' || type === 'change') && !event.composing))
                        queueMicrotask(() => {
                            if (eventCurrent())
                                inCurrentCallback(() => applyText(true));
                        });
                }
                finally {
                    if (observation && textObservation === observation)
                        textObservation = previous;
                    if (eventCurrent())
                        textComposing = event.composing;
                }
            });
        queueTextSelection();
    }
    function rootTag(): string | null { alive(); return textDeclaration ? textDeclaration.config.lineMode === 'single' ? 'input' : 'textarea' : null; }
    function adoptControlState(): void {
        alive();
        if (root)
            throw new Error('[Modules] adopt control state before the first view mount.');
        const target = options.getRoot();
        if (!target)
            throw new Error('[Modules] hydration requires the adopted physical Root.');
        if (target.id)
            hostIds.set(options.identity, target.id);
        if (textDeclared) {
            if (target.localName !== 'input' && target.localName !== 'textarea')
                throw new Error('[TextControl] adopted Root does not match the physical declaration.');
            textValue = canonicalText((target as HTMLInputElement | HTMLTextAreaElement).value);
        }
    }
    function rootProperties(): Readonly<Record<string, string | number | boolean | null>> {
        alive();
        const result: Record<string, string | number | boolean | null> = Object.create(null);
        if (textDeclaration) {
            if (textDeclaration.config.lineMode === 'single')
                result.type = 'text';
            result.value = textValue;
            for (const [key, value] of Object.entries(textPatch))
                if (!['value', 'valueMode', 'defaultValue'].includes(key) && (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean')) {
                    if (key === 'minLength' || key === 'maxLength')
                        result[key] = typeof value === 'number' && value >= 0 ? Math.trunc(value) : null;
                    else if (key === 'rows')
                        result[key] = Math.max(1, Math.trunc(Number(value)));
                    else
                        result[key] = value;
                }
        }
        return result;
    }
    function projectAttributes(): Readonly<Record<string, string | null>> {
        alive();
        const result: Record<string, string | null> = Object.create(null);
        if (owner.focusDeclared && focusConfig.navParticipation !== 'none') {
            const provider = ancestor(owner, candidate => candidate !== owner && candidate.rovingDeclared);
            if (provider) {
                const members = [...owners.values()].filter(candidate => candidate.focusDeclared && !candidate.focusConfig.disabled && ancestor(candidate, entry => entry !== candidate && entry.rovingDeclared) === provider).sort(hostOrder);
                const selected = members.find(candidate => candidate.active) ?? members.find(candidate => candidate.selected) ?? members[0];
                result.tabindex = focusConfig.disabled || selected !== owner ? '-1' : '0';
            }
        }
        return result;
    }
    const attributeBaselines = new Map<string, {
        baseline: string | null;
        projected: string | null;
    }>();
    function projectModuleAttributes() {
        if (!ready())
            return;
        if (options.requestAttributeRefresh) {
            options.requestAttributeRefresh();
            return;
        }
        for (const [name, value] of Object.entries(projectAttributes())) {
            const current = root!.getAttribute(name);
            let ownership = attributeBaselines.get(name);
            if (!ownership) {
                ownership = { baseline: current, projected: current };
                attributeBaselines.set(name, ownership);
            }
            else if (current !== ownership.projected)
                ownership.baseline = current;
            if (current !== value) {
                if (value === null)
                    root!.removeAttribute(name);
                else
                    root!.setAttribute(name, value);
            }
            ownership.projected = value;
        }
    }
    function refresh() {
        if (disposed || !options.isAlive())
            return;
        if (!ready()) {
            requestPresentation();
            return;
        }
        projectModuleAttributes();
        applyText(false, false);
        if (pendingFocus) {
            const request = pendingFocus;
            pendingFocus = null;
            requestFocus(request);
        }
        requestPresentation();
    }
    function portalTarget(): HTMLElement | null { return null; }
    function unmount() {
        const previous = root;
        ++generation;
        root = null;
        if (previous && targets.get(previous) === owner)
            targets.delete(previous);
        const failures: unknown[] = [];
        for (const cleanup of cleanups.splice(0))
            try {
                cleanup();
            }
            catch (error) {
                failures.push(error);
            }
        if (previous) {
            for (const [name, ownership] of attributeBaselines)
                if (previous.getAttribute(name) === ownership.projected) {
                    if (ownership.baseline === null)
                        previous.removeAttribute(name);
                    else
                        previous.setAttribute(name, ownership.baseline);
                }
            for (const [name, ownership] of propertyBaselines)
                if (previous.style.getPropertyValue(name) === ownership.projected) {
                    if (ownership.value)
                        previous.style.setProperty(name, ownership.value);
                    else
                        previous.style.removeProperty(name);
                }
        }
        attributeBaselines.clear();
        propertyBaselines.clear();
        {
            retireText();
            textComposing = false;
            textCallbackPrelude = null;
            ++textEventGeneration;
        }
        if (previous) {
            if (options.isAlive() && (options.isReady?.() ?? true)) {
            }
            announceTopology();
        }
        if (failures.length)
            throw new AggregateError(failures, '[Modules] view cleanup failed.');
    }
    function mount() {
        alive();
        const candidate = options.getRoot();
        if (root === candidate && ready()) {
            refresh();
            return;
        }
        unmount();
        root = candidate;
        if (!root)
            return;
        const mountEpoch = generation;
        targets.set(root, owner);
        if (root.id)
            hostIds.set(options.identity, root.id);
        try {
            const doc = root.ownerDocument;
            attachText();
            refresh();
            announceTopology();
        }
        catch (error) {
            if (mountEpoch === generation && root === candidate)
                try {
                    unmount();
                }
                catch (cleanup) {
                    throw new AggregateError([error, cleanup], '[Modules] mount and cleanup failed.');
                }
            throw error;
        }
    }
    const capabilities: NativeModuleCapabilities<Run> = {
        asTextControl() {
            declare('asTextControl');
            if (!textDeclaration)
                throw new Error('[TextControl] asTextControl requires its static physical declaration.');
            textDeclared = true;
            return textControl;
        },
        configureFocusable(config) { setup('focus.configure'); owner.focusDeclared = true; hooks.add('asFocusable'); Object.assign(focusConfig, config); },
        setFocusDisabled(value) {
            runtime('focus.setDisabled');
            focusConfig.disabled = value;
            if (value)
                pendingFocus = null;
            announceTopology();
        },
        setNavParticipation(value) {
            runtime('focus.setNavParticipation');
            if (!['auto', 'none'].includes(value))
                throw new Error('[Focus] invalid navigation participation.');
            focusConfig.navParticipation = value;
            refresh();
        },
        setRovingStatus(status) {
            runtime('focus.setRovingStatus');
            if (status.selected !== undefined)
                owner.selected = Boolean(status.selected);
            if (status.active !== undefined)
                owner.active = Boolean(status.active);
            refresh();
        },
        canFocus,
        focus(request) { runtime('focus.focus'); requestFocus(request); },
        blur() {
            runtime('focus.blur');
            ++scopeActivation;
            cancelOwnedEntry();
            pendingFocus = null;
            if (ready())
                root!.blur();
        },
        rootTag, rootProperties, projectAttributes, portalTarget, adoptControlState,
        commitHost() {
            applyText();
        },
        refresh, mount, unmount,
        dispose() {
            if (disposed)
                return;
            const rootOwner = logicalRoot(owner);
            const failures: unknown[] = [];
            try {
                unmount();
            }
            catch (error) {
                failures.push(error);
            }
            disposed = true;
            owners.delete(options.identity);
            claims.clear();
            hooks.clear();
            topologySubscribers.clear();
            textListeners.clear();
            for (const cleanup of terminalCleanups.splice(0))
                try {
                    cleanup();
                }
                catch (error) {
                    failures.push(error);
                }
            announceTopology(rootOwner);
            if (failures.length)
                throw new AggregateError(failures, '[Modules] terminal cleanup failed.');
        }
    };
    owners.set(options.identity, owner);
    return capabilities;
}
