import Vue from 'vue';
import Component from './Component.js';
const props=Vue.observable({value:'seed',seed:'seed',hint:'before',present:true});
const app=new Vue({render(h){return h(Component,{props:{...props}});}}).$mount();
document.body.append(app.$el);
const child=app.$children[0], trace=[];
let held;
const settle=async()=>{await Vue.nextTick();await Vue.nextTick();await Promise.resolve();};
function observe(label){
 const root=child.$el;
 if(!(root instanceof HTMLInputElement||root instanceof HTMLTextAreaElement))throw new Error('Physical native editor absent');
 const value={tagName:root.tagName,value:root.value,defaultValue:root.defaultValue,rows:root instanceof HTMLTextAreaElement?root.rows:undefined,readOnly:root.readOnly,placeholder:root.placeholder,minLength:root.getAttribute('minlength'),rootMarker:root.getAttribute('data-pui-root'),selection:[root.selectionStart,root.selectionEnd],data:{style:child._vnode.data.style,attrs:child._vnode.data.attrs}};
 trace.push({label,value});return value;
}
window.__nativeEditor={trace,observe,
 async setProps(patch){Object.assign(props,patch);await settle();},
 async repaint(){child.$forceUpdate();await settle();},
 holdEditor(){held=child.$el;},
 staleInput(value){if(!held)throw new Error('Missing retired editor');held.value=value;held.dispatchEvent(new InputEvent('input',{bubbles:true}));return held.isConnected;}
};
await settle();
window.__nativeEditor.observe('mounted');
