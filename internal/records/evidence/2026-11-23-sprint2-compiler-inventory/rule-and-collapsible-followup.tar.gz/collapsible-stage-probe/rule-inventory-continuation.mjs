import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
const root=process.argv[2];
if(!root)throw new Error('Explicit isolated checkout required');
const {parsePrototype,validateIR,compileFile}=await import(pathToFileURL(root+'/packages/compiler/src/index.ts'));
const {FileSourceGraph}=await import(pathToFileURL(root+'/packages/compiler/src/source-loader.ts'));
const hash=x=>createHash('sha256').update(x).digest('hex');
const profiles=['react-runtime-v1','react-dom-source-v1','vue-source-v1','vue2-source-v1','web-component-source-v1'];
const entries=['alert-dialog/action.proto.ts','alert-dialog/cancel.proto.ts','drawer/trigger.proto.ts','drawer/close.proto.ts'].map(x=>'packages/prototypes/shadcn/src/'+x);
console.log(JSON.stringify({stage:'source',root,sourceFiles:Object.fromEntries(['callable-effects.ts','ir-validation.ts','parser.ts','operations.ts'].map(x=>[x,hash(readFileSync(root+'/packages/compiler/src/'+x))])),entries,profiles}));
const counts={pass:0,failed:0};
for(const entry of entries){
 const graph=new FileSourceGraph(root);const snapshot=await graph.load(await graph.entry(root+'/'+entry));
 if(snapshot.failures.length)throw snapshot.failures[0];
 console.log(JSON.stringify({stage:'snapshot',entry,sourceImports:snapshot.sourceImports,files:Object.fromEntries(Object.entries(snapshot.files).map(([p,b])=>[p,hash(b)]))}));
 const source=parsePrototype(snapshot.files[snapshot.entry],{fileName:snapshot.entry,files:snapshot.files,sourceImports:snapshot.sourceImports});
 const cold=source.ok?validateIR(JSON.parse(JSON.stringify(source.value))):null;
 console.log(JSON.stringify({stage:'source-cold',entry,source:source.ok?{ok:true}:source,cold:cold?.ok?{ok:true}:cold}));
 for(const profile of profiles){
  const start=performance.now();const result=await compileFile(entry,{root,profile,sourceSnapshot:snapshot});
  counts[result.ok?'pass':'failed']++;
  console.log(JSON.stringify({stage:'compileFile',entry,profile,elapsedMs:performance.now()-start,result:result.ok?{ok:true,outputBytes:Buffer.byteLength(result.value.output.code),outputSha256:hash(result.value.output.code)}:result}));
 }
}
console.log(JSON.stringify({stage:'summary',expected:20,...counts,peakRssKiB:process.resourceUsage().maxRSS}));
if(counts.failed)process.exitCode=1;
