import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
const root=process.argv[2];
if(!root)throw new Error('Explicit isolated checkout required');
const {parsePrototype,validateIR,compileFile}=await import(pathToFileURL(root+'/packages/compiler/src/index.ts'));
const {FileSourceGraph}=await import(pathToFileURL(root+'/packages/compiler/src/source-loader.ts'));
const digest=(x)=>createHash('sha256').update(x).digest('hex');
console.log(JSON.stringify({stage:'source',root,files:Object.fromEntries(['callable-effects.ts','parser.ts','ir-validation.ts','operations.ts'].map(x=>[x,digest(readFileSync(root+'/packages/compiler/src/'+x))]))}));
const minimal=(declarations,body)=>`import {definePrototype,tw,type DefHandle} from '@proto.ui/core';${declarations}export default definePrototype({name:'rule-phase-probe',setup(def){${body}}});`;
const rule=`def.rule({when:w=>w.t(),intent:i=>i.feedback.style.use(tw('p-1'))});`;
const cases=[
 ['direct',minimal('',rule)],
 ['ordinary helper',minimal(`function paint(def:DefHandle){${rule}}`,'paint(def);')],
 ['ordinary alias',minimal(`function paint(def:DefHandle){const cdef=def;${rule.replaceAll('def.rule','cdef.rule')}}`,'paint(def);')],
 ['ordinary double assertion',minimal(`function paint(def:DefHandle){const cdef=def as unknown as DefHandle;${rule.replaceAll('def.rule','cdef.rule')}}`,'paint(def);')],
 ['ordinary typed variant',minimal(`function paint(def:DefHandle,variant:'first'|'second'){def.rule({when:w=>w.t(),intent:i=>i.feedback.style.use(tw(variant==='first'?'p-1':'p-2'))});}`,"paint(def,'first');")],
 ['helper in callback',minimal(`function paint(def:DefHandle){${rule}}`,"def.lifecycle.onMounted(()=>paint(def));")],
];
function inspect(name,source,options={}) {
 const result=parsePrototype(source,options);const cold=result.ok?validateIR(JSON.parse(JSON.stringify(result.value))):null;
 const declarations=[];const walk=(v,context)=>{if(!v||typeof v!=='object')return;if(Array.isArray(v)){v.forEach(x=>walk(x,context));return;}const next=('parameters'in v&&'body'in v&&'phase'in v)?{phase:v.phase,context:v.context,span:v.span}:context;if(v.kind==='rule')declarations.push({rule:v.span,receiver:v.receiver,context:next});Object.values(v).forEach(x=>walk(x,next));};if(result.ok)walk(result.value,null);
 console.log(JSON.stringify({name,result:result.ok?{ok:true}:result,cold:cold?.ok?{ok:true}:cold,rules:declarations}));
}
for(const [name,source] of cases)inspect(name,source);
for(const entry of ['packages/prototypes/shadcn/src/alert-dialog/action.proto.ts','packages/prototypes/shadcn/src/drawer/trigger.proto.ts']){
 const graph=new FileSourceGraph(root);const snapshot=await graph.load(await graph.entry(root+'/'+entry));
 console.log(JSON.stringify({stage:'snapshot',entry,failures:snapshot.failures.map(String),sourceImports:snapshot.sourceImports,files:Object.fromEntries(Object.entries(snapshot.files).map(([p,b])=>[p,digest(b)]))}));
 if(snapshot.failures.length)throw snapshot.failures[0];
 inspect(entry,snapshot.files[snapshot.entry],{fileName:snapshot.entry,files:snapshot.files,sourceImports:snapshot.sourceImports});
 const result=await compileFile(entry,{root,profile:'web-component-source-v1',sourceSnapshot:snapshot});
 console.log(JSON.stringify({stage:'compileFile',entry,result:result.ok?{ok:true}:result}));
}
