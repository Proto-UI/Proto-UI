import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
const root=process.argv[2];
if(!root)throw new Error('Explicit isolated checkout required');
const {parsePrototype,validateIR,compileFile,TARGET_PROFILES}=await import(pathToFileURL(root+'/packages/compiler/src/index.ts'));
const {FileSourceGraph}=await import(pathToFileURL(root+'/packages/compiler/src/source-loader.ts'));
const hash=x=>createHash('sha256').update(x).digest('hex');
const setup=`setup(def){const flag=def.state.bool('flag',false);def.expose.method('prime',()=>{flag.setDefault(flag.get());});}`;
const input=tail=>`import{definePrototype,defineAsHook}from'@proto.ui/core';${tail}`;
const cases=[
 ['direct prototype guarded method',input(`export default definePrototype({name:'direct-guard',${setup}});`)],
 ['raw hook setup invocation',input(`const install=defineAsHook({name:'raw-guard',${setup}});export default definePrototype({name:'raw-owner',setup(){const capture=install();capture.getMethod?.('prime')?.();}});`)],
 ['raw hook explicit runtime invocation',input(`const install=defineAsHook({name:'raw-guard',${setup}});export default definePrototype({name:'raw-owner',setup(def){const capture=install();def.lifecycle.onMounted(()=>capture.getMethod?.('prime')?.());}});`)],
];
console.log(JSON.stringify({stage:'source',root,callableSha256:hash(readFileSync(root+'/packages/compiler/src/callable-effects.ts'))}));
for(const [name,source] of cases){
 const parsed=parsePrototype(source);const cold=parsed.ok?validateIR(JSON.parse(JSON.stringify(parsed.value))):null;
 console.log(JSON.stringify({stage:'minimal',name,sourceSha256:hash(source),source,result:parsed.ok?{ok:true}:parsed,cold:cold?.ok?{ok:true}:cold}));
}
const entry='packages/prototypes/base/src/collapsible/content.proto.ts';
const graph=new FileSourceGraph(root);const snapshot=await graph.load(await graph.entry(root+'/'+entry));
if(snapshot.failures.length)throw snapshot.failures[0];
console.log(JSON.stringify({stage:'snapshot',entry,files:Object.fromEntries(Object.entries(snapshot.files).map(([p,b])=>[p,hash(b)]))}));
for(const profile of Object.values(TARGET_PROFILES).filter(p=>p.implemented).map(p=>p.id).sort()){
 const start=performance.now();const result=await compileFile(entry,{root,profile,sourceSnapshot:snapshot});
 console.log(JSON.stringify({stage:'compileFile',entry,profile,elapsedMs:performance.now()-start,result:result.ok?{ok:true}:result}));
}
