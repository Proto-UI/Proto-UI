#!/usr/bin/env python3
"""Sample actual descendant RSS of the five assigned jobs; no acceptance inference."""
from pathlib import Path
import datetime,json,os,signal,time
R=Path('/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202')
OUT=R/'results'/'resource-samples-final-5cb80'
JOBS=['full-compiler-general-0-5cb80','full-compiler-general-1-5cb80',
      'full-compiler-browser-5cb80','library-profile-0-5cb80','library-profile-1-5cb80']
OUT.mkdir(parents=True,exist_ok=False)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(p):
    try:return json.loads(p.read_text())
    except (FileNotFoundError,json.JSONDecodeError):return None
def save(name,value,replace=False):
    p=OUT/name
    if replace:
        t=p.with_name(p.name+'.tmp')
        with t.open('x') as f:json.dump(value,f,indent=2)
        t.replace(p)
    else:
        with p.open('x') as f:json.dump(value,f,indent=2)
stop=None
def request(signum,frame):
    global stop
    stop=signum
for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,request)
started=now();started_mono=time.monotonic();births={};peaks={j:0 for j in JOBS};samples=0
metadata={'started':started,'intervalSeconds':2,'jobs':JOBS,
 'scope':'Sampled sum of RSS for launcher and all current descendants; shared pages may be counted more than once. These are sampled peaks only, not kernel lifetime peaks, and earlier execution before this monitor began is not reconstructed.'}
save('plan.json',metadata)
with (OUT/'samples.jsonl').open('x') as log:
    while not stop and time.monotonic()-started_mono<24*60*60:
        processes={}
        for p in Path('/proc').iterdir():
            if not p.name.isdigit():continue
            try:
                fields=(p/'stat').read_text().rsplit(')',1)[1].split()
                processes[int(p.name)]={'ppid':int(fields[1]),'startTicks':int(fields[19]),
                  'rssKiB':int(fields[21])*os.sysconf('SC_PAGE_SIZE')//1024}
            except (OSError,ValueError,IndexError):continue
        data={'at':now(),'jobs':[]}
        finished=0
        for job in JOBS:
            directory=R/'evidence'/job;start=read(directory/'start.json');terminal=read(directory/'result.json')
            row={'id':job,'started':start is not None,'terminal':terminal is not None}
            if terminal is not None:
                row['exitCode']=terminal.get('exitCode');finished+=1
            if start is not None:
                pid=start['pid'];proc=processes.get(pid)
                if proc:
                    births.setdefault(job,proc['startTicks'])
                    if proc['startTicks']==births[job]:
                        pids={pid}
                        changed=True
                        while changed:
                            before=len(pids)
                            pids.update(p for p,v in processes.items() if v['ppid'] in pids)
                            changed=len(pids)!=before
                        row['processes']=[{'pid':p,**processes[p]} for p in sorted(pids)]
                        row['sumRssKiB']=sum(processes[p]['rssKiB'] for p in pids)
                        peaks[job]=max(peaks[job],row['sumRssKiB'])
                    else:row['rootPidReused']=True
            row['sampledPeakRssKiB']=peaks[job]
            data['jobs'].append(row)
        for line in Path('/proc/meminfo').read_text().splitlines():
            if line.startswith('MemAvailable:'):data['memAvailableKiB']=int(line.split()[1])
        log.write(json.dumps(data)+'\n');log.flush();samples+=1
        if samples%5==1:
            save('progress.json',{'started':started,'at':data['at'],'samples':samples,
              'terminalJobs':finished,'sampledPeakRssKiB':peaks,'last':data},True)
        if finished==len(JOBS):break
        time.sleep(2)
summary={**metadata,'ended':now(),'samples':samples,'sampledPeakRssKiB':peaks,
         'allJobsTerminal':all((R/'evidence'/job/'result.json').exists() for job in JOBS),
         'interruptedSignal':stop}
save('summary.json',summary)
print(json.dumps(summary))
