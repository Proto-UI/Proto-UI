#!/usr/bin/env python3
import collections, gzip, hashlib, json, os, pathlib, subprocess, sys

ROOT=pathlib.Path('/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202')
REPO=ROOT/'Proto-UI-final'
NODE='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin/node'
OUT=ROOT/'results/library-profile-merged-5cb80'
RUNS=[ROOT/'results'/name for name in ['library-profile-0-5cb80','library-profile-1-5cb80','library-profile-1-remaining-2048-5cb80']]
OUT.mkdir()
def save(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def command(name,args):
    result=subprocess.run(args,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    save(name,dict(command=args,exitCode=result.returncode,stdout=result.stdout,stderr=result.stderr))
    return result
plan=command('plan-command.json',[NODE,'scripts/compiler/library-profile-inventory.mjs','--output',str(OUT/'expected'),'--plan-only','--heap-mb','1536'])
if plan.returncode: raise SystemExit('Fresh full inventory planning failed')
merged=command('merge-command.json',[NODE,'scripts/compiler/library-profile-inventory.mjs','--merge',str(OUT/'merged.json'),*map(str,RUNS)])
if not (OUT/'merged.json').is_file(): raise SystemExit('Merge produced no report')
gate_source="""import {readFileSync,writeFileSync} from 'node:fs';
import {assertCompleteInventory} from './scripts/ci/compiler-library-inventory.mjs';
const read=p=>JSON.parse(readFileSync(p,'utf8'));
const out=process.argv[1];
const receipt={scope:'Actual local invocation of exported strict inventory predicate; not a GitHub CI run',ok:false};
try{receipt.result=assertCompleteInventory(read(out+'/merged.json'),read(out+'/expected/plan.json'));receipt.ok=true;}
catch(error){receipt.error={name:error.name,code:error.code,message:error.message,actual:error.actual,expected:error.expected,stack:error.stack};process.exitCode=1;}
writeFileSync(out+'/strict-gate.json',JSON.stringify(receipt,null,2)+'\\n');console.log(JSON.stringify(receipt));
"""
gate=command('strict-gate-command.json',[NODE,'--input-type=module','-e',gate_source,str(OUT)])
report=json.loads((OUT/'merged.json').read_text())
groups={}
for row in report['rows']:
    if row['status']!='FAIL': continue
    d=row.get('firstDiagnostic') or {};span=d.get('span') or {};k=(d.get('code'),d.get('message'),span.get('file'),span.get('line'))
    group=groups.setdefault(k,dict(code=k[0],message=k[1],source=k[2],line=k[3],rows=[]))
    group['rows'].append(dict(entry=row['entry'],profile=row['profile'],failureKind=row.get('failureKind'),entrySha256=row['entrySha256'],closure=row.get('closure'),receiptRoot=row.get('receiptRoot')))
save('failure-groups.json',list(groups.values()))
archives=[]
for i,p in enumerate([*[run/'report.json' for run in RUNS],OUT/'merged.json']):
    raw=p.read_bytes();target=OUT/f'report-{i}.json.gz'
    with target.open('xb') as f:
        with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as g:g.write(raw)
    archives.append(dict(source=str(p),sourceBytes=len(raw),sourceSha256=hashlib.sha256(raw).hexdigest(),gzip=str(target),gzipBytes=target.stat().st_size,gzipSha256=hashlib.sha256(target.read_bytes()).hexdigest()))
save('archives.json',archives)
summary=dict(sourceRevision=report['binding'].get('revision'),universeFingerprint=report['universeFingerprint'],counts=report['counts'],admissionCoverageComplete=report['admissionCoverageComplete'],allImplementedEntriesAdmitted=report['allImplementedEntriesAdmitted'],mergeExitCode=merged.returncode,strictGateExitCode=gate.returncode,failedAttempts=report['execution']['failedAttempts'],recordedAttempts=report['execution']['recordedAttempts'],missingProcessReceipts=report['execution']['missingProcessReceipts'],failureGroups=len(groups),untested=[dict(entry=row['entry'],profile=row['profile']) for row in report['rows'] if row['status']=='UNTESTED'])
save('summary.json',summary);print(json.dumps(summary));sys.exit(0 if gate.returncode==0 and merged.returncode==0 else 1)
