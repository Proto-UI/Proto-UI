#!/usr/bin/env python3
"""Bounded Compiler execution. Raw Vitest JSON remains the observation authority.

Zero-based shards partition sorted phase files by index % shard_count.
A pass covers only that selection; plans and skipped assertions never pass.
"""
from pathlib import Path
from collections import Counter
import argparse
import datetime
import hashlib
import json
import os
import re
import signal
import subprocess
import sys
import time

BROWSER_NAMES = frozenset({
    'browser-button-ssr.test.ts', 'browser-differential.test.ts',
    'browser-native-lifecycle.test.ts', 'browser-pointer-props.test.ts',
    'browser-source-presentation.test.ts', 'browser-update-intent.test.ts',
    'control-label-native.browser.test.ts', 'focus-scope-native.browser.test.ts',
    'presence-presentation.browser.test.ts', 'shader-presentation.browser.test.ts',
    'sprint1-ownership.browser.test.ts', 'sprint2-native.browser.test.ts',
    'transition-native.browser.test.ts', 'vue2-native-editor.browser.test.ts',
    'web-component-native.browser.test.ts',
})

# These browser-compiler unit/Happy DOM/build suites do not launch a real browser.
GENERAL_BROWSER_NAMES = frozenset({
    'browser-client.test.ts', 'browser-panel-retirement.test.ts',
    'browser-preview-retirement.test.ts', 'browser-revision-session.test.ts',
    'browser-target-consumer.test.ts', 'browser-wasm.test.ts',
})


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha_bytes(value):
    return hashlib.sha256(value).hexdigest()


def write_json(path, value, *, replace_owned=False):
    """Evidence is created once; only our own progress checkpoint is replaceable."""
    data = json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    if replace_owned:
        temporary = path.with_name(path.name + '.tmp')
        with temporary.open('x', encoding='utf-8') as handle:
            handle.write(data)
        temporary.replace(path)
    else:
        with path.open('x', encoding='utf-8') as handle:
            handle.write(data)


def git(repo, *args):
    return subprocess.check_output(
        ['git', *args], cwd=repo, timeout=30,
        env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'},
    ).decode('utf-8', errors='surrogateescape')


def source_snapshot(repo, expected):
    """Failed source inspection is a failed guard, never a clean checkout."""
    observation = {'at': stamp(), 'expectedHead': expected}
    try:
        observation['head'] = git(repo, 'rev-parse', 'HEAD').strip()
        status = git(repo, 'status', '--porcelain=v1', '-z', '--untracked-files=all',
                     '--ignore-submodules=none')
        observation['porcelainV1Z'] = status
        observation['statusSha256'] = sha_bytes(status.encode('utf-8', errors='surrogateescape'))
        observation['headMatches'] = observation['head'] == expected
        observation['clean'] = not status
        observation['ok'] = observation['headMatches'] and observation['clean']
    except Exception as error:
        observation.update(ok=False, clean=False, headMatches=False, error=repr(error))
    return observation


def parse_shard(value):
    if not re.fullmatch(r'\d+/\d+', value):
        raise argparse.ArgumentTypeError('shard must be zero-based i/n, for example 0/4')
    slot, count = map(int, value.split('/'))
    if count < 1 or slot >= count:
        raise argparse.ArgumentTypeError('shard requires 0 <= i < n and n >= 1')
    return slot, count


def select_files(all_files, phase, shard):
    browsers = [p for p in all_files if Path(p).name in BROWSER_NAMES]
    observed = Counter(Path(p).name for p in browsers)
    missing = sorted(BROWSER_NAMES - observed.keys())
    duplicate = sorted(name for name, count in observed.items() if count != 1)
    unclassified = [p for p in all_files if (
        Path(p).name.startswith('browser-') or Path(p).name.endswith('.browser.test.ts')
    ) and p not in browsers and Path(p).name not in GENERAL_BROWSER_NAMES]
    if missing or duplicate or unclassified:
        raise ValueError(f'Browser inventory drift: missing={missing}, duplicate={duplicate}, '
                         f'unclassified={unclassified}; update the explicit launch inventory')
    phase_files = browsers if phase == 'browser' else [p for p in all_files if p not in browsers]
    slot, count = shard
    selected = [p for i, p in enumerate(phase_files) if i % count == slot]
    if not selected:
        raise ValueError(f'Empty selection for phase {phase}, shard {slot}/{count}')
    return browsers, phase_files, selected


def inspect_report(report, repo, files):
    """Negative/missing/unknown observations cannot be promoted by success:true."""
    result = {'completeInventory': False, 'allAssertionsPassed': False,
              'missingFiles': list(files), 'unexpectedFiles': [], 'duplicateFiles': [],
              'counts': {}, 'reportErrors': []}
    if not report.is_file():
        result['reportErrors'].append('Missing Vitest JSON report')
        return result
    raw = report.read_bytes()
    result['reportSha256'] = sha_bytes(raw)
    try:
        data = json.loads(raw)
        if not isinstance(data, dict) or not isinstance(data.get('testResults'), list):
            raise ValueError('Report must contain a testResults array')
        names, assertions, empty_files, bad_files = [], [], [], []
        for observation in data['testResults']:
            name = observation.get('name')
            if not isinstance(name, str):
                raise ValueError('A reported file has no string name')
            absolute = Path(name) if Path(name).is_absolute() else repo / name
            try:
                name = str(absolute.resolve().relative_to(repo))
            except ValueError:
                name = str(absolute.resolve())
            names.append(name)
            items = observation.get('assertionResults')
            if not isinstance(items, list):
                raise ValueError(f'Missing assertionResults for {name}')
            if not items:
                empty_files.append(name)
            if observation.get('status') != 'passed':
                bad_files.append({'file': name, 'status': observation.get('status')})
            for item in items:
                if not isinstance(item, dict) or not isinstance(item.get('status'), str):
                    raise ValueError(f'Malformed assertion in {name}')
            assertions.extend(items)
        name_counts = Counter(names)
        result.update(
            missingFiles=[p for p in files if p not in name_counts],
            unexpectedFiles=sorted(set(names) - set(files)),
            duplicateFiles=sorted(p for p, count in name_counts.items() if count != 1),
            emptyAssertionFiles=empty_files, nonPassingFiles=bad_files,
            counts=dict(sorted(Counter(item['status'] for item in assertions).items())),
            reportedSuccess=data.get('success') is True,
        )
        if data.get('numTotalTests') != len(assertions):
            result['reportErrors'].append('numTotalTests differs from reported assertions')
        if data.get('numPassedTests') != sum(item['status'] == 'passed' for item in assertions):
            result['reportErrors'].append('numPassedTests differs from reported passed assertions')
        result['completeInventory'] = not any(result[key] for key in (
            'missingFiles', 'unexpectedFiles', 'duplicateFiles'))
        result['allAssertionsPassed'] = (
            bool(assertions) and not empty_files and not bad_files
            and all(item['status'] == 'passed' for item in assertions)
            and not result['reportErrors']
        )
    except Exception as error:
        result['reportErrors'].append(repr(error))
    return result


class StopRequest:
    signum = None

    def receive(self, signum, _frame):
        self.signum = signum


def terminate_owned_group(child):
    """Only target the process group created by this supervisor."""
    if child.poll() is not None:
        return
    try:
        os.killpg(child.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        child.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        child.wait(timeout=5)


def supervise(argv, repo, env, log_path, watch_source, stop, timeout_seconds, poll_seconds):
    begin = time.monotonic()
    row = {'command': argv, 'started': stamp(), 'exitCode': None, 'signal': None,
           'executionError': None, 'sourceBefore': watch_source(), 'sourcePolls': 0}
    child = None
    try:
        with log_path.open('xb') as log:
            if not row['sourceBefore']['ok']:
                row['executionError'] = 'Source changed before batch launch'
            elif stop.signum is not None:
                row['executionError'] = f'Wrapper interrupted by signal {stop.signum}'
            else:
                child = subprocess.Popen(argv, cwd=repo, env=env, stdout=log,
                                         stderr=subprocess.STDOUT, start_new_session=True)
                row['pid'] = child.pid
                while child.poll() is None:
                    observation = watch_source()
                    row['sourcePolls'] += 1
                    if not observation['ok']:
                        row['sourceViolation'] = observation
                        row['executionError'] = 'Source HEAD or working tree changed during batch'
                    elif stop.signum is not None:
                        row['executionError'] = f'Wrapper interrupted by signal {stop.signum}'
                    elif time.monotonic() - begin >= timeout_seconds:
                        row['executionError'] = f'Batch timed out after {timeout_seconds} seconds'
                    if row['executionError']:
                        terminate_owned_group(child)
                        break
                    try:
                        child.wait(timeout=min(poll_seconds, max(
                            0.01, timeout_seconds - (time.monotonic() - begin))))
                    except subprocess.TimeoutExpired:
                        pass
                row['exitCode'] = child.wait()
                if row['exitCode'] < 0:
                    row['signal'] = signal.Signals(-row['exitCode']).name
    except Exception as error:
        row['executionError'] = repr(error)
        if child is not None:
            terminate_owned_group(child)
            row['exitCode'] = child.returncode
    finally:
        row['sourceAfter'] = watch_source()
        row['sourceStable'] = (row['sourceBefore']['ok'] and row['sourceAfter']['ok']
                               and 'sourceViolation' not in row)
        if stop.signum is not None:
            row['executionError'] = row['executionError'] or f'Wrapper interrupted by signal {stop.signum}'
        if not row['sourceStable']:
            row['executionError'] = row['executionError'] or 'Source changed before or after batch'
        row.update(ended=stamp(), durationSeconds=time.monotonic() - begin)
        if log_path.is_file():
            row['logSha256'] = sha_bytes(log_path.read_bytes())
    return row


def execution_passed(row):
    return bool(row.get('exitCode') == 0 and row.get('signal') is None
                and row.get('executionError') is None and row.get('sourceStable') is True
                and row.get('reportedSuccess') is True and row.get('completeInventory') is True
                and row.get('allAssertionsPassed') is True)


def parse_args(argv):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repo', type=Path)
    parser.add_argument('output', type=Path, help='new directory outside checkout; never overwritten')
    parser.add_argument('expected', help='exact full source commit SHA')
    parser.add_argument('phase', nargs='?', choices=('general', 'browser'), default='general')
    parser.add_argument('--shard', type=parse_shard, default=(0, 1))
    parser.add_argument('--batch-size', type=int, default=os.environ.get('PUI_COMPILER_BATCH_SIZE', '1'))
    parser.add_argument('--heap-mb', type=int, default=os.environ.get('PUI_COMPILER_HEAP_MB', '1536'))
    parser.add_argument('--timeout-seconds', type=float, default=600)
    parser.add_argument('--poll-seconds', type=float, default=1)
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args(argv)
    if not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}', args.expected):
        parser.error('expected must be an exact full lower-case commit SHA')
    if args.batch_size < 1 or not 256 <= args.heap_mb <= 8192:
        parser.error('batch-size must be positive; heap-mb must be between 256 and 8192')
    if not 0 < args.poll_seconds <= 10 or not 0 < args.timeout_seconds < float('inf'):
        parser.error('poll-seconds must be in (0,10]; timeout-seconds must be finite and positive')
    return args


def main(argv=None):
    args = parse_args(argv)
    repo, requested_output = args.repo.resolve(), args.output.absolute()
    output = requested_output.resolve()
    if requested_output.exists() or requested_output.is_symlink() or output.exists():
        print(f'Refusing existing output: {requested_output}', file=sys.stderr)
        return 2
    if output == repo or repo in output.parents:
        print('Evidence output must be outside the checkout', file=sys.stderr)
        return 2
    output.parent.mkdir(parents=True, exist_ok=True)
    try:
        output.mkdir(exist_ok=False)
    except FileExistsError:
        print(f'Refusing concurrently created output: {output}', file=sys.stderr)
        return 2
    stop, old_handlers = StopRequest(), {}
    results, plan = [], None
    source_before = source_snapshot(repo, args.expected)
    try:
        if not source_before['ok']:
            raise ValueError(f'Checkout must match expected HEAD and be clean: {source_before}')
        root = Path(git(repo, 'rev-parse', '--show-toplevel').strip()).resolve()
        if root != repo:
            raise ValueError(f'repo must be the checkout root: {root}')
        all_files = sorted(p for p in git(repo, 'ls-files', '-z', 'packages/compiler').split('\0')
                           if p.endswith('.test.ts'))
        browser_files, phase_files, selected = select_files(all_files, args.phase, args.shard)
        node = subprocess.check_output(['node', '--version'], text=True, timeout=10).strip()
        vitest = repo / 'node_modules/vitest/vitest.mjs'
        if not vitest.is_file():
            raise ValueError(f'Missing installed Vitest: {vitest}')
        plan = {
            'schema': 'proto-ui.compiler-batches.v2', 'head': args.expected,
            'tree': git(repo, 'rev-parse', 'HEAD^{tree}').strip(), 'started': stamp(),
            'repo': str(repo), 'output': str(output), 'phase': args.phase,
            'allFiles': all_files, 'browserFiles': browser_files, 'phaseFiles': phase_files,
            'selectedFiles': selected, 'shard': list(args.shard),
            'selectionRule': 'sorted phaseFiles index % shard[1] == shard[0], zero-based',
            'testFileSha256': {p: sha_bytes((repo / p).read_bytes()) for p in all_files},
            'batchSize': args.batch_size, 'heapMb': args.heap_mb,
            'timeoutSeconds': args.timeout_seconds, 'sourcePollSeconds': args.poll_seconds,
            'node': node, 'scriptSha256': sha_bytes(Path(__file__).read_bytes()),
            'vitestEntrySha256': sha_bytes(vitest.read_bytes()), 'sourceBefore': source_before,
            'executionRequested': not args.plan_only,
            'boundary': ('Pass covers only this exact phase/shard. Full Compiler coverage requires '
                         'both phases and every shard with the same source and script. Skipped/TODO/'
                         'unknown assertions, signals, failed/missing receipts and source changes '
                         'never pass. All tracked changes and all nonignored untracked paths are '
                         'forbidden; normal Git ignores remain. Source guards are sampled at the '
                         'stated interval and before/after each batch.'),
        }
        write_json(output / 'plan.json', plan)
        if args.plan_only:
            source_after = source_snapshot(repo, args.expected)
            write_json(output / 'summary.json', {
                'head': args.expected, 'phase': args.phase, 'shard': list(args.shard),
                'executionStatus': 'planned-only', 'passedExecution': False,
                'allBatchesExecuted': False, 'selectedFiles': selected, 'results': [],
                'sourceBefore': source_before, 'sourceAfter': source_after, 'ended': stamp(),
            })
            print(json.dumps({'executionStatus': 'planned-only', 'selectedFiles': len(selected),
                              'passedExecution': False}), flush=True)
            return 0 if source_after['ok'] else 1
        for sig in (signal.SIGINT, signal.SIGTERM):
            old_handlers[sig] = signal.signal(sig, stop.receive)
        env = {**os.environ, 'NODE_OPTIONS': f'--max-old-space-size={args.heap_mb}'}
        watch = lambda: source_snapshot(repo, args.expected)
        abort_reason = None
        for index, start in enumerate(range(0, len(selected), args.batch_size)):
            files = selected[start:start + args.batch_size]
            name = f'batch-{index:03}'
            report = output / (name + '.vitest.json')
            command = ['node', str(vitest), 'run', *files, '--maxWorkers=1', '--minWorkers=1',
                       '--no-file-parallelism', '--reporter=default', '--reporter=json',
                       '--outputFile=' + str(report)]
            row = supervise(command, repo, env, output / (name + '.log'), watch, stop,
                            args.timeout_seconds, args.poll_seconds)
            row.update(id=name, files=files)
            row.update(inspect_report(report, repo, files))
            row['passedExecution'] = execution_passed(row)
            results.append(row)
            write_json(output / (name + '.receipt.json'), row)
            write_json(output / 'progress.json', {
                'head': args.expected, 'phase': args.phase, 'shard': list(args.shard),
                'selectedFiles': selected, 'completedBatches': len(results), 'results': results,
                'passedExecution': False, 'executionStatus': 'running',
            }, replace_owned=True)
            print(json.dumps({key: row[key] for key in (
                'id', 'exitCode', 'signal', 'passedExecution', 'durationSeconds', 'counts',
                'executionError')}), flush=True)
            if not row['sourceStable'] or stop.signum is not None:
                abort_reason = row['executionError'] or 'Source guard or wrapper interruption'
                break
        source_after = watch()
        executed = [p for row in results if row.get('pid') is not None for p in row['files']]
        finished = {
            'schema': plan['schema'], 'head': args.expected, 'tree': plan['tree'],
            'scriptSha256': plan['scriptSha256'], 'ended': stamp(), 'phase': args.phase,
            'shard': list(args.shard), 'allFiles': all_files, 'phaseFiles': phase_files,
            'selectedFiles': selected, 'unlaunchedFiles': [p for p in selected if p not in executed],
            'allBatchesExecuted': executed == selected,
            'sourceBefore': source_before, 'sourceAfter': source_after,
            'sourceHeadStable': source_before['headMatches'] and source_after['headMatches']
                                and all(row['sourceStable'] for row in results),
            'sourceCleanBeforeAfter': source_before['clean'] and source_after['clean'],
            'abortReason': abort_reason, 'wrapperSignal': stop.signum, 'results': results,
        }
        finished['passedExecution'] = bool(
            finished['allBatchesExecuted'] and source_after['ok'] and abort_reason is None
            and stop.signum is None and results and all(row['passedExecution'] for row in results))
        finished['executionStatus'] = 'passed' if finished['passedExecution'] else 'failed'
        write_json(output / 'summary.json', finished)
        return 0 if finished['passedExecution'] else 1
    except Exception as error:
        failure = {'head': args.expected, 'ended': stamp(), 'phase': args.phase,
                   'shard': list(args.shard), 'executionStatus': 'failed',
                   'passedExecution': False, 'allBatchesExecuted': False,
                   'executionError': repr(error), 'sourceBefore': source_before,
                   'sourceAfter': source_snapshot(repo, args.expected), 'results': results}
        target = output / ('fatal-error.json' if (output / 'summary.json').exists() else 'summary.json')
        write_json(target, failure)
        print(str(error), file=sys.stderr)
        return 2
    finally:
        for sig, handler in old_handlers.items():
            signal.signal(sig, handler)


if __name__ == '__main__':
    sys.exit(main())
