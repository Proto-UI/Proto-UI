from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys

ROOT = Path('/tmp/s5-native-scroll-sync-f7b2-v3')
OUT = ROOT / 'native-evidence'
OUT.mkdir(exist_ok=False)
FLUTTER = Path('/tmp/scope1191-native-sdk-acquisition-1113/sdk/flutter/bin/flutter')
ENV = dict(os.environ)
ENV.update({'CI': 'true', 'FLUTTER_SUPPRESS_ANALYTICS': 'true',
            'DART_SUPPRESS_ANALYTICS': 'true', 'PUB_CACHE': '/home/ezra/.pub-cache'})
receipt = json.loads((ROOT / 'source-receipt.json').read_text())
STATE = {
    'schemaVersion': 1,
    'task': 'Sprint 5 current experimental Flutter native Scroll consumer',
    'controller': 'ChatGPT GPT-6 Astra Pro; auxiliary native consumer, no remote model seat',
    'authorization': 'Current user instruction to complete Sprint 5; root-provided exact artifact',
    'container': 'doescontainer/agent-proto-dev',
    'pane': 's5-flutter-sync-v3-f7b2:0.0',
    'attach': 'ssh -t doescontainer docker exec -it agent-proto-dev tmux attach -t s5-flutter-sync-v3-f7b2',
    'workspace': str(ROOT), 'status': 'running',
    'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'flutter': str(FLUTTER), 'pubCache': ENV['PUB_CACHE'],
    'expectedCases': receipt['expectedDartCases'],
    'publicProfileActivated': False, 'vitestWrapperExecuted': False,
    'execution': 'Direct execution of the exact parser/emitter and original wrapper prepared artifact',
    'commands': [],
}


def save():
    (OUT / 'status.json').write_text(json.dumps(STATE, indent=2) + '\n')


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def run(name, args):
    item = {'name': name, 'command': args,
            'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    STATE['commands'].append(item)
    save()
    print('[flutter] ' + name + ': ' + ' '.join(args), flush=True)
    log = OUT / (name + '.log')
    with log.open('wb') as output:
        process = subprocess.Popen(args, cwd=ROOT, env=ENV, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT)
        for line in iter(process.stdout.readline, b''):
            output.write(line)
            output.flush()
            sys.stdout.buffer.write(line)
            sys.stdout.buffer.flush()
        code = process.wait()
    item.update(exitCode=code, log=str(log), sha256=sha(log),
                finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
    return code == 0


def execute():
    inputs = {item['path']: item['sha256'] for item in receipt['files']}
    actual = {p: sha(ROOT / p) for p in inputs}
    if actual != inputs:
        raise RuntimeError('Imported Flutter artifacts differ from exact source receipt')
    STATE['inputsBefore'] = actual
    STATE['sourceReceiptSha256'] = sha(ROOT / 'source-receipt.json')
    save()
    if not run('flutter-version', [str(FLUTTER), '--version', '--machine']):
        return False
    if not run('pub-get', [str(FLUTTER), 'pub', 'get', '--offline']):
        return False
    if not run('widget-consumer', [str(FLUTTER), 'test', '--no-pub', '--reporter', 'expanded',
                                  'test/consumer_test.dart']):
        return False
    log = (OUT / 'widget-consumer.log').read_text()
    if not re.search(r'\+17:\s+All tests passed!', log):
        raise RuntimeError('All 17 actual Widget cases did not execute')
    STATE['nativeCases'] = {'passed': 17, 'failed': 0}
    return True


save()
try:
    STATE['status'] = 'passed' if execute() else 'failed'
except Exception as error:
    STATE.update(status='failed', error=repr(error))
    print('[flutter] ' + repr(error), flush=True)
finally:
    STATE['inputsAfter'] = {item['path']: sha(ROOT / item['path']) for item in receipt['files']}
    STATE['generatedSourceDrift'] = [item['path'] for item in receipt['files']
                                   if STATE['inputsAfter'][item['path']] != item['sha256']]
    if STATE['generatedSourceDrift']:
        STATE['status'] = 'failed'
    STATE['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print('[flutter] final ' + STATE['status'] + '; receipt ' + str(OUT / 'status.json'), flush=True)
sys.exit(0 if STATE['status'] == 'passed' else 1)

