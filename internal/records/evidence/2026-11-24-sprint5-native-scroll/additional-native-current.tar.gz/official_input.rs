// Direct checked-source GPUI component. Supporting files are ordinary editable Rust.
  #[cfg(panic = "abort")] compile_error!("Authored exception lowering requires panic=unwind");
  pub use proto_ui_gpui_native as native;
  pub use native::gpui_native_owner::{ControlLabelRef, InstanceAssociations};
  use gpui::{prelude::*, App, Context, FocusHandle, Subscription, Window};
  use std::rc::Rc;
  use serde_json::Value as Json;
  use native::gpui_native_owner::*;
  
  
  fn style_vocabulary() -> &'static native::gpui_native_style::StyleVocabulary {
      static VOCABULARY: std::sync::OnceLock<native::gpui_native_style::StyleVocabulary> = std::sync::OnceLock::new();
      VOCABULARY.get_or_init(|| native::gpui_native_style::StyleVocabulary::from_json(include_str!(".proto-ui/fixtures/style-tokens.json")).expect("compiler-produced style vocabulary"))
  }
  fn accepts_context(key: &str, value: &Json) -> bool {
      match key {
          
          _ => false,
      }
  }
  fn accepts_props(value: &Json) -> bool { value.is_object() && value.get("value").map_or(true, |prop| prop.is_null() || prop.is_string()) && value.get("defaultValue").map_or(true, |prop| prop.is_null() || prop.is_string()) && value.get("disabled").map_or(true, |prop| prop.is_null() || prop.is_boolean()) && value.get("readOnly").map_or(true, |prop| prop.is_null() || prop.is_boolean()) && value.get("placeholder").map_or(true, |prop| prop.is_null() || prop.is_string()) && value.get("required").map_or(true, |prop| prop.is_null() || prop.is_boolean()) && value.get("name").map_or(true, |prop| prop.is_null() || prop.is_string()) && value.get("autoComplete").map_or(true, |prop| prop.is_null() || prop.is_string()) && value.get("minLength").map_or(true, |prop| prop.is_null() || prop.as_f64().is_some_and(f64::is_finite)) && value.get("maxLength").map_or(true, |prop| prop.is_null() || prop.as_f64().is_some_and(f64::is_finite)) && value.get("inputMode").map_or(true, |prop| prop.is_null() || (prop.as_str() == Some("none") || prop.as_str() == Some("text") || prop.as_str() == Some("tel") || prop.as_str() == Some("url") || prop.as_str() == Some("email") || prop.as_str() == Some("numeric") || prop.as_str() == Some("decimal") || prop.as_str() == Some("search"))) && value.get("enterKeyHint").map_or(true, |prop| prop.is_null() || (prop.as_str() == Some("enter") || prop.as_str() == Some("done") || prop.as_str() == Some("go") || prop.as_str() == Some("next") || prop.as_str() == Some("previous") || prop.as_str() == Some("search") || prop.as_str() == Some("send"))) && value.get("ariaLabel").map_or(true, |prop| prop.is_null() || prop.is_string()) && value.get("labelledBy").map_or(true, |prop| prop.is_null() || prop.is_string()) && value.get("describedBy").map_or(true, |prop| prop.is_null() || prop.is_string()) }
  fn prop_valid(key: &str, value: &Json) -> bool { match key { "value" => value.is_string(),
        "defaultValue" => value.is_string(),
        "disabled" => value.is_boolean(),
        "readOnly" => value.is_boolean(),
        "placeholder" => value.is_string(),
        "required" => value.is_boolean(),
        "name" => value.is_string(),
        "autoComplete" => value.is_string(),
        "minLength" => value.as_f64().is_some_and(f64::is_finite),
        "maxLength" => value.as_f64().is_some_and(f64::is_finite),
        "inputMode" => (value.as_str() == Some("none") || value.as_str() == Some("text") || value.as_str() == Some("tel") || value.as_str() == Some("url") || value.as_str() == Some("email") || value.as_str() == Some("numeric") || value.as_str() == Some("decimal") || value.as_str() == Some("search")),
        "enterKeyHint" => (value.as_str() == Some("enter") || value.as_str() == Some("done") || value.as_str() == Some("go") || value.as_str() == Some("next") || value.as_str() == Some("previous") || value.as_str() == Some("search") || value.as_str() == Some("send")),
        "ariaLabel" => value.is_string(),
        "labelledBy" => value.is_string(),
        "describedBy" => value.is_string(), _ => false } }
  fn check_method(name: &str, arguments: &[Value]) { match name {
          "focusSelf" => if !(arguments.len() <= 1 && arguments.get(0).map_or(true, |value| matches!(value, Value::Undefined) || (value).try_data().is_some_and(|data| (data.is_object() && data.get("reason").map_or(true, |field| (field.as_str() == Some("programmatic") || field.as_str() == Some("keyboard") || field.as_str() == Some("pointer"))) && data.get("preventScroll").map_or(true, |field| field.is_boolean()))))) { value_type_error("invalid exposed method arguments") },
        "blurSelf" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "resetValue" => if !(arguments.len() <= 1 && arguments.get(0).map_or(true, |value| matches!(value, Value::Undefined) || (value).try_data().is_some_and(|data| data.is_string()))) { value_type_error("invalid exposed method arguments") },
          _ => value_error("unknown exposed method"),
  } }
  
  #[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
#[serde(untagged)]
pub enum GeneratedData1 {
    Alternative0(String),
    Alternative1(String),
    Alternative2(String),
    Alternative3(String),
    Alternative4(String),
    Alternative5(String),
    Alternative6(String),
    Alternative7(String),
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
#[serde(untagged)]
pub enum GeneratedData2 {
    Alternative0(String),
    Alternative1(String),
    Alternative2(String),
    Alternative3(String),
    Alternative4(String),
    Alternative5(String),
    Alternative6(String),
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData0 {
    #[serde(rename = "value", default, skip_serializing_if = "Option::is_none")]
    pub field_0: Option<String>,
    #[serde(rename = "defaultValue", default, skip_serializing_if = "Option::is_none")]
    pub field_1: Option<String>,
    #[serde(rename = "disabled", default, skip_serializing_if = "Option::is_none")]
    pub field_2: Option<bool>,
    #[serde(rename = "readOnly", default, skip_serializing_if = "Option::is_none")]
    pub field_3: Option<bool>,
    #[serde(rename = "placeholder", default, skip_serializing_if = "Option::is_none")]
    pub field_4: Option<String>,
    #[serde(rename = "required", default, skip_serializing_if = "Option::is_none")]
    pub field_5: Option<bool>,
    #[serde(rename = "name", default, skip_serializing_if = "Option::is_none")]
    pub field_6: Option<String>,
    #[serde(rename = "autoComplete", default, skip_serializing_if = "Option::is_none")]
    pub field_7: Option<String>,
    #[serde(rename = "minLength", default, skip_serializing_if = "Option::is_none")]
    pub field_8: Option<f64>,
    #[serde(rename = "maxLength", default, skip_serializing_if = "Option::is_none")]
    pub field_9: Option<f64>,
    #[serde(rename = "inputMode", default, skip_serializing_if = "Option::is_none")]
    pub field_10: Option<GeneratedData1>,
    #[serde(rename = "enterKeyHint", default, skip_serializing_if = "Option::is_none")]
    pub field_11: Option<GeneratedData2>,
    #[serde(rename = "ariaLabel", default, skip_serializing_if = "Option::is_none")]
    pub field_12: Option<String>,
    #[serde(rename = "labelledBy", default, skip_serializing_if = "Option::is_none")]
    pub field_13: Option<String>,
    #[serde(rename = "describedBy", default, skip_serializing_if = "Option::is_none")]
    pub field_14: Option<String>,
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
#[serde(untagged)]
pub enum GeneratedData4 {
    Alternative0(String),
    Alternative1(String),
    Alternative2(String),
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData3 {
    #[serde(rename = "reason", default, skip_serializing_if = "Option::is_none")]
    pub field_0: Option<GeneratedData4>,
    #[serde(rename = "preventScroll", default, skip_serializing_if = "Option::is_none")]
    pub field_1: Option<bool>,
}
  
  pub type GeneratedProps = GeneratedData0;
  fn authored_hook_0(definition: Value, input: Value) -> Value {
    let owner = definition.owner();
    authored_hook(&owner, "as-input-editor", "once", input, { let owner = owner.clone();  Value::Function(Rc::new(move |arguments: Vec<Value>| {
        let v_646566: Value = arg(&arguments, 0);
        let v_636f6e74726f6c: LexicalBinding<Value> = lexical_binding();
        let v_666f63757361626c655f5f38363131313032356366613766623661: LexicalBinding<Value> = lexical_binding();
        let v_76616c7565: LexicalBinding<Value> = lexical_binding();
        let v_64697361626c6564: LexicalBinding<Value> = lexical_binding();
        let v_726561644f6e6c79: LexicalBinding<Value> = lexical_binding();
        let v_636f6d706f73696e67: LexicalBinding<Value> = lexical_binding();
        let v_617269614c6162656c: LexicalBinding<Value> = lexical_binding();
        let v_6c6162656c6c65644279: LexicalBinding<Value> = lexical_binding();
        let v_6465736372696265644279: LexicalBinding<Value> = lexical_binding();
        let v_63757272656e7456696577: LexicalBinding<Rc<std::cell::RefCell<Value>>> = lexical_binding();
        let v_7669657745706f6368: LexicalBinding<Rc<std::cell::RefCell<f64>>> = lexical_binding();
        let v_73796e63: LexicalBinding<Value> = lexical_binding();
        let v_656d6974436f6d706f736974696f6e: LexicalBinding<Value> = lexical_binding();
        // Source "packages/prototypes/base/src/input/root.proto.ts":30:9
        let v_61636365737369626c65 = native_builtin_hook(&owner, "asAccessible", || as_accessible(&owner));
        // Source "packages/prototypes/base/src/input/root.proto.ts":31:3
        { let v_7075695f6e61746976655f30 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f313e = record(vec![("value", record(vec![("type", Value::string("string")), ("empty", Value::string("fallback"))])), ("defaultValue", record(vec![("type", Value::string("string")), ("empty", Value::string("fallback"))])), ("disabled", record(vec![("type", Value::string("boolean")), ("empty", Value::string("fallback"))])), ("readOnly", record(vec![("type", Value::string("boolean")), ("empty", Value::string("fallback"))])), ("placeholder", record(vec![("type", Value::string("string")), ("empty", Value::string("fallback"))])), ("required", record(vec![("type", Value::string("boolean")), ("empty", Value::string("fallback"))])), ("name", record(vec![("type", Value::string("string")), ("empty", Value::string("fallback"))])), ("autoComplete", record(vec![("type", Value::string("string")), ("empty", Value::string("fallback"))])), ("minLength", record(vec![("type", Value::string("number")), ("empty", Value::string("fallback"))])), ("maxLength", record(vec![("type", Value::string("number")), ("empty", Value::string("fallback"))])), ("inputMode", record(vec![("type", Value::string("enum")), ("empty", Value::string("fallback")), ("options", Value::Array(Rc::new(vec![Value::string("none"), Value::string("text"), Value::string("tel"), Value::string("url"), Value::string("email"), Value::string("numeric"), Value::string("decimal"), Value::string("search")])))])), ("enterKeyHint", record(vec![("type", Value::string("enum")), ("empty", Value::string("fallback")), ("options", Value::Array(Rc::new(vec![Value::string("enter"), Value::string("done"), Value::string("go"), Value::string("next"), Value::string("previous"), Value::string("search"), Value::string("send")])))])), ("ariaLabel", record(vec![("type", Value::string("string")), ("empty", Value::string("fallback"))])), ("labelledBy", record(vec![("type", Value::string("string")), ("empty", Value::string("fallback"))])), ("describedBy", record(vec![("type", Value::string("string")), ("empty", Value::string("fallback"))]))]); let v_7075695f6e61746976655f32 = props_define(&owner, v_3c636170747572653a7075695f6e61746976655f313e.clone()); capture_effect(&owner, "props", record(vec![("op", Value::string("define")), ("specMap", v_3c636170747572653a7075695f6e61746976655f313e.clone())]));    v_7075695f6e61746976655f32 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":56:3
        { let v_7075695f6e61746976655f33 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f343e = record(vec![("defaultValue", Value::string("")), ("disabled", Value::boolean(false)), ("readOnly", Value::boolean(false)), ("placeholder", Value::string("")), ("required", Value::boolean(false)), ("name", Value::string("")), ("autoComplete", Value::string("")), ("minLength", Value::number(-(1.0_f64))), ("maxLength", Value::number(-(1.0_f64))), ("ariaLabel", Value::string("")), ("labelledBy", Value::string("")), ("describedBy", Value::string(""))]); let v_7075695f6e61746976655f35 = set_defaults(&owner, v_3c636170747572653a7075695f6e61746976655f343e.clone()); capture_effect(&owner, "props", record(vec![("op", Value::string("setDefaults")), ("partial", v_3c636170747572653a7075695f6e61746976655f343e.clone())]));    v_7075695f6e61746976655f35 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":71:9
        v_636f6e74726f6c.initialize(native_builtin_hook(&owner, "asTextControl", || text_setup(&owner)));
        // Source "packages/prototypes/base/src/input/root.proto.ts":72:9
        v_666f63757361626c655f5f38363131313032356366613766623661.initialize(native_builtin_hook(&owner, "asFocusable", || as_focusable(&owner)));
        // Source "packages/prototypes/base/src/input/root.proto.ts":73:3
        { let v_7075695f6e61746976655f36 = v_666f63757361626c655f5f38363131313032356366613766623661.read(); focus_setup_config(&(v_7075695f6e61746976655f36.clone()).owner(), "focus", record(vec![("disabled", Value::boolean(false))])) };
        // Source "packages/prototypes/base/src/input/root.proto.ts":74:9
        v_76616c7565.initialize({ let v_7075695f6e61746976655f37 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f383e = Value::string("value"); let v_3c636170747572653a7075695f6e61746976655f393e = Value::string(""); let v_7075695f6e61746976655f3130 = create_state(&owner, "string", v_3c636170747572653a7075695f6e61746976655f383e.clone(), v_3c636170747572653a7075695f6e61746976655f393e.clone(), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3130.clone());    v_7075695f6e61746976655f3130 } });
        // Source "packages/prototypes/base/src/input/root.proto.ts":75:9
        v_64697361626c6564.initialize({ let v_7075695f6e61746976655f3131 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f31323e = Value::string("disabled"); let v_3c636170747572653a7075695f6e61746976655f31333e = Value::boolean(false); let v_7075695f6e61746976655f3134 = create_state(&owner, "bool", v_3c636170747572653a7075695f6e61746976655f31323e.clone(), Value::boolean((v_3c636170747572653a7075695f6e61746976655f31333e.clone()).bool()), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3134.clone());    v_7075695f6e61746976655f3134 } });
        // Source "packages/prototypes/base/src/input/root.proto.ts":76:9
        v_726561644f6e6c79.initialize({ let v_7075695f6e61746976655f3135 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f31363e = Value::string("readOnly"); let v_3c636170747572653a7075695f6e61746976655f31373e = Value::boolean(false); let v_7075695f6e61746976655f3138 = create_state(&owner, "bool", v_3c636170747572653a7075695f6e61746976655f31363e.clone(), Value::boolean((v_3c636170747572653a7075695f6e61746976655f31373e.clone()).bool()), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3138.clone());    v_7075695f6e61746976655f3138 } });
        // Source "packages/prototypes/base/src/input/root.proto.ts":77:9
        v_636f6d706f73696e67.initialize({ let v_7075695f6e61746976655f3139 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f32303e = Value::string("composing"); let v_3c636170747572653a7075695f6e61746976655f32313e = Value::boolean(false); let v_7075695f6e61746976655f3232 = create_state(&owner, "bool", v_3c636170747572653a7075695f6e61746976655f32303e.clone(), Value::boolean((v_3c636170747572653a7075695f6e61746976655f32313e.clone()).bool()), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3232.clone());    v_7075695f6e61746976655f3232 } });
        // Source "packages/prototypes/base/src/input/root.proto.ts":78:9
        v_617269614c6162656c.initialize({ let v_7075695f6e61746976655f3233 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f32343e = Value::string("inputAriaLabel"); let v_3c636170747572653a7075695f6e61746976655f32353e = Value::string(""); let v_7075695f6e61746976655f3236 = create_state(&owner, "string", v_3c636170747572653a7075695f6e61746976655f32343e.clone(), v_3c636170747572653a7075695f6e61746976655f32353e.clone(), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3236.clone());    v_7075695f6e61746976655f3236 } });
        // Source "packages/prototypes/base/src/input/root.proto.ts":79:9
        v_6c6162656c6c65644279.initialize({ let v_7075695f6e61746976655f3237 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f32383e = Value::string("inputLabelledBy"); let v_3c636170747572653a7075695f6e61746976655f32393e = Value::string(""); let v_7075695f6e61746976655f3330 = create_state(&owner, "string", v_3c636170747572653a7075695f6e61746976655f32383e.clone(), v_3c636170747572653a7075695f6e61746976655f32393e.clone(), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3330.clone());    v_7075695f6e61746976655f3330 } });
        // Source "packages/prototypes/base/src/input/root.proto.ts":80:9
        v_6465736372696265644279.initialize({ let v_7075695f6e61746976655f3331 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f33323e = Value::string("inputDescribedBy"); let v_3c636170747572653a7075695f6e61746976655f33333e = Value::string(""); let v_7075695f6e61746976655f3334 = create_state(&owner, "string", v_3c636170747572653a7075695f6e61746976655f33323e.clone(), v_3c636170747572653a7075695f6e61746976655f33333e.clone(), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3334.clone());    v_7075695f6e61746976655f3334 } });
        // Source "packages/prototypes/base/src/input/root.proto.ts":81:9
        let v_666f6375736564 = (v_666f63757361626c655f5f38363131313032356366613766623661.read()).member("focused", false);
        // Source "packages/prototypes/base/src/input/root.proto.ts":82:9
        let v_666f63757356697369626c65 = (v_666f63757361626c655f5f38363131313032356366613766623661.read()).member("focusVisible", false);
        // Source "packages/prototypes/base/src/input/root.proto.ts":83:7
        v_63757272656e7456696577.initialize(Rc::new(std::cell::RefCell::new(Value::Json(Json::Null))));
        // Source "packages/prototypes/base/src/input/root.proto.ts":84:7
        v_7669657745706f6368.initialize(Rc::new(std::cell::RefCell::new(0.0_f64)));
        // Source "packages/prototypes/base/src/input/root.proto.ts":86:3
        { let v_7075695f6e61746976655f3335 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f33363e = Value::string("value"); let v_3c636170747572653a7075695f6e61746976655f33373e = v_76616c7565.read(); let v_7075695f6e61746976655f3338 = expose_state(&owner, v_3c636170747572653a7075695f6e61746976655f33363e.clone(), v_3c636170747572653a7075695f6e61746976655f33373e.clone()); capture_effect(&owner, "state", record(vec![("op", Value::string("expose.state")), ("key", v_3c636170747572653a7075695f6e61746976655f33363e.clone()), ("handle", v_3c636170747572653a7075695f6e61746976655f33373e.clone())]));   capture_introduced_state(&owner, v_3c636170747572653a7075695f6e61746976655f33373e.clone()); v_7075695f6e61746976655f3338 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":87:3
        { let v_7075695f6e61746976655f3339 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f34303e = Value::string("disabled"); let v_3c636170747572653a7075695f6e61746976655f34313e = v_64697361626c6564.read(); let v_7075695f6e61746976655f3432 = expose_state(&owner, v_3c636170747572653a7075695f6e61746976655f34303e.clone(), v_3c636170747572653a7075695f6e61746976655f34313e.clone()); capture_effect(&owner, "state", record(vec![("op", Value::string("expose.state")), ("key", v_3c636170747572653a7075695f6e61746976655f34303e.clone()), ("handle", v_3c636170747572653a7075695f6e61746976655f34313e.clone())]));   capture_introduced_state(&owner, v_3c636170747572653a7075695f6e61746976655f34313e.clone()); v_7075695f6e61746976655f3432 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":88:3
        { let v_7075695f6e61746976655f3433 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f34343e = Value::string("readOnly"); let v_3c636170747572653a7075695f6e61746976655f34353e = v_726561644f6e6c79.read(); let v_7075695f6e61746976655f3436 = expose_state(&owner, v_3c636170747572653a7075695f6e61746976655f34343e.clone(), v_3c636170747572653a7075695f6e61746976655f34353e.clone()); capture_effect(&owner, "state", record(vec![("op", Value::string("expose.state")), ("key", v_3c636170747572653a7075695f6e61746976655f34343e.clone()), ("handle", v_3c636170747572653a7075695f6e61746976655f34353e.clone())]));   capture_introduced_state(&owner, v_3c636170747572653a7075695f6e61746976655f34353e.clone()); v_7075695f6e61746976655f3436 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":89:3
        { let v_7075695f6e61746976655f3437 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f34383e = Value::string("focused"); let v_3c636170747572653a7075695f6e61746976655f34393e = v_666f6375736564.clone(); let v_7075695f6e61746976655f3530 = expose_state(&owner, v_3c636170747572653a7075695f6e61746976655f34383e.clone(), v_3c636170747572653a7075695f6e61746976655f34393e.clone()); capture_effect(&owner, "state", record(vec![("op", Value::string("expose.state")), ("key", v_3c636170747572653a7075695f6e61746976655f34383e.clone()), ("handle", v_3c636170747572653a7075695f6e61746976655f34393e.clone())]));   capture_introduced_state(&owner, v_3c636170747572653a7075695f6e61746976655f34393e.clone()); v_7075695f6e61746976655f3530 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":90:3
        { let v_7075695f6e61746976655f3531 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f35323e = Value::string("focusVisible"); let v_3c636170747572653a7075695f6e61746976655f35333e = v_666f63757356697369626c65.clone(); let v_7075695f6e61746976655f3534 = expose_state(&owner, v_3c636170747572653a7075695f6e61746976655f35323e.clone(), v_3c636170747572653a7075695f6e61746976655f35333e.clone()); capture_effect(&owner, "state", record(vec![("op", Value::string("expose.state")), ("key", v_3c636170747572653a7075695f6e61746976655f35323e.clone()), ("handle", v_3c636170747572653a7075695f6e61746976655f35333e.clone())]));   capture_introduced_state(&owner, v_3c636170747572653a7075695f6e61746976655f35333e.clone()); v_7075695f6e61746976655f3534 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":91:3
        { let v_7075695f6e61746976655f3535 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f35363e = Value::string("composing"); let v_3c636170747572653a7075695f6e61746976655f35373e = v_636f6d706f73696e67.read(); let v_7075695f6e61746976655f3538 = expose_state(&owner, v_3c636170747572653a7075695f6e61746976655f35363e.clone(), v_3c636170747572653a7075695f6e61746976655f35373e.clone()); capture_effect(&owner, "state", record(vec![("op", Value::string("expose.state")), ("key", v_3c636170747572653a7075695f6e61746976655f35363e.clone()), ("handle", v_3c636170747572653a7075695f6e61746976655f35373e.clone())]));   capture_introduced_state(&owner, v_3c636170747572653a7075695f6e61746976655f35373e.clone()); v_7075695f6e61746976655f3538 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":92:3
        { let v_7075695f6e61746976655f3539 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f36323e = Value::string("focusSelf"); let v_3c636170747572653a7075695f6e61746976655f36333e = {  let v_666f63757361626c655f5f38363131313032356366613766623661 = v_666f63757361626c655f5f38363131313032356366613766623661.clone(); let v_64697361626c6564 = v_64697361626c6564.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_6f7074696f6e73: Value = arg(&arguments, 0);
            // Source "packages/prototypes/base/src/input/root.proto.ts":93:5
            if !(({ let v_7075695f6e61746976655f3630 = v_64697361626c6564.read(); Value::boolean(((v_7075695f6e61746976655f3630.clone()).get()).bool()) }).bool()) {
                // Source "packages/prototypes/base/src/input/root.proto.ts":93:26
                { let v_7075695f6e61746976655f3631 = v_666f63757361626c655f5f38363131313032356366613766623661.read(); focus_request(&(v_7075695f6e61746976655f3631.clone()).owner(), v_6f7074696f6e73.clone(), false) };
            }
            Value::Undefined
        })) }; let v_7075695f6e61746976655f3634 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f36323e.clone(), v_3c636170747572653a7075695f6e61746976655f36333e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f36323e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f36333e.clone())]));    v_7075695f6e61746976655f3634 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":95:3
        { let v_7075695f6e61746976655f3635 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f36373e = Value::string("blurSelf"); let v_3c636170747572653a7075695f6e61746976655f36383e = {  let v_666f63757361626c655f5f38363131313032356366613766623661 = v_666f63757361626c655f5f38363131313032356366613766623661.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
            // Source "packages/prototypes/base/src/input/root.proto.ts":95:39
            return { let v_7075695f6e61746976655f3636 = v_666f63757361626c655f5f38363131313032356366613766623661.read(); focus_blur(&(v_7075695f6e61746976655f3636.clone()).owner()) };
        })) }; let v_7075695f6e61746976655f3639 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f36373e.clone(), v_3c636170747572653a7075695f6e61746976655f36383e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f36373e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f36383e.clone())]));    v_7075695f6e61746976655f3639 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":96:3
        { let v_7075695f6e61746976655f3730 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f3130363e = Value::string("resetValue"); let v_3c636170747572653a7075695f6e61746976655f3130373e = ({  let v_636f6e74726f6c = v_636f6e74726f6c.clone(); let v_76616c7565 = v_76616c7565.clone(); let v_636f6d706f73696e67 = v_636f6d706f73696e67.clone(); let v_63757272656e7456696577 = v_63757272656e7456696577.clone(); let v_7669657745706f6368 = v_7669657745706f6368.clone(); let call:Rc<dyn Fn(Value)->bool>=Rc::new(move |argument_0: Value| -> bool {
            let v_6e6578745f5f34643832326232613761376231643730: Value = argument_0;
            // Source "packages/prototypes/base/src/input/root.proto.ts":97:11
            let v_72756e5f5f66373037386136306230356637363866 = { let value = (v_63757272656e7456696577.read()).borrow().clone(); value };
            // Source "packages/prototypes/base/src/input/root.proto.ts":98:5
            if { let pui_native_71=!((v_72756e5f5f66373037386136306230356637363866.clone()).truthy()); if !(pui_native_71) {{ let pui_native_73=(Value::boolean(!strict_equal(&(v_6e6578745f5f34643832326232613761376231643730.clone()), &(Value::Undefined)))).bool(); if (pui_native_73) {(Value::boolean(!strict_equal(&(typeof_value(&(v_6e6578745f5f34643832326232613761376231643730.clone()))), &(Value::string("string"))))).bool()} else {pui_native_73} }} else {pui_native_71} } {
                // Source "packages/prototypes/base/src/input/root.proto.ts":98:67
                return false;
            }
            // Source "packages/prototypes/base/src/input/root.proto.ts":99:11
            let v_65706f63685f5f31636366343332626462666233373631: f64 = { let cell=v_7669657745706f6368.read(); let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; value };
            // Source "packages/prototypes/base/src/input/root.proto.ts":100:11
            let v_6163636570746564: bool = ({ let v_7075695f6e61746976655f3739 = v_636f6e74726f6c.read(); Value::boolean((text_reset_value(&(v_7075695f6e61746976655f3739.clone()).owner(), v_6e6578745f5f34643832326232613761376231643730.clone())).bool()) }).bool();
            // Source "packages/prototypes/base/src/input/root.proto.ts":101:5
            if { let pui_native_80=(Value::boolean(!strict_equal(&({ let value = (v_63757272656e7456696577.read()).borrow().clone(); value }), &(v_72756e5f5f66373037386136306230356637363866.clone())))).bool(); if !(pui_native_80) {{ let pui_native_84={ let value=(v_7669657745706f6368.read()).borrow().clone(); value }; let pui_native_85=v_65706f63685f5f31636366343332626462666233373631.clone(); !(pui_native_84==pui_native_85) }} else {pui_native_80} } {
                // Source "packages/prototypes/base/src/input/root.proto.ts":101:53
                return false;
            }
            // Source "packages/prototypes/base/src/input/root.proto.ts":102:5
            { let v_7075695f6e61746976655f3836 = v_636f6d706f73696e67.read(); state_set(v_7075695f6e61746976655f3836.clone(), Value::boolean({ let pui_native_87=({ let v_7075695f6e61746976655f3839 = v_636f6e74726f6c.read(); text_snapshot(&(v_7075695f6e61746976655f3839.clone()).owner()) }).member("composing", true); if pui_native_87.nullish() {false} else {(pui_native_87).bool()} }), Value::string("reason: input reset composition")) };
            // Source "packages/prototypes/base/src/input/root.proto.ts":103:5
            if { let pui_native_90=(Value::boolean(!strict_equal(&({ let value = (v_63757272656e7456696577.read()).borrow().clone(); value }), &(v_72756e5f5f66373037386136306230356637363866.clone())))).bool(); if !(pui_native_90) {{ let pui_native_94={ let value=(v_7669657745706f6368.read()).borrow().clone(); value }; let pui_native_95=v_65706f63685f5f31636366343332626462666233373631.clone(); !(pui_native_94==pui_native_95) }} else {pui_native_90} } {
                // Source "packages/prototypes/base/src/input/root.proto.ts":103:53
                return false;
            }
            // Source "packages/prototypes/base/src/input/root.proto.ts":106:5
            { let v_7075695f6e61746976655f3936 = v_76616c7565.read(); state_set(v_7075695f6e61746976655f3936.clone(), { let left = ({ let v_7075695f6e61746976655f3937 = v_636f6e74726f6c.read(); text_snapshot(&(v_7075695f6e61746976655f3937.clone()).owner()) }).member("value", true); if left.nullish() { Value::string("") } else { left } }, Value::string("reason: input reset value")) };
            // Source "packages/prototypes/base/src/input/root.proto.ts":107:5
            return { let pui_native_98={ let pui_native_100=(Value::boolean(strict_equal(&({ let value = (v_63757272656e7456696577.read()).borrow().clone(); value }), &(v_72756e5f5f66373037386136306230356637363866.clone())))).bool(); if (pui_native_100) {{ let pui_native_104={ let value=(v_7669657745706f6368.read()).borrow().clone(); value }; let pui_native_105=v_65706f63685f5f31636366343332626462666233373631.clone(); (pui_native_104==pui_native_105) }} else {pui_native_100} }; if (pui_native_98) {v_6163636570746564.clone()} else {pui_native_98} };
        }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call(arg(&arguments,0)))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"); let v_7075695f6e61746976655f313038 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3130363e.clone(), v_3c636170747572653a7075695f6e61746976655f3130373e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3130363e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3130373e.clone())]));    v_7075695f6e61746976655f313038 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":109:3
        { let v_7075695f6e61746976655f313039 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f3131303e = Value::string("valueChange"); let v_3c636170747572653a7075695f6e61746976655f3131313e = record(vec![("payload", Value::string("json"))]); let v_7075695f6e61746976655f313132 = expose_event(&owner, v_3c636170747572653a7075695f6e61746976655f3131303e.clone()); capture_effect(&owner, "event", record(vec![("op", Value::string("expose.event")), ("key", v_3c636170747572653a7075695f6e61746976655f3131303e.clone()), ("spec", v_3c636170747572653a7075695f6e61746976655f3131313e.clone())]));  capture_event_key(&owner, v_3c636170747572653a7075695f6e61746976655f3131303e.clone());  v_7075695f6e61746976655f313132 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":110:3
        { let v_7075695f6e61746976655f313133 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f3131343e = Value::string("change"); let v_3c636170747572653a7075695f6e61746976655f3131353e = record(vec![("payload", Value::string("json"))]); let v_7075695f6e61746976655f313136 = expose_event(&owner, v_3c636170747572653a7075695f6e61746976655f3131343e.clone()); capture_effect(&owner, "event", record(vec![("op", Value::string("expose.event")), ("key", v_3c636170747572653a7075695f6e61746976655f3131343e.clone()), ("spec", v_3c636170747572653a7075695f6e61746976655f3131353e.clone())]));  capture_event_key(&owner, v_3c636170747572653a7075695f6e61746976655f3131343e.clone());  v_7075695f6e61746976655f313136 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":111:3
        { let v_7075695f6e61746976655f313137 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f3131383e = Value::string("compositionStart"); let v_3c636170747572653a7075695f6e61746976655f3131393e = record(vec![("payload", Value::string("json"))]); let v_7075695f6e61746976655f313230 = expose_event(&owner, v_3c636170747572653a7075695f6e61746976655f3131383e.clone()); capture_effect(&owner, "event", record(vec![("op", Value::string("expose.event")), ("key", v_3c636170747572653a7075695f6e61746976655f3131383e.clone()), ("spec", v_3c636170747572653a7075695f6e61746976655f3131393e.clone())]));  capture_event_key(&owner, v_3c636170747572653a7075695f6e61746976655f3131383e.clone());  v_7075695f6e61746976655f313230 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":112:3
        { let v_7075695f6e61746976655f313231 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f3132323e = Value::string("compositionUpdate"); let v_3c636170747572653a7075695f6e61746976655f3132333e = record(vec![("payload", Value::string("json"))]); let v_7075695f6e61746976655f313234 = expose_event(&owner, v_3c636170747572653a7075695f6e61746976655f3132323e.clone()); capture_effect(&owner, "event", record(vec![("op", Value::string("expose.event")), ("key", v_3c636170747572653a7075695f6e61746976655f3132323e.clone()), ("spec", v_3c636170747572653a7075695f6e61746976655f3132333e.clone())]));  capture_event_key(&owner, v_3c636170747572653a7075695f6e61746976655f3132323e.clone());  v_7075695f6e61746976655f313234 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":113:3
        { let v_7075695f6e61746976655f313235 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f3132363e = Value::string("compositionEnd"); let v_3c636170747572653a7075695f6e61746976655f3132373e = record(vec![("payload", Value::string("json"))]); let v_7075695f6e61746976655f313238 = expose_event(&owner, v_3c636170747572653a7075695f6e61746976655f3132363e.clone()); capture_effect(&owner, "event", record(vec![("op", Value::string("expose.event")), ("key", v_3c636170747572653a7075695f6e61746976655f3132363e.clone()), ("spec", v_3c636170747572653a7075695f6e61746976655f3132373e.clone())]));  capture_event_key(&owner, v_3c636170747572653a7075695f6e61746976655f3132363e.clone());  v_7075695f6e61746976655f313238 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":115:3
        { let v_7075695f6e61746976655f313239 = v_61636365737369626c65.clone(); accessible_role(&(v_7075695f6e61746976655f313239.clone()).owner(), Value::string("textbox")) };
        // Source "packages/prototypes/base/src/input/root.proto.ts":116:3
        { let v_7075695f6e61746976655f313330 = v_61636365737369626c65.clone(); accessible_text(&(v_7075695f6e61746976655f313330.clone()).owner(), "name", v_617269614c6162656c.read()) };
        // Source "packages/prototypes/base/src/input/root.proto.ts":117:3
        { let v_7075695f6e61746976655f313331 = v_61636365737369626c65.clone(); { let v_3c636170747572653a7075695f6e61746976655f3133323e = Value::string("disabled"); let v_3c636170747572653a7075695f6e61746976655f3133333e = v_64697361626c6564.read(); let v_7075695f6e61746976655f313334 = accessible_state(&(v_7075695f6e61746976655f313331.clone()).owner(), v_3c636170747572653a7075695f6e61746976655f3133323e.clone(), v_3c636170747572653a7075695f6e61746976655f3133333e.clone(), Value::Undefined); capture_effect(&owner, "state", record(vec![("op", Value::string("a11y.state")), ("key", v_3c636170747572653a7075695f6e61746976655f3133323e.clone()), ("handle", v_3c636170747572653a7075695f6e61746976655f3133333e.clone()), ("options", Value::Undefined)]));   capture_introduced_state(&owner, v_3c636170747572653a7075695f6e61746976655f3133333e.clone()); v_7075695f6e61746976655f313334 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":118:3
        { let v_7075695f6e61746976655f313335 = v_61636365737369626c65.clone(); { let v_3c636170747572653a7075695f6e61746976655f3133363e = Value::string("readOnly"); let v_3c636170747572653a7075695f6e61746976655f3133373e = v_726561644f6e6c79.read(); let v_7075695f6e61746976655f313338 = accessible_state(&(v_7075695f6e61746976655f313335.clone()).owner(), v_3c636170747572653a7075695f6e61746976655f3133363e.clone(), v_3c636170747572653a7075695f6e61746976655f3133373e.clone(), Value::Undefined); capture_effect(&owner, "state", record(vec![("op", Value::string("a11y.state")), ("key", v_3c636170747572653a7075695f6e61746976655f3133363e.clone()), ("handle", v_3c636170747572653a7075695f6e61746976655f3133373e.clone()), ("options", Value::Undefined)]));   capture_introduced_state(&owner, v_3c636170747572653a7075695f6e61746976655f3133373e.clone()); v_7075695f6e61746976655f313338 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":119:3
        { let v_7075695f6e61746976655f313339 = v_61636365737369626c65.clone(); accessible_relation(&(v_7075695f6e61746976655f313339.clone()).owner(), Value::string("labelledBy"), record(vec![("target", v_6c6162656c6c65644279.read())])) };
        // Source "packages/prototypes/base/src/input/root.proto.ts":120:3
        { let v_7075695f6e61746976655f313430 = v_61636365737369626c65.clone(); accessible_relation(&(v_7075695f6e61746976655f313430.clone()).owner(), Value::string("describedBy"), record(vec![("target", v_6465736372696265644279.read())])) };
        // Source "packages/prototypes/base/src/input/root.proto.ts":122:9
        v_73796e63.initialize({  let v_636f6e74726f6c = v_636f6e74726f6c.clone(); let v_666f63757361626c655f5f38363131313032356366613766623661 = v_666f63757361626c655f5f38363131313032356366613766623661.clone(); let v_76616c7565 = v_76616c7565.clone(); let v_64697361626c6564 = v_64697361626c6564.clone(); let v_726561644f6e6c79 = v_726561644f6e6c79.clone(); let v_617269614c6162656c = v_617269614c6162656c.clone(); let v_6c6162656c6c65644279 = v_6c6162656c6c65644279.clone(); let v_6465736372696265644279 = v_6465736372696265644279.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_70726f7073: Value = arg(&arguments, 0);
            // Source "packages/prototypes/base/src/input/root.proto.ts":123:11
            let v_636f6e74726f6c6c6564: bool = (Value::boolean(strict_equal(&(typeof_value(&((v_70726f7073.clone()).member("value", false)))), &(Value::string("string"))))).bool();
            // Source "packages/prototypes/base/src/input/root.proto.ts":124:11
            let v_6e65787444697361626c6564: bool = { let pui_native_143=(v_70726f7073.clone()).member("disabled", false); if pui_native_143.nullish() {false} else {(pui_native_143).bool()} };
            // Source "packages/prototypes/base/src/input/root.proto.ts":125:5
            { let v_7075695f6e61746976655f313435 = v_64697361626c6564.read(); state_set(v_7075695f6e61746976655f313435.clone(), Value::boolean(v_6e65787444697361626c6564.clone()), Value::string("reason: input sync disabled")) };
            // Source "packages/prototypes/base/src/input/root.proto.ts":126:5
            { let v_7075695f6e61746976655f313436 = v_726561644f6e6c79.read(); state_set(v_7075695f6e61746976655f313436.clone(), Value::boolean({ let pui_native_147=(v_70726f7073.clone()).member("readOnly", false); if pui_native_147.nullish() {false} else {(pui_native_147).bool()} }), Value::string("reason: input sync readonly")) };
            // Source "packages/prototypes/base/src/input/root.proto.ts":127:5
            { let v_7075695f6e61746976655f313439 = v_617269614c6162656c.read(); state_set(v_7075695f6e61746976655f313439.clone(), { let left = (v_70726f7073.clone()).member("ariaLabel", false); if left.nullish() { Value::string("") } else { left } }, Value::string("reason: input sync aria label")) };
            // Source "packages/prototypes/base/src/input/root.proto.ts":128:5
            { let v_7075695f6e61746976655f313530 = v_6c6162656c6c65644279.read(); state_set(v_7075695f6e61746976655f313530.clone(), { let left = (v_70726f7073.clone()).member("labelledBy", false); if left.nullish() { Value::string("") } else { left } }, Value::string("reason: input sync labelledby")) };
            // Source "packages/prototypes/base/src/input/root.proto.ts":129:5
            { let v_7075695f6e61746976655f313531 = v_6465736372696265644279.read(); state_set(v_7075695f6e61746976655f313531.clone(), { let left = (v_70726f7073.clone()).member("describedBy", false); if left.nullish() { Value::string("") } else { left } }, Value::string("reason: input sync describedby")) };
            // Source "packages/prototypes/base/src/input/root.proto.ts":130:5
            { let v_7075695f6e61746976655f313532 = v_666f63757361626c655f5f38363131313032356366613766623661.read(); focus_disabled(&(v_7075695f6e61746976655f313532.clone()).owner(), Value::boolean(v_6e65787444697361626c6564.clone())) };
            // Source "packages/prototypes/base/src/input/root.proto.ts":131:5
            { let v_7075695f6e61746976655f313533 = v_636f6e74726f6c.read(); text_sync(&(v_7075695f6e61746976655f313533.clone()).owner(), record(vec![("valueMode", if (Value::boolean(v_636f6e74726f6c6c6564.clone())).truthy() { Value::string("controlled") } else { Value::string("uncontrolled") }), ("value", if (Value::boolean(v_636f6e74726f6c6c6564.clone())).truthy() { (v_70726f7073.clone()).member("value", false) } else { Value::Undefined }), ("defaultValue", { let left = (v_70726f7073.clone()).member("defaultValue", false); if left.nullish() { Value::string("") } else { left } }), ("disabled", Value::boolean(v_6e65787444697361626c6564.clone())), ("readOnly", Value::boolean({ let pui_native_154=(v_70726f7073.clone()).member("readOnly", false); if pui_native_154.nullish() {false} else {(pui_native_154).bool()} })), ("placeholder", { let left = (v_70726f7073.clone()).member("placeholder", false); if left.nullish() { Value::string("") } else { left } }), ("required", Value::boolean({ let pui_native_156=(v_70726f7073.clone()).member("required", false); if pui_native_156.nullish() {false} else {(pui_native_156).bool()} })), ("name", { let left = (v_70726f7073.clone()).member("name", false); if left.nullish() { Value::string("") } else { left } }), ("autoComplete", { let left = (v_70726f7073.clone()).member("autoComplete", false); if left.nullish() { Value::string("") } else { left } }), ("minLength", Value::number({ let pui_native_158=(v_70726f7073.clone()).member("minLength", false); if pui_native_158.nullish() {-(1.0_f64)} else {(pui_native_158).num()} })), ("maxLength", Value::number({ let pui_native_160=(v_70726f7073.clone()).member("maxLength", false); if pui_native_160.nullish() {-(1.0_f64)} else {(pui_native_160).num()} })), ("inputMode", (v_70726f7073.clone()).member("inputMode", false)), ("enterKeyHint", (v_70726f7073.clone()).member("enterKeyHint", false))])) };
            // Source "packages/prototypes/base/src/input/root.proto.ts":146:5
            { let v_7075695f6e61746976655f313632 = v_76616c7565.read(); state_set(v_7075695f6e61746976655f313632.clone(), { let left = ({ let v_7075695f6e61746976655f313633 = v_636f6e74726f6c.read(); text_snapshot(&(v_7075695f6e61746976655f313633.clone()).owner()) }).member("value", true); if left.nullish() { Value::string("") } else { left } }, Value::string("reason: input sync value")) };
            Value::Undefined
        })) });
        // Source "packages/prototypes/base/src/input/root.proto.ts":148:3
        { let v_7075695f6e61746976655f313634 = v_646566.clone(); register_life(&owner, "created", {  let v_73796e63 = v_73796e63.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_72756e5f5f34316434353732376264656163306662: Value = arg(&arguments, 0);
            // Source "packages/prototypes/base/src/input/root.proto.ts":148:36
            return v_73796e63.read().call_authored(vec![{ let v_7075695f6e61746976655f313635 = v_72756e5f5f34316434353732376264656163306662.clone(); read_props(&(v_7075695f6e61746976655f313635.clone()).owner(), false) }]);
        })) }) };
        // Source "packages/prototypes/base/src/input/root.proto.ts":149:3
        { let v_7075695f6e61746976655f313636 = v_646566.clone(); register_life(&owner, "mounted", {  let v_636f6e74726f6c = v_636f6e74726f6c.clone(); let v_76616c7565 = v_76616c7565.clone(); let v_636f6d706f73696e67 = v_636f6d706f73696e67.clone(); let v_63757272656e7456696577 = v_63757272656e7456696577.clone(); let v_7669657745706f6368 = v_7669657745706f6368.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_72756e5f5f64656530616562663333646539633834: Value = arg(&arguments, 0);
            // Source "packages/prototypes/base/src/input/root.proto.ts":150:5
            { let value = v_72756e5f5f64656530616562663333646539633834.clone(); *(v_63757272656e7456696577.read()).borrow_mut() = value; }
            // Source "packages/prototypes/base/src/input/root.proto.ts":151:11
            let v_65706f63685f5f32636339326437316464613635646538: f64 = { let cell=v_7669657745706f6368.read(); let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; value };
            // Source "packages/prototypes/base/src/input/root.proto.ts":154:5
            { let v_7075695f6e61746976655f313637 = v_636f6d706f73696e67.read(); state_set(v_7075695f6e61746976655f313637.clone(), Value::boolean({ let pui_native_168=({ let v_7075695f6e61746976655f313730 = v_636f6e74726f6c.read(); text_snapshot(&(v_7075695f6e61746976655f313730.clone()).owner()) }).member("composing", true); if pui_native_168.nullish() {false} else {(pui_native_168).bool()} }), Value::string("reason: input mounted composition")) };
            // Source "packages/prototypes/base/src/input/root.proto.ts":155:5
            if { let pui_native_171=(Value::boolean(!strict_equal(&({ let value = (v_63757272656e7456696577.read()).borrow().clone(); value }), &(v_72756e5f5f64656530616562663333646539633834.clone())))).bool(); if !(pui_native_171) {{ let pui_native_175={ let value=(v_7669657745706f6368.read()).borrow().clone(); value }; let pui_native_176=v_65706f63685f5f32636339326437316464613635646538.clone(); !(pui_native_175==pui_native_176) }} else {pui_native_171} } {
                // Source "packages/prototypes/base/src/input/root.proto.ts":155:53
                return Value::Undefined;
            }
            // Source "packages/prototypes/base/src/input/root.proto.ts":156:5
            { let v_7075695f6e61746976655f313737 = v_76616c7565.read(); state_set(v_7075695f6e61746976655f313737.clone(), { let left = ({ let v_7075695f6e61746976655f313738 = v_636f6e74726f6c.read(); text_snapshot(&(v_7075695f6e61746976655f313738.clone()).owner()) }).member("value", true); if left.nullish() { Value::string("") } else { left } }, Value::string("reason: input mounted value")) };
            Value::Undefined
        })) }) };
        // Source "packages/prototypes/base/src/input/root.proto.ts":158:3
        { let v_7075695f6e61746976655f313739 = v_646566.clone(); register_life(&owner, "unmounted", {  let v_636f6d706f73696e67 = v_636f6d706f73696e67.clone(); let v_63757272656e7456696577 = v_63757272656e7456696577.clone(); let v_7669657745706f6368 = v_7669657745706f6368.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
            // Source "packages/prototypes/base/src/input/root.proto.ts":159:5
            { let value = Value::Json(Json::Null); *(v_63757272656e7456696577.read()).borrow_mut() = value; }
            // Source "packages/prototypes/base/src/input/root.proto.ts":160:5
            Value::number({ let cell=v_7669657745706f6368.read(); let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; previous });
            // Source "packages/prototypes/base/src/input/root.proto.ts":162:5
            { let v_7075695f6e61746976655f313830 = v_636f6d706f73696e67.read(); state_set(v_7075695f6e61746976655f313830.clone(), Value::boolean(false), Value::string("reason: input view composition retired")) };
            Value::Undefined
        })) }) };
        // Source "packages/prototypes/base/src/input/root.proto.ts":164:3
        { let v_7075695f6e61746976655f313831 = v_646566.clone(); register_life(&owner, "before-dispose", {  let v_63757272656e7456696577 = v_63757272656e7456696577.clone(); let v_7669657745706f6368 = v_7669657745706f6368.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
            // Source "packages/prototypes/base/src/input/root.proto.ts":165:5
            { let value = Value::Json(Json::Null); *(v_63757272656e7456696577.read()).borrow_mut() = value; }
            // Source "packages/prototypes/base/src/input/root.proto.ts":166:5
            Value::number({ let cell=v_7669657745706f6368.read(); let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; previous });
            Value::Undefined
        })) }) };
        // Source "packages/prototypes/base/src/input/root.proto.ts":168:3
        { let v_7075695f6e61746976655f313832 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f3138333e = Value::Array(Rc::new(vec![Value::string("value"), Value::string("defaultValue"), Value::string("disabled"), Value::string("readOnly"), Value::string("placeholder"), Value::string("required"), Value::string("name"), Value::string("autoComplete"), Value::string("minLength"), Value::string("maxLength"), Value::string("inputMode"), Value::string("enterKeyHint"), Value::string("ariaLabel"), Value::string("labelledBy"), Value::string("describedBy")])); let v_3c636170747572653a7075695f6e61746976655f3138343e = {  let v_73796e63 = v_73796e63.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_5f72756e: Value = arg(&arguments, 0);
            let v_6e6578745f5f62373962383533353864336637323332: Value = arg(&arguments, 1);
            // Source "packages/prototypes/base/src/input/root.proto.ts":186:21
            return v_73796e63.read().call_authored(vec![v_6e6578745f5f62373962383533353864336637323332.clone()]);
        })) }; let v_7075695f6e61746976655f313835 = watch_props(&owner, Some(v_3c636170747572653a7075695f6e61746976655f3138333e.clone()), false, v_3c636170747572653a7075695f6e61746976655f3138343e.clone()); capture_effect(&owner, "props", record(vec![("op", Value::string("watch")), ("keys", v_3c636170747572653a7075695f6e61746976655f3138333e.clone()), ("off", v_7075695f6e61746976655f313835.clone())])); capture_disposer(&owner, "props", v_7075695f6e61746976655f313835.clone());   v_7075695f6e61746976655f313835 } };
        // Source "packages/prototypes/base/src/input/root.proto.ts":189:3
        { let v_7075695f6e61746976655f313836 = v_636f6e74726f6c.read(); text_on(&(v_7075695f6e61746976655f313836.clone()).owner(), Value::string("input"), {  let v_636f6e74726f6c = v_636f6e74726f6c.clone(); let v_76616c7565 = v_76616c7565.clone(); let v_636f6d706f73696e67 = v_636f6d706f73696e67.clone(); let v_63757272656e7456696577 = v_63757272656e7456696577.clone(); let v_7669657745706f6368 = v_7669657745706f6368.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_72756e5f5f66343237653333626638663865366433: Value = arg(&arguments, 0);
            let v_6576656e745f5f30366166366561326465333232633166: Value = arg(&arguments, 1);
            // Source "packages/prototypes/base/src/input/root.proto.ts":190:11
            let v_65706f63685f5f35346138653538363565393032333362: f64 = { let value=(v_7669657745706f6368.read()).borrow().clone(); value };
            // Source "packages/prototypes/base/src/input/root.proto.ts":191:5
            { let v_7075695f6e61746976655f313837 = v_76616c7565.read(); state_set(v_7075695f6e61746976655f313837.clone(), { let left = ({ let v_7075695f6e61746976655f313838 = v_636f6e74726f6c.read(); text_snapshot(&(v_7075695f6e61746976655f313838.clone()).owner()) }).member("value", true); if left.nullish() { (v_6576656e745f5f30366166366561326465333232633166.clone()).member("value", false) } else { left } }, Value::string("reason: input value")) };
            // Source "packages/prototypes/base/src/input/root.proto.ts":192:5
            if { let pui_native_189=(Value::boolean(!strict_equal(&({ let value = (v_63757272656e7456696577.read()).borrow().clone(); value }), &(v_72756e5f5f66343237653333626638663865366433.clone())))).bool(); if !(pui_native_189) {{ let pui_native_193={ let value=(v_7669657745706f6368.read()).borrow().clone(); value }; let pui_native_194=v_65706f63685f5f35346138653538363565393032333362.clone(); !(pui_native_193==pui_native_194) }} else {pui_native_189} } {
                // Source "packages/prototypes/base/src/input/root.proto.ts":192:53
                return Value::Undefined;
            }
            // Source "packages/prototypes/base/src/input/root.proto.ts":193:5
            { let v_7075695f6e61746976655f313935 = v_636f6d706f73696e67.read(); state_set(v_7075695f6e61746976655f313935.clone(), Value::boolean(((v_6576656e745f5f30366166366561326465333232633166.clone()).member("composing", false)).bool()), Value::string("reason: input composing")) };
            // Source "packages/prototypes/base/src/input/root.proto.ts":194:5
            if { let pui_native_196=(Value::boolean(!strict_equal(&({ let value = (v_63757272656e7456696577.read()).borrow().clone(); value }), &(v_72756e5f5f66343237653333626638663865366433.clone())))).bool(); if !(pui_native_196) {{ let pui_native_200={ let value=(v_7669657745706f6368.read()).borrow().clone(); value }; let pui_native_201=v_65706f63685f5f35346138653538363565393032333362.clone(); !(pui_native_200==pui_native_201) }} else {pui_native_196} } {
                // Source "packages/prototypes/base/src/input/root.proto.ts":194:53
                return Value::Undefined;
            }
            // Source "packages/prototypes/base/src/input/root.proto.ts":195:11
            let v_64657461696c5f5f36346264646237643732363963613635 = freeze(record(vec![("value", (v_6576656e745f5f30366166366561326465333232633166.clone()).member("value", false)), ("composing", Value::boolean(((v_6576656e745f5f30366166366561326465333232633166.clone()).member("composing", false)).bool())), ("data", (v_6576656e745f5f30366166366561326465333232633166.clone()).member("data", false)), ("inputType", (v_6576656e745f5f30366166366561326465333232633166.clone()).member("inputType", false))]));
            // Source "packages/prototypes/base/src/input/root.proto.ts":201:5
            { let v_7075695f6e61746976655f323032 = v_72756e5f5f66343237653333626638663865366433.clone(); emit(&(v_7075695f6e61746976655f323032.clone()).owner(), Value::string("valueChange"), v_64657461696c5f5f36346264646237643732363963613635.clone()) };
            Value::Undefined
        })) }) };
        // Source "packages/prototypes/base/src/input/root.proto.ts":203:3
        { let v_7075695f6e61746976655f323033 = v_636f6e74726f6c.read(); text_on(&(v_7075695f6e61746976655f323033.clone()).owner(), Value::string("change"), {  let v_636f6e74726f6c = v_636f6e74726f6c.clone(); let v_76616c7565 = v_76616c7565.clone(); let v_63757272656e7456696577 = v_63757272656e7456696577.clone(); let v_7669657745706f6368 = v_7669657745706f6368.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_72756e5f5f30633433663566333463616463373837: Value = arg(&arguments, 0);
            let v_6576656e745f5f39326238373862656137306265336264: Value = arg(&arguments, 1);
            // Source "packages/prototypes/base/src/input/root.proto.ts":204:11
            let v_65706f63685f5f33376364323664313064653635393464: f64 = { let value=(v_7669657745706f6368.read()).borrow().clone(); value };
            // Source "packages/prototypes/base/src/input/root.proto.ts":205:5
            { let v_7075695f6e61746976655f323034 = v_76616c7565.read(); state_set(v_7075695f6e61746976655f323034.clone(), { let left = ({ let v_7075695f6e61746976655f323035 = v_636f6e74726f6c.read(); text_snapshot(&(v_7075695f6e61746976655f323035.clone()).owner()) }).member("value", true); if left.nullish() { (v_6576656e745f5f39326238373862656137306265336264.clone()).member("value", false) } else { left } }, Value::string("reason: input change value")) };
            // Source "packages/prototypes/base/src/input/root.proto.ts":206:5
            if { let pui_native_206=(Value::boolean(!strict_equal(&({ let value = (v_63757272656e7456696577.read()).borrow().clone(); value }), &(v_72756e5f5f30633433663566333463616463373837.clone())))).bool(); if !(pui_native_206) {{ let pui_native_210={ let value=(v_7669657745706f6368.read()).borrow().clone(); value }; let pui_native_211=v_65706f63685f5f33376364323664313064653635393464.clone(); !(pui_native_210==pui_native_211) }} else {pui_native_206} } {
                // Source "packages/prototypes/base/src/input/root.proto.ts":206:53
                return Value::Undefined;
            }
            // Source "packages/prototypes/base/src/input/root.proto.ts":207:5
            { let v_7075695f6e61746976655f323132 = v_72756e5f5f30633433663566333463616463373837.clone(); emit(&(v_7075695f6e61746976655f323132.clone()).owner(), Value::string("change"), freeze(record(vec![("value", (v_6576656e745f5f39326238373862656137306265336264.clone()).member("value", false))]))) };
            Value::Undefined
        })) }) };
        // Source "packages/prototypes/base/src/input/root.proto.ts":209:9
        v_656d6974436f6d706f736974696f6e.initialize({   Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_72756e5f5f36633639333531616464373061663434: Value = arg(&arguments, 0);
            let v_6576656e744e616d65: Value = arg(&arguments, 1);
            let v_6576656e745f5f35613766323536363065373734653737: Value = arg(&arguments, 2);
            // Source "packages/prototypes/base/src/input/root.proto.ts":214:11
            let v_64657461696c5f5f39613962636431633038396136633464 = freeze(record(vec![("value", (v_6576656e745f5f35613766323536363065373734653737.clone()).member("value", false)), ("data", (v_6576656e745f5f35613766323536363065373734653737.clone()).member("data", false))]));
            // Source "packages/prototypes/base/src/input/root.proto.ts":215:5
            { let v_7075695f6e61746976655f323133 = v_72756e5f5f36633639333531616464373061663434.clone(); emit(&(v_7075695f6e61746976655f323133.clone()).owner(), v_6576656e744e616d65.clone(), v_64657461696c5f5f39613962636431633038396136633464.clone()) };
            Value::Undefined
        })) });
        // Source "packages/prototypes/base/src/input/root.proto.ts":217:3
        { let v_7075695f6e61746976655f323134 = v_636f6e74726f6c.read(); text_on(&(v_7075695f6e61746976655f323134.clone()).owner(), Value::string("compositionstart"), {  let v_636f6d706f73696e67 = v_636f6d706f73696e67.clone(); let v_63757272656e7456696577 = v_63757272656e7456696577.clone(); let v_7669657745706f6368 = v_7669657745706f6368.clone(); let v_656d6974436f6d706f736974696f6e = v_656d6974436f6d706f736974696f6e.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_72756e5f5f38356333323064333961343532323838: Value = arg(&arguments, 0);
            let v_6576656e745f5f36636535396431336134626637656137: Value = arg(&arguments, 1);
            // Source "packages/prototypes/base/src/input/root.proto.ts":218:11
            let v_65706f63685f5f31653037323564396238393561373062: f64 = { let value=(v_7669657745706f6368.read()).borrow().clone(); value };
            // Source "packages/prototypes/base/src/input/root.proto.ts":219:5
            { let v_7075695f6e61746976655f323135 = v_636f6d706f73696e67.read(); state_set(v_7075695f6e61746976655f323135.clone(), Value::boolean(true), Value::string("reason: input composition start")) };
            // Source "packages/prototypes/base/src/input/root.proto.ts":220:5
            if { let pui_native_216=(Value::boolean(!strict_equal(&({ let value = (v_63757272656e7456696577.read()).borrow().clone(); value }), &(v_72756e5f5f38356333323064333961343532323838.clone())))).bool(); if !(pui_native_216) {{ let pui_native_220={ let value=(v_7669657745706f6368.read()).borrow().clone(); value }; let pui_native_221=v_65706f63685f5f31653037323564396238393561373062.clone(); !(pui_native_220==pui_native_221) }} else {pui_native_216} } {
                // Source "packages/prototypes/base/src/input/root.proto.ts":220:53
                return Value::Undefined;
            }
            // Source "packages/prototypes/base/src/input/root.proto.ts":221:5
            v_656d6974436f6d706f736974696f6e.read().call_authored(vec![v_72756e5f5f38356333323064333961343532323838.clone(), Value::string("compositionStart"), v_6576656e745f5f36636535396431336134626637656137.clone()]);
            Value::Undefined
        })) }) };
        // Source "packages/prototypes/base/src/input/root.proto.ts":223:3
        { let v_7075695f6e61746976655f323232 = v_636f6e74726f6c.read(); text_on(&(v_7075695f6e61746976655f323232.clone()).owner(), Value::string("compositionupdate"), {  let v_656d6974436f6d706f736974696f6e = v_656d6974436f6d706f736974696f6e.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_72756e5f5f64316431633330363838326639343362: Value = arg(&arguments, 0);
            let v_6576656e745f5f65663561396239363265313838363864: Value = arg(&arguments, 1);
            // Source "packages/prototypes/base/src/input/root.proto.ts":223:51
            return v_656d6974436f6d706f736974696f6e.read().call_authored(vec![v_72756e5f5f64316431633330363838326639343362.clone(), Value::string("compositionUpdate"), v_6576656e745f5f65663561396239363265313838363864.clone()]);
        })) }) };
        // Source "packages/prototypes/base/src/input/root.proto.ts":224:3
        { let v_7075695f6e61746976655f323233 = v_636f6e74726f6c.read(); text_on(&(v_7075695f6e61746976655f323233.clone()).owner(), Value::string("compositionend"), {  let v_636f6e74726f6c = v_636f6e74726f6c.clone(); let v_76616c7565 = v_76616c7565.clone(); let v_636f6d706f73696e67 = v_636f6d706f73696e67.clone(); let v_63757272656e7456696577 = v_63757272656e7456696577.clone(); let v_7669657745706f6368 = v_7669657745706f6368.clone(); let v_656d6974436f6d706f736974696f6e = v_656d6974436f6d706f736974696f6e.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_72756e5f5f66663037383535393665393636636332: Value = arg(&arguments, 0);
            let v_6576656e745f5f30363664366433376266323266346464: Value = arg(&arguments, 1);
            // Source "packages/prototypes/base/src/input/root.proto.ts":225:11
            let v_65706f63685f5f37626438333832393233386632656563: f64 = { let value=(v_7669657745706f6368.read()).borrow().clone(); value };
            // Source "packages/prototypes/base/src/input/root.proto.ts":226:5
            { let v_7075695f6e61746976655f323234 = v_636f6d706f73696e67.read(); state_set(v_7075695f6e61746976655f323234.clone(), Value::boolean(false), Value::string("reason: input composition end")) };
            // Source "packages/prototypes/base/src/input/root.proto.ts":227:5
            if { let pui_native_225=(Value::boolean(!strict_equal(&({ let value = (v_63757272656e7456696577.read()).borrow().clone(); value }), &(v_72756e5f5f66663037383535393665393636636332.clone())))).bool(); if !(pui_native_225) {{ let pui_native_229={ let value=(v_7669657745706f6368.read()).borrow().clone(); value }; let pui_native_230=v_65706f63685f5f37626438333832393233386632656563.clone(); !(pui_native_229==pui_native_230) }} else {pui_native_225} } {
                // Source "packages/prototypes/base/src/input/root.proto.ts":227:53
                return Value::Undefined;
            }
            // Source "packages/prototypes/base/src/input/root.proto.ts":228:5
            { let v_7075695f6e61746976655f323331 = v_76616c7565.read(); state_set(v_7075695f6e61746976655f323331.clone(), { let left = ({ let v_7075695f6e61746976655f323332 = v_636f6e74726f6c.read(); text_snapshot(&(v_7075695f6e61746976655f323332.clone()).owner()) }).member("value", true); if left.nullish() { (v_6576656e745f5f30363664366433376266323266346464.clone()).member("value", false) } else { left } }, Value::string("reason: input composition end value")) };
            // Source "packages/prototypes/base/src/input/root.proto.ts":229:5
            if { let pui_native_233=(Value::boolean(!strict_equal(&({ let value = (v_63757272656e7456696577.read()).borrow().clone(); value }), &(v_72756e5f5f66663037383535393665393636636332.clone())))).bool(); if !(pui_native_233) {{ let pui_native_237={ let value=(v_7669657745706f6368.read()).borrow().clone(); value }; let pui_native_238=v_65706f63685f5f37626438333832393233386632656563.clone(); !(pui_native_237==pui_native_238) }} else {pui_native_233} } {
                // Source "packages/prototypes/base/src/input/root.proto.ts":229:53
                return Value::Undefined;
            }
            // Source "packages/prototypes/base/src/input/root.proto.ts":230:5
            v_656d6974436f6d706f736974696f6e.read().call_authored(vec![v_72756e5f5f66663037383535393665393636636332.clone(), Value::string("compositionEnd"), v_6576656e745f5f30363664366433376266323266346464.clone()]);
            Value::Undefined
        })) }) };
        // Source "packages/prototypes/base/src/input/root.proto.ts":232:3
        return { let callable={   Value::Function(Rc::new(move |_: Vec<Value>| {
            // Source "packages/prototypes/base/src/input/root.proto.ts":232:16
            return Value::Json(Json::Null);
        })) }; match callable {
      Value::NativeFunction{identity,render} => capture_renderer(Value::NativeFunction{identity,render:render.clone()},render),
      Value::Renderer(adapter) => Value::Renderer(adapter),
      Value::Function(callback) => capture_renderer(Value::Function(callback.clone()),Rc::new(move |arguments:Vec<Value>| { { let pui_native_239 = callback(arguments); if matches!(&pui_native_239, Value::Json(Json::Null)) { native::gpui_native_owner::NativeSnapshot::empty() } else { native::gpui_native_owner::NativeSnapshot::invalid(pui_native_239) } } })),
      _ => panic!("checked setup result must be a callable")
    } };
    })) }, Value::Undefined, Value::Undefined)
}
  #[derive(Clone)]
  pub struct CompiledComponentHandle { pub owner: OwnerRef }
  impl CompiledComponentHandle {
      pub fn state_0(&self) -> Result<String, Value> { self.state("value").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_1(&self) -> Result<bool, Value> { self.state("disabled").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_2(&self) -> Result<bool, Value> { self.state("readOnly").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_3(&self) -> Result<bool, Value> { self.state("focused").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_4(&self) -> Result<bool, Value> { self.state("focusVisible").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_5(&self) -> Result<bool, Value> { self.state("composing").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn method_6(&self, argument_0: Option<GeneratedData3>, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![argument_0.map(|value| Value::json(serde_json::to_value(value).expect("portable argument"))).unwrap_or(Value::Undefined)];
        let callback = self.owner.borrow().exposes.get("focusSelf").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("focusSelf", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_7(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("blurSelf").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("blurSelf", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_8(&self, argument_0: Option<String>, window: &mut Window, cx: &mut App) -> Result<bool, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![argument_0.map(|value| Value::json(serde_json::to_value(value).expect("portable argument"))).unwrap_or(Value::Undefined)];
        let callback = self.owner.borrow().exposes.get("resetValue").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("resetValue", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_boolean()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
      pub fn owner(&self) -> OwnerWeak { Rc::downgrade(&self.owner) }
      pub fn state(&self, name: &str) -> Result<Json, Value> { catch_authored(|| { let state=self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed State")); state.get().data() }) }
      pub fn call(&self, name: &str, arguments: Vec<Json>, window: &mut Window, cx: &mut App) -> Result<Json, Value> {
          let outcome = catch_authored(|| {
          refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
          let callback = self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed method"));
          let arguments: Vec<Value> = arguments.into_iter().map(Value::json).collect(); check_method(name, &arguments);
          let result = invoke(&self.owner, "expose-method", &callback, arguments);
          let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
          if matches!(result, Value::Undefined) { Json::Null } else { result.data() }
          });
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome
      }
      pub fn host_target(&self) -> Result<Value, Value> { catch_authored(|| { ensure(&self.owner()); Value::HostTarget(self.owner()) }) }
      pub fn take_events(&self) -> Vec<(String, Json)> { std::mem::take(&mut self.owner.borrow_mut().emitted) }
      pub fn take_failures(&self) -> Vec<NativeFailure> { take_native_failures(&self.owner) }
      pub fn dispose(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
          catch_authored(|| {
          let drive = self.owner.borrow().native_drive.clone();
          let failure = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| Owner::dispose(&self.owner)));
          let driven = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| { if let Some(drive) = drive { drive(window, cx); } }));
          if let Err(failure) = failure { std::panic::resume_unwind(failure); }
          if let Err(failure) = driven { std::panic::resume_unwind(failure); }
          })
      }
  }
  pub struct CompiledComponent { pub owner: OwnerRef, focus: FocusHandle, window_input: Option<FocusHandle>, _focus_subscriptions: Vec<Subscription>, _window_activation: Option<(gpui::WindowId, Subscription)>, _focus_lost: Option<Subscription>, _global_key_capture: Option<Subscription>, _entry_readiness: Option<(gpui::WindowId, Subscription)> }
  impl CompiledComponent {
      pub fn create_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> { Self::create(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn create(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          Self::create_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn create_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          let mut failure = None;
          let entity = cx.new(|cx| Self::new_with_associations(raw_props, parent, associations, window, cx).unwrap_or_else(|error| {
              failure = Some(error);
              // A failed construction still returns normally through GPUI's
              // entity insertion. This inert temporary is dropped immediately
              // below; it is never published or mounted as a native component.
              let owner = Owner::new(Json::Object(Default::default()), Default::default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
              { let mut owner = owner.borrow_mut(); owner.disposed = true; owner.present = false; }
              Self { owner, focus: cx.focus_handle(), window_input: None, _focus_subscriptions: Vec::new(), _window_activation: None, _focus_lost: None, _global_key_capture: None, _entry_readiness: None }
          }));
          match failure { Some(error) => Err(error), None => Ok(entity) }
      }
      pub fn new_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> { Self::new(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn new(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          Self::new_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn new_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          catch_authored(|| {
          let owner_ref = Owner::new(raw_props, parent.unwrap_or_default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
          initialize_instance_associations(&owner_ref, associations);
          let owner = Rc::downgrade(&owner_ref);
          let focus = cx.focus_handle();
          let view = cx.entity().downgrade();
          let drive_owner=owner.clone(); let drive_focus=focus.clone();
          let driving = Rc::new(std::cell::Cell::new(false));
          let drive_pending = Rc::new(std::cell::Cell::new(false));
          let drive: Drive = Rc::new(move |window, cx| {
              // Platform effects need owner storage and its real FocusHandle,
              // not another lease of the generated component. Preserve their
              // synchronous effect (notably physical focus) under public calls.
              if !driving.replace(true) {
                  if let Some(owner)=drive_owner.upgrade() {
                      native_host_callback(&owner, "drive", || { modules_drive(&owner, &drive_focus, window, cx); drive_queued_focus(&owner, window, cx); });
                  }
                  driving.set(false);
              }
              if drive_pending.replace(true) { return; }
              let view=view.clone(); let pending=drive_pending.clone();
              // A public handle can be called from Entity::update. Return the
              // current host lease before requesting another component update.
              // Authored calls, State writes and platform commands remain
              // synchronous; component refresh is coalesced at the host boundary.
              window.defer(cx, move |window, cx| {
                  pending.set(false);
                  let _ = view.update(cx, |view, cx| { if let Err(error) = view.drive(window, cx) { report_native_failure(&view.owner, "drive", error); } });
              });
          });
          { let mut owner = owner_ref.borrow_mut(); owner.native_drive = Some(drive); owner.window_id = Some(window.window_handle().window_id()); }
          text_declaration(&owner, false);
          configure_native_atoms(&owner_ref, false, false);
          refresh_native_atoms(&owner_ref, window, cx);
          let _lexical_owner = enter_lexical_owner(&owner);
          let renderer = { let owner = owner.clone();  Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_5f646566: Value = arg(&arguments, 0);
            let v_7374617465: LexicalBinding<Value> = lexical_binding();
            let v_666f63757361626c655f5f33656366326535333238633364636464: LexicalBinding<Value> = lexical_binding();
            // Source "packages/prototypes/base/src/input/root.proto.ts":247:9
            let v_696e68657269746564 = authored_hook_0(definition_capability(&owner), Value::Undefined);
            // Source "packages/prototypes/base/src/input/root.proto.ts":248:9
            v_7374617465.initialize((v_696e68657269746564.clone()).member("stateHandles", false));
            // Source "packages/prototypes/base/src/input/root.proto.ts":249:3
            if !((v_7374617465.read()).truthy()) {
                // Source "packages/prototypes/base/src/input/root.proto.ts":249:15
                throw_value(record(vec![("name", Value::string("Error")), ("message", (Value::string("[base-input-root] editing state projection is required.")).error_message_value())]));
            }
            // Source "packages/prototypes/base/src/input/root.proto.ts":250:9
            v_666f63757361626c655f5f33656366326535333238633364636464.initialize(native_builtin_hook(&owner, "asFocusable", || as_focusable(&owner)));
            // Source "packages/prototypes/base/src/input/root.proto.ts":251:3
            { let v_7075695f6e61746976655f323430 = native_builtin_hook(&owner, "asControlLabel", || module_handle(&owner, "control-label")); control_label_declare(&(v_7075695f6e61746976655f323430.clone()).owner(), true, {  let v_7374617465 = v_7374617465.clone(); let v_666f63757361626c655f5f33656366326535333238633364636464 = v_666f63757361626c655f5f33656366326535333238633364636464.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_5f: Value = arg(&arguments, 0);
                let v_72657175657374: Value = arg(&arguments, 1);
                // Source "packages/prototypes/base/src/input/root.proto.ts":252:5
                if { let pui_native_241=!(({ let v_7075695f6e61746976655f323433 = (v_7374617465.read()).member("disabled", false); Value::boolean(((v_7075695f6e61746976655f323433.clone()).get()).bool()) }).bool()); if (pui_native_241) {({ let v_7075695f6e61746976655f323434 = v_72657175657374.clone(); Value::boolean((control_label_request_current(v_7075695f6e61746976655f323434.clone())).bool()) }).bool()} else {pui_native_241} } {
                    // Source "packages/prototypes/base/src/input/root.proto.ts":253:7
                    { let v_7075695f6e61746976655f323435 = v_666f63757361626c655f5f33656366326535333238633364636464.read(); focus_request(&(v_7075695f6e61746976655f323435.clone()).owner(), record(vec![("reason", if (Value::boolean((Value::boolean(strict_equal(&((v_72657175657374.clone()).member("source", false)), &(Value::string("pointer"))))).bool())).truthy() { Value::string("pointer") } else { Value::string("programmatic") })]), false) };
                }
                Value::Undefined
            })) }, Value::Undefined) };
            // Source "packages/prototypes/base/src/input/root.proto.ts":255:3
            return { let callable=(v_696e68657269746564.clone()).member("render", false); match callable {
      Value::NativeFunction{identity,render} => capture_renderer(Value::NativeFunction{identity,render:render.clone()},render),
      Value::Renderer(adapter) => Value::Renderer(adapter),
      Value::Undefined => Value::Undefined,
      Value::Function(callback) => capture_renderer(Value::Function(callback.clone()),Rc::new(move |arguments:Vec<Value>| { { let pui_native_248 = callback(arguments); if matches!(&pui_native_248, Value::Json(Json::Null)) { native::gpui_native_owner::NativeSnapshot::empty() } else { native::gpui_native_owner::NativeSnapshot::invalid(pui_native_248) } } })),
      _ => panic!("checked setup result must be a callable")
    } };
        })) }.call_authored(vec![definition_capability(&owner)]);
          Owner::finish(&owner_ref, renderer);
          // Establish the App's default-action snapshot before any authored
          // global key capture can replace focus during the same keystroke.
          register_sequential_focus_owner(&owner_ref, cx);
          let focus_subscriptions = if native_focus_observation_needed(&owner_ref) {
          let focus_owner = owner_ref.clone();
          let on_focus = cx.on_focus(&focus, window, move |view, window, cx| {
              native_host_callback(&focus_owner, "focus", || {
              let epoch = focus_owner.borrow().epoch;
              if !ready(&focus_owner) || focus_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&focus_owner, window);
              native_focus_fact(&focus_owner, view.focus.is_focused(window));
              if !ready(&focus_owner) || focus_owner.borrow().epoch != epoch { return; }
              dispatch(&focus_owner, "host:focus", false, event_fields("host:focus"));
              if ready(&focus_owner) && focus_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          let blur_owner = owner_ref.clone();
          let on_blur = cx.on_blur(&focus, window, move |view, window, cx| {
              native_host_callback(&blur_owner, "blur", || {
              let epoch = blur_owner.borrow().epoch;
              if !ready(&blur_owner) || blur_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&blur_owner, window);
              native_focus_fact(&blur_owner, view.focus.is_focused(window));
              if !ready(&blur_owner) || blur_owner.borrow().epoch != epoch { return; }
              text_blur(&blur_owner, window, cx);
              dispatch(&blur_owner, "host:blur", false, event_fields("host:blur"));
              if ready(&blur_owner) && blur_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          // A native slot descendant can start this root's keyboard press
          // while the root FocusHandle itself is not focused. Its departure
          // from the physical subtree is distinct from the root's own blur.
          let focus_out_owner = Rc::downgrade(&owner_ref);
          let on_focus_out = cx.on_focus_out(&focus, window, move |view, _, window, cx| {
              let Some(owner) = focus_out_owner.upgrade() else { return; };
              native_host_callback(&owner, "focus-out", || {
              let epoch = owner.borrow().epoch;
              if !ready(&owner) || owner.borrow().window_id != Some(window.window_handle().window_id()) || view.focus.contains_focused(window, cx) { return; }
              // This retires only an existing root press lease. Do not forge
              // host:blur or change the root's own Focus observation here.
              native_press_blur(&owner);
              if ready(&owner) && owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          vec![on_focus, on_blur, on_focus_out]
          } else { Vec::new() };
          let global_key_capture = subscribe_global_key_capture(&owner_ref, cx);
          let window_input = window_input_needed(&owner_ref).then(|| cx.focus_handle().tab_stop(false));
          let focus_lost = window_input.as_ref().map(|_| cx.on_focus_lost(window, |view, window, cx| { let owner=view.owner.clone(); native_host_callback(&owner, "focus-lost", || { if view.owner.borrow().window_id == Some(window.window_handle().window_id()) { if let Some(focus) = &view.window_input { restore_window_input(&view.owner, focus, window, cx); } } }); }));
          let mut view = Self { owner: owner_ref, focus, window_input, _focus_subscriptions: focus_subscriptions, _window_activation: None, _focus_lost: focus_lost, _global_key_capture: global_key_capture, _entry_readiness: None };
          view.bind_window_activation(window, cx);
          view
          })
      }
      #[cfg(feature="test-support")]
      pub fn native_resource_counts(&self) -> Json { let mut counts=native::gpui_native_owner::native_resource_counts(&self.owner); counts["nativeSubscriptions"] = Json::from(self._focus_subscriptions.len() + usize::from(self._window_activation.is_some()) + usize::from(self._focus_lost.is_some()) + usize::from(self._global_key_capture.is_some()) + usize::from(self._entry_readiness.is_some())); counts }
      pub fn handle(&self) -> CompiledComponentHandle { CompiledComponentHandle { owner: self.owner.clone() } }
      pub fn set_props(&mut self, raw: Json, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_props(&self.owner, raw));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; self.drive(window, cx)
      }
      pub fn set_instance_associations(&mut self, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_instance_associations(&self.owner, associations));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; drive_owners(window, cx); self.drive(window, cx)
      }
      pub fn set_slot(&mut self, slot: Vec<native::gpui_native_owner::NativeSnapshot>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { ensure(&Rc::downgrade(&self.owner)); assert_native_slot_children(&slot); let mut owner = self.owner.borrow_mut(); owner.slot = slot; owner.dirty = true; cx.notify(); }) }
      pub fn set_parent(&mut self, parent: Option<OwnerWeak>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { if let Err(error)=set_native_parent(&self.owner, parent.unwrap_or_default()){throw_error("NATIVE_PARENT_INVALID", error)} cx.notify(); }) }
      fn bind_window_activation(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !native_focus_observation_needed(&self.owner) && !native::gpui_native_move::move_owner_has_binding(&self.owner) && !control_label_is_label(&self.owner) { self._window_activation.take(); return; }
          let id = window.window_handle().window_id();
          if self._window_activation.as_ref().is_some_and(|(bound, _)| *bound == id) { return; }
          self._window_activation.take();
          let owner = self.owner.clone();
          let subscription = cx.observe_window_activation(window, move |view, window, cx| {
              let deactivated = owner.borrow().window_id == Some(window.window_handle().window_id()) && !window.is_window_active();
              native_host_callback(&owner, "window-activation", || {
                  if deactivated {
                      native_window_blur(&owner);
                      view.drive(window, cx).unwrap_or_else(|error| throw_value(error));
                  }
              });
              if deactivated { notify_native_change(cx); }
          });
          self._window_activation = Some((id, subscription));
      }
      #[cfg(feature = "experimental-focus-tree")]
      fn bind_entry_readiness(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !self.owner.borrow().modules.hooks.contains("focus-entry") { return; }
          let window_id = window.window_handle().window_id();
          if self._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window_id) { return; }
          self._entry_readiness.take();
          let view = cx.entity().downgrade();
          let subscription = window.observe_focus_tree(cx, move |_, window, cx| {
              let _ = view.update(cx, |view, cx| {
                  if view._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window.window_handle().window_id()) { if let Err(error)=view.drive(window, cx){report_native_failure(&view.owner,"entry-readiness",error)} }
              });
          });
          self._entry_readiness = Some((window_id, subscription));
      }
      fn notify_after_turn(&self, cx: &mut Context<Self>) {
          // GPUI suppresses Entity observer effects while a window is drawing,
          // including its focus/blur phase. Keep authored state synchronous,
          // then publish the host change after that physical draw lease ends.
          // A weak target cannot keep a detached component alive for delivery.
          notify_native_change(cx);
      }
      pub fn drive(&mut self, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let result = catch_authored(|| {
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          modules_drive(&self.owner, &self.focus, window, cx);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          drive_queued_focus(&self.owner, window, cx);
          });
          // A callback can publish before failing or retiring its owner. That
          // output is independent from repaint dirtiness and an unread queue.
          let dirty = std::mem::take(&mut self.owner.borrow_mut().dirty);
          if !notify_native_events(&self.owner, cx) && dirty { self.notify_after_turn(cx); }
          result
      }
  }
  impl Drop for CompiledComponent { fn drop(&mut self) { native_host_callback(&self.owner, "drop", || Owner::dispose(&self.owner)); } }
  impl gpui::Focusable for CompiledComponent { fn focus_handle(&self, _: &App) -> FocusHandle { self.focus.clone() } }
  impl Render for CompiledComponent {
      fn render(&mut self, window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
          let report_owner = self.owner.clone();
          native_host_callback(&report_owner, "render", || {
          refresh_native_atoms(&self.owner, window, cx);
          Owner::project(&self.owner);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); return gpui::div().into_any_element(); }
          if !self.owner.borrow().present { self._window_activation.take(); detach_native_view(&self.owner); return gpui::div().into_any_element(); }
          bind_native_focus_window(&self.owner, window);
          self.bind_window_activation(window, cx);
          #[cfg(feature = "experimental-focus-tree")] self.bind_entry_readiness(window, cx);
          let drive = self.owner.borrow().native_drive.as_ref().expect("live native owner drive").clone();
          // Drawing consumes only repaint dirtiness. A parent Render can call
          // an exposed method before this child is laid out: its independent
          // pending_native_events flag survives until the coalesced drive wakes
          // the consumer. Repeated slot projection cannot create a notify loop.
          self.owner.borrow_mut().dirty = false;
          let snapshot = self.owner.borrow().projection.clone().expect("live native projection");
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          let element = paint_native_root(&snapshot, &self.owner, &self.focus, format!("compiled-root-{}", Rc::as_ptr(&self.owner) as usize), drive);
          if let Some(focus) = &self.window_input { window_input_scope(element, focus, &self.owner) } else { element }
          }).unwrap_or_else(|| gpui::div().into_any_element())
      }
  }
  