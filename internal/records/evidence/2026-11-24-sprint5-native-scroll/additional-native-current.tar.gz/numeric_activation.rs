// Direct checked-source GPUI component. Supporting files are ordinary editable Rust.
  
  pub use proto_ui_gpui_native as native;
  pub use native::gpui_native_owner::{ControlLabelRef, InstanceAssociations};
  use gpui::{prelude::*, App, Context, FocusHandle, Subscription, Window};
  use std::rc::Rc;
  use serde_json::Value as Json;
  use native::gpui_native_owner::*;
  
  
  fn style_vocabulary() -> &'static native::gpui_native_style::StyleVocabulary {
      static VOCABULARY: std::sync::OnceLock<native::gpui_native_style::StyleVocabulary> = std::sync::OnceLock::new();
      VOCABULARY.get_or_init(|| native::gpui_native_style::StyleVocabulary::from_json(include_str!(".proto-ui/fixtures/style-tokens.json")).expect("compiler-produced style vocabulary"))
  }
  fn accepts_context(key: &str, value: &Json) -> bool {
      match key {
          
          _ => false,
      }
  }
  fn accepts_props(value: &Json) -> bool { value.is_object() && value.get("disabled").map_or(true, |prop| prop.is_null() || prop.is_boolean()) }
  fn prop_valid(key: &str, value: &Json) -> bool { match key { "disabled" => value.is_boolean(), _ => false } }
  fn check_method(name: &str, arguments: &[Value]) { match name {
          "setDisabled" => if !(arguments.len() <= 1 && arguments.get(0).map_or(false, |value| (value).try_data().is_some_and(|data| data.is_boolean()))) { value_type_error("invalid exposed method arguments") },
        "setApplicable" => if !(arguments.len() <= 1 && arguments.get(0).map_or(false, |value| (value).try_data().is_some_and(|data| data.is_boolean()))) { value_type_error("invalid exposed method arguments") },
        "setSelected" => if !(arguments.len() <= 1 && arguments.get(0).map_or(false, |value| (value).try_data().is_some_and(|data| data.is_boolean()))) { value_type_error("invalid exposed method arguments") },
        "setObsolete" => if !(arguments.len() <= 1 && arguments.get(0).map_or(false, |value| (value).try_data().is_some_and(|data| data.is_boolean()))) { value_type_error("invalid exposed method arguments") },
          _ => value_error("unknown exposed method"),
  } }
  
  #[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData0 {
    #[serde(rename = "disabled", default, skip_serializing_if = "Option::is_none")]
    pub field_0: Option<bool>,
}
  
  pub type GeneratedProps = GeneratedData0;
  
  #[derive(Clone)]
  pub struct CompiledComponentHandle { pub owner: OwnerRef }
  impl CompiledComponentHandle {
      pub fn state_0(&self) -> Result<f64, Value> { self.state("count").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_1(&self) -> Result<bool, Value> { self.state("selected").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn method_3(&self, argument_0: bool, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![Value::json(serde_json::to_value(argument_0).expect("portable argument"))];
        let callback = self.owner.borrow().exposes.get("setDisabled").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("setDisabled", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_4(&self, argument_0: bool, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![Value::json(serde_json::to_value(argument_0).expect("portable argument"))];
        let callback = self.owner.borrow().exposes.get("setApplicable").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("setApplicable", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_5(&self, argument_0: bool, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![Value::json(serde_json::to_value(argument_0).expect("portable argument"))];
        let callback = self.owner.borrow().exposes.get("setSelected").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("setSelected", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_6(&self, argument_0: bool, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![Value::json(serde_json::to_value(argument_0).expect("portable argument"))];
        let callback = self.owner.borrow().exposes.get("setObsolete").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("setObsolete", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
      pub fn owner(&self) -> OwnerWeak { Rc::downgrade(&self.owner) }
      pub fn state(&self, name: &str) -> Result<Json, Value> { catch_authored(|| { let state=self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed State")); state.get().data() }) }
      pub fn call(&self, name: &str, arguments: Vec<Json>, window: &mut Window, cx: &mut App) -> Result<Json, Value> {
          let outcome = catch_authored(|| {
          refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
          let callback = self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed method"));
          let arguments: Vec<Value> = arguments.into_iter().map(Value::json).collect(); check_method(name, &arguments);
          let result = invoke(&self.owner, "expose-method", &callback, arguments);
          let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
          if matches!(result, Value::Undefined) { Json::Null } else { result.data() }
          });
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome
      }
      pub fn host_target(&self) -> Result<Value, Value> { catch_authored(|| { ensure(&self.owner()); Value::HostTarget(self.owner()) }) }
      pub fn take_events(&self) -> Vec<(String, Json)> { std::mem::take(&mut self.owner.borrow_mut().emitted) }
      pub fn take_failures(&self) -> Vec<NativeFailure> { take_native_failures(&self.owner) }
      pub fn dispose(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
          catch_authored(|| {
          let drive = self.owner.borrow().native_drive.clone();
          let failure = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| Owner::dispose(&self.owner)));
          let driven = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| { if let Some(drive) = drive { drive(window, cx); } }));
          if let Err(failure) = failure { std::panic::resume_unwind(failure); }
          if let Err(failure) = driven { std::panic::resume_unwind(failure); }
          })
      }
  }
  pub struct CompiledComponent { pub owner: OwnerRef, focus: FocusHandle, window_input: Option<FocusHandle>, _focus_subscriptions: Vec<Subscription>, _window_activation: Option<(gpui::WindowId, Subscription)>, _focus_lost: Option<Subscription>, _global_key_capture: Option<Subscription>, _entry_readiness: Option<(gpui::WindowId, Subscription)> }
  impl CompiledComponent {
      pub fn create_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> { Self::create(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn create(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          Self::create_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn create_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          let mut failure = None;
          let entity = cx.new(|cx| Self::new_with_associations(raw_props, parent, associations, window, cx).unwrap_or_else(|error| {
              failure = Some(error);
              // A failed construction still returns normally through GPUI's
              // entity insertion. This inert temporary is dropped immediately
              // below; it is never published or mounted as a native component.
              let owner = Owner::new(Json::Object(Default::default()), Default::default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
              { let mut owner = owner.borrow_mut(); owner.disposed = true; owner.present = false; }
              Self { owner, focus: cx.focus_handle(), window_input: None, _focus_subscriptions: Vec::new(), _window_activation: None, _focus_lost: None, _global_key_capture: None, _entry_readiness: None }
          }));
          match failure { Some(error) => Err(error), None => Ok(entity) }
      }
      pub fn new_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> { Self::new(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn new(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          Self::new_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn new_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          catch_authored(|| {
          let owner_ref = Owner::new(raw_props, parent.unwrap_or_default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
          initialize_instance_associations(&owner_ref, associations);
          let owner = Rc::downgrade(&owner_ref);
          let focus = cx.focus_handle();
          let view = cx.entity().downgrade();
          let drive_owner=owner.clone(); let drive_focus=focus.clone();
          let driving = Rc::new(std::cell::Cell::new(false));
          let drive_pending = Rc::new(std::cell::Cell::new(false));
          let drive: Drive = Rc::new(move |window, cx| {
              // Platform effects need owner storage and its real FocusHandle,
              // not another lease of the generated component. Preserve their
              // synchronous effect (notably physical focus) under public calls.
              if !driving.replace(true) {
                  if let Some(owner)=drive_owner.upgrade() {
                      native_host_callback(&owner, "drive", || { modules_drive(&owner, &drive_focus, window, cx); drive_queued_focus(&owner, window, cx); });
                  }
                  driving.set(false);
              }
              if drive_pending.replace(true) { return; }
              let view=view.clone(); let pending=drive_pending.clone();
              // A public handle can be called from Entity::update. Return the
              // current host lease before requesting another component update.
              // Authored calls, State writes and platform commands remain
              // synchronous; component refresh is coalesced at the host boundary.
              window.defer(cx, move |window, cx| {
                  pending.set(false);
                  let _ = view.update(cx, |view, cx| { if let Err(error) = view.drive(window, cx) { report_native_failure(&view.owner, "drive", error); } });
              });
          });
          { let mut owner = owner_ref.borrow_mut(); owner.native_drive = Some(drive); owner.window_id = Some(window.window_handle().window_id()); }
  
          configure_native_atoms(&owner_ref, false, false);
          refresh_native_atoms(&owner_ref, window, cx);
          let _lexical_owner = enter_lexical_owner(&owner);
          let renderer = { let owner = owner.clone();  Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_646566: Value = arg(&arguments, 0);
            let v_64697361626c6564: LexicalBinding<Value> = lexical_binding();
            let v_73656c6563746564: LexicalBinding<Value> = lexical_binding();
            let v_6170706c696361626c65: LexicalBinding<Value> = lexical_binding();
            let v_6f62736f6c657465: LexicalBinding<Value> = lexical_binding();
            let v_636f756e74: LexicalBinding<Value> = lexical_binding();
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":9:5
            { let v_7075695f6e61746976655f30 = v_646566.clone(); props_define(&owner, record(vec![("disabled", record(vec![("type", Value::string("boolean")), ("default", Value::boolean(false))]))])) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":10:5
            native_builtin_hook(&owner, "asTrigger", || as_trigger(&owner));
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":11:11
            v_64697361626c6564.initialize({ let v_7075695f6e61746976655f31 = v_646566.clone(); create_state(&owner, "bool", Value::string("disabled"), Value::boolean(false), Value::Undefined) });
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":12:11
            v_73656c6563746564.initialize({ let v_7075695f6e61746976655f32 = v_646566.clone(); create_state(&owner, "bool", Value::string("selected"), Value::boolean(false), Value::Undefined) });
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":13:11
            v_6170706c696361626c65.initialize({ let v_7075695f6e61746976655f33 = v_646566.clone(); create_state(&owner, "bool", Value::string("applicable"), Value::boolean(false), Value::Undefined) });
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":14:11
            v_6f62736f6c657465.initialize({ let v_7075695f6e61746976655f34 = v_646566.clone(); create_state(&owner, "bool", Value::string("obsolete"), Value::boolean(true), Value::Undefined) });
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":15:11
            v_636f756e74.initialize({ let v_7075695f6e61746976655f35 = v_646566.clone(); create_state(&owner, "discrete", Value::string("count"), Value::number(0.0_f64), Value::Undefined) });
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":16:11
            let v_61636365737369626c65 = native_builtin_hook(&owner, "asAccessible", || as_accessible(&owner));
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":17:5
            { let v_7075695f6e61746976655f36 = v_61636365737369626c65.clone(); accessible_role(&(v_7075695f6e61746976655f36.clone()).owner(), Value::string("button")) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":18:5
            { let v_7075695f6e61746976655f37 = v_61636365737369626c65.clone(); accessible_text(&(v_7075695f6e61746976655f37.clone()).owner(), "name", Value::string("Native authored command")) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":19:5
            { let v_7075695f6e61746976655f38 = v_61636365737369626c65.clone(); accessible_state(&(v_7075695f6e61746976655f38.clone()).owner(), Value::string("disabled"), v_64697361626c6564.read(), Value::Undefined) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":20:5
            { let v_7075695f6e61746976655f39 = v_61636365737369626c65.clone(); accessible_state(&(v_7075695f6e61746976655f39.clone()).owner(), Value::string("pressed"), v_6f62736f6c657465.read(), Value::Undefined) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":21:5
            { let v_7075695f6e61746976655f3130 = v_61636365737369626c65.clone(); accessible_state(&(v_7075695f6e61746976655f3130.clone()).owner(), Value::string("pressed"), v_73656c6563746564.read(), record(vec![("when", v_6170706c696361626c65.read())])) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":22:5
            { let v_7075695f6e61746976655f3131 = v_61636365737369626c65.clone(); accessible_state(&(v_7075695f6e61746976655f3131.clone()).owner(), Value::string("selected"), v_73656c6563746564.read(), record(vec![("when", v_6170706c696361626c65.read())])) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":23:5
            { let v_7075695f6e61746976655f3132 = v_61636365737369626c65.clone(); accessible_state(&(v_7075695f6e61746976655f3132.clone()).owner(), Value::string("expanded"), v_73656c6563746564.read(), record(vec![("when", v_6170706c696361626c65.read())])) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":24:5
            { let v_7075695f6e61746976655f3133 = v_61636365737369626c65.clone(); accessible_action_spec(&(v_7075695f6e61746976655f3133.clone()).owner(), Value::string("activate"), record(vec![("event", Value::string("invoked"))])) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":25:5
            { let v_7075695f6e61746976655f3134 = v_646566.clone(); register_life(&owner, "created", {  let v_64697361626c6564 = v_64697361626c6564.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f30343830336163653632303638313230: Value = arg(&arguments, 0);
                // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":25:38
                return { let v_7075695f6e61746976655f3135 = v_64697361626c6564.read(); state_set(v_7075695f6e61746976655f3135.clone(), Value::boolean((({ let v_7075695f6e61746976655f3136 = v_72756e5f5f30343830336163653632303638313230.clone(); read_props(&(v_7075695f6e61746976655f3136.clone()).owner(), false) }).member("disabled", false)).bool()), Value::Undefined) };
            })) }) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":26:5
            { let v_7075695f6e61746976655f3137 = v_646566.clone(); expose_state(&owner, Value::string("count"), v_636f756e74.read()) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":27:5
            { let v_7075695f6e61746976655f3138 = v_646566.clone(); expose_state(&owner, Value::string("selected"), v_73656c6563746564.read()) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":28:5
            { let v_7075695f6e61746976655f3139 = v_646566.clone(); expose_event(&owner, Value::string("invoked")) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":29:5
            { let v_7075695f6e61746976655f3230 = v_646566.clone(); expose_method(&owner, Value::string("setDisabled"), ({  let v_64697361626c6564 = v_64697361626c6564.clone(); let call:Rc<dyn Fn(bool)->Value>=Rc::new(move |argument_0: bool| -> Value {
                let v_6e6578745f5f63366566383766653235643066316533: bool = argument_0;
                // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":29:57
                return { let v_7075695f6e61746976655f3231 = v_64697361626c6564.read(); state_set(v_7075695f6e61746976655f3231.clone(), Value::boolean(v_6e6578745f5f63366566383766653235643066316533.clone()), Value::Undefined) };
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).bool())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":30:5
            { let v_7075695f6e61746976655f3232 = v_646566.clone(); expose_method(&owner, Value::string("setApplicable"), ({  let v_6170706c696361626c65 = v_6170706c696361626c65.clone(); let call:Rc<dyn Fn(bool)->Value>=Rc::new(move |argument_0: bool| -> Value {
                let v_6e6578745f5f66623033303436643635633430333164: bool = argument_0;
                // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":30:59
                return { let v_7075695f6e61746976655f3233 = v_6170706c696361626c65.read(); state_set(v_7075695f6e61746976655f3233.clone(), Value::boolean(v_6e6578745f5f66623033303436643635633430333164.clone()), Value::Undefined) };
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).bool())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":31:5
            { let v_7075695f6e61746976655f3234 = v_646566.clone(); expose_method(&owner, Value::string("setSelected"), ({  let v_73656c6563746564 = v_73656c6563746564.clone(); let call:Rc<dyn Fn(bool)->Value>=Rc::new(move |argument_0: bool| -> Value {
                let v_6e6578745f5f63633663633535613537306337323335: bool = argument_0;
                // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":31:57
                return { let v_7075695f6e61746976655f3235 = v_73656c6563746564.read(); state_set(v_7075695f6e61746976655f3235.clone(), Value::boolean(v_6e6578745f5f63633663633535613537306337323335.clone()), Value::Undefined) };
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).bool())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":32:5
            { let v_7075695f6e61746976655f3236 = v_646566.clone(); expose_method(&owner, Value::string("setObsolete"), ({  let v_6f62736f6c657465 = v_6f62736f6c657465.clone(); let call:Rc<dyn Fn(bool)->Value>=Rc::new(move |argument_0: bool| -> Value {
                let v_6e6578745f5f38343061643238666562316662343365: bool = argument_0;
                // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":32:57
                return { let v_7075695f6e61746976655f3237 = v_6f62736f6c657465.read(); state_set(v_7075695f6e61746976655f3237.clone(), Value::boolean(v_6e6578745f5f38343061643238666562316662343365.clone()), Value::Undefined) };
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).bool())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":33:5
            { let v_7075695f6e61746976655f3238 = v_646566.clone(); listen(&owner, Value::string("press.commit"), false, {  let v_64697361626c6564 = v_64697361626c6564.clone(); let v_73656c6563746564 = v_73656c6563746564.clone(); let v_636f756e74 = v_636f756e74.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f33396239616562643866333561356239: Value = arg(&arguments, 0);
                let v_6576656e74: Value = arg(&arguments, 1);
                // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":34:7
                if ({ let v_7075695f6e61746976655f3239 = v_64697361626c6564.read(); Value::boolean(((v_7075695f6e61746976655f3239.clone()).get()).bool()) }).bool() {
                    // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":34:27
                    return Value::Undefined;
                }
                // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":35:7
                { let v_7075695f6e61746976655f3330 = v_636f756e74.read(); state_set(v_7075695f6e61746976655f3330.clone(), Value::number({ let pui_native_31:f64=({ let v_7075695f6e61746976655f3333 = v_636f756e74.read(); Value::number(((v_7075695f6e61746976655f3333.clone()).get()).num()) }).num(); let pui_native_32:f64=2.0_f64; pui_native_31 + pui_native_32 }), Value::Undefined) };
                // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":36:7
                { let v_7075695f6e61746976655f3334 = v_73656c6563746564.read(); state_set(v_7075695f6e61746976655f3334.clone(), Value::boolean(!(({ let v_7075695f6e61746976655f3335 = v_73656c6563746564.read(); Value::boolean(((v_7075695f6e61746976655f3335.clone()).get()).bool()) }).bool())), Value::Undefined) };
                // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":37:7
                { let v_7075695f6e61746976655f3336 = v_6576656e74.clone(); prevent(v_7075695f6e61746976655f3336.clone()) };
                // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":38:7
                { let v_7075695f6e61746976655f3337 = v_72756e5f5f33396239616562643866333561356239.clone(); emit(&(v_7075695f6e61746976655f3337.clone()).owner(), Value::string("invoked"), record(vec![("count", Value::number(({ let v_7075695f6e61746976655f3338 = v_636f756e74.read(); Value::number(((v_7075695f6e61746976655f3338.clone()).get()).num()) }).num())), ("selected", Value::boolean(({ let v_7075695f6e61746976655f3339 = v_73656c6563746564.read(); Value::boolean(((v_7075695f6e61746976655f3339.clone()).get()).bool()) }).bool()))])) };
                Value::Undefined
            })) }, Value::Undefined) };
            // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":40:5
            return { let callable={ let pui_native_40={   let call:Rc<dyn Fn(Value)->native::gpui_native_owner::NativeSnapshot>=Rc::new(move |argument_0: Value| -> native::gpui_native_owner::NativeSnapshot {
                let v_72: Value = argument_0;
                // Source "packages/compiler/test/fixtures/gpui-a11y-value/activation.proto.ts":40:19
                return { let v_7075695f6e61746976655f3431 = v_72.clone(); native::gpui_native_owner::NativeSnapshot::slot() };
            }); native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:None } }; Value::NativeFunction{identity:pui_native_40.identity.clone(),render:Rc::new(move |arguments:Vec<Value>| {(pui_native_40.call)(arg(&arguments,0))})} }; match callable {
      Value::NativeFunction{identity,render} => capture_renderer(Value::NativeFunction{identity,render:render.clone()},render),
      Value::Renderer(adapter) => Value::Renderer(adapter),
      Value::Function(callback) => capture_renderer(Value::Function(callback.clone()),Rc::new(move |arguments:Vec<Value>| { panic!("checked native renderer entry has no scalar callback alternative") })),
      _ => panic!("checked setup result must be a callable")
    } };
        })) }.call_authored(vec![definition_capability(&owner)]);
          Owner::finish(&owner_ref, renderer);
          // Establish the App's default-action snapshot before any authored
          // global key capture can replace focus during the same keystroke.
          register_sequential_focus_owner(&owner_ref, cx);
          let focus_subscriptions = if native_focus_observation_needed(&owner_ref) {
          let focus_owner = owner_ref.clone();
          let on_focus = cx.on_focus(&focus, window, move |view, window, cx| {
              native_host_callback(&focus_owner, "focus", || {
              let epoch = focus_owner.borrow().epoch;
              if !ready(&focus_owner) || focus_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&focus_owner, window);
              native_focus_fact(&focus_owner, view.focus.is_focused(window));
              if !ready(&focus_owner) || focus_owner.borrow().epoch != epoch { return; }
              dispatch(&focus_owner, "host:focus", false, event_fields("host:focus"));
              if ready(&focus_owner) && focus_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          let blur_owner = owner_ref.clone();
          let on_blur = cx.on_blur(&focus, window, move |view, window, cx| {
              native_host_callback(&blur_owner, "blur", || {
              let epoch = blur_owner.borrow().epoch;
              if !ready(&blur_owner) || blur_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&blur_owner, window);
              native_focus_fact(&blur_owner, view.focus.is_focused(window));
              if !ready(&blur_owner) || blur_owner.borrow().epoch != epoch { return; }
              text_blur(&blur_owner, window, cx);
              dispatch(&blur_owner, "host:blur", false, event_fields("host:blur"));
              if ready(&blur_owner) && blur_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          // A native slot descendant can start this root's keyboard press
          // while the root FocusHandle itself is not focused. Its departure
          // from the physical subtree is distinct from the root's own blur.
          let focus_out_owner = Rc::downgrade(&owner_ref);
          let on_focus_out = cx.on_focus_out(&focus, window, move |view, _, window, cx| {
              let Some(owner) = focus_out_owner.upgrade() else { return; };
              native_host_callback(&owner, "focus-out", || {
              let epoch = owner.borrow().epoch;
              if !ready(&owner) || owner.borrow().window_id != Some(window.window_handle().window_id()) || view.focus.contains_focused(window, cx) { return; }
              // This retires only an existing root press lease. Do not forge
              // host:blur or change the root's own Focus observation here.
              native_press_blur(&owner);
              if ready(&owner) && owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          vec![on_focus, on_blur, on_focus_out]
          } else { Vec::new() };
          let global_key_capture = subscribe_global_key_capture(&owner_ref, cx);
          let window_input = window_input_needed(&owner_ref).then(|| cx.focus_handle().tab_stop(false));
          let focus_lost = window_input.as_ref().map(|_| cx.on_focus_lost(window, |view, window, cx| { let owner=view.owner.clone(); native_host_callback(&owner, "focus-lost", || { if view.owner.borrow().window_id == Some(window.window_handle().window_id()) { if let Some(focus) = &view.window_input { restore_window_input(&view.owner, focus, window, cx); } } }); }));
          let mut view = Self { owner: owner_ref, focus, window_input, _focus_subscriptions: focus_subscriptions, _window_activation: None, _focus_lost: focus_lost, _global_key_capture: global_key_capture, _entry_readiness: None };
          view.bind_window_activation(window, cx);
          view
          })
      }
      #[cfg(feature="test-support")]
      pub fn native_resource_counts(&self) -> Json { let mut counts=native::gpui_native_owner::native_resource_counts(&self.owner); counts["nativeSubscriptions"] = Json::from(self._focus_subscriptions.len() + usize::from(self._window_activation.is_some()) + usize::from(self._focus_lost.is_some()) + usize::from(self._global_key_capture.is_some()) + usize::from(self._entry_readiness.is_some())); counts }
      pub fn handle(&self) -> CompiledComponentHandle { CompiledComponentHandle { owner: self.owner.clone() } }
      pub fn set_props(&mut self, raw: Json, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_props(&self.owner, raw));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; self.drive(window, cx)
      }
      pub fn set_instance_associations(&mut self, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_instance_associations(&self.owner, associations));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; drive_owners(window, cx); self.drive(window, cx)
      }
      pub fn set_slot(&mut self, slot: Vec<native::gpui_native_owner::NativeSnapshot>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { ensure(&Rc::downgrade(&self.owner)); assert_native_slot_children(&slot); let mut owner = self.owner.borrow_mut(); owner.slot = slot; owner.dirty = true; cx.notify(); }) }
      pub fn set_parent(&mut self, parent: Option<OwnerWeak>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { if let Err(error)=set_native_parent(&self.owner, parent.unwrap_or_default()){throw_error("NATIVE_PARENT_INVALID", error)} cx.notify(); }) }
      fn bind_window_activation(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !native_focus_observation_needed(&self.owner) && !native::gpui_native_move::move_owner_has_binding(&self.owner) && !control_label_is_label(&self.owner) { self._window_activation.take(); return; }
          let id = window.window_handle().window_id();
          if self._window_activation.as_ref().is_some_and(|(bound, _)| *bound == id) { return; }
          self._window_activation.take();
          let owner = self.owner.clone();
          let subscription = cx.observe_window_activation(window, move |view, window, cx| {
              let deactivated = owner.borrow().window_id == Some(window.window_handle().window_id()) && !window.is_window_active();
              native_host_callback(&owner, "window-activation", || {
                  if deactivated {
                      native_window_blur(&owner);
                      view.drive(window, cx).unwrap_or_else(|error| throw_value(error));
                  }
              });
              if deactivated { notify_native_change(cx); }
          });
          self._window_activation = Some((id, subscription));
      }
      #[cfg(feature = "experimental-focus-tree")]
      fn bind_entry_readiness(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !self.owner.borrow().modules.hooks.contains("focus-entry") { return; }
          let window_id = window.window_handle().window_id();
          if self._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window_id) { return; }
          self._entry_readiness.take();
          let view = cx.entity().downgrade();
          let subscription = window.observe_focus_tree(cx, move |_, window, cx| {
              let _ = view.update(cx, |view, cx| {
                  if view._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window.window_handle().window_id()) { if let Err(error)=view.drive(window, cx){report_native_failure(&view.owner,"entry-readiness",error)} }
              });
          });
          self._entry_readiness = Some((window_id, subscription));
      }
      fn notify_after_turn(&self, cx: &mut Context<Self>) {
          // GPUI suppresses Entity observer effects while a window is drawing,
          // including its focus/blur phase. Keep authored state synchronous,
          // then publish the host change after that physical draw lease ends.
          // A weak target cannot keep a detached component alive for delivery.
          notify_native_change(cx);
      }
      pub fn drive(&mut self, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let result = catch_authored(|| {
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          modules_drive(&self.owner, &self.focus, window, cx);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          drive_queued_focus(&self.owner, window, cx);
          });
          // A callback can publish before failing or retiring its owner. That
          // output is independent from repaint dirtiness and an unread queue.
          let dirty = std::mem::take(&mut self.owner.borrow_mut().dirty);
          if !notify_native_events(&self.owner, cx) && dirty { self.notify_after_turn(cx); }
          result
      }
  }
  impl Drop for CompiledComponent { fn drop(&mut self) { native_host_callback(&self.owner, "drop", || Owner::dispose(&self.owner)); } }
  impl gpui::Focusable for CompiledComponent { fn focus_handle(&self, _: &App) -> FocusHandle { self.focus.clone() } }
  impl Render for CompiledComponent {
      fn render(&mut self, window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
          let report_owner = self.owner.clone();
          native_host_callback(&report_owner, "render", || {
          refresh_native_atoms(&self.owner, window, cx);
          Owner::project(&self.owner);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); return gpui::div().into_any_element(); }
          if !self.owner.borrow().present { self._window_activation.take(); detach_native_view(&self.owner); return gpui::div().into_any_element(); }
          bind_native_focus_window(&self.owner, window);
          self.bind_window_activation(window, cx);
          #[cfg(feature = "experimental-focus-tree")] self.bind_entry_readiness(window, cx);
          let drive = self.owner.borrow().native_drive.as_ref().expect("live native owner drive").clone();
          // Drawing consumes only repaint dirtiness. A parent Render can call
          // an exposed method before this child is laid out: its independent
          // pending_native_events flag survives until the coalesced drive wakes
          // the consumer. Repeated slot projection cannot create a notify loop.
          self.owner.borrow_mut().dirty = false;
          let snapshot = self.owner.borrow().projection.clone().expect("live native projection");
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          let element = paint_native_root(&snapshot, &self.owner, &self.focus, format!("compiled-root-{}", Rc::as_ptr(&self.owner) as usize), drive);
          if let Some(focus) = &self.window_input { window_input_scope(element, focus, &self.owner) } else { element }
          }).unwrap_or_else(|| gpui::div().into_any_element())
      }
  }
  