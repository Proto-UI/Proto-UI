# Independent review: Qt / Flutter Scroll axes sync

The bounded implementation follows the existing draft `C-SCROLL-AXIS-SYNC-0001`: a runtime callback may change axes while preserving setup-only projection/end-follow policy, current or next lease identity, and host-authoritative observed facts. This review found no new defect and supports integration of the exact reviewed sources, with actual platform acceptance reported separately.

Source baseline: `2df421b1fc55cc0649be6675c0ee46a69ad9316f`. Qt controls SHA-256: `8f883d3c96c6f734e733a669cffb829ed81f39ca6b325e42b1551b2f22d53d6c`. Flutter modules SHA-256: `7fa40bb6c6c3e81646adc5de06b3bde80dff5b6c3c1f5710bc76b45e18e5f8ff`. `review.json` binds all ten reviewed source/test/catalog/workflow files; complete copies are preserved under `reviewed-sources`.

## Independent execution

Five independent controls executed the exact emitted Qt guest module. They passed: preserved policy and immutable earlier configurations; omitted/same-value no-op; detached intent and fresh attachment; synchronous replacement while the old host callback is active; independent native observed facts; invalid values and setup/render/terminal refusal. The controls include a synchronous old-to-new host replacement beyond the author fixture. `qt-independent.mjs` and `qt-independent.json` preserve the executable oracle and original result.

This execution uses a bounded native-host protocol object. It does not claim QML or a native Qt window was run. The original author eight-case group is not rerun or replaced by these five independent controls.

## Flutter source review

Axis changes validate before mutation, increment the request generation, retire reader/follow observations and composed pointer routes, and reject a pending end request before scheduling a native projection. A generation guard stops reentrant work from continuing an old projection. Current axis permission is checked separately from actual controller attachment, so the still-attached old axis cannot accept requests after intent changes. Observed axes are derived from actual attached controllers after Flutter applies the topology.

The three added actual Widget tests preserve the generated consumer. They exercise callback authority and policy preservation, real controller replacement with detached restoration and terminal refusal, and an axis change during pending request publication. Their runtime outcome was pending at this review; the static review is not Flutter execution evidence.

## Scope

The public Qt and Flutter profiles remain unavailable with `PUI4001`, as explicitly required by the retained tests. The CI wrapper increases the actual Widget denominator from 14 to 17 and adds the new native Scroll source gate. This change does not establish whole-profile admission, complete cross-host parity, or full-family acceptance. No GitHub approval or external mutation was performed by this reviewer.

## Round 2: typed record lowering after actual SDK failure

The first native packet exposed a Dart typed-record to Map compilation mismatch before any of the 17 Widget tests ran. This remains a failed compilation, with zero executed Widget cases. The successor changes only the generic operation argument lowering in `flutter-source.ts`, SHA-256 `53b7d3f8915515462c8f9ad6c81ae2daa29898b86cb341d6a5b157715029e928`.

The independently read delta recognizes finite record `valueSchema` and existing `module-config` boundaries in the operation contract. It uses the existing `configuration` bridge. In the actual generated `syncExtra`, the typed record enters `nativeConfig` once and is projected into the required native Map; optional fields retain their existing presence guards. The native runtime, literal maps, empty patch and all 17 original Dart test bodies are unchanged. All 18 v2 artifact files matched their recorded sizes and hashes. No additional defect was found in this lowering delta; actual SDK success remains a separate requirement.

The author's original Qt execution records were also read: the exact eight-case baseline had four missing-sync failures and four passing controls; the successor passed eight with no skip. These are separate from this reviewer's five independent emitted-guest controls and remain bounded guest/source evidence, not a Qt window. Details and original JSON are under `round2/`.
