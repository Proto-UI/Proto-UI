import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';

const directory = '/workspace/scratch/f7b299133482/s5-native-scroll-sync';
const relative = 'packages/compiler/src/qt-native-controls.ts';
const source = readFileSync(`${directory}/${relative}`, 'utf8');
const emitted = new Function(source.replace('export const qtControlsSource =', 'return'))();
const create = new Function(emitted.replace('export function createControls', 'function createControls') + '\nreturn createControls;')();
const results = [];
function fixture() {
  let state = { alive: true, phase: 'setup', ready: false, root: null };
  const alive = () => { if (!state.alive) throw Error('terminal'); };
  const controls = create({
    declarations: [], alive,
    setup() { alive(); if (state.phase !== 'setup') throw Error('setup'); },
    runtime() { alive(); if (state.phase !== 'callback') throw Error('callback'); },
    root: () => state.root, ready: () => state.ready, active: () => state.alive && state.ready,
    changed() {}, refreshFacts() {}, bindScrollChrome() {},
    invoke(callback, args) { callback(...args); },
  });
  const scroll = controls.hooks.asScrollSurface();
  return { state, controls, scroll };
}
function probe(name, run) {
  try { run(); results.push({ name, result: 'passed' }); }
  catch (error) { results.push({ name, result: 'failed', message: String(error), stack: error.stack }); }
}
probe('same and omitted intent preserve exact native configuration snapshots and setup policies', () => {
  const { state, controls, scroll } = fixture();
  const sent = [];
  scroll.configure({ axes: 'vertical', projection: 'system', endFollow: { mode: 'while-at-end', axis: 'vertical' } });
  state.root = { syncScroll: value => sent.push(value) }; state.ready = true;
  controls.mount(); state.phase = 'callback';
  scroll.sync({ axes: 'horizontal', projection: 'composed', endFollow: { mode: 'off' } });
  assert.notEqual(sent[0], sent[1]);
  assert.equal(sent[0].axes, 'vertical');
  assert.deepEqual(sent[1], { axes: 'horizontal', projection: 'system', endFollow: { mode: 'while-at-end', axis: 'vertical' } });
  scroll.sync({}); scroll.sync({ axes: 'horizontal' });
  assert.equal(sent.length, 2);
});
probe('detached intent cannot touch retained old physical root and mounts only latest intent', () => {
  const { state, controls, scroll } = fixture(); const old = [], fresh = [];
  scroll.configure({ axes: 'both' });
  state.root = { syncScroll: value => old.push(value.axes) }; state.ready = true;
  controls.mount(); state.phase = 'callback'; state.ready = false; controls.unmount();
  scroll.sync({ axes: 'vertical' }); scroll.sync({ axes: 'horizontal' });
  assert.deepEqual(old, ['both']);
  state.root = { syncScroll: value => fresh.push(value.axes) }; state.ready = true; controls.mount();
  assert.deepEqual(fresh, ['horizontal']);
  assert.deepEqual(old, ['both']);
});
probe('synchronous replacement callback cannot resume work on the old physical root', () => {
  const { state, controls, scroll } = fixture(); const old = [], fresh = [];
  scroll.configure({ axes: 'vertical' });
  const replacement = { syncScroll: value => fresh.push(value.axes) };
  state.root = { syncScroll(value) {
    old.push(value.axes);
    if (value.axes === 'horizontal') {
      state.ready = false; controls.unmount();
      scroll.sync({ axes: 'both' });
      state.root = replacement; state.ready = true; controls.mount();
    }
  } }; state.ready = true; controls.mount(); state.phase = 'callback';
  scroll.sync({ axes: 'horizontal' });
  assert.deepEqual(old, ['vertical', 'horizontal']); assert.deepEqual(fresh, ['both']);
  scroll.sync({ axes: 'vertical' });
  assert.deepEqual(fresh, ['both', 'vertical']); assert.deepEqual(old, ['vertical', 'horizontal']);
});
probe('native observed facts stay independent until physical host publishes them', () => {
  const { state, controls, scroll } = fixture();
  scroll.configure({ axes: 'vertical' });
  state.root = { syncScroll() {} }; state.ready = true; controls.mount(); state.phase = 'callback';
  const original = scroll.axes.get();
  scroll.sync({ axes: 'horizontal' }); assert.equal(scroll.axes.get(), original);
  const axis = { position: 0, visibleRatio: 1, canScrollBefore: false, canScrollAfter: false, atEnd: true };
  controls.scrollFacts({ axes: 'horizontal', horizontal: { ...axis }, vertical: { ...axis }, scrolling: false, projection: 'system' });
  assert.equal(scroll.axes.get(), 'horizontal');
});
probe('invalid values and setup/render/terminal calls cannot alter queued native intent', () => {
  const { state, controls, scroll } = fixture(); const sent = [];
  scroll.configure({ axes: 'vertical' });
  assert.throws(() => scroll.sync({ axes: 'horizontal' }), /callback/);
  state.phase = 'callback';
  for (const axes of ['', 'diagonal', false, 0, {}]) assert.throws(() => scroll.sync({ axes }), /Invalid scroll axes/);
  state.phase = 'render'; assert.throws(() => scroll.sync({ axes: 'both' }), /callback/);
  state.phase = 'callback'; state.root = { syncScroll: value => sent.push(value.axes) }; state.ready = true;
  controls.mount(); assert.deepEqual(sent, ['vertical']);
  controls.dispose(); state.alive = false;
  assert.throws(() => scroll.sync({ axes: 'horizontal' }), /terminal/);
  assert.deepEqual(sent, ['vertical']);
});
const report = {
  base: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: directory, encoding: 'utf8' }).trim(),
  source: relative, sourceSha256: createHash('sha256').update(source).digest('hex'),
  scope: 'Exact emitted Qt guest JavaScript, bounded host protocol. No QML/native Qt window or Flutter execution is claimed.',
  results,
};
writeFileSync(new URL('./qt-independent.json', import.meta.url), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ sourceSha256: report.sourceSha256, passed: results.filter(x => x.result === 'passed').length, failed: results.filter(x => x.result === 'failed') }));
process.exitCode = results.some(x => x.result !== 'passed') ? 1 : 0;
