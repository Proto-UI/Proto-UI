const ts=require("/workspace/scratch/f7b299133482/s5-native-scroll-sync/node_modules/typescript");const path=require('node:path');const root="/workspace/scratch/f7b299133482/s5-native-scroll-sync";
const config=ts.readConfigFile(path.join(root,'tsconfig.json'),ts.sys.readFile);
const parsed=ts.parseJsonConfigFileContent(config.config,ts.sys,root);
const program=ts.createProgram({rootNames:['packages/compiler/src/flutter-source.ts','packages/compiler/src/flutter-native-modules.ts','packages/compiler/src/qt-native-controls.ts'].map(file=>path.join(root,file)),options:{...parsed.options,strict:true,noEmit:true,incremental:false}});
process.stdout.write(JSON.stringify({phase:'program',sourceFiles:program.getSourceFiles().length})+'\n');
const diagnostics=ts.getPreEmitDiagnostics(program);
process.stdout.write(JSON.stringify({strict:program.getCompilerOptions().strict,sourceFiles:program.getSourceFiles().length,diagnostics:diagnostics.length})+'\n');
if(diagnostics.length)process.stdout.write(ts.formatDiagnosticsWithColorAndContext(diagnostics,{getCurrentDirectory:()=>root,getCanonicalFileName:file=>file,getNewLine:()=>"\n"}));
process.exitCode=diagnostics.length?1:0;
