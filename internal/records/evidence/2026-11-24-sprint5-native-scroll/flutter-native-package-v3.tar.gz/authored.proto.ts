import { definePrototype } from '@proto.ui/core';
import { asScrollSurface } from '@proto.ui/hooks';
export default definePrototype({
  name: 'scroll-return-consumer',
  setup(def) {
    const scroll = asScrollSurface();
    scroll.configure({ axes: 'vertical', endFollow: { mode: 'while-at-end', axis: 'vertical' } });
    let createdKind = '';
    def.lifecycle.onCreated(() => {
      createdKind = scroll.request({ kind: 'to', axis: 'vertical', position: 0.5 }).kind;
    });
    def.expose.method('createdOutcome', () => createdKind);
    def.expose.method(
      'toKind',
      () => scroll.request({ kind: 'to', axis: 'vertical', position: 0.5 }).kind
    );
    def.expose.method(
      'byKind',
      () => scroll.request({ kind: 'by', axis: 'vertical', delta: 10 }).kind
    );
    def.expose.method(
      'pageKind',
      () => scroll.request({ kind: 'page', axis: 'vertical', direction: 'after' }).kind
    );
    def.expose.method(
      'dragKind',
      () => scroll.request({ kind: 'control-drag', axis: 'vertical', position: 0.25 }).kind
    );
    def.expose.method('endKind', () => scroll.request({ kind: 'to-end', axis: 'vertical' }).kind);
    def.expose.method(
      'wrongAxisKind',
      () => scroll.request({ kind: 'to', axis: 'horizontal', position: 0.5 }).kind
    );
    def.expose.method('wrongAxisOutcome', () =>
      scroll.request({ kind: 'to', axis: 'horizontal', position: 0.5 })
    );
    def.expose.method('pauseKind', () => scroll.pauseFollowing().kind);
    def.expose.method('syncHorizontal', () => scroll.sync({ axes: 'horizontal' }));
    def.expose.method('syncVertical', () => scroll.sync({ axes: 'vertical' }));
    def.expose.method('syncBoth', () => scroll.sync({ axes: 'both' }));
    def.expose.method('syncOmitted', () => scroll.sync({}));
    const axesOnly: { axes: 'horizontal'; projection: 'composed' } = {
      axes: 'horizontal',
      projection: 'composed',
    };
    def.expose.method('syncExtra', () => scroll.sync(axesOnly));
    def.expose.method(
      'byZeroKind',
      () => scroll.request({ kind: 'by', axis: 'vertical', delta: 0 }).kind
    );
    def.expose.method(
      'toEndPositionKind',
      () => scroll.request({ kind: 'to', axis: 'vertical', position: 1 }).kind
    );
    def.expose.method(
      'dragEndPositionKind',
      () => scroll.request({ kind: 'control-drag', axis: 'vertical', position: 1 }).kind
    );
    return (r) => r.el('div', r.slot());
  },
});
