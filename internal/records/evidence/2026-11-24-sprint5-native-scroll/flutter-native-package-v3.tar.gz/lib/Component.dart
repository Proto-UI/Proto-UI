// Flutter direct source v1. Source graph SHA-256: c95413eae3c698e8f6384c68d762528efa660b7aba7fe102a1937c32131877c5
// Native helper costs: owner/epochs, constrained state, props/watch, Context, style, input/focus/Semantics/layout.
import 'package:flutter/widgets.dart';
import '.proto_ui/flutter_native.dart';
export '.proto_ui/flutter_native.dart';
import '.proto_ui/data_05909a44e12f5c3d4fa11c0c.dart';
export '.proto_ui/data_05909a44e12f5c3d4fa11c0c.dart';
import '.proto_ui/data_6ba0fe935cc081d6f6dfcdba.dart';
export '.proto_ui/data_6ba0fe935cc081d6f6dfcdba.dart';
import '.proto_ui/data_eefb61491804088b15369c24.dart';
export '.proto_ui/data_eefb61491804088b15369c24.dart';
import '.proto_ui/data_795b5aca1c9a8cfa0578d255.dart';
export '.proto_ui/data_795b5aca1c9a8cfa0578d255.dart';
import '.proto_ui/data_d4d9289418565b21fed1c2b1.dart';
export '.proto_ui/data_d4d9289418565b21fed1c2b1.dart';
import '.proto_ui/data_6ef584c53bcdbe4919328a11.dart';
export '.proto_ui/data_6ef584c53bcdbe4919328a11.dart';
import '.proto_ui/data_ea57c7eeb38e644ec190fdc8.dart';
export '.proto_ui/data_ea57c7eeb38e644ec190fdc8.dart';
import '.proto_ui/data_9c2daadb6012e1c629a91c11.dart';
export '.proto_ui/data_9c2daadb6012e1c629a91c11.dart';
import '.proto_ui/data_daf9ebb55e2aa4db4141bbc7.dart';
export '.proto_ui/data_daf9ebb55e2aa4db4141bbc7.dart';




class GeneratedProps {
  GeneratedProps({Map<String, Object?> extra = const {}})
    : raw = Map.unmodifiable({...extra, });
  final Map<String, Object?> raw;
}
class GeneratedResolvedProps {
  GeneratedResolvedProps(this.raw);
  final Map<String, Object?> raw;

}
class GeneratedExposes {
  GeneratedExposes(this.controller);
  final CompiledComponentController controller;
  String Function() get createdOutcome => controller.owner.v_637265617465644f7574636f6d65;
  String Function() get toKind => controller.owner.v_746f4b696e64;
  String Function() get byKind => controller.owner.v_62794b696e64;
  String Function() get pageKind => controller.owner.v_706167654b696e64;
  String Function() get dragKind => controller.owner.v_647261674b696e64;
  String Function() get endKind => controller.owner.v_656e644b696e64;
  String Function() get wrongAxisKind => controller.owner.v_77726f6e67417869734b696e64;
  Object? Function() get wrongAxisOutcome => controller.owner.v_77726f6e67417869734f7574636f6d65;
  String Function() get pauseKind => controller.owner.v_70617573654b696e64;
  void Function() get syncHorizontal => controller.owner.v_73796e63486f72697a6f6e74616c;
  void Function() get syncVertical => controller.owner.v_73796e63566572746963616c;
  void Function() get syncBoth => controller.owner.v_73796e63426f7468;
  void Function() get syncOmitted => controller.owner.v_73796e634f6d6974746564;
  void Function() get syncExtra => controller.owner.v_73796e634578747261;
  String Function() get byZeroKind => controller.owner.v_62795a65726f4b696e64;
  String Function() get toEndPositionKind => controller.owner.v_746f456e64506f736974696f6e4b696e64;
  String Function() get dragEndPositionKind => controller.owner.v_64726167456e64506f736974696f6e4b696e64;
}
class CompiledComponentController {
  _Owner? _owner;
  _Owner get owner {
    final value = _owner;
    if (value == null) throw StateError('Component is not attached');
    value.ensureExternal(); return value;
  }
  GeneratedExposes getExposes() => GeneratedExposes(this);
  GeneratedDriver get driver => GeneratedDriver(this);
  void update() => owner.requestUpdate();
  void setProps(GeneratedProps next) => owner.applyProps(next.raw);
  void setPresent(bool present) => owner.externalPresent(present);
  bool get ready => owner.ready;
  int get viewEpoch => owner.epoch;
  FocusNode get focusNode => owner.focus.node;
  void dispose() { final value = owner; try { value.close(); } finally { value.requestHostUpdate(terminal: true); } }
}
class GeneratedDriver {
  GeneratedDriver(this.controller);
  final CompiledComponentController controller;
  NativeHostTarget get root => controller.owner.hostTarget;
  NativeFocus get focus => controller.owner.focus;
  NativeFocusScope? get focusScope => controller.owner.focusScope;
  NativeFocusRoving? get focusRoving => controller.owner.focusRoving;
  NativeTextControl<GeneratedResolvedProps>? get textControl => controller.owner.textControl;
  NativeImageView<GeneratedResolvedProps>? get imageView => controller.owner.imageView;
  NativeScroll? get scroll => controller.owner.scroll;
  NativeOverlay? get overlay => controller.owner.overlay;
  NativePositioning? get positioning => controller.owner.positioning;
  NativeBoundary<GeneratedResolvedProps>? get boundary => controller.owner.boundary;
  NativeAnatomy get anatomy => controller.owner.anatomy;
  T invoke<T>(T Function(GeneratedDriver) callback) => controller.owner.inScope('native-driver', () => callback(this));
}
class _Owner extends NativeOwner<GeneratedResolvedProps> {
  _Owner(void Function() invalidate, NativeContextScope? parent)
    : super(invalidate, parent, makeProps: GeneratedResolvedProps.new,
      checks: <String, bool Function(Object?)>{});
  String Function()? _bound_v_637265617465644f7574636f6d65;
  String Function() get v_637265617465644f7574636f6d65 { ensureExternal(); return _bound_v_637265617465644f7574636f6d65 ?? ((super.publicExposure("createdOutcome") as String Function())); }
  void bindv_637265617465644f7574636f6d65(String Function() value) {
    ensureSetup(); declareExpose("createdOutcome");
    _bound_v_637265617465644f7574636f6d65 = () {
      ensureExternal();

      final result = inScope('expose-method', () => value());
      if (!(true)) throw ArgumentError('Invalid Expose method result');
      return result;
    };
  }
  String Function()? _bound_v_746f4b696e64;
  String Function() get v_746f4b696e64 { ensureExternal(); return _bound_v_746f4b696e64 ?? (() => ((super.publicExposure("toKind") as Object? Function())() as String)); }
  void bindv_746f4b696e64(String Function() value) {
    ensureSetup(); declareExpose("toKind");
    _bound_v_746f4b696e64 = () {
      ensureExternal();

      final result = inScope('expose-method', () => value());
      if (!((result == "dispatched" || result == "queued" || result == "rejected"))) throw ArgumentError('Invalid Expose method result');
      return result;
    };
  }
  String Function()? _bound_v_62794b696e64;
  String Function() get v_62794b696e64 { ensureExternal(); return _bound_v_62794b696e64 ?? (() => ((super.publicExposure("byKind") as Object? Function())() as String)); }
  void bindv_62794b696e64(String Function() value) {
    ensureSetup(); declareExpose("byKind");
    _bound_v_62794b696e64 = () {
      ensureExternal();

      final result = inScope('expose-method', () => value());
      if (!((result == "dispatched" || result == "queued" || result == "rejected"))) throw ArgumentError('Invalid Expose method result');
      return result;
    };
  }
  String Function()? _bound_v_706167654b696e64;
  String Function() get v_706167654b696e64 { ensureExternal(); return _bound_v_706167654b696e64 ?? (() => ((super.publicExposure("pageKind") as Object? Function())() as String)); }
  void bindv_706167654b696e64(String Function() value) {
    ensureSetup(); declareExpose("pageKind");
    _bound_v_706167654b696e64 = () {
      ensureExternal();

      final result = inScope('expose-method', () => value());
      if (!((result == "dispatched" || result == "queued" || result == "rejected"))) throw ArgumentError('Invalid Expose method result');
      return result;
    };
  }
  String Function()? _bound_v_647261674b696e64;
  String Function() get v_647261674b696e64 { ensureExternal(); return _bound_v_647261674b696e64 ?? (() => ((super.publicExposure("dragKind") as Object? Function())() as String)); }
  void bindv_647261674b696e64(String Function() value) {
    ensureSetup(); declareExpose("dragKind");
    _bound_v_647261674b696e64 = () {
      ensureExternal();

      final result = inScope('expose-method', () => value());
      if (!((result == "dispatched" || result == "queued" || result == "rejected"))) throw ArgumentError('Invalid Expose method result');
      return result;
    };
  }
  String Function()? _bound_v_656e644b696e64;
  String Function() get v_656e644b696e64 { ensureExternal(); return _bound_v_656e644b696e64 ?? (() => ((super.publicExposure("endKind") as Object? Function())() as String)); }
  void bindv_656e644b696e64(String Function() value) {
    ensureSetup(); declareExpose("endKind");
    _bound_v_656e644b696e64 = () {
      ensureExternal();

      final result = inScope('expose-method', () => value());
      if (!((result == "dispatched" || result == "queued" || result == "rejected"))) throw ArgumentError('Invalid Expose method result');
      return result;
    };
  }
  String Function()? _bound_v_77726f6e67417869734b696e64;
  String Function() get v_77726f6e67417869734b696e64 { ensureExternal(); return _bound_v_77726f6e67417869734b696e64 ?? (() => ((super.publicExposure("wrongAxisKind") as Object? Function())() as String)); }
  void bindv_77726f6e67417869734b696e64(String Function() value) {
    ensureSetup(); declareExpose("wrongAxisKind");
    _bound_v_77726f6e67417869734b696e64 = () {
      ensureExternal();

      final result = inScope('expose-method', () => value());
      if (!((result == "dispatched" || result == "queued" || result == "rejected"))) throw ArgumentError('Invalid Expose method result');
      return result;
    };
  }
  Object? Function()? _bound_v_77726f6e67417869734f7574636f6d65;
  Object? Function() get v_77726f6e67417869734f7574636f6d65 { ensureExternal(); return _bound_v_77726f6e67417869734f7574636f6d65 ?? (() => nativeProject<Object?, Object?>(nativeValue((super.publicExposure("wrongAxisOutcome") as Object? Function())()), (item) { if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "dispatched")))) return nativeProject<Map<String, Object?>, NativeData_05909a44e12f5c3d4fa11c0c>(item as Map<String, Object?>, (record) => NativeData_05909a44e12f5c3d4fa11c0cValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "queued")))) return nativeProject<Map<String, Object?>, NativeData_6ba0fe935cc081d6f6dfcdba>(item as Map<String, Object?>, (record) => NativeData_6ba0fe935cc081d6f6dfcdbaValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "rejected")) && (item.containsKey("reason") && nativeProject<Object?, bool>(item["reason"], (field) => (field == "not-mounted" || field == "not-declared" || field == "unavailable"))))) return nativeProject<Map<String, Object?>, NativeData_eefb61491804088b15369c24>(item as Map<String, Object?>, (record) => NativeData_eefb61491804088b15369c24Value(kind: NativeOptional.value((record["kind"] as String)), reason: NativeOptional.value((record["reason"] as String)))); throw StateError('Invalid checked native data union'); })); }
  void bindv_77726f6e67417869734f7574636f6d65(Object? Function() value) {
    ensureSetup(); declareExpose("wrongAxisOutcome");
    _bound_v_77726f6e67417869734f7574636f6d65 = () {
      ensureExternal();

      final result = inScope('expose-method', () => value());
      if (!(((result is NativeData_05909a44e12f5c3d4fa11c0c && (result.kind.present && result.kind.value == "dispatched")) || (result is NativeData_6ba0fe935cc081d6f6dfcdba && (result.kind.present && result.kind.value == "queued")) || (result is NativeData_eefb61491804088b15369c24 && (result.kind.present && result.kind.value == "rejected") && (result.reason.present && (result.reason.value == "not-mounted" || result.reason.value == "not-declared" || result.reason.value == "unavailable")))))) throw ArgumentError('Invalid Expose method result');
      return result;
    };
  }
  String Function()? _bound_v_70617573654b696e64;
  String Function() get v_70617573654b696e64 { ensureExternal(); return _bound_v_70617573654b696e64 ?? (() => ((super.publicExposure("pauseKind") as Object? Function())() as String)); }
  void bindv_70617573654b696e64(String Function() value) {
    ensureSetup(); declareExpose("pauseKind");
    _bound_v_70617573654b696e64 = () {
      ensureExternal();

      final result = inScope('expose-method', () => value());
      if (!((result == "dispatched" || result == "queued" || result == "rejected"))) throw ArgumentError('Invalid Expose method result');
      return result;
    };
  }
  void Function()? _bound_v_73796e63486f72697a6f6e74616c;
  void Function() get v_73796e63486f72697a6f6e74616c { ensureExternal(); return _bound_v_73796e63486f72697a6f6e74616c ?? ((super.publicExposure("syncHorizontal") as void Function())); }
  void bindv_73796e63486f72697a6f6e74616c(void Function() value) {
    ensureSetup(); declareExpose("syncHorizontal");
    _bound_v_73796e63486f72697a6f6e74616c = () {
      ensureExternal();

      inScope('expose-method', () => value());
    };
  }
  void Function()? _bound_v_73796e63566572746963616c;
  void Function() get v_73796e63566572746963616c { ensureExternal(); return _bound_v_73796e63566572746963616c ?? ((super.publicExposure("syncVertical") as void Function())); }
  void bindv_73796e63566572746963616c(void Function() value) {
    ensureSetup(); declareExpose("syncVertical");
    _bound_v_73796e63566572746963616c = () {
      ensureExternal();

      inScope('expose-method', () => value());
    };
  }
  void Function()? _bound_v_73796e63426f7468;
  void Function() get v_73796e63426f7468 { ensureExternal(); return _bound_v_73796e63426f7468 ?? ((super.publicExposure("syncBoth") as void Function())); }
  void bindv_73796e63426f7468(void Function() value) {
    ensureSetup(); declareExpose("syncBoth");
    _bound_v_73796e63426f7468 = () {
      ensureExternal();

      inScope('expose-method', () => value());
    };
  }
  void Function()? _bound_v_73796e634f6d6974746564;
  void Function() get v_73796e634f6d6974746564 { ensureExternal(); return _bound_v_73796e634f6d6974746564 ?? ((super.publicExposure("syncOmitted") as void Function())); }
  void bindv_73796e634f6d6974746564(void Function() value) {
    ensureSetup(); declareExpose("syncOmitted");
    _bound_v_73796e634f6d6974746564 = () {
      ensureExternal();

      inScope('expose-method', () => value());
    };
  }
  void Function()? _bound_v_73796e634578747261;
  void Function() get v_73796e634578747261 { ensureExternal(); return _bound_v_73796e634578747261 ?? ((super.publicExposure("syncExtra") as void Function())); }
  void bindv_73796e634578747261(void Function() value) {
    ensureSetup(); declareExpose("syncExtra");
    _bound_v_73796e634578747261 = () {
      ensureExternal();

      inScope('expose-method', () => value());
    };
  }
  String Function()? _bound_v_62795a65726f4b696e64;
  String Function() get v_62795a65726f4b696e64 { ensureExternal(); return _bound_v_62795a65726f4b696e64 ?? (() => ((super.publicExposure("byZeroKind") as Object? Function())() as String)); }
  void bindv_62795a65726f4b696e64(String Function() value) {
    ensureSetup(); declareExpose("byZeroKind");
    _bound_v_62795a65726f4b696e64 = () {
      ensureExternal();

      final result = inScope('expose-method', () => value());
      if (!((result == "dispatched" || result == "queued" || result == "rejected"))) throw ArgumentError('Invalid Expose method result');
      return result;
    };
  }
  String Function()? _bound_v_746f456e64506f736974696f6e4b696e64;
  String Function() get v_746f456e64506f736974696f6e4b696e64 { ensureExternal(); return _bound_v_746f456e64506f736974696f6e4b696e64 ?? (() => ((super.publicExposure("toEndPositionKind") as Object? Function())() as String)); }
  void bindv_746f456e64506f736974696f6e4b696e64(String Function() value) {
    ensureSetup(); declareExpose("toEndPositionKind");
    _bound_v_746f456e64506f736974696f6e4b696e64 = () {
      ensureExternal();

      final result = inScope('expose-method', () => value());
      if (!((result == "dispatched" || result == "queued" || result == "rejected"))) throw ArgumentError('Invalid Expose method result');
      return result;
    };
  }
  String Function()? _bound_v_64726167456e64506f736974696f6e4b696e64;
  String Function() get v_64726167456e64506f736974696f6e4b696e64 { ensureExternal(); return _bound_v_64726167456e64506f736974696f6e4b696e64 ?? (() => ((super.publicExposure("dragEndPositionKind") as Object? Function())() as String)); }
  void bindv_64726167456e64506f736974696f6e4b696e64(String Function() value) {
    ensureSetup(); declareExpose("dragEndPositionKind");
    _bound_v_64726167456e64506f736974696f6e4b696e64 = () {
      ensureExternal();

      final result = inScope('expose-method', () => value());
      if (!((result == "dispatched" || result == "queued" || result == "rejected"))) throw ArgumentError('Invalid Expose method result');
      return result;
    };
  }
  @override Object? publicExposure(String name) {
    ensureAlive();
    switch (name) {
      case "createdOutcome": return v_637265617465644f7574636f6d65;
      case "toKind": return v_746f4b696e64;
      case "byKind": return v_62794b696e64;
      case "pageKind": return v_706167654b696e64;
      case "dragKind": return v_647261674b696e64;
      case "endKind": return v_656e644b696e64;
      case "wrongAxisKind": return v_77726f6e67417869734b696e64;
      case "wrongAxisOutcome": return v_77726f6e67417869734f7574636f6d65;
      case "pauseKind": return v_70617573654b696e64;
      case "syncHorizontal": return v_73796e63486f72697a6f6e74616c;
      case "syncVertical": return v_73796e63566572746963616c;
      case "syncBoth": return v_73796e63426f7468;
      case "syncOmitted": return v_73796e634f6d6974746564;
      case "syncExtra": return v_73796e634578747261;
      case "byZeroKind": return v_62795a65726f4b696e64;
      case "toEndPositionKind": return v_746f456e64506f736974696f6e4b696e64;
      case "dragEndPositionKind": return v_64726167456e64506f736974696f6e4b696e64;
      default: return super.publicExposure(name);
    }
  }
}
class CompiledComponent extends StatefulWidget {
  const CompiledComponent({super.key, this.props, this.controller, this.child});
  final GeneratedProps? props;
  final CompiledComponentController? controller;
  final Widget? child;
  @override State<CompiledComponent> createState() => _CompiledComponentState();
}
class _CompiledComponentState extends State<CompiledComponent> {
  _Owner? _instance;
  @override void didChangeDependencies() {
    super.didChangeDependencies();
    final parent = NativeContextHost.maybeOf(context);
    final existing = _instance;
    if (existing != null) { existing.context.parent = parent; return; }
    final _owner = _Owner(() { if (mounted) setState(() {}); }, parent);
    _owner.logicalContext = context;
    _instance = _owner;
    if (widget.controller?._owner != null) throw StateError('Controller already owns a component');
    widget.controller?._owner = _owner;
    try {


      final author = ((_Owner v_646566) {
        // Source "flutter-scroll-outcomes.proto.ts":6:11
        final v_7363726f6c6c = _owner.install('asScrollSurface', () => _owner.scroll ??= NativeScroll(_owner));
        // Source "flutter-scroll-outcomes.proto.ts":7:5
        v_7363726f6c6c.configure(<String, Object?>{"axes": "vertical", "endFollow": <String, Object?>{"mode": "while-at-end", "axis": "vertical"}});
        // Source "flutter-scroll-outcomes.proto.ts":8:9
        var v_637265617465644b696e64 = "";
        // Source "flutter-scroll-outcomes.proto.ts":9:5
        _owner.on("created", (run) => (() => _owner.inScope("created", () {
          // Source "flutter-scroll-outcomes.proto.ts":10:7
          (v_637265617465644b696e64 = nativeProject<Object?, String>(nativeValue(nativeProject<Object?, Object?>(nativeValue(v_7363726f6c6c.request(<String, Object?>{"kind": "to", "axis": "vertical", "position": 0.5})), (item) { if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "dispatched")))) return nativeProject<Map<String, Object?>, NativeData_05909a44e12f5c3d4fa11c0c>(item as Map<String, Object?>, (record) => NativeData_05909a44e12f5c3d4fa11c0cValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "queued")))) return nativeProject<Map<String, Object?>, NativeData_6ba0fe935cc081d6f6dfcdba>(item as Map<String, Object?>, (record) => NativeData_6ba0fe935cc081d6f6dfcdbaValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "rejected")) && (item.containsKey("reason") && nativeProject<Object?, bool>(item["reason"], (field) => (field == "not-mounted" || field == "not-declared" || field == "unavailable"))))) return nativeProject<Map<String, Object?>, NativeData_eefb61491804088b15369c24>(item as Map<String, Object?>, (record) => NativeData_eefb61491804088b15369c24Value(kind: NativeOptional.value((record["kind"] as String)), reason: NativeOptional.value((record["reason"] as String)))); throw StateError('Invalid checked native data union'); })), (value) { if (value is NativeData_05909a44e12f5c3d4fa11c0c) return value.kind.value; if (value is NativeData_6ba0fe935cc081d6f6dfcdba) return value.kind.value; if (value is NativeData_eefb61491804088b15369c24) return value.kind.value; throw StateError('Invalid checked member receiver'); }));
        }))());
        // Source "flutter-scroll-outcomes.proto.ts":12:5
        _owner.bindv_637265617465644f7574636f6d65(() {
          // Source "flutter-scroll-outcomes.proto.ts":12:47
          return v_637265617465644b696e64;
        });
        // Source "flutter-scroll-outcomes.proto.ts":13:5
        _owner.bindv_746f4b696e64(() {
          // Source "flutter-scroll-outcomes.proto.ts":15:13
          return nativeProject<Object?, String>(nativeValue(nativeProject<Object?, Object?>(nativeValue(v_7363726f6c6c.request(<String, Object?>{"kind": "to", "axis": "vertical", "position": 0.5})), (item) { if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "dispatched")))) return nativeProject<Map<String, Object?>, NativeData_05909a44e12f5c3d4fa11c0c>(item as Map<String, Object?>, (record) => NativeData_05909a44e12f5c3d4fa11c0cValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "queued")))) return nativeProject<Map<String, Object?>, NativeData_6ba0fe935cc081d6f6dfcdba>(item as Map<String, Object?>, (record) => NativeData_6ba0fe935cc081d6f6dfcdbaValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "rejected")) && (item.containsKey("reason") && nativeProject<Object?, bool>(item["reason"], (field) => (field == "not-mounted" || field == "not-declared" || field == "unavailable"))))) return nativeProject<Map<String, Object?>, NativeData_eefb61491804088b15369c24>(item as Map<String, Object?>, (record) => NativeData_eefb61491804088b15369c24Value(kind: NativeOptional.value((record["kind"] as String)), reason: NativeOptional.value((record["reason"] as String)))); throw StateError('Invalid checked native data union'); })), (value) { if (value is NativeData_05909a44e12f5c3d4fa11c0c) return value.kind.value; if (value is NativeData_6ba0fe935cc081d6f6dfcdba) return value.kind.value; if (value is NativeData_eefb61491804088b15369c24) return value.kind.value; throw StateError('Invalid checked member receiver'); });
        });
        // Source "flutter-scroll-outcomes.proto.ts":17:5
        _owner.bindv_62794b696e64(() {
          // Source "flutter-scroll-outcomes.proto.ts":19:13
          return nativeProject<Object?, String>(nativeValue(nativeProject<Object?, Object?>(nativeValue(v_7363726f6c6c.request(<String, Object?>{"kind": "by", "axis": "vertical", "delta": 10.0})), (item) { if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "dispatched")))) return nativeProject<Map<String, Object?>, NativeData_05909a44e12f5c3d4fa11c0c>(item as Map<String, Object?>, (record) => NativeData_05909a44e12f5c3d4fa11c0cValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "queued")))) return nativeProject<Map<String, Object?>, NativeData_6ba0fe935cc081d6f6dfcdba>(item as Map<String, Object?>, (record) => NativeData_6ba0fe935cc081d6f6dfcdbaValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "rejected")) && (item.containsKey("reason") && nativeProject<Object?, bool>(item["reason"], (field) => (field == "not-mounted" || field == "not-declared" || field == "unavailable"))))) return nativeProject<Map<String, Object?>, NativeData_eefb61491804088b15369c24>(item as Map<String, Object?>, (record) => NativeData_eefb61491804088b15369c24Value(kind: NativeOptional.value((record["kind"] as String)), reason: NativeOptional.value((record["reason"] as String)))); throw StateError('Invalid checked native data union'); })), (value) { if (value is NativeData_05909a44e12f5c3d4fa11c0c) return value.kind.value; if (value is NativeData_6ba0fe935cc081d6f6dfcdba) return value.kind.value; if (value is NativeData_eefb61491804088b15369c24) return value.kind.value; throw StateError('Invalid checked member receiver'); });
        });
        // Source "flutter-scroll-outcomes.proto.ts":21:5
        _owner.bindv_706167654b696e64(() {
          // Source "flutter-scroll-outcomes.proto.ts":23:13
          return nativeProject<Object?, String>(nativeValue(nativeProject<Object?, Object?>(nativeValue(v_7363726f6c6c.request(<String, Object?>{"kind": "page", "axis": "vertical", "direction": "after"})), (item) { if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "dispatched")))) return nativeProject<Map<String, Object?>, NativeData_05909a44e12f5c3d4fa11c0c>(item as Map<String, Object?>, (record) => NativeData_05909a44e12f5c3d4fa11c0cValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "queued")))) return nativeProject<Map<String, Object?>, NativeData_6ba0fe935cc081d6f6dfcdba>(item as Map<String, Object?>, (record) => NativeData_6ba0fe935cc081d6f6dfcdbaValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "rejected")) && (item.containsKey("reason") && nativeProject<Object?, bool>(item["reason"], (field) => (field == "not-mounted" || field == "not-declared" || field == "unavailable"))))) return nativeProject<Map<String, Object?>, NativeData_eefb61491804088b15369c24>(item as Map<String, Object?>, (record) => NativeData_eefb61491804088b15369c24Value(kind: NativeOptional.value((record["kind"] as String)), reason: NativeOptional.value((record["reason"] as String)))); throw StateError('Invalid checked native data union'); })), (value) { if (value is NativeData_05909a44e12f5c3d4fa11c0c) return value.kind.value; if (value is NativeData_6ba0fe935cc081d6f6dfcdba) return value.kind.value; if (value is NativeData_eefb61491804088b15369c24) return value.kind.value; throw StateError('Invalid checked member receiver'); });
        });
        // Source "flutter-scroll-outcomes.proto.ts":25:5
        _owner.bindv_647261674b696e64(() {
          // Source "flutter-scroll-outcomes.proto.ts":27:13
          return nativeProject<Object?, String>(nativeValue(nativeProject<Object?, Object?>(nativeValue(v_7363726f6c6c.request(<String, Object?>{"kind": "control-drag", "axis": "vertical", "position": 0.25})), (item) { if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "dispatched")))) return nativeProject<Map<String, Object?>, NativeData_05909a44e12f5c3d4fa11c0c>(item as Map<String, Object?>, (record) => NativeData_05909a44e12f5c3d4fa11c0cValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "queued")))) return nativeProject<Map<String, Object?>, NativeData_6ba0fe935cc081d6f6dfcdba>(item as Map<String, Object?>, (record) => NativeData_6ba0fe935cc081d6f6dfcdbaValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "rejected")) && (item.containsKey("reason") && nativeProject<Object?, bool>(item["reason"], (field) => (field == "not-mounted" || field == "not-declared" || field == "unavailable"))))) return nativeProject<Map<String, Object?>, NativeData_eefb61491804088b15369c24>(item as Map<String, Object?>, (record) => NativeData_eefb61491804088b15369c24Value(kind: NativeOptional.value((record["kind"] as String)), reason: NativeOptional.value((record["reason"] as String)))); throw StateError('Invalid checked native data union'); })), (value) { if (value is NativeData_05909a44e12f5c3d4fa11c0c) return value.kind.value; if (value is NativeData_6ba0fe935cc081d6f6dfcdba) return value.kind.value; if (value is NativeData_eefb61491804088b15369c24) return value.kind.value; throw StateError('Invalid checked member receiver'); });
        });
        // Source "flutter-scroll-outcomes.proto.ts":29:5
        _owner.bindv_656e644b696e64(() {
          // Source "flutter-scroll-outcomes.proto.ts":29:40
          return nativeProject<Object?, String>(nativeValue(nativeProject<Object?, Object?>(nativeValue(v_7363726f6c6c.request(<String, Object?>{"kind": "to-end", "axis": "vertical"})), (item) { if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "dispatched")))) return nativeProject<Map<String, Object?>, NativeData_05909a44e12f5c3d4fa11c0c>(item as Map<String, Object?>, (record) => NativeData_05909a44e12f5c3d4fa11c0cValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "queued")))) return nativeProject<Map<String, Object?>, NativeData_6ba0fe935cc081d6f6dfcdba>(item as Map<String, Object?>, (record) => NativeData_6ba0fe935cc081d6f6dfcdbaValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "rejected")) && (item.containsKey("reason") && nativeProject<Object?, bool>(item["reason"], (field) => (field == "not-mounted" || field == "not-declared" || field == "unavailable"))))) return nativeProject<Map<String, Object?>, NativeData_eefb61491804088b15369c24>(item as Map<String, Object?>, (record) => NativeData_eefb61491804088b15369c24Value(kind: NativeOptional.value((record["kind"] as String)), reason: NativeOptional.value((record["reason"] as String)))); throw StateError('Invalid checked native data union'); })), (value) { if (value is NativeData_05909a44e12f5c3d4fa11c0c) return value.kind.value; if (value is NativeData_6ba0fe935cc081d6f6dfcdba) return value.kind.value; if (value is NativeData_eefb61491804088b15369c24) return value.kind.value; throw StateError('Invalid checked member receiver'); });
        });
        // Source "flutter-scroll-outcomes.proto.ts":30:5
        _owner.bindv_77726f6e67417869734b696e64(() {
          // Source "flutter-scroll-outcomes.proto.ts":32:13
          return nativeProject<Object?, String>(nativeValue(nativeProject<Object?, Object?>(nativeValue(v_7363726f6c6c.request(<String, Object?>{"kind": "to", "axis": "horizontal", "position": 0.5})), (item) { if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "dispatched")))) return nativeProject<Map<String, Object?>, NativeData_05909a44e12f5c3d4fa11c0c>(item as Map<String, Object?>, (record) => NativeData_05909a44e12f5c3d4fa11c0cValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "queued")))) return nativeProject<Map<String, Object?>, NativeData_6ba0fe935cc081d6f6dfcdba>(item as Map<String, Object?>, (record) => NativeData_6ba0fe935cc081d6f6dfcdbaValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "rejected")) && (item.containsKey("reason") && nativeProject<Object?, bool>(item["reason"], (field) => (field == "not-mounted" || field == "not-declared" || field == "unavailable"))))) return nativeProject<Map<String, Object?>, NativeData_eefb61491804088b15369c24>(item as Map<String, Object?>, (record) => NativeData_eefb61491804088b15369c24Value(kind: NativeOptional.value((record["kind"] as String)), reason: NativeOptional.value((record["reason"] as String)))); throw StateError('Invalid checked native data union'); })), (value) { if (value is NativeData_05909a44e12f5c3d4fa11c0c) return value.kind.value; if (value is NativeData_6ba0fe935cc081d6f6dfcdba) return value.kind.value; if (value is NativeData_eefb61491804088b15369c24) return value.kind.value; throw StateError('Invalid checked member receiver'); });
        });
        // Source "flutter-scroll-outcomes.proto.ts":34:5
        _owner.bindv_77726f6e67417869734f7574636f6d65(() {
          // Source "flutter-scroll-outcomes.proto.ts":35:7
          return nativeProject<Object?, Object?>(nativeValue(v_7363726f6c6c.request(<String, Object?>{"kind": "to", "axis": "horizontal", "position": 0.5})), (item) { if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "dispatched")))) return nativeProject<Map<String, Object?>, NativeData_05909a44e12f5c3d4fa11c0c>(item as Map<String, Object?>, (record) => NativeData_05909a44e12f5c3d4fa11c0cValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "queued")))) return nativeProject<Map<String, Object?>, NativeData_6ba0fe935cc081d6f6dfcdba>(item as Map<String, Object?>, (record) => NativeData_6ba0fe935cc081d6f6dfcdbaValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "rejected")) && (item.containsKey("reason") && nativeProject<Object?, bool>(item["reason"], (field) => (field == "not-mounted" || field == "not-declared" || field == "unavailable"))))) return nativeProject<Map<String, Object?>, NativeData_eefb61491804088b15369c24>(item as Map<String, Object?>, (record) => NativeData_eefb61491804088b15369c24Value(kind: NativeOptional.value((record["kind"] as String)), reason: NativeOptional.value((record["reason"] as String)))); throw StateError('Invalid checked native data union'); });
        });
        // Source "flutter-scroll-outcomes.proto.ts":37:5
        _owner.bindv_70617573654b696e64(() {
          // Source "flutter-scroll-outcomes.proto.ts":37:42
          return nativeProject<Object?, String>(nativeValue(nativeProject<Object?, Object?>(nativeValue(v_7363726f6c6c.pauseFollowing()), (item) { if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "dispatched")))) return nativeProject<Map<String, Object?>, NativeData_05909a44e12f5c3d4fa11c0c>(item as Map<String, Object?>, (record) => NativeData_05909a44e12f5c3d4fa11c0cValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "queued")))) return nativeProject<Map<String, Object?>, NativeData_6ba0fe935cc081d6f6dfcdba>(item as Map<String, Object?>, (record) => NativeData_6ba0fe935cc081d6f6dfcdbaValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "rejected")) && (item.containsKey("reason") && nativeProject<Object?, bool>(item["reason"], (field) => (field == "not-mounted" || field == "not-declared" || field == "unavailable"))))) return nativeProject<Map<String, Object?>, NativeData_eefb61491804088b15369c24>(item as Map<String, Object?>, (record) => NativeData_eefb61491804088b15369c24Value(kind: NativeOptional.value((record["kind"] as String)), reason: NativeOptional.value((record["reason"] as String)))); throw StateError('Invalid checked native data union'); })), (value) { if (value is NativeData_05909a44e12f5c3d4fa11c0c) return value.kind.value; if (value is NativeData_6ba0fe935cc081d6f6dfcdba) return value.kind.value; if (value is NativeData_eefb61491804088b15369c24) return value.kind.value; throw StateError('Invalid checked member receiver'); });
        });
        // Source "flutter-scroll-outcomes.proto.ts":38:5
        _owner.bindv_73796e63486f72697a6f6e74616c(() {
          // Source "flutter-scroll-outcomes.proto.ts":38:47
          v_7363726f6c6c.sync(<String, Object?>{"axes": "horizontal"});
          return;
        });
        // Source "flutter-scroll-outcomes.proto.ts":39:5
        _owner.bindv_73796e63566572746963616c(() {
          // Source "flutter-scroll-outcomes.proto.ts":39:45
          v_7363726f6c6c.sync(<String, Object?>{"axes": "vertical"});
          return;
        });
        // Source "flutter-scroll-outcomes.proto.ts":40:5
        _owner.bindv_73796e63426f7468(() {
          // Source "flutter-scroll-outcomes.proto.ts":40:41
          v_7363726f6c6c.sync(<String, Object?>{"axes": "both"});
          return;
        });
        // Source "flutter-scroll-outcomes.proto.ts":41:5
        _owner.bindv_73796e634f6d6974746564(() {
          // Source "flutter-scroll-outcomes.proto.ts":41:44
          v_7363726f6c6c.sync(<String, Object?>{});
          return;
        });
        // Source "flutter-scroll-outcomes.proto.ts":42:11
        final v_617865734f6e6c79 = NativeData_daf9ebb55e2aa4db4141bbc7Value(axes: NativeOptional.value("horizontal"), projection: NativeOptional.value("composed"));
        // Source "flutter-scroll-outcomes.proto.ts":46:5
        _owner.bindv_73796e634578747261(() {
          // Source "flutter-scroll-outcomes.proto.ts":46:42
          v_7363726f6c6c.sync(nativeConfig(v_617865734f6e6c79, (config) => <String, Object?>{"axes": config.axes.value, "projection": config.projection.value}));
          return;
        });
        // Source "flutter-scroll-outcomes.proto.ts":47:5
        _owner.bindv_62795a65726f4b696e64(() {
          // Source "flutter-scroll-outcomes.proto.ts":49:13
          return nativeProject<Object?, String>(nativeValue(nativeProject<Object?, Object?>(nativeValue(v_7363726f6c6c.request(<String, Object?>{"kind": "by", "axis": "vertical", "delta": 0.0})), (item) { if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "dispatched")))) return nativeProject<Map<String, Object?>, NativeData_05909a44e12f5c3d4fa11c0c>(item as Map<String, Object?>, (record) => NativeData_05909a44e12f5c3d4fa11c0cValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "queued")))) return nativeProject<Map<String, Object?>, NativeData_6ba0fe935cc081d6f6dfcdba>(item as Map<String, Object?>, (record) => NativeData_6ba0fe935cc081d6f6dfcdbaValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "rejected")) && (item.containsKey("reason") && nativeProject<Object?, bool>(item["reason"], (field) => (field == "not-mounted" || field == "not-declared" || field == "unavailable"))))) return nativeProject<Map<String, Object?>, NativeData_eefb61491804088b15369c24>(item as Map<String, Object?>, (record) => NativeData_eefb61491804088b15369c24Value(kind: NativeOptional.value((record["kind"] as String)), reason: NativeOptional.value((record["reason"] as String)))); throw StateError('Invalid checked native data union'); })), (value) { if (value is NativeData_05909a44e12f5c3d4fa11c0c) return value.kind.value; if (value is NativeData_6ba0fe935cc081d6f6dfcdba) return value.kind.value; if (value is NativeData_eefb61491804088b15369c24) return value.kind.value; throw StateError('Invalid checked member receiver'); });
        });
        // Source "flutter-scroll-outcomes.proto.ts":51:5
        _owner.bindv_746f456e64506f736974696f6e4b696e64(() {
          // Source "flutter-scroll-outcomes.proto.ts":53:13
          return nativeProject<Object?, String>(nativeValue(nativeProject<Object?, Object?>(nativeValue(v_7363726f6c6c.request(<String, Object?>{"kind": "to", "axis": "vertical", "position": 1.0})), (item) { if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "dispatched")))) return nativeProject<Map<String, Object?>, NativeData_05909a44e12f5c3d4fa11c0c>(item as Map<String, Object?>, (record) => NativeData_05909a44e12f5c3d4fa11c0cValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "queued")))) return nativeProject<Map<String, Object?>, NativeData_6ba0fe935cc081d6f6dfcdba>(item as Map<String, Object?>, (record) => NativeData_6ba0fe935cc081d6f6dfcdbaValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "rejected")) && (item.containsKey("reason") && nativeProject<Object?, bool>(item["reason"], (field) => (field == "not-mounted" || field == "not-declared" || field == "unavailable"))))) return nativeProject<Map<String, Object?>, NativeData_eefb61491804088b15369c24>(item as Map<String, Object?>, (record) => NativeData_eefb61491804088b15369c24Value(kind: NativeOptional.value((record["kind"] as String)), reason: NativeOptional.value((record["reason"] as String)))); throw StateError('Invalid checked native data union'); })), (value) { if (value is NativeData_05909a44e12f5c3d4fa11c0c) return value.kind.value; if (value is NativeData_6ba0fe935cc081d6f6dfcdba) return value.kind.value; if (value is NativeData_eefb61491804088b15369c24) return value.kind.value; throw StateError('Invalid checked member receiver'); });
        });
        // Source "flutter-scroll-outcomes.proto.ts":55:5
        _owner.bindv_64726167456e64506f736974696f6e4b696e64(() {
          // Source "flutter-scroll-outcomes.proto.ts":57:13
          return nativeProject<Object?, String>(nativeValue(nativeProject<Object?, Object?>(nativeValue(v_7363726f6c6c.request(<String, Object?>{"kind": "control-drag", "axis": "vertical", "position": 1.0})), (item) { if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "dispatched")))) return nativeProject<Map<String, Object?>, NativeData_05909a44e12f5c3d4fa11c0c>(item as Map<String, Object?>, (record) => NativeData_05909a44e12f5c3d4fa11c0cValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "queued")))) return nativeProject<Map<String, Object?>, NativeData_6ba0fe935cc081d6f6dfcdba>(item as Map<String, Object?>, (record) => NativeData_6ba0fe935cc081d6f6dfcdbaValue(kind: NativeOptional.value((record["kind"] as String)))); if ((item is Map<String, Object?> && (item.containsKey("kind") && nativeProject<Object?, bool>(item["kind"], (field) => field == "rejected")) && (item.containsKey("reason") && nativeProject<Object?, bool>(item["reason"], (field) => (field == "not-mounted" || field == "not-declared" || field == "unavailable"))))) return nativeProject<Map<String, Object?>, NativeData_eefb61491804088b15369c24>(item as Map<String, Object?>, (record) => NativeData_eefb61491804088b15369c24Value(kind: NativeOptional.value((record["kind"] as String)), reason: NativeOptional.value((record["reason"] as String)))); throw StateError('Invalid checked native data union'); })), (value) { if (value is NativeData_05909a44e12f5c3d4fa11c0c) return value.kind.value; if (value is NativeData_6ba0fe935cc081d6f6dfcdba) return value.kind.value; if (value is NativeData_eefb61491804088b15369c24) return value.kind.value; throw StateError('Invalid checked member receiver'); });
        });
        // Source "flutter-scroll-outcomes.proto.ts":59:5
        return (NativeFrame<GeneratedResolvedProps> v_72) {
          // Source "flutter-scroll-outcomes.proto.ts":59:19
          return v_72.el("div", v_72.slot());
        };
      })(_owner);
      _owner.renderer = (frame) => nativeChildren(author(frame));
      _owner.finishSetup(widget.props?.raw ?? const {});
    } catch (error, stack) {
      try { _owner.close(); } catch (cleanupError, cleanupStack) {
        FlutterError.reportError(FlutterErrorDetails(exception: cleanupError, stack: cleanupStack));
      }
      Error.throwWithStackTrace(error, stack);
    }
  }
  @override void didUpdateWidget(covariant CompiledComponent oldWidget) {
    super.didUpdateWidget(oldWidget);
    final owner = _instance!;
    if (oldWidget.controller != widget.controller) {
      if (widget.controller?._owner != null) throw StateError('Controller already owns a component');
      oldWidget.controller?._owner = null; widget.controller?._owner = owner;
    }
    owner.applyProps(widget.props?.raw ?? const {});
  }
  @override Widget build(BuildContext context) => _instance!.build(widget.child);
  @override void deactivate() { _instance?.deactivate(); super.deactivate(); }
  @override void activate() { super.activate(); _instance?.activate(); }
  @override void dispose() {
    final owner = _instance;
    widget.controller?._owner = null;
    try { owner?.close(); } finally { super.dispose(); }
  }
}

(Object?, int) probeCheckedOutcome(Map<String, Object?> input) {
  final owner = _Owner(() {}, null);
  var evaluations = 0;
  owner.moduleExpose('wrongAxisOutcome', () { evaluations++; return input; });
  owner.finishSetup({});
  try {
    return (owner.v_77726f6e67417869734f7574636f6d65(), evaluations);
  } finally {
    owner.close();
  }
}
