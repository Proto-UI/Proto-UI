import 'flutter_native.dart';
import 'data_ea57c7eeb38e644ec190fdc8.dart';
abstract interface class NativeData_795b5aca1c9a8cfa0578d255 {
  NativeOptional<String> get kind;
  NativeOptional<String> get axis;
  NativeOptional<double> get position;
}
class NativeData_795b5aca1c9a8cfa0578d255Value implements NativeData_795b5aca1c9a8cfa0578d255, NativeData_ea57c7eeb38e644ec190fdc8 {
  const NativeData_795b5aca1c9a8cfa0578d255Value({required this.kind, required this.axis, required this.position});
  final NativeOptional<String> kind;
  final NativeOptional<String> axis;
  final NativeOptional<double> position;

}
