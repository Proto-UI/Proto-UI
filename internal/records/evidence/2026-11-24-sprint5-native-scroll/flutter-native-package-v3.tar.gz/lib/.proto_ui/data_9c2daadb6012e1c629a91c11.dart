import 'flutter_native.dart';

abstract interface class NativeData_9c2daadb6012e1c629a91c11 {
  NativeOptional<String> get axes;
}
class NativeData_9c2daadb6012e1c629a91c11Value implements NativeData_9c2daadb6012e1c629a91c11 {
  const NativeData_9c2daadb6012e1c629a91c11Value({required this.axes});
  final NativeOptional<String> axes;

}
