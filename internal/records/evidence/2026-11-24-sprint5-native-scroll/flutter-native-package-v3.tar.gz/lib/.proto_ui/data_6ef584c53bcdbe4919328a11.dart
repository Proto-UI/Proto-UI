import 'flutter_native.dart';
import 'data_ea57c7eeb38e644ec190fdc8.dart';
abstract interface class NativeData_6ef584c53bcdbe4919328a11 {
  NativeOptional<String> get kind;
  NativeOptional<String> get axis;
  NativeOptional<String> get direction;
}
class NativeData_6ef584c53bcdbe4919328a11Value implements NativeData_6ef584c53bcdbe4919328a11, NativeData_ea57c7eeb38e644ec190fdc8 {
  const NativeData_6ef584c53bcdbe4919328a11Value({required this.kind, required this.axis, required this.direction});
  final NativeOptional<String> kind;
  final NativeOptional<String> axis;
  final NativeOptional<String> direction;

}
