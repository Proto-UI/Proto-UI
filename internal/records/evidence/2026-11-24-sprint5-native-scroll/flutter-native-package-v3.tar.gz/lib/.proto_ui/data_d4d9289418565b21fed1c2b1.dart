import 'flutter_native.dart';
import 'data_ea57c7eeb38e644ec190fdc8.dart';
abstract interface class NativeData_d4d9289418565b21fed1c2b1 {
  NativeOptional<String> get kind;
  NativeOptional<String> get axis;
  NativeOptional<double> get delta;
}
class NativeData_d4d9289418565b21fed1c2b1Value implements NativeData_d4d9289418565b21fed1c2b1, NativeData_ea57c7eeb38e644ec190fdc8 {
  const NativeData_d4d9289418565b21fed1c2b1Value({required this.kind, required this.axis, required this.delta});
  final NativeOptional<String> kind;
  final NativeOptional<String> axis;
  final NativeOptional<double> delta;

}
