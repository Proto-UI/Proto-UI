import 'flutter_native.dart';

abstract interface class NativeData_ea57c7eeb38e644ec190fdc8 {
  NativeOptional<String> get kind;
  NativeOptional<String> get axis;
}
class NativeData_ea57c7eeb38e644ec190fdc8Value implements NativeData_ea57c7eeb38e644ec190fdc8 {
  const NativeData_ea57c7eeb38e644ec190fdc8Value({required this.kind, required this.axis});
  final NativeOptional<String> kind;
  final NativeOptional<String> axis;

}
