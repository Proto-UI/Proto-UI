import 'flutter_native.dart';

abstract interface class NativeData_05909a44e12f5c3d4fa11c0c {
  NativeOptional<String> get kind;
}
class NativeData_05909a44e12f5c3d4fa11c0cValue implements NativeData_05909a44e12f5c3d4fa11c0c {
  const NativeData_05909a44e12f5c3d4fa11c0cValue({required this.kind});
  final NativeOptional<String> kind;

}
