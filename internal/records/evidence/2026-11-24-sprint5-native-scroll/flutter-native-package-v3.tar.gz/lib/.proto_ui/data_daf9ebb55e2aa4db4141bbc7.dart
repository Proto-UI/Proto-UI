import 'flutter_native.dart';
import 'data_9c2daadb6012e1c629a91c11.dart';
abstract interface class NativeData_daf9ebb55e2aa4db4141bbc7 {
  NativeOptional<String> get axes;
  NativeOptional<String> get projection;
}
class NativeData_daf9ebb55e2aa4db4141bbc7Value implements NativeData_daf9ebb55e2aa4db4141bbc7, NativeData_9c2daadb6012e1c629a91c11 {
  const NativeData_daf9ebb55e2aa4db4141bbc7Value({required this.axes, required this.projection});
  final NativeOptional<String> axes;
  final NativeOptional<String> projection;

}
