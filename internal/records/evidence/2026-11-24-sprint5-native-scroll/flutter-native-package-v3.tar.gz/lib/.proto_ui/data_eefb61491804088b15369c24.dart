import 'flutter_native.dart';

abstract interface class NativeData_eefb61491804088b15369c24 {
  NativeOptional<String> get kind;
  NativeOptional<String> get reason;
}
class NativeData_eefb61491804088b15369c24Value implements NativeData_eefb61491804088b15369c24 {
  const NativeData_eefb61491804088b15369c24Value({required this.kind, required this.reason});
  final NativeOptional<String> kind;
  final NativeOptional<String> reason;

}
