import 'flutter_native.dart';

abstract interface class NativeData_6ba0fe935cc081d6f6dfcdba {
  NativeOptional<String> get kind;
}
class NativeData_6ba0fe935cc081d6f6dfcdbaValue implements NativeData_6ba0fe935cc081d6f6dfcdba {
  const NativeData_6ba0fe935cc081d6f6dfcdbaValue({required this.kind});
  final NativeOptional<String> kind;

}
