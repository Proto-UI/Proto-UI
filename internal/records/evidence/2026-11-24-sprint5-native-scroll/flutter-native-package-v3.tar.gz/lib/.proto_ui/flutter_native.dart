// Editable target-native host helpers. No Proto Runtime, Adapter, JS engine or semantic IR.
import 'dart:async';
import 'dart:collection';
import 'dart:ui' show SemanticsRole;
import 'package:flutter/widgets.dart';
import 'package:flutter/services.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/material.dart' show Scrollbar;


// Concrete Flutter module resources. Config maps are declaration records, never executable IR.
class NativeFocusScopeKey { NativeFocusScopeKey(this.debugName, this.meta); final String debugName; final Map<String, Object?> meta; }
class NativeFocusRovingKey { NativeFocusRovingKey(this.debugName, this.meta); final String debugName; final Map<String, Object?> meta; }
class NativeHostTarget {
  NativeHostTarget(this.key, {this.acceptsRead});
  final GlobalKey key;
  final bool Function()? acceptsRead;
  bool alive = true;
  final ValueNotifier<String> participation = ValueNotifier('participating');
  final ValueNotifier<NativeHostGeometry?> geometry = ValueNotifier(null);
  void Function(PointerEvent)? pointerRoute;
  RenderBox? get physicalBox { if (!alive) return null; final object = key.currentContext?.findRenderObject(); return object is RenderBox && object.attached && object.hasSize ? object : null; }
  RenderBox? get box => acceptsRead?.call() == false ? null : physicalBox;
  Rect? get bounds { final target = box; return target == null ? null : target.localToGlobal(Offset.zero) & target.size; }
  void dispose() { if (!alive) return; alive = false; pointerRoute = null; participation.dispose(); geometry.dispose(); }
}
class NativeHostGeometry {
  const NativeHostGeometry({this.width, this.height, this.offset = Offset.zero});
  final double? width, height;
  final Offset offset;
}
class NativeHostRegion extends StatelessWidget {
  const NativeHostRegion({super.key, required this.target, required this.child, this.ownsKey = true});
  final NativeHostTarget target;
  final Widget child;
  final bool ownsKey;
  @override Widget build(BuildContext context) => ValueListenableBuilder<String>(valueListenable: target.participation, child: ownsKey ? KeyedSubtree(key: target.key, child: child) : child, builder: (_, mode, child) => ValueListenableBuilder<NativeHostGeometry?>(valueListenable: target.geometry, child: child, builder: (_, geometry, child) {
    Widget result = child!;
    if (geometry != null) result = Transform.translate(offset: geometry.offset, child: SizedBox(width: geometry.width, height: geometry.height, child: result));
    if (mode == 'disabled') result = AbsorbPointer(child: result);
    if (mode == 'passthrough') result = IgnorePointer(child: result);
    return result;
  }));
}
class NativeFocusEntry {
  NativeFocusEntry(this.owner);
  final NativeOwner<Object?> owner;
  Map<String, Object?> config = const {};
  void configure(Map<String, Object?> patch) { owner.ensureSetup(); config = {...config, ...patch}; }
  void setDisabled(bool value) { owner.ensureRuntime(); config = {...config, 'disabled': value}; }
  void focus([Map<String, Object?> options = const {}]) {
    owner.ensureRuntime(); if (!owner.ready || config['disabled'] == true) return;
    if (config['strategy'] == 'descendant-first') {
      final descendants = NativeOwner._liveOwners.where((candidate) => candidate != owner && candidate.ready && candidate.focusAvailable && !candidate.focus.disabled && nativeLogicalDescendant(candidate,owner)).toList()..sort(NativeAnatomy.compareOwners);
      if (descendants.isNotEmpty) { final target = descendants.first; target.inScope('native-focus', () => target.focus.focusSelf(options)); return; }
      if (config['fallback'] == 'none') return;
    }
    owner.focus.focusSelf(options);
  }
}
bool nativeLogicalDescendant(NativeOwner<Object?> candidate, NativeOwner<Object?> ancestor) { NativeContextScope? current = candidate.context; while (current != null) { if (current.owner == ancestor) return true; current = current.parent; } return false; }
class NativeFocusScope {
  NativeFocusScope(this.owner) : active = NativeState<bool>(owner,'bool','focus.active',false,const {},observed:true), hasFocused = NativeState<bool>(owner,'bool','focus.hasFocused',false,const {},observed:true) { FocusManager.instance.addListener(_refresh); }
  final NativeOwner<Object?> owner;
  final FocusScopeNode node = FocusScopeNode();
  FocusNode? previous;
  final NativeState<bool> active, hasFocused;
  bool loop = false;
  String orientation = 'both';
  Map<String, Object?> config = const {};
  bool get roving => false;
  List<NativeOwner<Object?>> get members {
    final key = config['key'];
    final values = NativeOwner._liveOwners.where((candidate) {
      if (!candidate.ready || !candidate.focusAvailable || candidate.focus.disabled || !candidate.focus.nav || candidate == owner) return false;
      final declared = roving ? candidate.focus.groupKey : candidate.focus.scopeKey;
      if (declared != null) return key != null && identical(declared,key);
      NativeContextScope? current = candidate.context.parent;
      while (current != null) { if (current.owner == owner) return true; final parent = current.owner; if (parent is NativeOwner<Object?> && (roving ? parent.focusRoving != null : parent.focusScope != null)) return false; current = current.parent; }
      return false;
    }).toList()..sort(NativeAnatomy.compareOwners);
    return values;
  }
  List<FocusNode> get targets => members.map((member) => member.focus.node).toList(growable:false);
  void configure(Map<String, Object?> patch) {
    owner.ensureSetup(); config = {...config, ...patch}; loop = patch['loop'] as bool? ?? loop; orientation = patch['orientation'] as String? ?? orientation;
    final group = patch['group']; if (!roving && group != null && group != false) { final handle = owner.focusRoving ??= NativeFocusRoving(owner); handle.configure(group is Map<String,Object?> ? group : const {}); }
  }
  NativeFocusRoving? getRoving() { owner.ensureAlive(); final existing = owner.focusRoving; if (existing != null) return existing; final handle = owner.focusRoving = NativeFocusRoving(owner); owner.project(); return handle; }
  void _request(NativeOwner<Object?> target, Map<String,Object?> options) { if (options['defer'] == true) { final epoch = owner.epoch; WidgetsBinding.instance.addPostFrameCallback((_) { if (owner.alive && owner.ready && owner.epoch == epoch && target.ready) target.inScope('native-focus', () => target.focus.focusSelf(options)); }); } else target.inScope('native-focus', () => target.focus.focusSelf(options)); }
  void focusFirst([Map<String,Object?> options = const {}]) { owner.ensureRuntime(); final values = members; if (values.isNotEmpty) _request(values.first,options); else if (config['emptyPolicy'] != 'none' && owner.ready) owner.focus.focusSelf(options); }
  void focusLast([Map<String,Object?> options = const {}]) { owner.ensureRuntime(); final values = members; if (values.isNotEmpty) _request(values.last,options); }
  void focusNext() => _move(1);
  void focusPrev() => _move(-1);
  void _move(int delta) { owner.ensureRuntime(); final values = members; if (values.isEmpty) return; final current = values.indexWhere((member) => member.focus.node.hasFocus); int next = current < 0 ? delta > 0 ? 0 : values.length - 1 : current + delta; if (loop) next = next % values.length; if (next >= 0 && next < values.length) _request(values[next],const {'reason':'keyboard'}); }
  void focusSelected([Map<String, Object?> options = const {}]) { owner.ensureRuntime(); final values = members; final selected = values.where((member) => member.focus.rovingSelected).firstOrNull; if (selected != null) _request(selected,options); else focusFirst(options); }
  void activate([Map<String, Object?> options = const {}]) { owner.ensureRuntime(); if (!active.get()) previous = FocusManager.instance.primaryFocus; active.publish(true); final entry = config['entry'] ?? 'first'; if (entry == 'selected') focusSelected(options); else if (entry == 'active') { final current = members.where((member) => member.focus.rovingActive).firstOrNull; if (current != null) _request(current,options); else focusFirst(options); } else if (entry == 'container') owner.focus.focusSelf(options); else if (entry != 'manual') focusFirst(options); owner.project(); }
  void deactivate([Map<String, Object?> options = const {}]) { owner.ensureRuntime(); active.publish(false); if (config['restore'] != 'none') restoreFocus(); owner.project(); }
  void restoreFocus() { owner.ensureRuntime(); final target = previous; if (target != null && target.context != null && target.canRequestFocus) target.requestFocus(); }
  bool isActive() { owner.ensureAlive(); return active.get(); }
  void _refresh() { if (!owner.alive) return; final values = members; final focused = values.any((member) => member.focus.node.hasFocus); hasFocused.publish(focused); if (roving) active.publish(focused); if (roving && config['selectOnFocus'] == true) { for (final member in values) member.focus.rovingSelected = member.focus.node.hasFocus; } }
  KeyEventResult key(KeyEvent event) {
    if (event is! KeyDownEvent || !owner.ready) return KeyEventResult.ignored;
    final navigation = config['navigation'] as String? ?? (roving ? 'arrow' : 'tab');
    final key = event.logicalKey;
    if (key == LogicalKeyboardKey.tab && navigation.contains('tab') && (loop || config['trap'] == true)) { final values = members; if (values.isEmpty) return config['trap'] == true ? KeyEventResult.handled : KeyEventResult.ignored; final delta = HardwareKeyboard.instance.isShiftPressed ? -1 : 1; final current = values.indexWhere((member) => member.focus.node.hasFocus); var next = current+delta; if (next < 0 || next >= values.length) { if (!loop && config['trap'] != true) return KeyEventResult.ignored; next = (next+values.length)%values.length; } _request(values[next],const {'reason':'keyboard'}); return KeyEventResult.handled; }
    if (!navigation.contains('arrow')) return KeyEventResult.ignored;
    if (key == LogicalKeyboardKey.home) { focusFirst(); return KeyEventResult.handled; }
    if (key == LogicalKeyboardKey.end) { focusLast(); return KeyEventResult.handled; }
    if (orientation != 'vertical' && key == LogicalKeyboardKey.arrowRight || orientation != 'horizontal' && key == LogicalKeyboardKey.arrowDown) { focusNext(); return KeyEventResult.handled; }
    if (orientation != 'vertical' && key == LogicalKeyboardKey.arrowLeft || orientation != 'horizontal' && key == LogicalKeyboardKey.arrowUp) { focusPrev(); return KeyEventResult.handled; }
    return KeyEventResult.ignored;
  }
  Widget wrap(Widget child) => FocusScope(node: node, onKeyEvent: (_,event) => owner.inScope('event', () => key(event)), child: FocusTraversalGroup(policy: WidgetOrderTraversalPolicy(), child: child));
  void dispose() { FocusManager.instance.removeListener(_refresh); node.dispose(); active.subscribers.clear(); hasFocused.subscribers.clear(); }
}
class NativeFocusRoving extends NativeFocusScope {
  NativeFocusRoving(super.owner);
  @override bool get roving => true;
  void setLoop(bool value) { owner.ensureRuntime(); loop = value; }
  void setOrientation(String value) { owner.ensureRuntime(); if (!['horizontal', 'vertical', 'both'].contains(value)) throw ArgumentError('Invalid roving orientation'); orientation = value; }
}
class NativeAnatomyFamily {
  NativeAnatomyFamily(this.debugName, this.declaration);
  final String debugName;
  final Map<String, Object?> declaration;
}
final nativeTableFamily = NativeAnatomyFamily('base-table', const {'roles': {'root': {}, 'caption': {}, 'row': {}, 'headerCell': {}, 'cell': {}}});
class NativeTableStates {
  NativeTableStates(NativeOwnerBase owner) : a11yRole = NativeState<String>(owner, 'string', 'tableA11yRole', '', const {}), rowCount = NativeState<double>(owner, 'number.discrete', 'tableRowCount', 0, const {}), columnCount = NativeState<double>(owner, 'number.discrete', 'tableColumnCount', 0, const {}), row = NativeState<double>(owner, 'number.discrete', 'tableRow', -1, const {}), column = NativeState<double>(owner, 'number.discrete', 'tableColumn', -1, const {}), rowSpan = NativeState<double>(owner, 'number.discrete', 'tableRowSpan', 0, const {}), columnSpan = NativeState<double>(owner, 'number.discrete', 'tableColumnSpan', 0, const {});
  final NativeState<String> a11yRole;
  final NativeState<double> rowCount, columnCount, row, column, rowSpan, columnSpan;
  void dispose() { for (final state in <NativeState<Object?>>[a11yRole,rowCount,columnCount,row,column,rowSpan,columnSpan]) state.subscribers.clear(); }
}
class NativeTableDiagnostic {
  const NativeTableDiagnostic(this.code, {this.ref, this.row, this.headerKey});
  final String code;
  final NativeA11yRef? ref;
  final double? row;
  final String? headerKey;
}
class NativeTableCell {
  NativeTableCell(this.ref, this.kind, this.row, this.column, this.rowSpan, this.columnSpan, List<NativeA11yRef> columnHeaders, List<NativeA11yRef> rowHeaders, List<NativeA11yRef> orderedHeaders) : columnHeaders = List.unmodifiable(columnHeaders), rowHeaders = List.unmodifiable(rowHeaders), orderedHeaders = List.unmodifiable(orderedHeaders);
  final NativeA11yRef ref;
  final String kind;
  final double row, column, rowSpan, columnSpan;
  final List<NativeA11yRef> columnHeaders, rowHeaders, orderedHeaders;
}
class NativeTableRow {
  NativeTableRow(this.ref, this.index, List<NativeTableCell> cells) : cells = List.unmodifiable(cells);
  final NativeA11yRef ref;
  final double index;
  final List<NativeTableCell> cells;
}
class NativeTableSnapshot {
  NativeTableSnapshot(this.root, this.caption, this.rowCount, this.columnCount, List<NativeTableRow> rows, List<NativeTableDiagnostic> diagnostics) : rows = List.unmodifiable(rows), diagnostics = List.unmodifiable(diagnostics);
  final NativeA11yRef root;
  final NativeA11yRef? caption;
  final double rowCount, columnCount;
  final List<NativeTableRow> rows;
  final List<NativeTableDiagnostic> diagnostics;
  bool get valid => diagnostics.isEmpty;
}
class NativeTableStructure {
  NativeTableStructure(this.owner, this.role) : states = NativeTableStates(owner) {
    if (!['root','caption','row','headerCell','cell'].contains(role)) throw ArgumentError('Invalid table role');
  }
  final NativeOwner<Object?> owner;
  final String role;
  final NativeTableStates states;
  Map<String, Object?> config = const {};
  NativeTableSnapshot? _snapshot;
  void configure(Map<String, Object?> patch) { owner.ensureRuntime(); config = Map.unmodifiable({...config, ...patch, if (patch['headers'] is List<Object?>) 'headers': List<Object?>.unmodifiable(patch['headers'] as List<Object?>)}); refreshAll(); }
  NativeA11yRef getObjectRef() { owner.ensureAlive(); return owner.accessible.objectRef; }
  NativeTableSnapshot? getSnapshot() { owner.ensureAlive(); return _snapshot; }
  static void refreshAll() {
    for (final participant in NativeOwner._liveOwners) { final table = participant.tableStructure; if (table != null && table.role == 'root' && participant.ready) table._recompute(); }
  }
  void clear() {
    states.a11yRole.publish(''); states.row.publish(0); states.column.publish(0); states.rowSpan.publish(0); states.columnSpan.publish(0);
    states.rowCount.publish(0); states.columnCount.publish(0);
    for (final name in ['columnHeaders','rowHeaders','labelledBy','caption']) owner.accessible.relations[name] = const {'target': <Object?>[]};
    _snapshot = null;
  }
  void _recompute() {
    final rootClaim = NativeAnatomy.claims.where((claim) => claim.owner == owner && identical(claim.family,nativeTableFamily) && claim.role == 'root').firstOrNull;
    if (rootClaim == null) { clear(); return; }
    final claims = NativeAnatomy.claims.where((claim) => identical(claim.family,nativeTableFamily) && claim.owner.ready && owner.anatomy._within(claim.owner, owner, nativeTableFamily) && claim.owner.tableStructure != null).toList()..sort((a,b) => NativeAnatomy.compareOwners(a.owner,b.owner));
    final diagnostics = <NativeTableDiagnostic>[];
    final parts = <NativeTableStructure>[];
    for (final claim in claims) {
      final part = claim.owner.tableStructure!;
      if (claim.role != part.role) diagnostics.add(NativeTableDiagnostic('role-mismatch', ref: part.getObjectRef()));
      else parts.add(part);
    }
    final captions = parts.where((part) => part.role == 'caption').toList();
    final rows = parts.where((part) => part.role == 'row').toList();
    final cells = parts.where((part) => part.role == 'headerCell' || part.role == 'cell').toList();
    if (captions.length > 1) diagnostics.add(const NativeTableDiagnostic('multiple-captions'));
    if (rows.isEmpty) diagnostics.add(const NativeTableDiagnostic('missing-row'));
    final input = <List<NativeTableStructure>>[for (final _ in rows) []];
    for (final cell in cells) {
      NativeContextScope? scope = cell.owner.context.parent;
      int index = -1;
      while (scope != null && scope.owner != owner) { index = rows.indexWhere((row) => row.owner == scope!.owner); if (index >= 0) break; scope = scope.parent; }
      if (index < 0) diagnostics.add(NativeTableDiagnostic('missing-row-parent', ref: cell.getObjectRef()));
      else input[index].add(cell);
    }
    final orderedCells = input.expand((row) => row).toList();
    if (!orderedCells.any((cell) => cell.role == 'headerCell')) diagnostics.add(const NativeTableDiagnostic('missing-header-cell'));
    if (!orderedCells.any((cell) => cell.role == 'cell')) diagnostics.add(const NativeTableDiagnostic('missing-cell'));
    final dimensions = <NativeTableStructure, (int,int)>{};
    final headers = <String,List<NativeTableStructure>>{};
    for (int r = 0; r < rows.length; r++) {
      if (input[r].isEmpty) diagnostics.add(NativeTableDiagnostic('empty-row', ref: rows[r].getObjectRef(), row: r.toDouble()));
      for (final cell in input[r]) {
        final ref = cell.getObjectRef();
        if (cell.role == 'headerCell') {
          final key = cell.config['headerKey'] as String?;
          if (key == null || key.isEmpty) diagnostics.add(NativeTableDiagnostic('missing-header-key',ref: ref,row: r.toDouble()));
          else headers.putIfAbsent(key, () => []).add(cell);
          if (!['row','column'].contains(cell.config['headerKind'])) diagnostics.add(NativeTableDiagnostic('missing-header-kind',ref: ref,row: r.toDouble()));
        }
        final rs = cell.config['rowSpan'] as num? ?? 1, cs = cell.config['columnSpan'] as num? ?? 1;
        if (!rs.isFinite || !cs.isFinite || rs <= 0 || cs <= 0 || rs % 1 != 0 || cs % 1 != 0 || rs > 9007199254740991 || cs > 9007199254740991) diagnostics.add(NativeTableDiagnostic('invalid-span',ref:ref));
        else dimensions[cell] = (rs.toInt(),cs.toInt());
      }
    }
    for (final entry in headers.entries) { if (entry.value.length > 1) diagnostics.add(NativeTableDiagnostic('duplicate-header-key',ref:entry.value.first.getObjectRef(),headerKey:entry.key)); }
    final occupied = <int,List<(int,int)>>{};
    final placement = <NativeTableStructure,(int,int,int,int)>{};
    int columns = 0;
    for (int r = 0; r < rows.length; r++) {
      int cursor = 0;
      for (final cell in input[r]) {
        final size = dimensions[cell]; if (size == null) continue;
        if (r + size.$1 > rows.length) { diagnostics.add(NativeTableDiagnostic('row-span-out-of-range',ref:cell.getObjectRef(),row:r.toDouble())); continue; }
        int column = cursor;
        for (;;) {
          int next = column;
          for (int offset = 0; offset < size.$1; offset++) { for (final interval in occupied[r+offset] ?? <(int,int)>[]) { if (interval.$2 > column && interval.$1 < column + size.$2 && interval.$2 > next) next = interval.$2; } }
          if (next == column) break; column = next;
        }
        if (column + size.$2 > 9007199254740991) { diagnostics.add(NativeTableDiagnostic('column-range-out-of-range',ref:cell.getObjectRef(),row:r.toDouble())); continue; }
        for (int offset = 0; offset < size.$1; offset++) occupied.putIfAbsent(r+offset, () => []).add((column,column+size.$2));
        placement[cell] = (r,column,size.$1,size.$2); cursor = column+size.$2; if (cursor > columns) columns = cursor;
      }
    }
    final projected = <NativeTableStructure,NativeTableCell>{};
    for (int r = 0; r < rows.length; r++) {
      for (final cell in input[r]) {
        final references = cell.config['headers'] as List<Object?>? ?? const [];
        if (cell.role == 'cell' && references.isEmpty) diagnostics.add(NativeTableDiagnostic('missing-cell-headers',ref:cell.getObjectRef(),row:r.toDouble()));
        final source = placement[cell], seen = <String>{};
        final columnHeaders = <NativeA11yRef>[], rowHeaders = <NativeA11yRef>[], ordered = <NativeA11yRef>[];
        for (final raw in references) {
          final key = raw as String; String? failure;
          final matches = headers[key]; final target = matches?.length == 1 ? placement[matches!.single] : null;
          if (key.isEmpty) failure = 'empty-header-reference'; else if (!seen.add(key)) failure = 'duplicate-header-reference'; else if (matches == null) failure = 'missing-header-target'; else if (matches.length != 1) failure = 'ambiguous-header-target'; else if (target == null) failure = 'unprojectable-header-target'; else if (cell.role == 'headerCell' && source != null && (target.$1 > source.$1 || target.$1 == source.$1 && target.$2 >= source.$2)) failure = 'non-upstream-header-target';
          if (failure != null) { diagnostics.add(NativeTableDiagnostic(failure,ref:cell.getObjectRef(),row:r.toDouble(),headerKey:key)); continue; }
          if (source == null) continue;
          final header = matches!.single; final ref = header.getObjectRef(); ordered.add(ref); (header.config['headerKind'] == 'row' ? rowHeaders : columnHeaders).add(ref);
        }
        if (source != null) projected[cell] = NativeTableCell(cell.getObjectRef(),cell.role == 'cell' ? 'cell' : cell.config['headerKind'] == 'row' ? 'row-header' : 'column-header',source.$1.toDouble(),source.$2.toDouble(),source.$3.toDouble(),source.$4.toDouble(),columnHeaders,rowHeaders,ordered);
      }
    }
    final snapshot = NativeTableSnapshot(getObjectRef(),captions.length == 1 ? captions.single.getObjectRef() : null,rows.length.toDouble(),columns.toDouble(),[for (int r = 0; r < rows.length; r++) NativeTableRow(rows[r].getObjectRef(),r.toDouble(),[for (final cell in input[r]) if (projected[cell] != null) projected[cell]!])],diagnostics);
    _snapshot = snapshot;
    if (!snapshot.valid) { for (final claim in claims) { final table = claim.owner.tableStructure!; table.clear(); } _snapshot = snapshot; return; }
    states.a11yRole.publish('table'); states.rowCount.publish(snapshot.rowCount); states.columnCount.publish(snapshot.columnCount);
    owner.accessible.relations['caption'] = {'target': [if (snapshot.caption != null) snapshot.caption!]}; owner.accessible.relations['labelledBy'] = owner.accessible.relations['caption']!;
    if (captions.length == 1) captions.single.states.a11yRole.publish('caption');
    for (int r = 0; r < rows.length; r++) { rows[r].states.a11yRole.publish('row'); rows[r].states.row.publish(r+1.0); }
    for (final entry in projected.entries) {
      final cell = entry.key, view = entry.value; cell.states.a11yRole.publish(view.kind == 'cell' ? 'cell' : view.kind == 'row-header' ? 'rowheader' : 'columnheader'); cell.states.row.publish(view.row+1); cell.states.column.publish(view.column+1); cell.states.rowSpan.publish(view.rowSpan); cell.states.columnSpan.publish(view.columnSpan);
      cell.owner.accessible.relations['columnHeaders'] = {'target':view.columnHeaders}; cell.owner.accessible.relations['rowHeaders'] = {'target':view.rowHeaders}; cell.owner.accessible.relations['labelledBy'] = {'target': [if (view.orderedHeaders.isNotEmpty) ...[...view.orderedHeaders,view.ref]]};
    }
  }
  void dispose() { clear(); states.dispose(); }
}
class NativeAnatomyPart {
  NativeAnatomyPart(this.owner, this.role);
  final NativeOwner<Object?> owner;
  final String role;
  bool hasExpose(String name) { owner.ensureAlive(); return owner._exposeNames.contains(name); }
  Object? getExpose(String name) { owner.ensureAlive(); return owner.publicExposure(name); }
  bool hasHook(String name) { owner.ensureAlive(); return owner.hookNames.contains(name); }
  NativeHostTarget get target => owner.hostTarget;
}
class _AnatomyClaim { _AnatomyClaim(this.owner, this.family, this.role) : part = NativeAnatomyPart(owner,role); final NativeOwner<Object?> owner; final NativeAnatomyFamily family; final String role; final NativeAnatomyPart part; }
class NativeAnatomy {
  NativeAnatomy(this.owner);
  final NativeOwner<Object?> owner;
  static final List<_AnatomyClaim> claims = [];
  static int version = 0;
  final List<void Function()> removals = [];
  static int compareOwners(NativeOwner<Object?> a, NativeOwner<Object?> b) {
    if (identical(a,b)) return 0;
    List<Element> path(BuildContext? context) { if (context is! Element) return const []; final result = <Element>[context]; context.visitAncestorElements((element) { result.add(element); return true; }); return result.reversed.toList(); }
    final left = path(a.logicalContext), right = path(b.logicalContext);
    int shared = 0; while (shared < left.length && shared < right.length && identical(left[shared],right[shared])) shared++;
    if (shared > 0) {
      if (shared == left.length) return -1; if (shared == right.length) return 1;
      int index = 0, li = -1, ri = -1; left[shared-1].visitChildElements((child) { if (identical(child,left[shared])) li = index; if (identical(child,right[shared])) ri = index; index++; });
      if (li >= 0 && ri >= 0) return li.compareTo(ri);
    }
    return a.logicalOrder.compareTo(b.logicalOrder);
  }
  void claim(NativeAnatomyFamily family, Map<String, Object?> declaration) {
    owner.ensureSetup(); final role = declaration['role'] as String;
    final roles = family.declaration['roles'] as Map<String, Object?>?;
    if (roles != null && !roles.containsKey(role)) throw ArgumentError('Undeclared Anatomy role');
    if (claims.any((entry) => entry.owner == owner && entry.family == family)) throw StateError('Duplicate Anatomy claim');
    claims.add(_AnatomyClaim(owner, family, role)); version++;
  }
  NativeOwner<Object?> _root(NativeAnatomyFamily family) {
    NativeContextScope? scope = owner.context;
    while (scope != null) { final matches = claims.where((entry) => entry.owner == scope!.owner && entry.family == family && entry.role == 'root'); if (matches.isNotEmpty) return matches.first.owner; scope = scope.parent; }
    throw StateError('Anatomy root missing: ${family.debugName}');
  }
  bool _within(NativeOwner<Object?> candidate, NativeOwner<Object?> root, NativeAnatomyFamily family) {
    NativeContextScope? current = candidate.context;
    while (current != null) {
      if (current.owner == root) return true;
      if (claims.any((entry) => entry.owner == current!.owner && entry.family == family && entry.role == 'root')) return false;
      current = current.parent;
    }
    return false;
  }
  List<NativeAnatomyPart> parts(NativeAnatomyFamily family, [String? role]) {
    owner.ensureAlive(); final root = _root(family);
    final matching = claims.where((entry) => entry.family == family && entry.owner.ready && (role == null || entry.role == role) && _within(entry.owner, root, family)).toList();
    matching.sort((a,b) => compareOwners(a.owner,b.owner));
    return List.unmodifiable(matching.map((entry) => entry.part));
  }
  bool has(NativeAnatomyFamily family, String role) => parts(family, role).isNotEmpty;
  int orderVersion(NativeAnatomyFamily family) { _root(family); return version; }
  int indexOfSelf(NativeAnatomyFamily family, String role) => parts(family, role).indexWhere((part) => part.owner == owner);
  NativeAnatomyPart? neighbor(NativeAnatomyFamily family, String role, int delta) { final values = parts(family, role); final index = values.indexWhere((part) => part.owner == owner); final next = index + delta; return index < 0 || next < 0 || next >= values.length ? null : values[next]; }
  void Function() subscribeParts(NativeAnatomyFamily family, String role, void Function(List<NativeAnatomyPart>) callback) {
    owner.ensureSetup(); bool active = true; List<NativeOwner<Object?>> previous = [];
    final removal = owner.onCommit(() { if (!active) return; final next = parts(family, role); final identities = next.map((part) => part.owner).toList(); if (identities.length == previous.length && List.generate(identities.length, (index) => identities[index] == previous[index]).every((same) => same)) return; previous = identities; callback(next); });
    removals.add(removal); return () { owner.ensureSetup(); active = false; removal(); };
  }
  void dispose() { claims.removeWhere((entry) => entry.owner == owner); version++; for (final removal in removals) removal(); removals.clear(); }
}
class NativeCollectionSnapshot {
  NativeCollectionSnapshot(Map<String,Object?> values) : values = Map.unmodifiable(values);
  final Map<String,Object?> values;
  double get index => values['index'] as double;
  double get total => values['total'] as double;
  bool get first => values['first'] as bool;
  bool get last => values['last'] as bool;
  Object? operator [](String key) => values[key];
}
class NativeCollection {
  NativeCollection(this.owner) : count = NativeState<double>(owner,'number.discrete','collectionCount',0,const {}) { _offCommit = owner.onCommit(_sync); }
  final NativeOwner<Object?> owner;
  final NativeState<double> count;
  late final void Function() _offCommit;
  NativeAnatomyFamily? family;
  String role = 'item';
  String itemMetaExposeKey = '__collectionItem';
  void configure(Map<String, Object?> patch) {
    owner.ensureSetup(); family = patch['family'] as NativeAnatomyFamily; role = patch['itemRole'] as String? ?? role; itemMetaExposeKey = patch['itemMetaExposeKey'] as String? ?? itemMetaExposeKey;
    final ownerRole = patch['ownerRole'] ?? patch['rootRole']; if (ownerRole is String) owner.anatomy.claim(family!, {'role':ownerRole});
    owner.moduleExpose(patch['exposeCountStateKey'] as String? ?? 'count',count.external);
    owner.moduleExpose(patch['exposeItemsMethodKey'] as String? ?? 'getCollectionItems',() { owner.ensureExternal(); return getItems(); });
    owner.moduleExpose(patch['exposeCountMethodKey'] as String? ?? 'getCollectionCount',() { owner.ensureExternal(); return getCount(); });
  }
  List<NativeCollectionSnapshot> getItems() {
    owner.ensureAlive(); final key = family; if (key == null) return const []; final parts = owner.anatomy.parts(key, role);
    return List<NativeCollectionSnapshot>.unmodifiable([for (int i = 0; i < parts.length; i++) NativeCollectionSnapshot(<String,Object?>{..._meta(parts[i]),'index':i.toDouble(),'total':parts.length.toDouble(),'first':i == 0,'last':i == parts.length-1})]);
  }
  Map<String,Object?> _meta(NativeAnatomyPart part) { final exposed = part.getExpose(itemMetaExposeKey); if (exposed is NativeCollectionSnapshot Function()) return exposed().values; if (exposed is Map<String,Object?> Function()) return exposed(); if (exposed is Map<String,Object?>) return exposed; return const {}; }
  double getCount() { owner.ensureAlive(); final key = family; return key == null ? 0 : owner.anatomy.parts(key,role).length.toDouble(); }
  void _sync() { if (family != null && owner.ready) count.publish(getCount()); }
  void dispose() { _offCommit(); count.subscribers.clear(); }
}
class NativeCollectionItem<P> {
  NativeCollectionItem(this.owner) : collectionIndex = NativeState<double>(owner,'number.discrete','collectionIndex',-1,const {}), collectionTotal = NativeState<double>(owner,'number.discrete','collectionTotal',0,const {}), collectionFirst = NativeState<bool>(owner,'bool','collectionFirst',false,const {}), collectionLast = NativeState<bool>(owner,'bool','collectionLast',false,const {}) { _offCommit = owner.onCommit(_sync); }
  final NativeOwner<P> owner;
  final NativeState<double> collectionIndex, collectionTotal;
  final NativeState<bool> collectionFirst, collectionLast;
  late final void Function() _offCommit;
  NativeAnatomyFamily? family;
  String role = 'item';
  Map<String, Object?> meta = {};
  Map<String,Object?> Function(NativeRun<P>)? getMeta;
  void configure(Map<String, Object?> patch) {
    owner.ensureSetup(); family = patch['family'] as NativeAnatomyFamily; role = patch['role'] as String? ?? role; getMeta = patch['getMeta'] as Map<String,Object?> Function(NativeRun<P>)?; owner.anatomy.claim(family!, {'role': role});
    owner.moduleExpose(patch['exposeIndexStateKey'] as String? ?? 'collectionIndex',collectionIndex.external); owner.moduleExpose(patch['exposeTotalStateKey'] as String? ?? 'collectionTotal',collectionTotal.external); owner.moduleExpose(patch['exposeFirstStateKey'] as String? ?? 'collectionFirst',collectionFirst.external); owner.moduleExpose(patch['exposeLastStateKey'] as String? ?? 'collectionLast',collectionLast.external);
    NativeCollectionSnapshot externalSnapshot() { owner.ensureExternal(); return owner.inScope('expose-method',getSnapshot); }
    owner.moduleExpose(patch['exposeSnapshotMethodKey'] as String? ?? 'getCollectionItem',externalSnapshot); owner.moduleExpose(patch['metaExposeKey'] as String? ?? '__collectionItem',externalSnapshot);
  }
  NativeCollectionSnapshot getSnapshot() {
    owner.ensureAlive(); final callback = getMeta; if (callback != null && owner.ready) meta = owner.invoke(callback);
    final key = family; final parts = key == null ? const <NativeAnatomyPart>[] : owner.anatomy.parts(key,role); final index = parts.indexWhere((part) => part.owner == owner);
    return NativeCollectionSnapshot({...meta,'index':index < 0 && parts.isEmpty ? collectionIndex.get() : index.toDouble(),'total':index < 0 && parts.isEmpty ? collectionTotal.get() : parts.length.toDouble(),'first':index < 0 && parts.isEmpty ? collectionFirst.get() : index == 0,'last':index < 0 && parts.isEmpty ? collectionLast.get() : index >= 0 && index == parts.length-1});
  }
  void _sync() { if (family == null || !owner.ready) return; final value = owner.inScope('collection-sync',getSnapshot); collectionIndex.publish(value['index'] as double); collectionTotal.publish(value['total'] as double); collectionFirst.publish(value['first'] as bool); collectionLast.publish(value['last'] as bool); }
  void dispose() { _offCommit(); collectionIndex.subscribers.clear(); collectionTotal.subscribers.clear(); collectionFirst.subscribers.clear(); collectionLast.subscribers.clear(); }
}
class NativeBoundarySample {
  NativeBoundarySample(this.values);
  final Map<String,Object?> values;
  String? get type => values['type'] as String?;
  Object? get target => values['target'];
  Object? get nativeEvent => values['nativeEvent'];
  Object? get meta => values['meta'];
}
class NativeBoundaryOutsideEvent {
  NativeBoundaryOutsideEvent(this.sample);
  String get classification => 'outside';
  final NativeBoundarySample sample;
}
class NativeBoundary<P> {
  NativeBoundary(this.owner);
  final NativeOwner<P> owner;
  static final List<NativeBoundary<Object?>> stack = [];
  bool stackActive = false, observed = false;
  Map<String, Object?> config = {};
  final Set<NativeHostTarget> regions = {};
  final Set<void Function(NativeBoundaryOutsideEvent)> outside = {};
  void configure(Map<String, Object?> patch) { owner.ensureSetup(); config = {...config, ...patch}; }
  void observe(String observation) { owner.ensureSetup(); if (observation != 'pointer.press') throw ArgumentError('Unsupported Boundary observation'); observed = true; }
  void setStackActive(bool active) { owner.ensureRuntime(); stack.remove(this); stackActive = active; if (active) stack.add(this); }
  void Function() registerRegion(NativeHostTarget target, [Map<String, Object?> options = const {}]) { owner.ensureAlive(); regions.add(target); return () { owner.ensureAlive(); regions.remove(target); }; }
  void unregisterRegion(NativeHostTarget target) { owner.ensureRuntime(); regions.remove(target); }
  String classify([Map<String, Object?> sample = const {}]) {
    owner.ensureAlive(); final target = sample['target'];
    if (target is NativeHostTarget) return target == owner.hostTarget || regions.contains(target) ? 'inside' : 'outside';
    final position = sample['position'];
    if (position is! Offset) return 'unknown';
    final all = [owner.hostTarget, ...regions]; bool ready = false;
    for (final region in all) { final rect = region.bounds; if (rect == null) continue; ready = true; if (rect.contains(position)) return 'inside'; }
    return ready ? 'outside' : 'unknown';
  }
  String notify([Map<String, Object?> sample = const {}]) { owner.ensureRuntime(); final result = classify(sample); if (result == 'outside') { final event = NativeBoundaryOutsideEvent(NativeBoundarySample(Map.unmodifiable(sample))); for (final callback in List.of(outside)) { if (outside.contains(callback)) owner.inScope('event', () => callback(event)); } } return result; }
  void Function() subscribeOutside(void Function(NativeBoundaryOutsideEvent) callback) { owner.ensureAlive(); outside.add(callback); return () { owner.ensureAlive(); outside.remove(callback); }; }
  void pointer(PointerDownEvent event) { if (!observed || !owner.ready || stackActive && stack.isNotEmpty && stack.last != this) return; owner.inScope('event', () => notify({'type': 'pointer.press', 'position': event.position})); }
  void dispose() { stack.remove(this); regions.clear(); outside.clear(); }
}
class NativeHitParticipation {
  NativeHitParticipation(this.owner);
  final NativeOwner<Object?> owner;
  final Set<NativeHostTarget> regions = {};
  final Map<NativeHostTarget, (String, String)> _ownedModes = {};
  Map<String, Object?> config = {};
  void _mode(NativeHostTarget target, String mode) { if (!['participating','disabled','passthrough'].contains(mode)) throw ArgumentError('Invalid hit participation mode'); if (!target.alive) throw StateError('Hit target is disposed'); final previous = _ownedModes[target]?.$1 ?? target.participation.value; _ownedModes[target] = (previous, mode); target.participation.value = mode; }
  void configure(Map<String, Object?> patch) { owner.ensureSetup(); config = {...config, ...patch}; _mode(owner.hostTarget, config['mode'] as String? ?? 'participating'); }
  void Function() registerRegion(NativeHostTarget target, [Map<String, Object?> options = const {}]) { owner.ensureAlive(); regions.add(target); _mode(target, options['mode'] as String? ?? config['mode'] as String? ?? 'participating'); return () { owner.ensureAlive(); _release(target); }; }
  void _release(NativeHostTarget target) { regions.remove(target); final previous = _ownedModes.remove(target); if (previous != null && target.alive && target.participation.value == previous.$2) target.participation.value = previous.$1; }
  void unregisterRegion(NativeHostTarget target) { owner.ensureRuntime(); _release(target); }
  void dispose() { for (final target in List.of(_ownedModes.keys)) _release(target); }
}
class NativePositioning {
  NativePositioning(this.owner) { owner._commitObservers.add(_refresh); }
  final NativeOwner<Object?> owner;
  final ValueNotifier<Offset> offset = ValueNotifier(Offset.zero);
  Map<String, Object?> config = {};
  NativeHostTarget? anchor, content;
  bool connected = false;
  int generation = 0;
  Map<String,Object?>? snapshot;
  void Function(Map<String,Object?>)? onResolved;
  NativeHostGeometry? _previousGeometry, _appliedGeometry;
  void connect(Map<String, Object?> patch) { owner.ensureAlive(); _release(); generation++; config = Map.of(patch['config'] as Map<String,Object?>); anchor = patch['anchor'] as NativeHostTarget?; content = patch['floating'] as NativeHostTarget?; onResolved = patch['onResolved'] as void Function(Map<String,Object?>)?; connected = anchor != null && content != null; _refresh(); }
  void update(Map<String, Object?> patch) { owner.ensureRuntime(); config = Map.of(patch); requestUpdate(); }
  void requestUpdate() {
    owner.ensureRuntime(); _refresh();
  }
  void _refresh() {
    if (!owner.alive || !connected || !owner.ready) return; final a = anchor?.bounds, c = content?.bounds; if (a == null || c == null) { snapshot = null; return; }
    final gap = (config['sideOffset'] as num? ?? 0).toDouble(), cross = (config['alignOffset'] as num? ?? 0).toDouble(); var side = config['side'] as String? ?? 'bottom'; final align = config['align'] as String? ?? 'center'; final strategy = config['strategy'] as String? ?? 'absolute';
    Offset place(String side) { final horizontal = side == 'left' || side == 'right'; final center = horizontal ? a.center.dy-c.height/2 : a.center.dx-c.width/2; final start = horizontal ? a.top : a.left; final end = horizontal ? a.bottom-c.height : a.right-c.width; final along = (align == 'start' ? start : align == 'end' ? end : center)+cross; return side == 'top' ? Offset(along,a.top-c.height-gap) : side == 'left' ? Offset(a.left-c.width-gap,along) : side == 'right' ? Offset(a.right+gap,along) : Offset(along,a.bottom+gap); }
    var result = place(side); final context = owner.logicalContext; final size = context == null ? null : MediaQuery.maybeSizeOf(context); final padding = (config['collisionPadding'] as num? ?? 0).toDouble();
    if (size != null && config['avoidCollisions'] != false) {
      final overflow = side == 'top' ? result.dy < padding : side == 'bottom' ? result.dy+c.height > size.height-padding : side == 'left' ? result.dx < padding : result.dx+c.width > size.width-padding;
      if (overflow) { final opposite = {'top':'bottom','bottom':'top','left':'right','right':'left'}[side]!; final alternate = place(opposite); if (alternate.dx >= padding && alternate.dy >= padding && alternate.dx+c.width <= size.width-padding && alternate.dy+c.height <= size.height-padding) { side = opposite; result = alternate; } }
      result = Offset(result.dx.clamp(padding,(size.width-c.width-padding).clamp(padding,double.infinity)).toDouble(),result.dy.clamp(padding,(size.height-c.height-padding).clamp(padding,double.infinity)).toDouble());
    }
    offset.value = result;
    if (owner.overlay == null || content != owner.hostTarget) {
      final target = content!; final prior = target.geometry.value; if (!identical(prior,_appliedGeometry)) _previousGeometry = prior;
      final nextOffset = (prior?.offset ?? Offset.zero)+result-c.topLeft; final next = NativeHostGeometry(width:prior?.width,height:prior?.height,offset:nextOffset);
      if (prior == null || (prior.offset-nextOffset).distance > 0.01) { _appliedGeometry = next; target.geometry.value = next; }
    }
    final next = <String,Object?>{'side':side,'align':align,'strategy':strategy}; final changed = snapshot == null || snapshot!['side'] != side || snapshot!['align'] != align || snapshot!['strategy'] != strategy; snapshot = Map.unmodifiable(next); if (changed && onResolved != null) owner.inScope('positioning-resolved',() => onResolved!(snapshot!));
  }
  void _release() { final target = content; if (target != null && target.alive && identical(target.geometry.value,_appliedGeometry)) target.geometry.value = _previousGeometry; _previousGeometry = null; _appliedGeometry = null; snapshot = null; }
  void disconnect() { owner.ensureAlive(); generation++; connected = false; _release(); }
  Map<String, Object?>? getSnapshot() { owner.ensureAlive(); return snapshot; }
  void dispose() { connected = false; _release(); owner._commitObservers.remove(_refresh); offset.dispose(); }
}
class NativeOverlay {
  NativeOverlay(this.owner) { open = NativeState<bool>(owner, 'bool', 'overlay.open', false, const {}, observed: true); owner._commitObservers.add(_commit); FocusManager.instance.addListener(_focusChanged); }
  static final List<NativeOverlay> stack = [];
  final NativeOwner<Object?> owner;
  late final NativeState<bool> open;
  final OverlayPortalController portal = OverlayPortalController();
  Map<String, Object?> config = {};
  bool retained = false;
  NativeHostTarget? trigger, anchor, content;
  Map<String, Object?>? presence;
  FocusNode? previousFocus;
  bool _entered = false;
  bool isOpen() => open.get();
  void openOverlay([String? reason]) => _set(true, reason);
  void close([String? reason]) => _set(false, reason);
  void toggle([String? reason]) => _set(!open.get(),reason);
  void _set(bool value, String? reason) { owner.ensureRuntime(); if (owner.disposing) throw StateError('Overlay intent is closed during disposal'); if (value == open.get()) return; if (value) previousFocus = FocusManager.instance.primaryFocus; open.publish(value, reason); if (presence != null) { final callback = presence![value ? 'enter' : 'leave']; if (callback is void Function()) callback(); else throw StateError('Presence binding requires callable enter/leave'); } else if (!retained) owner.present = value; if (!value) _releaseView(); owner.requestHostUpdate(); }
  void configure(Map<String, Object?> patch) { owner.ensureSetup(); config = {...config, ...patch}; if (patch.containsKey('defaultOpen')) open.publish(patch['defaultOpen'] as bool); }
  void updatePosition(Map<String, Object?> patch) { owner.ensureRuntime(); config = {...config,...patch}; _position(); }
  void _position() { if (config['anchored'] == false || (anchor ?? trigger) == null) return; final position = owner.positioning ??= NativePositioning(owner); position.config = {...config,'side':config['placement'] ?? 'bottom'}; position.anchor = anchor ?? trigger; position.content = content ?? owner.hostTarget; position.connected = open.get(); position._refresh(); }
  void registerTrigger(NativeHostTarget target) { owner.ensureAlive(); trigger = target; }
  void registerAnchor(NativeHostTarget target) { owner.ensureAlive(); anchor = target; _position(); }
  void registerAnchorPart(NativeAnatomyPart? part) { owner.ensureAlive(); anchor = part?.target; _position(); }
  void registerContent(NativeHostTarget target) { owner.ensureAlive(); content = target; _position(); }
  Map<String, Object?>? getPositionSnapshot() { owner.ensureAlive(); return owner.positioning?.getSnapshot(); }
  void keepMounted() { owner.ensureSetup(); if (presence != null) throw StateError('Cannot retain a Presence-bound overlay'); retained = true; }
  void bindPresence(Map<String, Object?> binding) { owner.ensureSetup(); if (retained || presence != null) throw StateError('Overlay Presence already bound or retained'); presence = Map.unmodifiable({...binding}); }
  void _commit() { if (!owner.ready || !open.get()) return; if (!stack.contains(this)) stack.add(this); _position(); if (_entered) return; _entered = true; final entry = config['entry'] as String? ?? 'first'; if (entry == 'manual') return; final children = NativeOwner._liveOwners.where((candidate) => candidate.ready && candidate.focusAvailable && !candidate.focus.disabled && nativeLogicalDescendant(candidate,owner)).toList()..sort(NativeAnatomy.compareOwners); final target = entry == 'content' ? owner : entry == 'selected' ? children.where((candidate) => candidate.focus.rovingSelected).firstOrNull ?? children.firstOrNull : children.firstOrNull; if (target != null) target.inScope('overlay-entry',() => target.focus.focusSelf()); }
  void _releaseView() { stack.remove(this); _entered = false; owner.positioning?.disconnect(); final restore = config['restore'] as String? ?? 'trigger'; final target = restore == 'trigger' ? NativeOwner._liveOwners.where((candidate) => identical(candidate.hostTarget,trigger)).firstOrNull?.focus.node : restore == 'previous' ? previousFocus : null; if (target?.context != null && target!.canRequestFocus) target.requestFocus(); }
  void detached() { stack.remove(this); _entered = false; owner.positioning?.disconnect(); }
  bool key(KeyEvent event) { if (!owner.ready || !open.get() || stack.isNotEmpty && stack.last != this || config['closeOnEscape'] == false || event is! KeyDownEvent || event.logicalKey != LogicalKeyboardKey.escape) return false; owner.inScope('event',() => close('escape')); return true; }
  void pointer(PointerDownEvent event) { if (!owner.ready || !open.get() || stack.isNotEmpty && stack.last != this) return; final inTrigger = trigger?.bounds?.contains(event.position) == true, inAnchor = anchor?.bounds?.contains(event.position) == true; final inside = (content ?? owner.hostTarget).bounds?.contains(event.position) == true; if (inTrigger && config['closeOnTriggerPress'] == true || inAnchor && config['closeOnAnchorPress'] == true) owner.inScope('event',() => close(inTrigger ? 'trigger.press' : 'anchor.press')); else if (!inside && !inTrigger && !inAnchor && config['closeOnOutsidePress'] != false) owner.inScope('event',() => close('outside.press')); }
  void _focusChanged() { if (!owner.alive || !owner.ready || !open.get() || !_entered || stack.isNotEmpty && stack.last != this) return; final focused = NativeOwner._liveOwners.where((candidate) => candidate.focus.node.hasPrimaryFocus).firstOrNull; if (focused != null && nativeLogicalDescendant(focused,owner)) return; if (config['closeOnFocusOutside'] == true) owner.inScope('event',() => close('focus.outside')); else if (config['modal'] == true) { final target = NativeOwner._liveOwners.where((candidate) => candidate.ready && candidate.focusAvailable && nativeLogicalDescendant(candidate,owner)).firstOrNull; target?.focus.node.requestFocus(); } }
  Widget wrap(Widget root) {
    final usePortal = config['portal'] != false;
    final visible = owner.surfaceActive && (presence?['present'] is NativeObserved<bool> ? (presence!['present'] as NativeObserved<bool>).get() : open.get());
    if (!usePortal) return Offstage(offstage: !visible, child: root);
    WidgetsBinding.instance.addPostFrameCallback((_) { if (!owner.alive) return; if (visible) portal.show(); else portal.hide(); });
    return OverlayPortal(controller: portal, overlayChildBuilder: (context) {
      Widget content = NativeContextHost(scope: owner.context, child: root);
      final positioning = owner.positioning;
      if (positioning != null) content = ValueListenableBuilder<Offset>(valueListenable: positioning.offset, builder: (_, value, child) => Positioned(left: value.dx, top: value.dy, child: child!), child: content);
      else content = Positioned(left: 0, top: 0, child: content);
      if (config['modal'] == true) return Stack(children: [ModalBarrier(dismissible: config['closeOnOutsidePress'] != false, color: const Color(0x66000000), onDismiss: () => owner.inScope('event', () => close('outside.press'))), content]);
      return content;
    }, child: retained && !visible ? Offstage(offstage: true, child: root) : const SizedBox.shrink());
  }
  void dispose() { stack.remove(this); FocusManager.instance.removeListener(_focusChanged); owner._commitObservers.remove(_commit); portal.hide(); open.subscribers.clear(); }
}
class NativeScrollAxisFacts {
  NativeScrollAxisFacts(NativeOwnerBase owner, String name) : position = NativeState<double>(owner, 'number.range', '$name.position', 0, const {'min': 0, 'max': 1}, observed: true), visibleRatio = NativeState<double>(owner, 'number.range', '$name.visibleRatio', 1, const {'min': 0, 'max': 1}, observed: true), canScrollBefore = NativeState<bool>(owner, 'bool', '$name.canScrollBefore', false, const {}, observed: true), canScrollAfter = NativeState<bool>(owner, 'bool', '$name.canScrollAfter', false, const {}, observed: true), atEnd = NativeState<bool>(owner, 'bool', '$name.atEnd', true, const {}, observed: true);
  final NativeState<double> position, visibleRatio;
  final NativeState<bool> canScrollBefore, canScrollAfter, atEnd;
  void refresh(ScrollController control) {
    if (!control.hasClients || !control.position.hasContentDimensions) return;
    final metrics = control.position;
    final range = (metrics.maxScrollExtent - metrics.minScrollExtent).clamp(0,double.infinity);
    final offset = (metrics.pixels - metrics.minScrollExtent).clamp(0,range);
    position.publish(range > 0 ? offset / range : 0);
    visibleRatio.publish(range + metrics.viewportDimension > 0 ? (metrics.viewportDimension / (range + metrics.viewportDimension)).clamp(0,1).toDouble() : 1);
    canScrollBefore.publish(offset > 0); canScrollAfter.publish(offset < range); atEnd.publish(range - offset <= 1);
  }
  Map<String, Object?> snapshot() => {'position': position.get(), 'visibleRatio': visibleRatio.get(), 'canScrollBefore': canScrollBefore.get(), 'canScrollAfter': canScrollAfter.get(), 'atEnd': atEnd.get()};
  void reset() { position.publish(0); visibleRatio.publish(1); canScrollBefore.publish(false); canScrollAfter.publish(false); atEnd.publish(true); }
  void dispose() { position.subscribers.clear(); visibleRatio.subscribers.clear(); canScrollBefore.subscribers.clear(); canScrollAfter.subscribers.clear(); atEnd.subscribers.clear(); }
}
class NativeScrollFollowFacts {
  NativeScrollFollowFacts(NativeOwnerBase owner) : state = NativeState<String>(owner,'string','scroll.endFollow.state','off',const {},observed:true), requestStatus = NativeState<String>(owner,'string','scroll.endFollow.requestStatus','idle',const {},observed:true);
  final NativeState<String> state, requestStatus;
  void dispose() { state.subscribers.clear(); requestStatus.subscribers.clear(); }
}
class _NativeScrollObservation {
  _NativeScrollObservation(this.position, this.epoch, this.generation)
    : minimum = position.minScrollExtent, maximum = position.maxScrollExtent,
      viewport = position.viewportDimension,
      pixels = position.pixels.clamp(position.minScrollExtent, position.maxScrollExtent).toDouble();
  final ScrollPosition position;
  final int epoch, generation;
  final double minimum, maximum, viewport, pixels;
  bool current(NativeOwner<Object?> owner, int requestGeneration, ScrollPosition value) =>
    owner.alive && owner.ready && owner.epoch == epoch && requestGeneration == generation &&
    identical(position, value);
  bool sameLayout(ScrollPosition value) => value.hasContentDimensions &&
    minimum == value.minScrollExtent && maximum == value.maxScrollExtent &&
    viewport == value.viewportDimension;
  bool movedToEnd(ScrollPosition value) {
    final next = value.pixels.clamp(value.minScrollExtent, value.maxScrollExtent).toDouble();
    return sameLayout(value) && next != pixels && value.maxScrollExtent - next <= 1;
  }
}
class NativeScroll {
  NativeScroll(this.owner) : horizontal = NativeScrollAxisFacts(owner, 'scroll.horizontal'), vertical = NativeScrollAxisFacts(owner, 'scroll.vertical'), axes = NativeState<String>(owner,'string','scroll.axes','vertical',const {},observed:true), projection = NativeState<String>(owner,'string','scroll.projection','unresolved',const {},observed:true), scrolling = NativeState<bool>(owner,'bool','scroll.scrolling',false,const {},observed:true), endFollow = NativeScrollFollowFacts(owner) { _horizontalControl.addListener(_refresh); _verticalControl.addListener(_refresh); _offCommit = owner.onCommit(_refreshChrome); }
  final NativeOwner<Object?> owner;
  final ScrollController _verticalControl = ScrollController(), _horizontalControl = ScrollController();
  final NativeScrollAxisFacts horizontal, vertical;
  final NativeState<String> axes, projection;
  final NativeState<bool> scrolling;
  final NativeScrollFollowFacts endFollow;
  Map<String, Object?> config = {}, chrome = {};
  bool following = false, _mounted = false, _explicitlyPaused = false;
  _NativeScrollObservation? _readerObservation, _followObservation;
  int _requestGeneration = 0;
  int? _pendingEndGeneration;
  late final void Function() _offCommit;
  final Map<NativeHostTarget, (NativeHostGeometry?, void Function(PointerEvent)?, NativeHostGeometry?, void Function(PointerEvent))> _chromeOwned = {};
  final Map<int, PointerRoute> _dragRoutes = {};
  void configure(Map<String, Object?> patch) { owner.ensureSetup(); config = {...config, ...patch}; if (!['vertical','horizontal','both'].contains(config['axes'] ?? 'vertical')) throw ArgumentError('Invalid scroll axes'); if (!['auto','system','composed'].contains(config['projection'] ?? 'auto')) throw ArgumentError('Invalid scroll projection'); axes.publish(config['axes'] as String? ?? 'vertical'); _followFacts(); }
  void sync(Map<String, Object?> patch) {
    owner.ensureRuntime();
    final next = patch['axes'] ?? config['axes'] ?? 'vertical';
    if (!['horizontal','vertical','both'].contains(next)) throw ArgumentError('Invalid scroll axes');
    if (next == (config['axes'] ?? 'vertical')) return;
    config = {...config, 'axes': next};
    final generation = ++_requestGeneration;
    _readerObservation = null;
    _followObservation = null;
    _releaseChrome();
    if (_pendingEndGeneration != null) {
      _pendingEndGeneration = null;
      endFollow.requestStatus.publish('rejected');
    }
    if (!owner.alive || generation != _requestGeneration) return;
    owner.project();
  }
  void bindComposedChrome(Map<String, Object?> binding) { owner.ensureSetup(); if (chrome.isNotEmpty && !identical(chrome, binding)) throw StateError('Composed chrome may be bound only once'); chrome = binding; }
  ScrollController _controller(String axis) => axis == 'horizontal' ? _horizontalControl : _verticalControl;
  bool _allowsAxis(String axis) => (config['axes'] ?? 'vertical') == 'both' || (config['axes'] ?? 'vertical') == axis;
  ScrollPosition? _followPosition() {
    final policy = config['endFollow'];
    if (policy is! Map<String,Object?> || policy['mode'] != 'while-at-end') return null;
    final axis = policy['axis'] as String? ?? 'vertical';
    final control = _controller(axis);
    if (!owner.alive || !owner.ready || !control.hasClients || !_allowsAxis(axis)) return null;
    return control.position.hasContentDimensions ? control.position : null;
  }
  ScrollPosition? _ownedNotificationPosition(BuildContext? context) {
    if (context == null || !context.mounted) return null;
    final position = Scrollable.maybeOf(context)?.position;
    if (position == null) return null;
    return _verticalControl.positions.any((value) => identical(value, position)) ||
      _horizontalControl.positions.any((value) => identical(value, position)) ? position : null;
  }
  _NativeScrollObservation _observe(ScrollPosition position) =>
    _NativeScrollObservation(position, owner.epoch, _requestGeneration);
  bool _nativeScroll(ScrollNotification event) {
    if (!owner.alive || !owner.ready) return false;
    final position = _ownedNotificationPosition(event.context);
    if (position == null) return false;
    if (event is ScrollStartNotification) scrolling.publish(true);
    if (event is ScrollEndNotification) scrolling.publish(false);
    if (!owner.alive || !owner.ready) return false;
    if (identical(position, _followPosition())) {
      if (event is UserScrollNotification) {
        // Direction alone is intent, never proof of actual reader arrival.
        _readerObservation = event.direction == ScrollDirection.idle ? null : _observe(position);
      } else if (event is ScrollUpdateNotification) {
        // A new native drag sample may follow an explicit pause within the
        // same contact. Programmatic jumps have neither drag details nor a
        // retained reader observation; public requests retire that observation.
        final before = _readerObservation ??
          (event.dragDetails != null ? _followObservation : null);
        final current = _observe(position);
        if (before != null && before.current(owner, _requestGeneration, position)) {
          if (before.movedToEnd(position)) _explicitlyPaused = false;
          following = !_explicitlyPaused && position.extentAfter <= 1;
          _readerObservation = current;
        }
        _followObservation = current;
      }
    }
    _refresh();
    return false;
  }
  bool _nativeMetrics(ScrollMetricsNotification event) {
    if (!owner.alive || !owner.ready) return false;
    final position = _ownedNotificationPosition(event.context);
    if (position == null) return false;
    if (identical(position, _followPosition())) {
      // Layout can change bounds or clamp an offset, but is not reader input.
      _readerObservation = null;
      _followObservation = _observe(position);
      final epoch = owner.epoch, generation = _requestGeneration;
      if (following) WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!owner.alive || !owner.ready || owner.epoch != epoch ||
            generation != _requestGeneration || !following) return;
        if (identical(position, _followPosition())) position.jumpTo(position.maxScrollExtent);
      });
    }
    _refresh();
    return false;
  }
  void _followFacts() { final policy = config['endFollow']; endFollow.state.publish(policy is! Map<String,Object?> || policy['mode'] != 'while-at-end' ? 'off' : !owner.ready ? 'pending' : following ? 'following' : 'paused'); }
  void _refresh() {
    if (!owner.alive || !owner.ready) return;
    final hasHorizontal = _horizontalControl.hasClients, hasVertical = _verticalControl.hasClients;
    // Axis intent is not an observation. Publish only attached native axes,
    // after Flutter has applied the current widget/controller topology.
    if (hasHorizontal || hasVertical) axes.publish(hasHorizontal && hasVertical ? 'both' : hasHorizontal ? 'horizontal' : 'vertical');
    if (!owner.alive || !owner.ready) return;
    horizontal.refresh(_horizontalControl); vertical.refresh(_verticalControl); _followFacts(); _refreshChrome();
  }
  void _refreshChrome() {
    if (!owner.alive || !owner.ready || chrome.isEmpty || projection.get() != 'composed') return;
    final family = chrome['anatomy'] as NativeAnatomyFamily;
    final root = owner.anatomy._root(family);
    if (owner.context.resolve(chrome['scope']!) != root.context) { _releaseChrome(); return; }
    final tracks = owner.anatomy.parts(family, chrome['scrollbarRole'] as String);
    final thumbs = owner.anatomy.parts(family, chrome['thumbRole'] as String);
    final seen = <NativeHostTarget>{};
    for (final track in tracks) {
      final thumb = thumbs.where((part) { NativeContextScope? parent = part.owner.context.parent; while (parent != null) { if (parent.owner == track.owner) return true; parent = parent.parent; } return false; }).firstOrNull;
      final rect = track.target.bounds;
      if (thumb == null || rect == null || thumb.target.box == null) continue;
      final exposed = track.getExpose(chrome['orientationExpose'] as String);
      final axis = exposed is NativeObserved<Object?> && exposed.get() == 'horizontal' ? 'horizontal' : 'vertical';
      final facts = axis == 'horizontal' ? horizontal : vertical;
      final extent = axis == 'horizontal' ? rect.width : rect.height;
      final length = extent * facts.visibleRatio.get();
      final travel = (extent - length).clamp(0,double.infinity).toDouble();
      final offset = facts.position.get() * travel;
      final old = _chromeOwned[thumb.target];
      final previousGeometry = old == null || thumb.target.geometry.value != old.$3 ? thumb.target.geometry.value : old.$1;
      final previousRoute = old == null || thumb.target.pointerRoute != old.$4 ? thumb.target.pointerRoute : old.$2;
      final pointer = (PointerEvent event) {
        if (event is! PointerDownEvent || !owner.ready) return;
        final initial = event.position;
        final start = facts.position.get().toDouble();
        late final PointerRoute route;
        route = (sample) {
          if (!owner.alive || !owner.ready || sample is PointerUpEvent || sample is PointerCancelEvent) { GestureBinding.instance.pointerRouter.removeRoute(event.pointer, route); _dragRoutes.remove(event.pointer); return; }
          if (sample is PointerMoveEvent && travel > 0) { final delta = axis == 'horizontal' ? sample.position.dx - initial.dx : sample.position.dy - initial.dy; owner.inScope('event', () => _request({'kind':'control-drag','axis':axis,'position':(start + delta / travel).clamp(0,1)}, readerRequest: true)); }
        };
        _dragRoutes[event.pointer] = route; GestureBinding.instance.pointerRouter.addRoute(event.pointer, route);
      };
      final desiredOffset = axis == 'horizontal' ? Offset(offset.toDouble(),0) : Offset(0,offset.toDouble());
      final desiredWidth = axis == 'horizontal' ? length.toDouble() : null, desiredHeight = axis == 'vertical' ? length.toDouble() : null;
      final current = thumb.target.geometry.value;
      final next = current != null && current.offset == desiredOffset && current.width == desiredWidth && current.height == desiredHeight ? current : NativeHostGeometry(width: desiredWidth, height: desiredHeight, offset: desiredOffset);
      thumb.target.geometry.value = next; thumb.target.pointerRoute = pointer;
      _chromeOwned[thumb.target] = (previousGeometry, previousRoute, next, pointer); seen.add(thumb.target);
      final oldTrack = _chromeOwned[track.target];
      final trackPreviousRoute = oldTrack == null || track.target.pointerRoute != oldTrack.$4 ? track.target.pointerRoute : oldTrack.$2;
      final trackPointer = (PointerEvent event) {
        if (event is! PointerDownEvent || !owner.ready) return;
        final thumbRect = thumb.target.bounds;
        if (thumbRect == null || thumbRect.contains(event.position)) return;
        final coordinate = axis == 'horizontal' ? event.position.dx : event.position.dy;
        final start = axis == 'horizontal' ? thumbRect.left : thumbRect.top;
        owner.inScope('event', () => _request({'kind':'page','axis':axis,'direction':coordinate < start ? 'before' : 'after'}, readerRequest: true));
      };
      track.target.pointerRoute = trackPointer;
      _chromeOwned[track.target] = (oldTrack == null ? track.target.geometry.value : oldTrack.$1, trackPreviousRoute, track.target.geometry.value, trackPointer); seen.add(track.target);
    }
    for (final target in List.of(_chromeOwned.keys)) { if (!seen.contains(target)) _releaseTarget(target); }
  }
  void _releaseTarget(NativeHostTarget target) { final old = _chromeOwned.remove(target); if (old == null || !target.alive) return; if (target.geometry.value == old.$3) target.geometry.value = old.$1; if (target.pointerRoute == old.$4) target.pointerRoute = old.$2; }
  void _releaseChrome() { for (final target in List.of(_chromeOwned.keys)) _releaseTarget(target); for (final entry in _dragRoutes.entries) GestureBinding.instance.pointerRouter.removeRoute(entry.key,entry.value); _dragRoutes.clear(); }
  Map<String, Object?> request(Map<String, Object?> request) => _request(request);
  Map<String, Object?> _request(Map<String, Object?> request, {bool readerRequest = false}) {
    owner.ensureRuntime();
    final kind = request['kind'];
    final generation = ++_requestGeneration, epoch = owner.epoch;
    _readerObservation = null;
    _followObservation = null;
    Map<String, Object?> reject(String reason) {
      if (kind == 'to-end' && owner.alive && owner.epoch == epoch && (generation == _requestGeneration || _pendingEndGeneration == generation)) {
        if (_pendingEndGeneration == generation) _pendingEndGeneration = null;
        endFollow.requestStatus.publish('rejected');
      }
      return {'kind':'rejected','reason':reason};
    }
    if (!owner.hookNames.contains('asScrollSurface')) return reject('not-declared');
    if (!owner.ready) return reject('not-mounted');
    final axis = request['axis'] as String? ?? 'vertical';
    final control = _controller(axis);
    if (!control.hasClients || !_allowsAxis(axis)) return reject('unavailable');
    final metrics = control.position;
    if (!['by','page','to-end','to','control-drag'].contains(kind)) throw ArgumentError('Unknown Scroll request');
    if (!metrics.hasContentDimensions) return reject('unavailable');
    bool current() => owner.alive && owner.ready && owner.epoch == epoch && generation == _requestGeneration && control.hasClients && identical(control.position, metrics);
    final destination = kind == 'by' ? metrics.pixels + (request['delta'] as num).toDouble() : kind == 'page' ? metrics.pixels + metrics.viewportDimension * (request['direction'] == 'before' ? -1 : 1) : kind == 'to-end' ? metrics.maxScrollExtent : metrics.minScrollExtent + (metrics.maxScrollExtent - metrics.minScrollExtent) * (request['position'] as num).clamp(0,1);
    if (kind == 'to-end') { _pendingEndGeneration = generation; endFollow.requestStatus.publish('pending'); }
    if (!current()) return reject('unavailable');
    final before = _observe(metrics);
    control.jumpTo(destination.clamp(metrics.minScrollExtent, metrics.maxScrollExtent).toDouble());
    if (!current()) return reject('unavailable');
    if (identical(metrics, _followPosition())) {
      if (kind == 'to-end' || readerRequest && before.movedToEnd(metrics)) _explicitlyPaused = false;
      following = !_explicitlyPaused && metrics.extentAfter <= 1;
      _followObservation = _observe(metrics);
    }
    _refresh();
    if (!current()) return reject('unavailable');
    if (kind == 'to-end') { _pendingEndGeneration = null; endFollow.requestStatus.publish('applied'); }
    return current() ? const {'kind':'dispatched'} : const {'kind':'rejected','reason':'unavailable'};
  }
  Map<String, Object?> pauseFollowing() {
    owner.ensureRuntime();
    if (!owner.hookNames.contains('asScrollSurface')) return const {'kind':'rejected','reason':'not-declared'};
    if (!owner.ready) return const {'kind':'rejected','reason':'not-mounted'};
    final policy = config['endFollow'];
    if (policy is! Map<String,Object?> || policy['mode'] != 'while-at-end') return const {'kind':'rejected','reason':'unavailable'};
    final axis = policy['axis'] as String? ?? 'vertical';
    if (!_controller(axis).hasClients || !_allowsAxis(axis)) return const {'kind':'rejected','reason':'unavailable'};
    final generation = ++_requestGeneration, epoch = owner.epoch;
    following = false;
    _explicitlyPaused = true;
    _readerObservation = null;
    final position = _followPosition();
    _followObservation = position == null ? null : _observe(position);
    if (_pendingEndGeneration != null) { _pendingEndGeneration = null; endFollow.requestStatus.publish('rejected'); }
    if (!owner.alive || !owner.ready || owner.epoch != epoch) return const {'kind':'rejected','reason':'unavailable'};
    if (generation == _requestGeneration) _followFacts();
    return owner.alive && owner.ready && owner.epoch == epoch ? const {'kind':'dispatched'} : const {'kind':'rejected','reason':'unavailable'};
  }
  Map<String, Object?> getSnapshot() { owner.ensureAlive(); return {'axes': axes.get(), 'scrolling': scrolling.get(), 'projection': projection.get(), 'horizontal': horizontal.snapshot(), 'vertical': vertical.snapshot(), 'endFollow': {'state': endFollow.state.get(), 'requestStatus': endFollow.requestStatus.get()}}; }
  Widget wrap(Widget root) {
    Widget result = root;
    final axes = config['axes'] as String? ?? 'vertical';
    // Horizontal content may be taller than the non-scrolling viewport. Give
    // its natural block layout room, while the viewport retains its finite
    // cross-axis size and clips painting/hit testing at that boundary.
    if (axes == 'horizontal') result = OverflowBox(alignment: AlignmentDirectional.topStart,
      minHeight: 0, maxHeight: double.infinity, fit: OverflowBoxFit.deferToChild, child: result);
    // A different physical axis must not inherit the old ScrollableState or
    // ScrollPosition merely because both views have the same widget class.
    if (axes == 'vertical' || axes == 'both') result = SingleChildScrollView(key: ObjectKey(_verticalControl), controller: _verticalControl, child: result);
    if (axes == 'horizontal' || axes == 'both') result = SingleChildScrollView(key: ObjectKey(_horizontalControl), controller: _horizontalControl, scrollDirection: Axis.horizontal, child: result);
    if ((config['requireProjection'] ?? config['projection']) != 'composed') result = Scrollbar(controller: axes == 'horizontal' ? _horizontalControl : _verticalControl, child: result);
    final policy = config['endFollow'];
    if (policy is Map<String, Object?> && policy['mode'] == 'while-at-end') {
      final control = _controller(policy['axis'] as String? ?? 'vertical');
      final epoch = owner.epoch, generation = _requestGeneration;
      WidgetsBinding.instance.addPostFrameCallback((_) { if (!owner.alive || !owner.ready || owner.epoch != epoch || generation != _requestGeneration || !control.hasClients) return; if (following) control.jumpTo(control.position.maxScrollExtent); });
    }
    result = NotificationListener<ScrollMetricsNotification>(onNotification: _nativeMetrics, child: result);
    return NotificationListener<ScrollNotification>(onNotification: _nativeScroll, child: result);
  }
  void mount() { if (!_mounted) { _mounted = true; final preference = config['requireProjection'] ?? config['projection']; projection.publish(preference == 'composed' ? 'composed' : 'system'); final policy = config['endFollow']; following = policy is Map<String,Object?> && policy['mode'] == 'while-at-end' && _controller(policy['axis'] as String).hasClients && _controller(policy['axis'] as String).position.extentAfter <= 1; } _refresh(); }
  void unmount() { _mounted = false; _pendingEndGeneration = null; _explicitlyPaused = false; _readerObservation = null; _followObservation = null; _releaseChrome(); horizontal.reset(); vertical.reset(); scrolling.publish(false); projection.publish('unresolved'); endFollow.requestStatus.publish('idle'); following = false; _followFacts(); }
  void dispose() { _offCommit(); _releaseChrome(); _verticalControl.dispose(); _horizontalControl.dispose(); vertical.dispose(); horizontal.dispose(); axes.subscribers.clear(); projection.subscribers.clear(); scrolling.subscribers.clear(); endFollow.dispose(); }
}
class NativeTextControl<P> {
  NativeTextControl(this.owner) { controller.addListener(_changed); owner.focus.node.addListener(_focusChanged); }
  final NativeOwner<P> owner;
  final TextEditingController controller = TextEditingController();
  Map<String, Object?> config = {};
  final Map<String, Set<void Function(NativeRun<P>, Map<String, Object?>)>> listeners = {};
  bool composing = false, syncing = false, multiline = false, initialized = false;
  String previous = '';
  String committedValue = '';
  bool hadFocus = false;
  String normalize(String value) { final normalized = value.replaceAll('\r\n', '\n').replaceAll('\r', '\n'); return multiline ? normalized : normalized.replaceAll('\n', ''); }
  void Function() on(String type, void Function(NativeRun<P>, Map<String, Object?>) callback) { owner.ensureSetup(); if (!['input','change','compositionstart','compositionupdate','compositionend'].contains(type)) throw ArgumentError('Invalid TextControl event'); final entries = listeners.putIfAbsent(type, () => {}); entries.add(callback); return () { owner.ensureSetup(); entries.remove(callback); }; }
  void sync(Map<String, Object?> patch) {
    owner.ensureRuntime(); config = {...config, ...patch};
    if (!multiline && (patch.containsKey('rows') || patch.containsKey('wrap'))) throw ArgumentError('Multiline fields on single-line TextControl');
    final controlled = config['valueMode'] == 'controlled';
    if (controlled && patch.containsKey('value') || !initialized && patch.containsKey('defaultValue')) {
      final value = normalize((controlled ? patch['value'] : patch['defaultValue']) as String); syncing = true;
      try { if (controller.text != value) controller.value = TextEditingValue(text: value, selection: TextSelection.collapsed(offset: value.length)); previous = value; committedValue = value; } finally { syncing = false; }
    }
    owner.focus.node.canRequestFocus = config['disabled'] != true && !owner.focus.disabled; initialized = true; owner.project();
  }
  Map<String, Object?>? snapshot() { owner.ensureAlive(); return !owner.ready ? null : {'value': normalize(controller.text), 'composing': composing}; }
  void _emit(String type, [String? data]) {
    if (!owner.ready) return;
    final event = <String, Object?>{'type': type, 'value': normalize(controller.text), 'composing': composing, 'data': data, 'inputType': null};
    for (final callback in List.of(listeners[type] ?? <void Function(NativeRun<P>, Map<String, Object?>)>{})) owner.inScope('event', () => owner.invoke((run) => callback(run,event)));
  }
  void _changed() {
    if (!owner.alive || syncing) return;
    final nextComposing = controller.value.composing.isValid && !controller.value.composing.isCollapsed;
    if (nextComposing && !composing) { composing = true; _emit('compositionstart'); }
    else if (nextComposing) _emit('compositionupdate');
    if (!nextComposing && composing) { composing = false; _emit('compositionend'); }
    final value = normalize(controller.text); if (value != previous) { previous = value; _emit('input'); owner.dispatch(NativeInput('input')); }
  }
  void _commitValue() { if (committedValue == normalize(controller.text)) return; committedValue = normalize(controller.text); _emit('change'); owner.dispatch(NativeInput('change')); }
  void _focusChanged() { final next = owner.focus.node.hasFocus; if (hadFocus && !next && owner.ready) _commitValue(); hadFocus = next; }
  Widget widget() {
    final placeholder = config['placeholder'] as String?; final maxLength = (config['maxLength'] as num?)?.toInt();
    final editor = EditableText(controller: controller, focusNode: owner.focus.node, style: const TextStyle(fontSize:16,color:Color(0xff000000)), cursorColor:const Color(0xff000000), backgroundCursorColor:const Color(0xff808080), minLines:multiline ? (config['rows'] as num?)?.toInt() : 1, maxLines:multiline ? null : 1, readOnly:config['readOnly'] == true || config['disabled'] == true, keyboardType:_keyboard(), textInputAction:_action(), autofillHints:config['autoComplete'] == 'off' ? null : config['autoComplete'] is String ? [config['autoComplete'] as String] : const [], inputFormatters:[if (maxLength != null) LengthLimitingTextInputFormatter(maxLength),TextInputFormatter.withFunction((previous,next) { final value = normalize(next.text); if (value == next.text) return next; return next.copyWith(text:value,selection:TextSelection(baseOffset:next.selection.baseOffset.clamp(0,value.length),extentOffset:next.selection.extentOffset.clamp(0,value.length)),composing:TextRange.empty); })], onSubmitted:(_) => _commitValue());
    return Semantics(textField:true,enabled:config['disabled'] != true,readOnly:config['readOnly'] == true,label:config['name'] as String?,child:placeholder == null ? editor : Stack(children:[ValueListenableBuilder<TextEditingValue>(valueListenable:controller,builder:(_,value,__) => value.text.isEmpty ? IgnorePointer(child:Text(placeholder,style:const TextStyle(color:Color(0xff808080)))) : const SizedBox.shrink()),editor]));
  }
  TextInputAction _action() { final name = config['enterKeyHint']; return name == 'done' ? TextInputAction.done : name == 'go' ? TextInputAction.go : name == 'next' ? TextInputAction.next : name == 'previous' ? TextInputAction.previous : name == 'search' ? TextInputAction.search : name == 'send' ? TextInputAction.send : multiline ? TextInputAction.newline : TextInputAction.done; }
  TextInputType _keyboard() { final mode = config['inputMode']; return mode == 'none' ? TextInputType.none : mode == 'numeric' ? TextInputType.number : mode == 'decimal' ? const TextInputType.numberWithOptions(decimal: true) : mode == 'email' ? TextInputType.emailAddress : mode == 'tel' ? TextInputType.phone : mode == 'url' ? TextInputType.url : multiline ? TextInputType.multiline : TextInputType.text; }
  void dispose() { owner.focus.node.removeListener(_focusChanged); controller.removeListener(_changed); controller.dispose(); listeners.clear(); }
}
class NativeImageView<P> {
  NativeImageView(this.owner);
  final NativeOwner<P> owner;
  Map<String, Object?> config = {};
  final Set<void Function(NativeRun<P>, Map<String, Object?>)> listeners = {};
  String status = 'idle', source = '';
  int generation = 0;
  ImageStream? stream;
  ImageStreamListener? streamListener;
  ImageInfo? image;
  void Function() on(String type, void Function(NativeRun<P>, Map<String, Object?>) callback) { owner.ensureSetup(); if (type != 'loadingStatusChange') throw ArgumentError('Invalid ImageView event'); listeners.add(callback); return () { owner.ensureSetup(); listeners.remove(callback); }; }
  void _status(String value) {
    if (value == status) return; final previous = status; status = value;
    final event = <String, Object?>{'status': value, 'previousStatus': previous, 'source': source};
    for (final callback in List.of(listeners)) if (owner.alive) owner.inScope('event', () => owner.invoke((run) => callback(run,event)));
    owner.project();
  }
  void sync(Map<String, Object?> patch) {
    owner.ensureRuntime(); config = {...config, ...patch};
    final next = config['source'] as String? ?? source;
    if (next != source) { source = next; generation++; _release(); _status(source.isEmpty ? 'idle' : 'loading'); if (source.isNotEmpty && owner.ready) _load(generation); }
    owner.project();
  }
  void _load(int ticket) {
    final provider = source.startsWith('http:') || source.startsWith('https:') ? NetworkImage(source) as ImageProvider<Object> : AssetImage(source);
    final nextStream = provider.resolve(const ImageConfiguration()); stream = nextStream;
    final listener = ImageStreamListener((info, _) { if (!owner.alive || !owner.ready || ticket != generation) { info.dispose(); return; } image?.dispose(); image = info; _status('loaded'); }, onError: (Object error, StackTrace? stack) { if (!owner.alive || !owner.ready || ticket != generation) return; _status('error'); FlutterError.reportError(FlutterErrorDetails(exception: error, stack: stack)); });
    streamListener = listener; nextStream.addListener(listener);
  }
  Map<String, Object?>? snapshot() { owner.ensureAlive(); return !owner.ready ? null : {'source': source, 'loadingStatus': status, 'fit': config['fit'] ?? 'contain'}; }
  void mount() { if (source.isNotEmpty && stream == null) { _status('loading'); _load(++generation); } }
  void unmount() { generation++; _release(); }
  Widget widget() {
    final fit = config['fit'] == 'cover' ? BoxFit.cover : config['fit'] == 'fill' ? BoxFit.fill : BoxFit.contain;
    return Semantics(image: true, label: config['a11yMode'] == 'decorative' ? null : config['alternativeText'] as String?, excludeSemantics: config['a11yMode'] == 'decorative', child: RawImage(image: image?.image, scale: image?.scale ?? 1, fit: fit));
  }
  void _release() { final listener = streamListener; if (listener != null) stream?.removeListener(listener); stream = null; streamListener = null; image?.dispose(); image = null; }
  void dispose() { generation++; _release(); listeners.clear(); }
}


class NativeVoid { const NativeVoid(); }
class NativeOptional<T> {
  const NativeOptional.absent() : present = false, _value = null;
  const NativeOptional.value(T value) : present = true, _value = value;
  final bool present;
  final Object? _value;
  T get value { if (!present) throw StateError('Optional data field is absent'); return _value as T; }
}
Object? nativeValue(Object? value) => value is NativeOptional<Object?> ? value.present ? value.value : const NativeVoid() : value;
NativeOptional<T> nativeIndex<T>(List<T> values, int index) => index >= 0 && index < values.length ? NativeOptional.value(values[index]) : const NativeOptional<Never>.absent();
NativeOptional<R> nativeAccess<T, R>(T? receiver, NativeOptional<R> Function(T) read) => receiver == null ? const NativeOptional<Never>.absent() : read(receiver);
NativeOptional<T> nativeOptionalResult<T>(Object? value) { value = nativeValue(value); return value is NativeVoid ? const NativeOptional<Never>.absent() : NativeOptional.value(value as T); }
NativeOptional<T> nativeOptionalNullable<T>(T? value) => value == null ? const NativeOptional<Never>.absent() : NativeOptional.value(value);
Object? nativeCoalesce(Object? left, Object? Function() right) { final value = nativeValue(left); return value == null || value is NativeVoid ? right() : value; }
Map<String, Object?> nativeConfig<T>(T value, Map<String, Object?> Function(T) project) => project(value);
R nativeProject<T, R>(T value, R Function(T) project) => project(value);
bool nativeTruthy(Object? value) { value = nativeValue(value); return value is! NativeVoid && value != null && value != false && value != '' && (value is! num || value != 0 && !value.isNaN); }
double nativeNumber(Object? value) {
  value = nativeValue(value);
  if (value is NativeVoid) return double.nan;
  if (value == null) return 0;
  if (value is num) return value.toDouble();
  if (value is bool) return value ? 1 : 0;
  if (value is String) {
    final text = value.trim(); if (text.isEmpty) return 0;
    if (RegExp(r'^0[xX][0-9a-fA-F]+$').hasMatch(text)) return BigInt.parse(text.substring(2),radix:16).toDouble();
    if (RegExp(r'^0[bB][01]+$').hasMatch(text)) return BigInt.parse(text.substring(2),radix:2).toDouble();
    if (RegExp(r'^0[oO][0-7]+$').hasMatch(text)) return BigInt.parse(text.substring(2),radix:8).toDouble();
    if (!RegExp(r'^[+-]?(?:Infinity|(?:[0-9]+\.?[0-9]*|\.[0-9]+)(?:[eE][+-]?[0-9]+)?)$').hasMatch(text)) return double.nan;
    return double.tryParse(text) ?? double.nan;
  }
  throw ArgumentError('Only admitted scalar values may undergo numeric coercion');
}
String nativeString(Object? value) {
  value = nativeValue(value);
  if (value is NativeVoid) return 'undefined';
  if (value == null) return 'null';
  if (value is num) { if (value == 0) return '0'; final text = value.toDouble().toString(); return text.endsWith('.0') ? text.substring(0,text.length-2) : text; }
  if (value is bool || value is String) return value.toString();
  throw ArgumentError('Only admitted scalar values may undergo string coercion');
}
bool nativeSame(Object? left, Object? right) { left = nativeValue(left); right = nativeValue(right); return left is NativeVoid || right is NativeVoid ? left is NativeVoid && right is NativeVoid : left is num && right is num ? left == right : left is String && right is String || left is bool && right is bool || left == null || right == null ? left == right : identical(left, right); }
bool nativeIdentitySame(Object? left, Object? right) { if (left is num && right is num) { if (left.isNaN || right.isNaN) return left.isNaN && right.isNaN; if (left == 0 && right == 0) return 1 / left == 1 / right; } return nativeSame(left, right); }
Object? nativeLogical(Object? left, Object? Function() right, bool and) => nativeTruthy(left) == and ? right() : left;
Object nativeAdd(Object? left, Object? right) { left = nativeValue(left); right = nativeValue(right); return left is String || right is String ? nativeString(left) + nativeString(right) : nativeNumber(left) + nativeNumber(right); }
bool nativeCompare(Object? left, Object? right, String operator) {
  left = nativeValue(left); right = nativeValue(right);
  if (left is String && right is String) { final comparison = left.compareTo(right); return operator == '<' ? comparison < 0 : operator == '<=' ? comparison <= 0 : operator == '>' ? comparison > 0 : comparison >= 0; }
  final a = nativeNumber(left), b = nativeNumber(right);
  return operator == '<' ? a < b : operator == '<=' ? a <= b : operator == '>' ? a > b : a >= b;
}
class NativeEmptyRecord { const NativeEmptyRecord(); }
class NativeProvided<T> {
  const NativeProvided.absent() : present = false, value = null;
  const NativeProvided.value(this.value) : present = true;
  final bool present;
  final T? value;
}
class NativeStateChange<T> {
  const NativeStateChange(this.prev, this.next, this.reason);
  String get type => 'next';
  final T prev;
  final T next;
  final Object? reason;
}
class NativeStateWatchEvent<T> {
  const NativeStateWatchEvent.next(this.prev, this.next, this.reason) : type = 'next';
  const NativeStateWatchEvent.disconnect() : type = 'disconnect', prev = null, next = null, reason = null;
  final String type;
  final T? prev, next;
  final Object? reason;
}
abstract class NativeObserved<T> {
  T get();
  void Function() subscribe(void Function(NativeStateChange<T>) callback);
  void unsubscribe(void Function() removal);
  Map<String, Object?> get spec;
  NativeObserved<T> get external;
}
class _ExternalState<T> implements NativeObserved<T> {
  _ExternalState(this.source);
  final NativeState<T> source;
  @override T get() { source.owner.ensureExternal(); return source.value; }
  @override Map<String, Object?> get spec { source.owner.ensureExternal(); return source.spec; }
  @override NativeObserved<T> get external => this;
  @override void Function() subscribe(void Function(NativeStateChange<T>) callback) {
    source.owner.ensureExternal();
    source.subscribers.add(callback);
    bool active = true;
    return () { source.owner.ensureExternal(); if (active) { active = false; source.subscribers.remove(callback); } };
  }
  @override void unsubscribe(void Function() removal) { source.owner.ensureExternal(); removal(); }
}
class NativeState<T> implements NativeObserved<T> {
  NativeState(this.owner, this.kind, this.semantic, T initial, Map<String, Object?> options, {this.observed = false}) : spec = Map.unmodifiable({...options, 'kind': kind}), value = initial {
    value = normalize(initial, initial: true);
    externalView = _ExternalState<T>(this);
  }
  final NativeOwnerBase owner;
  final String kind;
  final String semantic;
  final bool observed;
  @override final Map<String, Object?> spec;
  T value;
  late final NativeObserved<T> externalView;
  final Set<void Function(NativeStateChange<T>)> subscribers = {};
  @override NativeObserved<T> get external => externalView;
  @override T get() { owner.ensureAlive(); return value; }
  T normalize(T candidate, {bool initial = false}) {
    Object? next = candidate;
    if (kind == 'bool' && next is! bool || (kind == 'string' || kind == 'enum') && next is! String || kind.startsWith('number') && (next is! num || next.isNaN)) throw ArgumentError('Invalid State value for $semantic');
    final options = spec['options'];
    if (kind == 'enum' && (options is! List<Object?> || !options.contains(next))) throw RangeError('Enum State value outside options: $semantic');
    if (options is List<Object?> && options.isNotEmpty && !options.contains(next)) throw RangeError('State outside options: $semantic');
    if (next is num) {
      final min = spec['min'] as num?;
      final max = spec['max'] as num?;
      if (kind == 'number.range' && initial && spec['clamp'] == true) next = next.clamp(min ?? double.negativeInfinity, max ?? double.infinity);
      final numeric = next as num;
      if (kind == 'number.range' || kind == 'number.discrete' && (options is! List<Object?> || options.isEmpty)) {
        if (min != null && numeric < min || max != null && numeric > max) throw RangeError('State outside range: $semantic');
        final step = spec['step'] as num?;
        if (kind == 'number.discrete' && step != null && step > 0 && ((numeric - (min ?? 0)) / step) % 1 != 0) throw RangeError('State violates step: $semantic');
      }
    }
    return (next is num ? next.toDouble() : next) as T;
  }
  void set(T next, [Object? reason]) { owner.ensureRuntime(); if (observed) throw StateError('Observed State has no write authority'); publish(normalize(next), reason); }
  void setDefault(T next) { owner.ensureSetup(); if (observed) throw StateError('Observed State has no default authority'); value = normalize(next,initial:true); }
  void publish(T next, [Object? reason]) {
    if (nativeIdentitySame(value, next)) return;
    final previous = value; value = next;
    owner.project();
    final event = NativeStateChange<T>(previous, next, reason);
    owner.enqueue(() { for (final callback in List.of(subscribers)) { if (subscribers.contains(callback) && owner.alive && !owner.disposing) owner.inScope('state-observer', () => callback(event)); } });
  }
  @override void Function() subscribe(void Function(NativeStateChange<T>) callback) => externalView.subscribe(callback);
  @override void unsubscribe(void Function() removal) => externalView.unsubscribe(removal);
}
abstract class NativeEventBase { void emit(Object? payload); void clear(); }
class NativeEvent<T> implements NativeEventBase {
  NativeEvent(this.owner, this.accepts);
  final NativeOwnerBase owner;
  final bool Function(Object?) accepts;
  final Set<void Function(T)> _subscribers = {};
  void Function() subscribe(void Function(T) callback) { owner.ensureExternal(); _subscribers.add(callback); return () { owner.ensureExternal(); _subscribers.remove(callback); }; }
  @override void emit(Object? payload) { if (!accepts(payload)) throw ArgumentError('Exposed event payload violates its checked signature'); final value = payload as T; for (final callback in List.of(_subscribers)) { if (_subscribers.contains(callback)) owner.inScope('expose-observer', () => callback(value)); } }
  @override void clear() => _subscribers.clear();
}

class NativeContextKey<T> {
  NativeContextKey(this.debugName, this.accepts);
  final String debugName;
  final bool Function(Object?) accepts;
}
abstract class _ContextCellBase { Object? get erasedValue; void write(Object? value); }
class _ContextCell<T> implements _ContextCellBase {
  _ContextCell(this.value);
  T value;
  @override Object? get erasedValue => value;
  @override void write(Object? next) { value = next as T; }
}
class _ContextSubscription {
  _ContextSubscription(this.optional, this.callback);
  final bool optional;
  final void Function(Object?, Object?)? callback;
  bool active = true;
}
class NativeContextScope {
  NativeContextScope(this.owner, this.parent) { _live.add(this); }
  static final Set<NativeContextScope> _live = {};
  static final Queue<void Function()> _notifications = Queue();
  static bool _dispatching = false;
  final NativeOwnerBase owner;
  NativeContextScope? parent;
  final Map<Object, _ContextCellBase> _providers = Map.identity();
  final Map<Object, List<_ContextSubscription>> _subscriptions = Map.identity();
  NativeContextScope? resolve(Object key) {
    NativeContextScope? current = this;
    final visited = <NativeContextScope>{};
    while (current != null) {
      if (!visited.add(current)) throw StateError('Cyclic logical Context ancestry');
      if (!current.owner.alive) return null;
      if (current._providers.containsKey(key)) return current;
      current = current.parent;
    }
    return null;
  }
  void provide<T>(NativeContextKey<T> key, T value) {
    owner.ensureSetup();
    if (_providers.containsKey(key)) throw StateError('Duplicate Context provider');
    if (!key.accepts(value)) throw ArgumentError('Invalid Context value: ${key.debugName}');
    _providers[key] = _ContextCell<T>(value);
  }
  void Function() subscribe<T>(NativeContextKey<T> key, bool optional, [void Function(T?, T?)? callback]) {
    owner.ensureSetup();
    if (!optional && resolve(key) == null) throw StateError('Required Context provider missing: ${key.debugName}');
    final entries = _subscriptions.putIfAbsent(key, () => []);
    if (entries.any((entry) => entry.optional != optional)) throw StateError('Conflicting Context subscription mode');
    final entry = _ContextSubscription(optional, callback == null ? null : (next, prev) => callback(next as T?, prev as T?));
    entries.add(entry);
    return () { owner.ensureAlive(); entry.active = false; };
  }
  void _subscribed(Object key, bool optional) {
    owner.ensureAlive();
    if (!_subscriptions.containsKey(key) || !_subscriptions[key]!.any((entry) => entry.optional == optional)) throw StateError('Context access requires declared subscription');
  }
  T read<T>(NativeContextKey<T> key) {
    _subscribed(key, false);
    final provider = resolve(key);
    if (provider == null) throw StateError('Required Context provider missing');
    return provider._providers[key]!.erasedValue as T;
  }
  T? tryRead<T>(NativeContextKey<T> key) { _subscribed(key, true); return resolve(key)?._providers[key]?.erasedValue as T?; }
  void update<T>(NativeContextKey<T> key, T Function(T) next) { owner.ensureRuntime(); if (!_providers.containsKey(key)) _subscribed(key, false); final provider = resolve(key); if (provider == null) throw StateError('Required Context provider missing'); _write(key, next, provider); }
  bool tryUpdate<T>(NativeContextKey<T> key, T Function(T) next) { owner.ensureRuntime(); _subscribed(key, true); final provider = resolve(key); if (provider == null) return false; _write(key, next, provider); return true; }
  void _write<T>(NativeContextKey<T> key, T Function(T) next, NativeContextScope provider) {
    final cell = provider._providers[key]!;
    final previous = cell.erasedValue as T;
    final value = next(previous);
    owner.ensureAlive();
    if (!provider.owner.alive || !key.accepts(value)) throw ArgumentError('Invalid Context transition');
    cell.write(value);
    for (final scope in List.of(_live)) {
      if (!scope.owner.alive || scope.resolve(key) != provider) continue;
      for (final entry in scope._subscriptions[key] ?? <_ContextSubscription>[]) {
        if (!entry.active || entry.callback == null) continue;
        _notifications.add(() { if (entry.active && scope.owner.alive) entry.callback!(value, previous); });
      }
    }
    if (_dispatching) return;
    _dispatching = true;
    Object? failure;
    StackTrace? trace;
    try { while (_notifications.isNotEmpty) { try { _notifications.removeFirst()(); } catch (error, stack) { failure ??= error; trace ??= stack; } } }
    finally { _dispatching = false; }
    if (failure != null) Error.throwWithStackTrace(failure, trace!);
  }
  void dispose() { _live.remove(this); for (final entries in _subscriptions.values) { for (final entry in entries) { entry.active = false; } } _subscriptions.clear(); _providers.clear(); parent = null; }
}
class NativeContextHost extends InheritedWidget {
  const NativeContextHost({super.key, required this.scope, required super.child, this.active = true});
  final NativeContextScope scope;
  final bool active;
  static NativeContextScope? maybeOf(BuildContext context) => context.dependOnInheritedWidgetOfExactType<NativeContextHost>()?.scope;
  @override bool updateShouldNotify(NativeContextHost oldWidget) => oldWidget.scope != scope || oldWidget.active != active;
}

class NativeStyleHandle {
  const NativeStyleHandle(this.tokens, this.groups);
  final List<String> tokens;
  final List<String> groups;
}
class _StyleChunk {
  _StyleChunk(this.handles, [this.test]);
  final List<NativeStyleHandle> handles;
  final bool Function()? test;
  bool active = true;
}
class NativeRule { NativeRule(this._dispose); final void Function() _dispose; void dispose() => _dispose(); }
class NativeStyle {
  NativeStyle(this.owner);
  final NativeOwnerBase owner;
  final List<_StyleChunk> _base = [], _rules = [];
  final Map<String, String?> _patch = {};
  void Function() use(List<NativeStyleHandle> handles) { owner.ensureSetup(); final entry = _StyleChunk(List.unmodifiable(handles)); _base.add(entry); return () { owner.ensureSetup(); entry.active = false; }; }
  NativeRule rule(bool Function() test, List<NativeStyleHandle> handles) { owner.ensureSetup(); final entry = _StyleChunk(List.unmodifiable(handles), test); _rules.add(entry); return NativeRule(() { owner.ensureSetup(); entry.active = false; }); }
  void patch(List<NativeStyleHandle> handles) { owner.ensureRuntime(); for (final handle in handles) { for (int i = 0; i < handle.tokens.length; i++) { _patch[handle.groups[i]] = handle.tokens[i]; } } owner.project(); }
  void suppress(List<NativeStyleHandle> handles) { owner.ensureRuntime(); for (final handle in handles) { for (final group in handle.groups) { _patch[group] = null; } } owner.project(); }
  void clearPatch() { owner.ensureRuntime(); _patch.clear(); owner.project(); }
  List<String> tokens() {
    final merged = <String, String>{};
    for (final chunk in [..._base, ..._rules]) { if (!chunk.active || chunk.test != null && (!owner.surfaceActive || !chunk.test!())) continue; for (final handle in chunk.handles) { for (int i = 0; i < handle.tokens.length; i++) { merged[handle.groups[i]] = handle.tokens[i]; } } }
    for (final entry in _patch.entries) { merged.remove(entry.key); if (entry.value != null) merged[entry.key] = entry.value!; }
    return List.unmodifiable(merged.values);
  }
  void dispose() { _base.clear(); _rules.clear(); _patch.clear(); }
}

class NativeInput {
  NativeInput(this.type, {this.key, this.ctrlKey = false, this.metaKey = false, this.altKey = false, this.shiftKey = false, this.repeat = false, this.pointer, this.globalPosition, this.localPosition, this.keyboardEvent, this.pointerEvent});
  final String type;
  final String? key;
  final bool ctrlKey, metaKey, altKey, shiftKey, repeat;
  final int? pointer;
  final Offset? globalPosition, localPosition;
  final KeyEvent? keyboardEvent;
  final PointerEvent? pointerEvent;
  bool defaultPrevented = false;
  bool _active = true, _passive = false;
  NativeInput get control => this;
  void requestDefaultActionPrevention() { if (!_active || _passive) throw StateError('Default action prevention outside live cancellable input'); defaultPrevented = true; }
}
class NativeFocus {
  NativeFocus(this.owner) {
    focused = NativeState<bool>(owner, 'bool', 'focus.focused', false, const {}, observed: true);
    focusVisible = NativeState<bool>(owner, 'bool', 'focus.focusVisible', false, const {}, observed: true);
    focusable = NativeState<bool>(owner, 'bool', 'focus.focusable', false, const {}, observed: true);
    node.addListener(_changed);
    FocusManager.instance.addHighlightModeListener(_highlightChanged);
  }
  final NativeOwnerBase owner;
  final FocusNode node = FocusNode();
  late final NativeState<bool> focused, focusVisible, focusable;
  bool disabled = false, autoFocus = false, nav = true;
  NativeFocusScopeKey? scopeKey;
  NativeFocusRovingKey? groupKey;
  void configure(Map<String, Object?> patch) { owner.ensureSetup(); disabled = patch['disabled'] as bool? ?? disabled; autoFocus = patch['autoFocus'] as bool? ?? autoFocus; if (patch.containsKey('navParticipation')) nav = patch['navParticipation'] != 'none'; scopeKey = patch['scopeKey'] as NativeFocusScopeKey? ?? scopeKey; groupKey = patch['groupKey'] as NativeFocusRovingKey? ?? groupKey; refresh(); }
  void setDisabled(bool value) { owner.ensureRuntime(); disabled = value; node.canRequestFocus = !value && owner.focusAvailable; if (value) node.unfocus(); refresh(); owner.project(); }
  void focusSelf([Map<String,Object?> options = const {}]) { owner.ensureRuntime(); if (!owner.ready || disabled) return; node.requestFocus(); if (options['preventScroll'] != true) { final context = node.context; if (context != null) Scrollable.ensureVisible(context); } }
  void focus([Map<String, Object?> options = const {}]) => focusSelf(options);
  bool isFocused() { owner.ensureAlive(); return focused.get(); }
  void blur() { owner.ensureRuntime(); node.unfocus(); }
  bool rovingSelected = false, rovingActive = false;
  void setNavParticipation(String value) { owner.ensureRuntime(); if (!['auto','none'].contains(value)) throw ArgumentError('Invalid focus navigation participation'); nav = value != 'none'; node.skipTraversal = !nav; refresh(); owner.project(); }
  void setRovingStatus(Map<String, Object?> status) { owner.ensureRuntime(); rovingSelected = status['selected'] as bool? ?? rovingSelected; rovingActive = status['active'] as bool? ?? rovingActive; owner.project(); }
  void refresh() { focusable.publish(owner.ready && owner.focusAvailable && !disabled && nav); }
  void _highlightChanged(FocusHighlightMode mode) { if (owner.alive) focusVisible.publish(node.hasFocus && mode == FocusHighlightMode.traditional); }
  void _changed() { if (!owner.alive) return; focused.publish(node.hasFocus); focusVisible.publish(node.hasFocus && FocusManager.instance.highlightMode == FocusHighlightMode.traditional); owner.dispatch(NativeInput(node.hasFocus ? 'nav.focus' : 'nav.blur')); }
  void dispose() { FocusManager.instance.removeHighlightModeListener(_highlightChanged); node.removeListener(_changed); node.dispose(); focused.subscribers.clear(); focusVisible.subscribers.clear(); focusable.subscribers.clear(); }
}
class NativeAccessible {
  NativeAccessible(this.owner);
  final NativeOwnerBase owner;
  final Map<String, NativeObserved<Object?>> states = {};
  final Map<String, NativeObserved<bool>> stateConditions = {};
  final Map<String, String> actions = {};
  Object? roleValue;
  bool contentName = false;
  late final NativeA11yRef objectRef = NativeA11yRef()..bind(this);
  Object? _identifier, _name, _description, _heading;
  Object? resolve(Object? value) => value is NativeObserved<Object?> ? value.get() : value;
  String? get identifier => resolve(_identifier) as String?;
  String? get textName => resolve(_name) as String?;
  String? get textDescription => resolve(_description) as String?;
  num? get heading => resolve(_heading) as num?;
  final Map<String, Map<String, Object?>> relations = {};
  Map<String, Object?> treeBehavior = {};
  void id(Object? value) { owner.ensureSetup(); _identifier = value; }
  void name(Object? value) { owner.ensureSetup(); _name = value; contentName = false; }
  void description(Object? value) { owner.ensureSetup(); _description = value; }
  void relation(String key, Map<String, Object?> spec) { owner.ensureSetup(); if (spec['mode'] == 'append' && relations.containsKey(key)) { final prior = relations[key]!['target']; final next = spec['target']; relations[key] = {...spec, 'target': [if (prior is List<Object?>) ...prior else prior, if (next is List<Object?>) ...next else next]}; } else relations[key] = Map.unmodifiable(spec); }
  void tree(Map<String, Object?> patch) { owner.ensureSetup(); treeBehavior = {...treeBehavior, ...patch}; }
  void level(Object value) { owner.ensureSetup(); final current = resolve(value); if (current is! num || !current.isFinite || current < 1 || current % 1 != 0) throw ArgumentError('Invalid semantic heading level'); _heading = value; }
  void state<T>(String name, NativeObserved<T> handle, [Map<String, Object?> options = const {}]) { owner.ensureSetup(); states[name] = handle; stateConditions.remove(name); final when = options['when']; if (when is NativeObserved<bool>) stateConditions[name] = when; }
  void action(String name, [Map<String, Object?> options = const {}]) { owner.ensureSetup(); actions[name] = options['event'] as String? ?? name; }
  void role(Object value) { owner.ensureSetup(); if (value is! String && value is! NativeObserved<String>) throw ArgumentError('Invalid AX role'); roleValue = value; }
  void nameFromContent() { owner.ensureSetup(); contentName = true; }
  Object? value(String name) { final current = states[name]?.get(); return stateConditions.containsKey(name) && stateConditions[name]?.get() != true ? null : current; }
  Widget wrap(Widget child) {
    final role = roleValue is NativeObserved<String> ? (roleValue as NativeObserved<String>).get() : roleValue;
    final controls = relations['controls']?['target'];
    final controlsNodes = _relationIds(controls).toSet();
    final nativeRole = SemanticsRole.values.where((value) => value.name.toLowerCase() == role?.toString().toLowerCase()).firstOrNull;
    final labelledBy = _relationText((relations['labelledBy'] ?? relations['labelledby'])?['target']);
    final describedBy = _relationText((relations['describedBy'] ?? relations['describedby'])?['target']);
    Widget result = Semantics(container: true, explicitChildNodes: !contentName,
      identifier: identifier ?? owner.hostTarget.key.toString(), label: labelledBy.isEmpty ? textName : labelledBy.join(' '), hint: describedBy.isEmpty ? textDescription : describedBy.join(' '), headingLevel: heading?.toInt(), controlsNodes: controlsNodes.isEmpty ? null : controlsNodes, role: nativeRole,
      button: role == 'button', textField: role == 'textbox', slider: role == 'slider', link: role == 'link', image: role == 'img', header: role == 'heading',
      enabled: value('disabled') == true ? false : null, checked: value('checked') is bool ? value('checked') as bool : null, mixed: value('checked') == 'mixed', selected: value('selected') as bool?, expanded: value('expanded') as bool?, toggled: value('pressed') is bool ? value('pressed') as bool : null,
      readOnly: value('readOnly') as bool?, scopesRoute: value('modal') == true,
      liveRegion: value('live') == 'polite' || value('live') == 'assertive', hidden: resolve(treeBehavior['hidden']) == true || value('hidden') == true,
      onTap: actions.containsKey('activate') || role == 'button' ? () => owner.semanticAction(actions['activate'] ?? 'press.commit') : null,
      onIncrease: actions.containsKey('increment') ? () => owner.semanticAction(actions['increment']!) : null,
      onDecrease: actions.containsKey('decrement') ? () => owner.semanticAction(actions['decrement']!) : null,
      child: child);
    if (resolve(treeBehavior['mergeChildren']) == true || contentName) result = MergeSemantics(child: result);
    return result;
  }
  List<String> _relationIds(Object? target) {
    target = resolve(target);
    if (target is String) return target.split(RegExp(r'\s+')).where((id) => id.isNotEmpty).toList();
    if (target is NativeA11yRef) { final accessible = target.accessible; return accessible == null || !accessible.owner.alive ? const [] : [accessible.identifier ?? accessible.owner.hostTarget.key.toString()]; }
    if (target is NativeHostTarget) return [target.key.toString()];
    if (target is List<Object?>) return [for (final item in target) ..._relationIds(item)];
    return const [];
  }
  List<String> _relationText(Object? target) {
    final ids = _relationIds(target);
    return [for (final participant in NativeOwner._liveOwners) if (participant.alive && ids.contains(participant.accessible.identifier ?? participant.hostTarget.key.toString())) participant.accessible.textName ?? nativeContentText(participant._projection)];
  }
}
class NativeA11yRef {
  NativeAccessible? _accessible;
  NativeAccessible? get accessible => _accessible;
  void bind(NativeAccessible target) { if (_accessible != null && _accessible != target && _accessible!.owner.alive) throw StateError('Semantic object ref already has a live owner'); _accessible = target; }
}
String nativeContentText(Widget? widget) {
  if (widget is Text) return widget.data ?? widget.textSpan?.toPlainText() ?? '';
  if (widget is NativeElement) return widget.children.map(nativeContentText).join('');
  if (widget is _NativeSlot) return nativeContentText(widget.owner.suppliedChild.value);
  if (widget is Flex) return widget.children.map(nativeContentText).join('');
  if (widget is Wrap) return widget.children.map(nativeContentText).join('');
  return '';
}
class _Listener {
  _Listener(this.callback, this.global, this.once, this.passive);
  final void Function(NativeInput) callback;
  final bool global, once, passive;
  bool active = true;
}
abstract class NativeOwnerBase {
  bool get alive;
  bool get disposing;
  bool get ready;
  bool get surfaceActive;
  bool get focusAvailable;
  NativeHostTarget get hostTarget;
  void ensureAlive();
  void ensureExternal();
  void ensureSetup();
  void ensureRuntime();
  T inScope<T>(String scope, T Function() callback);
  void project();
  void enqueue(void Function() callback);
  void dispatch(NativeInput event, {bool globalOnly = false});
  void semanticAction(String event);
}
class NativeRun<P> {
  NativeRun(this.owner, this._valid);
  final NativeOwner<P> owner;
  final bool Function() _valid;
  void check() { owner.ensureAlive(); if (!_valid()) throw StateError('Callback handle is stale'); }
  P get props { check(); return owner.props; }
  Map<String, Object?> get rawProps { check(); return owner.rawProps; }
  bool isProvided(String key) { check(); return owner.rawProps.containsKey(key); }
  NativeContextScope get context { check(); return owner.context; }
  NativeAnatomy get anatomy { check(); return owner.anatomy; }
  NativeHostTarget? getHost() { check(); return owner.ready ? owner.hostTarget : null; }
  NativeStyle get style { check(); return owner.style; }
  void update() { check(); owner.requestUpdate(); }
  void setPresent(bool value) { check(); owner.ensureRuntime(); if (owner.disposing) throw StateError('Present intent is closed during disposal'); owner.present = value; owner.requestHostUpdate(); }
  void emit(String name, [Object? payload]) { check(); owner.emit(name, payload); }
}
class NativeFrame<P> {
  NativeFrame(this.owner, this.child);
  final NativeOwner<P> owner;
  final Widget? child;
  bool active = true, slotUsed = false;
  void check() { owner.ensureAlive(); if (!active) throw StateError('Renderer handle is stale'); }
  P get props { check(); return owner.props; }
  Map<String, Object?> get rawProps { check(); return owner.rawProps; }
  bool isProvided(String key) { check(); return owner.rawProps.containsKey(key); }
  NativeContextScope get context { check(); return owner.context; }
  Widget slot() { check(); if (slotUsed) throw StateError('Only one anonymous supplied-child slot is allowed'); slotUsed = true; return _NativeSlot(owner: owner); }
  Widget el(String tag, [Object? a, Object? b]) {
    check();
    final hasProps = a is Map<String, Object?>;
    final children = nativeChildList(hasProps ? b : a);
    final style = hasProps ? a['style'] as NativeStyleHandle? : null;
    return NativeElement(owner, tag, children, style?.tokens ?? const []);
  }
}
class NativeElement extends StatelessWidget {
  const NativeElement(this.owner, this.tag, this.children, this.tokens, {super.key});
  final NativeOwner<Object?> owner;
  final String tag;
  final List<Widget> children;
  final List<String> tokens;
  @override Widget build(BuildContext context) {
    bool horizontal = tag.toLowerCase() == 'row';
    bool flex = tag.toLowerCase() == 'row' || tag.toLowerCase() == 'column';
    CrossAxisAlignment cross = CrossAxisAlignment.start;
    MainAxisAlignment main = MainAxisAlignment.start;
    double gap = 0;
    for (final token in tokens) {
      if (token == 'flex' || token == 'inline-flex') { flex = true; horizontal = true; }
      if (token == 'flex-col') { flex = true; horizontal = false; }
      if (token == 'flex-row') { flex = true; horizontal = true; }
      if (token == 'items-center') cross = CrossAxisAlignment.center;
      if (token == 'items-end') cross = CrossAxisAlignment.end;
      if (token == 'items-stretch') cross = CrossAxisAlignment.stretch;
      if (token == 'justify-center') main = MainAxisAlignment.center;
      if (token == 'justify-end') main = MainAxisAlignment.end;
      if (token == 'justify-between') main = MainAxisAlignment.spaceBetween;
      if (token == 'justify-around') main = MainAxisAlignment.spaceAround;
      if (token == 'justify-evenly') main = MainAxisAlignment.spaceEvenly;
      if (token.startsWith('gap-')) { final amount = double.tryParse(token.substring(4)); if (amount == null) throw ArgumentError('Unmapped Flutter gap: $token'); gap = amount * 4; }
    }
    final spaced = <Widget>[for (int index = 0; index < children.length; index++) ...[if (index != 0 && gap != 0) SizedBox(width: horizontal ? gap : null, height: horizontal ? null : gap), children[index]]];
    Widget layout;
    final kind = tag.toLowerCase();
    if (kind == 'input' || kind == 'textarea') {
      final control = owner.textControl;
      if (control == null) throw StateError('Native text Root requires asTextControl');
      control.multiline = kind == 'textarea'; layout = control.widget();
    } else if (kind == 'img' || kind == 'image') {
      final image = owner.imageView;
      if (image == null) throw StateError('Native image Root requires asImageView');
      layout = image.widget();
    } else if (kind == 'stack') layout = Stack(children: spaced);
    else if (flex) layout = Flex(direction: horizontal ? Axis.horizontal : Axis.vertical, mainAxisSize: MainAxisSize.min, mainAxisAlignment: main, crossAxisAlignment: cross, children: spaced);
    else if (['span','text','p','label','a','strong','em','small','code','li'].contains(kind)) layout = Wrap(children: spaced);
    else if (['column','div','section','root','button','main','ul','ol','nav','article','header','footer','aside','form','table','tbody','thead','tr','td','th','h1','h2','h3','h4','h5','h6'].contains(kind)) layout = Column(mainAxisSize: MainAxisSize.min, mainAxisAlignment: main, crossAxisAlignment: cross, children: spaced);
    else throw ArgumentError('No Flutter layout mapping for authored element: $tag');
    layout = nativeStyleWidget(layout, tokens, layoutApplied: true);
    if (tokens.contains('select-none')) layout = SelectionContainer.disabled(child: layout);
    if (tokens.contains('cursor-pointer')) layout = MouseRegion(cursor: SystemMouseCursors.click, child: layout);
    return layout;
  }
}
List<Widget> nativeChildList(Object? value) {
  if (value == null) return const [];
  if (value is Widget) return [value];
  if (value is String || value is num) return [Text(nativeString(value))];
  if (value is List<Object?>) return [for (final item in value) ...nativeChildList(item)];
  throw ArgumentError('Template child must be Widget, text, number, array or null');
}
Widget nativeChildren(Object? value) {
  final children = nativeChildList(value);
  if (children.isEmpty) return const SizedBox.shrink();
  return children.length == 1 ? children.single : Column(mainAxisSize: MainAxisSize.min, children: children);
}
class _NativeSlot extends StatelessWidget {
  const _NativeSlot({required this.owner});
  final NativeOwner<Object?> owner;
  @override Widget build(BuildContext context) => ValueListenableBuilder<Widget?>(valueListenable: owner.suppliedChild, builder: (_, child, __) => child ?? const SizedBox.shrink());
}
class _NativePhysicalRoot<P> extends StatefulWidget {
  const _NativePhysicalRoot({required this.owner, required this.version, required this.child});
  final NativeOwner<P> owner;
  final int version;
  final Widget child;
  @override State<_NativePhysicalRoot<P>> createState() => _NativePhysicalRootState<P>();
}
class _NativePhysicalRootState<P> extends State<_NativePhysicalRoot<P>> {
  void _schedule() { final version = widget.version; WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted) widget.owner._commit(version); }); }
  @override void initState() { super.initState(); _schedule(); }
  @override void didUpdateWidget(covariant _NativePhysicalRoot<P> oldWidget) { super.didUpdateWidget(oldWidget); _schedule(); }
  @override void activate() { super.activate(); _schedule(); }
  @override void deactivate() { widget.owner._physicalDetach(); super.deactivate(); }
  @override Widget build(BuildContext context) => widget.child;
}
class _PropWatch<P> {
  _PropWatch(this.keys, this.raw, this.callback);
  final List<String>? keys;
  final bool raw;
  final void Function(NativeRun<P>, Map<String, Object?>, Map<String, Object?>, Map<String, Object?>) callback;
  bool active = true;
}
class NativeOwner<P> implements NativeOwnerBase {
  final Map<String, Object?> _authoredResults = {};
  Object authoredHook(String name, void Function() install) {
    ensureSetup();
    if (_authoredResults.containsKey(name)) return _authoredResults[name] ?? Object();
    _authoredResults[name] = null;
    install();
    final result = Object();
    _authoredResults[name] = result;
    return result;
  }
  NativeOwner(this.invalidate, NativeContextScope? parent, {required this.makeProps, required this.checks}) {
    context = NativeContextScope(this, parent); style = NativeStyle(this); focus = NativeFocus(this); accessible = NativeAccessible(this);
    anatomy = NativeAnatomy(this); hostTarget = NativeHostTarget(rootKey, acceptsRead: () => ready); _liveOwners.add(this);
    FocusManager.instance.addEarlyKeyEventHandler(_earlyKey);
    GestureBinding.instance.pointerRouter.addGlobalRoute(_globalPointer);
    _typedProps = makeProps(_resolved);
  }
  final void Function() invalidate;
  final P Function(Map<String, Object?>) makeProps;
  final Map<String, bool Function(Object?)> checks;
  late final NativeContextScope context;
  late final NativeStyle style;
  late final NativeFocus focus;
  late final NativeAccessible accessible;
  late final NativeAnatomy anatomy;
  late final NativeHostTarget hostTarget;
  final GlobalKey rootKey = GlobalKey();
  static final Set<NativeOwner<Object?>> _liveOwners = {};
  static int _order = 0;
  final int logicalOrder = _order++;
  BuildContext? logicalContext;
  final Set<String> hookNames = {};
  NativeFocusEntry? focusEntry;
  NativeFocusScope? focusScope;
  NativeFocusRoving? focusRoving;
  NativeCollection? collection;
  NativeCollectionItem<P>? collectionItem;
  NativeBoundary<P>? boundary;
  NativeHitParticipation? hitParticipation;
  NativeOverlay? overlay;
  NativeScroll? scroll;
  NativeTextControl<P>? textControl;
  NativeImageView<P>? imageView;
  NativePositioning? positioning;
  NativeTableStructure? tableStructure;
  final Set<void Function()> _commitObservers = {};
  @override bool alive = true;
  @override bool disposing = false;
  bool setup = true, present = true, attached = true, dirty = true, queued = false, committed = false, trigger = false;
  @override bool get focusAvailable => hookNames.contains('asFocusable') || hookNames.contains('asFocusEntry') || hookNames.contains('asFocusScope') || trigger || textControl != null;
  bool _ready = false;
  @override bool get surfaceActive => alive && !disposing && attached && present && (context.parent?.owner.surfaceActive ?? true);
  @override bool get ready => _ready && surfaceActive;
  set ready(bool value) { _ready = value; }
  int epoch = 0, _ticket = 0, _renderVersion = 0, _committedVersion = -1;
  String? scope;
  late P _typedProps;
  P get props { ensureAlive(); return _typedProps; }
  Map<String, Object?> rawProps = const {}, _resolved = const {};
  final Map<String, Map<String, Object?>> _specs = {};
  final Map<String, Object?> _previousValid = {};
  final List<Map<String, Object?>> _defaults = [];
  final List<_PropWatch<P>> _watchers = [];
  final Map<String, List<void Function(NativeRun<P>)>> _life = {};
  final Map<String, NativeEventBase> _events = {};
  final Set<String> _exposeNames = {};
  final Map<String,Object?> _moduleExposes = {};
  Set<String> _semantics = {};
  final List<void Function()> _cleanups = [];
  final Queue<void Function()> _emissions = Queue();
  bool _emitting = false;
  final Map<String, List<_Listener>> _listeners = {};
  final Set<int> _pressedPointers = {};
  bool _keyboardPress = false;
  Widget? _projection;
  final ValueNotifier<Widget?> suppliedChild = ValueNotifier(null);
  Widget Function(NativeFrame<P>)? renderer;
  @override void ensureAlive() { if (!alive) throw StateError('Logical owner is terminally disposed'); }
  @override void ensureExternal() { ensureAlive(); if (disposing) throw StateError('Logical owner is disposing'); }
  @override void ensureSetup() { ensureAlive(); if (!setup) throw StateError('Setup-only authority is closed'); }
  @override void ensureRuntime() { ensureAlive(); if (setup || scope == null || scope == 'render' || disposing && scope != 'before-dispose' && scope != 'unmounted') throw StateError('Operation requires an owned callback'); }
  @override T inScope<T>(String origin, T Function() callback) { ensureAlive(); final previous = scope; scope = origin; try { return callback(); } finally { scope = previous; } }
  T invoke<T>(T Function(NativeRun<P>) callback) {
    ensureAlive(); bool active = true; final run = NativeRun<P>(this, () => active);
    try { return callback(run); } finally { active = false; }
  }
  @override void enqueue(void Function() callback) {
    _emissions.add(callback); if (_emitting) return; _emitting = true;
    Object? failure; StackTrace? trace;
    try { while (_emissions.isNotEmpty && alive) { try { _emissions.removeFirst()(); } catch (error, stack) { failure ??= error; trace ??= stack; } } } finally { _emitting = false; }
    if (failure != null) Error.throwWithStackTrace(failure, trace!);
  }
  bool _hostQueued = false, _hostTerminalRequested = false;
  void requestHostUpdate({bool terminal = false}) {
    _hostTerminalRequested = _hostTerminalRequested || terminal;
    if (_hostQueued) return;
    _hostQueued = true;
    scheduleMicrotask(() { _hostQueued = false; final terminal = _hostTerminalRequested; _hostTerminalRequested = false; if ((alive && !disposing || terminal) && attached) invalidate(); });
  }
  @override void project() { if (alive && !disposing && !setup) requestHostUpdate(); }
  NativeState<T> state<T>(String kind, String semantic, T initial, [Map<String, Object?> options = const {}]) {
    ensureSetup(); if (semantic.isEmpty || !_semantics.add(semantic)) throw ArgumentError('State semantic must be nonempty and unique in its frame');
    final handle = NativeState<T>(this, kind, semantic, initial, options);
    _cleanups.add(handle.subscribers.clear); return handle;
  }
  void Function() watchState<T>(NativeObserved<T> state, void Function(NativeRun<P>,NativeStateWatchEvent<T>) callback) {
    ensureSetup(); bool active = true;
    final source = state is _ExternalState<T> ? state.source : state as NativeState<T>;
    void observer(NativeStateChange<T> change) { if (active && alive && !setup && !disposing) inScope('state-watch',() => invoke((run) => callback(run,NativeStateWatchEvent.next(change.prev,change.next,change.reason)))); }
    source.subscribers.add(observer);
    void release() { if (!active) return; active = false; source.subscribers.remove(observer); }
    _cleanups.add(release);
    return () { ensureAlive(); release(); };
  }
  T withFrame<T>(T Function() callback) {
    ensureSetup(); final previous = _semantics; _semantics = {};
    try { return callback(); } finally { _semantics = previous; }
  }
  void declareExpose(String name) { ensureSetup(); if (!_exposeNames.add(name)) throw StateError('Duplicate expose: $name'); }
  Object? publicExposure(String name) { ensureAlive(); return _moduleExposes.containsKey(name) ? _moduleExposes[name] : _events[name]; }
  void moduleExpose(String name, Object? value) { declareExpose(name); _moduleExposes[name] = value; }
  T install<T>(String name, T Function() create) { ensureSetup(); hookNames.add(name); return create(); }
  NativeTableStructure declareTableStructure(String role) { ensureSetup(); final current = tableStructure; if (current != null && current.role != role) throw StateError('Table role already declared'); return tableStructure ??= NativeTableStructure(this,role); }
  void declareTextControl(bool multiline) { ensureSetup(); if (textControl != null) throw StateError('Duplicate static TextControl declaration'); textControl = NativeTextControl<P>(this)..multiline = multiline; }
  void declareImageView(Map<String, Object?> config) { ensureSetup(); if (imageView != null) throw StateError('Duplicate static ImageView declaration'); final module = NativeImageView<P>(this); module.config = Map.unmodifiable(config); module.source = config['source'] as String; imageView = module; }
  void Function() onCommit(void Function() callback) { ensureSetup(); _commitObservers.add(callback); return () { _commitObservers.remove(callback); }; }
  void declareEvent<T>(String name, bool Function(Object?) accepts) { declareExpose(name); _events[name] = NativeEvent<T>(this, accepts); }
  NativeEvent<T> event<T>(String name) { ensureExternal(); final event = _events[name]; if (event == null) throw StateError('Undeclared event'); return event as NativeEvent<T>; }
  void emit(String name, Object? value) { ensureRuntime(); final event = _events[name]; if (event == null) throw StateError('Undeclared event'); event.emit(value); }
  void on(String phase, void Function(NativeRun<P>) callback) { ensureSetup(); _life.putIfAbsent(phase, () => []).add(callback); }
  void _fire(String phase) {
    Object? failure; StackTrace? trace;
    final origin = phase == 'beforeDispose' ? 'before-dispose' : phase;
    if (phase == 'unmounted') { overlay?.detached(); tableStructure?.clear(); scheduleMicrotask(() { if (!alive) return; NativeTableStructure.refreshAll(); for (final participant in List.of(_liveOwners)) { if (participant.ready) { for (final observer in List.of(participant._commitObservers)) observer(); } } }); }
    for (final callback in List.of(_life[phase] ?? <void Function(NativeRun<P>)>[])) { try { inScope(origin, () => invoke(callback)); } catch (error, stack) { failure ??= error; trace ??= stack; } }
    if (failure != null) Error.throwWithStackTrace(failure, trace!);
  }
  void defineProps(Map<String, Object?> declarations) {
    ensureSetup();
    final merged = <String, Map<String, Object?>>{..._specs};
    for (final entry in declarations.entries) {
      if (!checks.containsKey(entry.key)) throw ArgumentError('Unknown prop declaration');
      final value = entry.value as Map<String, Object?>;
      final previous = merged[entry.key];
      if (previous != null && previous['type'] != value['type']) throw ArgumentError('Conflicting prop types');
      final priorRange = previous?['range'] as Map<String, Object?>?;
      final range = value['range'] as Map<String, Object?>?;
      if (priorRange != null && range != null && ((range['min'] as num? ?? double.negativeInfinity) > (priorRange['min'] as num? ?? double.negativeInfinity) || (range['max'] as num? ?? double.infinity) < (priorRange['max'] as num? ?? double.infinity))) throw ArgumentError('Conflicting prop ranges');
      int rank(Object? policy) => policy == 'accept' ? 0 : policy == 'error' ? 2 : 1;
      if (previous != null && value.containsKey('empty') && rank(value['empty']) > rank(previous['empty'])) throw ArgumentError('Conflicting prop empty policy');
      merged[entry.key] = {...?previous, ...value, 'empty': previous?['empty'] ?? value['empty'] ?? 'fallback', if (previous != null && previous.containsKey('default')) 'default': previous['default']};
    }
    _specs.clear(); _specs.addAll(merged); _resolved = _resolve(false); _typedProps = makeProps(_resolved);
  }
  void setDefaults(Map<String, Object?> values) { ensureSetup(); for (final key in values.keys) { if (!_specs.containsKey(key)) throw ArgumentError('Undeclared prop default'); } _defaults.insert(0, Map.unmodifiable(values)); _resolved = _resolve(false); _typedProps = makeProps(_resolved); }
  bool _valid(String name, Object? value) {
    if (checks[name]?.call(value) != true) return false;
    final spec = _specs[name]!;
    final options = spec['options']; if (options is List<Object?> && !options.contains(value)) return false;
    final range = spec['range'];
    if (range is Map<String, Object?> && value is num && (value < (range['min'] as num? ?? double.negativeInfinity) || value > (range['max'] as num? ?? double.infinity))) return false;
    return true;
  }
  Map<String, Object?> _resolve(bool strict) {
    final next = <String, Object?>{};
    for (final entry in _specs.entries) {
      final name = entry.key, spec = entry.value;
      final provided = rawProps.containsKey(name), raw = rawProps[name];
      if (provided && raw != null && _valid(name, raw)) { final value = raw is num ? raw.toDouble() : raw; next[name] = value; _previousValid[name] = value; continue; }
      if (provided && raw == null && spec['empty'] == 'accept') { next[name] = null; continue; }
      bool found = false; Object? fallback;
      if (provided && _previousValid.containsKey(name) && _valid(name, _previousValid[name])) { fallback = _previousValid[name]; found = true; }
      final layers = [..._defaults, if (spec.containsKey('default')) <String, Object?>{name: spec['default']}];
      if (!found) { for (final layer in layers) { if (!layer.containsKey(name)) continue; final value = layer[name]; if (value == null && (!strict || spec['empty'] != 'error') || value != null && _valid(name, value)) { fallback = value; found = true; break; } } }
      if (!found && strict && spec['empty'] == 'error') throw ArgumentError('Prop has no valid fallback: $name');
      next[name] = fallback;
      if (provided && fallback != null) _previousValid[name] = fallback;
    }
    return Map.unmodifiable(next);
  }
  void Function() watch(List<String>? keys, bool raw, void Function(NativeRun<P>, Map<String, Object?>, Map<String, Object?>, Map<String, Object?>) callback) {
    ensureSetup(); final watcher = _PropWatch<P>(keys == null ? null : List.unmodifiable(keys), raw, callback); _watchers.add(watcher); return () { ensureAlive(); watcher.active = false; };
  }
  bool _hydrated = false;
  void applyProps(Map<String, Object?> next) {
    ensureExternal(); final previous = _resolved, previousRaw = rawProps;
    final incoming = Map<String,Object?>.unmodifiable(next);
    final priorValid = Map<String,Object?>.of(_previousValid);
    rawProps = incoming;
    try { _resolved = _resolve(true); }
    catch (error, stack) { rawProps = previousRaw; _previousValid.clear(); _previousValid.addAll(priorValid); Error.throwWithStackTrace(error, stack); }
    _typedProps = makeProps(_resolved); project();
    if (!_hydrated) { _hydrated = true; return; }
    final changed = <String>[for (final key in _specs.keys) if (!nativeIdentitySame(previous[key], _resolved[key])) key];
    final rawKeys = {...previousRaw.keys, ...rawProps.keys};
    final rawChanged = <String>[for (final key in rawKeys) if (previousRaw.containsKey(key) != rawProps.containsKey(key) || !nativeIdentitySame(previousRaw[key], rawProps[key])) key];
    final snapshot = _resolved, rawSnapshot = rawProps;
    for (final watcher in List.of(_watchers)) {
      final all = watcher.raw ? rawChanged : changed;
      final matched = watcher.keys == null ? all : all.where(watcher.keys!.contains).toList();
      if (!watcher.active || matched.isEmpty) continue;
      final info = <String, Object?>{'changedKeysAll': List<String>.unmodifiable(all), 'changedKeysMatched': List<String>.unmodifiable(matched)};
      inScope('props-watch', () => invoke((run) => watcher.callback(run, watcher.raw ? rawSnapshot : snapshot, watcher.raw ? previousRaw : previous, info)));
    }
  }
  void finishSetup(Map<String, Object?> initial) { applyProps(initial); setup = false; if (overlay != null && !overlay!.retained && overlay!.presence == null) present = overlay!.isOpen(); _fire('created'); }
  void requestUpdate() { ensureExternal(); dirty = true; if (queued || !attached || !present) return; queued = true; final ticket = ++_ticket; scheduleMicrotask(() { if (!alive || disposing || ticket != _ticket) return; queued = false; if (attached && present) invalidate(); }); }
  void externalPresent(bool value) { ensureExternal(); present = value; requestHostUpdate(); }
  void deactivate() { if (!alive) return; attached = false; ready = false; _ticket++; queued = false; scheduleMicrotask(() { if (alive && !attached) _detach(); }); }
  void activate() { if (!alive) return; attached = true; requestHostUpdate(); }
  Widget build(Widget? child) {
    if (!alive || disposing) return const SizedBox.shrink();
    suppliedChild.value = child;
    final visible = surfaceActive;
    if (!visible) {
      ready = false;
      final ticket = _ticket;
      WidgetsBinding.instance.addPostFrameCallback((_) { if (alive && !disposing && !surfaceActive && ticket == _ticket) { if (committed) { committed = false; epoch++; imageView?.unmount(); scroll?.unmount(); focus.node.unfocus(); _fire('unmounted'); } dirty = true; } });
      if (_projection == null) return NativeContextHost(scope: context, active: false, child: const SizedBox.shrink());
    }
    if (visible && (_projection == null || dirty)) {
      final frame = NativeFrame<P>(this, child);
      try { _projection = inScope('render', () => renderer?.call(frame) ?? const SizedBox.shrink()); }
      finally { frame.active = false; }
      dirty = false; _renderVersion++;
    }
    Widget root = _projection!;
    if (textControl != null && root is! NativeElement) root = textControl!.widget();
    if (imageView != null && root is! NativeElement) root = imageView!.widget();
    if (root is! NativeElement) root = NativeElement(this, 'root', [root], const []);
    root = nativeStyleWidget(root, style.tokens());
    if (scroll != null) root = scroll!.wrap(root);
    root = accessible.wrap(root);
    root = Focus(focusNode: textControl == null ? focus.node : null, canRequestFocus: visible && focusAvailable && !focus.disabled, skipTraversal: !visible || !focusAvailable || !focus.nav, descendantsAreFocusable: visible, descendantsAreTraversable: visible, child: root);
    if (focusRoving != null) root = focusRoving!.wrap(root);
    if (focusScope != null) root = focusScope!.wrap(root);
    root = MouseRegion(onEnter: (event) => dispatch(NativeInput('pointer.enter', pointer: event.pointer)), onExit: (event) => dispatch(NativeInput('pointer.leave', pointer: event.pointer)), child: root);
    root = Listener(behavior: HitTestBehavior.translucent, onPointerDown: _pointerDown, onPointerMove: _pointerMove, onPointerUp: _pointerUp, onPointerCancel: _pointerCancel, child: root);
    root = KeyedSubtree(key: rootKey, child: root);
    root = NativeHostRegion(target: hostTarget, ownsKey: false, child: root);
    root = _NativePhysicalRoot<P>(owner: this, version: _renderVersion, child: root);
    if (overlay != null) root = overlay!.wrap(root);
    return NativeContextHost(scope: context, active: visible, child: Offstage(offstage: !visible, child: root));
  }
  void _commit(int version) {
    if (!alive || disposing || !surfaceActive || version != _renderVersion || hostTarget.physicalBox == null) return;
    ready = true;
    focus.refresh(); scroll?.mount();
    final updated = _committedVersion != version; _committedVersion = version;
    if (!committed) { committed = true; epoch++; imageView?.mount(); _fire('mounted'); if (focus.autoFocus && !focus.disabled) focus.node.requestFocus(); }
    else if (updated) _fire('updated');
    for (final owner in List.of(_liveOwners)) { if (owner.alive && owner.ready) { for (final observer in List.of(owner._commitObservers)) observer(); } }
    NativeTableStructure.refreshAll();
  }
  void _physicalDetach() {
    if (!alive || disposing) return;
    ready = false;
    scheduleMicrotask(() { if (!alive || disposing || hostTarget.physicalBox != null) return; if (committed) { committed = false; epoch++; imageView?.unmount(); scroll?.unmount(); _fire('unmounted'); } });
  }
  void _detach() {
    ready = false; _ticket++; queued = false; _pressedPointers.clear(); _keyboardPress = false;
    if (committed) { committed = false; epoch++; imageView?.unmount(); scroll?.unmount(); focus.node.unfocus(); _fire('unmounted'); }
    _projection = null; dirty = true;
  }
  void asTrigger() { ensureSetup(); hookNames.add('asTrigger'); trigger = true; }
  void Function() listen(String type, void Function(NativeRun<P>, NativeInput) callback, {bool global = false, Map<String, Object?> options = const {}}) {
    ensureSetup();
    final entry = _Listener((event) => inScope('event', () => invoke((run) => callback(run, event))), global, options['once'] == true, options['passive'] == true);
    _listeners.putIfAbsent(type, () => []).add(entry); return () { ensureAlive(); entry.active = false; };
  }
  @override void dispatch(NativeInput event, {bool globalOnly = false}) {
    if (!alive || disposing || !ready || !present || !attached) return;
    final hostNames = <String, String>{'key.down': 'keydown', 'key.up': 'keyup', 'pointer.down': 'pointerdown', 'pointer.move': 'pointermove', 'pointer.up': 'pointerup', 'pointer.cancel': 'pointercancel', 'pointer.enter': 'pointerenter', 'pointer.leave': 'pointerleave', 'nav.focus': 'focus', 'nav.blur': 'blur', 'input': 'input', 'change': 'change'};
    final hostName = hostNames[event.type];
    final routes = <(String, NativeInput)>[(event.type, event), if (hostName != null) ('host:$hostName', NativeInput(hostName, key: event.key, ctrlKey: event.ctrlKey, altKey: event.altKey, metaKey: event.metaKey, shiftKey: event.shiftKey, repeat: event.repeat, pointer: event.pointer, globalPosition: event.globalPosition, localPosition: event.localPosition, keyboardEvent: event.keyboardEvent, pointerEvent: event.pointerEvent))];
    try { for (final route in routes) {
      final input = route.$2;
      try { for (final entry in List.of(_listeners[route.$1] ?? <_Listener>[])) {
        if (!alive || disposing || !ready || !present) break;
        if (!entry.active || globalOnly && !entry.global || !globalOnly && entry.global) continue;
        input._passive = entry.passive; if (entry.once) entry.active = false; entry.callback(input);
      } } finally { input._active = false; event.defaultPrevented = event.defaultPrevented || input.defaultPrevented; }
    } }
    finally { event._active = false; event._passive = false; }
  }
  @override void semanticAction(String type) { dispatch(NativeInput(type)); }
  NativeInput _pointerEvent(String type, PointerEvent event) => NativeInput(type, pointer: event.pointer, globalPosition: event.position, localPosition: event.localPosition, pointerEvent: event);
  void _pointerDown(PointerDownEvent event) { final input = _pointerEvent('pointer.down', event); dispatch(input); if (input.defaultPrevented) return; if (trigger && !focus.disabled && event.buttons == kPrimaryButton) { final start = _pointerEvent('press.start', event); dispatch(start); if (start.defaultPrevented) return; _pressedPointers.add(event.pointer); if (focusAvailable) focus.node.requestFocus(); } if (ready) hostTarget.pointerRoute?.call(event); }
  void _pointerMove(PointerMoveEvent event) { dispatch(_pointerEvent('pointer.move', event)); }
  void _pointerUp(PointerUpEvent event) { final input = _pointerEvent('pointer.up', event); dispatch(input); if (_pressedPointers.remove(event.pointer)) { dispatch(_pointerEvent('press.end', event)); if (!input.defaultPrevented && !focus.disabled) dispatch(_pointerEvent('press.commit', event)); } }
  void _pointerCancel(PointerCancelEvent event) { dispatch(_pointerEvent('pointer.cancel', event)); if (_pressedPointers.remove(event.pointer)) dispatch(_pointerEvent('press.cancel', event)); }
  NativeInput _keyEvent(KeyEvent event) => NativeInput(event is KeyUpEvent ? 'key.up' : 'key.down', key: event.logicalKey == LogicalKeyboardKey.space ? ' ' : event.logicalKey.keyLabel, ctrlKey: HardwareKeyboard.instance.isControlPressed, altKey: HardwareKeyboard.instance.isAltPressed, metaKey: HardwareKeyboard.instance.isMetaPressed, shiftKey: HardwareKeyboard.instance.isShiftPressed, repeat: event is KeyRepeatEvent, keyboardEvent: event);
  KeyEventResult _key(KeyEvent event, NativeInput input) {
    input._active = true; dispatch(input);
    if (trigger && !focus.disabled && !input.defaultPrevented && (event.logicalKey == LogicalKeyboardKey.space || event.logicalKey == LogicalKeyboardKey.enter)) {
      if (event is KeyDownEvent && !_keyboardPress) { _keyboardPress = true; dispatch(NativeInput('press.start', key: input.key)); }
      if (event is KeyUpEvent && _keyboardPress) { _keyboardPress = false; dispatch(NativeInput('press.end', key: input.key)); dispatch(NativeInput('press.commit', key: input.key)); }
    }
    return input.defaultPrevented ? KeyEventResult.handled : KeyEventResult.ignored;
  }
  KeyEventResult _earlyKey(KeyEvent event) { final input = _keyEvent(event); dispatch(input, globalOnly: true); if (overlay?.key(event) == true) return KeyEventResult.handled; if (focus.node.hasFocus) return _key(event, input); return input.defaultPrevented ? KeyEventResult.handled : KeyEventResult.ignored; }
  void _globalPointer(PointerEvent event) { if (event is PointerDownEvent) { boundary?.pointer(event); overlay?.pointer(event); } final type = event is PointerDownEvent ? 'pointer.down' : event is PointerUpEvent ? 'pointer.up' : event is PointerMoveEvent ? 'pointer.move' : event is PointerCancelEvent ? 'pointer.cancel' : null; if (type != null) dispatch(_pointerEvent(type, event), globalOnly: true); }
  void close() {
    if (!alive || disposing) return; disposing = true;
    Object? failure; StackTrace? trace;
    try { _detach(); } catch (error, stack) { failure = error; trace = stack; }
    try { _fire('beforeDispose'); } catch (error, stack) { failure ??= error; trace ??= stack; }
    finally {
      alive = false; ready = false; epoch++; _ticket++;
      FocusManager.instance.removeEarlyKeyEventHandler(_earlyKey); GestureBinding.instance.pointerRouter.removeGlobalRoute(_globalPointer);
      final resources = <void Function()>[focus.dispose, if (focusScope != null) focusScope!.dispose, if (focusRoving != null) focusRoving!.dispose, context.dispose, style.dispose, anatomy.dispose, if (boundary != null) boundary!.dispose, if (hitParticipation != null) hitParticipation!.dispose, if (overlay != null) overlay!.dispose, if (scroll != null) scroll!.dispose, if (textControl != null) textControl!.dispose, if (imageView != null) imageView!.dispose, if (positioning != null) positioning!.dispose, if (tableStructure != null) tableStructure!.states.dispose, if (collection != null) collection!.dispose, if (collectionItem != null) collectionItem!.dispose, hostTarget.dispose, ..._cleanups, ..._events.values.map((event) => event.clear), suppliedChild.dispose];
      for (final release in resources) { try { release(); } catch (error, stack) { failure ??= error; trace ??= stack; } }
      _liveOwners.remove(this); _commitObservers.clear();
      _events.clear(); _moduleExposes.clear(); _life.clear(); _watchers.clear(); _listeners.clear(); _emissions.clear(); _cleanups.clear(); _projection = null; renderer = null;
    }
    if (failure != null) Error.throwWithStackTrace(failure, trace!);
  }
}

Widget nativeStyleWidget(Widget child, List<String> tokens, {bool layoutApplied = false}) {
  if (child is NativeElement) return NativeElement(child.owner, child.tag, child.children, [...child.tokens, ...tokens], key: child.key);
  Color? background, foreground;
  EdgeInsets padding = EdgeInsets.zero;
  double? width, height, opacity, radius;
  FontWeight? weight;
  double? fontSize;
  bool hidden = false;
  final colors = <String, Color>{'black': const Color(0xff000000), 'white': const Color(0xffffffff), 'transparent': const Color(0x00000000), 'red-500': const Color(0xffef4444), 'blue-500': const Color(0xff3b82f6), 'blue-600': const Color(0xff2563eb), 'green-500': const Color(0xff22c55e), 'gray-100': const Color(0xfff3f4f6), 'gray-500': const Color(0xff6b7280), 'gray-900': const Color(0xff111827)};
  double? scale(String value) { if (value == 'px') return 1; return double.tryParse(value)?.toDouble() == null ? null : double.parse(value) * 4; }
  for (final token in tokens) {
    if (token == 'hidden') { hidden = true; continue; }
    if (token.startsWith('bg-')) { background = colors[token.substring(3)]; if (background == null) throw ArgumentError('Unmapped Flutter color: $token'); continue; }
    if (token.startsWith('text-')) {
      const sizes = <String, double>{'xs': 12, 'sm': 14, 'base': 16, 'lg': 18, 'xl': 20, '2xl': 24};
      final value = token.substring(5); if (sizes.containsKey(value)) fontSize = sizes[value]; else { foreground = colors[value]; if (foreground == null) throw ArgumentError('Unmapped Flutter text style: $token'); } continue;
    }
    if (token == 'font-bold') { weight = FontWeight.bold; continue; }
    if (token == 'font-normal') { weight = FontWeight.normal; continue; }
    if (token.startsWith('opacity-')) { opacity = double.parse(token.substring(8)) / 100; continue; }
    if (token.startsWith('p-')) { final value = scale(token.substring(2)); if (value == null) throw ArgumentError('Unmapped Flutter spacing: $token'); padding = EdgeInsets.all(value); continue; }
    if (token.startsWith('px-')) { final value = scale(token.substring(3)); if (value == null) throw ArgumentError('Unmapped Flutter spacing'); padding = padding.copyWith(left: value, right: value); continue; }
    if (token.startsWith('py-')) { final value = scale(token.substring(3)); if (value == null) throw ArgumentError('Unmapped Flutter spacing'); padding = padding.copyWith(top: value, bottom: value); continue; }
    if (token.startsWith('w-')) { width = token == 'w-full' ? double.infinity : scale(token.substring(2)); if (width == null) throw ArgumentError('Unmapped Flutter width'); continue; }
    if (token.startsWith('h-')) { height = token == 'h-full' ? double.infinity : scale(token.substring(2)); if (height == null) throw ArgumentError('Unmapped Flutter height'); continue; }
    if (token == 'rounded' || token.startsWith('rounded-')) { radius = token == 'rounded' ? 4 : token == 'rounded-full' ? 999 : token == 'rounded-lg' ? 8 : token == 'rounded-md' ? 6 : token == 'rounded-sm' ? 2 : token == 'rounded-none' ? 0 : null; if (radius == null) throw ArgumentError('Unmapped Flutter radius'); continue; }
    if (layoutApplied && (token.startsWith('items-') || token.startsWith('justify-') || token.startsWith('gap-') || ['flex','flex-row','flex-col','inline-flex','block','inline-block','cursor-pointer','select-none'].contains(token))) continue;
    if (token == 'outline-none') continue;
    throw ArgumentError('No Flutter style mapping for token: $token');
  }
  Widget result = DefaultTextStyle.merge(style: TextStyle(color: foreground, fontWeight: weight, fontSize: fontSize), child: child);
  result = Container(width: width, height: height, padding: padding, decoration: background != null || radius != null ? BoxDecoration(color: background, borderRadius: radius == null ? null : BorderRadius.circular(radius)) : null, child: result);
  if (opacity != null) result = Opacity(opacity: opacity.clamp(0, 1).toDouble(), child: result);
  if (hidden) result = Offstage(offstage: true, child: result);
  return result;
}
