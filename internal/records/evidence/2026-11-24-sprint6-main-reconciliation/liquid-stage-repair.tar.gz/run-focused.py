from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys

ROOT = Path('/workspace/scratch/466206816961/proto-ui-s6')
EVIDENCE = Path('/workspace/scratch/466206816961/s6-evidence/liquid-stage-repair')
label, *files = sys.argv[1:]
baseline = json.loads((EVIDENCE / 'baseline.json').read_text())
inputs = sorted(set(baseline['sourceHashes']) | set(files))


def snapshot():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in inputs}


before = snapshot()
command = [
    'corepack', 'pnpm@10.32.1', 'exec', 'vitest', 'run', *files,
    '--maxWorkers=1', '--minWorkers=1', '--no-file-parallelism',
    '--reporter=default', '--reporter=json', f'--outputFile={EVIDENCE / (label + ".json")}',
]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
timed_out = False
with (EVIDENCE / (label + '.log')).open('wb') as log:
    child = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        code = child.wait(timeout=180)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(child.pid, signal.SIGTERM)
        try:
            child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait()
        code = 124
after = snapshot()
receipt = {
    'label': label, 'baseHead': baseline['baseHead'], 'command': command,
    'cwd': str(ROOT), 'startedAt': started,
    'endedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exitCode': code, 'externalTimeoutSeconds': 180, 'timedOut': timed_out,
    'originalTestDeadlinesUnchanged': True,
    'selectedFiles': files, 'sourceBefore': before, 'sourceAfter': after,
    'sourceInputsUnchanged': before == after,
}
report_path = EVIDENCE / (label + '.json')
if report_path.exists():
    report = json.loads(report_path.read_text())
    receipt['counts'] = {key: report[key] for key in [
        'numTotalTests', 'numPassedTests', 'numFailedTests', 'numPendingTests', 'numTodoTests',
    ]}
    receipt['executedFiles'] = [
        {'path': str(Path(suite['name']).relative_to(ROOT)),
         'cases': len(suite['assertionResults']), 'status': suite['status']}
        for suite in report['testResults']
    ]
    receipt['reportSha256'] = hashlib.sha256(report_path.read_bytes()).hexdigest()
receipt['logSha256'] = hashlib.sha256((EVIDENCE / (label + '.log')).read_bytes()).hexdigest()
(EVIDENCE / (label + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: receipt[key] for key in [
    'label', 'exitCode', 'timedOut', 'sourceInputsUnchanged',
]} | {'counts': receipt.get('counts'), 'executedFiles': receipt.get('executedFiles')}, indent=2))
sys.exit(code)
