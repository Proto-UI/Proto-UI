# Sprint 6 exact 041 canonical public package evidence

[Bootstrap run 45365822387](https://github.com/Proto-UI/Proto-UI/actions/runs/45365822387) measured `041277b4ec781e0ce737edeaf6911c5a15f9e9b8`. PR head was rechecked as the same commit at 2026-11-24T09:37:50.743Z; base is `88fc0883bec70abbc0d7505d88370657c279639e`.

## Completed public package results

- Public packages build job 138347165668: all 47 public packages built and 47 manifests passed. Budget controls passed 28/28 and execution controls 10/10. Only strict-budgets returned exit 1; its stderr is empty.
- React consumer job 138347165669: passed, 42/47 packed packages consumed; source before/after stayed clean at 041.
- CLI consumer job 138347165622: passed, 44/47 packed packages consumed, including a successful Vue2 consumer receipt; source before/after stayed clean at 041.
- Five of nine whole-entry budgets fail. This is valid exact-candidate cost evidence; it does not mark the whole workflow accepted. Workspace types have a separate failure and browser evidence was still running at the observation.

## Gzip bytes

| Entry | b939 canonical | 92 canonical | 041 canonical | Current ceiling | 041 excess |
|---|---:|---:|---:|---:|---:|
| lucide/icons/x | 1797 | 1797 | 1797 | 3000 | 0 |
| lucide root | 635917 | 635846 | 635846 | 700000 | 0 |
| core root | 12710 | 12967 | 12967 | 12800 | 167 |
| runtime root | 104125 | 106822 | 106822 | 104300 | 2522 |
| adapter-react root | 173379 | 179930 | 179944 | 173380 | 6564 |
| adapter-vue root | 172258 | 178711 | 178760 | 172180 | 6580 |
| adapter-web-component root | 208711 | 216228 | 216252 | 208740 | 7512 |
| prototypes-base/button | 4308 | 4311 | 4311 | 6000 | 0 |
| prototypes-shadcn/button | 6743 | 6739 | 6739 | 7900 | 0 |

Vue inherits 78 B of prior excess. Its new gzip delta against b939 is 6502 B, and total excess is 6580 B. Node v24.22.3, esbuild 0.25.12, zlib 1.3.2.1-motley-285e94b, platform and all measurement parameters are identical across reports.

## Attribution

All nine input path sets match 92. Six minified artifact hashes match. React/Vue/WC add 14/49/24 gzip bytes respectively. Their changed projector retains +114/+105/+110 minified bytes before gzip; these are attribution bytes, not additive gzip costs. Runtime reaches the changed projector with zero retained bytes and has the same output hash.

Against b939, the dominant closures are material paint reservation, resident motion width/numeric sources, presence top/channel sampling and restoration. WC also includes the portal-conceal ownership repair. No duplicate Runtime, dist or node_modules copy appeared; all Runtime-bearing entries still have the same 29 Runtime source paths. No Bootstrap/Liquid prototype, demo or test entered the five failing roots.

## Candidate boundary

Source tree: `4bc695e9399dd6d3607b4b2b3e3bf44d66d8e814`. Source fingerprint: `46d7bfcd4d5061196e722a989dc16d06d48546bfeb071f4c80278c6e74a84e25`. Clean, exact-head, matching source and stable-during-measurement checks all passed. No ceiling was chosen or changed by this report. Independent source/type and browser checks remain with root. A later source or numeric successor requires its own final exact-head result, preserving existing parallel contributions.

## Original artifacts

| Group | Artifact ID | ZIP SHA-256 |
|---|---:|---|
| build | 14906683210 | `432680e32280c842dadc1b031196c5d089fa12fd50023a19a1f8629e2864f6f3` |
| react | 14906752202 | `4f46801461a863c91fdd4bccbb0f0f140bd2326bd93d5cf59f93e4d87e920547` |
| cli | 14907146140 | `8a62a87afef2d304163771a8e3d2dc4fbdc172a93168beb70d367661a93ab46d` |

All ZIP SHA-256 values match GitHub metadata and all CRC checks passed. Each extracted member has a separate hash in its retained member manifest.

Raw package report: `/workspace/scratch/466206816961/s6-evidence/canonical-041-public-build/package-budgets.json`; SHA-256 `5057530f47d74d1eecb7769a1b72beaa72aa0e0346116a7196f7cf559b2b132a`.

Full comparison: `/workspace/scratch/466206816961/s6-evidence/canonical-041-package-budget-attribution.json`.
