import { writeFileSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const { BOOTSTRAP_MOTION_SUITES, PORTAL_REENTRY_TITLE, SPLIT_REJECTION_TITLE, inspectBootstrapMotionReport } = await import(pathToFileURL(path.resolve('scripts/test/check-bootstrap-motion-evidence.mjs')));
const currentCounts = new Map([
  ['packages/modules/feedback/test/presence-top-projector.test.ts', 18],
  ['packages/adapters/base/test/web-presence-top.test.ts', 17],
]);
const root = '/synthetic-current-motion-inventory';
const suites = BOOTSTRAP_MOTION_SUITES.map((suite) => ({ ...suite, cases: currentCounts.get(suite.file) ?? suite.cases }));
const total = suites.reduce((sum, suite) => sum + suite.cases, 0);
const report = {
  success: true, numTotalTests: total, numPassedTests: total, numFailedTests: 0,
  numTotalTestSuites: 29, numPassedTestSuites: 29, numFailedTestSuites: 0,
  numPendingTestSuites: 0, numPendingTests: 0, numTodoTests: 0,
  testResults: suites.map(({ file, cases }) => ({
    name: path.join(root, file), status: 'passed',
    assertionResults: Array.from({ length: cases }, (_, index) => ({
      title: file.endsWith('progress-width-motion.browser.test.ts') && index === cases - 1
        ? SPLIT_REJECTION_TITLE
        : file.endsWith('portal-conceal.test.ts') && index === cases - 1
          ? PORTAL_REENTRY_TITLE : `synthetic case ${index}`,
      fullName: `${file} synthetic case ${index}`, status: 'passed',
    })),
  })),
};
const result = await inspectBootstrapMotionReport(report, { root, stepOutcome: 'success' });
const evidence = { fixture: 'synthetic inventory only; not browser or physical-motion execution', suites, total, result };
writeFileSync(process.argv[2], JSON.stringify(evidence, null, 2) + '\n');
console.log(JSON.stringify({ total, expectedByChecker: result.requiredAssertions, passed: result.passed, failures: result.failures }, null, 2));
process.exitCode = result.passed ? 0 : 1;
