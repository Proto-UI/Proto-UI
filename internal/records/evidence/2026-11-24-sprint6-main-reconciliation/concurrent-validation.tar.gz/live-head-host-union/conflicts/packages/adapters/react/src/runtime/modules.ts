<<<<<<< HEAD
import type { WebShaderHostOptions } from '@proto.ui/adapter-base';
import { MATERIAL_PAINT_RESERVATION_CAP } from '@proto.ui/module-feedback';
=======
import { MATERIAL_PAINT_RESERVATION_CAP } from '@proto.ui/module-feedback';
import type { WebShaderHostOptions } from '@proto.ui/adapter-base';
>>>>>>> ffc8ba6bea65975cb4ee552a965966ad24cf820c
import { createWebPresencePresentationSink } from '@proto.ui/adapter-base';
import { createWebShaderPresentationSink } from '@proto.ui/adapter-base';
import { SHADER_PRESENTATION_SINK_CAP } from '@proto.ui/module-feedback';
import {
  PRESENCE_PRESENTATION_SINK_CAP,
  PRESENCE_RUN_IN_CALLBACK_CAP,
} from '@proto.ui/module-feedback';
import { createWebResidentMotionSink, type WebResidentMotionOptions } from '@proto.ui/adapter-base';
import { OWNED_DECORATION_CAP, RESIDENT_MOTION_SINK_CAP } from '@proto.ui/module-feedback';
import {
  NATIVE_LINK_HOST_CAP,
  NATIVE_LINK_RUN_IN_CALLBACK_CAP,
  createWebNativeLinkHost,
} from '@proto.ui/module-native-link';
import { AXIS_INPUT_HOST_CAP, AXIS_INPUT_RUN_IN_CALLBACK_CAP } from '@proto.ui/module-axis-input';
import { createWebAxisInputHost } from '@proto.ui/adapter-base';
import {
  CONTROL_LABEL_HOST_CAP,
  CONTROL_LABEL_RUN_IN_CALLBACK_CAP,
  createWebControlLabelHost,
} from '@proto.ui/module-control-label';
import type { FocusEntryConfig, TextControlPatch } from '@proto.ui/core';
import {
  isWebFocusTargetActive,
  orderFocusTargetsByDocument,
  resolveWebFocusEntryTarget,
} from '@proto.ui/adapter-base';
import {
  cancelWebEventDefaultAction,
  createCapsWiring,
  retainWebPortalDirection,
  createWebMoveGestureHost,
  type LogicalInstanceToken,
} from '@proto.ui/adapter-base';
import {
  HOST_ELEMENT_CAP,
  type EffectsPort,
  type FocusRequestOptions,
  type ScrollProjectionPreference,
} from '@proto.ui/core';
import {
  createDomOrderObserver,
  ANATOMY_GET_PROTO_CAP,
  ANATOMY_INSTANCE_TOKEN_CAP,
  ANATOMY_ORDER_OBSERVER_CAP,
  ANATOMY_PARENT_CAP,
  ANATOMY_ROOT_TARGET_CAP,
} from '@proto.ui/module-anatomy';
import {
  AS_TRIGGER_GET_PROTO_CAP,
  AS_TRIGGER_GET_GROUP_EVENT_TARGET_CAP,
  AS_TRIGGER_INSTANCE_CAP,
  AS_TRIGGER_MERGE_GROUP_CAP,
  AS_TRIGGER_PARENT_CAP,
} from '@proto.ui/module-as-trigger';
import { A11Y_PROJECT_CAP, createWebA11yProjector } from '@proto.ui/module-a11y';
import { createWebBoundaryHostBridge, BOUNDARY_HOST_BRIDGE_CAP } from '@proto.ui/module-boundary';
import { CONTEXT_INSTANCE_TOKEN_CAP, CONTEXT_PARENT_CAP } from '@proto.ui/module-context';
import {
  EFFECTS_CAP,
  VISUAL_FEEDBACK_SINK_CAP,
  type VisualFeedbackSink,
} from '@proto.ui/module-feedback';
import {
  EVENT_CANCEL_DEFAULT_ACTION_CAP,
  EVENT_GLOBAL_TARGET_CAP,
  EVENT_GLOBAL_INPUT_SCOPE_CAP,
  EVENT_ROOT_TARGET_CAP,
} from '@proto.ui/module-event';
import { EXPOSE_EVENT_SINK_CAP } from '@proto.ui/module-expose-event';
import { EXPOSES_RECORD_SINK_CAP } from '@proto.ui/module-expose-state';
import type { RawPropsSource } from '@proto.ui/module-props';
import {
  createExposeStateWebNameMap,
  createExposeStateWebNativeVariantPolicy,
  EXPOSE_STATE_WEB_MAP_CAP,
  EXPOSE_STATE_WEB_MODE_CAP,
  type ExposeStateWebMode,
} from '@proto.ui/module-expose-state-web';
import {
  FOCUS_BLUR_CAP,
  FOCUS_RELEASE_PENDING_CAP,
  FOCUS_INSTANCE_TOKEN_CAP,
  FOCUS_IS_NATIVELY_FOCUSABLE_CAP,
  FOCUS_ORDER_CAP,
  FOCUS_PARENT_CAP,
  FOCUS_REQUEST_FOCUS_CAP,
  FOCUS_ROOT_TARGET_CAP,
  FOCUS_RESOLVE_ENTRY_TARGET_CAP,
  FOCUS_SET_ENTRY_FOCUSABLE_CAP,
  FOCUS_RUN_IN_CALLBACK_CAP,
  FOCUS_SET_FOCUSABLE_CAP,
  FOCUS_TARGET_READY_CAP,
  type FocusRequestKind,
} from '@proto.ui/module-focus';
import {
  createWebHitParticipationHostBridge,
  HIT_PARTICIPATION_HOST_BRIDGE_CAP,
} from '@proto.ui/module-hit-participation';
import {
  OVERLAY_GLOBAL_MOUNT_CAP,
  OVERLAY_LAYER_SCHEDULER_CAP,
  OVERLAY_MODAL_CAP,
  OVERLAY_TARGET_HOST_CAP,
  createWebOverlayModal,
  type OverlayGlobalMount,
  type OverlayLayerScheduler,
} from '@proto.ui/module-overlay';
import {
  CONTEXT_MENU_INPUT_HOST_CAP,
  CONTEXT_MENU_INPUT_RUN_IN_CALLBACK_CAP,
  createWebContextMenuInputHost,
  AVAILABLE_SPACE_HOST_CAP,
  createWebAvailableSpaceHost,
  ANCHORED_POSITION_HOST_CAP,
  createFloatingUiAnchoredPositionHost,
} from '@proto.ui/module-positioning';
import { RAW_PROPS_SOURCE_CAP } from '@proto.ui/module-props';
import { RULE_EXPOSE_STATE_WEB_NATIVE_VARIANT_POLICY_CAP } from '@proto.ui/module-rule-expose-state-web';
import {
  RULE_META_GET_CAP,
  RULE_META_COLOR_SCHEME_SOURCE_CAP,
  RULE_META_PREFERENCE_SOURCE_CAP,
  RULE_META_STYLE_SUPPORT_SOURCE_CAP,
  RULE_META_VIEWPORT_SOURCE_CAP,
  type StyleSupportInvalidationSource,
  type ViewportInvalidationSource,
  type PreferenceInvalidationSource,
  type ColorSchemeInvalidationSource,
} from '@proto.ui/module-rule-meta';
import { createWebScrollSurfaceHost, SCROLL_SURFACE_HOST_CAP } from '@proto.ui/module-scroll';
import {
  createWebTextControlHost,
  TEXT_CONTROL_HOST_CAP,
  TEXT_CONTROL_RUN_IN_CALLBACK_CAP,
  type TextControlHost,
  type TextControlHostLease,
  type WebTextControl,
} from '@proto.ui/module-text-control';
import {
  createWebImageViewHost,
  IMAGE_VIEW_HOST_CAP,
  IMAGE_VIEW_RUN_IN_CALLBACK_CAP,
} from '@proto.ui/module-image-view';
import type { PropsBaseType } from '@proto.ui/types';

import {
  clearProtoParentProjection,
  getLogicalParent,
  getLogicalEventTarget,
  getLogicalPrototype,
  getLogicalRoot,
  getLogicalTriggerSurfaceRoot,
  isNativeFocusTargetReady,
  mergeLogicalTriggerGroup,
  setProtoParent,
  subscribeFocusSurfaceReady,
} from '../platform/instance-tree';

type ReactOwnerModulesArgs<Props extends PropsBaseType> = {
  ownedDecoration?: boolean;
  instanceToken: LogicalInstanceToken;
  emit: (key: string, payload?: unknown, options?: Record<string, unknown>) => void;
  rawPropsSource: RawPropsSource<Props>;
  getMeta: (key: string) => unknown;
  colorSchemeSource?: ColorSchemeInvalidationSource;
  preferenceSource?: PreferenceInvalidationSource;
  styleSupportSource?: StyleSupportInvalidationSource;
  viewportSource?: ViewportInvalidationSource;
  setExposes: (record: Record<string, unknown>) => void;
  runInCallbackScope: (fn: () => void) => void;
  overlayLayerScheduler?: OverlayLayerScheduler;
};

export function createReactOverlayGlobalMount(
  instanceToken: LogicalInstanceToken,
  getPortalOrigin?: () => Node | null
): OverlayGlobalMount<HTMLElement> {
  const directionLeases = new WeakMap<HTMLElement, () => void>();
  return {
    mount(hostEl: HTMLElement) {
      const parentToken = getLogicalParent(instanceToken);
      setProtoParent(hostEl, parentToken ? getLogicalRoot(parentToken) : null);
      if (!directionLeases.has(hostEl)) {
        const originalParent = hostEl.parentNode;
        directionLeases.set(
          hostEl,
          retainWebPortalDirection(
            hostEl,
            () =>
              getPortalOrigin?.() ??
              (getLogicalParent(instanceToken)
                ? getLogicalRoot(getLogicalParent(instanceToken)!)
                : originalParent)
          )
        );
      }
    },
    unmount(hostEl: HTMLElement) {
      const releaseDirection = directionLeases.get(hostEl);
      directionLeases.delete(hostEl);
      releaseDirection?.();
      // Removing a renderer-owned portal view must not detach the retained
      // Proto instance from its logical owner.
      clearProtoParentProjection(hostEl);
    },
  };
}

/** Owner/instance capabilities that are valid before a host view exists. */
export function createReactOwnerModules<Props extends PropsBaseType>(
  args: ReactOwnerModulesArgs<Props>
) {
  const {
    instanceToken,
    emit,
    rawPropsSource,
    getMeta,
    colorSchemeSource,
    preferenceSource,
    styleSupportSource,
    viewportSource,
    setExposes,
  } = args;

  return createCapsWiring()
    .use('feedback', [
      [MATERIAL_PAINT_RESERVATION_CAP, true],
      ...(args.ownedDecoration ? [[OWNED_DECORATION_CAP, true] as const] : []),
    ])
    .use('props', [[RAW_PROPS_SOURCE_CAP, rawPropsSource]])
    .use('expose-event', [[EXPOSE_EVENT_SINK_CAP, emit]])
    .use('focus', [
      [FOCUS_INSTANCE_TOKEN_CAP, instanceToken],
      [FOCUS_PARENT_CAP, (inst: unknown) => getLogicalParent(inst as LogicalInstanceToken)],
      [FOCUS_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
    ])
    .use('expose-state', [
      [
        EXPOSES_RECORD_SINK_CAP,
        (record: Record<string, unknown>) => {
          setExposes(record ?? {});
        },
      ],
    ])
    .use('context', [
      [CONTEXT_INSTANCE_TOKEN_CAP, instanceToken],
      [CONTEXT_PARENT_CAP, (inst: unknown) => getLogicalParent(inst as LogicalInstanceToken)],
    ])
    .use('anatomy', [
      [ANATOMY_INSTANCE_TOKEN_CAP, instanceToken],
      [ANATOMY_PARENT_CAP, getLogicalParent],
      [ANATOMY_GET_PROTO_CAP, (inst: unknown) => getLogicalPrototype(inst as LogicalInstanceToken)],
      [ANATOMY_ROOT_TARGET_CAP, (inst: unknown) => getLogicalRoot(inst as LogicalInstanceToken)],
    ])
    .use('as-trigger', [
      [AS_TRIGGER_INSTANCE_CAP, instanceToken],
      [AS_TRIGGER_PARENT_CAP, (inst: unknown) => getLogicalParent(inst as LogicalInstanceToken)],
      [
        AS_TRIGGER_MERGE_GROUP_CAP,
        (inst: unknown, anchor: unknown) =>
          mergeLogicalTriggerGroup(inst as LogicalInstanceToken, anchor as LogicalInstanceToken),
      ],
      [
        AS_TRIGGER_GET_GROUP_EVENT_TARGET_CAP,
        (inst: unknown) => getLogicalEventTarget(inst as LogicalInstanceToken),
      ],
      [
        AS_TRIGGER_GET_PROTO_CAP,
        (inst: unknown) => getLogicalPrototype(inst as LogicalInstanceToken),
      ],
    ])
    .use('rule-meta', [
      [RULE_META_GET_CAP, getMeta],
      ...(colorSchemeSource
        ? [[RULE_META_COLOR_SCHEME_SOURCE_CAP, colorSchemeSource] as const]
        : []),
      ...(preferenceSource ? [[RULE_META_PREFERENCE_SOURCE_CAP, preferenceSource] as const] : []),
      ...(viewportSource ? [[RULE_META_VIEWPORT_SOURCE_CAP, viewportSource] as const] : []),
      ...(styleSupportSource
        ? [[RULE_META_STYLE_SUPPORT_SOURCE_CAP, styleSupportSource] as const]
        : []),
    ])
    .use('rule-expose-state-web', [
      [RULE_EXPOSE_STATE_WEB_NATIVE_VARIANT_POLICY_CAP, createExposeStateWebNativeVariantPolicy],
    ])
    .use('overlay', () => [
      ...(args.overlayLayerScheduler
        ? [[OVERLAY_LAYER_SCHEDULER_CAP, args.overlayLayerScheduler] as const]
        : []),
    ])
    .build();
}

// Kept by the logical Adapter owner, across replaceable view providers.
export type FocusIntentState = {
  options?: FocusRequestOptions;
  kind?: FocusRequestKind;
};

export function createReactModules<Props extends PropsBaseType>(args: {
  ownedDecoration?: boolean;
  el: HTMLElement;
  instanceToken: LogicalInstanceToken;
  router: {
    rootTarget: EventTarget;
    globalTarget: EventTarget;
  };
  emit: (key: string, payload?: unknown, options?: Record<string, unknown>) => void;
  rawPropsSource: RawPropsSource<Props>;
  effectsPort: EffectsPort;
  /** Optional V2 visual provider for this physical view; absence retains ordinary style. */
  visualFeedbackSink?: VisualFeedbackSink;
  residentMotion?: WebResidentMotionOptions;
  shader?: WebShaderHostOptions;
  getMeta: (key: string) => unknown;
  colorSchemeSource?: ColorSchemeInvalidationSource;
  preferenceSource?: PreferenceInvalidationSource;
  styleSupportSource?: StyleSupportInvalidationSource;
  viewportSource?: ViewportInvalidationSource;
  exposeStateWebMode?: ExposeStateWebMode;
  scrollProjection?: ScrollProjectionPreference;
  setExposes: (record: Record<string, unknown>) => void;
  setTextControlDefaultValue: (value: string | undefined, name: string | undefined) => void;
  runInCallbackScope: (fn: () => void) => void;
  isViewReady: () => boolean;
  isEntryAcquisitionReady: (target: HTMLElement) => boolean;
  onFocusAcquired?: () => void;
  onFocusPendingReleased?: () => void;
  focusIntentState?: FocusIntentState;
  onFocusIntent?: () => void;
  getCurrentElement: () => HTMLElement | null;
  subscribeTargetReady: (listener: () => void) => () => void;
  retryTargetReady: () => void;
  overlayLayerScheduler?: OverlayLayerScheduler;
  getPortalOrigin?: () => Node | null;
}) {
  const {
    el,
    instanceToken,
    router,
    emit,
    rawPropsSource,
    effectsPort,
    getMeta,
    colorSchemeSource,
    preferenceSource,
    styleSupportSource,
    viewportSource,
    exposeStateWebMode,
    scrollProjection,
    setExposes,
  } = args;

  const request = args.focusIntentState ?? {};
  const getTriggerSurface = () => {
    const target = getLogicalTriggerSurfaceRoot(instanceToken);
    return args.isViewReady() && target?.isConnected ? target : null;
  };
  // Label owns physical-detachment discovery; focus still requires connection.
  const getControlLabelSurface = () =>
    args.isViewReady() ? getLogicalTriggerSurfaceRoot(instanceToken) : null;
  const subscribeFocusTarget = (listener: () => void) => {
    const offReady = args.subscribeTargetReady(listener);
    const offSurface = subscribeFocusSurfaceReady(instanceToken, listener);
    return () => {
      offReady();
      offSurface();
    };
  };

  const currentViewRoot = () => {
    const current = args.getCurrentElement();
    return current === el && current.isConnected ? current : null;
  };
  // Keep the native HTMLElement interface check and its error realm across adoption.
  const view = el.ownerDocument.defaultView;
  const htmlElementPrototype =
    view?.HTMLElement.prototype ??
    (typeof HTMLElement === 'undefined' ? null : HTMLElement.prototype);
  const readHtmlTitle = htmlElementPrototype
    ? Object.getOwnPropertyDescriptor(htmlElementPrototype, 'title')?.get
    : undefined;
  const nodePrototype =
    view?.Node.prototype ?? (typeof Node === 'undefined' ? null : Node.prototype);
  const readOwnerDocument = nodePrototype
    ? Object.getOwnPropertyDescriptor(nodePrototype, 'ownerDocument')?.get
    : undefined;
  const NativeTypeError = view?.TypeError ?? TypeError;
  const overlayTargetHost = {
    root: currentViewRoot,
    resolve(candidate: unknown): object | null {
      const root = currentViewRoot();
      if (!root || !readHtmlTitle || !readOwnerDocument) return null;
      try {
        // Explicit content may be outside Root. A native getter verifies its
        // interface without trusting shape fields or destination-realm instanceof.
        readHtmlTitle.call(candidate);
      } catch (error) {
        if (error instanceof NativeTypeError) return null;
        throw error;
      }
      if (readOwnerDocument.call(candidate) !== readOwnerDocument.call(root)) return null;
      return candidate as HTMLElement;
    },
  };

  const physicalControl = () =>
    args.getCurrentElement() as HTMLInputElement | HTMLTextAreaElement | null;
  const physicalImage = () => args.getCurrentElement() as HTMLImageElement | null;

  return createCapsWiring()
    .use('control-label', [
      [
        CONTROL_LABEL_HOST_CAP,
        createWebControlLabelHost(getControlLabelSurface, subscribeFocusTarget),
      ],
      [CONTROL_LABEL_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
    ])
    .use('text-control', [
      [
        TEXT_CONTROL_HOST_CAP,
        createReactTextControlHost(physicalControl, args.setTextControlDefaultValue),
      ],
      [TEXT_CONTROL_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
    ])
    .use('native-link', [
      [
        NATIVE_LINK_HOST_CAP,
        createWebNativeLinkHost(() => args.getCurrentElement() as HTMLAnchorElement | null),
      ],
      [NATIVE_LINK_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
    ])
    .use('image-view', [
      [IMAGE_VIEW_HOST_CAP, createWebImageViewHost(physicalImage)],
      [IMAGE_VIEW_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
    ])
    .use('props', [[RAW_PROPS_SOURCE_CAP, rawPropsSource]])
    .use('feedback', [
      [MATERIAL_PAINT_RESERVATION_CAP, true],
      ...(args.ownedDecoration ? [[OWNED_DECORATION_CAP, true] as const] : []),
      [EFFECTS_CAP, effectsPort],
      [
        SHADER_PRESENTATION_SINK_CAP,
        createWebShaderPresentationSink(args.getCurrentElement, effectsPort, args.shader),
      ],
      [PRESENCE_PRESENTATION_SINK_CAP, createWebPresencePresentationSink(args.el, effectsPort)],
      [PRESENCE_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
      [
        RESIDENT_MOTION_SINK_CAP,
        createWebResidentMotionSink(args.el, effectsPort, args.residentMotion),
      ],
      ...(args.visualFeedbackSink
        ? [[VISUAL_FEEDBACK_SINK_CAP, args.visualFeedbackSink] as const]
        : []),
    ])
    .use('a11y', [
      [
        A11Y_PROJECT_CAP,
        createWebA11yProjector(() => {
          const surface = getLogicalTriggerSurfaceRoot(instanceToken);
          const target = surface === el ? args.getCurrentElement() : surface;
          return args.isViewReady() && target?.isConnected ? target : null;
        }, subscribeFocusTarget),
      ],
    ])
    .use('event', [
      [EVENT_ROOT_TARGET_CAP, () => router.rootTarget],
      [EVENT_GLOBAL_TARGET_CAP, () => router.globalTarget],
      [EVENT_GLOBAL_INPUT_SCOPE_CAP, () => el.ownerDocument],
      [EVENT_CANCEL_DEFAULT_ACTION_CAP, cancelWebEventDefaultAction],
    ])
    .use('expose-event', [[EXPOSE_EVENT_SINK_CAP, emit]])
    .use('focus', [
      [FOCUS_INSTANCE_TOKEN_CAP, instanceToken],
      [FOCUS_PARENT_CAP, (inst: unknown) => getLogicalParent(inst as LogicalInstanceToken)],
      [FOCUS_TARGET_READY_CAP, subscribeFocusTarget],
      [FOCUS_RELEASE_PENDING_CAP, () => args.onFocusPendingReleased?.()],
      [FOCUS_ROOT_TARGET_CAP, getTriggerSurface],
      [FOCUS_IS_NATIVELY_FOCUSABLE_CAP, isNativelyFocusable],
      [FOCUS_ORDER_CAP, orderFocusTargetsByDocument],
      [
        FOCUS_SET_FOCUSABLE_CAP,
        (target: HTMLElement, enabled: boolean, options?: { programmatic?: boolean }) => {
          const surface = getLogicalTriggerSurfaceRoot(instanceToken);
          projectFocusable(target, enabled && (!surface || surface === target), options);
        },
      ],
      [
        FOCUS_RESOLVE_ENTRY_TARGET_CAP,
        (target: HTMLElement, config: FocusEntryConfig) =>
          resolveWebFocusEntryTarget(target, config, isNativelyFocusable),
      ],
      [
        FOCUS_SET_ENTRY_FOCUSABLE_CAP,
        (target: HTMLElement, config: FocusEntryConfig, enabled: boolean) => {
          const resolved = enabled
            ? resolveWebFocusEntryTarget(target, config, isNativelyFocusable)
            : null;
          projectFocusable(target, resolved === target);
        },
      ],
      [
        FOCUS_REQUEST_FOCUS_CAP,
        (target: HTMLElement, options: FocusRequestOptions | undefined, kind: FocusRequestKind) => {
          if (request.options !== options || request.kind !== kind) {
            request.options = options;
            request.kind = kind;
            args.onFocusIntent?.();
          }
          if (
            !target.isConnected ||
            (kind === 'native' && !isNativeFocusTargetReady(target)) ||
            (kind === 'entry' && !args.isEntryAcquisitionReady(target))
          )
            return false;
          target.focus(
            typeof options?.preventScroll === 'boolean'
              ? { preventScroll: options.preventScroll }
              : undefined
          );
          const applied = isWebFocusTargetActive(target);
          // Native focus can synchronously issue a newer request. Only the
          // still-current intent owns success or retry-budget accounting.
          if (request.options === options && request.kind === kind) {
            if (applied) args.onFocusAcquired?.();
            else args.retryTargetReady();
          }
          return applied;
        },
      ],
      [FOCUS_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
      [
        FOCUS_BLUR_CAP,
        (target: HTMLElement) => {
          target.blur();
        },
      ],
    ])
    .use('expose-state', [
      [
        EXPOSES_RECORD_SINK_CAP,
        (record: Record<string, unknown>) => {
          setExposes(record ?? {});
        },
      ],
    ])
    .use('expose-state-web', () => [
      [HOST_ELEMENT_CAP, el],
      [EXPOSE_STATE_WEB_MAP_CAP, createExposeStateWebNameMap],
      ...(exposeStateWebMode ? [[EXPOSE_STATE_WEB_MODE_CAP, exposeStateWebMode] as const] : []),
    ])
    .use('context', [
      [CONTEXT_INSTANCE_TOKEN_CAP, instanceToken],
      [CONTEXT_PARENT_CAP, (inst: unknown) => getLogicalParent(inst as LogicalInstanceToken)],
    ])
    .use('anatomy', [
      [ANATOMY_INSTANCE_TOKEN_CAP, instanceToken],
      [ANATOMY_PARENT_CAP, getLogicalParent],
      [ANATOMY_GET_PROTO_CAP, (inst: unknown) => getLogicalPrototype(inst as LogicalInstanceToken)],
      [ANATOMY_ROOT_TARGET_CAP, (inst: unknown) => getLogicalRoot(inst as LogicalInstanceToken)],
      [ANATOMY_ORDER_OBSERVER_CAP, createDomOrderObserver],
    ])
    .use('as-trigger', [
      [AS_TRIGGER_INSTANCE_CAP, instanceToken],
      [AS_TRIGGER_PARENT_CAP, (inst: unknown) => getLogicalParent(inst as LogicalInstanceToken)],
      [
        AS_TRIGGER_MERGE_GROUP_CAP,
        (inst: unknown, anchor: unknown) =>
          mergeLogicalTriggerGroup(inst as LogicalInstanceToken, anchor as LogicalInstanceToken),
      ],
      [
        AS_TRIGGER_GET_GROUP_EVENT_TARGET_CAP,
        (inst: unknown) => getLogicalEventTarget(inst as LogicalInstanceToken),
      ],
      [
        AS_TRIGGER_GET_PROTO_CAP,
        (inst: unknown) => getLogicalPrototype(inst as LogicalInstanceToken),
      ],
    ])
    .use('rule-meta', [
      [RULE_META_GET_CAP, getMeta],
      ...(colorSchemeSource
        ? [[RULE_META_COLOR_SCHEME_SOURCE_CAP, colorSchemeSource] as const]
        : []),
      ...(preferenceSource ? [[RULE_META_PREFERENCE_SOURCE_CAP, preferenceSource] as const] : []),
      ...(viewportSource ? [[RULE_META_VIEWPORT_SOURCE_CAP, viewportSource] as const] : []),
      ...(styleSupportSource
        ? [[RULE_META_STYLE_SUPPORT_SOURCE_CAP, styleSupportSource] as const]
        : []),
    ])
    .use('rule-expose-state-web', [
      [RULE_EXPOSE_STATE_WEB_NATIVE_VARIANT_POLICY_CAP, createExposeStateWebNativeVariantPolicy],
    ])
    .use('hit-participation', [
      [HOST_ELEMENT_CAP, el],
      [HIT_PARTICIPATION_HOST_BRIDGE_CAP, createWebHitParticipationHostBridge()],
    ])
    .use('boundary', [
      [HOST_ELEMENT_CAP, el],
      [BOUNDARY_HOST_BRIDGE_CAP, createWebBoundaryHostBridge()],
    ])
    .use('positioning', [
      [ANCHORED_POSITION_HOST_CAP, createFloatingUiAnchoredPositionHost()],
      [CONTEXT_MENU_INPUT_HOST_CAP, createWebContextMenuInputHost()],
      [CONTEXT_MENU_INPUT_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
      [AVAILABLE_SPACE_HOST_CAP, createWebAvailableSpaceHost()],
    ])
    .use('axis-input', [
      [AXIS_INPUT_HOST_CAP, createWebAxisInputHost()],
      [AXIS_INPUT_RUN_IN_CALLBACK_CAP, args.runInCallbackScope],
    ])
    .use('scroll', [
      [
        SCROLL_SURFACE_HOST_CAP,
        createWebScrollSurfaceHost(el, {
          moveGestureHost: createWebMoveGestureHost(),
          preference: scrollProjection,
        }),
      ],
    ])
    .use('overlay', () => [
      [HOST_ELEMENT_CAP, el],
      [OVERLAY_TARGET_HOST_CAP, overlayTargetHost],
      [
        OVERLAY_GLOBAL_MOUNT_CAP,
        createReactOverlayGlobalMount(instanceToken, args.getPortalOrigin),
      ],
      [OVERLAY_MODAL_CAP, createWebOverlayModal(el.ownerDocument)],
      ...(args.overlayLayerScheduler
        ? [[OVERLAY_LAYER_SCHEDULER_CAP, args.overlayLayerScheduler] as const]
        : []),
    ])
    .build();
}

function createReactTextControlHost(
  getTarget: Parameters<typeof createWebTextControlHost>[0],
  projectNativeProps: (defaultValue: string | undefined, name: string | undefined) => void
): TextControlHost {
  const projectPatch = (patch: TextControlPatch) => {
    if (typeof patch.defaultValue === 'string' || typeof patch.name === 'string') {
      projectNativeProps(patch.defaultValue, patch.name);
    }
  };

  return {
    attach(connection) {
      const target = getTarget();
      if (!target) throw new Error('[React Adapter] Text Control target is unavailable.');
      const releaseDefaultValue = bindReactTextControlDefaultValue(target);
      let lease: TextControlHostLease | undefined;
      try {
        const attachedLease = createWebTextControlHost(() => target).attach(connection);
        lease = attachedLease;
        projectPatch(connection.patch);
        return {
          update(patch) {
            attachedLease.update(patch);
            projectPatch(patch);
          },
          snapshot: () => attachedLease.snapshot(),
          dispose() {
            try {
              attachedLease.dispose();
            } finally {
              releaseDefaultValue();
            }
          },
        };
      } catch (error) {
        try {
          lease?.dispose();
        } catch {
          // Preserve the original attach failure while releasing both resources.
        }
        try {
          releaseDefaultValue();
        } catch {
          // A secondary binding release failure cannot replace the thrown value.
        }
        throw error;
      }
    },
  };
}

function bindReactTextControlDefaultValue(target: WebTextControl): () => void {
  const previous = Object.getOwnPropertyDescriptor(target, 'defaultValue');
  let descriptor = previous;
  for (
    let prototype = Object.getPrototypeOf(target);
    !descriptor && prototype;
    prototype = Object.getPrototypeOf(prototype)
  ) {
    descriptor = Object.getOwnPropertyDescriptor(prototype, 'defaultValue');
  }
  if (!descriptor?.get || !descriptor.set) {
    throw new Error('[React Adapter] Text Control requires a native defaultValue accessor.');
  }
  const { get, set, enumerable } = descriptor;
  // React 18/19 can rewrite defaultValue on an otherwise unrelated host commit.
  // Keep the Web lease's unchanged-value rule at this renderer boundary too:
  // even an equal native textarea defaultValue write can collapse its selection.
  const setDefaultValue = function (this: WebTextControl, value: unknown) {
    if (typeof value !== 'string' || get.call(this) !== value) set.call(this, value);
  };
  Object.defineProperty(target, 'defaultValue', {
    configurable: true,
    enumerable,
    get,
    set: setDefaultValue,
  });
  return () => {
    if (Object.getOwnPropertyDescriptor(target, 'defaultValue')?.set !== setDefaultValue) return;
    if (previous) Object.defineProperty(target, 'defaultValue', previous);
    else Reflect.deleteProperty(target, 'defaultValue');
  };
}

function isNativelyFocusable(el: HTMLElement): boolean {
  const tag = el.tagName.toLowerCase();
  if (tag === 'button' || tag === 'select' || tag === 'textarea' || tag === 'iframe') {
    return true;
  }
  if (tag === 'input') return (el as HTMLInputElement).type !== 'hidden';
  if (tag === 'a') return el.hasAttribute('href');
  if (tag === 'area') {
    const map = el.closest('map');
    if (!el.hasAttribute('href') || !map?.name || !el.isConnected) return false;
    return Array.from(el.ownerDocument.querySelectorAll('img[usemap]')).some(
      (image) =>
        image.getAttribute('usemap') === `#${map.name}` &&
        !image.closest('[hidden],[inert],[aria-hidden="true"]')
    );
  }
  if (tag === 'audio' || tag === 'video') return el.hasAttribute('controls');
  if (tag === 'summary') {
    const parent = el.parentElement;
    return (
      parent?.tagName.toLowerCase() === 'details' &&
      Array.from(parent.children).find((child) => child.tagName.toLowerCase() === 'summary') === el
    );
  }
  return false;
}

function projectFocusable(
  target: HTMLElement,
  enabled: boolean,
  options?: { programmatic?: boolean }
): void {
  if (enabled) {
    target.setAttribute('tabindex', '0');
  } else if (options?.programmatic || isNativelyFocusable(target)) {
    target.setAttribute('tabindex', '-1');
  } else {
    target.removeAttribute('tabindex');
  }
}
