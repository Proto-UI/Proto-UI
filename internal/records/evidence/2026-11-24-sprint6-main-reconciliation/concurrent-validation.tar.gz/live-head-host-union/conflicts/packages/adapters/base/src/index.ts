// packages/adapters/base/src/index.ts
export * from './wiring/host-wiring';
export * from './wiring/caps-builder';
export * from './gate/event-gate';
export * from './lifecycle/teardown';
export * from './host/adapter-host';
export * from './host/exposes';
export * from './host/view-epoch-owner';
export * from './host/view-visibility';
export * from './host/surface-projection';
export * from './events/web-event-router';
export * from './events/web-default-action';
export * from './gestures/web-move-gesture-host';
export * from './platform/instance-tree';
export * from './platform/layout-ready';
export * from './platform/web-preferences';
export * from './platform/web-color-scheme-source';
export * from './public-types';
export * from './types';
export * from './platform/focus-entry';
export * from './platform/focus-order';

export * from './platform/web-preference-source';

export * from './platform/web-style-support-source';

export * from './platform/portal-direction';
export * from './platform/portal-destination';
export { createWebAxisInputHost } from './gestures/web-axis-input-host';
export * from './motion/web-resident-motion';

export {
  createWebPresencePresentationSink,
  hasOwnedWebPresenceZeroOpacity,
} from './motion/web-presence-presentation';

export * from './platform/web-viewport-source';
export {
  collectWebOwnedDecorationTargets,
  createWebOwnedDecorationStage,
  type WebOwnedDecorationStage,
} from './platform/web-owned-decoration';

export { createWebOwnedDecorationPortalGate } from './platform/web-owned-decoration-portal';

export { createWebShaderPresentationSink } from './material/shader-webgl2';
<<<<<<< HEAD
=======
export { createWebMaterialPaintReservationRef } from './material/paint-reservation';
>>>>>>> ffc8ba6bea65975cb4ee552a965966ad24cf820c

export { createWebShaderHost } from './material/shader-scene-host';
export type {
  WebShaderHostOptions,
  WebShaderCanvasSceneLease,
  WebShaderSceneBindings,
} from './material/shader-scene-host';
<<<<<<< HEAD
export { createWebMaterialPaintReservationRef } from './material/paint-reservation';
=======
>>>>>>> ffc8ba6bea65975cb4ee552a965966ad24cf820c
