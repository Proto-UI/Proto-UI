// @vitest-environment node
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { tmpdir } from 'node:os';
import { chromium, type Browser, type Page, type Locator, type JSHandle } from 'playwright-core';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { chromeExecutable, startServer, stopServer, type RuntimeId } from './browser-harness';
import {
  collectLiquidMaterialObservation,
  liquidMaterialSubjectSelector,
} from './liquid-material-observation';
import { hasNoVisibleBoxShadow } from './finf-box-shadow-observation';
import { observeOwnedMaterialPaint } from './material-paint-observation';

// Each case gets a fresh context and a terminal receipt, including failed states.
// This is official sandboxed browser evidence, not native/packed/full Finf admission.
const FAMILIES = ['shadcn', 'brutalist', 'bootstrap-2-3-2', 'liquid-glass'] as const;
type Family = (typeof FAMILIES)[number];
const CALENDAR_STATES = [
  'rest',
  'month-menu',
  'year-scroll',
  'focus-only',
  'selected-focused',
] as const;
type CalendarState = (typeof CALENDAR_STATES)[number];
const RUNTIME_LABELS = { wc: 'Web Components', react: 'React', vue: 'Vue', vue2: 'Vue 2' } as const;
const HOST_CLOCK = '2026-10-10T12:00:00Z';
const RECORDS = {
  form: 'internal/records/2026-10-10-finf-form-upstream-paint.md',
  calendar: 'internal/records/2026-10-10-calendar-five-state-reference-correction.md',
  overlay: 'internal/records/2026-10-10-finf-overlay-passive-paint-repair.md',
  tabs: 'internal/records/2026-10-10-runtime-box-tabs.md',
  accordion: 'internal/records/2026-10-06-finf-accordion-family-source-stage.zh-CN.md',
  drawer: 'internal/records/2026-10-10-finf-b-drawer-scrollport-source.md',
} as const;
const output =
  process.env.PUI_FINF_FEATURE_EVIDENCE_DIR ?? path.join(tmpdir(), 'pui-finf-feature-evidence');
const revision = execFileSync('git', ['rev-parse', 'HEAD']).toString().trim();
const tree = execFileSync('git', ['rev-parse', 'HEAD^{tree}']).toString().trim();
const requestedGroup = process.env.PUI_FINF_FEATURE_GROUP;
let browser: Browser;
let baseUrl = '';

type Screenshot = { state: string; file: string; sha256: string; observation: unknown };
type Journey = {
  page: Page;
  previewer: Locator;
  family: Family;
  capture: (state: string, observation?: unknown, crop?: Locator) => Promise<void>;
};
type Case = {
  id: string;
  group: string;
  family: Family;
  component: string;
  runtime?: RuntimeId;
  run: (journey: Journey) => Promise<void>;
};

function routeFor(family: Family, component: string): string {
  const nested =
    family === 'brutalist' && ['popover', 'alert-dialog'].includes(component) ? 'components/' : '';
  return `/en/ui-libraries/${family}/${nested}${component}/`;
}

function references(family: Family, component: string) {
  const record =
    family === 'shadcn' && component === 'alert-dialog'
      ? 'internal/contracts/overlay/shadcn-alert-dialog.presentation.v0.md'
      : component === 'calendar'
        ? RECORDS.calendar
        : component === 'runtime-tabs'
          ? RECORDS.tabs
          : component === 'accordion'
            ? RECORDS.accordion
            : component === 'drawer'
              ? RECORDS.drawer
              : ['form', 'fieldset', 'checkbox-group'].includes(component)
                ? RECORDS.form
                : RECORDS.overlay;
  // Only references already inspected and named in the records are carried here.
  // A same-named upstream implementation is not invented for adapted families.
  const upstream =
    component === 'drawer'
      ? []
      : family === 'shadcn'
        ? component === 'runtime-tabs' || component === 'calendar'
          ? [
              'https://ui.shadcn.com/docs/components/base/calendar',
              'https://ui.shadcn.com/r/styles/base-nova/calendar.json',
            ]
          : ['form', 'fieldset', 'checkbox-group'].includes(component)
            ? [
                'https://ui.shadcn.com/docs/components/base/field',
                'https://ui.shadcn.com/docs/components/base/input',
              ]
            : component === 'accordion'
              ? ['https://ui.shadcn.com/docs/components/base/accordion']
              : component === 'alert-dialog'
                ? [
                    'https://github.com/shadcn-ui/ui/blob/02cad61166c4c20edbc8a3f71bd720eed4c1f49b/apps/v4/registry/new-york-v4/ui/alert-dialog.tsx',
                    'https://github.com/shadcn-ui/ui/blob/02cad61166c4c20edbc8a3f71bd720eed4c1f49b/apps/v4/registry/new-york-v4/ui/button.tsx',
                  ]
                : [`https://ui.shadcn.com/r/styles/base-nova/${component}.json`]
        : family === 'brutalist'
          ? [
              'https://github.com/ekmas/neobrutalism-components/tree/3306a802724874a85f93079702b2795370a279d4/src/components/ui',
            ]
          : family === 'bootstrap-2-3-2'
            ? [
                'https://github.com/twbs/bootstrap/tree/v2.3.2/less',
                'https://getbootstrap.com/2.3.2/base-css.html#forms',
              ]
            : [];
  return {
    record,
    upstream,
    comparison:
      'Source references only. Same-state upstream pixel comparison remains pending independent review.',
    limitations:
      family === 'liquid-glass'
        ? [
            'Independently authored Web material/fallback; no matching public Apple component source.',
            'Web output never substitutes for native GPUI/Qt/Rust evidence.',
          ]
        : component === 'calendar'
          ? [
              'Family Select popup differs from the official native select; no native popup equivalence.',
            ]
          : component === 'drawer'
            ? [
                'Own regression record supplies the geometry/Close oracle; no newly verified upstream source or image comparison.',
              ]
            : family === 'bootstrap-2-3-2'
              ? [
                  'Adapted family presentation; no same-named upstream AlertDialog or custom-checkbox equivalence.',
                ]
              : [],
  };
}

async function paint(locator: Locator) {
  return locator.evaluate((element) => {
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    const range = document.createRange();
    range.selectNodeContents(element);
    const textRect = range.getBoundingClientRect();
    return {
      rect: {
        x: rect.x,
        y: rect.y,
        width: rect.width,
        height: rect.height,
        right: rect.right,
        bottom: rect.bottom,
      },
      textWidth: textRect.width,
      display: style.display,
      visibility: style.visibility,
      color: style.color,
      background: style.backgroundColor,
      shadow: style.boxShadow,
      border: [
        style.borderTopWidth,
        style.borderRightWidth,
        style.borderBottomWidth,
        style.borderLeftWidth,
      ],
      borderColor: style.borderBottomColor,
      radius: style.borderRadius,
      padding: [style.paddingTop, style.paddingRight, style.paddingBottom, style.paddingLeft],
      font: style.font,
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      outline: style.outline,
      opacity: style.opacity,
      clientWidth: element.clientWidth,
      scrollWidth: element.scrollWidth,
      scrollLeft: element.scrollLeft,
      overflowX: style.overflowX,
      ariaSelected: element.getAttribute('aria-selected'),
      ariaChecked: element.getAttribute('aria-checked'),
    };
  });
}

async function settledPaint(locator: Locator) {
  // Keep the normal 1000 ms assertion budget. A focus event can resolve before
  // its 200 ms ring transition; observe the native animation endpoint instead
  // of sampling its interpolated spread or making a screenshot finish it.
  await expect
    .poll(() =>
      locator.evaluate((element) =>
        element
          .getAnimations()
          .some((animation) => animation.pending || animation.playState === 'running')
      )
    )
    .toBe(false);
  return paint(locator);
}

function createCalendarCloseProbe(element: Element, key: string) {
  const document = element.ownerDocument;
  const inspectSubject = (subject: Element | null, includeStyle = false) => {
    if (!subject) return null;
    const ancestors = [];
    for (let current: Element | null = subject; current; current = current.parentElement) {
      // Style reads are post-assertion diagnostics; the input/commit observer
      // only reads attributes and cannot force layout in the measured window.
      const style = includeStyle ? document.defaultView?.getComputedStyle(current) : null;
      ancestors.push({
        tag: current.tagName.toLowerCase(),
        id: current.id,
        ref: current.getAttribute('data-demo-ref'),
        role: current.getAttribute('role'),
        hidden: current.hasAttribute('hidden'),
        inert: current.hasAttribute('inert') || (current as HTMLElement).inert === true,
        ariaHidden: current.getAttribute('aria-hidden'),
        display: style?.display ?? null,
        visibility: style?.visibility ?? null,
      });
    }
    return {
      connected: subject.isConnected,
      tag: subject.tagName.toLowerCase(),
      id: subject.id,
      ref: subject.getAttribute('data-demo-ref'),
      role: subject.getAttribute('role'),
      label: subject.getAttribute('aria-label'),
      labelledBy: subject.getAttribute('aria-labelledby'),
      controls: subject.getAttribute('aria-controls'),
      expanded: subject.getAttribute('aria-expanded'),
      ancestors,
    };
  };
  const installedAt = performance.now();
  let keyAt: number | null = null;
  let keyExpanded: string | null = null;
  let closedAt: number | null = null;
  let keySubject: ReturnType<typeof inspectSubject> = null;
  let firstFalseSubject: ReturnType<typeof inspectSubject> = null;
  const events: Array<{
    at: number;
    kind: 'keydown' | 'expanded';
    previous?: string | null;
    expanded: string | null;
  }> = [];
  const initialExpanded = element.getAttribute('aria-expanded');
  const onKey = (event: KeyboardEvent) => {
    if (!event.isTrusted || event.key !== key || keyAt !== null) return;
    keyAt = performance.now();
    keyExpanded = element.getAttribute('aria-expanded');
    keySubject = inspectSubject(element);
    events.push({ at: keyAt, kind: 'keydown', expanded: keyExpanded });
  };
  const observer = new MutationObserver((records) => {
    const at = performance.now();
    for (let index = 0; index < records.length; index++) {
      const previous = records[index].oldValue;
      const expanded =
        index + 1 < records.length
          ? records[index + 1].oldValue
          : element.getAttribute('aria-expanded');
      events.push({ at, kind: 'expanded', previous, expanded });
      // Accessibility projection may withdraw the old attribute before
      // applying the new one, including across observer delivery batches.
      if (keyAt !== null && keyExpanded === 'true' && closedAt === null && expanded === 'false') {
        closedAt = at;
        firstFalseSubject = inspectSubject(element);
      }
    }
  });
  observer.observe(element, {
    attributes: true,
    attributeOldValue: true,
    attributeFilter: ['aria-expanded'],
  });
  document.addEventListener('keydown', onKey, true);
  return {
    stop(currentElement: Element | null = null) {
      observer.disconnect();
      document.removeEventListener('keydown', onKey, true);
      return {
        clock: 'page performance.now; trusted keydown and MutationObserver delivery',
        timeOrigin: performance.timeOrigin,
        installedAt,
        observedAt: performance.now(),
        keyAt,
        keyExpanded,
        closedAt,
        closeAfterKeyMs: keyAt !== null && closedAt !== null ? closedAt - keyAt : null,
        initialExpanded,
        expanded: element.getAttribute('aria-expanded'),
        keySubject,
        firstFalseSubject,
        observedSubject: inspectSubject(element, true),
        currentSubject: inspectSubject(currentElement, true),
        sameCurrentElement: currentElement === null ? null : currentElement === element,
        events,
      };
    },
  };
}

async function closeCalendarPopup(
  { page, previewer, capture }: Journey,
  trigger: Locator,
  key: 'Escape' | 'Enter',
  state: string
) {
  const probe = await trigger.evaluateHandle(createCalendarCloseProbe, key);
  type CapturedError = { name: string; message: string; stack?: string; cause?: CapturedError };
  const describeError = (error: unknown, depth = 0): CapturedError => {
    const value = error as Error & { cause?: unknown };
    return {
      name: value?.name ?? typeof error,
      message: value?.message ?? String(error),
      ...(value?.stack ? { stack: value.stack } : {}),
      ...(value?.cause !== undefined && depth < 2
        ? { cause: describeError(value.cause, depth + 1) }
        : {}),
    };
  };
  const reads: Array<{
    startedAt: number;
    settledAt: number | null;
    status: 'pending' | 'resolved' | 'rejected';
    value?: string | null;
    error?: CapturedError;
  }> = [];
  const nodeTrace = {
    clock: 'Node performance.now; timeOrigin maps timestamps to epoch milliseconds',
    timeOrigin: performance.timeOrigin,
    keyStartedAt: performance.now(),
    keyReturnedAt: null as number | null,
    pollStartedAt: null as number | null,
    assertionFinishedAt: null as number | null,
    assertionError: null as CapturedError | null,
    reads,
  };
  let failure: unknown;
  try {
    await page.keyboard.press(key);
    nodeTrace.keyReturnedAt = performance.now();
    // Retain the original 1000 ms assertion and its starting point. The page
    // clock below diagnoses input/commit latency without granting extra time.
    nodeTrace.pollStartedAt = performance.now();
    await expect
      .poll(async () => {
        const read: (typeof reads)[number] = {
          startedAt: performance.now(),
          settledAt: null,
          status: 'pending',
        };
        reads.push(read);
        try {
          const value = await trigger.getAttribute('aria-expanded');
          read.value = value;
          read.status = 'resolved';
          return value;
        } catch (error) {
          read.status = 'rejected';
          read.error = describeError(error);
          throw error;
        } finally {
          read.settledAt = performance.now();
        }
      })
      .toBe('false');
  } catch (error) {
    failure = error;
    nodeTrace.assertionError = describeError(error);
  } finally {
    nodeTrace.assertionFinishedAt = performance.now();
  }
  let currentElement: Awaited<ReturnType<Locator['elementHandle']>> = null;
  let currentLocatorError: CapturedError | null = null;
  try {
    // This bounded lookup is only a post-assertion identity diagnostic. It uses
    // the exact role/name locator and cannot turn a timed-out assertion green.
    try {
      currentElement = await trigger.elementHandle({ timeout: 1000 });
    } catch (error) {
      currentLocatorError = describeError(error);
    }
    const observation = await probe.evaluate(
      (current, resolved) => current.stop(resolved),
      currentElement
    );
    await capture(
      state,
      {
        key,
        assertionPassed: !failure,
        close: observation,
        currentLocatorError,
        nodeTrace: {
          ...nodeTrace,
          capturedAt: performance.now(),
          reads: reads.map((read) => ({ ...read })),
        },
      },
      previewer
    );
  } catch (error) {
    failure ??= error;
  } finally {
    await currentElement?.dispose().catch((error) => (failure ??= error));
    await probe.dispose().catch((error) => (failure ??= error));
  }
  if (failure) throw failure;
}

export type PopoverFrame = {
  contentId: string | null;
  openSequence: number;
  connected: boolean;
  expanded: string | null;
  role: string | null;
  reducedMotion: boolean;
  rect: { x: number; y: number; width: number; height: number } | null;
  clientWidth: number | null;
  rem: number;
  display: string | null;
  visibility: string | null;
  opacity: string | null;
  transform: string | null;
  shadow: string | null;
  animations: Array<{
    sequence: number;
    currentOpen: boolean;
    kind: string;
    name: string | null;
    playState: string;
    pending: boolean;
    currentTime: string | null;
  }>;
  at: number;
  phase: string;
  signature: string;
};
type PopoverMotionSample = PopoverFrame & {
  sampling: 'input-boundary' | 'animation-frame';
  settled: boolean;
};
type PopoverMotionTrace = {
  expectedEntryAnimation: string | null;
  frames: PopoverMotionSample[];
  error: string | null;
  stopReason: string | null;
};
export type PopoverMotionProbe = {
  read: () => PopoverFrame;
  frames: PopoverMotionSample[];
  readonly settled: boolean;
  mark: (phase: string) => void;
  stop: (reason?: string) => PopoverMotionTrace;
};
type PopoverProbe = JSHandle<PopoverMotionProbe>;
export type PopoverCaptureObservation = {
  panel: PopoverFrame;
  captureBinding: { before: PopoverFrame; after: PopoverFrame | null; animations: 'allow' };
};

// Serialized into the page. Observe the current Trigger's real portal before
// input, including missing/instant exit frames; never manufacture retained motion.
function createPopoverMotionProbe(
  trigger: HTMLElement,
  expectedEntryAnimation: string | null
): PopoverMotionProbe {
  const started = performance.now();
  let phase = 'entry';
  let raf = 0;
  let timer = 0;
  let stopReason: string | null = null;
  let error: string | null = null;
  let openPanel: HTMLElement | null = null;
  let openSequence = 0;
  let animationSequence = 0;
  const animationObservations = new WeakMap<
    Animation,
    { sequence: number; openSequence: number }
  >();
  const read = (): PopoverFrame => {
    const ids =
      trigger
        .getAttribute('aria-controls')
        ?.split(/[\t\n\f\r ]+/)
        .filter(Boolean) ?? [];
    const panel = ids.length === 1 ? document.getElementById(ids[0]) : null;
    const expanded = trigger.getAttribute('aria-expanded');
    const nextOpenPanel = panel?.isConnected && expanded === 'true' ? panel : null;
    if (nextOpenPanel !== openPanel) {
      openPanel = nextOpenPanel;
      if (openPanel) openSequence += 1;
    }
    const style = panel ? getComputedStyle(panel) : null;
    const rect = panel?.getBoundingClientRect();
    const state = {
      contentId: panel?.id ?? null,
      openSequence,
      connected: panel?.isConnected ?? false,
      expanded,
      role: panel?.getAttribute('role') ?? null,
      reducedMotion: matchMedia('(prefers-reduced-motion: reduce)').matches,
      rect: rect ? { x: rect.x, y: rect.y, width: rect.width, height: rect.height } : null,
      clientWidth: panel?.clientWidth ?? null,
      rem: Number.parseFloat(getComputedStyle(document.documentElement).fontSize),
      display: style?.display ?? null,
      visibility: style?.visibility ?? null,
      opacity: style?.opacity ?? null,
      transform: style?.transform ?? null,
      shadow: style?.boxShadow ?? null,
      animations:
        panel?.getAnimations().map((animation) => {
          let observation = animationObservations.get(animation);
          if (!observation) {
            observation = {
              sequence: ++animationSequence,
              openSequence: openPanel ? openSequence : 0,
            };
            animationObservations.set(animation, observation);
          }
          return {
            sequence: observation.sequence,
            currentOpen: openPanel !== null && observation.openSequence === openSequence,
            kind: animation.constructor.name,
            name: 'animationName' in animation ? String(animation.animationName) : null,
            playState: animation.playState,
            pending: animation.pending,
            currentTime: animation.currentTime === null ? null : String(animation.currentTime),
          };
        }) ?? [],
    };
    // Finished timelines may retain a time beyond their visual endpoint. Keep
    // native times in the trace; compare geometry, paint and animation status.
    const signature = JSON.stringify({
      ...state,
      animations: state.animations.map(({ currentTime: _time, ...animation }) => animation),
    });
    return { ...state, at: performance.now() - started, phase, signature };
  };
  const frames: PopoverMotionSample[] = [{ ...read(), sampling: 'input-boundary', settled: false }];
  let latest: PopoverMotionSample | null = null;
  let previous: PopoverFrame | null = null;
  let previousPanel: HTMLElement | null = null;
  const stop = (reason = 'completed') => {
    if (!stopReason) {
      stopReason = reason;
      cancelAnimationFrame(raf);
      clearTimeout(timer);
    }
    return { expectedEntryAnimation, frames, error, stopReason };
  };
  const sample = () => {
    try {
      const frame = read();
      const panel = frame.contentId ? document.getElementById(frame.contentId) : null;
      const ready =
        frame.connected &&
        frame.expanded === 'true' &&
        frame.role === 'dialog' &&
        frame.display !== 'none' &&
        frame.visibility === 'visible' &&
        frame.opacity === '1' &&
        (frame.rect?.width ?? 0) > 0 &&
        (frame.rect?.height ?? 0) > 0 &&
        // Two frames can precede the authored native animation. Require its
        // actual native endpoint, not the vacuous every([]) before it starts.
        // fill:both keeps a finished entry observable even to a late probe;
        // an animation retained from an older panel/open is not a new entry.
        (expectedEntryAnimation === null ||
          frame.animations.some(
            (animation) =>
              animation.currentOpen &&
              animation.name === expectedEntryAnimation &&
              animation.playState === 'finished'
          )) &&
        frame.animations.every(
          (animation) => !animation.pending && ['finished', 'idle'].includes(animation.playState)
        );
      latest = {
        ...frame,
        sampling: 'animation-frame',
        settled: ready && panel === previousPanel && previous?.signature === frame.signature,
      };
      frames.push(latest);
      previous = ready ? frame : null;
      previousPanel = panel;
      raf = requestAnimationFrame(sample);
    } catch (cause) {
      error = String(cause);
      stop('observer-error');
    }
  };
  // Native animation frames require the real platform clock. This is only an
  // observer deadline, bounded by the existing case, not a wait for guessed motion.
  timer = window.setTimeout(() => stop('case-deadline'), 120_000);
  raf = requestAnimationFrame(sample);
  return {
    read,
    frames,
    get settled() {
      return !stopReason && latest?.settled === true;
    },
    mark(next: string) {
      phase = next;
      previous = null;
      latest = null;
      frames.push({ ...read(), sampling: 'input-boundary', settled: false });
    },
    stop,
  };
}

async function waitForSettledPopover(probe: PopoverProbe) {
  // Retain the existing expect.poll default bound explicitly, not a sleep or an
  // animation.finish()/cancel() that changes the state being measured.
  await expect
    .poll(() => probe.evaluate((current) => current.settled), { timeout: 1_000 })
    .toBe(true);
}

async function captureSettledPopover(
  probe: PopoverProbe,
  panel: Locator,
  family: Family,
  capture: Journey['capture'],
  state: string
) {
  await waitForSettledPopover(probe);
  const { before, settled } = await probe.evaluate((current) => {
    const before = current.read();
    return {
      before,
      settled: current.settled && before.signature === current.frames.at(-1)?.signature,
    };
  });
  expect(settled).toBe(true);
  expect(await panel.getAttribute('id')).toBe(before.contentId);
  const binding: PopoverCaptureObservation['captureBinding'] = {
    before,
    after: null,
    animations: 'allow',
  };
  // The receipt retains both sides of the actual screenshot. Popover captures
  // allow animations, so screenshotting cannot turn an intermediate into an endpoint.
  await capture(state, { panel: before, captureBinding: binding });
  binding.after = await probe.evaluate((current) => current.read());
  expect(binding.after.signature).toBe(before.signature);
  expect(
    before.animations.every(
      (animation) => !animation.pending && ['finished', 'idle'].includes(animation.playState)
    )
  ).toBe(true);
  if (family === 'shadcn' || family === 'brutalist') {
    expect(Math.abs(before.rect!.width - 18 * before.rem)).toBeLessThanOrEqual(1);
    if (family === 'brutalist') expect(before.shadow).toBe('none');
  }
}

// Faults affect only this disposable browser context, and stay installed for the
// ordinary failure capture. Closing that context retires the native animation.
async function installPopoverNegativeControl(panel: Locator, control: string | undefined) {
  if (control === undefined) return;
  if (!['wrong-width', 'nonsettling'].includes(control))
    throw new Error(`Unknown Popover negative control: ${control}`);
  await panel.evaluate((element, fault) => {
    if (fault === 'wrong-width') element.style.setProperty('width', '20rem', 'important');
    else
      element.animate([{ opacity: 0.5 }, { opacity: 1 }], { duration: 200, iterations: Infinity });
  }, control);
}

async function hasFocus(locator: Locator) {
  return locator.evaluate((element) => {
    let active = document.activeElement;
    while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement;
    while (active) {
      if (element === active || element.contains(active)) return true;
      const root = active.getRootNode();
      active = root instanceof ShadowRoot ? root.host : null;
    }
    return false;
  });
}

// Suite-local: fixed projections and generic embeds own different real Tabs shells.
// Do not fall back to the obsolete Select control or change the shared harness.
async function runtimeControls(previewer: Locator) {
  const fixed = (await previewer.getAttribute('data-projection-mode')) === 'fixed-family';
  return previewer.locator(
    fixed
      ? '[data-projection-scope][data-projection-state="ready"] [data-projection-control="runtime"][data-runtime-tabs]'
      : '[data-runtime-tabs-mount] [data-runtime-tabs-root]'
  );
}

async function runtimeTab(previewer: Locator, runtime: RuntimeId) {
  return (await runtimeControls(previewer)).getByRole('tab', {
    name: RUNTIME_LABELS[runtime],
    exact: true,
  });
}

// This function is serialized into the page; keep every dependency inside it.
function inspectRuntime(
  root: HTMLElement,
  request: { runtime: RuntimeId; label: string; readySelector: string; count: number }
) {
  const { runtime, label, readySelector, count } = request;
  const fixed = root.dataset.projectionMode === 'fixed-family';
  const scopes = root.querySelectorAll<HTMLElement>('[data-projection-scope]');
  const scope = scopes.length === 1 ? scopes[0] : null;
  const hosts = root.querySelectorAll<HTMLElement>('.host');
  const host = hosts.length === 1 ? hosts[0] : null;
  const controls = root.querySelectorAll<HTMLElement>(
    fixed
      ? '[data-projection-scope][data-projection-state="ready"] [data-projection-control="runtime"][data-runtime-tabs]'
      : '[data-runtime-tabs-mount] [data-runtime-tabs-root]'
  );
  const control = controls.length === 1 ? controls[0] : null;
  const selected = control?.querySelectorAll<HTMLElement>('[role="tab"][aria-selected="true"]');
  const tab = selected?.length === 1 ? selected[0] : null;
  const content = fixed ? scope?.querySelector<HTMLElement>('[data-projection-content]') : host;
  const committed = fixed
    ? scope?.dataset.projectionRuntime
    : (
        root as HTMLElement & { __previewer__?: { getCurrentRuntime(): string | null } }
      ).__previewer__?.getCurrentRuntime();
  const surfaces = content?.querySelectorAll<HTMLElement>(
    '.pui-runtime-preview-surface[data-demo-ref="__website_runtime_preview_surface__"]'
  );
  const surface = surfaces?.length === 1 ? surfaces[0] : null;
  const firstRoot = surface?.querySelector<HTMLElement>('[data-pui-root]');
  const unavailable = (element: HTMLElement | null | undefined) => {
    if (!element?.isConnected) return true;
    for (let current: HTMLElement | null = element; current; current = current.parentElement) {
      if (
        current.inert ||
        current.matches(
          '[inert], [hidden], [aria-hidden="true"], [aria-busy="true"], [aria-disabled="true"], [data-previewer-startup-pending], [data-previewer-startup-shell]'
        )
      )
        return true;
      const style = getComputedStyle(current);
      if (style.display === 'none' || style.visibility === 'hidden') return true;
    }
    return false;
  };
  const framework = !firstRoot
    ? null
    : firstRoot.tagName.startsWith('WC-')
      ? 'wc'
      : (firstRoot as HTMLElement & { __vue__?: unknown }).__vue__
        ? 'vue2'
        : host?.hasAttribute('data-v-app') || firstRoot.closest('[data-v-app]')
          ? 'vue'
          : Object.keys(surface!).some((key) => key.startsWith('__reactFiber$'))
            ? 'react'
            : null;
  const targetCount = surface?.querySelectorAll(readySelector).length ?? 0;
  const problems: string[] = [];
  if (!host || !content || controls.length !== 1) problems.push('missing-or-ambiguous-shell');
  if (fixed && (scopes.length !== 1 || scope?.dataset.projectionState !== 'ready'))
    problems.push('projection-not-ready');
  if (!fixed && scopes.length) problems.push('unexpected-fixed-scope');
  if (committed !== runtime) problems.push('runtime-not-committed');
  if (!tab || tab.textContent?.trim() !== label || (!fixed && tab.dataset.runtimeTab !== runtime))
    problems.push('runtime-tab-not-selected');
  if (unavailable(host) || unavailable(control) || unavailable(tab) || unavailable(surface))
    problems.push('shell-not-interactive');
  if (
    root.querySelector(
      '[data-previewer-startup-pending], [data-previewer-startup-shell], .proto-previewer__skeleton'
    )
  )
    problems.push('startup-pending');
  if (
    !surface?.hasAttribute('data-pui-root') ||
    Array.from(content?.querySelectorAll('[data-pui-root]') ?? []).some(
      (element) => element !== surface && !surface?.contains(element)
    )
  )
    problems.push('missing-or-extra-demo-surface');
  if (framework !== runtime) problems.push('wrong-framework');
  if (!firstRoot || targetCount !== count) problems.push('target-controls-not-ready');
  return {
    ready: problems.length === 0,
    shell: fixed ? 'fixed-family' : 'generic',
    committedRuntime: committed ?? null,
    selectedLabel: tab?.textContent?.trim() ?? null,
    surfaceCount: surfaces?.length ?? 0,
    framework,
    targetCount,
    problems,
  };
}

async function waitForRealRuntime(
  previewer: Locator,
  runtime: RuntimeId,
  readySelector: string,
  count: number
) {
  await expect
    .poll(
      () =>
        previewer.evaluate(inspectRuntime, {
          runtime,
          label: RUNTIME_LABELS[runtime],
          readySelector,
          count,
        }),
      { timeout: 20_000 }
    )
    .toMatchObject({ ready: true });
}

async function selectRealRuntime(
  page: Page,
  previewer: Locator,
  runtime: RuntimeId,
  readySelector: string,
  count: number
) {
  const tab = await runtimeTab(previewer, runtime);
  await tab.waitFor({ state: 'visible' });
  // Even the initially selected runtime is a real user selection. Clicking its
  // tab gives the following Tab journey the same native starting point across
  // hosts instead of starting WC at the document's many navigation links.
  await tab.click();
  await waitForRealRuntime(previewer, runtime, readySelector, count);
  await expect
    .poll(async () => (await runtimeTab(previewer, runtime)).getAttribute('aria-selected'))
    .toBe('true');
}

async function keyboardReach(page: Page, target: Locator) {
  for (let attempt = 0; attempt < 30; attempt++) {
    if (await hasFocus(target)) return;
    await page.keyboard.press('Tab');
  }
  throw new Error('Target was not reached by 30 real Tab key presses.');
}

async function writeJson(file: string, value: unknown) {
  await writeFile(path.join(output, file), JSON.stringify(value, null, 2));
}

async function captureFailureDiagnostics(
  previewer: Locator,
  id: string,
  capture: Journey['capture']
) {
  if ((await previewer.count()) !== 1) return { unavailable: 'No previewer mounted.' };
  const files: Record<string, string> = {};
  const errors: string[] = [];
  for (const [kind, collect] of [
    ['dom', () => previewer.evaluate((root) => root.outerHTML)],
    ['aria', () => previewer.ariaSnapshot()],
  ] as const) {
    try {
      const file = `${id}-failed-${kind}.txt`;
      await writeFile(path.join(output, file), await collect());
      files[kind] = file;
    } catch (error) {
      errors.push(`${kind}: ${String(error)}`);
    }
  }
  try {
    await capture('failed-previewer', { diagnostic: 'Exact failed previewer region' }, previewer);
  } catch (error) {
    errors.push(`region: ${String(error)}`);
  }
  return { files, errors };
}

async function runCase(testCase: Case) {
  const context = await browser.newContext({
    viewport: { width: 1365, height: 1000 },
    colorScheme: 'light',
    locale: 'zh-CN',
    timezoneId: 'UTC',
  });
  const page = await context.newPage();
  page.setDefaultTimeout(15_000);
  const previewer = page
    .locator(
      testCase.component === 'drawer'
        ? '[data-demo-id="demo-shadcn-drawer-snap"]'
        : testCase.component === 'calendar'
          ? `[data-demo-id="demo-${testCase.family}-calendar"]`
          : '[data-previewer-id]'
    )
    .first();
  const screenshots: Screenshot[] = [];
  const pageErrors: string[] = [];
  const captureErrors: string[] = [];
  const blockedRequests: string[] = [];
  let failure: unknown;
  const route = routeFor(
    testCase.family,
    testCase.component === 'runtime-tabs' ? 'form' : testCase.component
  );
  const capture: Journey['capture'] = async (state, observation = {}, crop) => {
    const file = `${testCase.id}-${state}.png`;
    await page.evaluate(() => document.fonts.ready);
    if (crop)
      await crop.screenshot({
        path: path.join(output, file),
        animations: ['popover', 'calendar'].includes(testCase.component) ? 'allow' : 'disabled',
        timeout: 10_000,
      });
    else
      await page.screenshot({
        path: path.join(output, file),
        animations: ['popover', 'calendar'].includes(testCase.component) ? 'allow' : 'disabled',
        timeout: 10_000,
      });
    let capturedObservation = observation;
    if (
      testCase.family === 'liquid-glass' &&
      ['accordion', 'alert-dialog', 'popover'].includes(testCase.component)
    ) {
      let triggerCount: number | null = null;
      let ariaControls: string | null = null;
      let contentId: string | null = null;
      if (testCase.component === 'popover') {
        // Follow the current demo's relationship across its body portal; never
        // substitute another dialog or silently select one of several triggers.
        const trigger = previewer.getByRole('button', { name: 'Open Popover', exact: true });
        triggerCount = await trigger.count();
        if (triggerCount === 1) ariaControls = await trigger.getAttribute('aria-controls');
        const ids = ariaControls?.split(/[\t\n\f\r ]+/).filter(Boolean) ?? [];
        if (ids.length === 1) contentId = ids[0];
      }
      const selector = liquidMaterialSubjectSelector(testCase.component, contentId);
      const subjects = selector ? await page.locator(selector).all() : [];
      const matchedCount = subjects.length;
      // Absence or ambiguity is not a subject with null material attributes.
      const materialSubjects =
        testCase.component === 'popover' && matchedCount !== 1 ? [] : subjects;
      capturedObservation = {
        journey: observation,
        ...(testCase.component === 'popover'
          ? {
              materialTarget: {
                selection: 'current-previewer-trigger-aria-controls',
                observationTiming: 'after-screenshot',
                triggerCount,
                ariaControls,
                contentId,
                selector,
                matchedCount,
                status: !selector
                  ? 'unresolved-relationship'
                  : matchedCount === 0
                    ? 'absent'
                    : matchedCount === 1
                      ? 'unique'
                      : 'ambiguous',
              },
            }
          : {}),
        material: await Promise.all(
          materialSubjects.map((subject) => subject.evaluate(collectLiquidMaterialObservation))
        ),
      };
    }
    screenshots.push({
      state,
      file,
      sha256: createHash('sha256')
        .update(await readFile(path.join(output, file)))
        .digest('hex'),
      observation: capturedObservation,
    });
  };
  page.on('pageerror', (error) => pageErrors.push(error.message));
  await context.route('**/*', (request) => {
    const url = new URL(request.request().url());
    if (['http:', 'https:'].includes(url.protocol) && url.origin !== new URL(baseUrl).origin) {
      blockedRequests.push(`${url.origin}${url.pathname}`);
      return request.abort();
    }
    return request.continue();
  });
  try {
    // Locale and fixed clock belong to this host fixture, never to the prototype.
    await page.clock.setFixedTime(HOST_CLOCK);
    const response = await page.goto(`${baseUrl}${route}`, { waitUntil: 'networkidle' });
    expect(response?.status()).toBe(200);
    await previewer.waitFor({ state: 'visible' });
    await testCase.run({ page, previewer, family: testCase.family, capture });
    expect(pageErrors).toEqual([]);
  } catch (error) {
    failure = error;
  } finally {
    // A failed assertion cannot suppress either the current pixels or the receipt.
    await capture(failure ? 'failed' : 'final').catch((error) => captureErrors.push(String(error)));
    const failureDiagnostics = failure
      ? await captureFailureDiagnostics(previewer, testCase.id, capture).catch((error) => ({
          error: String(error),
        }))
      : null;
    const environment = await page
      .evaluate(() => ({
        locale: navigator.language,
        resolvedLocale: new Intl.DateTimeFormat().resolvedOptions().locale,
        today: new Date().toISOString(),
        devicePixelRatio,
        theme: document.documentElement.dataset.theme,
        font: getComputedStyle(document.body).font,
      }))
      .catch(() => null);
    await writeJson(`${testCase.id}.json`, {
      revision,
      tree,
      case: testCase.id,
      group: testCase.group,
      family: testCase.family,
      component: testCase.component,
      ...(testCase.component === 'popover'
        ? { negativeControl: process.env.PUI_FINF_POPOVER_NEGATIVE_CONTROL ?? null }
        : {}),
      route,
      viewport: page.viewportSize(),
      hostClock: HOST_CLOCK,
      environment,
      runtime:
        testCase.component === 'runtime-tabs'
          ? Object.keys(RUNTIME_LABELS)
          : (testCase.runtime ?? 'react'),
      presetCheck: process.env.PUI_FINF_PRESET_CHECK ?? 'unknown',
      browser: browser.version(),
      references: references(testCase.family, testCase.component),
      result: failure ? 'failed' : captureErrors.length ? 'capture-failed' : 'passed',
      error:
        failure instanceof Error
          ? { name: failure.name, message: failure.message, stack: failure.stack }
          : failure
            ? String(failure)
            : null,
      screenshots,
      captureErrors,
      failureDiagnostics,
      pageErrors,
      blockedRequests,
      acceptance:
        'Real current-source observations only; no full-delivery, upstream visual-equivalence or native admission.',
    });
    await context.close();
  }
  if (failure) throw failure;
  expect(captureErrors).toEqual([]);
}

async function formJourney({ page, previewer, family, capture }: Journey) {
  await selectRealRuntime(page, previewer, 'react', '[data-demo-ref="form"]', 1);
  const form = previewer.locator('[data-demo-ref="form"]');
  const editor = form.locator('input').first();
  const label = form.getByText('displayName', { exact: true });
  const field = label.locator('..');
  const submit = form.getByRole('button', { name: /Validate and submit/ });
  const rest = { editor: await paint(editor), label: await paint(label) };
  await capture('rest', rest, previewer);
  // Real user submission supplies invalidity. No Prop/state injection or direct expose call.
  await submit.click();
  await expect.poll(() => editor.getAttribute('aria-invalid')).toBe('true');
  await expect.poll(() => hasFocus(editor)).toBe(true);
  const errorId = await editor.getAttribute('aria-errormessage');
  expect(errorId).toBeTruthy();
  const error = form.locator(`[id=${JSON.stringify(errorId)}]`);
  expect(await error.isVisible()).toBe(true);
  expect(await error.textContent()).toMatch(/required/i);
  expect(await editor.getAttribute('aria-labelledby')).toBe(await label.getAttribute('id'));
  expect(await previewer.locator('[data-demo-ref="status"]').textContent()).not.toContain(
    '"displayName"'
  );
  const invalid = {
    field: await paint(field),
    label: await paint(label),
    editor: await paint(editor),
    error: await paint(error),
    errorText: await error.textContent(),
    errorId,
    firstEditorFocused: await hasFocus(editor),
  };
  await capture('invalid-submit-first-focus', invalid, previewer);
  if (family === 'shadcn' || family === 'brutalist') {
    expect(invalid.label.color).toBe(invalid.field.color);
    expect(invalid.label.color).toBe(invalid.error.color);
    expect(invalid.label.color).not.toBe(rest.label.color);
    expect(invalid.editor.color).toBe(rest.editor.color);
  }
  await editor.fill('Finf sample');
  await submit.click();
  await expect.poll(() => editor.getAttribute('aria-invalid')).not.toBe('true');
  await expect.poll(() => editor.getAttribute('aria-errormessage')).toBe(null);
  await expect
    .poll(() => previewer.locator('[data-demo-ref="status"]').textContent())
    .toContain('"displayName":"Finf sample"');
  expect((await paint(label)).color).toBe(rest.label.color);
  await capture(
    'corrected-submit',
    { editor: await paint(editor), label: await paint(label), value: await editor.inputValue() },
    previewer
  );
  await editor.fill('Finf sample');
  expect(await editor.inputValue()).toBe('Finf sample');
  await form.getByRole('button', { name: /Reset values/ }).click();
  await expect.poll(() => editor.inputValue()).toBe('');
  await capture('reset', { value: await editor.inputValue() }, previewer);
  await editor.fill('Finf sample');
  const email = form.getByRole('checkbox', { name: 'Email · 邮件', exact: true });
  const sms = form.getByRole('checkbox', { name: 'SMS · 短信', exact: true });
  await sms.click();
  await expect.poll(() => sms.getAttribute('aria-checked')).toBe('true');
  const rows = { email: await paint(email), sms: await paint(sms) };
  await capture(
    'edited',
    { editedValue: await editor.inputValue(), resetObserved: true, rows },
    previewer
  );
  if (family !== 'liquid-glass')
    for (const row of Object.values(rows)) expect(row.border).toEqual(['0px', '0px', '0px', '0px']);
}

async function fieldsetJourney({ page, previewer, family, capture }: Journey) {
  await selectRealRuntime(page, previewer, 'react', '[data-demo-ref="group"]', 1);
  const group = previewer.locator('[data-demo-ref="group"]');
  const editor = group.locator('input').first();
  const rest = await paint(group);
  await capture('rest', { group: rest }, previewer);
  await keyboardReach(page, editor);
  await editor.fill('Finf keyboard entry');
  await capture(
    'keyboard-focus',
    { group: await paint(group), editor: await paint(editor), focused: await hasFocus(editor) },
    previewer
  );
  expect(await hasFocus(editor)).toBe(true);
  expect(await group.getAttribute('aria-labelledby')).toBeTruthy();
  expect(await group.getAttribute('aria-describedby')).toBeTruthy();
  // Liquid's independently authored material card is intentionally not homogenized.
  if (family !== 'liquid-glass') {
    expect(rest.border).toEqual(['0px', '0px', '0px', '0px']);
    expect(rest.padding).toEqual(['0px', '0px', '0px', '0px']);
    expect(rest.shadow).toBe('none');
  }
}

async function checkboxGroupJourney({ page, previewer, family, capture }: Journey) {
  await selectRealRuntime(page, previewer, 'react', '[role="checkbox"]', 4);
  const all = previewer.getByRole('checkbox', { name: 'All channels · 全选', exact: true });
  const email = previewer.getByRole('checkbox', { name: 'Email · 邮件', exact: true });
  const sms = previewer.getByRole('checkbox', { name: 'SMS · 短信', exact: true });
  const disabled = previewer.getByRole('checkbox', {
    name: 'Push disabled · 推送已禁用',
    exact: true,
  });
  const rest = await paint(sms);
  await capture(
    'mixed',
    {
      all: await paint(all),
      email: await paint(email),
      sms: rest,
      disabled: await paint(disabled),
    },
    previewer
  );
  expect(await all.getAttribute('aria-checked')).toBe('mixed');
  await all.click();
  await expect.poll(() => sms.getAttribute('aria-checked')).toBe('true');
  const checked = await paint(sms);
  await capture(
    'checked',
    { all: await paint(all), email: await paint(email), sms: checked },
    previewer
  );
  expect(await email.getAttribute('aria-checked')).toBe('true');
  expect(await disabled.getAttribute('aria-checked')).toBe('false');
  await all.click();
  await expect.poll(() => sms.getAttribute('aria-checked')).toBe('false');
  await keyboardReach(page, sms);
  await page.keyboard.press('Space');
  await expect.poll(() => sms.getAttribute('aria-checked')).toBe('true');
  await capture(
    'keyboard-toggle',
    { all: await paint(all), sms: await paint(sms), focused: await hasFocus(sms) },
    previewer
  );
  if (family !== 'liquid-glass') {
    expect(checked.border).toEqual(['0px', '0px', '0px', '0px']);
    expect(checked.background).toBe(rest.background);
  }
}

async function calendarJourney(journey: Journey, state: CalendarState) {
  const { page, previewer, capture } = journey;
  await selectRealRuntime(page, previewer, 'react', '[role="gridcell"]', 42);
  const month = previewer.getByRole('combobox', { name: 'Month', exact: true });
  const year = previewer.getByRole('combobox', { name: 'Year', exact: true });
  await month.waitFor({ state: 'visible' });
  await year.waitFor({ state: 'visible' });
  if (state === 'month-menu') {
    await month.click();
    const options = page.getByRole('option');
    await options.first().waitFor({ state: 'visible' });
    await capture(state, {
      labels: await options.allTextContents(),
      month: await month.textContent(),
    });
    expect(await options.count()).toBe(12);
    expect(await options.allTextContents()).toContain('10月');
    await closeCalendarPopup(journey, month, 'Escape', 'month-escape-close');
  } else if (state === 'year-scroll') {
    await year.click();
    const options = page.getByRole('option');
    await options.first().waitFor({ state: 'attached' });
    const current = page.getByRole('option', { name: '2026', exact: true });
    // Attached options may still be waiting for the public Focus owner to
    // admit initial entry. Observe that real focus before testing its reveal.
    await expect.poll(() => hasFocus(current)).toBe(true);
    const scroll = () =>
      current.evaluate((element) => {
        let ancestor = element.parentElement;
        while (ancestor && ancestor.scrollHeight <= ancestor.clientHeight + 1)
          ancestor = ancestor.parentElement;
        if (!ancestor) return null;
        const item = element.getBoundingClientRect(),
          box = ancestor.getBoundingClientRect();
        return {
          scrollTop: ancestor.scrollTop,
          scrollHeight: ancestor.scrollHeight,
          clientHeight: ancestor.clientHeight,
          currentVisible: item.top >= box.top && item.bottom <= box.bottom + 1,
          box: { x: box.x, y: box.y, width: box.width, height: box.height },
        };
      });
    const initial = await scroll();
    await capture('year-current', { optionCount: await options.count(), initial });
    expect(initial).not.toBeNull();
    await page.mouse.move(
      initial!.box.x + initial!.box.width / 2,
      initial!.box.y + initial!.box.height / 2
    );
    const wheelDelta = initial!.scrollTop > 0 ? -560 : 560;
    await page.mouse.wheel(0, wheelDelta);
    await expect.poll(async () => (await scroll())?.scrollTop).not.toBe(initial!.scrollTop);
    await capture('year-wheel-scrolled', {
      before: initial,
      after: await scroll(),
      input: 'Playwright mouse wheel, no scrollTop writes',
      wheelDelta,
    });
    expect(await options.count()).toBe(101);
    expect(initial!.currentVisible).toBe(true);
    await page.keyboard.press('Escape');
  } else if (state === 'focus-only' || state === 'selected-focused') {
    const initial = previewer.getByRole('gridcell', {
      name: 'Saturday, October 10, 2026',
      exact: true,
    });
    await keyboardReach(page, initial);
    await page.keyboard.press('PageDown');
    await page.keyboard.press('ArrowLeft');
    await page.keyboard.press('ArrowLeft');
    await page.keyboard.press('ArrowLeft');
    const target = previewer.getByRole('gridcell', {
      name: 'Saturday, November 7, 2026',
      exact: true,
    });
    await expect.poll(() => hasFocus(target)).toBe(true);
    const focusOnly = await settledPaint(target);
    if (state === 'selected-focused') await target.click();
    const actual = await settledPaint(target);
    await capture(
      state,
      {
        target: actual,
        focusOnly,
        selectedDate: state === 'selected-focused' ? '2026-11-07' : '2026-10-10',
        focusedDate: '2026-11-07',
        input:
          state === 'selected-focused'
            ? 'keyboard navigation followed by real pointer click'
            : 'Tab, PageDown, ArrowLeft × 3',
      },
      previewer
    );
    expect(actual.ariaSelected).toBe(state === 'selected-focused' ? 'true' : 'false');
    expect(actual.shadow).not.toBe('none');
    expect(actual.shadow).toContain('3px');
    if (state === 'selected-focused') expect(actual.background).not.toBe(focusOnly.background);
  } else {
    await capture(
      'october-rest',
      {
        month: await month.textContent(),
        year: await year.textContent(),
        days: await previewer.locator('[role="gridcell"]:visible').count(),
      },
      previewer
    );
    // Preserve the original explicit October 15 selection assertion in addition to five reference states.
    const day = previewer.getByRole('gridcell', {
      name: 'Thursday, October 15, 2026',
      exact: true,
    });
    await day.click();
    await expect.poll(() => day.getAttribute('aria-selected')).toBe('true');
    await capture(
      'october-15-selected',
      { selectedDate: '2026-10-15', cell: await paint(day) },
      previewer
    );
    const box = await day.boundingBox();
    expect(box?.width).toBeGreaterThan(0);
    expect(box?.height).toBeGreaterThan(0);
  }
  // Count actual painted cells, separately from the retained 42-cell capacity.
  // Hidden-selector failures remain red and have already produced state captures.
  expect(await previewer.getByRole('columnheader').count()).toBe(7);
  expect(await previewer.locator('[role="gridcell"]:visible').count()).toBe(35);
  expect(await month.count()).toBe(1);
  expect(await year.count()).toBe(1);
  expect(await month.textContent()).toContain(state.includes('focus') ? '11月' : '10月');
  const visibleDay = previewer.locator('[role="gridcell"]:visible').first();
  const dimensions = await visibleDay.boundingBox();
  // The ordinary demo selects Rhea. Its pinned .cn-calendar recipe uses
  // --cell-size: --spacing(8), or 2rem; the unscoped Nova recipe uses 1.75rem.
  const rem = await page.evaluate(() =>
    parseFloat(getComputedStyle(document.documentElement).fontSize)
  );
  expect(Math.abs(dimensions!.width - 2 * rem)).toBeLessThanOrEqual(1);
  expect(Math.abs(dimensions!.height - 2 * rem)).toBeLessThanOrEqual(1);
  await capture(
    'rhea-cell-geometry',
    {
      styleProfile: 'rhea',
      upstream: '3d98900e9b73c45f035f8109e9d41ba6a51685e7',
      sourcePath: 'apps/v4/registry/styles/style-rhea.css',
      sourceBlob: '94bbca2a7f78845e7cfbcff68fb8f535e3848a98',
      dimensions,
      rem,
    },
    previewer
  );
}

async function calendarCaptionJourney(journey: Journey, runtime: RuntimeId) {
  const { page, previewer, capture } = journey;
  await selectRealRuntime(page, previewer, runtime, '[role="gridcell"]', 42);
  const month = previewer.getByRole('combobox', { name: 'Month', exact: true });
  const year = previewer.getByRole('combobox', { name: 'Year', exact: true });
  await month.waitFor({ state: 'visible' });
  await year.waitFor({ state: 'visible' });
  const monthControls = await month.getAttribute('aria-controls');
  const yearControls = await year.getAttribute('aria-controls');
  expect(monthControls).toBeTruthy();
  expect(yearControls).toBeTruthy();
  expect(monthControls).not.toBe(yearControls);
  const caption = async (state: string) => {
    // Role/name locators use the browser's accessible-name computation. The
    // selected text and owned controls relations remain separate observations.
    expect(await previewer.getByRole('combobox').count()).toBe(2);
    expect(await month.count()).toBe(1);
    expect(await year.count()).toBe(1);
    expect(await month.getAttribute('aria-controls')).toBe(monthControls);
    expect(await year.getAttribute('aria-controls')).toBe(yearControls);
    await capture(
      state,
      {
        runtime,
        aria: await previewer.ariaSnapshot(),
        month: await month.textContent(),
        year: await year.textContent(),
        monthControls,
        yearControls,
      },
      previewer
    );
  };
  await caption('caption-october-2026');
  for (const [trigger, controls, current, key, next] of [
    [month, monthControls, '10月', 'ArrowDown', '11月'],
    [year, yearControls, '2026', 'ArrowUp', '2025'],
  ] as const) {
    await keyboardReach(page, trigger);
    await page.keyboard.press('ArrowDown');
    const listbox = page.getByRole('listbox');
    await listbox.waitFor({ state: 'visible' });
    expect(await listbox.getAttribute('id')).toBe(controls);
    await expect
      .poll(() => hasFocus(listbox.getByRole('option', { name: current, exact: true })))
      .toBe(true);
    await page.keyboard.press(key);
    const option = listbox.getByRole('option', { name: next, exact: true });
    await expect.poll(() => hasFocus(option)).toBe(true);
    await closeCalendarPopup(journey, trigger, 'Enter', `caption-${next}-enter-close`);
    await expect.poll(() => hasFocus(trigger)).toBe(true);
    await expect.poll(() => trigger.textContent()).toBe(next);
    await caption(`caption-selected-${next}`);
  }
  const date = previewer.getByRole('gridcell', {
    name: 'Saturday, November 1, 2025',
    exact: true,
  });
  await date.waitFor({ state: 'visible' });
  await date.click();
  await expect.poll(() => date.getAttribute('aria-selected')).toBe('true');
  await caption('caption-november-2025-date-selected');
}

async function drawerJourney({ page, previewer, capture }: Journey) {
  await selectRealRuntime(page, previewer, 'react', '[data-demo-ref="root"]', 1);
  const trigger = previewer.getByRole('button', { name: 'Open Drawer', exact: true });
  await trigger.click();
  const panel = page.locator('[data-demo-ref="panel"][role="dialog"]');
  await panel.waitFor({ state: 'visible' });
  const handle = panel.getByRole('separator', { name: 'Resize drawer', exact: true });
  await handle.focus();
  await page.keyboard.press('Home');
  await expect
    .poll(() =>
      panel.evaluate((element) =>
        getComputedStyle(element).getPropertyValue('--pui-offset-percentage').trim()
      )
    )
    .toBe('50');
  const geometry = await panel.evaluate((element) => {
    const rect = element.getBoundingClientRect(),
      style = getComputedStyle(element);
    return {
      x: rect.x,
      y: rect.y,
      width: rect.width,
      height: rect.height,
      right: rect.right,
      bottom: rect.bottom,
      rootTextSize: Number.parseFloat(getComputedStyle(document.documentElement).fontSize),
      availableHeight:
        Number.parseFloat(style.getPropertyValue('--proto-ui-available-region-height')) ||
        window.visualViewport?.height ||
        window.innerHeight,
      viewportWidth: innerWidth,
      viewportHeight: innerHeight,
    };
  });
  await capture('half-open', { snapPoint: 0.5, offsetPercentage: 50, panel: geometry });
  expect(geometry.height).toBeGreaterThan(0);
  expect(
    Math.abs(
      geometry.height - Math.max(0, geometry.availableHeight - 6 * geometry.rootTextSize) * 0.5
    )
  ).toBeLessThanOrEqual(2);
  expect(geometry.x).toBeGreaterThanOrEqual(-1);
  expect(geometry.y).toBeGreaterThanOrEqual(-1);
  expect(geometry.right).toBeLessThanOrEqual(geometry.viewportWidth + 1);
  expect(geometry.bottom).toBeLessThanOrEqual(geometry.viewportHeight + 1);
  const close = panel.getByRole('button', { name: 'Close', exact: true });
  await close.scrollIntoViewIfNeeded();
  const closeRect = await close.boundingBox(),
    panelRect = await panel.boundingBox();
  expect(closeRect).not.toBeNull();
  expect(panelRect).not.toBeNull();
  const centerX = closeRect!.x + closeRect!.width / 2,
    centerY = closeRect!.y + closeRect!.height / 2;
  expect(centerX).toBeGreaterThanOrEqual(Math.max(0, panelRect!.x));
  expect(centerX).toBeLessThanOrEqual(
    Math.min(geometry.viewportWidth, panelRect!.x + panelRect!.width)
  );
  expect(centerY).toBeGreaterThanOrEqual(Math.max(0, panelRect!.y));
  expect(centerY).toBeLessThanOrEqual(
    Math.min(geometry.viewportHeight, panelRect!.y + panelRect!.height)
  );
  await capture('close-reachable', { close: closeRect });
  await close.click();
  await expect.poll(() => panel.isVisible()).toBe(false);
  await capture(
    'actually-closed',
    { panelVisible: await panel.isVisible(), triggerFocused: await hasFocus(trigger) },
    previewer
  );
  await expect.poll(() => hasFocus(trigger)).toBe(true);
  await trigger.click();
  await panel.waitFor({ state: 'visible' });
  await page.keyboard.press('Escape');
  await expect.poll(() => panel.isVisible()).toBe(false);
  await capture('reopen-escape-closed', { panelVisible: await panel.isVisible() }, previewer);
}

async function accordionJourney(
  { page, previewer, capture, family }: Journey,
  runtime: RuntimeId = 'react'
) {
  await selectRealRuntime(page, previewer, runtime, '[data-demo-ref="single"]', 1);
  const trigger = previewer.locator('[data-demo-ref="single-lifetime-trigger"]');
  const content = previewer.locator('[data-demo-ref="single-lifetime-content"]');
  const originalTrigger = await trigger.elementHandle();
  if (!originalTrigger) throw new Error('Missing original Accordion Trigger');
  let initializedSize: { width: number; height: number } | null = null;
  const assertReservation = async (state: string) => {
    if (family !== 'liquid-glass') return;
    // Keep the original readiness deadline. A reserved box alone never counts
    // as paint: the exact target must pass the unmodified material/source gates.
    await expect.poll(() => trigger.getAttribute('data-material-quality')).toBe('self-optical');
    expect(await trigger.evaluate((target, original) => target === original, originalTrigger)).toBe(
      true
    );
    const geometry = await trigger.evaluate((element) => {
      const target = element as HTMLElement;
      const heading = target.closest<HTMLElement>('[data-demo-ref="single-lifetime-heading"]');
      const part =
        heading?.querySelector<HTMLElement>('[data-pui-material-reservation]') ??
        heading?.shadowRoot?.querySelector<HTMLElement>('[data-pui-material-reservation]');
      const item = target.closest<HTMLElement>('[data-demo-ref="single-lifetime-item"]');
      const content = item?.querySelector<HTMLElement>('[data-demo-ref="single-lifetime-content"]');
      const root = target.closest<HTMLElement>('[data-demo-ref="single"]');
      const scene = target.closest<HTMLElement>('[data-material-scene]');
      const canvas = scene?.querySelector('canvas[data-material-backdrop]');
      if (!part || !item || !root || !canvas)
        throw new Error('Missing actual owned reservation/source composition');
      const rect = (node: Element) => {
        const r = node.getBoundingClientRect();
        return {
          x: r.x,
          y: r.y,
          width: r.width,
          height: r.height,
          top: r.top,
          right: r.right,
          bottom: r.bottom,
          left: r.left,
        };
      };
      const css = getComputedStyle(part),
        border = getComputedStyle(item);
      return {
        target: rect(target),
        part: rect(part),
        item: rect(item),
        source: rect(canvas),
        root: rect(root),
        rootContainer: getComputedStyle(root).containerType,
        dpr: devicePixelRatio,
        edges: {
          top: parseFloat(css.paddingTop),
          right: parseFloat(css.paddingRight),
          bottom: parseFloat(css.paddingBottom),
          left: parseFloat(css.paddingLeft),
        },
        border: {
          top: parseFloat(border.borderTopWidth),
          right: parseFloat(border.borderRightWidth),
          bottom: parseFloat(border.borderBottomWidth),
          left: parseFloat(border.borderLeftWidth),
        },
        borderPaint: {
          colors: [
            border.borderTopColor,
            border.borderRightColor,
            border.borderBottomColor,
            border.borderLeftColor,
          ],
          styles: [
            border.borderTopStyle,
            border.borderRightStyle,
            border.borderBottomStyle,
            border.borderLeftStyle,
          ],
          radius: [
            border.borderTopLeftRadius,
            border.borderTopRightRadius,
            border.borderBottomRightRadius,
            border.borderBottomLeftRadius,
          ],
          image: border.borderImageSource,
          shadow: border.boxShadow,
          outline: border.outlineStyle,
        },
        content:
          content &&
          getComputedStyle(content).display !== 'none' &&
          content.getBoundingClientRect().height > 0
            ? {
                rect: rect(content),
                padding: [
                  getComputedStyle(content).paddingTop,
                  getComputedStyle(content).paddingRight,
                  getComputedStyle(content).paddingBottom,
                  getComputedStyle(content).paddingLeft,
                ],
              }
            : null,
        semanticRoot:
          target.getAttribute('role') === 'button' && target.hasAttribute('aria-expanded'),
      };
    });
    expect(geometry.semanticRoot).toBe(true);
    const { target, part, item, source, border, edges } = geometry;
    const budget = Math.ceil(Math.max(target.width, target.height) * 0.08 + 1);
    const roi = {
      left: target.left - budget,
      right: target.right + budget,
      top: target.top - budget,
      bottom: target.bottom + budget,
    };
    // This oracle reads actual browser radii independently of the implementation.
    // It refuses percentages/unknown values rather than treating them as pixels.
    const radii = geometry.borderPaint.radius.map((value) => {
      const values = value.split(/\s+/);
      expect(values.every((v) => /^\d+(?:\.\d+)?px$/.test(v))).toBe(true);
      return [parseFloat(values[0]!), parseFloat(values[1] ?? values[0]!)];
    });
    const factor = Math.min(
      1,
      item.width / (radii[0]![0]! + radii[1]![0]!),
      item.width / (radii[3]![0]! + radii[2]![0]!),
      item.height / (radii[0]![1]! + radii[3]![1]!),
      item.height / (radii[1]![1]! + radii[2]![1]!)
    );
    const inner = radii.map(([x, y], i) => [
      Math.max(0, x! * factor - (i === 0 || i === 3 ? border.left : border.right)),
      Math.max(0, y! * factor - (i < 2 ? border.top : border.bottom)),
    ]);
    const clearance = {
      top: Math.max(inner[0]![1]!, inner[1]![1]!) + 1 / geometry.dpr,
      bottom: Math.max(inner[2]![1]!, inner[3]![1]!) + 1 / geometry.dpr,
    };
    expect(edges).toEqual({
      top: budget + clearance.top,
      right: budget,
      bottom: budget + clearance.bottom,
      left: budget,
    });
    expect(target.left - part.left).toBeCloseTo(edges.left, 1);
    expect(target.top - part.top).toBeCloseTo(edges.top, 1);
    expect(part.right - target.right).toBeCloseTo(edges.right, 1);
    expect(part.bottom - target.bottom).toBeCloseTo(edges.bottom, 1);
    expect(roi.left).toBeGreaterThanOrEqual(source.left);
    expect(roi.right).toBeLessThanOrEqual(source.right);
    expect(roi.top).toBeGreaterThanOrEqual(source.top);
    expect(roi.bottom).toBeLessThanOrEqual(source.bottom);
    expect(roi.left).toBeGreaterThanOrEqual(item.left + border.left - 0.02);
    expect(roi.right).toBeLessThanOrEqual(item.right - border.right + 0.02);
    // Full block clearance is past both actual curved corner tangents, including
    // their AA allowance; rectangle-only side inset is insufficient evidence.
    expect(roi.top).toBeGreaterThanOrEqual(item.top + border.top + clearance.top - 0.02);
    expect(roi.bottom).toBeLessThanOrEqual(item.bottom - border.bottom - clearance.bottom + 0.02);
    expect(geometry.borderPaint.styles).toEqual(['solid', 'solid', 'solid', 'solid']);
    expect(geometry.borderPaint.image).toBe('none');
    expect(geometry.borderPaint.shadow).toBe('none');
    expect(geometry.rootContainer).toBe('inline-size');
    if (initializedSize) {
      expect(target.width).toBeCloseTo(initializedSize.width, 1);
      expect(target.height).toBeCloseTo(initializedSize.height, 1);
    }
    if (geometry.content) {
      expect(geometry.content.rect.top).toBeGreaterThanOrEqual(roi.bottom - 0.02);
      expect(geometry.content.rect.width).toBeCloseTo(target.width, 1);
    }
    await capture(
      `reservation-${state}`,
      {
        ...geometry,
        profileFootprint: budget,
        roi,
        outlineClearance: clearance,
        initializedSize,
        sameInputNode: true,
      },
      previewer
    );
  };
  await capture('rest', {}, previewer);
  if (family === 'liquid-glass') {
    const item = previewer.locator('[data-demo-ref="single-lifetime-item"]');
    const nested = previewer.locator('[data-demo-ref="nested-overview-trigger"]');
    // Opaque body content deliberately bounds nested enhancement; this is not a whole-family optical claim.
    await expect
      .poll(() => nested.getAttribute('data-material-reason'))
      .toBe('source-painted-ancestor');
    expect(await nested.getAttribute('data-material-quality')).toBe('opaque-fallback');
    await expect.poll(() => trigger.getAttribute('data-material-quality')).toBe('self-optical');
    initializedSize = await trigger.evaluate((el) => {
      const rect = el.getBoundingClientRect();
      return { width: rect.width, height: rect.height };
    });
    const paint = await trigger.evaluate(observeOwnedMaterialPaint);
    expect(paint.committed).toBe(true);
    expect(paint.carrier).toBe('contact-v1');
    expect(paint.geometryMatches).toBe(true);
    expect(paint.image).toMatch(/data:image\/png/);
    const original = await item.getAttribute('style');
    try {
      // Restore only the old painted-ancestor defect; do not alter admission guards.
      await item.evaluate((el) =>
        (el as HTMLElement).style.setProperty('background-color', '#fff')
      );
      await expect
        .poll(() => trigger.getAttribute('data-material-reason'))
        .toBe('source-painted-ancestor');
      expect(await trigger.getAttribute('data-material-quality')).toBe('opaque-fallback');
      await capture('painted-item-negative-control', {}, previewer);
    } finally {
      await item.evaluate((el, previous) => {
        if (previous === null) el.removeAttribute('style');
        else el.setAttribute('style', previous);
      }, original);
    }
    await expect.poll(() => trigger.getAttribute('data-material-quality')).toBe('self-optical');
    await capture('transparent-item-recovered', {}, previewer);
    await assertReservation('recovered');
  }
  await trigger.click();
  await expect.poll(() => trigger.getAttribute('aria-expanded')).toBe('true');
  await content.waitFor({ state: 'visible' });
  await assertReservation('opened');
  await capture(
    'opened',
    { trigger: await paint(trigger), content: await paint(content) },
    previewer
  );
  await trigger.click();
  await expect.poll(() => content.isVisible()).toBe(false);
  await trigger.click();
  await content.waitFor({ state: 'visible' });
  await assertReservation('reopened');
  await capture('reopened', { content: await paint(content) }, previewer);
  const controlled = previewer.locator('[data-demo-ref="controlled-a-trigger"]');
  await controlled.click();
  expect(await controlled.getAttribute('aria-expanded')).toBe('false');
  await previewer
    .getByRole('button', { name: 'Accept pending request · 接受请求', exact: true })
    .click();
  await expect.poll(() => controlled.getAttribute('aria-expanded')).toBe('true');
  await capture('controlled-accepted', {}, previewer);
}

async function popoverJourney({ page, previewer, family, capture }: Journey) {
  await selectRealRuntime(page, previewer, 'react', '[data-demo-ref="root"]', 1);
  const trigger = previewer.getByRole('button', { name: 'Open Popover', exact: true });
  const panel = page.getByRole('dialog', { name: 'Popover settings', exact: true });
  await page.evaluate(() => document.fonts.ready);
  // Default Shadcn Content authors animate-in (motion.ts), emitted as retained
  // pui-enter by proto-style-css.ts. Other families keep their own motion policy.
  const probe = await trigger.evaluateHandle(
    createPopoverMotionProbe,
    family === 'shadcn' ? 'pui-enter' : null
  );
  let failure: { error: unknown } | undefined;
  try {
    await trigger.click();
    await panel.waitFor({ state: 'visible' });
    await installPopoverNegativeControl(panel, process.env.PUI_FINF_POPOVER_NEGATIVE_CONTROL);
    await probe.evaluate((current) => current.mark('entry-settlement'));
    await captureSettledPopover(probe, panel, family, capture, 'opened');
    await probe.evaluate((current) => current.mark('exit'));
    await panel.getByRole('button', { name: 'Close', exact: true }).click();
    await expect.poll(() => panel.isVisible()).toBe(false);
    await probe.evaluate((current) => current.mark('exit-closed'));
    await capture('closed', { triggerFocused: await hasFocus(trigger) }, previewer);

    await probe.evaluate((current) => current.mark('reversal-entry'));
    await trigger.click();
    await panel.waitFor({ state: 'visible' });
    // Keep the existing Liquid reopen material capture, independently of the
    // immediate-entry Escape observation for the committed families.
    if (family === 'liquid-glass')
      await captureSettledPopover(probe, panel, family, capture, 'reopened');
    await probe.evaluate((current) => current.mark('reversal-exit'));
    await page.keyboard.press('Escape');
    await expect.poll(() => panel.isVisible()).toBe(false);
    await probe.evaluate((current) => current.mark('reversal-closed'));
    await capture('reopen-escape-closed', { triggerFocused: await hasFocus(trigger) }, previewer);

    await page.emulateMedia({ reducedMotion: 'reduce' });
    await probe.evaluate((current) => current.mark('reduced-motion-entry'));
    await trigger.click();
    await panel.waitFor({ state: 'visible' });
    await captureSettledPopover(probe, panel, family, capture, 'reduced-motion-opened');
    await probe.evaluate((current) => current.mark('reduced-motion-exit'));
    await page.keyboard.press('Escape');
    await expect.poll(() => panel.isVisible()).toBe(false);
    await probe.evaluate((current) => current.mark('reduced-motion-closed'));
    await capture('reduced-motion-closed', { triggerFocused: await hasFocus(trigger) }, previewer);
  } catch (error) {
    failure = { error };
  }
  try {
    const motion = await probe.evaluate((current) => current.stop());
    await writeJson(`${family}-popover-motion.json`, {
      revision,
      tree,
      family,
      negativeControl: process.env.PUI_FINF_POPOVER_NEGATIVE_CONTROL ?? null,
      ...motion,
      limitation:
        'Native frames only. Missing retained exit/intermediate/reversal motion remains visible; action labels are not proof of such motion or complete family acceptance.',
    });
    expect(motion.error).toBeNull();
    expect(motion.stopReason).toBe('completed');
  } catch (error) {
    if (!failure) failure = { error };
  }
  try {
    await probe.dispose();
  } catch (error) {
    if (!failure) failure = { error };
  }
  if (failure) throw failure.error;
}

async function alertDialogJourney({ page, previewer, capture }: Journey) {
  await selectRealRuntime(page, previewer, 'react', '[data-demo-ref="root"]', 1);
  const trigger = previewer.getByRole('button', { name: 'Open AlertDialog', exact: true });
  await trigger.click();
  const panel = page.getByRole('alertdialog');
  await panel.waitFor({ state: 'visible' });
  const action = panel.getByRole('button', { name: 'Confirm', exact: true });
  const cancel = panel.getByRole('button', { name: 'Cancel', exact: true });
  const initial = {
    panel: await paint(panel),
    action: await paint(action),
    cancel: await paint(cancel),
    groups: await panel.evaluate((element) =>
      Array.from(element.children).map((child) => {
        const style = getComputedStyle(child);
        const rect = child.getBoundingClientRect();
        return {
          name: child.tagName,
          display: style.display,
          gap: style.gap,
          flexDirection: style.flexDirection,
          flexWrap: style.flexWrap,
          textAlign: style.textAlign,
          width: rect.width,
          height: rect.height,
        };
      })
    ),
  };
  await capture('opened', initial);
  await action.hover();
  await capture('action-hover', { action: await paint(action) });
  await cancel.click();
  await expect.poll(() => panel.isVisible()).toBe(false);
  await capture('cancelled', { triggerFocused: await hasFocus(trigger) }, previewer);
  await trigger.click();
  await panel.waitFor({ state: 'visible' });
  await keyboardReach(page, action);
  await capture('action-keyboard-focus', {
    action: await paint(action),
    focused: await hasFocus(action),
  });
  await page.keyboard.press('Enter');
  await expect.poll(() => panel.isVisible()).toBe(false);
  await capture(
    'confirmed-and-closed',
    { panelVisible: await panel.isVisible(), triggerFocused: await hasFocus(trigger) },
    previewer
  );
  expect(initial.action.background).not.toBe(initial.cancel.background);
  await expect.poll(() => hasFocus(trigger)).toBe(true);
}

async function runtimeTabsJourney({ page, previewer, capture }: Journey) {
  await selectRealRuntime(page, previewer, 'wc', '[data-demo-ref="form"]', 1);
  const hoverFacts = async () =>
    (await runtimeControls(previewer)).getByRole('tab').evaluateAll((tabs) =>
      tabs.map((tab) => ({
        runtime: tab.getAttribute('data-runtime-tab'),
        nativeHovered: tab.matches(':hover'),
        hovered: (tab as HTMLElement & { getExposes(): { hovered: { get(): boolean } } })
          .getExposes()
          .hovered.get(),
      }))
    );
  // Initial selection is a native click. Establish the unhovered state before
  // comparing resting inactive ink with selected ink; hover intentionally uses
  // the same foreground as selection in the underline appearance.
  const hoverBeforeRest = await hoverFacts();
  await page.mouse.move(0, 0);
  await expect
    .poll(async () => (await hoverFacts()).some((tab) => tab.nativeHovered || tab.hovered))
    .toBe(false);
  const hoverAfterRest = await hoverFacts();
  // These Form pages are generic embeds. Observe their real public commit event
  // and DOM ownership, rather than inventing a fixed-family generation counter.
  expect(await previewer.getAttribute('data-projection-mode')).not.toBe('fixed-family');
  const observation = await previewer.evaluateHandle((root) => {
    const events: string[] = [];
    const listener = (event: Event) => {
      if (event.target === root) events.push((event as CustomEvent<{ id: string }>).detail.id);
    };
    root.addEventListener('runtime:changed', listener);
    return { events, stop: () => root.removeEventListener('runtime:changed', listener) };
  });
  const publications = () => observation.evaluate((state) => [...state.events]);
  const labels = async () => (await runtimeControls(previewer)).getByRole('tab').allTextContents();
  const surface = () =>
    previewer
      .locator(
        '.host .pui-runtime-preview-surface[data-demo-ref="__website_runtime_preview_surface__"]'
      )
      .elementHandle();
  const snapshots = [];
  try {
    await capture(
      'wc-rest',
      { labels: await labels(), events: await publications(), hoverBeforeRest, hoverAfterRest },
      previewer
    );
    expect(await labels()).toEqual(Object.values(RUNTIME_LABELS));
    const expectedEvents: string[] = [];
    for (const [from, to, key] of [
      ['wc', 'react', 'Enter'],
      ['react', 'vue', 'Space'],
      ['vue', 'vue2', 'Enter'],
      ['vue2', 'wc', 'Space'],
    ] as const) {
      const previousSurface = await surface();
      expect(previousSurface).not.toBeNull();
      try {
        await (await runtimeTab(previewer, from)).focus();
        await page.keyboard.press('ArrowRight');
        await expect.poll(async () => hasFocus(await runtimeTab(previewer, to))).toBe(true);
        expect(await publications()).toEqual(expectedEvents);
        expect(await previousSurface!.evaluate((element) => element.isConnected)).toBe(true);
        await waitForRealRuntime(previewer, from, '[data-demo-ref="form"]', 1);
        expect(await (await runtimeTab(previewer, from)).getAttribute('aria-selected')).toBe(
          'true'
        );
        await page.keyboard.press(key);
        await waitForRealRuntime(previewer, to, '[data-demo-ref="form"]', 1);
        expectedEvents.push(to);
        await expect.poll(publications).toEqual(expectedEvents);
        expect(await previousSurface!.evaluate((element) => element.isConnected)).toBe(false);
        await expect.poll(async () => hasFocus(await runtimeTab(previewer, to))).toBe(true);
        const selected = await paint(await runtimeTab(previewer, to));
        const inactive = await paint(await runtimeTab(previewer, from));
        snapshots.push({
          from,
          to,
          key,
          events: await publications(),
          oldSurfaceDisconnected: true,
          selected,
          inactive,
          hover: await hoverFacts(),
        });
        await capture(`${to}-selected`, snapshots.at(-1), previewer);
        expect(await labels()).toEqual(Object.values(RUNTIME_LABELS));
        expect(
          await (await runtimeControls(previewer))
            .locator('[role="tab"][aria-selected="true"]')
            .count()
        ).toBe(1);
      } finally {
        await previousSurface?.dispose();
      }
    }
    const finalSurface = await surface();
    try {
      await page.keyboard.press('End');
      await expect.poll(async () => hasFocus(await runtimeTab(previewer, 'vue2'))).toBe(true);
      await page.keyboard.press('Home');
      await expect.poll(async () => hasFocus(await runtimeTab(previewer, 'wc'))).toBe(true);
      expect(await publications()).toEqual(expectedEvents);
      expect(await finalSurface!.evaluate((element) => element.isConnected)).toBe(true);
      await page.setViewportSize({ width: 320, height: 1000 });
      const list = (await runtimeControls(previewer)).getByRole('tablist');
      await page.keyboard.press('End');
      await expect.poll(async () => hasFocus(await runtimeTab(previewer, 'vue2'))).toBe(true);
      await capture('narrow-keyboard-focus', {
        list: await paint(list),
        last: await paint(await runtimeTab(previewer, 'vue2')),
        viewport: page.viewportSize(),
      });
      const narrowList = await paint(list);
      const lastTab = await paint(await runtimeTab(previewer, 'vue2'));
      expect(narrowList.overflowX).toBe('auto');
      expect(narrowList.scrollWidth).toBeGreaterThan(narrowList.clientWidth);
      expect(lastTab.rect.x).toBeGreaterThanOrEqual(narrowList.rect.x - 1);
      expect(lastTab.rect.right).toBeLessThanOrEqual(narrowList.rect.right + 1);
      expect(await publications()).toEqual(expectedEvents);
      expect(await finalSurface!.evaluate((element) => element.isConnected)).toBe(true);
      await waitForRealRuntime(previewer, 'wc', '[data-demo-ref="form"]', 1);
    } finally {
      await finalSurface?.dispose();
    }
  } finally {
    await observation.evaluate((state) => state.stop());
    await observation.dispose();
  }
  // Geometry follows the inspected underline reference; screenshots still need human inspection.
  for (const { selected, inactive } of snapshots) {
    expect(selected.border[2]).toBe('2px');
    expect(selected.radius).toBe('0px');
    expect(selected.padding[1]).toBe('0px');
    expect(selected.padding[3]).toBe('0px');
    expect(hasNoVisibleBoxShadow(selected.shadow), selected.shadow).toBe(true);
    expect(selected.background).toBe('rgba(0, 0, 0, 0)');
    expect(selected.textWidth).toBeGreaterThan(0);
    expect(Math.abs(selected.rect.width - selected.textWidth)).toBeLessThanOrEqual(2);
    expect(selected.color).not.toBe(inactive.color);
  }
}

const cases: Case[] = [
  ...FAMILIES.flatMap((family) => [
    { id: `${family}-form`, group: 'forms', family, component: 'form', run: formJourney },
    {
      id: `${family}-fieldset`,
      group: 'forms',
      family,
      component: 'fieldset',
      run: fieldsetJourney,
    },
    {
      id: `${family}-checkbox-group`,
      group: 'forms',
      family,
      component: 'checkbox-group',
      run: checkboxGroupJourney,
    },
  ]),
  ...CALENDAR_STATES.map((state) => ({
    id: `shadcn-calendar-${state}`,
    group: 'calendar',
    family: 'shadcn' as const,
    component: 'calendar',
    run: (journey: Journey) => calendarJourney(journey, state),
  })),
  ...(['wc', 'react', 'vue', 'vue2'] as const).map((runtime) => ({
    id: `shadcn-calendar-caption-${runtime}`,
    group: 'calendar',
    family: 'shadcn' as const,
    component: 'calendar',
    runtime,
    run: (journey: Journey) => calendarCaptionJourney(journey, runtime),
  })),
  {
    id: 'shadcn-drawer',
    group: 'modal-overlays',
    family: 'shadcn',
    component: 'drawer',
    run: drawerJourney,
  },
  ...FAMILIES.flatMap((family) => [
    {
      id: `${family}-accordion`,
      group: 'disclosure-overlays',
      family,
      component: 'accordion',
      run: accordionJourney,
    },
    {
      id: `${family}-popover`,
      group: 'disclosure-overlays',
      family,
      component: 'popover',
      run: popoverJourney,
    },
    {
      id: `${family}-alert-dialog`,
      group: 'modal-overlays',
      family,
      component: 'alert-dialog',
      run: alertDialogJourney,
    },
    {
      id: `${family}-runtime-tabs`,
      group: 'runtime-tabs',
      family,
      component: 'runtime-tabs',
      run: runtimeTabsJourney,
    },
  ]),
  ...(['wc', 'react', 'vue', 'vue2'] as const).map((runtime) => ({
    id: `liquid-glass-accordion-${runtime}-reservation`,
    group: 'liquid-reservation',
    family: 'liquid-glass' as const,
    component: 'accordion',
    runtime,
    run: (journey: Journey) => accordionJourney(journey, runtime),
  })),
];
const selectedCases = cases.filter(
  (testCase) => !requestedGroup || testCase.group === requestedGroup
);
if (!selectedCases.length) throw new Error(`Unknown Finf evidence group: ${requestedGroup}`);

beforeAll(async () => {
  await mkdir(output, { recursive: true });
  await writeJson('source.json', {
    revision,
    tree,
    requestedGroup: requestedGroup ?? 'all',
    cases: selectedCases.map(({ id, group, family, component, runtime }) => ({
      id,
      group,
      family,
      component,
      runtime: component === 'runtime-tabs' ? Object.keys(RUNTIME_LABELS) : (runtime ?? 'react'),
      route: routeFor(family, component === 'runtime-tabs' ? 'form' : component),
    })),
    phase: 'Planned at setup; each terminal case receipt is the result authority.',
  });
  try {
    if (process.env.GITHUB_ACTIONS !== 'true' || !process.env.CANDIDATE_SHA)
      throw new Error(
        'This receipt suite runs only in its official GitHub Actions workflow. Local source/type tests do not launch a native browser.'
      );
    expect(revision).toBe(process.env.CANDIDATE_SHA);
    expect(execFileSync('git', ['diff', '--name-only', 'HEAD']).toString().trim()).toBe('');
    // Readiness of a single component must not prevent unrelated cases from navigating.
    baseUrl = await startServer('/');
    if (!['127.0.0.1', 'localhost', '[::1]'].includes(new URL(baseUrl).hostname))
      throw new Error('Evidence may visit only this job’s own loopback documentation server.');
    browser = await chromium.launch({
      executablePath: await chromeExecutable(),
      headless: true,
      chromiumSandbox: true,
      args: ['--disable-dev-shm-usage'],
    });
  } catch (error) {
    for (const testCase of selectedCases)
      await writeJson(`${testCase.id}.json`, {
        revision,
        tree,
        case: testCase.id,
        group: testCase.group,
        result: 'blocked-before-browser',
        error: String(error),
        screenshots: [],
        reason: 'No running page was available; no image is claimed.',
      });
    throw error;
  }
}, 180_000);
afterAll(async () => {
  await browser?.close();
  await stopServer();
}, 30_000);

describe('Finf source-bound representative feature screenshots', () => {
  for (const testCase of selectedCases)
    it(
      testCase.id,
      () => runCase(testCase),
      testCase.component === 'runtime-tabs' ? 180_000 : 120_000
    );
});
