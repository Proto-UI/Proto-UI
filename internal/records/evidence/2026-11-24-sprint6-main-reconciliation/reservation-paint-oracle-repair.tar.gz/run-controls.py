from pathlib import Path
from datetime import datetime, timezone
import subprocess, hashlib, json
repo = Path('/workspace/scratch/466206816961/proto-ui-s6')
out = Path(__file__).parent
tests = [
    'apps/www/src/content/docs/zh-cn/material-paint-observation.test.ts',
    'apps/www/src/content/docs/zh-cn/liquid-material-observation.test.ts',
    'apps/www/src/content/docs/zh-cn/finf-representative-features-evidence.test.ts',
    'apps/www/src/content/docs/zh-cn/finf-representative-workflow-selection.test.ts',
]
inputs = tests + [
    'apps/www/src/content/docs/zh-cn/finf-representative-features.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/material-paint-observation.ts',
    'apps/www/src/content/docs/zh-cn/liquid-material-observation.ts',
    '.github/workflows/finf-representative-features-evidence.yml',
]
hashes = lambda: {p: hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in inputs}
command = ['corepack', 'pnpm@10.32.1', 'exec', 'vitest', 'run', *tests, '--reporter=default', '--reporter=json', '--outputFile='+str(out/'controls.json'), '--maxWorkers=1', '--minWorkers=1', '--no-file-parallelism']
receipt = {'startedAt':datetime.now(timezone.utc).isoformat(), 'cwd':str(repo), 'command':command, 'selectedFiles':tests, 'sourceBefore':hashes(), 'externalTimeoutSeconds':180, 'testDeadlines':'unchanged defaults and source deadlines', 'browserExecuted':False}
with (out/'controls.log').open('w') as log:
    try: receipt['exitCode'] = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT, timeout=180).returncode
    except subprocess.TimeoutExpired: receipt['exitCode'] = 124; receipt['timedOut'] = True
receipt['finishedAt'] = datetime.now(timezone.utc).isoformat()
receipt['sourceAfter'] = hashes()
receipt['sourceInputsUnchanged'] = receipt['sourceBefore'] == receipt['sourceAfter']
if (out/'controls.json').exists():
    report = json.loads((out/'controls.json').read_text())
    receipt['counts'] = {k:report[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests','success']}
    receipt['actualFiles'] = [{'file':f['name'],'assertions':len(f['assertionResults']), 'statuses':sorted(set(a['status'] for a in f['assertionResults']))} for f in report['testResults']]
    assert sorted(str(repo/t) for t in tests) == sorted(f['name'] for f in report['testResults']), 'Missing or extra selected file'
(out/'controls-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
raise SystemExit(receipt['exitCode'] if receipt['sourceInputsUnchanged'] else 1)
