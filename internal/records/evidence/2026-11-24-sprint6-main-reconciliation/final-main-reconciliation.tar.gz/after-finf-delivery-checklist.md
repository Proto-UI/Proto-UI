# Finf complete-delivery checklist

Tracker: [#870](https://github.com/Proto-UI/Proto-UI/issues/870). Status: **work in progress, not merge-ready**. 68 initial unchecked items: 55 full delivery items and 13 existing-PR closeout/carry items.

Release boundary: [the 0.3 plan](../governance/release-0.3-plan.md) commits Base, Shadcn, Brutalist and Lucide scope; Bootstrap 2.3.2 and Liquid Glass remain WIP / Experimental for 0.4. The four-family tracking matrix retains its [recorded 0.4 deferral](https://github.com/Proto-UI/Proto-UI/issues/870#issuecomment-6684477558). Original mixed criteria and evidence debts remain separately accountable; deferral, source presence and this documentation update do not complete them or close #870.

Current scope interpretation: the single Shadcn family column is only an inheritance inventory. Eight modern styles and independently retained New York have separate source and acceptance cells in the [active matrix](prototype-coverage-matrix.md). Complete source evidence, current exact-head CI, contribution rights and independent review remain required. Independently acceptable dependent stacked PRs are allowed by the 2026-10-22 tracker decision.

## Retained original delivery scope

Current owner explicitly selects groups 1–6 and complete four-family projection coverage, including Bootstrap 2.3.2 and Liquid Glass, plus Overlay scrollbar coordinate repair. This is project-owned scope, not automatic adoption of comparison projects.

No item is checked for an incremental/simple implementation. Every required acceptance dimension must be verified. Equal or higher aggregate counts do not compensate for missing Base identity mappings. No placeholder, CSS-only skin, invented identity or not-applicable shortcut waives the explicitly selected scope. Final Finf delivery requires every in-scope new and existing deliverable to leave Draft, including previously draft Table. Complete applicable prototype/module contracts, lifecycle evidence, all four projections, Adapter/Compiler/GPUI and documentation/consumer evidence, then perform formal promotion. Source-only or private draft availability is not the final state. Intermediate checkpoints remain WIP; this instruction grants no npm publication permission.

## One checkbox means all acceptance gates

1. Complete governed semantic contract and explicit negative boundaries; no simplified interim version marked done

2. Final Base identities mapped atom-by-atom to Shadcn, Neobrutalism (package brutalist), Bootstrap 2.3.2 and Liquid Glass

3. Every applicable Module/Host Capability/Adapter profile and generated Compiler target has verified conformance; unsupported/omitted scope explicitly governed, never counted as a pass

4. Complete source/dist exports, build and type artifacts, install/consumer smoke from local packed artifacts, package/CLI surface, DemoSpec, reachable real demos and bilingual documentation. Registry publication is a separate explicitly authorized release action. Every newly introduced prototype also requires a catalog-driven interactive homepage exhibition and state set built from its real atoms. Bootstrap 2.3.2 Classic and Liquid Glass homepage selection remains ineligible until complete Base atomic parity and mature applicable evidence.

5. Controlled/uncontrolled, disabled/readOnly, keyboard/pointer/touch/IME where applicable, accessibility, repeated mount/unmount and interruption paths

6. Real-input runtime and commit-bound visual evidence for all affected compositions/overlay dependants and four design languages

7. Focused and applicable aggregate tests plus trusted exact-head CI/DCO and independent review; no outstanding applicable findings

8. Complete the per-family and per-atomic-identity safe-area/spacing audit and accepted repairs across Base and all four design languages: explicit viewport/container/leaf ownership, outer and inner spacing, long content, scaling and keyboard reflow. Use family-specific evidence, not a universal inset or an unsupported not-applicable shortcut.

9. Deliver GPUI with the same applicable semantic capability as the other runtimes for this prototype and all four design-language projections: actual input, focus, accessibility, layout, theme, demo and Adapter/Compiler evidence. Existing private/experimental status or unsupported diagnostics are current gaps, never a final omission or completion shortcut. The homepage Runtime entry must launch or display actual native GPUI with an explicit integration boundary and native input/layout/accessibility evidence; a Web projection must never impersonate GPUI.

Each final Base atomic identity has a real conforming identity/implementation and evidence in each of four design families. Each final family count and atomic identity count is at least Base. Existing extra family identities may remain but cannot compensate for a missing Base mapping.

To be derived from governed completed semantics; 32 deliverables are not automatically 32 new Base families. Date Picker/Data Table/Message Scroller may be proper compositions.

## Full feature and projection items

- [ ] **deliver.label**: label. Group: 1. Existing work: [#389](https://github.com/Proto-UI/Proto-UI/issues/389), [#865](https://github.com/Proto-UI/Proto-UI/issues/865). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.field**: field. Group: 1. Existing work: [#389](https://github.com/Proto-UI/Proto-UI/issues/389), [#865](https://github.com/Proto-UI/Proto-UI/issues/865). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.fieldset**: fieldset. Group: 1. Existing work: [#389](https://github.com/Proto-UI/Proto-UI/issues/389), [#865](https://github.com/Proto-UI/Proto-UI/issues/865). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.form**: form. Group: 1. Existing work: [#389](https://github.com/Proto-UI/Proto-UI/issues/389), [#865](https://github.com/Proto-UI/Proto-UI/issues/865). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.checkbox-group**: checkbox-group. Group: 1. Existing work: [#389](https://github.com/Proto-UI/Proto-UI/issues/389), [#865](https://github.com/Proto-UI/Proto-UI/issues/865). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.autocomplete**: autocomplete. Group: 2. Existing work: [#388](https://github.com/Proto-UI/Proto-UI/issues/388), [#495](https://github.com/Proto-UI/Proto-UI/issues/495), [#832](https://github.com/Proto-UI/Proto-UI/issues/832). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.combobox**: combobox. Group: 2. Existing work: [#388](https://github.com/Proto-UI/Proto-UI/issues/388), [#495](https://github.com/Proto-UI/Proto-UI/issues/495), [#832](https://github.com/Proto-UI/Proto-UI/issues/832). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.command**: command. Group: 2. Existing work: [#388](https://github.com/Proto-UI/Proto-UI/issues/388), [#495](https://github.com/Proto-UI/Proto-UI/issues/495), [#832](https://github.com/Proto-UI/Proto-UI/issues/832). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.toggle-group**: toggle-group. Group: 2. Existing work: [#388](https://github.com/Proto-UI/Proto-UI/issues/388), [#495](https://github.com/Proto-UI/Proto-UI/issues/495), [#832](https://github.com/Proto-UI/Proto-UI/issues/832). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.toolbar**: toolbar. Group: 2. Existing work: [#388](https://github.com/Proto-UI/Proto-UI/issues/388), [#495](https://github.com/Proto-UI/Proto-UI/issues/495), [#832](https://github.com/Proto-UI/Proto-UI/issues/832). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.menubar**: menubar. Group: 2. Existing work: [#388](https://github.com/Proto-UI/Proto-UI/issues/388), [#495](https://github.com/Proto-UI/Proto-UI/issues/495), [#832](https://github.com/Proto-UI/Proto-UI/issues/832). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.navigation-menu**: navigation-menu. Group: 2. Existing work: [#388](https://github.com/Proto-UI/Proto-UI/issues/388), [#495](https://github.com/Proto-UI/Proto-UI/issues/495), [#832](https://github.com/Proto-UI/Proto-UI/issues/832). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.context-menu**: context-menu. Group: 2. Existing work: [#388](https://github.com/Proto-UI/Proto-UI/issues/388), [#495](https://github.com/Proto-UI/Proto-UI/issues/495), [#832](https://github.com/Proto-UI/Proto-UI/issues/832). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.collapsible**: collapsible. Group: 3. Existing work: [#388](https://github.com/Proto-UI/Proto-UI/issues/388), [#548](https://github.com/Proto-UI/Proto-UI/issues/548), [#549](https://github.com/Proto-UI/Proto-UI/issues/549), [#688](https://github.com/Proto-UI/Proto-UI/issues/688), [#835](https://github.com/Proto-UI/Proto-UI/issues/835). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.accordion**: accordion. Group: 3. Existing work: [#388](https://github.com/Proto-UI/Proto-UI/issues/388), [#548](https://github.com/Proto-UI/Proto-UI/issues/548), [#549](https://github.com/Proto-UI/Proto-UI/issues/549), [#688](https://github.com/Proto-UI/Proto-UI/issues/688), [#835](https://github.com/Proto-UI/Proto-UI/issues/835). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.popover**: popover. Group: 4. Existing work: [#495](https://github.com/Proto-UI/Proto-UI/issues/495), [#522](https://github.com/Proto-UI/Proto-UI/issues/522), [#640](https://github.com/Proto-UI/Proto-UI/issues/640). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.alert-dialog**: alert-dialog. Group: 4. Existing work: [#495](https://github.com/Proto-UI/Proto-UI/issues/495), [#522](https://github.com/Proto-UI/Proto-UI/issues/522), [#640](https://github.com/Proto-UI/Proto-UI/issues/640). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.drawer**: drawer. Group: 4. Existing work: [#495](https://github.com/Proto-UI/Proto-UI/issues/495), [#522](https://github.com/Proto-UI/Proto-UI/issues/522), [#640](https://github.com/Proto-UI/Proto-UI/issues/640). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.toast**: toast. Group: 4. Existing work: [#495](https://github.com/Proto-UI/Proto-UI/issues/495), [#522](https://github.com/Proto-UI/Proto-UI/issues/522), [#640](https://github.com/Proto-UI/Proto-UI/issues/640). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.slider**: slider. Group: 5. Existing work: [#389](https://github.com/Proto-UI/Proto-UI/issues/389), [#495](https://github.com/Proto-UI/Proto-UI/issues/495), [#498](https://github.com/Proto-UI/Proto-UI/issues/498). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.number-field**: number-field. Group: 5. Existing work: [#389](https://github.com/Proto-UI/Proto-UI/issues/389), [#495](https://github.com/Proto-UI/Proto-UI/issues/495), [#498](https://github.com/Proto-UI/Proto-UI/issues/498). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.progress**: progress. Group: 5. Existing work: [#389](https://github.com/Proto-UI/Proto-UI/issues/389), [#495](https://github.com/Proto-UI/Proto-UI/issues/495), [#498](https://github.com/Proto-UI/Proto-UI/issues/498). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.meter**: meter. Group: 5. Existing work: [#389](https://github.com/Proto-UI/Proto-UI/issues/389), [#495](https://github.com/Proto-UI/Proto-UI/issues/495), [#498](https://github.com/Proto-UI/Proto-UI/issues/498). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.input-otp**: input-otp. Group: 5. Existing work: [#389](https://github.com/Proto-UI/Proto-UI/issues/389), [#495](https://github.com/Proto-UI/Proto-UI/issues/495), [#498](https://github.com/Proto-UI/Proto-UI/issues/498). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.calendar**: calendar. Group: 5. Existing work: [#377](https://github.com/Proto-UI/Proto-UI/issues/377). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.date-picker**: date-picker. Group: 5. Existing work: [#377](https://github.com/Proto-UI/Proto-UI/issues/377). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.resizable**: resizable. Group: 6. Existing work: [#519](https://github.com/Proto-UI/Proto-UI/issues/519), [#520](https://github.com/Proto-UI/Proto-UI/issues/520), [#521](https://github.com/Proto-UI/Proto-UI/issues/521), [#522](https://github.com/Proto-UI/Proto-UI/issues/522), [#523](https://github.com/Proto-UI/Proto-UI/issues/523), [#746](https://github.com/Proto-UI/Proto-UI/issues/746). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.carousel**: carousel. Group: 6. Existing work: [#519](https://github.com/Proto-UI/Proto-UI/issues/519), [#520](https://github.com/Proto-UI/Proto-UI/issues/520), [#521](https://github.com/Proto-UI/Proto-UI/issues/521), [#522](https://github.com/Proto-UI/Proto-UI/issues/522), [#523](https://github.com/Proto-UI/Proto-UI/issues/523), [#746](https://github.com/Proto-UI/Proto-UI/issues/746). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.message-scroller**: message-scroller. Group: 6. Existing work: [#519](https://github.com/Proto-UI/Proto-UI/issues/519), [#520](https://github.com/Proto-UI/Proto-UI/issues/520), [#521](https://github.com/Proto-UI/Proto-UI/issues/521), [#522](https://github.com/Proto-UI/Proto-UI/issues/522), [#523](https://github.com/Proto-UI/Proto-UI/issues/523), [#623](https://github.com/Proto-UI/Proto-UI/issues/623), [#746](https://github.com/Proto-UI/Proto-UI/issues/746). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.tree**: tree. Group: 6. Existing work: [#523](https://github.com/Proto-UI/Proto-UI/issues/523). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.virtual-list**: virtual-list. Group: 6. Existing work: [#521](https://github.com/Proto-UI/Proto-UI/issues/521). All gates above are mandatory; partial commits do not check this item.

- [ ] **deliver.data-table**: data-table. Group: 6. Existing work: [#513](https://github.com/Proto-UI/Proto-UI/issues/513), [#516](https://github.com/Proto-UI/Proto-UI/issues/516), [#517](https://github.com/Proto-UI/Proto-UI/issues/517), [#518](https://github.com/Proto-UI/Proto-UI/issues/518), [#526](https://github.com/Proto-UI/Proto-UI/issues/526), [#527](https://github.com/Proto-UI/Proto-UI/issues/527), [#528](https://github.com/Proto-UI/Proto-UI/issues/528), [#529](https://github.com/Proto-UI/Proto-UI/issues/529). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.async-region**: async-region. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.button**: button. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.checkbox**: checkbox. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.dialog**: dialog. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.dropdown**: dropdown. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.hover-card**: hover-card. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.image**: image. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.input**: input. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.live-region**: live-region. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.radio-group**: radio-group. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.scroll-area**: scroll-area. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.select**: select. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.separator**: separator. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.surface**: surface. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.switch**: switch. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.table**: table. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.tabs**: tabs. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.text**: text. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.textarea**: textarea. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.toggle**: toggle. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.tooltip**: tooltip. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **baseline.transition**: transition. Group: existing-base-parity. Existing work: [#792](https://github.com/Proto-UI/Proto-UI/issues/792), [#799](https://github.com/Proto-UI/Proto-UI/issues/799). All gates above are mandatory; partial commits do not check this item.

- [ ] **repair.overlay-scrollbar-coordinate**: Overlay coordinate offset when scrollbars change. Group: reported-regression. Existing work: [#870](https://github.com/Proto-UI/Proto-UI/issues/870), [#587](https://github.com/Proto-UI/Proto-UI/issues/587), [#683](https://github.com/Proto-UI/Proto-UI/issues/683), [#684](https://github.com/Proto-UI/Proto-UI/issues/684). All gates above are mandatory; partial commits do not check this item.

## Cross-matrix safe-area and spacing acceptance

Every implemented Base and four-family atomic identity, including Lucide dependency behavior where it participates. Source coverage and confirmed findings first, then finish actual Finf implementation and real-input validation; the audit is not the deliverable end state. No blanket 16px rule or unexplained not-applicable mass disposition.

- Dialog acceptance: Reference-aware Shadcn edge clearance and maximum inline/block extent; preserve long-content scrolling

- Dialog acceptance: Test enlarged fonts/zoom, keyboard-reduced available space and applicable safe-area facts

- Dialog acceptance: Implement the reusable prototype/projection/host responsibility, not a homepage-only CSS patch

## Homepage exhibition and eligibility

- [ ] Every newly introduced prototype has a catalog-driven, genuinely interactive homepage recipe and state set using its actual atoms, with source-bound interaction, accessibility and visual evidence.

- [ ] Bootstrap 2.3.2 Classic and Liquid Glass become homepage-selectable only after complete Base identity/atomic parity and mature applicable source, tests, demos/docs, optics and native capability; keep eligibility closed until accepted.

- [ ] GPUI appears as a homepage Runtime through an actual native running/exhibition entry with a clear launch or embedding boundary. Verify real native input/layout/accessibility and never present a Web projection as GPUI.

Source-stage additions do not establish homepage eligibility. No unfinished family or Web-only substitute is enabled as an accepted native Runtime.

## GPUI same-capability delivery

Every final Base atomic identity and its Shadcn/Neobrutalism/Bootstrap2.3.2/LiquidGlass projection, with semantic parity and real native usability. Substantial T0 native implementation already exists; row-specific capability/native evidence is being reconciled. Do not infer absence from the stale native/gpui README or imply full support from current private peer metadata.

Two coexisting intents are required: explicit Liquid Glass uses a self-implemented effect; ordinary adaptive native blur prefers the actual system/version native mechanism. Do not silently substitute them. Govern sampling, ownership, performance and accessibility/capability fallback; Apple native effects do not discharge the explicit self-implemented intent.

The structured ledger has 468 required GPUI Base-identity × design-family cells. They remain unassessed/pending until exact implementation and native evidence are mapped; existing code is not erased and missing code is not marked not-applicable.

## Previous work remains equal priority

- [ ] **prior-pr.775** [#775](https://github.com/Proto-UI/Proto-UI/issues/775): continue-current-owner; integrate normally if exact-head ready; otherwise retain code/failures/open criteria as equal-priority Finf follow-up. Preserve current authorization, provenance and topic owner; integrate only a verified frozen candidate..

- [ ] **prior-pr.832** [#832](https://github.com/Proto-UI/Proto-UI/issues/832): continue-current-owner; integrate normally if exact-head ready; otherwise retain code/failures/open criteria as equal-priority Finf follow-up. Preserve current authorization, provenance and topic owner; integrate only a verified frozen candidate..

- [ ] **prior-pr.863** [#863](https://github.com/Proto-UI/Proto-UI/issues/863): continue-current-owner; integrate normally if exact-head ready; otherwise retain code/failures/open criteria as equal-priority Finf follow-up. Preserve current authorization, provenance and topic owner; integrate only a verified frozen candidate..

- [ ] **prior-pr.858** [#858](https://github.com/Proto-UI/Proto-UI/issues/858): continue-current-owner; integrate normally if exact-head ready; otherwise retain code/failures/open criteria as equal-priority Finf follow-up. Preserve current authorization, provenance and topic owner; integrate only a verified frozen candidate..

- [ ] **prior-pr.868** [#868](https://github.com/Proto-UI/Proto-UI/issues/868): continue-current-owner; integrate normally if exact-head ready; otherwise retain code/failures/open criteria as equal-priority Finf follow-up. Preserve current authorization, provenance and topic owner; integrate only a verified frozen candidate..

- [x] **prior-pr.857** [#857](https://github.com/Proto-UI/Proto-UI/issues/857): Accepted bounded prior-work closeout at 5dab3a9e; source, applicable official evidence and independent technical review are retained. [Closeout review](https://github.com/Proto-UI/Proto-UI/blob/9395d2deb012934976ab155b9461aa0356583247/internal/records/2026-10-10-finf-three-prior-closeouts.md). No full Finf, prototype lifecycle or merge approval is implied.

- [x] **prior-pr.855** [#855](https://github.com/Proto-UI/Proto-UI/issues/855): Accepted original finite padding-box/border/composed-blend repair at reviewed 8989403; broader Liquid Card and optical/native acceptance remain separate.. The independent record URL is rebound to its actual published commit before PR advancement. Only the original prior-pr.855 scope is closed..

- [x] **prior-pr.862** [#862](https://github.com/Proto-UI/Proto-UI/issues/862): Accepted original bounded Template/Scroll/Focus budget transaction at reviewed 8989403; later strict-budget overages remain open.. The immutable record source is rebound to the actual published record commit during publication. This closes only prior-pr.862 and does not certify current package sizes, full Finf acceptance or merge approval..

- [x] **prior-pr.867** [#867](https://github.com/Proto-UI/Proto-UI/issues/867): Accepted bounded prior-work closeout at 5dab3a9e; source, applicable official evidence and independent technical review are retained. [Closeout review](https://github.com/Proto-UI/Proto-UI/blob/9395d2deb012934976ab155b9461aa0356583247/internal/records/2026-10-10-finf-three-prior-closeouts.md). No full Finf, prototype lifecycle or merge approval is implied.

- [ ] **prior-pr.869** [#869](https://github.com/Proto-UI/Proto-UI/issues/869): continue-current-owner; integrate normally if exact-head ready; otherwise retain code/failures/open criteria as equal-priority Finf follow-up. Preserve current authorization, provenance and topic owner; integrate only a verified frozen candidate..

- [ ] **prior-pr.808** [#808](https://github.com/Proto-UI/Proto-UI/issues/808): continue-current-owner; integrate normally if exact-head ready; otherwise retain code/failures/open criteria as equal-priority Finf follow-up. Preserve current authorization, provenance and topic owner; integrate only a verified frozen candidate..

- [ ] **prior-pr.835** [#835](https://github.com/Proto-UI/Proto-UI/issues/835): continue-current-owner; integrate normally if exact-head ready; otherwise retain code/failures/open criteria as equal-priority Finf follow-up. Preserve current authorization, provenance and topic owner; integrate only a verified frozen candidate..

- [x] **prior-pr.871** [#871](https://github.com/Proto-UI/Proto-UI/issues/871): Accepted bounded prior-work closeout at 5dab3a9e; source, applicable official evidence and independent technical review are retained. [Closeout review](https://github.com/Proto-UI/Proto-UI/blob/9395d2deb012934976ab155b9461aa0356583247/internal/records/2026-10-10-finf-three-prior-closeouts.md). No full Finf, prototype lifecycle or merge approval is implied.

The shared benchmark bootstrap repair is tracked by #871 and remains with its current owner until an exact frozen integration receipt is accepted. #826 and #846 are **NEVER MERGE**, evidence-only branches.

## Retained prior-work acceptance details

Existing 41-calibration profile: 790 raw / 782 achieved / 8 declared rounded-clip unmeasured / 40 not executed; does not close the six later criteria.

- **775-paint-presence** (unmet): achieved/painted require bounded actual paint presence, including real descendant ink; reject fully transparent nonzero geometry and unsupported/hidden cases. Do not treat nontransparent text color without glyphs as ink. [source](https://github.com/Proto-UI/Proto-UI/pull/775#discussion_r4197650211)

- **775-fillable-svg** (unmet): Withhold fill ratio unless the finite geometry profile proves fillable area; reject line/degenerate paths, retain stroke and pixels, and use fillable circle/rect positive controls. [source](https://github.com/Proto-UI/Proto-UI/pull/775#discussion_r4197650234)

- **775-unique-editor** (unmet): Collect composed light/shadow editor candidates and require exactly one; reject missing/duplicate/foreign targets and retain four-Adapter real single-editor positives. [source](https://github.com/Proto-UI/Proto-UI/pull/775#discussion_r4197650245)

- **775-decoration-fingerprint** (unmet): Fingerprint applicable text-decoration line/color/thickness/style/offset paint changes, including CSSOM changes without attribute/rect mutation between image and fact collection; preserve inheritance/descendant snapshot scope. [source](https://github.com/Proto-UI/Proto-UI/pull/775#discussion_r4197650258)

- **775-reading-route-reset** (unmet): Diagnose the repeated local route.fetch ECONNRESET at radio-group-light-normal-1279-text100; retain both failed attempts and network refusal boundary, prove all 16 real cases without blind retries or readiness widening. Shared keepalive is a hypothesis, not established cause. [source](https://github.com/Proto-UI/Proto-UI/actions/runs/37490381731)

- **775-no-js-timeout** (unmet): Use phase diagnostics from frozen b3601697c4daef1854b64d64a6edb2102a398e6d to establish the actual cause of the 5s no-JS overview timeout. Preserve assertions/time budget and cleanup; a diagnostic commit is not the repair. [source](https://github.com/Proto-UI/Proto-UI/actions/runs/37490381737)

The accepted #858 source is carried by the current main merge. Its earlier scoped results remain source-bound; the two newly requested runtime-demo acceptance subitems below are still unmet.

- **runtime-demo.vertical-spacing-parity** (unmet): Reproduce and repair WC-to-React/Vue vertical-spacing changes for identical family/content/viewport/theme/font/state, with source-owned cause and matched real-input geometry/screenshots. [source](https://github.com/Proto-UI/Proto-UI/pull/872)

- **runtime-demo.region-loading-mask** (unmet): Replace the bottom runtime-switch notice with a preview-region mask composed from actual Proto UI primitives; verify repeated/superseded switches, failure/retry, cancellation/unmount, keyboard/pointer, focus and accessibility, without stale completion or trapped focus. [source](https://github.com/Proto-UI/Proto-UI/pull/872)

Shared CI hygiene (unmet): Real API reconciliation of 27 Issues plus PR580 showed only #377.updatedAt changed; governance fields and reviewed owners were identical. Coordinate one semantic-versus-observation timestamp correction; preserve failure and real API evidence, do not blindly refresh multiple branches or weaken owner/state validation. [failure](https://github.com/Proto-UI/Proto-UI/actions/runs/37501442006/job/112399177604)

## Atomic parity obligations

Each cell below is required. An existing draft inheritance mapping is source evidence only and has not passed the full Finf acceptance gate.

| Base atomic identity | Shadcn | Neobrutalism (brutalist) | Bootstrap 2.3.2 | Liquid Glass |
| --- | --- | --- | --- | --- |
| P-BASE-ACCORDION | P-SHADCN-ACCORDION | P-BRUTALIST-ACCORDION | P-BOOTSTRAP-2-3-2-ACCORDION | P-LIQUID-GLASS-ACCORDION |
| P-BASE-ACCORDION-CONTENT | P-SHADCN-ACCORDION-CONTENT | P-BRUTALIST-ACCORDION-CONTENT | P-BOOTSTRAP-2-3-2-ACCORDION-CONTENT | P-LIQUID-GLASS-ACCORDION-CONTENT |
| P-BASE-ACCORDION-HEADING | P-SHADCN-ACCORDION-HEADING | P-BRUTALIST-ACCORDION-HEADING | P-BOOTSTRAP-2-3-2-ACCORDION-HEADING | P-LIQUID-GLASS-ACCORDION-HEADING |
| P-BASE-ACCORDION-ITEM | P-SHADCN-ACCORDION-ITEM | P-BRUTALIST-ACCORDION-ITEM | P-BOOTSTRAP-2-3-2-ACCORDION-ITEM | P-LIQUID-GLASS-ACCORDION-ITEM |
| P-BASE-ACCORDION-TRIGGER | P-SHADCN-ACCORDION-TRIGGER | P-BRUTALIST-ACCORDION-TRIGGER | P-BOOTSTRAP-2-3-2-ACCORDION-TRIGGER | P-LIQUID-GLASS-ACCORDION-TRIGGER |
| P-BASE-ALERT-DIALOG | P-SHADCN-ALERT-DIALOG | required missing | P-BOOTSTRAP-2-3-2-ALERT-DIALOG, P-BOOTSTRAP-2-3-2-ALERT-DIALOG-FOOTER | P-LIQUID-GLASS-ALERT-DIALOG |
| P-BASE-ASYNC-REGION | P-SHADCN-ASYNC-REGION | P-BRUTALIST-ASYNC-REGION | P-BOOTSTRAP-2-3-2-ASYNC-REGION | P-LIQUID-GLASS-ASYNC-REGION |
| P-BASE-AUTOCOMPLETE | P-SHADCN-AUTOCOMPLETE | required missing | P-BOOTSTRAP-2-3-2-AUTOCOMPLETE | P-LIQUID-GLASS-AUTOCOMPLETE |
| P-BASE-BUTTON | P-SHADCN-BUTTON | P-BRUTALIST-BUTTON | P-BOOTSTRAP-2-3-2-BUTTON | P-LIQUID-GLASS-BUTTON |
| P-BASE-CALENDAR | P-SHADCN-CALENDAR | required missing | P-BOOTSTRAP-2-3-2-CALENDAR | P-LIQUID-GLASS-CALENDAR |
| P-BASE-CAROUSEL | P-SHADCN-CAROUSEL | required missing | P-BOOTSTRAP-2-3-2-CAROUSEL | P-LIQUID-GLASS-CAROUSEL |
| P-BASE-CHECKBOX | P-SHADCN-CHECKBOX | P-BRUTALIST-CHECKBOX | P-BOOTSTRAP-2-3-2-CHECKBOX | P-LIQUID-GLASS-CHECKBOX |
| P-BASE-CHECKBOX-INDICATOR | P-SHADCN-CHECKBOX-INDICATOR | P-BRUTALIST-CHECKBOX-INDICATOR | P-BOOTSTRAP-2-3-2-CHECKBOX-INDICATOR | P-LIQUID-GLASS-CHECKBOX-INDICATOR |
| P-BASE-CHECKBOX-GROUP | P-SHADCN-CHECKBOX-GROUP | required missing | P-BOOTSTRAP-2-3-2-CHECKBOX-GROUP | P-LIQUID-GLASS-CHECKBOX-GROUP |
| P-BASE-COLLAPSIBLE | P-SHADCN-COLLAPSIBLE | P-BRUTALIST-COLLAPSIBLE | P-BOOTSTRAP-2-3-2-COLLAPSIBLE | P-LIQUID-GLASS-COLLAPSIBLE |
| P-BASE-COLLAPSIBLE-CONTENT | P-SHADCN-COLLAPSIBLE-CONTENT | P-BRUTALIST-COLLAPSIBLE-CONTENT | P-BOOTSTRAP-2-3-2-COLLAPSIBLE-CONTENT | P-LIQUID-GLASS-COLLAPSIBLE-CONTENT |
| P-BASE-COLLAPSIBLE-TRIGGER | P-SHADCN-COLLAPSIBLE-TRIGGER | P-BRUTALIST-COLLAPSIBLE-TRIGGER | P-BOOTSTRAP-2-3-2-COLLAPSIBLE-TRIGGER | P-LIQUID-GLASS-COLLAPSIBLE-TRIGGER |
| P-BASE-COMBOBOX | P-SHADCN-COMBOBOX | required missing | P-BOOTSTRAP-2-3-2-COMBOBOX | P-LIQUID-GLASS-COMBOBOX |
| P-BASE-COMMAND | P-SHADCN-COMMAND | required missing | P-BOOTSTRAP-2-3-2-COMMAND | P-LIQUID-GLASS-COMMAND |
| P-BASE-CONTEXT-MENU | P-SHADCN-CONTEXT-MENU | required missing | P-BOOTSTRAP-2-3-2-CONTEXT-MENU | P-LIQUID-GLASS-CONTEXT-MENU |
| P-BASE-DATA-TABLE | P-SHADCN-DATA-TABLE | required missing | P-BOOTSTRAP-2-3-2-DATA-TABLE | P-LIQUID-GLASS-DATA-TABLE |
| P-BASE-DATA-TABLE-HEADER-ROW | P-SHADCN-DATA-TABLE-HEADER-ROW | P-BRUTALIST-DATA-TABLE-HEADER-ROW | P-BOOTSTRAP-2-3-2-DATA-TABLE-HEADER-ROW | P-LIQUID-GLASS-DATA-TABLE-HEADER-ROW |
| P-BASE-DATE-PICKER | P-SHADCN-DATE-PICKER | required missing | P-BOOTSTRAP-2-3-2-DATE-PICKER | P-LIQUID-GLASS-DATE-PICKER |
| P-BASE-DIALOG | P-SHADCN-DIALOG | P-BRUTALIST-DIALOG | P-BOOTSTRAP-2-3-2-DIALOG, P-BOOTSTRAP-2-3-2-DIALOG-FOOTER, P-BOOTSTRAP-2-3-2-DIALOG-HEADER | P-LIQUID-GLASS-DIALOG |
| P-BASE-DIALOG-CLOSE | P-SHADCN-DIALOG-CLOSE, P-SHADCN-DIALOG-CLOSE-ICON | P-BRUTALIST-DIALOG-CLOSE, P-BRUTALIST-DIALOG-CLOSE-ICON | P-BOOTSTRAP-2-3-2-DIALOG-CLOSE, P-BOOTSTRAP-2-3-2-DIALOG-CLOSE-ICON | P-LIQUID-GLASS-DIALOG-CLOSE |
| P-BASE-DIALOG-CONTENT | P-SHADCN-DIALOG-CONTENT | P-BRUTALIST-DIALOG-CONTENT | P-BOOTSTRAP-2-3-2-DIALOG-CONTENT | P-LIQUID-GLASS-DIALOG-CONTENT |
| P-BASE-DIALOG-DESCRIPTION | P-SHADCN-DIALOG-DESCRIPTION | P-BRUTALIST-DIALOG-DESCRIPTION | P-BOOTSTRAP-2-3-2-DIALOG-DESCRIPTION | P-LIQUID-GLASS-DIALOG-DESCRIPTION |
| P-BASE-DIALOG-MASK | P-SHADCN-DIALOG-MASK | P-BRUTALIST-DIALOG-MASK | P-BOOTSTRAP-2-3-2-DIALOG-MASK | P-LIQUID-GLASS-DIALOG-MASK |
| P-BASE-DIALOG-TITLE | P-SHADCN-DIALOG-TITLE | P-BRUTALIST-DIALOG-TITLE | P-BOOTSTRAP-2-3-2-DIALOG-TITLE | P-LIQUID-GLASS-DIALOG-TITLE |
| P-BASE-DIALOG-TRIGGER | P-SHADCN-DIALOG-TRIGGER | P-BRUTALIST-DIALOG-TRIGGER | P-BOOTSTRAP-2-3-2-DIALOG-TRIGGER | P-LIQUID-GLASS-DIALOG-TRIGGER |
| P-BASE-DRAWER | P-SHADCN-DRAWER | required missing | P-BOOTSTRAP-2-3-2-DRAWER | P-LIQUID-GLASS-DRAWER |
| P-BASE-DRAWER-ACCEPTED-SIDE | required missing | required missing | required missing | required missing |
| P-BASE-DRAWER-FOOTER | P-SHADCN-DRAWER-FOOTER | required missing | P-BOOTSTRAP-2-3-2-DRAWER-FOOTER | P-LIQUID-GLASS-DRAWER-FOOTER |
| P-BASE-DRAWER-HEADER | P-SHADCN-DRAWER-HEADER | required missing | P-BOOTSTRAP-2-3-2-DRAWER-HEADER | P-LIQUID-GLASS-DRAWER-HEADER |
| P-BASE-DRAWER-SCROLL | required missing | required missing | required missing | required missing |
| P-BASE-DROPDOWN-MENU | P-SHADCN-DROPDOWN-MENU | P-BRUTALIST-DROPDOWN-MENU | P-BOOTSTRAP-2-3-2-DROPDOWN-MENU | P-LIQUID-GLASS-DROPDOWN-MENU |
| P-BASE-DROPDOWN-MENU-CONTENT | P-SHADCN-DROPDOWN-MENU-CONTENT | P-BRUTALIST-DROPDOWN-MENU-CONTENT | P-BOOTSTRAP-2-3-2-DROPDOWN-MENU-CONTENT | P-LIQUID-GLASS-DROPDOWN-MENU-CONTENT |
| P-BASE-DROPDOWN-MENU-GROUP | P-SHADCN-DROPDOWN-MENU-GROUP | required missing | P-BOOTSTRAP-2-3-2-DROPDOWN-MENU-GROUP | P-LIQUID-GLASS-DROPDOWN-MENU-GROUP |
| P-BASE-DROPDOWN-MENU-ITEM | P-SHADCN-DROPDOWN-MENU-ITEM | P-BRUTALIST-DROPDOWN-MENU-ITEM | P-BOOTSTRAP-2-3-2-DROPDOWN-MENU-ITEM | P-LIQUID-GLASS-DROPDOWN-MENU-ITEM |
| P-BASE-DROPDOWN-MENU-LABEL | P-SHADCN-DROPDOWN-MENU-LABEL | required missing | P-BOOTSTRAP-2-3-2-DROPDOWN-MENU-LABEL | P-LIQUID-GLASS-DROPDOWN-MENU-LABEL |
| P-BASE-DROPDOWN-MENU-SEPARATOR | P-SHADCN-DROPDOWN-MENU-SEPARATOR | required missing | P-BOOTSTRAP-2-3-2-DROPDOWN-MENU-SEPARATOR | P-LIQUID-GLASS-DROPDOWN-MENU-SEPARATOR |
| P-BASE-DROPDOWN-MENU-SHORTCUT | P-SHADCN-DROPDOWN-MENU-SHORTCUT | required missing | P-BOOTSTRAP-2-3-2-DROPDOWN-MENU-SHORTCUT | P-LIQUID-GLASS-DROPDOWN-MENU-SHORTCUT |
| P-BASE-DROPDOWN-MENU-TRIGGER | P-SHADCN-DROPDOWN-MENU-TRIGGER | P-BRUTALIST-DROPDOWN-MENU-TRIGGER | P-BOOTSTRAP-2-3-2-DROPDOWN-MENU-TRIGGER | P-LIQUID-GLASS-DROPDOWN-MENU-TRIGGER |
| P-BASE-FIELD | P-SHADCN-FIELD | P-BRUTALIST-FIELD | P-BOOTSTRAP-2-3-2-FIELD | P-LIQUID-GLASS-FIELD |
| P-BASE-FIELD-CHOICES | P-SHADCN-FIELD-CHOICES | P-BRUTALIST-FIELD-CHOICES | required missing | required missing |
| P-BASE-FIELD-CONTROL | P-SHADCN-FIELD-CONTROL | P-BRUTALIST-FIELD-CONTROL | P-BOOTSTRAP-2-3-2-FIELD-CONTROL | P-LIQUID-GLASS-FIELD-CONTROL |
| P-BASE-FIELD-DESCRIPTION | P-SHADCN-FIELD-DESCRIPTION | P-BRUTALIST-FIELD-DESCRIPTION | P-BOOTSTRAP-2-3-2-FIELD-DESCRIPTION | P-LIQUID-GLASS-FIELD-DESCRIPTION |
| P-BASE-FIELD-ERROR | P-SHADCN-FIELD-ERROR | P-BRUTALIST-FIELD-ERROR | P-BOOTSTRAP-2-3-2-FIELD-ERROR | P-LIQUID-GLASS-FIELD-ERROR |
| P-BASE-FIELD-LABEL | P-SHADCN-FIELD-LABEL | P-BRUTALIST-FIELD-LABEL | P-BOOTSTRAP-2-3-2-FIELD-LABEL | P-LIQUID-GLASS-FIELD-LABEL |
| P-BASE-FIELD-VALIDITY | P-SHADCN-FIELD-VALIDITY | P-BRUTALIST-FIELD-VALIDITY | P-BOOTSTRAP-2-3-2-FIELD-VALIDITY | P-LIQUID-GLASS-FIELD-VALIDITY |
| P-BASE-FIELDSET | P-SHADCN-FIELDSET | P-BRUTALIST-FIELDSET | P-BOOTSTRAP-2-3-2-FIELDSET | P-LIQUID-GLASS-FIELDSET |
| P-BASE-FIELDSET-DESCRIPTION | P-SHADCN-FIELDSET-DESCRIPTION | P-BRUTALIST-FIELDSET-DESCRIPTION | P-BOOTSTRAP-2-3-2-FIELDSET-DESCRIPTION | P-LIQUID-GLASS-FIELDSET-DESCRIPTION |
| P-BASE-FIELDSET-LEGEND | P-SHADCN-FIELDSET-LEGEND | P-BRUTALIST-FIELDSET-LEGEND | P-BOOTSTRAP-2-3-2-FIELDSET-LEGEND | P-LIQUID-GLASS-FIELDSET-LEGEND |
| P-BASE-FORM | P-SHADCN-FORM | required missing | P-BOOTSTRAP-2-3-2-FORM | P-LIQUID-GLASS-FORM |
| P-BASE-HOVER-CARD | P-SHADCN-HOVER-CARD | P-BRUTALIST-HOVER-CARD | P-BOOTSTRAP-2-3-2-HOVER-CARD | P-LIQUID-GLASS-HOVER-CARD |
| P-BASE-HOVER-CARD-CONTENT | P-SHADCN-HOVER-CARD-CONTENT | P-BRUTALIST-HOVER-CARD-CONTENT | P-BOOTSTRAP-2-3-2-HOVER-CARD-CONTENT | P-LIQUID-GLASS-HOVER-CARD-CONTENT |
| P-BASE-HOVER-CARD-TRIGGER | P-SHADCN-HOVER-CARD-TRIGGER | P-BRUTALIST-HOVER-CARD-TRIGGER | P-BOOTSTRAP-2-3-2-HOVER-CARD-TRIGGER | P-LIQUID-GLASS-HOVER-CARD-TRIGGER |
| P-BASE-IMAGE | P-SHADCN-IMAGE | P-BRUTALIST-IMAGE | P-BOOTSTRAP-2-3-2-IMAGE | P-LIQUID-GLASS-IMAGE |
| P-BASE-INPUT | P-SHADCN-INPUT, P-SHADCN-INPUT-SHELL-CONTROL | P-BRUTALIST-INPUT | P-BOOTSTRAP-2-3-2-INPUT | P-LIQUID-GLASS-INPUT |
| P-BASE-INPUT-OTP | P-SHADCN-INPUT-OTP | required missing | P-BOOTSTRAP-2-3-2-INPUT-OTP | P-LIQUID-GLASS-INPUT-OTP |
| P-BASE-LABEL | P-SHADCN-LABEL | P-BRUTALIST-LABEL | P-BOOTSTRAP-2-3-2-LABEL | P-LIQUID-GLASS-LABEL |
| P-BASE-LIVE-REGION | P-SHADCN-LIVE-REGION | P-BRUTALIST-LIVE-REGION | P-BOOTSTRAP-2-3-2-LIVE-REGION | P-LIQUID-GLASS-LIVE-REGION |
| P-BASE-MENUBAR | P-SHADCN-MENUBAR | required missing | P-BOOTSTRAP-2-3-2-MENUBAR | P-LIQUID-GLASS-MENUBAR |
| P-BASE-MESSAGE-SCROLLER | P-SHADCN-MESSAGE-SCROLLER | required missing | P-BOOTSTRAP-2-3-2-MESSAGE-SCROLLER | P-LIQUID-GLASS-MESSAGE-SCROLLER |
| P-BASE-METER | P-SHADCN-METER | required missing | P-BOOTSTRAP-2-3-2-METER | P-LIQUID-GLASS-METER |
| P-BASE-NATIVE-FILE-INPUT | required missing | required missing | required missing | required missing |
| P-BASE-NAVIGATION-MENU | P-SHADCN-NAVIGATION-MENU | required missing | P-BOOTSTRAP-2-3-2-NAVIGATION-MENU | P-LIQUID-GLASS-NAVIGATION-MENU |
| P-BASE-NUMBER-FIELD | P-SHADCN-NUMBER-FIELD | P-BRUTALIST-NUMBER-FIELD | P-BOOTSTRAP-2-3-2-NUMBER-FIELD | P-LIQUID-GLASS-NUMBER-FIELD |
| P-BASE-POPOVER | P-SHADCN-POPOVER | required missing | P-BOOTSTRAP-2-3-2-POPOVER | P-LIQUID-GLASS-POPOVER |
| P-BASE-PROGRESS | P-SHADCN-PROGRESS | required missing | P-BOOTSTRAP-2-3-2-PROGRESS | P-LIQUID-GLASS-PROGRESS |
| P-BASE-RADIO-GROUP | P-SHADCN-RADIO-GROUP | P-BRUTALIST-RADIO-GROUP | P-BOOTSTRAP-2-3-2-RADIO-GROUP | P-LIQUID-GLASS-RADIO-GROUP |
| P-BASE-RADIO-GROUP-INDICATOR | P-SHADCN-RADIO-GROUP-INDICATOR | P-BRUTALIST-RADIO-GROUP-INDICATOR | P-BOOTSTRAP-2-3-2-RADIO-GROUP-INDICATOR | P-LIQUID-GLASS-RADIO-GROUP-INDICATOR |
| P-BASE-RADIO-GROUP-ITEM | P-SHADCN-RADIO-GROUP-ITEM | P-BRUTALIST-RADIO-GROUP-ITEM | P-BOOTSTRAP-2-3-2-RADIO-GROUP-ITEM | P-LIQUID-GLASS-RADIO-GROUP-ITEM |
| P-BASE-RESIZABLE | P-SHADCN-RESIZABLE | required missing | P-BOOTSTRAP-2-3-2-RESIZABLE | P-LIQUID-GLASS-RESIZABLE |
| P-BASE-SCROLL-AREA | P-SHADCN-SCROLL-AREA | P-BRUTALIST-SCROLL-AREA | P-BOOTSTRAP-2-3-2-SCROLL-AREA | P-LIQUID-GLASS-SCROLL-AREA |
| P-BASE-SCROLL-AREA-SCROLLBAR | P-SHADCN-SCROLL-AREA-SCROLLBAR | P-BRUTALIST-SCROLL-AREA-SCROLLBAR | P-BOOTSTRAP-2-3-2-SCROLL-AREA-SCROLLBAR | P-LIQUID-GLASS-SCROLL-AREA-SCROLLBAR |
| P-BASE-SCROLL-AREA-THUMB | P-SHADCN-SCROLL-AREA-THUMB | P-BRUTALIST-SCROLL-AREA-THUMB | P-BOOTSTRAP-2-3-2-SCROLL-AREA-THUMB | P-LIQUID-GLASS-SCROLL-AREA-THUMB |
| P-BASE-SCROLL-AREA-VIEWPORT | P-SHADCN-SCROLL-AREA-VIEWPORT | P-BRUTALIST-SCROLL-AREA-VIEWPORT | P-BOOTSTRAP-2-3-2-SCROLL-AREA-VIEWPORT | P-LIQUID-GLASS-SCROLL-AREA-VIEWPORT |
| P-BASE-SELECT | P-SHADCN-SELECT | P-BRUTALIST-SELECT | P-BOOTSTRAP-2-3-2-SELECT | P-LIQUID-GLASS-SELECT |
| P-BASE-SELECT-ALIGNMENT-PARTS | P-SHADCN-SELECT-ALIGNMENT-PARTS | required missing | P-BOOTSTRAP-2-3-2-SELECT-ALIGNMENT-PARTS | P-LIQUID-GLASS-SELECT-ALIGNMENT-PARTS |
| P-BASE-SELECT-CONTENT | P-SHADCN-SELECT-CONTENT | P-BRUTALIST-SELECT-CONTENT | P-BOOTSTRAP-2-3-2-SELECT-CONTENT | P-LIQUID-GLASS-SELECT-CONTENT |
| P-BASE-SELECT-ITEM | P-SHADCN-SELECT-ITEM | P-BRUTALIST-SELECT-ITEM | P-BOOTSTRAP-2-3-2-SELECT-ITEM | P-LIQUID-GLASS-SELECT-ITEM |
| P-BASE-SELECT-STRUCTURAL-PARTS | P-SHADCN-SELECT-STRUCTURAL-PARTS | required missing | P-BOOTSTRAP-2-3-2-SELECT-STRUCTURAL-PARTS | P-LIQUID-GLASS-SELECT-STRUCTURAL-PARTS |
| P-BASE-SELECT-TRIGGER | P-SHADCN-SELECT-TRIGGER | P-BRUTALIST-SELECT-TRIGGER | P-BOOTSTRAP-2-3-2-SELECT-TRIGGER | P-LIQUID-GLASS-SELECT-TRIGGER |
| P-BASE-SELECT-VALUE | P-SHADCN-SELECT-VALUE | P-BRUTALIST-SELECT-VALUE | P-BOOTSTRAP-2-3-2-SELECT-VALUE | P-LIQUID-GLASS-SELECT-VALUE |
| P-BASE-SELECTABLE-ROW | required missing | required missing | required missing | required missing |
| P-BASE-SEPARATOR | P-SHADCN-SEPARATOR | P-BRUTALIST-SEPARATOR | P-BOOTSTRAP-2-3-2-SEPARATOR | P-LIQUID-GLASS-SEPARATOR |
| P-BASE-SLIDER | P-SHADCN-SLIDER | required missing | P-BOOTSTRAP-2-3-2-SLIDER | P-LIQUID-GLASS-SLIDER |
| P-BASE-SLIDER-FIELD-THUMB | P-SHADCN-SLIDER-FIELD-THUMB | required missing | P-BOOTSTRAP-2-3-2-SLIDER-FIELD-THUMB | P-LIQUID-GLASS-SLIDER-FIELD-THUMB |
| P-BASE-SLIDER-THUMB | P-SHADCN-SLIDER-THUMB | required missing | P-BOOTSTRAP-2-3-2-SLIDER-THUMB | P-LIQUID-GLASS-SLIDER-THUMB |
| P-BASE-SLIDER-VALUES | P-SHADCN-SLIDER-VALUES | P-BRUTALIST-SLIDER-VALUES | P-BOOTSTRAP-2-3-2-SLIDER-VALUES | P-LIQUID-GLASS-SLIDER-VALUES |
| P-BASE-SURFACE | P-SHADCN-SURFACE | P-BRUTALIST-SURFACE | P-BOOTSTRAP-2-3-2-SURFACE | P-LIQUID-GLASS-SURFACE |
| P-BASE-SWITCH | P-SHADCN-SWITCH | P-BRUTALIST-SWITCH | P-BOOTSTRAP-2-3-2-SWITCH | P-LIQUID-GLASS-SWITCH |
| P-BASE-SWITCH-THUMB | P-SHADCN-SWITCH-THUMB | P-BRUTALIST-SWITCH-THUMB | P-BOOTSTRAP-2-3-2-SWITCH-THUMB | P-LIQUID-GLASS-SWITCH-THUMB |
| P-BASE-TABLE | P-SHADCN-TABLE | P-BRUTALIST-TABLE | P-BOOTSTRAP-2-3-2-TABLE | P-LIQUID-GLASS-TABLE |
| P-BASE-TABLE-CAPTION | P-SHADCN-TABLE-CAPTION | P-BRUTALIST-TABLE-CAPTION | P-BOOTSTRAP-2-3-2-TABLE-CAPTION | P-LIQUID-GLASS-TABLE-CAPTION |
| P-BASE-TABLE-CELL | P-SHADCN-TABLE-CELL | P-BRUTALIST-TABLE-CELL | P-BOOTSTRAP-2-3-2-TABLE-CELL | P-LIQUID-GLASS-TABLE-CELL |
| P-BASE-TABLE-HEADER-CELL | P-SHADCN-TABLE-HEADER-CELL | P-BRUTALIST-TABLE-HEADER-CELL | P-BOOTSTRAP-2-3-2-TABLE-HEADER-CELL | P-LIQUID-GLASS-TABLE-HEADER-CELL |
| P-BASE-TABLE-ROW | P-SHADCN-TABLE-ROW | P-BRUTALIST-TABLE-ROW | P-BOOTSTRAP-2-3-2-TABLE-ROW | P-LIQUID-GLASS-TABLE-ROW |
| P-BASE-TABS | P-SHADCN-TABS | P-BRUTALIST-TABS | P-BOOTSTRAP-2-3-2-TABS | P-LIQUID-GLASS-TABS |
| P-BASE-TABS-CONTENT | P-SHADCN-TABS-CONTENT | P-BRUTALIST-TABS-CONTENT | P-BOOTSTRAP-2-3-2-TABS-CONTENT | P-LIQUID-GLASS-TABS-CONTENT |
| P-BASE-TABS-INDICATOR | P-SHADCN-TABS-INDICATOR | required missing | P-BOOTSTRAP-2-3-2-TABS-INDICATOR | P-LIQUID-GLASS-TABS-INDICATOR |
| P-BASE-TABS-LIST | P-SHADCN-TABS-LIST | P-BRUTALIST-TABS-LIST | P-BOOTSTRAP-2-3-2-TABS-LIST | P-LIQUID-GLASS-TABS-LIST |
| P-BASE-TABS-TRIGGER | P-SHADCN-TABS-TRIGGER | P-BRUTALIST-TABS-TRIGGER | P-BOOTSTRAP-2-3-2-TABS-TRIGGER | P-LIQUID-GLASS-TABS-TRIGGER |
| P-BASE-TEXT | P-SHADCN-TEXT | P-BRUTALIST-TEXT | P-BOOTSTRAP-2-3-2-TEXT | P-LIQUID-GLASS-TEXT |
| P-BASE-TEXTAREA | P-SHADCN-TEXTAREA | P-BRUTALIST-TEXTAREA | P-BOOTSTRAP-2-3-2-TEXTAREA | P-LIQUID-GLASS-TEXTAREA |
| P-BASE-TOAST | P-SHADCN-TOAST | required missing | P-BOOTSTRAP-2-3-2-TOAST | P-LIQUID-GLASS-TOAST |
| P-BASE-TOGGLE | P-SHADCN-TOGGLE | P-BRUTALIST-TOGGLE | P-BOOTSTRAP-2-3-2-TOGGLE | P-LIQUID-GLASS-TOGGLE |
| P-BASE-TOGGLE-GROUP | P-SHADCN-TOGGLE-GROUP | P-BRUTALIST-TOGGLE-GROUP | P-BOOTSTRAP-2-3-2-TOGGLE-GROUP | P-LIQUID-GLASS-TOGGLE-GROUP |
| P-BASE-TOOLBAR | P-SHADCN-TOOLBAR | required missing | P-BOOTSTRAP-2-3-2-TOOLBAR | P-LIQUID-GLASS-TOOLBAR |
| P-BASE-TOOLTIP | P-SHADCN-TOOLTIP | P-BRUTALIST-TOOLTIP | P-BOOTSTRAP-2-3-2-TOOLTIP | P-LIQUID-GLASS-TOOLTIP |
| P-BASE-TOOLTIP-CONTENT | P-SHADCN-TOOLTIP-CONTENT | P-BRUTALIST-TOOLTIP-CONTENT | P-BOOTSTRAP-2-3-2-TOOLTIP-CONTENT | P-LIQUID-GLASS-TOOLTIP-CONTENT |
| P-BASE-TOOLTIP-GROUP | P-SHADCN-TOOLTIP-GROUP | P-BRUTALIST-TOOLTIP-GROUP | P-BOOTSTRAP-2-3-2-TOOLTIP-GROUP | P-LIQUID-GLASS-TOOLTIP-GROUP |
| P-BASE-TOOLTIP-TRIGGER | P-SHADCN-TOOLTIP-TRIGGER | P-BRUTALIST-TOOLTIP-TRIGGER | P-BOOTSTRAP-2-3-2-TOOLTIP-TRIGGER | P-LIQUID-GLASS-TOOLTIP-TRIGGER |
| P-BASE-TRANSITION | P-SHADCN-TRANSITION | P-BRUTALIST-TRANSITION | P-BOOTSTRAP-2-3-2-TRANSITION | P-LIQUID-GLASS-TRANSITION |
| P-BASE-TREE | P-SHADCN-TREE | required missing | P-BOOTSTRAP-2-3-2-TREE | P-LIQUID-GLASS-TREE |
| P-BASE-VIRTUAL-LIST | P-SHADCN-VIRTUAL-LIST | required missing | P-BOOTSTRAP-2-3-2-VIRTUAL-LIST | P-LIQUID-GLASS-VIRTUAL-LIST |

## Integration discipline

The original integration routing below is historical. Current topic ownership and real dependencies determine bounded stacked PRs; the historical single-PR route does not prohibit them. No routing change waives the retained acceptance conditions.

dot Finf integrator; topic owners provide frozen patches; only integrator CAS-updates the Finf branch

For a carry, retain frozen source, original author/provenance, exact failures, unresolved criteria and evidence links. Do not close an unfinished item as fixed. The integration owner revalidates exact heads, dependencies, independent review, CI, DCO, repository protection and actual semantic boundaries before publication or integration.

- Required Overlay evidence: Reproduce the actual user-reported scroll/scrollbar coordinate drift before assigning root cause

- Required Overlay evidence: Exercise body and nested scrollers, portal/container coordinates, scrollbar appearance/removal, modal scroll lock, RTL, zoom/transforms and resize; verify every anchored/dependent overlay

- Required Overlay evidence: Preserve original reproduction, failing baseline and repaired exact-head evidence

Overlay root cause is not yet reproduced. The scrollbar-coordinate regression must retain actual baseline, repaired real-input journeys and every dependent anchored/portaled composition; it cannot be checked from a guessed offset patch.

Two coexisting intents are required: explicit Liquid Glass uses a self-implemented effect; ordinary adaptive native blur prefers the actual system/version native mechanism. Do not silently substitute them. Govern sampling, ownership, performance and accessibility/capability fallback; Apple native effects do not discharge the explicit self-implemented intent.

Bootstrap and Liquid Glass receive complete source/dist/type/package/consumer readiness in this task. Existing private flags are not a permanent exemption. Inspect release workflows before changing flags/exports; do not implicitly trigger registry publishing. Actual registry release or new credentials remain separately gated.

Agent: dot
