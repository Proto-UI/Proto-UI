import datetime
import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path('/workspace/scratch/466206816961/proto-ui-s6')
OUT = pathlib.Path('/workspace/scratch/466206816961/s6-evidence/postmerge-validation')
files = [
    'apps/www/src/content/docs/accordion-demo-layout.test.ts',
    'apps/www/src/components/PrototypePreviewer/demo-material-stages.test.ts',
    'apps/www/src/components/PrototypePreviewer/projection-composition.material-stages.test.ts',
    'apps/www/src/components/PrototypePreviewer/runtime-preview-surface.test.ts',
    'apps/www/src/components/PrototypePreviewer/preview-material-scene.test.ts',
    'packages/cli/test/proto-style-css.test.ts',
]
steps = [
    ('merged-stage-consumers', ['corepack', 'pnpm@10.32.1', 'exec', 'vitest', 'run', *files, '--maxWorkers=1', '--minWorkers=1', '--no-file-parallelism', '--reporter=default', '--reporter=json', '--outputFile=' + str(OUT / 'merged-stage-consumers.json')]),
    ('styles-preset-check', ['corepack', 'pnpm@10.32.1', 'check:styles:preset']),
    ('cli-build', ['node', 'scripts/build/public-packages.mjs', '--package', '@proto.ui/cli']),
    ('website-generate', ['node', 'apps/www/scripts/generate-website-prototype-tokens.mjs']),
    ('type-contracts', ['node', 'node_modules/typescript/bin/tsc', '-p', 'internal/contracts/types/tsconfig.json', '--noEmit']),
    ('coverage-binding-check', ['node', 'scripts/coverage-matrices/prototype-coverage.mjs', '--check']),
]
statuses = []
for label, command in steps:
    if label == 'website-generate' and any(s['label'] == 'cli-build' and s['exitCode'] != 0 for s in statuses):
        statuses.append({'label': label, 'status': 'not-executed-cli-build-failed'})
        continue
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    print(json.dumps({'label': label, 'startedAt': started}), flush=True)
    with (OUT / (label + '.stdout.log')).open('wb') as stdout, (OUT / (label + '.stderr.log')).open('wb') as stderr:
        result = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr)
    status = {'label': label, 'command': command, 'startedAt': started, 'endedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exitCode': result.returncode}
    statuses.append(status)
    (OUT / 'status.json').write_text(json.dumps(statuses, indent=2) + '\n')
    print(json.dumps(status), flush=True)
before = json.loads((OUT / 'source-before.json').read_text())
after = {**before, 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), 'dirty': subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True), 'files': {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in before['files']}}
(OUT / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
print(json.dumps({'inputChanges': [p for p in before['files'] if before['files'][p] != after['files'][p]], 'dirty': after['dirty']}), flush=True)
