import pathlib,subprocess,hashlib,json,datetime
C=pathlib.Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation');H=pathlib.Path('/home/ezra/proto-ui-sprint1-current-20261124-56f6684');p=H/'packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs'
def blob(b):return hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()
raw=p.read_bytes();assert blob(raw)=='07599e7406e5d5d32e62bada802a3bb561afa002'
old=subprocess.check_output(['git','show','0b0b861bf18a18d20aa2f0e627ba477dbab463e5:packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs'],cwd=H);assert blob(old)=='044d15396a309d1372d9dbf4fb10368cfeb99541'
try:
 p.write_bytes(old);subprocess.run(['python3',str(C/'executed-lane.py'),str(C/'gpui-after-duplicate-removal-baseline-spec.json')])
finally:
 assert blob(p.read_bytes())=='044d15396a309d1372d9dbf4fb10368cfeb99541';p.write_bytes(raw)
 (C/'gpui-after-duplicate-removal-restored.json').write_text(json.dumps({'restoredBlob':blob(p.read_bytes()),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
