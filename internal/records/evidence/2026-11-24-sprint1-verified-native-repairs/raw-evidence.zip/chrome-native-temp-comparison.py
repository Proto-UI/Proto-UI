import subprocess,pathlib,tempfile,json,datetime,os
C=pathlib.Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation');short=pathlib.Path('/home/ezra/s1-56f6684-tmp')
assert not short.exists();short.mkdir(mode=0o700)
records=[]
for name,tmp,trace in [('long',C/'task-temp',True),('short',short,False)]:
 profile=pathlib.Path(tempfile.mkdtemp(prefix='chrome-',dir=tmp))
 args=['/home/ezra/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome','--headless=new','--disable-dev-shm-usage','--enable-logging=stderr','--no-first-run','--no-default-browser-check','--user-data-dir='+str(profile),'--dump-dom','about:blank']
 if trace:args=['strace','-o',str(C/'chrome-native-long-temp.strace'),'-e','trace=bind,connect,mkdir,openat,unlink,write,writev,newfstatat,readlink,tgkill',*args]
 env=os.environ.copy();env['TMPDIR']=str(tmp);start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (C/('chrome-native-'+name+'-temp.stdout')).open('x') as out,(C/('chrome-native-'+name+'-temp.stderr')).open('x') as err:
  try:r=subprocess.run(args,stdout=out,stderr=err,env=env,timeout=20);result={'exit':r.returncode}
  except subprocess.TimeoutExpired:result={'deadlineReached':True}
 result.update(name=name,args=args,TMPDIR=str(tmp),startedAt=start,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),profile=str(profile));records.append(result)
(C/'chrome-native-temp-comparison.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records))
