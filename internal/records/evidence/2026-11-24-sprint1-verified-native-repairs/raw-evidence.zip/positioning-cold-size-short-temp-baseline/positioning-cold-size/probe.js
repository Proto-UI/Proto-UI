(() => {
  // packages/modules/positioning/src/web/owned-style-lease.ts
  var styleOwners = /* @__PURE__ */ new WeakMap();
  function ownStyles(target) {
    const fields = /* @__PURE__ */ new Map();
    let owners = styleOwners.get(target);
    if (!owners) {
      owners = /* @__PURE__ */ new Map();
      styleOwners.set(target, owners);
    }
    const currentOwners = owners;
    let lost = false;
    const matches = (name, record) => target.style.getPropertyValue(name) === record.written && target.style.getPropertyPriority(name) === "";
    return {
      isCurrent() {
        return !lost && Array.from(fields).every(
          ([name, record]) => currentOwners.get(name) === record && matches(name, record)
        );
      },
      write(name, value) {
        if (lost) return false;
        let record = fields.get(name);
        if (record && (currentOwners.get(name) !== record || !matches(name, record))) {
          lost = true;
          return false;
        }
        if (!record) {
          const prior = currentOwners.get(name);
          const inherit = prior && matches(name, prior);
          record = {
            before: inherit ? prior.before : target.style.getPropertyValue(name),
            priority: inherit ? prior.priority : target.style.getPropertyPriority(name),
            written: ""
          };
          fields.set(name, record);
          currentOwners.set(name, record);
        }
        target.style.setProperty(name, value);
        record.written = target.style.getPropertyValue(name);
        return true;
      },
      restore() {
        for (const [name, record] of fields) {
          if (currentOwners.get(name) !== record) continue;
          currentOwners.delete(name);
          if (!matches(name, record)) continue;
          if (record.before) target.style.setProperty(name, record.before, record.priority);
          else target.style.removeProperty(name);
        }
        fields.clear();
      }
    };
  }
  function hasOwnedStyle(target, name) {
    const claim = styleOwners.get(target)?.get(name);
    return !!claim && target.style.getPropertyValue(name) === claim.written && target.style.getPropertyPriority(name) === "";
  }

  // packages/modules/positioning/src/web/border-box-size-lease.ts
  var nextSizeLeaseGeneration = 0;
  var admittedSizeGenerations = /* @__PURE__ */ new WeakMap();
  function createBorderBoxSizeLease(reference, targets, current) {
    const generation = ++nextSizeLeaseGeneration;
    const ownerDocument = reference.ownerDocument;
    const sizeFields = ["width", "height", "inline-size", "block-size"];
    const hasAuthoredSizing = (target) => sizeFields.some(
      (name) => !!target.style.getPropertyValue(name) && !hasOwnedStyle(target, name)
    ) || !!target.style.getPropertyValue("box-sizing") && !hasOwnedStyle(target, "box-sizing");
    const authoredConflict = targets.some(hasAuthoredSizing);
    const owners = targets.map((target) => ({ target, styles: ownStyles(target) }));
    let terminal = authoredConflict ? "size-conflict" : null;
    const unavailable = (reason) => {
      terminal = reason;
      for (const { styles } of owners) styles.restore();
      return { kind: "unavailable", reason };
    };
    let preparedSize = null;
    const pending = () => {
      preparedSize = null;
      return { kind: "pending", reason: "missing-layout" };
    };
    const ownsCurrentFields = () => owners.every(
      ({ target, styles }) => (admittedSizeGenerations.get(target) ?? 0) <= generation && styles.isCurrent()
    );
    const hasNewAuthoredSizing = () => owners.some(({ target }) => hasAuthoredSizing(target));
    const availabilityFailure = () => {
      if (!current() || reference.ownerDocument !== ownerDocument || owners.some(({ target }) => target.ownerDocument !== ownerDocument))
        return unavailable("detached-target");
      if (!ownsCurrentFields() || hasNewAuthoredSizing()) return unavailable("ownership-lost");
      if (!reference.isConnected || owners.some(({ target }) => !target.isConnected)) {
        preparedSize = null;
        return { kind: "unavailable", reason: "detached-target" };
      }
      return null;
    };
    const prepare = () => {
      if (terminal) return { kind: "unavailable", reason: terminal };
      const failure = availabilityFailure();
      if (failure) return failure;
      const width = reference.offsetWidth, height = reference.offsetHeight;
      if (!Number.isFinite(width) || !Number.isFinite(height) || width < 0 || height < 0)
        return unavailable("invalid-geometry");
      if (width === 0 || height === 0) return pending();
      const afterRead = availabilityFailure();
      if (afterRead) return afterRead;
      for (const { target } of owners) admittedSizeGenerations.set(target, generation);
      for (const { styles } of owners) {
        const beforeWrite = availabilityFailure();
        if (beforeWrite) return beforeWrite;
        if (!styles.write("box-sizing", "border-box") || !styles.write("width", `${width}px`) || !styles.write("height", `${height}px`))
          return unavailable("ownership-lost");
      }
      preparedSize = { width, height };
      return { kind: "prepared", width, height };
    };
    const verify = () => {
      if (terminal) return { kind: "unavailable", reason: terminal };
      const failure = availabilityFailure();
      if (failure) return failure;
      if (!preparedSize) return pending();
      const prepared = preparedSize;
      const { width, height } = prepared;
      const currentWidth = reference.offsetWidth, currentHeight = reference.offsetHeight;
      if (!Number.isFinite(currentWidth) || !Number.isFinite(currentHeight) || currentWidth < 0 || currentHeight < 0)
        return unavailable("invalid-geometry");
      if (currentWidth === 0 || currentHeight === 0) return pending();
      if (currentWidth !== width || currentHeight !== height) return { kind: "reference-changed" };
      for (const { target } of owners) {
        const beforeRead = availabilityFailure();
        if (beforeRead) return beforeRead;
        const targetWidth = target.offsetWidth, targetHeight = target.offsetHeight;
        if (!Number.isFinite(targetWidth) || !Number.isFinite(targetHeight) || targetWidth < 0 || targetHeight < 0)
          return unavailable("invalid-geometry");
        if (targetWidth === 0 || targetHeight === 0) return pending();
        if (Math.abs(targetWidth - width) > 1 || Math.abs(targetHeight - height) > 1 || target.scrollHeight > target.clientHeight + 1 || target.scrollWidth > target.clientWidth + 1)
          return unavailable("size-conflict");
      }
      const finalWidth = reference.offsetWidth, finalHeight = reference.offsetHeight;
      const afterRead = availabilityFailure();
      if (afterRead) return afterRead;
      if (!Number.isFinite(finalWidth) || !Number.isFinite(finalHeight) || finalWidth < 0 || finalHeight < 0)
        return unavailable("invalid-geometry");
      if (finalWidth === 0 || finalHeight === 0) return pending();
      if (finalWidth !== width || finalHeight !== height || preparedSize !== prepared)
        return { kind: "reference-changed" };
      return { kind: "matched", width, height };
    };
    return {
      prepare,
      verify,
      abort: unavailable,
      apply() {
        const prepared = prepare();
        if (prepared.kind !== "prepared") return prepared;
        const result = verify();
        return result.kind === "reference-changed" ? unavailable("invalid-geometry") : result;
      },
      restore() {
        terminal = "detached-target";
        for (const { styles } of owners) styles.restore();
      }
    };
  }
  function layoutInlineStart(node) {
    let left = 0;
    let current = node;
    while (current) {
      left += current.offsetLeft;
      const parent = current.offsetParent;
      if (!parent || !("offsetLeft" in parent)) break;
      left += parent.clientLeft;
      current = parent;
    }
    for (let parent = node.parentElement; parent; parent = parent.parentElement)
      left -= parent.scrollLeft;
    return left;
  }
  function hasBorderBoxInlineClipping(target, frame) {
    const view = frame.ownerDocument.defaultView;
    if (!view || target === frame || !frame.contains(target)) return null;
    const left = layoutInlineStart(target);
    const width = target.offsetWidth;
    if (!Number.isFinite(left) || !Number.isFinite(width) || width < 0) return null;
    const position = view.getComputedStyle(target).position;
    let containingBlock = position === "absolute" || position === "fixed" ? target.offsetParent : void 0;
    for (let parent = target.parentElement; parent; parent = parent.parentElement) {
      if (parent === containingBlock) containingBlock = void 0;
      const style = view.getComputedStyle(parent);
      const overflow = style.overflowX || style.overflow;
      if (containingBlock === void 0 && (overflow === "hidden" || overflow === "clip" || overflow === "scroll" || overflow === "auto")) {
        const start = layoutInlineStart(parent) + parent.clientLeft;
        const available = parent.clientWidth;
        if (!Number.isFinite(start) || !Number.isFinite(available) || available < 0) return null;
        if (left < start - 1 || left + width > start + available + 1) return true;
      }
      if (parent === frame) return false;
      if (containingBlock === void 0 && (style.position === "absolute" || style.position === "fixed"))
        containingBlock = parent.offsetParent;
    }
    return null;
  }
  function measureBorderBoxInlineGutter(target, surface2) {
    const view = surface2.ownerDocument.defaultView;
    if (!view || !surface2.contains(target)) return null;
    const number = (value) => value === "auto" ? 0 : Number.parseFloat(value);
    let gutter = 0;
    let child = target;
    for (let parent = target.parentElement; parent; parent = parent.parentElement) {
      const childStyle = view.getComputedStyle(child);
      const style = view.getComputedStyle(parent);
      const margin = number(childStyle.marginLeft) + number(childStyle.marginRight);
      const border = number(style.borderLeftWidth) + number(style.borderRightWidth);
      const padding = number(style.paddingLeft) + number(style.paddingRight);
      const scrollbar = Math.max(0, parent.offsetWidth - parent.clientWidth - border);
      if (![margin, border, padding, scrollbar].every(Number.isFinite) || border < 0 || padding < 0)
        return null;
      gutter += margin + border + padding + scrollbar;
      if (parent === surface2) return Math.max(0, gutter);
      child = parent;
    }
    return null;
  }

  // packages/modules/positioning/src/geometry/target-alignment.ts
  var invalid = (reason) => Object.freeze({ kind: "invalid", reason });
  var finite = (numbers) => numbers.every(Number.isFinite);
  var nonnegative = (numbers) => numbers.every((value) => value >= 0);
  var clamp = (value, minimum, maximum) => Math.min(Math.max(value, minimum), maximum);
  function solveTargetAlignment(metrics, constraints) {
    const { viewport: v, reference: a, surface: c, target: t, scrollport: s } = metrics;
    const facts2 = [
      ...Object.values(v),
      ...Object.values(a),
      ...Object.values(c),
      t.offset,
      t.height,
      ...t.minimumOuterInlineSpan === void 0 ? [] : [t.minimumOuterInlineSpan],
      ...t.inlineStartInset === void 0 ? [] : [t.inlineStartInset],
      ...Object.values(s)
    ];
    if (!finite(facts2)) return invalid("nonfinite-fact");
    if (v.width <= 0 || v.height <= 0 || t.height <= 0 || !nonnegative([
      a.width,
      a.height,
      c.width,
      c.clientHeight,
      c.borderTop,
      c.borderBottom,
      c.paddingTop,
      c.paddingBottom,
      t.offset,
      ...t.minimumOuterInlineSpan === void 0 ? [] : [t.minimumOuterInlineSpan],
      ...t.inlineStartInset === void 0 ? [] : [t.inlineStartInset],
      s.scrollHeight,
      s.offsetTop,
      s.height,
      s.paddingTop,
      s.paddingBottom
    ]) || a.right < a.left || c.right < c.left)
      return invalid("invalid-extent");
    const { margin, minimumTargetSpanCount } = constraints;
    if (!finite([margin, minimumTargetSpanCount]) || margin < 0 || minimumTargetSpanCount <= 0 || constraints.boundary !== "layout-viewport" || constraints.inlineOverflow !== "preserve-start" || metrics.direction !== "ltr" && metrics.direction !== "rtl" || typeof constraints.expandOnScroll !== "boolean")
      return invalid("invalid-constraint");
    const rtl = metrics.direction === "rtl";
    const referenceInset = (rtl ? v.width - a.right : a.left) - (t.inlineStartInset ?? 0);
    const minimumInlineSpan = Math.max(a.width, t.minimumOuterInlineSpan ?? 0);
    const widthForClamp = Math.max(minimumInlineSpan, c.width);
    const inlineInset = clamp(
      referenceInset,
      margin,
      Math.max(margin, v.width - margin - widthForClamp)
    );
    const available = v.height - 2 * margin;
    const natural2 = c.borderTop + c.paddingTop + s.scrollHeight + c.paddingBottom + c.borderBottom;
    const minimum = Math.min(minimumTargetSpanCount * t.height, natural2);
    const beforeReference = a.top + a.height / 2 - margin;
    const afterReference = available - beforeReference;
    const half = t.height / 2;
    const beforeTarget = c.borderTop + c.paddingTop + t.offset + half;
    const afterTarget = natural2 - beforeTarget;
    const endPinned = beforeTarget <= beforeReference;
    const requestedSpan = endPinned ? beforeTarget + Math.max(
      afterReference,
      half + (t.atEnd ? s.paddingBottom : 0) + c.clientHeight - s.offsetTop - s.height + c.borderBottom
    ) : Math.max(beforeReference, c.borderTop + s.offsetTop + (t.atStart ? s.paddingTop : 0) + half) + afterTarget;
    const requestedScroll = endPinned ? void 0 : beforeTarget - beforeReference + s.offsetTop;
    if (!finite([
      minimumInlineSpan,
      inlineInset,
      available,
      minimum,
      requestedSpan,
      ...requestedScroll === void 0 ? [] : [requestedScroll]
    ]))
      return invalid("nonfinite-plan");
    const plan = Object.freeze({
      inline: Object.freeze({
        edge: rtl ? "right" : "left",
        inset: inlineInset,
        minimumSpan: minimumInlineSpan
      }),
      block: Object.freeze({
        pin: endPinned ? "end" : "start",
        margin,
        requestedSpan,
        minimumSpan: minimum,
        maximumSpan: available
      }),
      contentAlignment: "normal",
      ...requestedScroll === void 0 ? {} : { requestedScroll }
    });
    return Object.freeze({ kind: "plan", plan });
  }
  function reduceScrollExpansion(sample) {
    const values = [
      sample.previousActualScroll,
      sample.actualScroll,
      sample.previousRequestedSpan,
      sample.minimumSpan,
      sample.availableSpan
    ];
    if (!finite(values)) return invalid("nonfinite-fact");
    if (!nonnegative(values.slice(0, 4))) return invalid("invalid-extent");
    if (sample.pin !== "start" && sample.pin !== "end" || typeof sample.enabled !== "boolean") {
      return invalid("invalid-constraint");
    }
    const delta = Math.abs(sample.previousActualScroll - sample.actualScroll);
    const previousSpan = Math.max(sample.minimumSpan, sample.previousRequestedSpan);
    let plan = { nextPreviousActualScroll: sample.actualScroll };
    if (sample.enabled && delta > 0 && previousSpan < sample.availableSpan) {
      const proposed = previousSpan + delta;
      const requestedSpan = Math.min(sample.availableSpan, proposed);
      if (!Number.isFinite(proposed)) return invalid("nonfinite-plan");
      plan = {
        ...plan,
        requestedSpan,
        ...sample.pin === "end" ? {
          requestedScroll: Math.max(proposed - requestedSpan, 0),
          contentAlignment: "end"
        } : {}
      };
    }
    return Object.freeze({ kind: "plan", plan: Object.freeze(plan) });
  }

  // packages/modules/positioning/src/web/target-alignment-host.ts
  var element = (value) => !!value && typeof value === "object" && value.nodeType === 1 && typeof value.getBoundingClientRect === "function" && "style" in value;
  function layoutTop(node) {
    let top = 0;
    let current = node;
    while (current) {
      top += current.offsetTop;
      const parent = current.offsetParent;
      if (!element(parent)) break;
      top += parent.clientTop;
      current = parent;
    }
    return top;
  }
  var relativeTop = (node, ancestor) => layoutTop(node) - layoutTop(ancestor) - ancestor.clientTop;
  function sameGeometry(a, b) {
    const x = a.targetAlignment, y = b.targetAlignment;
    if (!x || !y || a.floating !== b.floating) return false;
    const sameSize = !x.sizeMatch && !y.sizeMatch || !!x.sizeMatch && !!y.sizeMatch && x.sizeMatch.reference === y.sizeMatch.reference && x.sizeMatch.targets.length === y.sizeMatch.targets.length && x.sizeMatch.targets.every((target, index) => target === y.sizeMatch?.targets[index]);
    return sameSize && [
      "surface",
      "scrollport",
      "blockReference",
      "inlineReference",
      "blockTarget",
      "inlineTarget",
      "atStart",
      "atEnd"
    ].every((key) => x[key] === y[key]) && ["boundary", "margin", "minimumTargetSpanCount", "inlineOverflow", "expandOnScroll"].every((key) => x.constraints[key] === y.constraints[key]);
  }
  function createTargetAlignmentLease(initial) {
    let connection = initial;
    let disposed = false;
    let version = 0;
    let lastStatus = null;
    let stop = null;
    let restore = null;
    let updateGeometry = null;
    const retire = () => {
      stop?.();
      stop = null;
      updateGeometry = null;
      restore?.();
      restore = null;
    };
    const start = () => {
      const current = connection;
      const request = ++version;
      lastStatus = null;
      retire();
      const live = () => !disposed && version === request;
      const report = (status) => {
        if (live()) {
          lastStatus = status;
          connection.onAlignment?.(status);
        }
      };
      const descriptor = current.targetAlignment;
      if (!descriptor || !element(current.floating)) {
        report({ status: "pending-target", reason: "missing-target" });
        return;
      }
      const keys = [
        "surface",
        "scrollport",
        "blockReference",
        "inlineReference",
        "blockTarget",
        "inlineTarget"
      ];
      if (!keys.every((key) => element(descriptor[key]))) {
        report({ status: "pending-target", reason: "missing-target" });
        return;
      }
      const targets = descriptor;
      const frame = current.floating;
      const doc = frame.ownerDocument;
      const view = doc.defaultView;
      if (!view) {
        report({ status: "pending-target", reason: "detached-target" });
        return;
      }
      const sizing = descriptor.sizeMatch;
      if (sizing && (!element(sizing.reference) || sizing.targets.length === 0 || !sizing.targets.every(element))) {
        report({ status: "pending-target", reason: "missing-target" });
        return;
      }
      const sizeTargets = sizing ? sizing.targets : [];
      const sizeLease = sizing ? createBorderBoxSizeLease(sizing.reference, sizeTargets, live) : null;
      const owned = ownStyles(frame);
      const rejectAdmission = (reason) => {
        sizeLease?.abort(reason);
        report({ status: "unavailable", reason });
      };
      restore = () => {
        owned.restore();
        sizeLease?.restore();
      };
      let plan = null;
      let requestedSpan = 0;
      let previousScroll = targets.scrollport.scrollTop;
      let expand = false;
      let frameTask = null;
      let applied = false;
      let writing = false;
      let ownershipLost = false;
      let referenceBox = null;
      const write = (name, value) => {
        if (!live() || ownershipLost) return false;
        if (!owned.write(name, value)) {
          ownershipLost = true;
          rejectAdmission("ownership-lost");
          return false;
        }
        return true;
      };
      const connected = () => frame.isConnected && keys.every((key) => targets[key].isConnected && targets[key].ownerDocument === doc) && sizeTargets.every((target) => target.isConnected && target.ownerDocument === doc);
      const readPlan = () => {
        if (!live() || !connected()) {
          if (live()) report({ status: "pending-target", reason: "detached-target" });
          return null;
        }
        const reference = targets.blockReference.getBoundingClientRect();
        const origin = frame.getBoundingClientRect().left - layoutInlineStart(frame);
        const surfaceLeft = origin + layoutInlineStart(targets.surface);
        const surfaceWidth = targets.surface.offsetWidth;
        if (targets.blockTarget.offsetHeight <= 0 || reference.height <= 0) {
          report({ status: "pending-target", reason: "missing-target" });
          return null;
        }
        const paint = view.getComputedStyle(targets.surface);
        const scroll = view.getComputedStyle(targets.scrollport);
        const css = (text) => Number.parseInt(text, 10);
        const gutters = sizeTargets.map(
          (target) => measureBorderBoxInlineGutter(target, targets.surface)
        );
        if (gutters.some((gutter) => gutter === null)) {
          rejectAdmission("invalid-geometry");
          return null;
        }
        const minimumOuterInlineSpan = sizeTargets.length ? (sizing?.reference).offsetWidth + Math.max(...gutters) : void 0;
        const direction = view.getComputedStyle(frame).direction === "rtl" ? "rtl" : "ltr";
        const matchedTarget = sizeTargets.includes(targets.blockTarget);
        const targetLeft = origin + layoutInlineStart(targets.blockTarget);
        const inlineStartInset = matchedTarget ? direction === "rtl" ? surfaceLeft + surfaceWidth - targetLeft - targets.blockTarget.offsetWidth : targetLeft - surfaceLeft : void 0;
        const layoutRoot = doc.documentElement;
        const viewportWidth = layoutRoot.clientWidth > 0 ? layoutRoot.clientWidth : view.innerWidth;
        const viewportHeight = layoutRoot.clientHeight > 0 ? layoutRoot.clientHeight : view.innerHeight;
        const result = solveTargetAlignment(
          {
            direction,
            viewport: { width: viewportWidth, height: viewportHeight },
            reference: {
              left: reference.left,
              right: reference.right,
              top: reference.top,
              width: reference.width,
              height: reference.height
            },
            surface: {
              left: surfaceLeft,
              right: surfaceLeft + surfaceWidth,
              width: surfaceWidth,
              clientHeight: targets.surface.clientHeight,
              borderTop: css(paint.borderTopWidth),
              borderBottom: css(paint.borderBottomWidth),
              paddingTop: css(paint.paddingTop),
              paddingBottom: css(paint.paddingBottom)
            },
            target: {
              offset: relativeTop(targets.blockTarget, targets.scrollport),
              height: targets.blockTarget.offsetHeight,
              atStart: descriptor.atStart,
              atEnd: descriptor.atEnd,
              ...minimumOuterInlineSpan === void 0 ? {} : { minimumOuterInlineSpan },
              ...inlineStartInset === void 0 ? {} : { inlineStartInset }
            },
            scrollport: {
              scrollHeight: targets.scrollport.scrollHeight,
              offsetTop: relativeTop(targets.scrollport, targets.surface),
              height: targets.scrollport.offsetHeight,
              paddingTop: css(scroll.paddingTop),
              paddingBottom: css(scroll.paddingBottom)
            }
          },
          descriptor.constraints
        );
        if (!live()) return null;
        if (result.kind !== "plan") {
          rejectAdmission("invalid-geometry");
          return null;
        }
        return result.plan;
      };
      const equivalent = (a, b) => a.inline.edge === b.inline.edge && a.block.pin === b.block.pin && Math.abs(a.inline.inset - b.inline.inset) < 0.01 && Math.abs(a.inline.minimumSpan - b.inline.minimumSpan) < 0.01 && Math.abs(a.block.requestedSpan - b.block.requestedSpan) < 0.01 && Math.abs(a.block.minimumSpan - b.block.minimumSpan) < 0.01 && Math.abs(a.block.maximumSpan - b.block.maximumSpan) < 0.01 && a.requestedScroll === b.requestedScroll;
      const position = () => {
        if (!live() || writing || ownershipLost) return;
        writing = true;
        let stable = false;
        let nextReferenceBox = [];
        try {
          const reference = targets.blockReference.getBoundingClientRect();
          nextReferenceBox = [reference.left, reference.top, reference.width, reference.height];
          const referenceChanged = !!referenceBox && nextReferenceBox.some((value, index) => value !== referenceBox[index]);
          for (const [name, value] of Object.entries({
            position: "fixed",
            display: "flex",
            "flex-direction": "column",
            // Scroll expansion owns end alignment only while its reference
            // geometry is current. A new reference plan resets that alignment
            // with its span/scroll; a same-reference refresh retains expansion.
            ...!applied || referenceChanged ? { "justify-content": "normal" } : {},
            // Neutral reference facts, matching the edge host and native targets.
            // Family recipes may bind popup chrome to the anchor without a size lease.
            "--proto-ui-anchor-width": `${targets.blockReference.offsetWidth}px`,
            "--proto-ui-anchor-height": `${targets.blockReference.offsetHeight}px`
          }))
            if (!write(name, value)) return;
          if (sizeLease) {
            const sized = sizeLease.prepare();
            if (sized.kind !== "prepared") {
              if (sized.kind === "pending")
                report({ status: "pending-target", reason: "missing-target" });
              else if (sized.reason === "detached-target")
                report({ status: "pending-target", reason: "detached-target" });
              else report({ status: "unavailable", reason: sized.reason });
              return;
            }
          }
          let candidate = readPlan();
          if (!candidate) return;
          for (let pass = 0; pass < 4; pass++) {
            for (const [name, value] of Object.entries({
              "min-width": `${candidate.inline.minimumSpan}px`,
              ...sizeLease ? { width: `${candidate.inline.minimumSpan}px` } : {},
              [candidate.inline.edge]: `${candidate.inline.inset}px`,
              [candidate.inline.edge === "left" ? "right" : "left"]: ""
            }))
              if (!write(name, value)) return;
            if (sizeLease) {
              const sized = sizeLease.prepare();
              if (sized.kind !== "prepared") {
                if (sized.kind === "pending")
                  report({ status: "pending-target", reason: "missing-target" });
                else if (sized.reason === "detached-target")
                  report({ status: "pending-target", reason: "detached-target" });
                else report({ status: "unavailable", reason: sized.reason });
                return;
              }
            }
            const constrained = readPlan();
            if (!constrained) return;
            plan = constrained;
            const nextSpan = applied && !referenceChanged ? Math.min(Math.max(requestedSpan, plan.block.requestedSpan), plan.block.maximumSpan) : plan.block.requestedSpan;
            const styles = {
              top: plan.block.pin === "start" ? "0px" : "",
              bottom: plan.block.pin === "end" ? "0px" : "",
              margin: `${plan.block.margin}px 0px`,
              height: `${nextSpan}px`,
              "min-height": `${plan.block.minimumSpan}px`,
              "max-height": `${plan.block.maximumSpan}px`
            };
            for (const [name, value] of Object.entries(styles)) if (!write(name, value)) return;
            requestedSpan = nextSpan;
            if ((!applied || referenceChanged) && plan.requestedScroll !== void 0 && live())
              targets.scrollport.scrollTop = plan.requestedScroll;
            else if (referenceChanged && live()) targets.scrollport.scrollTop = 0;
            previousScroll = targets.scrollport.scrollTop;
            const settled = readPlan();
            if (!settled) return;
            if (equivalent(candidate, constrained) && equivalent(constrained, settled)) {
              const sized = sizeLease?.verify();
              if (sized?.kind === "reference-changed") {
                const prepared = sizeLease.prepare();
                if (prepared.kind !== "prepared") {
                  if (prepared.kind === "pending")
                    report({ status: "pending-target", reason: "missing-target" });
                  else if (prepared.reason === "detached-target")
                    report({ status: "pending-target", reason: "detached-target" });
                  else report({ status: "unavailable", reason: prepared.reason });
                  return;
                }
                const resized = readPlan();
                if (!resized) return;
                candidate = resized;
                continue;
              }
              if (sized?.kind === "unavailable" || sized?.kind === "pending") {
                if (sized.kind === "pending")
                  report({ status: "pending-target", reason: "missing-target" });
                else if (sized.reason === "detached-target")
                  report({ status: "pending-target", reason: "detached-target" });
                else report({ status: "unavailable", reason: sized.reason });
                return;
              }
              for (const target of sizeTargets) {
                const clipped = hasBorderBoxInlineClipping(target, frame);
                if (clipped !== false) {
                  rejectAdmission(clipped === null ? "invalid-geometry" : "size-conflict");
                  return;
                }
              }
              stable = true;
              break;
            }
            candidate = settled;
          }
        } finally {
          writing = false;
        }
        if (!live()) return;
        if (!stable) {
          rejectAdmission("invalid-geometry");
          return;
        }
        const firstApply = !applied;
        referenceBox = nextReferenceBox;
        if (firstApply || lastStatus?.status !== "applied") {
          applied = true;
          report({ status: "applied" });
          if (!live()) return;
        }
        if (firstApply) {
          frameTask = view.requestAnimationFrame(() => {
            frameTask = null;
            if (live()) expand = descriptor.constraints.expandOnScroll;
          });
        }
      };
      const onScroll = () => {
        if (!live() || writing || ownershipLost || !plan) return;
        const actualScroll = targets.scrollport.scrollTop;
        const result = reduceScrollExpansion({
          enabled: expand,
          previousActualScroll: previousScroll,
          actualScroll,
          previousRequestedSpan: requestedSpan,
          minimumSpan: plan.block.minimumSpan,
          availableSpan: view.innerHeight - descriptor.constraints.margin * 2,
          pin: plan.block.pin
        });
        if (result.kind !== "plan") return;
        previousScroll = actualScroll;
        writing = true;
        try {
          if (result.plan.requestedSpan !== void 0) {
            if (!write("height", `${result.plan.requestedSpan}px`)) return;
            requestedSpan = result.plan.requestedSpan;
          }
          if (result.plan.contentAlignment && !write("justify-content", "flex-end")) return;
          if (result.plan.requestedScroll !== void 0 && live())
            targets.scrollport.scrollTop = result.plan.requestedScroll;
          previousScroll = targets.scrollport.scrollTop;
        } finally {
          writing = false;
        }
      };
      const onOuterScroll = (event) => {
        if (event.target !== targets.scrollport) position();
      };
      const observedTargets = /* @__PURE__ */ new Set([frame, ...keys.map((key) => targets[key]), ...sizeTargets]);
      const observers = typeof view.ResizeObserver === "function" ? ["content-box", "border-box"].map((box2) => {
        const observer = new view.ResizeObserver(() => position());
        for (const target of observedTargets) observer.observe(target, { box: box2 });
        return observer;
      }) : [];
      targets.scrollport.addEventListener("scroll", onScroll);
      doc.addEventListener("scroll", onOuterScroll, true);
      view.addEventListener("resize", position);
      stop = () => {
        for (const observer of observers) observer.disconnect();
        targets.scrollport.removeEventListener("scroll", onScroll);
        doc.removeEventListener("scroll", onOuterScroll, true);
        view.removeEventListener("resize", position);
        if (frameTask !== null) view.cancelAnimationFrame(frameTask);
        frameTask = null;
      };
      updateGeometry = position;
      position();
    };
    start();
    return {
      update(next) {
        if (disposed) return;
        if (sameGeometry(connection, next)) {
          connection = next;
          const request = version;
          updateGeometry?.();
          if (!disposed && version === request && connection === next && lastStatus)
            next.onAlignment?.(lastStatus);
          return;
        }
        connection = next;
        start();
      },
      requestUpdate() {
        if (!disposed) updateGeometry?.();
      },
      dispose() {
        if (disposed) return;
        disposed = true;
        version++;
        retire();
      }
    };
  }

  // packages/modules/positioning/src/web/input-origin-anchor.ts
  var references = /* @__PURE__ */ new WeakMap();
  function resolveWebInputOriginAnchor(value) {
    if (!value || typeof value !== "object") return null;
    const reference = references.get(value);
    return reference?.isLive() ? reference : null;
  }

  // packages/modules/positioning/src/web/root-space-observer.ts
  var roots = /* @__PURE__ */ new WeakMap();
  var read = (root) => ({
    width: root.clientWidth,
    height: root.clientHeight,
    left: root.clientLeft,
    boxWidth: root.getBoundingClientRect().width,
    boxLeft: root.getBoundingClientRect().left + (root.ownerDocument.defaultView?.scrollX ?? 0),
    // When the propagated page scroller is body (root overflow hidden, body
    // overflow scroll), a classic gutter belongs to body's box alone: the root
    // box above stays identical, so without this half the drift is unobservable.
    bodyWidth: root.ownerDocument.body?.clientWidth ?? 0,
    bodyLeft: root.ownerDocument.body?.getBoundingClientRect().left ?? 0
  });
  function observeRootSpace(document2, listener) {
    const root = document2.documentElement, view = document2.defaultView;
    if (!root || !view) return () => {
    };
    let tracker = roots.get(document2);
    if (!tracker) {
      let previous = read(root), disposed = false;
      const listeners = /* @__PURE__ */ new Set();
      const update = () => {
        if (disposed) return;
        const next = read(root);
        if (next.width === previous.width && next.height === previous.height && next.left === previous.left && next.boxWidth === previous.boxWidth && next.boxLeft === previous.boxLeft && next.bodyWidth === previous.bodyWidth && next.bodyLeft === previous.bodyLeft)
          return;
        previous = next;
        const errors = [];
        for (const callback of [...listeners]) {
          if (!listeners.has(callback)) continue;
          try {
            callback();
          } catch (error) {
            errors.push(error);
          }
        }
        if (errors.length === 1) throw errors[0];
        if (errors.length > 1) throw new AggregateError(errors, "Root-space subscribers failed");
      };
      const resize = typeof view.ResizeObserver === "function" ? new view.ResizeObserver(update) : null;
      const mutation = typeof view.MutationObserver === "function" ? new view.MutationObserver(update) : null;
      tracker = {
        listeners,
        dispose() {
          disposed = true;
          resize?.disconnect();
          mutation?.disconnect();
          roots.delete(document2);
        }
      };
      roots.set(document2, tracker);
      resize?.observe(root);
      if (document2.body) resize?.observe(document2.body);
      mutation?.observe(root, { attributes: true, attributeFilter: ["dir", "style", "class"] });
      if (document2.body)
        mutation?.observe(document2.body, {
          attributes: true,
          attributeFilter: ["dir", "style", "class"]
        });
    }
    const owned = tracker;
    const ownedListener = () => listener();
    owned.listeners.add(ownedListener);
    let released = false;
    return () => {
      if (released) return;
      released = true;
      owned.listeners.delete(ownedListener);
      if (!owned.listeners.size) owned.dispose();
    };
  }

  // node_modules/.pnpm/@floating-ui+utils@0.2.12/node_modules/@floating-ui/utils/dist/floating-ui.utils.mjs
  var min = Math.min;
  var max = Math.max;
  var round = Math.round;
  var floor = Math.floor;
  var createCoords = (v) => ({
    x: v,
    y: v
  });
  var oppositeSideMap = {
    left: "right",
    right: "left",
    bottom: "top",
    top: "bottom"
  };
  function clamp2(start, value, end) {
    return max(start, min(value, end));
  }
  function evaluate(value, param) {
    return typeof value === "function" ? value(param) : value;
  }
  function getSide(placement) {
    return placement.split("-")[0];
  }
  function getAlignment(placement) {
    return placement.split("-")[1];
  }
  function getOppositeAxis(axis) {
    return axis === "x" ? "y" : "x";
  }
  function getAxisLength(axis) {
    return axis === "y" ? "height" : "width";
  }
  function getSideAxis(placement) {
    const firstChar = placement[0];
    return firstChar === "t" || firstChar === "b" ? "y" : "x";
  }
  function getAlignmentAxis(placement) {
    return getOppositeAxis(getSideAxis(placement));
  }
  function getAlignmentSides(placement, rects, rtl) {
    if (rtl === void 0) {
      rtl = false;
    }
    const alignment = getAlignment(placement);
    const alignmentAxis = getAlignmentAxis(placement);
    const length = getAxisLength(alignmentAxis);
    let mainAlignmentSide = alignmentAxis === "x" ? alignment === (rtl ? "end" : "start") ? "right" : "left" : alignment === "start" ? "bottom" : "top";
    if (rects.reference[length] > rects.floating[length]) {
      mainAlignmentSide = getOppositePlacement(mainAlignmentSide);
    }
    return [mainAlignmentSide, getOppositePlacement(mainAlignmentSide)];
  }
  function getExpandedPlacements(placement) {
    const oppositePlacement = getOppositePlacement(placement);
    return [getOppositeAlignmentPlacement(placement), oppositePlacement, getOppositeAlignmentPlacement(oppositePlacement)];
  }
  function getOppositeAlignmentPlacement(placement) {
    return placement.includes("start") ? placement.replace("start", "end") : placement.replace("end", "start");
  }
  var lrPlacement = ["left", "right"];
  var rlPlacement = ["right", "left"];
  var tbPlacement = ["top", "bottom"];
  var btPlacement = ["bottom", "top"];
  function getSideList(side, isStart, rtl) {
    switch (side) {
      case "top":
      case "bottom":
        if (rtl) return isStart ? rlPlacement : lrPlacement;
        return isStart ? lrPlacement : rlPlacement;
      case "left":
      case "right":
        return isStart ? tbPlacement : btPlacement;
      default:
        return [];
    }
  }
  function getOppositeAxisPlacements(placement, flipAlignment, direction, rtl) {
    const alignment = getAlignment(placement);
    let list = getSideList(getSide(placement), direction === "start", rtl);
    if (alignment) {
      list = list.map((side) => side + "-" + alignment);
      if (flipAlignment) {
        list = list.concat(list.map(getOppositeAlignmentPlacement));
      }
    }
    return list;
  }
  function getOppositePlacement(placement) {
    const side = getSide(placement);
    return oppositeSideMap[side] + placement.slice(side.length);
  }
  function expandPaddingObject(padding) {
    var _padding$top, _padding$right, _padding$bottom, _padding$left;
    return {
      top: (_padding$top = padding.top) != null ? _padding$top : 0,
      right: (_padding$right = padding.right) != null ? _padding$right : 0,
      bottom: (_padding$bottom = padding.bottom) != null ? _padding$bottom : 0,
      left: (_padding$left = padding.left) != null ? _padding$left : 0
    };
  }
  function getPaddingObject(padding) {
    return typeof padding !== "number" ? expandPaddingObject(padding) : {
      top: padding,
      right: padding,
      bottom: padding,
      left: padding
    };
  }
  function rectToClientRect(rect) {
    const {
      x,
      y,
      width,
      height
    } = rect;
    return {
      width,
      height,
      top: y,
      left: x,
      right: x + width,
      bottom: y + height,
      x,
      y
    };
  }

  // node_modules/.pnpm/@floating-ui+core@1.8.0/node_modules/@floating-ui/core/dist/floating-ui.core.mjs
  function computeCoordsFromPlacement(_ref, placement, rtl) {
    let {
      reference,
      floating: floating2
    } = _ref;
    const sideAxis = getSideAxis(placement);
    const alignmentAxis = getAlignmentAxis(placement);
    const alignLength = getAxisLength(alignmentAxis);
    const side = getSide(placement);
    const isVertical = sideAxis === "y";
    const commonX = reference.x + reference.width / 2 - floating2.width / 2;
    const commonY = reference.y + reference.height / 2 - floating2.height / 2;
    const commonAlign = reference[alignLength] / 2 - floating2[alignLength] / 2;
    let coords;
    switch (side) {
      case "top":
        coords = {
          x: commonX,
          y: reference.y - floating2.height
        };
        break;
      case "bottom":
        coords = {
          x: commonX,
          y: reference.y + reference.height
        };
        break;
      case "right":
        coords = {
          x: reference.x + reference.width,
          y: commonY
        };
        break;
      case "left":
        coords = {
          x: reference.x - floating2.width,
          y: commonY
        };
        break;
      default:
        coords = {
          x: reference.x,
          y: reference.y
        };
    }
    const alignment = getAlignment(placement);
    if (alignment) {
      coords[alignmentAxis] += commonAlign * (alignment === "end" ? 1 : -1) * (rtl && isVertical ? -1 : 1);
    }
    return coords;
  }
  async function detectOverflow(state, options) {
    var _await$platform$isEle;
    if (options === void 0) {
      options = {};
    }
    const {
      x,
      y,
      platform: platform2,
      rects,
      elements,
      strategy
    } = state;
    const {
      boundary = "clippingAncestors",
      rootBoundary = "viewport",
      elementContext = "floating",
      altBoundary = false,
      padding = 0
    } = evaluate(options, state);
    const paddingObject = getPaddingObject(padding);
    const altContext = elementContext === "floating" ? "reference" : "floating";
    const element2 = elements[altBoundary ? altContext : elementContext];
    const clippingClientRect = rectToClientRect(await platform2.getClippingRect({
      element: ((_await$platform$isEle = await (platform2.isElement == null ? void 0 : platform2.isElement(element2))) != null ? _await$platform$isEle : true) ? element2 : element2.contextElement || await (platform2.getDocumentElement == null ? void 0 : platform2.getDocumentElement(elements.floating)),
      boundary,
      rootBoundary,
      strategy
    }));
    const rect = elementContext === "floating" ? {
      x,
      y,
      width: rects.floating.width,
      height: rects.floating.height
    } : rects.reference;
    const offsetParent = await (platform2.getOffsetParent == null ? void 0 : platform2.getOffsetParent(elements.floating));
    const offsetScale = await (platform2.isElement == null ? void 0 : platform2.isElement(offsetParent)) && await (platform2.getScale == null ? void 0 : platform2.getScale(offsetParent)) || {
      x: 1,
      y: 1
    };
    const elementClientRect = rectToClientRect(platform2.convertOffsetParentRelativeRectToViewportRelativeRect ? await platform2.convertOffsetParentRelativeRectToViewportRelativeRect({
      elements,
      rect,
      offsetParent,
      strategy
    }) : rect);
    return {
      top: (clippingClientRect.top - elementClientRect.top + paddingObject.top) / offsetScale.y,
      bottom: (elementClientRect.bottom - clippingClientRect.bottom + paddingObject.bottom) / offsetScale.y,
      left: (clippingClientRect.left - elementClientRect.left + paddingObject.left) / offsetScale.x,
      right: (elementClientRect.right - clippingClientRect.right + paddingObject.right) / offsetScale.x
    };
  }
  var MAX_RESET_COUNT = 50;
  var computePosition = async (reference, floating2, config2) => {
    const {
      placement = "bottom",
      strategy = "absolute",
      middleware = [],
      platform: platform2
    } = config2;
    const platformWithDetectOverflow = platform2.detectOverflow ? platform2 : {
      ...platform2,
      detectOverflow
    };
    const rtl = await (platform2.isRTL == null ? void 0 : platform2.isRTL(floating2));
    let rects = await platform2.getElementRects({
      reference,
      floating: floating2,
      strategy
    });
    let {
      x,
      y
    } = computeCoordsFromPlacement(rects, placement, rtl);
    let statefulPlacement = placement;
    let resetCount = 0;
    const middlewareData = {};
    for (let i = 0; i < middleware.length; i++) {
      const currentMiddleware = middleware[i];
      if (!currentMiddleware) {
        continue;
      }
      const {
        name,
        fn
      } = currentMiddleware;
      const {
        x: nextX,
        y: nextY,
        data,
        reset
      } = await fn({
        x,
        y,
        initialPlacement: placement,
        placement: statefulPlacement,
        strategy,
        middlewareData,
        rects,
        platform: platformWithDetectOverflow,
        elements: {
          reference,
          floating: floating2
        }
      });
      x = nextX != null ? nextX : x;
      y = nextY != null ? nextY : y;
      middlewareData[name] = {
        ...middlewareData[name],
        ...data
      };
      if (reset && resetCount < MAX_RESET_COUNT) {
        resetCount++;
        if (typeof reset === "object") {
          if (reset.placement) {
            statefulPlacement = reset.placement;
          }
          if (reset.rects) {
            rects = reset.rects === true ? await platform2.getElementRects({
              reference,
              floating: floating2,
              strategy
            }) : reset.rects;
          }
          ({
            x,
            y
          } = computeCoordsFromPlacement(rects, statefulPlacement, rtl));
        }
        i = -1;
      }
    }
    return {
      x,
      y,
      placement: statefulPlacement,
      strategy,
      middlewareData
    };
  };
  var flip = function(options) {
    if (options === void 0) {
      options = {};
    }
    return {
      name: "flip",
      options,
      async fn(state) {
        var _middlewareData$arrow, _middlewareData$flip;
        const {
          placement,
          middlewareData,
          rects,
          initialPlacement,
          platform: platform2,
          elements
        } = state;
        const {
          mainAxis: checkMainAxis = true,
          crossAxis: checkCrossAxis = true,
          fallbackPlacements: specifiedFallbackPlacements,
          fallbackStrategy = "bestFit",
          fallbackAxisSideDirection = "none",
          flipAlignment = true,
          ...detectOverflowOptions
        } = evaluate(options, state);
        if ((_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) {
          return {};
        }
        const side = getSide(placement);
        const initialSideAxis = getSideAxis(initialPlacement);
        const isBasePlacement = getSide(initialPlacement) === initialPlacement;
        const rtl = await (platform2.isRTL == null ? void 0 : platform2.isRTL(elements.floating));
        const fallbackPlacements = specifiedFallbackPlacements || (isBasePlacement || !flipAlignment ? [getOppositePlacement(initialPlacement)] : getExpandedPlacements(initialPlacement));
        const hasFallbackAxisSideDirection = fallbackAxisSideDirection !== "none";
        if (!specifiedFallbackPlacements && hasFallbackAxisSideDirection) {
          fallbackPlacements.push(...getOppositeAxisPlacements(initialPlacement, flipAlignment, fallbackAxisSideDirection, rtl));
        }
        const placements2 = [initialPlacement, ...fallbackPlacements];
        const overflow = await platform2.detectOverflow(state, detectOverflowOptions);
        const overflows = [];
        let overflowsData = ((_middlewareData$flip = middlewareData.flip) == null ? void 0 : _middlewareData$flip.overflows) || [];
        if (checkMainAxis) {
          overflows.push(overflow[side]);
        }
        if (checkCrossAxis) {
          const sides2 = getAlignmentSides(placement, rects, rtl);
          overflows.push(overflow[sides2[0]], overflow[sides2[1]]);
        }
        overflowsData = [...overflowsData, {
          placement,
          overflows
        }];
        if (!overflows.every((side2) => side2 <= 0)) {
          var _middlewareData$flip2, _overflowsData$filter;
          const nextIndex = (((_middlewareData$flip2 = middlewareData.flip) == null ? void 0 : _middlewareData$flip2.index) || 0) + 1;
          const nextPlacement = placements2[nextIndex];
          if (nextPlacement) {
            const ignoreCrossAxisOverflow = checkCrossAxis === "alignment" ? initialSideAxis !== getSideAxis(nextPlacement) : false;
            if (!ignoreCrossAxisOverflow || // We leave the current main axis only if every placement on that axis
            // overflows the main axis.
            overflowsData.every((d) => getSideAxis(d.placement) === initialSideAxis ? d.overflows[0] > 0 : true)) {
              return {
                data: {
                  index: nextIndex,
                  overflows: overflowsData
                },
                reset: {
                  placement: nextPlacement
                }
              };
            }
          }
          let resetPlacement = (_overflowsData$filter = overflowsData.filter((d) => d.overflows[0] <= 0).sort((a, b) => a.overflows[1] - b.overflows[1])[0]) == null ? void 0 : _overflowsData$filter.placement;
          if (!resetPlacement) {
            switch (fallbackStrategy) {
              case "bestFit": {
                var _overflowsData$filter2;
                const placement2 = (_overflowsData$filter2 = overflowsData.filter((d) => {
                  if (hasFallbackAxisSideDirection) {
                    const currentSideAxis = getSideAxis(d.placement);
                    return currentSideAxis === initialSideAxis || // Create a bias to the `y` side axis due to horizontal
                    // reading directions favoring greater width.
                    currentSideAxis === "y";
                  }
                  return true;
                }).map((d) => [d.placement, d.overflows.filter((overflow2) => overflow2 > 0).reduce((acc, overflow2) => acc + overflow2, 0)]).sort((a, b) => a[1] - b[1])[0]) == null ? void 0 : _overflowsData$filter2[0];
                if (placement2) {
                  resetPlacement = placement2;
                }
                break;
              }
              case "initialPlacement":
                resetPlacement = initialPlacement;
                break;
            }
          }
          if (placement !== resetPlacement) {
            return {
              reset: {
                placement: resetPlacement
              }
            };
          }
        }
        return {};
      }
    };
  };
  var originSides = /* @__PURE__ */ new Set(["left", "top"]);
  async function convertValueToCoords(state, options) {
    const {
      placement,
      platform: platform2,
      elements
    } = state;
    const rtl = await (platform2.isRTL == null ? void 0 : platform2.isRTL(elements.floating));
    const side = getSide(placement);
    const alignment = getAlignment(placement);
    const isVertical = getSideAxis(placement) === "y";
    const mainAxisMulti = originSides.has(side) ? -1 : 1;
    const crossAxisMulti = rtl && isVertical ? -1 : 1;
    const rawValue = evaluate(options, state);
    let {
      mainAxis,
      crossAxis,
      alignmentAxis
    } = typeof rawValue === "number" ? {
      mainAxis: rawValue,
      crossAxis: 0,
      alignmentAxis: null
    } : {
      mainAxis: rawValue.mainAxis || 0,
      crossAxis: rawValue.crossAxis || 0,
      alignmentAxis: rawValue.alignmentAxis
    };
    if (alignment && typeof alignmentAxis === "number") {
      crossAxis = alignment === "end" ? alignmentAxis * -1 : alignmentAxis;
    }
    return isVertical ? {
      x: crossAxis * crossAxisMulti,
      y: mainAxis * mainAxisMulti
    } : {
      x: mainAxis * mainAxisMulti,
      y: crossAxis * crossAxisMulti
    };
  }
  var offset = function(options) {
    if (options === void 0) {
      options = 0;
    }
    return {
      name: "offset",
      options,
      async fn(state) {
        var _middlewareData$offse, _middlewareData$arrow;
        const {
          x,
          y,
          placement,
          middlewareData
        } = state;
        const diffCoords = await convertValueToCoords(state, options);
        if (placement === ((_middlewareData$offse = middlewareData.offset) == null ? void 0 : _middlewareData$offse.placement) && (_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) {
          return {};
        }
        return {
          x: x + diffCoords.x,
          y: y + diffCoords.y,
          data: {
            ...diffCoords,
            placement
          }
        };
      }
    };
  };
  var shift = function(options) {
    if (options === void 0) {
      options = {};
    }
    return {
      name: "shift",
      options,
      async fn(state) {
        const {
          x,
          y,
          placement,
          platform: platform2
        } = state;
        const {
          mainAxis: checkMainAxis = true,
          crossAxis: checkCrossAxis = false,
          limiter = {
            fn: (_ref) => {
              let {
                x: x2,
                y: y2
              } = _ref;
              return {
                x: x2,
                y: y2
              };
            }
          },
          ...detectOverflowOptions
        } = evaluate(options, state);
        const coords = {
          x,
          y
        };
        const overflow = await platform2.detectOverflow(state, detectOverflowOptions);
        const crossAxis = getSideAxis(placement);
        const mainAxis = getOppositeAxis(crossAxis);
        let mainAxisCoord = coords[mainAxis];
        let crossAxisCoord = coords[crossAxis];
        const clampCoord = (axis, coord) => clamp2(coord + overflow[axis === "y" ? "top" : "left"], coord, coord - overflow[axis === "y" ? "bottom" : "right"]);
        if (checkMainAxis) {
          mainAxisCoord = clampCoord(mainAxis, mainAxisCoord);
        }
        if (checkCrossAxis) {
          crossAxisCoord = clampCoord(crossAxis, crossAxisCoord);
        }
        const limitedCoords = limiter.fn({
          ...state,
          [mainAxis]: mainAxisCoord,
          [crossAxis]: crossAxisCoord
        });
        return {
          ...limitedCoords,
          data: {
            x: limitedCoords.x - x,
            y: limitedCoords.y - y,
            enabled: {
              [mainAxis]: checkMainAxis,
              [crossAxis]: checkCrossAxis
            }
          }
        };
      }
    };
  };
  var size = function(options) {
    if (options === void 0) {
      options = {};
    }
    return {
      name: "size",
      options,
      async fn(state) {
        const {
          placement,
          rects,
          platform: platform2,
          elements
        } = state;
        const {
          apply = () => {
          },
          ...detectOverflowOptions
        } = evaluate(options, state);
        const overflow = await platform2.detectOverflow(state, detectOverflowOptions);
        const side = getSide(placement);
        const alignment = getAlignment(placement);
        const isYAxis = getSideAxis(placement) === "y";
        const {
          width,
          height
        } = rects.floating;
        let heightSide;
        let widthSide;
        if (side === "top" || side === "bottom") {
          heightSide = side;
          widthSide = alignment === (await (platform2.isRTL == null ? void 0 : platform2.isRTL(elements.floating)) ? "start" : "end") ? "left" : "right";
        } else {
          widthSide = side;
          heightSide = alignment === "end" ? "top" : "bottom";
        }
        const maximumClippingHeight = height - overflow.top - overflow.bottom;
        const maximumClippingWidth = width - overflow.left - overflow.right;
        const overflowAvailableHeight = min(height - overflow[heightSide], maximumClippingHeight);
        const overflowAvailableWidth = min(width - overflow[widthSide], maximumClippingWidth);
        const shiftData = state.middlewareData.shift;
        const noShift = !shiftData;
        let availableHeight = overflowAvailableHeight;
        let availableWidth = overflowAvailableWidth;
        if (shiftData != null && shiftData.enabled.x) {
          availableWidth = maximumClippingWidth;
        }
        if (shiftData != null && shiftData.enabled.y) {
          availableHeight = maximumClippingHeight;
        }
        if (noShift && !alignment) {
          if (isYAxis) {
            availableWidth = width - 2 * max(overflow.left, overflow.right);
          } else {
            availableHeight = height - 2 * max(overflow.top, overflow.bottom);
          }
        }
        await apply({
          ...state,
          availableWidth,
          availableHeight
        });
        const nextDimensions = await platform2.getDimensions(elements.floating);
        if (width !== nextDimensions.width || height !== nextDimensions.height) {
          return {
            reset: {
              rects: true
            }
          };
        }
        return {};
      }
    };
  };

  // node_modules/.pnpm/@floating-ui+utils@0.2.12/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs
  function hasWindow() {
    return typeof window !== "undefined";
  }
  function getNodeName(node) {
    if (isNode(node)) {
      return (node.nodeName || "").toLowerCase();
    }
    return "#document";
  }
  function getWindow(node) {
    var _node$ownerDocument;
    return (node == null || (_node$ownerDocument = node.ownerDocument) == null ? void 0 : _node$ownerDocument.defaultView) || window;
  }
  function getDocumentElement(node) {
    var _ref;
    return (_ref = (isNode(node) ? node.ownerDocument : node.document) || window.document) == null ? void 0 : _ref.documentElement;
  }
  function isNode(value) {
    if (!hasWindow()) {
      return false;
    }
    return value instanceof Node || value instanceof getWindow(value).Node;
  }
  function isElement(value) {
    if (!hasWindow()) {
      return false;
    }
    return value instanceof Element || value instanceof getWindow(value).Element;
  }
  function isHTMLElement(value) {
    if (!hasWindow()) {
      return false;
    }
    return value instanceof HTMLElement || value instanceof getWindow(value).HTMLElement;
  }
  function isShadowRoot(value) {
    if (!hasWindow() || typeof ShadowRoot === "undefined") {
      return false;
    }
    return value instanceof ShadowRoot || value instanceof getWindow(value).ShadowRoot;
  }
  function isOverflowElement(element2) {
    const {
      overflow,
      overflowX,
      overflowY,
      display
    } = getComputedStyle2(element2);
    return /auto|scroll|overlay|hidden|clip/.test(overflow + overflowY + overflowX) && display !== "inline" && display !== "contents";
  }
  function isTableElement(element2) {
    return /^(table|td|th)$/.test(getNodeName(element2));
  }
  function isTopLayer(element2) {
    try {
      if (element2.matches(":popover-open")) {
        return true;
      }
    } catch (_e) {
    }
    try {
      return element2.matches(":modal");
    } catch (_e) {
      return false;
    }
  }
  var willChangeRe = /transform|translate|scale|rotate|perspective|filter/;
  var containRe = /paint|layout|strict|content/;
  var isNotNone = (value) => !!value && value !== "none";
  var isWebKitValue;
  function isContainingBlock(elementOrCss) {
    const css = isElement(elementOrCss) ? getComputedStyle2(elementOrCss) : elementOrCss;
    return isNotNone(css.transform) || isNotNone(css.translate) || isNotNone(css.scale) || isNotNone(css.rotate) || isNotNone(css.perspective) || !isWebKit() && (isNotNone(css.backdropFilter) || isNotNone(css.filter)) || willChangeRe.test(css.willChange || "") || containRe.test(css.contain || "");
  }
  function getContainingBlock(element2) {
    let currentNode = getParentNode(element2);
    while (isHTMLElement(currentNode) && !isLastTraversableNode(currentNode)) {
      if (isContainingBlock(currentNode)) {
        return currentNode;
      } else if (isTopLayer(currentNode)) {
        return null;
      }
      currentNode = getParentNode(currentNode);
    }
    return null;
  }
  function isWebKit() {
    if (isWebKitValue == null) {
      isWebKitValue = typeof CSS !== "undefined" && CSS.supports && CSS.supports("-webkit-backdrop-filter", "none");
    }
    return isWebKitValue;
  }
  function isLastTraversableNode(node) {
    return /^(html|body|#document)$/.test(getNodeName(node));
  }
  function getComputedStyle2(element2) {
    return getWindow(element2).getComputedStyle(element2);
  }
  function getNodeScroll(element2) {
    if (isElement(element2)) {
      return {
        scrollLeft: element2.scrollLeft,
        scrollTop: element2.scrollTop
      };
    }
    return {
      scrollLeft: element2.scrollX,
      scrollTop: element2.scrollY
    };
  }
  function getParentNode(node) {
    if (getNodeName(node) === "html") {
      return node;
    }
    const result = (
      // Step into the shadow DOM of the parent of a slotted node.
      node.assignedSlot || // DOM Element detected.
      node.parentNode || // ShadowRoot detected.
      isShadowRoot(node) && node.host || // Fallback.
      getDocumentElement(node)
    );
    return isShadowRoot(result) ? result.host : result;
  }
  function getNearestOverflowAncestor(node) {
    const parentNode = getParentNode(node);
    if (isLastTraversableNode(parentNode)) {
      return (node.ownerDocument || node).body;
    }
    if (isHTMLElement(parentNode) && isOverflowElement(parentNode)) {
      return parentNode;
    }
    return getNearestOverflowAncestor(parentNode);
  }
  function getOverflowAncestors(node, list, traverseIframes) {
    var _node$ownerDocument2;
    if (list === void 0) {
      list = [];
    }
    if (traverseIframes === void 0) {
      traverseIframes = true;
    }
    const scrollableAncestor = getNearestOverflowAncestor(node);
    const isBody = scrollableAncestor === ((_node$ownerDocument2 = node.ownerDocument) == null ? void 0 : _node$ownerDocument2.body);
    const win = getWindow(scrollableAncestor);
    if (isBody) {
      const frameElement = getFrameElement(win);
      return list.concat(win, win.visualViewport || [], isOverflowElement(scrollableAncestor) ? scrollableAncestor : [], frameElement && traverseIframes ? getOverflowAncestors(frameElement) : []);
    } else {
      return list.concat(scrollableAncestor, getOverflowAncestors(scrollableAncestor, [], traverseIframes));
    }
  }
  function getFrameElement(win) {
    return win.parent && Object.getPrototypeOf(win.parent) ? win.frameElement : null;
  }

  // node_modules/.pnpm/@floating-ui+dom@1.8.0/node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs
  function getCssDimensions(element2) {
    const css = getComputedStyle2(element2);
    let width = parseFloat(css.width) || 0;
    let height = parseFloat(css.height) || 0;
    const hasOffset = isHTMLElement(element2);
    const offsetWidth = hasOffset ? element2.offsetWidth : width;
    const offsetHeight = hasOffset ? element2.offsetHeight : height;
    const shouldFallback = round(width) !== offsetWidth || round(height) !== offsetHeight;
    if (shouldFallback) {
      width = offsetWidth;
      height = offsetHeight;
    }
    return {
      width,
      height,
      $: shouldFallback
    };
  }
  function unwrapElement(element2) {
    return !isElement(element2) ? element2.contextElement : element2;
  }
  function getScale(element2) {
    const domElement = unwrapElement(element2);
    if (!isHTMLElement(domElement)) {
      return createCoords(1);
    }
    const rect = domElement.getBoundingClientRect();
    const {
      width,
      height,
      $
    } = getCssDimensions(domElement);
    let x = ($ ? round(rect.width) : rect.width) / width;
    let y = ($ ? round(rect.height) : rect.height) / height;
    if (!x || !Number.isFinite(x)) {
      x = 1;
    }
    if (!y || !Number.isFinite(y)) {
      y = 1;
    }
    return {
      x,
      y
    };
  }
  var noOffsets = /* @__PURE__ */ createCoords(0);
  function getVisualOffsets(element2) {
    const win = getWindow(element2);
    if (!isWebKit() || !win.visualViewport) {
      return noOffsets;
    }
    return {
      x: win.visualViewport.offsetLeft,
      y: win.visualViewport.offsetTop
    };
  }
  function shouldAddVisualOffsets(element2, isFixed, floatingOffsetParent) {
    if (isFixed === void 0) {
      isFixed = false;
    }
    return !!floatingOffsetParent && isFixed && floatingOffsetParent === getWindow(element2);
  }
  function getBoundingClientRect(element2, includeScale, isFixedStrategy, offsetParent) {
    if (includeScale === void 0) {
      includeScale = false;
    }
    if (isFixedStrategy === void 0) {
      isFixedStrategy = false;
    }
    const clientRect = element2.getBoundingClientRect();
    const domElement = unwrapElement(element2);
    let scale = createCoords(1);
    if (includeScale) {
      if (offsetParent) {
        if (isElement(offsetParent)) {
          scale = getScale(offsetParent);
        }
      } else {
        scale = getScale(element2);
      }
    }
    const visualOffsets = shouldAddVisualOffsets(domElement, isFixedStrategy, offsetParent) ? getVisualOffsets(domElement) : createCoords(0);
    let x = (clientRect.left + visualOffsets.x) / scale.x;
    let y = (clientRect.top + visualOffsets.y) / scale.y;
    let width = clientRect.width / scale.x;
    let height = clientRect.height / scale.y;
    if (domElement && offsetParent) {
      const win = getWindow(domElement);
      const offsetWin = isElement(offsetParent) ? getWindow(offsetParent) : offsetParent;
      let currentWin = win;
      let currentIFrame = getFrameElement(currentWin);
      while (currentIFrame && offsetWin !== currentWin) {
        const iframeScale = getScale(currentIFrame);
        const iframeRect = currentIFrame.getBoundingClientRect();
        const css = getComputedStyle2(currentIFrame);
        const left = iframeRect.left + (currentIFrame.clientLeft + parseFloat(css.paddingLeft)) * iframeScale.x;
        const top = iframeRect.top + (currentIFrame.clientTop + parseFloat(css.paddingTop)) * iframeScale.y;
        x *= iframeScale.x;
        y *= iframeScale.y;
        width *= iframeScale.x;
        height *= iframeScale.y;
        x += left;
        y += top;
        currentWin = getWindow(currentIFrame);
        currentIFrame = getFrameElement(currentWin);
      }
    }
    return rectToClientRect({
      width,
      height,
      x,
      y
    });
  }
  function getWindowScrollBarX(element2, rect) {
    const leftScroll = getNodeScroll(element2).scrollLeft;
    if (!rect) {
      return getBoundingClientRect(getDocumentElement(element2)).left + leftScroll;
    }
    return rect.left + leftScroll;
  }
  function getHTMLOffset(documentElement, scroll) {
    const htmlRect = documentElement.getBoundingClientRect();
    const x = htmlRect.left + scroll.scrollLeft - getWindowScrollBarX(documentElement, htmlRect);
    const y = htmlRect.top + scroll.scrollTop;
    return {
      x,
      y
    };
  }
  function convertOffsetParentRelativeRectToViewportRelativeRect(_ref) {
    let {
      elements,
      rect,
      offsetParent,
      strategy
    } = _ref;
    const isFixed = strategy === "fixed";
    const documentElement = getDocumentElement(offsetParent);
    const topLayer = elements ? isTopLayer(elements.floating) : false;
    if (offsetParent === documentElement || topLayer && isFixed) {
      return rect;
    }
    let scroll = {
      scrollLeft: 0,
      scrollTop: 0
    };
    let scale = createCoords(1);
    const offsets = createCoords(0);
    const isOffsetParentAnElement = isHTMLElement(offsetParent);
    if (isOffsetParentAnElement || !isFixed) {
      if (getNodeName(offsetParent) !== "body" || isOverflowElement(documentElement)) {
        scroll = getNodeScroll(offsetParent);
      }
      if (isOffsetParentAnElement) {
        const offsetRect = getBoundingClientRect(offsetParent);
        scale = getScale(offsetParent);
        offsets.x = offsetRect.x + offsetParent.clientLeft;
        offsets.y = offsetRect.y + offsetParent.clientTop;
      }
    }
    const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
    return {
      width: rect.width * scale.x,
      height: rect.height * scale.y,
      x: rect.x * scale.x - scroll.scrollLeft * scale.x + offsets.x + htmlOffset.x,
      y: rect.y * scale.y - scroll.scrollTop * scale.y + offsets.y + htmlOffset.y
    };
  }
  function getClientRects(element2) {
    return element2.getClientRects ? Array.from(element2.getClientRects()) : [];
  }
  function getDocumentRect(html) {
    const scroll = getNodeScroll(html);
    const body = html.ownerDocument.body;
    const width = max(html.scrollWidth, html.clientWidth, body.scrollWidth, body.clientWidth);
    const height = max(html.scrollHeight, html.clientHeight, body.scrollHeight, body.clientHeight);
    let x = -scroll.scrollLeft + getWindowScrollBarX(html);
    const y = -scroll.scrollTop;
    if (getComputedStyle2(body).direction === "rtl") {
      x += max(html.clientWidth, body.clientWidth) - width;
    }
    return {
      width,
      height,
      x,
      y
    };
  }
  var SCROLLBAR_MAX = 25;
  function getViewportRect(element2, strategy, rootBoundary) {
    if (rootBoundary === void 0) {
      rootBoundary = "viewport";
    }
    const isLayoutViewport = rootBoundary === "layoutViewport";
    const win = getWindow(element2);
    const html = getDocumentElement(element2);
    const visualViewport = win.visualViewport;
    let width = html.clientWidth;
    let height = html.clientHeight;
    let x = 0;
    let y = 0;
    if (visualViewport) {
      const layoutRelativeClientCoords = !isWebKit() || strategy === "fixed";
      if (isLayoutViewport) {
        if (!layoutRelativeClientCoords) {
          x = -visualViewport.offsetLeft;
          y = -visualViewport.offsetTop;
        }
      } else {
        width = visualViewport.width;
        height = visualViewport.height;
        if (layoutRelativeClientCoords) {
          x = visualViewport.offsetLeft;
          y = visualViewport.offsetTop;
        }
      }
    }
    const windowScrollbarX = getWindowScrollBarX(html);
    if (windowScrollbarX <= 0) {
      const doc = html.ownerDocument;
      const body = doc.body;
      const bodyStyles = getComputedStyle(body);
      const bodyMarginInline = doc.compatMode === "CSS1Compat" ? parseFloat(bodyStyles.marginLeft) + parseFloat(bodyStyles.marginRight) || 0 : 0;
      const reservedWidth = Math.abs(html.clientWidth - body.clientWidth - bodyMarginInline);
      const gutter = getComputedStyle(html).scrollbarGutter === "stable both-edges" ? reservedWidth / 2 : reservedWidth;
      if (gutter <= SCROLLBAR_MAX) {
        width -= gutter;
      }
    }
    return {
      width,
      height,
      x,
      y
    };
  }
  function getInnerBoundingClientRect(element2, strategy) {
    const clientRect = getBoundingClientRect(element2, true, strategy === "fixed");
    const top = clientRect.top + element2.clientTop;
    const left = clientRect.left + element2.clientLeft;
    const scale = getScale(element2);
    const width = element2.clientWidth * scale.x;
    const height = element2.clientHeight * scale.y;
    const x = left * scale.x;
    const y = top * scale.y;
    return {
      width,
      height,
      x,
      y
    };
  }
  function getClientRectFromClippingAncestor(element2, clippingAncestor, strategy) {
    let rect;
    if (clippingAncestor === "viewport" || clippingAncestor === "layoutViewport") {
      rect = getViewportRect(element2, strategy, clippingAncestor);
    } else if (clippingAncestor === "document") {
      rect = getDocumentRect(getDocumentElement(element2));
    } else if (isElement(clippingAncestor)) {
      rect = getInnerBoundingClientRect(clippingAncestor, strategy);
    } else {
      const visualOffsets = getVisualOffsets(element2);
      rect = {
        x: clippingAncestor.x - visualOffsets.x,
        y: clippingAncestor.y - visualOffsets.y,
        width: clippingAncestor.width,
        height: clippingAncestor.height
      };
    }
    return rectToClientRect(rect);
  }
  function getClippingElementAncestors(element2, cache) {
    const cachedResult = cache.get(element2);
    if (cachedResult) {
      return cachedResult;
    }
    let result = getOverflowAncestors(element2, [], false).filter((el) => isElement(el) && getNodeName(el) !== "body");
    let lastKeptComputedStyle = null;
    const elementIsFixed = getComputedStyle2(element2).position === "fixed";
    let currentNode = elementIsFixed ? getParentNode(element2) : element2;
    while (isElement(currentNode) && !isLastTraversableNode(currentNode)) {
      const computedStyle = getComputedStyle2(currentNode);
      const currentNodeIsContaining = isContainingBlock(currentNode);
      const lastPosition = lastKeptComputedStyle ? lastKeptComputedStyle.position : elementIsFixed ? "fixed" : "";
      const shouldDropCurrentNode = !currentNodeIsContaining && (lastPosition === "fixed" || lastPosition === "absolute" && computedStyle.position === "static");
      if (shouldDropCurrentNode) {
        result = result.filter((ancestor) => ancestor !== currentNode);
      } else {
        lastKeptComputedStyle = computedStyle;
      }
      currentNode = getParentNode(currentNode);
    }
    cache.set(element2, result);
    return result;
  }
  function getClippingRect(_ref) {
    let {
      element: element2,
      boundary,
      rootBoundary,
      strategy
    } = _ref;
    const elementClippingAncestors = boundary === "clippingAncestors" ? isTopLayer(element2) ? [] : getClippingElementAncestors(element2, this._c) : [].concat(boundary);
    const clippingAncestors = [...elementClippingAncestors, rootBoundary];
    const firstRect = getClientRectFromClippingAncestor(element2, clippingAncestors[0], strategy);
    let top = firstRect.top;
    let right = firstRect.right;
    let bottom = firstRect.bottom;
    let left = firstRect.left;
    for (let i = 1; i < clippingAncestors.length; i++) {
      const rect = getClientRectFromClippingAncestor(element2, clippingAncestors[i], strategy);
      top = max(rect.top, top);
      right = min(rect.right, right);
      bottom = min(rect.bottom, bottom);
      left = max(rect.left, left);
    }
    return {
      width: right - left,
      height: bottom - top,
      x: left,
      y: top
    };
  }
  function getDimensions(element2) {
    const {
      width,
      height
    } = getCssDimensions(element2);
    return {
      width,
      height
    };
  }
  function getRectRelativeToOffsetParent(element2, offsetParent, strategy) {
    const isOffsetParentAnElement = isHTMLElement(offsetParent);
    const documentElement = getDocumentElement(offsetParent);
    const isFixed = strategy === "fixed";
    const rect = getBoundingClientRect(element2, true, isFixed, offsetParent);
    let scroll = {
      scrollLeft: 0,
      scrollTop: 0
    };
    const offsets = createCoords(0);
    if (isOffsetParentAnElement || !isFixed) {
      if (getNodeName(offsetParent) !== "body" || isOverflowElement(documentElement)) {
        scroll = getNodeScroll(offsetParent);
      }
      if (isOffsetParentAnElement) {
        const offsetRect = getBoundingClientRect(offsetParent, true, isFixed, offsetParent);
        offsets.x = offsetRect.x + offsetParent.clientLeft;
        offsets.y = offsetRect.y + offsetParent.clientTop;
      }
    }
    if (!isOffsetParentAnElement && documentElement) {
      offsets.x = getWindowScrollBarX(documentElement);
    }
    const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
    const x = rect.left + scroll.scrollLeft - offsets.x - htmlOffset.x;
    const y = rect.top + scroll.scrollTop - offsets.y - htmlOffset.y;
    return {
      x,
      y,
      width: rect.width,
      height: rect.height
    };
  }
  function isStaticPositioned(element2) {
    return getComputedStyle2(element2).position === "static";
  }
  function getTrueOffsetParent(element2, polyfill) {
    if (!isHTMLElement(element2) || getComputedStyle2(element2).position === "fixed") {
      return null;
    }
    if (polyfill) {
      return polyfill(element2);
    }
    let rawOffsetParent = element2.offsetParent;
    if (getDocumentElement(element2) === rawOffsetParent) {
      rawOffsetParent = rawOffsetParent.ownerDocument.body;
    }
    return rawOffsetParent;
  }
  function getOffsetParent(element2, polyfill) {
    const win = getWindow(element2);
    if (isTopLayer(element2)) {
      return win;
    }
    if (!isHTMLElement(element2)) {
      let svgOffsetParent = getParentNode(element2);
      while (svgOffsetParent && !isLastTraversableNode(svgOffsetParent)) {
        if (isElement(svgOffsetParent) && !isStaticPositioned(svgOffsetParent)) {
          return svgOffsetParent;
        }
        svgOffsetParent = getParentNode(svgOffsetParent);
      }
      return win;
    }
    let offsetParent = getTrueOffsetParent(element2, polyfill);
    while (offsetParent && isTableElement(offsetParent) && isStaticPositioned(offsetParent)) {
      offsetParent = getTrueOffsetParent(offsetParent, polyfill);
    }
    if (offsetParent && isLastTraversableNode(offsetParent) && isStaticPositioned(offsetParent) && !isContainingBlock(offsetParent)) {
      return win;
    }
    return offsetParent || getContainingBlock(element2) || win;
  }
  var getElementRects = async function(data) {
    const getOffsetParentFn = this.getOffsetParent || getOffsetParent;
    const getDimensionsFn = this.getDimensions;
    const floatingDimensions = await getDimensionsFn(data.floating);
    return {
      reference: getRectRelativeToOffsetParent(data.reference, await getOffsetParentFn(data.floating), data.strategy),
      floating: {
        x: 0,
        y: 0,
        width: floatingDimensions.width,
        height: floatingDimensions.height
      }
    };
  };
  function isRTL(element2) {
    return getComputedStyle2(element2).direction === "rtl";
  }
  var platform = {
    convertOffsetParentRelativeRectToViewportRelativeRect,
    getDocumentElement,
    getClippingRect,
    getOffsetParent,
    getElementRects,
    getClientRects,
    getDimensions,
    getScale,
    isElement,
    isRTL
  };
  function rectsAreEqual(a, b) {
    return a.x === b.x && a.y === b.y && a.width === b.width && a.height === b.height;
  }
  function observeMove(element2, onMove, ancestorResize) {
    let io = null;
    let timeoutId;
    const root = getDocumentElement(element2);
    function cleanup() {
      var _io;
      clearTimeout(timeoutId);
      (_io = io) == null || _io.disconnect();
      io = null;
    }
    function refresh(skip, threshold) {
      if (skip === void 0) {
        skip = false;
      }
      if (threshold === void 0) {
        threshold = 1;
      }
      cleanup();
      const elementRectForRootMargin = element2.getBoundingClientRect();
      const {
        left,
        top,
        width,
        height
      } = elementRectForRootMargin;
      if (!skip) {
        onMove();
      }
      if (!width || !height) {
        return;
      }
      const insetTop = floor(top);
      const insetRight = floor(root.clientWidth - (left + width));
      const insetBottom = floor(root.clientHeight - (top + height));
      const insetLeft = floor(left);
      const rootMargin = -insetTop + "px " + -insetRight + "px " + -insetBottom + "px " + -insetLeft + "px";
      const options = {
        rootMargin,
        threshold: max(0, min(1, threshold)) || 1
      };
      let isFirstUpdate = true;
      function handleObserve(entries) {
        const ratio = entries[0].intersectionRatio;
        if (!rectsAreEqual(elementRectForRootMargin, element2.getBoundingClientRect())) {
          return refresh();
        }
        if (ratio !== threshold) {
          if (!isFirstUpdate) {
            return refresh();
          }
          if (!ratio) {
            timeoutId = setTimeout(() => {
              refresh(false, 1e-7);
            }, 1e3);
          } else {
            refresh(false, ratio);
          }
        }
        isFirstUpdate = false;
      }
      try {
        io = new IntersectionObserver(handleObserve, {
          ...options,
          // Handle <iframe>s
          root: root.ownerDocument
        });
      } catch (_e) {
        io = new IntersectionObserver(handleObserve, options);
      }
      io.observe(element2);
    }
    const win = getWindow(element2);
    const handleResize = () => refresh(ancestorResize);
    win.addEventListener("resize", handleResize);
    refresh(true);
    return () => {
      win.removeEventListener("resize", handleResize);
      cleanup();
    };
  }
  function autoUpdate(reference, floating2, update, options) {
    if (options === void 0) {
      options = {};
    }
    const {
      ancestorScroll = true,
      ancestorResize = true,
      elementResize = typeof ResizeObserver === "function",
      layoutShift = typeof IntersectionObserver === "function",
      animationFrame = false
    } = options;
    const referenceEl = unwrapElement(reference);
    const ancestors = ancestorScroll || ancestorResize ? [...referenceEl ? getOverflowAncestors(referenceEl) : [], ...floating2 ? getOverflowAncestors(floating2) : []] : [];
    ancestors.forEach((ancestor) => {
      ancestorScroll && ancestor.addEventListener("scroll", update);
      ancestorResize && ancestor.addEventListener("resize", update);
    });
    const cleanupIo = referenceEl && layoutShift ? observeMove(referenceEl, update, ancestorResize) : null;
    let reobserveFrame = -1;
    let resizeObserver = null;
    if (elementResize) {
      resizeObserver = new ResizeObserver((_ref) => {
        let [firstEntry] = _ref;
        if (firstEntry && firstEntry.target === referenceEl && resizeObserver && floating2) {
          resizeObserver.unobserve(floating2);
          cancelAnimationFrame(reobserveFrame);
          reobserveFrame = requestAnimationFrame(() => {
            var _resizeObserver;
            (_resizeObserver = resizeObserver) == null || _resizeObserver.observe(floating2);
          });
        }
        update();
      });
      if (referenceEl && !animationFrame) {
        resizeObserver.observe(referenceEl);
      }
      if (floating2) {
        resizeObserver.observe(floating2);
      }
    }
    let frameId;
    let prevRefRect = animationFrame ? getBoundingClientRect(reference) : null;
    if (animationFrame) {
      frameLoop();
    }
    function frameLoop() {
      const nextRefRect = getBoundingClientRect(reference);
      if (prevRefRect && !rectsAreEqual(prevRefRect, nextRefRect)) {
        update();
      }
      prevRefRect = nextRefRect;
      frameId = requestAnimationFrame(frameLoop);
    }
    update();
    return () => {
      var _resizeObserver2;
      ancestors.forEach((ancestor) => {
        ancestorScroll && ancestor.removeEventListener("scroll", update);
        ancestorResize && ancestor.removeEventListener("resize", update);
      });
      cleanupIo == null || cleanupIo();
      (_resizeObserver2 = resizeObserver) == null || _resizeObserver2.disconnect();
      resizeObserver = null;
      if (animationFrame) {
        cancelAnimationFrame(frameId);
      }
    };
  }
  var offset2 = offset;
  var shift2 = shift;
  var flip2 = flip;
  var size2 = size;
  var computePosition2 = (reference, floating2, options) => {
    const cache = /* @__PURE__ */ new Map();
    const mergedOptions = options != null ? options : {};
    const platformWithCache = {
      ...platform,
      ...mergedOptions.platform,
      _c: cache
    };
    return computePosition(reference, floating2, {
      ...mergedOptions,
      platform: platformWithCache
    });
  };

  // packages/modules/positioning/src/web/floating-ui-host.ts
  function toPlacement(config2) {
    return config2.align === "center" ? config2.side : `${config2.side}-${config2.align}`;
  }
  function fromPlacement(placement) {
    const [side, align] = placement.split("-");
    return { side, align: align ?? "center" };
  }
  function isElement2(value) {
    return typeof HTMLElement !== "undefined" && value instanceof HTMLElement;
  }
  function virtualReferenceFor(anchor2) {
    return {
      getBoundingClientRect() {
        const rect = anchor2.getBoundingClientRect();
        const shift3 = ownAnchorTranslation(anchor2);
        return {
          x: rect.x - shift3.x,
          y: rect.y - shift3.y,
          left: rect.left - shift3.x,
          top: rect.top - shift3.y,
          right: rect.right - shift3.x,
          bottom: rect.bottom - shift3.y,
          width: rect.width,
          height: rect.height,
          toJSON: () => ({})
        };
      }
    };
  }
  function ownAnchorTranslation(anchor2) {
    let x = 0;
    let y = 0;
    if (typeof getComputedStyle !== "function") return { x, y };
    const style = getComputedStyle(anchor2);
    const transform = style.transform;
    if (transform && transform !== "none" && typeof DOMMatrixReadOnly !== "undefined") {
      const matrix = new DOMMatrixReadOnly(transform);
      x += matrix.m41;
      y += matrix.m42;
    }
    const translate = style.translate;
    if (translate && translate !== "none") {
      const [tx, ty] = translate.trim().split(/\s+/);
      x += cssLengthToPx(tx, rectBasis(anchor2, "x"));
      y += cssLengthToPx(ty ?? "0px", rectBasis(anchor2, "y"));
    }
    return { x, y };
  }
  function rectBasis(anchor2, axis) {
    const rect = anchor2.getBoundingClientRect();
    return axis === "x" ? rect.width : rect.height;
  }
  function cssLengthToPx(value, basis) {
    if (!value) return 0;
    const text = value.trim();
    if (!text || text === "none") return 0;
    if (text.endsWith("%")) {
      const percent = Number.parseFloat(text);
      return Number.isFinite(percent) ? percent / 100 * basis : 0;
    }
    const pixels = Number.parseFloat(text);
    return Number.isFinite(pixels) ? pixels : 0;
  }
  function positionReference(anchor2, config2) {
    return config2.excludeAnchorTranslation === true ? virtualReferenceFor(anchor2) : anchor2;
  }
  function middlewareFor(config2, isCurrent, available) {
    const middleware = [
      offset2({ mainAxis: config2.sideOffset, crossAxis: config2.alignOffset })
    ];
    const boundary = config2.collisionBoundary === "viewport" ? [] : "clippingAncestors";
    if (config2.avoidCollisions) {
      middleware.push(
        flip2({ boundary, rootBoundary: "viewport", padding: config2.collisionPadding }),
        shift2({ boundary, rootBoundary: "viewport", padding: config2.collisionPadding })
      );
    }
    middleware.push(
      size2({
        boundary,
        rootBoundary: "viewport",
        padding: config2.collisionPadding,
        apply({ availableWidth, availableHeight, rects, elements }) {
          if (!isCurrent()) return;
          available?.(availableWidth, availableHeight);
          if (!isCurrent()) return;
          const style = elements.floating.style;
          for (const [name, value] of [
            ["--proto-ui-anchor-width", `${rects.reference.width}px`],
            ["--proto-ui-anchor-height", `${rects.reference.height}px`],
            ["--proto-ui-available-width", `${availableWidth}px`],
            ["--proto-ui-available-height", `${availableHeight}px`]
          ]) {
            if (!isCurrent()) return;
            style.setProperty(name, value);
          }
        }
      })
    );
    return middleware;
  }
  function createEdgeSizeLease(connection, current) {
    const descriptor = connection.sizeMatch;
    const frame = connection.floating;
    const reference = descriptor.reference;
    const targets = descriptor.targets;
    const complete = isElement2(frame) && isElement2(reference) && targets.every(isElement2);
    const valid = !connection.targetAlignment && complete && reference === connection.anchor && targets.length > 0 && targets.every(isElement2) && new Set(targets).size === targets.length && targets.every(
      (target) => frame.contains(target) && target !== frame && target.ownerDocument === frame.ownerDocument
    ) && reference.ownerDocument === frame.ownerDocument;
    const missing = frame == null || reference == null || targets.some((target) => target == null);
    let terminal = valid ? null : missing ? { status: "pending-target", reason: "missing-target" } : { status: "unavailable", reason: "invalid-association" };
    const sizeLease = valid ? createBorderBoxSizeLease(reference, targets, current) : null;
    const frameStyle = valid ? ownStyles(frame) : null;
    let wroteWidth = false;
    let minimum = 0;
    const fail = (reason) => {
      sizeLease?.abort(reason);
      frameStyle?.restore();
      terminal = { status: "unavailable", reason };
      return terminal;
    };
    const convert = (result) => {
      if (result.kind === "pending") return { status: "pending-target", reason: "missing-target" };
      if (result.reason === "detached-target") {
        return { status: "pending-target", reason: "detached-target" };
      }
      return fail(result.reason);
    };
    return {
      observed: valid ? [reference, frame, ...targets] : [],
      prepare() {
        if (terminal) return terminal;
        if (!current() || !isElement2(frame) || !sizeLease || !frameStyle)
          return { status: "pending-target", reason: "detached-target" };
        if (!frameStyle.isCurrent()) return fail("ownership-lost");
        const prepared = sizeLease.prepare();
        if (prepared.kind !== "prepared") return convert(prepared);
        const gutters = targets.map(
          (target) => measureBorderBoxInlineGutter(target, frame)
        );
        if (gutters.some((gutter) => gutter === null)) return fail("invalid-geometry");
        minimum = prepared.width + Math.max(...gutters);
        if (!current()) return { status: "pending-target", reason: "detached-target" };
        const frameWidth = frame.offsetWidth;
        if (!current()) return { status: "pending-target", reason: "detached-target" };
        if (wroteWidth || frameWidth < minimum) {
          if (!wroteWidth && (frame.style.getPropertyValue("width") && !hasOwnedStyle(frame, "width") || frame.style.getPropertyValue("inline-size") && !hasOwnedStyle(frame, "inline-size")))
            return fail("size-conflict");
          const style = frame.ownerDocument.defaultView?.getComputedStyle(frame);
          if (!style) return fail("invalid-geometry");
          const chrome = style.boxSizing === "border-box" ? 0 : Number.parseFloat(style.paddingLeft) + Number.parseFloat(style.paddingRight) + Number.parseFloat(style.borderLeftWidth) + Number.parseFloat(style.borderRightWidth);
          const width = minimum - chrome;
          if (!Number.isFinite(width) || chrome < 0) return fail("invalid-geometry");
          if (width <= 0) return fail("size-conflict");
          if (!frameStyle.write("width", `${width}px`)) return fail("ownership-lost");
          wroteWidth = true;
        }
        return { width: prepared.width, height: prepared.height };
      },
      verify(available) {
        if (terminal) return terminal;
        if (!current() || !isElement2(frame) || !sizeLease || !frameStyle)
          return { status: "pending-target", reason: "detached-target" };
        if (!frameStyle.isCurrent()) return fail("ownership-lost");
        const verified = sizeLease.verify();
        if (verified.kind === "reference-changed") return { status: "reference-changed" };
        if (verified.kind !== "matched") return convert(verified);
        if (!Number.isFinite(frame.offsetWidth) || !Number.isFinite(frame.offsetHeight))
          return fail("invalid-geometry");
        if (frame.offsetWidth <= 0 || frame.offsetHeight <= 0)
          return { status: "pending-target", reason: "missing-target" };
        if (frame.offsetWidth + 1 < minimum || available && (frame.offsetWidth > available.width + 1 || frame.offsetHeight > available.height + 1))
          return fail("size-conflict");
        for (const target of targets) {
          const clipped = hasBorderBoxInlineClipping(target, frame);
          if (clipped !== false) return fail(clipped === null ? "invalid-geometry" : "size-conflict");
        }
        return { status: "applied" };
      },
      fail,
      dispose() {
        sizeLease?.restore();
        frameStyle?.restore();
      }
    };
  }
  function pinAnchoredStrategy(floating2, strategy, styles) {
    if (floating2.style.position !== strategy || hasOwnedStyle(floating2, "position"))
      styles.write("position", strategy);
    for (const name of ["top", "left"]) {
      if (floating2.style[name] === "" || hasOwnedStyle(floating2, name))
        styles.write(name, floating2.style[name] || "0px");
    }
  }
  function createEdgeAnchoredPositionHost() {
    return {
      attach(initial) {
        let connection = initial;
        let disposed = false;
        let generation = 0;
        let cleanup = null;
        let sizingEpoch = 0;
        let sizing = null;
        let sizeObservers = [];
        let strategyPin = null;
        const retireStrategyPin = () => {
          const previous = strategyPin;
          strategyPin = null;
          previous?.styles.restore();
        };
        const retireSizing = () => {
          sizingEpoch++;
          for (const observer of sizeObservers) observer.disconnect();
          sizeObservers = [];
          const previous = sizing;
          sizing = null;
          previous?.dispose();
        };
        const referenceFor = (anchor2, config2) => {
          if (isElement2(anchor2))
            return {
              element: anchor2,
              reference: positionReference(anchor2, config2),
              isLive: () => true
            };
          return resolveWebInputOriginAnchor(anchor2);
        };
        const position = async () => {
          const current = connection;
          const { anchor: anchor2, floating: floating2, config: config2 } = current;
          const version = ++generation;
          const reference = referenceFor(anchor2, config2);
          const isCurrent = () => !disposed && version === generation && !!reference?.isLive() && (!strategyPin || strategyPin.styles.isCurrent());
          if (disposed) return;
          if (!reference || !isElement2(floating2)) {
            if (current.sizeMatch && version === generation) {
              const ownSizing = sizing;
              const prepared = ownSizing?.prepare();
              if (!disposed && version === generation && ownSizing === sizing)
                current.onSizeMatch?.(
                  prepared && "status" in prepared ? prepared : { status: "pending-target", reason: "missing-target" }
                );
            }
            return;
          }
          if (!strategyPin || strategyPin.target !== floating2) {
            retireStrategyPin();
            strategyPin = { target: floating2, styles: ownStyles(floating2) };
          }
          pinAnchoredStrategy(floating2, config2.strategy, strategyPin.styles);
          if (!isCurrent()) return;
          if (sizing) {
            const ownSizing = sizing;
            for (let pass = 0; pass < 4; pass++) {
              if (!isCurrent() || ownSizing !== sizing) return;
              const prepared = ownSizing.prepare();
              if ("status" in prepared) {
                if (isCurrent()) current.onSizeMatch?.(prepared);
                return;
              }
              let available = null;
              let result2;
              try {
                result2 = await computePosition2(reference.reference, floating2, {
                  placement: toPlacement(config2),
                  strategy: config2.strategy,
                  middleware: middlewareFor(config2, isCurrent, (width, height) => {
                    available = { width, height };
                  })
                });
              } catch (error) {
                if (isCurrent() && ownSizing === sizing)
                  current.onSizeMatch?.(ownSizing.fail("invalid-geometry"));
                return;
              }
              if (!isCurrent() || ownSizing !== sizing) return;
              const verified = ownSizing.verify(available);
              if (verified.status === "reference-changed") continue;
              if (verified.status !== "applied") {
                if (isCurrent()) current.onSizeMatch?.(verified);
                return;
              }
              retireStrategyPin();
              for (const [name, value] of [
                ["position", result2.strategy],
                ["left", `${result2.x}px`],
                ["top", `${result2.y}px`]
              ]) {
                if (!isCurrent() || ownSizing !== sizing) return;
                floating2.style.setProperty(name, value);
              }
              const resolved2 = fromPlacement(result2.placement);
              if (!isCurrent() || ownSizing !== sizing) return;
              floating2.dataset.side = resolved2.side;
              if (!isCurrent() || ownSizing !== sizing) return;
              floating2.dataset.align = resolved2.align;
              if (!isCurrent() || ownSizing !== sizing) return;
              const placed = ownSizing.verify(available);
              if (placed.status === "reference-changed") continue;
              if (placed.status !== "applied") {
                if (isCurrent()) current.onSizeMatch?.(placed);
                return;
              }
              current.onResolved?.({ ...resolved2, strategy: result2.strategy });
              if (!isCurrent() || ownSizing !== sizing) return;
              const delivered = ownSizing.verify(available);
              if (delivered.status === "reference-changed") continue;
              if (isCurrent() && ownSizing === sizing) current.onSizeMatch?.(delivered);
              return;
            }
            if (isCurrent() && ownSizing === sizing)
              current.onSizeMatch?.(ownSizing.fail("invalid-geometry"));
            return;
          }
          const result = await computePosition2(reference.reference, floating2, {
            placement: toPlacement(config2),
            strategy: config2.strategy,
            middleware: middlewareFor(config2, isCurrent)
          });
          if (!isCurrent()) return;
          retireStrategyPin();
          if (!isCurrent()) return;
          Object.assign(floating2.style, {
            position: result.strategy,
            left: `${result.x}px`,
            top: `${result.y}px`
          });
          const resolved = fromPlacement(result.placement);
          floating2.dataset.side = resolved.side;
          floating2.dataset.align = resolved.align;
          current.onResolved?.({ ...resolved, strategy: result.strategy });
        };
        const restart = () => {
          cleanup?.();
          cleanup = null;
          retireSizing();
          retireStrategyPin();
          if (connection.sizeMatch) {
            const epoch2 = sizingEpoch;
            sizing = createEdgeSizeLease(connection, () => !disposed && epoch2 === sizingEpoch);
            const view = isElement2(connection.floating) ? connection.floating.ownerDocument.defaultView : null;
            if (typeof view?.ResizeObserver === "function") {
              sizeObservers = ["content-box", "border-box"].map((box2) => {
                const observer = new view.ResizeObserver(() => {
                  if (!disposed && epoch2 === sizingEpoch) void position();
                });
                for (const target of sizing.observed) observer.observe(target, { box: box2 });
                return observer;
              });
            }
          }
          const { anchor: anchor2, floating: floating2 } = connection;
          const reference = referenceFor(anchor2, connection.config);
          if (!reference || !isElement2(floating2)) {
            if (connection.sizeMatch) void position();
            return;
          }
          const stopAuto = autoUpdate(reference.reference, floating2, position, {
            animationFrame: false
          });
          const stopRoot = observeRootSpace(reference.element.ownerDocument, () => {
            void position();
          });
          const ownerDocument = reference.element.ownerDocument;
          const onCapturedScroll = () => {
            void position();
          };
          ownerDocument.addEventListener("scroll", onCapturedScroll, true);
          const stopInvalidation = resolveWebInputOriginAnchor(anchor2)?.subscribeInvalidation(() => {
            generation++;
            retireSizing();
            retireStrategyPin();
            cleanup?.();
            cleanup = null;
          });
          cleanup = () => {
            stopAuto();
            stopRoot();
            stopInvalidation?.();
            ownerDocument.removeEventListener("scroll", onCapturedScroll, true);
          };
        };
        restart();
        return {
          update(next) {
            if (disposed) return;
            generation += 1;
            const targetsChanged = !Object.is(connection.anchor, next.anchor) || !Object.is(connection.floating, next.floating) || Boolean(connection.targetAlignment) !== Boolean(next.targetAlignment) || Boolean(connection.sizeMatch) !== Boolean(next.sizeMatch) || !!connection.sizeMatch && !!next.sizeMatch && (connection.sizeMatch.reference !== next.sizeMatch.reference || connection.sizeMatch.targets.length !== next.sizeMatch.targets.length || connection.sizeMatch.targets.some(
              (target, index) => target !== next.sizeMatch.targets[index]
            ));
            connection = next;
            if (targetsChanged || next.sizeMatch) restart();
            else void position();
          },
          requestUpdate() {
            void position();
          },
          dispose() {
            disposed = true;
            generation += 1;
            retireSizing();
            retireStrategyPin();
            cleanup?.();
            cleanup = null;
          }
        };
      }
    };
  }
  function createFloatingUiAnchoredPositionHost() {
    const edge = createEdgeAnchoredPositionHost();
    return {
      supportsTargetAlignment: true,
      supportsSizeMatch: true,
      attach(initial) {
        let connection = initial;
        let disposed = false;
        const acquire = (next) => next.targetAlignment && !next.sizeMatch ? createTargetAlignmentLease(next) : edge.attach(next);
        let lease2 = acquire(initial);
        let generation = 0;
        return {
          update(next) {
            if (disposed) return;
            const changed = Boolean(connection.targetAlignment && !connection.sizeMatch) !== Boolean(next.targetAlignment && !next.sizeMatch);
            connection = next;
            if (!changed && lease2) {
              lease2.update(next);
              return;
            }
            const request = ++generation;
            const previous = lease2;
            lease2 = null;
            previous?.dispose();
            if (disposed || request !== generation || connection !== next) return;
            const acquired = acquire(next);
            if (disposed || request !== generation || connection !== next) acquired.dispose();
            else lease2 = acquired;
          },
          requestUpdate() {
            if (!disposed) lease2?.requestUpdate();
          },
          dispose() {
            if (disposed) return;
            disposed = true;
            generation++;
            const previous = lease2;
            lease2 = null;
            previous?.dispose();
          }
        };
      }
    };
  }

  // anchored-positioning-cold-size-probe.ts
  var labels = ["Web Components", "React", "Vue", "Vue 2"];
  var longHeights = [104, 64, 64, 64];
  var anchor;
  var floating;
  var originalFloating;
  var surface;
  var viewport;
  var rows = [];
  var lease;
  var config;
  var composition;
  var epoch = 0;
  var natural;
  var resolutions = [];
  var box = (element2) => element2.getBoundingClientRect().toJSON();
  var layer = (element2) => {
    const computed = getComputedStyle(element2);
    return {
      id: element2.id,
      connected: element2.isConnected,
      box: box(element2),
      clientHeight: element2.clientHeight,
      offsetHeight: element2.offsetHeight,
      scrollHeight: element2.scrollHeight,
      scrollTop: element2.scrollTop,
      display: computed.display,
      maxHeight: computed.maxHeight,
      overflowY: computed.overflowY,
      position: computed.position,
      transform: computed.transform,
      availableHeight: computed.getPropertyValue("--proto-ui-available-height"),
      availableWidth: computed.getPropertyValue("--proto-ui-available-width"),
      inlineStyle: element2.getAttribute("style")
    };
  };
  var facts = () => ({
    composition,
    epoch,
    sameContent: document.getElementById("floating") === originalFloating,
    sameRows: rows.every((row, index) => document.getElementById("row-" + index) === row),
    natural,
    side: floating.dataset.side ?? null,
    align: floating.dataset.align ?? null,
    anchor: box(anchor),
    frame: layer(floating),
    surface: surface ? layer(surface) : null,
    viewport: layer(viewport),
    window: { width: innerWidth, height: innerHeight },
    rows: rows.map((row) => {
      const bounds = row.getBoundingClientRect();
      const center = document.elementFromPoint(
        bounds.x + bounds.width / 2,
        bounds.y + bounds.height / 2
      );
      const range = document.createRange();
      range.selectNodeContents(row.firstElementChild);
      return {
        text: row.textContent,
        box: bounds.toJSON(),
        lines: [...range.getClientRects()].map((entry) => entry.toJSON()),
        ownsCenter: center === row || !!center && row.contains(center)
      };
    }),
    resolutions: resolutions.slice()
  });
  var attach = () => {
    const ownEpoch = ++epoch;
    lease = createFloatingUiAnchoredPositionHost().attach({
      anchor,
      floating,
      config,
      onResolved(snapshot) {
        if (resolutions.length < 48) {
          resolutions.push({
            epoch: ownEpoch,
            at: performance.now(),
            snapshot,
            frame: layer(floating),
            viewport: layer(viewport)
          });
        }
      }
    });
  };
  var create = (options) => {
    lease?.dispose();
    resolutions.length = 0;
    epoch = 0;
    composition = options.composition;
    document.body.replaceChildren();
    anchor = document.createElement("button");
    anchor.id = "anchor";
    anchor.type = "button";
    anchor.textContent = "Anchor";
    floating = document.createElement("div");
    originalFloating = floating;
    floating.id = "floating";
    floating.className = "floating " + composition;
    floating.setAttribute("role", "listbox");
    surface = null;
    viewport = floating;
    if (composition === "nested") {
      surface = document.createElement("div");
      surface.id = "surface";
      surface.className = "surface";
      viewport = document.createElement("div");
      viewport.id = "viewport";
      viewport.className = "viewport";
      surface.append(viewport);
      floating.append(surface);
    }
    rows = labels.map((label, index) => {
      const row = document.createElement("div");
      row.id = "row-" + index;
      row.className = "row";
      row.setAttribute("role", "option");
      row.style.height = (options.short ? 40 : longHeights[index]) + "px";
      const text = document.createElement("span");
      text.textContent = label;
      row.append(text);
      viewport.append(row);
      return row;
    });
    document.body.append(anchor, floating);
    natural = {
      frame: box(floating),
      viewport: box(viewport),
      rows: rows.map(box)
    };
    if (options.hidden) floating.style.display = "none";
    config = {
      side: "bottom",
      align: "start",
      sideOffset: 4,
      alignOffset: 0,
      strategy: "fixed",
      avoidCollisions: options.avoidCollisions,
      collisionBoundary: "clippingAncestors",
      collisionPadding: 10
    };
    attach();
    return facts();
  };
  var hiddenLayoutCheckpoint = async () => {
    await new Promise((resolve) => requestAnimationFrame(resolve));
    await new Promise((resolve) => requestAnimationFrame(resolve));
    return facts();
  };
  var reopenWithLongContent = () => {
    floating.style.display = "none";
    lease.dispose();
    rows.forEach((row, index) => {
      row.style.height = longHeights[index] + "px";
    });
    attach();
    return facts();
  };
  var revealAndRequestUpdate = () => {
    floating.style.removeProperty("display");
    lease.requestUpdate();
    return facts();
  };
  globalThis.positioningColdSizeFixture = {
    create,
    facts,
    hiddenLayoutCheckpoint,
    reopenWithLongContent,
    revealAndRequestUpdate,
    dispose() {
      lease?.dispose();
    }
  };
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsicGFja2FnZXMvbW9kdWxlcy9wb3NpdGlvbmluZy9zcmMvd2ViL293bmVkLXN0eWxlLWxlYXNlLnRzIiwgInBhY2thZ2VzL21vZHVsZXMvcG9zaXRpb25pbmcvc3JjL3dlYi9ib3JkZXItYm94LXNpemUtbGVhc2UudHMiLCAicGFja2FnZXMvbW9kdWxlcy9wb3NpdGlvbmluZy9zcmMvZ2VvbWV0cnkvdGFyZ2V0LWFsaWdubWVudC50cyIsICJwYWNrYWdlcy9tb2R1bGVzL3Bvc2l0aW9uaW5nL3NyYy93ZWIvdGFyZ2V0LWFsaWdubWVudC1ob3N0LnRzIiwgInBhY2thZ2VzL21vZHVsZXMvcG9zaXRpb25pbmcvc3JjL3dlYi9pbnB1dC1vcmlnaW4tYW5jaG9yLnRzIiwgInBhY2thZ2VzL21vZHVsZXMvcG9zaXRpb25pbmcvc3JjL3dlYi9yb290LXNwYWNlLW9ic2VydmVyLnRzIiwgIm5vZGVfbW9kdWxlcy8ucG5wbS9AZmxvYXRpbmctdWkrdXRpbHNAMC4yLjEyL25vZGVfbW9kdWxlcy9AZmxvYXRpbmctdWkvdXRpbHMvZGlzdC9mbG9hdGluZy11aS51dGlscy5tanMiLCAibm9kZV9tb2R1bGVzLy5wbnBtL0BmbG9hdGluZy11aStjb3JlQDEuOC4wL25vZGVfbW9kdWxlcy9AZmxvYXRpbmctdWkvY29yZS9kaXN0L2Zsb2F0aW5nLXVpLmNvcmUubWpzIiwgIm5vZGVfbW9kdWxlcy8ucG5wbS9AZmxvYXRpbmctdWkrdXRpbHNAMC4yLjEyL25vZGVfbW9kdWxlcy9AZmxvYXRpbmctdWkvdXRpbHMvZGlzdC9mbG9hdGluZy11aS51dGlscy5kb20ubWpzIiwgIm5vZGVfbW9kdWxlcy8ucG5wbS9AZmxvYXRpbmctdWkrZG9tQDEuOC4wL25vZGVfbW9kdWxlcy9AZmxvYXRpbmctdWkvZG9tL2Rpc3QvZmxvYXRpbmctdWkuZG9tLm1qcyIsICJwYWNrYWdlcy9tb2R1bGVzL3Bvc2l0aW9uaW5nL3NyYy93ZWIvZmxvYXRpbmctdWktaG9zdC50cyIsICJhbmNob3JlZC1wb3NpdGlvbmluZy1jb2xkLXNpemUtcHJvYmUudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbInR5cGUgU3R5bGVDbGFpbSA9IHsgYmVmb3JlOiBzdHJpbmc7IHByaW9yaXR5OiBzdHJpbmc7IHdyaXR0ZW46IHN0cmluZyB9O1xuY29uc3Qgc3R5bGVPd25lcnMgPSBuZXcgV2Vha01hcDxIVE1MRWxlbWVudCwgTWFwPHN0cmluZywgU3R5bGVDbGFpbT4+KCk7XG5cbi8qKiBDbGFpbXMgYXJlIGlkZW50aXR5LW93bmVkIGFjcm9zcyBzeW5jaHJvbm91cyBsZWFzZSBoYW5kb2Zmcywgbm90IG1lcmVseSB2YWx1ZS1vd25lZC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBvd25TdHlsZXModGFyZ2V0OiBIVE1MRWxlbWVudCkge1xuICBjb25zdCBmaWVsZHMgPSBuZXcgTWFwPHN0cmluZywgU3R5bGVDbGFpbT4oKTtcbiAgbGV0IG93bmVycyA9IHN0eWxlT3duZXJzLmdldCh0YXJnZXQpO1xuICBpZiAoIW93bmVycykge1xuICAgIG93bmVycyA9IG5ldyBNYXAoKTtcbiAgICBzdHlsZU93bmVycy5zZXQodGFyZ2V0LCBvd25lcnMpO1xuICB9XG4gIGNvbnN0IGN1cnJlbnRPd25lcnMgPSBvd25lcnM7XG4gIGxldCBsb3N0ID0gZmFsc2U7XG4gIGNvbnN0IG1hdGNoZXMgPSAobmFtZTogc3RyaW5nLCByZWNvcmQ6IFN0eWxlQ2xhaW0pID0+XG4gICAgdGFyZ2V0LnN0eWxlLmdldFByb3BlcnR5VmFsdWUobmFtZSkgPT09IHJlY29yZC53cml0dGVuICYmXG4gICAgdGFyZ2V0LnN0eWxlLmdldFByb3BlcnR5UHJpb3JpdHkobmFtZSkgPT09ICcnO1xuICByZXR1cm4ge1xuICAgIGlzQ3VycmVudCgpOiBib29sZWFuIHtcbiAgICAgIHJldHVybiAoXG4gICAgICAgICFsb3N0ICYmXG4gICAgICAgIEFycmF5LmZyb20oZmllbGRzKS5ldmVyeShcbiAgICAgICAgICAoW25hbWUsIHJlY29yZF0pID0+IGN1cnJlbnRPd25lcnMuZ2V0KG5hbWUpID09PSByZWNvcmQgJiYgbWF0Y2hlcyhuYW1lLCByZWNvcmQpXG4gICAgICAgIClcbiAgICAgICk7XG4gICAgfSxcbiAgICB3cml0ZShuYW1lOiBzdHJpbmcsIHZhbHVlOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgICAgIGlmIChsb3N0KSByZXR1cm4gZmFsc2U7XG4gICAgICBsZXQgcmVjb3JkID0gZmllbGRzLmdldChuYW1lKTtcbiAgICAgIGlmIChyZWNvcmQgJiYgKGN1cnJlbnRPd25lcnMuZ2V0KG5hbWUpICE9PSByZWNvcmQgfHwgIW1hdGNoZXMobmFtZSwgcmVjb3JkKSkpIHtcbiAgICAgICAgbG9zdCA9IHRydWU7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGlmICghcmVjb3JkKSB7XG4gICAgICAgIGNvbnN0IHByaW9yID0gY3VycmVudE93bmVycy5nZXQobmFtZSk7XG4gICAgICAgIGNvbnN0IGluaGVyaXQgPSBwcmlvciAmJiBtYXRjaGVzKG5hbWUsIHByaW9yKTtcbiAgICAgICAgcmVjb3JkID0ge1xuICAgICAgICAgIGJlZm9yZTogaW5oZXJpdCA/IHByaW9yLmJlZm9yZSA6IHRhcmdldC5zdHlsZS5nZXRQcm9wZXJ0eVZhbHVlKG5hbWUpLFxuICAgICAgICAgIHByaW9yaXR5OiBpbmhlcml0ID8gcHJpb3IucHJpb3JpdHkgOiB0YXJnZXQuc3R5bGUuZ2V0UHJvcGVydHlQcmlvcml0eShuYW1lKSxcbiAgICAgICAgICB3cml0dGVuOiAnJyxcbiAgICAgICAgfTtcbiAgICAgICAgZmllbGRzLnNldChuYW1lLCByZWNvcmQpO1xuICAgICAgICBjdXJyZW50T3duZXJzLnNldChuYW1lLCByZWNvcmQpO1xuICAgICAgfVxuICAgICAgdGFyZ2V0LnN0eWxlLnNldFByb3BlcnR5KG5hbWUsIHZhbHVlKTtcbiAgICAgIHJlY29yZC53cml0dGVuID0gdGFyZ2V0LnN0eWxlLmdldFByb3BlcnR5VmFsdWUobmFtZSk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9LFxuICAgIHJlc3RvcmUoKSB7XG4gICAgICBmb3IgKGNvbnN0IFtuYW1lLCByZWNvcmRdIG9mIGZpZWxkcykge1xuICAgICAgICBpZiAoY3VycmVudE93bmVycy5nZXQobmFtZSkgIT09IHJlY29yZCkgY29udGludWU7XG4gICAgICAgIGN1cnJlbnRPd25lcnMuZGVsZXRlKG5hbWUpO1xuICAgICAgICBpZiAoIW1hdGNoZXMobmFtZSwgcmVjb3JkKSkgY29udGludWU7XG4gICAgICAgIGlmIChyZWNvcmQuYmVmb3JlKSB0YXJnZXQuc3R5bGUuc2V0UHJvcGVydHkobmFtZSwgcmVjb3JkLmJlZm9yZSwgcmVjb3JkLnByaW9yaXR5KTtcbiAgICAgICAgZWxzZSB0YXJnZXQuc3R5bGUucmVtb3ZlUHJvcGVydHkobmFtZSk7XG4gICAgICB9XG4gICAgICBmaWVsZHMuY2xlYXIoKTtcbiAgICB9LFxuICB9O1xufVxuXG4vKiogV2hldGhlciB0aGlzIGV4YWN0IGZpZWxkIGlzIHN0aWxsIGhlbGQgYnkgYSBsaXZlIGludGVybmFsIGdlb21ldHJ5IGNsYWltLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGhhc093bmVkU3R5bGUodGFyZ2V0OiBIVE1MRWxlbWVudCwgbmFtZTogc3RyaW5nKTogYm9vbGVhbiB7XG4gIGNvbnN0IGNsYWltID0gc3R5bGVPd25lcnMuZ2V0KHRhcmdldCk/LmdldChuYW1lKTtcbiAgcmV0dXJuIChcbiAgICAhIWNsYWltICYmXG4gICAgdGFyZ2V0LnN0eWxlLmdldFByb3BlcnR5VmFsdWUobmFtZSkgPT09IGNsYWltLndyaXR0ZW4gJiZcbiAgICB0YXJnZXQuc3R5bGUuZ2V0UHJvcGVydHlQcmlvcml0eShuYW1lKSA9PT0gJydcbiAgKTtcbn1cbiIsICJpbXBvcnQgeyBvd25TdHlsZXMsIGhhc093bmVkU3R5bGUgfSBmcm9tICcuL293bmVkLXN0eWxlLWxlYXNlJztcblxubGV0IG5leHRTaXplTGVhc2VHZW5lcmF0aW9uID0gMDtcbmNvbnN0IGFkbWl0dGVkU2l6ZUdlbmVyYXRpb25zID0gbmV3IFdlYWtNYXA8SFRNTEVsZW1lbnQsIG51bWJlcj4oKTtcblxuZXhwb3J0IHR5cGUgQm9yZGVyQm94U2l6ZVJlc3VsdCA9XG4gIHwgUmVhZG9ubHk8eyBraW5kOiAnbWF0Y2hlZCc7IHdpZHRoOiBudW1iZXI7IGhlaWdodDogbnVtYmVyIH0+XG4gIHwgUmVhZG9ubHk8eyBraW5kOiAncGVuZGluZyc7IHJlYXNvbjogJ21pc3NpbmctbGF5b3V0JyB9PlxuICB8IFJlYWRvbmx5PHtcbiAgICAgIGtpbmQ6ICd1bmF2YWlsYWJsZSc7XG4gICAgICByZWFzb246ICdkZXRhY2hlZC10YXJnZXQnIHwgJ2ludmFsaWQtZ2VvbWV0cnknIHwgJ293bmVyc2hpcC1sb3N0JyB8ICdzaXplLWNvbmZsaWN0JztcbiAgICB9PjtcblxudHlwZSBCb3JkZXJCb3hTaXplUHJlcGFyYXRpb24gPVxuICB8IFJlYWRvbmx5PHsga2luZDogJ3ByZXBhcmVkJzsgd2lkdGg6IG51bWJlcjsgaGVpZ2h0OiBudW1iZXIgfT5cbiAgfCBFeGNsdWRlPEJvcmRlckJveFNpemVSZXN1bHQsIHsga2luZDogJ21hdGNoZWQnIH0+O1xuXG4vKipcbiAqIE5ldXRyYWwgbGF5b3V0LW9ubHkgbGVhc2UuIFNlbWFudGljIHRhcmdldCBzZWxlY3Rpb24gYW5kIHNhZmUgYXNzb2NpYXRpb25zXG4gKiBiZWxvbmcgdG8gdGhlIGNvbnN1bWVyL092ZXJsYXkuIE5vIGNvbXBvbmVudCBpZGVudGl0eSBpcyBpbnNwZWN0ZWQgaGVyZS5cbiAqIFN1cmZhY2UgcGFpbnQgdHJhbnNmb3JtcyByZW1haW4gZGVjb3JhdGlvbjsgcmVhZGJhY2sgaXMgaXRzIHVzZWQgbGF5b3V0XG4gKiBib3JkZXIgYm94LCBtYXRjaGluZyB0aGUgZXhpc3RpbmcgdGFyZ2V0LWFsaWdubWVudCBjb29yZGluYXRlIGNvbnRyYWN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlQm9yZGVyQm94U2l6ZUxlYXNlKFxuICByZWZlcmVuY2U6IEhUTUxFbGVtZW50LFxuICB0YXJnZXRzOiByZWFkb25seSBIVE1MRWxlbWVudFtdLFxuICBjdXJyZW50OiAoKSA9PiBib29sZWFuXG4pIHtcbiAgY29uc3QgZ2VuZXJhdGlvbiA9ICsrbmV4dFNpemVMZWFzZUdlbmVyYXRpb247XG4gIGNvbnN0IG93bmVyRG9jdW1lbnQgPSByZWZlcmVuY2Uub3duZXJEb2N1bWVudDtcbiAgY29uc3Qgc2l6ZUZpZWxkcyA9IFsnd2lkdGgnLCAnaGVpZ2h0JywgJ2lubGluZS1zaXplJywgJ2Jsb2NrLXNpemUnXTtcbiAgLy8gYm94LXNpemluZyBpcyBhdXRob3JlZCBzaXppbmcgYnkgdmFsdWUsIG5vdCBvbmx5IGJ5IGltcG9ydGFudCBwcmlvcml0eTtcbiAgLy8gYSBzdGlsbC1vd25lZCBpbnRlcm5hbCBjbGFpbSBtYXkgdHJhbnNmZXIgYnkgaWRlbnRpdHkgZWl0aGVyIHdheS5cbiAgY29uc3QgaGFzQXV0aG9yZWRTaXppbmcgPSAodGFyZ2V0OiBIVE1MRWxlbWVudCkgPT5cbiAgICBzaXplRmllbGRzLnNvbWUoXG4gICAgICAobmFtZSkgPT4gISF0YXJnZXQuc3R5bGUuZ2V0UHJvcGVydHlWYWx1ZShuYW1lKSAmJiAhaGFzT3duZWRTdHlsZSh0YXJnZXQsIG5hbWUpXG4gICAgKSB8fFxuICAgICghIXRhcmdldC5zdHlsZS5nZXRQcm9wZXJ0eVZhbHVlKCdib3gtc2l6aW5nJykgJiYgIWhhc093bmVkU3R5bGUodGFyZ2V0LCAnYm94LXNpemluZycpKTtcbiAgY29uc3QgYXV0aG9yZWRDb25mbGljdCA9IHRhcmdldHMuc29tZShoYXNBdXRob3JlZFNpemluZyk7XG4gIGNvbnN0IG93bmVycyA9IHRhcmdldHMubWFwKCh0YXJnZXQpID0+ICh7IHRhcmdldCwgc3R5bGVzOiBvd25TdHlsZXModGFyZ2V0KSB9KSk7XG4gIHR5cGUgUmVhc29uID0gRXh0cmFjdDxCb3JkZXJCb3hTaXplUmVzdWx0LCB7IGtpbmQ6ICd1bmF2YWlsYWJsZScgfT5bJ3JlYXNvbiddO1xuICBsZXQgdGVybWluYWw6IFJlYXNvbiB8IG51bGwgPSBhdXRob3JlZENvbmZsaWN0ID8gJ3NpemUtY29uZmxpY3QnIDogbnVsbDtcbiAgY29uc3QgdW5hdmFpbGFibGUgPSAocmVhc29uOiBSZWFzb24pOiBFeHRyYWN0PEJvcmRlckJveFNpemVSZXN1bHQsIHsga2luZDogJ3VuYXZhaWxhYmxlJyB9PiA9PiB7XG4gICAgdGVybWluYWwgPSByZWFzb247XG4gICAgLy8gUGFydGlhbCB3cml0ZXMgbXVzdCBub3Qgb3V0bGl2ZSBmYWlsZWQgYWRtaXNzaW9uLiBSZXN0b3JlIG9ubHkgZmllbGRzXG4gICAgLy8gc3RpbGwgb3duZWQgYnkgdGhpcyBpZGVudGl0eTsgbmV3ZXIgYXV0aG9yIHdyaXRlcyByZW1haW4gdW50b3VjaGVkLlxuICAgIGZvciAoY29uc3QgeyBzdHlsZXMgfSBvZiBvd25lcnMpIHN0eWxlcy5yZXN0b3JlKCk7XG4gICAgcmV0dXJuIHsga2luZDogJ3VuYXZhaWxhYmxlJywgcmVhc29uIH07XG4gIH07XG4gIGxldCBwcmVwYXJlZFNpemU6IFJlYWRvbmx5PHsgd2lkdGg6IG51bWJlcjsgaGVpZ2h0OiBudW1iZXIgfT4gfCBudWxsID0gbnVsbDtcbiAgY29uc3QgcGVuZGluZyA9ICgpOiBFeHRyYWN0PEJvcmRlckJveFNpemVSZXN1bHQsIHsga2luZDogJ3BlbmRpbmcnIH0+ID0+IHtcbiAgICBwcmVwYXJlZFNpemUgPSBudWxsO1xuICAgIC8vIEEgbWlzc2luZyB1c2VkIGJveCBpcyBub3QgYSB0ZXJtaW5hbCBjb25mbGljdCBvciBhIGNlcnRpZmllZCBtYXRjaC5cbiAgICAvLyBSZXRhaW4gY2xhaW0gaWRlbnRpdGllcyB3aGlsZSBwZW5kaW5nLCBzbyBhIHNhbWUtdmFsdWVkIHN1Y2Nlc3NvciBjYW5ub3RcbiAgICAvLyBiZSBzdG9sZW4gYmFjayBvbiByZXN1bWUuIERpc3Bvc2FsL3Rlcm1pbmFsIGZhaWx1cmUgc3RpbGwgcmVzdG9yZXMgb3Vycy5cbiAgICByZXR1cm4geyBraW5kOiAncGVuZGluZycsIHJlYXNvbjogJ21pc3NpbmctbGF5b3V0JyB9O1xuICB9O1xuICBjb25zdCBvd25zQ3VycmVudEZpZWxkcyA9ICgpID0+XG4gICAgb3duZXJzLmV2ZXJ5KFxuICAgICAgKHsgdGFyZ2V0LCBzdHlsZXMgfSkgPT5cbiAgICAgICAgKGFkbWl0dGVkU2l6ZUdlbmVyYXRpb25zLmdldCh0YXJnZXQpID8/IDApIDw9IGdlbmVyYXRpb24gJiYgc3R5bGVzLmlzQ3VycmVudCgpXG4gICAgKTtcbiAgY29uc3QgaGFzTmV3QXV0aG9yZWRTaXppbmcgPSAoKSA9PiBvd25lcnMuc29tZSgoeyB0YXJnZXQgfSkgPT4gaGFzQXV0aG9yZWRTaXppbmcodGFyZ2V0KSk7XG4gIGNvbnN0IGF2YWlsYWJpbGl0eUZhaWx1cmUgPSAoKTogRXh0cmFjdDxCb3JkZXJCb3hTaXplUmVzdWx0LCB7IGtpbmQ6ICd1bmF2YWlsYWJsZScgfT4gfCBudWxsID0+IHtcbiAgICBpZiAoXG4gICAgICAhY3VycmVudCgpIHx8XG4gICAgICByZWZlcmVuY2Uub3duZXJEb2N1bWVudCAhPT0gb3duZXJEb2N1bWVudCB8fFxuICAgICAgb3duZXJzLnNvbWUoKHsgdGFyZ2V0IH0pID0+IHRhcmdldC5vd25lckRvY3VtZW50ICE9PSBvd25lckRvY3VtZW50KVxuICAgIClcbiAgICAgIHJldHVybiB1bmF2YWlsYWJsZSgnZGV0YWNoZWQtdGFyZ2V0Jyk7XG4gICAgaWYgKCFvd25zQ3VycmVudEZpZWxkcygpIHx8IGhhc05ld0F1dGhvcmVkU2l6aW5nKCkpIHJldHVybiB1bmF2YWlsYWJsZSgnb3duZXJzaGlwLWxvc3QnKTtcbiAgICBpZiAoIXJlZmVyZW5jZS5pc0Nvbm5lY3RlZCB8fCBvd25lcnMuc29tZSgoeyB0YXJnZXQgfSkgPT4gIXRhcmdldC5pc0Nvbm5lY3RlZCkpIHtcbiAgICAgIC8vIFRlbXBvcmFyeSBET00gcmVtb3ZhbCBzdXNwZW5kcyBjZXJ0aWZpY2F0aW9uLCBub3QgdGhpcyBjdXJyZW50IGlkZW50aXR5LlxuICAgICAgLy8gUmV0YWluIGNsYWltcyBzbyBhIHN1Y2Nlc3NvciBzdGlsbCBmZW5jZXMgdXMgd2hlbiB0aGUgbm9kZXMgcmVjb25uZWN0LlxuICAgICAgcHJlcGFyZWRTaXplID0gbnVsbDtcbiAgICAgIHJldHVybiB7IGtpbmQ6ICd1bmF2YWlsYWJsZScsIHJlYXNvbjogJ2RldGFjaGVkLXRhcmdldCcgfTtcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG4gIH07XG4gIGNvbnN0IHByZXBhcmUgPSAoKTogQm9yZGVyQm94U2l6ZVByZXBhcmF0aW9uID0+IHtcbiAgICBpZiAodGVybWluYWwpIHJldHVybiB7IGtpbmQ6ICd1bmF2YWlsYWJsZScsIHJlYXNvbjogdGVybWluYWwgfTtcbiAgICBjb25zdCBmYWlsdXJlID0gYXZhaWxhYmlsaXR5RmFpbHVyZSgpO1xuICAgIGlmIChmYWlsdXJlKSByZXR1cm4gZmFpbHVyZTtcbiAgICAvLyBCb3RoIHNpZGVzIHVzZSB0aGUgc2FtZSB1c2VkLWxheW91dCBDU1NPTSBib3JkZXItYm94IGNvb3JkaW5hdGUgc3BhY2UuXG4gICAgLy8gVHJpZ2dlciBob3Zlci9wcmVzcyBvciBhbmNlc3RvciBwYWludCB0cmFuc2Zvcm1zIG5ldmVyIHJlc2l6ZSByb3dzLlxuICAgIGNvbnN0IHdpZHRoID0gcmVmZXJlbmNlLm9mZnNldFdpZHRoLFxuICAgICAgaGVpZ2h0ID0gcmVmZXJlbmNlLm9mZnNldEhlaWdodDtcbiAgICBpZiAoIU51bWJlci5pc0Zpbml0ZSh3aWR0aCkgfHwgIU51bWJlci5pc0Zpbml0ZShoZWlnaHQpIHx8IHdpZHRoIDwgMCB8fCBoZWlnaHQgPCAwKVxuICAgICAgcmV0dXJuIHVuYXZhaWxhYmxlKCdpbnZhbGlkLWdlb21ldHJ5Jyk7XG4gICAgaWYgKHdpZHRoID09PSAwIHx8IGhlaWdodCA9PT0gMCkgcmV0dXJuIHBlbmRpbmcoKTtcbiAgICAvLyBJbml0aWFsIHBlbmRpbmcgaGFzIG5vIHN0eWxlIGZpZWxkcyB0byBwcm90ZWN0LiBBIGxhdGVyIGFkbWl0dGVkIGxlYXNlXG4gICAgLy8gc3RpbGwgc3VwZXJzZWRlcyBpdCwgZXZlbiBhZnRlciB0aGF0IHN1Y2Nlc3NvciByZXN0b3JlcyBpdHMgb3duIGZpZWxkcy5cbiAgICAvLyBNaXNzaW5nIGxheW91dCBvciBhbiBpbml0aWFsIGF1dGhvciBjb25mbGljdCBuZXZlciBjbGFpbXMgdGhpcyBnZW5lcmF0aW9uLlxuICAgIGNvbnN0IGFmdGVyUmVhZCA9IGF2YWlsYWJpbGl0eUZhaWx1cmUoKTtcbiAgICBpZiAoYWZ0ZXJSZWFkKSByZXR1cm4gYWZ0ZXJSZWFkO1xuICAgIGZvciAoY29uc3QgeyB0YXJnZXQgfSBvZiBvd25lcnMpIGFkbWl0dGVkU2l6ZUdlbmVyYXRpb25zLnNldCh0YXJnZXQsIGdlbmVyYXRpb24pO1xuICAgIC8vIERvIG5vdCBlcmFzZSBhdXRob3IgbWluL21heCBjb25zdHJhaW50cy4gQ29uZmxpY3RpbmcgdXNlZCBkaW1lbnNpb25zXG4gICAgLy8gYXJlIGRpYWdub3NlZCBiZWxvdzsgYW4gZXhwbGljaXQgaW50cmluc2ljIHBvbGljeSBvcHRzIG91dCB1cHN0cmVhbS5cbiAgICBmb3IgKGNvbnN0IHsgc3R5bGVzIH0gb2Ygb3duZXJzKSB7XG4gICAgICBjb25zdCBiZWZvcmVXcml0ZSA9IGF2YWlsYWJpbGl0eUZhaWx1cmUoKTtcbiAgICAgIGlmIChiZWZvcmVXcml0ZSkgcmV0dXJuIGJlZm9yZVdyaXRlO1xuICAgICAgaWYgKFxuICAgICAgICAhc3R5bGVzLndyaXRlKCdib3gtc2l6aW5nJywgJ2JvcmRlci1ib3gnKSB8fFxuICAgICAgICAhc3R5bGVzLndyaXRlKCd3aWR0aCcsIGAke3dpZHRofXB4YCkgfHxcbiAgICAgICAgIXN0eWxlcy53cml0ZSgnaGVpZ2h0JywgYCR7aGVpZ2h0fXB4YClcbiAgICAgIClcbiAgICAgICAgcmV0dXJuIHVuYXZhaWxhYmxlKCdvd25lcnNoaXAtbG9zdCcpO1xuICAgIH1cbiAgICAvLyBQcmVwYXJhdGlvbiBvd25zIHRoZSByZXF1ZXN0ZWQgZGltZW5zaW9ucywgYnV0IGNhbm5vdCBjZXJ0aWZ5IHRoZSB1c2VkXG4gICAgLy8gYm94IHVudGlsIHRoZSBjYWxsZXIgaGFzIGluc3RhbGxlZCB0aGUgY29udGFpbmluZyBsYXlvdXQgY29uc3RyYWludHMuXG4gICAgcHJlcGFyZWRTaXplID0geyB3aWR0aCwgaGVpZ2h0IH07XG4gICAgcmV0dXJuIHsga2luZDogJ3ByZXBhcmVkJywgd2lkdGgsIGhlaWdodCB9O1xuICB9O1xuICBjb25zdCB2ZXJpZnkgPSAoKTogQm9yZGVyQm94U2l6ZVJlc3VsdCB8IFJlYWRvbmx5PHsga2luZDogJ3JlZmVyZW5jZS1jaGFuZ2VkJyB9PiA9PiB7XG4gICAgaWYgKHRlcm1pbmFsKSByZXR1cm4geyBraW5kOiAndW5hdmFpbGFibGUnLCByZWFzb246IHRlcm1pbmFsIH07XG4gICAgY29uc3QgZmFpbHVyZSA9IGF2YWlsYWJpbGl0eUZhaWx1cmUoKTtcbiAgICBpZiAoZmFpbHVyZSkgcmV0dXJuIGZhaWx1cmU7XG4gICAgLy8gQSBsZWFzZSB0aGF0IG9ubHkgZXZlciBzYXcgbWlzc2luZyBsYXlvdXQgaGFzIG5vdGhpbmcgdG8gY2VydGlmeSwgYnV0IGFcbiAgICAvLyByZXBlYXRlZCB2ZXJpZmljYXRpb24gbXVzdCBzdGF5IHJlY292ZXJhYmxlLCBub3QgdHVybiB0ZXJtaW5hbC4gUmVhbFxuICAgIC8vIHRlcm1pbmFsIGFuZCBvd25lcnNoaXAgZmFpbHVyZXMgYWJvdmUgc3RpbGwgd2luIG92ZXIgcGVuZGluZy5cbiAgICBpZiAoIXByZXBhcmVkU2l6ZSkgcmV0dXJuIHBlbmRpbmcoKTtcbiAgICBjb25zdCBwcmVwYXJlZCA9IHByZXBhcmVkU2l6ZTtcbiAgICBjb25zdCB7IHdpZHRoLCBoZWlnaHQgfSA9IHByZXBhcmVkO1xuICAgIC8vIFZlcmlmaWNhdGlvbiBuZXZlciByZXdyaXRlcyBkaW1lbnNpb25zIGFmdGVyIHRoZSBjYWxsZXIgc29sdmVkIGxheW91dC5cbiAgICAvLyBBIGNoYW5nZWQgcmVmZXJlbmNlIHJlcXVpcmVzIGFub3RoZXIgYm91bmRlZCBzb2x2ZSwgbm90IGNlcnRpZmljYXRpb25cbiAgICAvLyBvZiBmcmVzaCByb3cgZGltZW5zaW9ucyBhZ2FpbnN0IGEgcGxhbiBjb21wdXRlZCBmb3IgdGhlIGVhcmxpZXIgb25lcy5cbiAgICBjb25zdCBjdXJyZW50V2lkdGggPSByZWZlcmVuY2Uub2Zmc2V0V2lkdGgsXG4gICAgICBjdXJyZW50SGVpZ2h0ID0gcmVmZXJlbmNlLm9mZnNldEhlaWdodDtcbiAgICBpZiAoXG4gICAgICAhTnVtYmVyLmlzRmluaXRlKGN1cnJlbnRXaWR0aCkgfHxcbiAgICAgICFOdW1iZXIuaXNGaW5pdGUoY3VycmVudEhlaWdodCkgfHxcbiAgICAgIGN1cnJlbnRXaWR0aCA8IDAgfHxcbiAgICAgIGN1cnJlbnRIZWlnaHQgPCAwXG4gICAgKVxuICAgICAgcmV0dXJuIHVuYXZhaWxhYmxlKCdpbnZhbGlkLWdlb21ldHJ5Jyk7XG4gICAgaWYgKGN1cnJlbnRXaWR0aCA9PT0gMCB8fCBjdXJyZW50SGVpZ2h0ID09PSAwKSByZXR1cm4gcGVuZGluZygpO1xuICAgIGlmIChjdXJyZW50V2lkdGggIT09IHdpZHRoIHx8IGN1cnJlbnRIZWlnaHQgIT09IGhlaWdodCkgcmV0dXJuIHsga2luZDogJ3JlZmVyZW5jZS1jaGFuZ2VkJyB9O1xuICAgIGZvciAoY29uc3QgeyB0YXJnZXQgfSBvZiBvd25lcnMpIHtcbiAgICAgIGNvbnN0IGJlZm9yZVJlYWQgPSBhdmFpbGFiaWxpdHlGYWlsdXJlKCk7XG4gICAgICBpZiAoYmVmb3JlUmVhZCkgcmV0dXJuIGJlZm9yZVJlYWQ7XG4gICAgICAvLyBVc2VkIGRpbWVuc2lvbnMgYW5kIHVuLWNsaXBwZWQgY29udGVudCBhcmUgdmVyaWZpZWQgaW5kZXBlbmRlbnRseVxuICAgICAgLy8gb2Ygc3VjY2Vzc2Z1bCB3cml0ZXMuIE11bHRpLWxpbmUgY2FsbGVycyBtdXN0IGNob29zZSBpbnRyaW5zaWMuXG4gICAgICBjb25zdCB0YXJnZXRXaWR0aCA9IHRhcmdldC5vZmZzZXRXaWR0aCxcbiAgICAgICAgdGFyZ2V0SGVpZ2h0ID0gdGFyZ2V0Lm9mZnNldEhlaWdodDtcbiAgICAgIGlmIChcbiAgICAgICAgIU51bWJlci5pc0Zpbml0ZSh0YXJnZXRXaWR0aCkgfHxcbiAgICAgICAgIU51bWJlci5pc0Zpbml0ZSh0YXJnZXRIZWlnaHQpIHx8XG4gICAgICAgIHRhcmdldFdpZHRoIDwgMCB8fFxuICAgICAgICB0YXJnZXRIZWlnaHQgPCAwXG4gICAgICApXG4gICAgICAgIHJldHVybiB1bmF2YWlsYWJsZSgnaW52YWxpZC1nZW9tZXRyeScpO1xuICAgICAgaWYgKHRhcmdldFdpZHRoID09PSAwIHx8IHRhcmdldEhlaWdodCA9PT0gMCkgcmV0dXJuIHBlbmRpbmcoKTtcbiAgICAgIGlmIChcbiAgICAgICAgTWF0aC5hYnModGFyZ2V0V2lkdGggLSB3aWR0aCkgPiAxIHx8XG4gICAgICAgIE1hdGguYWJzKHRhcmdldEhlaWdodCAtIGhlaWdodCkgPiAxIHx8XG4gICAgICAgIHRhcmdldC5zY3JvbGxIZWlnaHQgPiB0YXJnZXQuY2xpZW50SGVpZ2h0ICsgMSB8fFxuICAgICAgICB0YXJnZXQuc2Nyb2xsV2lkdGggPiB0YXJnZXQuY2xpZW50V2lkdGggKyAxXG4gICAgICApXG4gICAgICAgIHJldHVybiB1bmF2YWlsYWJsZSgnc2l6ZS1jb25mbGljdCcpO1xuICAgIH1cbiAgICBjb25zdCBmaW5hbFdpZHRoID0gcmVmZXJlbmNlLm9mZnNldFdpZHRoLFxuICAgICAgZmluYWxIZWlnaHQgPSByZWZlcmVuY2Uub2Zmc2V0SGVpZ2h0O1xuICAgIC8vIExheW91dCByZWFkcyBjYW4gc3luY2hyb25vdXNseSByZWVudGVyIGFuIG93bmVyL0RPTSBib3VuZGFyeS4gTmV2ZXJcbiAgICAvLyBjZXJ0aWZ5IGEgZGlzY29ubmVjdGVkL2Fkb3B0ZWQgdGFyZ2V0IG9yIGFuIGVxdWFsLXZhbHVlZCBzdWNjZXNzb3IgY2xhaW0uXG4gICAgY29uc3QgYWZ0ZXJSZWFkID0gYXZhaWxhYmlsaXR5RmFpbHVyZSgpO1xuICAgIGlmIChhZnRlclJlYWQpIHJldHVybiBhZnRlclJlYWQ7XG4gICAgaWYgKFxuICAgICAgIU51bWJlci5pc0Zpbml0ZShmaW5hbFdpZHRoKSB8fFxuICAgICAgIU51bWJlci5pc0Zpbml0ZShmaW5hbEhlaWdodCkgfHxcbiAgICAgIGZpbmFsV2lkdGggPCAwIHx8XG4gICAgICBmaW5hbEhlaWdodCA8IDBcbiAgICApXG4gICAgICByZXR1cm4gdW5hdmFpbGFibGUoJ2ludmFsaWQtZ2VvbWV0cnknKTtcbiAgICBpZiAoZmluYWxXaWR0aCA9PT0gMCB8fCBmaW5hbEhlaWdodCA9PT0gMCkgcmV0dXJuIHBlbmRpbmcoKTtcbiAgICBpZiAoZmluYWxXaWR0aCAhPT0gd2lkdGggfHwgZmluYWxIZWlnaHQgIT09IGhlaWdodCB8fCBwcmVwYXJlZFNpemUgIT09IHByZXBhcmVkKVxuICAgICAgcmV0dXJuIHsga2luZDogJ3JlZmVyZW5jZS1jaGFuZ2VkJyB9O1xuICAgIHJldHVybiB7IGtpbmQ6ICdtYXRjaGVkJywgd2lkdGgsIGhlaWdodCB9O1xuICB9O1xuICByZXR1cm4ge1xuICAgIHByZXBhcmUsXG4gICAgdmVyaWZ5LFxuICAgIGFib3J0OiB1bmF2YWlsYWJsZSxcbiAgICBhcHBseSgpOiBCb3JkZXJCb3hTaXplUmVzdWx0IHtcbiAgICAgIGNvbnN0IHByZXBhcmVkID0gcHJlcGFyZSgpO1xuICAgICAgaWYgKHByZXBhcmVkLmtpbmQgIT09ICdwcmVwYXJlZCcpIHJldHVybiBwcmVwYXJlZDtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IHZlcmlmeSgpO1xuICAgICAgcmV0dXJuIHJlc3VsdC5raW5kID09PSAncmVmZXJlbmNlLWNoYW5nZWQnID8gdW5hdmFpbGFibGUoJ2ludmFsaWQtZ2VvbWV0cnknKSA6IHJlc3VsdDtcbiAgICB9LFxuICAgIHJlc3RvcmUoKSB7XG4gICAgICB0ZXJtaW5hbCA9ICdkZXRhY2hlZC10YXJnZXQnO1xuICAgICAgZm9yIChjb25zdCB7IHN0eWxlcyB9IG9mIG93bmVycykgc3R5bGVzLnJlc3RvcmUoKTtcbiAgICB9LFxuICB9O1xufVxuXG4vKiogU2Nyb2xsLWFkanVzdGVkIGxheW91dCBwb3NpdGlvbjsgcGFpbnQgdHJhbnNmb3JtcyBhcmUgbm90IHNpemluZyBpbnB1dHMuICovXG5leHBvcnQgZnVuY3Rpb24gbGF5b3V0SW5saW5lU3RhcnQobm9kZTogSFRNTEVsZW1lbnQpOiBudW1iZXIge1xuICBsZXQgbGVmdCA9IDA7XG4gIGxldCBjdXJyZW50OiBIVE1MRWxlbWVudCB8IG51bGwgPSBub2RlO1xuICB3aGlsZSAoY3VycmVudCkge1xuICAgIGxlZnQgKz0gY3VycmVudC5vZmZzZXRMZWZ0O1xuICAgIGNvbnN0IHBhcmVudDogRWxlbWVudCB8IG51bGwgPSBjdXJyZW50Lm9mZnNldFBhcmVudDtcbiAgICBpZiAoIXBhcmVudCB8fCAhKCdvZmZzZXRMZWZ0JyBpbiBwYXJlbnQpKSBicmVhaztcbiAgICBsZWZ0ICs9IChwYXJlbnQgYXMgSFRNTEVsZW1lbnQpLmNsaWVudExlZnQ7XG4gICAgY3VycmVudCA9IHBhcmVudCBhcyBIVE1MRWxlbWVudDtcbiAgfVxuICBmb3IgKGxldCBwYXJlbnQgPSBub2RlLnBhcmVudEVsZW1lbnQ7IHBhcmVudDsgcGFyZW50ID0gcGFyZW50LnBhcmVudEVsZW1lbnQpXG4gICAgbGVmdCAtPSBwYXJlbnQuc2Nyb2xsTGVmdDtcbiAgcmV0dXJuIGxlZnQ7XG59XG5cbi8qKiBDaGVjayBjbGlwcGluZyBvbmx5IGluc2lkZSB0aGUgb3duaW5nIGZyYW1lLCBpbiB0aGUgc2FtZSBsYXlvdXQgY29vcmRpbmF0ZXMuICovXG5leHBvcnQgZnVuY3Rpb24gaGFzQm9yZGVyQm94SW5saW5lQ2xpcHBpbmcoXG4gIHRhcmdldDogSFRNTEVsZW1lbnQsXG4gIGZyYW1lOiBIVE1MRWxlbWVudFxuKTogYm9vbGVhbiB8IG51bGwge1xuICBjb25zdCB2aWV3ID0gZnJhbWUub3duZXJEb2N1bWVudC5kZWZhdWx0VmlldztcbiAgaWYgKCF2aWV3IHx8IHRhcmdldCA9PT0gZnJhbWUgfHwgIWZyYW1lLmNvbnRhaW5zKHRhcmdldCkpIHJldHVybiBudWxsO1xuICBjb25zdCBsZWZ0ID0gbGF5b3V0SW5saW5lU3RhcnQodGFyZ2V0KTtcbiAgY29uc3Qgd2lkdGggPSB0YXJnZXQub2Zmc2V0V2lkdGg7XG4gIGlmICghTnVtYmVyLmlzRmluaXRlKGxlZnQpIHx8ICFOdW1iZXIuaXNGaW5pdGUod2lkdGgpIHx8IHdpZHRoIDwgMCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IHBvc2l0aW9uID0gdmlldy5nZXRDb21wdXRlZFN0eWxlKHRhcmdldCkucG9zaXRpb247XG4gIC8vIG51bGwgcmVhY2hlcyB0aGUgdmlld3BvcnQ7IHVuZGVmaW5lZCBmb2xsb3dzIG9yZGluYXJ5IGFuY2VzdG9yIGNsaXBwaW5nLlxuICBsZXQgY29udGFpbmluZ0Jsb2NrID1cbiAgICBwb3NpdGlvbiA9PT0gJ2Fic29sdXRlJyB8fCBwb3NpdGlvbiA9PT0gJ2ZpeGVkJyA/IHRhcmdldC5vZmZzZXRQYXJlbnQgOiB1bmRlZmluZWQ7XG4gIGZvciAobGV0IHBhcmVudCA9IHRhcmdldC5wYXJlbnRFbGVtZW50OyBwYXJlbnQ7IHBhcmVudCA9IHBhcmVudC5wYXJlbnRFbGVtZW50KSB7XG4gICAgaWYgKHBhcmVudCA9PT0gY29udGFpbmluZ0Jsb2NrKSBjb250YWluaW5nQmxvY2sgPSB1bmRlZmluZWQ7XG4gICAgY29uc3Qgc3R5bGUgPSB2aWV3LmdldENvbXB1dGVkU3R5bGUocGFyZW50KTtcbiAgICBjb25zdCBvdmVyZmxvdyA9IHN0eWxlLm92ZXJmbG93WCB8fCBzdHlsZS5vdmVyZmxvdztcbiAgICBpZiAoXG4gICAgICBjb250YWluaW5nQmxvY2sgPT09IHVuZGVmaW5lZCAmJlxuICAgICAgKG92ZXJmbG93ID09PSAnaGlkZGVuJyB8fFxuICAgICAgICBvdmVyZmxvdyA9PT0gJ2NsaXAnIHx8XG4gICAgICAgIG92ZXJmbG93ID09PSAnc2Nyb2xsJyB8fFxuICAgICAgICBvdmVyZmxvdyA9PT0gJ2F1dG8nKVxuICAgICkge1xuICAgICAgY29uc3Qgc3RhcnQgPSBsYXlvdXRJbmxpbmVTdGFydChwYXJlbnQpICsgcGFyZW50LmNsaWVudExlZnQ7XG4gICAgICBjb25zdCBhdmFpbGFibGUgPSBwYXJlbnQuY2xpZW50V2lkdGg7XG4gICAgICBpZiAoIU51bWJlci5pc0Zpbml0ZShzdGFydCkgfHwgIU51bWJlci5pc0Zpbml0ZShhdmFpbGFibGUpIHx8IGF2YWlsYWJsZSA8IDApIHJldHVybiBudWxsO1xuICAgICAgaWYgKGxlZnQgPCBzdGFydCAtIDEgfHwgbGVmdCArIHdpZHRoID4gc3RhcnQgKyBhdmFpbGFibGUgKyAxKSByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKHBhcmVudCA9PT0gZnJhbWUpIHJldHVybiBmYWxzZTtcbiAgICBpZiAoXG4gICAgICBjb250YWluaW5nQmxvY2sgPT09IHVuZGVmaW5lZCAmJlxuICAgICAgKHN0eWxlLnBvc2l0aW9uID09PSAnYWJzb2x1dGUnIHx8IHN0eWxlLnBvc2l0aW9uID09PSAnZml4ZWQnKVxuICAgIClcbiAgICAgIGNvbnRhaW5pbmdCbG9jayA9IHBhcmVudC5vZmZzZXRQYXJlbnQ7XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8qKiBMYXlvdXQgY2hyb21lIG91dHNpZGUgb25lIHJvdydzIGJvcmRlciBib3gsIGluY2x1ZGluZyByZXNlcnZlZCBzY3JvbGxiYXJzLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1lYXN1cmVCb3JkZXJCb3hJbmxpbmVHdXR0ZXIoXG4gIHRhcmdldDogSFRNTEVsZW1lbnQsXG4gIHN1cmZhY2U6IEhUTUxFbGVtZW50XG4pOiBudW1iZXIgfCBudWxsIHtcbiAgY29uc3QgdmlldyA9IHN1cmZhY2Uub3duZXJEb2N1bWVudC5kZWZhdWx0VmlldztcbiAgaWYgKCF2aWV3IHx8ICFzdXJmYWNlLmNvbnRhaW5zKHRhcmdldCkpIHJldHVybiBudWxsO1xuICBjb25zdCBudW1iZXIgPSAodmFsdWU6IHN0cmluZykgPT4gKHZhbHVlID09PSAnYXV0bycgPyAwIDogTnVtYmVyLnBhcnNlRmxvYXQodmFsdWUpKTtcbiAgbGV0IGd1dHRlciA9IDA7XG4gIGxldCBjaGlsZDogSFRNTEVsZW1lbnQgPSB0YXJnZXQ7XG4gIGZvciAobGV0IHBhcmVudCA9IHRhcmdldC5wYXJlbnRFbGVtZW50OyBwYXJlbnQ7IHBhcmVudCA9IHBhcmVudC5wYXJlbnRFbGVtZW50KSB7XG4gICAgY29uc3QgY2hpbGRTdHlsZSA9IHZpZXcuZ2V0Q29tcHV0ZWRTdHlsZShjaGlsZCk7XG4gICAgY29uc3Qgc3R5bGUgPSB2aWV3LmdldENvbXB1dGVkU3R5bGUocGFyZW50KTtcbiAgICBjb25zdCBtYXJnaW4gPSBudW1iZXIoY2hpbGRTdHlsZS5tYXJnaW5MZWZ0KSArIG51bWJlcihjaGlsZFN0eWxlLm1hcmdpblJpZ2h0KTtcbiAgICBjb25zdCBib3JkZXIgPSBudW1iZXIoc3R5bGUuYm9yZGVyTGVmdFdpZHRoKSArIG51bWJlcihzdHlsZS5ib3JkZXJSaWdodFdpZHRoKTtcbiAgICBjb25zdCBwYWRkaW5nID0gbnVtYmVyKHN0eWxlLnBhZGRpbmdMZWZ0KSArIG51bWJlcihzdHlsZS5wYWRkaW5nUmlnaHQpO1xuICAgIGNvbnN0IHNjcm9sbGJhciA9IE1hdGgubWF4KDAsIHBhcmVudC5vZmZzZXRXaWR0aCAtIHBhcmVudC5jbGllbnRXaWR0aCAtIGJvcmRlcik7XG4gICAgaWYgKCFbbWFyZ2luLCBib3JkZXIsIHBhZGRpbmcsIHNjcm9sbGJhcl0uZXZlcnkoTnVtYmVyLmlzRmluaXRlKSB8fCBib3JkZXIgPCAwIHx8IHBhZGRpbmcgPCAwKVxuICAgICAgcmV0dXJuIG51bGw7XG4gICAgZ3V0dGVyICs9IG1hcmdpbiArIGJvcmRlciArIHBhZGRpbmcgKyBzY3JvbGxiYXI7XG4gICAgaWYgKHBhcmVudCA9PT0gc3VyZmFjZSkgcmV0dXJuIE1hdGgubWF4KDAsIGd1dHRlcik7XG4gICAgY2hpbGQgPSBwYXJlbnQ7XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG4iLCAiLyoqIEludGVybmFsLCBwbGF0Zm9ybS1pbmRlcGVuZGVudCBudW1lcmljYWwgcGxhbnMuIEMtVEFSR0VULUFMSUdOTUVOVC1QTEFOLTAwMDEuXG4gKiBIb3N0cyBzdXBwbHkgZmFjdHMgYW5kIGFwcGx5L3JlYWQgYmFjayBjb25zdHJhaW50czsgdGhpcyBmaWxlIG5ldmVyIG1lYXN1cmVzIGEgaG9zdC5cbiAqIEludGVybmFsIG1lY2hhbmlzbTsgdGFyZ2V0IGhvc3RzIHN1cHBseSBmYWN0cyBhbmQgY29uc3VtZSBpdHMgcGxhbnMuXG4gKi9cbmltcG9ydCB0eXBlIHsgVGFyZ2V0QWxpZ25tZW50Q29uc3RyYWludHMgfSBmcm9tICdAcHJvdG8udWkvY29yZSc7XG5leHBvcnQgdHlwZSB7IFRhcmdldEFsaWdubWVudENvbnN0cmFpbnRzIH0gZnJvbSAnQHByb3RvLnVpL2NvcmUnO1xuXG5leHBvcnQgdHlwZSBUYXJnZXRBbGlnbm1lbnRNZXRyaWNzID0gUmVhZG9ubHk8e1xuICBkaXJlY3Rpb246ICdsdHInIHwgJ3J0bCc7XG4gIHZpZXdwb3J0OiBSZWFkb25seTx7IHdpZHRoOiBudW1iZXI7IGhlaWdodDogbnVtYmVyIH0+O1xuICByZWZlcmVuY2U6IFJlYWRvbmx5PHtcbiAgICBsZWZ0OiBudW1iZXI7XG4gICAgcmlnaHQ6IG51bWJlcjtcbiAgICB0b3A6IG51bWJlcjtcbiAgICB3aWR0aDogbnVtYmVyO1xuICAgIGhlaWdodDogbnVtYmVyO1xuICB9PjtcbiAgc3VyZmFjZTogUmVhZG9ubHk8e1xuICAgIGxlZnQ6IG51bWJlcjtcbiAgICByaWdodDogbnVtYmVyO1xuICAgIHdpZHRoOiBudW1iZXI7XG4gICAgY2xpZW50SGVpZ2h0OiBudW1iZXI7XG4gICAgYm9yZGVyVG9wOiBudW1iZXI7XG4gICAgYm9yZGVyQm90dG9tOiBudW1iZXI7XG4gICAgcGFkZGluZ1RvcDogbnVtYmVyO1xuICAgIHBhZGRpbmdCb3R0b206IG51bWJlcjtcbiAgfT47XG4gIHRhcmdldDogUmVhZG9ubHk8e1xuICAgIG9mZnNldDogbnVtYmVyO1xuICAgIGhlaWdodDogbnVtYmVyO1xuICAgIGF0U3RhcnQ6IGJvb2xlYW47XG4gICAgYXRFbmQ6IGJvb2xlYW47XG4gICAgLyoqIE9wdGlvbmFsIG1lYXN1cmVkIG91dGVyIGNocm9tZSBuZWVkZWQgdG8gcmV0YWluIGEgcmVxdWVzdGVkIHJvdyBib3JkZXIgYm94LiAqL1xuICAgIG1pbmltdW1PdXRlcklubGluZVNwYW4/OiBudW1iZXI7XG4gICAgLyoqIExvZ2ljYWwgYm9yZGVyLWJveCBpbnNldCBvZiBhIHNpemUtbWF0Y2hlZCB0YXJnZXQgaW5zaWRlIHRoZSBwYWludGVkIHN1cmZhY2UuICovXG4gICAgaW5saW5lU3RhcnRJbnNldD86IG51bWJlcjtcbiAgfT47XG4gIHNjcm9sbHBvcnQ6IFJlYWRvbmx5PHtcbiAgICBzY3JvbGxIZWlnaHQ6IG51bWJlcjtcbiAgICBvZmZzZXRUb3A6IG51bWJlcjtcbiAgICBoZWlnaHQ6IG51bWJlcjtcbiAgICBwYWRkaW5nVG9wOiBudW1iZXI7XG4gICAgcGFkZGluZ0JvdHRvbTogbnVtYmVyO1xuICB9Pjtcbn0+O1xuXG5leHBvcnQgdHlwZSBUYXJnZXRBbGlnbm1lbnRQbGFuID0gUmVhZG9ubHk8e1xuICBpbmxpbmU6IFJlYWRvbmx5PHsgZWRnZTogJ2xlZnQnIHwgJ3JpZ2h0JzsgaW5zZXQ6IG51bWJlcjsgbWluaW11bVNwYW46IG51bWJlciB9PjtcbiAgYmxvY2s6IFJlYWRvbmx5PHtcbiAgICBwaW46ICdzdGFydCcgfCAnZW5kJztcbiAgICBtYXJnaW46IG51bWJlcjtcbiAgICByZXF1ZXN0ZWRTcGFuOiBudW1iZXI7XG4gICAgbWluaW11bVNwYW46IG51bWJlcjtcbiAgICBtYXhpbXVtU3BhbjogbnVtYmVyO1xuICB9PjtcbiAgY29udGVudEFsaWdubWVudDogJ25vcm1hbCc7XG4gIC8qKiBPbWl0dGVkIG1lYW5zIG5vIHdyaXRlLCBub3QgYSByZXF1ZXN0IHRvIHJlc2V0IHJldGFpbmVkIHNjcm9sbCB0byB6ZXJvLiAqL1xuICByZXF1ZXN0ZWRTY3JvbGw/OiBudW1iZXI7XG59PjtcblxudHlwZSBJbnZhbGlkID0gUmVhZG9ubHk8e1xuICBraW5kOiAnaW52YWxpZCc7XG4gIHJlYXNvbjogJ25vbmZpbml0ZS1mYWN0JyB8ICdpbnZhbGlkLWV4dGVudCcgfCAnaW52YWxpZC1jb25zdHJhaW50JyB8ICdub25maW5pdGUtcGxhbic7XG59PjtcbmV4cG9ydCB0eXBlIFRhcmdldEFsaWdubWVudFJlc3VsdCA9IEludmFsaWQgfCBSZWFkb25seTx7IGtpbmQ6ICdwbGFuJzsgcGxhbjogVGFyZ2V0QWxpZ25tZW50UGxhbiB9PjtcbmNvbnN0IGludmFsaWQgPSAocmVhc29uOiBJbnZhbGlkWydyZWFzb24nXSk6IEludmFsaWQgPT4gT2JqZWN0LmZyZWV6ZSh7IGtpbmQ6ICdpbnZhbGlkJywgcmVhc29uIH0pO1xuY29uc3QgZmluaXRlID0gKG51bWJlcnM6IHJlYWRvbmx5IG51bWJlcltdKSA9PiBudW1iZXJzLmV2ZXJ5KE51bWJlci5pc0Zpbml0ZSk7XG5jb25zdCBub25uZWdhdGl2ZSA9IChudW1iZXJzOiByZWFkb25seSBudW1iZXJbXSkgPT4gbnVtYmVycy5ldmVyeSgodmFsdWUpID0+IHZhbHVlID49IDApO1xuY29uc3QgY2xhbXAgPSAodmFsdWU6IG51bWJlciwgbWluaW11bTogbnVtYmVyLCBtYXhpbXVtOiBudW1iZXIpID0+XG4gIE1hdGgubWluKE1hdGgubWF4KHZhbHVlLCBtaW5pbXVtKSwgbWF4aW11bSk7XG5cbmV4cG9ydCBmdW5jdGlvbiBzb2x2ZVRhcmdldEFsaWdubWVudChcbiAgbWV0cmljczogVGFyZ2V0QWxpZ25tZW50TWV0cmljcyxcbiAgY29uc3RyYWludHM6IFRhcmdldEFsaWdubWVudENvbnN0cmFpbnRzXG4pOiBUYXJnZXRBbGlnbm1lbnRSZXN1bHQge1xuICBjb25zdCB7IHZpZXdwb3J0OiB2LCByZWZlcmVuY2U6IGEsIHN1cmZhY2U6IGMsIHRhcmdldDogdCwgc2Nyb2xscG9ydDogcyB9ID0gbWV0cmljcztcbiAgY29uc3QgZmFjdHMgPSBbXG4gICAgLi4uT2JqZWN0LnZhbHVlcyh2KSxcbiAgICAuLi5PYmplY3QudmFsdWVzKGEpLFxuICAgIC4uLk9iamVjdC52YWx1ZXMoYyksXG4gICAgdC5vZmZzZXQsXG4gICAgdC5oZWlnaHQsXG4gICAgLi4uKHQubWluaW11bU91dGVySW5saW5lU3BhbiA9PT0gdW5kZWZpbmVkID8gW10gOiBbdC5taW5pbXVtT3V0ZXJJbmxpbmVTcGFuXSksXG4gICAgLi4uKHQuaW5saW5lU3RhcnRJbnNldCA9PT0gdW5kZWZpbmVkID8gW10gOiBbdC5pbmxpbmVTdGFydEluc2V0XSksXG4gICAgLi4uT2JqZWN0LnZhbHVlcyhzKSxcbiAgXTtcbiAgaWYgKCFmaW5pdGUoZmFjdHMpKSByZXR1cm4gaW52YWxpZCgnbm9uZmluaXRlLWZhY3QnKTtcbiAgaWYgKFxuICAgIHYud2lkdGggPD0gMCB8fFxuICAgIHYuaGVpZ2h0IDw9IDAgfHxcbiAgICB0LmhlaWdodCA8PSAwIHx8XG4gICAgIW5vbm5lZ2F0aXZlKFtcbiAgICAgIGEud2lkdGgsXG4gICAgICBhLmhlaWdodCxcbiAgICAgIGMud2lkdGgsXG4gICAgICBjLmNsaWVudEhlaWdodCxcbiAgICAgIGMuYm9yZGVyVG9wLFxuICAgICAgYy5ib3JkZXJCb3R0b20sXG4gICAgICBjLnBhZGRpbmdUb3AsXG4gICAgICBjLnBhZGRpbmdCb3R0b20sXG4gICAgICB0Lm9mZnNldCxcbiAgICAgIC4uLih0Lm1pbmltdW1PdXRlcklubGluZVNwYW4gPT09IHVuZGVmaW5lZCA/IFtdIDogW3QubWluaW11bU91dGVySW5saW5lU3Bhbl0pLFxuICAgICAgLi4uKHQuaW5saW5lU3RhcnRJbnNldCA9PT0gdW5kZWZpbmVkID8gW10gOiBbdC5pbmxpbmVTdGFydEluc2V0XSksXG4gICAgICBzLnNjcm9sbEhlaWdodCxcbiAgICAgIHMub2Zmc2V0VG9wLFxuICAgICAgcy5oZWlnaHQsXG4gICAgICBzLnBhZGRpbmdUb3AsXG4gICAgICBzLnBhZGRpbmdCb3R0b20sXG4gICAgXSkgfHxcbiAgICBhLnJpZ2h0IDwgYS5sZWZ0IHx8XG4gICAgYy5yaWdodCA8IGMubGVmdFxuICApXG4gICAgcmV0dXJuIGludmFsaWQoJ2ludmFsaWQtZXh0ZW50Jyk7XG4gIGNvbnN0IHsgbWFyZ2luLCBtaW5pbXVtVGFyZ2V0U3BhbkNvdW50IH0gPSBjb25zdHJhaW50cztcbiAgaWYgKFxuICAgICFmaW5pdGUoW21hcmdpbiwgbWluaW11bVRhcmdldFNwYW5Db3VudF0pIHx8XG4gICAgbWFyZ2luIDwgMCB8fFxuICAgIG1pbmltdW1UYXJnZXRTcGFuQ291bnQgPD0gMCB8fFxuICAgIGNvbnN0cmFpbnRzLmJvdW5kYXJ5ICE9PSAnbGF5b3V0LXZpZXdwb3J0JyB8fFxuICAgIGNvbnN0cmFpbnRzLmlubGluZU92ZXJmbG93ICE9PSAncHJlc2VydmUtc3RhcnQnIHx8XG4gICAgKG1ldHJpY3MuZGlyZWN0aW9uICE9PSAnbHRyJyAmJiBtZXRyaWNzLmRpcmVjdGlvbiAhPT0gJ3J0bCcpIHx8XG4gICAgdHlwZW9mIGNvbnN0cmFpbnRzLmV4cGFuZE9uU2Nyb2xsICE9PSAnYm9vbGVhbidcbiAgKVxuICAgIHJldHVybiBpbnZhbGlkKCdpbnZhbGlkLWNvbnN0cmFpbnQnKTtcblxuICBjb25zdCBydGwgPSBtZXRyaWNzLmRpcmVjdGlvbiA9PT0gJ3J0bCc7XG4gIC8vIEEgc2l6ZS1tYXRjaGVkIHRhcmdldCByZXBsYWNlcyB0aGUgcmVmZXJlbmNlIGJveC4gSXRzIHN1cnJvdW5kaW5nIGNocm9tZVxuICAvLyByZW1haW5zIG91dHNpZGUgdGhhdCBib3g7IHRleHQgbWV0cmljcyBuZXZlciBkZWNpZGUgdGhlIHBsYWNlbWVudC5cbiAgY29uc3QgcmVmZXJlbmNlSW5zZXQgPSAocnRsID8gdi53aWR0aCAtIGEucmlnaHQgOiBhLmxlZnQpIC0gKHQuaW5saW5lU3RhcnRJbnNldCA/PyAwKTtcbiAgY29uc3QgbWluaW11bUlubGluZVNwYW4gPSBNYXRoLm1heChhLndpZHRoLCB0Lm1pbmltdW1PdXRlcklubGluZVNwYW4gPz8gMCk7XG4gIGNvbnN0IHdpZHRoRm9yQ2xhbXAgPSBNYXRoLm1heChtaW5pbXVtSW5saW5lU3BhbiwgYy53aWR0aCk7XG4gIGNvbnN0IGlubGluZUluc2V0ID0gY2xhbXAoXG4gICAgcmVmZXJlbmNlSW5zZXQsXG4gICAgbWFyZ2luLFxuICAgIE1hdGgubWF4KG1hcmdpbiwgdi53aWR0aCAtIG1hcmdpbiAtIHdpZHRoRm9yQ2xhbXApXG4gICk7XG5cbiAgY29uc3QgYXZhaWxhYmxlID0gdi5oZWlnaHQgLSAyICogbWFyZ2luO1xuICBjb25zdCBuYXR1cmFsID0gYy5ib3JkZXJUb3AgKyBjLnBhZGRpbmdUb3AgKyBzLnNjcm9sbEhlaWdodCArIGMucGFkZGluZ0JvdHRvbSArIGMuYm9yZGVyQm90dG9tO1xuICBjb25zdCBtaW5pbXVtID0gTWF0aC5taW4obWluaW11bVRhcmdldFNwYW5Db3VudCAqIHQuaGVpZ2h0LCBuYXR1cmFsKTtcbiAgY29uc3QgYmVmb3JlUmVmZXJlbmNlID0gYS50b3AgKyBhLmhlaWdodCAvIDIgLSBtYXJnaW47XG4gIGNvbnN0IGFmdGVyUmVmZXJlbmNlID0gYXZhaWxhYmxlIC0gYmVmb3JlUmVmZXJlbmNlO1xuICBjb25zdCBoYWxmID0gdC5oZWlnaHQgLyAyO1xuICBjb25zdCBiZWZvcmVUYXJnZXQgPSBjLmJvcmRlclRvcCArIGMucGFkZGluZ1RvcCArIHQub2Zmc2V0ICsgaGFsZjtcbiAgY29uc3QgYWZ0ZXJUYXJnZXQgPSBuYXR1cmFsIC0gYmVmb3JlVGFyZ2V0O1xuICBjb25zdCBlbmRQaW5uZWQgPSBiZWZvcmVUYXJnZXQgPD0gYmVmb3JlUmVmZXJlbmNlO1xuICBjb25zdCByZXF1ZXN0ZWRTcGFuID0gZW5kUGlubmVkXG4gICAgPyBiZWZvcmVUYXJnZXQgK1xuICAgICAgTWF0aC5tYXgoXG4gICAgICAgIGFmdGVyUmVmZXJlbmNlLFxuICAgICAgICBoYWxmICtcbiAgICAgICAgICAodC5hdEVuZCA/IHMucGFkZGluZ0JvdHRvbSA6IDApICtcbiAgICAgICAgICBjLmNsaWVudEhlaWdodCAtXG4gICAgICAgICAgcy5vZmZzZXRUb3AgLVxuICAgICAgICAgIHMuaGVpZ2h0ICtcbiAgICAgICAgICBjLmJvcmRlckJvdHRvbVxuICAgICAgKVxuICAgIDogTWF0aC5tYXgoYmVmb3JlUmVmZXJlbmNlLCBjLmJvcmRlclRvcCArIHMub2Zmc2V0VG9wICsgKHQuYXRTdGFydCA/IHMucGFkZGluZ1RvcCA6IDApICsgaGFsZikgK1xuICAgICAgYWZ0ZXJUYXJnZXQ7XG4gIGNvbnN0IHJlcXVlc3RlZFNjcm9sbCA9IGVuZFBpbm5lZCA/IHVuZGVmaW5lZCA6IGJlZm9yZVRhcmdldCAtIGJlZm9yZVJlZmVyZW5jZSArIHMub2Zmc2V0VG9wO1xuICBpZiAoXG4gICAgIWZpbml0ZShbXG4gICAgICBtaW5pbXVtSW5saW5lU3BhbixcbiAgICAgIGlubGluZUluc2V0LFxuICAgICAgYXZhaWxhYmxlLFxuICAgICAgbWluaW11bSxcbiAgICAgIHJlcXVlc3RlZFNwYW4sXG4gICAgICAuLi4ocmVxdWVzdGVkU2Nyb2xsID09PSB1bmRlZmluZWQgPyBbXSA6IFtyZXF1ZXN0ZWRTY3JvbGxdKSxcbiAgICBdKVxuICApXG4gICAgcmV0dXJuIGludmFsaWQoJ25vbmZpbml0ZS1wbGFuJyk7XG4gIGNvbnN0IHBsYW46IFRhcmdldEFsaWdubWVudFBsYW4gPSBPYmplY3QuZnJlZXplKHtcbiAgICBpbmxpbmU6IE9iamVjdC5mcmVlemUoe1xuICAgICAgZWRnZTogcnRsID8gJ3JpZ2h0JyA6ICdsZWZ0JyxcbiAgICAgIGluc2V0OiBpbmxpbmVJbnNldCxcbiAgICAgIG1pbmltdW1TcGFuOiBtaW5pbXVtSW5saW5lU3BhbixcbiAgICB9KSxcbiAgICBibG9jazogT2JqZWN0LmZyZWV6ZSh7XG4gICAgICBwaW46IGVuZFBpbm5lZCA/ICdlbmQnIDogJ3N0YXJ0JyxcbiAgICAgIG1hcmdpbixcbiAgICAgIHJlcXVlc3RlZFNwYW4sXG4gICAgICBtaW5pbXVtU3BhbjogbWluaW11bSxcbiAgICAgIG1heGltdW1TcGFuOiBhdmFpbGFibGUsXG4gICAgfSksXG4gICAgY29udGVudEFsaWdubWVudDogJ25vcm1hbCcsXG4gICAgLi4uKHJlcXVlc3RlZFNjcm9sbCA9PT0gdW5kZWZpbmVkID8ge30gOiB7IHJlcXVlc3RlZFNjcm9sbCB9KSxcbiAgfSk7XG4gIHJldHVybiBPYmplY3QuZnJlZXplKHsga2luZDogJ3BsYW4nLCBwbGFuIH0pO1xufVxuXG5leHBvcnQgdHlwZSBTY3JvbGxFeHBhbnNpb25TYW1wbGUgPSBSZWFkb25seTx7XG4gIGVuYWJsZWQ6IGJvb2xlYW47XG4gIHByZXZpb3VzQWN0dWFsU2Nyb2xsOiBudW1iZXI7XG4gIGFjdHVhbFNjcm9sbDogbnVtYmVyO1xuICBwcmV2aW91c1JlcXVlc3RlZFNwYW46IG51bWJlcjtcbiAgbWluaW11bVNwYW46IG51bWJlcjtcbiAgYXZhaWxhYmxlU3BhbjogbnVtYmVyO1xuICBwaW46ICdzdGFydCcgfCAnZW5kJztcbn0+O1xuZXhwb3J0IHR5cGUgU2Nyb2xsRXhwYW5zaW9uUGxhbiA9IFJlYWRvbmx5PHtcbiAgLyoqIFRoZSBzdXBwbGllZCBhY3R1YWwgc2FtcGxlLiBBIHJlcXVlc3RlZCBjb3JyZWN0aW9uIHN0aWxsIHJlcXVpcmVzIGhvc3QgcmVhZGJhY2suICovXG4gIG5leHRQcmV2aW91c0FjdHVhbFNjcm9sbDogbnVtYmVyO1xuICByZXF1ZXN0ZWRTcGFuPzogbnVtYmVyO1xuICByZXF1ZXN0ZWRTY3JvbGw/OiBudW1iZXI7XG4gIGNvbnRlbnRBbGlnbm1lbnQ/OiAnZW5kJztcbn0+O1xuZXhwb3J0IHR5cGUgU2Nyb2xsRXhwYW5zaW9uUmVzdWx0ID0gSW52YWxpZCB8IFJlYWRvbmx5PHsga2luZDogJ3BsYW4nOyBwbGFuOiBTY3JvbGxFeHBhbnNpb25QbGFuIH0+O1xuXG5leHBvcnQgZnVuY3Rpb24gcmVkdWNlU2Nyb2xsRXhwYW5zaW9uKHNhbXBsZTogU2Nyb2xsRXhwYW5zaW9uU2FtcGxlKTogU2Nyb2xsRXhwYW5zaW9uUmVzdWx0IHtcbiAgY29uc3QgdmFsdWVzID0gW1xuICAgIHNhbXBsZS5wcmV2aW91c0FjdHVhbFNjcm9sbCxcbiAgICBzYW1wbGUuYWN0dWFsU2Nyb2xsLFxuICAgIHNhbXBsZS5wcmV2aW91c1JlcXVlc3RlZFNwYW4sXG4gICAgc2FtcGxlLm1pbmltdW1TcGFuLFxuICAgIHNhbXBsZS5hdmFpbGFibGVTcGFuLFxuICBdO1xuICBpZiAoIWZpbml0ZSh2YWx1ZXMpKSByZXR1cm4gaW52YWxpZCgnbm9uZmluaXRlLWZhY3QnKTtcbiAgaWYgKCFub25uZWdhdGl2ZSh2YWx1ZXMuc2xpY2UoMCwgNCkpKSByZXR1cm4gaW52YWxpZCgnaW52YWxpZC1leHRlbnQnKTtcbiAgaWYgKChzYW1wbGUucGluICE9PSAnc3RhcnQnICYmIHNhbXBsZS5waW4gIT09ICdlbmQnKSB8fCB0eXBlb2Ygc2FtcGxlLmVuYWJsZWQgIT09ICdib29sZWFuJykge1xuICAgIHJldHVybiBpbnZhbGlkKCdpbnZhbGlkLWNvbnN0cmFpbnQnKTtcbiAgfVxuICBjb25zdCBkZWx0YSA9IE1hdGguYWJzKHNhbXBsZS5wcmV2aW91c0FjdHVhbFNjcm9sbCAtIHNhbXBsZS5hY3R1YWxTY3JvbGwpO1xuICBjb25zdCBwcmV2aW91c1NwYW4gPSBNYXRoLm1heChzYW1wbGUubWluaW11bVNwYW4sIHNhbXBsZS5wcmV2aW91c1JlcXVlc3RlZFNwYW4pO1xuICBsZXQgcGxhbjogU2Nyb2xsRXhwYW5zaW9uUGxhbiA9IHsgbmV4dFByZXZpb3VzQWN0dWFsU2Nyb2xsOiBzYW1wbGUuYWN0dWFsU2Nyb2xsIH07XG4gIGlmIChzYW1wbGUuZW5hYmxlZCAmJiBkZWx0YSA+IDAgJiYgcHJldmlvdXNTcGFuIDwgc2FtcGxlLmF2YWlsYWJsZVNwYW4pIHtcbiAgICBjb25zdCBwcm9wb3NlZCA9IHByZXZpb3VzU3BhbiArIGRlbHRhO1xuICAgIGNvbnN0IHJlcXVlc3RlZFNwYW4gPSBNYXRoLm1pbihzYW1wbGUuYXZhaWxhYmxlU3BhbiwgcHJvcG9zZWQpO1xuICAgIGlmICghTnVtYmVyLmlzRmluaXRlKHByb3Bvc2VkKSkgcmV0dXJuIGludmFsaWQoJ25vbmZpbml0ZS1wbGFuJyk7XG4gICAgcGxhbiA9IHtcbiAgICAgIC4uLnBsYW4sXG4gICAgICByZXF1ZXN0ZWRTcGFuLFxuICAgICAgLi4uKHNhbXBsZS5waW4gPT09ICdlbmQnXG4gICAgICAgID8ge1xuICAgICAgICAgICAgcmVxdWVzdGVkU2Nyb2xsOiBNYXRoLm1heChwcm9wb3NlZCAtIHJlcXVlc3RlZFNwYW4sIDApLFxuICAgICAgICAgICAgY29udGVudEFsaWdubWVudDogJ2VuZCcgYXMgY29uc3QsXG4gICAgICAgICAgfVxuICAgICAgICA6IHt9KSxcbiAgICB9O1xuICB9XG4gIHJldHVybiBPYmplY3QuZnJlZXplKHsga2luZDogJ3BsYW4nLCBwbGFuOiBPYmplY3QuZnJlZXplKHBsYW4pIH0pO1xufVxuIiwgImltcG9ydCB7IG93blN0eWxlcyB9IGZyb20gJy4vb3duZWQtc3R5bGUtbGVhc2UnO1xuaW1wb3J0IHtcbiAgY3JlYXRlQm9yZGVyQm94U2l6ZUxlYXNlLFxuICBoYXNCb3JkZXJCb3hJbmxpbmVDbGlwcGluZyxcbiAgbGF5b3V0SW5saW5lU3RhcnQsXG4gIG1lYXN1cmVCb3JkZXJCb3hJbmxpbmVHdXR0ZXIsXG59IGZyb20gJy4vYm9yZGVyLWJveC1zaXplLWxlYXNlJztcbmltcG9ydCB0eXBlIHtcbiAgQW5jaG9yZWRQb3NpdGlvbkNvbm5lY3Rpb24sXG4gIFRhcmdldEFsaWdubWVudENvbm5lY3Rpb24sXG4gIFRhcmdldEFsaWdubWVudFN0YXR1cyxcbn0gZnJvbSAnQHByb3RvLnVpL2NvcmUnO1xuaW1wb3J0IHR5cGUgeyBBbmNob3JlZFBvc2l0aW9uSG9zdExlYXNlIH0gZnJvbSAnLi4vY2Fwcyc7XG5pbXBvcnQge1xuICByZWR1Y2VTY3JvbGxFeHBhbnNpb24sXG4gIHNvbHZlVGFyZ2V0QWxpZ25tZW50LFxuICB0eXBlIFRhcmdldEFsaWdubWVudFBsYW4sXG59IGZyb20gJy4uL2dlb21ldHJ5L3RhcmdldC1hbGlnbm1lbnQnO1xuXG5jb25zdCBlbGVtZW50ID0gKHZhbHVlOiB1bmtub3duKTogdmFsdWUgaXMgSFRNTEVsZW1lbnQgPT5cbiAgISF2YWx1ZSAmJlxuICB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmXG4gICh2YWx1ZSBhcyBOb2RlKS5ub2RlVHlwZSA9PT0gMSAmJlxuICB0eXBlb2YgKHZhbHVlIGFzIEhUTUxFbGVtZW50KS5nZXRCb3VuZGluZ0NsaWVudFJlY3QgPT09ICdmdW5jdGlvbicgJiZcbiAgJ3N0eWxlJyBpbiB2YWx1ZTtcblxuLyoqIFVuc2Nyb2xsZWQgbGF5b3V0IG9mZnNldCwgaW5kZXBlbmRlbnQgb2YgdHJhbnNmb3JtcyBhbmQgaW50ZXJ2ZW5pbmcgcG9zaXRpb25lZCBhbmNlc3RvcnMuICovXG5mdW5jdGlvbiBsYXlvdXRUb3Aobm9kZTogSFRNTEVsZW1lbnQpOiBudW1iZXIge1xuICBsZXQgdG9wID0gMDtcbiAgbGV0IGN1cnJlbnQ6IEhUTUxFbGVtZW50IHwgbnVsbCA9IG5vZGU7XG4gIHdoaWxlIChjdXJyZW50KSB7XG4gICAgdG9wICs9IGN1cnJlbnQub2Zmc2V0VG9wO1xuICAgIGNvbnN0IHBhcmVudDogRWxlbWVudCB8IG51bGwgPSBjdXJyZW50Lm9mZnNldFBhcmVudDtcbiAgICBpZiAoIWVsZW1lbnQocGFyZW50KSkgYnJlYWs7XG4gICAgdG9wICs9IHBhcmVudC5jbGllbnRUb3A7XG4gICAgY3VycmVudCA9IHBhcmVudDtcbiAgfVxuICByZXR1cm4gdG9wO1xufVxuY29uc3QgcmVsYXRpdmVUb3AgPSAobm9kZTogSFRNTEVsZW1lbnQsIGFuY2VzdG9yOiBIVE1MRWxlbWVudCkgPT5cbiAgbGF5b3V0VG9wKG5vZGUpIC0gbGF5b3V0VG9wKGFuY2VzdG9yKSAtIGFuY2VzdG9yLmNsaWVudFRvcDtcblxudHlwZSBUYXJnZXRzID0ge1xuICBbSyBpblxuICAgIHwgJ3N1cmZhY2UnXG4gICAgfCAnc2Nyb2xscG9ydCdcbiAgICB8ICdibG9ja1JlZmVyZW5jZSdcbiAgICB8ICdpbmxpbmVSZWZlcmVuY2UnXG4gICAgfCAnYmxvY2tUYXJnZXQnXG4gICAgfCAnaW5saW5lVGFyZ2V0J106IEhUTUxFbGVtZW50O1xufTtcblxuZnVuY3Rpb24gc2FtZUdlb21ldHJ5KGE6IEFuY2hvcmVkUG9zaXRpb25Db25uZWN0aW9uLCBiOiBBbmNob3JlZFBvc2l0aW9uQ29ubmVjdGlvbik6IGJvb2xlYW4ge1xuICBjb25zdCB4ID0gYS50YXJnZXRBbGlnbm1lbnQsXG4gICAgeSA9IGIudGFyZ2V0QWxpZ25tZW50O1xuICBpZiAoIXggfHwgIXkgfHwgYS5mbG9hdGluZyAhPT0gYi5mbG9hdGluZykgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBzYW1lU2l6ZSA9XG4gICAgKCF4LnNpemVNYXRjaCAmJiAheS5zaXplTWF0Y2gpIHx8XG4gICAgKCEheC5zaXplTWF0Y2ggJiZcbiAgICAgICEheS5zaXplTWF0Y2ggJiZcbiAgICAgIHguc2l6ZU1hdGNoLnJlZmVyZW5jZSA9PT0geS5zaXplTWF0Y2gucmVmZXJlbmNlICYmXG4gICAgICB4LnNpemVNYXRjaC50YXJnZXRzLmxlbmd0aCA9PT0geS5zaXplTWF0Y2gudGFyZ2V0cy5sZW5ndGggJiZcbiAgICAgIHguc2l6ZU1hdGNoLnRhcmdldHMuZXZlcnkoKHRhcmdldCwgaW5kZXgpID0+IHRhcmdldCA9PT0geS5zaXplTWF0Y2g/LnRhcmdldHNbaW5kZXhdKSk7XG4gIHJldHVybiAoXG4gICAgc2FtZVNpemUgJiZcbiAgICAoXG4gICAgICBbXG4gICAgICAgICdzdXJmYWNlJyxcbiAgICAgICAgJ3Njcm9sbHBvcnQnLFxuICAgICAgICAnYmxvY2tSZWZlcmVuY2UnLFxuICAgICAgICAnaW5saW5lUmVmZXJlbmNlJyxcbiAgICAgICAgJ2Jsb2NrVGFyZ2V0JyxcbiAgICAgICAgJ2lubGluZVRhcmdldCcsXG4gICAgICAgICdhdFN0YXJ0JyxcbiAgICAgICAgJ2F0RW5kJyxcbiAgICAgIF0gYXMgY29uc3RcbiAgICApLmV2ZXJ5KChrZXkpID0+IHhba2V5XSA9PT0geVtrZXldKSAmJlxuICAgIChcbiAgICAgIFsnYm91bmRhcnknLCAnbWFyZ2luJywgJ21pbmltdW1UYXJnZXRTcGFuQ291bnQnLCAnaW5saW5lT3ZlcmZsb3cnLCAnZXhwYW5kT25TY3JvbGwnXSBhcyBjb25zdFxuICAgICkuZXZlcnkoKGtleSkgPT4geC5jb25zdHJhaW50c1trZXldID09PSB5LmNvbnN0cmFpbnRzW2tleV0pXG4gICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVUYXJnZXRBbGlnbm1lbnRMZWFzZShcbiAgaW5pdGlhbDogQW5jaG9yZWRQb3NpdGlvbkNvbm5lY3Rpb25cbik6IEFuY2hvcmVkUG9zaXRpb25Ib3N0TGVhc2Uge1xuICBsZXQgY29ubmVjdGlvbiA9IGluaXRpYWw7XG4gIGxldCBkaXNwb3NlZCA9IGZhbHNlO1xuICBsZXQgdmVyc2lvbiA9IDA7XG4gIGxldCBsYXN0U3RhdHVzOiBUYXJnZXRBbGlnbm1lbnRTdGF0dXMgfCBudWxsID0gbnVsbDtcbiAgbGV0IHN0b3A6ICgoKSA9PiB2b2lkKSB8IG51bGwgPSBudWxsO1xuICBsZXQgcmVzdG9yZTogKCgpID0+IHZvaWQpIHwgbnVsbCA9IG51bGw7XG4gIGxldCB1cGRhdGVHZW9tZXRyeTogKCgpID0+IHZvaWQpIHwgbnVsbCA9IG51bGw7XG5cbiAgY29uc3QgcmV0aXJlID0gKCkgPT4ge1xuICAgIHN0b3A/LigpO1xuICAgIHN0b3AgPSBudWxsO1xuICAgIHVwZGF0ZUdlb21ldHJ5ID0gbnVsbDtcbiAgICByZXN0b3JlPy4oKTtcbiAgICByZXN0b3JlID0gbnVsbDtcbiAgfTtcbiAgY29uc3Qgc3RhcnQgPSAoKSA9PiB7XG4gICAgY29uc3QgY3VycmVudCA9IGNvbm5lY3Rpb247XG4gICAgY29uc3QgcmVxdWVzdCA9ICsrdmVyc2lvbjtcbiAgICBsYXN0U3RhdHVzID0gbnVsbDtcbiAgICByZXRpcmUoKTtcbiAgICBjb25zdCBsaXZlID0gKCkgPT4gIWRpc3Bvc2VkICYmIHZlcnNpb24gPT09IHJlcXVlc3Q7XG4gICAgY29uc3QgcmVwb3J0ID0gKHN0YXR1czogVGFyZ2V0QWxpZ25tZW50U3RhdHVzKSA9PiB7XG4gICAgICBpZiAobGl2ZSgpKSB7XG4gICAgICAgIGxhc3RTdGF0dXMgPSBzdGF0dXM7XG4gICAgICAgIGNvbm5lY3Rpb24ub25BbGlnbm1lbnQ/LihzdGF0dXMpO1xuICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgZGVzY3JpcHRvciA9IGN1cnJlbnQudGFyZ2V0QWxpZ25tZW50O1xuICAgIGlmICghZGVzY3JpcHRvciB8fCAhZWxlbWVudChjdXJyZW50LmZsb2F0aW5nKSkge1xuICAgICAgcmVwb3J0KHsgc3RhdHVzOiAncGVuZGluZy10YXJnZXQnLCByZWFzb246ICdtaXNzaW5nLXRhcmdldCcgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGtleXMgPSBbXG4gICAgICAnc3VyZmFjZScsXG4gICAgICAnc2Nyb2xscG9ydCcsXG4gICAgICAnYmxvY2tSZWZlcmVuY2UnLFxuICAgICAgJ2lubGluZVJlZmVyZW5jZScsXG4gICAgICAnYmxvY2tUYXJnZXQnLFxuICAgICAgJ2lubGluZVRhcmdldCcsXG4gICAgXSBhcyBjb25zdDtcbiAgICBpZiAoIWtleXMuZXZlcnkoKGtleSkgPT4gZWxlbWVudChkZXNjcmlwdG9yW2tleV0pKSkge1xuICAgICAgcmVwb3J0KHsgc3RhdHVzOiAncGVuZGluZy10YXJnZXQnLCByZWFzb246ICdtaXNzaW5nLXRhcmdldCcgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHRhcmdldHMgPSBkZXNjcmlwdG9yIGFzIFRhcmdldEFsaWdubWVudENvbm5lY3Rpb24gJiBUYXJnZXRzO1xuICAgIGNvbnN0IGZyYW1lID0gY3VycmVudC5mbG9hdGluZztcbiAgICBjb25zdCBkb2MgPSBmcmFtZS5vd25lckRvY3VtZW50O1xuICAgIGNvbnN0IHZpZXcgPSBkb2MuZGVmYXVsdFZpZXc7XG4gICAgaWYgKCF2aWV3KSB7XG4gICAgICByZXBvcnQoeyBzdGF0dXM6ICdwZW5kaW5nLXRhcmdldCcsIHJlYXNvbjogJ2RldGFjaGVkLXRhcmdldCcgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHNpemluZyA9IGRlc2NyaXB0b3Iuc2l6ZU1hdGNoO1xuICAgIGlmIChcbiAgICAgIHNpemluZyAmJlxuICAgICAgKCFlbGVtZW50KHNpemluZy5yZWZlcmVuY2UpIHx8IHNpemluZy50YXJnZXRzLmxlbmd0aCA9PT0gMCB8fCAhc2l6aW5nLnRhcmdldHMuZXZlcnkoZWxlbWVudCkpXG4gICAgKSB7XG4gICAgICByZXBvcnQoeyBzdGF0dXM6ICdwZW5kaW5nLXRhcmdldCcsIHJlYXNvbjogJ21pc3NpbmctdGFyZ2V0JyB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qgc2l6ZVRhcmdldHMgPSBzaXppbmcgPyAoc2l6aW5nLnRhcmdldHMgYXMgcmVhZG9ubHkgSFRNTEVsZW1lbnRbXSkgOiBbXTtcbiAgICBjb25zdCBzaXplTGVhc2UgPSBzaXppbmdcbiAgICAgID8gY3JlYXRlQm9yZGVyQm94U2l6ZUxlYXNlKHNpemluZy5yZWZlcmVuY2UgYXMgSFRNTEVsZW1lbnQsIHNpemVUYXJnZXRzLCBsaXZlKVxuICAgICAgOiBudWxsO1xuICAgIGNvbnN0IG93bmVkID0gb3duU3R5bGVzKGZyYW1lKTtcbiAgICBjb25zdCByZWplY3RBZG1pc3Npb24gPSAocmVhc29uOiAnaW52YWxpZC1nZW9tZXRyeScgfCAnb3duZXJzaGlwLWxvc3QnIHwgJ3NpemUtY29uZmxpY3QnKSA9PiB7XG4gICAgICAvLyBBZG1pc3Npb24gZmFpbHVyZSBpcyBvYnNlcnZhYmxlIHN5bmNocm9ub3VzbHkuIFJvbGwgYmFjayBvdXIgc2l6aW5nXG4gICAgICAvLyBiZWZvcmUgZGVsaXZlcnk7IHBlbmRpbmcgbGF5b3V0IGtlZXBzIGl0cyBpZGVudGl0eSBjbGFpbXMgaW5zdGVhZC5cbiAgICAgIHNpemVMZWFzZT8uYWJvcnQocmVhc29uKTtcbiAgICAgIHJlcG9ydCh7IHN0YXR1czogJ3VuYXZhaWxhYmxlJywgcmVhc29uIH0pO1xuICAgIH07XG4gICAgcmVzdG9yZSA9ICgpID0+IHtcbiAgICAgIG93bmVkLnJlc3RvcmUoKTtcbiAgICAgIHNpemVMZWFzZT8ucmVzdG9yZSgpO1xuICAgIH07XG4gICAgbGV0IHBsYW46IFRhcmdldEFsaWdubWVudFBsYW4gfCBudWxsID0gbnVsbDtcbiAgICBsZXQgcmVxdWVzdGVkU3BhbiA9IDA7XG4gICAgbGV0IHByZXZpb3VzU2Nyb2xsID0gdGFyZ2V0cy5zY3JvbGxwb3J0LnNjcm9sbFRvcDtcbiAgICBsZXQgZXhwYW5kID0gZmFsc2U7XG4gICAgbGV0IGZyYW1lVGFzazogbnVtYmVyIHwgbnVsbCA9IG51bGw7XG4gICAgbGV0IGFwcGxpZWQgPSBmYWxzZTtcbiAgICBsZXQgd3JpdGluZyA9IGZhbHNlO1xuICAgIGxldCBvd25lcnNoaXBMb3N0ID0gZmFsc2U7XG4gICAgbGV0IHJlZmVyZW5jZUJveDogcmVhZG9ubHkgbnVtYmVyW10gfCBudWxsID0gbnVsbDtcbiAgICBjb25zdCB3cml0ZSA9IChuYW1lOiBzdHJpbmcsIHZhbHVlOiBzdHJpbmcpID0+IHtcbiAgICAgIGlmICghbGl2ZSgpIHx8IG93bmVyc2hpcExvc3QpIHJldHVybiBmYWxzZTtcbiAgICAgIGlmICghb3duZWQud3JpdGUobmFtZSwgdmFsdWUpKSB7XG4gICAgICAgIG93bmVyc2hpcExvc3QgPSB0cnVlO1xuICAgICAgICByZWplY3RBZG1pc3Npb24oJ293bmVyc2hpcC1sb3N0Jyk7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH07XG4gICAgY29uc3QgY29ubmVjdGVkID0gKCkgPT5cbiAgICAgIGZyYW1lLmlzQ29ubmVjdGVkICYmXG4gICAgICBrZXlzLmV2ZXJ5KChrZXkpID0+IHRhcmdldHNba2V5XS5pc0Nvbm5lY3RlZCAmJiB0YXJnZXRzW2tleV0ub3duZXJEb2N1bWVudCA9PT0gZG9jKSAmJlxuICAgICAgc2l6ZVRhcmdldHMuZXZlcnkoKHRhcmdldCkgPT4gdGFyZ2V0LmlzQ29ubmVjdGVkICYmIHRhcmdldC5vd25lckRvY3VtZW50ID09PSBkb2MpO1xuICAgIGNvbnN0IHJlYWRQbGFuID0gKCk6IFRhcmdldEFsaWdubWVudFBsYW4gfCBudWxsID0+IHtcbiAgICAgIGlmICghbGl2ZSgpIHx8ICFjb25uZWN0ZWQoKSkge1xuICAgICAgICBpZiAobGl2ZSgpKSByZXBvcnQoeyBzdGF0dXM6ICdwZW5kaW5nLXRhcmdldCcsIHJlYXNvbjogJ2RldGFjaGVkLXRhcmdldCcgfSk7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgY29uc3QgcmVmZXJlbmNlID0gdGFyZ2V0cy5ibG9ja1JlZmVyZW5jZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgIC8vIEZsb2F0aW5nIGxheW91dCB1c2VzIENTU09NIG9mZnNldCBwcmVjaXNpb24sIG5vdCB0aGUgU3VyZmFjZSdzIGFuaW1hdGVkIHBhaW50IGJvdW5kcy5cbiAgICAgIC8vIEtlZXAgdGhlIG5ldXRyYWwgRnJhbWUgb3JpZ2luIGFuZCByZWZlcmVuY2Ugdmlld3BvcnQgZnJhY3Rpb25zLlxuICAgICAgY29uc3Qgb3JpZ2luID0gZnJhbWUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkubGVmdCAtIGxheW91dElubGluZVN0YXJ0KGZyYW1lKTtcbiAgICAgIGNvbnN0IHN1cmZhY2VMZWZ0ID0gb3JpZ2luICsgbGF5b3V0SW5saW5lU3RhcnQodGFyZ2V0cy5zdXJmYWNlKTtcbiAgICAgIGNvbnN0IHN1cmZhY2VXaWR0aCA9IHRhcmdldHMuc3VyZmFjZS5vZmZzZXRXaWR0aDtcbiAgICAgIGlmICh0YXJnZXRzLmJsb2NrVGFyZ2V0Lm9mZnNldEhlaWdodCA8PSAwIHx8IHJlZmVyZW5jZS5oZWlnaHQgPD0gMCkge1xuICAgICAgICByZXBvcnQoeyBzdGF0dXM6ICdwZW5kaW5nLXRhcmdldCcsIHJlYXNvbjogJ21pc3NpbmctdGFyZ2V0JyB9KTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG4gICAgICBjb25zdCBwYWludCA9IHZpZXcuZ2V0Q29tcHV0ZWRTdHlsZSh0YXJnZXRzLnN1cmZhY2UpO1xuICAgICAgY29uc3Qgc2Nyb2xsID0gdmlldy5nZXRDb21wdXRlZFN0eWxlKHRhcmdldHMuc2Nyb2xscG9ydCk7XG4gICAgICBjb25zdCBjc3MgPSAodGV4dDogc3RyaW5nKSA9PiBOdW1iZXIucGFyc2VJbnQodGV4dCwgMTApO1xuICAgICAgY29uc3QgZ3V0dGVycyA9IHNpemVUYXJnZXRzLm1hcCgodGFyZ2V0KSA9PlxuICAgICAgICBtZWFzdXJlQm9yZGVyQm94SW5saW5lR3V0dGVyKHRhcmdldCwgdGFyZ2V0cy5zdXJmYWNlKVxuICAgICAgKTtcbiAgICAgIGlmIChndXR0ZXJzLnNvbWUoKGd1dHRlcikgPT4gZ3V0dGVyID09PSBudWxsKSkge1xuICAgICAgICByZWplY3RBZG1pc3Npb24oJ2ludmFsaWQtZ2VvbWV0cnknKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG4gICAgICBjb25zdCBtaW5pbXVtT3V0ZXJJbmxpbmVTcGFuID0gc2l6ZVRhcmdldHMubGVuZ3RoXG4gICAgICAgID8gKHNpemluZz8ucmVmZXJlbmNlIGFzIEhUTUxFbGVtZW50KS5vZmZzZXRXaWR0aCArIE1hdGgubWF4KC4uLihndXR0ZXJzIGFzIG51bWJlcltdKSlcbiAgICAgICAgOiB1bmRlZmluZWQ7XG4gICAgICBjb25zdCBkaXJlY3Rpb24gPSB2aWV3LmdldENvbXB1dGVkU3R5bGUoZnJhbWUpLmRpcmVjdGlvbiA9PT0gJ3J0bCcgPyAncnRsJyA6ICdsdHInO1xuICAgICAgY29uc3QgbWF0Y2hlZFRhcmdldCA9IHNpemVUYXJnZXRzLmluY2x1ZGVzKHRhcmdldHMuYmxvY2tUYXJnZXQpO1xuICAgICAgY29uc3QgdGFyZ2V0TGVmdCA9IG9yaWdpbiArIGxheW91dElubGluZVN0YXJ0KHRhcmdldHMuYmxvY2tUYXJnZXQpO1xuICAgICAgY29uc3QgaW5saW5lU3RhcnRJbnNldCA9IG1hdGNoZWRUYXJnZXRcbiAgICAgICAgPyBkaXJlY3Rpb24gPT09ICdydGwnXG4gICAgICAgICAgPyBzdXJmYWNlTGVmdCArIHN1cmZhY2VXaWR0aCAtIHRhcmdldExlZnQgLSB0YXJnZXRzLmJsb2NrVGFyZ2V0Lm9mZnNldFdpZHRoXG4gICAgICAgICAgOiB0YXJnZXRMZWZ0IC0gc3VyZmFjZUxlZnRcbiAgICAgICAgOiB1bmRlZmluZWQ7XG4gICAgICAvLyBDU1MgZml4ZWQgYGxlZnRgL2ByaWdodGAgcmVzb2x2ZSBhZ2FpbnN0IHRoZSBsYXlvdXQgdmlld3BvcnQuXG4gICAgICAvLyBgaW5uZXJXaWR0aGAgaW5jbHVkZXMgYSBjbGFzc2ljIHNjcm9sbGJhcjsgdXNpbmcgaXQgYXMgdGhlIFJUTFxuICAgICAgLy8gY29udGFpbmluZy1ibG9jayB3aWR0aCBwYXJrcyB0aGUgcG9wdXAgb25lIHNjcm9sbGJhciBhd2F5IGZyb20gdGhlXG4gICAgICAvLyBhbmNob3IgKGhlYWRlciBzZWxlY3QgbmV2ZXIgbWF0Y2hlcyBpdHMgcmVmZXJlbmNlIGFuZCBzdGF5cyB1bnN0YWJsZSkuXG4gICAgICAvLyBBIHplcm8gY2xpZW50IGJveCBpcyBhbiBlbnZpcm9ubWVudCB3aXRob3V0IGxheW91dCAodW5pdCB0ZXN0cyksIG5vdCBhXG4gICAgICAvLyBzY3JvbGxiYXIsIHNvIGtlZXAgdGhlIHdpbmRvdyBzaXplIHRoZXJlLlxuICAgICAgY29uc3QgbGF5b3V0Um9vdCA9IGRvYy5kb2N1bWVudEVsZW1lbnQ7XG4gICAgICBjb25zdCB2aWV3cG9ydFdpZHRoID0gbGF5b3V0Um9vdC5jbGllbnRXaWR0aCA+IDAgPyBsYXlvdXRSb290LmNsaWVudFdpZHRoIDogdmlldy5pbm5lcldpZHRoO1xuICAgICAgY29uc3Qgdmlld3BvcnRIZWlnaHQgPVxuICAgICAgICBsYXlvdXRSb290LmNsaWVudEhlaWdodCA+IDAgPyBsYXlvdXRSb290LmNsaWVudEhlaWdodCA6IHZpZXcuaW5uZXJIZWlnaHQ7XG4gICAgICBjb25zdCByZXN1bHQgPSBzb2x2ZVRhcmdldEFsaWdubWVudChcbiAgICAgICAge1xuICAgICAgICAgIGRpcmVjdGlvbixcbiAgICAgICAgICB2aWV3cG9ydDogeyB3aWR0aDogdmlld3BvcnRXaWR0aCwgaGVpZ2h0OiB2aWV3cG9ydEhlaWdodCB9LFxuICAgICAgICAgIHJlZmVyZW5jZToge1xuICAgICAgICAgICAgbGVmdDogcmVmZXJlbmNlLmxlZnQsXG4gICAgICAgICAgICByaWdodDogcmVmZXJlbmNlLnJpZ2h0LFxuICAgICAgICAgICAgdG9wOiByZWZlcmVuY2UudG9wLFxuICAgICAgICAgICAgd2lkdGg6IHJlZmVyZW5jZS53aWR0aCxcbiAgICAgICAgICAgIGhlaWdodDogcmVmZXJlbmNlLmhlaWdodCxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHN1cmZhY2U6IHtcbiAgICAgICAgICAgIGxlZnQ6IHN1cmZhY2VMZWZ0LFxuICAgICAgICAgICAgcmlnaHQ6IHN1cmZhY2VMZWZ0ICsgc3VyZmFjZVdpZHRoLFxuICAgICAgICAgICAgd2lkdGg6IHN1cmZhY2VXaWR0aCxcbiAgICAgICAgICAgIGNsaWVudEhlaWdodDogdGFyZ2V0cy5zdXJmYWNlLmNsaWVudEhlaWdodCxcbiAgICAgICAgICAgIGJvcmRlclRvcDogY3NzKHBhaW50LmJvcmRlclRvcFdpZHRoKSxcbiAgICAgICAgICAgIGJvcmRlckJvdHRvbTogY3NzKHBhaW50LmJvcmRlckJvdHRvbVdpZHRoKSxcbiAgICAgICAgICAgIHBhZGRpbmdUb3A6IGNzcyhwYWludC5wYWRkaW5nVG9wKSxcbiAgICAgICAgICAgIHBhZGRpbmdCb3R0b206IGNzcyhwYWludC5wYWRkaW5nQm90dG9tKSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHRhcmdldDoge1xuICAgICAgICAgICAgb2Zmc2V0OiByZWxhdGl2ZVRvcCh0YXJnZXRzLmJsb2NrVGFyZ2V0LCB0YXJnZXRzLnNjcm9sbHBvcnQpLFxuICAgICAgICAgICAgaGVpZ2h0OiB0YXJnZXRzLmJsb2NrVGFyZ2V0Lm9mZnNldEhlaWdodCxcbiAgICAgICAgICAgIGF0U3RhcnQ6IGRlc2NyaXB0b3IuYXRTdGFydCxcbiAgICAgICAgICAgIGF0RW5kOiBkZXNjcmlwdG9yLmF0RW5kLFxuICAgICAgICAgICAgLi4uKG1pbmltdW1PdXRlcklubGluZVNwYW4gPT09IHVuZGVmaW5lZCA/IHt9IDogeyBtaW5pbXVtT3V0ZXJJbmxpbmVTcGFuIH0pLFxuICAgICAgICAgICAgLi4uKGlubGluZVN0YXJ0SW5zZXQgPT09IHVuZGVmaW5lZCA/IHt9IDogeyBpbmxpbmVTdGFydEluc2V0IH0pLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgc2Nyb2xscG9ydDoge1xuICAgICAgICAgICAgc2Nyb2xsSGVpZ2h0OiB0YXJnZXRzLnNjcm9sbHBvcnQuc2Nyb2xsSGVpZ2h0LFxuICAgICAgICAgICAgb2Zmc2V0VG9wOiByZWxhdGl2ZVRvcCh0YXJnZXRzLnNjcm9sbHBvcnQsIHRhcmdldHMuc3VyZmFjZSksXG4gICAgICAgICAgICBoZWlnaHQ6IHRhcmdldHMuc2Nyb2xscG9ydC5vZmZzZXRIZWlnaHQsXG4gICAgICAgICAgICBwYWRkaW5nVG9wOiBjc3Moc2Nyb2xsLnBhZGRpbmdUb3ApLFxuICAgICAgICAgICAgcGFkZGluZ0JvdHRvbTogY3NzKHNjcm9sbC5wYWRkaW5nQm90dG9tKSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBkZXNjcmlwdG9yLmNvbnN0cmFpbnRzXG4gICAgICApO1xuICAgICAgaWYgKCFsaXZlKCkpIHJldHVybiBudWxsO1xuICAgICAgaWYgKHJlc3VsdC5raW5kICE9PSAncGxhbicpIHtcbiAgICAgICAgcmVqZWN0QWRtaXNzaW9uKCdpbnZhbGlkLWdlb21ldHJ5Jyk7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3VsdC5wbGFuO1xuICAgIH07XG4gICAgY29uc3QgZXF1aXZhbGVudCA9IChhOiBUYXJnZXRBbGlnbm1lbnRQbGFuLCBiOiBUYXJnZXRBbGlnbm1lbnRQbGFuKSA9PlxuICAgICAgYS5pbmxpbmUuZWRnZSA9PT0gYi5pbmxpbmUuZWRnZSAmJlxuICAgICAgYS5ibG9jay5waW4gPT09IGIuYmxvY2sucGluICYmXG4gICAgICBNYXRoLmFicyhhLmlubGluZS5pbnNldCAtIGIuaW5saW5lLmluc2V0KSA8IDAuMDEgJiZcbiAgICAgIE1hdGguYWJzKGEuaW5saW5lLm1pbmltdW1TcGFuIC0gYi5pbmxpbmUubWluaW11bVNwYW4pIDwgMC4wMSAmJlxuICAgICAgTWF0aC5hYnMoYS5ibG9jay5yZXF1ZXN0ZWRTcGFuIC0gYi5ibG9jay5yZXF1ZXN0ZWRTcGFuKSA8IDAuMDEgJiZcbiAgICAgIE1hdGguYWJzKGEuYmxvY2subWluaW11bVNwYW4gLSBiLmJsb2NrLm1pbmltdW1TcGFuKSA8IDAuMDEgJiZcbiAgICAgIE1hdGguYWJzKGEuYmxvY2subWF4aW11bVNwYW4gLSBiLmJsb2NrLm1heGltdW1TcGFuKSA8IDAuMDEgJiZcbiAgICAgIGEucmVxdWVzdGVkU2Nyb2xsID09PSBiLnJlcXVlc3RlZFNjcm9sbDtcbiAgICBjb25zdCBwb3NpdGlvbiA9ICgpID0+IHtcbiAgICAgIGlmICghbGl2ZSgpIHx8IHdyaXRpbmcgfHwgb3duZXJzaGlwTG9zdCkgcmV0dXJuO1xuICAgICAgd3JpdGluZyA9IHRydWU7XG4gICAgICBsZXQgc3RhYmxlID0gZmFsc2U7XG4gICAgICBsZXQgbmV4dFJlZmVyZW5jZUJveDogcmVhZG9ubHkgbnVtYmVyW10gPSBbXTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlZmVyZW5jZSA9IHRhcmdldHMuYmxvY2tSZWZlcmVuY2UuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgIG5leHRSZWZlcmVuY2VCb3ggPSBbcmVmZXJlbmNlLmxlZnQsIHJlZmVyZW5jZS50b3AsIHJlZmVyZW5jZS53aWR0aCwgcmVmZXJlbmNlLmhlaWdodF07XG4gICAgICAgIGNvbnN0IHJlZmVyZW5jZUNoYW5nZWQgPVxuICAgICAgICAgICEhcmVmZXJlbmNlQm94ICYmIG5leHRSZWZlcmVuY2VCb3guc29tZSgodmFsdWUsIGluZGV4KSA9PiB2YWx1ZSAhPT0gcmVmZXJlbmNlQm94IVtpbmRleF0pO1xuICAgICAgICBmb3IgKGNvbnN0IFtuYW1lLCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMoe1xuICAgICAgICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxuICAgICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgICAnZmxleC1kaXJlY3Rpb24nOiAnY29sdW1uJyxcbiAgICAgICAgICAvLyBTY3JvbGwgZXhwYW5zaW9uIG93bnMgZW5kIGFsaWdubWVudCBvbmx5IHdoaWxlIGl0cyByZWZlcmVuY2VcbiAgICAgICAgICAvLyBnZW9tZXRyeSBpcyBjdXJyZW50LiBBIG5ldyByZWZlcmVuY2UgcGxhbiByZXNldHMgdGhhdCBhbGlnbm1lbnRcbiAgICAgICAgICAvLyB3aXRoIGl0cyBzcGFuL3Njcm9sbDsgYSBzYW1lLXJlZmVyZW5jZSByZWZyZXNoIHJldGFpbnMgZXhwYW5zaW9uLlxuICAgICAgICAgIC4uLighYXBwbGllZCB8fCByZWZlcmVuY2VDaGFuZ2VkID8geyAnanVzdGlmeS1jb250ZW50JzogJ25vcm1hbCcgfSA6IHt9KSxcbiAgICAgICAgICAvLyBOZXV0cmFsIHJlZmVyZW5jZSBmYWN0cywgbWF0Y2hpbmcgdGhlIGVkZ2UgaG9zdCBhbmQgbmF0aXZlIHRhcmdldHMuXG4gICAgICAgICAgLy8gRmFtaWx5IHJlY2lwZXMgbWF5IGJpbmQgcG9wdXAgY2hyb21lIHRvIHRoZSBhbmNob3Igd2l0aG91dCBhIHNpemUgbGVhc2UuXG4gICAgICAgICAgJy0tcHJvdG8tdWktYW5jaG9yLXdpZHRoJzogYCR7dGFyZ2V0cy5ibG9ja1JlZmVyZW5jZS5vZmZzZXRXaWR0aH1weGAsXG4gICAgICAgICAgJy0tcHJvdG8tdWktYW5jaG9yLWhlaWdodCc6IGAke3RhcmdldHMuYmxvY2tSZWZlcmVuY2Uub2Zmc2V0SGVpZ2h0fXB4YCxcbiAgICAgICAgfSkpXG4gICAgICAgICAgaWYgKCF3cml0ZShuYW1lLCB2YWx1ZSkpIHJldHVybjtcbiAgICAgICAgaWYgKHNpemVMZWFzZSkge1xuICAgICAgICAgIGNvbnN0IHNpemVkID0gc2l6ZUxlYXNlLnByZXBhcmUoKTtcbiAgICAgICAgICBpZiAoc2l6ZWQua2luZCAhPT0gJ3ByZXBhcmVkJykge1xuICAgICAgICAgICAgaWYgKHNpemVkLmtpbmQgPT09ICdwZW5kaW5nJylcbiAgICAgICAgICAgICAgcmVwb3J0KHsgc3RhdHVzOiAncGVuZGluZy10YXJnZXQnLCByZWFzb246ICdtaXNzaW5nLXRhcmdldCcgfSk7XG4gICAgICAgICAgICBlbHNlIGlmIChzaXplZC5yZWFzb24gPT09ICdkZXRhY2hlZC10YXJnZXQnKVxuICAgICAgICAgICAgICByZXBvcnQoeyBzdGF0dXM6ICdwZW5kaW5nLXRhcmdldCcsIHJlYXNvbjogJ2RldGFjaGVkLXRhcmdldCcgfSk7XG4gICAgICAgICAgICBlbHNlIHJlcG9ydCh7IHN0YXR1czogJ3VuYXZhaWxhYmxlJywgcmVhc29uOiBzaXplZC5yZWFzb24gfSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIElubGluZSBjb25zdHJhaW50cyBjYW4gcmVmbG93IHByZWNlZGluZyByb3dzLiBOZXZlciB1c2UgcHJlLXdpZHRoIGJsb2NrIG1ldHJpY3MuXG4gICAgICAgIGxldCBjYW5kaWRhdGUgPSByZWFkUGxhbigpO1xuICAgICAgICBpZiAoIWNhbmRpZGF0ZSkgcmV0dXJuO1xuICAgICAgICBmb3IgKGxldCBwYXNzID0gMDsgcGFzcyA8IDQ7IHBhc3MrKykge1xuICAgICAgICAgIGZvciAoY29uc3QgW25hbWUsIHZhbHVlXSBvZiBPYmplY3QuZW50cmllcyh7XG4gICAgICAgICAgICAnbWluLXdpZHRoJzogYCR7Y2FuZGlkYXRlLmlubGluZS5taW5pbXVtU3Bhbn1weGAsXG4gICAgICAgICAgICAuLi4oc2l6ZUxlYXNlID8geyB3aWR0aDogYCR7Y2FuZGlkYXRlLmlubGluZS5taW5pbXVtU3Bhbn1weGAgfSA6IHt9KSxcbiAgICAgICAgICAgIFtjYW5kaWRhdGUuaW5saW5lLmVkZ2VdOiBgJHtjYW5kaWRhdGUuaW5saW5lLmluc2V0fXB4YCxcbiAgICAgICAgICAgIFtjYW5kaWRhdGUuaW5saW5lLmVkZ2UgPT09ICdsZWZ0JyA/ICdyaWdodCcgOiAnbGVmdCddOiAnJyxcbiAgICAgICAgICB9KSlcbiAgICAgICAgICAgIGlmICghd3JpdGUobmFtZSwgdmFsdWUpKSByZXR1cm47XG4gICAgICAgICAgaWYgKHNpemVMZWFzZSkge1xuICAgICAgICAgICAgY29uc3Qgc2l6ZWQgPSBzaXplTGVhc2UucHJlcGFyZSgpO1xuICAgICAgICAgICAgaWYgKHNpemVkLmtpbmQgIT09ICdwcmVwYXJlZCcpIHtcbiAgICAgICAgICAgICAgaWYgKHNpemVkLmtpbmQgPT09ICdwZW5kaW5nJylcbiAgICAgICAgICAgICAgICByZXBvcnQoeyBzdGF0dXM6ICdwZW5kaW5nLXRhcmdldCcsIHJlYXNvbjogJ21pc3NpbmctdGFyZ2V0JyB9KTtcbiAgICAgICAgICAgICAgZWxzZSBpZiAoc2l6ZWQucmVhc29uID09PSAnZGV0YWNoZWQtdGFyZ2V0JylcbiAgICAgICAgICAgICAgICByZXBvcnQoeyBzdGF0dXM6ICdwZW5kaW5nLXRhcmdldCcsIHJlYXNvbjogJ2RldGFjaGVkLXRhcmdldCcgfSk7XG4gICAgICAgICAgICAgIGVsc2UgcmVwb3J0KHsgc3RhdHVzOiAndW5hdmFpbGFibGUnLCByZWFzb246IHNpemVkLnJlYXNvbiB9KTtcbiAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBjb25zdHJhaW5lZCA9IHJlYWRQbGFuKCk7XG4gICAgICAgICAgaWYgKCFjb25zdHJhaW5lZCkgcmV0dXJuO1xuICAgICAgICAgIHBsYW4gPSBjb25zdHJhaW5lZDtcbiAgICAgICAgICBjb25zdCBuZXh0U3BhbiA9XG4gICAgICAgICAgICBhcHBsaWVkICYmICFyZWZlcmVuY2VDaGFuZ2VkXG4gICAgICAgICAgICAgID8gTWF0aC5taW4oTWF0aC5tYXgocmVxdWVzdGVkU3BhbiwgcGxhbi5ibG9jay5yZXF1ZXN0ZWRTcGFuKSwgcGxhbi5ibG9jay5tYXhpbXVtU3BhbilcbiAgICAgICAgICAgICAgOiBwbGFuLmJsb2NrLnJlcXVlc3RlZFNwYW47XG4gICAgICAgICAgY29uc3Qgc3R5bGVzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICAgICAgICAgICAgdG9wOiBwbGFuLmJsb2NrLnBpbiA9PT0gJ3N0YXJ0JyA/ICcwcHgnIDogJycsXG4gICAgICAgICAgICBib3R0b206IHBsYW4uYmxvY2sucGluID09PSAnZW5kJyA/ICcwcHgnIDogJycsXG4gICAgICAgICAgICBtYXJnaW46IGAke3BsYW4uYmxvY2subWFyZ2lufXB4IDBweGAsXG4gICAgICAgICAgICBoZWlnaHQ6IGAke25leHRTcGFufXB4YCxcbiAgICAgICAgICAgICdtaW4taGVpZ2h0JzogYCR7cGxhbi5ibG9jay5taW5pbXVtU3Bhbn1weGAsXG4gICAgICAgICAgICAnbWF4LWhlaWdodCc6IGAke3BsYW4uYmxvY2subWF4aW11bVNwYW59cHhgLFxuICAgICAgICAgIH07XG4gICAgICAgICAgZm9yIChjb25zdCBbbmFtZSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKHN0eWxlcykpIGlmICghd3JpdGUobmFtZSwgdmFsdWUpKSByZXR1cm47XG4gICAgICAgICAgcmVxdWVzdGVkU3BhbiA9IG5leHRTcGFuO1xuICAgICAgICAgIGlmICgoIWFwcGxpZWQgfHwgcmVmZXJlbmNlQ2hhbmdlZCkgJiYgcGxhbi5yZXF1ZXN0ZWRTY3JvbGwgIT09IHVuZGVmaW5lZCAmJiBsaXZlKCkpXG4gICAgICAgICAgICB0YXJnZXRzLnNjcm9sbHBvcnQuc2Nyb2xsVG9wID0gcGxhbi5yZXF1ZXN0ZWRTY3JvbGw7XG4gICAgICAgICAgZWxzZSBpZiAocmVmZXJlbmNlQ2hhbmdlZCAmJiBsaXZlKCkpIHRhcmdldHMuc2Nyb2xscG9ydC5zY3JvbGxUb3AgPSAwO1xuICAgICAgICAgIHByZXZpb3VzU2Nyb2xsID0gdGFyZ2V0cy5zY3JvbGxwb3J0LnNjcm9sbFRvcDtcbiAgICAgICAgICBjb25zdCBzZXR0bGVkID0gcmVhZFBsYW4oKTtcbiAgICAgICAgICBpZiAoIXNldHRsZWQpIHJldHVybjtcbiAgICAgICAgICBpZiAoZXF1aXZhbGVudChjYW5kaWRhdGUsIGNvbnN0cmFpbmVkKSAmJiBlcXVpdmFsZW50KGNvbnN0cmFpbmVkLCBzZXR0bGVkKSkge1xuICAgICAgICAgICAgLy8gQ2VydGlmeSB0aGUgZGltZW5zaW9ucyBhbHJlYWR5IHVzZWQgYnkgdGhpcyBwbGFuIHdpdGhvdXQgd3JpdGluZ1xuICAgICAgICAgICAgLy8gYWdhaW4uIEEgbGF0ZSByZWZlcmVuY2UgcmVzaXplIGNvbnN1bWVzIGFub3RoZXIgZXhpc3RpbmcgYm91bmRlZFxuICAgICAgICAgICAgLy8gc29sdmUgcGFzczsgaXQgY2Fubm90IHNpbGVudGx5IGFkbWl0IGEgcGxhbiBmb3IgYW4gZWFybGllciBzaXplLlxuICAgICAgICAgICAgY29uc3Qgc2l6ZWQgPSBzaXplTGVhc2U/LnZlcmlmeSgpO1xuICAgICAgICAgICAgaWYgKHNpemVkPy5raW5kID09PSAncmVmZXJlbmNlLWNoYW5nZWQnKSB7XG4gICAgICAgICAgICAgIGNvbnN0IHByZXBhcmVkID0gc2l6ZUxlYXNlIS5wcmVwYXJlKCk7XG4gICAgICAgICAgICAgIGlmIChwcmVwYXJlZC5raW5kICE9PSAncHJlcGFyZWQnKSB7XG4gICAgICAgICAgICAgICAgaWYgKHByZXBhcmVkLmtpbmQgPT09ICdwZW5kaW5nJylcbiAgICAgICAgICAgICAgICAgIHJlcG9ydCh7IHN0YXR1czogJ3BlbmRpbmctdGFyZ2V0JywgcmVhc29uOiAnbWlzc2luZy10YXJnZXQnIH0pO1xuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHByZXBhcmVkLnJlYXNvbiA9PT0gJ2RldGFjaGVkLXRhcmdldCcpXG4gICAgICAgICAgICAgICAgICByZXBvcnQoeyBzdGF0dXM6ICdwZW5kaW5nLXRhcmdldCcsIHJlYXNvbjogJ2RldGFjaGVkLXRhcmdldCcgfSk7XG4gICAgICAgICAgICAgICAgZWxzZSByZXBvcnQoeyBzdGF0dXM6ICd1bmF2YWlsYWJsZScsIHJlYXNvbjogcHJlcGFyZWQucmVhc29uIH0pO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBjb25zdCByZXNpemVkID0gcmVhZFBsYW4oKTtcbiAgICAgICAgICAgICAgaWYgKCFyZXNpemVkKSByZXR1cm47XG4gICAgICAgICAgICAgIGNhbmRpZGF0ZSA9IHJlc2l6ZWQ7XG4gICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHNpemVkPy5raW5kID09PSAndW5hdmFpbGFibGUnIHx8IHNpemVkPy5raW5kID09PSAncGVuZGluZycpIHtcbiAgICAgICAgICAgICAgaWYgKHNpemVkLmtpbmQgPT09ICdwZW5kaW5nJylcbiAgICAgICAgICAgICAgICByZXBvcnQoeyBzdGF0dXM6ICdwZW5kaW5nLXRhcmdldCcsIHJlYXNvbjogJ21pc3NpbmctdGFyZ2V0JyB9KTtcbiAgICAgICAgICAgICAgZWxzZSBpZiAoc2l6ZWQucmVhc29uID09PSAnZGV0YWNoZWQtdGFyZ2V0JylcbiAgICAgICAgICAgICAgICByZXBvcnQoeyBzdGF0dXM6ICdwZW5kaW5nLXRhcmdldCcsIHJlYXNvbjogJ2RldGFjaGVkLXRhcmdldCcgfSk7XG4gICAgICAgICAgICAgIGVsc2UgcmVwb3J0KHsgc3RhdHVzOiAndW5hdmFpbGFibGUnLCByZWFzb246IHNpemVkLnJlYXNvbiB9KTtcbiAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZm9yIChjb25zdCB0YXJnZXQgb2Ygc2l6ZVRhcmdldHMpIHtcbiAgICAgICAgICAgICAgY29uc3QgY2xpcHBlZCA9IGhhc0JvcmRlckJveElubGluZUNsaXBwaW5nKHRhcmdldCwgZnJhbWUpO1xuICAgICAgICAgICAgICBpZiAoY2xpcHBlZCAhPT0gZmFsc2UpIHtcbiAgICAgICAgICAgICAgICByZWplY3RBZG1pc3Npb24oY2xpcHBlZCA9PT0gbnVsbCA/ICdpbnZhbGlkLWdlb21ldHJ5JyA6ICdzaXplLWNvbmZsaWN0Jyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzdGFibGUgPSB0cnVlO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNhbmRpZGF0ZSA9IHNldHRsZWQ7XG4gICAgICAgIH1cbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHdyaXRpbmcgPSBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGlmICghbGl2ZSgpKSByZXR1cm47XG4gICAgICBpZiAoIXN0YWJsZSkge1xuICAgICAgICByZWplY3RBZG1pc3Npb24oJ2ludmFsaWQtZ2VvbWV0cnknKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgZmlyc3RBcHBseSA9ICFhcHBsaWVkO1xuICAgICAgcmVmZXJlbmNlQm94ID0gbmV4dFJlZmVyZW5jZUJveDtcbiAgICAgIGlmIChmaXJzdEFwcGx5IHx8IGxhc3RTdGF0dXM/LnN0YXR1cyAhPT0gJ2FwcGxpZWQnKSB7XG4gICAgICAgIGFwcGxpZWQgPSB0cnVlO1xuICAgICAgICByZXBvcnQoeyBzdGF0dXM6ICdhcHBsaWVkJyB9KTtcbiAgICAgICAgaWYgKCFsaXZlKCkpIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChmaXJzdEFwcGx5KSB7XG4gICAgICAgIGZyYW1lVGFzayA9IHZpZXcucmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHtcbiAgICAgICAgICBmcmFtZVRhc2sgPSBudWxsO1xuICAgICAgICAgIGlmIChsaXZlKCkpIGV4cGFuZCA9IGRlc2NyaXB0b3IuY29uc3RyYWludHMuZXhwYW5kT25TY3JvbGw7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH07XG4gICAgY29uc3Qgb25TY3JvbGwgPSAoKSA9PiB7XG4gICAgICBpZiAoIWxpdmUoKSB8fCB3cml0aW5nIHx8IG93bmVyc2hpcExvc3QgfHwgIXBsYW4pIHJldHVybjtcbiAgICAgIGNvbnN0IGFjdHVhbFNjcm9sbCA9IHRhcmdldHMuc2Nyb2xscG9ydC5zY3JvbGxUb3A7XG4gICAgICBjb25zdCByZXN1bHQgPSByZWR1Y2VTY3JvbGxFeHBhbnNpb24oe1xuICAgICAgICBlbmFibGVkOiBleHBhbmQsXG4gICAgICAgIHByZXZpb3VzQWN0dWFsU2Nyb2xsOiBwcmV2aW91c1Njcm9sbCxcbiAgICAgICAgYWN0dWFsU2Nyb2xsLFxuICAgICAgICBwcmV2aW91c1JlcXVlc3RlZFNwYW46IHJlcXVlc3RlZFNwYW4sXG4gICAgICAgIG1pbmltdW1TcGFuOiBwbGFuLmJsb2NrLm1pbmltdW1TcGFuLFxuICAgICAgICBhdmFpbGFibGVTcGFuOiB2aWV3LmlubmVySGVpZ2h0IC0gZGVzY3JpcHRvci5jb25zdHJhaW50cy5tYXJnaW4gKiAyLFxuICAgICAgICBwaW46IHBsYW4uYmxvY2sucGluLFxuICAgICAgfSk7XG4gICAgICBpZiAocmVzdWx0LmtpbmQgIT09ICdwbGFuJykgcmV0dXJuO1xuICAgICAgcHJldmlvdXNTY3JvbGwgPSBhY3R1YWxTY3JvbGw7XG4gICAgICB3cml0aW5nID0gdHJ1ZTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGlmIChyZXN1bHQucGxhbi5yZXF1ZXN0ZWRTcGFuICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICBpZiAoIXdyaXRlKCdoZWlnaHQnLCBgJHtyZXN1bHQucGxhbi5yZXF1ZXN0ZWRTcGFufXB4YCkpIHJldHVybjtcbiAgICAgICAgICByZXF1ZXN0ZWRTcGFuID0gcmVzdWx0LnBsYW4ucmVxdWVzdGVkU3BhbjtcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVzdWx0LnBsYW4uY29udGVudEFsaWdubWVudCAmJiAhd3JpdGUoJ2p1c3RpZnktY29udGVudCcsICdmbGV4LWVuZCcpKSByZXR1cm47XG4gICAgICAgIGlmIChyZXN1bHQucGxhbi5yZXF1ZXN0ZWRTY3JvbGwgIT09IHVuZGVmaW5lZCAmJiBsaXZlKCkpXG4gICAgICAgICAgdGFyZ2V0cy5zY3JvbGxwb3J0LnNjcm9sbFRvcCA9IHJlc3VsdC5wbGFuLnJlcXVlc3RlZFNjcm9sbDtcbiAgICAgICAgcHJldmlvdXNTY3JvbGwgPSB0YXJnZXRzLnNjcm9sbHBvcnQuc2Nyb2xsVG9wO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgd3JpdGluZyA9IGZhbHNlO1xuICAgICAgfVxuICAgIH07XG4gICAgY29uc3Qgb25PdXRlclNjcm9sbCA9IChldmVudDogRXZlbnQpID0+IHtcbiAgICAgIGlmIChldmVudC50YXJnZXQgIT09IHRhcmdldHMuc2Nyb2xscG9ydCkgcG9zaXRpb24oKTtcbiAgICB9O1xuICAgIGNvbnN0IG9ic2VydmVkVGFyZ2V0cyA9IG5ldyBTZXQoW2ZyYW1lLCAuLi5rZXlzLm1hcCgoa2V5KSA9PiB0YXJnZXRzW2tleV0pLCAuLi5zaXplVGFyZ2V0c10pO1xuICAgIC8vIFRoZXNlIG1ldHJpY3MgdXNlIGJvdGggYm94ZXMuIE9uZSBvYnNlcnZlciBjYW5ub3QgcmV0YWluIHR3byBib3ggcmVnaXN0cmF0aW9ucyBwZXIgdGFyZ2V0LlxuICAgIGNvbnN0IG9ic2VydmVycyA9XG4gICAgICB0eXBlb2Ygdmlldy5SZXNpemVPYnNlcnZlciA9PT0gJ2Z1bmN0aW9uJ1xuICAgICAgICA/IChbJ2NvbnRlbnQtYm94JywgJ2JvcmRlci1ib3gnXSBhcyBjb25zdCkubWFwKChib3gpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG9ic2VydmVyID0gbmV3IHZpZXcuUmVzaXplT2JzZXJ2ZXIoKCkgPT4gcG9zaXRpb24oKSk7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHRhcmdldCBvZiBvYnNlcnZlZFRhcmdldHMpIG9ic2VydmVyLm9ic2VydmUodGFyZ2V0LCB7IGJveCB9KTtcbiAgICAgICAgICAgIHJldHVybiBvYnNlcnZlcjtcbiAgICAgICAgICB9KVxuICAgICAgICA6IFtdO1xuICAgIHRhcmdldHMuc2Nyb2xscG9ydC5hZGRFdmVudExpc3RlbmVyKCdzY3JvbGwnLCBvblNjcm9sbCk7XG4gICAgZG9jLmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIG9uT3V0ZXJTY3JvbGwsIHRydWUpO1xuICAgIHZpZXcuYWRkRXZlbnRMaXN0ZW5lcigncmVzaXplJywgcG9zaXRpb24pO1xuICAgIHN0b3AgPSAoKSA9PiB7XG4gICAgICBmb3IgKGNvbnN0IG9ic2VydmVyIG9mIG9ic2VydmVycykgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgdGFyZ2V0cy5zY3JvbGxwb3J0LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIG9uU2Nyb2xsKTtcbiAgICAgIGRvYy5yZW1vdmVFdmVudExpc3RlbmVyKCdzY3JvbGwnLCBvbk91dGVyU2Nyb2xsLCB0cnVlKTtcbiAgICAgIHZpZXcucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgcG9zaXRpb24pO1xuICAgICAgaWYgKGZyYW1lVGFzayAhPT0gbnVsbCkgdmlldy5jYW5jZWxBbmltYXRpb25GcmFtZShmcmFtZVRhc2spO1xuICAgICAgZnJhbWVUYXNrID0gbnVsbDtcbiAgICB9O1xuICAgIHVwZGF0ZUdlb21ldHJ5ID0gcG9zaXRpb247XG4gICAgcG9zaXRpb24oKTtcbiAgfTtcbiAgc3RhcnQoKTtcbiAgcmV0dXJuIHtcbiAgICB1cGRhdGUobmV4dCkge1xuICAgICAgaWYgKGRpc3Bvc2VkKSByZXR1cm47XG4gICAgICBpZiAoc2FtZUdlb21ldHJ5KGNvbm5lY3Rpb24sIG5leHQpKSB7XG4gICAgICAgIGNvbm5lY3Rpb24gPSBuZXh0O1xuICAgICAgICBjb25zdCByZXF1ZXN0ID0gdmVyc2lvbjtcbiAgICAgICAgdXBkYXRlR2VvbWV0cnk/LigpO1xuICAgICAgICBpZiAoIWRpc3Bvc2VkICYmIHZlcnNpb24gPT09IHJlcXVlc3QgJiYgY29ubmVjdGlvbiA9PT0gbmV4dCAmJiBsYXN0U3RhdHVzKVxuICAgICAgICAgIG5leHQub25BbGlnbm1lbnQ/LihsYXN0U3RhdHVzKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29ubmVjdGlvbiA9IG5leHQ7XG4gICAgICBzdGFydCgpO1xuICAgIH0sXG4gICAgcmVxdWVzdFVwZGF0ZSgpIHtcbiAgICAgIGlmICghZGlzcG9zZWQpIHVwZGF0ZUdlb21ldHJ5Py4oKTtcbiAgICB9LFxuICAgIGRpc3Bvc2UoKSB7XG4gICAgICBpZiAoZGlzcG9zZWQpIHJldHVybjtcbiAgICAgIGRpc3Bvc2VkID0gdHJ1ZTtcbiAgICAgIHZlcnNpb24rKztcbiAgICAgIHJldGlyZSgpO1xuICAgIH0sXG4gIH07XG59XG4iLCAiaW1wb3J0IHR5cGUgeyBJbnB1dE9yaWdpbkFuY2hvciB9IGZyb20gJ0Bwcm90by51aS9jb3JlJztcbmltcG9ydCB0eXBlIHsgVmlydHVhbEVsZW1lbnQgfSBmcm9tICdAZmxvYXRpbmctdWkvZG9tJztcblxuZXhwb3J0IHR5cGUgV2ViSW5wdXRPcmlnaW5SZWZlcmVuY2UgPSBSZWFkb25seTx7XG4gIGVsZW1lbnQ6IEhUTUxFbGVtZW50O1xuICByZWZlcmVuY2U6IEhUTUxFbGVtZW50IHwgVmlydHVhbEVsZW1lbnQ7XG4gIGlzTGl2ZSgpOiBib29sZWFuO1xuICBzdWJzY3JpYmVJbnZhbGlkYXRpb24oY2FsbGJhY2s6ICgpID0+IHZvaWQpOiAoKSA9PiB2b2lkO1xufT47XG5jb25zdCByZWZlcmVuY2VzID0gbmV3IFdlYWtNYXA8b2JqZWN0LCBXZWJJbnB1dE9yaWdpblJlZmVyZW5jZT4oKTtcblxuLyoqIFByaXZpbGVnZWQgaG9zdC1vbmx5IHJlZ2lzdHJ5LiBUaGUgcG9ydGFibGUgYXNzb2NpYXRpb24gaGFzIG5vIGluc3BlY3RhYmxlIGdlb21ldHJ5LiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZVdlYklucHV0T3JpZ2luQW5jaG9yKFxuICBlbGVtZW50OiBIVE1MRWxlbWVudCxcbiAgcG9pbnQ/OiB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH1cbik6IHsgYW5jaG9yOiBJbnB1dE9yaWdpbkFuY2hvcjsgZGlzcG9zZSgpOiB2b2lkIH0ge1xuICBjb25zdCBhbmNob3IgPSBPYmplY3QuZnJlZXplKE9iamVjdC5jcmVhdGUobnVsbCkpIGFzIElucHV0T3JpZ2luQW5jaG9yO1xuICBsZXQgbGl2ZSA9IHRydWU7XG4gIGNvbnN0IGxpc3RlbmVycyA9IG5ldyBTZXQ8KCkgPT4gdm9pZD4oKTtcbiAgLy8gQ29weSBwcmltaXRpdmVzIGJlZm9yZSBjcmVhdGluZyB0aGUgY2xvc3VyZTsgbmV2ZXIgcmV0YWluIGEgbmF0aXZlIGlucHV0IGV2ZW50LlxuICBjb25zdCB4ID0gcG9pbnQ/Lng7XG4gIGNvbnN0IHkgPSBwb2ludD8ueTtcbiAgY29uc3QgcmVmZXJlbmNlOiBIVE1MRWxlbWVudCB8IFZpcnR1YWxFbGVtZW50ID0gcG9pbnRcbiAgICA/IHtcbiAgICAgICAgY29udGV4dEVsZW1lbnQ6IGVsZW1lbnQsXG4gICAgICAgIGdldEJvdW5kaW5nQ2xpZW50UmVjdDogKCkgPT4gKHtcbiAgICAgICAgICB4OiB4ISxcbiAgICAgICAgICB5OiB5ISxcbiAgICAgICAgICBsZWZ0OiB4ISxcbiAgICAgICAgICB0b3A6IHkhLFxuICAgICAgICAgIHJpZ2h0OiB4ISxcbiAgICAgICAgICBib3R0b206IHkhLFxuICAgICAgICAgIHdpZHRoOiAwLFxuICAgICAgICAgIGhlaWdodDogMCxcbiAgICAgICAgICB0b0pTT046ICgpID0+ICh7fSksXG4gICAgICAgIH0pLFxuICAgICAgfVxuICAgIDogZWxlbWVudDtcbiAgcmVmZXJlbmNlcy5zZXQoYW5jaG9yLCB7XG4gICAgZWxlbWVudCxcbiAgICByZWZlcmVuY2UsXG4gICAgaXNMaXZlOiAoKSA9PiBsaXZlICYmIGVsZW1lbnQuaXNDb25uZWN0ZWQsXG4gICAgc3Vic2NyaWJlSW52YWxpZGF0aW9uKGNhbGxiYWNrKSB7XG4gICAgICBsaXN0ZW5lcnMuYWRkKGNhbGxiYWNrKTtcbiAgICAgIHJldHVybiAoKSA9PiBsaXN0ZW5lcnMuZGVsZXRlKGNhbGxiYWNrKTtcbiAgICB9LFxuICB9KTtcbiAgcmV0dXJuIHtcbiAgICBhbmNob3IsXG4gICAgZGlzcG9zZSgpIHtcbiAgICAgIGlmICghbGl2ZSkgcmV0dXJuO1xuICAgICAgbGl2ZSA9IGZhbHNlO1xuICAgICAgcmVmZXJlbmNlcy5kZWxldGUoYW5jaG9yKTtcbiAgICAgIGZvciAoY29uc3QgY2FsbGJhY2sgb2YgWy4uLmxpc3RlbmVyc10pIGNhbGxiYWNrKCk7XG4gICAgICBsaXN0ZW5lcnMuY2xlYXIoKTtcbiAgICB9LFxuICB9O1xufVxuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVXZWJJbnB1dE9yaWdpbkFuY2hvcih2YWx1ZTogdW5rbm93bik6IFdlYklucHV0T3JpZ2luUmVmZXJlbmNlIHwgbnVsbCB7XG4gIGlmICghdmFsdWUgfHwgdHlwZW9mIHZhbHVlICE9PSAnb2JqZWN0JykgcmV0dXJuIG51bGw7XG4gIGNvbnN0IHJlZmVyZW5jZSA9IHJlZmVyZW5jZXMuZ2V0KHZhbHVlKTtcbiAgcmV0dXJuIHJlZmVyZW5jZT8uaXNMaXZlKCkgPyByZWZlcmVuY2UgOiBudWxsO1xufVxuIiwgIi8qKiBBY3RpdmUgV2ViIGdlb21ldHJ5IGxlYXNlcyBzaGFyZSB0aGlzIHJvb3Qtc3BhY2Ugb2JzZXJ2YXRpb24sIG5ldmVyIGEgZnJhbWUgcG9sbC4gKi9cbnR5cGUgUm9vdFNwYWNlID0gUmVhZG9ubHk8e1xuICB3aWR0aDogbnVtYmVyO1xuICBoZWlnaHQ6IG51bWJlcjtcbiAgbGVmdDogbnVtYmVyO1xuICBib3hXaWR0aDogbnVtYmVyO1xuICBib3hMZWZ0OiBudW1iZXI7XG4gIGJvZHlXaWR0aDogbnVtYmVyO1xuICBib2R5TGVmdDogbnVtYmVyO1xufT47XG50eXBlIFRyYWNrZXIgPSB7IGxpc3RlbmVyczogU2V0PCgpID0+IHZvaWQ+OyBkaXNwb3NlKCk6IHZvaWQgfTtcbmNvbnN0IHJvb3RzID0gbmV3IFdlYWtNYXA8RG9jdW1lbnQsIFRyYWNrZXI+KCk7XG5jb25zdCByZWFkID0gKHJvb3Q6IEhUTUxFbGVtZW50KTogUm9vdFNwYWNlID0+ICh7XG4gIHdpZHRoOiByb290LmNsaWVudFdpZHRoLFxuICBoZWlnaHQ6IHJvb3QuY2xpZW50SGVpZ2h0LFxuICBsZWZ0OiByb290LmNsaWVudExlZnQsXG4gIGJveFdpZHRoOiByb290LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoLFxuICBib3hMZWZ0OiByb290LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmxlZnQgKyAocm9vdC5vd25lckRvY3VtZW50LmRlZmF1bHRWaWV3Py5zY3JvbGxYID8/IDApLFxuICAvLyBXaGVuIHRoZSBwcm9wYWdhdGVkIHBhZ2Ugc2Nyb2xsZXIgaXMgYm9keSAocm9vdCBvdmVyZmxvdyBoaWRkZW4sIGJvZHlcbiAgLy8gb3ZlcmZsb3cgc2Nyb2xsKSwgYSBjbGFzc2ljIGd1dHRlciBiZWxvbmdzIHRvIGJvZHkncyBib3ggYWxvbmU6IHRoZSByb290XG4gIC8vIGJveCBhYm92ZSBzdGF5cyBpZGVudGljYWwsIHNvIHdpdGhvdXQgdGhpcyBoYWxmIHRoZSBkcmlmdCBpcyB1bm9ic2VydmFibGUuXG4gIGJvZHlXaWR0aDogcm9vdC5vd25lckRvY3VtZW50LmJvZHk/LmNsaWVudFdpZHRoID8/IDAsXG4gIGJvZHlMZWZ0OiByb290Lm93bmVyRG9jdW1lbnQuYm9keT8uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkubGVmdCA/PyAwLFxufSk7XG5leHBvcnQgZnVuY3Rpb24gb2JzZXJ2ZVJvb3RTcGFjZShkb2N1bWVudDogRG9jdW1lbnQsIGxpc3RlbmVyOiAoKSA9PiB2b2lkKTogKCkgPT4gdm9pZCB7XG4gIGNvbnN0IHJvb3QgPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQsXG4gICAgdmlldyA9IGRvY3VtZW50LmRlZmF1bHRWaWV3O1xuICBpZiAoIXJvb3QgfHwgIXZpZXcpIHJldHVybiAoKSA9PiB7fTtcbiAgbGV0IHRyYWNrZXIgPSByb290cy5nZXQoZG9jdW1lbnQpO1xuICBpZiAoIXRyYWNrZXIpIHtcbiAgICBsZXQgcHJldmlvdXMgPSByZWFkKHJvb3QpLFxuICAgICAgZGlzcG9zZWQgPSBmYWxzZTtcbiAgICBjb25zdCBsaXN0ZW5lcnMgPSBuZXcgU2V0PCgpID0+IHZvaWQ+KCk7XG4gICAgY29uc3QgdXBkYXRlID0gKCkgPT4ge1xuICAgICAgaWYgKGRpc3Bvc2VkKSByZXR1cm47XG4gICAgICBjb25zdCBuZXh0ID0gcmVhZChyb290KTtcbiAgICAgIGlmIChcbiAgICAgICAgbmV4dC53aWR0aCA9PT0gcHJldmlvdXMud2lkdGggJiZcbiAgICAgICAgbmV4dC5oZWlnaHQgPT09IHByZXZpb3VzLmhlaWdodCAmJlxuICAgICAgICBuZXh0LmxlZnQgPT09IHByZXZpb3VzLmxlZnQgJiZcbiAgICAgICAgbmV4dC5ib3hXaWR0aCA9PT0gcHJldmlvdXMuYm94V2lkdGggJiZcbiAgICAgICAgbmV4dC5ib3hMZWZ0ID09PSBwcmV2aW91cy5ib3hMZWZ0ICYmXG4gICAgICAgIG5leHQuYm9keVdpZHRoID09PSBwcmV2aW91cy5ib2R5V2lkdGggJiZcbiAgICAgICAgbmV4dC5ib2R5TGVmdCA9PT0gcHJldmlvdXMuYm9keUxlZnRcbiAgICAgIClcbiAgICAgICAgcmV0dXJuO1xuICAgICAgcHJldmlvdXMgPSBuZXh0O1xuICAgICAgY29uc3QgZXJyb3JzOiB1bmtub3duW10gPSBbXTtcbiAgICAgIGZvciAoY29uc3QgY2FsbGJhY2sgb2YgWy4uLmxpc3RlbmVyc10pIHtcbiAgICAgICAgaWYgKCFsaXN0ZW5lcnMuaGFzKGNhbGxiYWNrKSkgY29udGludWU7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY2FsbGJhY2soKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBlcnJvcnMucHVzaChlcnJvcik7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC8vIFByZXNlcnZlIHRoZSBob3N0IGNhbGxiYWNrJ3Mgc3VyZmFjZWQtZXJyb3IgcG9saWN5IGFmdGVyIG5vdGlmeWluZ1xuICAgICAgLy8gaW5kZXBlbmRlbnQgb3duZXJzOyBvbmUgZmFpbGVkIGxlYXNlIG11c3Qgbm90IHN0YXJ2ZSB0aGUgb3RoZXJzLlxuICAgICAgaWYgKGVycm9ycy5sZW5ndGggPT09IDEpIHRocm93IGVycm9yc1swXTtcbiAgICAgIGlmIChlcnJvcnMubGVuZ3RoID4gMSkgdGhyb3cgbmV3IEFnZ3JlZ2F0ZUVycm9yKGVycm9ycywgJ1Jvb3Qtc3BhY2Ugc3Vic2NyaWJlcnMgZmFpbGVkJyk7XG4gICAgfTtcbiAgICBjb25zdCByZXNpemUgPVxuICAgICAgdHlwZW9mIHZpZXcuUmVzaXplT2JzZXJ2ZXIgPT09ICdmdW5jdGlvbicgPyBuZXcgdmlldy5SZXNpemVPYnNlcnZlcih1cGRhdGUpIDogbnVsbDtcbiAgICBjb25zdCBtdXRhdGlvbiA9XG4gICAgICB0eXBlb2Ygdmlldy5NdXRhdGlvbk9ic2VydmVyID09PSAnZnVuY3Rpb24nID8gbmV3IHZpZXcuTXV0YXRpb25PYnNlcnZlcih1cGRhdGUpIDogbnVsbDtcbiAgICB0cmFja2VyID0ge1xuICAgICAgbGlzdGVuZXJzLFxuICAgICAgZGlzcG9zZSgpIHtcbiAgICAgICAgZGlzcG9zZWQgPSB0cnVlO1xuICAgICAgICByZXNpemU/LmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgbXV0YXRpb24/LmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgcm9vdHMuZGVsZXRlKGRvY3VtZW50KTtcbiAgICAgIH0sXG4gICAgfTtcbiAgICByb290cy5zZXQoZG9jdW1lbnQsIHRyYWNrZXIpO1xuICAgIC8vIFJvb3Qgd2lkdGggY2FuIGNoYW5nZSB3aXRob3V0IGFuY2hvciBzaXplIG9yIGEgd2luZG93IHJlc2l6ZSwgYW5kIGFuXG4gICAgLy8gaW50ZXJzZWN0aW9uIG9ic2VydmVyIG5lZWQgbm90IHJlcG9ydCBhIHNhbWUtc2l6ZSwgZnVsbHkgdmlzaWJsZSBhbmNob3IuXG4gICAgcmVzaXplPy5vYnNlcnZlKHJvb3QpO1xuICAgIC8vIEJvZHkgcGFydGljaXBhdGVzIGZvciB0aGUgYm9keS1vd25lZCBzY3JvbGxlciBjYXNlOiBpdHMgaW5saW5lIGJveCBjYW5cbiAgICAvLyBjaGFuZ2Ugd2hpbGUgZXZlcnkgcm9vdCBtZWFzdXJlbWVudCBhYm92ZSBzdGF5cyBmaXhlZC4gT2JzZXJ2aW5nIHRoZSByb290XG4gICAgLy8gYWxvbmUgbGVhdmVzIGEgZml4ZWQtcG9zaXRpb24gb3ZlcmxheSBzdGFsZSBieSBleGFjdGx5IHRoZSBndXR0ZXIgd2lkdGguXG4gICAgaWYgKGRvY3VtZW50LmJvZHkpIHJlc2l6ZT8ub2JzZXJ2ZShkb2N1bWVudC5ib2R5KTtcbiAgICAvLyBEaXJlY3Rpb24vc3RhYmxlLWd1dHRlciBjaGFuZ2VzIGNhbiBtb3ZlIHRoZSBvcmlnaW4gd2l0aG91dCByZXNpemluZy5cbiAgICBtdXRhdGlvbj8ub2JzZXJ2ZShyb290LCB7IGF0dHJpYnV0ZXM6IHRydWUsIGF0dHJpYnV0ZUZpbHRlcjogWydkaXInLCAnc3R5bGUnLCAnY2xhc3MnXSB9KTtcbiAgICAvLyBBIHByb3BhZ2F0ZWQgYm9keSBndXR0ZXIgY2FuIGFwcGVhciBvciBkaXNhcHBlYXIgd2l0aG91dCB0b3VjaGluZyBhbnlcbiAgICAvLyByb290IGF0dHJpYnV0ZSwgc28gdGhlIGJvZHkncyBvd24gaW5saW5lIHN0eWxlIGlzIG9ic2VydmVkIHRvby5cbiAgICBpZiAoZG9jdW1lbnQuYm9keSlcbiAgICAgIG11dGF0aW9uPy5vYnNlcnZlKGRvY3VtZW50LmJvZHksIHtcbiAgICAgICAgYXR0cmlidXRlczogdHJ1ZSxcbiAgICAgICAgYXR0cmlidXRlRmlsdGVyOiBbJ2RpcicsICdzdHlsZScsICdjbGFzcyddLFxuICAgICAgfSk7XG4gIH1cbiAgY29uc3Qgb3duZWQgPSB0cmFja2VyO1xuICBjb25zdCBvd25lZExpc3RlbmVyID0gKCkgPT4gbGlzdGVuZXIoKTtcbiAgb3duZWQubGlzdGVuZXJzLmFkZChvd25lZExpc3RlbmVyKTtcbiAgbGV0IHJlbGVhc2VkID0gZmFsc2U7XG4gIHJldHVybiAoKSA9PiB7XG4gICAgaWYgKHJlbGVhc2VkKSByZXR1cm47XG4gICAgcmVsZWFzZWQgPSB0cnVlO1xuICAgIG93bmVkLmxpc3RlbmVycy5kZWxldGUob3duZWRMaXN0ZW5lcik7XG4gICAgaWYgKCFvd25lZC5saXN0ZW5lcnMuc2l6ZSkgb3duZWQuZGlzcG9zZSgpO1xuICB9O1xufVxuIiwgIi8qKlxuICogQ3VzdG9tIHBvc2l0aW9uaW5nIHJlZmVyZW5jZSBlbGVtZW50LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL3ZpcnR1YWwtZWxlbWVudHNcbiAqL1xuXG5jb25zdCBzaWRlcyA9IFsndG9wJywgJ3JpZ2h0JywgJ2JvdHRvbScsICdsZWZ0J107XG5jb25zdCBhbGlnbm1lbnRzID0gWydzdGFydCcsICdlbmQnXTtcbmNvbnN0IHBsYWNlbWVudHMgPSAvKiNfX1BVUkVfXyovc2lkZXMucmVkdWNlKChhY2MsIHNpZGUpID0+IGFjYy5jb25jYXQoc2lkZSwgc2lkZSArIFwiLVwiICsgYWxpZ25tZW50c1swXSwgc2lkZSArIFwiLVwiICsgYWxpZ25tZW50c1sxXSksIFtdKTtcbmNvbnN0IG1pbiA9IE1hdGgubWluO1xuY29uc3QgbWF4ID0gTWF0aC5tYXg7XG5jb25zdCByb3VuZCA9IE1hdGgucm91bmQ7XG5jb25zdCBmbG9vciA9IE1hdGguZmxvb3I7XG5jb25zdCBjcmVhdGVDb29yZHMgPSB2ID0+ICh7XG4gIHg6IHYsXG4gIHk6IHZcbn0pO1xuY29uc3Qgb3Bwb3NpdGVTaWRlTWFwID0ge1xuICBsZWZ0OiAncmlnaHQnLFxuICByaWdodDogJ2xlZnQnLFxuICBib3R0b206ICd0b3AnLFxuICB0b3A6ICdib3R0b20nXG59O1xuZnVuY3Rpb24gY2xhbXAoc3RhcnQsIHZhbHVlLCBlbmQpIHtcbiAgcmV0dXJuIG1heChzdGFydCwgbWluKHZhbHVlLCBlbmQpKTtcbn1cbmZ1bmN0aW9uIGV2YWx1YXRlKHZhbHVlLCBwYXJhbSkge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSAnZnVuY3Rpb24nID8gdmFsdWUocGFyYW0pIDogdmFsdWU7XG59XG5mdW5jdGlvbiBnZXRTaWRlKHBsYWNlbWVudCkge1xuICByZXR1cm4gcGxhY2VtZW50LnNwbGl0KCctJylbMF07XG59XG5mdW5jdGlvbiBnZXRBbGlnbm1lbnQocGxhY2VtZW50KSB7XG4gIHJldHVybiBwbGFjZW1lbnQuc3BsaXQoJy0nKVsxXTtcbn1cbmZ1bmN0aW9uIGdldE9wcG9zaXRlQXhpcyhheGlzKSB7XG4gIHJldHVybiBheGlzID09PSAneCcgPyAneScgOiAneCc7XG59XG5mdW5jdGlvbiBnZXRBeGlzTGVuZ3RoKGF4aXMpIHtcbiAgcmV0dXJuIGF4aXMgPT09ICd5JyA/ICdoZWlnaHQnIDogJ3dpZHRoJztcbn1cbmZ1bmN0aW9uIGdldFNpZGVBeGlzKHBsYWNlbWVudCkge1xuICBjb25zdCBmaXJzdENoYXIgPSBwbGFjZW1lbnRbMF07XG4gIHJldHVybiBmaXJzdENoYXIgPT09ICd0JyB8fCBmaXJzdENoYXIgPT09ICdiJyA/ICd5JyA6ICd4Jztcbn1cbmZ1bmN0aW9uIGdldEFsaWdubWVudEF4aXMocGxhY2VtZW50KSB7XG4gIHJldHVybiBnZXRPcHBvc2l0ZUF4aXMoZ2V0U2lkZUF4aXMocGxhY2VtZW50KSk7XG59XG5mdW5jdGlvbiBnZXRBbGlnbm1lbnRTaWRlcyhwbGFjZW1lbnQsIHJlY3RzLCBydGwpIHtcbiAgaWYgKHJ0bCA9PT0gdm9pZCAwKSB7XG4gICAgcnRsID0gZmFsc2U7XG4gIH1cbiAgY29uc3QgYWxpZ25tZW50ID0gZ2V0QWxpZ25tZW50KHBsYWNlbWVudCk7XG4gIGNvbnN0IGFsaWdubWVudEF4aXMgPSBnZXRBbGlnbm1lbnRBeGlzKHBsYWNlbWVudCk7XG4gIGNvbnN0IGxlbmd0aCA9IGdldEF4aXNMZW5ndGgoYWxpZ25tZW50QXhpcyk7XG4gIGxldCBtYWluQWxpZ25tZW50U2lkZSA9IGFsaWdubWVudEF4aXMgPT09ICd4JyA/IGFsaWdubWVudCA9PT0gKHJ0bCA/ICdlbmQnIDogJ3N0YXJ0JykgPyAncmlnaHQnIDogJ2xlZnQnIDogYWxpZ25tZW50ID09PSAnc3RhcnQnID8gJ2JvdHRvbScgOiAndG9wJztcbiAgaWYgKHJlY3RzLnJlZmVyZW5jZVtsZW5ndGhdID4gcmVjdHMuZmxvYXRpbmdbbGVuZ3RoXSkge1xuICAgIG1haW5BbGlnbm1lbnRTaWRlID0gZ2V0T3Bwb3NpdGVQbGFjZW1lbnQobWFpbkFsaWdubWVudFNpZGUpO1xuICB9XG4gIHJldHVybiBbbWFpbkFsaWdubWVudFNpZGUsIGdldE9wcG9zaXRlUGxhY2VtZW50KG1haW5BbGlnbm1lbnRTaWRlKV07XG59XG5mdW5jdGlvbiBnZXRFeHBhbmRlZFBsYWNlbWVudHMocGxhY2VtZW50KSB7XG4gIGNvbnN0IG9wcG9zaXRlUGxhY2VtZW50ID0gZ2V0T3Bwb3NpdGVQbGFjZW1lbnQocGxhY2VtZW50KTtcbiAgcmV0dXJuIFtnZXRPcHBvc2l0ZUFsaWdubWVudFBsYWNlbWVudChwbGFjZW1lbnQpLCBvcHBvc2l0ZVBsYWNlbWVudCwgZ2V0T3Bwb3NpdGVBbGlnbm1lbnRQbGFjZW1lbnQob3Bwb3NpdGVQbGFjZW1lbnQpXTtcbn1cbmZ1bmN0aW9uIGdldE9wcG9zaXRlQWxpZ25tZW50UGxhY2VtZW50KHBsYWNlbWVudCkge1xuICByZXR1cm4gcGxhY2VtZW50LmluY2x1ZGVzKCdzdGFydCcpID8gcGxhY2VtZW50LnJlcGxhY2UoJ3N0YXJ0JywgJ2VuZCcpIDogcGxhY2VtZW50LnJlcGxhY2UoJ2VuZCcsICdzdGFydCcpO1xufVxuY29uc3QgbHJQbGFjZW1lbnQgPSBbJ2xlZnQnLCAncmlnaHQnXTtcbmNvbnN0IHJsUGxhY2VtZW50ID0gWydyaWdodCcsICdsZWZ0J107XG5jb25zdCB0YlBsYWNlbWVudCA9IFsndG9wJywgJ2JvdHRvbSddO1xuY29uc3QgYnRQbGFjZW1lbnQgPSBbJ2JvdHRvbScsICd0b3AnXTtcbmZ1bmN0aW9uIGdldFNpZGVMaXN0KHNpZGUsIGlzU3RhcnQsIHJ0bCkge1xuICBzd2l0Y2ggKHNpZGUpIHtcbiAgICBjYXNlICd0b3AnOlxuICAgIGNhc2UgJ2JvdHRvbSc6XG4gICAgICBpZiAocnRsKSByZXR1cm4gaXNTdGFydCA/IHJsUGxhY2VtZW50IDogbHJQbGFjZW1lbnQ7XG4gICAgICByZXR1cm4gaXNTdGFydCA/IGxyUGxhY2VtZW50IDogcmxQbGFjZW1lbnQ7XG4gICAgY2FzZSAnbGVmdCc6XG4gICAgY2FzZSAncmlnaHQnOlxuICAgICAgcmV0dXJuIGlzU3RhcnQgPyB0YlBsYWNlbWVudCA6IGJ0UGxhY2VtZW50O1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gW107XG4gIH1cbn1cbmZ1bmN0aW9uIGdldE9wcG9zaXRlQXhpc1BsYWNlbWVudHMocGxhY2VtZW50LCBmbGlwQWxpZ25tZW50LCBkaXJlY3Rpb24sIHJ0bCkge1xuICBjb25zdCBhbGlnbm1lbnQgPSBnZXRBbGlnbm1lbnQocGxhY2VtZW50KTtcbiAgbGV0IGxpc3QgPSBnZXRTaWRlTGlzdChnZXRTaWRlKHBsYWNlbWVudCksIGRpcmVjdGlvbiA9PT0gJ3N0YXJ0JywgcnRsKTtcbiAgaWYgKGFsaWdubWVudCkge1xuICAgIGxpc3QgPSBsaXN0Lm1hcChzaWRlID0+IHNpZGUgKyBcIi1cIiArIGFsaWdubWVudCk7XG4gICAgaWYgKGZsaXBBbGlnbm1lbnQpIHtcbiAgICAgIGxpc3QgPSBsaXN0LmNvbmNhdChsaXN0Lm1hcChnZXRPcHBvc2l0ZUFsaWdubWVudFBsYWNlbWVudCkpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbGlzdDtcbn1cbmZ1bmN0aW9uIGdldE9wcG9zaXRlUGxhY2VtZW50KHBsYWNlbWVudCkge1xuICBjb25zdCBzaWRlID0gZ2V0U2lkZShwbGFjZW1lbnQpO1xuICByZXR1cm4gb3Bwb3NpdGVTaWRlTWFwW3NpZGVdICsgcGxhY2VtZW50LnNsaWNlKHNpZGUubGVuZ3RoKTtcbn1cbmZ1bmN0aW9uIGV4cGFuZFBhZGRpbmdPYmplY3QocGFkZGluZykge1xuICB2YXIgX3BhZGRpbmckdG9wLCBfcGFkZGluZyRyaWdodCwgX3BhZGRpbmckYm90dG9tLCBfcGFkZGluZyRsZWZ0O1xuICByZXR1cm4ge1xuICAgIHRvcDogKF9wYWRkaW5nJHRvcCA9IHBhZGRpbmcudG9wKSAhPSBudWxsID8gX3BhZGRpbmckdG9wIDogMCxcbiAgICByaWdodDogKF9wYWRkaW5nJHJpZ2h0ID0gcGFkZGluZy5yaWdodCkgIT0gbnVsbCA/IF9wYWRkaW5nJHJpZ2h0IDogMCxcbiAgICBib3R0b206IChfcGFkZGluZyRib3R0b20gPSBwYWRkaW5nLmJvdHRvbSkgIT0gbnVsbCA/IF9wYWRkaW5nJGJvdHRvbSA6IDAsXG4gICAgbGVmdDogKF9wYWRkaW5nJGxlZnQgPSBwYWRkaW5nLmxlZnQpICE9IG51bGwgPyBfcGFkZGluZyRsZWZ0IDogMFxuICB9O1xufVxuZnVuY3Rpb24gZ2V0UGFkZGluZ09iamVjdChwYWRkaW5nKSB7XG4gIHJldHVybiB0eXBlb2YgcGFkZGluZyAhPT0gJ251bWJlcicgPyBleHBhbmRQYWRkaW5nT2JqZWN0KHBhZGRpbmcpIDoge1xuICAgIHRvcDogcGFkZGluZyxcbiAgICByaWdodDogcGFkZGluZyxcbiAgICBib3R0b206IHBhZGRpbmcsXG4gICAgbGVmdDogcGFkZGluZ1xuICB9O1xufVxuZnVuY3Rpb24gcmVjdFRvQ2xpZW50UmVjdChyZWN0KSB7XG4gIGNvbnN0IHtcbiAgICB4LFxuICAgIHksXG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0XG4gIH0gPSByZWN0O1xuICByZXR1cm4ge1xuICAgIHdpZHRoLFxuICAgIGhlaWdodCxcbiAgICB0b3A6IHksXG4gICAgbGVmdDogeCxcbiAgICByaWdodDogeCArIHdpZHRoLFxuICAgIGJvdHRvbTogeSArIGhlaWdodCxcbiAgICB4LFxuICAgIHlcbiAgfTtcbn1cblxuZXhwb3J0IHsgYWxpZ25tZW50cywgY2xhbXAsIGNyZWF0ZUNvb3JkcywgZXZhbHVhdGUsIGV4cGFuZFBhZGRpbmdPYmplY3QsIGZsb29yLCBnZXRBbGlnbm1lbnQsIGdldEFsaWdubWVudEF4aXMsIGdldEFsaWdubWVudFNpZGVzLCBnZXRBeGlzTGVuZ3RoLCBnZXRFeHBhbmRlZFBsYWNlbWVudHMsIGdldE9wcG9zaXRlQWxpZ25tZW50UGxhY2VtZW50LCBnZXRPcHBvc2l0ZUF4aXMsIGdldE9wcG9zaXRlQXhpc1BsYWNlbWVudHMsIGdldE9wcG9zaXRlUGxhY2VtZW50LCBnZXRQYWRkaW5nT2JqZWN0LCBnZXRTaWRlLCBnZXRTaWRlQXhpcywgbWF4LCBtaW4sIHBsYWNlbWVudHMsIHJlY3RUb0NsaWVudFJlY3QsIHJvdW5kLCBzaWRlcyB9O1xuIiwgImltcG9ydCB7IGdldFNpZGVBeGlzLCBnZXRBbGlnbm1lbnRBeGlzLCBnZXRBeGlzTGVuZ3RoLCBnZXRTaWRlLCBnZXRBbGlnbm1lbnQsIGV2YWx1YXRlLCBnZXRQYWRkaW5nT2JqZWN0LCByZWN0VG9DbGllbnRSZWN0LCBtaW4sIGNsYW1wLCBwbGFjZW1lbnRzLCBnZXRBbGlnbm1lbnRTaWRlcywgZ2V0T3Bwb3NpdGVBbGlnbm1lbnRQbGFjZW1lbnQsIGdldE9wcG9zaXRlUGxhY2VtZW50LCBnZXRFeHBhbmRlZFBsYWNlbWVudHMsIGdldE9wcG9zaXRlQXhpc1BsYWNlbWVudHMsIHNpZGVzLCBtYXgsIGdldE9wcG9zaXRlQXhpcyB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscyc7XG5leHBvcnQgeyByZWN0VG9DbGllbnRSZWN0IH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzJztcblxuZnVuY3Rpb24gY29tcHV0ZUNvb3Jkc0Zyb21QbGFjZW1lbnQoX3JlZiwgcGxhY2VtZW50LCBydGwpIHtcbiAgbGV0IHtcbiAgICByZWZlcmVuY2UsXG4gICAgZmxvYXRpbmdcbiAgfSA9IF9yZWY7XG4gIGNvbnN0IHNpZGVBeGlzID0gZ2V0U2lkZUF4aXMocGxhY2VtZW50KTtcbiAgY29uc3QgYWxpZ25tZW50QXhpcyA9IGdldEFsaWdubWVudEF4aXMocGxhY2VtZW50KTtcbiAgY29uc3QgYWxpZ25MZW5ndGggPSBnZXRBeGlzTGVuZ3RoKGFsaWdubWVudEF4aXMpO1xuICBjb25zdCBzaWRlID0gZ2V0U2lkZShwbGFjZW1lbnQpO1xuICBjb25zdCBpc1ZlcnRpY2FsID0gc2lkZUF4aXMgPT09ICd5JztcbiAgY29uc3QgY29tbW9uWCA9IHJlZmVyZW5jZS54ICsgcmVmZXJlbmNlLndpZHRoIC8gMiAtIGZsb2F0aW5nLndpZHRoIC8gMjtcbiAgY29uc3QgY29tbW9uWSA9IHJlZmVyZW5jZS55ICsgcmVmZXJlbmNlLmhlaWdodCAvIDIgLSBmbG9hdGluZy5oZWlnaHQgLyAyO1xuICBjb25zdCBjb21tb25BbGlnbiA9IHJlZmVyZW5jZVthbGlnbkxlbmd0aF0gLyAyIC0gZmxvYXRpbmdbYWxpZ25MZW5ndGhdIC8gMjtcbiAgbGV0IGNvb3JkcztcbiAgc3dpdGNoIChzaWRlKSB7XG4gICAgY2FzZSAndG9wJzpcbiAgICAgIGNvb3JkcyA9IHtcbiAgICAgICAgeDogY29tbW9uWCxcbiAgICAgICAgeTogcmVmZXJlbmNlLnkgLSBmbG9hdGluZy5oZWlnaHRcbiAgICAgIH07XG4gICAgICBicmVhaztcbiAgICBjYXNlICdib3R0b20nOlxuICAgICAgY29vcmRzID0ge1xuICAgICAgICB4OiBjb21tb25YLFxuICAgICAgICB5OiByZWZlcmVuY2UueSArIHJlZmVyZW5jZS5oZWlnaHRcbiAgICAgIH07XG4gICAgICBicmVhaztcbiAgICBjYXNlICdyaWdodCc6XG4gICAgICBjb29yZHMgPSB7XG4gICAgICAgIHg6IHJlZmVyZW5jZS54ICsgcmVmZXJlbmNlLndpZHRoLFxuICAgICAgICB5OiBjb21tb25ZXG4gICAgICB9O1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnbGVmdCc6XG4gICAgICBjb29yZHMgPSB7XG4gICAgICAgIHg6IHJlZmVyZW5jZS54IC0gZmxvYXRpbmcud2lkdGgsXG4gICAgICAgIHk6IGNvbW1vbllcbiAgICAgIH07XG4gICAgICBicmVhaztcbiAgICBkZWZhdWx0OlxuICAgICAgY29vcmRzID0ge1xuICAgICAgICB4OiByZWZlcmVuY2UueCxcbiAgICAgICAgeTogcmVmZXJlbmNlLnlcbiAgICAgIH07XG4gIH1cbiAgY29uc3QgYWxpZ25tZW50ID0gZ2V0QWxpZ25tZW50KHBsYWNlbWVudCk7XG4gIGlmIChhbGlnbm1lbnQpIHtcbiAgICBjb29yZHNbYWxpZ25tZW50QXhpc10gKz0gY29tbW9uQWxpZ24gKiAoYWxpZ25tZW50ID09PSAnZW5kJyA/IDEgOiAtMSkgKiAocnRsICYmIGlzVmVydGljYWwgPyAtMSA6IDEpO1xuICB9XG4gIHJldHVybiBjb29yZHM7XG59XG5cbi8qKlxuICogUmVzb2x2ZXMgd2l0aCBhbiBvYmplY3Qgb2Ygb3ZlcmZsb3cgc2lkZSBvZmZzZXRzIHRoYXQgZGV0ZXJtaW5lIGhvdyBtdWNoIHRoZVxuICogZWxlbWVudCBpcyBvdmVyZmxvd2luZyBhIGdpdmVuIGNsaXBwaW5nIGJvdW5kYXJ5IG9uIGVhY2ggc2lkZS5cbiAqIC0gcG9zaXRpdmUgPSBvdmVyZmxvd2luZyB0aGUgYm91bmRhcnkgYnkgdGhhdCBudW1iZXIgb2YgcGl4ZWxzXG4gKiAtIG5lZ2F0aXZlID0gaG93IG1hbnkgcGl4ZWxzIGxlZnQgYmVmb3JlIGl0IHdpbGwgb3ZlcmZsb3dcbiAqIC0gMCA9IGxpZXMgZmx1c2ggd2l0aCB0aGUgYm91bmRhcnlcbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9kZXRlY3RPdmVyZmxvd1xuICovXG5hc3luYyBmdW5jdGlvbiBkZXRlY3RPdmVyZmxvdyhzdGF0ZSwgb3B0aW9ucykge1xuICB2YXIgX2F3YWl0JHBsYXRmb3JtJGlzRWxlO1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG4gIGNvbnN0IHtcbiAgICB4LFxuICAgIHksXG4gICAgcGxhdGZvcm0sXG4gICAgcmVjdHMsXG4gICAgZWxlbWVudHMsXG4gICAgc3RyYXRlZ3lcbiAgfSA9IHN0YXRlO1xuICBjb25zdCB7XG4gICAgYm91bmRhcnkgPSAnY2xpcHBpbmdBbmNlc3RvcnMnLFxuICAgIHJvb3RCb3VuZGFyeSA9ICd2aWV3cG9ydCcsXG4gICAgZWxlbWVudENvbnRleHQgPSAnZmxvYXRpbmcnLFxuICAgIGFsdEJvdW5kYXJ5ID0gZmFsc2UsXG4gICAgcGFkZGluZyA9IDBcbiAgfSA9IGV2YWx1YXRlKG9wdGlvbnMsIHN0YXRlKTtcbiAgY29uc3QgcGFkZGluZ09iamVjdCA9IGdldFBhZGRpbmdPYmplY3QocGFkZGluZyk7XG4gIGNvbnN0IGFsdENvbnRleHQgPSBlbGVtZW50Q29udGV4dCA9PT0gJ2Zsb2F0aW5nJyA/ICdyZWZlcmVuY2UnIDogJ2Zsb2F0aW5nJztcbiAgY29uc3QgZWxlbWVudCA9IGVsZW1lbnRzW2FsdEJvdW5kYXJ5ID8gYWx0Q29udGV4dCA6IGVsZW1lbnRDb250ZXh0XTtcbiAgY29uc3QgY2xpcHBpbmdDbGllbnRSZWN0ID0gcmVjdFRvQ2xpZW50UmVjdChhd2FpdCBwbGF0Zm9ybS5nZXRDbGlwcGluZ1JlY3Qoe1xuICAgIGVsZW1lbnQ6ICgoX2F3YWl0JHBsYXRmb3JtJGlzRWxlID0gYXdhaXQgKHBsYXRmb3JtLmlzRWxlbWVudCA9PSBudWxsID8gdm9pZCAwIDogcGxhdGZvcm0uaXNFbGVtZW50KGVsZW1lbnQpKSkgIT0gbnVsbCA/IF9hd2FpdCRwbGF0Zm9ybSRpc0VsZSA6IHRydWUpID8gZWxlbWVudCA6IGVsZW1lbnQuY29udGV4dEVsZW1lbnQgfHwgKGF3YWl0IChwbGF0Zm9ybS5nZXREb2N1bWVudEVsZW1lbnQgPT0gbnVsbCA/IHZvaWQgMCA6IHBsYXRmb3JtLmdldERvY3VtZW50RWxlbWVudChlbGVtZW50cy5mbG9hdGluZykpKSxcbiAgICBib3VuZGFyeSxcbiAgICByb290Qm91bmRhcnksXG4gICAgc3RyYXRlZ3lcbiAgfSkpO1xuICBjb25zdCByZWN0ID0gZWxlbWVudENvbnRleHQgPT09ICdmbG9hdGluZycgPyB7XG4gICAgeCxcbiAgICB5LFxuICAgIHdpZHRoOiByZWN0cy5mbG9hdGluZy53aWR0aCxcbiAgICBoZWlnaHQ6IHJlY3RzLmZsb2F0aW5nLmhlaWdodFxuICB9IDogcmVjdHMucmVmZXJlbmNlO1xuICBjb25zdCBvZmZzZXRQYXJlbnQgPSBhd2FpdCAocGxhdGZvcm0uZ2V0T2Zmc2V0UGFyZW50ID09IG51bGwgPyB2b2lkIDAgOiBwbGF0Zm9ybS5nZXRPZmZzZXRQYXJlbnQoZWxlbWVudHMuZmxvYXRpbmcpKTtcbiAgY29uc3Qgb2Zmc2V0U2NhbGUgPSAoYXdhaXQgKHBsYXRmb3JtLmlzRWxlbWVudCA9PSBudWxsID8gdm9pZCAwIDogcGxhdGZvcm0uaXNFbGVtZW50KG9mZnNldFBhcmVudCkpKSAmJiAoYXdhaXQgKHBsYXRmb3JtLmdldFNjYWxlID09IG51bGwgPyB2b2lkIDAgOiBwbGF0Zm9ybS5nZXRTY2FsZShvZmZzZXRQYXJlbnQpKSkgfHwge1xuICAgIHg6IDEsXG4gICAgeTogMVxuICB9O1xuICBjb25zdCBlbGVtZW50Q2xpZW50UmVjdCA9IHJlY3RUb0NsaWVudFJlY3QocGxhdGZvcm0uY29udmVydE9mZnNldFBhcmVudFJlbGF0aXZlUmVjdFRvVmlld3BvcnRSZWxhdGl2ZVJlY3QgPyBhd2FpdCBwbGF0Zm9ybS5jb252ZXJ0T2Zmc2V0UGFyZW50UmVsYXRpdmVSZWN0VG9WaWV3cG9ydFJlbGF0aXZlUmVjdCh7XG4gICAgZWxlbWVudHMsXG4gICAgcmVjdCxcbiAgICBvZmZzZXRQYXJlbnQsXG4gICAgc3RyYXRlZ3lcbiAgfSkgOiByZWN0KTtcbiAgcmV0dXJuIHtcbiAgICB0b3A6IChjbGlwcGluZ0NsaWVudFJlY3QudG9wIC0gZWxlbWVudENsaWVudFJlY3QudG9wICsgcGFkZGluZ09iamVjdC50b3ApIC8gb2Zmc2V0U2NhbGUueSxcbiAgICBib3R0b206IChlbGVtZW50Q2xpZW50UmVjdC5ib3R0b20gLSBjbGlwcGluZ0NsaWVudFJlY3QuYm90dG9tICsgcGFkZGluZ09iamVjdC5ib3R0b20pIC8gb2Zmc2V0U2NhbGUueSxcbiAgICBsZWZ0OiAoY2xpcHBpbmdDbGllbnRSZWN0LmxlZnQgLSBlbGVtZW50Q2xpZW50UmVjdC5sZWZ0ICsgcGFkZGluZ09iamVjdC5sZWZ0KSAvIG9mZnNldFNjYWxlLngsXG4gICAgcmlnaHQ6IChlbGVtZW50Q2xpZW50UmVjdC5yaWdodCAtIGNsaXBwaW5nQ2xpZW50UmVjdC5yaWdodCArIHBhZGRpbmdPYmplY3QucmlnaHQpIC8gb2Zmc2V0U2NhbGUueFxuICB9O1xufVxuXG4vLyBNYXhpbXVtIG51bWJlciBvZiByZXNldHMgdGhhdCBjYW4gb2NjdXIgYmVmb3JlIGJhaWxpbmcgdG8gYXZvaWQgaW5maW5pdGUgcmVzZXQgbG9vcHMuXG5jb25zdCBNQVhfUkVTRVRfQ09VTlQgPSA1MDtcblxuLyoqXG4gKiBDb21wdXRlcyB0aGUgYHhgIGFuZCBgeWAgY29vcmRpbmF0ZXMgdGhhdCB3aWxsIHBsYWNlIHRoZSBmbG9hdGluZyBlbGVtZW50XG4gKiBuZXh0IHRvIGEgZ2l2ZW4gcmVmZXJlbmNlIGVsZW1lbnQuXG4gKlxuICogVGhpcyBleHBvcnQgZG9lcyBub3QgaGF2ZSBhbnkgYHBsYXRmb3JtYCBpbnRlcmZhY2UgbG9naWMuIFlvdSB3aWxsIG5lZWQgdG9cbiAqIHdyaXRlIG9uZSBmb3IgdGhlIHBsYXRmb3JtIHlvdSBhcmUgdXNpbmcgRmxvYXRpbmcgVUkgd2l0aC5cbiAqL1xuY29uc3QgY29tcHV0ZVBvc2l0aW9uID0gYXN5bmMgKHJlZmVyZW5jZSwgZmxvYXRpbmcsIGNvbmZpZykgPT4ge1xuICBjb25zdCB7XG4gICAgcGxhY2VtZW50ID0gJ2JvdHRvbScsXG4gICAgc3RyYXRlZ3kgPSAnYWJzb2x1dGUnLFxuICAgIG1pZGRsZXdhcmUgPSBbXSxcbiAgICBwbGF0Zm9ybVxuICB9ID0gY29uZmlnO1xuICBjb25zdCBwbGF0Zm9ybVdpdGhEZXRlY3RPdmVyZmxvdyA9IHBsYXRmb3JtLmRldGVjdE92ZXJmbG93ID8gcGxhdGZvcm0gOiB7XG4gICAgLi4ucGxhdGZvcm0sXG4gICAgZGV0ZWN0T3ZlcmZsb3dcbiAgfTtcbiAgY29uc3QgcnRsID0gYXdhaXQgKHBsYXRmb3JtLmlzUlRMID09IG51bGwgPyB2b2lkIDAgOiBwbGF0Zm9ybS5pc1JUTChmbG9hdGluZykpO1xuICBsZXQgcmVjdHMgPSBhd2FpdCBwbGF0Zm9ybS5nZXRFbGVtZW50UmVjdHMoe1xuICAgIHJlZmVyZW5jZSxcbiAgICBmbG9hdGluZyxcbiAgICBzdHJhdGVneVxuICB9KTtcbiAgbGV0IHtcbiAgICB4LFxuICAgIHlcbiAgfSA9IGNvbXB1dGVDb29yZHNGcm9tUGxhY2VtZW50KHJlY3RzLCBwbGFjZW1lbnQsIHJ0bCk7XG4gIGxldCBzdGF0ZWZ1bFBsYWNlbWVudCA9IHBsYWNlbWVudDtcbiAgbGV0IHJlc2V0Q291bnQgPSAwO1xuICBjb25zdCBtaWRkbGV3YXJlRGF0YSA9IHt9O1xuICBmb3IgKGxldCBpID0gMDsgaSA8IG1pZGRsZXdhcmUubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBjdXJyZW50TWlkZGxld2FyZSA9IG1pZGRsZXdhcmVbaV07XG4gICAgaWYgKCFjdXJyZW50TWlkZGxld2FyZSkge1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGNvbnN0IHtcbiAgICAgIG5hbWUsXG4gICAgICBmblxuICAgIH0gPSBjdXJyZW50TWlkZGxld2FyZTtcbiAgICBjb25zdCB7XG4gICAgICB4OiBuZXh0WCxcbiAgICAgIHk6IG5leHRZLFxuICAgICAgZGF0YSxcbiAgICAgIHJlc2V0XG4gICAgfSA9IGF3YWl0IGZuKHtcbiAgICAgIHgsXG4gICAgICB5LFxuICAgICAgaW5pdGlhbFBsYWNlbWVudDogcGxhY2VtZW50LFxuICAgICAgcGxhY2VtZW50OiBzdGF0ZWZ1bFBsYWNlbWVudCxcbiAgICAgIHN0cmF0ZWd5LFxuICAgICAgbWlkZGxld2FyZURhdGEsXG4gICAgICByZWN0cyxcbiAgICAgIHBsYXRmb3JtOiBwbGF0Zm9ybVdpdGhEZXRlY3RPdmVyZmxvdyxcbiAgICAgIGVsZW1lbnRzOiB7XG4gICAgICAgIHJlZmVyZW5jZSxcbiAgICAgICAgZmxvYXRpbmdcbiAgICAgIH1cbiAgICB9KTtcbiAgICB4ID0gbmV4dFggIT0gbnVsbCA/IG5leHRYIDogeDtcbiAgICB5ID0gbmV4dFkgIT0gbnVsbCA/IG5leHRZIDogeTtcbiAgICBtaWRkbGV3YXJlRGF0YVtuYW1lXSA9IHtcbiAgICAgIC4uLm1pZGRsZXdhcmVEYXRhW25hbWVdLFxuICAgICAgLi4uZGF0YVxuICAgIH07XG4gICAgaWYgKHJlc2V0ICYmIHJlc2V0Q291bnQgPCBNQVhfUkVTRVRfQ09VTlQpIHtcbiAgICAgIHJlc2V0Q291bnQrKztcbiAgICAgIGlmICh0eXBlb2YgcmVzZXQgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIGlmIChyZXNldC5wbGFjZW1lbnQpIHtcbiAgICAgICAgICBzdGF0ZWZ1bFBsYWNlbWVudCA9IHJlc2V0LnBsYWNlbWVudDtcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVzZXQucmVjdHMpIHtcbiAgICAgICAgICByZWN0cyA9IHJlc2V0LnJlY3RzID09PSB0cnVlID8gYXdhaXQgcGxhdGZvcm0uZ2V0RWxlbWVudFJlY3RzKHtcbiAgICAgICAgICAgIHJlZmVyZW5jZSxcbiAgICAgICAgICAgIGZsb2F0aW5nLFxuICAgICAgICAgICAgc3RyYXRlZ3lcbiAgICAgICAgICB9KSA6IHJlc2V0LnJlY3RzO1xuICAgICAgICB9XG4gICAgICAgICh7XG4gICAgICAgICAgeCxcbiAgICAgICAgICB5XG4gICAgICAgIH0gPSBjb21wdXRlQ29vcmRzRnJvbVBsYWNlbWVudChyZWN0cywgc3RhdGVmdWxQbGFjZW1lbnQsIHJ0bCkpO1xuICAgICAgfVxuICAgICAgaSA9IC0xO1xuICAgIH1cbiAgfVxuICByZXR1cm4ge1xuICAgIHgsXG4gICAgeSxcbiAgICBwbGFjZW1lbnQ6IHN0YXRlZnVsUGxhY2VtZW50LFxuICAgIHN0cmF0ZWd5LFxuICAgIG1pZGRsZXdhcmVEYXRhXG4gIH07XG59O1xuXG4vKipcbiAqIFByb3ZpZGVzIGRhdGEgdG8gcG9zaXRpb24gYW4gaW5uZXIgZWxlbWVudCBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBzbyB0aGF0IGl0XG4gKiBhcHBlYXJzIGNlbnRlcmVkIHRvIHRoZSByZWZlcmVuY2UgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9hcnJvd1xuICovXG5jb25zdCBhcnJvdyA9IG9wdGlvbnMgPT4gKHtcbiAgbmFtZTogJ2Fycm93JyxcbiAgb3B0aW9ucyxcbiAgYXN5bmMgZm4oc3RhdGUpIHtcbiAgICBjb25zdCB7XG4gICAgICB4LFxuICAgICAgeSxcbiAgICAgIHBsYWNlbWVudCxcbiAgICAgIHJlY3RzLFxuICAgICAgcGxhdGZvcm0sXG4gICAgICBlbGVtZW50cyxcbiAgICAgIG1pZGRsZXdhcmVEYXRhXG4gICAgfSA9IHN0YXRlO1xuICAgIC8vIFNpbmNlIGBlbGVtZW50YCBpcyByZXF1aXJlZCwgd2UgZG9uJ3QgUGFydGlhbDw+IHRoZSB0eXBlLlxuICAgIGNvbnN0IHtcbiAgICAgIGVsZW1lbnQsXG4gICAgICBwYWRkaW5nID0gMFxuICAgIH0gPSBldmFsdWF0ZShvcHRpb25zLCBzdGF0ZSkgfHwge307XG4gICAgaWYgKGVsZW1lbnQgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuIHt9O1xuICAgIH1cbiAgICBjb25zdCBwYWRkaW5nT2JqZWN0ID0gZ2V0UGFkZGluZ09iamVjdChwYWRkaW5nKTtcbiAgICBjb25zdCBjb29yZHMgPSB7XG4gICAgICB4LFxuICAgICAgeVxuICAgIH07XG4gICAgY29uc3QgYXhpcyA9IGdldEFsaWdubWVudEF4aXMocGxhY2VtZW50KTtcbiAgICBjb25zdCBsZW5ndGggPSBnZXRBeGlzTGVuZ3RoKGF4aXMpO1xuICAgIGNvbnN0IGFycm93RGltZW5zaW9ucyA9IGF3YWl0IHBsYXRmb3JtLmdldERpbWVuc2lvbnMoZWxlbWVudCk7XG4gICAgY29uc3QgaXNZQXhpcyA9IGF4aXMgPT09ICd5JztcbiAgICBjb25zdCBtaW5Qcm9wID0gaXNZQXhpcyA/ICd0b3AnIDogJ2xlZnQnO1xuICAgIGNvbnN0IG1heFByb3AgPSBpc1lBeGlzID8gJ2JvdHRvbScgOiAncmlnaHQnO1xuICAgIGNvbnN0IGNsaWVudFByb3AgPSBpc1lBeGlzID8gJ2NsaWVudEhlaWdodCcgOiAnY2xpZW50V2lkdGgnO1xuICAgIGNvbnN0IGVuZERpZmYgPSByZWN0cy5yZWZlcmVuY2VbbGVuZ3RoXSArIHJlY3RzLnJlZmVyZW5jZVtheGlzXSAtIGNvb3Jkc1theGlzXSAtIHJlY3RzLmZsb2F0aW5nW2xlbmd0aF07XG4gICAgY29uc3Qgc3RhcnREaWZmID0gY29vcmRzW2F4aXNdIC0gcmVjdHMucmVmZXJlbmNlW2F4aXNdO1xuICAgIGNvbnN0IGFycm93T2Zmc2V0UGFyZW50ID0gYXdhaXQgKHBsYXRmb3JtLmdldE9mZnNldFBhcmVudCA9PSBudWxsID8gdm9pZCAwIDogcGxhdGZvcm0uZ2V0T2Zmc2V0UGFyZW50KGVsZW1lbnQpKTtcbiAgICBsZXQgY2xpZW50U2l6ZSA9IGFycm93T2Zmc2V0UGFyZW50ID8gYXJyb3dPZmZzZXRQYXJlbnRbY2xpZW50UHJvcF0gOiAwO1xuXG4gICAgLy8gRE9NIHBsYXRmb3JtIGNhbiByZXR1cm4gYHdpbmRvd2AgYXMgdGhlIGBvZmZzZXRQYXJlbnRgLlxuICAgIGlmICghY2xpZW50U2l6ZSB8fCAhKGF3YWl0IChwbGF0Zm9ybS5pc0VsZW1lbnQgPT0gbnVsbCA/IHZvaWQgMCA6IHBsYXRmb3JtLmlzRWxlbWVudChhcnJvd09mZnNldFBhcmVudCkpKSkge1xuICAgICAgY2xpZW50U2l6ZSA9IGVsZW1lbnRzLmZsb2F0aW5nW2NsaWVudFByb3BdIHx8IHJlY3RzLmZsb2F0aW5nW2xlbmd0aF07XG4gICAgfVxuICAgIGNvbnN0IGNlbnRlclRvUmVmZXJlbmNlID0gZW5kRGlmZiAvIDIgLSBzdGFydERpZmYgLyAyO1xuXG4gICAgLy8gSWYgdGhlIHBhZGRpbmcgaXMgbGFyZ2UgZW5vdWdoIHRoYXQgaXQgY2F1c2VzIHRoZSBhcnJvdyB0byBubyBsb25nZXIgYmVcbiAgICAvLyBjZW50ZXJlZCwgbW9kaWZ5IHRoZSBwYWRkaW5nIHNvIHRoYXQgaXQgaXMgY2VudGVyZWQuXG4gICAgY29uc3QgbGFyZ2VzdFBvc3NpYmxlUGFkZGluZyA9IGNsaWVudFNpemUgLyAyIC0gYXJyb3dEaW1lbnNpb25zW2xlbmd0aF0gLyAyIC0gMTtcbiAgICBjb25zdCBtaW5QYWRkaW5nID0gbWluKHBhZGRpbmdPYmplY3RbbWluUHJvcF0sIGxhcmdlc3RQb3NzaWJsZVBhZGRpbmcpO1xuICAgIGNvbnN0IG1heFBhZGRpbmcgPSBtaW4ocGFkZGluZ09iamVjdFttYXhQcm9wXSwgbGFyZ2VzdFBvc3NpYmxlUGFkZGluZyk7XG5cbiAgICAvLyBNYWtlIHN1cmUgdGhlIGFycm93IGRvZXNuJ3Qgb3ZlcmZsb3cgdGhlIGZsb2F0aW5nIGVsZW1lbnQgaWYgdGhlIGNlbnRlclxuICAgIC8vIHBvaW50IGlzIG91dHNpZGUgdGhlIGZsb2F0aW5nIGVsZW1lbnQncyBib3VuZHMuXG4gICAgY29uc3QgbWF4ID0gY2xpZW50U2l6ZSAtIGFycm93RGltZW5zaW9uc1tsZW5ndGhdIC0gbWF4UGFkZGluZztcbiAgICBjb25zdCBjZW50ZXIgPSBjbGllbnRTaXplIC8gMiAtIGFycm93RGltZW5zaW9uc1tsZW5ndGhdIC8gMiArIGNlbnRlclRvUmVmZXJlbmNlO1xuICAgIGNvbnN0IG9mZnNldCA9IGNsYW1wKG1pblBhZGRpbmcsIGNlbnRlciwgbWF4KTtcblxuICAgIC8vIElmIHRoZSByZWZlcmVuY2UgaXMgc21hbGwgZW5vdWdoIHRoYXQgdGhlIGFycm93J3MgcGFkZGluZyBjYXVzZXMgaXQgdG9cbiAgICAvLyB0byBwb2ludCB0byBub3RoaW5nIGZvciBhbiBhbGlnbmVkIHBsYWNlbWVudCwgYWRqdXN0IHRoZSBvZmZzZXQgb2YgdGhlXG4gICAgLy8gZmxvYXRpbmcgZWxlbWVudCBpdHNlbGYuIFRvIGVuc3VyZSBgc2hpZnQoKWAgY29udGludWVzIHRvIHRha2UgYWN0aW9uLFxuICAgIC8vIGEgc2luZ2xlIHJlc2V0IGlzIHBlcmZvcm1lZCB3aGVuIHRoaXMgaXMgdHJ1ZS5cbiAgICBjb25zdCBzaG91bGRBZGRPZmZzZXQgPSAhbWlkZGxld2FyZURhdGEuYXJyb3cgJiYgZ2V0QWxpZ25tZW50KHBsYWNlbWVudCkgIT0gbnVsbCAmJiBjZW50ZXIgIT09IG9mZnNldCAmJiByZWN0cy5yZWZlcmVuY2VbbGVuZ3RoXSAvIDIgLSAoY2VudGVyIDwgbWluUGFkZGluZyA/IG1pblBhZGRpbmcgOiBtYXhQYWRkaW5nKSAtIGFycm93RGltZW5zaW9uc1tsZW5ndGhdIC8gMiA8IDA7XG4gICAgY29uc3QgYWxpZ25tZW50T2Zmc2V0ID0gc2hvdWxkQWRkT2Zmc2V0ID8gY2VudGVyIDwgbWluUGFkZGluZyA/IGNlbnRlciAtIG1pblBhZGRpbmcgOiBjZW50ZXIgLSBtYXggOiAwO1xuICAgIHJldHVybiB7XG4gICAgICBbYXhpc106IGNvb3Jkc1theGlzXSArIGFsaWdubWVudE9mZnNldCxcbiAgICAgIGRhdGE6IHtcbiAgICAgICAgW2F4aXNdOiBvZmZzZXQsXG4gICAgICAgIGNlbnRlck9mZnNldDogY2VudGVyIC0gb2Zmc2V0IC0gYWxpZ25tZW50T2Zmc2V0LFxuICAgICAgICAuLi4oc2hvdWxkQWRkT2Zmc2V0ICYmIHtcbiAgICAgICAgICBhbGlnbm1lbnRPZmZzZXRcbiAgICAgICAgfSlcbiAgICAgIH0sXG4gICAgICByZXNldDogc2hvdWxkQWRkT2Zmc2V0XG4gICAgfTtcbiAgfVxufSk7XG5cbmZ1bmN0aW9uIGdldFBsYWNlbWVudExpc3QoYWxpZ25tZW50LCBhdXRvQWxpZ25tZW50LCBhbGxvd2VkUGxhY2VtZW50cykge1xuICBjb25zdCBhbGxvd2VkUGxhY2VtZW50c1NvcnRlZEJ5QWxpZ25tZW50ID0gYWxpZ25tZW50ID8gWy4uLmFsbG93ZWRQbGFjZW1lbnRzLmZpbHRlcihwbGFjZW1lbnQgPT4gZ2V0QWxpZ25tZW50KHBsYWNlbWVudCkgPT09IGFsaWdubWVudCksIC4uLmFsbG93ZWRQbGFjZW1lbnRzLmZpbHRlcihwbGFjZW1lbnQgPT4gZ2V0QWxpZ25tZW50KHBsYWNlbWVudCkgIT09IGFsaWdubWVudCldIDogYWxsb3dlZFBsYWNlbWVudHMuZmlsdGVyKHBsYWNlbWVudCA9PiBnZXRTaWRlKHBsYWNlbWVudCkgPT09IHBsYWNlbWVudCk7XG4gIHJldHVybiBhbGxvd2VkUGxhY2VtZW50c1NvcnRlZEJ5QWxpZ25tZW50LmZpbHRlcihwbGFjZW1lbnQgPT4ge1xuICAgIGlmIChhbGlnbm1lbnQpIHtcbiAgICAgIHJldHVybiBnZXRBbGlnbm1lbnQocGxhY2VtZW50KSA9PT0gYWxpZ25tZW50IHx8IChhdXRvQWxpZ25tZW50ID8gZ2V0T3Bwb3NpdGVBbGlnbm1lbnRQbGFjZW1lbnQocGxhY2VtZW50KSAhPT0gcGxhY2VtZW50IDogZmFsc2UpO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSk7XG59XG4vKipcbiAqIE9wdGltaXplcyB0aGUgdmlzaWJpbGl0eSBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBieSBjaG9vc2luZyB0aGUgcGxhY2VtZW50XG4gKiB0aGF0IGhhcyB0aGUgbW9zdCBzcGFjZSBhdmFpbGFibGUgYXV0b21hdGljYWxseSwgd2l0aG91dCBuZWVkaW5nIHRvIHNwZWNpZnkgYVxuICogcHJlZmVycmVkIHBsYWNlbWVudC4gQWx0ZXJuYXRpdmUgdG8gYGZsaXBgLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2F1dG9QbGFjZW1lbnRcbiAqL1xuY29uc3QgYXV0b1BsYWNlbWVudCA9IGZ1bmN0aW9uIChvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBuYW1lOiAnYXV0b1BsYWNlbWVudCcsXG4gICAgb3B0aW9ucyxcbiAgICBhc3luYyBmbihzdGF0ZSkge1xuICAgICAgdmFyIF9taWRkbGV3YXJlRGF0YSRhdXRvUCwgX21pZGRsZXdhcmVEYXRhJGF1dG9QMiwgX3BsYWNlbWVudHNUaGF0Rml0T25FO1xuICAgICAgY29uc3Qge1xuICAgICAgICByZWN0cyxcbiAgICAgICAgbWlkZGxld2FyZURhdGEsXG4gICAgICAgIHBsYWNlbWVudCxcbiAgICAgICAgcGxhdGZvcm0sXG4gICAgICAgIGVsZW1lbnRzXG4gICAgICB9ID0gc3RhdGU7XG4gICAgICBjb25zdCB7XG4gICAgICAgIGNyb3NzQXhpcyA9IGZhbHNlLFxuICAgICAgICBhbGlnbm1lbnQsXG4gICAgICAgIGFsbG93ZWRQbGFjZW1lbnRzID0gcGxhY2VtZW50cyxcbiAgICAgICAgYXV0b0FsaWdubWVudCA9IHRydWUsXG4gICAgICAgIC4uLmRldGVjdE92ZXJmbG93T3B0aW9uc1xuICAgICAgfSA9IGV2YWx1YXRlKG9wdGlvbnMsIHN0YXRlKTtcbiAgICAgIGNvbnN0IHBsYWNlbWVudHMkMSA9IGFsaWdubWVudCAhPT0gdW5kZWZpbmVkIHx8IGFsbG93ZWRQbGFjZW1lbnRzID09PSBwbGFjZW1lbnRzID8gZ2V0UGxhY2VtZW50TGlzdChhbGlnbm1lbnQgfHwgbnVsbCwgYXV0b0FsaWdubWVudCwgYWxsb3dlZFBsYWNlbWVudHMpIDogYWxsb3dlZFBsYWNlbWVudHM7XG4gICAgICBjb25zdCBjdXJyZW50SW5kZXggPSAoKF9taWRkbGV3YXJlRGF0YSRhdXRvUCA9IG1pZGRsZXdhcmVEYXRhLmF1dG9QbGFjZW1lbnQpID09IG51bGwgPyB2b2lkIDAgOiBfbWlkZGxld2FyZURhdGEkYXV0b1AuaW5kZXgpIHx8IDA7XG4gICAgICBjb25zdCBjdXJyZW50UGxhY2VtZW50ID0gcGxhY2VtZW50cyQxW2N1cnJlbnRJbmRleF07XG4gICAgICBpZiAoY3VycmVudFBsYWNlbWVudCA9PSBudWxsKSB7XG4gICAgICAgIHJldHVybiB7fTtcbiAgICAgIH1cblxuICAgICAgLy8gTWFrZSBgY29tcHV0ZUNvb3Jkc2Agc3RhcnQgZnJvbSB0aGUgcmlnaHQgcGxhY2UuXG4gICAgICBpZiAocGxhY2VtZW50ICE9PSBjdXJyZW50UGxhY2VtZW50KSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgcmVzZXQ6IHtcbiAgICAgICAgICAgIHBsYWNlbWVudDogcGxhY2VtZW50cyQxWzBdXG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgY29uc3Qgb3ZlcmZsb3cgPSBhd2FpdCBwbGF0Zm9ybS5kZXRlY3RPdmVyZmxvdyhzdGF0ZSwgZGV0ZWN0T3ZlcmZsb3dPcHRpb25zKTtcbiAgICAgIGNvbnN0IGFsaWdubWVudFNpZGVzID0gZ2V0QWxpZ25tZW50U2lkZXMoY3VycmVudFBsYWNlbWVudCwgcmVjdHMsIGF3YWl0IChwbGF0Zm9ybS5pc1JUTCA9PSBudWxsID8gdm9pZCAwIDogcGxhdGZvcm0uaXNSVEwoZWxlbWVudHMuZmxvYXRpbmcpKSk7XG4gICAgICBjb25zdCBjdXJyZW50T3ZlcmZsb3dzID0gW292ZXJmbG93W2dldFNpZGUoY3VycmVudFBsYWNlbWVudCldLCBvdmVyZmxvd1thbGlnbm1lbnRTaWRlc1swXV0sIG92ZXJmbG93W2FsaWdubWVudFNpZGVzWzFdXV07XG4gICAgICBjb25zdCBhbGxPdmVyZmxvd3MgPSBbLi4uKCgoX21pZGRsZXdhcmVEYXRhJGF1dG9QMiA9IG1pZGRsZXdhcmVEYXRhLmF1dG9QbGFjZW1lbnQpID09IG51bGwgPyB2b2lkIDAgOiBfbWlkZGxld2FyZURhdGEkYXV0b1AyLm92ZXJmbG93cykgfHwgW10pLCB7XG4gICAgICAgIHBsYWNlbWVudDogY3VycmVudFBsYWNlbWVudCxcbiAgICAgICAgb3ZlcmZsb3dzOiBjdXJyZW50T3ZlcmZsb3dzXG4gICAgICB9XTtcbiAgICAgIGNvbnN0IG5leHRQbGFjZW1lbnQgPSBwbGFjZW1lbnRzJDFbY3VycmVudEluZGV4ICsgMV07XG5cbiAgICAgIC8vIFRoZXJlIGFyZSBtb3JlIHBsYWNlbWVudHMgdG8gY2hlY2suXG4gICAgICBpZiAobmV4dFBsYWNlbWVudCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgIGluZGV4OiBjdXJyZW50SW5kZXggKyAxLFxuICAgICAgICAgICAgb3ZlcmZsb3dzOiBhbGxPdmVyZmxvd3NcbiAgICAgICAgICB9LFxuICAgICAgICAgIHJlc2V0OiB7XG4gICAgICAgICAgICBwbGFjZW1lbnQ6IG5leHRQbGFjZW1lbnRcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBjb25zdCBwbGFjZW1lbnRzU29ydGVkQnlNb3N0U3BhY2UgPSBhbGxPdmVyZmxvd3MubWFwKGQgPT4ge1xuICAgICAgICBjb25zdCBhbGlnbm1lbnQgPSBnZXRBbGlnbm1lbnQoZC5wbGFjZW1lbnQpO1xuICAgICAgICByZXR1cm4gW2QucGxhY2VtZW50LCBhbGlnbm1lbnQgJiYgY3Jvc3NBeGlzID9cbiAgICAgICAgLy8gQ2hlY2sgYWxvbmcgdGhlIG1haW5BeGlzIGFuZCBtYWluIGNyb3NzQXhpcyBzaWRlLlxuICAgICAgICBkLm92ZXJmbG93cy5zbGljZSgwLCAyKS5yZWR1Y2UoKGFjYywgdikgPT4gYWNjICsgdiwgMCkgOlxuICAgICAgICAvLyBDaGVjayBvbmx5IHRoZSBtYWluQXhpcy5cbiAgICAgICAgZC5vdmVyZmxvd3NbMF0sIGQub3ZlcmZsb3dzXTtcbiAgICAgIH0pLnNvcnQoKGEsIGIpID0+IGFbMV0gLSBiWzFdKTtcbiAgICAgIGNvbnN0IHBsYWNlbWVudHNUaGF0Rml0T25FYWNoU2lkZSA9IHBsYWNlbWVudHNTb3J0ZWRCeU1vc3RTcGFjZS5maWx0ZXIoZCA9PiBkWzJdLnNsaWNlKDAsXG4gICAgICAvLyBBbGlnbmVkIHBsYWNlbWVudHMgc2hvdWxkIG5vdCBjaGVjayB0aGVpciBvcHBvc2l0ZSBjcm9zc0F4aXNcbiAgICAgIC8vIHNpZGUuXG4gICAgICBnZXRBbGlnbm1lbnQoZFswXSkgPyAyIDogMykuZXZlcnkodiA9PiB2IDw9IDApKTtcbiAgICAgIGNvbnN0IHJlc2V0UGxhY2VtZW50ID0gKChfcGxhY2VtZW50c1RoYXRGaXRPbkUgPSBwbGFjZW1lbnRzVGhhdEZpdE9uRWFjaFNpZGVbMF0pID09IG51bGwgPyB2b2lkIDAgOiBfcGxhY2VtZW50c1RoYXRGaXRPbkVbMF0pIHx8IHBsYWNlbWVudHNTb3J0ZWRCeU1vc3RTcGFjZVswXVswXTtcbiAgICAgIGlmIChyZXNldFBsYWNlbWVudCAhPT0gcGxhY2VtZW50KSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgaW5kZXg6IGN1cnJlbnRJbmRleCArIDEsXG4gICAgICAgICAgICBvdmVyZmxvd3M6IGFsbE92ZXJmbG93c1xuICAgICAgICAgIH0sXG4gICAgICAgICAgcmVzZXQ6IHtcbiAgICAgICAgICAgIHBsYWNlbWVudDogcmVzZXRQbGFjZW1lbnRcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICByZXR1cm4ge307XG4gICAgfVxuICB9O1xufTtcblxuLyoqXG4gKiBPcHRpbWl6ZXMgdGhlIHZpc2liaWxpdHkgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQgYnkgZmxpcHBpbmcgdGhlIGBwbGFjZW1lbnRgXG4gKiBpbiBvcmRlciB0byBrZWVwIGl0IGluIHZpZXcgd2hlbiB0aGUgcHJlZmVycmVkIHBsYWNlbWVudChzKSB3aWxsIG92ZXJmbG93IHRoZVxuICogY2xpcHBpbmcgYm91bmRhcnkuIEFsdGVybmF0aXZlIHRvIGBhdXRvUGxhY2VtZW50YC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9mbGlwXG4gKi9cbmNvbnN0IGZsaXAgPSBmdW5jdGlvbiAob3B0aW9ucykge1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG4gIHJldHVybiB7XG4gICAgbmFtZTogJ2ZsaXAnLFxuICAgIG9wdGlvbnMsXG4gICAgYXN5bmMgZm4oc3RhdGUpIHtcbiAgICAgIHZhciBfbWlkZGxld2FyZURhdGEkYXJyb3csIF9taWRkbGV3YXJlRGF0YSRmbGlwO1xuICAgICAgY29uc3Qge1xuICAgICAgICBwbGFjZW1lbnQsXG4gICAgICAgIG1pZGRsZXdhcmVEYXRhLFxuICAgICAgICByZWN0cyxcbiAgICAgICAgaW5pdGlhbFBsYWNlbWVudCxcbiAgICAgICAgcGxhdGZvcm0sXG4gICAgICAgIGVsZW1lbnRzXG4gICAgICB9ID0gc3RhdGU7XG4gICAgICBjb25zdCB7XG4gICAgICAgIG1haW5BeGlzOiBjaGVja01haW5BeGlzID0gdHJ1ZSxcbiAgICAgICAgY3Jvc3NBeGlzOiBjaGVja0Nyb3NzQXhpcyA9IHRydWUsXG4gICAgICAgIGZhbGxiYWNrUGxhY2VtZW50czogc3BlY2lmaWVkRmFsbGJhY2tQbGFjZW1lbnRzLFxuICAgICAgICBmYWxsYmFja1N0cmF0ZWd5ID0gJ2Jlc3RGaXQnLFxuICAgICAgICBmYWxsYmFja0F4aXNTaWRlRGlyZWN0aW9uID0gJ25vbmUnLFxuICAgICAgICBmbGlwQWxpZ25tZW50ID0gdHJ1ZSxcbiAgICAgICAgLi4uZGV0ZWN0T3ZlcmZsb3dPcHRpb25zXG4gICAgICB9ID0gZXZhbHVhdGUob3B0aW9ucywgc3RhdGUpO1xuXG4gICAgICAvLyBJZiBhIHJlc2V0IGJ5IHRoZSBhcnJvdyB3YXMgY2F1c2VkIGR1ZSB0byBhbiBhbGlnbm1lbnQgb2Zmc2V0IGJlaW5nXG4gICAgICAvLyBhZGRlZCwgd2Ugc2hvdWxkIHNraXAgYW55IGxvZ2ljIG5vdyBzaW5jZSBgZmxpcCgpYCBoYXMgYWxyZWFkeSBkb25lIGl0c1xuICAgICAgLy8gd29yay5cbiAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9mbG9hdGluZy11aS9mbG9hdGluZy11aS9pc3N1ZXMvMjU0OSNpc3N1ZWNvbW1lbnQtMTcxOTYwMTY0M1xuICAgICAgaWYgKChfbWlkZGxld2FyZURhdGEkYXJyb3cgPSBtaWRkbGV3YXJlRGF0YS5hcnJvdykgIT0gbnVsbCAmJiBfbWlkZGxld2FyZURhdGEkYXJyb3cuYWxpZ25tZW50T2Zmc2V0KSB7XG4gICAgICAgIHJldHVybiB7fTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHNpZGUgPSBnZXRTaWRlKHBsYWNlbWVudCk7XG4gICAgICBjb25zdCBpbml0aWFsU2lkZUF4aXMgPSBnZXRTaWRlQXhpcyhpbml0aWFsUGxhY2VtZW50KTtcbiAgICAgIGNvbnN0IGlzQmFzZVBsYWNlbWVudCA9IGdldFNpZGUoaW5pdGlhbFBsYWNlbWVudCkgPT09IGluaXRpYWxQbGFjZW1lbnQ7XG4gICAgICBjb25zdCBydGwgPSBhd2FpdCAocGxhdGZvcm0uaXNSVEwgPT0gbnVsbCA/IHZvaWQgMCA6IHBsYXRmb3JtLmlzUlRMKGVsZW1lbnRzLmZsb2F0aW5nKSk7XG4gICAgICBjb25zdCBmYWxsYmFja1BsYWNlbWVudHMgPSBzcGVjaWZpZWRGYWxsYmFja1BsYWNlbWVudHMgfHwgKGlzQmFzZVBsYWNlbWVudCB8fCAhZmxpcEFsaWdubWVudCA/IFtnZXRPcHBvc2l0ZVBsYWNlbWVudChpbml0aWFsUGxhY2VtZW50KV0gOiBnZXRFeHBhbmRlZFBsYWNlbWVudHMoaW5pdGlhbFBsYWNlbWVudCkpO1xuICAgICAgY29uc3QgaGFzRmFsbGJhY2tBeGlzU2lkZURpcmVjdGlvbiA9IGZhbGxiYWNrQXhpc1NpZGVEaXJlY3Rpb24gIT09ICdub25lJztcbiAgICAgIGlmICghc3BlY2lmaWVkRmFsbGJhY2tQbGFjZW1lbnRzICYmIGhhc0ZhbGxiYWNrQXhpc1NpZGVEaXJlY3Rpb24pIHtcbiAgICAgICAgZmFsbGJhY2tQbGFjZW1lbnRzLnB1c2goLi4uZ2V0T3Bwb3NpdGVBeGlzUGxhY2VtZW50cyhpbml0aWFsUGxhY2VtZW50LCBmbGlwQWxpZ25tZW50LCBmYWxsYmFja0F4aXNTaWRlRGlyZWN0aW9uLCBydGwpKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHBsYWNlbWVudHMgPSBbaW5pdGlhbFBsYWNlbWVudCwgLi4uZmFsbGJhY2tQbGFjZW1lbnRzXTtcbiAgICAgIGNvbnN0IG92ZXJmbG93ID0gYXdhaXQgcGxhdGZvcm0uZGV0ZWN0T3ZlcmZsb3coc3RhdGUsIGRldGVjdE92ZXJmbG93T3B0aW9ucyk7XG4gICAgICBjb25zdCBvdmVyZmxvd3MgPSBbXTtcbiAgICAgIGxldCBvdmVyZmxvd3NEYXRhID0gKChfbWlkZGxld2FyZURhdGEkZmxpcCA9IG1pZGRsZXdhcmVEYXRhLmZsaXApID09IG51bGwgPyB2b2lkIDAgOiBfbWlkZGxld2FyZURhdGEkZmxpcC5vdmVyZmxvd3MpIHx8IFtdO1xuICAgICAgaWYgKGNoZWNrTWFpbkF4aXMpIHtcbiAgICAgICAgb3ZlcmZsb3dzLnB1c2gob3ZlcmZsb3dbc2lkZV0pO1xuICAgICAgfVxuICAgICAgaWYgKGNoZWNrQ3Jvc3NBeGlzKSB7XG4gICAgICAgIGNvbnN0IHNpZGVzID0gZ2V0QWxpZ25tZW50U2lkZXMocGxhY2VtZW50LCByZWN0cywgcnRsKTtcbiAgICAgICAgb3ZlcmZsb3dzLnB1c2gob3ZlcmZsb3dbc2lkZXNbMF1dLCBvdmVyZmxvd1tzaWRlc1sxXV0pO1xuICAgICAgfVxuICAgICAgb3ZlcmZsb3dzRGF0YSA9IFsuLi5vdmVyZmxvd3NEYXRhLCB7XG4gICAgICAgIHBsYWNlbWVudCxcbiAgICAgICAgb3ZlcmZsb3dzXG4gICAgICB9XTtcblxuICAgICAgLy8gT25lIG9yIG1vcmUgc2lkZXMgaXMgb3ZlcmZsb3dpbmcuXG4gICAgICBpZiAoIW92ZXJmbG93cy5ldmVyeShzaWRlID0+IHNpZGUgPD0gMCkpIHtcbiAgICAgICAgdmFyIF9taWRkbGV3YXJlRGF0YSRmbGlwMiwgX292ZXJmbG93c0RhdGEkZmlsdGVyO1xuICAgICAgICBjb25zdCBuZXh0SW5kZXggPSAoKChfbWlkZGxld2FyZURhdGEkZmxpcDIgPSBtaWRkbGV3YXJlRGF0YS5mbGlwKSA9PSBudWxsID8gdm9pZCAwIDogX21pZGRsZXdhcmVEYXRhJGZsaXAyLmluZGV4KSB8fCAwKSArIDE7XG4gICAgICAgIGNvbnN0IG5leHRQbGFjZW1lbnQgPSBwbGFjZW1lbnRzW25leHRJbmRleF07XG4gICAgICAgIGlmIChuZXh0UGxhY2VtZW50KSB7XG4gICAgICAgICAgY29uc3QgaWdub3JlQ3Jvc3NBeGlzT3ZlcmZsb3cgPSBjaGVja0Nyb3NzQXhpcyA9PT0gJ2FsaWdubWVudCcgPyBpbml0aWFsU2lkZUF4aXMgIT09IGdldFNpZGVBeGlzKG5leHRQbGFjZW1lbnQpIDogZmFsc2U7XG4gICAgICAgICAgaWYgKCFpZ25vcmVDcm9zc0F4aXNPdmVyZmxvdyB8fFxuICAgICAgICAgIC8vIFdlIGxlYXZlIHRoZSBjdXJyZW50IG1haW4gYXhpcyBvbmx5IGlmIGV2ZXJ5IHBsYWNlbWVudCBvbiB0aGF0IGF4aXNcbiAgICAgICAgICAvLyBvdmVyZmxvd3MgdGhlIG1haW4gYXhpcy5cbiAgICAgICAgICBvdmVyZmxvd3NEYXRhLmV2ZXJ5KGQgPT4gZ2V0U2lkZUF4aXMoZC5wbGFjZW1lbnQpID09PSBpbml0aWFsU2lkZUF4aXMgPyBkLm92ZXJmbG93c1swXSA+IDAgOiB0cnVlKSkge1xuICAgICAgICAgICAgLy8gVHJ5IG5leHQgcGxhY2VtZW50IGFuZCByZS1ydW4gdGhlIGxpZmVjeWNsZS5cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICBpbmRleDogbmV4dEluZGV4LFxuICAgICAgICAgICAgICAgIG92ZXJmbG93czogb3ZlcmZsb3dzRGF0YVxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICByZXNldDoge1xuICAgICAgICAgICAgICAgIHBsYWNlbWVudDogbmV4dFBsYWNlbWVudFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEZpcnN0LCBmaW5kIHRoZSBjYW5kaWRhdGVzIHRoYXQgZml0IG9uIHRoZSBtYWluQXhpcyBzaWRlIG9mIG92ZXJmbG93LFxuICAgICAgICAvLyB0aGVuIGZpbmQgdGhlIHBsYWNlbWVudCB0aGF0IGZpdHMgdGhlIGJlc3Qgb24gdGhlIG1haW4gY3Jvc3NBeGlzIHNpZGUuXG4gICAgICAgIGxldCByZXNldFBsYWNlbWVudCA9IChfb3ZlcmZsb3dzRGF0YSRmaWx0ZXIgPSBvdmVyZmxvd3NEYXRhLmZpbHRlcihkID0+IGQub3ZlcmZsb3dzWzBdIDw9IDApLnNvcnQoKGEsIGIpID0+IGEub3ZlcmZsb3dzWzFdIC0gYi5vdmVyZmxvd3NbMV0pWzBdKSA9PSBudWxsID8gdm9pZCAwIDogX292ZXJmbG93c0RhdGEkZmlsdGVyLnBsYWNlbWVudDtcblxuICAgICAgICAvLyBPdGhlcndpc2UgZmFsbGJhY2suXG4gICAgICAgIGlmICghcmVzZXRQbGFjZW1lbnQpIHtcbiAgICAgICAgICBzd2l0Y2ggKGZhbGxiYWNrU3RyYXRlZ3kpIHtcbiAgICAgICAgICAgIGNhc2UgJ2Jlc3RGaXQnOlxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdmFyIF9vdmVyZmxvd3NEYXRhJGZpbHRlcjI7XG4gICAgICAgICAgICAgICAgY29uc3QgcGxhY2VtZW50ID0gKF9vdmVyZmxvd3NEYXRhJGZpbHRlcjIgPSBvdmVyZmxvd3NEYXRhLmZpbHRlcihkID0+IHtcbiAgICAgICAgICAgICAgICAgIGlmIChoYXNGYWxsYmFja0F4aXNTaWRlRGlyZWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRTaWRlQXhpcyA9IGdldFNpZGVBeGlzKGQucGxhY2VtZW50KTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGN1cnJlbnRTaWRlQXhpcyA9PT0gaW5pdGlhbFNpZGVBeGlzIHx8XG4gICAgICAgICAgICAgICAgICAgIC8vIENyZWF0ZSBhIGJpYXMgdG8gdGhlIGB5YCBzaWRlIGF4aXMgZHVlIHRvIGhvcml6b250YWxcbiAgICAgICAgICAgICAgICAgICAgLy8gcmVhZGluZyBkaXJlY3Rpb25zIGZhdm9yaW5nIGdyZWF0ZXIgd2lkdGguXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnRTaWRlQXhpcyA9PT0gJ3knO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICAgICAgfSkubWFwKGQgPT4gW2QucGxhY2VtZW50LCBkLm92ZXJmbG93cy5maWx0ZXIob3ZlcmZsb3cgPT4gb3ZlcmZsb3cgPiAwKS5yZWR1Y2UoKGFjYywgb3ZlcmZsb3cpID0+IGFjYyArIG92ZXJmbG93LCAwKV0pLnNvcnQoKGEsIGIpID0+IGFbMV0gLSBiWzFdKVswXSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9vdmVyZmxvd3NEYXRhJGZpbHRlcjJbMF07XG4gICAgICAgICAgICAgICAgaWYgKHBsYWNlbWVudCkge1xuICAgICAgICAgICAgICAgICAgcmVzZXRQbGFjZW1lbnQgPSBwbGFjZW1lbnQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlICdpbml0aWFsUGxhY2VtZW50JzpcbiAgICAgICAgICAgICAgcmVzZXRQbGFjZW1lbnQgPSBpbml0aWFsUGxhY2VtZW50O1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHBsYWNlbWVudCAhPT0gcmVzZXRQbGFjZW1lbnQpIHtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVzZXQ6IHtcbiAgICAgICAgICAgICAgcGxhY2VtZW50OiByZXNldFBsYWNlbWVudFxuICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiB7fTtcbiAgICB9XG4gIH07XG59O1xuXG5mdW5jdGlvbiBnZXRTaWRlT2Zmc2V0cyhvdmVyZmxvdywgcmVjdCkge1xuICByZXR1cm4ge1xuICAgIHRvcDogb3ZlcmZsb3cudG9wIC0gcmVjdC5oZWlnaHQsXG4gICAgcmlnaHQ6IG92ZXJmbG93LnJpZ2h0IC0gcmVjdC53aWR0aCxcbiAgICBib3R0b206IG92ZXJmbG93LmJvdHRvbSAtIHJlY3QuaGVpZ2h0LFxuICAgIGxlZnQ6IG92ZXJmbG93LmxlZnQgLSByZWN0LndpZHRoXG4gIH07XG59XG5mdW5jdGlvbiBpc0FueVNpZGVGdWxseUNsaXBwZWQob3ZlcmZsb3cpIHtcbiAgcmV0dXJuIHNpZGVzLnNvbWUoc2lkZSA9PiBvdmVyZmxvd1tzaWRlXSA+PSAwKTtcbn1cbi8qKlxuICogUHJvdmlkZXMgZGF0YSB0byBoaWRlIHRoZSBmbG9hdGluZyBlbGVtZW50IGluIGFwcGxpY2FibGUgc2l0dWF0aW9ucywgc3VjaCBhc1xuICogd2hlbiBpdCBpcyBub3QgaW4gdGhlIHNhbWUgY2xpcHBpbmcgY29udGV4dCBhcyB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvaGlkZVxuICovXG5jb25zdCBoaWRlID0gZnVuY3Rpb24gKG9wdGlvbnMpIHtcbiAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkge1xuICAgIG9wdGlvbnMgPSB7fTtcbiAgfVxuICByZXR1cm4ge1xuICAgIG5hbWU6ICdoaWRlJyxcbiAgICBvcHRpb25zLFxuICAgIGFzeW5jIGZuKHN0YXRlKSB7XG4gICAgICBjb25zdCB7XG4gICAgICAgIHJlY3RzLFxuICAgICAgICBwbGF0Zm9ybVxuICAgICAgfSA9IHN0YXRlO1xuICAgICAgY29uc3Qge1xuICAgICAgICBzdHJhdGVneSA9ICdyZWZlcmVuY2VIaWRkZW4nLFxuICAgICAgICAuLi5kZXRlY3RPdmVyZmxvd09wdGlvbnNcbiAgICAgIH0gPSBldmFsdWF0ZShvcHRpb25zLCBzdGF0ZSk7XG4gICAgICBzd2l0Y2ggKHN0cmF0ZWd5KSB7XG4gICAgICAgIGNhc2UgJ3JlZmVyZW5jZUhpZGRlbic6XG4gICAgICAgICAge1xuICAgICAgICAgICAgY29uc3Qgb3ZlcmZsb3cgPSBhd2FpdCBwbGF0Zm9ybS5kZXRlY3RPdmVyZmxvdyhzdGF0ZSwge1xuICAgICAgICAgICAgICAuLi5kZXRlY3RPdmVyZmxvd09wdGlvbnMsXG4gICAgICAgICAgICAgIGVsZW1lbnRDb250ZXh0OiAncmVmZXJlbmNlJ1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBjb25zdCBvZmZzZXRzID0gZ2V0U2lkZU9mZnNldHMob3ZlcmZsb3csIHJlY3RzLnJlZmVyZW5jZSk7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgcmVmZXJlbmNlSGlkZGVuT2Zmc2V0czogb2Zmc2V0cyxcbiAgICAgICAgICAgICAgICByZWZlcmVuY2VIaWRkZW46IGlzQW55U2lkZUZ1bGx5Q2xpcHBlZChvZmZzZXRzKVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgY2FzZSAnZXNjYXBlZCc6XG4gICAgICAgICAge1xuICAgICAgICAgICAgY29uc3Qgb3ZlcmZsb3cgPSBhd2FpdCBwbGF0Zm9ybS5kZXRlY3RPdmVyZmxvdyhzdGF0ZSwge1xuICAgICAgICAgICAgICAuLi5kZXRlY3RPdmVyZmxvd09wdGlvbnMsXG4gICAgICAgICAgICAgIGFsdEJvdW5kYXJ5OiB0cnVlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNvbnN0IG9mZnNldHMgPSBnZXRTaWRlT2Zmc2V0cyhvdmVyZmxvdywgcmVjdHMuZmxvYXRpbmcpO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgIGVzY2FwZWRPZmZzZXRzOiBvZmZzZXRzLFxuICAgICAgICAgICAgICAgIGVzY2FwZWQ6IGlzQW55U2lkZUZ1bGx5Q2xpcHBlZChvZmZzZXRzKVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICB7XG4gICAgICAgICAgICByZXR1cm4ge307XG4gICAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfTtcbn07XG5cbmZ1bmN0aW9uIGdldEJvdW5kaW5nUmVjdChyZWN0cykge1xuICBjb25zdCBtaW5YID0gbWluKC4uLnJlY3RzLm1hcChyZWN0ID0+IHJlY3QubGVmdCkpO1xuICBjb25zdCBtaW5ZID0gbWluKC4uLnJlY3RzLm1hcChyZWN0ID0+IHJlY3QudG9wKSk7XG4gIGNvbnN0IG1heFggPSBtYXgoLi4ucmVjdHMubWFwKHJlY3QgPT4gcmVjdC5yaWdodCkpO1xuICBjb25zdCBtYXhZID0gbWF4KC4uLnJlY3RzLm1hcChyZWN0ID0+IHJlY3QuYm90dG9tKSk7XG4gIHJldHVybiB7XG4gICAgeDogbWluWCxcbiAgICB5OiBtaW5ZLFxuICAgIHdpZHRoOiBtYXhYIC0gbWluWCxcbiAgICBoZWlnaHQ6IG1heFkgLSBtaW5ZXG4gIH07XG59XG5mdW5jdGlvbiBnZXRSZWN0c0J5TGluZShyZWN0cykge1xuICBjb25zdCBzb3J0ZWRSZWN0cyA9IHJlY3RzLnNsaWNlKCkuc29ydCgoYSwgYikgPT4gYS55IC0gYi55KTtcbiAgY29uc3QgZ3JvdXBzID0gW107XG4gIGxldCBwcmV2UmVjdCA9IG51bGw7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgc29ydGVkUmVjdHMubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCByZWN0ID0gc29ydGVkUmVjdHNbaV07XG4gICAgaWYgKCFwcmV2UmVjdCB8fCByZWN0LnkgLSBwcmV2UmVjdC55ID4gcHJldlJlY3QuaGVpZ2h0IC8gMikge1xuICAgICAgZ3JvdXBzLnB1c2goW3JlY3RdKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZ3JvdXBzW2dyb3Vwcy5sZW5ndGggLSAxXS5wdXNoKHJlY3QpO1xuICAgIH1cbiAgICBwcmV2UmVjdCA9IHJlY3Q7XG4gIH1cbiAgcmV0dXJuIGdyb3Vwcy5tYXAocmVjdCA9PiByZWN0VG9DbGllbnRSZWN0KGdldEJvdW5kaW5nUmVjdChyZWN0KSkpO1xufVxuLyoqXG4gKiBQcm92aWRlcyBpbXByb3ZlZCBwb3NpdGlvbmluZyBmb3IgaW5saW5lIHJlZmVyZW5jZSBlbGVtZW50cyB0aGF0IGNhbiBzcGFuXG4gKiBvdmVyIG11bHRpcGxlIGxpbmVzLCBzdWNoIGFzIGh5cGVybGlua3Mgb3IgcmFuZ2Ugc2VsZWN0aW9ucy5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9pbmxpbmVcbiAqL1xuY29uc3QgaW5saW5lID0gZnVuY3Rpb24gKG9wdGlvbnMpIHtcbiAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkge1xuICAgIG9wdGlvbnMgPSB7fTtcbiAgfVxuICByZXR1cm4ge1xuICAgIG5hbWU6ICdpbmxpbmUnLFxuICAgIG9wdGlvbnMsXG4gICAgYXN5bmMgZm4oc3RhdGUpIHtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgcGxhY2VtZW50LFxuICAgICAgICBlbGVtZW50cyxcbiAgICAgICAgcmVjdHMsXG4gICAgICAgIHBsYXRmb3JtLFxuICAgICAgICBzdHJhdGVneVxuICAgICAgfSA9IHN0YXRlO1xuICAgICAgLy8gQSBNb3VzZUV2ZW50J3MgY2xpZW50e1gsWX0gY29vcmRzIGNhbiBiZSB1cCB0byAyIHBpeGVscyBvZmYgYVxuICAgICAgLy8gQ2xpZW50UmVjdCdzIGJvdW5kcywgZGVzcGl0ZSB0aGUgZXZlbnQgbGlzdGVuZXIgYmVpbmcgdHJpZ2dlcmVkLiBBXG4gICAgICAvLyBwYWRkaW5nIG9mIDIgc2VlbXMgdG8gaGFuZGxlIHRoaXMgaXNzdWUuXG4gICAgICBjb25zdCB7XG4gICAgICAgIHBhZGRpbmcgPSAyLFxuICAgICAgICB4LFxuICAgICAgICB5XG4gICAgICB9ID0gZXZhbHVhdGUob3B0aW9ucywgc3RhdGUpO1xuICAgICAgY29uc3QgbmF0aXZlQ2xpZW50UmVjdHMgPSBBcnJheS5mcm9tKChhd2FpdCAocGxhdGZvcm0uZ2V0Q2xpZW50UmVjdHMgPT0gbnVsbCA/IHZvaWQgMCA6IHBsYXRmb3JtLmdldENsaWVudFJlY3RzKGVsZW1lbnRzLnJlZmVyZW5jZSkpKSB8fCBbXSk7XG5cbiAgICAgIC8vIE5vIHJlY3RzIChlLmcuIGEgaGlkZGVuIG9yIGRldGFjaGVkIHJlZmVyZW5jZSwgb3IgYSBjb2xsYXBzZWQgcmFuZ2UpIFx1MjAxNFxuICAgICAgLy8ga2VlcCB0aGUgZXhpc3RpbmcgcmVmZXJlbmNlIHJlY3QgcmF0aGVyIHRoYW4gcmVzZXR0aW5nIHRvIGFuIGludmFsaWRcbiAgICAgIC8vIG9uZSB3aXRoIG5vbi1maW5pdGUgdmFsdWVzLlxuICAgICAgaWYgKCFuYXRpdmVDbGllbnRSZWN0cy5sZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuIHt9O1xuICAgICAgfVxuICAgICAgY29uc3QgY2xpZW50UmVjdHMgPSBnZXRSZWN0c0J5TGluZShuYXRpdmVDbGllbnRSZWN0cyk7XG4gICAgICBjb25zdCBmYWxsYmFjayA9IHJlY3RUb0NsaWVudFJlY3QoZ2V0Qm91bmRpbmdSZWN0KG5hdGl2ZUNsaWVudFJlY3RzKSk7XG4gICAgICBjb25zdCBwYWRkaW5nT2JqZWN0ID0gZ2V0UGFkZGluZ09iamVjdChwYWRkaW5nKTtcbiAgICAgIGZ1bmN0aW9uIGdldEJvdW5kaW5nQ2xpZW50UmVjdCgpIHtcbiAgICAgICAgLy8gVGhlcmUgYXJlIHR3byByZWN0cyBhbmQgdGhleSBhcmUgZGlzam9pbmVkLlxuICAgICAgICBpZiAoY2xpZW50UmVjdHMubGVuZ3RoID09PSAyICYmIChjbGllbnRSZWN0c1swXS5sZWZ0ID4gY2xpZW50UmVjdHNbMV0ucmlnaHQgfHwgY2xpZW50UmVjdHNbMV0ubGVmdCA+IGNsaWVudFJlY3RzWzBdLnJpZ2h0KSAmJiB4ICE9IG51bGwgJiYgeSAhPSBudWxsKSB7XG4gICAgICAgICAgLy8gRmluZCB0aGUgZmlyc3QgcmVjdCBpbiB3aGljaCB0aGUgcG9pbnQgaXMgZnVsbHkgaW5zaWRlLlxuICAgICAgICAgIHJldHVybiBjbGllbnRSZWN0cy5maW5kKHJlY3QgPT4geCA+IHJlY3QubGVmdCAtIHBhZGRpbmdPYmplY3QubGVmdCAmJiB4IDwgcmVjdC5yaWdodCArIHBhZGRpbmdPYmplY3QucmlnaHQgJiYgeSA+IHJlY3QudG9wIC0gcGFkZGluZ09iamVjdC50b3AgJiYgeSA8IHJlY3QuYm90dG9tICsgcGFkZGluZ09iamVjdC5ib3R0b20pIHx8IGZhbGxiYWNrO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gVGhlcmUgYXJlIDIgb3IgbW9yZSBjb25uZWN0ZWQgcmVjdHMuXG4gICAgICAgIGlmIChjbGllbnRSZWN0cy5sZW5ndGggPj0gMikge1xuICAgICAgICAgIGlmIChnZXRTaWRlQXhpcyhwbGFjZW1lbnQpID09PSAneScpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpcnN0UmVjdCA9IGNsaWVudFJlY3RzWzBdO1xuICAgICAgICAgICAgY29uc3QgbGFzdFJlY3QgPSBjbGllbnRSZWN0c1tjbGllbnRSZWN0cy5sZW5ndGggLSAxXTtcbiAgICAgICAgICAgIGNvbnN0IGlzVG9wID0gZ2V0U2lkZShwbGFjZW1lbnQpID09PSAndG9wJztcbiAgICAgICAgICAgIGNvbnN0IHRvcCA9IGZpcnN0UmVjdC50b3A7XG4gICAgICAgICAgICBjb25zdCBib3R0b20gPSBsYXN0UmVjdC5ib3R0b207XG4gICAgICAgICAgICBjb25zdCBsZWZ0ID0gaXNUb3AgPyBmaXJzdFJlY3QubGVmdCA6IGxhc3RSZWN0LmxlZnQ7XG4gICAgICAgICAgICBjb25zdCByaWdodCA9IGlzVG9wID8gZmlyc3RSZWN0LnJpZ2h0IDogbGFzdFJlY3QucmlnaHQ7XG4gICAgICAgICAgICByZXR1cm4gcmVjdFRvQ2xpZW50UmVjdCh7XG4gICAgICAgICAgICAgIHg6IGxlZnQsXG4gICAgICAgICAgICAgIHk6IHRvcCxcbiAgICAgICAgICAgICAgd2lkdGg6IHJpZ2h0IC0gbGVmdCxcbiAgICAgICAgICAgICAgaGVpZ2h0OiBib3R0b20gLSB0b3BcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBpc0xlZnRTaWRlID0gZ2V0U2lkZShwbGFjZW1lbnQpID09PSAnbGVmdCc7XG4gICAgICAgICAgY29uc3QgbWF4UmlnaHQgPSBtYXgoLi4uY2xpZW50UmVjdHMubWFwKHJlY3QgPT4gcmVjdC5yaWdodCkpO1xuICAgICAgICAgIGNvbnN0IG1pbkxlZnQgPSBtaW4oLi4uY2xpZW50UmVjdHMubWFwKHJlY3QgPT4gcmVjdC5sZWZ0KSk7XG4gICAgICAgICAgY29uc3QgbWVhc3VyZVJlY3RzID0gY2xpZW50UmVjdHMuZmlsdGVyKHJlY3QgPT4gaXNMZWZ0U2lkZSA/IHJlY3QubGVmdCA9PT0gbWluTGVmdCA6IHJlY3QucmlnaHQgPT09IG1heFJpZ2h0KTtcbiAgICAgICAgICBjb25zdCB0b3AgPSBtZWFzdXJlUmVjdHNbMF0udG9wO1xuICAgICAgICAgIGNvbnN0IGJvdHRvbSA9IG1lYXN1cmVSZWN0c1ttZWFzdXJlUmVjdHMubGVuZ3RoIC0gMV0uYm90dG9tO1xuICAgICAgICAgIHJldHVybiByZWN0VG9DbGllbnRSZWN0KHtcbiAgICAgICAgICAgIHg6IG1pbkxlZnQsXG4gICAgICAgICAgICB5OiB0b3AsXG4gICAgICAgICAgICB3aWR0aDogbWF4UmlnaHQgLSBtaW5MZWZ0LFxuICAgICAgICAgICAgaGVpZ2h0OiBib3R0b20gLSB0b3BcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsbGJhY2s7XG4gICAgICB9XG4gICAgICBjb25zdCByZXNldFJlY3RzID0gYXdhaXQgcGxhdGZvcm0uZ2V0RWxlbWVudFJlY3RzKHtcbiAgICAgICAgcmVmZXJlbmNlOiB7XG4gICAgICAgICAgZ2V0Qm91bmRpbmdDbGllbnRSZWN0XG4gICAgICAgIH0sXG4gICAgICAgIGZsb2F0aW5nOiBlbGVtZW50cy5mbG9hdGluZyxcbiAgICAgICAgc3RyYXRlZ3lcbiAgICAgIH0pO1xuICAgICAgaWYgKHJlY3RzLnJlZmVyZW5jZS54ICE9PSByZXNldFJlY3RzLnJlZmVyZW5jZS54IHx8IHJlY3RzLnJlZmVyZW5jZS55ICE9PSByZXNldFJlY3RzLnJlZmVyZW5jZS55IHx8IHJlY3RzLnJlZmVyZW5jZS53aWR0aCAhPT0gcmVzZXRSZWN0cy5yZWZlcmVuY2Uud2lkdGggfHwgcmVjdHMucmVmZXJlbmNlLmhlaWdodCAhPT0gcmVzZXRSZWN0cy5yZWZlcmVuY2UuaGVpZ2h0KSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgcmVzZXQ6IHtcbiAgICAgICAgICAgIHJlY3RzOiByZXNldFJlY3RzXG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHt9O1xuICAgIH1cbiAgfTtcbn07XG5cbmNvbnN0IG9yaWdpblNpZGVzID0gLyojX19QVVJFX18qL25ldyBTZXQoWydsZWZ0JywgJ3RvcCddKTtcblxuLy8gRm9yIHR5cGUgYmFja3dhcmRzLWNvbXBhdGliaWxpdHksIHRoZSBgT2Zmc2V0T3B0aW9uc2AgdHlwZSB3YXMgYWxzb1xuLy8gRGVyaXZhYmxlLlxuXG5hc3luYyBmdW5jdGlvbiBjb252ZXJ0VmFsdWVUb0Nvb3JkcyhzdGF0ZSwgb3B0aW9ucykge1xuICBjb25zdCB7XG4gICAgcGxhY2VtZW50LFxuICAgIHBsYXRmb3JtLFxuICAgIGVsZW1lbnRzXG4gIH0gPSBzdGF0ZTtcbiAgY29uc3QgcnRsID0gYXdhaXQgKHBsYXRmb3JtLmlzUlRMID09IG51bGwgPyB2b2lkIDAgOiBwbGF0Zm9ybS5pc1JUTChlbGVtZW50cy5mbG9hdGluZykpO1xuICBjb25zdCBzaWRlID0gZ2V0U2lkZShwbGFjZW1lbnQpO1xuICBjb25zdCBhbGlnbm1lbnQgPSBnZXRBbGlnbm1lbnQocGxhY2VtZW50KTtcbiAgY29uc3QgaXNWZXJ0aWNhbCA9IGdldFNpZGVBeGlzKHBsYWNlbWVudCkgPT09ICd5JztcbiAgY29uc3QgbWFpbkF4aXNNdWx0aSA9IG9yaWdpblNpZGVzLmhhcyhzaWRlKSA/IC0xIDogMTtcbiAgY29uc3QgY3Jvc3NBeGlzTXVsdGkgPSBydGwgJiYgaXNWZXJ0aWNhbCA/IC0xIDogMTtcbiAgY29uc3QgcmF3VmFsdWUgPSBldmFsdWF0ZShvcHRpb25zLCBzdGF0ZSk7XG5cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHByZWZlci1jb25zdFxuICBsZXQge1xuICAgIG1haW5BeGlzLFxuICAgIGNyb3NzQXhpcyxcbiAgICBhbGlnbm1lbnRBeGlzXG4gIH0gPSB0eXBlb2YgcmF3VmFsdWUgPT09ICdudW1iZXInID8ge1xuICAgIG1haW5BeGlzOiByYXdWYWx1ZSxcbiAgICBjcm9zc0F4aXM6IDAsXG4gICAgYWxpZ25tZW50QXhpczogbnVsbFxuICB9IDoge1xuICAgIG1haW5BeGlzOiByYXdWYWx1ZS5tYWluQXhpcyB8fCAwLFxuICAgIGNyb3NzQXhpczogcmF3VmFsdWUuY3Jvc3NBeGlzIHx8IDAsXG4gICAgYWxpZ25tZW50QXhpczogcmF3VmFsdWUuYWxpZ25tZW50QXhpc1xuICB9O1xuICBpZiAoYWxpZ25tZW50ICYmIHR5cGVvZiBhbGlnbm1lbnRBeGlzID09PSAnbnVtYmVyJykge1xuICAgIGNyb3NzQXhpcyA9IGFsaWdubWVudCA9PT0gJ2VuZCcgPyBhbGlnbm1lbnRBeGlzICogLTEgOiBhbGlnbm1lbnRBeGlzO1xuICB9XG4gIHJldHVybiBpc1ZlcnRpY2FsID8ge1xuICAgIHg6IGNyb3NzQXhpcyAqIGNyb3NzQXhpc011bHRpLFxuICAgIHk6IG1haW5BeGlzICogbWFpbkF4aXNNdWx0aVxuICB9IDoge1xuICAgIHg6IG1haW5BeGlzICogbWFpbkF4aXNNdWx0aSxcbiAgICB5OiBjcm9zc0F4aXMgKiBjcm9zc0F4aXNNdWx0aVxuICB9O1xufVxuXG4vKipcbiAqIE1vZGlmaWVzIHRoZSBwbGFjZW1lbnQgYnkgdHJhbnNsYXRpbmcgdGhlIGZsb2F0aW5nIGVsZW1lbnQgYWxvbmcgdGhlXG4gKiBzcGVjaWZpZWQgYXhlcy5cbiAqIEEgbnVtYmVyIChzaG9ydGhhbmQgZm9yIGBtYWluQXhpc2Agb3IgZGlzdGFuY2UpLCBvciBhbiBheGVzIGNvbmZpZ3VyYXRpb25cbiAqIG9iamVjdCBtYXkgYmUgcGFzc2VkLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL29mZnNldFxuICovXG5jb25zdCBvZmZzZXQgPSBmdW5jdGlvbiAob3B0aW9ucykge1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IDA7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBuYW1lOiAnb2Zmc2V0JyxcbiAgICBvcHRpb25zLFxuICAgIGFzeW5jIGZuKHN0YXRlKSB7XG4gICAgICB2YXIgX21pZGRsZXdhcmVEYXRhJG9mZnNlLCBfbWlkZGxld2FyZURhdGEkYXJyb3c7XG4gICAgICBjb25zdCB7XG4gICAgICAgIHgsXG4gICAgICAgIHksXG4gICAgICAgIHBsYWNlbWVudCxcbiAgICAgICAgbWlkZGxld2FyZURhdGFcbiAgICAgIH0gPSBzdGF0ZTtcbiAgICAgIGNvbnN0IGRpZmZDb29yZHMgPSBhd2FpdCBjb252ZXJ0VmFsdWVUb0Nvb3JkcyhzdGF0ZSwgb3B0aW9ucyk7XG5cbiAgICAgIC8vIElmIHRoZSBwbGFjZW1lbnQgaXMgdGhlIHNhbWUgYW5kIHRoZSBhcnJvdyBjYXVzZWQgYW4gYWxpZ25tZW50IG9mZnNldFxuICAgICAgLy8gdGhlbiB3ZSBkb24ndCBuZWVkIHRvIGNoYW5nZSB0aGUgcG9zaXRpb25pbmcgY29vcmRpbmF0ZXMuXG4gICAgICBpZiAocGxhY2VtZW50ID09PSAoKF9taWRkbGV3YXJlRGF0YSRvZmZzZSA9IG1pZGRsZXdhcmVEYXRhLm9mZnNldCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9taWRkbGV3YXJlRGF0YSRvZmZzZS5wbGFjZW1lbnQpICYmIChfbWlkZGxld2FyZURhdGEkYXJyb3cgPSBtaWRkbGV3YXJlRGF0YS5hcnJvdykgIT0gbnVsbCAmJiBfbWlkZGxld2FyZURhdGEkYXJyb3cuYWxpZ25tZW50T2Zmc2V0KSB7XG4gICAgICAgIHJldHVybiB7fTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7XG4gICAgICAgIHg6IHggKyBkaWZmQ29vcmRzLngsXG4gICAgICAgIHk6IHkgKyBkaWZmQ29vcmRzLnksXG4gICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAuLi5kaWZmQ29vcmRzLFxuICAgICAgICAgIHBsYWNlbWVudFxuICAgICAgICB9XG4gICAgICB9O1xuICAgIH1cbiAgfTtcbn07XG5cbi8qKlxuICogT3B0aW1pemVzIHRoZSB2aXNpYmlsaXR5IG9mIHRoZSBmbG9hdGluZyBlbGVtZW50IGJ5IHNoaWZ0aW5nIGl0IGluIG9yZGVyIHRvXG4gKiBrZWVwIGl0IGluIHZpZXcgd2hlbiBpdCB3aWxsIG92ZXJmbG93IHRoZSBjbGlwcGluZyBib3VuZGFyeS5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9zaGlmdFxuICovXG5jb25zdCBzaGlmdCA9IGZ1bmN0aW9uIChvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBuYW1lOiAnc2hpZnQnLFxuICAgIG9wdGlvbnMsXG4gICAgYXN5bmMgZm4oc3RhdGUpIHtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgeCxcbiAgICAgICAgeSxcbiAgICAgICAgcGxhY2VtZW50LFxuICAgICAgICBwbGF0Zm9ybVxuICAgICAgfSA9IHN0YXRlO1xuICAgICAgY29uc3Qge1xuICAgICAgICBtYWluQXhpczogY2hlY2tNYWluQXhpcyA9IHRydWUsXG4gICAgICAgIGNyb3NzQXhpczogY2hlY2tDcm9zc0F4aXMgPSBmYWxzZSxcbiAgICAgICAgbGltaXRlciA9IHtcbiAgICAgICAgICBmbjogX3JlZiA9PiB7XG4gICAgICAgICAgICBsZXQge1xuICAgICAgICAgICAgICB4LFxuICAgICAgICAgICAgICB5XG4gICAgICAgICAgICB9ID0gX3JlZjtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgIHgsXG4gICAgICAgICAgICAgIHlcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICAuLi5kZXRlY3RPdmVyZmxvd09wdGlvbnNcbiAgICAgIH0gPSBldmFsdWF0ZShvcHRpb25zLCBzdGF0ZSk7XG4gICAgICBjb25zdCBjb29yZHMgPSB7XG4gICAgICAgIHgsXG4gICAgICAgIHlcbiAgICAgIH07XG4gICAgICBjb25zdCBvdmVyZmxvdyA9IGF3YWl0IHBsYXRmb3JtLmRldGVjdE92ZXJmbG93KHN0YXRlLCBkZXRlY3RPdmVyZmxvd09wdGlvbnMpO1xuICAgICAgY29uc3QgY3Jvc3NBeGlzID0gZ2V0U2lkZUF4aXMocGxhY2VtZW50KTtcbiAgICAgIGNvbnN0IG1haW5BeGlzID0gZ2V0T3Bwb3NpdGVBeGlzKGNyb3NzQXhpcyk7XG4gICAgICBsZXQgbWFpbkF4aXNDb29yZCA9IGNvb3Jkc1ttYWluQXhpc107XG4gICAgICBsZXQgY3Jvc3NBeGlzQ29vcmQgPSBjb29yZHNbY3Jvc3NBeGlzXTtcbiAgICAgIGNvbnN0IGNsYW1wQ29vcmQgPSAoYXhpcywgY29vcmQpID0+IGNsYW1wKGNvb3JkICsgb3ZlcmZsb3dbYXhpcyA9PT0gJ3knID8gJ3RvcCcgOiAnbGVmdCddLCBjb29yZCwgY29vcmQgLSBvdmVyZmxvd1theGlzID09PSAneScgPyAnYm90dG9tJyA6ICdyaWdodCddKTtcbiAgICAgIGlmIChjaGVja01haW5BeGlzKSB7XG4gICAgICAgIG1haW5BeGlzQ29vcmQgPSBjbGFtcENvb3JkKG1haW5BeGlzLCBtYWluQXhpc0Nvb3JkKTtcbiAgICAgIH1cbiAgICAgIGlmIChjaGVja0Nyb3NzQXhpcykge1xuICAgICAgICBjcm9zc0F4aXNDb29yZCA9IGNsYW1wQ29vcmQoY3Jvc3NBeGlzLCBjcm9zc0F4aXNDb29yZCk7XG4gICAgICB9XG4gICAgICBjb25zdCBsaW1pdGVkQ29vcmRzID0gbGltaXRlci5mbih7XG4gICAgICAgIC4uLnN0YXRlLFxuICAgICAgICBbbWFpbkF4aXNdOiBtYWluQXhpc0Nvb3JkLFxuICAgICAgICBbY3Jvc3NBeGlzXTogY3Jvc3NBeGlzQ29vcmRcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4ubGltaXRlZENvb3JkcyxcbiAgICAgICAgZGF0YToge1xuICAgICAgICAgIHg6IGxpbWl0ZWRDb29yZHMueCAtIHgsXG4gICAgICAgICAgeTogbGltaXRlZENvb3Jkcy55IC0geSxcbiAgICAgICAgICBlbmFibGVkOiB7XG4gICAgICAgICAgICBbbWFpbkF4aXNdOiBjaGVja01haW5BeGlzLFxuICAgICAgICAgICAgW2Nyb3NzQXhpc106IGNoZWNrQ3Jvc3NBeGlzXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9O1xuICAgIH1cbiAgfTtcbn07XG4vKipcbiAqIEJ1aWx0LWluIGBsaW1pdGVyYCB0aGF0IHdpbGwgc3RvcCBgc2hpZnQoKWAgYXQgYSBjZXJ0YWluIHBvaW50LlxuICovXG5jb25zdCBsaW1pdFNoaWZ0ID0gZnVuY3Rpb24gKG9wdGlvbnMpIHtcbiAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkge1xuICAgIG9wdGlvbnMgPSB7fTtcbiAgfVxuICByZXR1cm4ge1xuICAgIG9wdGlvbnMsXG4gICAgZm4oc3RhdGUpIHtcbiAgICAgIHZhciBfcmF3T2Zmc2V0JG1haW5BeGlzLCBfcmF3T2Zmc2V0JGNyb3NzQXhpcztcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgeCxcbiAgICAgICAgeSxcbiAgICAgICAgcGxhY2VtZW50LFxuICAgICAgICByZWN0cyxcbiAgICAgICAgbWlkZGxld2FyZURhdGFcbiAgICAgIH0gPSBzdGF0ZTtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgb2Zmc2V0ID0gMCxcbiAgICAgICAgbWFpbkF4aXM6IGNoZWNrTWFpbkF4aXMgPSB0cnVlLFxuICAgICAgICBjcm9zc0F4aXM6IGNoZWNrQ3Jvc3NBeGlzID0gdHJ1ZVxuICAgICAgfSA9IGV2YWx1YXRlKG9wdGlvbnMsIHN0YXRlKTtcbiAgICAgIGNvbnN0IGNvb3JkcyA9IHtcbiAgICAgICAgeCxcbiAgICAgICAgeVxuICAgICAgfTtcbiAgICAgIGNvbnN0IGNyb3NzQXhpcyA9IGdldFNpZGVBeGlzKHBsYWNlbWVudCk7XG4gICAgICBjb25zdCBtYWluQXhpcyA9IGdldE9wcG9zaXRlQXhpcyhjcm9zc0F4aXMpO1xuICAgICAgbGV0IG1haW5BeGlzQ29vcmQgPSBjb29yZHNbbWFpbkF4aXNdO1xuICAgICAgbGV0IGNyb3NzQXhpc0Nvb3JkID0gY29vcmRzW2Nyb3NzQXhpc107XG4gICAgICBjb25zdCByYXdPZmZzZXQgPSBldmFsdWF0ZShvZmZzZXQsIHN0YXRlKTtcbiAgICAgIGNvbnN0IGNvbXB1dGVkT2Zmc2V0ID0gdHlwZW9mIHJhd09mZnNldCA9PT0gJ251bWJlcicgPyB7XG4gICAgICAgIG1haW5BeGlzOiByYXdPZmZzZXQsXG4gICAgICAgIGNyb3NzQXhpczogMFxuICAgICAgfSA6IHtcbiAgICAgICAgbWFpbkF4aXM6IChfcmF3T2Zmc2V0JG1haW5BeGlzID0gcmF3T2Zmc2V0Lm1haW5BeGlzKSAhPSBudWxsID8gX3Jhd09mZnNldCRtYWluQXhpcyA6IDAsXG4gICAgICAgIGNyb3NzQXhpczogKF9yYXdPZmZzZXQkY3Jvc3NBeGlzID0gcmF3T2Zmc2V0LmNyb3NzQXhpcykgIT0gbnVsbCA/IF9yYXdPZmZzZXQkY3Jvc3NBeGlzIDogMFxuICAgICAgfTtcbiAgICAgIGlmIChjaGVja01haW5BeGlzKSB7XG4gICAgICAgIGNvbnN0IGxlbiA9IG1haW5BeGlzID09PSAneScgPyAnaGVpZ2h0JyA6ICd3aWR0aCc7XG4gICAgICAgIGNvbnN0IGxpbWl0TWluID0gcmVjdHMucmVmZXJlbmNlW21haW5BeGlzXSAtIHJlY3RzLmZsb2F0aW5nW2xlbl0gKyBjb21wdXRlZE9mZnNldC5tYWluQXhpcztcbiAgICAgICAgY29uc3QgbGltaXRNYXggPSByZWN0cy5yZWZlcmVuY2VbbWFpbkF4aXNdICsgcmVjdHMucmVmZXJlbmNlW2xlbl0gLSBjb21wdXRlZE9mZnNldC5tYWluQXhpcztcbiAgICAgICAgaWYgKG1haW5BeGlzQ29vcmQgPCBsaW1pdE1pbikge1xuICAgICAgICAgIG1haW5BeGlzQ29vcmQgPSBsaW1pdE1pbjtcbiAgICAgICAgfSBlbHNlIGlmIChtYWluQXhpc0Nvb3JkID4gbGltaXRNYXgpIHtcbiAgICAgICAgICBtYWluQXhpc0Nvb3JkID0gbGltaXRNYXg7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChjaGVja0Nyb3NzQXhpcykge1xuICAgICAgICB2YXIgX21pZGRsZXdhcmVEYXRhJG9mZnNlLCBfbWlkZGxld2FyZURhdGEkb2Zmc2UyO1xuICAgICAgICBjb25zdCBsZW4gPSBtYWluQXhpcyA9PT0gJ3knID8gJ3dpZHRoJyA6ICdoZWlnaHQnO1xuICAgICAgICBjb25zdCBpc09yaWdpblNpZGUgPSBvcmlnaW5TaWRlcy5oYXMoZ2V0U2lkZShwbGFjZW1lbnQpKTtcbiAgICAgICAgY29uc3QgbGltaXRNaW4gPSByZWN0cy5yZWZlcmVuY2VbY3Jvc3NBeGlzXSAtIHJlY3RzLmZsb2F0aW5nW2xlbl0gKyAoaXNPcmlnaW5TaWRlID8gKChfbWlkZGxld2FyZURhdGEkb2Zmc2UgPSBtaWRkbGV3YXJlRGF0YS5vZmZzZXQpID09IG51bGwgPyB2b2lkIDAgOiBfbWlkZGxld2FyZURhdGEkb2Zmc2VbY3Jvc3NBeGlzXSkgfHwgMCA6IDApICsgKGlzT3JpZ2luU2lkZSA/IDAgOiBjb21wdXRlZE9mZnNldC5jcm9zc0F4aXMpO1xuICAgICAgICBjb25zdCBsaW1pdE1heCA9IHJlY3RzLnJlZmVyZW5jZVtjcm9zc0F4aXNdICsgcmVjdHMucmVmZXJlbmNlW2xlbl0gKyAoaXNPcmlnaW5TaWRlID8gMCA6ICgoX21pZGRsZXdhcmVEYXRhJG9mZnNlMiA9IG1pZGRsZXdhcmVEYXRhLm9mZnNldCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9taWRkbGV3YXJlRGF0YSRvZmZzZTJbY3Jvc3NBeGlzXSkgfHwgMCkgLSAoaXNPcmlnaW5TaWRlID8gY29tcHV0ZWRPZmZzZXQuY3Jvc3NBeGlzIDogMCk7XG4gICAgICAgIGlmIChjcm9zc0F4aXNDb29yZCA8IGxpbWl0TWluKSB7XG4gICAgICAgICAgY3Jvc3NBeGlzQ29vcmQgPSBsaW1pdE1pbjtcbiAgICAgICAgfSBlbHNlIGlmIChjcm9zc0F4aXNDb29yZCA+IGxpbWl0TWF4KSB7XG4gICAgICAgICAgY3Jvc3NBeGlzQ29vcmQgPSBsaW1pdE1heDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgW21haW5BeGlzXTogbWFpbkF4aXNDb29yZCxcbiAgICAgICAgW2Nyb3NzQXhpc106IGNyb3NzQXhpc0Nvb3JkXG4gICAgICB9O1xuICAgIH1cbiAgfTtcbn07XG5cbi8vIE1ldGhvZCBzeW50YXgga2VlcHMgY2FsbGJhY2sgcGFyYW1ldGVycyBiaXZhcmlhbnQsIGJ1dCBleHByZXNzaW5nIHRoZVxuLy8gZXhwbGljaXQgYHwgdW5kZWZpbmVkYCByZXF1aXJlZCBieSBgZXhhY3RPcHRpb25hbFByb3BlcnR5VHlwZXNgIG5lZWRzXG4vLyBwcm9wZXJ0eSBzeW50YXgsIHdoaWNoIGlzIGNvbnRyYXZhcmlhbnQgdW5kZXIgYHN0cmljdEZ1bmN0aW9uVHlwZXNgLlxuLy8gRXh0cmFjdGluZyB0aGUgZnVuY3Rpb24gZnJvbSBhIG1ldGhvZCBwb3NpdGlvbiByZXN0b3JlcyB0aGF0IGJpdmFyaWFuY2Ugc29cbi8vIGNvbnN1bWVycyBjYW4gc3RpbGwgYXNzaWduIGNhbGxiYWNrcyB3aXRoIG5hcnJvd2VyIHBhcmFtZXRlciB0eXBlcy5cblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRoYXQgYWxsb3dzIHlvdSB0byBjaGFuZ2UgdGhlIHNpemUgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQgXHUyMDE0XG4gKiBmb3IgaW5zdGFuY2UsIHByZXZlbnQgaXQgZnJvbSBvdmVyZmxvd2luZyB0aGUgY2xpcHBpbmcgYm91bmRhcnkgb3IgbWF0Y2ggdGhlXG4gKiB3aWR0aCBvZiB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3Mvc2l6ZVxuICovXG5jb25zdCBzaXplID0gZnVuY3Rpb24gKG9wdGlvbnMpIHtcbiAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkge1xuICAgIG9wdGlvbnMgPSB7fTtcbiAgfVxuICByZXR1cm4ge1xuICAgIG5hbWU6ICdzaXplJyxcbiAgICBvcHRpb25zLFxuICAgIGFzeW5jIGZuKHN0YXRlKSB7XG4gICAgICBjb25zdCB7XG4gICAgICAgIHBsYWNlbWVudCxcbiAgICAgICAgcmVjdHMsXG4gICAgICAgIHBsYXRmb3JtLFxuICAgICAgICBlbGVtZW50c1xuICAgICAgfSA9IHN0YXRlO1xuICAgICAgY29uc3Qge1xuICAgICAgICBhcHBseSA9ICgpID0+IHt9LFxuICAgICAgICAuLi5kZXRlY3RPdmVyZmxvd09wdGlvbnNcbiAgICAgIH0gPSBldmFsdWF0ZShvcHRpb25zLCBzdGF0ZSk7XG4gICAgICBjb25zdCBvdmVyZmxvdyA9IGF3YWl0IHBsYXRmb3JtLmRldGVjdE92ZXJmbG93KHN0YXRlLCBkZXRlY3RPdmVyZmxvd09wdGlvbnMpO1xuICAgICAgY29uc3Qgc2lkZSA9IGdldFNpZGUocGxhY2VtZW50KTtcbiAgICAgIGNvbnN0IGFsaWdubWVudCA9IGdldEFsaWdubWVudChwbGFjZW1lbnQpO1xuICAgICAgY29uc3QgaXNZQXhpcyA9IGdldFNpZGVBeGlzKHBsYWNlbWVudCkgPT09ICd5JztcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgd2lkdGgsXG4gICAgICAgIGhlaWdodFxuICAgICAgfSA9IHJlY3RzLmZsb2F0aW5nO1xuICAgICAgbGV0IGhlaWdodFNpZGU7XG4gICAgICBsZXQgd2lkdGhTaWRlO1xuICAgICAgaWYgKHNpZGUgPT09ICd0b3AnIHx8IHNpZGUgPT09ICdib3R0b20nKSB7XG4gICAgICAgIGhlaWdodFNpZGUgPSBzaWRlO1xuICAgICAgICB3aWR0aFNpZGUgPSBhbGlnbm1lbnQgPT09ICgoYXdhaXQgKHBsYXRmb3JtLmlzUlRMID09IG51bGwgPyB2b2lkIDAgOiBwbGF0Zm9ybS5pc1JUTChlbGVtZW50cy5mbG9hdGluZykpKSA/ICdzdGFydCcgOiAnZW5kJykgPyAnbGVmdCcgOiAncmlnaHQnO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgd2lkdGhTaWRlID0gc2lkZTtcbiAgICAgICAgaGVpZ2h0U2lkZSA9IGFsaWdubWVudCA9PT0gJ2VuZCcgPyAndG9wJyA6ICdib3R0b20nO1xuICAgICAgfVxuICAgICAgY29uc3QgbWF4aW11bUNsaXBwaW5nSGVpZ2h0ID0gaGVpZ2h0IC0gb3ZlcmZsb3cudG9wIC0gb3ZlcmZsb3cuYm90dG9tO1xuICAgICAgY29uc3QgbWF4aW11bUNsaXBwaW5nV2lkdGggPSB3aWR0aCAtIG92ZXJmbG93LmxlZnQgLSBvdmVyZmxvdy5yaWdodDtcbiAgICAgIGNvbnN0IG92ZXJmbG93QXZhaWxhYmxlSGVpZ2h0ID0gbWluKGhlaWdodCAtIG92ZXJmbG93W2hlaWdodFNpZGVdLCBtYXhpbXVtQ2xpcHBpbmdIZWlnaHQpO1xuICAgICAgY29uc3Qgb3ZlcmZsb3dBdmFpbGFibGVXaWR0aCA9IG1pbih3aWR0aCAtIG92ZXJmbG93W3dpZHRoU2lkZV0sIG1heGltdW1DbGlwcGluZ1dpZHRoKTtcbiAgICAgIGNvbnN0IHNoaWZ0RGF0YSA9IHN0YXRlLm1pZGRsZXdhcmVEYXRhLnNoaWZ0O1xuICAgICAgY29uc3Qgbm9TaGlmdCA9ICFzaGlmdERhdGE7XG4gICAgICBsZXQgYXZhaWxhYmxlSGVpZ2h0ID0gb3ZlcmZsb3dBdmFpbGFibGVIZWlnaHQ7XG4gICAgICBsZXQgYXZhaWxhYmxlV2lkdGggPSBvdmVyZmxvd0F2YWlsYWJsZVdpZHRoO1xuICAgICAgaWYgKHNoaWZ0RGF0YSAhPSBudWxsICYmIHNoaWZ0RGF0YS5lbmFibGVkLngpIHtcbiAgICAgICAgYXZhaWxhYmxlV2lkdGggPSBtYXhpbXVtQ2xpcHBpbmdXaWR0aDtcbiAgICAgIH1cbiAgICAgIGlmIChzaGlmdERhdGEgIT0gbnVsbCAmJiBzaGlmdERhdGEuZW5hYmxlZC55KSB7XG4gICAgICAgIGF2YWlsYWJsZUhlaWdodCA9IG1heGltdW1DbGlwcGluZ0hlaWdodDtcbiAgICAgIH1cbiAgICAgIGlmIChub1NoaWZ0ICYmICFhbGlnbm1lbnQpIHtcbiAgICAgICAgaWYgKGlzWUF4aXMpIHtcbiAgICAgICAgICBhdmFpbGFibGVXaWR0aCA9IHdpZHRoIC0gMiAqIG1heChvdmVyZmxvdy5sZWZ0LCBvdmVyZmxvdy5yaWdodCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgYXZhaWxhYmxlSGVpZ2h0ID0gaGVpZ2h0IC0gMiAqIG1heChvdmVyZmxvdy50b3AsIG92ZXJmbG93LmJvdHRvbSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGF3YWl0IGFwcGx5KHtcbiAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgIGF2YWlsYWJsZVdpZHRoLFxuICAgICAgICBhdmFpbGFibGVIZWlnaHRcbiAgICAgIH0pO1xuICAgICAgY29uc3QgbmV4dERpbWVuc2lvbnMgPSBhd2FpdCBwbGF0Zm9ybS5nZXREaW1lbnNpb25zKGVsZW1lbnRzLmZsb2F0aW5nKTtcbiAgICAgIGlmICh3aWR0aCAhPT0gbmV4dERpbWVuc2lvbnMud2lkdGggfHwgaGVpZ2h0ICE9PSBuZXh0RGltZW5zaW9ucy5oZWlnaHQpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICByZXNldDoge1xuICAgICAgICAgICAgcmVjdHM6IHRydWVcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICByZXR1cm4ge307XG4gICAgfVxuICB9O1xufTtcblxuZXhwb3J0IHsgYXJyb3csIGF1dG9QbGFjZW1lbnQsIGNvbXB1dGVQb3NpdGlvbiwgZGV0ZWN0T3ZlcmZsb3csIGZsaXAsIGhpZGUsIGlubGluZSwgbGltaXRTaGlmdCwgb2Zmc2V0LCBzaGlmdCwgc2l6ZSB9O1xuIiwgImZ1bmN0aW9uIGhhc1dpbmRvdygpIHtcbiAgcmV0dXJuIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnO1xufVxuZnVuY3Rpb24gZ2V0Tm9kZU5hbWUobm9kZSkge1xuICBpZiAoaXNOb2RlKG5vZGUpKSB7XG4gICAgcmV0dXJuIChub2RlLm5vZGVOYW1lIHx8ICcnKS50b0xvd2VyQ2FzZSgpO1xuICB9XG4gIC8vIE1vY2tlZCBub2RlcyBpbiB0ZXN0aW5nIGVudmlyb25tZW50cyBtYXkgbm90IGJlIGluc3RhbmNlcyBvZiBOb2RlLiBCeVxuICAvLyByZXR1cm5pbmcgYCNkb2N1bWVudGAgYW4gaW5maW5pdGUgbG9vcCB3b24ndCBvY2N1ci5cbiAgLy8gaHR0cHM6Ly9naXRodWIuY29tL2Zsb2F0aW5nLXVpL2Zsb2F0aW5nLXVpL2lzc3Vlcy8yMzE3XG4gIHJldHVybiAnI2RvY3VtZW50Jztcbn1cbmZ1bmN0aW9uIGdldFdpbmRvdyhub2RlKSB7XG4gIHZhciBfbm9kZSRvd25lckRvY3VtZW50O1xuICByZXR1cm4gKG5vZGUgPT0gbnVsbCB8fCAoX25vZGUkb3duZXJEb2N1bWVudCA9IG5vZGUub3duZXJEb2N1bWVudCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9ub2RlJG93bmVyRG9jdW1lbnQuZGVmYXVsdFZpZXcpIHx8IHdpbmRvdztcbn1cbmZ1bmN0aW9uIGdldERvY3VtZW50RWxlbWVudChub2RlKSB7XG4gIHZhciBfcmVmO1xuICByZXR1cm4gKF9yZWYgPSAoaXNOb2RlKG5vZGUpID8gbm9kZS5vd25lckRvY3VtZW50IDogbm9kZS5kb2N1bWVudCkgfHwgd2luZG93LmRvY3VtZW50KSA9PSBudWxsID8gdm9pZCAwIDogX3JlZi5kb2N1bWVudEVsZW1lbnQ7XG59XG5mdW5jdGlvbiBpc05vZGUodmFsdWUpIHtcbiAgaWYgKCFoYXNXaW5kb3coKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBOb2RlIHx8IHZhbHVlIGluc3RhbmNlb2YgZ2V0V2luZG93KHZhbHVlKS5Ob2RlO1xufVxuZnVuY3Rpb24gaXNFbGVtZW50KHZhbHVlKSB7XG4gIGlmICghaGFzV2luZG93KCkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgRWxlbWVudCB8fCB2YWx1ZSBpbnN0YW5jZW9mIGdldFdpbmRvdyh2YWx1ZSkuRWxlbWVudDtcbn1cbmZ1bmN0aW9uIGlzSFRNTEVsZW1lbnQodmFsdWUpIHtcbiAgaWYgKCFoYXNXaW5kb3coKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCB8fCB2YWx1ZSBpbnN0YW5jZW9mIGdldFdpbmRvdyh2YWx1ZSkuSFRNTEVsZW1lbnQ7XG59XG5mdW5jdGlvbiBpc1NoYWRvd1Jvb3QodmFsdWUpIHtcbiAgaWYgKCFoYXNXaW5kb3coKSB8fCB0eXBlb2YgU2hhZG93Um9vdCA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgU2hhZG93Um9vdCB8fCB2YWx1ZSBpbnN0YW5jZW9mIGdldFdpbmRvdyh2YWx1ZSkuU2hhZG93Um9vdDtcbn1cbmZ1bmN0aW9uIGlzT3ZlcmZsb3dFbGVtZW50KGVsZW1lbnQpIHtcbiAgY29uc3Qge1xuICAgIG92ZXJmbG93LFxuICAgIG92ZXJmbG93WCxcbiAgICBvdmVyZmxvd1ksXG4gICAgZGlzcGxheVxuICB9ID0gZ2V0Q29tcHV0ZWRTdHlsZShlbGVtZW50KTtcbiAgcmV0dXJuIC9hdXRvfHNjcm9sbHxvdmVybGF5fGhpZGRlbnxjbGlwLy50ZXN0KG92ZXJmbG93ICsgb3ZlcmZsb3dZICsgb3ZlcmZsb3dYKSAmJiBkaXNwbGF5ICE9PSAnaW5saW5lJyAmJiBkaXNwbGF5ICE9PSAnY29udGVudHMnO1xufVxuZnVuY3Rpb24gaXNUYWJsZUVsZW1lbnQoZWxlbWVudCkge1xuICByZXR1cm4gL14odGFibGV8dGR8dGgpJC8udGVzdChnZXROb2RlTmFtZShlbGVtZW50KSk7XG59XG5mdW5jdGlvbiBpc1RvcExheWVyKGVsZW1lbnQpIHtcbiAgdHJ5IHtcbiAgICBpZiAoZWxlbWVudC5tYXRjaGVzKCc6cG9wb3Zlci1vcGVuJykpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgfSBjYXRjaCAoX2UpIHtcbiAgICAvLyBuby1vcFxuICB9XG4gIHRyeSB7XG4gICAgcmV0dXJuIGVsZW1lbnQubWF0Y2hlcygnOm1vZGFsJyk7XG4gIH0gY2F0Y2ggKF9lKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5jb25zdCB3aWxsQ2hhbmdlUmUgPSAvdHJhbnNmb3JtfHRyYW5zbGF0ZXxzY2FsZXxyb3RhdGV8cGVyc3BlY3RpdmV8ZmlsdGVyLztcbmNvbnN0IGNvbnRhaW5SZSA9IC9wYWludHxsYXlvdXR8c3RyaWN0fGNvbnRlbnQvO1xuY29uc3QgaXNOb3ROb25lID0gdmFsdWUgPT4gISF2YWx1ZSAmJiB2YWx1ZSAhPT0gJ25vbmUnO1xubGV0IGlzV2ViS2l0VmFsdWU7XG5mdW5jdGlvbiBpc0NvbnRhaW5pbmdCbG9jayhlbGVtZW50T3JDc3MpIHtcbiAgY29uc3QgY3NzID0gaXNFbGVtZW50KGVsZW1lbnRPckNzcykgPyBnZXRDb21wdXRlZFN0eWxlKGVsZW1lbnRPckNzcykgOiBlbGVtZW50T3JDc3M7XG5cbiAgLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQ1NTL0NvbnRhaW5pbmdfYmxvY2sjaWRlbnRpZnlpbmdfdGhlX2NvbnRhaW5pbmdfYmxvY2tcbiAgLy8gaHR0cHM6Ly9kcmFmdHMuY3Nzd2cub3JnL2Nzcy10cmFuc2Zvcm1zLTIvI2luZGl2aWR1YWwtdHJhbnNmb3Jtc1xuICByZXR1cm4gaXNOb3ROb25lKGNzcy50cmFuc2Zvcm0pIHx8IGlzTm90Tm9uZShjc3MudHJhbnNsYXRlKSB8fCBpc05vdE5vbmUoY3NzLnNjYWxlKSB8fCBpc05vdE5vbmUoY3NzLnJvdGF0ZSkgfHwgaXNOb3ROb25lKGNzcy5wZXJzcGVjdGl2ZSkgfHwgIWlzV2ViS2l0KCkgJiYgKGlzTm90Tm9uZShjc3MuYmFja2Ryb3BGaWx0ZXIpIHx8IGlzTm90Tm9uZShjc3MuZmlsdGVyKSkgfHwgd2lsbENoYW5nZVJlLnRlc3QoY3NzLndpbGxDaGFuZ2UgfHwgJycpIHx8IGNvbnRhaW5SZS50ZXN0KGNzcy5jb250YWluIHx8ICcnKTtcbn1cbmZ1bmN0aW9uIGdldENvbnRhaW5pbmdCbG9jayhlbGVtZW50KSB7XG4gIGxldCBjdXJyZW50Tm9kZSA9IGdldFBhcmVudE5vZGUoZWxlbWVudCk7XG4gIHdoaWxlIChpc0hUTUxFbGVtZW50KGN1cnJlbnROb2RlKSAmJiAhaXNMYXN0VHJhdmVyc2FibGVOb2RlKGN1cnJlbnROb2RlKSkge1xuICAgIGlmIChpc0NvbnRhaW5pbmdCbG9jayhjdXJyZW50Tm9kZSkpIHtcbiAgICAgIHJldHVybiBjdXJyZW50Tm9kZTtcbiAgICB9IGVsc2UgaWYgKGlzVG9wTGF5ZXIoY3VycmVudE5vZGUpKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY3VycmVudE5vZGUgPSBnZXRQYXJlbnROb2RlKGN1cnJlbnROb2RlKTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cbmZ1bmN0aW9uIGlzV2ViS2l0KCkge1xuICBpZiAoaXNXZWJLaXRWYWx1ZSA9PSBudWxsKSB7XG4gICAgaXNXZWJLaXRWYWx1ZSA9IHR5cGVvZiBDU1MgIT09ICd1bmRlZmluZWQnICYmIENTUy5zdXBwb3J0cyAmJiBDU1Muc3VwcG9ydHMoJy13ZWJraXQtYmFja2Ryb3AtZmlsdGVyJywgJ25vbmUnKTtcbiAgfVxuICByZXR1cm4gaXNXZWJLaXRWYWx1ZTtcbn1cbmZ1bmN0aW9uIGlzTGFzdFRyYXZlcnNhYmxlTm9kZShub2RlKSB7XG4gIHJldHVybiAvXihodG1sfGJvZHl8I2RvY3VtZW50KSQvLnRlc3QoZ2V0Tm9kZU5hbWUobm9kZSkpO1xufVxuZnVuY3Rpb24gZ2V0Q29tcHV0ZWRTdHlsZShlbGVtZW50KSB7XG4gIHJldHVybiBnZXRXaW5kb3coZWxlbWVudCkuZ2V0Q29tcHV0ZWRTdHlsZShlbGVtZW50KTtcbn1cbmZ1bmN0aW9uIGdldE5vZGVTY3JvbGwoZWxlbWVudCkge1xuICBpZiAoaXNFbGVtZW50KGVsZW1lbnQpKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHNjcm9sbExlZnQ6IGVsZW1lbnQuc2Nyb2xsTGVmdCxcbiAgICAgIHNjcm9sbFRvcDogZWxlbWVudC5zY3JvbGxUb3BcbiAgICB9O1xuICB9XG4gIHJldHVybiB7XG4gICAgc2Nyb2xsTGVmdDogZWxlbWVudC5zY3JvbGxYLFxuICAgIHNjcm9sbFRvcDogZWxlbWVudC5zY3JvbGxZXG4gIH07XG59XG5mdW5jdGlvbiBnZXRQYXJlbnROb2RlKG5vZGUpIHtcbiAgaWYgKGdldE5vZGVOYW1lKG5vZGUpID09PSAnaHRtbCcpIHtcbiAgICByZXR1cm4gbm9kZTtcbiAgfVxuICBjb25zdCByZXN1bHQgPVxuICAvLyBTdGVwIGludG8gdGhlIHNoYWRvdyBET00gb2YgdGhlIHBhcmVudCBvZiBhIHNsb3R0ZWQgbm9kZS5cbiAgbm9kZS5hc3NpZ25lZFNsb3QgfHxcbiAgLy8gRE9NIEVsZW1lbnQgZGV0ZWN0ZWQuXG4gIG5vZGUucGFyZW50Tm9kZSB8fFxuICAvLyBTaGFkb3dSb290IGRldGVjdGVkLlxuICBpc1NoYWRvd1Jvb3Qobm9kZSkgJiYgbm9kZS5ob3N0IHx8XG4gIC8vIEZhbGxiYWNrLlxuICBnZXREb2N1bWVudEVsZW1lbnQobm9kZSk7XG4gIHJldHVybiBpc1NoYWRvd1Jvb3QocmVzdWx0KSA/IHJlc3VsdC5ob3N0IDogcmVzdWx0O1xufVxuZnVuY3Rpb24gZ2V0TmVhcmVzdE92ZXJmbG93QW5jZXN0b3Iobm9kZSkge1xuICBjb25zdCBwYXJlbnROb2RlID0gZ2V0UGFyZW50Tm9kZShub2RlKTtcbiAgaWYgKGlzTGFzdFRyYXZlcnNhYmxlTm9kZShwYXJlbnROb2RlKSkge1xuICAgIHJldHVybiAobm9kZS5vd25lckRvY3VtZW50IHx8IG5vZGUpLmJvZHk7XG4gIH1cbiAgaWYgKGlzSFRNTEVsZW1lbnQocGFyZW50Tm9kZSkgJiYgaXNPdmVyZmxvd0VsZW1lbnQocGFyZW50Tm9kZSkpIHtcbiAgICByZXR1cm4gcGFyZW50Tm9kZTtcbiAgfVxuICByZXR1cm4gZ2V0TmVhcmVzdE92ZXJmbG93QW5jZXN0b3IocGFyZW50Tm9kZSk7XG59XG5mdW5jdGlvbiBnZXRPdmVyZmxvd0FuY2VzdG9ycyhub2RlLCBsaXN0LCB0cmF2ZXJzZUlmcmFtZXMpIHtcbiAgdmFyIF9ub2RlJG93bmVyRG9jdW1lbnQyO1xuICBpZiAobGlzdCA9PT0gdm9pZCAwKSB7XG4gICAgbGlzdCA9IFtdO1xuICB9XG4gIGlmICh0cmF2ZXJzZUlmcmFtZXMgPT09IHZvaWQgMCkge1xuICAgIHRyYXZlcnNlSWZyYW1lcyA9IHRydWU7XG4gIH1cbiAgY29uc3Qgc2Nyb2xsYWJsZUFuY2VzdG9yID0gZ2V0TmVhcmVzdE92ZXJmbG93QW5jZXN0b3Iobm9kZSk7XG4gIGNvbnN0IGlzQm9keSA9IHNjcm9sbGFibGVBbmNlc3RvciA9PT0gKChfbm9kZSRvd25lckRvY3VtZW50MiA9IG5vZGUub3duZXJEb2N1bWVudCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9ub2RlJG93bmVyRG9jdW1lbnQyLmJvZHkpO1xuICBjb25zdCB3aW4gPSBnZXRXaW5kb3coc2Nyb2xsYWJsZUFuY2VzdG9yKTtcbiAgaWYgKGlzQm9keSkge1xuICAgIGNvbnN0IGZyYW1lRWxlbWVudCA9IGdldEZyYW1lRWxlbWVudCh3aW4pO1xuICAgIHJldHVybiBsaXN0LmNvbmNhdCh3aW4sIHdpbi52aXN1YWxWaWV3cG9ydCB8fCBbXSwgaXNPdmVyZmxvd0VsZW1lbnQoc2Nyb2xsYWJsZUFuY2VzdG9yKSA/IHNjcm9sbGFibGVBbmNlc3RvciA6IFtdLCBmcmFtZUVsZW1lbnQgJiYgdHJhdmVyc2VJZnJhbWVzID8gZ2V0T3ZlcmZsb3dBbmNlc3RvcnMoZnJhbWVFbGVtZW50KSA6IFtdKTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gbGlzdC5jb25jYXQoc2Nyb2xsYWJsZUFuY2VzdG9yLCBnZXRPdmVyZmxvd0FuY2VzdG9ycyhzY3JvbGxhYmxlQW5jZXN0b3IsIFtdLCB0cmF2ZXJzZUlmcmFtZXMpKTtcbiAgfVxufVxuZnVuY3Rpb24gZ2V0RnJhbWVFbGVtZW50KHdpbikge1xuICByZXR1cm4gd2luLnBhcmVudCAmJiBPYmplY3QuZ2V0UHJvdG90eXBlT2Yod2luLnBhcmVudCkgPyB3aW4uZnJhbWVFbGVtZW50IDogbnVsbDtcbn1cblxuZXhwb3J0IHsgZ2V0Q29tcHV0ZWRTdHlsZSwgZ2V0Q29udGFpbmluZ0Jsb2NrLCBnZXREb2N1bWVudEVsZW1lbnQsIGdldEZyYW1lRWxlbWVudCwgZ2V0TmVhcmVzdE92ZXJmbG93QW5jZXN0b3IsIGdldE5vZGVOYW1lLCBnZXROb2RlU2Nyb2xsLCBnZXRPdmVyZmxvd0FuY2VzdG9ycywgZ2V0UGFyZW50Tm9kZSwgZ2V0V2luZG93LCBpc0NvbnRhaW5pbmdCbG9jaywgaXNFbGVtZW50LCBpc0hUTUxFbGVtZW50LCBpc0xhc3RUcmF2ZXJzYWJsZU5vZGUsIGlzTm9kZSwgaXNPdmVyZmxvd0VsZW1lbnQsIGlzU2hhZG93Um9vdCwgaXNUYWJsZUVsZW1lbnQsIGlzVG9wTGF5ZXIsIGlzV2ViS2l0IH07XG4iLCAiaW1wb3J0IHsgcmVjdFRvQ2xpZW50UmVjdCwgYXJyb3cgYXMgYXJyb3ckMSwgYXV0b1BsYWNlbWVudCBhcyBhdXRvUGxhY2VtZW50JDEsIGRldGVjdE92ZXJmbG93IGFzIGRldGVjdE92ZXJmbG93JDEsIGZsaXAgYXMgZmxpcCQxLCBoaWRlIGFzIGhpZGUkMSwgaW5saW5lIGFzIGlubGluZSQxLCBsaW1pdFNoaWZ0IGFzIGxpbWl0U2hpZnQkMSwgb2Zmc2V0IGFzIG9mZnNldCQxLCBzaGlmdCBhcyBzaGlmdCQxLCBzaXplIGFzIHNpemUkMSwgY29tcHV0ZVBvc2l0aW9uIGFzIGNvbXB1dGVQb3NpdGlvbiQxIH0gZnJvbSAnQGZsb2F0aW5nLXVpL2NvcmUnO1xuaW1wb3J0IHsgcm91bmQsIGNyZWF0ZUNvb3JkcywgbWF4LCBtaW4sIGZsb29yIH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzJztcbmltcG9ydCB7IGdldENvbXB1dGVkU3R5bGUgYXMgZ2V0Q29tcHV0ZWRTdHlsZSQxLCBpc0hUTUxFbGVtZW50LCBpc0VsZW1lbnQsIGdldFdpbmRvdywgaXNXZWJLaXQsIGdldEZyYW1lRWxlbWVudCwgZ2V0Tm9kZVNjcm9sbCwgZ2V0RG9jdW1lbnRFbGVtZW50LCBpc1RvcExheWVyLCBnZXROb2RlTmFtZSwgaXNPdmVyZmxvd0VsZW1lbnQsIGdldE92ZXJmbG93QW5jZXN0b3JzLCBnZXRQYXJlbnROb2RlLCBpc0xhc3RUcmF2ZXJzYWJsZU5vZGUsIGlzQ29udGFpbmluZ0Jsb2NrLCBpc1RhYmxlRWxlbWVudCwgZ2V0Q29udGFpbmluZ0Jsb2NrIH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzL2RvbSc7XG5leHBvcnQgeyBnZXRPdmVyZmxvd0FuY2VzdG9ycyB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscy9kb20nO1xuXG5mdW5jdGlvbiBnZXRDc3NEaW1lbnNpb25zKGVsZW1lbnQpIHtcbiAgY29uc3QgY3NzID0gZ2V0Q29tcHV0ZWRTdHlsZSQxKGVsZW1lbnQpO1xuICAvLyBJbiB0ZXN0aW5nIGVudmlyb25tZW50cywgdGhlIGB3aWR0aGAgYW5kIGBoZWlnaHRgIHByb3BlcnRpZXMgYXJlIGVtcHR5XG4gIC8vIHN0cmluZ3MgZm9yIFNWRyBlbGVtZW50cywgcmV0dXJuaW5nIE5hTi4gRmFsbGJhY2sgdG8gYDBgIGluIHRoaXMgY2FzZS5cbiAgbGV0IHdpZHRoID0gcGFyc2VGbG9hdChjc3Mud2lkdGgpIHx8IDA7XG4gIGxldCBoZWlnaHQgPSBwYXJzZUZsb2F0KGNzcy5oZWlnaHQpIHx8IDA7XG4gIGNvbnN0IGhhc09mZnNldCA9IGlzSFRNTEVsZW1lbnQoZWxlbWVudCk7XG4gIGNvbnN0IG9mZnNldFdpZHRoID0gaGFzT2Zmc2V0ID8gZWxlbWVudC5vZmZzZXRXaWR0aCA6IHdpZHRoO1xuICBjb25zdCBvZmZzZXRIZWlnaHQgPSBoYXNPZmZzZXQgPyBlbGVtZW50Lm9mZnNldEhlaWdodCA6IGhlaWdodDtcbiAgY29uc3Qgc2hvdWxkRmFsbGJhY2sgPSByb3VuZCh3aWR0aCkgIT09IG9mZnNldFdpZHRoIHx8IHJvdW5kKGhlaWdodCkgIT09IG9mZnNldEhlaWdodDtcbiAgaWYgKHNob3VsZEZhbGxiYWNrKSB7XG4gICAgd2lkdGggPSBvZmZzZXRXaWR0aDtcbiAgICBoZWlnaHQgPSBvZmZzZXRIZWlnaHQ7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB3aWR0aCxcbiAgICBoZWlnaHQsXG4gICAgJDogc2hvdWxkRmFsbGJhY2tcbiAgfTtcbn1cblxuZnVuY3Rpb24gdW53cmFwRWxlbWVudChlbGVtZW50KSB7XG4gIHJldHVybiAhaXNFbGVtZW50KGVsZW1lbnQpID8gZWxlbWVudC5jb250ZXh0RWxlbWVudCA6IGVsZW1lbnQ7XG59XG5cbmZ1bmN0aW9uIGdldFNjYWxlKGVsZW1lbnQpIHtcbiAgY29uc3QgZG9tRWxlbWVudCA9IHVud3JhcEVsZW1lbnQoZWxlbWVudCk7XG4gIGlmICghaXNIVE1MRWxlbWVudChkb21FbGVtZW50KSkge1xuICAgIHJldHVybiBjcmVhdGVDb29yZHMoMSk7XG4gIH1cbiAgY29uc3QgcmVjdCA9IGRvbUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gIGNvbnN0IHtcbiAgICB3aWR0aCxcbiAgICBoZWlnaHQsXG4gICAgJFxuICB9ID0gZ2V0Q3NzRGltZW5zaW9ucyhkb21FbGVtZW50KTtcbiAgbGV0IHggPSAoJCA/IHJvdW5kKHJlY3Qud2lkdGgpIDogcmVjdC53aWR0aCkgLyB3aWR0aDtcbiAgbGV0IHkgPSAoJCA/IHJvdW5kKHJlY3QuaGVpZ2h0KSA6IHJlY3QuaGVpZ2h0KSAvIGhlaWdodDtcblxuICAvLyAwLCBOYU4sIG9yIEluZmluaXR5IHNob3VsZCBhbHdheXMgZmFsbGJhY2sgdG8gMS5cblxuICBpZiAoIXggfHwgIU51bWJlci5pc0Zpbml0ZSh4KSkge1xuICAgIHggPSAxO1xuICB9XG4gIGlmICgheSB8fCAhTnVtYmVyLmlzRmluaXRlKHkpKSB7XG4gICAgeSA9IDE7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB4LFxuICAgIHlcbiAgfTtcbn1cblxuY29uc3Qgbm9PZmZzZXRzID0gLyojX19QVVJFX18qL2NyZWF0ZUNvb3JkcygwKTtcbmZ1bmN0aW9uIGdldFZpc3VhbE9mZnNldHMoZWxlbWVudCkge1xuICBjb25zdCB3aW4gPSBnZXRXaW5kb3coZWxlbWVudCk7XG4gIGlmICghaXNXZWJLaXQoKSB8fCAhd2luLnZpc3VhbFZpZXdwb3J0KSB7XG4gICAgcmV0dXJuIG5vT2Zmc2V0cztcbiAgfVxuICByZXR1cm4ge1xuICAgIHg6IHdpbi52aXN1YWxWaWV3cG9ydC5vZmZzZXRMZWZ0LFxuICAgIHk6IHdpbi52aXN1YWxWaWV3cG9ydC5vZmZzZXRUb3BcbiAgfTtcbn1cbmZ1bmN0aW9uIHNob3VsZEFkZFZpc3VhbE9mZnNldHMoZWxlbWVudCwgaXNGaXhlZCwgZmxvYXRpbmdPZmZzZXRQYXJlbnQpIHtcbiAgaWYgKGlzRml4ZWQgPT09IHZvaWQgMCkge1xuICAgIGlzRml4ZWQgPSBmYWxzZTtcbiAgfVxuICByZXR1cm4gISFmbG9hdGluZ09mZnNldFBhcmVudCAmJiBpc0ZpeGVkICYmIGZsb2F0aW5nT2Zmc2V0UGFyZW50ID09PSBnZXRXaW5kb3coZWxlbWVudCk7XG59XG5cbmZ1bmN0aW9uIGdldEJvdW5kaW5nQ2xpZW50UmVjdChlbGVtZW50LCBpbmNsdWRlU2NhbGUsIGlzRml4ZWRTdHJhdGVneSwgb2Zmc2V0UGFyZW50KSB7XG4gIGlmIChpbmNsdWRlU2NhbGUgPT09IHZvaWQgMCkge1xuICAgIGluY2x1ZGVTY2FsZSA9IGZhbHNlO1xuICB9XG4gIGlmIChpc0ZpeGVkU3RyYXRlZ3kgPT09IHZvaWQgMCkge1xuICAgIGlzRml4ZWRTdHJhdGVneSA9IGZhbHNlO1xuICB9XG4gIGNvbnN0IGNsaWVudFJlY3QgPSBlbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICBjb25zdCBkb21FbGVtZW50ID0gdW53cmFwRWxlbWVudChlbGVtZW50KTtcbiAgbGV0IHNjYWxlID0gY3JlYXRlQ29vcmRzKDEpO1xuICBpZiAoaW5jbHVkZVNjYWxlKSB7XG4gICAgaWYgKG9mZnNldFBhcmVudCkge1xuICAgICAgaWYgKGlzRWxlbWVudChvZmZzZXRQYXJlbnQpKSB7XG4gICAgICAgIHNjYWxlID0gZ2V0U2NhbGUob2Zmc2V0UGFyZW50KTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgc2NhbGUgPSBnZXRTY2FsZShlbGVtZW50KTtcbiAgICB9XG4gIH1cbiAgY29uc3QgdmlzdWFsT2Zmc2V0cyA9IHNob3VsZEFkZFZpc3VhbE9mZnNldHMoZG9tRWxlbWVudCwgaXNGaXhlZFN0cmF0ZWd5LCBvZmZzZXRQYXJlbnQpID8gZ2V0VmlzdWFsT2Zmc2V0cyhkb21FbGVtZW50KSA6IGNyZWF0ZUNvb3JkcygwKTtcbiAgbGV0IHggPSAoY2xpZW50UmVjdC5sZWZ0ICsgdmlzdWFsT2Zmc2V0cy54KSAvIHNjYWxlLng7XG4gIGxldCB5ID0gKGNsaWVudFJlY3QudG9wICsgdmlzdWFsT2Zmc2V0cy55KSAvIHNjYWxlLnk7XG4gIGxldCB3aWR0aCA9IGNsaWVudFJlY3Qud2lkdGggLyBzY2FsZS54O1xuICBsZXQgaGVpZ2h0ID0gY2xpZW50UmVjdC5oZWlnaHQgLyBzY2FsZS55O1xuICBpZiAoZG9tRWxlbWVudCAmJiBvZmZzZXRQYXJlbnQpIHtcbiAgICBjb25zdCB3aW4gPSBnZXRXaW5kb3coZG9tRWxlbWVudCk7XG4gICAgY29uc3Qgb2Zmc2V0V2luID0gaXNFbGVtZW50KG9mZnNldFBhcmVudCkgPyBnZXRXaW5kb3cob2Zmc2V0UGFyZW50KSA6IG9mZnNldFBhcmVudDtcbiAgICBsZXQgY3VycmVudFdpbiA9IHdpbjtcbiAgICBsZXQgY3VycmVudElGcmFtZSA9IGdldEZyYW1lRWxlbWVudChjdXJyZW50V2luKTtcbiAgICB3aGlsZSAoY3VycmVudElGcmFtZSAmJiBvZmZzZXRXaW4gIT09IGN1cnJlbnRXaW4pIHtcbiAgICAgIGNvbnN0IGlmcmFtZVNjYWxlID0gZ2V0U2NhbGUoY3VycmVudElGcmFtZSk7XG4gICAgICBjb25zdCBpZnJhbWVSZWN0ID0gY3VycmVudElGcmFtZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgIGNvbnN0IGNzcyA9IGdldENvbXB1dGVkU3R5bGUkMShjdXJyZW50SUZyYW1lKTtcbiAgICAgIGNvbnN0IGxlZnQgPSBpZnJhbWVSZWN0LmxlZnQgKyAoY3VycmVudElGcmFtZS5jbGllbnRMZWZ0ICsgcGFyc2VGbG9hdChjc3MucGFkZGluZ0xlZnQpKSAqIGlmcmFtZVNjYWxlLng7XG4gICAgICBjb25zdCB0b3AgPSBpZnJhbWVSZWN0LnRvcCArIChjdXJyZW50SUZyYW1lLmNsaWVudFRvcCArIHBhcnNlRmxvYXQoY3NzLnBhZGRpbmdUb3ApKSAqIGlmcmFtZVNjYWxlLnk7XG4gICAgICB4ICo9IGlmcmFtZVNjYWxlLng7XG4gICAgICB5ICo9IGlmcmFtZVNjYWxlLnk7XG4gICAgICB3aWR0aCAqPSBpZnJhbWVTY2FsZS54O1xuICAgICAgaGVpZ2h0ICo9IGlmcmFtZVNjYWxlLnk7XG4gICAgICB4ICs9IGxlZnQ7XG4gICAgICB5ICs9IHRvcDtcbiAgICAgIGN1cnJlbnRXaW4gPSBnZXRXaW5kb3coY3VycmVudElGcmFtZSk7XG4gICAgICBjdXJyZW50SUZyYW1lID0gZ2V0RnJhbWVFbGVtZW50KGN1cnJlbnRXaW4pO1xuICAgIH1cbiAgfVxuICByZXR1cm4gcmVjdFRvQ2xpZW50UmVjdCh7XG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0LFxuICAgIHgsXG4gICAgeVxuICB9KTtcbn1cblxuLy8gSWYgPGh0bWw+IGhhcyBhIENTUyB3aWR0aCBncmVhdGVyIHRoYW4gdGhlIHZpZXdwb3J0LCB0aGVuIHRoaXMgd2lsbCBiZVxuLy8gaW5jb3JyZWN0IGZvciBSVEwuXG5mdW5jdGlvbiBnZXRXaW5kb3dTY3JvbGxCYXJYKGVsZW1lbnQsIHJlY3QpIHtcbiAgY29uc3QgbGVmdFNjcm9sbCA9IGdldE5vZGVTY3JvbGwoZWxlbWVudCkuc2Nyb2xsTGVmdDtcbiAgaWYgKCFyZWN0KSB7XG4gICAgcmV0dXJuIGdldEJvdW5kaW5nQ2xpZW50UmVjdChnZXREb2N1bWVudEVsZW1lbnQoZWxlbWVudCkpLmxlZnQgKyBsZWZ0U2Nyb2xsO1xuICB9XG4gIHJldHVybiByZWN0LmxlZnQgKyBsZWZ0U2Nyb2xsO1xufVxuXG5mdW5jdGlvbiBnZXRIVE1MT2Zmc2V0KGRvY3VtZW50RWxlbWVudCwgc2Nyb2xsKSB7XG4gIGNvbnN0IGh0bWxSZWN0ID0gZG9jdW1lbnRFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICBjb25zdCB4ID0gaHRtbFJlY3QubGVmdCArIHNjcm9sbC5zY3JvbGxMZWZ0IC0gZ2V0V2luZG93U2Nyb2xsQmFyWChkb2N1bWVudEVsZW1lbnQsIGh0bWxSZWN0KTtcbiAgY29uc3QgeSA9IGh0bWxSZWN0LnRvcCArIHNjcm9sbC5zY3JvbGxUb3A7XG4gIHJldHVybiB7XG4gICAgeCxcbiAgICB5XG4gIH07XG59XG5cbmZ1bmN0aW9uIGNvbnZlcnRPZmZzZXRQYXJlbnRSZWxhdGl2ZVJlY3RUb1ZpZXdwb3J0UmVsYXRpdmVSZWN0KF9yZWYpIHtcbiAgbGV0IHtcbiAgICBlbGVtZW50cyxcbiAgICByZWN0LFxuICAgIG9mZnNldFBhcmVudCxcbiAgICBzdHJhdGVneVxuICB9ID0gX3JlZjtcbiAgY29uc3QgaXNGaXhlZCA9IHN0cmF0ZWd5ID09PSAnZml4ZWQnO1xuICBjb25zdCBkb2N1bWVudEVsZW1lbnQgPSBnZXREb2N1bWVudEVsZW1lbnQob2Zmc2V0UGFyZW50KTtcbiAgY29uc3QgdG9wTGF5ZXIgPSBlbGVtZW50cyA/IGlzVG9wTGF5ZXIoZWxlbWVudHMuZmxvYXRpbmcpIDogZmFsc2U7XG4gIGlmIChvZmZzZXRQYXJlbnQgPT09IGRvY3VtZW50RWxlbWVudCB8fCB0b3BMYXllciAmJiBpc0ZpeGVkKSB7XG4gICAgcmV0dXJuIHJlY3Q7XG4gIH1cbiAgbGV0IHNjcm9sbCA9IHtcbiAgICBzY3JvbGxMZWZ0OiAwLFxuICAgIHNjcm9sbFRvcDogMFxuICB9O1xuICBsZXQgc2NhbGUgPSBjcmVhdGVDb29yZHMoMSk7XG4gIGNvbnN0IG9mZnNldHMgPSBjcmVhdGVDb29yZHMoMCk7XG4gIGNvbnN0IGlzT2Zmc2V0UGFyZW50QW5FbGVtZW50ID0gaXNIVE1MRWxlbWVudChvZmZzZXRQYXJlbnQpO1xuICBpZiAoaXNPZmZzZXRQYXJlbnRBbkVsZW1lbnQgfHwgIWlzRml4ZWQpIHtcbiAgICBpZiAoZ2V0Tm9kZU5hbWUob2Zmc2V0UGFyZW50KSAhPT0gJ2JvZHknIHx8IGlzT3ZlcmZsb3dFbGVtZW50KGRvY3VtZW50RWxlbWVudCkpIHtcbiAgICAgIHNjcm9sbCA9IGdldE5vZGVTY3JvbGwob2Zmc2V0UGFyZW50KTtcbiAgICB9XG4gICAgaWYgKGlzT2Zmc2V0UGFyZW50QW5FbGVtZW50KSB7XG4gICAgICBjb25zdCBvZmZzZXRSZWN0ID0gZ2V0Qm91bmRpbmdDbGllbnRSZWN0KG9mZnNldFBhcmVudCk7XG4gICAgICBzY2FsZSA9IGdldFNjYWxlKG9mZnNldFBhcmVudCk7XG4gICAgICBvZmZzZXRzLnggPSBvZmZzZXRSZWN0LnggKyBvZmZzZXRQYXJlbnQuY2xpZW50TGVmdDtcbiAgICAgIG9mZnNldHMueSA9IG9mZnNldFJlY3QueSArIG9mZnNldFBhcmVudC5jbGllbnRUb3A7XG4gICAgfVxuICB9XG4gIGNvbnN0IGh0bWxPZmZzZXQgPSBkb2N1bWVudEVsZW1lbnQgJiYgIWlzT2Zmc2V0UGFyZW50QW5FbGVtZW50ICYmICFpc0ZpeGVkID8gZ2V0SFRNTE9mZnNldChkb2N1bWVudEVsZW1lbnQsIHNjcm9sbCkgOiBjcmVhdGVDb29yZHMoMCk7XG4gIHJldHVybiB7XG4gICAgd2lkdGg6IHJlY3Qud2lkdGggKiBzY2FsZS54LFxuICAgIGhlaWdodDogcmVjdC5oZWlnaHQgKiBzY2FsZS55LFxuICAgIHg6IHJlY3QueCAqIHNjYWxlLnggLSBzY3JvbGwuc2Nyb2xsTGVmdCAqIHNjYWxlLnggKyBvZmZzZXRzLnggKyBodG1sT2Zmc2V0LngsXG4gICAgeTogcmVjdC55ICogc2NhbGUueSAtIHNjcm9sbC5zY3JvbGxUb3AgKiBzY2FsZS55ICsgb2Zmc2V0cy55ICsgaHRtbE9mZnNldC55XG4gIH07XG59XG5cbmZ1bmN0aW9uIGdldENsaWVudFJlY3RzKGVsZW1lbnQpIHtcbiAgcmV0dXJuIGVsZW1lbnQuZ2V0Q2xpZW50UmVjdHMgPyBBcnJheS5mcm9tKGVsZW1lbnQuZ2V0Q2xpZW50UmVjdHMoKSkgOiBbXTtcbn1cblxuLy8gR2V0cyB0aGUgZW50aXJlIHNpemUgb2YgdGhlIHNjcm9sbGFibGUgZG9jdW1lbnQgYXJlYSwgZXZlbiBleHRlbmRpbmcgb3V0c2lkZVxuLy8gb2YgdGhlIGA8aHRtbD5gIGFuZCBgPGJvZHk+YCByZWN0IGJvdW5kcyBpZiBob3Jpem9udGFsbHkgc2Nyb2xsYWJsZS5cbmZ1bmN0aW9uIGdldERvY3VtZW50UmVjdChodG1sKSB7XG4gIGNvbnN0IHNjcm9sbCA9IGdldE5vZGVTY3JvbGwoaHRtbCk7XG4gIGNvbnN0IGJvZHkgPSBodG1sLm93bmVyRG9jdW1lbnQuYm9keTtcbiAgY29uc3Qgd2lkdGggPSBtYXgoaHRtbC5zY3JvbGxXaWR0aCwgaHRtbC5jbGllbnRXaWR0aCwgYm9keS5zY3JvbGxXaWR0aCwgYm9keS5jbGllbnRXaWR0aCk7XG4gIGNvbnN0IGhlaWdodCA9IG1heChodG1sLnNjcm9sbEhlaWdodCwgaHRtbC5jbGllbnRIZWlnaHQsIGJvZHkuc2Nyb2xsSGVpZ2h0LCBib2R5LmNsaWVudEhlaWdodCk7XG4gIGxldCB4ID0gLXNjcm9sbC5zY3JvbGxMZWZ0ICsgZ2V0V2luZG93U2Nyb2xsQmFyWChodG1sKTtcbiAgY29uc3QgeSA9IC1zY3JvbGwuc2Nyb2xsVG9wO1xuICBpZiAoZ2V0Q29tcHV0ZWRTdHlsZSQxKGJvZHkpLmRpcmVjdGlvbiA9PT0gJ3J0bCcpIHtcbiAgICB4ICs9IG1heChodG1sLmNsaWVudFdpZHRoLCBib2R5LmNsaWVudFdpZHRoKSAtIHdpZHRoO1xuICB9XG4gIHJldHVybiB7XG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0LFxuICAgIHgsXG4gICAgeVxuICB9O1xufVxuXG4vLyBTYWZldHkgY2hlY2s6IGVuc3VyZSB0aGUgc2Nyb2xsYmFyIHNwYWNlIGlzIHJlYXNvbmFibGUgaW4gY2FzZSB0aGlzXG4vLyBjYWxjdWxhdGlvbiBpcyBhZmZlY3RlZCBieSB1bnVzdWFsIHN0eWxlcy5cbi8vIE1vc3Qgc2Nyb2xsYmFycyBsZWF2ZSAxNS0xOHB4IG9mIHNwYWNlLlxuY29uc3QgU0NST0xMQkFSX01BWCA9IDI1O1xuZnVuY3Rpb24gZ2V0Vmlld3BvcnRSZWN0KGVsZW1lbnQsIHN0cmF0ZWd5LCByb290Qm91bmRhcnkpIHtcbiAgaWYgKHJvb3RCb3VuZGFyeSA9PT0gdm9pZCAwKSB7XG4gICAgcm9vdEJvdW5kYXJ5ID0gJ3ZpZXdwb3J0JztcbiAgfVxuICBjb25zdCBpc0xheW91dFZpZXdwb3J0ID0gcm9vdEJvdW5kYXJ5ID09PSAnbGF5b3V0Vmlld3BvcnQnO1xuICBjb25zdCB3aW4gPSBnZXRXaW5kb3coZWxlbWVudCk7XG4gIGNvbnN0IGh0bWwgPSBnZXREb2N1bWVudEVsZW1lbnQoZWxlbWVudCk7XG4gIGNvbnN0IHZpc3VhbFZpZXdwb3J0ID0gd2luLnZpc3VhbFZpZXdwb3J0O1xuICBsZXQgd2lkdGggPSBodG1sLmNsaWVudFdpZHRoO1xuICBsZXQgaGVpZ2h0ID0gaHRtbC5jbGllbnRIZWlnaHQ7XG4gIGxldCB4ID0gMDtcbiAgbGV0IHkgPSAwO1xuICBpZiAodmlzdWFsVmlld3BvcnQpIHtcbiAgICAvLyBDbGllbnQgY29vcmRpbmF0ZXMgYXJlIHJlbGF0aXZlIHRvIHRoZSBsYXlvdXQgdmlld3BvcnQsIGV4Y2VwdCBpblxuICAgIC8vIFdlYktpdCB3aXRoIGFuIGBhYnNvbHV0ZWAgc3RyYXRlZ3ksIHdoZXJlIHRoZXkgYXJlIHJlbGF0aXZlIHRvIHRoZVxuICAgIC8vIHZpc3VhbCB2aWV3cG9ydC5cbiAgICBjb25zdCBsYXlvdXRSZWxhdGl2ZUNsaWVudENvb3JkcyA9ICFpc1dlYktpdCgpIHx8IHN0cmF0ZWd5ID09PSAnZml4ZWQnO1xuICAgIGlmIChpc0xheW91dFZpZXdwb3J0KSB7XG4gICAgICBpZiAoIWxheW91dFJlbGF0aXZlQ2xpZW50Q29vcmRzKSB7XG4gICAgICAgIHggPSAtdmlzdWFsVmlld3BvcnQub2Zmc2V0TGVmdDtcbiAgICAgICAgeSA9IC12aXN1YWxWaWV3cG9ydC5vZmZzZXRUb3A7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHdpZHRoID0gdmlzdWFsVmlld3BvcnQud2lkdGg7XG4gICAgICBoZWlnaHQgPSB2aXN1YWxWaWV3cG9ydC5oZWlnaHQ7XG4gICAgICBpZiAobGF5b3V0UmVsYXRpdmVDbGllbnRDb29yZHMpIHtcbiAgICAgICAgeCA9IHZpc3VhbFZpZXdwb3J0Lm9mZnNldExlZnQ7XG4gICAgICAgIHkgPSB2aXN1YWxWaWV3cG9ydC5vZmZzZXRUb3A7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGNvbnN0IHdpbmRvd1Njcm9sbGJhclggPSBnZXRXaW5kb3dTY3JvbGxCYXJYKGh0bWwpO1xuICAvLyBgc2Nyb2xsYmFyLWd1dHRlcjogc3RhYmxlYCBvbiB0aGUgPGh0bWw+IHJlc2VydmVzIGd1dHRlciBzcGFjZSB0aGF0IHNocmlua3NcbiAgLy8gdGhlIHZpc3VhbCB3aWR0aCBidXQgaXNuJ3QgcmVmbGVjdGVkIGluIGBodG1sLmNsaWVudFdpZHRoYCwgc28gc3VidHJhY3QgaXQuXG4gIC8vIE9ubHkgdGhlIGlubGluZS1lbmQgKHJpZ2h0KSBndXR0ZXIgY2FuIGhvbGQgdGhlIHNjcm9sbGJhcjsgYGJvdGgtZWRnZXNgIGFsc29cbiAgLy8gcmVzZXJ2ZXMgYW4gZW1wdHkgaW5saW5lLXN0YXJ0IGd1dHRlciB0aGF0IGNsaXBzIG5vdGhpbmcsIHNvIGV4Y2x1ZGUganVzdFxuICAvLyB0aGUgb25lIHNjcm9sbGJhci1zaWRlIGd1dHRlciBcdTIwMTQgaGFsdmUgdGhlIG1lYXN1cmVkICh0d28tZ3V0dGVyKSB0b3RhbC4gQVxuICAvLyBsZWZ0LXNpZGUgc2Nyb2xsYmFyIChgd2luZG93U2Nyb2xsYmFyWCA+IDBgKSBpcyBhbHJlYWR5IGhhbmRsZWQgYnlcbiAgLy8gYGdldEhUTUxPZmZzZXRgL2B2aXN1YWxWaWV3cG9ydC53aWR0aGA7IHNraXAgaXQgaGVyZS5cbiAgaWYgKHdpbmRvd1Njcm9sbGJhclggPD0gMCkge1xuICAgIGNvbnN0IGRvYyA9IGh0bWwub3duZXJEb2N1bWVudDtcbiAgICBjb25zdCBib2R5ID0gZG9jLmJvZHk7XG4gICAgY29uc3QgYm9keVN0eWxlcyA9IGdldENvbXB1dGVkU3R5bGUoYm9keSk7XG4gICAgY29uc3QgYm9keU1hcmdpbklubGluZSA9IGRvYy5jb21wYXRNb2RlID09PSAnQ1NTMUNvbXBhdCcgPyBwYXJzZUZsb2F0KGJvZHlTdHlsZXMubWFyZ2luTGVmdCkgKyBwYXJzZUZsb2F0KGJvZHlTdHlsZXMubWFyZ2luUmlnaHQpIHx8IDAgOiAwO1xuICAgIGNvbnN0IHJlc2VydmVkV2lkdGggPSBNYXRoLmFicyhodG1sLmNsaWVudFdpZHRoIC0gYm9keS5jbGllbnRXaWR0aCAtIGJvZHlNYXJnaW5JbmxpbmUpO1xuICAgIGNvbnN0IGd1dHRlciA9IGdldENvbXB1dGVkU3R5bGUoaHRtbCkuc2Nyb2xsYmFyR3V0dGVyID09PSAnc3RhYmxlIGJvdGgtZWRnZXMnID8gcmVzZXJ2ZWRXaWR0aCAvIDIgOiByZXNlcnZlZFdpZHRoO1xuICAgIGlmIChndXR0ZXIgPD0gU0NST0xMQkFSX01BWCkge1xuICAgICAgd2lkdGggLT0gZ3V0dGVyO1xuICAgIH1cbiAgfVxuICByZXR1cm4ge1xuICAgIHdpZHRoLFxuICAgIGhlaWdodCxcbiAgICB4LFxuICAgIHlcbiAgfTtcbn1cblxuLy8gUmV0dXJucyB0aGUgaW5uZXIgY2xpZW50IHJlY3QsIHN1YnRyYWN0aW5nIHNjcm9sbGJhcnMgaWYgcHJlc2VudC5cbmZ1bmN0aW9uIGdldElubmVyQm91bmRpbmdDbGllbnRSZWN0KGVsZW1lbnQsIHN0cmF0ZWd5KSB7XG4gIGNvbnN0IGNsaWVudFJlY3QgPSBnZXRCb3VuZGluZ0NsaWVudFJlY3QoZWxlbWVudCwgdHJ1ZSwgc3RyYXRlZ3kgPT09ICdmaXhlZCcpO1xuICBjb25zdCB0b3AgPSBjbGllbnRSZWN0LnRvcCArIGVsZW1lbnQuY2xpZW50VG9wO1xuICBjb25zdCBsZWZ0ID0gY2xpZW50UmVjdC5sZWZ0ICsgZWxlbWVudC5jbGllbnRMZWZ0O1xuICBjb25zdCBzY2FsZSA9IGdldFNjYWxlKGVsZW1lbnQpO1xuICBjb25zdCB3aWR0aCA9IGVsZW1lbnQuY2xpZW50V2lkdGggKiBzY2FsZS54O1xuICBjb25zdCBoZWlnaHQgPSBlbGVtZW50LmNsaWVudEhlaWdodCAqIHNjYWxlLnk7XG4gIGNvbnN0IHggPSBsZWZ0ICogc2NhbGUueDtcbiAgY29uc3QgeSA9IHRvcCAqIHNjYWxlLnk7XG4gIHJldHVybiB7XG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0LFxuICAgIHgsXG4gICAgeVxuICB9O1xufVxuZnVuY3Rpb24gZ2V0Q2xpZW50UmVjdEZyb21DbGlwcGluZ0FuY2VzdG9yKGVsZW1lbnQsIGNsaXBwaW5nQW5jZXN0b3IsIHN0cmF0ZWd5KSB7XG4gIGxldCByZWN0O1xuICBpZiAoY2xpcHBpbmdBbmNlc3RvciA9PT0gJ3ZpZXdwb3J0JyB8fCBjbGlwcGluZ0FuY2VzdG9yID09PSAnbGF5b3V0Vmlld3BvcnQnKSB7XG4gICAgcmVjdCA9IGdldFZpZXdwb3J0UmVjdChlbGVtZW50LCBzdHJhdGVneSwgY2xpcHBpbmdBbmNlc3Rvcik7XG4gIH0gZWxzZSBpZiAoY2xpcHBpbmdBbmNlc3RvciA9PT0gJ2RvY3VtZW50Jykge1xuICAgIHJlY3QgPSBnZXREb2N1bWVudFJlY3QoZ2V0RG9jdW1lbnRFbGVtZW50KGVsZW1lbnQpKTtcbiAgfSBlbHNlIGlmIChpc0VsZW1lbnQoY2xpcHBpbmdBbmNlc3RvcikpIHtcbiAgICByZWN0ID0gZ2V0SW5uZXJCb3VuZGluZ0NsaWVudFJlY3QoY2xpcHBpbmdBbmNlc3Rvciwgc3RyYXRlZ3kpO1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IHZpc3VhbE9mZnNldHMgPSBnZXRWaXN1YWxPZmZzZXRzKGVsZW1lbnQpO1xuICAgIHJlY3QgPSB7XG4gICAgICB4OiBjbGlwcGluZ0FuY2VzdG9yLnggLSB2aXN1YWxPZmZzZXRzLngsXG4gICAgICB5OiBjbGlwcGluZ0FuY2VzdG9yLnkgLSB2aXN1YWxPZmZzZXRzLnksXG4gICAgICB3aWR0aDogY2xpcHBpbmdBbmNlc3Rvci53aWR0aCxcbiAgICAgIGhlaWdodDogY2xpcHBpbmdBbmNlc3Rvci5oZWlnaHRcbiAgICB9O1xuICB9XG4gIHJldHVybiByZWN0VG9DbGllbnRSZWN0KHJlY3QpO1xufVxuXG4vLyBBIFwiY2xpcHBpbmcgYW5jZXN0b3JcIiBpcyBhbiBgb3ZlcmZsb3dgIGVsZW1lbnQgd2l0aCB0aGUgY2hhcmFjdGVyaXN0aWMgb2Zcbi8vIGNsaXBwaW5nIChvciBoaWRpbmcpIGNoaWxkIGVsZW1lbnRzLiBUaGlzIHJldHVybnMgYWxsIGNsaXBwaW5nIGFuY2VzdG9yc1xuLy8gb2YgdGhlIGdpdmVuIGVsZW1lbnQgdXAgdGhlIHRyZWUuXG5mdW5jdGlvbiBnZXRDbGlwcGluZ0VsZW1lbnRBbmNlc3RvcnMoZWxlbWVudCwgY2FjaGUpIHtcbiAgY29uc3QgY2FjaGVkUmVzdWx0ID0gY2FjaGUuZ2V0KGVsZW1lbnQpO1xuICBpZiAoY2FjaGVkUmVzdWx0KSB7XG4gICAgcmV0dXJuIGNhY2hlZFJlc3VsdDtcbiAgfVxuICBsZXQgcmVzdWx0ID0gZ2V0T3ZlcmZsb3dBbmNlc3RvcnMoZWxlbWVudCwgW10sIGZhbHNlKS5maWx0ZXIoZWwgPT4gaXNFbGVtZW50KGVsKSAmJiBnZXROb2RlTmFtZShlbCkgIT09ICdib2R5Jyk7XG4gIGxldCBsYXN0S2VwdENvbXB1dGVkU3R5bGUgPSBudWxsO1xuICBjb25zdCBlbGVtZW50SXNGaXhlZCA9IGdldENvbXB1dGVkU3R5bGUkMShlbGVtZW50KS5wb3NpdGlvbiA9PT0gJ2ZpeGVkJztcbiAgbGV0IGN1cnJlbnROb2RlID0gZWxlbWVudElzRml4ZWQgPyBnZXRQYXJlbnROb2RlKGVsZW1lbnQpIDogZWxlbWVudDtcblxuICAvLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9DU1MvQ29udGFpbmluZ19ibG9jayNpZGVudGlmeWluZ190aGVfY29udGFpbmluZ19ibG9ja1xuICB3aGlsZSAoaXNFbGVtZW50KGN1cnJlbnROb2RlKSAmJiAhaXNMYXN0VHJhdmVyc2FibGVOb2RlKGN1cnJlbnROb2RlKSkge1xuICAgIGNvbnN0IGNvbXB1dGVkU3R5bGUgPSBnZXRDb21wdXRlZFN0eWxlJDEoY3VycmVudE5vZGUpO1xuICAgIGNvbnN0IGN1cnJlbnROb2RlSXNDb250YWluaW5nID0gaXNDb250YWluaW5nQmxvY2soY3VycmVudE5vZGUpO1xuICAgIC8vIFBvc2l0aW9uIG9mIHRoZSBjb250YWluaW5nIGJsb2NrIGNoYWluIGJlbG93IHRoZSBjdXJyZW50IG5vZGUuIEEgZml4ZWRcbiAgICAvLyBlbGVtZW50IHdob3NlIGNvbnRhaW5pbmcgYmxvY2sgaGFzbid0IGJlZW4gZm91bmQgeWV0IGlzIGEgZml4ZWQgY2hhaW4uXG4gICAgY29uc3QgbGFzdFBvc2l0aW9uID0gbGFzdEtlcHRDb21wdXRlZFN0eWxlID8gbGFzdEtlcHRDb21wdXRlZFN0eWxlLnBvc2l0aW9uIDogZWxlbWVudElzRml4ZWQgPyAnZml4ZWQnIDogJyc7XG5cbiAgICAvLyBBIG5vbi1jb250YWluaW5nIGFuY2VzdG9yIGRvZXMgbm90IGNsaXAgdGhlIGVsZW1lbnQgd2hlbiB0aGUgY2hhaW5cbiAgICAvLyBiZWxvdyBpdCBlc2NhcGVzIGl0OiBhIGZpeGVkIGNoYWluIGVzY2FwZXMgYWxsIGFuY2VzdG9ycyB1cCB0byB0aGVcbiAgICAvLyBuZXh0IGNvbnRhaW5pbmcgYmxvY2ssIGFuIGFic29sdXRlIGNoYWluIGVzY2FwZXMgc3RhdGljIGFuY2VzdG9ycy5cbiAgICBjb25zdCBzaG91bGREcm9wQ3VycmVudE5vZGUgPSAhY3VycmVudE5vZGVJc0NvbnRhaW5pbmcgJiYgKGxhc3RQb3NpdGlvbiA9PT0gJ2ZpeGVkJyB8fCBsYXN0UG9zaXRpb24gPT09ICdhYnNvbHV0ZScgJiYgY29tcHV0ZWRTdHlsZS5wb3NpdGlvbiA9PT0gJ3N0YXRpYycpO1xuICAgIGlmIChzaG91bGREcm9wQ3VycmVudE5vZGUpIHtcbiAgICAgIC8vIERyb3Agbm9uLWNvbnRhaW5pbmcgYmxvY2tzLlxuICAgICAgcmVzdWx0ID0gcmVzdWx0LmZpbHRlcihhbmNlc3RvciA9PiBhbmNlc3RvciAhPT0gY3VycmVudE5vZGUpO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBUaGUga2VwdCBub2RlIGNhcnJpZXMgdGhlIGNoYWluIHBvc2l0aW9uIGZvciB0aGUgbmV4dCBpdGVyYXRpb24uXG4gICAgICBsYXN0S2VwdENvbXB1dGVkU3R5bGUgPSBjb21wdXRlZFN0eWxlO1xuICAgIH1cbiAgICBjdXJyZW50Tm9kZSA9IGdldFBhcmVudE5vZGUoY3VycmVudE5vZGUpO1xuICB9XG4gIGNhY2hlLnNldChlbGVtZW50LCByZXN1bHQpO1xuICByZXR1cm4gcmVzdWx0O1xufVxuXG4vLyBHZXRzIHRoZSBtYXhpbXVtIGFyZWEgdGhhdCB0aGUgZWxlbWVudCBpcyB2aXNpYmxlIGluIGR1ZSB0byBhbnkgbnVtYmVyIG9mXG4vLyBjbGlwcGluZyBhbmNlc3RvcnMuXG5mdW5jdGlvbiBnZXRDbGlwcGluZ1JlY3QoX3JlZikge1xuICBsZXQge1xuICAgIGVsZW1lbnQsXG4gICAgYm91bmRhcnksXG4gICAgcm9vdEJvdW5kYXJ5LFxuICAgIHN0cmF0ZWd5XG4gIH0gPSBfcmVmO1xuICBjb25zdCBlbGVtZW50Q2xpcHBpbmdBbmNlc3RvcnMgPSBib3VuZGFyeSA9PT0gJ2NsaXBwaW5nQW5jZXN0b3JzJyA/IGlzVG9wTGF5ZXIoZWxlbWVudCkgPyBbXSA6IGdldENsaXBwaW5nRWxlbWVudEFuY2VzdG9ycyhlbGVtZW50LCB0aGlzLl9jKSA6IFtdLmNvbmNhdChib3VuZGFyeSk7XG4gIGNvbnN0IGNsaXBwaW5nQW5jZXN0b3JzID0gWy4uLmVsZW1lbnRDbGlwcGluZ0FuY2VzdG9ycywgcm9vdEJvdW5kYXJ5XTtcbiAgY29uc3QgZmlyc3RSZWN0ID0gZ2V0Q2xpZW50UmVjdEZyb21DbGlwcGluZ0FuY2VzdG9yKGVsZW1lbnQsIGNsaXBwaW5nQW5jZXN0b3JzWzBdLCBzdHJhdGVneSk7XG4gIGxldCB0b3AgPSBmaXJzdFJlY3QudG9wO1xuICBsZXQgcmlnaHQgPSBmaXJzdFJlY3QucmlnaHQ7XG4gIGxldCBib3R0b20gPSBmaXJzdFJlY3QuYm90dG9tO1xuICBsZXQgbGVmdCA9IGZpcnN0UmVjdC5sZWZ0O1xuICBmb3IgKGxldCBpID0gMTsgaSA8IGNsaXBwaW5nQW5jZXN0b3JzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgcmVjdCA9IGdldENsaWVudFJlY3RGcm9tQ2xpcHBpbmdBbmNlc3RvcihlbGVtZW50LCBjbGlwcGluZ0FuY2VzdG9yc1tpXSwgc3RyYXRlZ3kpO1xuICAgIHRvcCA9IG1heChyZWN0LnRvcCwgdG9wKTtcbiAgICByaWdodCA9IG1pbihyZWN0LnJpZ2h0LCByaWdodCk7XG4gICAgYm90dG9tID0gbWluKHJlY3QuYm90dG9tLCBib3R0b20pO1xuICAgIGxlZnQgPSBtYXgocmVjdC5sZWZ0LCBsZWZ0KTtcbiAgfVxuICByZXR1cm4ge1xuICAgIHdpZHRoOiByaWdodCAtIGxlZnQsXG4gICAgaGVpZ2h0OiBib3R0b20gLSB0b3AsXG4gICAgeDogbGVmdCxcbiAgICB5OiB0b3BcbiAgfTtcbn1cblxuZnVuY3Rpb24gZ2V0RGltZW5zaW9ucyhlbGVtZW50KSB7XG4gIGNvbnN0IHtcbiAgICB3aWR0aCxcbiAgICBoZWlnaHRcbiAgfSA9IGdldENzc0RpbWVuc2lvbnMoZWxlbWVudCk7XG4gIHJldHVybiB7XG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0XG4gIH07XG59XG5cbmZ1bmN0aW9uIGdldFJlY3RSZWxhdGl2ZVRvT2Zmc2V0UGFyZW50KGVsZW1lbnQsIG9mZnNldFBhcmVudCwgc3RyYXRlZ3kpIHtcbiAgY29uc3QgaXNPZmZzZXRQYXJlbnRBbkVsZW1lbnQgPSBpc0hUTUxFbGVtZW50KG9mZnNldFBhcmVudCk7XG4gIGNvbnN0IGRvY3VtZW50RWxlbWVudCA9IGdldERvY3VtZW50RWxlbWVudChvZmZzZXRQYXJlbnQpO1xuICBjb25zdCBpc0ZpeGVkID0gc3RyYXRlZ3kgPT09ICdmaXhlZCc7XG4gIGNvbnN0IHJlY3QgPSBnZXRCb3VuZGluZ0NsaWVudFJlY3QoZWxlbWVudCwgdHJ1ZSwgaXNGaXhlZCwgb2Zmc2V0UGFyZW50KTtcbiAgbGV0IHNjcm9sbCA9IHtcbiAgICBzY3JvbGxMZWZ0OiAwLFxuICAgIHNjcm9sbFRvcDogMFxuICB9O1xuICBjb25zdCBvZmZzZXRzID0gY3JlYXRlQ29vcmRzKDApO1xuICBpZiAoaXNPZmZzZXRQYXJlbnRBbkVsZW1lbnQgfHwgIWlzRml4ZWQpIHtcbiAgICBpZiAoZ2V0Tm9kZU5hbWUob2Zmc2V0UGFyZW50KSAhPT0gJ2JvZHknIHx8IGlzT3ZlcmZsb3dFbGVtZW50KGRvY3VtZW50RWxlbWVudCkpIHtcbiAgICAgIHNjcm9sbCA9IGdldE5vZGVTY3JvbGwob2Zmc2V0UGFyZW50KTtcbiAgICB9XG4gICAgaWYgKGlzT2Zmc2V0UGFyZW50QW5FbGVtZW50KSB7XG4gICAgICBjb25zdCBvZmZzZXRSZWN0ID0gZ2V0Qm91bmRpbmdDbGllbnRSZWN0KG9mZnNldFBhcmVudCwgdHJ1ZSwgaXNGaXhlZCwgb2Zmc2V0UGFyZW50KTtcbiAgICAgIG9mZnNldHMueCA9IG9mZnNldFJlY3QueCArIG9mZnNldFBhcmVudC5jbGllbnRMZWZ0O1xuICAgICAgb2Zmc2V0cy55ID0gb2Zmc2V0UmVjdC55ICsgb2Zmc2V0UGFyZW50LmNsaWVudFRvcDtcbiAgICB9XG4gIH1cblxuICAvLyBJZiB0aGUgPGJvZHk+IHNjcm9sbGJhciBhcHBlYXJzIG9uIHRoZSBsZWZ0IChlLmcuIFJUTCBzeXN0ZW1zKS4gVXNlXG4gIC8vIEZpcmVmb3ggd2l0aCBsYXlvdXQuc2Nyb2xsYmFyLnNpZGUgPSAzIGluIGFib3V0OmNvbmZpZyB0byB0ZXN0IHRoaXMuXG4gIGlmICghaXNPZmZzZXRQYXJlbnRBbkVsZW1lbnQgJiYgZG9jdW1lbnRFbGVtZW50KSB7XG4gICAgb2Zmc2V0cy54ID0gZ2V0V2luZG93U2Nyb2xsQmFyWChkb2N1bWVudEVsZW1lbnQpO1xuICB9XG4gIGNvbnN0IGh0bWxPZmZzZXQgPSBkb2N1bWVudEVsZW1lbnQgJiYgIWlzT2Zmc2V0UGFyZW50QW5FbGVtZW50ICYmICFpc0ZpeGVkID8gZ2V0SFRNTE9mZnNldChkb2N1bWVudEVsZW1lbnQsIHNjcm9sbCkgOiBjcmVhdGVDb29yZHMoMCk7XG4gIGNvbnN0IHggPSByZWN0LmxlZnQgKyBzY3JvbGwuc2Nyb2xsTGVmdCAtIG9mZnNldHMueCAtIGh0bWxPZmZzZXQueDtcbiAgY29uc3QgeSA9IHJlY3QudG9wICsgc2Nyb2xsLnNjcm9sbFRvcCAtIG9mZnNldHMueSAtIGh0bWxPZmZzZXQueTtcbiAgcmV0dXJuIHtcbiAgICB4LFxuICAgIHksXG4gICAgd2lkdGg6IHJlY3Qud2lkdGgsXG4gICAgaGVpZ2h0OiByZWN0LmhlaWdodFxuICB9O1xufVxuXG5mdW5jdGlvbiBpc1N0YXRpY1Bvc2l0aW9uZWQoZWxlbWVudCkge1xuICByZXR1cm4gZ2V0Q29tcHV0ZWRTdHlsZSQxKGVsZW1lbnQpLnBvc2l0aW9uID09PSAnc3RhdGljJztcbn1cblxuZnVuY3Rpb24gZ2V0VHJ1ZU9mZnNldFBhcmVudChlbGVtZW50LCBwb2x5ZmlsbCkge1xuICBpZiAoIWlzSFRNTEVsZW1lbnQoZWxlbWVudCkgfHwgZ2V0Q29tcHV0ZWRTdHlsZSQxKGVsZW1lbnQpLnBvc2l0aW9uID09PSAnZml4ZWQnKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgaWYgKHBvbHlmaWxsKSB7XG4gICAgcmV0dXJuIHBvbHlmaWxsKGVsZW1lbnQpO1xuICB9XG4gIGxldCByYXdPZmZzZXRQYXJlbnQgPSBlbGVtZW50Lm9mZnNldFBhcmVudDtcblxuICAvLyBGaXJlZm94IHJldHVybnMgdGhlIDxodG1sPiBlbGVtZW50IGFzIHRoZSBvZmZzZXRQYXJlbnQgaWYgaXQncyBub24tc3RhdGljLFxuICAvLyB3aGlsZSBDaHJvbWUgYW5kIFNhZmFyaSByZXR1cm4gdGhlIDxib2R5PiBlbGVtZW50LiBUaGUgPGJvZHk+IGVsZW1lbnQgbXVzdFxuICAvLyBiZSB1c2VkIHRvIHBlcmZvcm0gdGhlIGNvcnJlY3QgY2FsY3VsYXRpb25zIGV2ZW4gaWYgdGhlIDxodG1sPiBlbGVtZW50IGlzXG4gIC8vIG5vbi1zdGF0aWMuXG4gIGlmIChnZXREb2N1bWVudEVsZW1lbnQoZWxlbWVudCkgPT09IHJhd09mZnNldFBhcmVudCkge1xuICAgIHJhd09mZnNldFBhcmVudCA9IHJhd09mZnNldFBhcmVudC5vd25lckRvY3VtZW50LmJvZHk7XG4gIH1cbiAgcmV0dXJuIHJhd09mZnNldFBhcmVudDtcbn1cblxuLy8gR2V0cyB0aGUgY2xvc2VzdCBhbmNlc3RvciBwb3NpdGlvbmVkIGVsZW1lbnQuIEhhbmRsZXMgc29tZSBlZGdlIGNhc2VzLFxuLy8gc3VjaCBhcyB0YWJsZSBhbmNlc3RvcnMgYW5kIGNyb3NzIGJyb3dzZXIgYnVncy5cbmZ1bmN0aW9uIGdldE9mZnNldFBhcmVudChlbGVtZW50LCBwb2x5ZmlsbCkge1xuICBjb25zdCB3aW4gPSBnZXRXaW5kb3coZWxlbWVudCk7XG4gIGlmIChpc1RvcExheWVyKGVsZW1lbnQpKSB7XG4gICAgcmV0dXJuIHdpbjtcbiAgfVxuICBpZiAoIWlzSFRNTEVsZW1lbnQoZWxlbWVudCkpIHtcbiAgICBsZXQgc3ZnT2Zmc2V0UGFyZW50ID0gZ2V0UGFyZW50Tm9kZShlbGVtZW50KTtcbiAgICB3aGlsZSAoc3ZnT2Zmc2V0UGFyZW50ICYmICFpc0xhc3RUcmF2ZXJzYWJsZU5vZGUoc3ZnT2Zmc2V0UGFyZW50KSkge1xuICAgICAgaWYgKGlzRWxlbWVudChzdmdPZmZzZXRQYXJlbnQpICYmICFpc1N0YXRpY1Bvc2l0aW9uZWQoc3ZnT2Zmc2V0UGFyZW50KSkge1xuICAgICAgICByZXR1cm4gc3ZnT2Zmc2V0UGFyZW50O1xuICAgICAgfVxuICAgICAgc3ZnT2Zmc2V0UGFyZW50ID0gZ2V0UGFyZW50Tm9kZShzdmdPZmZzZXRQYXJlbnQpO1xuICAgIH1cbiAgICByZXR1cm4gd2luO1xuICB9XG4gIGxldCBvZmZzZXRQYXJlbnQgPSBnZXRUcnVlT2Zmc2V0UGFyZW50KGVsZW1lbnQsIHBvbHlmaWxsKTtcbiAgd2hpbGUgKG9mZnNldFBhcmVudCAmJiBpc1RhYmxlRWxlbWVudChvZmZzZXRQYXJlbnQpICYmIGlzU3RhdGljUG9zaXRpb25lZChvZmZzZXRQYXJlbnQpKSB7XG4gICAgb2Zmc2V0UGFyZW50ID0gZ2V0VHJ1ZU9mZnNldFBhcmVudChvZmZzZXRQYXJlbnQsIHBvbHlmaWxsKTtcbiAgfVxuICBpZiAob2Zmc2V0UGFyZW50ICYmIGlzTGFzdFRyYXZlcnNhYmxlTm9kZShvZmZzZXRQYXJlbnQpICYmIGlzU3RhdGljUG9zaXRpb25lZChvZmZzZXRQYXJlbnQpICYmICFpc0NvbnRhaW5pbmdCbG9jayhvZmZzZXRQYXJlbnQpKSB7XG4gICAgcmV0dXJuIHdpbjtcbiAgfVxuICByZXR1cm4gb2Zmc2V0UGFyZW50IHx8IGdldENvbnRhaW5pbmdCbG9jayhlbGVtZW50KSB8fCB3aW47XG59XG5cbmNvbnN0IGdldEVsZW1lbnRSZWN0cyA9IGFzeW5jIGZ1bmN0aW9uIChkYXRhKSB7XG4gIGNvbnN0IGdldE9mZnNldFBhcmVudEZuID0gdGhpcy5nZXRPZmZzZXRQYXJlbnQgfHwgZ2V0T2Zmc2V0UGFyZW50O1xuICBjb25zdCBnZXREaW1lbnNpb25zRm4gPSB0aGlzLmdldERpbWVuc2lvbnM7XG4gIGNvbnN0IGZsb2F0aW5nRGltZW5zaW9ucyA9IGF3YWl0IGdldERpbWVuc2lvbnNGbihkYXRhLmZsb2F0aW5nKTtcbiAgcmV0dXJuIHtcbiAgICByZWZlcmVuY2U6IGdldFJlY3RSZWxhdGl2ZVRvT2Zmc2V0UGFyZW50KGRhdGEucmVmZXJlbmNlLCBhd2FpdCBnZXRPZmZzZXRQYXJlbnRGbihkYXRhLmZsb2F0aW5nKSwgZGF0YS5zdHJhdGVneSksXG4gICAgZmxvYXRpbmc6IHtcbiAgICAgIHg6IDAsXG4gICAgICB5OiAwLFxuICAgICAgd2lkdGg6IGZsb2F0aW5nRGltZW5zaW9ucy53aWR0aCxcbiAgICAgIGhlaWdodDogZmxvYXRpbmdEaW1lbnNpb25zLmhlaWdodFxuICAgIH1cbiAgfTtcbn07XG5cbmZ1bmN0aW9uIGlzUlRMKGVsZW1lbnQpIHtcbiAgcmV0dXJuIGdldENvbXB1dGVkU3R5bGUkMShlbGVtZW50KS5kaXJlY3Rpb24gPT09ICdydGwnO1xufVxuXG5jb25zdCBwbGF0Zm9ybSA9IHtcbiAgY29udmVydE9mZnNldFBhcmVudFJlbGF0aXZlUmVjdFRvVmlld3BvcnRSZWxhdGl2ZVJlY3QsXG4gIGdldERvY3VtZW50RWxlbWVudCxcbiAgZ2V0Q2xpcHBpbmdSZWN0LFxuICBnZXRPZmZzZXRQYXJlbnQsXG4gIGdldEVsZW1lbnRSZWN0cyxcbiAgZ2V0Q2xpZW50UmVjdHMsXG4gIGdldERpbWVuc2lvbnMsXG4gIGdldFNjYWxlLFxuICBpc0VsZW1lbnQsXG4gIGlzUlRMXG59O1xuXG5mdW5jdGlvbiByZWN0c0FyZUVxdWFsKGEsIGIpIHtcbiAgcmV0dXJuIGEueCA9PT0gYi54ICYmIGEueSA9PT0gYi55ICYmIGEud2lkdGggPT09IGIud2lkdGggJiYgYS5oZWlnaHQgPT09IGIuaGVpZ2h0O1xufVxuXG4vLyBodHRwczovL3NhbXRob3IuYXUvMjAyMS9vYnNlcnZpbmctZG9tL1xuZnVuY3Rpb24gb2JzZXJ2ZU1vdmUoZWxlbWVudCwgb25Nb3ZlLCBhbmNlc3RvclJlc2l6ZSkge1xuICBsZXQgaW8gPSBudWxsO1xuICBsZXQgdGltZW91dElkO1xuICBjb25zdCByb290ID0gZ2V0RG9jdW1lbnRFbGVtZW50KGVsZW1lbnQpO1xuICBmdW5jdGlvbiBjbGVhbnVwKCkge1xuICAgIHZhciBfaW87XG4gICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG4gICAgKF9pbyA9IGlvKSA9PSBudWxsIHx8IF9pby5kaXNjb25uZWN0KCk7XG4gICAgaW8gPSBudWxsO1xuICB9XG4gIGZ1bmN0aW9uIHJlZnJlc2goc2tpcCwgdGhyZXNob2xkKSB7XG4gICAgaWYgKHNraXAgPT09IHZvaWQgMCkge1xuICAgICAgc2tpcCA9IGZhbHNlO1xuICAgIH1cbiAgICBpZiAodGhyZXNob2xkID09PSB2b2lkIDApIHtcbiAgICAgIHRocmVzaG9sZCA9IDE7XG4gICAgfVxuICAgIGNsZWFudXAoKTtcbiAgICBjb25zdCBlbGVtZW50UmVjdEZvclJvb3RNYXJnaW4gPSBlbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGNvbnN0IHtcbiAgICAgIGxlZnQsXG4gICAgICB0b3AsXG4gICAgICB3aWR0aCxcbiAgICAgIGhlaWdodFxuICAgIH0gPSBlbGVtZW50UmVjdEZvclJvb3RNYXJnaW47XG4gICAgaWYgKCFza2lwKSB7XG4gICAgICBvbk1vdmUoKTtcbiAgICB9XG4gICAgaWYgKCF3aWR0aCB8fCAhaGVpZ2h0KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGluc2V0VG9wID0gZmxvb3IodG9wKTtcbiAgICBjb25zdCBpbnNldFJpZ2h0ID0gZmxvb3Iocm9vdC5jbGllbnRXaWR0aCAtIChsZWZ0ICsgd2lkdGgpKTtcbiAgICBjb25zdCBpbnNldEJvdHRvbSA9IGZsb29yKHJvb3QuY2xpZW50SGVpZ2h0IC0gKHRvcCArIGhlaWdodCkpO1xuICAgIGNvbnN0IGluc2V0TGVmdCA9IGZsb29yKGxlZnQpO1xuICAgIGNvbnN0IHJvb3RNYXJnaW4gPSAtaW5zZXRUb3AgKyBcInB4IFwiICsgLWluc2V0UmlnaHQgKyBcInB4IFwiICsgLWluc2V0Qm90dG9tICsgXCJweCBcIiArIC1pbnNldExlZnQgKyBcInB4XCI7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgIHJvb3RNYXJnaW4sXG4gICAgICB0aHJlc2hvbGQ6IG1heCgwLCBtaW4oMSwgdGhyZXNob2xkKSkgfHwgMVxuICAgIH07XG4gICAgbGV0IGlzRmlyc3RVcGRhdGUgPSB0cnVlO1xuICAgIGZ1bmN0aW9uIGhhbmRsZU9ic2VydmUoZW50cmllcykge1xuICAgICAgY29uc3QgcmF0aW8gPSBlbnRyaWVzWzBdLmludGVyc2VjdGlvblJhdGlvO1xuXG4gICAgICAvLyBUaGUgZW50cnkgaXMgYSBzbmFwc2hvdCwgc28gdGhlIHJlZmVyZW5jZSBtYXkgaGF2ZSBtb3ZlZCBzaW5jZSB0aGVcbiAgICAgIC8vIGludGVyc2VjdGlvbiB3YXMgY29tcHV0ZWQgKHVuZGVyIHBlcmZvcm1hbmNlIGNvbnN0cmFpbnRzLCBvciBiZXR3ZWVuXG4gICAgICAvLyBjb25zZWN1dGl2ZSBmcmFtZXMgb2YgYSBtdWx0aS1mcmFtZSBsYXlvdXQgc2hpZnQpLiBUaGUgcmVwb3J0ZWQgcmF0aW9cbiAgICAgIC8vIGFuZCB0aGUgb2JzZXJ2ZWQgYXJlYSBhcmUgc3RhbGUgaW4gdGhhdCBjYXNlIGFuZCBjYW5ub3QgYmUgdHJ1c3RlZCB0b1xuICAgICAgLy8gZGV0ZWN0IHN1YnNlcXVlbnQgbW92ZW1lbnQsIHNvIHJlZnJlc2ggcmVnYXJkbGVzcyBvZiB0aGUgcmF0aW8uXG4gICAgICBpZiAoIXJlY3RzQXJlRXF1YWwoZWxlbWVudFJlY3RGb3JSb290TWFyZ2luLCBlbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpKSkge1xuICAgICAgICByZXR1cm4gcmVmcmVzaCgpO1xuICAgICAgfVxuICAgICAgaWYgKHJhdGlvICE9PSB0aHJlc2hvbGQpIHtcbiAgICAgICAgaWYgKCFpc0ZpcnN0VXBkYXRlKSB7XG4gICAgICAgICAgcmV0dXJuIHJlZnJlc2goKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXJhdGlvKSB7XG4gICAgICAgICAgLy8gSWYgdGhlIHJlZmVyZW5jZSBpcyBjbGlwcGVkIGluIHBsYWNlLCB0aGUgcmF0aW8gaXMgMC4gVGhyb3R0bGVcbiAgICAgICAgICAvLyB0aGUgcmVmcmVzaCB0byBwcmV2ZW50IGFuIGluZmluaXRlIGxvb3Agb2YgdXBkYXRlcy5cbiAgICAgICAgICB0aW1lb3V0SWQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIHJlZnJlc2goZmFsc2UsIDFlLTcpO1xuICAgICAgICAgIH0sIDEwMDApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlZnJlc2goZmFsc2UsIHJhdGlvKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaXNGaXJzdFVwZGF0ZSA9IGZhbHNlO1xuICAgIH1cblxuICAgIC8vIE9sZGVyIGJyb3dzZXJzIGRvbid0IHN1cHBvcnQgYSBgZG9jdW1lbnRgIGFzIHRoZSByb290IGFuZCB3aWxsIHRocm93IGFuXG4gICAgLy8gZXJyb3IuXG4gICAgdHJ5IHtcbiAgICAgIGlvID0gbmV3IEludGVyc2VjdGlvbk9ic2VydmVyKGhhbmRsZU9ic2VydmUsIHtcbiAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgLy8gSGFuZGxlIDxpZnJhbWU+c1xuICAgICAgICByb290OiByb290Lm93bmVyRG9jdW1lbnRcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKF9lKSB7XG4gICAgICBpbyA9IG5ldyBJbnRlcnNlY3Rpb25PYnNlcnZlcihoYW5kbGVPYnNlcnZlLCBvcHRpb25zKTtcbiAgICB9XG4gICAgaW8ub2JzZXJ2ZShlbGVtZW50KTtcbiAgfVxuICBjb25zdCB3aW4gPSBnZXRXaW5kb3coZWxlbWVudCk7XG4gIC8vIFRoZSB3aW5kb3cgaXMgYSByZXNpemUgYW5jZXN0b3IsIHNvIHdoZW4gYGFuY2VzdG9yUmVzaXplYCBpcyBlbmFibGVkIGl0c1xuICAvLyBsaXN0ZW5lciBhbHJlYWR5IHJ1bnMgdGhlIHVwZGF0ZSBvbiByZXNpemUuIEhlcmUgd2Ugb25seSBuZWVkIHRvIHJlYnVpbGRcbiAgLy8gdGhlIGBJbnRlcnNlY3Rpb25PYnNlcnZlcmAgZm9yIHRoZSBuZXcgcm9vdCBzaXplLCBza2lwcGluZyBhIHJlZHVuZGFudFxuICAvLyB1cGRhdGUuIFdoZW4gYGFuY2VzdG9yUmVzaXplYCBpcyBkaXNhYmxlZCwgdGhpcyBiZWNvbWVzIHRoZSBzb2xlIHVwZGF0ZS5cbiAgY29uc3QgaGFuZGxlUmVzaXplID0gKCkgPT4gcmVmcmVzaChhbmNlc3RvclJlc2l6ZSk7XG4gIHdpbi5hZGRFdmVudExpc3RlbmVyKCdyZXNpemUnLCBoYW5kbGVSZXNpemUpO1xuICByZWZyZXNoKHRydWUpO1xuICByZXR1cm4gKCkgPT4ge1xuICAgIHdpbi5yZW1vdmVFdmVudExpc3RlbmVyKCdyZXNpemUnLCBoYW5kbGVSZXNpemUpO1xuICAgIGNsZWFudXAoKTtcbiAgfTtcbn1cblxuLyoqXG4gKiBBdXRvbWF0aWNhbGx5IHVwZGF0ZXMgdGhlIHBvc2l0aW9uIG9mIHRoZSBmbG9hdGluZyBlbGVtZW50IHdoZW4gbmVjZXNzYXJ5LlxuICogU2hvdWxkIG9ubHkgYmUgY2FsbGVkIHdoZW4gdGhlIGZsb2F0aW5nIGVsZW1lbnQgaXMgbW91bnRlZCBvbiB0aGUgRE9NIG9yXG4gKiB2aXNpYmxlIG9uIHRoZSBzY3JlZW4uXG4gKiBAcmV0dXJucyBjbGVhbnVwIGZ1bmN0aW9uIHRoYXQgc2hvdWxkIGJlIGludm9rZWQgd2hlbiB0aGUgZmxvYXRpbmcgZWxlbWVudCBpc1xuICogcmVtb3ZlZCBmcm9tIHRoZSBET00gb3IgaGlkZGVuIGZyb20gdGhlIHNjcmVlbi5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9hdXRvVXBkYXRlXG4gKi9cbmZ1bmN0aW9uIGF1dG9VcGRhdGUocmVmZXJlbmNlLCBmbG9hdGluZywgdXBkYXRlLCBvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cbiAgY29uc3Qge1xuICAgIGFuY2VzdG9yU2Nyb2xsID0gdHJ1ZSxcbiAgICBhbmNlc3RvclJlc2l6ZSA9IHRydWUsXG4gICAgZWxlbWVudFJlc2l6ZSA9IHR5cGVvZiBSZXNpemVPYnNlcnZlciA9PT0gJ2Z1bmN0aW9uJyxcbiAgICBsYXlvdXRTaGlmdCA9IHR5cGVvZiBJbnRlcnNlY3Rpb25PYnNlcnZlciA9PT0gJ2Z1bmN0aW9uJyxcbiAgICBhbmltYXRpb25GcmFtZSA9IGZhbHNlXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCByZWZlcmVuY2VFbCA9IHVud3JhcEVsZW1lbnQocmVmZXJlbmNlKTtcbiAgY29uc3QgYW5jZXN0b3JzID0gYW5jZXN0b3JTY3JvbGwgfHwgYW5jZXN0b3JSZXNpemUgPyBbLi4uKHJlZmVyZW5jZUVsID8gZ2V0T3ZlcmZsb3dBbmNlc3RvcnMocmVmZXJlbmNlRWwpIDogW10pLCAuLi4oZmxvYXRpbmcgPyBnZXRPdmVyZmxvd0FuY2VzdG9ycyhmbG9hdGluZykgOiBbXSldIDogW107XG4gIGFuY2VzdG9ycy5mb3JFYWNoKGFuY2VzdG9yID0+IHtcbiAgICBhbmNlc3RvclNjcm9sbCAmJiBhbmNlc3Rvci5hZGRFdmVudExpc3RlbmVyKCdzY3JvbGwnLCB1cGRhdGUpO1xuICAgIGFuY2VzdG9yUmVzaXplICYmIGFuY2VzdG9yLmFkZEV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHVwZGF0ZSk7XG4gIH0pO1xuICBjb25zdCBjbGVhbnVwSW8gPSByZWZlcmVuY2VFbCAmJiBsYXlvdXRTaGlmdCA/IG9ic2VydmVNb3ZlKHJlZmVyZW5jZUVsLCB1cGRhdGUsIGFuY2VzdG9yUmVzaXplKSA6IG51bGw7XG4gIGxldCByZW9ic2VydmVGcmFtZSA9IC0xO1xuICBsZXQgcmVzaXplT2JzZXJ2ZXIgPSBudWxsO1xuICBpZiAoZWxlbWVudFJlc2l6ZSkge1xuICAgIHJlc2l6ZU9ic2VydmVyID0gbmV3IFJlc2l6ZU9ic2VydmVyKF9yZWYgPT4ge1xuICAgICAgbGV0IFtmaXJzdEVudHJ5XSA9IF9yZWY7XG4gICAgICBpZiAoZmlyc3RFbnRyeSAmJiBmaXJzdEVudHJ5LnRhcmdldCA9PT0gcmVmZXJlbmNlRWwgJiYgcmVzaXplT2JzZXJ2ZXIgJiYgZmxvYXRpbmcpIHtcbiAgICAgICAgLy8gUHJldmVudCB1cGRhdGUgbG9vcHMgd2hlbiB1c2luZyB0aGUgYHNpemVgIG1pZGRsZXdhcmUuXG4gICAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9mbG9hdGluZy11aS9mbG9hdGluZy11aS9pc3N1ZXMvMTc0MFxuICAgICAgICByZXNpemVPYnNlcnZlci51bm9ic2VydmUoZmxvYXRpbmcpO1xuICAgICAgICBjYW5jZWxBbmltYXRpb25GcmFtZShyZW9ic2VydmVGcmFtZSk7XG4gICAgICAgIHJlb2JzZXJ2ZUZyYW1lID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHtcbiAgICAgICAgICB2YXIgX3Jlc2l6ZU9ic2VydmVyO1xuICAgICAgICAgIChfcmVzaXplT2JzZXJ2ZXIgPSByZXNpemVPYnNlcnZlcikgPT0gbnVsbCB8fCBfcmVzaXplT2JzZXJ2ZXIub2JzZXJ2ZShmbG9hdGluZyk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgdXBkYXRlKCk7XG4gICAgfSk7XG4gICAgaWYgKHJlZmVyZW5jZUVsICYmICFhbmltYXRpb25GcmFtZSkge1xuICAgICAgcmVzaXplT2JzZXJ2ZXIub2JzZXJ2ZShyZWZlcmVuY2VFbCk7XG4gICAgfVxuICAgIGlmIChmbG9hdGluZykge1xuICAgICAgcmVzaXplT2JzZXJ2ZXIub2JzZXJ2ZShmbG9hdGluZyk7XG4gICAgfVxuICB9XG4gIGxldCBmcmFtZUlkO1xuICBsZXQgcHJldlJlZlJlY3QgPSBhbmltYXRpb25GcmFtZSA/IGdldEJvdW5kaW5nQ2xpZW50UmVjdChyZWZlcmVuY2UpIDogbnVsbDtcbiAgaWYgKGFuaW1hdGlvbkZyYW1lKSB7XG4gICAgZnJhbWVMb29wKCk7XG4gIH1cbiAgZnVuY3Rpb24gZnJhbWVMb29wKCkge1xuICAgIGNvbnN0IG5leHRSZWZSZWN0ID0gZ2V0Qm91bmRpbmdDbGllbnRSZWN0KHJlZmVyZW5jZSk7XG4gICAgaWYgKHByZXZSZWZSZWN0ICYmICFyZWN0c0FyZUVxdWFsKHByZXZSZWZSZWN0LCBuZXh0UmVmUmVjdCkpIHtcbiAgICAgIHVwZGF0ZSgpO1xuICAgIH1cbiAgICBwcmV2UmVmUmVjdCA9IG5leHRSZWZSZWN0O1xuICAgIGZyYW1lSWQgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoZnJhbWVMb29wKTtcbiAgfVxuICB1cGRhdGUoKTtcbiAgcmV0dXJuICgpID0+IHtcbiAgICB2YXIgX3Jlc2l6ZU9ic2VydmVyMjtcbiAgICBhbmNlc3RvcnMuZm9yRWFjaChhbmNlc3RvciA9PiB7XG4gICAgICBhbmNlc3RvclNjcm9sbCAmJiBhbmNlc3Rvci5yZW1vdmVFdmVudExpc3RlbmVyKCdzY3JvbGwnLCB1cGRhdGUpO1xuICAgICAgYW5jZXN0b3JSZXNpemUgJiYgYW5jZXN0b3IucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgdXBkYXRlKTtcbiAgICB9KTtcbiAgICBjbGVhbnVwSW8gPT0gbnVsbCB8fCBjbGVhbnVwSW8oKTtcbiAgICAoX3Jlc2l6ZU9ic2VydmVyMiA9IHJlc2l6ZU9ic2VydmVyKSA9PSBudWxsIHx8IF9yZXNpemVPYnNlcnZlcjIuZGlzY29ubmVjdCgpO1xuICAgIHJlc2l6ZU9ic2VydmVyID0gbnVsbDtcbiAgICBpZiAoYW5pbWF0aW9uRnJhbWUpIHtcbiAgICAgIGNhbmNlbEFuaW1hdGlvbkZyYW1lKGZyYW1lSWQpO1xuICAgIH1cbiAgfTtcbn1cblxuLyoqXG4gKiBSZXNvbHZlcyB3aXRoIGFuIG9iamVjdCBvZiBvdmVyZmxvdyBzaWRlIG9mZnNldHMgdGhhdCBkZXRlcm1pbmUgaG93IG11Y2ggdGhlXG4gKiBlbGVtZW50IGlzIG92ZXJmbG93aW5nIGEgZ2l2ZW4gY2xpcHBpbmcgYm91bmRhcnkgb24gZWFjaCBzaWRlLlxuICogLSBwb3NpdGl2ZSA9IG92ZXJmbG93aW5nIHRoZSBib3VuZGFyeSBieSB0aGF0IG51bWJlciBvZiBwaXhlbHNcbiAqIC0gbmVnYXRpdmUgPSBob3cgbWFueSBwaXhlbHMgbGVmdCBiZWZvcmUgaXQgd2lsbCBvdmVyZmxvd1xuICogLSAwID0gbGllcyBmbHVzaCB3aXRoIHRoZSBib3VuZGFyeVxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2RldGVjdE92ZXJmbG93XG4gKi9cbmNvbnN0IGRldGVjdE92ZXJmbG93ID0gZGV0ZWN0T3ZlcmZsb3ckMTtcblxuLyoqXG4gKiBNb2RpZmllcyB0aGUgcGxhY2VtZW50IGJ5IHRyYW5zbGF0aW5nIHRoZSBmbG9hdGluZyBlbGVtZW50IGFsb25nIHRoZVxuICogc3BlY2lmaWVkIGF4ZXMuXG4gKiBBIG51bWJlciAoc2hvcnRoYW5kIGZvciBgbWFpbkF4aXNgIG9yIGRpc3RhbmNlKSwgb3IgYW4gYXhlcyBjb25maWd1cmF0aW9uXG4gKiBvYmplY3QgbWF5IGJlIHBhc3NlZC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9vZmZzZXRcbiAqL1xuY29uc3Qgb2Zmc2V0ID0gb2Zmc2V0JDE7XG5cbi8qKlxuICogT3B0aW1pemVzIHRoZSB2aXNpYmlsaXR5IG9mIHRoZSBmbG9hdGluZyBlbGVtZW50IGJ5IGNob29zaW5nIHRoZSBwbGFjZW1lbnRcbiAqIHRoYXQgaGFzIHRoZSBtb3N0IHNwYWNlIGF2YWlsYWJsZSBhdXRvbWF0aWNhbGx5LCB3aXRob3V0IG5lZWRpbmcgdG8gc3BlY2lmeSBhXG4gKiBwcmVmZXJyZWQgcGxhY2VtZW50LiBBbHRlcm5hdGl2ZSB0byBgZmxpcGAuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvYXV0b1BsYWNlbWVudFxuICovXG5jb25zdCBhdXRvUGxhY2VtZW50ID0gYXV0b1BsYWNlbWVudCQxO1xuXG4vKipcbiAqIE9wdGltaXplcyB0aGUgdmlzaWJpbGl0eSBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBieSBzaGlmdGluZyBpdCBpbiBvcmRlciB0b1xuICoga2VlcCBpdCBpbiB2aWV3IHdoZW4gaXQgd2lsbCBvdmVyZmxvdyB0aGUgY2xpcHBpbmcgYm91bmRhcnkuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3Mvc2hpZnRcbiAqL1xuY29uc3Qgc2hpZnQgPSBzaGlmdCQxO1xuXG4vKipcbiAqIE9wdGltaXplcyB0aGUgdmlzaWJpbGl0eSBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBieSBmbGlwcGluZyB0aGUgYHBsYWNlbWVudGBcbiAqIGluIG9yZGVyIHRvIGtlZXAgaXQgaW4gdmlldyB3aGVuIHRoZSBwcmVmZXJyZWQgcGxhY2VtZW50KHMpIHdpbGwgb3ZlcmZsb3cgdGhlXG4gKiBjbGlwcGluZyBib3VuZGFyeS4gQWx0ZXJuYXRpdmUgdG8gYGF1dG9QbGFjZW1lbnRgLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2ZsaXBcbiAqL1xuY29uc3QgZmxpcCA9IGZsaXAkMTtcblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRoYXQgYWxsb3dzIHlvdSB0byBjaGFuZ2UgdGhlIHNpemUgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQgXHUyMDE0XG4gKiBmb3IgaW5zdGFuY2UsIHByZXZlbnQgaXQgZnJvbSBvdmVyZmxvd2luZyB0aGUgY2xpcHBpbmcgYm91bmRhcnkgb3IgbWF0Y2ggdGhlXG4gKiB3aWR0aCBvZiB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3Mvc2l6ZVxuICovXG5jb25zdCBzaXplID0gc2l6ZSQxO1xuXG4vKipcbiAqIFByb3ZpZGVzIGRhdGEgdG8gaGlkZSB0aGUgZmxvYXRpbmcgZWxlbWVudCBpbiBhcHBsaWNhYmxlIHNpdHVhdGlvbnMsIHN1Y2ggYXNcbiAqIHdoZW4gaXQgaXMgbm90IGluIHRoZSBzYW1lIGNsaXBwaW5nIGNvbnRleHQgYXMgdGhlIHJlZmVyZW5jZSBlbGVtZW50LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2hpZGVcbiAqL1xuY29uc3QgaGlkZSA9IGhpZGUkMTtcblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRvIHBvc2l0aW9uIGFuIGlubmVyIGVsZW1lbnQgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQgc28gdGhhdCBpdFxuICogYXBwZWFycyBjZW50ZXJlZCB0byB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvYXJyb3dcbiAqL1xuY29uc3QgYXJyb3cgPSBhcnJvdyQxO1xuXG4vKipcbiAqIFByb3ZpZGVzIGltcHJvdmVkIHBvc2l0aW9uaW5nIGZvciBpbmxpbmUgcmVmZXJlbmNlIGVsZW1lbnRzIHRoYXQgY2FuIHNwYW5cbiAqIG92ZXIgbXVsdGlwbGUgbGluZXMsIHN1Y2ggYXMgaHlwZXJsaW5rcyBvciByYW5nZSBzZWxlY3Rpb25zLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2lubGluZVxuICovXG5jb25zdCBpbmxpbmUgPSBpbmxpbmUkMTtcblxuLyoqXG4gKiBCdWlsdC1pbiBgbGltaXRlcmAgdGhhdCB3aWxsIHN0b3AgYHNoaWZ0KClgIGF0IGEgY2VydGFpbiBwb2ludC5cbiAqL1xuY29uc3QgbGltaXRTaGlmdCA9IGxpbWl0U2hpZnQkMTtcblxuLyoqXG4gKiBDb21wdXRlcyB0aGUgYHhgIGFuZCBgeWAgY29vcmRpbmF0ZXMgdGhhdCB3aWxsIHBsYWNlIHRoZSBmbG9hdGluZyBlbGVtZW50XG4gKiBuZXh0IHRvIGEgZ2l2ZW4gcmVmZXJlbmNlIGVsZW1lbnQuXG4gKi9cbmNvbnN0IGNvbXB1dGVQb3NpdGlvbiA9IChyZWZlcmVuY2UsIGZsb2F0aW5nLCBvcHRpb25zKSA9PiB7XG4gIC8vIFRoaXMgY2FjaGVzIHRoZSBleHBlbnNpdmUgYGdldENsaXBwaW5nRWxlbWVudEFuY2VzdG9yc2AgZnVuY3Rpb24gc28gdGhhdFxuICAvLyBtdWx0aXBsZSBsaWZlY3ljbGUgcmVzZXRzIHJlLXVzZSB0aGUgc2FtZSByZXN1bHQuIEl0IG9ubHkgbGl2ZXMgZm9yIGFcbiAgLy8gc2luZ2xlIGNhbGwuIElmIG90aGVyIGZ1bmN0aW9ucyBiZWNvbWUgZXhwZW5zaXZlLCB3ZSBjYW4gYWRkIHRoZW0gYXMgd2VsbC5cbiAgY29uc3QgY2FjaGUgPSBuZXcgTWFwKCk7XG4gIGNvbnN0IG1lcmdlZE9wdGlvbnMgPSBvcHRpb25zICE9IG51bGwgPyBvcHRpb25zIDoge307XG4gIGNvbnN0IHBsYXRmb3JtV2l0aENhY2hlID0ge1xuICAgIC4uLnBsYXRmb3JtLFxuICAgIC4uLm1lcmdlZE9wdGlvbnMucGxhdGZvcm0sXG4gICAgX2M6IGNhY2hlXG4gIH07XG4gIHJldHVybiBjb21wdXRlUG9zaXRpb24kMShyZWZlcmVuY2UsIGZsb2F0aW5nLCB7XG4gICAgLi4ubWVyZ2VkT3B0aW9ucyxcbiAgICBwbGF0Zm9ybTogcGxhdGZvcm1XaXRoQ2FjaGVcbiAgfSk7XG59O1xuXG5leHBvcnQgeyBhcnJvdywgYXV0b1BsYWNlbWVudCwgYXV0b1VwZGF0ZSwgY29tcHV0ZVBvc2l0aW9uLCBkZXRlY3RPdmVyZmxvdywgZmxpcCwgaGlkZSwgaW5saW5lLCBsaW1pdFNoaWZ0LCBvZmZzZXQsIHBsYXRmb3JtLCBzaGlmdCwgc2l6ZSB9O1xuIiwgImltcG9ydCB7IGNyZWF0ZVRhcmdldEFsaWdubWVudExlYXNlIH0gZnJvbSAnLi90YXJnZXQtYWxpZ25tZW50LWhvc3QnO1xuaW1wb3J0IHsgcmVzb2x2ZVdlYklucHV0T3JpZ2luQW5jaG9yIH0gZnJvbSAnLi9pbnB1dC1vcmlnaW4tYW5jaG9yJztcbmltcG9ydCB7IG9ic2VydmVSb290U3BhY2UgfSBmcm9tICcuL3Jvb3Qtc3BhY2Utb2JzZXJ2ZXInO1xuaW1wb3J0IHtcbiAgY3JlYXRlQm9yZGVyQm94U2l6ZUxlYXNlLFxuICBoYXNCb3JkZXJCb3hJbmxpbmVDbGlwcGluZyxcbiAgbWVhc3VyZUJvcmRlckJveElubGluZUd1dHRlcixcbn0gZnJvbSAnLi9ib3JkZXItYm94LXNpemUtbGVhc2UnO1xuaW1wb3J0IHsgb3duU3R5bGVzLCBoYXNPd25lZFN0eWxlIH0gZnJvbSAnLi9vd25lZC1zdHlsZS1sZWFzZSc7XG5pbXBvcnQge1xuICBhdXRvVXBkYXRlLFxuICBjb21wdXRlUG9zaXRpb24sXG4gIGZsaXAsXG4gIG9mZnNldCxcbiAgc2hpZnQsXG4gIHNpemUsXG4gIHR5cGUgTWlkZGxld2FyZSxcbiAgdHlwZSBQbGFjZW1lbnQsXG59IGZyb20gJ0BmbG9hdGluZy11aS9kb20nO1xuaW1wb3J0IHR5cGUge1xuICBBbmNob3JlZFBvc2l0aW9uQWxpZ24sXG4gIEFuY2hvcmVkUG9zaXRpb25Db25maWcsXG4gIEFuY2hvcmVkUG9zaXRpb25Db25uZWN0aW9uLFxuICBBbmNob3JlZFBvc2l0aW9uU2lkZSxcbiAgVGFyZ2V0QWxpZ25tZW50U3RhdHVzLFxufSBmcm9tICdAcHJvdG8udWkvY29yZSc7XG5pbXBvcnQgdHlwZSB7IEFuY2hvcmVkUG9zaXRpb25Ib3N0LCBBbmNob3JlZFBvc2l0aW9uSG9zdExlYXNlIH0gZnJvbSAnLi4vY2Fwcyc7XG5cbmZ1bmN0aW9uIHRvUGxhY2VtZW50KGNvbmZpZzogQW5jaG9yZWRQb3NpdGlvbkNvbmZpZyk6IFBsYWNlbWVudCB7XG4gIHJldHVybiBjb25maWcuYWxpZ24gPT09ICdjZW50ZXInID8gY29uZmlnLnNpZGUgOiBgJHtjb25maWcuc2lkZX0tJHtjb25maWcuYWxpZ259YDtcbn1cblxuZnVuY3Rpb24gZnJvbVBsYWNlbWVudChwbGFjZW1lbnQ6IFBsYWNlbWVudCk6IHtcbiAgc2lkZTogQW5jaG9yZWRQb3NpdGlvblNpZGU7XG4gIGFsaWduOiBBbmNob3JlZFBvc2l0aW9uQWxpZ247XG59IHtcbiAgY29uc3QgW3NpZGUsIGFsaWduXSA9IHBsYWNlbWVudC5zcGxpdCgnLScpIGFzIFtBbmNob3JlZFBvc2l0aW9uU2lkZSwgQW5jaG9yZWRQb3NpdGlvbkFsaWduP107XG4gIHJldHVybiB7IHNpZGUsIGFsaWduOiBhbGlnbiA/PyAnY2VudGVyJyB9O1xufVxuXG5mdW5jdGlvbiBpc0VsZW1lbnQodmFsdWU6IHVua25vd24pOiB2YWx1ZSBpcyBIVE1MRWxlbWVudCB7XG4gIHJldHVybiB0eXBlb2YgSFRNTEVsZW1lbnQgIT09ICd1bmRlZmluZWQnICYmIHZhbHVlIGluc3RhbmNlb2YgSFRNTEVsZW1lbnQ7XG59XG5cbi8qKlxuICogQW5jaG9yZWQgZ2VvbWV0cnkgbWF5IGV4Y2x1ZGUgdGhlIGFuY2hvcidzIG93biBDU1MgdHJhbnNsYXRpb24uIEludGVyYWN0aW9uXG4gKiB0cmFuc2Zvcm1zIChob3ZlciBsaWZ0LCBwcmVzcy1kb3duKSBhcmUgZGVjb3JhdGlvbiBvZiB0aGUgYW5jaG9yIHN1cmZhY2U7XG4gKiB3aGVuIHRoZSBjb25zdW1lciBvcHRzIGluIHZpYSBgZXhjbHVkZUFuY2hvclRyYW5zbGF0aW9uYCwgYW5jaG9yZWQgc3VyZmFjZXNcbiAqIHRyYWNrIGxheW91dCBwb3NpdGlvbiBpbnN0ZWFkIG9mIHRoZSByZW5kZXJlZCBzdXJmYWNlLiBCeSBkZWZhdWx0IHRoZSBob3N0XG4gKiBtZWFzdXJlcyB0aGUgYW5jaG9yJ3MgYWN0dWFsIHJlbmRlcmVkIGdlb21ldHJ5LCBzbyBsZWdpdGltYXRlIHRyYW5zbGF0aW9uc1xuICogKGNlbnRlcmluZywgYXBwbGljYXRpb24gYW5pbWF0aW9uKSBrZWVwIGZsb2F0aW5nIHBsYWNlbWVudCB3aGVyZSB0aGUgdXNlclxuICogc2VlcyB0aGUgYW5jaG9yLlxuICovXG5mdW5jdGlvbiB2aXJ0dWFsUmVmZXJlbmNlRm9yKGFuY2hvcjogSFRNTEVsZW1lbnQpIHtcbiAgcmV0dXJuIHtcbiAgICBnZXRCb3VuZGluZ0NsaWVudFJlY3QoKTogRE9NUmVjdCB7XG4gICAgICBjb25zdCByZWN0ID0gYW5jaG9yLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgY29uc3Qgc2hpZnQgPSBvd25BbmNob3JUcmFuc2xhdGlvbihhbmNob3IpO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgeDogcmVjdC54IC0gc2hpZnQueCxcbiAgICAgICAgeTogcmVjdC55IC0gc2hpZnQueSxcbiAgICAgICAgbGVmdDogcmVjdC5sZWZ0IC0gc2hpZnQueCxcbiAgICAgICAgdG9wOiByZWN0LnRvcCAtIHNoaWZ0LnksXG4gICAgICAgIHJpZ2h0OiByZWN0LnJpZ2h0IC0gc2hpZnQueCxcbiAgICAgICAgYm90dG9tOiByZWN0LmJvdHRvbSAtIHNoaWZ0LnksXG4gICAgICAgIHdpZHRoOiByZWN0LndpZHRoLFxuICAgICAgICBoZWlnaHQ6IHJlY3QuaGVpZ2h0LFxuICAgICAgICB0b0pTT046ICgpID0+ICh7fSksXG4gICAgICB9IGFzIERPTVJlY3Q7XG4gICAgfSxcbiAgfTtcbn1cblxuLyoqXG4gKiBUaGUgYW5jaG9yJ3Mgb3duIHBhaW50IHRyYW5zbGF0aW9uLCBub3QgYW4gYW5jZXN0b3Incy4gYHRyYW5zZm9ybWAgbWF0cmljZXNcbiAqIGRvIG5vdCBpbmNsdWRlIHRoZSBpbmRlcGVuZGVudCBDU1MgYHRyYW5zbGF0ZWAgcHJvcGVydHksIHdoaWNoIHN0aWxsIHNoaWZ0c1xuICogYGdldEJvdW5kaW5nQ2xpZW50UmVjdGAgYW5kIHdvdWxkIG90aGVyd2lzZSBtb3ZlIHRoZSBwb3BwZXIgYmFzaXMuXG4gKi9cbmZ1bmN0aW9uIG93bkFuY2hvclRyYW5zbGF0aW9uKGFuY2hvcjogSFRNTEVsZW1lbnQpOiB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0ge1xuICBsZXQgeCA9IDA7XG4gIGxldCB5ID0gMDtcbiAgaWYgKHR5cGVvZiBnZXRDb21wdXRlZFN0eWxlICE9PSAnZnVuY3Rpb24nKSByZXR1cm4geyB4LCB5IH07XG4gIGNvbnN0IHN0eWxlID0gZ2V0Q29tcHV0ZWRTdHlsZShhbmNob3IpO1xuICBjb25zdCB0cmFuc2Zvcm0gPSBzdHlsZS50cmFuc2Zvcm07XG4gIGlmICh0cmFuc2Zvcm0gJiYgdHJhbnNmb3JtICE9PSAnbm9uZScgJiYgdHlwZW9mIERPTU1hdHJpeFJlYWRPbmx5ICE9PSAndW5kZWZpbmVkJykge1xuICAgIGNvbnN0IG1hdHJpeCA9IG5ldyBET01NYXRyaXhSZWFkT25seSh0cmFuc2Zvcm0pO1xuICAgIHggKz0gbWF0cml4Lm00MTtcbiAgICB5ICs9IG1hdHJpeC5tNDI7XG4gIH1cbiAgY29uc3QgdHJhbnNsYXRlID0gc3R5bGUudHJhbnNsYXRlO1xuICBpZiAodHJhbnNsYXRlICYmIHRyYW5zbGF0ZSAhPT0gJ25vbmUnKSB7XG4gICAgY29uc3QgW3R4LCB0eV0gPSB0cmFuc2xhdGUudHJpbSgpLnNwbGl0KC9cXHMrLyk7XG4gICAgeCArPSBjc3NMZW5ndGhUb1B4KHR4LCByZWN0QmFzaXMoYW5jaG9yLCAneCcpKTtcbiAgICB5ICs9IGNzc0xlbmd0aFRvUHgodHkgPz8gJzBweCcsIHJlY3RCYXNpcyhhbmNob3IsICd5JykpO1xuICB9XG4gIHJldHVybiB7IHgsIHkgfTtcbn1cblxuZnVuY3Rpb24gcmVjdEJhc2lzKGFuY2hvcjogSFRNTEVsZW1lbnQsIGF4aXM6ICd4JyB8ICd5Jyk6IG51bWJlciB7XG4gIGNvbnN0IHJlY3QgPSBhbmNob3IuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gIHJldHVybiBheGlzID09PSAneCcgPyByZWN0LndpZHRoIDogcmVjdC5oZWlnaHQ7XG59XG5cbmZ1bmN0aW9uIGNzc0xlbmd0aFRvUHgodmFsdWU6IHN0cmluZyB8IHVuZGVmaW5lZCwgYmFzaXM6IG51bWJlcik6IG51bWJlciB7XG4gIGlmICghdmFsdWUpIHJldHVybiAwO1xuICBjb25zdCB0ZXh0ID0gdmFsdWUudHJpbSgpO1xuICBpZiAoIXRleHQgfHwgdGV4dCA9PT0gJ25vbmUnKSByZXR1cm4gMDtcbiAgaWYgKHRleHQuZW5kc1dpdGgoJyUnKSkge1xuICAgIGNvbnN0IHBlcmNlbnQgPSBOdW1iZXIucGFyc2VGbG9hdCh0ZXh0KTtcbiAgICByZXR1cm4gTnVtYmVyLmlzRmluaXRlKHBlcmNlbnQpID8gKHBlcmNlbnQgLyAxMDApICogYmFzaXMgOiAwO1xuICB9XG4gIGNvbnN0IHBpeGVscyA9IE51bWJlci5wYXJzZUZsb2F0KHRleHQpO1xuICByZXR1cm4gTnVtYmVyLmlzRmluaXRlKHBpeGVscykgPyBwaXhlbHMgOiAwO1xufVxuXG5mdW5jdGlvbiBwb3NpdGlvblJlZmVyZW5jZShhbmNob3I6IEhUTUxFbGVtZW50LCBjb25maWc6IEFuY2hvcmVkUG9zaXRpb25Db25maWcpIHtcbiAgcmV0dXJuIGNvbmZpZy5leGNsdWRlQW5jaG9yVHJhbnNsYXRpb24gPT09IHRydWUgPyB2aXJ0dWFsUmVmZXJlbmNlRm9yKGFuY2hvcikgOiBhbmNob3I7XG59XG5cbmZ1bmN0aW9uIG1pZGRsZXdhcmVGb3IoXG4gIGNvbmZpZzogQW5jaG9yZWRQb3NpdGlvbkNvbmZpZyxcbiAgaXNDdXJyZW50OiAoKSA9PiBib29sZWFuLFxuICBhdmFpbGFibGU/OiAod2lkdGg6IG51bWJlciwgaGVpZ2h0OiBudW1iZXIpID0+IHZvaWRcbik6IE1pZGRsZXdhcmVbXSB7XG4gIGNvbnN0IG1pZGRsZXdhcmU6IE1pZGRsZXdhcmVbXSA9IFtcbiAgICBvZmZzZXQoeyBtYWluQXhpczogY29uZmlnLnNpZGVPZmZzZXQsIGNyb3NzQXhpczogY29uZmlnLmFsaWduT2Zmc2V0IH0pLFxuICBdO1xuICBjb25zdCBib3VuZGFyeSA9IGNvbmZpZy5jb2xsaXNpb25Cb3VuZGFyeSA9PT0gJ3ZpZXdwb3J0JyA/IFtdIDogJ2NsaXBwaW5nQW5jZXN0b3JzJztcbiAgaWYgKGNvbmZpZy5hdm9pZENvbGxpc2lvbnMpIHtcbiAgICBtaWRkbGV3YXJlLnB1c2goXG4gICAgICBmbGlwKHsgYm91bmRhcnksIHJvb3RCb3VuZGFyeTogJ3ZpZXdwb3J0JywgcGFkZGluZzogY29uZmlnLmNvbGxpc2lvblBhZGRpbmcgfSksXG4gICAgICBzaGlmdCh7IGJvdW5kYXJ5LCByb290Qm91bmRhcnk6ICd2aWV3cG9ydCcsIHBhZGRpbmc6IGNvbmZpZy5jb2xsaXNpb25QYWRkaW5nIH0pXG4gICAgKTtcbiAgfVxuICBtaWRkbGV3YXJlLnB1c2goXG4gICAgc2l6ZSh7XG4gICAgICBib3VuZGFyeSxcbiAgICAgIHJvb3RCb3VuZGFyeTogJ3ZpZXdwb3J0JyxcbiAgICAgIHBhZGRpbmc6IGNvbmZpZy5jb2xsaXNpb25QYWRkaW5nLFxuICAgICAgYXBwbHkoeyBhdmFpbGFibGVXaWR0aCwgYXZhaWxhYmxlSGVpZ2h0LCByZWN0cywgZWxlbWVudHMgfSkge1xuICAgICAgICBpZiAoIWlzQ3VycmVudCgpKSByZXR1cm47XG4gICAgICAgIGF2YWlsYWJsZT8uKGF2YWlsYWJsZVdpZHRoLCBhdmFpbGFibGVIZWlnaHQpO1xuICAgICAgICBpZiAoIWlzQ3VycmVudCgpKSByZXR1cm47XG4gICAgICAgIGNvbnN0IHN0eWxlID0gZWxlbWVudHMuZmxvYXRpbmcuc3R5bGU7XG4gICAgICAgIGZvciAoY29uc3QgW25hbWUsIHZhbHVlXSBvZiBbXG4gICAgICAgICAgWyctLXByb3RvLXVpLWFuY2hvci13aWR0aCcsIGAke3JlY3RzLnJlZmVyZW5jZS53aWR0aH1weGBdLFxuICAgICAgICAgIFsnLS1wcm90by11aS1hbmNob3ItaGVpZ2h0JywgYCR7cmVjdHMucmVmZXJlbmNlLmhlaWdodH1weGBdLFxuICAgICAgICAgIFsnLS1wcm90by11aS1hdmFpbGFibGUtd2lkdGgnLCBgJHthdmFpbGFibGVXaWR0aH1weGBdLFxuICAgICAgICAgIFsnLS1wcm90by11aS1hdmFpbGFibGUtaGVpZ2h0JywgYCR7YXZhaWxhYmxlSGVpZ2h0fXB4YF0sXG4gICAgICAgIF0pIHtcbiAgICAgICAgICBpZiAoIWlzQ3VycmVudCgpKSByZXR1cm47XG4gICAgICAgICAgc3R5bGUuc2V0UHJvcGVydHkobmFtZSwgdmFsdWUpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgIH0pXG4gICk7XG4gIHJldHVybiBtaWRkbGV3YXJlO1xufVxuXG4vKiogRWRnZSBwbGFjZW1lbnQgYW5kIHVzZWQtYm94IHNpemluZyBzaGFyZSBhIGxpZmV0aW1lLCBub3QgYSBjb21wb25lbnQgcG9saWN5LiAqL1xuZnVuY3Rpb24gY3JlYXRlRWRnZVNpemVMZWFzZShjb25uZWN0aW9uOiBBbmNob3JlZFBvc2l0aW9uQ29ubmVjdGlvbiwgY3VycmVudDogKCkgPT4gYm9vbGVhbikge1xuICBjb25zdCBkZXNjcmlwdG9yID0gY29ubmVjdGlvbi5zaXplTWF0Y2ghO1xuICBjb25zdCBmcmFtZSA9IGNvbm5lY3Rpb24uZmxvYXRpbmc7XG4gIGNvbnN0IHJlZmVyZW5jZSA9IGRlc2NyaXB0b3IucmVmZXJlbmNlO1xuICBjb25zdCB0YXJnZXRzID0gZGVzY3JpcHRvci50YXJnZXRzO1xuICBjb25zdCBjb21wbGV0ZSA9IGlzRWxlbWVudChmcmFtZSkgJiYgaXNFbGVtZW50KHJlZmVyZW5jZSkgJiYgdGFyZ2V0cy5ldmVyeShpc0VsZW1lbnQpO1xuICBjb25zdCB2YWxpZCA9XG4gICAgIWNvbm5lY3Rpb24udGFyZ2V0QWxpZ25tZW50ICYmXG4gICAgY29tcGxldGUgJiZcbiAgICByZWZlcmVuY2UgPT09IGNvbm5lY3Rpb24uYW5jaG9yICYmXG4gICAgdGFyZ2V0cy5sZW5ndGggPiAwICYmXG4gICAgdGFyZ2V0cy5ldmVyeShpc0VsZW1lbnQpICYmXG4gICAgbmV3IFNldCh0YXJnZXRzKS5zaXplID09PSB0YXJnZXRzLmxlbmd0aCAmJlxuICAgIHRhcmdldHMuZXZlcnkoXG4gICAgICAodGFyZ2V0KSA9PlxuICAgICAgICBmcmFtZS5jb250YWlucyh0YXJnZXQgYXMgSFRNTEVsZW1lbnQpICYmXG4gICAgICAgIHRhcmdldCAhPT0gZnJhbWUgJiZcbiAgICAgICAgKHRhcmdldCBhcyBIVE1MRWxlbWVudCkub3duZXJEb2N1bWVudCA9PT0gZnJhbWUub3duZXJEb2N1bWVudFxuICAgICkgJiZcbiAgICByZWZlcmVuY2Uub3duZXJEb2N1bWVudCA9PT0gZnJhbWUub3duZXJEb2N1bWVudDtcbiAgY29uc3QgbWlzc2luZyA9IGZyYW1lID09IG51bGwgfHwgcmVmZXJlbmNlID09IG51bGwgfHwgdGFyZ2V0cy5zb21lKCh0YXJnZXQpID0+IHRhcmdldCA9PSBudWxsKTtcbiAgbGV0IHRlcm1pbmFsOiBUYXJnZXRBbGlnbm1lbnRTdGF0dXMgfCBudWxsID0gdmFsaWRcbiAgICA/IG51bGxcbiAgICA6IG1pc3NpbmdcbiAgICAgID8geyBzdGF0dXM6ICdwZW5kaW5nLXRhcmdldCcsIHJlYXNvbjogJ21pc3NpbmctdGFyZ2V0JyB9XG4gICAgICA6IHsgc3RhdHVzOiAndW5hdmFpbGFibGUnLCByZWFzb246ICdpbnZhbGlkLWFzc29jaWF0aW9uJyB9O1xuICBjb25zdCBzaXplTGVhc2UgPSB2YWxpZFxuICAgID8gY3JlYXRlQm9yZGVyQm94U2l6ZUxlYXNlKHJlZmVyZW5jZSwgdGFyZ2V0cyBhcyBIVE1MRWxlbWVudFtdLCBjdXJyZW50KVxuICAgIDogbnVsbDtcbiAgY29uc3QgZnJhbWVTdHlsZSA9IHZhbGlkID8gb3duU3R5bGVzKGZyYW1lKSA6IG51bGw7XG4gIGxldCB3cm90ZVdpZHRoID0gZmFsc2U7XG4gIGxldCBtaW5pbXVtID0gMDtcbiAgY29uc3QgZmFpbCA9IChcbiAgICByZWFzb246ICdpbnZhbGlkLWdlb21ldHJ5JyB8ICdvd25lcnNoaXAtbG9zdCcgfCAnc2l6ZS1jb25mbGljdCdcbiAgKTogVGFyZ2V0QWxpZ25tZW50U3RhdHVzID0+IHtcbiAgICBzaXplTGVhc2U/LmFib3J0KHJlYXNvbik7XG4gICAgZnJhbWVTdHlsZT8ucmVzdG9yZSgpO1xuICAgIHRlcm1pbmFsID0geyBzdGF0dXM6ICd1bmF2YWlsYWJsZScsIHJlYXNvbiB9O1xuICAgIHJldHVybiB0ZXJtaW5hbDtcbiAgfTtcbiAgY29uc3QgY29udmVydCA9IChcbiAgICByZXN1bHQ6IEV4Y2x1ZGU8UmV0dXJuVHlwZTxOb25OdWxsYWJsZTx0eXBlb2Ygc2l6ZUxlYXNlPlsncHJlcGFyZSddPiwgeyBraW5kOiAncHJlcGFyZWQnIH0+XG4gICk6IFRhcmdldEFsaWdubWVudFN0YXR1cyA9PiB7XG4gICAgaWYgKHJlc3VsdC5raW5kID09PSAncGVuZGluZycpIHJldHVybiB7IHN0YXR1czogJ3BlbmRpbmctdGFyZ2V0JywgcmVhc29uOiAnbWlzc2luZy10YXJnZXQnIH07XG4gICAgaWYgKHJlc3VsdC5yZWFzb24gPT09ICdkZXRhY2hlZC10YXJnZXQnKSB7XG4gICAgICByZXR1cm4geyBzdGF0dXM6ICdwZW5kaW5nLXRhcmdldCcsIHJlYXNvbjogJ2RldGFjaGVkLXRhcmdldCcgfTtcbiAgICB9XG4gICAgcmV0dXJuIGZhaWwocmVzdWx0LnJlYXNvbik7XG4gIH07XG4gIHJldHVybiB7XG4gICAgb2JzZXJ2ZWQ6IHZhbGlkID8gW3JlZmVyZW5jZSwgZnJhbWUsIC4uLih0YXJnZXRzIGFzIEhUTUxFbGVtZW50W10pXSA6IFtdLFxuICAgIHByZXBhcmUoKTogVGFyZ2V0QWxpZ25tZW50U3RhdHVzIHwgeyB3aWR0aDogbnVtYmVyOyBoZWlnaHQ6IG51bWJlciB9IHtcbiAgICAgIGlmICh0ZXJtaW5hbCkgcmV0dXJuIHRlcm1pbmFsO1xuICAgICAgaWYgKCFjdXJyZW50KCkgfHwgIWlzRWxlbWVudChmcmFtZSkgfHwgIXNpemVMZWFzZSB8fCAhZnJhbWVTdHlsZSlcbiAgICAgICAgcmV0dXJuIHsgc3RhdHVzOiAncGVuZGluZy10YXJnZXQnLCByZWFzb246ICdkZXRhY2hlZC10YXJnZXQnIH07XG4gICAgICBpZiAoIWZyYW1lU3R5bGUuaXNDdXJyZW50KCkpIHJldHVybiBmYWlsKCdvd25lcnNoaXAtbG9zdCcpO1xuICAgICAgY29uc3QgcHJlcGFyZWQgPSBzaXplTGVhc2UucHJlcGFyZSgpO1xuICAgICAgaWYgKHByZXBhcmVkLmtpbmQgIT09ICdwcmVwYXJlZCcpIHJldHVybiBjb252ZXJ0KHByZXBhcmVkKTtcbiAgICAgIGNvbnN0IGd1dHRlcnMgPSAodGFyZ2V0cyBhcyBIVE1MRWxlbWVudFtdKS5tYXAoKHRhcmdldCkgPT5cbiAgICAgICAgbWVhc3VyZUJvcmRlckJveElubGluZUd1dHRlcih0YXJnZXQsIGZyYW1lKVxuICAgICAgKTtcbiAgICAgIGlmIChndXR0ZXJzLnNvbWUoKGd1dHRlcikgPT4gZ3V0dGVyID09PSBudWxsKSkgcmV0dXJuIGZhaWwoJ2ludmFsaWQtZ2VvbWV0cnknKTtcbiAgICAgIG1pbmltdW0gPSBwcmVwYXJlZC53aWR0aCArIE1hdGgubWF4KC4uLihndXR0ZXJzIGFzIG51bWJlcltdKSk7XG4gICAgICBpZiAoIWN1cnJlbnQoKSkgcmV0dXJuIHsgc3RhdHVzOiAncGVuZGluZy10YXJnZXQnLCByZWFzb246ICdkZXRhY2hlZC10YXJnZXQnIH07XG4gICAgICBjb25zdCBmcmFtZVdpZHRoID0gZnJhbWUub2Zmc2V0V2lkdGg7XG4gICAgICBpZiAoIWN1cnJlbnQoKSkgcmV0dXJuIHsgc3RhdHVzOiAncGVuZGluZy10YXJnZXQnLCByZWFzb246ICdkZXRhY2hlZC10YXJnZXQnIH07XG4gICAgICBpZiAod3JvdGVXaWR0aCB8fCBmcmFtZVdpZHRoIDwgbWluaW11bSkge1xuICAgICAgICAvLyBQcmVzZXJ2ZSBhdXRob3JlZCBzaXppbmcuIENTUyByZXNvbHZlcyBtaW4vbWF4IGNvbnN0cmFpbnRzOyB2ZXJpZnkoKVxuICAgICAgICAvLyBjZXJ0aWZpZXMgdGhlIHVzZWQgYm94IGluc3RlYWQgb2YgYSBtaW5pbXVtIG92ZXJyaWRpbmcgYW4gYXV0aG9yIGNhcC5cbiAgICAgICAgaWYgKFxuICAgICAgICAgICF3cm90ZVdpZHRoICYmXG4gICAgICAgICAgKChmcmFtZS5zdHlsZS5nZXRQcm9wZXJ0eVZhbHVlKCd3aWR0aCcpICYmICFoYXNPd25lZFN0eWxlKGZyYW1lLCAnd2lkdGgnKSkgfHxcbiAgICAgICAgICAgIChmcmFtZS5zdHlsZS5nZXRQcm9wZXJ0eVZhbHVlKCdpbmxpbmUtc2l6ZScpICYmICFoYXNPd25lZFN0eWxlKGZyYW1lLCAnaW5saW5lLXNpemUnKSkpXG4gICAgICAgIClcbiAgICAgICAgICByZXR1cm4gZmFpbCgnc2l6ZS1jb25mbGljdCcpO1xuICAgICAgICBjb25zdCBzdHlsZSA9IGZyYW1lLm93bmVyRG9jdW1lbnQuZGVmYXVsdFZpZXc/LmdldENvbXB1dGVkU3R5bGUoZnJhbWUpO1xuICAgICAgICBpZiAoIXN0eWxlKSByZXR1cm4gZmFpbCgnaW52YWxpZC1nZW9tZXRyeScpO1xuICAgICAgICBjb25zdCBjaHJvbWUgPVxuICAgICAgICAgIHN0eWxlLmJveFNpemluZyA9PT0gJ2JvcmRlci1ib3gnXG4gICAgICAgICAgICA/IDBcbiAgICAgICAgICAgIDogTnVtYmVyLnBhcnNlRmxvYXQoc3R5bGUucGFkZGluZ0xlZnQpICtcbiAgICAgICAgICAgICAgTnVtYmVyLnBhcnNlRmxvYXQoc3R5bGUucGFkZGluZ1JpZ2h0KSArXG4gICAgICAgICAgICAgIE51bWJlci5wYXJzZUZsb2F0KHN0eWxlLmJvcmRlckxlZnRXaWR0aCkgK1xuICAgICAgICAgICAgICBOdW1iZXIucGFyc2VGbG9hdChzdHlsZS5ib3JkZXJSaWdodFdpZHRoKTtcbiAgICAgICAgY29uc3Qgd2lkdGggPSBtaW5pbXVtIC0gY2hyb21lO1xuICAgICAgICBpZiAoIU51bWJlci5pc0Zpbml0ZSh3aWR0aCkgfHwgY2hyb21lIDwgMCkgcmV0dXJuIGZhaWwoJ2ludmFsaWQtZ2VvbWV0cnknKTtcbiAgICAgICAgaWYgKHdpZHRoIDw9IDApIHJldHVybiBmYWlsKCdzaXplLWNvbmZsaWN0Jyk7XG4gICAgICAgIGlmICghZnJhbWVTdHlsZS53cml0ZSgnd2lkdGgnLCBgJHt3aWR0aH1weGApKSByZXR1cm4gZmFpbCgnb3duZXJzaGlwLWxvc3QnKTtcbiAgICAgICAgd3JvdGVXaWR0aCA9IHRydWU7XG4gICAgICB9XG4gICAgICByZXR1cm4geyB3aWR0aDogcHJlcGFyZWQud2lkdGgsIGhlaWdodDogcHJlcGFyZWQuaGVpZ2h0IH07XG4gICAgfSxcbiAgICB2ZXJpZnkoXG4gICAgICBhdmFpbGFibGU6IHsgd2lkdGg6IG51bWJlcjsgaGVpZ2h0OiBudW1iZXIgfSB8IG51bGxcbiAgICApOiBUYXJnZXRBbGlnbm1lbnRTdGF0dXMgfCB7IHN0YXR1czogJ3JlZmVyZW5jZS1jaGFuZ2VkJyB9IHtcbiAgICAgIGlmICh0ZXJtaW5hbCkgcmV0dXJuIHRlcm1pbmFsO1xuICAgICAgaWYgKCFjdXJyZW50KCkgfHwgIWlzRWxlbWVudChmcmFtZSkgfHwgIXNpemVMZWFzZSB8fCAhZnJhbWVTdHlsZSlcbiAgICAgICAgcmV0dXJuIHsgc3RhdHVzOiAncGVuZGluZy10YXJnZXQnLCByZWFzb246ICdkZXRhY2hlZC10YXJnZXQnIH07XG4gICAgICBpZiAoIWZyYW1lU3R5bGUuaXNDdXJyZW50KCkpIHJldHVybiBmYWlsKCdvd25lcnNoaXAtbG9zdCcpO1xuICAgICAgY29uc3QgdmVyaWZpZWQgPSBzaXplTGVhc2UudmVyaWZ5KCk7XG4gICAgICBpZiAodmVyaWZpZWQua2luZCA9PT0gJ3JlZmVyZW5jZS1jaGFuZ2VkJykgcmV0dXJuIHsgc3RhdHVzOiAncmVmZXJlbmNlLWNoYW5nZWQnIH07XG4gICAgICBpZiAodmVyaWZpZWQua2luZCAhPT0gJ21hdGNoZWQnKSByZXR1cm4gY29udmVydCh2ZXJpZmllZCk7XG4gICAgICBpZiAoIU51bWJlci5pc0Zpbml0ZShmcmFtZS5vZmZzZXRXaWR0aCkgfHwgIU51bWJlci5pc0Zpbml0ZShmcmFtZS5vZmZzZXRIZWlnaHQpKVxuICAgICAgICByZXR1cm4gZmFpbCgnaW52YWxpZC1nZW9tZXRyeScpO1xuICAgICAgaWYgKGZyYW1lLm9mZnNldFdpZHRoIDw9IDAgfHwgZnJhbWUub2Zmc2V0SGVpZ2h0IDw9IDApXG4gICAgICAgIHJldHVybiB7IHN0YXR1czogJ3BlbmRpbmctdGFyZ2V0JywgcmVhc29uOiAnbWlzc2luZy10YXJnZXQnIH07XG4gICAgICBpZiAoXG4gICAgICAgIGZyYW1lLm9mZnNldFdpZHRoICsgMSA8IG1pbmltdW0gfHxcbiAgICAgICAgKGF2YWlsYWJsZSAmJlxuICAgICAgICAgIChmcmFtZS5vZmZzZXRXaWR0aCA+IGF2YWlsYWJsZS53aWR0aCArIDEgfHwgZnJhbWUub2Zmc2V0SGVpZ2h0ID4gYXZhaWxhYmxlLmhlaWdodCArIDEpKVxuICAgICAgKVxuICAgICAgICByZXR1cm4gZmFpbCgnc2l6ZS1jb25mbGljdCcpO1xuICAgICAgZm9yIChjb25zdCB0YXJnZXQgb2YgdGFyZ2V0cyBhcyBIVE1MRWxlbWVudFtdKSB7XG4gICAgICAgIGNvbnN0IGNsaXBwZWQgPSBoYXNCb3JkZXJCb3hJbmxpbmVDbGlwcGluZyh0YXJnZXQsIGZyYW1lKTtcbiAgICAgICAgaWYgKGNsaXBwZWQgIT09IGZhbHNlKSByZXR1cm4gZmFpbChjbGlwcGVkID09PSBudWxsID8gJ2ludmFsaWQtZ2VvbWV0cnknIDogJ3NpemUtY29uZmxpY3QnKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IHN0YXR1czogJ2FwcGxpZWQnIH07XG4gICAgfSxcbiAgICBmYWlsLFxuICAgIGRpc3Bvc2UoKSB7XG4gICAgICBzaXplTGVhc2U/LnJlc3RvcmUoKTtcbiAgICAgIGZyYW1lU3R5bGU/LnJlc3RvcmUoKTtcbiAgICB9LFxuICB9O1xufVxuXG4vLyBjb21wdXRlUG9zaXRpb24geWllbGRzIGJlZm9yZSB3cml0aW5nIGNvb3JkaW5hdGVzLiBBIHBvcnRhbGVkIGN1c3RvbSBlbGVtZW50XG4vLyBpcyBzdGlsbCBpbiBub3JtYWwgZmxvdyBhdCB0aGUgZW5kIG9mIHRoZSBkb2N1bWVudCBkdXJpbmcgdGhhdCBnYXAsIGFuZCBXQ1xuLy8gZW50cnkgZm9jdXMgc2Nyb2xscyBpdCBpbnRvIHZpZXcgZXZlbiB3aGVuIHByZXZlbnRTY3JvbGwgaXMgcmVxdWVzdGVkLiBUaGVcbi8vIGxhdGVyIGZpeGVkIGNvb3JkaW5hdGVzIGFyZSB0aGVuIHNvbHZlZCBhZ2FpbnN0IHRoZSBzY3JvbGxlZCBhbmNob3IgYW5kIHN0YXlcbi8vIG91dHNpZGUgdGhlIHZpZXdwb3J0LiBQaW4gdGhlIGNvbmZpZ3VyZWQgc3RyYXRlZ3kgaW5zaWRlIHRoZSB2aWV3cG9ydCBiZWZvcmVcbi8vIHRoZSBmaXJzdCBhd2FpdCBzbyBmb2N1cyBjYW5ub3QgbW92ZSB0aGUgZG9jdW1lbnQuXG5mdW5jdGlvbiBwaW5BbmNob3JlZFN0cmF0ZWd5KFxuICBmbG9hdGluZzogSFRNTEVsZW1lbnQsXG4gIHN0cmF0ZWd5OiBzdHJpbmcsXG4gIHN0eWxlczogUmV0dXJuVHlwZTx0eXBlb2Ygb3duU3R5bGVzPlxuKSB7XG4gIC8vIFByZXBhcmF0aW9uIGlzIHN0aWxsIGFuIG93bmVkIGdlb21ldHJ5IHdyaXRlLiBBbiBlcXVhbCB2YWx1ZSBoZWxkIGJ5IGFcbiAgLy8gcHJpb3IgbGVhc2UgbXVzdCB0cmFuc2ZlciBvd25lcnNoaXAgc28gaXRzIHJldGlyZW1lbnQgY2Fubm90IGVyYXNlIHVzLlxuICBpZiAoZmxvYXRpbmcuc3R5bGUucG9zaXRpb24gIT09IHN0cmF0ZWd5IHx8IGhhc093bmVkU3R5bGUoZmxvYXRpbmcsICdwb3NpdGlvbicpKVxuICAgIHN0eWxlcy53cml0ZSgncG9zaXRpb24nLCBzdHJhdGVneSk7XG4gIGZvciAoY29uc3QgbmFtZSBvZiBbJ3RvcCcsICdsZWZ0J10gYXMgY29uc3QpIHtcbiAgICBpZiAoZmxvYXRpbmcuc3R5bGVbbmFtZV0gPT09ICcnIHx8IGhhc093bmVkU3R5bGUoZmxvYXRpbmcsIG5hbWUpKVxuICAgICAgc3R5bGVzLndyaXRlKG5hbWUsIGZsb2F0aW5nLnN0eWxlW25hbWVdIHx8ICcwcHgnKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBjcmVhdGVFZGdlQW5jaG9yZWRQb3NpdGlvbkhvc3QoKTogQW5jaG9yZWRQb3NpdGlvbkhvc3Qge1xuICByZXR1cm4ge1xuICAgIGF0dGFjaChpbml0aWFsKTogQW5jaG9yZWRQb3NpdGlvbkhvc3RMZWFzZSB7XG4gICAgICBsZXQgY29ubmVjdGlvbiA9IGluaXRpYWw7XG4gICAgICBsZXQgZGlzcG9zZWQgPSBmYWxzZTtcbiAgICAgIGxldCBnZW5lcmF0aW9uID0gMDtcbiAgICAgIGxldCBjbGVhbnVwOiAoKCkgPT4gdm9pZCkgfCBudWxsID0gbnVsbDtcbiAgICAgIGxldCBzaXppbmdFcG9jaCA9IDA7XG4gICAgICBsZXQgc2l6aW5nOiBSZXR1cm5UeXBlPHR5cGVvZiBjcmVhdGVFZGdlU2l6ZUxlYXNlPiB8IG51bGwgPSBudWxsO1xuICAgICAgbGV0IHNpemVPYnNlcnZlcnM6IFJlc2l6ZU9ic2VydmVyW10gPSBbXTtcbiAgICAgIGxldCBzdHJhdGVneVBpbjogeyB0YXJnZXQ6IEhUTUxFbGVtZW50OyBzdHlsZXM6IFJldHVyblR5cGU8dHlwZW9mIG93blN0eWxlcz4gfSB8IG51bGwgPSBudWxsO1xuICAgICAgY29uc3QgcmV0aXJlU3RyYXRlZ3lQaW4gPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHByZXZpb3VzID0gc3RyYXRlZ3lQaW47XG4gICAgICAgIHN0cmF0ZWd5UGluID0gbnVsbDtcbiAgICAgICAgcHJldmlvdXM/LnN0eWxlcy5yZXN0b3JlKCk7XG4gICAgICB9O1xuICAgICAgY29uc3QgcmV0aXJlU2l6aW5nID0gKCkgPT4ge1xuICAgICAgICBzaXppbmdFcG9jaCsrO1xuICAgICAgICBmb3IgKGNvbnN0IG9ic2VydmVyIG9mIHNpemVPYnNlcnZlcnMpIG9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgc2l6ZU9ic2VydmVycyA9IFtdO1xuICAgICAgICBjb25zdCBwcmV2aW91cyA9IHNpemluZztcbiAgICAgICAgc2l6aW5nID0gbnVsbDtcbiAgICAgICAgcHJldmlvdXM/LmRpc3Bvc2UoKTtcbiAgICAgIH07XG4gICAgICBjb25zdCByZWZlcmVuY2VGb3IgPSAoYW5jaG9yOiB1bmtub3duLCBjb25maWc6IEFuY2hvcmVkUG9zaXRpb25Db25maWcpID0+IHtcbiAgICAgICAgaWYgKGlzRWxlbWVudChhbmNob3IpKVxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBlbGVtZW50OiBhbmNob3IsXG4gICAgICAgICAgICByZWZlcmVuY2U6IHBvc2l0aW9uUmVmZXJlbmNlKGFuY2hvciwgY29uZmlnKSxcbiAgICAgICAgICAgIGlzTGl2ZTogKCkgPT4gdHJ1ZSxcbiAgICAgICAgICB9O1xuICAgICAgICByZXR1cm4gcmVzb2x2ZVdlYklucHV0T3JpZ2luQW5jaG9yKGFuY2hvcik7XG4gICAgICB9O1xuXG4gICAgICBjb25zdCBwb3NpdGlvbiA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgY3VycmVudCA9IGNvbm5lY3Rpb247XG4gICAgICAgIGNvbnN0IHsgYW5jaG9yLCBmbG9hdGluZywgY29uZmlnIH0gPSBjdXJyZW50O1xuICAgICAgICBjb25zdCB2ZXJzaW9uID0gKytnZW5lcmF0aW9uO1xuICAgICAgICBjb25zdCByZWZlcmVuY2UgPSByZWZlcmVuY2VGb3IoYW5jaG9yLCBjb25maWcpO1xuICAgICAgICBjb25zdCBpc0N1cnJlbnQgPSAoKSA9PlxuICAgICAgICAgICFkaXNwb3NlZCAmJlxuICAgICAgICAgIHZlcnNpb24gPT09IGdlbmVyYXRpb24gJiZcbiAgICAgICAgICAhIXJlZmVyZW5jZT8uaXNMaXZlKCkgJiZcbiAgICAgICAgICAoIXN0cmF0ZWd5UGluIHx8IHN0cmF0ZWd5UGluLnN0eWxlcy5pc0N1cnJlbnQoKSk7XG4gICAgICAgIGlmIChkaXNwb3NlZCkgcmV0dXJuO1xuICAgICAgICBpZiAoIXJlZmVyZW5jZSB8fCAhaXNFbGVtZW50KGZsb2F0aW5nKSkge1xuICAgICAgICAgIGlmIChjdXJyZW50LnNpemVNYXRjaCAmJiB2ZXJzaW9uID09PSBnZW5lcmF0aW9uKSB7XG4gICAgICAgICAgICBjb25zdCBvd25TaXppbmcgPSBzaXppbmc7XG4gICAgICAgICAgICBjb25zdCBwcmVwYXJlZCA9IG93blNpemluZz8ucHJlcGFyZSgpO1xuICAgICAgICAgICAgaWYgKCFkaXNwb3NlZCAmJiB2ZXJzaW9uID09PSBnZW5lcmF0aW9uICYmIG93blNpemluZyA9PT0gc2l6aW5nKVxuICAgICAgICAgICAgICBjdXJyZW50Lm9uU2l6ZU1hdGNoPy4oXG4gICAgICAgICAgICAgICAgcHJlcGFyZWQgJiYgJ3N0YXR1cycgaW4gcHJlcGFyZWRcbiAgICAgICAgICAgICAgICAgID8gcHJlcGFyZWRcbiAgICAgICAgICAgICAgICAgIDogeyBzdGF0dXM6ICdwZW5kaW5nLXRhcmdldCcsIHJlYXNvbjogJ21pc3NpbmctdGFyZ2V0JyB9XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXN0cmF0ZWd5UGluIHx8IHN0cmF0ZWd5UGluLnRhcmdldCAhPT0gZmxvYXRpbmcpIHtcbiAgICAgICAgICByZXRpcmVTdHJhdGVneVBpbigpO1xuICAgICAgICAgIHN0cmF0ZWd5UGluID0geyB0YXJnZXQ6IGZsb2F0aW5nLCBzdHlsZXM6IG93blN0eWxlcyhmbG9hdGluZykgfTtcbiAgICAgICAgfVxuICAgICAgICBwaW5BbmNob3JlZFN0cmF0ZWd5KGZsb2F0aW5nLCBjb25maWcuc3RyYXRlZ3ksIHN0cmF0ZWd5UGluLnN0eWxlcyk7XG4gICAgICAgIGlmICghaXNDdXJyZW50KCkpIHJldHVybjtcbiAgICAgICAgaWYgKHNpemluZykge1xuICAgICAgICAgIGNvbnN0IG93blNpemluZyA9IHNpemluZztcbiAgICAgICAgICBmb3IgKGxldCBwYXNzID0gMDsgcGFzcyA8IDQ7IHBhc3MrKykge1xuICAgICAgICAgICAgaWYgKCFpc0N1cnJlbnQoKSB8fCBvd25TaXppbmcgIT09IHNpemluZykgcmV0dXJuO1xuICAgICAgICAgICAgY29uc3QgcHJlcGFyZWQgPSBvd25TaXppbmcucHJlcGFyZSgpO1xuICAgICAgICAgICAgaWYgKCdzdGF0dXMnIGluIHByZXBhcmVkKSB7XG4gICAgICAgICAgICAgIGlmIChpc0N1cnJlbnQoKSkgY3VycmVudC5vblNpemVNYXRjaD8uKHByZXBhcmVkKTtcbiAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGV0IGF2YWlsYWJsZTogeyB3aWR0aDogbnVtYmVyOyBoZWlnaHQ6IG51bWJlciB9IHwgbnVsbCA9IG51bGw7XG4gICAgICAgICAgICBsZXQgcmVzdWx0OiBBd2FpdGVkPFJldHVyblR5cGU8dHlwZW9mIGNvbXB1dGVQb3NpdGlvbj4+O1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgY29tcHV0ZVBvc2l0aW9uKHJlZmVyZW5jZS5yZWZlcmVuY2UsIGZsb2F0aW5nLCB7XG4gICAgICAgICAgICAgICAgcGxhY2VtZW50OiB0b1BsYWNlbWVudChjb25maWcpLFxuICAgICAgICAgICAgICAgIHN0cmF0ZWd5OiBjb25maWcuc3RyYXRlZ3ksXG4gICAgICAgICAgICAgICAgbWlkZGxld2FyZTogbWlkZGxld2FyZUZvcihjb25maWcsIGlzQ3VycmVudCwgKHdpZHRoLCBoZWlnaHQpID0+IHtcbiAgICAgICAgICAgICAgICAgIGF2YWlsYWJsZSA9IHsgd2lkdGgsIGhlaWdodCB9O1xuICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgIGlmIChpc0N1cnJlbnQoKSAmJiBvd25TaXppbmcgPT09IHNpemluZylcbiAgICAgICAgICAgICAgICBjdXJyZW50Lm9uU2l6ZU1hdGNoPy4ob3duU2l6aW5nLmZhaWwoJ2ludmFsaWQtZ2VvbWV0cnknKSk7XG4gICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghaXNDdXJyZW50KCkgfHwgb3duU2l6aW5nICE9PSBzaXppbmcpIHJldHVybjtcbiAgICAgICAgICAgIGNvbnN0IHZlcmlmaWVkID0gb3duU2l6aW5nLnZlcmlmeShhdmFpbGFibGUpO1xuICAgICAgICAgICAgaWYgKHZlcmlmaWVkLnN0YXR1cyA9PT0gJ3JlZmVyZW5jZS1jaGFuZ2VkJykgY29udGludWU7XG4gICAgICAgICAgICBpZiAodmVyaWZpZWQuc3RhdHVzICE9PSAnYXBwbGllZCcpIHtcbiAgICAgICAgICAgICAgaWYgKGlzQ3VycmVudCgpKSBjdXJyZW50Lm9uU2l6ZU1hdGNoPy4odmVyaWZpZWQpO1xuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBBIGNvbXBsZXRlZCBzb2x2ZSByZXBsYWNlcyB0aGUgdGVtcG9yYXJ5IHByZXBhcmF0aW9uLiBSZXN0b3JlXG4gICAgICAgICAgICAvLyBpdHMgb3JpZ2luYWwgZmllbGRzIGJlZm9yZSBwdWJsaXNoaW5nIGNvb3JkaW5hdGVzIHN5bmNocm9ub3VzbHk7XG4gICAgICAgICAgICAvLyBsYXRlciBkaXNwb3NhbCBtdXN0IG5vdCB1bmRvIGFuIGFscmVhZHkgcmVzb2x2ZWQgcGxhY2VtZW50LlxuICAgICAgICAgICAgcmV0aXJlU3RyYXRlZ3lQaW4oKTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgW25hbWUsIHZhbHVlXSBvZiBbXG4gICAgICAgICAgICAgIFsncG9zaXRpb24nLCByZXN1bHQuc3RyYXRlZ3ldLFxuICAgICAgICAgICAgICBbJ2xlZnQnLCBgJHtyZXN1bHQueH1weGBdLFxuICAgICAgICAgICAgICBbJ3RvcCcsIGAke3Jlc3VsdC55fXB4YF0sXG4gICAgICAgICAgICBdKSB7XG4gICAgICAgICAgICAgIGlmICghaXNDdXJyZW50KCkgfHwgb3duU2l6aW5nICE9PSBzaXppbmcpIHJldHVybjtcbiAgICAgICAgICAgICAgZmxvYXRpbmcuc3R5bGUuc2V0UHJvcGVydHkobmFtZSwgdmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgcmVzb2x2ZWQgPSBmcm9tUGxhY2VtZW50KHJlc3VsdC5wbGFjZW1lbnQpO1xuICAgICAgICAgICAgaWYgKCFpc0N1cnJlbnQoKSB8fCBvd25TaXppbmcgIT09IHNpemluZykgcmV0dXJuO1xuICAgICAgICAgICAgZmxvYXRpbmcuZGF0YXNldC5zaWRlID0gcmVzb2x2ZWQuc2lkZTtcbiAgICAgICAgICAgIGlmICghaXNDdXJyZW50KCkgfHwgb3duU2l6aW5nICE9PSBzaXppbmcpIHJldHVybjtcbiAgICAgICAgICAgIGZsb2F0aW5nLmRhdGFzZXQuYWxpZ24gPSByZXNvbHZlZC5hbGlnbjtcbiAgICAgICAgICAgIGlmICghaXNDdXJyZW50KCkgfHwgb3duU2l6aW5nICE9PSBzaXppbmcpIHJldHVybjtcbiAgICAgICAgICAgIC8vIEluc3RhbGxpbmcgZml4ZWQvYWJzb2x1dGUgcGxhY2VtZW50IG1heSBpdHNlbGYgYWx0ZXIgY29udGFpbmluZ1xuICAgICAgICAgICAgLy8gbGF5b3V0LiBDZXJ0aWZ5IHRoZSByZXN1bHRpbmcgdXNlZCBib3hlcywgbm90IG9ubHkgdGhlIHNvbHZlIGlucHV0LlxuICAgICAgICAgICAgY29uc3QgcGxhY2VkID0gb3duU2l6aW5nLnZlcmlmeShhdmFpbGFibGUpO1xuICAgICAgICAgICAgaWYgKHBsYWNlZC5zdGF0dXMgPT09ICdyZWZlcmVuY2UtY2hhbmdlZCcpIGNvbnRpbnVlO1xuICAgICAgICAgICAgaWYgKHBsYWNlZC5zdGF0dXMgIT09ICdhcHBsaWVkJykge1xuICAgICAgICAgICAgICBpZiAoaXNDdXJyZW50KCkpIGN1cnJlbnQub25TaXplTWF0Y2g/LihwbGFjZWQpO1xuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjdXJyZW50Lm9uUmVzb2x2ZWQ/Lih7IC4uLnJlc29sdmVkLCBzdHJhdGVneTogcmVzdWx0LnN0cmF0ZWd5IH0pO1xuICAgICAgICAgICAgaWYgKCFpc0N1cnJlbnQoKSB8fCBvd25TaXppbmcgIT09IHNpemluZykgcmV0dXJuO1xuICAgICAgICAgICAgLy8gVGhlIHJlc29sdmVkIGNhbGxiYWNrIGlzIGEgcmVlbnRyYW50IG93bmVyIGJvdW5kYXJ5IHRvby5cbiAgICAgICAgICAgIGNvbnN0IGRlbGl2ZXJlZCA9IG93blNpemluZy52ZXJpZnkoYXZhaWxhYmxlKTtcbiAgICAgICAgICAgIGlmIChkZWxpdmVyZWQuc3RhdHVzID09PSAncmVmZXJlbmNlLWNoYW5nZWQnKSBjb250aW51ZTtcbiAgICAgICAgICAgIGlmIChpc0N1cnJlbnQoKSAmJiBvd25TaXppbmcgPT09IHNpemluZykgY3VycmVudC5vblNpemVNYXRjaD8uKGRlbGl2ZXJlZCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChpc0N1cnJlbnQoKSAmJiBvd25TaXppbmcgPT09IHNpemluZylcbiAgICAgICAgICAgIGN1cnJlbnQub25TaXplTWF0Y2g/Lihvd25TaXppbmcuZmFpbCgnaW52YWxpZC1nZW9tZXRyeScpKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29tcHV0ZVBvc2l0aW9uKHJlZmVyZW5jZS5yZWZlcmVuY2UsIGZsb2F0aW5nLCB7XG4gICAgICAgICAgcGxhY2VtZW50OiB0b1BsYWNlbWVudChjb25maWcpLFxuICAgICAgICAgIHN0cmF0ZWd5OiBjb25maWcuc3RyYXRlZ3ksXG4gICAgICAgICAgbWlkZGxld2FyZTogbWlkZGxld2FyZUZvcihjb25maWcsIGlzQ3VycmVudCksXG4gICAgICAgIH0pO1xuICAgICAgICBpZiAoIWlzQ3VycmVudCgpKSByZXR1cm47XG4gICAgICAgIHJldGlyZVN0cmF0ZWd5UGluKCk7XG4gICAgICAgIGlmICghaXNDdXJyZW50KCkpIHJldHVybjtcbiAgICAgICAgT2JqZWN0LmFzc2lnbihmbG9hdGluZy5zdHlsZSwge1xuICAgICAgICAgIHBvc2l0aW9uOiByZXN1bHQuc3RyYXRlZ3ksXG4gICAgICAgICAgbGVmdDogYCR7cmVzdWx0Lnh9cHhgLFxuICAgICAgICAgIHRvcDogYCR7cmVzdWx0Lnl9cHhgLFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgcmVzb2x2ZWQgPSBmcm9tUGxhY2VtZW50KHJlc3VsdC5wbGFjZW1lbnQpO1xuICAgICAgICBmbG9hdGluZy5kYXRhc2V0LnNpZGUgPSByZXNvbHZlZC5zaWRlO1xuICAgICAgICBmbG9hdGluZy5kYXRhc2V0LmFsaWduID0gcmVzb2x2ZWQuYWxpZ247XG4gICAgICAgIGN1cnJlbnQub25SZXNvbHZlZD8uKHsgLi4ucmVzb2x2ZWQsIHN0cmF0ZWd5OiByZXN1bHQuc3RyYXRlZ3kgfSk7XG4gICAgICB9O1xuXG4gICAgICBjb25zdCByZXN0YXJ0ID0gKCkgPT4ge1xuICAgICAgICBjbGVhbnVwPy4oKTtcbiAgICAgICAgY2xlYW51cCA9IG51bGw7XG4gICAgICAgIHJldGlyZVNpemluZygpO1xuICAgICAgICByZXRpcmVTdHJhdGVneVBpbigpO1xuICAgICAgICBpZiAoY29ubmVjdGlvbi5zaXplTWF0Y2gpIHtcbiAgICAgICAgICBjb25zdCBlcG9jaCA9IHNpemluZ0Vwb2NoO1xuICAgICAgICAgIHNpemluZyA9IGNyZWF0ZUVkZ2VTaXplTGVhc2UoY29ubmVjdGlvbiwgKCkgPT4gIWRpc3Bvc2VkICYmIGVwb2NoID09PSBzaXppbmdFcG9jaCk7XG4gICAgICAgICAgY29uc3QgdmlldyA9IGlzRWxlbWVudChjb25uZWN0aW9uLmZsb2F0aW5nKVxuICAgICAgICAgICAgPyBjb25uZWN0aW9uLmZsb2F0aW5nLm93bmVyRG9jdW1lbnQuZGVmYXVsdFZpZXdcbiAgICAgICAgICAgIDogbnVsbDtcbiAgICAgICAgICBpZiAodHlwZW9mIHZpZXc/LlJlc2l6ZU9ic2VydmVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAvLyBBIHRhcmdldCByZXRhaW5zIG9uZSBib3ggcmVnaXN0cmF0aW9uIHBlciBvYnNlcnZlciwgbm90IHR3by5cbiAgICAgICAgICAgIHNpemVPYnNlcnZlcnMgPSAoWydjb250ZW50LWJveCcsICdib3JkZXItYm94J10gYXMgY29uc3QpLm1hcCgoYm94KSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IG9ic2VydmVyID0gbmV3IHZpZXcuUmVzaXplT2JzZXJ2ZXIoKCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmICghZGlzcG9zZWQgJiYgZXBvY2ggPT09IHNpemluZ0Vwb2NoKSB2b2lkIHBvc2l0aW9uKCk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICBmb3IgKGNvbnN0IHRhcmdldCBvZiBzaXppbmchLm9ic2VydmVkKSBvYnNlcnZlci5vYnNlcnZlKHRhcmdldCwgeyBib3ggfSk7XG4gICAgICAgICAgICAgIHJldHVybiBvYnNlcnZlcjtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCB7IGFuY2hvciwgZmxvYXRpbmcgfSA9IGNvbm5lY3Rpb247XG4gICAgICAgIGNvbnN0IHJlZmVyZW5jZSA9IHJlZmVyZW5jZUZvcihhbmNob3IsIGNvbm5lY3Rpb24uY29uZmlnKTtcbiAgICAgICAgaWYgKCFyZWZlcmVuY2UgfHwgIWlzRWxlbWVudChmbG9hdGluZykpIHtcbiAgICAgICAgICBpZiAoY29ubmVjdGlvbi5zaXplTWF0Y2gpIHZvaWQgcG9zaXRpb24oKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc3RvcEF1dG8gPSBhdXRvVXBkYXRlKHJlZmVyZW5jZS5yZWZlcmVuY2UsIGZsb2F0aW5nLCBwb3NpdGlvbiwge1xuICAgICAgICAgIGFuaW1hdGlvbkZyYW1lOiBmYWxzZSxcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IHN0b3BSb290ID0gb2JzZXJ2ZVJvb3RTcGFjZShyZWZlcmVuY2UuZWxlbWVudC5vd25lckRvY3VtZW50LCAoKSA9PiB7XG4gICAgICAgICAgdm9pZCBwb3NpdGlvbigpO1xuICAgICAgICB9KTtcbiAgICAgICAgLy8gYXV0b1VwZGF0ZSByZWNvcmRzIG92ZXJmbG93IGFuY2VzdG9ycyBvbmx5IG9uY2UuIEEgc2Nyb2xsZXIgdGhhdFxuICAgICAgICAvLyBiZWNvbWVzIG92ZXJmbG93OmF1dG8gYWZ0ZXIgdGhlIHBvcHVwIG9wZW5zIChuZXN0ZWQgZGVtbyBwYW5lcylcbiAgICAgICAgLy8gbmV2ZXIgbm90aWZpZXMgdGhhdCBsaXN0LCBzbyB0aGUgZml4ZWQgcG9wcGVyIGtlZXBzIGl0cyBwcmUtc2Nyb2xsXG4gICAgICAgIC8vIGNvb3JkaW5hdGVzLiBFbGVtZW50IHNjcm9sbCBkb2VzIG5vdCBidWJibGUsIGJ1dCBpdCBpcyBvYnNlcnZhYmxlXG4gICAgICAgIC8vIGluIHRoZSBjYXB0dXJlIHBoYXNlIG9uIHRoZSBkb2N1bWVudC5cbiAgICAgICAgY29uc3Qgb3duZXJEb2N1bWVudCA9IHJlZmVyZW5jZS5lbGVtZW50Lm93bmVyRG9jdW1lbnQ7XG4gICAgICAgIGNvbnN0IG9uQ2FwdHVyZWRTY3JvbGwgPSAoKSA9PiB7XG4gICAgICAgICAgdm9pZCBwb3NpdGlvbigpO1xuICAgICAgICB9O1xuICAgICAgICBvd25lckRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIG9uQ2FwdHVyZWRTY3JvbGwsIHRydWUpO1xuICAgICAgICBjb25zdCBzdG9wSW52YWxpZGF0aW9uID0gcmVzb2x2ZVdlYklucHV0T3JpZ2luQW5jaG9yKGFuY2hvcik/LnN1YnNjcmliZUludmFsaWRhdGlvbigoKSA9PiB7XG4gICAgICAgICAgZ2VuZXJhdGlvbisrO1xuICAgICAgICAgIHJldGlyZVNpemluZygpO1xuICAgICAgICAgIHJldGlyZVN0cmF0ZWd5UGluKCk7XG4gICAgICAgICAgY2xlYW51cD8uKCk7XG4gICAgICAgICAgY2xlYW51cCA9IG51bGw7XG4gICAgICAgIH0pO1xuICAgICAgICBjbGVhbnVwID0gKCkgPT4ge1xuICAgICAgICAgIHN0b3BBdXRvKCk7XG4gICAgICAgICAgc3RvcFJvb3QoKTtcbiAgICAgICAgICBzdG9wSW52YWxpZGF0aW9uPy4oKTtcbiAgICAgICAgICBvd25lckRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIG9uQ2FwdHVyZWRTY3JvbGwsIHRydWUpO1xuICAgICAgICB9O1xuICAgICAgfTtcblxuICAgICAgcmVzdGFydCgpO1xuXG4gICAgICByZXR1cm4ge1xuICAgICAgICB1cGRhdGUobmV4dCkge1xuICAgICAgICAgIGlmIChkaXNwb3NlZCkgcmV0dXJuO1xuICAgICAgICAgIGdlbmVyYXRpb24gKz0gMTtcbiAgICAgICAgICBjb25zdCB0YXJnZXRzQ2hhbmdlZCA9XG4gICAgICAgICAgICAhT2JqZWN0LmlzKGNvbm5lY3Rpb24uYW5jaG9yLCBuZXh0LmFuY2hvcikgfHxcbiAgICAgICAgICAgICFPYmplY3QuaXMoY29ubmVjdGlvbi5mbG9hdGluZywgbmV4dC5mbG9hdGluZykgfHxcbiAgICAgICAgICAgIEJvb2xlYW4oY29ubmVjdGlvbi50YXJnZXRBbGlnbm1lbnQpICE9PSBCb29sZWFuKG5leHQudGFyZ2V0QWxpZ25tZW50KSB8fFxuICAgICAgICAgICAgQm9vbGVhbihjb25uZWN0aW9uLnNpemVNYXRjaCkgIT09IEJvb2xlYW4obmV4dC5zaXplTWF0Y2gpIHx8XG4gICAgICAgICAgICAoISFjb25uZWN0aW9uLnNpemVNYXRjaCAmJlxuICAgICAgICAgICAgICAhIW5leHQuc2l6ZU1hdGNoICYmXG4gICAgICAgICAgICAgIChjb25uZWN0aW9uLnNpemVNYXRjaC5yZWZlcmVuY2UgIT09IG5leHQuc2l6ZU1hdGNoLnJlZmVyZW5jZSB8fFxuICAgICAgICAgICAgICAgIGNvbm5lY3Rpb24uc2l6ZU1hdGNoLnRhcmdldHMubGVuZ3RoICE9PSBuZXh0LnNpemVNYXRjaC50YXJnZXRzLmxlbmd0aCB8fFxuICAgICAgICAgICAgICAgIGNvbm5lY3Rpb24uc2l6ZU1hdGNoLnRhcmdldHMuc29tZShcbiAgICAgICAgICAgICAgICAgICh0YXJnZXQsIGluZGV4KSA9PiB0YXJnZXQgIT09IG5leHQuc2l6ZU1hdGNoIS50YXJnZXRzW2luZGV4XVxuICAgICAgICAgICAgICAgICkpKTtcbiAgICAgICAgICBjb25uZWN0aW9uID0gbmV4dDtcbiAgICAgICAgICAvLyBBIG5ldyBleHBsaWNpdCBzaXppbmcgY29ubmVjdGlvbiBpcyBhIG5ldyBvd25lciBnZW5lcmF0aW9uIGV2ZW5cbiAgICAgICAgICAvLyB3aGVuIGl0cyBlbGVtZW50IGlkZW50aXRpZXMgc3RheSBlcXVhbC4gUmVlbnRyYW50IGNvbmZpZy9zdGF0dXNcbiAgICAgICAgICAvLyBoYW5kb2ZmcyBtdXN0IG5vdCBsZWF2ZSB0aGUgcHJpb3Igc3luY2hyb25vdXMgc2l6ZSB3cml0ZXIgY3VycmVudC5cbiAgICAgICAgICBpZiAodGFyZ2V0c0NoYW5nZWQgfHwgbmV4dC5zaXplTWF0Y2gpIHJlc3RhcnQoKTtcbiAgICAgICAgICBlbHNlIHZvaWQgcG9zaXRpb24oKTtcbiAgICAgICAgfSxcbiAgICAgICAgcmVxdWVzdFVwZGF0ZSgpIHtcbiAgICAgICAgICB2b2lkIHBvc2l0aW9uKCk7XG4gICAgICAgIH0sXG4gICAgICAgIGRpc3Bvc2UoKSB7XG4gICAgICAgICAgZGlzcG9zZWQgPSB0cnVlO1xuICAgICAgICAgIGdlbmVyYXRpb24gKz0gMTtcbiAgICAgICAgICByZXRpcmVTaXppbmcoKTtcbiAgICAgICAgICByZXRpcmVTdHJhdGVneVBpbigpO1xuICAgICAgICAgIGNsZWFudXA/LigpO1xuICAgICAgICAgIGNsZWFudXAgPSBudWxsO1xuICAgICAgICB9LFxuICAgICAgfTtcbiAgICB9LFxuICB9O1xufVxuXG4vKiogQm90aCBwb2xpY2llcyBzaGFyZSBvbmUgaG9zdCBjYXBhYmlsaXR5OyB0aGUgZGVzY3JpcHRvciBzZWxlY3RzIGdlb21ldHJ5LCBub3QgYSBjb21wb25lbnQuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlRmxvYXRpbmdVaUFuY2hvcmVkUG9zaXRpb25Ib3N0KCk6IEFuY2hvcmVkUG9zaXRpb25Ib3N0IHtcbiAgY29uc3QgZWRnZSA9IGNyZWF0ZUVkZ2VBbmNob3JlZFBvc2l0aW9uSG9zdCgpO1xuICByZXR1cm4ge1xuICAgIHN1cHBvcnRzVGFyZ2V0QWxpZ25tZW50OiB0cnVlLFxuICAgIHN1cHBvcnRzU2l6ZU1hdGNoOiB0cnVlLFxuICAgIGF0dGFjaChpbml0aWFsKSB7XG4gICAgICBsZXQgY29ubmVjdGlvbiA9IGluaXRpYWw7XG4gICAgICBsZXQgZGlzcG9zZWQgPSBmYWxzZTtcbiAgICAgIGNvbnN0IGFjcXVpcmUgPSAobmV4dDogQW5jaG9yZWRQb3NpdGlvbkNvbm5lY3Rpb24pID0+XG4gICAgICAgIG5leHQudGFyZ2V0QWxpZ25tZW50ICYmICFuZXh0LnNpemVNYXRjaFxuICAgICAgICAgID8gY3JlYXRlVGFyZ2V0QWxpZ25tZW50TGVhc2UobmV4dClcbiAgICAgICAgICA6IGVkZ2UuYXR0YWNoKG5leHQpO1xuICAgICAgbGV0IGxlYXNlOiBSZXR1cm5UeXBlPHR5cGVvZiBhY3F1aXJlPiB8IG51bGwgPSBhY3F1aXJlKGluaXRpYWwpO1xuICAgICAgbGV0IGdlbmVyYXRpb24gPSAwO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdXBkYXRlKG5leHQpIHtcbiAgICAgICAgICBpZiAoZGlzcG9zZWQpIHJldHVybjtcbiAgICAgICAgICBjb25zdCBjaGFuZ2VkID1cbiAgICAgICAgICAgIEJvb2xlYW4oY29ubmVjdGlvbi50YXJnZXRBbGlnbm1lbnQgJiYgIWNvbm5lY3Rpb24uc2l6ZU1hdGNoKSAhPT1cbiAgICAgICAgICAgIEJvb2xlYW4obmV4dC50YXJnZXRBbGlnbm1lbnQgJiYgIW5leHQuc2l6ZU1hdGNoKTtcbiAgICAgICAgICBjb25uZWN0aW9uID0gbmV4dDtcbiAgICAgICAgICBpZiAoIWNoYW5nZWQgJiYgbGVhc2UpIHtcbiAgICAgICAgICAgIGxlYXNlLnVwZGF0ZShuZXh0KTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgcmVxdWVzdCA9ICsrZ2VuZXJhdGlvbjtcbiAgICAgICAgICBjb25zdCBwcmV2aW91cyA9IGxlYXNlO1xuICAgICAgICAgIGxlYXNlID0gbnVsbDtcbiAgICAgICAgICBwcmV2aW91cz8uZGlzcG9zZSgpO1xuICAgICAgICAgIGlmIChkaXNwb3NlZCB8fCByZXF1ZXN0ICE9PSBnZW5lcmF0aW9uIHx8IGNvbm5lY3Rpb24gIT09IG5leHQpIHJldHVybjtcbiAgICAgICAgICBjb25zdCBhY3F1aXJlZCA9IGFjcXVpcmUobmV4dCk7XG4gICAgICAgICAgaWYgKGRpc3Bvc2VkIHx8IHJlcXVlc3QgIT09IGdlbmVyYXRpb24gfHwgY29ubmVjdGlvbiAhPT0gbmV4dCkgYWNxdWlyZWQuZGlzcG9zZSgpO1xuICAgICAgICAgIGVsc2UgbGVhc2UgPSBhY3F1aXJlZDtcbiAgICAgICAgfSxcbiAgICAgICAgcmVxdWVzdFVwZGF0ZSgpIHtcbiAgICAgICAgICBpZiAoIWRpc3Bvc2VkKSBsZWFzZT8ucmVxdWVzdFVwZGF0ZSgpO1xuICAgICAgICB9LFxuICAgICAgICBkaXNwb3NlKCkge1xuICAgICAgICAgIGlmIChkaXNwb3NlZCkgcmV0dXJuO1xuICAgICAgICAgIGRpc3Bvc2VkID0gdHJ1ZTtcbiAgICAgICAgICBnZW5lcmF0aW9uKys7XG4gICAgICAgICAgY29uc3QgcHJldmlvdXMgPSBsZWFzZTtcbiAgICAgICAgICBsZWFzZSA9IG51bGw7XG4gICAgICAgICAgcHJldmlvdXM/LmRpc3Bvc2UoKTtcbiAgICAgICAgfSxcbiAgICAgIH07XG4gICAgfSxcbiAgfTtcbn1cbiIsICJcbmltcG9ydCB7IGNyZWF0ZUZsb2F0aW5nVWlBbmNob3JlZFBvc2l0aW9uSG9zdCB9IGZyb20gJy4vcGFja2FnZXMvbW9kdWxlcy9wb3NpdGlvbmluZy9zcmMvd2ViL2Zsb2F0aW5nLXVpLWhvc3QudHMnO1xuXG5jb25zdCBsYWJlbHMgPSBbJ1dlYiBDb21wb25lbnRzJywgJ1JlYWN0JywgJ1Z1ZScsICdWdWUgMiddO1xuY29uc3QgbG9uZ0hlaWdodHMgPSBbMTA0LCA2NCwgNjQsIDY0XTtcbmxldCBhbmNob3I7XG5sZXQgZmxvYXRpbmc7XG5sZXQgb3JpZ2luYWxGbG9hdGluZztcbmxldCBzdXJmYWNlO1xubGV0IHZpZXdwb3J0O1xubGV0IHJvd3MgPSBbXTtcbmxldCBsZWFzZTtcbmxldCBjb25maWc7XG5sZXQgY29tcG9zaXRpb247XG5sZXQgZXBvY2ggPSAwO1xubGV0IG5hdHVyYWw7XG5jb25zdCByZXNvbHV0aW9ucyA9IFtdO1xuY29uc3QgYm94ID0gKGVsZW1lbnQpID0+IGVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkudG9KU09OKCk7XG5jb25zdCBsYXllciA9IChlbGVtZW50KSA9PiB7XG4gIGNvbnN0IGNvbXB1dGVkID0gZ2V0Q29tcHV0ZWRTdHlsZShlbGVtZW50KTtcbiAgcmV0dXJuIHtcbiAgICBpZDogZWxlbWVudC5pZCxcbiAgICBjb25uZWN0ZWQ6IGVsZW1lbnQuaXNDb25uZWN0ZWQsXG4gICAgYm94OiBib3goZWxlbWVudCksXG4gICAgY2xpZW50SGVpZ2h0OiBlbGVtZW50LmNsaWVudEhlaWdodCxcbiAgICBvZmZzZXRIZWlnaHQ6IGVsZW1lbnQub2Zmc2V0SGVpZ2h0LFxuICAgIHNjcm9sbEhlaWdodDogZWxlbWVudC5zY3JvbGxIZWlnaHQsXG4gICAgc2Nyb2xsVG9wOiBlbGVtZW50LnNjcm9sbFRvcCxcbiAgICBkaXNwbGF5OiBjb21wdXRlZC5kaXNwbGF5LFxuICAgIG1heEhlaWdodDogY29tcHV0ZWQubWF4SGVpZ2h0LFxuICAgIG92ZXJmbG93WTogY29tcHV0ZWQub3ZlcmZsb3dZLFxuICAgIHBvc2l0aW9uOiBjb21wdXRlZC5wb3NpdGlvbixcbiAgICB0cmFuc2Zvcm06IGNvbXB1dGVkLnRyYW5zZm9ybSxcbiAgICBhdmFpbGFibGVIZWlnaHQ6IGNvbXB1dGVkLmdldFByb3BlcnR5VmFsdWUoJy0tcHJvdG8tdWktYXZhaWxhYmxlLWhlaWdodCcpLFxuICAgIGF2YWlsYWJsZVdpZHRoOiBjb21wdXRlZC5nZXRQcm9wZXJ0eVZhbHVlKCctLXByb3RvLXVpLWF2YWlsYWJsZS13aWR0aCcpLFxuICAgIGlubGluZVN0eWxlOiBlbGVtZW50LmdldEF0dHJpYnV0ZSgnc3R5bGUnKSxcbiAgfTtcbn07XG5jb25zdCBmYWN0cyA9ICgpID0+ICh7XG4gIGNvbXBvc2l0aW9uLFxuICBlcG9jaCxcbiAgc2FtZUNvbnRlbnQ6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdmbG9hdGluZycpID09PSBvcmlnaW5hbEZsb2F0aW5nLFxuICBzYW1lUm93czogcm93cy5ldmVyeSgocm93LCBpbmRleCkgPT4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvdy0nICsgaW5kZXgpID09PSByb3cpLFxuICBuYXR1cmFsLFxuICBzaWRlOiBmbG9hdGluZy5kYXRhc2V0LnNpZGUgPz8gbnVsbCxcbiAgYWxpZ246IGZsb2F0aW5nLmRhdGFzZXQuYWxpZ24gPz8gbnVsbCxcbiAgYW5jaG9yOiBib3goYW5jaG9yKSxcbiAgZnJhbWU6IGxheWVyKGZsb2F0aW5nKSxcbiAgc3VyZmFjZTogc3VyZmFjZSA/IGxheWVyKHN1cmZhY2UpIDogbnVsbCxcbiAgdmlld3BvcnQ6IGxheWVyKHZpZXdwb3J0KSxcbiAgd2luZG93OiB7IHdpZHRoOiBpbm5lcldpZHRoLCBoZWlnaHQ6IGlubmVySGVpZ2h0IH0sXG4gIHJvd3M6IHJvd3MubWFwKChyb3cpID0+IHtcbiAgICBjb25zdCBib3VuZHMgPSByb3cuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgY29uc3QgY2VudGVyID0gZG9jdW1lbnQuZWxlbWVudEZyb21Qb2ludChcbiAgICAgIGJvdW5kcy54ICsgYm91bmRzLndpZHRoIC8gMixcbiAgICAgIGJvdW5kcy55ICsgYm91bmRzLmhlaWdodCAvIDJcbiAgICApO1xuICAgIGNvbnN0IHJhbmdlID0gZG9jdW1lbnQuY3JlYXRlUmFuZ2UoKTtcbiAgICByYW5nZS5zZWxlY3ROb2RlQ29udGVudHMocm93LmZpcnN0RWxlbWVudENoaWxkKTtcbiAgICByZXR1cm4ge1xuICAgICAgdGV4dDogcm93LnRleHRDb250ZW50LFxuICAgICAgYm94OiBib3VuZHMudG9KU09OKCksXG4gICAgICBsaW5lczogWy4uLnJhbmdlLmdldENsaWVudFJlY3RzKCldLm1hcCgoZW50cnkpID0+IGVudHJ5LnRvSlNPTigpKSxcbiAgICAgIG93bnNDZW50ZXI6IGNlbnRlciA9PT0gcm93IHx8ICghIWNlbnRlciAmJiByb3cuY29udGFpbnMoY2VudGVyKSksXG4gICAgfTtcbiAgfSksXG4gIHJlc29sdXRpb25zOiByZXNvbHV0aW9ucy5zbGljZSgpLFxufSk7XG5jb25zdCBhdHRhY2ggPSAoKSA9PiB7XG4gIGNvbnN0IG93bkVwb2NoID0gKytlcG9jaDtcbiAgbGVhc2UgPSBjcmVhdGVGbG9hdGluZ1VpQW5jaG9yZWRQb3NpdGlvbkhvc3QoKS5hdHRhY2goe1xuICAgIGFuY2hvcixcbiAgICBmbG9hdGluZyxcbiAgICBjb25maWcsXG4gICAgb25SZXNvbHZlZChzbmFwc2hvdCkge1xuICAgICAgaWYgKHJlc29sdXRpb25zLmxlbmd0aCA8IDQ4KSB7XG4gICAgICAgIHJlc29sdXRpb25zLnB1c2goe1xuICAgICAgICAgIGVwb2NoOiBvd25FcG9jaCxcbiAgICAgICAgICBhdDogcGVyZm9ybWFuY2Uubm93KCksXG4gICAgICAgICAgc25hcHNob3QsXG4gICAgICAgICAgZnJhbWU6IGxheWVyKGZsb2F0aW5nKSxcbiAgICAgICAgICB2aWV3cG9ydDogbGF5ZXIodmlld3BvcnQpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9LFxuICB9KTtcbn07XG5jb25zdCBjcmVhdGUgPSAob3B0aW9ucykgPT4ge1xuICBsZWFzZT8uZGlzcG9zZSgpO1xuICByZXNvbHV0aW9ucy5sZW5ndGggPSAwO1xuICBlcG9jaCA9IDA7XG4gIGNvbXBvc2l0aW9uID0gb3B0aW9ucy5jb21wb3NpdGlvbjtcbiAgZG9jdW1lbnQuYm9keS5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgYW5jaG9yID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYnV0dG9uJyk7XG4gIGFuY2hvci5pZCA9ICdhbmNob3InO1xuICBhbmNob3IudHlwZSA9ICdidXR0b24nO1xuICBhbmNob3IudGV4dENvbnRlbnQgPSAnQW5jaG9yJztcbiAgZmxvYXRpbmcgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgb3JpZ2luYWxGbG9hdGluZyA9IGZsb2F0aW5nO1xuICBmbG9hdGluZy5pZCA9ICdmbG9hdGluZyc7XG4gIGZsb2F0aW5nLmNsYXNzTmFtZSA9ICdmbG9hdGluZyAnICsgY29tcG9zaXRpb247XG4gIGZsb2F0aW5nLnNldEF0dHJpYnV0ZSgncm9sZScsICdsaXN0Ym94Jyk7XG4gIHN1cmZhY2UgPSBudWxsO1xuICB2aWV3cG9ydCA9IGZsb2F0aW5nO1xuICBpZiAoY29tcG9zaXRpb24gPT09ICduZXN0ZWQnKSB7XG4gICAgc3VyZmFjZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHN1cmZhY2UuaWQgPSAnc3VyZmFjZSc7XG4gICAgc3VyZmFjZS5jbGFzc05hbWUgPSAnc3VyZmFjZSc7XG4gICAgdmlld3BvcnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICB2aWV3cG9ydC5pZCA9ICd2aWV3cG9ydCc7XG4gICAgdmlld3BvcnQuY2xhc3NOYW1lID0gJ3ZpZXdwb3J0JztcbiAgICBzdXJmYWNlLmFwcGVuZCh2aWV3cG9ydCk7XG4gICAgZmxvYXRpbmcuYXBwZW5kKHN1cmZhY2UpO1xuICB9XG4gIHJvd3MgPSBsYWJlbHMubWFwKChsYWJlbCwgaW5kZXgpID0+IHtcbiAgICBjb25zdCByb3cgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICByb3cuaWQgPSAncm93LScgKyBpbmRleDtcbiAgICByb3cuY2xhc3NOYW1lID0gJ3Jvdyc7XG4gICAgcm93LnNldEF0dHJpYnV0ZSgncm9sZScsICdvcHRpb24nKTtcbiAgICByb3cuc3R5bGUuaGVpZ2h0ID0gKG9wdGlvbnMuc2hvcnQgPyA0MCA6IGxvbmdIZWlnaHRzW2luZGV4XSkgKyAncHgnO1xuICAgIGNvbnN0IHRleHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgdGV4dC50ZXh0Q29udGVudCA9IGxhYmVsO1xuICAgIHJvdy5hcHBlbmQodGV4dCk7XG4gICAgdmlld3BvcnQuYXBwZW5kKHJvdyk7XG4gICAgcmV0dXJuIHJvdztcbiAgfSk7XG4gIGRvY3VtZW50LmJvZHkuYXBwZW5kKGFuY2hvciwgZmxvYXRpbmcpO1xuICAvLyBUaGUgb25seSB1bmNvbnN0cmFpbmVkIG1lYXN1cmVtZW50IGhhcHBlbnMgYmVmb3JlIGFueSBob3N0IGxlYXNlIGV4aXN0cy5cbiAgLy8gSXQgaXMgYSByZWFsIERPTSBwcmVtaXNlLCBub3QgYSBtb2NrZWQgcmVjdGFuZ2xlIG9yIGFuIGFjY2VwdGVkIGZpbmFsIHBsYWNlbWVudC5cbiAgbmF0dXJhbCA9IHtcbiAgICBmcmFtZTogYm94KGZsb2F0aW5nKSxcbiAgICB2aWV3cG9ydDogYm94KHZpZXdwb3J0KSxcbiAgICByb3dzOiByb3dzLm1hcChib3gpLFxuICB9O1xuICBpZiAob3B0aW9ucy5oaWRkZW4pIGZsb2F0aW5nLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG4gIGNvbmZpZyA9IHtcbiAgICBzaWRlOiAnYm90dG9tJyxcbiAgICBhbGlnbjogJ3N0YXJ0JyxcbiAgICBzaWRlT2Zmc2V0OiA0LFxuICAgIGFsaWduT2Zmc2V0OiAwLFxuICAgIHN0cmF0ZWd5OiAnZml4ZWQnLFxuICAgIGF2b2lkQ29sbGlzaW9uczogb3B0aW9ucy5hdm9pZENvbGxpc2lvbnMsXG4gICAgY29sbGlzaW9uQm91bmRhcnk6ICdjbGlwcGluZ0FuY2VzdG9ycycsXG4gICAgY29sbGlzaW9uUGFkZGluZzogMTAsXG4gIH07XG4gIGF0dGFjaCgpO1xuICByZXR1cm4gZmFjdHMoKTtcbn07XG5jb25zdCBoaWRkZW5MYXlvdXRDaGVja3BvaW50ID0gYXN5bmMgKCkgPT4ge1xuICAvLyBBIGNvbnRyb2xsZWQgaG9zdC1sYXlvdXQgb3JkZXJpbmc6IGxldCByZWFsIGhpZGRlbi12aWV3IHVwZGF0ZXMgcnVuIGJlZm9yZSByZXZlYWwuXG4gIC8vIFRoaXMgZG9lcyBub3QgYWRkIHRpbWUgdG8sIG9yIHJlcGxhY2UsIHRoZSBvcmlnaW5hbCB3ZWJzaXRlJ3MgdmlzaWJpbGl0eSBvcmFjbGUuXG4gIGF3YWl0IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiByZXF1ZXN0QW5pbWF0aW9uRnJhbWUocmVzb2x2ZSkpO1xuICBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHJlc29sdmUpKTtcbiAgcmV0dXJuIGZhY3RzKCk7XG59O1xuY29uc3QgcmVvcGVuV2l0aExvbmdDb250ZW50ID0gKCkgPT4ge1xuICBmbG9hdGluZy5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuICBsZWFzZS5kaXNwb3NlKCk7XG4gIHJvd3MuZm9yRWFjaCgocm93LCBpbmRleCkgPT4geyByb3cuc3R5bGUuaGVpZ2h0ID0gbG9uZ0hlaWdodHNbaW5kZXhdICsgJ3B4JzsgfSk7XG4gIC8vIEtlZXAgdGhlIGV4YWN0IENvbnRlbnQgYW5kIHJvdyBub2RlcywgaW5jbHVkaW5nIGFueSBzdHlsZXMgdGhlIG9sZCBsZWFzZSByZXRhaW5lZC5cbiAgYXR0YWNoKCk7XG4gIHJldHVybiBmYWN0cygpO1xufTtcbmNvbnN0IHJldmVhbEFuZFJlcXVlc3RVcGRhdGUgPSAoKSA9PiB7XG4gIGZsb2F0aW5nLnN0eWxlLnJlbW92ZVByb3BlcnR5KCdkaXNwbGF5Jyk7XG4gIGxlYXNlLnJlcXVlc3RVcGRhdGUoKTtcbiAgcmV0dXJuIGZhY3RzKCk7XG59O1xuZ2xvYmFsVGhpcy5wb3NpdGlvbmluZ0NvbGRTaXplRml4dHVyZSA9IHtcbiAgY3JlYXRlLFxuICBmYWN0cyxcbiAgaGlkZGVuTGF5b3V0Q2hlY2twb2ludCxcbiAgcmVvcGVuV2l0aExvbmdDb250ZW50LFxuICByZXZlYWxBbmRSZXF1ZXN0VXBkYXRlLFxuICBkaXNwb3NlKCkgeyBsZWFzZT8uZGlzcG9zZSgpOyB9LFxufTtcbiJdLAogICJtYXBwaW5ncyI6ICI7O0FBQ0EsTUFBTSxjQUFjLG9CQUFJLFFBQThDO0FBRy9ELFdBQVMsVUFBVSxRQUFxQjtBQUM3QyxVQUFNLFNBQVMsb0JBQUksSUFBd0I7QUFDM0MsUUFBSSxTQUFTLFlBQVksSUFBSSxNQUFNO0FBQ25DLFFBQUksQ0FBQyxRQUFRO0FBQ1gsZUFBUyxvQkFBSSxJQUFJO0FBQ2pCLGtCQUFZLElBQUksUUFBUSxNQUFNO0FBQUEsSUFDaEM7QUFDQSxVQUFNLGdCQUFnQjtBQUN0QixRQUFJLE9BQU87QUFDWCxVQUFNLFVBQVUsQ0FBQyxNQUFjLFdBQzdCLE9BQU8sTUFBTSxpQkFBaUIsSUFBSSxNQUFNLE9BQU8sV0FDL0MsT0FBTyxNQUFNLG9CQUFvQixJQUFJLE1BQU07QUFDN0MsV0FBTztBQUFBLE1BQ0wsWUFBcUI7QUFDbkIsZUFDRSxDQUFDLFFBQ0QsTUFBTSxLQUFLLE1BQU0sRUFBRTtBQUFBLFVBQ2pCLENBQUMsQ0FBQyxNQUFNLE1BQU0sTUFBTSxjQUFjLElBQUksSUFBSSxNQUFNLFVBQVUsUUFBUSxNQUFNLE1BQU07QUFBQSxRQUNoRjtBQUFBLE1BRUo7QUFBQSxNQUNBLE1BQU0sTUFBYyxPQUF3QjtBQUMxQyxZQUFJLEtBQU0sUUFBTztBQUNqQixZQUFJLFNBQVMsT0FBTyxJQUFJLElBQUk7QUFDNUIsWUFBSSxXQUFXLGNBQWMsSUFBSSxJQUFJLE1BQU0sVUFBVSxDQUFDLFFBQVEsTUFBTSxNQUFNLElBQUk7QUFDNUUsaUJBQU87QUFDUCxpQkFBTztBQUFBLFFBQ1Q7QUFDQSxZQUFJLENBQUMsUUFBUTtBQUNYLGdCQUFNLFFBQVEsY0FBYyxJQUFJLElBQUk7QUFDcEMsZ0JBQU0sVUFBVSxTQUFTLFFBQVEsTUFBTSxLQUFLO0FBQzVDLG1CQUFTO0FBQUEsWUFDUCxRQUFRLFVBQVUsTUFBTSxTQUFTLE9BQU8sTUFBTSxpQkFBaUIsSUFBSTtBQUFBLFlBQ25FLFVBQVUsVUFBVSxNQUFNLFdBQVcsT0FBTyxNQUFNLG9CQUFvQixJQUFJO0FBQUEsWUFDMUUsU0FBUztBQUFBLFVBQ1g7QUFDQSxpQkFBTyxJQUFJLE1BQU0sTUFBTTtBQUN2Qix3QkFBYyxJQUFJLE1BQU0sTUFBTTtBQUFBLFFBQ2hDO0FBQ0EsZUFBTyxNQUFNLFlBQVksTUFBTSxLQUFLO0FBQ3BDLGVBQU8sVUFBVSxPQUFPLE1BQU0saUJBQWlCLElBQUk7QUFDbkQsZUFBTztBQUFBLE1BQ1Q7QUFBQSxNQUNBLFVBQVU7QUFDUixtQkFBVyxDQUFDLE1BQU0sTUFBTSxLQUFLLFFBQVE7QUFDbkMsY0FBSSxjQUFjLElBQUksSUFBSSxNQUFNLE9BQVE7QUFDeEMsd0JBQWMsT0FBTyxJQUFJO0FBQ3pCLGNBQUksQ0FBQyxRQUFRLE1BQU0sTUFBTSxFQUFHO0FBQzVCLGNBQUksT0FBTyxPQUFRLFFBQU8sTUFBTSxZQUFZLE1BQU0sT0FBTyxRQUFRLE9BQU8sUUFBUTtBQUFBLGNBQzNFLFFBQU8sTUFBTSxlQUFlLElBQUk7QUFBQSxRQUN2QztBQUNBLGVBQU8sTUFBTTtBQUFBLE1BQ2Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUdPLFdBQVMsY0FBYyxRQUFxQixNQUF1QjtBQUN4RSxVQUFNLFFBQVEsWUFBWSxJQUFJLE1BQU0sR0FBRyxJQUFJLElBQUk7QUFDL0MsV0FDRSxDQUFDLENBQUMsU0FDRixPQUFPLE1BQU0saUJBQWlCLElBQUksTUFBTSxNQUFNLFdBQzlDLE9BQU8sTUFBTSxvQkFBb0IsSUFBSSxNQUFNO0FBQUEsRUFFL0M7OztBQ2xFQSxNQUFJLDBCQUEwQjtBQUM5QixNQUFNLDBCQUEwQixvQkFBSSxRQUE2QjtBQW9CMUQsV0FBUyx5QkFDZCxXQUNBLFNBQ0EsU0FDQTtBQUNBLFVBQU0sYUFBYSxFQUFFO0FBQ3JCLFVBQU0sZ0JBQWdCLFVBQVU7QUFDaEMsVUFBTSxhQUFhLENBQUMsU0FBUyxVQUFVLGVBQWUsWUFBWTtBQUdsRSxVQUFNLG9CQUFvQixDQUFDLFdBQ3pCLFdBQVc7QUFBQSxNQUNULENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxNQUFNLGlCQUFpQixJQUFJLEtBQUssQ0FBQyxjQUFjLFFBQVEsSUFBSTtBQUFBLElBQ2hGLEtBQ0MsQ0FBQyxDQUFDLE9BQU8sTUFBTSxpQkFBaUIsWUFBWSxLQUFLLENBQUMsY0FBYyxRQUFRLFlBQVk7QUFDdkYsVUFBTSxtQkFBbUIsUUFBUSxLQUFLLGlCQUFpQjtBQUN2RCxVQUFNLFNBQVMsUUFBUSxJQUFJLENBQUMsWUFBWSxFQUFFLFFBQVEsUUFBUSxVQUFVLE1BQU0sRUFBRSxFQUFFO0FBRTlFLFFBQUksV0FBMEIsbUJBQW1CLGtCQUFrQjtBQUNuRSxVQUFNLGNBQWMsQ0FBQyxXQUEwRTtBQUM3RixpQkFBVztBQUdYLGlCQUFXLEVBQUUsT0FBTyxLQUFLLE9BQVEsUUFBTyxRQUFRO0FBQ2hELGFBQU8sRUFBRSxNQUFNLGVBQWUsT0FBTztBQUFBLElBQ3ZDO0FBQ0EsUUFBSSxlQUFtRTtBQUN2RSxVQUFNLFVBQVUsTUFBeUQ7QUFDdkUscUJBQWU7QUFJZixhQUFPLEVBQUUsTUFBTSxXQUFXLFFBQVEsaUJBQWlCO0FBQUEsSUFDckQ7QUFDQSxVQUFNLG9CQUFvQixNQUN4QixPQUFPO0FBQUEsTUFDTCxDQUFDLEVBQUUsUUFBUSxPQUFPLE9BQ2Ysd0JBQXdCLElBQUksTUFBTSxLQUFLLE1BQU0sY0FBYyxPQUFPLFVBQVU7QUFBQSxJQUNqRjtBQUNGLFVBQU0sdUJBQXVCLE1BQU0sT0FBTyxLQUFLLENBQUMsRUFBRSxPQUFPLE1BQU0sa0JBQWtCLE1BQU0sQ0FBQztBQUN4RixVQUFNLHNCQUFzQixNQUFvRTtBQUM5RixVQUNFLENBQUMsUUFBUSxLQUNULFVBQVUsa0JBQWtCLGlCQUM1QixPQUFPLEtBQUssQ0FBQyxFQUFFLE9BQU8sTUFBTSxPQUFPLGtCQUFrQixhQUFhO0FBRWxFLGVBQU8sWUFBWSxpQkFBaUI7QUFDdEMsVUFBSSxDQUFDLGtCQUFrQixLQUFLLHFCQUFxQixFQUFHLFFBQU8sWUFBWSxnQkFBZ0I7QUFDdkYsVUFBSSxDQUFDLFVBQVUsZUFBZSxPQUFPLEtBQUssQ0FBQyxFQUFFLE9BQU8sTUFBTSxDQUFDLE9BQU8sV0FBVyxHQUFHO0FBRzlFLHVCQUFlO0FBQ2YsZUFBTyxFQUFFLE1BQU0sZUFBZSxRQUFRLGtCQUFrQjtBQUFBLE1BQzFEO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNLFVBQVUsTUFBZ0M7QUFDOUMsVUFBSSxTQUFVLFFBQU8sRUFBRSxNQUFNLGVBQWUsUUFBUSxTQUFTO0FBQzdELFlBQU0sVUFBVSxvQkFBb0I7QUFDcEMsVUFBSSxRQUFTLFFBQU87QUFHcEIsWUFBTSxRQUFRLFVBQVUsYUFDdEIsU0FBUyxVQUFVO0FBQ3JCLFVBQUksQ0FBQyxPQUFPLFNBQVMsS0FBSyxLQUFLLENBQUMsT0FBTyxTQUFTLE1BQU0sS0FBSyxRQUFRLEtBQUssU0FBUztBQUMvRSxlQUFPLFlBQVksa0JBQWtCO0FBQ3ZDLFVBQUksVUFBVSxLQUFLLFdBQVcsRUFBRyxRQUFPLFFBQVE7QUFJaEQsWUFBTSxZQUFZLG9CQUFvQjtBQUN0QyxVQUFJLFVBQVcsUUFBTztBQUN0QixpQkFBVyxFQUFFLE9BQU8sS0FBSyxPQUFRLHlCQUF3QixJQUFJLFFBQVEsVUFBVTtBQUcvRSxpQkFBVyxFQUFFLE9BQU8sS0FBSyxRQUFRO0FBQy9CLGNBQU0sY0FBYyxvQkFBb0I7QUFDeEMsWUFBSSxZQUFhLFFBQU87QUFDeEIsWUFDRSxDQUFDLE9BQU8sTUFBTSxjQUFjLFlBQVksS0FDeEMsQ0FBQyxPQUFPLE1BQU0sU0FBUyxHQUFHLEtBQUssSUFBSSxLQUNuQyxDQUFDLE9BQU8sTUFBTSxVQUFVLEdBQUcsTUFBTSxJQUFJO0FBRXJDLGlCQUFPLFlBQVksZ0JBQWdCO0FBQUEsTUFDdkM7QUFHQSxxQkFBZSxFQUFFLE9BQU8sT0FBTztBQUMvQixhQUFPLEVBQUUsTUFBTSxZQUFZLE9BQU8sT0FBTztBQUFBLElBQzNDO0FBQ0EsVUFBTSxTQUFTLE1BQXFFO0FBQ2xGLFVBQUksU0FBVSxRQUFPLEVBQUUsTUFBTSxlQUFlLFFBQVEsU0FBUztBQUM3RCxZQUFNLFVBQVUsb0JBQW9CO0FBQ3BDLFVBQUksUUFBUyxRQUFPO0FBSXBCLFVBQUksQ0FBQyxhQUFjLFFBQU8sUUFBUTtBQUNsQyxZQUFNLFdBQVc7QUFDakIsWUFBTSxFQUFFLE9BQU8sT0FBTyxJQUFJO0FBSTFCLFlBQU0sZUFBZSxVQUFVLGFBQzdCLGdCQUFnQixVQUFVO0FBQzVCLFVBQ0UsQ0FBQyxPQUFPLFNBQVMsWUFBWSxLQUM3QixDQUFDLE9BQU8sU0FBUyxhQUFhLEtBQzlCLGVBQWUsS0FDZixnQkFBZ0I7QUFFaEIsZUFBTyxZQUFZLGtCQUFrQjtBQUN2QyxVQUFJLGlCQUFpQixLQUFLLGtCQUFrQixFQUFHLFFBQU8sUUFBUTtBQUM5RCxVQUFJLGlCQUFpQixTQUFTLGtCQUFrQixPQUFRLFFBQU8sRUFBRSxNQUFNLG9CQUFvQjtBQUMzRixpQkFBVyxFQUFFLE9BQU8sS0FBSyxRQUFRO0FBQy9CLGNBQU0sYUFBYSxvQkFBb0I7QUFDdkMsWUFBSSxXQUFZLFFBQU87QUFHdkIsY0FBTSxjQUFjLE9BQU8sYUFDekIsZUFBZSxPQUFPO0FBQ3hCLFlBQ0UsQ0FBQyxPQUFPLFNBQVMsV0FBVyxLQUM1QixDQUFDLE9BQU8sU0FBUyxZQUFZLEtBQzdCLGNBQWMsS0FDZCxlQUFlO0FBRWYsaUJBQU8sWUFBWSxrQkFBa0I7QUFDdkMsWUFBSSxnQkFBZ0IsS0FBSyxpQkFBaUIsRUFBRyxRQUFPLFFBQVE7QUFDNUQsWUFDRSxLQUFLLElBQUksY0FBYyxLQUFLLElBQUksS0FDaEMsS0FBSyxJQUFJLGVBQWUsTUFBTSxJQUFJLEtBQ2xDLE9BQU8sZUFBZSxPQUFPLGVBQWUsS0FDNUMsT0FBTyxjQUFjLE9BQU8sY0FBYztBQUUxQyxpQkFBTyxZQUFZLGVBQWU7QUFBQSxNQUN0QztBQUNBLFlBQU0sYUFBYSxVQUFVLGFBQzNCLGNBQWMsVUFBVTtBQUcxQixZQUFNLFlBQVksb0JBQW9CO0FBQ3RDLFVBQUksVUFBVyxRQUFPO0FBQ3RCLFVBQ0UsQ0FBQyxPQUFPLFNBQVMsVUFBVSxLQUMzQixDQUFDLE9BQU8sU0FBUyxXQUFXLEtBQzVCLGFBQWEsS0FDYixjQUFjO0FBRWQsZUFBTyxZQUFZLGtCQUFrQjtBQUN2QyxVQUFJLGVBQWUsS0FBSyxnQkFBZ0IsRUFBRyxRQUFPLFFBQVE7QUFDMUQsVUFBSSxlQUFlLFNBQVMsZ0JBQWdCLFVBQVUsaUJBQWlCO0FBQ3JFLGVBQU8sRUFBRSxNQUFNLG9CQUFvQjtBQUNyQyxhQUFPLEVBQUUsTUFBTSxXQUFXLE9BQU8sT0FBTztBQUFBLElBQzFDO0FBQ0EsV0FBTztBQUFBLE1BQ0w7QUFBQSxNQUNBO0FBQUEsTUFDQSxPQUFPO0FBQUEsTUFDUCxRQUE2QjtBQUMzQixjQUFNLFdBQVcsUUFBUTtBQUN6QixZQUFJLFNBQVMsU0FBUyxXQUFZLFFBQU87QUFDekMsY0FBTSxTQUFTLE9BQU87QUFDdEIsZUFBTyxPQUFPLFNBQVMsc0JBQXNCLFlBQVksa0JBQWtCLElBQUk7QUFBQSxNQUNqRjtBQUFBLE1BQ0EsVUFBVTtBQUNSLG1CQUFXO0FBQ1gsbUJBQVcsRUFBRSxPQUFPLEtBQUssT0FBUSxRQUFPLFFBQVE7QUFBQSxNQUNsRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBR08sV0FBUyxrQkFBa0IsTUFBMkI7QUFDM0QsUUFBSSxPQUFPO0FBQ1gsUUFBSSxVQUE4QjtBQUNsQyxXQUFPLFNBQVM7QUFDZCxjQUFRLFFBQVE7QUFDaEIsWUFBTSxTQUF5QixRQUFRO0FBQ3ZDLFVBQUksQ0FBQyxVQUFVLEVBQUUsZ0JBQWdCLFFBQVM7QUFDMUMsY0FBUyxPQUF1QjtBQUNoQyxnQkFBVTtBQUFBLElBQ1o7QUFDQSxhQUFTLFNBQVMsS0FBSyxlQUFlLFFBQVEsU0FBUyxPQUFPO0FBQzVELGNBQVEsT0FBTztBQUNqQixXQUFPO0FBQUEsRUFDVDtBQUdPLFdBQVMsMkJBQ2QsUUFDQSxPQUNnQjtBQUNoQixVQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFFBQUksQ0FBQyxRQUFRLFdBQVcsU0FBUyxDQUFDLE1BQU0sU0FBUyxNQUFNLEVBQUcsUUFBTztBQUNqRSxVQUFNLE9BQU8sa0JBQWtCLE1BQU07QUFDckMsVUFBTSxRQUFRLE9BQU87QUFDckIsUUFBSSxDQUFDLE9BQU8sU0FBUyxJQUFJLEtBQUssQ0FBQyxPQUFPLFNBQVMsS0FBSyxLQUFLLFFBQVEsRUFBRyxRQUFPO0FBQzNFLFVBQU0sV0FBVyxLQUFLLGlCQUFpQixNQUFNLEVBQUU7QUFFL0MsUUFBSSxrQkFDRixhQUFhLGNBQWMsYUFBYSxVQUFVLE9BQU8sZUFBZTtBQUMxRSxhQUFTLFNBQVMsT0FBTyxlQUFlLFFBQVEsU0FBUyxPQUFPLGVBQWU7QUFDN0UsVUFBSSxXQUFXLGdCQUFpQixtQkFBa0I7QUFDbEQsWUFBTSxRQUFRLEtBQUssaUJBQWlCLE1BQU07QUFDMUMsWUFBTSxXQUFXLE1BQU0sYUFBYSxNQUFNO0FBQzFDLFVBQ0Usb0JBQW9CLFdBQ25CLGFBQWEsWUFDWixhQUFhLFVBQ2IsYUFBYSxZQUNiLGFBQWEsU0FDZjtBQUNBLGNBQU0sUUFBUSxrQkFBa0IsTUFBTSxJQUFJLE9BQU87QUFDakQsY0FBTSxZQUFZLE9BQU87QUFDekIsWUFBSSxDQUFDLE9BQU8sU0FBUyxLQUFLLEtBQUssQ0FBQyxPQUFPLFNBQVMsU0FBUyxLQUFLLFlBQVksRUFBRyxRQUFPO0FBQ3BGLFlBQUksT0FBTyxRQUFRLEtBQUssT0FBTyxRQUFRLFFBQVEsWUFBWSxFQUFHLFFBQU87QUFBQSxNQUN2RTtBQUNBLFVBQUksV0FBVyxNQUFPLFFBQU87QUFDN0IsVUFDRSxvQkFBb0IsV0FDbkIsTUFBTSxhQUFhLGNBQWMsTUFBTSxhQUFhO0FBRXJELDBCQUFrQixPQUFPO0FBQUEsSUFDN0I7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUdPLFdBQVMsNkJBQ2QsUUFDQUEsVUFDZTtBQUNmLFVBQU0sT0FBT0EsU0FBUSxjQUFjO0FBQ25DLFFBQUksQ0FBQyxRQUFRLENBQUNBLFNBQVEsU0FBUyxNQUFNLEVBQUcsUUFBTztBQUMvQyxVQUFNLFNBQVMsQ0FBQyxVQUFtQixVQUFVLFNBQVMsSUFBSSxPQUFPLFdBQVcsS0FBSztBQUNqRixRQUFJLFNBQVM7QUFDYixRQUFJLFFBQXFCO0FBQ3pCLGFBQVMsU0FBUyxPQUFPLGVBQWUsUUFBUSxTQUFTLE9BQU8sZUFBZTtBQUM3RSxZQUFNLGFBQWEsS0FBSyxpQkFBaUIsS0FBSztBQUM5QyxZQUFNLFFBQVEsS0FBSyxpQkFBaUIsTUFBTTtBQUMxQyxZQUFNLFNBQVMsT0FBTyxXQUFXLFVBQVUsSUFBSSxPQUFPLFdBQVcsV0FBVztBQUM1RSxZQUFNLFNBQVMsT0FBTyxNQUFNLGVBQWUsSUFBSSxPQUFPLE1BQU0sZ0JBQWdCO0FBQzVFLFlBQU0sVUFBVSxPQUFPLE1BQU0sV0FBVyxJQUFJLE9BQU8sTUFBTSxZQUFZO0FBQ3JFLFlBQU0sWUFBWSxLQUFLLElBQUksR0FBRyxPQUFPLGNBQWMsT0FBTyxjQUFjLE1BQU07QUFDOUUsVUFBSSxDQUFDLENBQUMsUUFBUSxRQUFRLFNBQVMsU0FBUyxFQUFFLE1BQU0sT0FBTyxRQUFRLEtBQUssU0FBUyxLQUFLLFVBQVU7QUFDMUYsZUFBTztBQUNULGdCQUFVLFNBQVMsU0FBUyxVQUFVO0FBQ3RDLFVBQUksV0FBV0EsU0FBUyxRQUFPLEtBQUssSUFBSSxHQUFHLE1BQU07QUFDakQsY0FBUTtBQUFBLElBQ1Y7QUFDQSxXQUFPO0FBQUEsRUFDVDs7O0FDbE5BLE1BQU0sVUFBVSxDQUFDLFdBQXVDLE9BQU8sT0FBTyxFQUFFLE1BQU0sV0FBVyxPQUFPLENBQUM7QUFDakcsTUFBTSxTQUFTLENBQUMsWUFBK0IsUUFBUSxNQUFNLE9BQU8sUUFBUTtBQUM1RSxNQUFNLGNBQWMsQ0FBQyxZQUErQixRQUFRLE1BQU0sQ0FBQyxVQUFVLFNBQVMsQ0FBQztBQUN2RixNQUFNLFFBQVEsQ0FBQyxPQUFlLFNBQWlCLFlBQzdDLEtBQUssSUFBSSxLQUFLLElBQUksT0FBTyxPQUFPLEdBQUcsT0FBTztBQUVyQyxXQUFTLHFCQUNkLFNBQ0EsYUFDdUI7QUFDdkIsVUFBTSxFQUFFLFVBQVUsR0FBRyxXQUFXLEdBQUcsU0FBUyxHQUFHLFFBQVEsR0FBRyxZQUFZLEVBQUUsSUFBSTtBQUM1RSxVQUFNQyxTQUFRO0FBQUEsTUFDWixHQUFHLE9BQU8sT0FBTyxDQUFDO0FBQUEsTUFDbEIsR0FBRyxPQUFPLE9BQU8sQ0FBQztBQUFBLE1BQ2xCLEdBQUcsT0FBTyxPQUFPLENBQUM7QUFBQSxNQUNsQixFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsTUFDRixHQUFJLEVBQUUsMkJBQTJCLFNBQVksQ0FBQyxJQUFJLENBQUMsRUFBRSxzQkFBc0I7QUFBQSxNQUMzRSxHQUFJLEVBQUUscUJBQXFCLFNBQVksQ0FBQyxJQUFJLENBQUMsRUFBRSxnQkFBZ0I7QUFBQSxNQUMvRCxHQUFHLE9BQU8sT0FBTyxDQUFDO0FBQUEsSUFDcEI7QUFDQSxRQUFJLENBQUMsT0FBT0EsTUFBSyxFQUFHLFFBQU8sUUFBUSxnQkFBZ0I7QUFDbkQsUUFDRSxFQUFFLFNBQVMsS0FDWCxFQUFFLFVBQVUsS0FDWixFQUFFLFVBQVUsS0FDWixDQUFDLFlBQVk7QUFBQSxNQUNYLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEdBQUksRUFBRSwyQkFBMkIsU0FBWSxDQUFDLElBQUksQ0FBQyxFQUFFLHNCQUFzQjtBQUFBLE1BQzNFLEdBQUksRUFBRSxxQkFBcUIsU0FBWSxDQUFDLElBQUksQ0FBQyxFQUFFLGdCQUFnQjtBQUFBLE1BQy9ELEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxJQUNKLENBQUMsS0FDRCxFQUFFLFFBQVEsRUFBRSxRQUNaLEVBQUUsUUFBUSxFQUFFO0FBRVosYUFBTyxRQUFRLGdCQUFnQjtBQUNqQyxVQUFNLEVBQUUsUUFBUSx1QkFBdUIsSUFBSTtBQUMzQyxRQUNFLENBQUMsT0FBTyxDQUFDLFFBQVEsc0JBQXNCLENBQUMsS0FDeEMsU0FBUyxLQUNULDBCQUEwQixLQUMxQixZQUFZLGFBQWEscUJBQ3pCLFlBQVksbUJBQW1CLG9CQUM5QixRQUFRLGNBQWMsU0FBUyxRQUFRLGNBQWMsU0FDdEQsT0FBTyxZQUFZLG1CQUFtQjtBQUV0QyxhQUFPLFFBQVEsb0JBQW9CO0FBRXJDLFVBQU0sTUFBTSxRQUFRLGNBQWM7QUFHbEMsVUFBTSxrQkFBa0IsTUFBTSxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLG9CQUFvQjtBQUNuRixVQUFNLG9CQUFvQixLQUFLLElBQUksRUFBRSxPQUFPLEVBQUUsMEJBQTBCLENBQUM7QUFDekUsVUFBTSxnQkFBZ0IsS0FBSyxJQUFJLG1CQUFtQixFQUFFLEtBQUs7QUFDekQsVUFBTSxjQUFjO0FBQUEsTUFDbEI7QUFBQSxNQUNBO0FBQUEsTUFDQSxLQUFLLElBQUksUUFBUSxFQUFFLFFBQVEsU0FBUyxhQUFhO0FBQUEsSUFDbkQ7QUFFQSxVQUFNLFlBQVksRUFBRSxTQUFTLElBQUk7QUFDakMsVUFBTUMsV0FBVSxFQUFFLFlBQVksRUFBRSxhQUFhLEVBQUUsZUFBZSxFQUFFLGdCQUFnQixFQUFFO0FBQ2xGLFVBQU0sVUFBVSxLQUFLLElBQUkseUJBQXlCLEVBQUUsUUFBUUEsUUFBTztBQUNuRSxVQUFNLGtCQUFrQixFQUFFLE1BQU0sRUFBRSxTQUFTLElBQUk7QUFDL0MsVUFBTSxpQkFBaUIsWUFBWTtBQUNuQyxVQUFNLE9BQU8sRUFBRSxTQUFTO0FBQ3hCLFVBQU0sZUFBZSxFQUFFLFlBQVksRUFBRSxhQUFhLEVBQUUsU0FBUztBQUM3RCxVQUFNLGNBQWNBLFdBQVU7QUFDOUIsVUFBTSxZQUFZLGdCQUFnQjtBQUNsQyxVQUFNLGdCQUFnQixZQUNsQixlQUNBLEtBQUs7QUFBQSxNQUNIO0FBQUEsTUFDQSxRQUNHLEVBQUUsUUFBUSxFQUFFLGdCQUFnQixLQUM3QixFQUFFLGVBQ0YsRUFBRSxZQUNGLEVBQUUsU0FDRixFQUFFO0FBQUEsSUFDTixJQUNBLEtBQUssSUFBSSxpQkFBaUIsRUFBRSxZQUFZLEVBQUUsYUFBYSxFQUFFLFVBQVUsRUFBRSxhQUFhLEtBQUssSUFBSSxJQUMzRjtBQUNKLFVBQU0sa0JBQWtCLFlBQVksU0FBWSxlQUFlLGtCQUFrQixFQUFFO0FBQ25GLFFBQ0UsQ0FBQyxPQUFPO0FBQUEsTUFDTjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBLEdBQUksb0JBQW9CLFNBQVksQ0FBQyxJQUFJLENBQUMsZUFBZTtBQUFBLElBQzNELENBQUM7QUFFRCxhQUFPLFFBQVEsZ0JBQWdCO0FBQ2pDLFVBQU0sT0FBNEIsT0FBTyxPQUFPO0FBQUEsTUFDOUMsUUFBUSxPQUFPLE9BQU87QUFBQSxRQUNwQixNQUFNLE1BQU0sVUFBVTtBQUFBLFFBQ3RCLE9BQU87QUFBQSxRQUNQLGFBQWE7QUFBQSxNQUNmLENBQUM7QUFBQSxNQUNELE9BQU8sT0FBTyxPQUFPO0FBQUEsUUFDbkIsS0FBSyxZQUFZLFFBQVE7QUFBQSxRQUN6QjtBQUFBLFFBQ0E7QUFBQSxRQUNBLGFBQWE7QUFBQSxRQUNiLGFBQWE7QUFBQSxNQUNmLENBQUM7QUFBQSxNQUNELGtCQUFrQjtBQUFBLE1BQ2xCLEdBQUksb0JBQW9CLFNBQVksQ0FBQyxJQUFJLEVBQUUsZ0JBQWdCO0FBQUEsSUFDN0QsQ0FBQztBQUNELFdBQU8sT0FBTyxPQUFPLEVBQUUsTUFBTSxRQUFRLEtBQUssQ0FBQztBQUFBLEVBQzdDO0FBb0JPLFdBQVMsc0JBQXNCLFFBQXNEO0FBQzFGLFVBQU0sU0FBUztBQUFBLE1BQ2IsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLElBQ1Q7QUFDQSxRQUFJLENBQUMsT0FBTyxNQUFNLEVBQUcsUUFBTyxRQUFRLGdCQUFnQjtBQUNwRCxRQUFJLENBQUMsWUFBWSxPQUFPLE1BQU0sR0FBRyxDQUFDLENBQUMsRUFBRyxRQUFPLFFBQVEsZ0JBQWdCO0FBQ3JFLFFBQUssT0FBTyxRQUFRLFdBQVcsT0FBTyxRQUFRLFNBQVUsT0FBTyxPQUFPLFlBQVksV0FBVztBQUMzRixhQUFPLFFBQVEsb0JBQW9CO0FBQUEsSUFDckM7QUFDQSxVQUFNLFFBQVEsS0FBSyxJQUFJLE9BQU8sdUJBQXVCLE9BQU8sWUFBWTtBQUN4RSxVQUFNLGVBQWUsS0FBSyxJQUFJLE9BQU8sYUFBYSxPQUFPLHFCQUFxQjtBQUM5RSxRQUFJLE9BQTRCLEVBQUUsMEJBQTBCLE9BQU8sYUFBYTtBQUNoRixRQUFJLE9BQU8sV0FBVyxRQUFRLEtBQUssZUFBZSxPQUFPLGVBQWU7QUFDdEUsWUFBTSxXQUFXLGVBQWU7QUFDaEMsWUFBTSxnQkFBZ0IsS0FBSyxJQUFJLE9BQU8sZUFBZSxRQUFRO0FBQzdELFVBQUksQ0FBQyxPQUFPLFNBQVMsUUFBUSxFQUFHLFFBQU8sUUFBUSxnQkFBZ0I7QUFDL0QsYUFBTztBQUFBLFFBQ0wsR0FBRztBQUFBLFFBQ0g7QUFBQSxRQUNBLEdBQUksT0FBTyxRQUFRLFFBQ2Y7QUFBQSxVQUNFLGlCQUFpQixLQUFLLElBQUksV0FBVyxlQUFlLENBQUM7QUFBQSxVQUNyRCxrQkFBa0I7QUFBQSxRQUNwQixJQUNBLENBQUM7QUFBQSxNQUNQO0FBQUEsSUFDRjtBQUNBLFdBQU8sT0FBTyxPQUFPLEVBQUUsTUFBTSxRQUFRLE1BQU0sT0FBTyxPQUFPLElBQUksRUFBRSxDQUFDO0FBQUEsRUFDbEU7OztBQzdOQSxNQUFNLFVBQVUsQ0FBQyxVQUNmLENBQUMsQ0FBQyxTQUNGLE9BQU8sVUFBVSxZQUNoQixNQUFlLGFBQWEsS0FDN0IsT0FBUSxNQUFzQiwwQkFBMEIsY0FDeEQsV0FBVztBQUdiLFdBQVMsVUFBVSxNQUEyQjtBQUM1QyxRQUFJLE1BQU07QUFDVixRQUFJLFVBQThCO0FBQ2xDLFdBQU8sU0FBUztBQUNkLGFBQU8sUUFBUTtBQUNmLFlBQU0sU0FBeUIsUUFBUTtBQUN2QyxVQUFJLENBQUMsUUFBUSxNQUFNLEVBQUc7QUFDdEIsYUFBTyxPQUFPO0FBQ2QsZ0JBQVU7QUFBQSxJQUNaO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFNLGNBQWMsQ0FBQyxNQUFtQixhQUN0QyxVQUFVLElBQUksSUFBSSxVQUFVLFFBQVEsSUFBSSxTQUFTO0FBWW5ELFdBQVMsYUFBYSxHQUErQixHQUF3QztBQUMzRixVQUFNLElBQUksRUFBRSxpQkFDVixJQUFJLEVBQUU7QUFDUixRQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxhQUFhLEVBQUUsU0FBVSxRQUFPO0FBQ2xELFVBQU0sV0FDSCxDQUFDLEVBQUUsYUFBYSxDQUFDLEVBQUUsYUFDbkIsQ0FBQyxDQUFDLEVBQUUsYUFDSCxDQUFDLENBQUMsRUFBRSxhQUNKLEVBQUUsVUFBVSxjQUFjLEVBQUUsVUFBVSxhQUN0QyxFQUFFLFVBQVUsUUFBUSxXQUFXLEVBQUUsVUFBVSxRQUFRLFVBQ25ELEVBQUUsVUFBVSxRQUFRLE1BQU0sQ0FBQyxRQUFRLFVBQVUsV0FBVyxFQUFFLFdBQVcsUUFBUSxLQUFLLENBQUM7QUFDdkYsV0FDRSxZQUVFO0FBQUEsTUFDRTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGLEVBQ0EsTUFBTSxDQUFDLFFBQVEsRUFBRSxHQUFHLE1BQU0sRUFBRSxHQUFHLENBQUMsS0FFaEMsQ0FBQyxZQUFZLFVBQVUsMEJBQTBCLGtCQUFrQixnQkFBZ0IsRUFDbkYsTUFBTSxDQUFDLFFBQVEsRUFBRSxZQUFZLEdBQUcsTUFBTSxFQUFFLFlBQVksR0FBRyxDQUFDO0FBQUEsRUFFOUQ7QUFFTyxXQUFTLDJCQUNkLFNBQzJCO0FBQzNCLFFBQUksYUFBYTtBQUNqQixRQUFJLFdBQVc7QUFDZixRQUFJLFVBQVU7QUFDZCxRQUFJLGFBQTJDO0FBQy9DLFFBQUksT0FBNEI7QUFDaEMsUUFBSSxVQUErQjtBQUNuQyxRQUFJLGlCQUFzQztBQUUxQyxVQUFNLFNBQVMsTUFBTTtBQUNuQixhQUFPO0FBQ1AsYUFBTztBQUNQLHVCQUFpQjtBQUNqQixnQkFBVTtBQUNWLGdCQUFVO0FBQUEsSUFDWjtBQUNBLFVBQU0sUUFBUSxNQUFNO0FBQ2xCLFlBQU0sVUFBVTtBQUNoQixZQUFNLFVBQVUsRUFBRTtBQUNsQixtQkFBYTtBQUNiLGFBQU87QUFDUCxZQUFNLE9BQU8sTUFBTSxDQUFDLFlBQVksWUFBWTtBQUM1QyxZQUFNLFNBQVMsQ0FBQyxXQUFrQztBQUNoRCxZQUFJLEtBQUssR0FBRztBQUNWLHVCQUFhO0FBQ2IscUJBQVcsY0FBYyxNQUFNO0FBQUEsUUFDakM7QUFBQSxNQUNGO0FBQ0EsWUFBTSxhQUFhLFFBQVE7QUFDM0IsVUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLFFBQVEsUUFBUSxHQUFHO0FBQzdDLGVBQU8sRUFBRSxRQUFRLGtCQUFrQixRQUFRLGlCQUFpQixDQUFDO0FBQzdEO0FBQUEsTUFDRjtBQUNBLFlBQU0sT0FBTztBQUFBLFFBQ1g7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQSxVQUFJLENBQUMsS0FBSyxNQUFNLENBQUMsUUFBUSxRQUFRLFdBQVcsR0FBRyxDQUFDLENBQUMsR0FBRztBQUNsRCxlQUFPLEVBQUUsUUFBUSxrQkFBa0IsUUFBUSxpQkFBaUIsQ0FBQztBQUM3RDtBQUFBLE1BQ0Y7QUFDQSxZQUFNLFVBQVU7QUFDaEIsWUFBTSxRQUFRLFFBQVE7QUFDdEIsWUFBTSxNQUFNLE1BQU07QUFDbEIsWUFBTSxPQUFPLElBQUk7QUFDakIsVUFBSSxDQUFDLE1BQU07QUFDVCxlQUFPLEVBQUUsUUFBUSxrQkFBa0IsUUFBUSxrQkFBa0IsQ0FBQztBQUM5RDtBQUFBLE1BQ0Y7QUFDQSxZQUFNLFNBQVMsV0FBVztBQUMxQixVQUNFLFdBQ0MsQ0FBQyxRQUFRLE9BQU8sU0FBUyxLQUFLLE9BQU8sUUFBUSxXQUFXLEtBQUssQ0FBQyxPQUFPLFFBQVEsTUFBTSxPQUFPLElBQzNGO0FBQ0EsZUFBTyxFQUFFLFFBQVEsa0JBQWtCLFFBQVEsaUJBQWlCLENBQUM7QUFDN0Q7QUFBQSxNQUNGO0FBQ0EsWUFBTSxjQUFjLFNBQVUsT0FBTyxVQUFxQyxDQUFDO0FBQzNFLFlBQU0sWUFBWSxTQUNkLHlCQUF5QixPQUFPLFdBQTBCLGFBQWEsSUFBSSxJQUMzRTtBQUNKLFlBQU0sUUFBUSxVQUFVLEtBQUs7QUFDN0IsWUFBTSxrQkFBa0IsQ0FBQyxXQUFvRTtBQUczRixtQkFBVyxNQUFNLE1BQU07QUFDdkIsZUFBTyxFQUFFLFFBQVEsZUFBZSxPQUFPLENBQUM7QUFBQSxNQUMxQztBQUNBLGdCQUFVLE1BQU07QUFDZCxjQUFNLFFBQVE7QUFDZCxtQkFBVyxRQUFRO0FBQUEsTUFDckI7QUFDQSxVQUFJLE9BQW1DO0FBQ3ZDLFVBQUksZ0JBQWdCO0FBQ3BCLFVBQUksaUJBQWlCLFFBQVEsV0FBVztBQUN4QyxVQUFJLFNBQVM7QUFDYixVQUFJLFlBQTJCO0FBQy9CLFVBQUksVUFBVTtBQUNkLFVBQUksVUFBVTtBQUNkLFVBQUksZ0JBQWdCO0FBQ3BCLFVBQUksZUFBeUM7QUFDN0MsWUFBTSxRQUFRLENBQUMsTUFBYyxVQUFrQjtBQUM3QyxZQUFJLENBQUMsS0FBSyxLQUFLLGNBQWUsUUFBTztBQUNyQyxZQUFJLENBQUMsTUFBTSxNQUFNLE1BQU0sS0FBSyxHQUFHO0FBQzdCLDBCQUFnQjtBQUNoQiwwQkFBZ0IsZ0JBQWdCO0FBQ2hDLGlCQUFPO0FBQUEsUUFDVDtBQUNBLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxZQUFZLE1BQ2hCLE1BQU0sZUFDTixLQUFLLE1BQU0sQ0FBQyxRQUFRLFFBQVEsR0FBRyxFQUFFLGVBQWUsUUFBUSxHQUFHLEVBQUUsa0JBQWtCLEdBQUcsS0FDbEYsWUFBWSxNQUFNLENBQUMsV0FBVyxPQUFPLGVBQWUsT0FBTyxrQkFBa0IsR0FBRztBQUNsRixZQUFNLFdBQVcsTUFBa0M7QUFDakQsWUFBSSxDQUFDLEtBQUssS0FBSyxDQUFDLFVBQVUsR0FBRztBQUMzQixjQUFJLEtBQUssRUFBRyxRQUFPLEVBQUUsUUFBUSxrQkFBa0IsUUFBUSxrQkFBa0IsQ0FBQztBQUMxRSxpQkFBTztBQUFBLFFBQ1Q7QUFDQSxjQUFNLFlBQVksUUFBUSxlQUFlLHNCQUFzQjtBQUcvRCxjQUFNLFNBQVMsTUFBTSxzQkFBc0IsRUFBRSxPQUFPLGtCQUFrQixLQUFLO0FBQzNFLGNBQU0sY0FBYyxTQUFTLGtCQUFrQixRQUFRLE9BQU87QUFDOUQsY0FBTSxlQUFlLFFBQVEsUUFBUTtBQUNyQyxZQUFJLFFBQVEsWUFBWSxnQkFBZ0IsS0FBSyxVQUFVLFVBQVUsR0FBRztBQUNsRSxpQkFBTyxFQUFFLFFBQVEsa0JBQWtCLFFBQVEsaUJBQWlCLENBQUM7QUFDN0QsaUJBQU87QUFBQSxRQUNUO0FBQ0EsY0FBTSxRQUFRLEtBQUssaUJBQWlCLFFBQVEsT0FBTztBQUNuRCxjQUFNLFNBQVMsS0FBSyxpQkFBaUIsUUFBUSxVQUFVO0FBQ3ZELGNBQU0sTUFBTSxDQUFDLFNBQWlCLE9BQU8sU0FBUyxNQUFNLEVBQUU7QUFDdEQsY0FBTSxVQUFVLFlBQVk7QUFBQSxVQUFJLENBQUMsV0FDL0IsNkJBQTZCLFFBQVEsUUFBUSxPQUFPO0FBQUEsUUFDdEQ7QUFDQSxZQUFJLFFBQVEsS0FBSyxDQUFDLFdBQVcsV0FBVyxJQUFJLEdBQUc7QUFDN0MsMEJBQWdCLGtCQUFrQjtBQUNsQyxpQkFBTztBQUFBLFFBQ1Q7QUFDQSxjQUFNLHlCQUF5QixZQUFZLFVBQ3RDLFFBQVEsV0FBMEIsY0FBYyxLQUFLLElBQUksR0FBSSxPQUFvQixJQUNsRjtBQUNKLGNBQU0sWUFBWSxLQUFLLGlCQUFpQixLQUFLLEVBQUUsY0FBYyxRQUFRLFFBQVE7QUFDN0UsY0FBTSxnQkFBZ0IsWUFBWSxTQUFTLFFBQVEsV0FBVztBQUM5RCxjQUFNLGFBQWEsU0FBUyxrQkFBa0IsUUFBUSxXQUFXO0FBQ2pFLGNBQU0sbUJBQW1CLGdCQUNyQixjQUFjLFFBQ1osY0FBYyxlQUFlLGFBQWEsUUFBUSxZQUFZLGNBQzlELGFBQWEsY0FDZjtBQU9KLGNBQU0sYUFBYSxJQUFJO0FBQ3ZCLGNBQU0sZ0JBQWdCLFdBQVcsY0FBYyxJQUFJLFdBQVcsY0FBYyxLQUFLO0FBQ2pGLGNBQU0saUJBQ0osV0FBVyxlQUFlLElBQUksV0FBVyxlQUFlLEtBQUs7QUFDL0QsY0FBTSxTQUFTO0FBQUEsVUFDYjtBQUFBLFlBQ0U7QUFBQSxZQUNBLFVBQVUsRUFBRSxPQUFPLGVBQWUsUUFBUSxlQUFlO0FBQUEsWUFDekQsV0FBVztBQUFBLGNBQ1QsTUFBTSxVQUFVO0FBQUEsY0FDaEIsT0FBTyxVQUFVO0FBQUEsY0FDakIsS0FBSyxVQUFVO0FBQUEsY0FDZixPQUFPLFVBQVU7QUFBQSxjQUNqQixRQUFRLFVBQVU7QUFBQSxZQUNwQjtBQUFBLFlBQ0EsU0FBUztBQUFBLGNBQ1AsTUFBTTtBQUFBLGNBQ04sT0FBTyxjQUFjO0FBQUEsY0FDckIsT0FBTztBQUFBLGNBQ1AsY0FBYyxRQUFRLFFBQVE7QUFBQSxjQUM5QixXQUFXLElBQUksTUFBTSxjQUFjO0FBQUEsY0FDbkMsY0FBYyxJQUFJLE1BQU0saUJBQWlCO0FBQUEsY0FDekMsWUFBWSxJQUFJLE1BQU0sVUFBVTtBQUFBLGNBQ2hDLGVBQWUsSUFBSSxNQUFNLGFBQWE7QUFBQSxZQUN4QztBQUFBLFlBQ0EsUUFBUTtBQUFBLGNBQ04sUUFBUSxZQUFZLFFBQVEsYUFBYSxRQUFRLFVBQVU7QUFBQSxjQUMzRCxRQUFRLFFBQVEsWUFBWTtBQUFBLGNBQzVCLFNBQVMsV0FBVztBQUFBLGNBQ3BCLE9BQU8sV0FBVztBQUFBLGNBQ2xCLEdBQUksMkJBQTJCLFNBQVksQ0FBQyxJQUFJLEVBQUUsdUJBQXVCO0FBQUEsY0FDekUsR0FBSSxxQkFBcUIsU0FBWSxDQUFDLElBQUksRUFBRSxpQkFBaUI7QUFBQSxZQUMvRDtBQUFBLFlBQ0EsWUFBWTtBQUFBLGNBQ1YsY0FBYyxRQUFRLFdBQVc7QUFBQSxjQUNqQyxXQUFXLFlBQVksUUFBUSxZQUFZLFFBQVEsT0FBTztBQUFBLGNBQzFELFFBQVEsUUFBUSxXQUFXO0FBQUEsY0FDM0IsWUFBWSxJQUFJLE9BQU8sVUFBVTtBQUFBLGNBQ2pDLGVBQWUsSUFBSSxPQUFPLGFBQWE7QUFBQSxZQUN6QztBQUFBLFVBQ0Y7QUFBQSxVQUNBLFdBQVc7QUFBQSxRQUNiO0FBQ0EsWUFBSSxDQUFDLEtBQUssRUFBRyxRQUFPO0FBQ3BCLFlBQUksT0FBTyxTQUFTLFFBQVE7QUFDMUIsMEJBQWdCLGtCQUFrQjtBQUNsQyxpQkFBTztBQUFBLFFBQ1Q7QUFDQSxlQUFPLE9BQU87QUFBQSxNQUNoQjtBQUNBLFlBQU0sYUFBYSxDQUFDLEdBQXdCLE1BQzFDLEVBQUUsT0FBTyxTQUFTLEVBQUUsT0FBTyxRQUMzQixFQUFFLE1BQU0sUUFBUSxFQUFFLE1BQU0sT0FDeEIsS0FBSyxJQUFJLEVBQUUsT0FBTyxRQUFRLEVBQUUsT0FBTyxLQUFLLElBQUksUUFDNUMsS0FBSyxJQUFJLEVBQUUsT0FBTyxjQUFjLEVBQUUsT0FBTyxXQUFXLElBQUksUUFDeEQsS0FBSyxJQUFJLEVBQUUsTUFBTSxnQkFBZ0IsRUFBRSxNQUFNLGFBQWEsSUFBSSxRQUMxRCxLQUFLLElBQUksRUFBRSxNQUFNLGNBQWMsRUFBRSxNQUFNLFdBQVcsSUFBSSxRQUN0RCxLQUFLLElBQUksRUFBRSxNQUFNLGNBQWMsRUFBRSxNQUFNLFdBQVcsSUFBSSxRQUN0RCxFQUFFLG9CQUFvQixFQUFFO0FBQzFCLFlBQU0sV0FBVyxNQUFNO0FBQ3JCLFlBQUksQ0FBQyxLQUFLLEtBQUssV0FBVyxjQUFlO0FBQ3pDLGtCQUFVO0FBQ1YsWUFBSSxTQUFTO0FBQ2IsWUFBSSxtQkFBc0MsQ0FBQztBQUMzQyxZQUFJO0FBQ0YsZ0JBQU0sWUFBWSxRQUFRLGVBQWUsc0JBQXNCO0FBQy9ELDZCQUFtQixDQUFDLFVBQVUsTUFBTSxVQUFVLEtBQUssVUFBVSxPQUFPLFVBQVUsTUFBTTtBQUNwRixnQkFBTSxtQkFDSixDQUFDLENBQUMsZ0JBQWdCLGlCQUFpQixLQUFLLENBQUMsT0FBTyxVQUFVLFVBQVUsYUFBYyxLQUFLLENBQUM7QUFDMUYscUJBQVcsQ0FBQyxNQUFNLEtBQUssS0FBSyxPQUFPLFFBQVE7QUFBQSxZQUN6QyxVQUFVO0FBQUEsWUFDVixTQUFTO0FBQUEsWUFDVCxrQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlsQixHQUFJLENBQUMsV0FBVyxtQkFBbUIsRUFBRSxtQkFBbUIsU0FBUyxJQUFJLENBQUM7QUFBQTtBQUFBO0FBQUEsWUFHdEUsMkJBQTJCLEdBQUcsUUFBUSxlQUFlLFdBQVc7QUFBQSxZQUNoRSw0QkFBNEIsR0FBRyxRQUFRLGVBQWUsWUFBWTtBQUFBLFVBQ3BFLENBQUM7QUFDQyxnQkFBSSxDQUFDLE1BQU0sTUFBTSxLQUFLLEVBQUc7QUFDM0IsY0FBSSxXQUFXO0FBQ2Isa0JBQU0sUUFBUSxVQUFVLFFBQVE7QUFDaEMsZ0JBQUksTUFBTSxTQUFTLFlBQVk7QUFDN0Isa0JBQUksTUFBTSxTQUFTO0FBQ2pCLHVCQUFPLEVBQUUsUUFBUSxrQkFBa0IsUUFBUSxpQkFBaUIsQ0FBQztBQUFBLHVCQUN0RCxNQUFNLFdBQVc7QUFDeEIsdUJBQU8sRUFBRSxRQUFRLGtCQUFrQixRQUFRLGtCQUFrQixDQUFDO0FBQUEsa0JBQzNELFFBQU8sRUFBRSxRQUFRLGVBQWUsUUFBUSxNQUFNLE9BQU8sQ0FBQztBQUMzRDtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBRUEsY0FBSSxZQUFZLFNBQVM7QUFDekIsY0FBSSxDQUFDLFVBQVc7QUFDaEIsbUJBQVMsT0FBTyxHQUFHLE9BQU8sR0FBRyxRQUFRO0FBQ25DLHVCQUFXLENBQUMsTUFBTSxLQUFLLEtBQUssT0FBTyxRQUFRO0FBQUEsY0FDekMsYUFBYSxHQUFHLFVBQVUsT0FBTyxXQUFXO0FBQUEsY0FDNUMsR0FBSSxZQUFZLEVBQUUsT0FBTyxHQUFHLFVBQVUsT0FBTyxXQUFXLEtBQUssSUFBSSxDQUFDO0FBQUEsY0FDbEUsQ0FBQyxVQUFVLE9BQU8sSUFBSSxHQUFHLEdBQUcsVUFBVSxPQUFPLEtBQUs7QUFBQSxjQUNsRCxDQUFDLFVBQVUsT0FBTyxTQUFTLFNBQVMsVUFBVSxNQUFNLEdBQUc7QUFBQSxZQUN6RCxDQUFDO0FBQ0Msa0JBQUksQ0FBQyxNQUFNLE1BQU0sS0FBSyxFQUFHO0FBQzNCLGdCQUFJLFdBQVc7QUFDYixvQkFBTSxRQUFRLFVBQVUsUUFBUTtBQUNoQyxrQkFBSSxNQUFNLFNBQVMsWUFBWTtBQUM3QixvQkFBSSxNQUFNLFNBQVM7QUFDakIseUJBQU8sRUFBRSxRQUFRLGtCQUFrQixRQUFRLGlCQUFpQixDQUFDO0FBQUEseUJBQ3RELE1BQU0sV0FBVztBQUN4Qix5QkFBTyxFQUFFLFFBQVEsa0JBQWtCLFFBQVEsa0JBQWtCLENBQUM7QUFBQSxvQkFDM0QsUUFBTyxFQUFFLFFBQVEsZUFBZSxRQUFRLE1BQU0sT0FBTyxDQUFDO0FBQzNEO0FBQUEsY0FDRjtBQUFBLFlBQ0Y7QUFDQSxrQkFBTSxjQUFjLFNBQVM7QUFDN0IsZ0JBQUksQ0FBQyxZQUFhO0FBQ2xCLG1CQUFPO0FBQ1Asa0JBQU0sV0FDSixXQUFXLENBQUMsbUJBQ1IsS0FBSyxJQUFJLEtBQUssSUFBSSxlQUFlLEtBQUssTUFBTSxhQUFhLEdBQUcsS0FBSyxNQUFNLFdBQVcsSUFDbEYsS0FBSyxNQUFNO0FBQ2pCLGtCQUFNLFNBQWlDO0FBQUEsY0FDckMsS0FBSyxLQUFLLE1BQU0sUUFBUSxVQUFVLFFBQVE7QUFBQSxjQUMxQyxRQUFRLEtBQUssTUFBTSxRQUFRLFFBQVEsUUFBUTtBQUFBLGNBQzNDLFFBQVEsR0FBRyxLQUFLLE1BQU0sTUFBTTtBQUFBLGNBQzVCLFFBQVEsR0FBRyxRQUFRO0FBQUEsY0FDbkIsY0FBYyxHQUFHLEtBQUssTUFBTSxXQUFXO0FBQUEsY0FDdkMsY0FBYyxHQUFHLEtBQUssTUFBTSxXQUFXO0FBQUEsWUFDekM7QUFDQSx1QkFBVyxDQUFDLE1BQU0sS0FBSyxLQUFLLE9BQU8sUUFBUSxNQUFNLEVBQUcsS0FBSSxDQUFDLE1BQU0sTUFBTSxLQUFLLEVBQUc7QUFDN0UsNEJBQWdCO0FBQ2hCLGlCQUFLLENBQUMsV0FBVyxxQkFBcUIsS0FBSyxvQkFBb0IsVUFBYSxLQUFLO0FBQy9FLHNCQUFRLFdBQVcsWUFBWSxLQUFLO0FBQUEscUJBQzdCLG9CQUFvQixLQUFLLEVBQUcsU0FBUSxXQUFXLFlBQVk7QUFDcEUsNkJBQWlCLFFBQVEsV0FBVztBQUNwQyxrQkFBTSxVQUFVLFNBQVM7QUFDekIsZ0JBQUksQ0FBQyxRQUFTO0FBQ2QsZ0JBQUksV0FBVyxXQUFXLFdBQVcsS0FBSyxXQUFXLGFBQWEsT0FBTyxHQUFHO0FBSTFFLG9CQUFNLFFBQVEsV0FBVyxPQUFPO0FBQ2hDLGtCQUFJLE9BQU8sU0FBUyxxQkFBcUI7QUFDdkMsc0JBQU0sV0FBVyxVQUFXLFFBQVE7QUFDcEMsb0JBQUksU0FBUyxTQUFTLFlBQVk7QUFDaEMsc0JBQUksU0FBUyxTQUFTO0FBQ3BCLDJCQUFPLEVBQUUsUUFBUSxrQkFBa0IsUUFBUSxpQkFBaUIsQ0FBQztBQUFBLDJCQUN0RCxTQUFTLFdBQVc7QUFDM0IsMkJBQU8sRUFBRSxRQUFRLGtCQUFrQixRQUFRLGtCQUFrQixDQUFDO0FBQUEsc0JBQzNELFFBQU8sRUFBRSxRQUFRLGVBQWUsUUFBUSxTQUFTLE9BQU8sQ0FBQztBQUM5RDtBQUFBLGdCQUNGO0FBQ0Esc0JBQU0sVUFBVSxTQUFTO0FBQ3pCLG9CQUFJLENBQUMsUUFBUztBQUNkLDRCQUFZO0FBQ1o7QUFBQSxjQUNGO0FBQ0Esa0JBQUksT0FBTyxTQUFTLGlCQUFpQixPQUFPLFNBQVMsV0FBVztBQUM5RCxvQkFBSSxNQUFNLFNBQVM7QUFDakIseUJBQU8sRUFBRSxRQUFRLGtCQUFrQixRQUFRLGlCQUFpQixDQUFDO0FBQUEseUJBQ3RELE1BQU0sV0FBVztBQUN4Qix5QkFBTyxFQUFFLFFBQVEsa0JBQWtCLFFBQVEsa0JBQWtCLENBQUM7QUFBQSxvQkFDM0QsUUFBTyxFQUFFLFFBQVEsZUFBZSxRQUFRLE1BQU0sT0FBTyxDQUFDO0FBQzNEO0FBQUEsY0FDRjtBQUNBLHlCQUFXLFVBQVUsYUFBYTtBQUNoQyxzQkFBTSxVQUFVLDJCQUEyQixRQUFRLEtBQUs7QUFDeEQsb0JBQUksWUFBWSxPQUFPO0FBQ3JCLGtDQUFnQixZQUFZLE9BQU8scUJBQXFCLGVBQWU7QUFDdkU7QUFBQSxnQkFDRjtBQUFBLGNBQ0Y7QUFDQSx1QkFBUztBQUNUO0FBQUEsWUFDRjtBQUNBLHdCQUFZO0FBQUEsVUFDZDtBQUFBLFFBQ0YsVUFBRTtBQUNBLG9CQUFVO0FBQUEsUUFDWjtBQUNBLFlBQUksQ0FBQyxLQUFLLEVBQUc7QUFDYixZQUFJLENBQUMsUUFBUTtBQUNYLDBCQUFnQixrQkFBa0I7QUFDbEM7QUFBQSxRQUNGO0FBQ0EsY0FBTSxhQUFhLENBQUM7QUFDcEIsdUJBQWU7QUFDZixZQUFJLGNBQWMsWUFBWSxXQUFXLFdBQVc7QUFDbEQsb0JBQVU7QUFDVixpQkFBTyxFQUFFLFFBQVEsVUFBVSxDQUFDO0FBQzVCLGNBQUksQ0FBQyxLQUFLLEVBQUc7QUFBQSxRQUNmO0FBQ0EsWUFBSSxZQUFZO0FBQ2Qsc0JBQVksS0FBSyxzQkFBc0IsTUFBTTtBQUMzQyx3QkFBWTtBQUNaLGdCQUFJLEtBQUssRUFBRyxVQUFTLFdBQVcsWUFBWTtBQUFBLFVBQzlDLENBQUM7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUNBLFlBQU0sV0FBVyxNQUFNO0FBQ3JCLFlBQUksQ0FBQyxLQUFLLEtBQUssV0FBVyxpQkFBaUIsQ0FBQyxLQUFNO0FBQ2xELGNBQU0sZUFBZSxRQUFRLFdBQVc7QUFDeEMsY0FBTSxTQUFTLHNCQUFzQjtBQUFBLFVBQ25DLFNBQVM7QUFBQSxVQUNULHNCQUFzQjtBQUFBLFVBQ3RCO0FBQUEsVUFDQSx1QkFBdUI7QUFBQSxVQUN2QixhQUFhLEtBQUssTUFBTTtBQUFBLFVBQ3hCLGVBQWUsS0FBSyxjQUFjLFdBQVcsWUFBWSxTQUFTO0FBQUEsVUFDbEUsS0FBSyxLQUFLLE1BQU07QUFBQSxRQUNsQixDQUFDO0FBQ0QsWUFBSSxPQUFPLFNBQVMsT0FBUTtBQUM1Qix5QkFBaUI7QUFDakIsa0JBQVU7QUFDVixZQUFJO0FBQ0YsY0FBSSxPQUFPLEtBQUssa0JBQWtCLFFBQVc7QUFDM0MsZ0JBQUksQ0FBQyxNQUFNLFVBQVUsR0FBRyxPQUFPLEtBQUssYUFBYSxJQUFJLEVBQUc7QUFDeEQsNEJBQWdCLE9BQU8sS0FBSztBQUFBLFVBQzlCO0FBQ0EsY0FBSSxPQUFPLEtBQUssb0JBQW9CLENBQUMsTUFBTSxtQkFBbUIsVUFBVSxFQUFHO0FBQzNFLGNBQUksT0FBTyxLQUFLLG9CQUFvQixVQUFhLEtBQUs7QUFDcEQsb0JBQVEsV0FBVyxZQUFZLE9BQU8sS0FBSztBQUM3QywyQkFBaUIsUUFBUSxXQUFXO0FBQUEsUUFDdEMsVUFBRTtBQUNBLG9CQUFVO0FBQUEsUUFDWjtBQUFBLE1BQ0Y7QUFDQSxZQUFNLGdCQUFnQixDQUFDLFVBQWlCO0FBQ3RDLFlBQUksTUFBTSxXQUFXLFFBQVEsV0FBWSxVQUFTO0FBQUEsTUFDcEQ7QUFDQSxZQUFNLGtCQUFrQixvQkFBSSxJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssSUFBSSxDQUFDLFFBQVEsUUFBUSxHQUFHLENBQUMsR0FBRyxHQUFHLFdBQVcsQ0FBQztBQUUzRixZQUFNLFlBQ0osT0FBTyxLQUFLLG1CQUFtQixhQUMxQixDQUFDLGVBQWUsWUFBWSxFQUFZLElBQUksQ0FBQ0MsU0FBUTtBQUNwRCxjQUFNLFdBQVcsSUFBSSxLQUFLLGVBQWUsTUFBTSxTQUFTLENBQUM7QUFDekQsbUJBQVcsVUFBVSxnQkFBaUIsVUFBUyxRQUFRLFFBQVEsRUFBRSxLQUFBQSxLQUFJLENBQUM7QUFDdEUsZUFBTztBQUFBLE1BQ1QsQ0FBQyxJQUNELENBQUM7QUFDUCxjQUFRLFdBQVcsaUJBQWlCLFVBQVUsUUFBUTtBQUN0RCxVQUFJLGlCQUFpQixVQUFVLGVBQWUsSUFBSTtBQUNsRCxXQUFLLGlCQUFpQixVQUFVLFFBQVE7QUFDeEMsYUFBTyxNQUFNO0FBQ1gsbUJBQVcsWUFBWSxVQUFXLFVBQVMsV0FBVztBQUN0RCxnQkFBUSxXQUFXLG9CQUFvQixVQUFVLFFBQVE7QUFDekQsWUFBSSxvQkFBb0IsVUFBVSxlQUFlLElBQUk7QUFDckQsYUFBSyxvQkFBb0IsVUFBVSxRQUFRO0FBQzNDLFlBQUksY0FBYyxLQUFNLE1BQUsscUJBQXFCLFNBQVM7QUFDM0Qsb0JBQVk7QUFBQSxNQUNkO0FBQ0EsdUJBQWlCO0FBQ2pCLGVBQVM7QUFBQSxJQUNYO0FBQ0EsVUFBTTtBQUNOLFdBQU87QUFBQSxNQUNMLE9BQU8sTUFBTTtBQUNYLFlBQUksU0FBVTtBQUNkLFlBQUksYUFBYSxZQUFZLElBQUksR0FBRztBQUNsQyx1QkFBYTtBQUNiLGdCQUFNLFVBQVU7QUFDaEIsMkJBQWlCO0FBQ2pCLGNBQUksQ0FBQyxZQUFZLFlBQVksV0FBVyxlQUFlLFFBQVE7QUFDN0QsaUJBQUssY0FBYyxVQUFVO0FBQy9CO0FBQUEsUUFDRjtBQUNBLHFCQUFhO0FBQ2IsY0FBTTtBQUFBLE1BQ1I7QUFBQSxNQUNBLGdCQUFnQjtBQUNkLFlBQUksQ0FBQyxTQUFVLGtCQUFpQjtBQUFBLE1BQ2xDO0FBQUEsTUFDQSxVQUFVO0FBQ1IsWUFBSSxTQUFVO0FBQ2QsbUJBQVc7QUFDWDtBQUNBLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7OztBQ2pmQSxNQUFNLGFBQWEsb0JBQUksUUFBeUM7QUFpRHpELFdBQVMsNEJBQTRCLE9BQWdEO0FBQzFGLFFBQUksQ0FBQyxTQUFTLE9BQU8sVUFBVSxTQUFVLFFBQU87QUFDaEQsVUFBTSxZQUFZLFdBQVcsSUFBSSxLQUFLO0FBQ3RDLFdBQU8sV0FBVyxPQUFPLElBQUksWUFBWTtBQUFBLEVBQzNDOzs7QUNuREEsTUFBTSxRQUFRLG9CQUFJLFFBQTJCO0FBQzdDLE1BQU0sT0FBTyxDQUFDLFVBQWtDO0FBQUEsSUFDOUMsT0FBTyxLQUFLO0FBQUEsSUFDWixRQUFRLEtBQUs7QUFBQSxJQUNiLE1BQU0sS0FBSztBQUFBLElBQ1gsVUFBVSxLQUFLLHNCQUFzQixFQUFFO0FBQUEsSUFDdkMsU0FBUyxLQUFLLHNCQUFzQixFQUFFLFFBQVEsS0FBSyxjQUFjLGFBQWEsV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBLElBSXpGLFdBQVcsS0FBSyxjQUFjLE1BQU0sZUFBZTtBQUFBLElBQ25ELFVBQVUsS0FBSyxjQUFjLE1BQU0sc0JBQXNCLEVBQUUsUUFBUTtBQUFBLEVBQ3JFO0FBQ08sV0FBUyxpQkFBaUJDLFdBQW9CLFVBQWtDO0FBQ3JGLFVBQU0sT0FBT0EsVUFBUyxpQkFDcEIsT0FBT0EsVUFBUztBQUNsQixRQUFJLENBQUMsUUFBUSxDQUFDLEtBQU0sUUFBTyxNQUFNO0FBQUEsSUFBQztBQUNsQyxRQUFJLFVBQVUsTUFBTSxJQUFJQSxTQUFRO0FBQ2hDLFFBQUksQ0FBQyxTQUFTO0FBQ1osVUFBSSxXQUFXLEtBQUssSUFBSSxHQUN0QixXQUFXO0FBQ2IsWUFBTSxZQUFZLG9CQUFJLElBQWdCO0FBQ3RDLFlBQU0sU0FBUyxNQUFNO0FBQ25CLFlBQUksU0FBVTtBQUNkLGNBQU0sT0FBTyxLQUFLLElBQUk7QUFDdEIsWUFDRSxLQUFLLFVBQVUsU0FBUyxTQUN4QixLQUFLLFdBQVcsU0FBUyxVQUN6QixLQUFLLFNBQVMsU0FBUyxRQUN2QixLQUFLLGFBQWEsU0FBUyxZQUMzQixLQUFLLFlBQVksU0FBUyxXQUMxQixLQUFLLGNBQWMsU0FBUyxhQUM1QixLQUFLLGFBQWEsU0FBUztBQUUzQjtBQUNGLG1CQUFXO0FBQ1gsY0FBTSxTQUFvQixDQUFDO0FBQzNCLG1CQUFXLFlBQVksQ0FBQyxHQUFHLFNBQVMsR0FBRztBQUNyQyxjQUFJLENBQUMsVUFBVSxJQUFJLFFBQVEsRUFBRztBQUM5QixjQUFJO0FBQ0YscUJBQVM7QUFBQSxVQUNYLFNBQVMsT0FBTztBQUNkLG1CQUFPLEtBQUssS0FBSztBQUFBLFVBQ25CO0FBQUEsUUFDRjtBQUdBLFlBQUksT0FBTyxXQUFXLEVBQUcsT0FBTSxPQUFPLENBQUM7QUFDdkMsWUFBSSxPQUFPLFNBQVMsRUFBRyxPQUFNLElBQUksZUFBZSxRQUFRLCtCQUErQjtBQUFBLE1BQ3pGO0FBQ0EsWUFBTSxTQUNKLE9BQU8sS0FBSyxtQkFBbUIsYUFBYSxJQUFJLEtBQUssZUFBZSxNQUFNLElBQUk7QUFDaEYsWUFBTSxXQUNKLE9BQU8sS0FBSyxxQkFBcUIsYUFBYSxJQUFJLEtBQUssaUJBQWlCLE1BQU0sSUFBSTtBQUNwRixnQkFBVTtBQUFBLFFBQ1I7QUFBQSxRQUNBLFVBQVU7QUFDUixxQkFBVztBQUNYLGtCQUFRLFdBQVc7QUFDbkIsb0JBQVUsV0FBVztBQUNyQixnQkFBTSxPQUFPQSxTQUFRO0FBQUEsUUFDdkI7QUFBQSxNQUNGO0FBQ0EsWUFBTSxJQUFJQSxXQUFVLE9BQU87QUFHM0IsY0FBUSxRQUFRLElBQUk7QUFJcEIsVUFBSUEsVUFBUyxLQUFNLFNBQVEsUUFBUUEsVUFBUyxJQUFJO0FBRWhELGdCQUFVLFFBQVEsTUFBTSxFQUFFLFlBQVksTUFBTSxpQkFBaUIsQ0FBQyxPQUFPLFNBQVMsT0FBTyxFQUFFLENBQUM7QUFHeEYsVUFBSUEsVUFBUztBQUNYLGtCQUFVLFFBQVFBLFVBQVMsTUFBTTtBQUFBLFVBQy9CLFlBQVk7QUFBQSxVQUNaLGlCQUFpQixDQUFDLE9BQU8sU0FBUyxPQUFPO0FBQUEsUUFDM0MsQ0FBQztBQUFBLElBQ0w7QUFDQSxVQUFNLFFBQVE7QUFDZCxVQUFNLGdCQUFnQixNQUFNLFNBQVM7QUFDckMsVUFBTSxVQUFVLElBQUksYUFBYTtBQUNqQyxRQUFJLFdBQVc7QUFDZixXQUFPLE1BQU07QUFDWCxVQUFJLFNBQVU7QUFDZCxpQkFBVztBQUNYLFlBQU0sVUFBVSxPQUFPLGFBQWE7QUFDcEMsVUFBSSxDQUFDLE1BQU0sVUFBVSxLQUFNLE9BQU0sUUFBUTtBQUFBLElBQzNDO0FBQUEsRUFDRjs7O0FDOUZBLE1BQU0sTUFBTSxLQUFLO0FBQ2pCLE1BQU0sTUFBTSxLQUFLO0FBQ2pCLE1BQU0sUUFBUSxLQUFLO0FBQ25CLE1BQU0sUUFBUSxLQUFLO0FBQ25CLE1BQU0sZUFBZSxRQUFNO0FBQUEsSUFDekIsR0FBRztBQUFBLElBQ0gsR0FBRztBQUFBLEVBQ0w7QUFDQSxNQUFNLGtCQUFrQjtBQUFBLElBQ3RCLE1BQU07QUFBQSxJQUNOLE9BQU87QUFBQSxJQUNQLFFBQVE7QUFBQSxJQUNSLEtBQUs7QUFBQSxFQUNQO0FBQ0EsV0FBU0MsT0FBTSxPQUFPLE9BQU8sS0FBSztBQUNoQyxXQUFPLElBQUksT0FBTyxJQUFJLE9BQU8sR0FBRyxDQUFDO0FBQUEsRUFDbkM7QUFDQSxXQUFTLFNBQVMsT0FBTyxPQUFPO0FBQzlCLFdBQU8sT0FBTyxVQUFVLGFBQWEsTUFBTSxLQUFLLElBQUk7QUFBQSxFQUN0RDtBQUNBLFdBQVMsUUFBUSxXQUFXO0FBQzFCLFdBQU8sVUFBVSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDL0I7QUFDQSxXQUFTLGFBQWEsV0FBVztBQUMvQixXQUFPLFVBQVUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQy9CO0FBQ0EsV0FBUyxnQkFBZ0IsTUFBTTtBQUM3QixXQUFPLFNBQVMsTUFBTSxNQUFNO0FBQUEsRUFDOUI7QUFDQSxXQUFTLGNBQWMsTUFBTTtBQUMzQixXQUFPLFNBQVMsTUFBTSxXQUFXO0FBQUEsRUFDbkM7QUFDQSxXQUFTLFlBQVksV0FBVztBQUM5QixVQUFNLFlBQVksVUFBVSxDQUFDO0FBQzdCLFdBQU8sY0FBYyxPQUFPLGNBQWMsTUFBTSxNQUFNO0FBQUEsRUFDeEQ7QUFDQSxXQUFTLGlCQUFpQixXQUFXO0FBQ25DLFdBQU8sZ0JBQWdCLFlBQVksU0FBUyxDQUFDO0FBQUEsRUFDL0M7QUFDQSxXQUFTLGtCQUFrQixXQUFXLE9BQU8sS0FBSztBQUNoRCxRQUFJLFFBQVEsUUFBUTtBQUNsQixZQUFNO0FBQUEsSUFDUjtBQUNBLFVBQU0sWUFBWSxhQUFhLFNBQVM7QUFDeEMsVUFBTSxnQkFBZ0IsaUJBQWlCLFNBQVM7QUFDaEQsVUFBTSxTQUFTLGNBQWMsYUFBYTtBQUMxQyxRQUFJLG9CQUFvQixrQkFBa0IsTUFBTSxlQUFlLE1BQU0sUUFBUSxXQUFXLFVBQVUsU0FBUyxjQUFjLFVBQVUsV0FBVztBQUM5SSxRQUFJLE1BQU0sVUFBVSxNQUFNLElBQUksTUFBTSxTQUFTLE1BQU0sR0FBRztBQUNwRCwwQkFBb0IscUJBQXFCLGlCQUFpQjtBQUFBLElBQzVEO0FBQ0EsV0FBTyxDQUFDLG1CQUFtQixxQkFBcUIsaUJBQWlCLENBQUM7QUFBQSxFQUNwRTtBQUNBLFdBQVMsc0JBQXNCLFdBQVc7QUFDeEMsVUFBTSxvQkFBb0IscUJBQXFCLFNBQVM7QUFDeEQsV0FBTyxDQUFDLDhCQUE4QixTQUFTLEdBQUcsbUJBQW1CLDhCQUE4QixpQkFBaUIsQ0FBQztBQUFBLEVBQ3ZIO0FBQ0EsV0FBUyw4QkFBOEIsV0FBVztBQUNoRCxXQUFPLFVBQVUsU0FBUyxPQUFPLElBQUksVUFBVSxRQUFRLFNBQVMsS0FBSyxJQUFJLFVBQVUsUUFBUSxPQUFPLE9BQU87QUFBQSxFQUMzRztBQUNBLE1BQU0sY0FBYyxDQUFDLFFBQVEsT0FBTztBQUNwQyxNQUFNLGNBQWMsQ0FBQyxTQUFTLE1BQU07QUFDcEMsTUFBTSxjQUFjLENBQUMsT0FBTyxRQUFRO0FBQ3BDLE1BQU0sY0FBYyxDQUFDLFVBQVUsS0FBSztBQUNwQyxXQUFTLFlBQVksTUFBTSxTQUFTLEtBQUs7QUFDdkMsWUFBUSxNQUFNO0FBQUEsTUFDWixLQUFLO0FBQUEsTUFDTCxLQUFLO0FBQ0gsWUFBSSxJQUFLLFFBQU8sVUFBVSxjQUFjO0FBQ3hDLGVBQU8sVUFBVSxjQUFjO0FBQUEsTUFDakMsS0FBSztBQUFBLE1BQ0wsS0FBSztBQUNILGVBQU8sVUFBVSxjQUFjO0FBQUEsTUFDakM7QUFDRSxlQUFPLENBQUM7QUFBQSxJQUNaO0FBQUEsRUFDRjtBQUNBLFdBQVMsMEJBQTBCLFdBQVcsZUFBZSxXQUFXLEtBQUs7QUFDM0UsVUFBTSxZQUFZLGFBQWEsU0FBUztBQUN4QyxRQUFJLE9BQU8sWUFBWSxRQUFRLFNBQVMsR0FBRyxjQUFjLFNBQVMsR0FBRztBQUNyRSxRQUFJLFdBQVc7QUFDYixhQUFPLEtBQUssSUFBSSxVQUFRLE9BQU8sTUFBTSxTQUFTO0FBQzlDLFVBQUksZUFBZTtBQUNqQixlQUFPLEtBQUssT0FBTyxLQUFLLElBQUksNkJBQTZCLENBQUM7QUFBQSxNQUM1RDtBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNBLFdBQVMscUJBQXFCLFdBQVc7QUFDdkMsVUFBTSxPQUFPLFFBQVEsU0FBUztBQUM5QixXQUFPLGdCQUFnQixJQUFJLElBQUksVUFBVSxNQUFNLEtBQUssTUFBTTtBQUFBLEVBQzVEO0FBQ0EsV0FBUyxvQkFBb0IsU0FBUztBQUNwQyxRQUFJLGNBQWMsZ0JBQWdCLGlCQUFpQjtBQUNuRCxXQUFPO0FBQUEsTUFDTCxNQUFNLGVBQWUsUUFBUSxRQUFRLE9BQU8sZUFBZTtBQUFBLE1BQzNELFFBQVEsaUJBQWlCLFFBQVEsVUFBVSxPQUFPLGlCQUFpQjtBQUFBLE1BQ25FLFNBQVMsa0JBQWtCLFFBQVEsV0FBVyxPQUFPLGtCQUFrQjtBQUFBLE1BQ3ZFLE9BQU8sZ0JBQWdCLFFBQVEsU0FBUyxPQUFPLGdCQUFnQjtBQUFBLElBQ2pFO0FBQUEsRUFDRjtBQUNBLFdBQVMsaUJBQWlCLFNBQVM7QUFDakMsV0FBTyxPQUFPLFlBQVksV0FBVyxvQkFBb0IsT0FBTyxJQUFJO0FBQUEsTUFDbEUsS0FBSztBQUFBLE1BQ0wsT0FBTztBQUFBLE1BQ1AsUUFBUTtBQUFBLE1BQ1IsTUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQ0EsV0FBUyxpQkFBaUIsTUFBTTtBQUM5QixVQUFNO0FBQUEsTUFDSjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsSUFBSTtBQUNKLFdBQU87QUFBQSxNQUNMO0FBQUEsTUFDQTtBQUFBLE1BQ0EsS0FBSztBQUFBLE1BQ0wsTUFBTTtBQUFBLE1BQ04sT0FBTyxJQUFJO0FBQUEsTUFDWCxRQUFRLElBQUk7QUFBQSxNQUNaO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxFQUNGOzs7QUNsSUEsV0FBUywyQkFBMkIsTUFBTSxXQUFXLEtBQUs7QUFDeEQsUUFBSTtBQUFBLE1BQ0Y7QUFBQSxNQUNBLFVBQUFDO0FBQUEsSUFDRixJQUFJO0FBQ0osVUFBTSxXQUFXLFlBQVksU0FBUztBQUN0QyxVQUFNLGdCQUFnQixpQkFBaUIsU0FBUztBQUNoRCxVQUFNLGNBQWMsY0FBYyxhQUFhO0FBQy9DLFVBQU0sT0FBTyxRQUFRLFNBQVM7QUFDOUIsVUFBTSxhQUFhLGFBQWE7QUFDaEMsVUFBTSxVQUFVLFVBQVUsSUFBSSxVQUFVLFFBQVEsSUFBSUEsVUFBUyxRQUFRO0FBQ3JFLFVBQU0sVUFBVSxVQUFVLElBQUksVUFBVSxTQUFTLElBQUlBLFVBQVMsU0FBUztBQUN2RSxVQUFNLGNBQWMsVUFBVSxXQUFXLElBQUksSUFBSUEsVUFBUyxXQUFXLElBQUk7QUFDekUsUUFBSTtBQUNKLFlBQVEsTUFBTTtBQUFBLE1BQ1osS0FBSztBQUNILGlCQUFTO0FBQUEsVUFDUCxHQUFHO0FBQUEsVUFDSCxHQUFHLFVBQVUsSUFBSUEsVUFBUztBQUFBLFFBQzVCO0FBQ0E7QUFBQSxNQUNGLEtBQUs7QUFDSCxpQkFBUztBQUFBLFVBQ1AsR0FBRztBQUFBLFVBQ0gsR0FBRyxVQUFVLElBQUksVUFBVTtBQUFBLFFBQzdCO0FBQ0E7QUFBQSxNQUNGLEtBQUs7QUFDSCxpQkFBUztBQUFBLFVBQ1AsR0FBRyxVQUFVLElBQUksVUFBVTtBQUFBLFVBQzNCLEdBQUc7QUFBQSxRQUNMO0FBQ0E7QUFBQSxNQUNGLEtBQUs7QUFDSCxpQkFBUztBQUFBLFVBQ1AsR0FBRyxVQUFVLElBQUlBLFVBQVM7QUFBQSxVQUMxQixHQUFHO0FBQUEsUUFDTDtBQUNBO0FBQUEsTUFDRjtBQUNFLGlCQUFTO0FBQUEsVUFDUCxHQUFHLFVBQVU7QUFBQSxVQUNiLEdBQUcsVUFBVTtBQUFBLFFBQ2Y7QUFBQSxJQUNKO0FBQ0EsVUFBTSxZQUFZLGFBQWEsU0FBUztBQUN4QyxRQUFJLFdBQVc7QUFDYixhQUFPLGFBQWEsS0FBSyxlQUFlLGNBQWMsUUFBUSxJQUFJLE9BQU8sT0FBTyxhQUFhLEtBQUs7QUFBQSxJQUNwRztBQUNBLFdBQU87QUFBQSxFQUNUO0FBVUEsaUJBQWUsZUFBZSxPQUFPLFNBQVM7QUFDNUMsUUFBSTtBQUNKLFFBQUksWUFBWSxRQUFRO0FBQ3RCLGdCQUFVLENBQUM7QUFBQSxJQUNiO0FBQ0EsVUFBTTtBQUFBLE1BQ0o7QUFBQSxNQUNBO0FBQUEsTUFDQSxVQUFBQztBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsSUFBSTtBQUNKLFVBQU07QUFBQSxNQUNKLFdBQVc7QUFBQSxNQUNYLGVBQWU7QUFBQSxNQUNmLGlCQUFpQjtBQUFBLE1BQ2pCLGNBQWM7QUFBQSxNQUNkLFVBQVU7QUFBQSxJQUNaLElBQUksU0FBUyxTQUFTLEtBQUs7QUFDM0IsVUFBTSxnQkFBZ0IsaUJBQWlCLE9BQU87QUFDOUMsVUFBTSxhQUFhLG1CQUFtQixhQUFhLGNBQWM7QUFDakUsVUFBTUMsV0FBVSxTQUFTLGNBQWMsYUFBYSxjQUFjO0FBQ2xFLFVBQU0scUJBQXFCLGlCQUFpQixNQUFNRCxVQUFTLGdCQUFnQjtBQUFBLE1BQ3pFLFdBQVcsd0JBQXdCLE9BQU9BLFVBQVMsYUFBYSxPQUFPLFNBQVNBLFVBQVMsVUFBVUMsUUFBTyxPQUFPLE9BQU8sd0JBQXdCLFFBQVFBLFdBQVVBLFNBQVEsa0JBQW1CLE9BQU9ELFVBQVMsc0JBQXNCLE9BQU8sU0FBU0EsVUFBUyxtQkFBbUIsU0FBUyxRQUFRO0FBQUEsTUFDaFM7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQyxDQUFDO0FBQ0YsVUFBTSxPQUFPLG1CQUFtQixhQUFhO0FBQUEsTUFDM0M7QUFBQSxNQUNBO0FBQUEsTUFDQSxPQUFPLE1BQU0sU0FBUztBQUFBLE1BQ3RCLFFBQVEsTUFBTSxTQUFTO0FBQUEsSUFDekIsSUFBSSxNQUFNO0FBQ1YsVUFBTSxlQUFlLE9BQU9BLFVBQVMsbUJBQW1CLE9BQU8sU0FBU0EsVUFBUyxnQkFBZ0IsU0FBUyxRQUFRO0FBQ2xILFVBQU0sY0FBZSxPQUFPQSxVQUFTLGFBQWEsT0FBTyxTQUFTQSxVQUFTLFVBQVUsWUFBWSxNQUFRLE9BQU9BLFVBQVMsWUFBWSxPQUFPLFNBQVNBLFVBQVMsU0FBUyxZQUFZLE1BQU87QUFBQSxNQUN4TCxHQUFHO0FBQUEsTUFDSCxHQUFHO0FBQUEsSUFDTDtBQUNBLFVBQU0sb0JBQW9CLGlCQUFpQkEsVUFBUyx3REFBd0QsTUFBTUEsVUFBUyxzREFBc0Q7QUFBQSxNQUMvSztBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQyxJQUFJLElBQUk7QUFDVCxXQUFPO0FBQUEsTUFDTCxNQUFNLG1CQUFtQixNQUFNLGtCQUFrQixNQUFNLGNBQWMsT0FBTyxZQUFZO0FBQUEsTUFDeEYsU0FBUyxrQkFBa0IsU0FBUyxtQkFBbUIsU0FBUyxjQUFjLFVBQVUsWUFBWTtBQUFBLE1BQ3BHLE9BQU8sbUJBQW1CLE9BQU8sa0JBQWtCLE9BQU8sY0FBYyxRQUFRLFlBQVk7QUFBQSxNQUM1RixRQUFRLGtCQUFrQixRQUFRLG1CQUFtQixRQUFRLGNBQWMsU0FBUyxZQUFZO0FBQUEsSUFDbEc7QUFBQSxFQUNGO0FBR0EsTUFBTSxrQkFBa0I7QUFTeEIsTUFBTSxrQkFBa0IsT0FBTyxXQUFXRCxXQUFVRyxZQUFXO0FBQzdELFVBQU07QUFBQSxNQUNKLFlBQVk7QUFBQSxNQUNaLFdBQVc7QUFBQSxNQUNYLGFBQWEsQ0FBQztBQUFBLE1BQ2QsVUFBQUY7QUFBQSxJQUNGLElBQUlFO0FBQ0osVUFBTSw2QkFBNkJGLFVBQVMsaUJBQWlCQSxZQUFXO0FBQUEsTUFDdEUsR0FBR0E7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUNBLFVBQU0sTUFBTSxPQUFPQSxVQUFTLFNBQVMsT0FBTyxTQUFTQSxVQUFTLE1BQU1ELFNBQVE7QUFDNUUsUUFBSSxRQUFRLE1BQU1DLFVBQVMsZ0JBQWdCO0FBQUEsTUFDekM7QUFBQSxNQUNBLFVBQUFEO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUNELFFBQUk7QUFBQSxNQUNGO0FBQUEsTUFDQTtBQUFBLElBQ0YsSUFBSSwyQkFBMkIsT0FBTyxXQUFXLEdBQUc7QUFDcEQsUUFBSSxvQkFBb0I7QUFDeEIsUUFBSSxhQUFhO0FBQ2pCLFVBQU0saUJBQWlCLENBQUM7QUFDeEIsYUFBUyxJQUFJLEdBQUcsSUFBSSxXQUFXLFFBQVEsS0FBSztBQUMxQyxZQUFNLG9CQUFvQixXQUFXLENBQUM7QUFDdEMsVUFBSSxDQUFDLG1CQUFtQjtBQUN0QjtBQUFBLE1BQ0Y7QUFDQSxZQUFNO0FBQUEsUUFDSjtBQUFBLFFBQ0E7QUFBQSxNQUNGLElBQUk7QUFDSixZQUFNO0FBQUEsUUFDSixHQUFHO0FBQUEsUUFDSCxHQUFHO0FBQUEsUUFDSDtBQUFBLFFBQ0E7QUFBQSxNQUNGLElBQUksTUFBTSxHQUFHO0FBQUEsUUFDWDtBQUFBLFFBQ0E7QUFBQSxRQUNBLGtCQUFrQjtBQUFBLFFBQ2xCLFdBQVc7QUFBQSxRQUNYO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLFVBQVU7QUFBQSxRQUNWLFVBQVU7QUFBQSxVQUNSO0FBQUEsVUFDQSxVQUFBQTtBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFDRCxVQUFJLFNBQVMsT0FBTyxRQUFRO0FBQzVCLFVBQUksU0FBUyxPQUFPLFFBQVE7QUFDNUIscUJBQWUsSUFBSSxJQUFJO0FBQUEsUUFDckIsR0FBRyxlQUFlLElBQUk7QUFBQSxRQUN0QixHQUFHO0FBQUEsTUFDTDtBQUNBLFVBQUksU0FBUyxhQUFhLGlCQUFpQjtBQUN6QztBQUNBLFlBQUksT0FBTyxVQUFVLFVBQVU7QUFDN0IsY0FBSSxNQUFNLFdBQVc7QUFDbkIsZ0NBQW9CLE1BQU07QUFBQSxVQUM1QjtBQUNBLGNBQUksTUFBTSxPQUFPO0FBQ2Ysb0JBQVEsTUFBTSxVQUFVLE9BQU8sTUFBTUMsVUFBUyxnQkFBZ0I7QUFBQSxjQUM1RDtBQUFBLGNBQ0EsVUFBQUQ7QUFBQSxjQUNBO0FBQUEsWUFDRixDQUFDLElBQUksTUFBTTtBQUFBLFVBQ2I7QUFDQSxXQUFDO0FBQUEsWUFDQztBQUFBLFlBQ0E7QUFBQSxVQUNGLElBQUksMkJBQTJCLE9BQU8sbUJBQW1CLEdBQUc7QUFBQSxRQUM5RDtBQUNBLFlBQUk7QUFBQSxNQUNOO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxNQUNMO0FBQUEsTUFDQTtBQUFBLE1BQ0EsV0FBVztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFnTUEsTUFBTSxPQUFPLFNBQVUsU0FBUztBQUM5QixRQUFJLFlBQVksUUFBUTtBQUN0QixnQkFBVSxDQUFDO0FBQUEsSUFDYjtBQUNBLFdBQU87QUFBQSxNQUNMLE1BQU07QUFBQSxNQUNOO0FBQUEsTUFDQSxNQUFNLEdBQUcsT0FBTztBQUNkLFlBQUksdUJBQXVCO0FBQzNCLGNBQU07QUFBQSxVQUNKO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQSxVQUFBSTtBQUFBLFVBQ0E7QUFBQSxRQUNGLElBQUk7QUFDSixjQUFNO0FBQUEsVUFDSixVQUFVLGdCQUFnQjtBQUFBLFVBQzFCLFdBQVcsaUJBQWlCO0FBQUEsVUFDNUIsb0JBQW9CO0FBQUEsVUFDcEIsbUJBQW1CO0FBQUEsVUFDbkIsNEJBQTRCO0FBQUEsVUFDNUIsZ0JBQWdCO0FBQUEsVUFDaEIsR0FBRztBQUFBLFFBQ0wsSUFBSSxTQUFTLFNBQVMsS0FBSztBQU0zQixhQUFLLHdCQUF3QixlQUFlLFVBQVUsUUFBUSxzQkFBc0IsaUJBQWlCO0FBQ25HLGlCQUFPLENBQUM7QUFBQSxRQUNWO0FBQ0EsY0FBTSxPQUFPLFFBQVEsU0FBUztBQUM5QixjQUFNLGtCQUFrQixZQUFZLGdCQUFnQjtBQUNwRCxjQUFNLGtCQUFrQixRQUFRLGdCQUFnQixNQUFNO0FBQ3RELGNBQU0sTUFBTSxPQUFPQSxVQUFTLFNBQVMsT0FBTyxTQUFTQSxVQUFTLE1BQU0sU0FBUyxRQUFRO0FBQ3JGLGNBQU0scUJBQXFCLGdDQUFnQyxtQkFBbUIsQ0FBQyxnQkFBZ0IsQ0FBQyxxQkFBcUIsZ0JBQWdCLENBQUMsSUFBSSxzQkFBc0IsZ0JBQWdCO0FBQ2hMLGNBQU0sK0JBQStCLDhCQUE4QjtBQUNuRSxZQUFJLENBQUMsK0JBQStCLDhCQUE4QjtBQUNoRSw2QkFBbUIsS0FBSyxHQUFHLDBCQUEwQixrQkFBa0IsZUFBZSwyQkFBMkIsR0FBRyxDQUFDO0FBQUEsUUFDdkg7QUFDQSxjQUFNQyxjQUFhLENBQUMsa0JBQWtCLEdBQUcsa0JBQWtCO0FBQzNELGNBQU0sV0FBVyxNQUFNRCxVQUFTLGVBQWUsT0FBTyxxQkFBcUI7QUFDM0UsY0FBTSxZQUFZLENBQUM7QUFDbkIsWUFBSSxrQkFBa0IsdUJBQXVCLGVBQWUsU0FBUyxPQUFPLFNBQVMscUJBQXFCLGNBQWMsQ0FBQztBQUN6SCxZQUFJLGVBQWU7QUFDakIsb0JBQVUsS0FBSyxTQUFTLElBQUksQ0FBQztBQUFBLFFBQy9CO0FBQ0EsWUFBSSxnQkFBZ0I7QUFDbEIsZ0JBQU1FLFNBQVEsa0JBQWtCLFdBQVcsT0FBTyxHQUFHO0FBQ3JELG9CQUFVLEtBQUssU0FBU0EsT0FBTSxDQUFDLENBQUMsR0FBRyxTQUFTQSxPQUFNLENBQUMsQ0FBQyxDQUFDO0FBQUEsUUFDdkQ7QUFDQSx3QkFBZ0IsQ0FBQyxHQUFHLGVBQWU7QUFBQSxVQUNqQztBQUFBLFVBQ0E7QUFBQSxRQUNGLENBQUM7QUFHRCxZQUFJLENBQUMsVUFBVSxNQUFNLENBQUFDLFVBQVFBLFNBQVEsQ0FBQyxHQUFHO0FBQ3ZDLGNBQUksdUJBQXVCO0FBQzNCLGdCQUFNLGVBQWUsd0JBQXdCLGVBQWUsU0FBUyxPQUFPLFNBQVMsc0JBQXNCLFVBQVUsS0FBSztBQUMxSCxnQkFBTSxnQkFBZ0JGLFlBQVcsU0FBUztBQUMxQyxjQUFJLGVBQWU7QUFDakIsa0JBQU0sMEJBQTBCLG1CQUFtQixjQUFjLG9CQUFvQixZQUFZLGFBQWEsSUFBSTtBQUNsSCxnQkFBSSxDQUFDO0FBQUE7QUFBQSxZQUdMLGNBQWMsTUFBTSxPQUFLLFlBQVksRUFBRSxTQUFTLE1BQU0sa0JBQWtCLEVBQUUsVUFBVSxDQUFDLElBQUksSUFBSSxJQUFJLEdBQUc7QUFFbEcscUJBQU87QUFBQSxnQkFDTCxNQUFNO0FBQUEsa0JBQ0osT0FBTztBQUFBLGtCQUNQLFdBQVc7QUFBQSxnQkFDYjtBQUFBLGdCQUNBLE9BQU87QUFBQSxrQkFDTCxXQUFXO0FBQUEsZ0JBQ2I7QUFBQSxjQUNGO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFJQSxjQUFJLGtCQUFrQix3QkFBd0IsY0FBYyxPQUFPLE9BQUssRUFBRSxVQUFVLENBQUMsS0FBSyxDQUFDLEVBQUUsS0FBSyxDQUFDLEdBQUcsTUFBTSxFQUFFLFVBQVUsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sT0FBTyxTQUFTLHNCQUFzQjtBQUcxTCxjQUFJLENBQUMsZ0JBQWdCO0FBQ25CLG9CQUFRLGtCQUFrQjtBQUFBLGNBQ3hCLEtBQUssV0FDSDtBQUNFLG9CQUFJO0FBQ0osc0JBQU1HLGNBQWEseUJBQXlCLGNBQWMsT0FBTyxPQUFLO0FBQ3BFLHNCQUFJLDhCQUE4QjtBQUNoQywwQkFBTSxrQkFBa0IsWUFBWSxFQUFFLFNBQVM7QUFDL0MsMkJBQU8sb0JBQW9CO0FBQUE7QUFBQSxvQkFHM0Isb0JBQW9CO0FBQUEsa0JBQ3RCO0FBQ0EseUJBQU87QUFBQSxnQkFDVCxDQUFDLEVBQUUsSUFBSSxPQUFLLENBQUMsRUFBRSxXQUFXLEVBQUUsVUFBVSxPQUFPLENBQUFDLGNBQVlBLFlBQVcsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxLQUFLQSxjQUFhLE1BQU1BLFdBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsR0FBRyxNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNLE9BQU8sU0FBUyx1QkFBdUIsQ0FBQztBQUNqTSxvQkFBSUQsWUFBVztBQUNiLG1DQUFpQkE7QUFBQSxnQkFDbkI7QUFDQTtBQUFBLGNBQ0Y7QUFBQSxjQUNGLEtBQUs7QUFDSCxpQ0FBaUI7QUFDakI7QUFBQSxZQUNKO0FBQUEsVUFDRjtBQUNBLGNBQUksY0FBYyxnQkFBZ0I7QUFDaEMsbUJBQU87QUFBQSxjQUNMLE9BQU87QUFBQSxnQkFDTCxXQUFXO0FBQUEsY0FDYjtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUNBLGVBQU8sQ0FBQztBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQW9NQSxNQUFNLGNBQTJCLG9CQUFJLElBQUksQ0FBQyxRQUFRLEtBQUssQ0FBQztBQUt4RCxpQkFBZSxxQkFBcUIsT0FBTyxTQUFTO0FBQ2xELFVBQU07QUFBQSxNQUNKO0FBQUEsTUFDQSxVQUFBRTtBQUFBLE1BQ0E7QUFBQSxJQUNGLElBQUk7QUFDSixVQUFNLE1BQU0sT0FBT0EsVUFBUyxTQUFTLE9BQU8sU0FBU0EsVUFBUyxNQUFNLFNBQVMsUUFBUTtBQUNyRixVQUFNLE9BQU8sUUFBUSxTQUFTO0FBQzlCLFVBQU0sWUFBWSxhQUFhLFNBQVM7QUFDeEMsVUFBTSxhQUFhLFlBQVksU0FBUyxNQUFNO0FBQzlDLFVBQU0sZ0JBQWdCLFlBQVksSUFBSSxJQUFJLElBQUksS0FBSztBQUNuRCxVQUFNLGlCQUFpQixPQUFPLGFBQWEsS0FBSztBQUNoRCxVQUFNLFdBQVcsU0FBUyxTQUFTLEtBQUs7QUFHeEMsUUFBSTtBQUFBLE1BQ0Y7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsSUFBSSxPQUFPLGFBQWEsV0FBVztBQUFBLE1BQ2pDLFVBQVU7QUFBQSxNQUNWLFdBQVc7QUFBQSxNQUNYLGVBQWU7QUFBQSxJQUNqQixJQUFJO0FBQUEsTUFDRixVQUFVLFNBQVMsWUFBWTtBQUFBLE1BQy9CLFdBQVcsU0FBUyxhQUFhO0FBQUEsTUFDakMsZUFBZSxTQUFTO0FBQUEsSUFDMUI7QUFDQSxRQUFJLGFBQWEsT0FBTyxrQkFBa0IsVUFBVTtBQUNsRCxrQkFBWSxjQUFjLFFBQVEsZ0JBQWdCLEtBQUs7QUFBQSxJQUN6RDtBQUNBLFdBQU8sYUFBYTtBQUFBLE1BQ2xCLEdBQUcsWUFBWTtBQUFBLE1BQ2YsR0FBRyxXQUFXO0FBQUEsSUFDaEIsSUFBSTtBQUFBLE1BQ0YsR0FBRyxXQUFXO0FBQUEsTUFDZCxHQUFHLFlBQVk7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFTQSxNQUFNLFNBQVMsU0FBVSxTQUFTO0FBQ2hDLFFBQUksWUFBWSxRQUFRO0FBQ3RCLGdCQUFVO0FBQUEsSUFDWjtBQUNBLFdBQU87QUFBQSxNQUNMLE1BQU07QUFBQSxNQUNOO0FBQUEsTUFDQSxNQUFNLEdBQUcsT0FBTztBQUNkLFlBQUksdUJBQXVCO0FBQzNCLGNBQU07QUFBQSxVQUNKO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDRixJQUFJO0FBQ0osY0FBTSxhQUFhLE1BQU0scUJBQXFCLE9BQU8sT0FBTztBQUk1RCxZQUFJLGdCQUFnQix3QkFBd0IsZUFBZSxXQUFXLE9BQU8sU0FBUyxzQkFBc0IsZUFBZSx3QkFBd0IsZUFBZSxVQUFVLFFBQVEsc0JBQXNCLGlCQUFpQjtBQUN6TixpQkFBTyxDQUFDO0FBQUEsUUFDVjtBQUNBLGVBQU87QUFBQSxVQUNMLEdBQUcsSUFBSSxXQUFXO0FBQUEsVUFDbEIsR0FBRyxJQUFJLFdBQVc7QUFBQSxVQUNsQixNQUFNO0FBQUEsWUFDSixHQUFHO0FBQUEsWUFDSDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBT0EsTUFBTSxRQUFRLFNBQVUsU0FBUztBQUMvQixRQUFJLFlBQVksUUFBUTtBQUN0QixnQkFBVSxDQUFDO0FBQUEsSUFDYjtBQUNBLFdBQU87QUFBQSxNQUNMLE1BQU07QUFBQSxNQUNOO0FBQUEsTUFDQSxNQUFNLEdBQUcsT0FBTztBQUNkLGNBQU07QUFBQSxVQUNKO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBLFVBQUFBO0FBQUEsUUFDRixJQUFJO0FBQ0osY0FBTTtBQUFBLFVBQ0osVUFBVSxnQkFBZ0I7QUFBQSxVQUMxQixXQUFXLGlCQUFpQjtBQUFBLFVBQzVCLFVBQVU7QUFBQSxZQUNSLElBQUksVUFBUTtBQUNWLGtCQUFJO0FBQUEsZ0JBQ0YsR0FBQUM7QUFBQSxnQkFDQSxHQUFBQztBQUFBLGNBQ0YsSUFBSTtBQUNKLHFCQUFPO0FBQUEsZ0JBQ0wsR0FBQUQ7QUFBQSxnQkFDQSxHQUFBQztBQUFBLGNBQ0Y7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFVBQ0EsR0FBRztBQUFBLFFBQ0wsSUFBSSxTQUFTLFNBQVMsS0FBSztBQUMzQixjQUFNLFNBQVM7QUFBQSxVQUNiO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFDQSxjQUFNLFdBQVcsTUFBTUYsVUFBUyxlQUFlLE9BQU8scUJBQXFCO0FBQzNFLGNBQU0sWUFBWSxZQUFZLFNBQVM7QUFDdkMsY0FBTSxXQUFXLGdCQUFnQixTQUFTO0FBQzFDLFlBQUksZ0JBQWdCLE9BQU8sUUFBUTtBQUNuQyxZQUFJLGlCQUFpQixPQUFPLFNBQVM7QUFDckMsY0FBTSxhQUFhLENBQUMsTUFBTSxVQUFVRyxPQUFNLFFBQVEsU0FBUyxTQUFTLE1BQU0sUUFBUSxNQUFNLEdBQUcsT0FBTyxRQUFRLFNBQVMsU0FBUyxNQUFNLFdBQVcsT0FBTyxDQUFDO0FBQ3JKLFlBQUksZUFBZTtBQUNqQiwwQkFBZ0IsV0FBVyxVQUFVLGFBQWE7QUFBQSxRQUNwRDtBQUNBLFlBQUksZ0JBQWdCO0FBQ2xCLDJCQUFpQixXQUFXLFdBQVcsY0FBYztBQUFBLFFBQ3ZEO0FBQ0EsY0FBTSxnQkFBZ0IsUUFBUSxHQUFHO0FBQUEsVUFDL0IsR0FBRztBQUFBLFVBQ0gsQ0FBQyxRQUFRLEdBQUc7QUFBQSxVQUNaLENBQUMsU0FBUyxHQUFHO0FBQUEsUUFDZixDQUFDO0FBQ0QsZUFBTztBQUFBLFVBQ0wsR0FBRztBQUFBLFVBQ0gsTUFBTTtBQUFBLFlBQ0osR0FBRyxjQUFjLElBQUk7QUFBQSxZQUNyQixHQUFHLGNBQWMsSUFBSTtBQUFBLFlBQ3JCLFNBQVM7QUFBQSxjQUNQLENBQUMsUUFBUSxHQUFHO0FBQUEsY0FDWixDQUFDLFNBQVMsR0FBRztBQUFBLFlBQ2Y7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQWtGQSxNQUFNLE9BQU8sU0FBVSxTQUFTO0FBQzlCLFFBQUksWUFBWSxRQUFRO0FBQ3RCLGdCQUFVLENBQUM7QUFBQSxJQUNiO0FBQ0EsV0FBTztBQUFBLE1BQ0wsTUFBTTtBQUFBLE1BQ047QUFBQSxNQUNBLE1BQU0sR0FBRyxPQUFPO0FBQ2QsY0FBTTtBQUFBLFVBQ0o7QUFBQSxVQUNBO0FBQUEsVUFDQSxVQUFBQztBQUFBLFVBQ0E7QUFBQSxRQUNGLElBQUk7QUFDSixjQUFNO0FBQUEsVUFDSixRQUFRLE1BQU07QUFBQSxVQUFDO0FBQUEsVUFDZixHQUFHO0FBQUEsUUFDTCxJQUFJLFNBQVMsU0FBUyxLQUFLO0FBQzNCLGNBQU0sV0FBVyxNQUFNQSxVQUFTLGVBQWUsT0FBTyxxQkFBcUI7QUFDM0UsY0FBTSxPQUFPLFFBQVEsU0FBUztBQUM5QixjQUFNLFlBQVksYUFBYSxTQUFTO0FBQ3hDLGNBQU0sVUFBVSxZQUFZLFNBQVMsTUFBTTtBQUMzQyxjQUFNO0FBQUEsVUFDSjtBQUFBLFVBQ0E7QUFBQSxRQUNGLElBQUksTUFBTTtBQUNWLFlBQUk7QUFDSixZQUFJO0FBQ0osWUFBSSxTQUFTLFNBQVMsU0FBUyxVQUFVO0FBQ3ZDLHVCQUFhO0FBQ2Isc0JBQVksZUFBZ0IsT0FBT0EsVUFBUyxTQUFTLE9BQU8sU0FBU0EsVUFBUyxNQUFNLFNBQVMsUUFBUSxLQUFNLFVBQVUsU0FBUyxTQUFTO0FBQUEsUUFDekksT0FBTztBQUNMLHNCQUFZO0FBQ1osdUJBQWEsY0FBYyxRQUFRLFFBQVE7QUFBQSxRQUM3QztBQUNBLGNBQU0sd0JBQXdCLFNBQVMsU0FBUyxNQUFNLFNBQVM7QUFDL0QsY0FBTSx1QkFBdUIsUUFBUSxTQUFTLE9BQU8sU0FBUztBQUM5RCxjQUFNLDBCQUEwQixJQUFJLFNBQVMsU0FBUyxVQUFVLEdBQUcscUJBQXFCO0FBQ3hGLGNBQU0seUJBQXlCLElBQUksUUFBUSxTQUFTLFNBQVMsR0FBRyxvQkFBb0I7QUFDcEYsY0FBTSxZQUFZLE1BQU0sZUFBZTtBQUN2QyxjQUFNLFVBQVUsQ0FBQztBQUNqQixZQUFJLGtCQUFrQjtBQUN0QixZQUFJLGlCQUFpQjtBQUNyQixZQUFJLGFBQWEsUUFBUSxVQUFVLFFBQVEsR0FBRztBQUM1QywyQkFBaUI7QUFBQSxRQUNuQjtBQUNBLFlBQUksYUFBYSxRQUFRLFVBQVUsUUFBUSxHQUFHO0FBQzVDLDRCQUFrQjtBQUFBLFFBQ3BCO0FBQ0EsWUFBSSxXQUFXLENBQUMsV0FBVztBQUN6QixjQUFJLFNBQVM7QUFDWCw2QkFBaUIsUUFBUSxJQUFJLElBQUksU0FBUyxNQUFNLFNBQVMsS0FBSztBQUFBLFVBQ2hFLE9BQU87QUFDTCw4QkFBa0IsU0FBUyxJQUFJLElBQUksU0FBUyxLQUFLLFNBQVMsTUFBTTtBQUFBLFVBQ2xFO0FBQUEsUUFDRjtBQUNBLGNBQU0sTUFBTTtBQUFBLFVBQ1YsR0FBRztBQUFBLFVBQ0g7QUFBQSxVQUNBO0FBQUEsUUFDRixDQUFDO0FBQ0QsY0FBTSxpQkFBaUIsTUFBTUEsVUFBUyxjQUFjLFNBQVMsUUFBUTtBQUNyRSxZQUFJLFVBQVUsZUFBZSxTQUFTLFdBQVcsZUFBZSxRQUFRO0FBQ3RFLGlCQUFPO0FBQUEsWUFDTCxPQUFPO0FBQUEsY0FDTCxPQUFPO0FBQUEsWUFDVDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0EsZUFBTyxDQUFDO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFBQSxFQUNGOzs7QUMzZ0NBLFdBQVMsWUFBWTtBQUNuQixXQUFPLE9BQU8sV0FBVztBQUFBLEVBQzNCO0FBQ0EsV0FBUyxZQUFZLE1BQU07QUFDekIsUUFBSSxPQUFPLElBQUksR0FBRztBQUNoQixjQUFRLEtBQUssWUFBWSxJQUFJLFlBQVk7QUFBQSxJQUMzQztBQUlBLFdBQU87QUFBQSxFQUNUO0FBQ0EsV0FBUyxVQUFVLE1BQU07QUFDdkIsUUFBSTtBQUNKLFlBQVEsUUFBUSxTQUFTLHNCQUFzQixLQUFLLGtCQUFrQixPQUFPLFNBQVMsb0JBQW9CLGdCQUFnQjtBQUFBLEVBQzVIO0FBQ0EsV0FBUyxtQkFBbUIsTUFBTTtBQUNoQyxRQUFJO0FBQ0osWUFBUSxRQUFRLE9BQU8sSUFBSSxJQUFJLEtBQUssZ0JBQWdCLEtBQUssYUFBYSxPQUFPLGFBQWEsT0FBTyxTQUFTLEtBQUs7QUFBQSxFQUNqSDtBQUNBLFdBQVMsT0FBTyxPQUFPO0FBQ3JCLFFBQUksQ0FBQyxVQUFVLEdBQUc7QUFDaEIsYUFBTztBQUFBLElBQ1Q7QUFDQSxXQUFPLGlCQUFpQixRQUFRLGlCQUFpQixVQUFVLEtBQUssRUFBRTtBQUFBLEVBQ3BFO0FBQ0EsV0FBUyxVQUFVLE9BQU87QUFDeEIsUUFBSSxDQUFDLFVBQVUsR0FBRztBQUNoQixhQUFPO0FBQUEsSUFDVDtBQUNBLFdBQU8saUJBQWlCLFdBQVcsaUJBQWlCLFVBQVUsS0FBSyxFQUFFO0FBQUEsRUFDdkU7QUFDQSxXQUFTLGNBQWMsT0FBTztBQUM1QixRQUFJLENBQUMsVUFBVSxHQUFHO0FBQ2hCLGFBQU87QUFBQSxJQUNUO0FBQ0EsV0FBTyxpQkFBaUIsZUFBZSxpQkFBaUIsVUFBVSxLQUFLLEVBQUU7QUFBQSxFQUMzRTtBQUNBLFdBQVMsYUFBYSxPQUFPO0FBQzNCLFFBQUksQ0FBQyxVQUFVLEtBQUssT0FBTyxlQUFlLGFBQWE7QUFDckQsYUFBTztBQUFBLElBQ1Q7QUFDQSxXQUFPLGlCQUFpQixjQUFjLGlCQUFpQixVQUFVLEtBQUssRUFBRTtBQUFBLEVBQzFFO0FBQ0EsV0FBUyxrQkFBa0JDLFVBQVM7QUFDbEMsVUFBTTtBQUFBLE1BQ0o7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGLElBQUlDLGtCQUFpQkQsUUFBTztBQUM1QixXQUFPLGtDQUFrQyxLQUFLLFdBQVcsWUFBWSxTQUFTLEtBQUssWUFBWSxZQUFZLFlBQVk7QUFBQSxFQUN6SDtBQUNBLFdBQVMsZUFBZUEsVUFBUztBQUMvQixXQUFPLGtCQUFrQixLQUFLLFlBQVlBLFFBQU8sQ0FBQztBQUFBLEVBQ3BEO0FBQ0EsV0FBUyxXQUFXQSxVQUFTO0FBQzNCLFFBQUk7QUFDRixVQUFJQSxTQUFRLFFBQVEsZUFBZSxHQUFHO0FBQ3BDLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRixTQUFTLElBQUk7QUFBQSxJQUViO0FBQ0EsUUFBSTtBQUNGLGFBQU9BLFNBQVEsUUFBUSxRQUFRO0FBQUEsSUFDakMsU0FBUyxJQUFJO0FBQ1gsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0EsTUFBTSxlQUFlO0FBQ3JCLE1BQU0sWUFBWTtBQUNsQixNQUFNLFlBQVksV0FBUyxDQUFDLENBQUMsU0FBUyxVQUFVO0FBQ2hELE1BQUk7QUFDSixXQUFTLGtCQUFrQixjQUFjO0FBQ3ZDLFVBQU0sTUFBTSxVQUFVLFlBQVksSUFBSUMsa0JBQWlCLFlBQVksSUFBSTtBQUl2RSxXQUFPLFVBQVUsSUFBSSxTQUFTLEtBQUssVUFBVSxJQUFJLFNBQVMsS0FBSyxVQUFVLElBQUksS0FBSyxLQUFLLFVBQVUsSUFBSSxNQUFNLEtBQUssVUFBVSxJQUFJLFdBQVcsS0FBSyxDQUFDLFNBQVMsTUFBTSxVQUFVLElBQUksY0FBYyxLQUFLLFVBQVUsSUFBSSxNQUFNLE1BQU0sYUFBYSxLQUFLLElBQUksY0FBYyxFQUFFLEtBQUssVUFBVSxLQUFLLElBQUksV0FBVyxFQUFFO0FBQUEsRUFDdFM7QUFDQSxXQUFTLG1CQUFtQkQsVUFBUztBQUNuQyxRQUFJLGNBQWMsY0FBY0EsUUFBTztBQUN2QyxXQUFPLGNBQWMsV0FBVyxLQUFLLENBQUMsc0JBQXNCLFdBQVcsR0FBRztBQUN4RSxVQUFJLGtCQUFrQixXQUFXLEdBQUc7QUFDbEMsZUFBTztBQUFBLE1BQ1QsV0FBVyxXQUFXLFdBQVcsR0FBRztBQUNsQyxlQUFPO0FBQUEsTUFDVDtBQUNBLG9CQUFjLGNBQWMsV0FBVztBQUFBLElBQ3pDO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxXQUFTLFdBQVc7QUFDbEIsUUFBSSxpQkFBaUIsTUFBTTtBQUN6QixzQkFBZ0IsT0FBTyxRQUFRLGVBQWUsSUFBSSxZQUFZLElBQUksU0FBUywyQkFBMkIsTUFBTTtBQUFBLElBQzlHO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxXQUFTLHNCQUFzQixNQUFNO0FBQ25DLFdBQU8sMEJBQTBCLEtBQUssWUFBWSxJQUFJLENBQUM7QUFBQSxFQUN6RDtBQUNBLFdBQVNDLGtCQUFpQkQsVUFBUztBQUNqQyxXQUFPLFVBQVVBLFFBQU8sRUFBRSxpQkFBaUJBLFFBQU87QUFBQSxFQUNwRDtBQUNBLFdBQVMsY0FBY0EsVUFBUztBQUM5QixRQUFJLFVBQVVBLFFBQU8sR0FBRztBQUN0QixhQUFPO0FBQUEsUUFDTCxZQUFZQSxTQUFRO0FBQUEsUUFDcEIsV0FBV0EsU0FBUTtBQUFBLE1BQ3JCO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxNQUNMLFlBQVlBLFNBQVE7QUFBQSxNQUNwQixXQUFXQSxTQUFRO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBQ0EsV0FBUyxjQUFjLE1BQU07QUFDM0IsUUFBSSxZQUFZLElBQUksTUFBTSxRQUFRO0FBQ2hDLGFBQU87QUFBQSxJQUNUO0FBQ0EsVUFBTTtBQUFBO0FBQUEsTUFFTixLQUFLO0FBQUEsTUFFTCxLQUFLO0FBQUEsTUFFTCxhQUFhLElBQUksS0FBSyxLQUFLO0FBQUEsTUFFM0IsbUJBQW1CLElBQUk7QUFBQTtBQUN2QixXQUFPLGFBQWEsTUFBTSxJQUFJLE9BQU8sT0FBTztBQUFBLEVBQzlDO0FBQ0EsV0FBUywyQkFBMkIsTUFBTTtBQUN4QyxVQUFNLGFBQWEsY0FBYyxJQUFJO0FBQ3JDLFFBQUksc0JBQXNCLFVBQVUsR0FBRztBQUNyQyxjQUFRLEtBQUssaUJBQWlCLE1BQU07QUFBQSxJQUN0QztBQUNBLFFBQUksY0FBYyxVQUFVLEtBQUssa0JBQWtCLFVBQVUsR0FBRztBQUM5RCxhQUFPO0FBQUEsSUFDVDtBQUNBLFdBQU8sMkJBQTJCLFVBQVU7QUFBQSxFQUM5QztBQUNBLFdBQVMscUJBQXFCLE1BQU0sTUFBTSxpQkFBaUI7QUFDekQsUUFBSTtBQUNKLFFBQUksU0FBUyxRQUFRO0FBQ25CLGFBQU8sQ0FBQztBQUFBLElBQ1Y7QUFDQSxRQUFJLG9CQUFvQixRQUFRO0FBQzlCLHdCQUFrQjtBQUFBLElBQ3BCO0FBQ0EsVUFBTSxxQkFBcUIsMkJBQTJCLElBQUk7QUFDMUQsVUFBTSxTQUFTLHlCQUF5Qix1QkFBdUIsS0FBSyxrQkFBa0IsT0FBTyxTQUFTLHFCQUFxQjtBQUMzSCxVQUFNLE1BQU0sVUFBVSxrQkFBa0I7QUFDeEMsUUFBSSxRQUFRO0FBQ1YsWUFBTSxlQUFlLGdCQUFnQixHQUFHO0FBQ3hDLGFBQU8sS0FBSyxPQUFPLEtBQUssSUFBSSxrQkFBa0IsQ0FBQyxHQUFHLGtCQUFrQixrQkFBa0IsSUFBSSxxQkFBcUIsQ0FBQyxHQUFHLGdCQUFnQixrQkFBa0IscUJBQXFCLFlBQVksSUFBSSxDQUFDLENBQUM7QUFBQSxJQUM5TCxPQUFPO0FBQ0wsYUFBTyxLQUFLLE9BQU8sb0JBQW9CLHFCQUFxQixvQkFBb0IsQ0FBQyxHQUFHLGVBQWUsQ0FBQztBQUFBLElBQ3RHO0FBQUEsRUFDRjtBQUNBLFdBQVMsZ0JBQWdCLEtBQUs7QUFDNUIsV0FBTyxJQUFJLFVBQVUsT0FBTyxlQUFlLElBQUksTUFBTSxJQUFJLElBQUksZUFBZTtBQUFBLEVBQzlFOzs7QUM3SkEsV0FBUyxpQkFBaUJFLFVBQVM7QUFDakMsVUFBTSxNQUFNQyxrQkFBbUJELFFBQU87QUFHdEMsUUFBSSxRQUFRLFdBQVcsSUFBSSxLQUFLLEtBQUs7QUFDckMsUUFBSSxTQUFTLFdBQVcsSUFBSSxNQUFNLEtBQUs7QUFDdkMsVUFBTSxZQUFZLGNBQWNBLFFBQU87QUFDdkMsVUFBTSxjQUFjLFlBQVlBLFNBQVEsY0FBYztBQUN0RCxVQUFNLGVBQWUsWUFBWUEsU0FBUSxlQUFlO0FBQ3hELFVBQU0saUJBQWlCLE1BQU0sS0FBSyxNQUFNLGVBQWUsTUFBTSxNQUFNLE1BQU07QUFDekUsUUFBSSxnQkFBZ0I7QUFDbEIsY0FBUTtBQUNSLGVBQVM7QUFBQSxJQUNYO0FBQ0EsV0FBTztBQUFBLE1BQ0w7QUFBQSxNQUNBO0FBQUEsTUFDQSxHQUFHO0FBQUEsSUFDTDtBQUFBLEVBQ0Y7QUFFQSxXQUFTLGNBQWNBLFVBQVM7QUFDOUIsV0FBTyxDQUFDLFVBQVVBLFFBQU8sSUFBSUEsU0FBUSxpQkFBaUJBO0FBQUEsRUFDeEQ7QUFFQSxXQUFTLFNBQVNBLFVBQVM7QUFDekIsVUFBTSxhQUFhLGNBQWNBLFFBQU87QUFDeEMsUUFBSSxDQUFDLGNBQWMsVUFBVSxHQUFHO0FBQzlCLGFBQU8sYUFBYSxDQUFDO0FBQUEsSUFDdkI7QUFDQSxVQUFNLE9BQU8sV0FBVyxzQkFBc0I7QUFDOUMsVUFBTTtBQUFBLE1BQ0o7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsSUFBSSxpQkFBaUIsVUFBVTtBQUMvQixRQUFJLEtBQUssSUFBSSxNQUFNLEtBQUssS0FBSyxJQUFJLEtBQUssU0FBUztBQUMvQyxRQUFJLEtBQUssSUFBSSxNQUFNLEtBQUssTUFBTSxJQUFJLEtBQUssVUFBVTtBQUlqRCxRQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sU0FBUyxDQUFDLEdBQUc7QUFDN0IsVUFBSTtBQUFBLElBQ047QUFDQSxRQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sU0FBUyxDQUFDLEdBQUc7QUFDN0IsVUFBSTtBQUFBLElBQ047QUFDQSxXQUFPO0FBQUEsTUFDTDtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLE1BQU0sWUFBeUIsNkJBQWEsQ0FBQztBQUM3QyxXQUFTLGlCQUFpQkEsVUFBUztBQUNqQyxVQUFNLE1BQU0sVUFBVUEsUUFBTztBQUM3QixRQUFJLENBQUMsU0FBUyxLQUFLLENBQUMsSUFBSSxnQkFBZ0I7QUFDdEMsYUFBTztBQUFBLElBQ1Q7QUFDQSxXQUFPO0FBQUEsTUFDTCxHQUFHLElBQUksZUFBZTtBQUFBLE1BQ3RCLEdBQUcsSUFBSSxlQUFlO0FBQUEsSUFDeEI7QUFBQSxFQUNGO0FBQ0EsV0FBUyx1QkFBdUJBLFVBQVMsU0FBUyxzQkFBc0I7QUFDdEUsUUFBSSxZQUFZLFFBQVE7QUFDdEIsZ0JBQVU7QUFBQSxJQUNaO0FBQ0EsV0FBTyxDQUFDLENBQUMsd0JBQXdCLFdBQVcseUJBQXlCLFVBQVVBLFFBQU87QUFBQSxFQUN4RjtBQUVBLFdBQVMsc0JBQXNCQSxVQUFTLGNBQWMsaUJBQWlCLGNBQWM7QUFDbkYsUUFBSSxpQkFBaUIsUUFBUTtBQUMzQixxQkFBZTtBQUFBLElBQ2pCO0FBQ0EsUUFBSSxvQkFBb0IsUUFBUTtBQUM5Qix3QkFBa0I7QUFBQSxJQUNwQjtBQUNBLFVBQU0sYUFBYUEsU0FBUSxzQkFBc0I7QUFDakQsVUFBTSxhQUFhLGNBQWNBLFFBQU87QUFDeEMsUUFBSSxRQUFRLGFBQWEsQ0FBQztBQUMxQixRQUFJLGNBQWM7QUFDaEIsVUFBSSxjQUFjO0FBQ2hCLFlBQUksVUFBVSxZQUFZLEdBQUc7QUFDM0Isa0JBQVEsU0FBUyxZQUFZO0FBQUEsUUFDL0I7QUFBQSxNQUNGLE9BQU87QUFDTCxnQkFBUSxTQUFTQSxRQUFPO0FBQUEsTUFDMUI7QUFBQSxJQUNGO0FBQ0EsVUFBTSxnQkFBZ0IsdUJBQXVCLFlBQVksaUJBQWlCLFlBQVksSUFBSSxpQkFBaUIsVUFBVSxJQUFJLGFBQWEsQ0FBQztBQUN2SSxRQUFJLEtBQUssV0FBVyxPQUFPLGNBQWMsS0FBSyxNQUFNO0FBQ3BELFFBQUksS0FBSyxXQUFXLE1BQU0sY0FBYyxLQUFLLE1BQU07QUFDbkQsUUFBSSxRQUFRLFdBQVcsUUFBUSxNQUFNO0FBQ3JDLFFBQUksU0FBUyxXQUFXLFNBQVMsTUFBTTtBQUN2QyxRQUFJLGNBQWMsY0FBYztBQUM5QixZQUFNLE1BQU0sVUFBVSxVQUFVO0FBQ2hDLFlBQU0sWUFBWSxVQUFVLFlBQVksSUFBSSxVQUFVLFlBQVksSUFBSTtBQUN0RSxVQUFJLGFBQWE7QUFDakIsVUFBSSxnQkFBZ0IsZ0JBQWdCLFVBQVU7QUFDOUMsYUFBTyxpQkFBaUIsY0FBYyxZQUFZO0FBQ2hELGNBQU0sY0FBYyxTQUFTLGFBQWE7QUFDMUMsY0FBTSxhQUFhLGNBQWMsc0JBQXNCO0FBQ3ZELGNBQU0sTUFBTUMsa0JBQW1CLGFBQWE7QUFDNUMsY0FBTSxPQUFPLFdBQVcsUUFBUSxjQUFjLGFBQWEsV0FBVyxJQUFJLFdBQVcsS0FBSyxZQUFZO0FBQ3RHLGNBQU0sTUFBTSxXQUFXLE9BQU8sY0FBYyxZQUFZLFdBQVcsSUFBSSxVQUFVLEtBQUssWUFBWTtBQUNsRyxhQUFLLFlBQVk7QUFDakIsYUFBSyxZQUFZO0FBQ2pCLGlCQUFTLFlBQVk7QUFDckIsa0JBQVUsWUFBWTtBQUN0QixhQUFLO0FBQ0wsYUFBSztBQUNMLHFCQUFhLFVBQVUsYUFBYTtBQUNwQyx3QkFBZ0IsZ0JBQWdCLFVBQVU7QUFBQSxNQUM1QztBQUFBLElBQ0Y7QUFDQSxXQUFPLGlCQUFpQjtBQUFBLE1BQ3RCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUlBLFdBQVMsb0JBQW9CRCxVQUFTLE1BQU07QUFDMUMsVUFBTSxhQUFhLGNBQWNBLFFBQU8sRUFBRTtBQUMxQyxRQUFJLENBQUMsTUFBTTtBQUNULGFBQU8sc0JBQXNCLG1CQUFtQkEsUUFBTyxDQUFDLEVBQUUsT0FBTztBQUFBLElBQ25FO0FBQ0EsV0FBTyxLQUFLLE9BQU87QUFBQSxFQUNyQjtBQUVBLFdBQVMsY0FBYyxpQkFBaUIsUUFBUTtBQUM5QyxVQUFNLFdBQVcsZ0JBQWdCLHNCQUFzQjtBQUN2RCxVQUFNLElBQUksU0FBUyxPQUFPLE9BQU8sYUFBYSxvQkFBb0IsaUJBQWlCLFFBQVE7QUFDM0YsVUFBTSxJQUFJLFNBQVMsTUFBTSxPQUFPO0FBQ2hDLFdBQU87QUFBQSxNQUNMO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsV0FBUyxzREFBc0QsTUFBTTtBQUNuRSxRQUFJO0FBQUEsTUFDRjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsSUFBSTtBQUNKLFVBQU0sVUFBVSxhQUFhO0FBQzdCLFVBQU0sa0JBQWtCLG1CQUFtQixZQUFZO0FBQ3ZELFVBQU0sV0FBVyxXQUFXLFdBQVcsU0FBUyxRQUFRLElBQUk7QUFDNUQsUUFBSSxpQkFBaUIsbUJBQW1CLFlBQVksU0FBUztBQUMzRCxhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksU0FBUztBQUFBLE1BQ1gsWUFBWTtBQUFBLE1BQ1osV0FBVztBQUFBLElBQ2I7QUFDQSxRQUFJLFFBQVEsYUFBYSxDQUFDO0FBQzFCLFVBQU0sVUFBVSxhQUFhLENBQUM7QUFDOUIsVUFBTSwwQkFBMEIsY0FBYyxZQUFZO0FBQzFELFFBQUksMkJBQTJCLENBQUMsU0FBUztBQUN2QyxVQUFJLFlBQVksWUFBWSxNQUFNLFVBQVUsa0JBQWtCLGVBQWUsR0FBRztBQUM5RSxpQkFBUyxjQUFjLFlBQVk7QUFBQSxNQUNyQztBQUNBLFVBQUkseUJBQXlCO0FBQzNCLGNBQU0sYUFBYSxzQkFBc0IsWUFBWTtBQUNyRCxnQkFBUSxTQUFTLFlBQVk7QUFDN0IsZ0JBQVEsSUFBSSxXQUFXLElBQUksYUFBYTtBQUN4QyxnQkFBUSxJQUFJLFdBQVcsSUFBSSxhQUFhO0FBQUEsTUFDMUM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxhQUFhLG1CQUFtQixDQUFDLDJCQUEyQixDQUFDLFVBQVUsY0FBYyxpQkFBaUIsTUFBTSxJQUFJLGFBQWEsQ0FBQztBQUNwSSxXQUFPO0FBQUEsTUFDTCxPQUFPLEtBQUssUUFBUSxNQUFNO0FBQUEsTUFDMUIsUUFBUSxLQUFLLFNBQVMsTUFBTTtBQUFBLE1BQzVCLEdBQUcsS0FBSyxJQUFJLE1BQU0sSUFBSSxPQUFPLGFBQWEsTUFBTSxJQUFJLFFBQVEsSUFBSSxXQUFXO0FBQUEsTUFDM0UsR0FBRyxLQUFLLElBQUksTUFBTSxJQUFJLE9BQU8sWUFBWSxNQUFNLElBQUksUUFBUSxJQUFJLFdBQVc7QUFBQSxJQUM1RTtBQUFBLEVBQ0Y7QUFFQSxXQUFTLGVBQWVBLFVBQVM7QUFDL0IsV0FBT0EsU0FBUSxpQkFBaUIsTUFBTSxLQUFLQSxTQUFRLGVBQWUsQ0FBQyxJQUFJLENBQUM7QUFBQSxFQUMxRTtBQUlBLFdBQVMsZ0JBQWdCLE1BQU07QUFDN0IsVUFBTSxTQUFTLGNBQWMsSUFBSTtBQUNqQyxVQUFNLE9BQU8sS0FBSyxjQUFjO0FBQ2hDLFVBQU0sUUFBUSxJQUFJLEtBQUssYUFBYSxLQUFLLGFBQWEsS0FBSyxhQUFhLEtBQUssV0FBVztBQUN4RixVQUFNLFNBQVMsSUFBSSxLQUFLLGNBQWMsS0FBSyxjQUFjLEtBQUssY0FBYyxLQUFLLFlBQVk7QUFDN0YsUUFBSSxJQUFJLENBQUMsT0FBTyxhQUFhLG9CQUFvQixJQUFJO0FBQ3JELFVBQU0sSUFBSSxDQUFDLE9BQU87QUFDbEIsUUFBSUMsa0JBQW1CLElBQUksRUFBRSxjQUFjLE9BQU87QUFDaEQsV0FBSyxJQUFJLEtBQUssYUFBYSxLQUFLLFdBQVcsSUFBSTtBQUFBLElBQ2pEO0FBQ0EsV0FBTztBQUFBLE1BQ0w7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUtBLE1BQU0sZ0JBQWdCO0FBQ3RCLFdBQVMsZ0JBQWdCRCxVQUFTLFVBQVUsY0FBYztBQUN4RCxRQUFJLGlCQUFpQixRQUFRO0FBQzNCLHFCQUFlO0FBQUEsSUFDakI7QUFDQSxVQUFNLG1CQUFtQixpQkFBaUI7QUFDMUMsVUFBTSxNQUFNLFVBQVVBLFFBQU87QUFDN0IsVUFBTSxPQUFPLG1CQUFtQkEsUUFBTztBQUN2QyxVQUFNLGlCQUFpQixJQUFJO0FBQzNCLFFBQUksUUFBUSxLQUFLO0FBQ2pCLFFBQUksU0FBUyxLQUFLO0FBQ2xCLFFBQUksSUFBSTtBQUNSLFFBQUksSUFBSTtBQUNSLFFBQUksZ0JBQWdCO0FBSWxCLFlBQU0sNkJBQTZCLENBQUMsU0FBUyxLQUFLLGFBQWE7QUFDL0QsVUFBSSxrQkFBa0I7QUFDcEIsWUFBSSxDQUFDLDRCQUE0QjtBQUMvQixjQUFJLENBQUMsZUFBZTtBQUNwQixjQUFJLENBQUMsZUFBZTtBQUFBLFFBQ3RCO0FBQUEsTUFDRixPQUFPO0FBQ0wsZ0JBQVEsZUFBZTtBQUN2QixpQkFBUyxlQUFlO0FBQ3hCLFlBQUksNEJBQTRCO0FBQzlCLGNBQUksZUFBZTtBQUNuQixjQUFJLGVBQWU7QUFBQSxRQUNyQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsVUFBTSxtQkFBbUIsb0JBQW9CLElBQUk7QUFRakQsUUFBSSxvQkFBb0IsR0FBRztBQUN6QixZQUFNLE1BQU0sS0FBSztBQUNqQixZQUFNLE9BQU8sSUFBSTtBQUNqQixZQUFNLGFBQWEsaUJBQWlCLElBQUk7QUFDeEMsWUFBTSxtQkFBbUIsSUFBSSxlQUFlLGVBQWUsV0FBVyxXQUFXLFVBQVUsSUFBSSxXQUFXLFdBQVcsV0FBVyxLQUFLLElBQUk7QUFDekksWUFBTSxnQkFBZ0IsS0FBSyxJQUFJLEtBQUssY0FBYyxLQUFLLGNBQWMsZ0JBQWdCO0FBQ3JGLFlBQU0sU0FBUyxpQkFBaUIsSUFBSSxFQUFFLG9CQUFvQixzQkFBc0IsZ0JBQWdCLElBQUk7QUFDcEcsVUFBSSxVQUFVLGVBQWU7QUFDM0IsaUJBQVM7QUFBQSxNQUNYO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxNQUNMO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFHQSxXQUFTLDJCQUEyQkEsVUFBUyxVQUFVO0FBQ3JELFVBQU0sYUFBYSxzQkFBc0JBLFVBQVMsTUFBTSxhQUFhLE9BQU87QUFDNUUsVUFBTSxNQUFNLFdBQVcsTUFBTUEsU0FBUTtBQUNyQyxVQUFNLE9BQU8sV0FBVyxPQUFPQSxTQUFRO0FBQ3ZDLFVBQU0sUUFBUSxTQUFTQSxRQUFPO0FBQzlCLFVBQU0sUUFBUUEsU0FBUSxjQUFjLE1BQU07QUFDMUMsVUFBTSxTQUFTQSxTQUFRLGVBQWUsTUFBTTtBQUM1QyxVQUFNLElBQUksT0FBTyxNQUFNO0FBQ3ZCLFVBQU0sSUFBSSxNQUFNLE1BQU07QUFDdEIsV0FBTztBQUFBLE1BQ0w7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFdBQVMsa0NBQWtDQSxVQUFTLGtCQUFrQixVQUFVO0FBQzlFLFFBQUk7QUFDSixRQUFJLHFCQUFxQixjQUFjLHFCQUFxQixrQkFBa0I7QUFDNUUsYUFBTyxnQkFBZ0JBLFVBQVMsVUFBVSxnQkFBZ0I7QUFBQSxJQUM1RCxXQUFXLHFCQUFxQixZQUFZO0FBQzFDLGFBQU8sZ0JBQWdCLG1CQUFtQkEsUUFBTyxDQUFDO0FBQUEsSUFDcEQsV0FBVyxVQUFVLGdCQUFnQixHQUFHO0FBQ3RDLGFBQU8sMkJBQTJCLGtCQUFrQixRQUFRO0FBQUEsSUFDOUQsT0FBTztBQUNMLFlBQU0sZ0JBQWdCLGlCQUFpQkEsUUFBTztBQUM5QyxhQUFPO0FBQUEsUUFDTCxHQUFHLGlCQUFpQixJQUFJLGNBQWM7QUFBQSxRQUN0QyxHQUFHLGlCQUFpQixJQUFJLGNBQWM7QUFBQSxRQUN0QyxPQUFPLGlCQUFpQjtBQUFBLFFBQ3hCLFFBQVEsaUJBQWlCO0FBQUEsTUFDM0I7QUFBQSxJQUNGO0FBQ0EsV0FBTyxpQkFBaUIsSUFBSTtBQUFBLEVBQzlCO0FBS0EsV0FBUyw0QkFBNEJBLFVBQVMsT0FBTztBQUNuRCxVQUFNLGVBQWUsTUFBTSxJQUFJQSxRQUFPO0FBQ3RDLFFBQUksY0FBYztBQUNoQixhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksU0FBUyxxQkFBcUJBLFVBQVMsQ0FBQyxHQUFHLEtBQUssRUFBRSxPQUFPLFFBQU0sVUFBVSxFQUFFLEtBQUssWUFBWSxFQUFFLE1BQU0sTUFBTTtBQUM5RyxRQUFJLHdCQUF3QjtBQUM1QixVQUFNLGlCQUFpQkMsa0JBQW1CRCxRQUFPLEVBQUUsYUFBYTtBQUNoRSxRQUFJLGNBQWMsaUJBQWlCLGNBQWNBLFFBQU8sSUFBSUE7QUFHNUQsV0FBTyxVQUFVLFdBQVcsS0FBSyxDQUFDLHNCQUFzQixXQUFXLEdBQUc7QUFDcEUsWUFBTSxnQkFBZ0JDLGtCQUFtQixXQUFXO0FBQ3BELFlBQU0sMEJBQTBCLGtCQUFrQixXQUFXO0FBRzdELFlBQU0sZUFBZSx3QkFBd0Isc0JBQXNCLFdBQVcsaUJBQWlCLFVBQVU7QUFLekcsWUFBTSx3QkFBd0IsQ0FBQyw0QkFBNEIsaUJBQWlCLFdBQVcsaUJBQWlCLGNBQWMsY0FBYyxhQUFhO0FBQ2pKLFVBQUksdUJBQXVCO0FBRXpCLGlCQUFTLE9BQU8sT0FBTyxjQUFZLGFBQWEsV0FBVztBQUFBLE1BQzdELE9BQU87QUFFTCxnQ0FBd0I7QUFBQSxNQUMxQjtBQUNBLG9CQUFjLGNBQWMsV0FBVztBQUFBLElBQ3pDO0FBQ0EsVUFBTSxJQUFJRCxVQUFTLE1BQU07QUFDekIsV0FBTztBQUFBLEVBQ1Q7QUFJQSxXQUFTLGdCQUFnQixNQUFNO0FBQzdCLFFBQUk7QUFBQSxNQUNGLFNBQUFBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixJQUFJO0FBQ0osVUFBTSwyQkFBMkIsYUFBYSxzQkFBc0IsV0FBV0EsUUFBTyxJQUFJLENBQUMsSUFBSSw0QkFBNEJBLFVBQVMsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFLE9BQU8sUUFBUTtBQUNqSyxVQUFNLG9CQUFvQixDQUFDLEdBQUcsMEJBQTBCLFlBQVk7QUFDcEUsVUFBTSxZQUFZLGtDQUFrQ0EsVUFBUyxrQkFBa0IsQ0FBQyxHQUFHLFFBQVE7QUFDM0YsUUFBSSxNQUFNLFVBQVU7QUFDcEIsUUFBSSxRQUFRLFVBQVU7QUFDdEIsUUFBSSxTQUFTLFVBQVU7QUFDdkIsUUFBSSxPQUFPLFVBQVU7QUFDckIsYUFBUyxJQUFJLEdBQUcsSUFBSSxrQkFBa0IsUUFBUSxLQUFLO0FBQ2pELFlBQU0sT0FBTyxrQ0FBa0NBLFVBQVMsa0JBQWtCLENBQUMsR0FBRyxRQUFRO0FBQ3RGLFlBQU0sSUFBSSxLQUFLLEtBQUssR0FBRztBQUN2QixjQUFRLElBQUksS0FBSyxPQUFPLEtBQUs7QUFDN0IsZUFBUyxJQUFJLEtBQUssUUFBUSxNQUFNO0FBQ2hDLGFBQU8sSUFBSSxLQUFLLE1BQU0sSUFBSTtBQUFBLElBQzVCO0FBQ0EsV0FBTztBQUFBLE1BQ0wsT0FBTyxRQUFRO0FBQUEsTUFDZixRQUFRLFNBQVM7QUFBQSxNQUNqQixHQUFHO0FBQUEsTUFDSCxHQUFHO0FBQUEsSUFDTDtBQUFBLEVBQ0Y7QUFFQSxXQUFTLGNBQWNBLFVBQVM7QUFDOUIsVUFBTTtBQUFBLE1BQ0o7QUFBQSxNQUNBO0FBQUEsSUFDRixJQUFJLGlCQUFpQkEsUUFBTztBQUM1QixXQUFPO0FBQUEsTUFDTDtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFdBQVMsOEJBQThCQSxVQUFTLGNBQWMsVUFBVTtBQUN0RSxVQUFNLDBCQUEwQixjQUFjLFlBQVk7QUFDMUQsVUFBTSxrQkFBa0IsbUJBQW1CLFlBQVk7QUFDdkQsVUFBTSxVQUFVLGFBQWE7QUFDN0IsVUFBTSxPQUFPLHNCQUFzQkEsVUFBUyxNQUFNLFNBQVMsWUFBWTtBQUN2RSxRQUFJLFNBQVM7QUFBQSxNQUNYLFlBQVk7QUFBQSxNQUNaLFdBQVc7QUFBQSxJQUNiO0FBQ0EsVUFBTSxVQUFVLGFBQWEsQ0FBQztBQUM5QixRQUFJLDJCQUEyQixDQUFDLFNBQVM7QUFDdkMsVUFBSSxZQUFZLFlBQVksTUFBTSxVQUFVLGtCQUFrQixlQUFlLEdBQUc7QUFDOUUsaUJBQVMsY0FBYyxZQUFZO0FBQUEsTUFDckM7QUFDQSxVQUFJLHlCQUF5QjtBQUMzQixjQUFNLGFBQWEsc0JBQXNCLGNBQWMsTUFBTSxTQUFTLFlBQVk7QUFDbEYsZ0JBQVEsSUFBSSxXQUFXLElBQUksYUFBYTtBQUN4QyxnQkFBUSxJQUFJLFdBQVcsSUFBSSxhQUFhO0FBQUEsTUFDMUM7QUFBQSxJQUNGO0FBSUEsUUFBSSxDQUFDLDJCQUEyQixpQkFBaUI7QUFDL0MsY0FBUSxJQUFJLG9CQUFvQixlQUFlO0FBQUEsSUFDakQ7QUFDQSxVQUFNLGFBQWEsbUJBQW1CLENBQUMsMkJBQTJCLENBQUMsVUFBVSxjQUFjLGlCQUFpQixNQUFNLElBQUksYUFBYSxDQUFDO0FBQ3BJLFVBQU0sSUFBSSxLQUFLLE9BQU8sT0FBTyxhQUFhLFFBQVEsSUFBSSxXQUFXO0FBQ2pFLFVBQU0sSUFBSSxLQUFLLE1BQU0sT0FBTyxZQUFZLFFBQVEsSUFBSSxXQUFXO0FBQy9ELFdBQU87QUFBQSxNQUNMO0FBQUEsTUFDQTtBQUFBLE1BQ0EsT0FBTyxLQUFLO0FBQUEsTUFDWixRQUFRLEtBQUs7QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUVBLFdBQVMsbUJBQW1CQSxVQUFTO0FBQ25DLFdBQU9DLGtCQUFtQkQsUUFBTyxFQUFFLGFBQWE7QUFBQSxFQUNsRDtBQUVBLFdBQVMsb0JBQW9CQSxVQUFTLFVBQVU7QUFDOUMsUUFBSSxDQUFDLGNBQWNBLFFBQU8sS0FBS0Msa0JBQW1CRCxRQUFPLEVBQUUsYUFBYSxTQUFTO0FBQy9FLGFBQU87QUFBQSxJQUNUO0FBQ0EsUUFBSSxVQUFVO0FBQ1osYUFBTyxTQUFTQSxRQUFPO0FBQUEsSUFDekI7QUFDQSxRQUFJLGtCQUFrQkEsU0FBUTtBQU05QixRQUFJLG1CQUFtQkEsUUFBTyxNQUFNLGlCQUFpQjtBQUNuRCx3QkFBa0IsZ0JBQWdCLGNBQWM7QUFBQSxJQUNsRDtBQUNBLFdBQU87QUFBQSxFQUNUO0FBSUEsV0FBUyxnQkFBZ0JBLFVBQVMsVUFBVTtBQUMxQyxVQUFNLE1BQU0sVUFBVUEsUUFBTztBQUM3QixRQUFJLFdBQVdBLFFBQU8sR0FBRztBQUN2QixhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksQ0FBQyxjQUFjQSxRQUFPLEdBQUc7QUFDM0IsVUFBSSxrQkFBa0IsY0FBY0EsUUFBTztBQUMzQyxhQUFPLG1CQUFtQixDQUFDLHNCQUFzQixlQUFlLEdBQUc7QUFDakUsWUFBSSxVQUFVLGVBQWUsS0FBSyxDQUFDLG1CQUFtQixlQUFlLEdBQUc7QUFDdEUsaUJBQU87QUFBQSxRQUNUO0FBQ0EsMEJBQWtCLGNBQWMsZUFBZTtBQUFBLE1BQ2pEO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJLGVBQWUsb0JBQW9CQSxVQUFTLFFBQVE7QUFDeEQsV0FBTyxnQkFBZ0IsZUFBZSxZQUFZLEtBQUssbUJBQW1CLFlBQVksR0FBRztBQUN2RixxQkFBZSxvQkFBb0IsY0FBYyxRQUFRO0FBQUEsSUFDM0Q7QUFDQSxRQUFJLGdCQUFnQixzQkFBc0IsWUFBWSxLQUFLLG1CQUFtQixZQUFZLEtBQUssQ0FBQyxrQkFBa0IsWUFBWSxHQUFHO0FBQy9ILGFBQU87QUFBQSxJQUNUO0FBQ0EsV0FBTyxnQkFBZ0IsbUJBQW1CQSxRQUFPLEtBQUs7QUFBQSxFQUN4RDtBQUVBLE1BQU0sa0JBQWtCLGVBQWdCLE1BQU07QUFDNUMsVUFBTSxvQkFBb0IsS0FBSyxtQkFBbUI7QUFDbEQsVUFBTSxrQkFBa0IsS0FBSztBQUM3QixVQUFNLHFCQUFxQixNQUFNLGdCQUFnQixLQUFLLFFBQVE7QUFDOUQsV0FBTztBQUFBLE1BQ0wsV0FBVyw4QkFBOEIsS0FBSyxXQUFXLE1BQU0sa0JBQWtCLEtBQUssUUFBUSxHQUFHLEtBQUssUUFBUTtBQUFBLE1BQzlHLFVBQVU7QUFBQSxRQUNSLEdBQUc7QUFBQSxRQUNILEdBQUc7QUFBQSxRQUNILE9BQU8sbUJBQW1CO0FBQUEsUUFDMUIsUUFBUSxtQkFBbUI7QUFBQSxNQUM3QjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsV0FBUyxNQUFNQSxVQUFTO0FBQ3RCLFdBQU9DLGtCQUFtQkQsUUFBTyxFQUFFLGNBQWM7QUFBQSxFQUNuRDtBQUVBLE1BQU0sV0FBVztBQUFBLElBQ2Y7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBRUEsV0FBUyxjQUFjLEdBQUcsR0FBRztBQUMzQixXQUFPLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFO0FBQUEsRUFDN0U7QUFHQSxXQUFTLFlBQVlBLFVBQVMsUUFBUSxnQkFBZ0I7QUFDcEQsUUFBSSxLQUFLO0FBQ1QsUUFBSTtBQUNKLFVBQU0sT0FBTyxtQkFBbUJBLFFBQU87QUFDdkMsYUFBUyxVQUFVO0FBQ2pCLFVBQUk7QUFDSixtQkFBYSxTQUFTO0FBQ3RCLE9BQUMsTUFBTSxPQUFPLFFBQVEsSUFBSSxXQUFXO0FBQ3JDLFdBQUs7QUFBQSxJQUNQO0FBQ0EsYUFBUyxRQUFRLE1BQU0sV0FBVztBQUNoQyxVQUFJLFNBQVMsUUFBUTtBQUNuQixlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksY0FBYyxRQUFRO0FBQ3hCLG9CQUFZO0FBQUEsTUFDZDtBQUNBLGNBQVE7QUFDUixZQUFNLDJCQUEyQkEsU0FBUSxzQkFBc0I7QUFDL0QsWUFBTTtBQUFBLFFBQ0o7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGLElBQUk7QUFDSixVQUFJLENBQUMsTUFBTTtBQUNULGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRO0FBQ3JCO0FBQUEsTUFDRjtBQUNBLFlBQU0sV0FBVyxNQUFNLEdBQUc7QUFDMUIsWUFBTSxhQUFhLE1BQU0sS0FBSyxlQUFlLE9BQU8sTUFBTTtBQUMxRCxZQUFNLGNBQWMsTUFBTSxLQUFLLGdCQUFnQixNQUFNLE9BQU87QUFDNUQsWUFBTSxZQUFZLE1BQU0sSUFBSTtBQUM1QixZQUFNLGFBQWEsQ0FBQyxXQUFXLFFBQVEsQ0FBQyxhQUFhLFFBQVEsQ0FBQyxjQUFjLFFBQVEsQ0FBQyxZQUFZO0FBQ2pHLFlBQU0sVUFBVTtBQUFBLFFBQ2Q7QUFBQSxRQUNBLFdBQVcsSUFBSSxHQUFHLElBQUksR0FBRyxTQUFTLENBQUMsS0FBSztBQUFBLE1BQzFDO0FBQ0EsVUFBSSxnQkFBZ0I7QUFDcEIsZUFBUyxjQUFjLFNBQVM7QUFDOUIsY0FBTSxRQUFRLFFBQVEsQ0FBQyxFQUFFO0FBT3pCLFlBQUksQ0FBQyxjQUFjLDBCQUEwQkEsU0FBUSxzQkFBc0IsQ0FBQyxHQUFHO0FBQzdFLGlCQUFPLFFBQVE7QUFBQSxRQUNqQjtBQUNBLFlBQUksVUFBVSxXQUFXO0FBQ3ZCLGNBQUksQ0FBQyxlQUFlO0FBQ2xCLG1CQUFPLFFBQVE7QUFBQSxVQUNqQjtBQUNBLGNBQUksQ0FBQyxPQUFPO0FBR1Ysd0JBQVksV0FBVyxNQUFNO0FBQzNCLHNCQUFRLE9BQU8sSUFBSTtBQUFBLFlBQ3JCLEdBQUcsR0FBSTtBQUFBLFVBQ1QsT0FBTztBQUNMLG9CQUFRLE9BQU8sS0FBSztBQUFBLFVBQ3RCO0FBQUEsUUFDRjtBQUNBLHdCQUFnQjtBQUFBLE1BQ2xCO0FBSUEsVUFBSTtBQUNGLGFBQUssSUFBSSxxQkFBcUIsZUFBZTtBQUFBLFVBQzNDLEdBQUc7QUFBQTtBQUFBLFVBRUgsTUFBTSxLQUFLO0FBQUEsUUFDYixDQUFDO0FBQUEsTUFDSCxTQUFTLElBQUk7QUFDWCxhQUFLLElBQUkscUJBQXFCLGVBQWUsT0FBTztBQUFBLE1BQ3REO0FBQ0EsU0FBRyxRQUFRQSxRQUFPO0FBQUEsSUFDcEI7QUFDQSxVQUFNLE1BQU0sVUFBVUEsUUFBTztBQUs3QixVQUFNLGVBQWUsTUFBTSxRQUFRLGNBQWM7QUFDakQsUUFBSSxpQkFBaUIsVUFBVSxZQUFZO0FBQzNDLFlBQVEsSUFBSTtBQUNaLFdBQU8sTUFBTTtBQUNYLFVBQUksb0JBQW9CLFVBQVUsWUFBWTtBQUM5QyxjQUFRO0FBQUEsSUFDVjtBQUFBLEVBQ0Y7QUFVQSxXQUFTLFdBQVcsV0FBV0UsV0FBVSxRQUFRLFNBQVM7QUFDeEQsUUFBSSxZQUFZLFFBQVE7QUFDdEIsZ0JBQVUsQ0FBQztBQUFBLElBQ2I7QUFDQSxVQUFNO0FBQUEsTUFDSixpQkFBaUI7QUFBQSxNQUNqQixpQkFBaUI7QUFBQSxNQUNqQixnQkFBZ0IsT0FBTyxtQkFBbUI7QUFBQSxNQUMxQyxjQUFjLE9BQU8seUJBQXlCO0FBQUEsTUFDOUMsaUJBQWlCO0FBQUEsSUFDbkIsSUFBSTtBQUNKLFVBQU0sY0FBYyxjQUFjLFNBQVM7QUFDM0MsVUFBTSxZQUFZLGtCQUFrQixpQkFBaUIsQ0FBQyxHQUFJLGNBQWMscUJBQXFCLFdBQVcsSUFBSSxDQUFDLEdBQUksR0FBSUEsWUFBVyxxQkFBcUJBLFNBQVEsSUFBSSxDQUFDLENBQUUsSUFBSSxDQUFDO0FBQ3pLLGNBQVUsUUFBUSxjQUFZO0FBQzVCLHdCQUFrQixTQUFTLGlCQUFpQixVQUFVLE1BQU07QUFDNUQsd0JBQWtCLFNBQVMsaUJBQWlCLFVBQVUsTUFBTTtBQUFBLElBQzlELENBQUM7QUFDRCxVQUFNLFlBQVksZUFBZSxjQUFjLFlBQVksYUFBYSxRQUFRLGNBQWMsSUFBSTtBQUNsRyxRQUFJLGlCQUFpQjtBQUNyQixRQUFJLGlCQUFpQjtBQUNyQixRQUFJLGVBQWU7QUFDakIsdUJBQWlCLElBQUksZUFBZSxVQUFRO0FBQzFDLFlBQUksQ0FBQyxVQUFVLElBQUk7QUFDbkIsWUFBSSxjQUFjLFdBQVcsV0FBVyxlQUFlLGtCQUFrQkEsV0FBVTtBQUdqRix5QkFBZSxVQUFVQSxTQUFRO0FBQ2pDLCtCQUFxQixjQUFjO0FBQ25DLDJCQUFpQixzQkFBc0IsTUFBTTtBQUMzQyxnQkFBSTtBQUNKLGFBQUMsa0JBQWtCLG1CQUFtQixRQUFRLGdCQUFnQixRQUFRQSxTQUFRO0FBQUEsVUFDaEYsQ0FBQztBQUFBLFFBQ0g7QUFDQSxlQUFPO0FBQUEsTUFDVCxDQUFDO0FBQ0QsVUFBSSxlQUFlLENBQUMsZ0JBQWdCO0FBQ2xDLHVCQUFlLFFBQVEsV0FBVztBQUFBLE1BQ3BDO0FBQ0EsVUFBSUEsV0FBVTtBQUNaLHVCQUFlLFFBQVFBLFNBQVE7QUFBQSxNQUNqQztBQUFBLElBQ0Y7QUFDQSxRQUFJO0FBQ0osUUFBSSxjQUFjLGlCQUFpQixzQkFBc0IsU0FBUyxJQUFJO0FBQ3RFLFFBQUksZ0JBQWdCO0FBQ2xCLGdCQUFVO0FBQUEsSUFDWjtBQUNBLGFBQVMsWUFBWTtBQUNuQixZQUFNLGNBQWMsc0JBQXNCLFNBQVM7QUFDbkQsVUFBSSxlQUFlLENBQUMsY0FBYyxhQUFhLFdBQVcsR0FBRztBQUMzRCxlQUFPO0FBQUEsTUFDVDtBQUNBLG9CQUFjO0FBQ2QsZ0JBQVUsc0JBQXNCLFNBQVM7QUFBQSxJQUMzQztBQUNBLFdBQU87QUFDUCxXQUFPLE1BQU07QUFDWCxVQUFJO0FBQ0osZ0JBQVUsUUFBUSxjQUFZO0FBQzVCLDBCQUFrQixTQUFTLG9CQUFvQixVQUFVLE1BQU07QUFDL0QsMEJBQWtCLFNBQVMsb0JBQW9CLFVBQVUsTUFBTTtBQUFBLE1BQ2pFLENBQUM7QUFDRCxtQkFBYSxRQUFRLFVBQVU7QUFDL0IsT0FBQyxtQkFBbUIsbUJBQW1CLFFBQVEsaUJBQWlCLFdBQVc7QUFDM0UsdUJBQWlCO0FBQ2pCLFVBQUksZ0JBQWdCO0FBQ2xCLDZCQUFxQixPQUFPO0FBQUEsTUFDOUI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQW1CQSxNQUFNQyxVQUFTO0FBZWYsTUFBTUMsU0FBUTtBQVFkLE1BQU1DLFFBQU87QUFRYixNQUFNQyxRQUFPO0FBZ0NiLE1BQU1DLG1CQUFrQixDQUFDLFdBQVdDLFdBQVUsWUFBWTtBQUl4RCxVQUFNLFFBQVEsb0JBQUksSUFBSTtBQUN0QixVQUFNLGdCQUFnQixXQUFXLE9BQU8sVUFBVSxDQUFDO0FBQ25ELFVBQU0sb0JBQW9CO0FBQUEsTUFDeEIsR0FBRztBQUFBLE1BQ0gsR0FBRyxjQUFjO0FBQUEsTUFDakIsSUFBSTtBQUFBLElBQ047QUFDQSxXQUFPLGdCQUFrQixXQUFXQSxXQUFVO0FBQUEsTUFDNUMsR0FBRztBQUFBLE1BQ0gsVUFBVTtBQUFBLElBQ1osQ0FBQztBQUFBLEVBQ0g7OztBQ3R2QkEsV0FBUyxZQUFZQyxTQUEyQztBQUM5RCxXQUFPQSxRQUFPLFVBQVUsV0FBV0EsUUFBTyxPQUFPLEdBQUdBLFFBQU8sSUFBSSxJQUFJQSxRQUFPLEtBQUs7QUFBQSxFQUNqRjtBQUVBLFdBQVMsY0FBYyxXQUdyQjtBQUNBLFVBQU0sQ0FBQyxNQUFNLEtBQUssSUFBSSxVQUFVLE1BQU0sR0FBRztBQUN6QyxXQUFPLEVBQUUsTUFBTSxPQUFPLFNBQVMsU0FBUztBQUFBLEVBQzFDO0FBRUEsV0FBU0MsV0FBVSxPQUFzQztBQUN2RCxXQUFPLE9BQU8sZ0JBQWdCLGVBQWUsaUJBQWlCO0FBQUEsRUFDaEU7QUFXQSxXQUFTLG9CQUFvQkMsU0FBcUI7QUFDaEQsV0FBTztBQUFBLE1BQ0wsd0JBQWlDO0FBQy9CLGNBQU0sT0FBT0EsUUFBTyxzQkFBc0I7QUFDMUMsY0FBTUMsU0FBUSxxQkFBcUJELE9BQU07QUFDekMsZUFBTztBQUFBLFVBQ0wsR0FBRyxLQUFLLElBQUlDLE9BQU07QUFBQSxVQUNsQixHQUFHLEtBQUssSUFBSUEsT0FBTTtBQUFBLFVBQ2xCLE1BQU0sS0FBSyxPQUFPQSxPQUFNO0FBQUEsVUFDeEIsS0FBSyxLQUFLLE1BQU1BLE9BQU07QUFBQSxVQUN0QixPQUFPLEtBQUssUUFBUUEsT0FBTTtBQUFBLFVBQzFCLFFBQVEsS0FBSyxTQUFTQSxPQUFNO0FBQUEsVUFDNUIsT0FBTyxLQUFLO0FBQUEsVUFDWixRQUFRLEtBQUs7QUFBQSxVQUNiLFFBQVEsT0FBTyxDQUFDO0FBQUEsUUFDbEI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFPQSxXQUFTLHFCQUFxQkQsU0FBK0M7QUFDM0UsUUFBSSxJQUFJO0FBQ1IsUUFBSSxJQUFJO0FBQ1IsUUFBSSxPQUFPLHFCQUFxQixXQUFZLFFBQU8sRUFBRSxHQUFHLEVBQUU7QUFDMUQsVUFBTSxRQUFRLGlCQUFpQkEsT0FBTTtBQUNyQyxVQUFNLFlBQVksTUFBTTtBQUN4QixRQUFJLGFBQWEsY0FBYyxVQUFVLE9BQU8sc0JBQXNCLGFBQWE7QUFDakYsWUFBTSxTQUFTLElBQUksa0JBQWtCLFNBQVM7QUFDOUMsV0FBSyxPQUFPO0FBQ1osV0FBSyxPQUFPO0FBQUEsSUFDZDtBQUNBLFVBQU0sWUFBWSxNQUFNO0FBQ3hCLFFBQUksYUFBYSxjQUFjLFFBQVE7QUFDckMsWUFBTSxDQUFDLElBQUksRUFBRSxJQUFJLFVBQVUsS0FBSyxFQUFFLE1BQU0sS0FBSztBQUM3QyxXQUFLLGNBQWMsSUFBSSxVQUFVQSxTQUFRLEdBQUcsQ0FBQztBQUM3QyxXQUFLLGNBQWMsTUFBTSxPQUFPLFVBQVVBLFNBQVEsR0FBRyxDQUFDO0FBQUEsSUFDeEQ7QUFDQSxXQUFPLEVBQUUsR0FBRyxFQUFFO0FBQUEsRUFDaEI7QUFFQSxXQUFTLFVBQVVBLFNBQXFCLE1BQXlCO0FBQy9ELFVBQU0sT0FBT0EsUUFBTyxzQkFBc0I7QUFDMUMsV0FBTyxTQUFTLE1BQU0sS0FBSyxRQUFRLEtBQUs7QUFBQSxFQUMxQztBQUVBLFdBQVMsY0FBYyxPQUEyQixPQUF1QjtBQUN2RSxRQUFJLENBQUMsTUFBTyxRQUFPO0FBQ25CLFVBQU0sT0FBTyxNQUFNLEtBQUs7QUFDeEIsUUFBSSxDQUFDLFFBQVEsU0FBUyxPQUFRLFFBQU87QUFDckMsUUFBSSxLQUFLLFNBQVMsR0FBRyxHQUFHO0FBQ3RCLFlBQU0sVUFBVSxPQUFPLFdBQVcsSUFBSTtBQUN0QyxhQUFPLE9BQU8sU0FBUyxPQUFPLElBQUssVUFBVSxNQUFPLFFBQVE7QUFBQSxJQUM5RDtBQUNBLFVBQU0sU0FBUyxPQUFPLFdBQVcsSUFBSTtBQUNyQyxXQUFPLE9BQU8sU0FBUyxNQUFNLElBQUksU0FBUztBQUFBLEVBQzVDO0FBRUEsV0FBUyxrQkFBa0JBLFNBQXFCRixTQUFnQztBQUM5RSxXQUFPQSxRQUFPLDZCQUE2QixPQUFPLG9CQUFvQkUsT0FBTSxJQUFJQTtBQUFBLEVBQ2xGO0FBRUEsV0FBUyxjQUNQRixTQUNBLFdBQ0EsV0FDYztBQUNkLFVBQU0sYUFBMkI7QUFBQSxNQUMvQkksUUFBTyxFQUFFLFVBQVVKLFFBQU8sWUFBWSxXQUFXQSxRQUFPLFlBQVksQ0FBQztBQUFBLElBQ3ZFO0FBQ0EsVUFBTSxXQUFXQSxRQUFPLHNCQUFzQixhQUFhLENBQUMsSUFBSTtBQUNoRSxRQUFJQSxRQUFPLGlCQUFpQjtBQUMxQixpQkFBVztBQUFBLFFBQ1RLLE1BQUssRUFBRSxVQUFVLGNBQWMsWUFBWSxTQUFTTCxRQUFPLGlCQUFpQixDQUFDO0FBQUEsUUFDN0VHLE9BQU0sRUFBRSxVQUFVLGNBQWMsWUFBWSxTQUFTSCxRQUFPLGlCQUFpQixDQUFDO0FBQUEsTUFDaEY7QUFBQSxJQUNGO0FBQ0EsZUFBVztBQUFBLE1BQ1RNLE1BQUs7QUFBQSxRQUNIO0FBQUEsUUFDQSxjQUFjO0FBQUEsUUFDZCxTQUFTTixRQUFPO0FBQUEsUUFDaEIsTUFBTSxFQUFFLGdCQUFnQixpQkFBaUIsT0FBTyxTQUFTLEdBQUc7QUFDMUQsY0FBSSxDQUFDLFVBQVUsRUFBRztBQUNsQixzQkFBWSxnQkFBZ0IsZUFBZTtBQUMzQyxjQUFJLENBQUMsVUFBVSxFQUFHO0FBQ2xCLGdCQUFNLFFBQVEsU0FBUyxTQUFTO0FBQ2hDLHFCQUFXLENBQUMsTUFBTSxLQUFLLEtBQUs7QUFBQSxZQUMxQixDQUFDLDJCQUEyQixHQUFHLE1BQU0sVUFBVSxLQUFLLElBQUk7QUFBQSxZQUN4RCxDQUFDLDRCQUE0QixHQUFHLE1BQU0sVUFBVSxNQUFNLElBQUk7QUFBQSxZQUMxRCxDQUFDLDhCQUE4QixHQUFHLGNBQWMsSUFBSTtBQUFBLFlBQ3BELENBQUMsK0JBQStCLEdBQUcsZUFBZSxJQUFJO0FBQUEsVUFDeEQsR0FBRztBQUNELGdCQUFJLENBQUMsVUFBVSxFQUFHO0FBQ2xCLGtCQUFNLFlBQVksTUFBTSxLQUFLO0FBQUEsVUFDL0I7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUNBLFdBQU87QUFBQSxFQUNUO0FBR0EsV0FBUyxvQkFBb0IsWUFBd0MsU0FBd0I7QUFDM0YsVUFBTSxhQUFhLFdBQVc7QUFDOUIsVUFBTSxRQUFRLFdBQVc7QUFDekIsVUFBTSxZQUFZLFdBQVc7QUFDN0IsVUFBTSxVQUFVLFdBQVc7QUFDM0IsVUFBTSxXQUFXQyxXQUFVLEtBQUssS0FBS0EsV0FBVSxTQUFTLEtBQUssUUFBUSxNQUFNQSxVQUFTO0FBQ3BGLFVBQU0sUUFDSixDQUFDLFdBQVcsbUJBQ1osWUFDQSxjQUFjLFdBQVcsVUFDekIsUUFBUSxTQUFTLEtBQ2pCLFFBQVEsTUFBTUEsVUFBUyxLQUN2QixJQUFJLElBQUksT0FBTyxFQUFFLFNBQVMsUUFBUSxVQUNsQyxRQUFRO0FBQUEsTUFDTixDQUFDLFdBQ0MsTUFBTSxTQUFTLE1BQXFCLEtBQ3BDLFdBQVcsU0FDVixPQUF1QixrQkFBa0IsTUFBTTtBQUFBLElBQ3BELEtBQ0EsVUFBVSxrQkFBa0IsTUFBTTtBQUNwQyxVQUFNLFVBQVUsU0FBUyxRQUFRLGFBQWEsUUFBUSxRQUFRLEtBQUssQ0FBQyxXQUFXLFVBQVUsSUFBSTtBQUM3RixRQUFJLFdBQXlDLFFBQ3pDLE9BQ0EsVUFDRSxFQUFFLFFBQVEsa0JBQWtCLFFBQVEsaUJBQWlCLElBQ3JELEVBQUUsUUFBUSxlQUFlLFFBQVEsc0JBQXNCO0FBQzdELFVBQU0sWUFBWSxRQUNkLHlCQUF5QixXQUFXLFNBQTBCLE9BQU8sSUFDckU7QUFDSixVQUFNLGFBQWEsUUFBUSxVQUFVLEtBQUssSUFBSTtBQUM5QyxRQUFJLGFBQWE7QUFDakIsUUFBSSxVQUFVO0FBQ2QsVUFBTSxPQUFPLENBQ1gsV0FDMEI7QUFDMUIsaUJBQVcsTUFBTSxNQUFNO0FBQ3ZCLGtCQUFZLFFBQVE7QUFDcEIsaUJBQVcsRUFBRSxRQUFRLGVBQWUsT0FBTztBQUMzQyxhQUFPO0FBQUEsSUFDVDtBQUNBLFVBQU0sVUFBVSxDQUNkLFdBQzBCO0FBQzFCLFVBQUksT0FBTyxTQUFTLFVBQVcsUUFBTyxFQUFFLFFBQVEsa0JBQWtCLFFBQVEsaUJBQWlCO0FBQzNGLFVBQUksT0FBTyxXQUFXLG1CQUFtQjtBQUN2QyxlQUFPLEVBQUUsUUFBUSxrQkFBa0IsUUFBUSxrQkFBa0I7QUFBQSxNQUMvRDtBQUNBLGFBQU8sS0FBSyxPQUFPLE1BQU07QUFBQSxJQUMzQjtBQUNBLFdBQU87QUFBQSxNQUNMLFVBQVUsUUFBUSxDQUFDLFdBQVcsT0FBTyxHQUFJLE9BQXlCLElBQUksQ0FBQztBQUFBLE1BQ3ZFLFVBQXFFO0FBQ25FLFlBQUksU0FBVSxRQUFPO0FBQ3JCLFlBQUksQ0FBQyxRQUFRLEtBQUssQ0FBQ0EsV0FBVSxLQUFLLEtBQUssQ0FBQyxhQUFhLENBQUM7QUFDcEQsaUJBQU8sRUFBRSxRQUFRLGtCQUFrQixRQUFRLGtCQUFrQjtBQUMvRCxZQUFJLENBQUMsV0FBVyxVQUFVLEVBQUcsUUFBTyxLQUFLLGdCQUFnQjtBQUN6RCxjQUFNLFdBQVcsVUFBVSxRQUFRO0FBQ25DLFlBQUksU0FBUyxTQUFTLFdBQVksUUFBTyxRQUFRLFFBQVE7QUFDekQsY0FBTSxVQUFXLFFBQTBCO0FBQUEsVUFBSSxDQUFDLFdBQzlDLDZCQUE2QixRQUFRLEtBQUs7QUFBQSxRQUM1QztBQUNBLFlBQUksUUFBUSxLQUFLLENBQUMsV0FBVyxXQUFXLElBQUksRUFBRyxRQUFPLEtBQUssa0JBQWtCO0FBQzdFLGtCQUFVLFNBQVMsUUFBUSxLQUFLLElBQUksR0FBSSxPQUFvQjtBQUM1RCxZQUFJLENBQUMsUUFBUSxFQUFHLFFBQU8sRUFBRSxRQUFRLGtCQUFrQixRQUFRLGtCQUFrQjtBQUM3RSxjQUFNLGFBQWEsTUFBTTtBQUN6QixZQUFJLENBQUMsUUFBUSxFQUFHLFFBQU8sRUFBRSxRQUFRLGtCQUFrQixRQUFRLGtCQUFrQjtBQUM3RSxZQUFJLGNBQWMsYUFBYSxTQUFTO0FBR3RDLGNBQ0UsQ0FBQyxlQUNDLE1BQU0sTUFBTSxpQkFBaUIsT0FBTyxLQUFLLENBQUMsY0FBYyxPQUFPLE9BQU8sS0FDckUsTUFBTSxNQUFNLGlCQUFpQixhQUFhLEtBQUssQ0FBQyxjQUFjLE9BQU8sYUFBYTtBQUVyRixtQkFBTyxLQUFLLGVBQWU7QUFDN0IsZ0JBQU0sUUFBUSxNQUFNLGNBQWMsYUFBYSxpQkFBaUIsS0FBSztBQUNyRSxjQUFJLENBQUMsTUFBTyxRQUFPLEtBQUssa0JBQWtCO0FBQzFDLGdCQUFNLFNBQ0osTUFBTSxjQUFjLGVBQ2hCLElBQ0EsT0FBTyxXQUFXLE1BQU0sV0FBVyxJQUNuQyxPQUFPLFdBQVcsTUFBTSxZQUFZLElBQ3BDLE9BQU8sV0FBVyxNQUFNLGVBQWUsSUFDdkMsT0FBTyxXQUFXLE1BQU0sZ0JBQWdCO0FBQzlDLGdCQUFNLFFBQVEsVUFBVTtBQUN4QixjQUFJLENBQUMsT0FBTyxTQUFTLEtBQUssS0FBSyxTQUFTLEVBQUcsUUFBTyxLQUFLLGtCQUFrQjtBQUN6RSxjQUFJLFNBQVMsRUFBRyxRQUFPLEtBQUssZUFBZTtBQUMzQyxjQUFJLENBQUMsV0FBVyxNQUFNLFNBQVMsR0FBRyxLQUFLLElBQUksRUFBRyxRQUFPLEtBQUssZ0JBQWdCO0FBQzFFLHVCQUFhO0FBQUEsUUFDZjtBQUNBLGVBQU8sRUFBRSxPQUFPLFNBQVMsT0FBTyxRQUFRLFNBQVMsT0FBTztBQUFBLE1BQzFEO0FBQUEsTUFDQSxPQUNFLFdBQ3lEO0FBQ3pELFlBQUksU0FBVSxRQUFPO0FBQ3JCLFlBQUksQ0FBQyxRQUFRLEtBQUssQ0FBQ0EsV0FBVSxLQUFLLEtBQUssQ0FBQyxhQUFhLENBQUM7QUFDcEQsaUJBQU8sRUFBRSxRQUFRLGtCQUFrQixRQUFRLGtCQUFrQjtBQUMvRCxZQUFJLENBQUMsV0FBVyxVQUFVLEVBQUcsUUFBTyxLQUFLLGdCQUFnQjtBQUN6RCxjQUFNLFdBQVcsVUFBVSxPQUFPO0FBQ2xDLFlBQUksU0FBUyxTQUFTLG9CQUFxQixRQUFPLEVBQUUsUUFBUSxvQkFBb0I7QUFDaEYsWUFBSSxTQUFTLFNBQVMsVUFBVyxRQUFPLFFBQVEsUUFBUTtBQUN4RCxZQUFJLENBQUMsT0FBTyxTQUFTLE1BQU0sV0FBVyxLQUFLLENBQUMsT0FBTyxTQUFTLE1BQU0sWUFBWTtBQUM1RSxpQkFBTyxLQUFLLGtCQUFrQjtBQUNoQyxZQUFJLE1BQU0sZUFBZSxLQUFLLE1BQU0sZ0JBQWdCO0FBQ2xELGlCQUFPLEVBQUUsUUFBUSxrQkFBa0IsUUFBUSxpQkFBaUI7QUFDOUQsWUFDRSxNQUFNLGNBQWMsSUFBSSxXQUN2QixjQUNFLE1BQU0sY0FBYyxVQUFVLFFBQVEsS0FBSyxNQUFNLGVBQWUsVUFBVSxTQUFTO0FBRXRGLGlCQUFPLEtBQUssZUFBZTtBQUM3QixtQkFBVyxVQUFVLFNBQTBCO0FBQzdDLGdCQUFNLFVBQVUsMkJBQTJCLFFBQVEsS0FBSztBQUN4RCxjQUFJLFlBQVksTUFBTyxRQUFPLEtBQUssWUFBWSxPQUFPLHFCQUFxQixlQUFlO0FBQUEsUUFDNUY7QUFDQSxlQUFPLEVBQUUsUUFBUSxVQUFVO0FBQUEsTUFDN0I7QUFBQSxNQUNBO0FBQUEsTUFDQSxVQUFVO0FBQ1IsbUJBQVcsUUFBUTtBQUNuQixvQkFBWSxRQUFRO0FBQUEsTUFDdEI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQVFBLFdBQVMsb0JBQ1BNLFdBQ0EsVUFDQSxRQUNBO0FBR0EsUUFBSUEsVUFBUyxNQUFNLGFBQWEsWUFBWSxjQUFjQSxXQUFVLFVBQVU7QUFDNUUsYUFBTyxNQUFNLFlBQVksUUFBUTtBQUNuQyxlQUFXLFFBQVEsQ0FBQyxPQUFPLE1BQU0sR0FBWTtBQUMzQyxVQUFJQSxVQUFTLE1BQU0sSUFBSSxNQUFNLE1BQU0sY0FBY0EsV0FBVSxJQUFJO0FBQzdELGVBQU8sTUFBTSxNQUFNQSxVQUFTLE1BQU0sSUFBSSxLQUFLLEtBQUs7QUFBQSxJQUNwRDtBQUFBLEVBQ0Y7QUFFQSxXQUFTLGlDQUF1RDtBQUM5RCxXQUFPO0FBQUEsTUFDTCxPQUFPLFNBQW9DO0FBQ3pDLFlBQUksYUFBYTtBQUNqQixZQUFJLFdBQVc7QUFDZixZQUFJLGFBQWE7QUFDakIsWUFBSSxVQUErQjtBQUNuQyxZQUFJLGNBQWM7QUFDbEIsWUFBSSxTQUF3RDtBQUM1RCxZQUFJLGdCQUFrQyxDQUFDO0FBQ3ZDLFlBQUksY0FBb0Y7QUFDeEYsY0FBTSxvQkFBb0IsTUFBTTtBQUM5QixnQkFBTSxXQUFXO0FBQ2pCLHdCQUFjO0FBQ2Qsb0JBQVUsT0FBTyxRQUFRO0FBQUEsUUFDM0I7QUFDQSxjQUFNLGVBQWUsTUFBTTtBQUN6QjtBQUNBLHFCQUFXLFlBQVksY0FBZSxVQUFTLFdBQVc7QUFDMUQsMEJBQWdCLENBQUM7QUFDakIsZ0JBQU0sV0FBVztBQUNqQixtQkFBUztBQUNULG9CQUFVLFFBQVE7QUFBQSxRQUNwQjtBQUNBLGNBQU0sZUFBZSxDQUFDTCxTQUFpQkYsWUFBbUM7QUFDeEUsY0FBSUMsV0FBVUMsT0FBTTtBQUNsQixtQkFBTztBQUFBLGNBQ0wsU0FBU0E7QUFBQSxjQUNULFdBQVcsa0JBQWtCQSxTQUFRRixPQUFNO0FBQUEsY0FDM0MsUUFBUSxNQUFNO0FBQUEsWUFDaEI7QUFDRixpQkFBTyw0QkFBNEJFLE9BQU07QUFBQSxRQUMzQztBQUVBLGNBQU0sV0FBVyxZQUFZO0FBQzNCLGdCQUFNLFVBQVU7QUFDaEIsZ0JBQU0sRUFBRSxRQUFBQSxTQUFRLFVBQUFLLFdBQVUsUUFBQVAsUUFBTyxJQUFJO0FBQ3JDLGdCQUFNLFVBQVUsRUFBRTtBQUNsQixnQkFBTSxZQUFZLGFBQWFFLFNBQVFGLE9BQU07QUFDN0MsZ0JBQU0sWUFBWSxNQUNoQixDQUFDLFlBQ0QsWUFBWSxjQUNaLENBQUMsQ0FBQyxXQUFXLE9BQU8sTUFDbkIsQ0FBQyxlQUFlLFlBQVksT0FBTyxVQUFVO0FBQ2hELGNBQUksU0FBVTtBQUNkLGNBQUksQ0FBQyxhQUFhLENBQUNDLFdBQVVNLFNBQVEsR0FBRztBQUN0QyxnQkFBSSxRQUFRLGFBQWEsWUFBWSxZQUFZO0FBQy9DLG9CQUFNLFlBQVk7QUFDbEIsb0JBQU0sV0FBVyxXQUFXLFFBQVE7QUFDcEMsa0JBQUksQ0FBQyxZQUFZLFlBQVksY0FBYyxjQUFjO0FBQ3ZELHdCQUFRO0FBQUEsa0JBQ04sWUFBWSxZQUFZLFdBQ3BCLFdBQ0EsRUFBRSxRQUFRLGtCQUFrQixRQUFRLGlCQUFpQjtBQUFBLGdCQUMzRDtBQUFBLFlBQ0o7QUFDQTtBQUFBLFVBQ0Y7QUFDQSxjQUFJLENBQUMsZUFBZSxZQUFZLFdBQVdBLFdBQVU7QUFDbkQsOEJBQWtCO0FBQ2xCLDBCQUFjLEVBQUUsUUFBUUEsV0FBVSxRQUFRLFVBQVVBLFNBQVEsRUFBRTtBQUFBLFVBQ2hFO0FBQ0EsOEJBQW9CQSxXQUFVUCxRQUFPLFVBQVUsWUFBWSxNQUFNO0FBQ2pFLGNBQUksQ0FBQyxVQUFVLEVBQUc7QUFDbEIsY0FBSSxRQUFRO0FBQ1Ysa0JBQU0sWUFBWTtBQUNsQixxQkFBUyxPQUFPLEdBQUcsT0FBTyxHQUFHLFFBQVE7QUFDbkMsa0JBQUksQ0FBQyxVQUFVLEtBQUssY0FBYyxPQUFRO0FBQzFDLG9CQUFNLFdBQVcsVUFBVSxRQUFRO0FBQ25DLGtCQUFJLFlBQVksVUFBVTtBQUN4QixvQkFBSSxVQUFVLEVBQUcsU0FBUSxjQUFjLFFBQVE7QUFDL0M7QUFBQSxjQUNGO0FBQ0Esa0JBQUksWUFBc0Q7QUFDMUQsa0JBQUlRO0FBQ0osa0JBQUk7QUFDRixnQkFBQUEsVUFBUyxNQUFNQyxpQkFBZ0IsVUFBVSxXQUFXRixXQUFVO0FBQUEsa0JBQzVELFdBQVcsWUFBWVAsT0FBTTtBQUFBLGtCQUM3QixVQUFVQSxRQUFPO0FBQUEsa0JBQ2pCLFlBQVksY0FBY0EsU0FBUSxXQUFXLENBQUMsT0FBTyxXQUFXO0FBQzlELGdDQUFZLEVBQUUsT0FBTyxPQUFPO0FBQUEsa0JBQzlCLENBQUM7QUFBQSxnQkFDSCxDQUFDO0FBQUEsY0FDSCxTQUFTLE9BQU87QUFDZCxvQkFBSSxVQUFVLEtBQUssY0FBYztBQUMvQiwwQkFBUSxjQUFjLFVBQVUsS0FBSyxrQkFBa0IsQ0FBQztBQUMxRDtBQUFBLGNBQ0Y7QUFDQSxrQkFBSSxDQUFDLFVBQVUsS0FBSyxjQUFjLE9BQVE7QUFDMUMsb0JBQU0sV0FBVyxVQUFVLE9BQU8sU0FBUztBQUMzQyxrQkFBSSxTQUFTLFdBQVcsb0JBQXFCO0FBQzdDLGtCQUFJLFNBQVMsV0FBVyxXQUFXO0FBQ2pDLG9CQUFJLFVBQVUsRUFBRyxTQUFRLGNBQWMsUUFBUTtBQUMvQztBQUFBLGNBQ0Y7QUFJQSxnQ0FBa0I7QUFDbEIseUJBQVcsQ0FBQyxNQUFNLEtBQUssS0FBSztBQUFBLGdCQUMxQixDQUFDLFlBQVlRLFFBQU8sUUFBUTtBQUFBLGdCQUM1QixDQUFDLFFBQVEsR0FBR0EsUUFBTyxDQUFDLElBQUk7QUFBQSxnQkFDeEIsQ0FBQyxPQUFPLEdBQUdBLFFBQU8sQ0FBQyxJQUFJO0FBQUEsY0FDekIsR0FBRztBQUNELG9CQUFJLENBQUMsVUFBVSxLQUFLLGNBQWMsT0FBUTtBQUMxQyxnQkFBQUQsVUFBUyxNQUFNLFlBQVksTUFBTSxLQUFLO0FBQUEsY0FDeEM7QUFDQSxvQkFBTUcsWUFBVyxjQUFjRixRQUFPLFNBQVM7QUFDL0Msa0JBQUksQ0FBQyxVQUFVLEtBQUssY0FBYyxPQUFRO0FBQzFDLGNBQUFELFVBQVMsUUFBUSxPQUFPRyxVQUFTO0FBQ2pDLGtCQUFJLENBQUMsVUFBVSxLQUFLLGNBQWMsT0FBUTtBQUMxQyxjQUFBSCxVQUFTLFFBQVEsUUFBUUcsVUFBUztBQUNsQyxrQkFBSSxDQUFDLFVBQVUsS0FBSyxjQUFjLE9BQVE7QUFHMUMsb0JBQU0sU0FBUyxVQUFVLE9BQU8sU0FBUztBQUN6QyxrQkFBSSxPQUFPLFdBQVcsb0JBQXFCO0FBQzNDLGtCQUFJLE9BQU8sV0FBVyxXQUFXO0FBQy9CLG9CQUFJLFVBQVUsRUFBRyxTQUFRLGNBQWMsTUFBTTtBQUM3QztBQUFBLGNBQ0Y7QUFDQSxzQkFBUSxhQUFhLEVBQUUsR0FBR0EsV0FBVSxVQUFVRixRQUFPLFNBQVMsQ0FBQztBQUMvRCxrQkFBSSxDQUFDLFVBQVUsS0FBSyxjQUFjLE9BQVE7QUFFMUMsb0JBQU0sWUFBWSxVQUFVLE9BQU8sU0FBUztBQUM1QyxrQkFBSSxVQUFVLFdBQVcsb0JBQXFCO0FBQzlDLGtCQUFJLFVBQVUsS0FBSyxjQUFjLE9BQVEsU0FBUSxjQUFjLFNBQVM7QUFDeEU7QUFBQSxZQUNGO0FBQ0EsZ0JBQUksVUFBVSxLQUFLLGNBQWM7QUFDL0Isc0JBQVEsY0FBYyxVQUFVLEtBQUssa0JBQWtCLENBQUM7QUFDMUQ7QUFBQSxVQUNGO0FBQ0EsZ0JBQU0sU0FBUyxNQUFNQyxpQkFBZ0IsVUFBVSxXQUFXRixXQUFVO0FBQUEsWUFDbEUsV0FBVyxZQUFZUCxPQUFNO0FBQUEsWUFDN0IsVUFBVUEsUUFBTztBQUFBLFlBQ2pCLFlBQVksY0FBY0EsU0FBUSxTQUFTO0FBQUEsVUFDN0MsQ0FBQztBQUNELGNBQUksQ0FBQyxVQUFVLEVBQUc7QUFDbEIsNEJBQWtCO0FBQ2xCLGNBQUksQ0FBQyxVQUFVLEVBQUc7QUFDbEIsaUJBQU8sT0FBT08sVUFBUyxPQUFPO0FBQUEsWUFDNUIsVUFBVSxPQUFPO0FBQUEsWUFDakIsTUFBTSxHQUFHLE9BQU8sQ0FBQztBQUFBLFlBQ2pCLEtBQUssR0FBRyxPQUFPLENBQUM7QUFBQSxVQUNsQixDQUFDO0FBQ0QsZ0JBQU0sV0FBVyxjQUFjLE9BQU8sU0FBUztBQUMvQyxVQUFBQSxVQUFTLFFBQVEsT0FBTyxTQUFTO0FBQ2pDLFVBQUFBLFVBQVMsUUFBUSxRQUFRLFNBQVM7QUFDbEMsa0JBQVEsYUFBYSxFQUFFLEdBQUcsVUFBVSxVQUFVLE9BQU8sU0FBUyxDQUFDO0FBQUEsUUFDakU7QUFFQSxjQUFNLFVBQVUsTUFBTTtBQUNwQixvQkFBVTtBQUNWLG9CQUFVO0FBQ1YsdUJBQWE7QUFDYiw0QkFBa0I7QUFDbEIsY0FBSSxXQUFXLFdBQVc7QUFDeEIsa0JBQU1JLFNBQVE7QUFDZCxxQkFBUyxvQkFBb0IsWUFBWSxNQUFNLENBQUMsWUFBWUEsV0FBVSxXQUFXO0FBQ2pGLGtCQUFNLE9BQU9WLFdBQVUsV0FBVyxRQUFRLElBQ3RDLFdBQVcsU0FBUyxjQUFjLGNBQ2xDO0FBQ0osZ0JBQUksT0FBTyxNQUFNLG1CQUFtQixZQUFZO0FBRTlDLDhCQUFpQixDQUFDLGVBQWUsWUFBWSxFQUFZLElBQUksQ0FBQ1csU0FBUTtBQUNwRSxzQkFBTSxXQUFXLElBQUksS0FBSyxlQUFlLE1BQU07QUFDN0Msc0JBQUksQ0FBQyxZQUFZRCxXQUFVLFlBQWEsTUFBSyxTQUFTO0FBQUEsZ0JBQ3hELENBQUM7QUFDRCwyQkFBVyxVQUFVLE9BQVEsU0FBVSxVQUFTLFFBQVEsUUFBUSxFQUFFLEtBQUFDLEtBQUksQ0FBQztBQUN2RSx1QkFBTztBQUFBLGNBQ1QsQ0FBQztBQUFBLFlBQ0g7QUFBQSxVQUNGO0FBQ0EsZ0JBQU0sRUFBRSxRQUFBVixTQUFRLFVBQUFLLFVBQVMsSUFBSTtBQUM3QixnQkFBTSxZQUFZLGFBQWFMLFNBQVEsV0FBVyxNQUFNO0FBQ3hELGNBQUksQ0FBQyxhQUFhLENBQUNELFdBQVVNLFNBQVEsR0FBRztBQUN0QyxnQkFBSSxXQUFXLFVBQVcsTUFBSyxTQUFTO0FBQ3hDO0FBQUEsVUFDRjtBQUNBLGdCQUFNLFdBQVcsV0FBVyxVQUFVLFdBQVdBLFdBQVUsVUFBVTtBQUFBLFlBQ25FLGdCQUFnQjtBQUFBLFVBQ2xCLENBQUM7QUFDRCxnQkFBTSxXQUFXLGlCQUFpQixVQUFVLFFBQVEsZUFBZSxNQUFNO0FBQ3ZFLGlCQUFLLFNBQVM7QUFBQSxVQUNoQixDQUFDO0FBTUQsZ0JBQU0sZ0JBQWdCLFVBQVUsUUFBUTtBQUN4QyxnQkFBTSxtQkFBbUIsTUFBTTtBQUM3QixpQkFBSyxTQUFTO0FBQUEsVUFDaEI7QUFDQSx3QkFBYyxpQkFBaUIsVUFBVSxrQkFBa0IsSUFBSTtBQUMvRCxnQkFBTSxtQkFBbUIsNEJBQTRCTCxPQUFNLEdBQUcsc0JBQXNCLE1BQU07QUFDeEY7QUFDQSx5QkFBYTtBQUNiLDhCQUFrQjtBQUNsQixzQkFBVTtBQUNWLHNCQUFVO0FBQUEsVUFDWixDQUFDO0FBQ0Qsb0JBQVUsTUFBTTtBQUNkLHFCQUFTO0FBQ1QscUJBQVM7QUFDVCwrQkFBbUI7QUFDbkIsMEJBQWMsb0JBQW9CLFVBQVUsa0JBQWtCLElBQUk7QUFBQSxVQUNwRTtBQUFBLFFBQ0Y7QUFFQSxnQkFBUTtBQUVSLGVBQU87QUFBQSxVQUNMLE9BQU8sTUFBTTtBQUNYLGdCQUFJLFNBQVU7QUFDZCwwQkFBYztBQUNkLGtCQUFNLGlCQUNKLENBQUMsT0FBTyxHQUFHLFdBQVcsUUFBUSxLQUFLLE1BQU0sS0FDekMsQ0FBQyxPQUFPLEdBQUcsV0FBVyxVQUFVLEtBQUssUUFBUSxLQUM3QyxRQUFRLFdBQVcsZUFBZSxNQUFNLFFBQVEsS0FBSyxlQUFlLEtBQ3BFLFFBQVEsV0FBVyxTQUFTLE1BQU0sUUFBUSxLQUFLLFNBQVMsS0FDdkQsQ0FBQyxDQUFDLFdBQVcsYUFDWixDQUFDLENBQUMsS0FBSyxjQUNOLFdBQVcsVUFBVSxjQUFjLEtBQUssVUFBVSxhQUNqRCxXQUFXLFVBQVUsUUFBUSxXQUFXLEtBQUssVUFBVSxRQUFRLFVBQy9ELFdBQVcsVUFBVSxRQUFRO0FBQUEsY0FDM0IsQ0FBQyxRQUFRLFVBQVUsV0FBVyxLQUFLLFVBQVcsUUFBUSxLQUFLO0FBQUEsWUFDN0Q7QUFDTix5QkFBYTtBQUliLGdCQUFJLGtCQUFrQixLQUFLLFVBQVcsU0FBUTtBQUFBLGdCQUN6QyxNQUFLLFNBQVM7QUFBQSxVQUNyQjtBQUFBLFVBQ0EsZ0JBQWdCO0FBQ2QsaUJBQUssU0FBUztBQUFBLFVBQ2hCO0FBQUEsVUFDQSxVQUFVO0FBQ1IsdUJBQVc7QUFDWCwwQkFBYztBQUNkLHlCQUFhO0FBQ2IsOEJBQWtCO0FBQ2xCLHNCQUFVO0FBQ1Ysc0JBQVU7QUFBQSxVQUNaO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUdPLFdBQVMsdUNBQTZEO0FBQzNFLFVBQU0sT0FBTywrQkFBK0I7QUFDNUMsV0FBTztBQUFBLE1BQ0wseUJBQXlCO0FBQUEsTUFDekIsbUJBQW1CO0FBQUEsTUFDbkIsT0FBTyxTQUFTO0FBQ2QsWUFBSSxhQUFhO0FBQ2pCLFlBQUksV0FBVztBQUNmLGNBQU0sVUFBVSxDQUFDLFNBQ2YsS0FBSyxtQkFBbUIsQ0FBQyxLQUFLLFlBQzFCLDJCQUEyQixJQUFJLElBQy9CLEtBQUssT0FBTyxJQUFJO0FBQ3RCLFlBQUlXLFNBQTJDLFFBQVEsT0FBTztBQUM5RCxZQUFJLGFBQWE7QUFDakIsZUFBTztBQUFBLFVBQ0wsT0FBTyxNQUFNO0FBQ1gsZ0JBQUksU0FBVTtBQUNkLGtCQUFNLFVBQ0osUUFBUSxXQUFXLG1CQUFtQixDQUFDLFdBQVcsU0FBUyxNQUMzRCxRQUFRLEtBQUssbUJBQW1CLENBQUMsS0FBSyxTQUFTO0FBQ2pELHlCQUFhO0FBQ2IsZ0JBQUksQ0FBQyxXQUFXQSxRQUFPO0FBQ3JCLGNBQUFBLE9BQU0sT0FBTyxJQUFJO0FBQ2pCO0FBQUEsWUFDRjtBQUNBLGtCQUFNLFVBQVUsRUFBRTtBQUNsQixrQkFBTSxXQUFXQTtBQUNqQixZQUFBQSxTQUFRO0FBQ1Isc0JBQVUsUUFBUTtBQUNsQixnQkFBSSxZQUFZLFlBQVksY0FBYyxlQUFlLEtBQU07QUFDL0Qsa0JBQU0sV0FBVyxRQUFRLElBQUk7QUFDN0IsZ0JBQUksWUFBWSxZQUFZLGNBQWMsZUFBZSxLQUFNLFVBQVMsUUFBUTtBQUFBLGdCQUMzRSxDQUFBQSxTQUFRO0FBQUEsVUFDZjtBQUFBLFVBQ0EsZ0JBQWdCO0FBQ2QsZ0JBQUksQ0FBQyxTQUFVLENBQUFBLFFBQU8sY0FBYztBQUFBLFVBQ3RDO0FBQUEsVUFDQSxVQUFVO0FBQ1IsZ0JBQUksU0FBVTtBQUNkLHVCQUFXO0FBQ1g7QUFDQSxrQkFBTSxXQUFXQTtBQUNqQixZQUFBQSxTQUFRO0FBQ1Isc0JBQVUsUUFBUTtBQUFBLFVBQ3BCO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjs7O0FDN2xCQSxNQUFNLFNBQVMsQ0FBQyxrQkFBa0IsU0FBUyxPQUFPLE9BQU87QUFDekQsTUFBTSxjQUFjLENBQUMsS0FBSyxJQUFJLElBQUksRUFBRTtBQUNwQyxNQUFJO0FBQ0osTUFBSTtBQUNKLE1BQUk7QUFDSixNQUFJO0FBQ0osTUFBSTtBQUNKLE1BQUksT0FBTyxDQUFDO0FBQ1osTUFBSTtBQUNKLE1BQUk7QUFDSixNQUFJO0FBQ0osTUFBSSxRQUFRO0FBQ1osTUFBSTtBQUNKLE1BQU0sY0FBYyxDQUFDO0FBQ3JCLE1BQU0sTUFBTSxDQUFDQyxhQUFZQSxTQUFRLHNCQUFzQixFQUFFLE9BQU87QUFDaEUsTUFBTSxRQUFRLENBQUNBLGFBQVk7QUFDekIsVUFBTSxXQUFXLGlCQUFpQkEsUUFBTztBQUN6QyxXQUFPO0FBQUEsTUFDTCxJQUFJQSxTQUFRO0FBQUEsTUFDWixXQUFXQSxTQUFRO0FBQUEsTUFDbkIsS0FBSyxJQUFJQSxRQUFPO0FBQUEsTUFDaEIsY0FBY0EsU0FBUTtBQUFBLE1BQ3RCLGNBQWNBLFNBQVE7QUFBQSxNQUN0QixjQUFjQSxTQUFRO0FBQUEsTUFDdEIsV0FBV0EsU0FBUTtBQUFBLE1BQ25CLFNBQVMsU0FBUztBQUFBLE1BQ2xCLFdBQVcsU0FBUztBQUFBLE1BQ3BCLFdBQVcsU0FBUztBQUFBLE1BQ3BCLFVBQVUsU0FBUztBQUFBLE1BQ25CLFdBQVcsU0FBUztBQUFBLE1BQ3BCLGlCQUFpQixTQUFTLGlCQUFpQiw2QkFBNkI7QUFBQSxNQUN4RSxnQkFBZ0IsU0FBUyxpQkFBaUIsNEJBQTRCO0FBQUEsTUFDdEUsYUFBYUEsU0FBUSxhQUFhLE9BQU87QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFDQSxNQUFNLFFBQVEsT0FBTztBQUFBLElBQ25CO0FBQUEsSUFDQTtBQUFBLElBQ0EsYUFBYSxTQUFTLGVBQWUsVUFBVSxNQUFNO0FBQUEsSUFDckQsVUFBVSxLQUFLLE1BQU0sQ0FBQyxLQUFLLFVBQVUsU0FBUyxlQUFlLFNBQVMsS0FBSyxNQUFNLEdBQUc7QUFBQSxJQUNwRjtBQUFBLElBQ0EsTUFBTSxTQUFTLFFBQVEsUUFBUTtBQUFBLElBQy9CLE9BQU8sU0FBUyxRQUFRLFNBQVM7QUFBQSxJQUNqQyxRQUFRLElBQUksTUFBTTtBQUFBLElBQ2xCLE9BQU8sTUFBTSxRQUFRO0FBQUEsSUFDckIsU0FBUyxVQUFVLE1BQU0sT0FBTyxJQUFJO0FBQUEsSUFDcEMsVUFBVSxNQUFNLFFBQVE7QUFBQSxJQUN4QixRQUFRLEVBQUUsT0FBTyxZQUFZLFFBQVEsWUFBWTtBQUFBLElBQ2pELE1BQU0sS0FBSyxJQUFJLENBQUMsUUFBUTtBQUN0QixZQUFNLFNBQVMsSUFBSSxzQkFBc0I7QUFDekMsWUFBTSxTQUFTLFNBQVM7QUFBQSxRQUN0QixPQUFPLElBQUksT0FBTyxRQUFRO0FBQUEsUUFDMUIsT0FBTyxJQUFJLE9BQU8sU0FBUztBQUFBLE1BQzdCO0FBQ0EsWUFBTSxRQUFRLFNBQVMsWUFBWTtBQUNuQyxZQUFNLG1CQUFtQixJQUFJLGlCQUFpQjtBQUM5QyxhQUFPO0FBQUEsUUFDTCxNQUFNLElBQUk7QUFBQSxRQUNWLEtBQUssT0FBTyxPQUFPO0FBQUEsUUFDbkIsT0FBTyxDQUFDLEdBQUcsTUFBTSxlQUFlLENBQUMsRUFBRSxJQUFJLENBQUMsVUFBVSxNQUFNLE9BQU8sQ0FBQztBQUFBLFFBQ2hFLFlBQVksV0FBVyxPQUFRLENBQUMsQ0FBQyxVQUFVLElBQUksU0FBUyxNQUFNO0FBQUEsTUFDaEU7QUFBQSxJQUNGLENBQUM7QUFBQSxJQUNELGFBQWEsWUFBWSxNQUFNO0FBQUEsRUFDakM7QUFDQSxNQUFNLFNBQVMsTUFBTTtBQUNuQixVQUFNLFdBQVcsRUFBRTtBQUNuQixZQUFRLHFDQUFxQyxFQUFFLE9BQU87QUFBQSxNQUNwRDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQSxXQUFXLFVBQVU7QUFDbkIsWUFBSSxZQUFZLFNBQVMsSUFBSTtBQUMzQixzQkFBWSxLQUFLO0FBQUEsWUFDZixPQUFPO0FBQUEsWUFDUCxJQUFJLFlBQVksSUFBSTtBQUFBLFlBQ3BCO0FBQUEsWUFDQSxPQUFPLE1BQU0sUUFBUTtBQUFBLFlBQ3JCLFVBQVUsTUFBTSxRQUFRO0FBQUEsVUFDMUIsQ0FBQztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUNBLE1BQU0sU0FBUyxDQUFDLFlBQVk7QUFDMUIsV0FBTyxRQUFRO0FBQ2YsZ0JBQVksU0FBUztBQUNyQixZQUFRO0FBQ1Isa0JBQWMsUUFBUTtBQUN0QixhQUFTLEtBQUssZ0JBQWdCO0FBQzlCLGFBQVMsU0FBUyxjQUFjLFFBQVE7QUFDeEMsV0FBTyxLQUFLO0FBQ1osV0FBTyxPQUFPO0FBQ2QsV0FBTyxjQUFjO0FBQ3JCLGVBQVcsU0FBUyxjQUFjLEtBQUs7QUFDdkMsdUJBQW1CO0FBQ25CLGFBQVMsS0FBSztBQUNkLGFBQVMsWUFBWSxjQUFjO0FBQ25DLGFBQVMsYUFBYSxRQUFRLFNBQVM7QUFDdkMsY0FBVTtBQUNWLGVBQVc7QUFDWCxRQUFJLGdCQUFnQixVQUFVO0FBQzVCLGdCQUFVLFNBQVMsY0FBYyxLQUFLO0FBQ3RDLGNBQVEsS0FBSztBQUNiLGNBQVEsWUFBWTtBQUNwQixpQkFBVyxTQUFTLGNBQWMsS0FBSztBQUN2QyxlQUFTLEtBQUs7QUFDZCxlQUFTLFlBQVk7QUFDckIsY0FBUSxPQUFPLFFBQVE7QUFDdkIsZUFBUyxPQUFPLE9BQU87QUFBQSxJQUN6QjtBQUNBLFdBQU8sT0FBTyxJQUFJLENBQUMsT0FBTyxVQUFVO0FBQ2xDLFlBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxVQUFJLEtBQUssU0FBUztBQUNsQixVQUFJLFlBQVk7QUFDaEIsVUFBSSxhQUFhLFFBQVEsUUFBUTtBQUNqQyxVQUFJLE1BQU0sVUFBVSxRQUFRLFFBQVEsS0FBSyxZQUFZLEtBQUssS0FBSztBQUMvRCxZQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsV0FBSyxjQUFjO0FBQ25CLFVBQUksT0FBTyxJQUFJO0FBQ2YsZUFBUyxPQUFPLEdBQUc7QUFDbkIsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUNELGFBQVMsS0FBSyxPQUFPLFFBQVEsUUFBUTtBQUdyQyxjQUFVO0FBQUEsTUFDUixPQUFPLElBQUksUUFBUTtBQUFBLE1BQ25CLFVBQVUsSUFBSSxRQUFRO0FBQUEsTUFDdEIsTUFBTSxLQUFLLElBQUksR0FBRztBQUFBLElBQ3BCO0FBQ0EsUUFBSSxRQUFRLE9BQVEsVUFBUyxNQUFNLFVBQVU7QUFDN0MsYUFBUztBQUFBLE1BQ1AsTUFBTTtBQUFBLE1BQ04sT0FBTztBQUFBLE1BQ1AsWUFBWTtBQUFBLE1BQ1osYUFBYTtBQUFBLE1BQ2IsVUFBVTtBQUFBLE1BQ1YsaUJBQWlCLFFBQVE7QUFBQSxNQUN6QixtQkFBbUI7QUFBQSxNQUNuQixrQkFBa0I7QUFBQSxJQUNwQjtBQUNBLFdBQU87QUFDUCxXQUFPLE1BQU07QUFBQSxFQUNmO0FBQ0EsTUFBTSx5QkFBeUIsWUFBWTtBQUd6QyxVQUFNLElBQUksUUFBUSxDQUFDLFlBQVksc0JBQXNCLE9BQU8sQ0FBQztBQUM3RCxVQUFNLElBQUksUUFBUSxDQUFDLFlBQVksc0JBQXNCLE9BQU8sQ0FBQztBQUM3RCxXQUFPLE1BQU07QUFBQSxFQUNmO0FBQ0EsTUFBTSx3QkFBd0IsTUFBTTtBQUNsQyxhQUFTLE1BQU0sVUFBVTtBQUN6QixVQUFNLFFBQVE7QUFDZCxTQUFLLFFBQVEsQ0FBQyxLQUFLLFVBQVU7QUFBRSxVQUFJLE1BQU0sU0FBUyxZQUFZLEtBQUssSUFBSTtBQUFBLElBQU0sQ0FBQztBQUU5RSxXQUFPO0FBQ1AsV0FBTyxNQUFNO0FBQUEsRUFDZjtBQUNBLE1BQU0seUJBQXlCLE1BQU07QUFDbkMsYUFBUyxNQUFNLGVBQWUsU0FBUztBQUN2QyxVQUFNLGNBQWM7QUFDcEIsV0FBTyxNQUFNO0FBQUEsRUFDZjtBQUNBLGFBQVcsNkJBQTZCO0FBQUEsSUFDdEM7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxVQUFVO0FBQUUsYUFBTyxRQUFRO0FBQUEsSUFBRztBQUFBLEVBQ2hDOyIsCiAgIm5hbWVzIjogWyJzdXJmYWNlIiwgImZhY3RzIiwgIm5hdHVyYWwiLCAiYm94IiwgImRvY3VtZW50IiwgImNsYW1wIiwgImZsb2F0aW5nIiwgInBsYXRmb3JtIiwgImVsZW1lbnQiLCAiY29uZmlnIiwgInBsYXRmb3JtIiwgInBsYWNlbWVudHMiLCAic2lkZXMiLCAic2lkZSIsICJwbGFjZW1lbnQiLCAib3ZlcmZsb3ciLCAicGxhdGZvcm0iLCAieCIsICJ5IiwgImNsYW1wIiwgInBsYXRmb3JtIiwgImVsZW1lbnQiLCAiZ2V0Q29tcHV0ZWRTdHlsZSIsICJlbGVtZW50IiwgImdldENvbXB1dGVkU3R5bGUiLCAiZmxvYXRpbmciLCAib2Zmc2V0IiwgInNoaWZ0IiwgImZsaXAiLCAic2l6ZSIsICJjb21wdXRlUG9zaXRpb24iLCAiZmxvYXRpbmciLCAiY29uZmlnIiwgImlzRWxlbWVudCIsICJhbmNob3IiLCAic2hpZnQiLCAib2Zmc2V0IiwgImZsaXAiLCAic2l6ZSIsICJmbG9hdGluZyIsICJyZXN1bHQiLCAiY29tcHV0ZVBvc2l0aW9uIiwgInJlc29sdmVkIiwgImVwb2NoIiwgImJveCIsICJsZWFzZSIsICJlbGVtZW50Il0KfQo=
