import subprocess,pathlib,tempfile,json,datetime,os
C=pathlib.Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation')
profile=pathlib.Path(tempfile.mkdtemp(prefix='s1-chrome-diagnostic-',dir=C/'task-temp'))
args=['/home/ezra/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome','--headless=new','--disable-dev-shm-usage','--enable-logging=stderr','--v=1','--no-first-run','--no-default-browser-check','--user-data-dir='+str(profile),'--dump-dom','about:blank']
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (C/'chrome-native-startup.stdout').open('x') as out,(C/'chrome-native-startup.stderr').open('x') as err:
 try:r=subprocess.run(args,stdout=out,stderr=err,timeout=20);result={'exit':r.returncode}
 except subprocess.TimeoutExpired:result={'deadlineReached':True}
result.update(args=args,startedAt=start,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),profile=str(profile))
(C/'chrome-native-startup-diagnostic.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
