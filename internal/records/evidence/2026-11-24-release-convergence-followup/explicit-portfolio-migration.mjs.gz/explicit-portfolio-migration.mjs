import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { consumerLedgerRows, refreshSourceInventory, validate, render, renderPlan, dataPath, markdownPath } from '/tmp/pui-40da-integration/scripts/coverage-matrices/prototype-coverage.mjs';
const root='/tmp/pui-40da-integration';
const revision='78af4d4c9dc822e66a525b1ddc2794d618b1afc3';
if(execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim()!==revision)throw Error('Wrong source revision');
execFileSync('git',['diff','--exit-code'],{cwd:root});execFileSync('git',['diff','--cached','--exit-code'],{cwd:root});
const before=JSON.parse(fs.readFileSync(path.join(root,dataPath),'utf8'));
const data=structuredClone(before);
const ledger='internal/website/self-hosting-coverage-matrix.md';
const source=fs.readFileSync(path.join(root,ledger),'utf8');
const {rows}=consumerLedgerRows(source);
const existing=data.consumerRows.filter(row=>row.program==='website');
const added=[...rows.keys()].filter(id=>!existing.some(row=>row.ID===id));
const removed=existing.filter(row=>!rows.has(row.ID)).map(row=>row.ID);
if(JSON.stringify(added)!==JSON.stringify(['www.docs.code-panel-scroll'])||removed.length)throw Error('Unexpected consumer identity migration');
const row=rows.get(added[0]);
if(row.State!=='blocked'||!Object.values(row).join(' ').includes('HC-SCROLL-SURFACE-0001=draft'))throw Error('Unexpected consumer admission');
const issues=[...new Set([...Object.values(row).join(' ').matchAll(/#([1-9]\d*)\b/g)].map(m=>Number(m[1])))].sort((a,b)=>a-b);
if(JSON.stringify(issues)!==JSON.stringify([1323]))throw Error('Unexpected consumer issue binding');
data.consumerRows.push({...row,program:'website',source:ledger,issues});
const after=refreshSourceInventory(data,root,{revision});
for(const key of Object.keys(before))if(!['consumerRows','counts','candidateSource'].includes(key)&&JSON.stringify(before[key])!==JSON.stringify(after[key]))throw Error(`Unexpected historical mutation: ${key}`);
for(const old of before.consumerRows){const current=after.consumerRows.find(row=>row.program===old.program&&row.ID===old.ID);if(!current||JSON.stringify(old.issues)!==JSON.stringify(current.issues))throw Error(`Historical issue index changed: ${old.ID}`);}
const errors=validate(after,root);
const receipt={revision,ledger,ledgerSHA256:crypto.createHash('sha256').update(source).digest('hex'),added,removed,addedCanonicalRow:row,issues,historicalIssueIndexesRetained:true,errors};
fs.writeFileSync('/tmp/pui-40da-evidence/portfolio-migration-receipt.json',JSON.stringify(receipt,null,2)+'\n');
if(errors.length){console.error(errors.join('\n'));process.exitCode=1;}else{
fs.writeFileSync(path.join(root,dataPath),JSON.stringify(after,null,2)+'\n');
fs.writeFileSync(path.join(root,markdownPath),render(after));
fs.writeFileSync(path.join(root,'internal/coverage-matrices/finf-delivery-checklist.md'),renderPlan(after));
console.log(JSON.stringify({revision,added,removed,validated:true,consumerRows:after.consumerRows.length}));
}
