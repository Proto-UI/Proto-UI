# Callable provenance merge validation

## Exact source boundary

Only `packages/compiler/src/callable-effects.ts` was edited in the integration worktree. No index operation, commit, other integration source change, or external write was made by this agent. The merge parents, exact stage blobs and the reviewed candidate hashes are in `source-bindings.json`. Candidate Git blob: `610b32ae9cf90286c2ffef721b0c9b07eb424e7a`; SHA-256: `f151a48fd13b23e2111c8072ad1ca6b2dbbc8bb7f271085c719685aec15c2b5c`.

The merge retains actual JSON backing record/array provenance, opaque fields, structural-view handling, lexical stores and scalar extraction. It also retains reached capture getter binding, actual facade presence, the ABSENT / own UNDEFINED distinction, and operation failure snapshots. The shared `copyProperties` now visits actual present fields in own-key order, runs present getters, retains preceding keys on absent branches, preserves unknown host data facts, and returns both copied fields and opaque status. Optional typed host properties retain value / own undefined / absent alternatives. Object.assign applies the same overlay in both analysis modes. No public admission, draft status, IR version or unknown-callable trust policy was changed.

## Actual validation

| Run | Actual result | Meaning |
| --- | --- | --- |
| Candidate, nine original suites | 126 passed / 0 failed / 0 skipped | JSON 35; capture/facade/lookup/presence 53; record getter 38. |
| Substitute exact stage-2 callable source, same seven current suites | 69 passed / 19 failed / 0 skipped | All JSON 35 stay green; capture getter/presence controls detect missing incoming behavior. |
| Substitute exact stage-3 callable source, same seven current suites | 71 passed / 17 failed / 0 skipped | All capture 53 stay green; JSON hidden backing values and cold-IR controls detect missing existing behavior. |
| Candidate, incoming presence controls with an additional unused JSON event declaration | 15 passed / 0 failed / 0 skipped | Both capture and typed host own-property rules hold when data-boundary analysis is enabled. |
| Strict TypeScript, changed analyzer and nine test entries with their dependency closure | 479 source files / 0 diagnostics | Original repository compiler options with strict=true and no emit. Not the whole workspace typecheck. |

All Vitest runs used one worker. The two source substitutions are counterfactual single-module replacements over the current integrated tree, not claims that either entire parent commit was tested. A Vite pre-load override served exact archived stage bytes without writing the candidate. Load observation files prove that the requested module was substituted. The cross-mode control augments authored fixture source with an unused JSON exposure; it preserves all original negative diagnostics and positive cold-IR checks.

The initial cross-mode driver matched only the formatted getter fixture and missed the compact host factory. It executed 12 passing cases but failed to load the host suite. `cross-mode-first-*` and the first config retain that harness error. A whitespace-tolerant pattern then executed all 15. No product failure or success is attributed to the unloaded cases.

`git diff --check` passed. Conflict markers and duplicate ABSENT/fingerprint branches were removed. The root index is intentionally left to the integration owner. Independent review follows this receipt; it is not self-declared acceptance of Sprint 5 or either draft owner specification.
