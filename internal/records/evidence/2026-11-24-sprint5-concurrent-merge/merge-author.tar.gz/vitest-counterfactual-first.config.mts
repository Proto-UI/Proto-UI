import base from "/workspace/scratch/f7b299133482/proto-ui-s5/vitest.config.ts";
import { readFileSync, appendFileSync } from 'node:fs';
const root = "/workspace/scratch/f7b299133482/proto-ui-s5";
const out = "/workspace/scratch/f7b299133482/merge-callable-check";
const label = process.env.S5_CALLABLE_VARIANT;
if (!['ours', 'theirs', 'cross-mode'].includes(label ?? '')) throw new Error('missing explicit source variant');
export default {
  ...base, root,
  plugins: [{
    name: 'sprint5-readonly-merge-counterfactual', enforce: 'pre',
    load(id) {
      const clean = id.split('?')[0];
      if (label !== 'cross-mode' && clean === root + '/packages/compiler/src/callable-effects.ts') {
        appendFileSync(out + '/' + label + '-source-load.txt', clean + '\n');
        return readFileSync(out + '/' + label + '.ts', 'utf8');
      }
      if (label === 'cross-mode' && /\/capture-(?:getter|host)-presence\.test\.ts$/.test(clean)) {
        const code = readFileSync(clean, 'utf8');
        const augmented = code.replace(/(export default definePrototype\(\{ name: '[^']+', setup\(def\) \{)/g,
          '$1\n    def.expose.event("__mergeDataBoundaryProbe", { payload: "json" });');
        if (code === augmented) throw new Error('counterfactual did not enable data boundaries: ' + clean);
        appendFileSync(out + '/cross-mode-source-load.txt', clean + '\n');
        return augmented;
      }
    }
  }, ...(base.plugins ?? [])]
};
