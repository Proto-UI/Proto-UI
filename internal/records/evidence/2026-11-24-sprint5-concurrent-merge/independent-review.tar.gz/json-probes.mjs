import assert from 'node:assert/strict';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
const root='/workspace/scratch/f7b299133482/proto-ui-s5';
const { parsePrototype } = await import(pathToFileURL(path.join(root,'packages/compiler/src/parser.ts')).href);
const { validateIR } = await import(pathToFileURL(path.join(root,'packages/compiler/src/ir-validation.ts')).href);
const p=(setup,body)=>`import {definePrototype,type RunHandle} from '@proto.ui/core';export default definePrototype({name:'review-json',setup(def){def.expose.event('changed',{payload:'json'});${setup}def.event.on('press.commit',run=>{${body}});return r=>r.slot();}});`;
const backing='const backing:{value:string,hidden:string|undefined}={value:"safe",hidden:"safe"};const view:Readonly<{value:string}>=backing;';
const array='const backing={value:"safe",hidden:undefined};const view:{value:string}=backing;const list=[view];';
const cases=[
 {name:'getter-mutates-hidden-field',setup:backing,body:'const copy={...{get read(){backing.hidden=undefined;return 1;}}};run.expose.emit("changed",{view,copy});',expect:false,message:'Outward JSON payload retains'},
 {name:'sequential-getter-mutation-retains-backing',setup:backing,body:'run.expose.emit("changed",{...{get first(){backing.hidden=undefined;return 1;},get child(){return view;}}});',expect:false,message:'Outward JSON payload retains'},
 {name:'getter-throw-retains-write-in-catch-path',setup:backing,body:'try{const copy={...{get first():number{backing.hidden=undefined;throw 7;}}};}catch(error){}run.expose.emit("changed",view);',expect:false,message:'Outward JSON payload retains'},
 {name:'helper-alias-later-write',setup:backing+'const invalidate=(value:{hidden:string|undefined})=>{value.hidden=undefined;};',body:'invalidate(backing);run.expose.emit("changed",view);',expect:false,message:'Outward JSON payload retains'},
 {name:'safe-local-copy-before-original-write',setup:'',body:backing+'const copy={...view};backing.hidden=undefined;run.expose.emit("changed",copy);',expect:true},
 {name:'safe-local-copy-before-getter-write',setup:'',body:backing+'const copy={...view};const unused={...{get invalidate(){backing.hidden=undefined;return 1;}}};run.expose.emit("changed",copy);',expect:true},
 {name:'array-narrowed-element-retains-hidden-field',setup:array,body:'run.expose.emit("changed",{list});',expect:false,message:'Outward JSON payload retains'},
 {name:'array-narrowed-element-later-alias-write',setup:'const backing:{value:string,hidden:string|undefined}={value:"safe",hidden:"safe"};const view:{value:string}=backing;const list=[view];',body:'backing.hidden=undefined;run.expose.emit("changed",{list});',expect:false,message:'Outward JSON payload retains'},
 {name:'array-every-uses-actual-element-provenance',setup:array,body:'list.every(item=>{run.expose.emit("changed",item);return true;});',expect:false,message:'Outward JSON payload retains'},
 {name:'array-every-explicit-safe-scalar',setup:array,body:'list.every(item=>{run.expose.emit("changed",{value:item.value});return true;});',expect:true},
 {name:'scalar-alias-write-invalidates-narrowing',setup:'const backing:{value:string|undefined}={value:"safe"};const alias=backing;',body:'if(backing.value!==undefined){alias.value=undefined;run.expose.emit("changed",{value:backing.value});}',expect:false,message:'declared data boundary'},
 {name:'getter-write-invalidates-scalar-narrowing',setup:'const backing:{value:string|undefined}={value:"safe"};',body:'if(backing.value!==undefined){const unused={...{get invalidate(){backing.value=undefined;return 1;}}};run.expose.emit("changed",{value:backing.value});}',expect:false,message:'declared data boundary'},
 {name:'unknown-helper-sink-rejected',setup:'const forward=(run:RunHandle,value:unknown)=>run.expose.emit("changed",value);',body:'forward(run,{value:"safe"});',expect:false,message:'declared data boundary'},
 {name:'hidden-unknown-cannot-be-structurally-erased',setup:'const original:{value:string,hidden:unknown}={value:"safe",hidden:"safe"};const view:Readonly<{value:string}>=original;',body:'run.expose.emit("changed",view);',expect:false,message:'structural type view cannot hide'},
 {name:'open-dictionary-remains-outside-source-admission',setup:'const backing:{value:string;[key:string]:string}={value:"safe"};const view:Readonly<{value:string}>=backing;',body:'run.expose.emit("changed",view);',expect:false,message:'statically declared fields'},
 {name:'conditional-definite-override-removes-unsafe-field',setup:'const flag=def.state.bool("flag",false);const backing={value:"safe",hidden:undefined};const view:Readonly<{value:string}>=backing;',body:'const input=flag.get()?view:{value:"safe"};run.expose.emit("changed",{...input,hidden:"safe"});',expect:true},
 {name:'unused-getter-override-still-enforces-phase',setup:'const record={get value(){def.expose.value("executed",1);return 9;}};',body:'const unused={...record,value:0};run.expose.emit("changed",{value:1});',expect:false,message:'not permitted in callback'},
];
const findings=[];
for(const c of cases){
 const source=p(c.setup,c.body),r=parsePrototype(source);
 const diagnostics=r.ok?[]:r.diagnostics.map(d=>({code:d.code,message:d.message}));
 assert.equal(r.ok,c.expect,`${c.name}: ${JSON.stringify(diagnostics)}`);
 if(c.message) assert(diagnostics.some(d=>d.message.toLowerCase().includes(c.message.toLowerCase())),`${c.name}: ${JSON.stringify(diagnostics)}`);
 if(r.ok) assert.equal(validateIR(JSON.parse(JSON.stringify(r.value))).ok,true,`${c.name}: legal cold IR`);
 findings.push({name:c.name,ok:r.ok,diagnostics,sourceSha256:createHash('sha256').update(source).digest('hex'),legalColdIrChecked:r.ok});
}
function walk(value,callback){if(!value||typeof value!=='object')return;if(Array.isArray(value)){value.forEach(v=>walk(v,callback));return;}callback(value);Object.values(value).forEach(v=>walk(v,callback));}
const coldCases=[
 {name:'cold-ir-direct-narrow-view',setup:'const original={value:"safe",hidden:undefined};const view:Readonly<{value:string}>=original;',body:'run.expose.emit("changed",{value:view.value});',message:'Outward JSON payload retains'},
 {name:'cold-ir-copied-getter-return',setup:'const original={value:"safe",hidden:undefined};const view:{value:string}=original;const copied={...{get child(){return view;}}};',body:'run.expose.emit("changed",{value:copied.child.value});',message:'Outward JSON payload retains'},
 {name:'cold-ir-array-every-element',setup:array,body:'list.every(item=>{run.expose.emit("changed",{value:item.value});return true;});',message:'Outward JSON payload retains'},
 {name:'cold-ir-forged-scalar-reference-type',setup:'const original={value:"safe",hidden:undefined};const view:Readonly<{value:string}>=original;',body:'run.expose.emit("changed",{value:view.value});',forgeScalar:true},
];
for(const c of coldCases){
 const source=p(c.setup,c.body),parsed=parsePrototype(source);
 assert(parsed.ok,`${c.name}: legal source prerequisite`);
 const ir=JSON.parse(JSON.stringify(parsed.value));let changed=0;
 walk(ir,node=>{if(node.kind==='operation'&&node.operation==='expose.emit'){
  const payload=node.arguments[1];assert.equal(payload.kind,'record');assert.equal(payload.entries[0].value.kind,'member');
  node.arguments[1]=JSON.parse(JSON.stringify(payload.entries[0].value.object));
  if(c.forgeScalar)node.arguments[1].type='string';changed++;
 }});
 assert.equal(changed,1);
 const result=validateIR(ir),diagnostics=result.ok?[]:result.diagnostics.map(d=>({code:d.code,message:d.message}));
 assert.equal(result.ok,false,`${c.name}: forged IR should reject`);
 if(c.message)assert(diagnostics.some(d=>d.message.includes(c.message)),`${c.name}: ${JSON.stringify(diagnostics)}`);
 findings.push({name:c.name,ok:result.ok,diagnostics,sourceSha256:createHash('sha256').update(source).digest('hex'),irSha256:createHash('sha256').update(JSON.stringify(ir)).digest('hex')});
}
console.log(JSON.stringify({kind:'independent-targeted-json-falsification',reviewedSource:{"kind":"independent-merged-source-json-falsification","head":"cde582a260a8a3d646fe4dbd38ac22bb1f71d273","mergeHead":"2df421b1fc55cc0649be6675c0ee46a69ad9316f","source":"packages/compiler/src/callable-effects.ts","sourceSha256":"f151a48fd13b23e2111c8072ad1ca6b2dbbc8bb7f271085c719685aec15c2b5c"},sourceCases:cases.length,coldIrCases:coldCases.length,assertionsPassed:true,findings},null,2));
