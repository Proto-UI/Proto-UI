# Independent callable-effects merge review

Verdict: no new defect established in this bounded merge; supports integration of the exact source below. This is a technical source peer review, not GitHub approval.

- Reviewer: `/root/browser`, not the merge author.
- Frozen source SHA-256: `f151a48fd13b23e2111c8072ad1ca6b2dbbc8bb7f271085c719685aec15c2b5c`.
- Parents: `cde582a260a8a3d646fe4dbd38ac22bb1f71d273` and `2df421b1fc55cc0649be6675c0ee46a69ad9316f`.
- Source is not yet bound to a new merge commit.

## Reasoning

### Both parent scopes retained

The merged entry point still enables retained JSON-data tracking for non-void event outputs, while all direct and copied capture getter calls share reached-capture lookup and phase failure handling. No public admission or contract lifecycle was widened.

### Own key versus own undefined

ABSENT is now consistently used in field/store/capture joins and weak writes. Reading converts it to undefined. copyField branches without invoking a missing getter, preserving a preceding key; an actual UNDEFINED overwrites it. Optional host members retain value, own undefined and absence in both callable and data-boundary modes.

### Retained JSON provenance

Complete record/array fields, structured mutable cells, aliases, helper results, getter writes and thrown stores remain traced. Copies keep unknown backing shape opaque. The outward sink rejects hidden non-data/unknown/nested undefined and cyclic records while preserving explicit scalar snapshots and finite legal copies.

### Capture authority and phase

Only reached captures create capture-getter atoms. Lookup follows the current method/child graph; missing hook identities remain UNKNOWN/ABSENT. Escaped getters traverse the actual returned closures in caller context. States/events presence joins and fingerprints are retained; pre/post contribution exception snapshots remain distinct.

### Shared copy and mutation paths

Object spread and existing admitted Object.assign use the merged own-key overlay, actual getter execution order and store effects. Object.assign keeps aliases/opaque fields for JSON tracking and weak writes for multiple possible targets. Existing callable Object.assign admission is not broadened.

### Independent rejection controls

All 17 unchanged source probes and 4 unchanged cold-IR mutations passed their original assertions. Hidden undefined, unknown helper sinks, erased unknown fields, open dictionaries, illegal callback getters and forged source-free payloads remain rejected; all accepted positive sources pass JSON-round-trip IR validation.

## Evidence and limits

Independently executed the original 17 source probes and 4 cold-IR mutations: all assertions passed, exit 0. Only output provenance metadata changed from the prior reviewer script; fixture bytes, expectations and diagnostics were preserved. Source hash was unchanged after execution.

Independently read the merge author’s 9-file 126/126 run, 15/15 data-mode presence controls, and 479-file strict TypeScript result (0 diagnostics). These are supplied execution evidence, not duplicate independent runs. The same 88-control parent overrides preserve 69/88 and 71/88 respectively; neither parent alone is a valid replacement for the merged scope. Ten retained parent test/contract files were byte-verified.

No full compiler, whole-tree, physical browser, native hardware, public SSR or Sprint acceptance is claimed. The original 250 ms browser retirement journey remains separate. No product source, tests, index, commit, push or GitHub surface was modified.
