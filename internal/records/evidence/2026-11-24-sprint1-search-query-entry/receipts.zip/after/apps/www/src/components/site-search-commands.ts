import { createSiteSearchOwner } from './site-search-owner';
import { createSiteSearchComposition } from './site-search-composition';
import { siteSearchShortcutLabel } from './site-search-shortcut';
import { headerButtonProps, headerResponsiveButtonFeedback } from './site-header-control-recipes';
import type { ExposeStateExternalHandle } from '@proto.ui/module-expose-state';
import searchIcon from '../../../../packages/prototypes/lucide/src/icons/search';
import arrowRightIcon from '../../../../packages/prototypes/lucide/src/icons/arrow-right';
import closeIcon from '../../../../packages/prototypes/lucide/src/icons/x';
import { registerPrototype } from './PrototypePreviewer/registry';
import { PREFERRED_ADAPTER_EVENT, PREFERRED_ADAPTER_KEY } from './adapter-preference';
import { isRuntimeId, type RuntimeId } from './PrototypePreviewer/runtimes/ids';
import {
  createProjectionScopeController,
  type ProjectionScopeCommit,
  type ProjectionScopeController,
  type ProjectionScopeMaterializeRequest,
} from './PrototypePreviewer/projection-scope';
import {
  materializeProjectionCandidate,
  type MaterializedProjectionCandidate,
  type ProjectionMaterializerOptions,
} from './PrototypePreviewer/projection-materializer';
import { collectPrototypeIds, type DemoSpec } from './PrototypePreviewer/demo-types';
import { requireSiteLibraryFamily, type SiteLibraryFamily } from './site-library-family';
import type { SiteSearchFocusRestore } from './site-search-composition';

// These fixed glyphs are required by every Search generation. Keep them in
// the command owner's initial module graph instead of discovering their import
// chain only after the custom element connects. The materializer still owns
// rendering the registered prototypes and committing all three commands.
registerPrototype('lucide-search-icon', searchIcon);
registerPrototype('lucide-x-icon', closeIcon);
registerPrototype('lucide-arrow-right-icon', arrowRightIcon);

export type SearchCommand = 'open' | 'close' | 'retry';
type SearchThemeSource = NonNullable<ProjectionMaterializerOptions['themeSource']>;
type SearchCallbacks = Record<SearchCommand, () => unknown> & { prepare?: () => unknown };
export type SearchCommandParticipant = {
  root: HTMLElement;
  mounts: HTMLElement[];
  bind(callbacks: SearchCallbacks): void;
  open(): void;
  toggle(): void;
  /** Current open state of the public Dialog session. */
  isOpen(): boolean;
  onOpen?(listener: () => void): () => void;
  setRetryDisabled(value: boolean): void;
  focus(command: SearchCommand): void;
  materialize(
    request: ProjectionScopeMaterializeRequest,
    namespace?: string,
    themeSource?: SearchThemeSource
  ): Promise<MaterializedProjectionCandidate[]>;
  materializeDialog(
    request: ProjectionScopeMaterializeRequest,
    namespace?: string,
    options?: {
      themeSource?: SearchThemeSource;
      focusEpoch(): number;
      takeFocusRestore(): SiteSearchFocusRestore | null;
    }
  ): Promise<MaterializedProjectionCandidate>;
  prepareCommit(commit: ProjectionScopeCommit): { publish(): void; rollback(): void };
  dispose(): void;
};
const legacyCommands: SearchCommand[] = ['open', 'close', 'retry'];
const participants = new WeakMap<HTMLElement, SearchCommandParticipant>();
let serial = 0;
const controls = {
  runtime: { label: 'Runtime', options: [], onValueChange() {} },
  family: { label: 'Family', options: [], onValueChange() {} },
  component: { label: 'Component', options: [], onValueChange() {} },
};

/** Website data ownership outlives projection generations; Dialog remains a public composition. */
export function searchCommandParticipant(root: HTMLElement): SearchCommandParticipant {
  const existing = participants.get(root);
  if (existing) return existing;
  const document = root.ownerDocument;
  const view = document.defaultView!;
  const owner = `site-search-${++serial}`;
  const publicComposition = root.dataset.searchComposition === 'command-dialog';
  const commands: SearchCommand[] = publicComposition ? ['open'] : legacyCommands;
  const search = publicComposition ? createSiteSearchOwner(root) : null;
  const dialogMount = publicComposition
    ? root.querySelector<HTMLElement>('[data-search-dialog-mount]')
    : null;
  if (publicComposition && !dialogMount) throw new Error('Public Search dialog mount is missing');
  const mounts = commands.map((command) => {
    const mount = root.querySelector<HTMLElement>(`[data-search-command-mount="${command}"]`);
    if (!mount) throw new Error(`Search ${command} mount is missing`);
    return mount;
  });
  if (dialogMount) mounts.push(dialogMount);
  let callbacks: SearchCallbacks | null = search
    ? {
        open: () => search.session.setOpen(true),
        close: () => search.session.setOpen(false),
        retry: () => search.session.retry(),
        prepare: () => search.prepare(),
      }
    : null;
  let retryDisabled = false;
  let alive = true;
  const subscribers = new Set<() => void>();
  const publishState = () => subscribers.forEach((paint) => paint());
  const focusTargets = new Set<{ command: SearchCommand; active(): boolean; focus(): void }>();
  const homepage = !!root.closest('[data-homepage-runtime]');
  let focusEpoch = 0;
  let dialogFocusEpoch = 0;
  let activeDialogCandidate: MaterializedProjectionCandidate | null = null;
  let rememberedDialogFocus: {
    candidate: MaterializedProjectionCandidate;
    request: SiteSearchFocusRestore;
    replacement?: { owner: string; generation: string };
  } | null = null;
  const onFocus = (event: FocusEvent) => {
    focusEpoch++;
    if (!homepage || event.target === document.body || event.target === document.documentElement)
      return;
    const replacement = rememberedDialogFocus?.replacement;
    if (replacement && event.target instanceof view.HTMLElement) {
      const scope = event.target.closest<HTMLElement>(
        '[data-projection-owner][data-projection-generation]'
      );
      // Focus inside the speculative Dialog is part of its activation.
      // Until the old view retires, it cannot invalidate rollback focus.
      if (
        scope?.dataset.projectionOwner === replacement.owner &&
        scope.dataset.projectionGeneration === replacement.generation
      )
        return;
    }
    dialogFocusEpoch++;
  };
  document.addEventListener('focusin', onFocus, true);
  let dialogCloseEpoch = 0;
  const offDialogFocus =
    homepage && search
      ? search.session.subscribe(() => {
          if (!rememberedDialogFocus || search.session.read().open) return;
          dialogCloseEpoch++;
          rememberedDialogFocus = null;
        })
      : undefined;
  const rememberedFocus = new Map<
    number,
    { command: SearchCommand; origin: Element | null; epoch: number }
  >();
  let deferredFocus: { command: SearchCommand; origin: Element | null; epoch: number } | null =
    null;
  const focus = (command: SearchCommand) => {
    if (!alive) return;
    for (const target of focusTargets)
      if (target.command === command && target.active()) {
        deferredFocus = null;
        target.focus();
        return;
      }
    deferredFocus = { command, origin: document.activeElement, epoch: focusEpoch };
  };
  const content = (
    command: SearchCommand,
    family: SiteLibraryFamily,
    runtime: RuntimeId,
    isActive: () => boolean
  ): DemoSpec => {
    const label = root.dataset[`${command}Label`] || command;
    const icon = command === 'open' ? 'search' : command === 'close' ? 'x' : null;
    const isHeaderOpen = command === 'open' && !!root.closest('[data-site-header]');
    const props = isHeaderOpen
      ? headerButtonProps(family, 'default')
      : family === 'bootstrap-2-3-2'
        ? { variant: 'default', size: command === 'open' ? 'default' : 'small' }
        : {
            variant:
              family === 'brutalist' ? 'surface' : command === 'retry' ? 'secondary' : 'ghost',
            size: command === 'open' ? 'default' : 'sm',
          };
    return {
      type: 'demo',
      root: {
        kind: 'proto',
        prototypeId: `${family}-button`,
        ref: 'search-command',
        props: { ...props, disabled: !callbacks || (command === 'retry' && retryDisabled) },
        surfaceStyle:
          command === 'open'
            ? {
                width: 'var(--site-search-trigger-width, 2.75rem)',
                minWidth: '0',
                maxWidth: '100%',
                height: 'var(--site-control-height, 2.75rem)',
                minHeight: 'var(--site-control-height, 2.75rem)',
                paddingInline: 'var(--site-search-trigger-padding, 0)',
                justifyContent: 'var(--site-search-trigger-justify, center)',
                ...(isHeaderOpen ? headerResponsiveButtonFeedback(family) : {}),
              }
            : { minHeight: '2.75rem' },
        className:
          command === 'close'
            ? 'search-toolbar__close'
            : command === 'retry'
              ? 'search-failure__retry'
              : undefined,
        children: [
          ...(icon
            ? [
                {
                  kind: 'box' as const,
                  attrs: { 'aria-hidden': 'true' },
                  children: [
                    {
                      kind: 'proto' as const,
                      prototypeId: `lucide-${icon}-icon`,
                      props: { size: 16 },
                    },
                  ],
                },
              ]
            : []),
          { kind: 'box', className: 'sr-only', children: [label] },
          {
            kind: 'box',
            attrs: { 'aria-hidden': 'true' },
            className:
              command === 'open'
                ? 'site-search-label sl-hidden md:sl-block'
                : command === 'close'
                  ? 'search-toolbar__close-label'
                  : undefined,
            children: [label],
          },
          ...(command === 'open'
            ? [
                {
                  kind: 'box' as const,
                  attrs: { 'aria-hidden': 'true' },
                  className: 'site-search-shortcut sl-hidden md:sl-flex',
                  children: [siteSearchShortcutLabel(root.dataset.ctrlLabel || 'Ctrl')],
                },
              ]
            : []),
        ],
      },
      setup(context) {
        const button = context.refs['search-command'];
        button.dataset.searchCommand = command;
        button.dataset.siteControlFamily = family;
        if (command === 'open') {
          button.dataset.openModal = '';
          button.setAttribute(
            'aria-keyshortcuts',
            /(Mac|iPhone|iPod|iPad)/i.test(view.navigator.userAgent) ? 'Meta+K' : 'Control+K'
          );
        }
        if (command === 'close') button.dataset.closeModal = '';
        let live = true;
        let queued = false;
        // Consume public Button facts. Search owns resource preparation only;
        // it does not recreate hover/focus semantics or an activation route.
        const intentSubscriptions: Array<() => void> = [];
        if (command === 'open') {
          const exposes = context.api.getExposes('search-command');
          for (const key of ['hovered', 'focusVisible']) {
            const fact = exposes?.[key] as ExposeStateExternalHandle<boolean> | undefined;
            if (!fact?.subscribe) continue;
            intentSubscriptions.push(
              fact.subscribe((event) => {
                if (event.type !== 'next' || event.next !== true) return;
                queueMicrotask(() => {
                  if (alive && live && isActive()) callbacks?.prepare?.();
                });
              })
            );
          }
        }
        const activate = () => {
          // Both props and native-dialog focus must happen after the WC callback exits.
          queueMicrotask(() => {
            if (alive && live && isActive() && !(command === 'retry' && retryDisabled))
              callbacks?.[command]();
          });
        };
        const click = (event: Event) => {
          if (event instanceof view.CustomEvent) activate();
        };
        const paint = () => {
          if (queued) return;
          queued = true;
          queueMicrotask(() => {
            queued = false;
            if (!alive || !live) return;
            // The composition retains surfaceStyle; send the complete authored props bag.
            context.api.setProps('search-command', {
              ...props,
              disabled: !callbacks || (command === 'retry' && retryDisabled),
              ...(runtime === 'wc' ? {} : { onClick: activate }),
            });
          });
        };
        if (runtime === 'wc') button.addEventListener('click', click);
        const focusTarget = {
          command,
          active: isActive,
          focus: () => {
            context.api.call('search-command', 'focusSelf');
          },
        };
        focusTargets.add(focusTarget);
        subscribers.add(paint);
        paint();
        return () => {
          live = false;
          for (const unsubscribe of intentSubscriptions) unsubscribe();
          subscribers.delete(paint);
          focusTargets.delete(focusTarget);
          button.removeEventListener('click', click);
        };
      },
    };
  };
  const handle = {
    root,
    mounts,
    open() {
      if (alive) callbacks?.open();
    },
    toggle() {
      if (!alive) return;
      if (search) search.session.setOpen(!search.session.read().open);
      else callbacks?.open();
    },
    isOpen() {
      return !!search?.session.read().open;
    },
    onOpen(listener: () => void) {
      if (!search) return () => {};
      let wasOpen = search.session.read().open;
      return search.session.subscribe(() => {
        const isOpen = search.session.read().open;
        if (isOpen && !wasOpen) listener();
        wasOpen = isOpen;
      });
    },
    bind(next: SearchCallbacks) {
      callbacks = next;
      publishState();
    },
    setRetryDisabled(value: boolean) {
      retryDisabled = value;
      publishState();
    },
    focus,
    async materialize(
      request: ProjectionScopeMaterializeRequest,
      namespace = 'homepage',
      themeSource?: SearchThemeSource
    ) {
      rememberedFocus.clear();
      const origin = document.activeElement;
      const focusedCommand =
        origin instanceof view.HTMLElement && root.contains(origin)
          ? (origin.dataset.searchCommand as SearchCommand | undefined)
          : undefined;
      if (focusedCommand && commands.includes(focusedCommand))
        rememberedFocus.set(request.generation, {
          command: focusedCommand,
          origin,
          epoch: focusEpoch,
        });
      const family = request.selection.projectionFamilyId as SiteLibraryFamily;
      const runtime = request.selection.runtimeId as RuntimeId;
      const outcomes = await Promise.allSettled([
        ...commands.map(async (command, index) => {
          let candidate: MaterializedProjectionCandidate | undefined;
          const ownerId = `${owner}-${namespace}-${command}`;
          mounts[index]!.dataset.projectionOwner = ownerId;
          candidate = await materializeProjectionCandidate(request, {
            mount: mounts[index]!,
            themeSource,
            ownerId,
            componentId: 'button',
            controls,
            controlIds: [],
            content: {
              demo: content(
                command,
                family,
                runtime,
                () =>
                  !!candidate &&
                  candidate.host.dataset.projectionGenerationState === 'active' &&
                  !candidate.host.inert
              ),
              recipe: {
                id: `website-search-${command}`,
                prototypeIds:
                  command === 'retry'
                    ? [`${family}-button`]
                    : [`${family}-button`, `lucide-${command === 'open' ? 'search' : 'x'}-icon`],
                rootPrototypeId: `${family}-button`,
              },
            },
          });
          return candidate;
        }),
      ]);
      const candidates = outcomes.flatMap((outcome) =>
        outcome.status === 'fulfilled' ? [outcome.value] : []
      );
      const failure = outcomes.find((outcome) => outcome.status === 'rejected');
      if (failure?.status === 'rejected') {
        await Promise.allSettled(candidates.map((candidate) => candidate.dispose()));
        throw failure.reason;
      }
      return candidates;
    },
    async materializeDialog(
      request: ProjectionScopeMaterializeRequest,
      namespace = 'homepage',
      options?: {
        themeSource?: SearchThemeSource;
        focusEpoch(): number;
        takeFocusRestore(): SiteSearchFocusRestore | null;
      }
    ) {
      if (!search || !dialogMount) throw new Error('Public Search owner is missing');
      const family = request.selection.projectionFamilyId as SiteLibraryFamily;
      const focusCloseEpoch = dialogCloseEpoch;
      let pendingFocusRestore = rememberedDialogFocus?.request ?? null;
      let candidate: MaterializedProjectionCandidate | undefined;
      let activated = false;
      let locked = false;
      const current = () =>
        !!candidate &&
        candidate.host.dataset.projectionGenerationState === 'active' &&
        !candidate.host.inert;
      const composition = createSiteSearchComposition({
        family,
        shadcnStyle: root.dataset.searchStyle === 'new-york-v4' ? 'new-york-v4' : 'rhea',
        session: search.session,
        copy: search.copy,
        isCurrent: current,
        retainsOpenWhileLocked: () => homepage && activated && locked,
        onFailure: (error) => {
          if (current()) search.fail(error);
        },
        focusEpoch: options?.focusEpoch ?? (() => dialogFocusEpoch),
        takeFocusRestore:
          options?.takeFocusRestore ??
          (() => {
            const pending = pendingFocusRestore;
            pendingFocusRestore = null;
            return focusCloseEpoch === dialogCloseEpoch ? pending : null;
          }),
      });
      const ids = new Set<string>();
      collectPrototypeIds(composition.demo.root, ids);
      const ownerId = `${owner}-${namespace}-dialog`;
      dialogMount.dataset.projectionOwner = ownerId;
      candidate = await materializeProjectionCandidate(request, {
        mount: dialogMount,
        themeSource: options?.themeSource,
        ownerId,
        componentId: 'dialog',
        controls,
        controlIds: [],
        content: {
          demo: composition.demo,
          recipe: {
            id: 'website-search-command-dialog',
            prototypeIds: [...ids],
            rootPrototypeId: `${family}-dialog-root`,
          },
        },
      });
      const prepared = candidate;
      return {
        ...prepared,
        activate() {
          // Docs commits its command and Dialog with independent controllers.
          // The command's published generation cannot identify the Dialog
          // owner being replaced; follow the actual activated candidate.
          const replacesOpenDialog =
            !activated &&
            !!activeDialogCandidate &&
            activeDialogCandidate !== prepared &&
            search.session.read().open;
          if (replacesOpenDialog && homepage && rememberedDialogFocus)
            rememberedDialogFocus.replacement = {
              owner: ownerId,
              generation: String(request.generation),
            };
          prepared.activate();
          activeDialogCandidate = prepared;
          activated = true;
          // The opener-return restore is armed on every activation, not only
          // on a generation swap. The public Dialog's own restore targets the
          // pre-activation focus entry; a shortcut open (Ctrl+K) starts from
          // the document, so without this callback the close would leave
          // focus on the document instead of the Search opener.
          composition.activate((panel) => {
            const origin = document.activeElement;
            const epoch = focusEpoch;
            // Restore to the opener only when focus was inside the dialog
            // content at close. A focus that already fell to the document
            // (body/html) or moved to a newer external control keeps that
            // landing rather than being pulled back to the Search opener.
            if (!origin || !panel?.contains(origin)) return;
            return () => {
              const active = document.activeElement;
              if (
                epoch === focusEpoch &&
                (active === origin ||
                  active === document.body ||
                  active === document.documentElement)
              )
                focus('open');
            };
          });
        },
        setLocked(nextLocked: boolean) {
          if (homepage && activated) {
            if (nextLocked && current()) {
              // The page transaction locks the retained projection before it
              // prepares the replacement. Read its owned focus before inert
              // can move focus back to the document.
              const origin = document.activeElement;
              const control =
                origin instanceof view.HTMLElement
                  ? origin.closest<HTMLElement>('[data-demo-ref]')
                  : null;
              rememberedDialogFocus =
                search.session.read().open &&
                control?.dataset.projectionOwner === ownerId &&
                control.dataset.projectionGeneration === String(request.generation) &&
                control.dataset.demoRef
                  ? {
                      candidate: prepared,
                      request: { ref: control.dataset.demoRef, origin, epoch: dialogFocusEpoch },
                    }
                  : null;
            }
          }
          locked = nextLocked;
          const retainedFocus = locked ? null : rememberedDialogFocus;
          const result = prepared.setLocked?.(locked);
          if (locked || !homepage || !activated) return result;
          const resume = () => {
            if (!alive || !prepared.host.isConnected || !current()) return;
            composition.activate();
            if (retainedFocus?.candidate !== prepared || rememberedDialogFocus !== retainedFocus)
              return;
            rememberedDialogFocus = null;
            if (document.activeElement !== retainedFocus.request.origin)
              composition.restoreFocus(retainedFocus.request);
          };
          if (result) return result.then(resume);
          resume();
        },
        dispose() {
          if (activeDialogCandidate === prepared) activeDialogCandidate = null;
          if (rememberedDialogFocus?.candidate === prepared) rememberedDialogFocus = null;
          return prepared.dispose();
        },
      };
    },
    prepareCommit(commit: ProjectionScopeCommit) {
      const names = [
        'data-search-runtime',
        'data-search-family',
        'data-search-generation',
        'data-search-view',
      ];
      const previous = names.map((name) => [name, root.getAttribute(name)] as const);
      let published = false;
      return {
        publish() {
          root.dataset.searchRuntime = commit.selection.runtimeId;
          root.dataset.searchFamily = commit.selection.projectionFamilyId;
          root.dataset.searchGeneration = String(commit.generation);
          root.dataset.searchView = 'ready';
          published = true;
          const target = deferredFocus ?? rememberedFocus.get(commit.generation);
          rememberedFocus.delete(commit.generation);
          queueMicrotask(() => {
            if (
              alive &&
              published &&
              target &&
              target.epoch === focusEpoch &&
              (document.activeElement === target.origin || document.activeElement === document.body)
            )
              focus(target.command);
          });
        },
        rollback() {
          published = false;
          rememberedFocus.delete(commit.generation);
          for (const [name, value] of previous) {
            if (value === null) root.removeAttribute(name);
            else root.setAttribute(name, value);
          }
        },
      };
    },
    dispose() {
      alive = false;
      callbacks = null;
      offDialogFocus?.();
      activeDialogCandidate = null;
      rememberedDialogFocus = null;
      search?.dispose();
      subscribers.clear();
      focusTargets.clear();
      rememberedFocus.clear();
      document.removeEventListener('focusin', onFocus, true);
      participants.delete(root);
    },
  };
  participants.set(root, handle);
  return handle;
}

/** Docs-only Search scope. Homepage contributes its candidates to the page controller. */
export function initDocumentationSearchCommands(participant: SearchCommandParticipant) {
  const { root } = participant;
  if (root.closest('[data-homepage-runtime]'))
    throw new Error('Homepage Search must use its page transaction');
  const document = root.ownerDocument;
  let runtime: RuntimeId = 'wc';
  try {
    const stored = document.defaultView?.localStorage.getItem(PREFERRED_ADAPTER_KEY);
    if (isRuntimeId(stored)) runtime = stored;
  } catch {
    /* Optional storage. */
  }
  const family = requireSiteLibraryFamily(root.dataset.searchInitialFamily ?? 'shadcn');
  let alive = true;
  // The same owner supplies the initial theme and later color-mode updates.
  // Each candidate keeps its own lease, including the retained rollback view.
  const themeSource: SearchThemeSource = { scope: root, family, isCurrent: () => alive };
  let attempt = 0;
  const retired = new Set<Promise<void>>();
  let destroyPromise: Promise<void> | null = null;
  // The public Dialog is only needed once the user opens Search. Defer its
  // prototype loading and rendering so the open command can activate within
  // the initial-ready budget instead of waiting for the full dialog tree.
  let dialogController: ProjectionScopeController | null = null;
  const retire = (previous: ProjectionScopeController) => {
    const cleanup = previous.destroy();
    retired.add(cleanup);
    void cleanup.then(
      () => retired.delete(cleanup),
      (error) => {
        retired.delete(cleanup);
        console.error('[SiteSearch] retired projection cleanup failed.', error);
      }
    );
  };
  // Bounded focus continuity for the public Dialog across a generation swap.
  // The restore request is armed only while the Dialog is actually open, so a
  // runtime switch made while the Dialog is closed cannot change the next
  // fresh open's entry behaviour.  A newer swap replaces the pending request,
  // so a superseded swap can never restore focus into a later generation.
  //
  // The epoch advances on every focus change so focus that moved after the
  // swap began wins over the restore, even when that focus later fell back
  // to the document.  Focus falling back to the document is not a focus
  // change of its own and does not advance the epoch.
  let dialogFocusEpoch = 0;
  const onDialogFocus = (event: FocusEvent) => {
    const target = event.target;
    if (!target) return;
    if (target === root.ownerDocument.body || target === root.ownerDocument.documentElement) return;
    dialogFocusEpoch++;
  };
  document.addEventListener('focusin', onDialogFocus, true);
  let pendingDialogFocus: SiteSearchFocusRestore | null = null;
  const createDialog = () => {
    const namespace = `docs-dialog-${++attempt}`;
    return createProjectionScopeController({
      initialSelection: { runtimeId: runtime, projectionFamilyId: family },
      async materialize(request) {
        return participant.materializeDialog(request, namespace, {
          themeSource,
          focusEpoch: () => dialogFocusEpoch,
          takeFocusRestore: () => {
            const pending = pendingDialogFocus;
            pendingDialogFocus = null;
            return pending;
          },
        });
      },
    });
  };
  const ensureDialog = () => {
    if (!alive) return;
    if (dialogController) {
      const snapshot = dialogController.getSnapshot();
      // A pending or committed Dialog already owns this open intent. An
      // uncommitted failure returns to idle and needs a fresh projection
      // attempt, while the independent Search data/session owner stays live.
      if (snapshot.generation !== 0 || snapshot.phase !== 'idle') return;
      retire(dialogController);
    }
    dialogController = createDialog();
    observe(dialogController.start(), dialogController);
  };
  const offDialogOpen = participant.onOpen?.(() => ensureDialog());
  const create = () => {
    const namespace = `docs-${++attempt}`;
    return createProjectionScopeController({
      initialSelection: { runtimeId: runtime, projectionFamilyId: family },
      async materialize(request) {
        const candidates = await participant.materialize(request, namespace, themeSource);
        return {
          activate() {
            candidates.forEach((candidate) => candidate.activate());
          },
          setLocked(locked) {
            candidates.forEach((candidate) => candidate.setLocked?.(locked));
          },
          async dispose() {
            const results = await Promise.allSettled(
              candidates.map((candidate) => candidate.dispose())
            );
            const failed = results.find((result) => result.status === 'rejected');
            if (failed?.status === 'rejected') throw failed.reason;
          },
        };
      },
      prepareCommit: participant.prepareCommit,
    });
  };
  let controller = create();
  const observe = (pending: Promise<unknown>, owner = controller) =>
    pending.then(
      (snapshot) => {
        if (
          alive &&
          owner === dialogController &&
          owner.getSnapshot().phase === 'ready' &&
          controller.getSnapshot().phase === 'ready'
        )
          root.dataset.searchView = 'ready';
        return snapshot;
      },
      (error) => {
        if (!alive) return;
        const dialogFailure = owner === dialogController;
        if (!dialogFailure && owner !== controller) return;
        root.dataset.searchView = dialogFailure
          ? 'unavailable'
          : controller.getSnapshot().generation
            ? 'retained'
            : 'unavailable';
        console.error('[SiteSearch] Search command projection failed.', error);
      }
    );
  const refresh = () => {
    if (!alive) return;
    if (controller.getSnapshot().generation === 0 && controller.getSnapshot().phase === 'idle') {
      const previous = controller;
      controller = create();
      retire(previous);
      return observe(controller.start());
    }
    return observe(controller.request({ runtimeId: runtime, projectionFamilyId: family }));
  };
  const onPreference = (event: Event) => {
    const next = (event as CustomEvent<{ adapter?: unknown }>).detail?.adapter;
    if (isRuntimeId(next)) {
      runtime = next;
      void refresh();
      if (dialogController) {
        const snapshot = dialogController.getSnapshot();
        if (snapshot.generation === 0 && snapshot.phase === 'idle') {
          // request() is deliberately unavailable after an uncommitted start
          // failure. Restart with the latest requested runtime coordinates.
          ensureDialog();
          return;
        }
        const doc = root.ownerDocument;
        const view = doc.defaultView;
        const dialogMount = root.querySelector<HTMLElement>('[data-search-dialog-mount]');
        const owner = dialogMount?.dataset.projectionOwner;
        const focused = doc.activeElement;
        // The restore is armed only while the Dialog is genuinely open and
        // one of its own controls holds focus.  A runtime switch made while
        // the Dialog is closed must leave the next fresh open's automatic
        // entry focus untouched.
        const openNow = participant.isOpen();
        if (
          openNow &&
          view &&
          focused instanceof view.HTMLElement &&
          owner &&
          focused.dataset.projectionOwner === owner &&
          focused.dataset.demoRef
        ) {
          pendingDialogFocus = {
            ref: focused.dataset.demoRef,
            origin: focused,
            epoch: dialogFocusEpoch,
          };
        } else {
          pendingDialogFocus = null;
        }
        observe(
          dialogController.request({ runtimeId: runtime, projectionFamilyId: family }),
          dialogController
        );
      }
    }
  };
  document.addEventListener(PREFERRED_ADAPTER_EVENT, onPreference);
  return {
    ready: observe(controller.start()),
    refresh,
    destroy(): Promise<void> {
      if (destroyPromise) return destroyPromise;
      if (!alive) return Promise.resolve();
      alive = false;
      offDialogOpen?.();
      document.removeEventListener('focusin', onDialogFocus, true);
      document.removeEventListener(PREFERRED_ADAPTER_EVENT, onPreference);
      // These controllers own independent leases. A failed opener must not
      // prevent Dialog retirement; keep the existing first-failure policy.
      destroyPromise = Promise.allSettled([controller.destroy(), dialogController?.destroy()]).then(
        async (results) => {
          await Promise.allSettled([...retired]);
          const failed = results.find((result) => result.status === 'rejected');
          if (failed?.status === 'rejected') throw failed.reason;
        }
      );
      return destroyPromise;
    },
  };
}
