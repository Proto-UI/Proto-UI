from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

REPO = Path('/workspace/scratch/40da939bdb35/anatomy-recovered')
OUT = Path(__file__).parent
SOURCES = [
    'packages/modules/anatomy/src/impl.ts',
    'packages/modules/anatomy/test/subscriber-fanout.test.ts',
    'packages/runtime/test/contract/anatomy.order-fanout-cost.contract.test.ts',
]
ENV = dict(os.environ, NODE_OPTIONS='--max-old-space-size=768')
BASE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()


def source_hashes():
    return {name: hashlib.sha256((REPO / name).read_bytes()).hexdigest() for name in SOURCES}


def run(name, command, expected=0, timeout=120, test_report=False):
    before = source_hashes()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (OUT / (name + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=REPO, env=ENV, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
    receipt = {
        'role': 'fresh-execution-after-executor-replacement',
        'baseRevision': BASE,
        'command': command,
        'startedAt': started,
        'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'exitCode': result.returncode,
        'expectedExitCode': expected,
        'sourceBefore': before,
        'sourceAfter': source_hashes(),
        'environment': {'node': '24.22.3', 'pnpm': '10.32.1', 'NODE_OPTIONS': ENV['NODE_OPTIONS']},
    }
    if test_report and (OUT / (name + '.json')).exists():
        report = json.loads((OUT / (name + '.json')).read_text())
        receipt['results'] = {key: report.get(key) for key in ['numTotalTests', 'numPassedTests', 'numFailedTests', 'numPendingTests']}
        receipt['files'] = [str(Path(row['name']).relative_to(REPO)) for row in report['testResults']]
        receipt['failures'] = [case['fullName'] for row in report['testResults'] for case in row['assertionResults'] if case['status'] == 'failed']
    (OUT / (name + '.receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'name': name, 'exitCode': result.returncode, 'results': receipt.get('results'), 'files': len(receipt.get('files', []))}), flush=True)
    assert receipt['sourceBefore'] == receipt['sourceAfter'], 'Source changed during execution'
    assert result.returncode == expected, name
    return receipt


def tests(name, files, pattern=None, expected=0):
    command = ['corepack', 'pnpm@10.32.1', 'exec', 'vitest', 'run', '--no-cache', '--maxWorkers=1', '--no-file-parallelism', *files]
    if pattern:
        command += ['-t', pattern]
    command += ['--reporter=default', '--reporter=json', '--outputFile.json=' + str(OUT / (name + '.json'))]
    return run(name, command, expected=expected, test_report=True)


run('format', ['corepack', 'pnpm@10.32.1', 'exec', 'prettier', '--check', *SOURCES])
run('diff-check', ['git', 'diff', '--check'])
tests('candidate-anatomy', ['packages/modules/anatomy/test', 'packages/runtime/test/contract/anatomy'])
tests('candidate-adapters', [
    'packages/adapters/react/test/anatomy.integration.test.ts',
    'packages/adapters/react/test/context-anatomy.test.ts',
    'packages/adapters/vue/test/anatomy.integration.test.ts',
    'packages/adapters/vue/test/context-anatomy.test.ts',
    'packages/adapters/vue2/test/anatomy.integration.test.ts',
    'packages/adapters/web-component/test/anatomy.integration.test.ts',
    'packages/adapters/web-component/test/contract/anatomy.runtime-access.v0.contract.test.ts',
    'packages/adapters/base/test/logical-parent-authority.test.ts',
    'packages/adapters/web-component/test/anatomy-reparent-rollback.test.ts',
    'packages/adapters/web-component/test/table-retained-membership.test.ts',
    'packages/adapters/web-component/test/table-reentrant-projection.test.ts',
])
run('focused-types', ['corepack', 'pnpm@10.32.1', 'exec', 'tsc', '-p', str(OUT / 'focused-types.json'), '--pretty', 'false'])

# A bounded temporary mutation proves why comparator replacement must advance
# the epoch. This is not a source repair; candidate bytes are restored in finally.
source = REPO / SOURCES[0]
candidate = source.read_bytes()
guard = b'      if (entry && reads) reads.comparisonEpoch++;\n'
assert candidate.count(guard) == 1
try:
    source.write_bytes(candidate.replace(guard, b''))
    mutant = tests('epoch-guard-mutant', [SOURCES[1]], 'former comparator result', expected=1)
    assert mutant['results']['numFailedTests'] == 1
finally:
    source.write_bytes(candidate)
assert source.read_bytes() == candidate
restored = {'sourceSha256': source_hashes(), 'restored': True, 'note': 'The unsafe mutant source is absent from the committed candidate.'}
(OUT / 'restored-source.json').write_text(json.dumps(restored, indent=2) + '\n')
print(json.dumps(restored), flush=True)
