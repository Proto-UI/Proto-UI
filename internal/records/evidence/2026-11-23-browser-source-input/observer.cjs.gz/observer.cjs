// Diagnostic-only Playwright observer; it does not modify application sources or deadlines.
const fs = require('node:fs');
const { createRequire } = require('node:module');
const root = '/tank/shared/projects/proto-ui-agent/sprint5-ready-75d5e28a';
const projectRequire = createRequire(root + '/apps/www/package.json');
const { chromium } = projectRequire('playwright-core');
const trace = process.env.PUI_OBSERVER_TRACE;
if (!trace) throw new Error('PUI_OBSERVER_TRACE is required');
let sequence = 0;
const append = (record) => fs.appendFileSync(trace, JSON.stringify({ sequence: ++sequence, observerNow: Date.now(), ...record }) + '\n');
const observe = String.raw`(() => {
  const outer = window === window.top;
  const emit = (record) => {
    try {
      const pending = globalThis.__sprint5Observe({ time: performance.timeOrigin + performance.now(), outer, url: location.href, ...record });
      pending?.catch(() => {});
    } catch {}
  };
  emit({ kind: 'document-init' });
  addEventListener('message', (event) => {
    const data = event.data;
    if (data && typeof data.type === 'string' && /^(preview-|dispose|disposed|cleanup-error)/.test(data.type)) {
      emit({ kind: 'message', type: data.type, revision: data.revision, profile: data.profile, origin: event.origin, fromParent: event.source === parent });
    }
  }, true);
  for (const event of ['pagehide', 'unload', 'visibilitychange']) addEventListener(event, () => emit({ kind: event, visibility: document.visibilityState }));
  if (!outer) return;
  for (const event of ['input', 'change', 'click', 'toggle']) addEventListener(event, (entry) => {
    const element = entry.target instanceof Element ? entry.target.closest('[data-compiler-run],[data-compiler-cancel],[data-compiler-target],[data-source-text],[data-source-editor],[data-compiler-panel]') : null;
    if (!element) return;
    const panel = element.closest('pui-browser-compiler');
    emit({ kind: 'action', event, target: element.tagName, attributes: Object.keys(element.dataset), phase: panel?.dataset.compilerPhase, revision: panel?.dataset.compilerRevision, valueLength: typeof element.value === 'string' ? element.value.length : null, sourceRejectedProbe: typeof element.value === 'string' && element.value.startsWith("throw new Error('must-not-evaluate');"), scrollY, visibility: document.visibilityState });
  }, true);
  const identities = new WeakMap(); let nextFrame = 0, previous = '';
  const snapshot = () => {
    const panel = document.querySelector('pui-browser-compiler');
    if (!panel) return;
    const value = { phase: panel.dataset.compilerPhase, revision: panel.dataset.compilerRevision, scrollY, viewportHeight: innerHeight, visibility: document.visibilityState, frames: [...panel.querySelectorAll('iframe')].map(frame => {
      if (!identities.has(frame)) identities.set(frame, ++nextFrame);
      const bounds = frame.getBoundingClientRect();
      return { id: identities.get(frame), hidden: frame.hidden, connected: frame.isConnected, display: getComputedStyle(frame).display, cssVisibility: getComputedStyle(frame).visibility, bounds: { top: bounds.top, bottom: bounds.bottom, height: bounds.height, width: bounds.width }, revision: frame.srcdoc.match(/"revision":"([^"]+)"/)?.[1] };
    }) };
    const current = JSON.stringify(value);
    if (current !== previous) { previous = current; emit({ kind: 'panel-state', ...value }); }
  };
  new MutationObserver(snapshot).observe(document, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-compiler-phase', 'data-compiler-revision', 'hidden'] });
  addEventListener('scroll', snapshot, { passive: true });
  snapshot();
})();`;
const launch = chromium.launch.bind(chromium);
chromium.launch = async function (...arguments_) {
  append({ kind: 'launch', options: arguments_[0] });
  const browser = await launch(...arguments_);
  const newPage = browser.newPage.bind(browser);
  browser.newPage = async function (...options) {
    const page = await newPage(...options);
    await page.exposeBinding('__sprint5Observe', ({ frame }, payload) => append({ frameUrl: frame.url(), ...payload }));
    await page.addInitScript({ content: observe });
    for (const kind of ['frameattached', 'framenavigated', 'framedetached']) page.on(kind, frame => append({ kind, frameUrl: frame.url() }));
    return page;
  };
  return browser;
};
