// @vitest-environment node
import { revealHeaderPreferences } from './site-header-browser';
import { observeContentsWheel } from './contents-wheel-evidence';
import {
  prepareUtilityFamilyReadObservation,
  settleFamilyQueryBatch,
} from './family-query-observer';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { installDocsCallTimingObserver } from '../../../../test/helpers/docs-query-timing.mjs';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {
  captureHeaderPreferenceLease,
  inspectHeaderPreferenceLease,
  headerPreferenceLeaseIssues,
  measureHeaderPreferenceFocusRing,
} from './site-header-breakpoint-evidence';
import type { Browser, ElementHandle, JSHandle, Page } from 'playwright-core';
import type * as SidebarCurrentVisibility from '../../../components/site-sidebar-current-visibility';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { launchBrowser, RUNTIMES, startServer, stopServer } from './browser-harness';
const LABELS = { wc: 'Web Components', react: 'React', vue: 'Vue', vue2: 'Vue 2' } as const;
const familyQueryMode = process.env.PROTO_UI_FAMILY_QUERY_MODE ?? 'hybrid';
if (!['hybrid', 'native-only', 'node-only'].includes(familyQueryMode))
  throw new Error('Unknown family query observation mode');
let browser: Browser;
let baseUrl: string;
beforeAll(async () => {
  baseUrl = await startServer('/zh-cn/');
  browser = await launchBrowser();
}, 150_000);
afterAll(async () => {
  await browser?.close();
  await stopServer();
}, 60_000);
async function ready(page: Page, runtime: string) {
  await page.waitForFunction(
    (target) => {
      const page = document.querySelector<HTMLElement>('[data-homepage-runtime]');
      const demo = document.querySelector<HTMLElement>('[data-home-showcase]');
      return (
        page?.dataset.runtimeState === 'ready' &&
        page.dataset.runtime === target &&
        demo?.dataset.runnerState === 'ready' &&
        demo.dataset.runnerRuntime === target
      );
    },
    runtime,
    { timeout: 30_000 }
  );
}
async function switchRuntime(page: Page, runtime: keyof typeof LABELS) {
  await revealHeaderPreferences(page);
  const trigger = page.locator(
    '[data-homepage-runtime] [data-projection-control="runtime"] [role="combobox"]'
  );
  await trigger.click();
  const id = await trigger.getAttribute('aria-controls');
  expect(id).toBeTruthy();
  await page
    .locator(`[id=${JSON.stringify(id)}]`)
    .getByRole('option', { name: LABELS[runtime], exact: true })
    .click();
  await ready(page, runtime);
}

describe.sequential('Homepage end-to-end dogfood boundary', () => {
  it('switches every registered homepage group through real adapters, preserving native anchors and theme', async () => {
    const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
    const page = await context.newPage();
    const errors: string[] = [];
    page.on('pageerror', (error) => errors.push(error.message));
    try {
      await page.goto(`${baseUrl}/zh-cn/`, { waitUntil: 'networkidle' });
      await ready(page, 'wc');
      const fallbackLinks = await page.locator('[data-homepage-fallback] a').evaluateAll((links) =>
        links.map((link) => ({
          href: link.getAttribute('href'),
          text: link.textContent?.trim(),
          target: link.getAttribute('target'),
        }))
      );
      expect(fallbackLinks.length).toBeGreaterThan(5);
      expect(
        await page.locator('[data-home-showcase] [data-projection-control="runtime"]').count()
      ).toBe(0);
      for (const runtime of [...RUNTIMES, 'react', 'wc'] as const) {
        await switchRuntime(page, runtime);
        const groups = await page.locator('[data-homepage-actions]').evaluateAll((roots) =>
          roots.map((root) => {
            const active = root.querySelectorAll<HTMLElement>(
              '[data-projection-generation-state="active"]'
            );
            const surfaces = [
              ...(active[0]?.querySelectorAll<HTMLElement>('[data-projection-prototype]') ?? []),
            ];
            return {
              activeCount: active.length,
              runtime:
                active[0]?.querySelector<HTMLElement>('[data-projection-scope]')?.dataset
                  .projectionRuntime,
              surfaces: surfaces.length,
              fallbackHidden: root.querySelector<HTMLElement>('[data-homepage-fallback]')?.hidden,
            };
          })
        );
        expect(groups.length).toBeGreaterThanOrEqual(3);
        for (const group of groups) {
          expect(group.activeCount).toBe(1);
          expect(group.runtime).toBe(runtime);

          expect(group.fallbackHidden).toBe(true);
        }
        const anchors = await page
          .locator('[data-homepage-mount] [data-projection-generation-state="active"] a')
          .evaluateAll((links) =>
            links.map((link) => ({
              href: link.getAttribute('href'),
              text: link.textContent?.trim(),
              target: link.getAttribute('target'),
            }))
          );
        expect(anchors).toEqual(fallbackLinks);
        expect(
          await page
            .locator(
              '[data-homepage-runtime] [data-projection-control="runtime"] [role="combobox"]'
            )
            .evaluate((element) => document.activeElement === element)
        ).toBe(true);
        const accessibleTheme = page
          .locator('[data-homepage-runtime]')
          .getByRole('button', { name: '切换主题', exact: true });
        expect(await accessibleTheme.count()).toBe(1);
        expect(await accessibleTheme.getAttribute('title')).toBe('切换主题');
        await accessibleTheme.hover();
        expect(await accessibleTheme.count(), 'name survives hover feedback').toBe(1);
        const themeBefore = await page.locator('html').getAttribute('data-theme');
        await page
          .locator(
            '[data-homepage-runtime] [data-projection-generation-state="active"] [data-demo-ref="home-theme"]'
          )
          .click();
        await expect
          .poll(() => page.locator('html').getAttribute('data-theme'))
          .toBe(themeBefore === 'dark' ? 'light' : 'dark');
        expect(await page.evaluate(() => localStorage.getItem('starlight-theme'))).toBe(
          themeBefore === 'dark' ? 'light' : 'dark'
        );
        const trigger = page.locator(
          '[data-homepage-runtime] [data-projection-control="runtime"] [role="combobox"]'
        );
        await revealHeaderPreferences(page);
        await trigger.focus();
        await page.keyboard.press('Enter');
        const keyboardPortalId = await trigger.getAttribute('aria-controls');
        const keyboardPortal = page.locator(`[id=${JSON.stringify(keyboardPortalId)}]`);
        await keyboardPortal.waitFor({ state: 'visible' });
        // Select enters the selected item after its deferred overlay-ready step.
        // Escape must test an entered popup, not race that entry callback.
        await expect
          .poll(
            () =>
              keyboardPortal
                .getByRole('option')
                .evaluateAll((items) => items.some((item) => item === document.activeElement)),
            { timeout: 10_000 }
          )
          .toBe(true);
        await page.keyboard.press('Escape');
        await keyboardPortal.waitFor({ state: 'hidden' });
        await expect
          .poll(() => trigger.evaluate((element) => document.activeElement === element), {
            timeout: 10_000,
          })
          .toBe(true);
      }
      const chooseDemo = async (control: 'family', label: string) => {
        const trigger = page.locator(
          `[data-homepage-runtime] [data-projection-generation-state="active"] [data-projection-control="${control}"] [role="combobox"]`
        );
        await trigger.click();
        const id = await trigger.getAttribute('aria-controls');
        await page
          .locator(`[id=${JSON.stringify(id)}]`)
          .getByRole('option', { name: label, exact: true })
          .click();
      };
      for (const family of ['brutalist', 'shadcn'] as const) {
        await chooseDemo('family', family === 'brutalist' ? 'Brutalist' : 'Shadcn');
        await page.waitForFunction(
          (target) =>
            document.querySelector<HTMLElement>('[data-homepage-runtime]')?.dataset.family ===
            target,
          family
        );
        for (const runtime of RUNTIMES) {
          await switchRuntime(page, runtime);
          const coordinates = await page.evaluate(() => {
            const root = document.querySelector<HTMLElement>('[data-homepage-runtime]')!;
            const demo = document.querySelector<HTMLElement>('[data-home-showcase]')!;
            const scopes = [
              ...document.querySelectorAll<HTMLElement>(
                '[data-homepage-mount] [data-projection-generation-state="active"] [data-projection-scope], [data-home-demo-host] [data-projection-generation-state="active"] [data-projection-scope]'
              ),
            ];
            return {
              family: root.dataset.family,
              component: demo.dataset.projectionComponent,
              pageGeneration: root.dataset.runtimeGeneration,
              demoGeneration: demo.dataset.projectionGeneration,
              scopes: scopes.map((scope) => ({
                runtime: scope.dataset.projectionRuntime,
                family: scope.dataset.projectionFamily,
                generation: scope.dataset.projectionGeneration,
              })),
            };
          });
          const accessibleTheme = page
            .locator('[data-homepage-runtime]')
            .getByRole('button', { name: '切换主题', exact: true });
          expect(await accessibleTheme.count(), `${family}/${runtime} icon accessible name`).toBe(
            1
          );
          expect(await accessibleTheme.getAttribute('title')).toBe('切换主题');
          expect(coordinates.family).toBe(family);
          expect(coordinates.component).toBe('website-component-gallery');
          expect(coordinates.demoGeneration).toBe(coordinates.pageGeneration);
          expect(
            await page.locator('[data-home-showcase] [data-projection-control="component"]').count()
          ).toBe(0);
          expect(await page.locator('[data-home-settings]').count()).toBe(1);
          for (const scope of coordinates.scopes) {
            expect(scope.runtime).toBe(runtime);
            expect(scope.family).toBe(family);
            expect(scope.generation).toBe(coordinates.pageGeneration);
          }
        }
      }
      expect(errors).toEqual([]);
      const link = page
        .locator(
          '#home-navigation-desktop [data-homepage-mount] [data-projection-generation-state="active"] a'
        )
        .filter({ hasText: '文档' });
      expect(await link.count()).toBe(1);
      expect(await link.isVisible()).toBe(true);
      const destination = await link.getAttribute('href');
      const opened = context.waitForEvent('page');
      await link.click({ modifiers: ['ControlOrMeta'] });
      const newPage = await opened;
      await newPage.waitForURL(`**${destination}`);
      await newPage.close();
      expect(new URL(page.url()).pathname).toBe('/zh-cn/');
    } finally {
      await context.close();
    }
  }, 240_000);

  it('keeps native navigation available without JavaScript and does not overflow mobile', async () => {
    const noJs = await browser.newContext({
      javaScriptEnabled: false,
      viewport: { width: 390, height: 844 },
    });
    try {
      const page = await noJs.newPage();
      await page.goto(`${baseUrl}/zh-cn/`);
      const links = page.locator('[data-homepage-fallback] a');
      expect(await links.count()).toBeGreaterThan(5);
      expect(await links.first().isVisible()).toBe(true);
      const nativeMobileDocs = page
        .locator('#home-navigation-mobile [data-homepage-fallback] a')
        .filter({ hasText: '文档' });
      expect(await nativeMobileDocs.count()).toBe(1);
      expect(await nativeMobileDocs.isVisible()).toBe(false);
      const summary = page.locator('[data-site-header-fallback-summary]');
      expect(await summary.isVisible()).toBe(true);
      await summary.click();
      expect(await nativeMobileDocs.isVisible()).toBe(true);
      expect(
        await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)
      ).toBe(true);
      expect(await nativeMobileDocs.getAttribute('href')).toBe('/zh-cn/start-here/what-you-saw/');
      await nativeMobileDocs.click();
      await page.waitForURL('**/zh-cn/start-here/what-you-saw/');
    } finally {
      await noJs.close();
    }
    const context = await browser.newContext({ viewport: { width: 320, height: 844 } });
    try {
      const page = await context.newPage();
      await page.goto(`${baseUrl}/zh-cn/`);
      await ready(page, 'wc');
      for (const width of [390, 430, 320]) {
        await page.setViewportSize({ width, height: 844 });
        const navigation = page.locator('[data-site-header-navigation]');
        const originalNavigation = await navigation.elementHandle();
        expect(
          await originalNavigation!.evaluate((node) => (node as HTMLElement).hidden),
          `${width}px navigation starts collapsed`
        ).toBe(true);
        await revealHeaderPreferences(page);
        expect(
          await originalNavigation!.evaluate(
            (node) => node === document.querySelector('[data-site-header-navigation]')
          )
        ).toBe(true);
        const geometry = await page.evaluate(() => {
          const header = document
            .querySelector<HTMLElement>('[data-homepage-runtime]')!
            .getBoundingClientRect();
          const navigation = document.querySelector<HTMLElement>('[data-site-header-navigation]')!;
          const controls = [
            ...document.querySelectorAll<HTMLElement>(
              '.site-header-search [data-open-modal], .site-header-theme [data-demo-ref="home-theme"], .site-header-menu [data-demo-ref="home-menu"]'
            ),
          ].filter(
            (element) =>
              element.closest('[data-projection-generation-state="active"]') ||
              element.hasAttribute('data-open-modal')
          );
          const controlBounds = controls.map((element) => element.getBoundingClientRect());
          const status = document
            .querySelector<HTMLElement>('[data-homepage-runtime-status]')!
            .getBoundingClientRect();
          const brand = document.querySelector<HTMLElement>(
            '[data-homepage-mount] [data-home-brand]'
          )!;
          return {
            width: header.width,
            navHidden: navigation.hidden,
            controls: controlBounds.map(({ x, y, width, height }) => ({ x, y, width, height })),
            height: header.height,
            headerBottom: header.bottom,
            panel: document
              .querySelector('[data-site-header-panel]')!
              .getBoundingClientRect()
              .toJSON(),
            menu: document
              .querySelector(
                '[data-projection-generation-state="active"] [data-demo-ref="home-menu"]'
              )!
              .getBoundingClientRect()
              .toJSON(),
            preferences: [
              ...document.querySelectorAll<HTMLElement>(
                '[data-homepage-runtime] [data-projection-generation-state="active"] [data-projection-control] [role="combobox"]'
              ),
            ].map((control) => {
              const bounds = control.getBoundingClientRect();
              const value = control.querySelector<HTMLElement>(
                '[data-projection-prototype$="-select-value"]'
              )!;
              return {
                x: bounds.x,
                y: bounds.y,
                width: bounds.width,
                height: bounds.height,
                bottom: bounds.bottom,
                fullValueVisible: value.scrollWidth <= value.clientWidth + 1,
              };
            }),
            statusArea: status.width * status.height,
            brandSize: getComputedStyle(brand).fontSize,
          };
        });
        expect(geometry.navHidden, `${width}px navigation is deliberately disclosed`).toBe(false);
        await originalNavigation!.dispose();
        // Author labels name each independent Select; selected text is its value,
        // not a replacement accessible name. Each named control must occur once.
        for (const [name, value] of [
          ['整页 Runtime', 'Web Components'],
          ['整页组件库', 'Shadcn'],
          ['语言', '简体中文'],
        ]) {
          const control = page.locator('[data-homepage-runtime]').getByRole('combobox', {
            name,
            exact: true,
          });
          expect(await control.count()).toBe(1);
          expect(await control.isVisible()).toBe(true);
          expect((await control.ariaSnapshot()).split('\n')[0]).toContain(`combobox "${name}"`);
          expect(
            (
              await control.locator('[data-projection-prototype$="-select-value"]').textContent()
            )?.trim()
          ).toBe(value);
          expect(await control.getAttribute('aria-expanded')).toBe('false');
        }
        for (const preference of geometry.preferences) {
          expect(preference.height).toBeGreaterThanOrEqual(44);
          expect(preference.width, 'minimum native touch target').toBeGreaterThanOrEqual(44);
          expect(preference.fullValueVisible).toBe(true);
          expect(preference.bottom).toBeLessThanOrEqual(geometry.panel.bottom + 1);
          expect(preference.y).toBeGreaterThanOrEqual(geometry.panel.top);
          expect(preference.y).toBeGreaterThan(
            geometry.controls[0]!.y + geometry.controls[0]!.height
          );
        }
        for (let index = 1; index < geometry.preferences.length; index++)
          expect(geometry.preferences[index]!.y).toBeGreaterThan(
            geometry.preferences[index - 1]!.bottom
          );
        expect(Math.abs(geometry.panel.top - geometry.headerBottom - 5)).toBeLessThanOrEqual(1);
        expect(Math.abs(geometry.panel.right - (width - 8))).toBeLessThanOrEqual(1);
        expect(geometry.height).toBeLessThanOrEqual(64);
        expect(geometry.controls).toHaveLength(3);
        for (const control of geometry.controls) {
          expect(control.width).toBeGreaterThanOrEqual(44);
          expect(control.height).toBeGreaterThanOrEqual(44);
          expect(control.y).toBe(geometry.controls[0]!.y);
        }
        expect(geometry.statusArea).toBeLessThanOrEqual(1);
        expect(geometry.brandSize).toBe('16px');
        await page.keyboard.press('Escape');
      }
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
        true
      );
      const menu = page.locator(
        '[data-projection-generation-state="active"] [data-demo-ref="home-menu"]'
      );
      await menu.click();
      expect(await menu.getAttribute('aria-expanded')).toBe('true');
      const disclosedDocs = page
        .locator('#home-navigation-mobile [data-homepage-mount] a')
        .filter({ hasText: '文档' });
      expect(await disclosedDocs.isVisible()).toBe(true);
      await switchRuntime(page, 'vue2');
      expect(
        await menu.getAttribute('aria-expanded'),
        'open application state survives runtime commit'
      ).toBe('true');
      expect(await disclosedDocs.isVisible()).toBe(true);
      await page.keyboard.press('Escape');
      expect(await menu.getAttribute('aria-expanded')).toBe('false');
      expect(await menu.evaluate((element) => document.activeElement === element)).toBe(true);
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
        true
      );
      // Runtime selection above commits Vue2. Family selection has its own
      // unchanged 1000ms transaction gate later in this suite. Exercise locale
      // as navigation, not merely another identically shaped combobox.
      await revealHeaderPreferences(page);
      const locale = page.locator('[data-homepage-runtime]').getByRole('combobox', {
        name: '语言',
        exact: true,
      });
      await locale.click();
      const localeList = await locale.getAttribute('aria-controls');
      expect(localeList).toBeTruthy();
      const options = page.locator(`[id=${JSON.stringify(localeList)}]`);
      expect(
        await options
          .getByRole('option', { name: '简体中文', exact: true })
          .getAttribute('aria-selected')
      ).toBe('true');
      await Promise.all([
        page.waitForURL(`${baseUrl}/en/`, { timeout: 10_000 }),
        options.getByRole('option', { name: 'English', exact: true }).click(),
      ]);
      expect(new URL(page.url()).origin).toBe(new URL(baseUrl).origin);
      await ready(page, 'vue2');
      await revealHeaderPreferences(page);
      const english = page.locator('[data-homepage-runtime]').getByRole('combobox', {
        name: 'Language',
        exact: true,
      });
      expect(await english.count()).toBe(1);
      expect(
        (
          await english.locator('[data-projection-prototype$="-select-value"]').textContent()
        )?.trim()
      ).toBe('English');
      expect(await page.evaluate(() => localStorage.getItem('preferred-locale'))).toBe('en');
    } finally {
      await context.close();
    }
  }, 90_000);
  it('retains saved React across cold library routes and exercises actual family chrome', async () => {
    const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
    const page = await context.newPage();
    try {
      await page.goto(`${baseUrl}/zh-cn/`, { waitUntil: 'networkidle' });
      await ready(page, 'wc');
      await switchRuntime(page, 'react');
      expect(await page.evaluate(() => localStorage.getItem('preferred-prototypes-adapter'))).toBe(
        'react'
      );
      for (const route of [
        {
          path: '/zh-cn/ui-libraries/brutalist/components/tooltip/',
          family: 'brutalist',
          component: 'tooltip',
        },
        {
          path: '/zh-cn/ui-libraries/shadcn/radio-group/',
          family: 'shadcn',
          component: 'radio-group',
        },
      ]) {
        await page.goto(`${baseUrl}${route.path}`, { waitUntil: 'networkidle' });
        const preview = page
          .locator('[data-previewer-id][data-projection-mode="fixed-family"]')
          .first();
        await preview.scrollIntoViewIfNeeded();
        const scope = preview.locator(
          '[data-projection-generation-state="active"] [data-projection-scope]'
        );
        await expect.poll(() => scope.getAttribute('data-projection-runtime')).toBe('react');
        expect(await page.locator('html').getAttribute('data-site-library-family')).toBe(
          route.family
        );
        expect(await preview.getAttribute('data-projection-family')).toBe(route.family);
        expect(await preview.getAttribute('data-projection-component')).toBe(route.component);
        const adapter = page.locator('header [data-adapter-select-root]').first();
        const language = page.locator('header [data-language-select-root]').first();
        const theme = page.locator('header [data-theme-toggle]').first();
        for (const control of [adapter, language]) {
          expect(await control.evaluate((element) => element.localName)).toBe(
            `wc-${route.family}-select-root`
          );
          expect(await control.getAttribute('data-pui-root')).not.toBeNull();
        }
        expect(await theme.evaluate((element) => element.localName)).toBe(
          `wc-${route.family}-button`
        );
        const chooseAdapter = async (value: 'vue' | 'react') => {
          await revealHeaderPreferences(page);
          const trigger = adapter.locator('[role="combobox"]');
          await trigger.click();
          const id = await trigger.getAttribute('aria-controls');
          expect(id).toBeTruthy();
          const portal = page.locator(`[id=${JSON.stringify(id)}]`);
          await portal.waitFor({ state: 'visible' });
          expect(await portal.getAttribute('data-site-control-family')).toBe(route.family);
          expect(await portal.getAttribute('data-pui-root')).not.toBeNull();
          await portal
            .getByRole('option', { name: value === 'vue' ? 'Vue' : 'React', exact: true })
            .click();
          await expect.poll(() => scope.getAttribute('data-projection-runtime')).toBe(value);
        };
        await chooseAdapter('vue');
        await chooseAdapter('react');
        const menu = page.locator('header [data-site-menu-button]');
        await menu.click();
        expect(await menu.getAttribute('aria-expanded')).toBe('true');
        const languageTrigger = language.locator('[role="combobox"]');
        await languageTrigger.click();
        const languagePortalId = await languageTrigger.getAttribute('aria-controls');
        const languagePortal = page.locator(`[id=${JSON.stringify(languagePortalId)}]`);
        await languagePortal.waitFor({ state: 'visible' });
        expect(await languagePortal.getAttribute('data-site-control-family')).toBe(route.family);
        await languagePortal.getByRole('option').first().waitFor({ state: 'visible' });
        expect(await languagePortal.getByRole('option').count()).toBeGreaterThan(1);
        await page.keyboard.press('Escape');
        await languagePortal.waitFor({ state: 'hidden' });
        const beforeTheme = await page.locator('html').getAttribute('data-theme');
        await page.evaluate(() => {
          const state = window as typeof window & { __siteThemeChanges?: number };
          state.__siteThemeChanges = 0;
          document.addEventListener('starlight-theme:change', () => {
            state.__siteThemeChanges = (state.__siteThemeChanges ?? 0) + 1;
          });
        });
        await theme.click();
        await expect
          .poll(() => page.locator('html').getAttribute('data-theme'))
          .toBe(beforeTheme === 'dark' ? 'light' : 'dark');
        expect(
          await page.evaluate(
            () => (window as typeof window & { __siteThemeChanges?: number }).__siteThemeChanges
          )
        ).toBe(1);
        expect(
          await page.evaluate(() => localStorage.getItem('preferred-prototypes-adapter'))
        ).toBe('react');
        expect(await preview.getAttribute('data-projection-family')).toBe(route.family);
        expect(await preview.getAttribute('data-projection-component')).toBe(route.component);
      }
    } finally {
      await context.close();
    }
  }, 180_000);
  it('reveals current articles through native shadow slots and preserves viewport handback', async () => {
    const directory = path.join(
      process.env.PROTO_UI_RUNTIME_EVIDENCE_DIR ??
        path.join(process.env.RUNNER_TEMP ?? os.tmpdir(), 'homepage-evidence'),
      'sidebar-native-slot'
    );
    await mkdir(directory, { recursive: true });
    const source = {
      sha: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
      dirty: execFileSync('git', ['status', '--porcelain'], { encoding: 'utf8' }).trim() !== '',
      files: Object.fromEntries(
        [
          'apps/www/src/components/site-sidebar-current-visibility.ts',
          'apps/www/src/components/site-sidebar-disclosure-policy.ts',
          'apps/www/src/content/docs/zh-cn/homepage-dogfood.browser.test.ts',
          'apps/www/src/content/docs/zh-cn/browser-harness.ts',
        ].map((file) => [file, createHash('sha256').update(readFileSync(file)).digest('hex')])
      ),
    };
    const context = await browser.newContext({ viewport: { width: 390, height: 844 } });
    await context.route('**/*', (route) =>
      new URL(route.request().url()).origin === new URL(baseUrl).origin
        ? route.continue()
        : route.abort()
    );
    const page = await context.newPage();
    const errors: string[] = [];
    const observations: unknown[] = [];
    const completionErrors: unknown[] = [];
    let failed = false;
    let failure: unknown;
    page.on('pageerror', (error) => errors.push(error.message));
    try {
      await page.goto(`${baseUrl}/zh-cn/ui-libraries/shadcn/button/`, {
        waitUntil: 'networkidle',
      });
      const fixture = await page.evaluateHandle(async () => {
        await document.fonts.ready;
        // Keep this import in the native browser realm, following the existing
        // browser fixtures rather than Vitest's Node SSR import rewriting.
        const browserImport = new Function('url', 'return import(url)') as (
          url: string
        ) => Promise<unknown>;
        const { initSidebarCurrentVisibility, nearestSidebarScroller } = (await browserImport(
          '/src/components/site-sidebar-current-visibility.ts'
        )) as typeof SidebarCurrentVisibility;
        const home = document.createElement('div');
        home.style.cssText =
          'position:fixed;left:16px;top:80px;width:240px;z-index:2147483000;background:white;color:black';
        const tree = document.createElement('nav');
        tree.id = 'pui-sidebar-native-slot-fixture';
        tree.setAttribute('aria-label', 'Native slot visibility fixture');
        tree.style.cssText =
          'display:block;width:240px;height:160px;overflow-y:auto;overflow-anchor:none;scroll-behavior:auto;font:16px/20px sans-serif';
        tree.innerHTML =
          '<ul class="top-level" style="margin:0;padding:0;list-style:none"><li style="margin:0;padding:0"><div style="height:720px"></div><a href="#pui-sidebar-native-slot-current" aria-current="page" style="display:block;height:44px;box-sizing:border-box;background:#ffe49a">Current article</a><div style="height:640px"></div></li></ul>';
        const current = tree.querySelector<HTMLAnchorElement>('[aria-current="page"]')!;
        const sibling = document.createElement('span');
        sibling.textContent = 'Original home sibling';
        home.append(tree, sibling);
        const host = document.createElement('div');
        host.style.cssText = 'position:fixed;left:16px;top:300px;width:240px;z-index:2147483000';
        const shadow = host.attachShadow({ mode: 'open' });
        const content = document.createElement('div');
        content.style.cssText =
          'box-sizing:content-box;width:212px;height:160px;padding:12px;border:2px solid black;overflow-y:auto;overflow-anchor:none;overscroll-behavior:contain;scroll-behavior:auto;background:white;color:black';
        const slot = document.createElement('slot');
        content.append(slot);
        shadow.append(content);
        const nativeSlot = document.createElement('div');
        host.append(nativeSlot);
        const focusTarget = document.createElement('button');
        focusTarget.textContent = 'Keep focus';
        focusTarget.style.cssText =
          'position:fixed;left:300px;top:16px;width:74px;height:44px;z-index:2147483001';
        document.body.append(home, host, focusTarget);
        focusTarget.focus();
        const documentPosition = { x: scrollX, y: scrollY };
        const stop = initSidebarCurrentVisibility(tree);
        let placement: 'home' | 'slotted' = 'home';
        let inputPhase = 'idle';
        let manualDone: Promise<void> | undefined;
        let releaseScrollEnd: (() => void) | undefined;
        const inputs: { phase: string; trusted: boolean; viewportTarget: boolean }[] = [];
        const recordWheel = (event: WheelEvent) => {
          inputs.push({
            phase: inputPhase,
            trusted: event.isTrusted,
            viewportTarget: event.target === content && !event.composedPath().includes(tree),
          });
        };
        content.addEventListener('wheel', recordWheel, { passive: true });
        return {
          read() {
            const viewport = placement === 'slotted' ? content : tree;
            const owner = nearestSidebarScroller(current, tree);
            const box = viewport.getBoundingClientRect();
            const row = current.getBoundingClientRect();
            const top = box.top + viewport.clientTop;
            const bottom = top + viewport.clientHeight;
            const manualInputs = inputs.filter((input) => input.phase === 'trusted-manual');
            return {
              placement,
              owner: owner === tree ? 'home' : owner === content ? 'slotted' : 'none',
              nativeSlotAssigned: nativeSlot.assignedSlot === slot,
              sameTree: document.getElementById(tree.id) === tree,
              sameCurrent: tree.querySelector('[aria-current="page"]') === current,
              treeCount: document.querySelectorAll(`#${tree.id}`).length,
              homeSibling: tree.parentNode === home && tree.nextSibling === sibling,
              focusPreserved: document.activeElement === focusTarget,
              documentPreserved: scrollX === documentPosition.x && scrollY === documentPosition.y,
              scrollTop: viewport.scrollTop,
              scrollHeight: viewport.scrollHeight,
              clientHeight: viewport.clientHeight,
              viewportTop: top,
              viewportBottom: bottom,
              rowTop: row.top,
              rowBottom: row.bottom,
              visible:
                row.width > 0 && row.height > 0 && row.top >= top - 1 && row.bottom <= bottom + 1,
              nearestBottom: Math.abs(row.bottom - bottom) <= 1,
              trustedManualInput:
                manualInputs.length > 0 &&
                manualInputs.every((input) => input.trusted && input.viewportTarget),
              inputs: [...inputs],
            };
          },
          lend() {
            placement = 'slotted';
            tree.style.height = 'auto';
            tree.style.overflowY = 'visible';
            tree.setAttribute('data-site-contents-popover-tree', '');
            nativeSlot.append(tree);
          },
          armManualWheel() {
            inputPhase = 'trusted-manual';
            const { promise, resolve } = Promise.withResolvers<void>();
            manualDone = promise;
            const onEnd = () => resolve();
            content.addEventListener('scrollend', onEnd, { once: true });
            releaseScrollEnd = () => content.removeEventListener('scrollend', onEnd);
            const box = content.getBoundingClientRect();
            return {
              x: box.left + content.clientLeft + 4,
              y: box.top + content.clientTop + 4,
            };
          },
          waitForManualWheel() {
            if (!manualDone) throw new Error('Native manual wheel was not armed');
            return manualDone;
          },
          async resizeAfterManual() {
            const { promise, resolve } = Promise.withResolvers<void>();
            const observer = new ResizeObserver(() => {
              observer.disconnect();
              resolve();
            });
            observer.observe(content);
            content.style.height = '128px';
            document.dispatchEvent(new CustomEvent('site-contents:open'));
            await promise;
          },
          handBack() {
            placement = 'home';
            tree.style.height = '160px';
            tree.style.overflowY = 'auto';
            home.insertBefore(tree, sibling);
            tree.removeAttribute('data-site-contents-popover-tree');
            tree.scrollTop = 0;
            // This controlled persisted-history notification starts a new
            // request. The retired viewport event is explicitly synthetic;
            // it must not cancel that request through an obsolete binding.
            window.dispatchEvent(new PageTransitionEvent('pageshow', { persisted: true }));
            inputPhase = 'retired-viewport-probe';
            content.dispatchEvent(new WheelEvent('wheel', { bubbles: true }));
          },
          dispose() {
            stop();
            releaseScrollEnd?.();
            content.removeEventListener('wheel', recordWheel);
            home.remove();
            host.remove();
            focusTarget.remove();
          },
        };
      });
      const read = () => fixture.evaluate((probe) => probe.read());
      const capture = async (phase: string) => {
        const observation = {
          phase,
          metrics: await read(),
          screenshot: `${phase}.png`,
          screenshotComplete: false,
        };
        observations.push(observation);
        await page.screenshot({ path: path.join(directory, observation.screenshot) });
        observation.screenshotComplete = true;
      };
      await expect
        .poll(async () => {
          const state = await read();
          return { owner: state.owner, visible: state.visible, nearest: state.nearestBottom };
        })
        .toEqual({ owner: 'home', visible: true, nearest: true });
      await capture('home-revealed');
      await fixture.evaluate((probe) => probe.lend());
      await expect
        .poll(async () => {
          const state = await read();
          return {
            owner: state.owner,
            assigned: state.nativeSlotAssigned,
            visible: state.visible,
            nearest: state.nearestBottom,
          };
        })
        .toEqual({ owner: 'slotted', assigned: true, visible: true, nearest: true });
      const slotted = await read();
      expect(slotted).toMatchObject({
        sameTree: true,
        sameCurrent: true,
        treeCount: 1,
        focusPreserved: true,
        documentPreserved: true,
      });
      await capture('slotted-revealed');
      const wheel = await fixture.evaluate((probe) => probe.armManualWheel());
      await page.mouse.move(wheel.x, wheel.y);
      await page.mouse.wheel(0, -160);
      await fixture.evaluate((probe) => probe.waitForManualWheel());
      const manual = await read();
      expect(manual.trustedManualInput).toBe(true);
      expect(Math.abs(manual.scrollTop - slotted.scrollTop)).toBeGreaterThan(1);
      await fixture.evaluate((probe) => probe.resizeAfterManual());
      const afterLayout = await read();
      expect(afterLayout.scrollTop).toBe(manual.scrollTop);
      expect(afterLayout).toMatchObject({ focusPreserved: true, documentPreserved: true });
      await capture('manual-retained');
      await fixture.evaluate((probe) => probe.handBack());
      await expect
        .poll(async () => {
          const state = await read();
          return {
            owner: state.owner,
            sibling: state.homeSibling,
            visible: state.visible,
            nearest: state.nearestBottom,
          };
        })
        .toEqual({ owner: 'home', sibling: true, visible: true, nearest: true });
      expect(await read()).toMatchObject({
        sameTree: true,
        sameCurrent: true,
        treeCount: 1,
        focusPreserved: true,
        documentPreserved: true,
      });
      await capture('home-restored');
      await fixture.evaluate((probe) => probe.dispose());
      await fixture.dispose();
      expect(errors).toEqual([]);
    } catch (error) {
      failed = true;
      failure = error;
    }
    try {
      await context.close();
    } catch (error) {
      completionErrors.push(error);
    }
    try {
      await writeFile(
        path.join(directory, 'receipt.json'),
        JSON.stringify(
          {
            source,
            result: failed || completionErrors.length > 0 ? 'failed' : 'passed',
            failure: failed ? String(failure) : null,
            completionErrors: completionErrors.map(String),
            errors,
            observations,
            boundary:
              'Native browser helper fixture with real DOM, automatic slot assignment, CSS geometry and trusted wheel input. Persisted-history and retired-viewport events are controlled injections. This does not establish public Popover-family or full website acceptance.',
          },
          null,
          2
        )
      );
    } catch (error) {
      completionErrors.push(error);
    }
    if (failed) {
      if (completionErrors.length) console.error('[Native slot completion]', completionErrors);
      throw failure;
    }
    if (completionErrors.length)
      throw new AggregateError(completionErrors, 'Native slot evidence or context cleanup failed');
  }, 60_000);

  it('uses real family Popover Triggers through all four Docs runtimes with keyboard and exact-source visual evidence', async () => {
    type CloseObservation = {
      initialMarker: string | null;
      events: (
        | { kind: 'home-inserted'; siblingMatches: boolean }
        | { kind: 'marker-change'; oldValue: string | null }
      )[];
    };
    const closeObservations: unknown[] = [];
    const directory = path.join(
      process.env.PROTO_UI_RUNTIME_EVIDENCE_DIR ??
        path.join(process.env.RUNNER_TEMP ?? os.tmpdir(), 'homepage-evidence'),
      'contents-command'
    );
    await mkdir(directory, { recursive: true });
    const source = {
      sha: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
      dirty: execFileSync('git', ['status', '--porcelain'], { encoding: 'utf8' }).trim() !== '',
      expectedSha: process.env.CANDIDATE_SHA ?? null,
      files: Object.fromEntries(
        [
          'components/SiteContentsCommand.astro',
          'components/site-contents-command.ts',
          'components/site-contents-panel.ts',
          'components/site-header-surface.ts',
          'components/site-header-disclosure.ts',
          'components/override/Sidebar.astro',
          'components/override/PageFrame.astro',
          'styles/site-contents-command.css',
          'content/docs/zh-cn/contents-wheel-evidence.ts',
        ].map((file) => [
          file,
          createHash('sha256')
            .update(readFileSync(`apps/www/src/${file}`))
            .digest('hex'),
        ])
      ),
    };
    const saveCloseEvidence = () =>
      writeFile(
        path.join(directory, 'normal-close-mutations.json'),
        JSON.stringify({ source, observations: closeObservations }, null, 2)
      );
    const familyRoutes = {
      shadcn: '/zh-cn/ui-libraries/shadcn/button/',
      brutalist: '/zh-cn/ui-libraries/brutalist/components/button/',
      'bootstrap-2-3-2': '/zh-cn/ui-libraries/bootstrap-2-3-2/button/',
    } as const;
    for (const family of ['shadcn', 'brutalist', 'bootstrap-2-3-2'] as const) {
      const context = await browser.newContext({
        viewport: { width: 390, height: 844 },
        colorScheme: 'dark',
      });
      await context.route('**/*', (route) =>
        new URL(route.request().url()).origin === new URL(baseUrl).origin
          ? route.continue()
          : route.abort()
      );
      const page = await context.newPage();
      const pageErrors: string[] = [];
      page.on('pageerror', (error) => pageErrors.push(error.message));
      page.on('console', (message) => {
        if (message.type() === 'error') pageErrors.push(`console: ${message.text()}`);
      });
      await page.addInitScript(() => {
        const evidence = {
          longTasks: [] as Array<{ start: number; duration: number }>,
          changes: [] as Array<{ at: number; adapter: unknown }>,
        };
        Object.assign(window, { __contentsRuntimeEvidence: evidence });
        document.addEventListener('proto-adapter:change', (event) => {
          evidence.changes.push({
            at: performance.timeOrigin + performance.now(),
            adapter: (event as CustomEvent<{ adapter: unknown }>).detail?.adapter,
          });
        });
        if (PerformanceObserver.supportedEntryTypes.includes('longtask'))
          new PerformanceObserver((entries) => {
            evidence.longTasks.push(
              ...entries.getEntries().map((entry) => ({
                start: performance.timeOrigin + entry.startTime,
                duration: entry.duration,
              }))
            );
            evidence.longTasks.splice(0, Math.max(0, evidence.longTasks.length - 100));
          }).observe({ type: 'longtask', buffered: true });
      });
      try {
        await page.goto(`${baseUrl}${familyRoutes[family]}`, { waitUntil: 'networkidle' });
        if (family === 'bootstrap-2-3-2') {
          // Idle pagination enhancement can shrink the short article while it
          // is scrolled to the bottom. Finish it before measuring wheel ownership.
          const pagination = page.locator('footer .pagination-links a');
          expect(await pagination.count()).toBe(2);
          await page
            .locator('footer .pagination-links a:not([data-site-link-enhanced])')
            .first()
            .waitFor({ state: 'detached' });
        }
        const root = page.locator('[data-site-contents-command]');
        const command = root.locator(
          '[data-projection-generation-state="active"] [data-site-contents-button]'
        );
        const menu = page.locator('[data-docs-site-header] [data-site-menu-button]');
        await page.evaluate(() =>
          Object.assign(window, {
            __contentsOriginalTree: document.querySelector('nav.docs-sidebar'),
            __contentsOriginalParent: document.querySelector('nav.docs-sidebar')?.parentNode,
            __contentsOriginalNextSibling: document.querySelector('nav.docs-sidebar')?.nextSibling,
            __contentsOriginalDetails: [...document.querySelectorAll('nav.docs-sidebar details')],
            __contentsOriginalCurrent: document.querySelector(
              'nav.docs-sidebar [aria-current="page"]'
            ),
          })
        );
        for (const runtime of RUNTIMES) {
          await revealHeaderPreferences(page);
          const select = page.locator('[data-adapter-select] [role="combobox"]');
          await select.click();
          const popup = await select.getAttribute('aria-controls');
          const transitionStartedAt = Date.now();
          await page
            .locator(`[id=${JSON.stringify(popup)}]`)
            .getByRole('option', { name: LABELS[runtime], exact: true })
            .click();
          const clickedAt = Date.now();
          let originalError: unknown;
          try {
            await expect.poll(() => root.getAttribute('data-contents-runtime')).toBe(runtime);
          } catch (error) {
            originalError = error;
          }
          const originalCheckAt = Date.now();
          const readTransition = () =>
            page.evaluate((since) => {
              const contents = document.querySelector<HTMLElement>('[data-site-contents-command]');
              const panel = document.querySelector<HTMLElement>('[data-site-header-panel]');
              const evidence = (
                window as typeof window & {
                  __contentsRuntimeEvidence?: {
                    longTasks: Array<{ start: number; duration: number }>;
                    changes: Array<{ at: number; adapter: unknown }>;
                  };
                }
              ).__contentsRuntimeEvidence;
              return {
                observedAt: performance.timeOrigin + performance.now(),
                preference: localStorage.getItem('preferred-prototypes-adapter'),
                contents: contents ? { ...contents.dataset } : null,
                panel: panel ? { ...panel.dataset } : null,
                generations: [
                  ...document.querySelectorAll<HTMLElement>(
                    'header [data-projection-generation-host]'
                  ),
                ].map((element) => ({ ...element.dataset, inert: element.inert })),
                longTasks: evidence?.longTasks.filter((entry) => entry.start >= since),
                changes: evidence?.changes.filter((entry) => entry.at >= since),
                resources: performance
                  .getEntriesByType('resource')
                  .filter(
                    (entry) =>
                      performance.timeOrigin + entry.startTime >= since &&
                      new URL(entry.name).origin === location.origin
                  )
                  .slice(-40)
                  .map((entry) => ({
                    path: new URL(entry.name).pathname,
                    start: performance.timeOrigin + entry.startTime,
                    duration: entry.duration,
                  })),
              };
            }, transitionStartedAt);
          try {
            const first = await readTransition();
            let late: Awaited<ReturnType<typeof readTransition>> | null = null;
            if (originalError) {
              // Diagnosis only: retain the original1000ms failure even if this
              // bounded observation later sees the requested generation commit.
              await page
                .waitForFunction(
                  (target) =>
                    document.querySelector<HTMLElement>('[data-site-contents-command]')?.dataset
                      .contentsRuntime === target,
                  runtime,
                  { timeout: 3000 }
                )
                .catch(() => {});
              late = await readTransition();
              await page.screenshot({
                path: path.join(directory, `${family}-${runtime}-failure.png`),
              });
            }
            await writeFile(
              path.join(directory, `${family}-${runtime}-transition.json`),
              JSON.stringify(
                {
                  source,
                  family,
                  runtime,
                  transitionStartedAt,
                  clickedAt,
                  originalCheckAt,
                  originalDeadlineMs: 1000,
                  originalError: originalError ? String(originalError) : null,
                  first,
                  late,
                  pageErrors,
                },
                null,
                2
              )
            );
          } catch (diagnosticError) {
            console.error('[Contents runtime evidence]', diagnosticError);
          }
          if (originalError) throw originalError;
          expect(await root.getAttribute('data-contents-family')).toBe(family);
          expect(
            await page
              .locator('[data-site-contents-panel-mount]')
              .getAttribute('data-contents-panel-runtime')
          ).toBe(runtime);
          expect(await root.getAttribute('data-contents-generation')).toBe(
            await page
              .locator('[data-site-header-panel]')
              .getAttribute('data-header-surface-generation')
          );
          if ((await menu.getAttribute('aria-expanded')) === 'true') await menu.click();
          expect(await root.getByRole('button', { name: '页面目录', exact: true }).count()).toBe(1);
          const contentId = await command.getAttribute('aria-controls');
          expect(contentId).toBeTruthy();
          expect(contentId).not.toBe('starlight__sidebar');
          for (const action of ['click', 'Enter', 'Space']) {
            expect(await command.getAttribute('aria-expanded')).toBe('false');
            if (action === 'click') await command.click();
            else {
              await command.focus();
              await page.keyboard.press(action);
            }
            await expect.poll(() => command.getAttribute('aria-expanded')).toBe('true');
            await expect
              .poll(() =>
                page.locator('nav.docs-sidebar[data-site-contents-popover-tree]').isVisible()
              )
              .toBe(true);
            expect(await command.getAttribute('aria-controls')).toBe(contentId);
            const dialog = page.getByRole('dialog');
            expect(await dialog.count()).toBe(1);
            expect(await dialog.getAttribute('id')).toBe(contentId);
            // The mobile contents shell is a nonmodal public Popover, so it
            // keeps the dialog role without the modal state.
            expect(await dialog.getAttribute('aria-modal')).toBe('false');
            expect(
              await dialog.evaluate((surface) => {
                let node: Node | null = document.querySelector('nav.docs-sidebar');
                while (node) {
                  if (node === surface) return true;
                  node =
                    (node as Element).assignedSlot ??
                    node.parentNode ??
                    (node.getRootNode() as ShadowRoot).host ??
                    null;
                }
                return false;
              })
            ).toBe(true);
            expect(await page.locator('nav.docs-sidebar').count()).toBe(1);
            expect(
              await page
                .locator('nav.docs-sidebar select, nav.docs-sidebar .mobile-menu-footer')
                .count()
            ).toBe(0);
            expect(
              await page.evaluate(() => {
                const state = window as typeof window & {
                  __contentsOriginalTree?: Element;
                  __contentsOriginalDetails?: Element[];
                  __contentsOriginalCurrent?: Element;
                };
                const tree = document.querySelector('nav.docs-sidebar');
                if (!tree) return false;
                return (
                  tree === state.__contentsOriginalTree &&
                  tree.querySelector('[aria-current="page"]') === state.__contentsOriginalCurrent &&
                  [...tree.querySelectorAll('details')].every(
                    (node, index) => node === state.__contentsOriginalDetails?.[index]
                  )
                );
              })
            ).toBe(true);
            // Opening must actually enter public Content. The old offscreen
            // shell left focus on the Header, making close-return trivial.
            expect(
              await dialog.evaluate((surface) => {
                let active = document.activeElement;
                while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement;
                let node: Node | null = active;
                while (node) {
                  if (node === surface) return true;
                  node =
                    (node as Element).assignedSlot ??
                    node.parentNode ??
                    (node.getRootNode() as ShadowRoot).host ??
                    null;
                }
                return false;
              })
            ).toBe(true);
            await page.keyboard.press('Tab');
            expect(
              await dialog.evaluate((surface) => {
                let active = document.activeElement;
                while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement;
                let node: Node | null = active;
                while (node) {
                  if (node === surface) return true;
                  node =
                    (node as Element).assignedSlot ??
                    node.parentNode ??
                    (node.getRootNode() as ShadowRoot).host ??
                    null;
                }
                return false;
              })
            ).toBe(true);
            const wheel = await dialog.evaluateHandle(observeContentsWheel);
            const readWheel = async () => {
              // Query the current public role without waiting for a replacement
              // to appear. The retained probe must still belong to that exact
              // dialog; an old node's unchanged split surface is insufficient.
              const currentDialogs = await dialog.elementHandles();
              try {
                return await wheel.evaluate((probe, dialogs) => {
                  const current = dialogs.length === 1 ? dialogs[0] : null;
                  return probe.read(current instanceof Element ? current : null);
                }, currentDialogs);
              } finally {
                await Promise.all(currentDialogs.map((current) => current.dispose()));
              }
            };
            let initialGeometry: ReturnType<
              ReturnType<typeof observeContentsWheel>['read']
            > | null = null;
            let scrolling: ReturnType<ReturnType<typeof observeContentsWheel>['read']> | null =
              null;
            let wheelChainBefore: ReturnType<
              ReturnType<typeof observeContentsWheel>['inspect']
            > | null = null;
            let wheelError: unknown;
            const wheelCompletionErrors: unknown[] = [];
            try {
              initialGeometry = await readWheel();
              // Visible slotted navigation and a positive scroll range do not
              // establish that Content has acquired its positioned viewport:
              // clientHeight=0 also makes scrollHeight-clientHeight positive.
              // Observe the existing public available-space commit before input.
              await expect.poll(async () => (await readWheel()).ready).toBe(true);
              scrolling = await readWheel();
              expect(scrolling.hitInContent).toBe(true);
              expect(scrolling.max).toBeGreaterThan(0);
              wheelChainBefore = await wheel.evaluate((probe) => probe.inspect());
              await page.mouse.move(scrolling.x, scrolling.y);
              const direction = scrolling.top < scrolling.max / 2 ? 1 : -1;
              await page.mouse.wheel(0, direction * 500);
              await vi.waitFor(
                async () => {
                  const current = await readWheel();
                  expect(current.connected).toBe(true);
                  expect(current.sameDialog).toBe(true);
                  expect(current.sameSurface).toBe(true);
                  expect(current.ready).toBe(true);
                  const top = current.top;
                  expect(top).not.toBe(scrolling!.top);
                  expect(direction * (top - scrolling!.top)).toBeGreaterThan(0);
                },
                { timeout: 1000 }
              );
              await page.evaluate(
                () =>
                  new Promise<void>((resolve) =>
                    requestAnimationFrame(() => requestAnimationFrame(() => resolve()))
                  )
              );
              const after = await readWheel();
              expect(after.connected).toBe(true);
              expect(after.sameDialog).toBe(true);
              expect(after.sameSurface).toBe(true);
              expect(after.ready).toBe(true);
              expect(after.top).not.toBe(scrolling.top);
              expect(direction * (after.top - scrolling.top)).toBeGreaterThan(0);
              expect(after.documentY).toBe(scrolling.documentY);
              expect(
                after.wheels.some(
                  (event) =>
                    event.trusted &&
                    event.surfaceInPath &&
                    event.contentInPath &&
                    !event.defaultPrevented &&
                    direction * event.deltaY > 0
                )
              ).toBe(true);
            } catch (error) {
              wheelError = error;
            } finally {
              try {
                await writeFile(
                  path.join(directory, `${family}-${runtime}-${action}-wheel.json`),
                  JSON.stringify(
                    {
                      source,
                      family,
                      runtime,
                      action,
                      input: 'native mouse wheel',
                      originalDeadlineMs: 1000,
                      initialGeometry,
                      before: scrolling,
                      after: await readWheel(),
                      scrollChain: {
                        before: wheelChainBefore,
                        after: await wheel.evaluate((probe) => probe.inspect()),
                      },
                      error: wheelError ? String(wheelError) : null,
                    },
                    null,
                    2
                  )
                );
                if (wheelError)
                  await page.screenshot({
                    path: path.join(directory, `${family}-${runtime}-${action}-wheel-failure.png`),
                  });
              } catch (error) {
                wheelCompletionErrors.push(error);
              }
              try {
                await wheel.evaluate((probe) => probe.dispose());
              } catch (error) {
                wheelCompletionErrors.push(error);
              }
              try {
                await wheel.dispose();
              } catch (error) {
                wheelCompletionErrors.push(error);
              }
            }
            if (wheelError) {
              if (wheelCompletionErrors.length)
                console.error('[Contents wheel evidence]', wheelCompletionErrors);
              throw wheelError;
            }
            if (wheelCompletionErrors.length)
              throw new AggregateError(wheelCompletionErrors, 'Contents wheel evidence failed');
            if (action === 'click') {
              const id = `${family}-${runtime}-public-popover-open`;
              const metrics = await dialog.evaluate((element) => {
                const panel = element.getBoundingClientRect();
                const tree = document.querySelector('nav.docs-sidebar')!;
                const treeRect = tree.getBoundingClientRect();
                return {
                  panel: { x: panel.x, y: panel.y, width: panel.width, height: panel.height },
                  tree: {
                    x: treeRect.x,
                    y: treeRect.y,
                    width: treeRect.width,
                    height: treeRect.height,
                  },
                  treePosition: getComputedStyle(tree).position,
                  overflow: document.documentElement.scrollWidth - innerWidth,
                  rootFont: getComputedStyle(document.documentElement).fontSize,
                  dpr: devicePixelRatio,
                  scale: visualViewport?.scale,
                };
              });
              await writeFile(
                path.join(directory, `${id}.json`),
                JSON.stringify(
                  {
                    source,
                    family,
                    runtime,
                    viewport: page.viewportSize(),
                    metrics,
                    screenshotComplete: false,
                  },
                  null,
                  2
                )
              );
              await page.screenshot({ path: path.join(directory, `${id}.png`) });
              await writeFile(
                path.join(directory, `${id}.json`),
                JSON.stringify(
                  {
                    source,
                    family,
                    runtime,
                    viewport: page.viewportSize(),
                    metrics,
                    screenshotComplete: true,
                  },
                  null,
                  2
                )
              );
              expect(metrics.overflow).toBeLessThanOrEqual(1);
              expect(metrics.treePosition).toBe('static');
              expect(metrics.tree.width).toBeGreaterThan(120);
              expect(metrics.panel.y).toBeGreaterThanOrEqual(0);
              expect(metrics.panel.y + metrics.panel.height).toBeLessThanOrEqual(845);
              expect(metrics.panel.x).toBeGreaterThanOrEqual(0);
              expect(metrics.panel.x + metrics.panel.width).toBeLessThanOrEqual(391);
              expect(metrics.panel.height).toBeGreaterThan(0);
            }
            await page.evaluate(() => {
              const state = window as typeof window & {
                __contentsOriginalTree?: Element;
                __contentsOriginalParent?: Node | null;
                __contentsOriginalNextSibling?: Node | null;
                __contentsTakeCloseObservation?: () => CloseObservation;
              };
              const tree = state.__contentsOriginalTree!;
              const home = state.__contentsOriginalParent!;
              const observation: CloseObservation = {
                initialMarker: tree.getAttribute('data-site-contents-popover-tree'),
                events: [],
              };
              const collect = (records: MutationRecord[]) => {
                for (const record of records) {
                  if (
                    record.type === 'childList' &&
                    record.target === home &&
                    [...record.addedNodes].includes(tree)
                  )
                    observation.events.push({
                      kind: 'home-inserted',
                      siblingMatches: record.nextSibling === state.__contentsOriginalNextSibling,
                    });
                  if (record.type === 'attributes' && record.target === tree)
                    observation.events.push({ kind: 'marker-change', oldValue: record.oldValue });
                }
              };
              const observer = new MutationObserver(collect);
              observer.observe(home, { childList: true });
              observer.observe(tree, {
                attributes: true,
                attributeFilter: ['data-site-contents-popover-tree'],
                attributeOldValue: true,
              });
              state.__contentsTakeCloseObservation = () => {
                collect(observer.takeRecords());
                observer.disconnect();
                delete state.__contentsTakeCloseObservation;
                return observation;
              };
            });
            await page.keyboard.press('Escape');
            const closeDeadline = performance.now() + 1000;
            let focusRestoredAtCollapse = false;
            await expect
              .poll(async () => {
                const collapsed = await command.evaluate((element) => ({
                  expanded: element.getAttribute('aria-expanded'),
                  focused: document.activeElement === element,
                }));
                focusRestoredAtCollapse = collapsed.focused;
                return collapsed.expanded;
              })
              .toBe('false');
            expect(focusRestoredAtCollapse).toBe(true);
            // The website retains its native tree through the public leave barrier.
            // Lease completion shares the original close budget, without a fixed sleep.
            const remainingCloseMs = closeDeadline - performance.now();
            expect(remainingCloseMs).toBeGreaterThan(0);
            await expect
              .poll(
                () =>
                  page.evaluate(() => {
                    const state = window as typeof window & { __contentsOriginalTree?: Element };
                    const tree = state.__contentsOriginalTree;
                    return (
                      !!tree?.isConnected &&
                      tree === document.querySelector('nav.docs-sidebar') &&
                      !tree.hasAttribute('data-site-contents-popover-tree')
                    );
                  }),
                { timeout: remainingCloseMs }
              )
              .toBe(true);
            const [closeObservation, homeTreeCount, popoverMarker, hasOriginalPosition] =
              await Promise.all([
                page
                  .evaluate(() => {
                    const state = window as typeof window & {
                      __contentsTakeCloseObservation?: () => CloseObservation;
                    };
                    return state.__contentsTakeCloseObservation!();
                  })
                  .then((observation) => {
                    closeObservations.push({ family, runtime, action, observation });
                    return observation;
                  }),
                page.locator('.docs-shell nav.docs-sidebar').count(),
                page.locator('nav.docs-sidebar').getAttribute('data-site-contents-popover-tree'),
                page.evaluate(() => {
                  const state = window as typeof window & {
                    __contentsOriginalTree?: Element;
                    __contentsOriginalParent?: Node | null;
                    __contentsOriginalNextSibling?: Node | null;
                  };
                  const tree = state.__contentsOriginalTree;
                  return (
                    !!tree &&
                    tree.parentNode === state.__contentsOriginalParent &&
                    tree.nextSibling === state.__contentsOriginalNextSibling
                  );
                }),
              ]);
            expect(homeTreeCount).toBe(1);
            expect(popoverMarker).toBeNull();
            expect(hasOriginalPosition).toBe(true);
            expect(closeObservation.initialMarker).not.toBeNull();
            expect(closeObservation.events).toEqual([
              { kind: 'home-inserted', siblingMatches: true },
              { kind: 'marker-change', oldValue: closeObservation.initialMarker },
            ]);
            expect(performance.now()).toBeLessThanOrEqual(closeDeadline);
          }
          // Real keyboard navigation selects the focus-visible state for the capture.
          await page.keyboard.press('Tab');
          await page.keyboard.press('Shift+Tab');
          const facts = await command.evaluate((element) => {
            const style = getComputedStyle(element);
            const box = element.getBoundingClientRect();
            const center = document.elementFromPoint(box.x + box.width / 2, box.y + box.height / 2);
            return {
              tokens: element.getAttribute('data-pui-style'),
              width: box.width,
              height: box.height,
              border: [style.borderWidth, style.borderColor],
              radius: style.borderRadius,
              shadow: style.boxShadow,
              font: style.fontFamily,
              focusVisible: element.hasAttribute('data-focus-visible'),
              ownsCenter: !!center && element.contains(center),
            };
          });
          expect(facts.width).toBeGreaterThanOrEqual(44);
          expect(facts.height).toBeGreaterThanOrEqual(44);
          expect(facts.ownsCenter).toBe(true);
          expect(facts.focusVisible).toBe(true);
          const expectedFocusPaint = {
            shadcn: 'border-ring',
            brutalist: 'rounded-base',
            'bootstrap-2-3-2': 'rounded-[4px]',
          } as const;
          expect(facts.tokens).toContain(expectedFocusPaint[family]);
          const id = `${family}-${runtime}-keyboard-focus`;
          const record = {
            source,
            family,
            runtime,
            viewport: page.viewportSize(),
            facts,
            screenshot: `${id}.png`,
          };
          await writeFile(
            path.join(directory, `${id}.json`),
            JSON.stringify({ ...record, screenshotComplete: false }, null, 2)
          );
          await page.screenshot({ path: path.join(directory, `${id}.png`) });
          await writeFile(
            path.join(directory, `${id}.json`),
            JSON.stringify({ ...record, screenshotComplete: true }, null, 2)
          );
        }
        await saveCloseEvidence();
      } catch (originalError) {
        try {
          await saveCloseEvidence();
        } catch (evidenceError) {
          console.error('[Contents close mutation evidence]', evidenceError);
        }
        throw originalError;
      } finally {
        await context.close();
      }
    }
  }, 180_000);
  it('uses the same mobile shell on documentation with independent global navigation and contents', async () => {
    const context = await browser.newContext({ viewport: { width: 390, height: 844 } });
    await context.route('**/*', (route) =>
      new URL(route.request().url()).origin === new URL(baseUrl).origin
        ? route.continue()
        : route.abort()
    );
    const page = await context.newPage();
    const source = {
      sha: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
      dirty: execFileSync('git', ['status', '--porcelain'], { encoding: 'utf8' }).trim() !== '',
    };
    let stage = 'navigate';
    let activeWidth: number | null = null;
    const stages: Array<{ stage: string; width: number; nodeMs: number }> = [];
    try {
      for (const width of [390, 430, 320]) {
        activeWidth = width;
        stage = 'navigate';
        await page.setViewportSize({ width, height: 844 });
        await page.goto(`${baseUrl}/zh-cn/ui-libraries/brutalist/components/tooltip/`, {
          waitUntil: 'networkidle',
        });
        const header = page.locator('[data-docs-site-header]');
        const menu = header.locator('[data-site-menu-button]');
        stage = 'menu-ready';
        stages.push({ stage, width, nodeMs: performance.now() });
        await expect.poll(() => header.getAttribute('data-site-menu-ready')).toBe('');
        stage = 'mobile-interaction';
        stages.push({ stage, width, nodeMs: performance.now() });
        // This loop reuses its native pointer across navigations. Measure the
        // resting row, not a legitimate +4px Brutalist hover under the old point.
        await page.mouse.move(0, 800);
        await expect
          .poll(
            () =>
              header.evaluate((element) =>
                [
                  ...element.querySelectorAll(
                    '.site-header-search [data-open-modal], [data-theme-toggle], [data-site-menu-button]'
                  ),
                ].every((control) => getComputedStyle(control).transform === 'none')
              ),
            { timeout: 1000 }
          )
          .toBe(true);
        const geometry = await header.evaluate((element) => {
          const bounds = element.getBoundingClientRect();
          const controls = [
            ...element.querySelectorAll<HTMLElement>(
              '.site-header-search [data-open-modal], [data-theme-toggle], [data-site-menu-button]'
            ),
          ].map((control) => {
            const { x, y, width, height } = control.getBoundingClientRect();
            return { x, y, width, height };
          });
          return {
            height: bounds.height,
            measuredOffset: parseFloat(
              getComputedStyle(element.closest('.site-page-frame')!).getPropertyValue(
                '--header-height'
              )
            ),
            controls,
            overflow: document.documentElement.scrollWidth > innerWidth,
          };
        });
        expect(Math.abs(geometry.height - geometry.measuredOffset)).toBeLessThanOrEqual(1);
        expect(geometry.overflow).toBe(false);
        expect(geometry.controls).toHaveLength(3);
        for (const control of geometry.controls) {
          expect(control.width).toBeGreaterThanOrEqual(44);
          expect(control.height).toBeGreaterThanOrEqual(44);
          expect(control.y).toBe(geometry.controls[0]!.y);
        }
        await menu.click();
        expect(await menu.getAttribute('aria-controls')).toBe('site-header-panel');
        expect(await header.locator('[data-site-header-navigation]').isVisible()).toBe(true);
        expect(await page.locator('body').getAttribute('data-mobile-menu-expanded')).toBeNull();
        await page.keyboard.press('Escape');
        expect(await menu.getAttribute('aria-expanded')).toBe('false');
        const contents = header.locator(
          '[data-site-contents-command] [data-projection-generation-state="active"] [data-site-contents-button]'
        );
        const contentsId = await contents.getAttribute('aria-controls');
        expect(contentsId).toBeTruthy();
        expect(contentsId).not.toBe('starlight__sidebar');
        expect(await header.getByRole('button', { name: '页面目录', exact: true }).count()).toBe(1);
        expect(await contents.getAttribute('title')).toBe('页面目录');
        await revealHeaderPreferences(page);
        const hitTargets = await header.evaluate((element) => {
          const trigger = element.querySelector<HTMLElement>(
            '[data-adapter-select] [role="combobox"]'
          )!;
          const contents = element.querySelector<HTMLElement>(
            '[data-site-contents-command] [data-projection-generation-state="active"] [data-site-contents-button]'
          )!;
          const triggerRect = trigger.getBoundingClientRect();
          const contentsRect = contents.getBoundingClientRect();
          const center = document.elementFromPoint(
            contentsRect.x + contentsRect.width / 2,
            contentsRect.y + contentsRect.height / 2
          );
          return {
            trigger: { left: triggerRect.left, right: triggerRect.right, top: triggerRect.top },
            contents: {
              left: contentsRect.left,
              right: contentsRect.right,
              bottom: contentsRect.bottom,
            },
            contentsOwnsCenter: center !== null && contents.contains(center),
            centerTag: center?.tagName,
            chevrons: [...trigger.querySelectorAll('svg')].map((svg) => {
              const rect = svg.getBoundingClientRect();
              return { left: rect.left, right: rect.right, width: rect.width };
            }),
          };
        });
        console.info('Mobile documentation header hit targets', { width, ...hitTargets });
        expect(hitTargets.chevrons).toHaveLength(1);
        for (const chevron of hitTargets.chevrons) {
          expect(chevron.width, `${width}px real runtime chevron`).toBeGreaterThan(0);
          expect(chevron.left, `${width}px chevron inside trigger left`).toBeGreaterThanOrEqual(
            hitTargets.trigger.left
          );
          expect(chevron.right, `${width}px chevron inside trigger right`).toBeLessThanOrEqual(
            hitTargets.trigger.right
          );
        }
        expect(
          hitTargets.trigger.top,
          `${width}px runtime panel is separate from the first-row contents opener`
        ).toBeGreaterThanOrEqual(hitTargets.contents.bottom);
        expect(
          hitTargets.contentsOwnsCenter,
          `${width}px native contents target owns its center`
        ).toBe(true);
        await contents.click();
        expect(await page.locator('body').getAttribute('data-mobile-menu-expanded')).not.toBeNull();
        expect(await menu.getAttribute('aria-expanded')).toBe('false');
        // Nonmodal navigation leaves the actual Header settings target usable.
        expect(await contents.getAttribute('aria-controls')).toBe(contentsId);
        const dialog = page.getByRole('dialog');
        await expect.poll(() => dialog.isVisible()).toBe(true);
        const menuHit = await menu.evaluate((element) => {
          const rect = element.getBoundingClientRect();
          return element.contains(
            document.elementFromPoint(rect.x + rect.width / 2, rect.y + rect.height / 2)
          );
        });
        expect(menuHit).toBe(true);
        await menu.click();
        await expect.poll(() => contents.getAttribute('aria-expanded')).toBe('false');
        await expect.poll(() => dialog.count()).toBe(0);
        expect(await menu.getAttribute('aria-expanded')).toBe('true');
        expect(await contents.getAttribute('aria-expanded')).toBe('false');
        expect(await page.locator('body').getAttribute('data-mobile-menu-expanded')).toBeNull();
        expect(await header.locator('[data-language-select]').isVisible()).toBe(true);
        expect(await header.locator('[data-theme-toggle]').isVisible()).toBe(true);
        expect(
          await header.locator('[data-site-header-settings] a[href*="github.com"]').count()
        ).toBeGreaterThan(0);
        await page.keyboard.press('Escape');
        expect(await menu.evaluate((element) => document.activeElement === element)).toBe(true);
        // Reverse the order and exercise the complete keydown + keyup Escape.
        await menu.click();
        await contents.click();
        stage = 'navigation-close-from-contents';
        stages.push({ stage, width, nodeMs: performance.now() });
        await expect.poll(() => menu.getAttribute('aria-expanded')).toBe('false');
        stage = 'contents-focus';
        stages.push({ stage, width, nodeMs: performance.now() });
        expect(await contents.getAttribute('aria-expanded')).toBe('true');
        await page.keyboard.press('Escape');
        expect(await contents.evaluate((element) => document.activeElement === element)).toBe(true);
      }
    } catch (error) {
      const rejected = {
        source,
        stage,
        width: activeWidth,
        nodeMs: performance.now(),
        message: String(error),
        stack: error instanceof Error ? error.stack : null,
        cause: error instanceof Error && error.cause !== undefined ? String(error.cause) : null,
        stages: stages.map((entry) => ({ ...entry })),
      };
      // Freeze the original rejection before any post-failure browser request.
      console.info('[mobile-shell-rejection]', JSON.stringify(rejected));
      try {
        const directory = path.join(
          process.env.PROTO_UI_RUNTIME_EVIDENCE_DIR ??
            path.join(process.env.RUNNER_TEMP ?? os.tmpdir(), 'homepage-evidence'),
          'mobile-shell'
        );
        await mkdir(directory, { recursive: true });
        await writeFile(path.join(directory, 'rejection.json'), JSON.stringify(rejected, null, 2));
        const nodeStartedMs = performance.now();
        const facts = await page.evaluate(() => {
          const header = document.querySelector<HTMLElement>('[data-docs-site-header]');
          const menu = header?.querySelector('[data-site-menu-button]');
          const contents = header?.querySelector('[data-site-contents-command]');
          return {
            timeOrigin: performance.timeOrigin,
            pageMs: performance.now(),
            menuReady: header?.getAttribute('data-site-menu-ready'),
            menuExpanded: menu?.getAttribute('aria-expanded'),
            contents: contents?.outerHTML,
            bodyExpanded: document.body.getAttribute('data-mobile-menu-expanded'),
            activeElement: document.activeElement?.outerHTML,
          };
        });
        await writeFile(
          path.join(directory, 'post-rejection.json'),
          JSON.stringify({ nodeStartedMs, nodeReturnedMs: performance.now(), facts }, null, 2)
        );
        await page.screenshot({ path: path.join(directory, 'failure.png'), fullPage: true });
      } catch (captureError) {
        console.info('[mobile-shell-capture-error]', String(captureError));
      }
      throw error;
    } finally {
      console.info('[mobile-shell-stages]', JSON.stringify({ source, stages }));
      await context.close();
    }
  }, 90_000);
});

for (const family of ['shadcn', 'brutalist'] as const) {
  it(`compact ${family} preferences stay usable at 200% text, RTL and breakpoint moves`, async () => {
    const context = await browser.newContext({ viewport: { width: 390, height: 1000 } });
    const page = await context.newPage();
    try {
      await page.goto(`${baseUrl}/zh-cn/`, { waitUntil: 'networkidle' });
      await ready(page, 'wc');
      await revealHeaderPreferences(page);
      if (family === 'brutalist') {
        const control = page.locator(
          '#home-preferences [data-projection-control="family"] [role="combobox"]'
        );
        await control.click();
        const id = await control.getAttribute('aria-controls');
        await page
          .locator(`[id=${JSON.stringify(id)}]`)
          .getByRole('option', { name: 'Brutalist', exact: true })
          .click();
        await page.waitForFunction(
          () =>
            document.querySelector<HTMLElement>('[data-homepage-runtime]')?.dataset.family ===
            'brutalist'
        );
      }
      for (const width of [320, 390])
        for (const rtl of [false, true]) {
          await page.setViewportSize({ width, height: 1000 });
          await page.evaluate((rtl) => {
            document.documentElement.dir = rtl ? 'rtl' : 'ltr';
            document.documentElement.style.fontSize = '200%';
          }, rtl);
          const menu = page.locator(
            '.site-header-menu [data-projection-generation-state="active"] [data-demo-ref="home-menu"]'
          );
          // Reopen through the actual Button after changing host text/direction.
          if ((await menu.getAttribute('aria-expanded')) === 'true') await menu.click();
          await revealHeaderPreferences(page);
          const controls = page.locator('#home-preferences [role="combobox"]');
          expect(await controls.count()).toBe(2);
          for (const control of await controls.all()) {
            await control.scrollIntoViewIfNeeded();
            const facts = await control.evaluate((node) => {
              const value = node.querySelector<HTMLElement>(
                '[data-projection-prototype$="-select-value"]'
              )!;
              return {
                rect: node.getBoundingClientRect().toJSON(),
                overflow: value.scrollWidth - value.clientWidth,
                whiteSpace: getComputedStyle(value).whiteSpace,
                hidden: !!node.closest('[hidden], [inert]'),
              };
            });
            expect(facts.hidden).toBe(false);
            expect(facts.rect.height).toBeGreaterThanOrEqual(44);
            expect(facts.whiteSpace).toBe('normal');
            expect(facts.overflow).toBeLessThanOrEqual(1);
          }
          const placement = await page.locator('[data-site-header-panel]').evaluate((panel) => {
            const surface = panel.querySelector('.site-header-popup-surface')!;
            const trigger = document.querySelector(
              '.site-header-menu [data-projection-generation-state="active"] [data-demo-ref="home-menu"]'
            )!;
            return {
              panel: panel.getBoundingClientRect().toJSON(),
              surface: surface.getBoundingClientRect().toJSON(),
              trigger: trigger.getBoundingClientRect().toJSON(),
              header: trigger.closest('[data-site-header]')!.getBoundingClientRect().toJSON(),
              overflow: document.documentElement.scrollWidth - innerWidth,
            };
          });
          expect(placement.overflow).toBeLessThanOrEqual(1);
          expect(Math.abs(placement.panel.top - placement.header.bottom - 5)).toBeLessThanOrEqual(
            1
          );
          expect(
            Math.abs((rtl ? placement.panel.left : placement.panel.right) - (rtl ? 8 : width - 8))
          ).toBeLessThanOrEqual(1);
          expect(Math.abs(placement.surface.width - placement.panel.width)).toBeLessThanOrEqual(1);
          const runtime = page.locator(
            '#home-preferences [data-projection-control="runtime"] [role="combobox"]'
          );
          await runtime.focus();
          await page.setViewportSize({ width: 1440, height: 1000 });
          await expect
            .poll(() =>
              runtime.evaluate(
                (node) =>
                  node === document.activeElement && !node.closest('[data-site-header-panel]')
              )
            )
            .toBe(true);
          await page.setViewportSize({ width, height: 1000 });
          await expect
            .poll(() =>
              runtime.evaluate(
                (node) =>
                  node === document.activeElement &&
                  !!node.closest('[data-site-header-panel]') &&
                  !node.closest('[hidden], [inert]')
              )
            )
            .toBe(true);
          await page.keyboard.press('Escape');
          expect(await menu.evaluate((node) => node === document.activeElement)).toBe(true);
          expect(await page.locator('[data-site-header-panel]').isVisible()).toBe(false);
        }
    } finally {
      await context.close();
    }
  }, 120_000);
}

// Two bounded family journeys, each exercising all four actual renderers. A
// locator re-query is insufficient here: every comparison retains the original
// physical ElementHandle, plus WC's public exposed-state handle identities.
for (const family of ['shadcn', 'brutalist'] as const) {
  it(`retains ${family} preference owners and portals through real breakpoint reconnects`, async () => {
    const context = await browser.newContext({ viewport: { width: 390, height: 844 } });
    const page = await context.newPage();
    const evidenceDirectory = path.join(
      process.env.PROTO_UI_RUNTIME_EVIDENCE_DIR ??
        path.join(process.env.RUNNER_TEMP ?? os.tmpdir(), 'homepage-evidence'),
      'header-breakpoint'
    );
    await mkdir(evidenceDirectory, { recursive: true });
    const source = {
      sha: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
      dirty: execFileSync('git', ['status', '--porcelain'], { encoding: 'utf8' }).trim() !== '',
      expectedSha: process.env.CANDIDATE_SHA ?? null,
      eventSha: process.env.GITHUB_SHA ?? null,
    };
    const records: unknown[] = [];
    const ringFailures: string[] = [];
    const errors: string[] = [];
    const consoleErrors: string[] = [];
    const familyCommitCalls: Array<{
      call: number;
      startedMs: number;
      returnedMs?: number;
      value?: string | null;
      error?: string;
    }> = [];
    const familyCommitTiming = {
      clock: 'Node performance.now() milliseconds',
      timeOrigin: performance.timeOrigin,
      startedMs: null as number | null,
      finishedMs: null as number | null,
      outcome: 'not-run',
      totalCalls: 0,
      droppedCalls: 0,
      observerError: false,
      calls: familyCommitCalls,
      rejectionSnapshot: null as typeof familyCommitCalls | null,
    };
    let utilityObservation: Awaited<ReturnType<typeof prepareUtilityFamilyReadObservation>> | null =
      null;
    // Keep every original Promise until post-verdict settlement; only displayed rows are capped.
    const familyQueryRequests: Array<{
      request: Promise<string | null>;
      call: (typeof familyCommitCalls)[number];
    }> = [];
    const familyQueryObservation = {
      mode: familyQueryMode,
      enabled: {
        node: true,
        writerMO: familyQueryMode !== 'node-only',
        utility: familyQueryMode === 'hybrid',
      },
      ledgerError: false,
      verdict: null as null | { outcome: string; nodeMs: number | null; frozenAtMs: number },
      pendingAtVerdict: [] as typeof familyCommitCalls,
      pendingAtVerdictCount: 0,
      droppedPendingRows: 0,
      referenceCountAtVerdict: 0,
      referenceCountAfterDrain: 0,
      issuedAfterDrain: 0,
      wait: {
        startedMs: null as number | null,
        finishedMs: null as number | null,
        drainedReferences: 0,
        budgetMs: 1000,
        budgetExpired: false,
        pendingAtDrainEndCount: 0,
        pendingAtDrainEnd: [] as typeof familyCommitCalls,
        droppedPendingAtDrainEndRows: 0,
        displayedOutcomes: [] as Array<Record<string, unknown>>,
        droppedOutcomeRows: 0,
        completeAtDrainPoint: false,
      },
      utility: null as Record<string, any> | null,
      cleanupDeferredUntilContextClose: false,
      errors: [] as string[],
    };
    const noteQueryError = (error: unknown) => {
      try {
        familyQueryObservation.errors.push(String(error));
      } catch {
        familyQueryObservation.ledgerError = true;
      }
    };
    let finishQueries: Promise<void> | null = null;
    const finishFamilyQueryObservation = () =>
      (finishQueries ??= (async () => {
        if (family !== 'brutalist') return;
        try {
          familySDK?.freezeVerdict(familyCommitTiming.outcome === 'fulfilled');
          familyQueryObservation.verdict = {
            outcome: familyCommitTiming.outcome,
            nodeMs: familyCommitTiming.finishedMs,
            frozenAtMs: performance.now(),
          };
          familyQueryObservation.referenceCountAtVerdict = familyQueryRequests.length;
          const pending = familyQueryRequests.filter(({ call }) => call.returnedMs === undefined);
          familyQueryObservation.pendingAtVerdictCount = pending.length;
          familyQueryObservation.pendingAtVerdict = pending
            .slice(0, 64)
            .map(({ call }) => ({ ...call }));
          familyQueryObservation.droppedPendingRows = Math.max(0, pending.length - 64);
          try {
            console.info(
              '[family-query-verdict]',
              JSON.stringify({
                source,
                family,
                mode: familyQueryMode,
                verdict: familyQueryObservation.verdict,
                referenceCount: familyQueryObservation.referenceCountAtVerdict,
                pendingCount: pending.length,
                pending: familyQueryObservation.pendingAtVerdict,
                droppedPendingRows: familyQueryObservation.droppedPendingRows,
              })
            );
          } catch (error) {
            noteQueryError(error);
          }
          familyQueryObservation.wait.startedMs = performance.now();
          const drainDeadline =
            familyQueryObservation.wait.startedMs + familyQueryObservation.wait.budgetMs;
          let drained = 0;
          while (drained < familyQueryRequests.length) {
            const batch = familyQueryRequests.slice(drained);
            const settlement = await settleFamilyQueryBatch(
              batch.map(({ request }) => request),
              Math.max(0, drainDeadline - performance.now())
            );
            if (!settlement.complete) {
              familyQueryObservation.wait.budgetExpired = true;
              break;
            }
            const outcomes = settlement.outcomes;
            const observedAtMs = performance.now();
            outcomes.forEach((outcome, index) => {
              try {
                if (familyQueryObservation.wait.displayedOutcomes.length < 64)
                  familyQueryObservation.wait.displayedOutcomes.push({
                    call: batch[index]!.call.call,
                    status: outcome.status,
                    ...('value' in outcome
                      ? { value: outcome.value }
                      : { error: String(outcome.reason) }),
                    batchObservedAtMs: observedAtMs,
                  });
                else familyQueryObservation.wait.droppedOutcomeRows++;
              } catch (error) {
                noteQueryError(error);
              }
            });
            drained += batch.length;
            familyQueryObservation.wait.drainedReferences = drained;
          }
          familyQueryObservation.referenceCountAfterDrain = familyQueryRequests.length;
          const pendingAtDrainEnd = familyQueryRequests.filter(
            ({ call }) => call.returnedMs === undefined
          );
          familyQueryObservation.wait.pendingAtDrainEndCount = pendingAtDrainEnd.length;
          familyQueryObservation.wait.pendingAtDrainEnd = pendingAtDrainEnd
            .slice(0, 64)
            .map(({ call }) => ({ ...call }));
          familyQueryObservation.wait.droppedPendingAtDrainEndRows = Math.max(
            0,
            pendingAtDrainEnd.length - 64
          );
          familyQueryObservation.wait.completeAtDrainPoint =
            !familyQueryObservation.ledgerError &&
            !familyQueryObservation.wait.budgetExpired &&
            drained === familyQueryRequests.length;
        } catch (error) {
          noteQueryError(error);
        } finally {
          familyQueryObservation.wait.finishedMs = performance.now();
        }
        if (utilityObservation) {
          if (familyQueryObservation.wait.completeAtDrainPoint) {
            try {
              familyQueryObservation.utility = await utilityObservation.collectAndRestore();
            } catch (error) {
              noteQueryError(error);
            }
          } else {
            // Unknown/unretained requests cannot be made safe by restoring their hook early.
            familyQueryObservation.cleanupDeferredUntilContextClose = true;
          }
        }
        try {
          console.info(
            '[family-query-settled]',
            JSON.stringify({ source, family, ...familyQueryObservation })
          );
        } catch (error) {
          noteQueryError(error);
        }
      })());
    const observeFamilyMutation = () => {
      const target = document.querySelector<HTMLElement>('[data-homepage-runtime]')!;
      const nativeDataset = target.dataset;
      const ownDataset = Object.getOwnPropertyDescriptor(target, 'dataset');
      const writes: Array<{
        startedMs: number | null;
        finishedMs: number;
        previous: string | null;
        current: string | null;
        returned?: boolean;
        error?: string;
      }> = [];
      let droppedWrites = 0;
      let writerObserverError = false;
      const recordWrite = (
        startedMs: number | null,
        previous: string | null,
        result: { returned: boolean } | { error: unknown }
      ) => {
        try {
          const finishedMs = performance.now();
          if (writes.length < 64)
            writes.push({
              startedMs,
              finishedMs,
              previous,
              current: target.getAttribute('data-family'),
              ...('error' in result ? { error: String(result.error) } : result),
            });
          else droppedWrites += 1;
        } catch {
          writerObserverError = true;
        }
      };
      // This instance-only interposition changes dataset identity/access cost.
      // It brackets the native attribute write, not the complete publication.
      const dataset = new Proxy(nativeDataset, {
        set(subject, key, value) {
          if (key !== 'family') return Reflect.set(subject, key, value, subject);
          let previous: string | null = null;
          let startedMs: number | null = null;
          try {
            previous = target.getAttribute('data-family');
            startedMs = performance.now();
          } catch {
            writerObserverError = true;
          }
          let returned: boolean;
          try {
            returned = Reflect.set(subject, key, value, subject);
          } catch (error) {
            recordWrite(startedMs, previous, { error });
            throw error;
          }
          recordWrite(startedMs, previous, { returned });
          return returned;
        },
      });
      const datasetGetter = () => dataset;
      const deliveries: Array<{
        deliveredMs: number;
        oldValues: Array<string | null>;
        currentValueAtDelivery: string | null;
        connected: boolean;
      }> = [];
      let retainedRecords = 0;
      let droppedRecords = 0;
      let observerError: string | null = null;
      const observer = new MutationObserver((records) => {
        try {
          const deliveredMs = performance.now();
          const retained = records.slice(0, 64 - retainedRecords);
          retainedRecords += retained.length;
          droppedRecords += records.length - retained.length;
          if (retained.length)
            deliveries.push({
              deliveredMs,
              oldValues: retained.map((record) => record.oldValue),
              currentValueAtDelivery: target.getAttribute('data-family'),
              connected: target.isConnected,
            });
        } catch (error) {
          observerError = String(error);
        }
      });
      observer.observe(target, {
        attributes: true,
        attributeFilter: ['data-family'],
        attributeOldValue: true,
      });
      try {
        Object.defineProperty(target, 'dataset', {
          configurable: true,
          enumerable: ownDataset?.enumerable ?? false,
          get: datasetGetter,
        });
      } catch (error) {
        observer.disconnect();
        throw error;
      }
      return {
        target,
        observer,
        deliveries,
        getDroppedRecords: () => droppedRecords,
        getObserverError: () => observerError,
        initialValue: target.getAttribute('data-family'),
        timeOrigin: performance.timeOrigin,
        setupPageMs: performance.now(),
        writes,
        getDroppedWrites: () => droppedWrites,
        getWriterObserverError: () => writerObserverError,
        restoreDataset: () => {
          if (Object.getOwnPropertyDescriptor(target, 'dataset')?.get !== datasetGetter)
            return false;
          if (ownDataset) Object.defineProperty(target, 'dataset', ownDataset);
          else Reflect.deleteProperty(target, 'dataset');
          return target.dataset === nativeDataset;
        },
      };
    };
    let familyMutationHandle: JSHandle<ReturnType<typeof observeFamilyMutation>> | null = null;
    const familyMutationTiming = {
      clock: 'Browser performance.now() milliseconds; MutationObserver delivery, not mutation time',
      setup: null as { nodeStartedMs: number; nodeReturnedMs: number } | null,
      collect: null as { nodeStartedMs: number; nodeReturnedMs: number } | null,
      calibration: [] as Array<{
        nodeStartedMs: number;
        nodeReturnedMs: number;
        timeOrigin: number;
        pageMs: number;
        currentRootSame: boolean;
      }>,
      facts: null as unknown,
      errors: [] as string[],
    };
    const collectFamilyMutation = async () => {
      const handle = familyMutationHandle;
      if (!handle) return;
      familyMutationHandle = null;
      const nodeStartedMs = performance.now();
      try {
        familyMutationTiming.facts = await handle.evaluate((state) => {
          const pending = state.observer.takeRecords();
          const pendingOldValues = pending.slice(0, 64).map((record) => record.oldValue);
          state.observer.disconnect();
          const datasetRestored = state.restoreDataset();
          return {
            timeOrigin: state.timeOrigin,
            collectedTimeOrigin: performance.timeOrigin,
            setupPageMs: state.setupPageMs,
            collectedPageMs: performance.now(),
            initialValue: state.initialValue,
            deliveries: state.deliveries,
            pendingOldValues,
            pendingDroppedRecords: Math.max(0, pending.length - pendingOldValues.length),
            currentValueAtCollection: state.target.getAttribute('data-family'),
            currentRootSame: document.querySelector('[data-homepage-runtime]') === state.target,
            connected: state.target.isConnected,
            droppedRecords: state.getDroppedRecords(),
            observerError: state.getObserverError(),
            writes: state.writes,
            droppedWrites: state.getDroppedWrites(),
            writerObserverError: state.getWriterObserverError(),
            datasetRestored,
          };
        });
      } catch (error) {
        familyMutationTiming.errors.push(String(error));
      } finally {
        familyMutationTiming.collect = { nodeStartedMs, nodeReturnedMs: performance.now() };
      }
      try {
        // Fixed post-poll samples; retain every interval rather than picking a fast one.
        for (let index = 0; index < 3; index += 1) {
          const nodeStartedMs = performance.now();
          const sample = await handle.evaluate((state) => ({
            timeOrigin: performance.timeOrigin,
            pageMs: performance.now(),
            currentRootSame: document.querySelector('[data-homepage-runtime]') === state.target,
          }));
          familyMutationTiming.calibration.push({
            nodeStartedMs,
            nodeReturnedMs: performance.now(),
            ...sample,
          });
        }
      } catch (error) {
        familyMutationTiming.errors.push(String(error));
      } finally {
        await handle.dispose().catch((error) => familyMutationTiming.errors.push(String(error)));
      }
    };
    page.on('console', (message) => {
      if (message.type() === 'error') consoleErrors.push(message.text());
    });
    page.on('pageerror', (error) => errors.push(error.message));
    const familySDK =
      family === 'brutalist'
        ? installDocsCallTimingObserver(page, {
            sdkRoot: path.dirname(
              createRequire(import.meta.url).resolve('playwright-core/package.json')
            ),
            selector: '[data-homepage-runtime]',
            attribute: 'data-family',
          })
        : null;
    let stage = 'navigate';
    const save = async (name: string, facts: unknown) => {
      const id = `${family}-${name}`;
      const screenshot = `${id}.png`;
      const jsonPath = path.join(evidenceDirectory, `${id}.json`);
      const record = {
        source,
        screenshot,
        family,
        stage,
        viewport: page.viewportSize(),
        capturedAt: new Date().toISOString(),
        facts,
      };
      // Retain the primary geometry/ownership facts even if capture itself fails.
      await writeFile(jsonPath, JSON.stringify({ ...record, screenshotComplete: false }, null, 2));
      await page.screenshot({ path: path.join(evidenceDirectory, screenshot) });
      await writeFile(jsonPath, JSON.stringify({ ...record, screenshotComplete: true }, null, 2));
    };
    try {
      await page.goto(`${baseUrl}/zh-cn/`, { waitUntil: 'networkidle' });
      stage = 'initial-ready';
      await ready(page, 'wc');
      if (family === 'brutalist') {
        if (familyQueryMode !== 'node-only') {
          // Bracket a page-clock sample before input; keep the original click/poll interval intact.
          const nodeStartedMs = performance.now();
          try {
            familyMutationHandle = await page.evaluateHandle(observeFamilyMutation);
          } catch (error) {
            familyMutationTiming.errors.push(String(error));
          } finally {
            familyMutationTiming.setup = { nodeStartedMs, nodeReturnedMs: performance.now() };
          }
        }
        stage = 'family-open';
        await revealHeaderPreferences(page);
        const control = page.locator(
          '#home-preferences [data-projection-control="family"] [role="combobox"]'
        );
        await control.click();
        const id = await control.getAttribute('aria-controls');
        if (familyQueryMode === 'hybrid')
          utilityObservation = await prepareUtilityFamilyReadObservation(page);
        stage = 'family-choice';
        await page
          .locator(`[id=${JSON.stringify(id)}]`)
          .getByRole('option', { name: 'Brutalist', exact: true })
          .click();
        stage = 'family-commit';
        familyCommitTiming.startedMs = performance.now();
        familyCommitTiming.outcome = 'pending';
        await expect
          .poll(() => {
            const call: (typeof familyCommitCalls)[number] = {
              call: ++familyCommitTiming.totalCalls,
              startedMs: performance.now(),
            };
            if (familyCommitCalls.length < 64) familyCommitCalls.push(call);
            else familyCommitTiming.droppedCalls += 1;
            const request: Promise<string | null> = familySDK!.runOriginalQuery(call.call, () =>
              page.locator('[data-homepage-runtime]').getAttribute('data-family')
            );
            try {
              familyQueryRequests.push({ request, call });
              if (familyQueryObservation.wait.finishedMs !== null)
                familyQueryObservation.issuedAfterDrain++;
            } catch {
              familyQueryObservation.ledgerError = true;
            }
            void request
              .then(
                (value) => {
                  call.returnedMs = performance.now();
                  call.value = value;
                },
                (error) => {
                  call.returnedMs = performance.now();
                  call.error = String(error);
                }
              )
              .catch(() => {
                familyCommitTiming.observerError = true;
              });
            return request;
          })
          .toBe(family);
        familyCommitTiming.finishedMs = performance.now();
        familyCommitTiming.outcome = 'fulfilled';
        await finishFamilyQueryObservation();
        await collectFamilyMutation();
        stage = 'family-ready';
        await ready(page, 'wc');
      }
      for (const runtime of RUNTIMES) {
        stage = `${runtime}-setup`;
        await page.setViewportSize({ width: 390, height: 844 });
        await switchRuntime(page, runtime);
        const header = page.locator('[data-homepage-runtime]');
        const generation = await header.getAttribute('data-runtime-generation');
        const handles = new Map<string, ElementHandle<HTMLElement>>();
        for (const control of ['runtime', 'family'] as const) {
          stage = `${runtime}-${control}-lease`;
          const triggerLocator = page.locator(
            `#home-preferences [data-projection-control="${control}"] [role="combobox"]`
          );
          const rootLocator = page.locator(
            `#home-preferences [data-demo-ref="__pui_projection__${control}_root"]`
          );
          await expect.poll(() => triggerLocator.count()).toBe(1);
          await expect.poll(() => rootLocator.count()).toBe(1);
          const trigger = (await triggerLocator.elementHandle()) as ElementHandle<HTMLElement>;
          const root = (await rootLocator.elementHandle()) as ElementHandle<HTMLElement>;
          expect(trigger).not.toBeNull();
          expect(root).not.toBeNull();
          handles.set(control, trigger);
          const lease = await trigger.evaluateHandle(captureHeaderPreferenceLease, {
            root,
            control,
          });
          let portal: ElementHandle<HTMLElement> | null = null;
          let selected: ElementHandle<HTMLElement> | null = null;
          try {
            await trigger.focus();
            await page.keyboard.press('Enter');
            const id = await trigger.getAttribute('aria-controls');
            expect(id).toBeTruthy();
            const portalLocator = page.locator(`[id=${JSON.stringify(id)}]`);
            await portalLocator.waitFor({ state: 'visible' });
            const expectedLabel =
              control === 'runtime'
                ? LABELS[runtime]
                : family === 'shadcn'
                  ? 'Shadcn'
                  : 'Brutalist';
            const selectedLocator = portalLocator.getByRole('option', {
              name: expectedLabel,
              exact: true,
            });
            await expect
              .poll(() =>
                selectedLocator.evaluate(
                  (node) =>
                    node === document.activeElement && node.getAttribute('aria-selected') === 'true'
                )
              )
              .toBe(true);
            portal = (await portalLocator.elementHandle()) as ElementHandle<HTMLElement>;
            selected = (await selectedLocator.elementHandle()) as ElementHandle<HTMLElement>;
            for (const [name, width, insidePanel] of [
              ['mobile-before', 390, true],
              ['desktop', 1440, false],
              ['mobile-return', 320, true],
            ] as const) {
              stage = `${runtime}-${control}-${name}`;
              await page.setViewportSize({ width, height: 844 });
              await expect
                .poll(() =>
                  lease
                    .evaluate(inspectHeaderPreferenceLease, {
                      insidePanel,
                      portal: portal!,
                      selected: selected!,
                      focused: 'portal' as const,
                    })
                    .then(headerPreferenceLeaseIssues)
                )
                .toEqual([]);
              const facts = await lease.evaluate(inspectHeaderPreferenceLease, {
                insidePanel,
                portal,
                selected,
                focused: 'portal' as const,
              });
              records.push({ stage, facts });
              if (control === 'runtime') await save(stage, facts);
              expect(await header.getAttribute('data-runtime-generation')).toBe(generation);
              expect(await trigger.getAttribute('aria-controls')).toBe(id);
            }
            // Re-select the current value using native keys, so a legitimate
            // runtime/family change cannot hide a breakpoint-induced remount.
            stage = `${runtime}-${control}-keyboard-commit-current`;
            await page.keyboard.press('Home');
            const options = control === 'runtime' ? Object.values(LABELS) : ['Shadcn', 'Brutalist'];
            for (let index = 0; index < options.indexOf(expectedLabel); index++)
              await page.keyboard.press('ArrowDown');
            await expect
              .poll(() => selected!.evaluate((node) => node === document.activeElement))
              .toBe(true);
            await page.keyboard.press('Enter');
            await expect.poll(() => portal!.isVisible()).toBe(false);
            await expect
              .poll(() =>
                lease
                  .evaluate(inspectHeaderPreferenceLease, {
                    insidePanel: true,
                    focused: 'trigger' as const,
                  })
                  .then(headerPreferenceLeaseIssues)
              )
              .toEqual([]);
            records.push({
              stage,
              facts: await lease.evaluate(inspectHeaderPreferenceLease, {
                insidePanel: true,
                focused: 'trigger' as const,
              }),
            });
            expect(await header.getAttribute('data-runtime-generation')).toBe(generation);
          } finally {
            await lease.dispose();
            await root.dispose();
            await portal?.dispose();
            await selected?.dispose();
          }
        }
        // The compact closed state must remove the settings row. Do not change
        // app DOM or force a hidden Select to obtain its focus-ring capture.
        stage = `${runtime}-closed`;
        await page.keyboard.press('Escape');
        const menu = page.locator(
          '.site-header-menu [data-projection-generation-state="active"] [data-demo-ref="home-menu"]'
        );
        await expect.poll(() => menu.getAttribute('aria-expanded')).toBe('false');
        expect(await header.locator('[data-site-header-preferences]').isVisible()).toBe(false);
        expect((await header.boundingBox())!.height).toBeLessThanOrEqual(64);
        await page.setViewportSize({ width: 320, height: 300 });
        await menu.focus();
        await page.keyboard.press('Enter');
        const firstLink = page
          .locator('#home-navigation-mobile [data-homepage-mount] a[href]')
          .first();
        await expect
          .poll(() => firstLink.evaluate((node) => node === document.activeElement))
          .toBe(true);
        const unfocused = await handles.get('runtime')!.evaluate(measureHeaderPreferenceFocusRing);
        for (let index = 0; index < 3; index++) await page.keyboard.press('Tab');
        for (const control of ['runtime', 'family'] as const) {
          stage = `${runtime}-${control}-narrow-focus-ring`;
          const trigger = handles.get(control)!;
          await expect
            .poll(() =>
              trigger.evaluate(
                (node) => node === document.activeElement && node.matches(':focus-visible')
              )
            )
            .toBe(true);
          const expectedToken = family === 'shadcn' ? 'ring-3' : 'ring-2';
          if (family === 'brutalist' && control === 'runtime') {
            // Elevated Brutalist transitions the shadow after publishing its ring token.
            // Use the original poll window for the visual state that the capture asserts.
            await expect
              .poll(() =>
                trigger.evaluate(
                  (node, restingShadow) => ({
                    tokens: node.getAttribute('data-pui-style') ?? '',
                    painted:
                      node === node.ownerDocument.activeElement &&
                      node.matches(':focus-visible') &&
                      getComputedStyle(node).boxShadow !== restingShadow,
                  }),
                  unfocused.shadow
                )
              )
              .toEqual({ tokens: expect.stringContaining(expectedToken), painted: true });
          } else {
            await expect
              .poll(() => trigger.getAttribute('data-pui-style'))
              .toContain(expectedToken);
          }
          const facts = await trigger.evaluate(measureHeaderPreferenceFocusRing);
          records.push({ stage, facts });
          await save(stage, { unfocused, focused: facts });
          if (!facts.unclipped || !facts.inViewport)
            ringFailures.push(
              `${stage}: ${JSON.stringify({ ring: facts.ring, viewport: facts.viewport, clipping: facts.clipping })}`
            );
          expect(facts.prototype).toBe(`${family}-select-trigger`);
          expect(facts.ringWidth).toBe(family === 'shadcn' ? 3 : 2);
          expect(facts.ringOffset).toBe(family === 'shadcn' ? 0 : 2);
          expect(facts.shadow).not.toBe('none');
          if (control === 'runtime') expect(facts.shadow).not.toBe(unfocused.shadow);
          if (control === 'runtime') await page.keyboard.press('Tab');
        }
        await page.keyboard.press('Escape');
        await expect
          .poll(() => menu.evaluate((node) => node === document.activeElement))
          .toBe(true);
        for (const handle of handles.values()) await handle.dispose();
      }
      expect(errors).toEqual([]);
      // Collect every family/runtime sample before reporting clipping debt.
      expect(ringFailures, 'Prototype focus rings must fit all real clipping boundaries').toEqual(
        []
      );
    } catch (error) {
      if (stage === 'family-commit') {
        familyCommitTiming.finishedMs = performance.now();
        familyCommitTiming.outcome = 'rejected';
        familyCommitTiming.rejectionSnapshot = familyCommitCalls.map((call) => ({ ...call }));
      }
      await finishFamilyQueryObservation();
      await collectFamilyMutation();
      const failureState = await page
        .evaluate(() => {
          const header = document.querySelector<HTMLElement>('[data-homepage-runtime]');
          const demo = document.querySelector<HTMLElement>('[data-home-showcase]');
          const trigger = header?.querySelector<HTMLElement>(
            '[data-projection-control="family"] [role="combobox"]'
          );
          const portalId = trigger?.getAttribute('aria-controls');
          const portal = portalId ? document.getElementById(portalId) : null;
          const sample = (element: HTMLElement | null | undefined) =>
            element
              ? {
                  tag: element.tagName,
                  id: element.id,
                  connected: element.isConnected,
                  dataset: { ...element.dataset },
                  busy: element.getAttribute('aria-busy'),
                  hidden: !!element.closest('[hidden], [inert]'),
                }
              : null;
          return {
            header: sample(header),
            showcase: sample(demo),
            status: header?.querySelector('[data-homepage-runtime-status]')?.textContent,
            transaction: (
              header as HTMLElement & { __homepageRuntime__?: { getSnapshot(): unknown } }
            )?.__homepageRuntime__?.getSnapshot(),
            generations: Array.from(
              header?.querySelectorAll<HTMLElement>('[data-projection-generation-state]') ?? []
            ).map(sample),
            familyTrigger: sample(trigger),
            familyValue: trigger?.textContent,
            portal: sample(portal),
          };
        })
        .catch((captureError) => ({ captureError: String(captureError) }));
      await save('failure', {
        stage,
        message: String(error),
        familyCommitTiming,
        familyMutationTiming,
        records,
        ringFailures,
        errors,
        consoleErrors,
        failureState,
      });
      throw error;
    } finally {
      if (family === 'brutalist') await finishFamilyQueryObservation();
      await writeFile(
        path.join(evidenceDirectory, `${family}-lifecycle.json`),
        JSON.stringify(
          {
            source,
            family,
            records,
            ringFailures,
            errors,
            consoleErrors,
            familyCommitTiming,
            familyMutationTiming,
          },
          null,
          2
        )
      );
      if (family === 'brutalist') {
        console.info(
          '[family-commit-poll-timing]',
          JSON.stringify({ source, familyCommitTiming, familyMutationTiming })
        );
      }
      let contextCloseSucceeded = false;
      try {
        await context.close();
        contextCloseSucceeded = true;
      } finally {
        try {
          familySDK?.disposeAfterContextClosed(contextCloseSucceeded);
          if (familySDK)
            await settleFamilyQueryBatch(
              [
                writeFile(
                  path.join(evidenceDirectory, `${family}-sdk-timing.json`),
                  JSON.stringify({ source, family, observation: familySDK.snapshot() }, null, 2)
                ),
              ],
              2000
            );
        } catch (error) {
          noteQueryError(error);
        }
        if (utilityObservation && familyQueryObservation.cleanupDeferredUntilContextClose) {
          try {
            familyQueryObservation.utility =
              await utilityObservation.disposeIncompleteCapture(contextCloseSucceeded);
          } catch (error) {
            noteQueryError(error);
          }
        }
        if (family === 'brutalist') {
          try {
            const report = {
              source,
              family,
              ...familyQueryObservation,
              referenceCountAtReport: familyQueryRequests.length,
              pendingObservedAtReport: familyQueryRequests.filter(
                ({ call }) => call.returnedMs === undefined
              ).length,
              droppedNodeRows: familyCommitTiming.droppedCalls,
              captureCoversAllRecordedQueries:
                !familyQueryObservation.ledgerError &&
                familyQueryObservation.issuedAfterDrain === 0 &&
                familyQueryObservation.wait.completeAtDrainPoint &&
                familyQueryObservation.wait.droppedOutcomeRows === 0 &&
                familyQueryObservation.droppedPendingRows === 0 &&
                familyCommitTiming.droppedCalls === 0,
            };
            console.info('[family-query-observation]', JSON.stringify(report));
            await writeFile(
              path.join(evidenceDirectory, `${family}-query-observation.json`),
              JSON.stringify(report, null, 2)
            );
          } catch (error) {
            noteQueryError(error);
            try {
              console.info('[family-query-capture-error]', String(error));
            } catch {
              /* Retain original outcome. */
            }
          }
        }
      }
    }
  }, 180_000);
}
