import base from "/workspace/scratch/5e512bf106bf/proto-ui-recovery/vitest.config.ts";
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const sourceRoot="/tmp/contents-transaction-baseline-7642/packages/modules/positioning/src";
const proof="/tmp/contents-transaction-baseline-7642/loaded-source.jsonl";
export default { ...base, plugins: [{name:'record-frozen-positioning-source',enforce:'pre',load(id){if(id.startsWith(sourceRoot+'/') && fs.existsSync(id)){fs.appendFileSync(proof,JSON.stringify({path:id,sha256:crypto.createHash('sha256').update(fs.readFileSync(id)).digest('hex')})+'\n');}return null;}}, ...(base.plugins ?? [])], test:{...base.test,include:["/tmp/contents-transaction-baseline-7642/packages/modules/positioning/test/floating-ui-host-intrinsic-invalidation.test.ts"],reporters:['verbose','json'],outputFile:{json:"/tmp/contents-transaction-baseline-7642/result.json"}}};
