from pathlib import Path
import subprocess,json,datetime
b=Path('/tmp/s5-qt-native-requests-f7b2')
with (b/'run.log').open('w') as o:p=subprocess.run(['python3','run.py'],cwd=b,stdout=o,stderr=subprocess.STDOUT)
(b/'finished.json').write_text(json.dumps({'exitCode':p.returncode,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
