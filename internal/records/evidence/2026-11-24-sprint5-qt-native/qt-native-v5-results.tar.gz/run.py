from pathlib import Path
import os,subprocess,json,hashlib,datetime,time,traceback
task=Path('/tmp/s5-qt-native-requests-f7b2')
source=task/'qt-native-v5'
sysroot=Path('/tmp/s5-qt-sdk-f7b2/sysroot')
sdk=Path('/tmp/s5-qt-sdk-f7b2/sdk/6.4.2/gcc_64')
python=Path('/tmp/s5-qt-sdk-f7b2/python')
logs=task/'logs';logs.mkdir(parents=True,exist_ok=True)
env=os.environ.copy()
env.update(PYTHONPATH=str(python),PATH=str(python/'bin')+':'+env['PATH'],LD_LIBRARY_PATH=str(sdk/'lib')+':'+str(sysroot/'usr/lib/x86_64-linux-gnu')+':'+env.get('LD_LIBRARY_PATH',''),QML_IMPORT_PATH=str(sdk/'qml'),QT_PLUGIN_PATH=str(sdk/'plugins'),QT_QPA_PLATFORM='offscreen',QT_QUICK_BACKEND='software',TMPDIR=str(task/'tmp'))
(task/'tmp').mkdir(exist_ok=True)
status={'source':'actual parsed, cold-validated direct emitter output; no generated product edits','qt':'6.4.2','mode':'real Qt Quick; offscreen software platform, no physical GPU/AT claim','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[],'status':'running'}
def save(): (task/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def digest():
 receipt=json.loads((source/'source-receipt.json').read_text())
 return [{'path':x['file'],'sha256':hashlib.sha256((source/x['file']).read_bytes()).hexdigest(),'matches':hashlib.sha256((source/x['file']).read_bytes()).hexdigest()==x['sha256']} for x in receipt['files']]
def run(label,args,timeout):
 entry={'label':label,'args':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};status['commands'].append(entry);save();start=time.monotonic()
 with (logs/(label+'.log')).open('w') as log:
  result=subprocess.run(args,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 entry.update(exitCode=result.returncode,seconds=time.monotonic()-start,endedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
 if result.returncode: raise RuntimeError(label+' exit '+str(result.returncode))
 return (logs/(label+'.log')).read_text()
try:
 status['before']=digest();save()
 assert all(x['matches'] for x in status['before'])
 run('configure',[str(python/'bin/cmake'),'-S','.','-B',str(task/'build-v5'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(sdk)+';'+str(sysroot/'usr'),'-DCMAKE_INCLUDE_PATH='+str(sysroot/'usr/include'),'-DCMAKE_LIBRARY_PATH='+str(sysroot/'usr/lib/x86_64-linux-gnu')],180)
 run('build',[str(python/'bin/cmake'),'--build',str(task/'build-v5'),'--parallel','2'],180)
 output=run('consumer',[str(task/'build-v5/compiled-qt'),str(source/'Consumer.qml')],30)
 lines=[line.split('PUI_QT_RESULT ',1)[1] for line in output.splitlines() if 'PUI_QT_RESULT ' in line]
 assert len(lines)==1, 'Expected exactly one outcome receipt'
 result=json.loads(lines[0]);status['consumer']=result
 assert result.get('passed')==12 and result.get('failed')==0, 'Unexpected actual consumer outcomes'
 status['status']='passed'
except BaseException as error:
 status['status']='failed';status['error']=str(error);status['exception']=traceback.format_exc()
finally:
 status['after']=digest();status['generatedDrift']=[x for x in status['after'] if not x['matches']]
 status['endedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps({key:status.get(key) for key in ['status','error','consumer','generatedDrift']},indent=2))

raise SystemExit(0 if status['status']=='passed' and not status['generatedDrift'] else 1)
