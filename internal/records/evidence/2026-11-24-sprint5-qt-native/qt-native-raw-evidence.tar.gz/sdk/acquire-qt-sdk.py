import subprocess,os,json,pathlib,datetime,sys,traceback
root=pathlib.Path('/tmp/s5-qt-sdk-f7b2')
root.mkdir(exist_ok=True)
status={'task':'Sprint 5 actual Qt 6.4.2 SDK acquisition','authorization':'Current user requested completion of Sprint 5; task-local build tools and SDK only','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','commands':[]}
env=dict(os.environ)
env['PYTHONPATH']=str(root/'python')
env['PATH']=str(root/'python/bin')+':'+env['PATH']
env['TMPDIR']=str(root/'tmp');(root/'tmp').mkdir(exist_ok=True)
def save(): (root/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def run(name,args,timeout=1200):
 record={'name':name,'args':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};status['commands'].append(record);save()
 with (root/(name+'.log')).open('w') as f: p=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 record.update(exitCode=p.returncode,endedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
 if p.returncode: raise RuntimeError(name+' failed with '+str(p.returncode))
 return (root/(name+'.log')).read_text()
save()
try:
 run('pip-version',['python3','-m','pip','--version'])
 run('tools-install',['python3','-m','pip','install','--target',str(root/'python'),'--report',str(root/'installer-report.json'),'aqtinstall==3.3.0','cmake','ninja'])
 archives=run('qt-archives',['python3','-m','aqt','list-qt','linux','desktop','--archives','6.4.2','gcc_64'])
 available=set(archives.split())
 assert {'qtbase','qtdeclarative'}<=available,archives
 selected=[name for name in ['qtbase','qtdeclarative','qtshadertools','qtsvg','icu'] if name in available]
 status['selectedArchives']=selected;save()
 run('qt-install',['python3','-m','aqt','install-qt','linux','desktop','6.4.2','gcc_64','--outputdir',str(root/'sdk'),'--archives',*selected])
 run('qt-version',[str(root/'sdk/6.4.2/gcc_64/bin/qmake'),'-query'])
 run('cmake-version',[str(root/'python/bin/cmake'),'--version'])
 run('ninja-version',[str(root/'python/bin/ninja'),'--version'])
 status['status']='passed'
except BaseException as e:
 status['status']='failed';status['error']=str(e);traceback.print_exc()
finally:
 status['endedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
sys.exit(0 if status['status']=='passed' else 1)
