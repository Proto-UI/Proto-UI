import QtQuick 6.4
import QtQuick.Window 6.4
import "." as Generated
Window {
    id: window
    width: 640; height: 480; visible: true
    property int stage: 0
    property var oldRoot: null
    property var owner: null
    property var oldExposes: null
    property int oldEpoch: 0
    property var receipts: []
    Generated.Component {
        id: compiled
        Rectangle { width: 1600; height: 1600; color: "lightblue" }
    }
    function assert(value,message) { if(!value)throw new Error(message) }
    function record(name) { receipts.push({name:name,status:"passed"}); console.log("PUI_QT_CASE "+JSON.stringify(receipts[receipts.length-1])) }
    Timer {
        interval: 50; running: true; repeat: true
        onTriggered: {
            try {
                var exposes=compiled.getExposes()
                if(stage===0) {
                    assert(compiled.present && compiled.nativeRoot!==null,"actual view mounted")
                    owner=compiled.logicalOwner; oldRoot=compiled.nativeRoot; oldEpoch=compiled.viewEpoch; oldExposes=exposes
                    var initial=exposes.snapshot()
                    assert(initial.axes==="vertical" && initial.projection==="system","actual vertical/system facts")
                    assert(oldRoot.width===240 && oldRoot.height===200,"240x200 native viewport")
                    assert(initial.vertical.visibleRatio>0 && initial.vertical.visibleRatio<1,"actual overflow")
                    record("initial native Flickable viewport and facts")
                    exposes.extra(); stage=1
                } else if(stage===1) {
                    var horizontal=exposes.snapshot()
                    assert(horizontal.axes==="horizontal" && horizontal.projection==="system","axes-only sync retains projection")
                    assert(compiled.logicalOwner===owner && compiled.nativeRoot===oldRoot,"sync preserves owner and view")
                    assert(oldRoot.scrollOptions.endFollow.axis==="vertical" && oldRoot.scrollOptions.endFollow.mode==="while-at-end","sync retains follow policy")
                    exposes.same(); assert(exposes.snapshot().axes==="horizontal","missing axes no-op")
                    record("axes-only sync and unrelated policy preservation")
                    compiled.setProps({present:false}); stage=2
                } else if(stage===2) {
                    assert(!compiled.present && compiled.nativeRoot===null,"view actually detached")
                    assert(exposes.snapshot().projection==="unresolved","detached physical fact")
                    exposes.both(); assert(exposes.snapshot().axes==="horizontal","detached intent does not forge facts")
                    compiled.setProps({present:true}); stage=3
                } else if(stage===3) {
                    assert(compiled.present && compiled.nativeRoot!==null && compiled.nativeRoot!==oldRoot,"replacement physical root")
                    assert(compiled.logicalOwner===owner && compiled.viewEpoch>oldEpoch,"same owner with new view epoch")
                    assert(exposes.snapshot().axes==="both","replacement adopts retained axes")
                    assert(exposes.snapshot().vertical.visibleRatio<1,"slot remains native and overflows after reconnect")
                    record("detach and same-owner replacement with retained intent")
                    compiled.dispose(); var refused=false
                    try { oldExposes.horizontal() } catch(error) { refused=true }
                    assert(refused && compiled.disposed && compiled.logicalOwner===null,"terminal old callable refusal")
                    record("terminal old callable refusal")
                    console.log("PUI_QT_RESULT "+JSON.stringify({passed:receipts.length,failed:0,cases:receipts,qt:"6.4.2",platform:"offscreen"}))
                    running=false; Qt.quit()
                }
            } catch(error) {
                running=false
                console.log("PUI_QT_RESULT "+JSON.stringify({passed:receipts.length,failed:1,stage:stage,error:String(error),cases:receipts}))
                throw error
            }
        }
    }
}
