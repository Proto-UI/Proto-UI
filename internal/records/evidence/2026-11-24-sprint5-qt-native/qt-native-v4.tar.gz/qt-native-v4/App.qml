import QtQuick 6.4
import QtQuick.Window 6.4
import "." as Generated
Window {
    width: 640; height: 480; visible: true
    Generated.Component { id: compiled; anchors.centerIn: parent }
}
