#pragma once
#include <QQuickItem>
#include <QPointer>
#include <QEvent>
#include <QVariantMap>

// Native physical item, not a semantic Runtime. Accessibility reads current Qt facts.
class QtNativeNode : public QQuickItem {
    Q_OBJECT
    Q_PROPERTY(QVariantMap facts READ facts WRITE setFacts NOTIFY factsChanged)
public:
    explicit QtNativeNode(QQuickItem *parent = nullptr);
    ~QtNativeNode() override;
    QVariantMap facts() const { return facts_; }
    void setFacts(const QVariantMap &value);
    Q_INVOKABLE void notifyAccessibleName();
    Q_INVOKABLE void notifyAccessibleFocus();
signals:
    void factsChanged();
    void nativeAccessibleAction(const QString &name);
private:
    QVariantMap facts_;
};

class QtNativeInputEvent : public QObject {
    Q_OBJECT
    Q_PROPERTY(QString key MEMBER key CONSTANT)
    Q_PROPERTY(QString text MEMBER text CONSTANT)
    Q_PROPERTY(int modifiers MEMBER modifiers CONSTANT)
    Q_PROPERTY(int button MEMBER button CONSTANT)
    Q_PROPERTY(bool isAutoRepeat MEMBER isAutoRepeat CONSTANT)
    Q_PROPERTY(bool accepted READ accepted WRITE setAccepted)
    Q_PROPERTY(qreal x MEMBER x CONSTANT)
    Q_PROPERTY(qreal y MEMBER y CONSTANT)
public:
    explicit QtNativeInputEvent(QEvent *event, QObject *parent=nullptr);
    QString key, text;
    int modifiers=0, button=0;
    bool isAutoRepeat=false;
    qreal x=0, y=0;
    bool accepted() const { return prevented_; }
    void setAccepted(bool value);
    bool prevented() const { return prevented_; }
    void close() { event_=nullptr; }
private:
    QEvent *event_;
    bool prevented_=false;
};

class QtNativeInputObserver : public QObject {
    Q_OBJECT
    Q_PROPERTY(QQuickItem* root READ root WRITE setRoot NOTIFY rootChanged)
public:
    explicit QtNativeInputObserver(QObject *parent=nullptr);
    ~QtNativeInputObserver() override;
    QQuickItem *root() const { return root_; }
    void setRoot(QQuickItem *value);
signals:
    void rootChanged();
    void observed(const QString &name, QObject *event);
protected:
    bool eventFilter(QObject *watched, QEvent *event) override;
private:
    QPointer<QQuickItem> root_;
    bool pointerHeld_=false;
    QPointF pointerStart_;
};
void registerQtNativeTypes();
