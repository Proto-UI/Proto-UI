export function projectNativeTable(input) {
    var _a, _b, _c, _d;
    const diagnostics = [];
    if (input.captions.length > 1)
        diagnostics.push({ code: 'multiple-captions' });
    if (!input.rows.length)
        diagnostics.push({ code: 'missing-row' });
    for (const ref of input.unmatchedCells)
        diagnostics.push({ code: 'missing-row-parent', ref });
    for (const ref of input.roleMismatches)
        diagnostics.push({ code: 'role-mismatch', ref });
    let headerCount = 0, cellCount = 0;
    const dimensions = new Map();
    for (let row = 0; row < input.rows.length; row++) {
        const current = input.rows[row];
        if (!current.cells.length)
            diagnostics.push({ code: 'empty-row', ref: current.ref, row });
        for (const cell of current.cells) {
            if (cell.kind === 'headerCell') {
                ++headerCount;
                if (!cell.headerKey)
                    diagnostics.push({ code: 'missing-header-key', ref: cell.ref, row });
                if (cell.headerKind !== 'column' && cell.headerKind !== 'row')
                    diagnostics.push({ code: 'missing-header-kind', ref: cell.ref, row });
            }
            else
                ++cellCount;
            const rowSpan = (_a = cell.rowSpan) !== null && _a !== void 0 ? _a : 1, columnSpan = (_b = cell.columnSpan) !== null && _b !== void 0 ? _b : 1;
            if (!Number.isSafeInteger(rowSpan) || rowSpan <= 0 || !Number.isSafeInteger(columnSpan) || columnSpan <= 0) {
                diagnostics.push({ code: 'invalid-span', ref: cell.ref });
                dimensions.set(cell, null);
            }
            else
                dimensions.set(cell, { rowSpan, columnSpan });
        }
    }
    if (!headerCount)
        diagnostics.push({ code: 'missing-header-cell' });
    if (!cellCount)
        diagnostics.push({ code: 'missing-cell' });
    const occupied = new Map(), placed = new Map();
    const rows = [];
    let columnCount = 0;
    for (let row = 0; row < input.rows.length; row++) {
        const rowInput = input.rows[row], cells = [];
        let cursor = 0;
        for (const cell of rowInput.cells) {
            const dimensionsForCell = dimensions.get(cell);
            if (!dimensionsForCell)
                continue;
            const { rowSpan, columnSpan } = dimensionsForCell;
            if (row + rowSpan > input.rows.length) {
                diagnostics.push({ code: 'row-span-out-of-range', ref: cell.ref, row });
                continue;
            }
            let column = cursor, columnValid = true;
            for (;;) {
                const end = column + columnSpan;
                if (!Number.isSafeInteger(end)) {
                    columnValid = false;
                    break;
                }
                let next = column;
                for (let offset = 0; offset < rowSpan; offset++)
                    for (const interval of (_c = occupied.get(row + offset)) !== null && _c !== void 0 ? _c : []) {
                        if (interval.end <= column)
                            continue;
                        if (interval.start >= end)
                            break;
                        next = Math.max(next, interval.end);
                        break;
                    }
                if (next === column)
                    break;
                column = next;
            }
            if (!columnValid) {
                diagnostics.push({ code: 'column-range-out-of-range', ref: cell.ref, row });
                continue;
            }
            const end = column + columnSpan;
            for (let offset = 0; offset < rowSpan; offset++) {
                const rowIndex = row + offset, intervals = (_d = occupied.get(rowIndex)) !== null && _d !== void 0 ? _d : [];
                let at = 0, start = column, mergedEnd = end;
                while (at < intervals.length && intervals[at].end < column)
                    ++at;
                while (at < intervals.length && intervals[at].start <= mergedEnd) {
                    start = Math.min(start, intervals[at].start);
                    mergedEnd = Math.max(mergedEnd, intervals[at].end);
                    intervals.splice(at, 1);
                }
                intervals.splice(at, 0, { start, end: mergedEnd });
                occupied.set(rowIndex, intervals);
            }
            cursor = end;
            columnCount = Math.max(columnCount, cursor);
            const projected = { ref: cell.ref, kind: cell.kind === 'cell' ? 'cell' : cell.headerKind === 'row' ? 'row-header' : 'column-header', row, column, rowSpan, columnSpan, columnHeaders: [], rowHeaders: [], orderedHeaders: [] };
            cells.push(projected);
            placed.set(cell, projected);
        }
        rows.push({ ref: rowInput.ref, index: row, cells });
    }
    const headersByKey = new Map();
    for (const row of input.rows)
        for (const cell of row.cells)
            if (cell.kind === 'headerCell' && cell.headerKey) {
                const matches = headersByKey.get(cell.headerKey);
                if (matches)
                    matches.push(cell);
                else
                    headersByKey.set(cell.headerKey, [cell]);
            }
    for (const [headerKey, matches] of headersByKey)
        if (matches.length > 1)
            diagnostics.push({ code: 'duplicate-header-key', ref: matches[0].ref, headerKey });
    for (let row = 0; row < input.rows.length; row++)
        for (const cell of input.rows[row].cells) {
            if (cell.kind === 'cell' && !cell.headers.length)
                diagnostics.push({ code: 'missing-cell-headers', ref: cell.ref, row });
            const source = placed.get(cell), seen = new Set();
            for (const headerKey of cell.headers) {
                if (!headerKey) {
                    diagnostics.push({ code: 'empty-header-reference', ref: cell.ref, row });
                    continue;
                }
                if (seen.has(headerKey)) {
                    diagnostics.push({ code: 'duplicate-header-reference', ref: cell.ref, row, headerKey });
                    continue;
                }
                seen.add(headerKey);
                const matches = headersByKey.get(headerKey);
                if (!matches) {
                    diagnostics.push({ code: 'missing-header-target', ref: cell.ref, row, headerKey });
                    continue;
                }
                if (matches.length !== 1) {
                    diagnostics.push({ code: 'ambiguous-header-target', ref: cell.ref, row, headerKey });
                    continue;
                }
                const targetInput = matches[0], target = placed.get(targetInput);
                if (!target) {
                    diagnostics.push({ code: 'unprojectable-header-target', ref: cell.ref, row, headerKey });
                    continue;
                }
                if (cell.kind === 'headerCell' && source && (target.row > source.row || target.row === source.row && target.column >= source.column)) {
                    diagnostics.push({ code: 'non-upstream-header-target', ref: cell.ref, row, headerKey });
                    continue;
                }
                if (!source)
                    continue;
                source.orderedHeaders.push(targetInput.ref);
                if (targetInput.headerKind === 'row')
                    source.rowHeaders.push(targetInput.ref);
                else
                    source.columnHeaders.push(targetInput.ref);
            }
        }
    return Object.freeze({ root: input.root, caption: input.captions.length === 1 ? input.captions[0] : undefined, rowCount: input.rows.length, columnCount,
        rows: Object.freeze(rows.map(row => Object.freeze(Object.assign(Object.assign({}, row), { cells: Object.freeze(row.cells.map(cell => Object.freeze(Object.assign(Object.assign({}, cell), { columnHeaders: Object.freeze(cell.columnHeaders), rowHeaders: Object.freeze(cell.rowHeaders), orderedHeaders: Object.freeze(cell.orderedHeaders) })))) })))),
        valid: !diagnostics.length, diagnostics: Object.freeze(diagnostics.map(diagnostic => Object.freeze(diagnostic))) });
}
