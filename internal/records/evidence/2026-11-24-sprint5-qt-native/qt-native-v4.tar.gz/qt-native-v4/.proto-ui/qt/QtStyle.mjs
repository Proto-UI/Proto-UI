// Qt Quick style contributions, immediate projection only. No semantic render callback.
export function createStyle(options, table) {
  const chunks = [], rules = [], patches = new Map();
  let mounted = false, disposed = false, sequence = 0;
  function append(merged, handles) {
    for (const handle of handles) {
      if (!handle || handle.kind !== 'tw' || handle.tokens.length !== handle.groups.length) throw new TypeError('Invalid checked style handle');
      for (let i = 0; i < handle.tokens.length; ++i) merged.set(handle.groups[i], handle.tokens[i]);
    }
  }
  function tokens() {
    const merged = new Map();
    for (const chunk of chunks) if (chunk.active) append(merged, chunk.handles);
    if (mounted) for (const rule of rules) if (rule.active && rule.test()) append(merged, rule.handles);
    for (const group of patches.keys()) merged.delete(group);
    for (const [group, token] of patches) if (token !== null) merged.set(group, token);
    return Array.from(merged.values());
  }
  function properties(list) {
    const result = {};
    for (const token of list) {
      const entry = table[token];
      if (!entry) throw new Error('Unmapped Qt Quick token: ' + token);
      Object.assign(result, entry);
    }
    return result;
  }
  function refresh() { if (mounted && !disposed) options.project(properties(tokens())); }
  const api = {
    use() { options.setup(); const chunk = {handles: Array.from(arguments), active: true}; chunks.push(chunk); return () => { options.setup(); chunk.active = false; refresh(); }; },
    rule(test, handles) { options.setup(); const rule = {test, handles, active: true}; rules.push(rule); return {id: ++sequence, dispose() { options.setup(); rule.active = false; refresh(); }}; },
    patch() { options.runtime(); for (const h of arguments) for (let i=0;i<h.tokens.length;++i) patches.set(h.groups[i], h.tokens[i]); refresh(); },
    suppress() { options.runtime(); for (const h of arguments) for (const group of h.groups) patches.set(group, null); refresh(); },
    clearPatch() { options.runtime(); patches.clear(); refresh(); },
    mount() { mounted = true; refresh(); }, unmount() { mounted = false; }, refresh, properties,
    dispose() { disposed = true; mounted = false; chunks.length=0; rules.length=0; patches.clear(); }
  };
  return api;
}
