#include "QtNativeHost.h"
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlError>
#include <QUrl>
#include <QDir>
#include <QFileInfo>
#include <QDebug>
int main(int argc,char **argv) {
    QGuiApplication app(argc,argv);
    registerQtNativeTypes();
    QQmlApplicationEngine engine;
    bool failed=false;
    QObject::connect(&engine,&QQmlEngine::warnings,&app,[&app,&failed](const QList<QQmlError> &errors){failed=true;for(const auto &error:errors)qCritical().noquote()<<error.toString();app.exit(1);});
    engine.load(QUrl::fromLocalFile(QFileInfo(argc>1 ? QString::fromLocal8Bit(argv[1]) : QStringLiteral("App.qml")).absoluteFilePath()));
    if(engine.rootObjects().isEmpty()||failed)return 1;
    return app.exec();
}
