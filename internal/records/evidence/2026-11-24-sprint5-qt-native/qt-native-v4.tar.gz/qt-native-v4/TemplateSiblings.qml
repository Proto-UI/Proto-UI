// Editable ordinary Qt Quick 6.4.2 source. No Proto Runtime/Core/Adapter dependency.
// Authored templates are cached and reconciled only at explicit update or view epoch entry.
// Helper cost: owned Props/State/Context resources, Qt native facts/style repaint, QML node reconciliation.
// Public Props are a full presence-preserving rawProps map; mutation requires a replacement snapshot.
import QtQuick 6.4
import QtQuick.Window 6.4
import QtQml 6.4 as Qml
import PuiQtNative 1.0
import "./.proto-ui/qt/QtOwner.mjs" as PuiQtNative

import "./.proto-ui/qt/context/QtContextScope.mjs" as PuiQtContext
import "./.proto-ui/qt" as PuiQtView



FocusScope {
    id: puiQtHost
    objectName: "TemplateSiblings"
    property var rawProps: ({})
    property Item logicalParent: null
    readonly property Window nativeWindow: puiQtHost.Window.window
    default property alias slotContent: puiQtParking.data
    readonly property var logicalOwner: !puiQtClosed && puiQtOwner ? puiQtOwner.identity : null
    readonly property var exposes: !puiQtClosed && puiQtOwner ? puiQtOwner.exposes : ({})
    readonly property bool disposed: puiQtClosed
    readonly property int viewEpoch: puiQtEpoch
    readonly property bool present: puiQtPresent
    readonly property Item nativeRoot: puiQtRoot
    property var puiQtOwner: null
    property bool puiQtClosed: false
    property bool puiQtReady: false
    property int puiQtRevision: 0
    property int puiQtEpoch: 0
    property bool puiQtPresent: false
    property Item puiQtRoot: null
    implicitWidth: puiQtRoot ? puiQtRoot.implicitWidth : 0
    implicitHeight: puiQtRoot ? puiQtRoot.implicitHeight : 0

    signal exposed(string key, var payload)
    signal nativeHostEvent(string type, var event)
    onNativeHostEvent: (type, event) => { if (puiQtOwner && !puiQtClosed) puiQtOwner.nativeEvent(type, event) }
    property Item puiQtParking: Item { id: puiQtParking; readonly property Item logicalParent: puiQtHost; parent: puiQtHost; visible: parent !== puiQtHost; width: childrenRect.width; height: childrenRect.height; implicitWidth: childrenRect.width; implicitHeight: childrenRect.height }
    property Item puiQtContent: Item { parent: puiQtHost; anchors.fill: parent }
    property Qml.Component puiQtNodeComponent: Qml.Component { PuiQtView.QtNode {} }
    property NativeInputObserver puiQtInputObserver: NativeInputObserver {
        root: null
        onObserved: (name, event) => { if (puiQtOwner && !puiQtClosed) puiQtOwner.globalNativeEvent(name, event) }
    }
    function ensureOwner() {
        if (puiQtClosed) throw new Error('Qt component is terminally disposed')
        if (puiQtOwner) return puiQtOwner
        puiQtOwner = PuiQtNative.createOwner(puiQtHost, {
            parking: puiQtParking, slot: puiQtParking, content: puiQtContent,
            createNode: function(parent) { return puiQtNodeComponent.createObject(parent) },
            connected: function() { return puiQtHost.Window.window !== null },
            later: function(callback) { Qt.callLater(callback) },
            rootChanged: function(root) { puiQtRoot = root },
            epochChanged: function(epoch, present) { puiQtEpoch = epoch; puiQtPresent = present },
            changed: function() { ++puiQtRevision },
            emit: function(key, payload) { puiQtHost.deliverExpose(key, payload) },
            propChecks: {["children"]: function(value) { return (typeof value === "boolean"); }}, eventChecks: {}, methodChecks: {},
            styleTable: {"w-40":{"fixedWidth":160},"h-20":{"fixedHeight":80},"w-8":{"fixedWidth":32},"h-4":{"fixedHeight":16},"w-12":{"fixedWidth":48},"h-6":{"fixedHeight":24}},
            declarations: [],
            tableFamilies: [],
            contextCheck: (key, value) => false
        })
        const puiQtDef = puiQtOwner.def

        const puiQtHookResults = new Map();

        try {
            puiQtOwner.setRender((function(def) {
                // Source "qt-native-siblings.proto.ts":6:5
                def.props.define({["children"]: {["type"]: "boolean", ["default"]: true}});
                // Source "qt-native-siblings.proto.ts":7:5
                def.props.watch(["children"], function(run) {
                    // Source "qt-native-siblings.proto.ts":7:44
                    return run.update();
                });
                // Source "qt-native-siblings.proto.ts":8:5
                def.feedback.style.use({"kind":"tw","tokens":["w-40","h-20"],"groups":["w-","h-"]});
                // Source "qt-native-siblings.proto.ts":9:5
                return function(renderer) {
                    // Source "qt-native-siblings.proto.ts":10:7
                    return ((renderer.read.props.get())["children"] ? [renderer.el("div", {["style"]: {"kind":"tw","tokens":["w-8","h-4"],"groups":["w-","h-"]}}, "first"), renderer.el("div", {["style"]: {"kind":"tw","tokens":["w-12","h-6"],"groups":["w-","h-"]}}, "second")] : null);
                };
            })(puiQtDef))
            puiQtOwner.hydrate(rawProps)
            puiQtOwner.created()
            puiQtReady = true
            ++puiQtRevision
        } catch (error) {
            try { puiQtOwner.dispose() } finally { puiQtOwner = null; puiQtClosed = true }
            throw error
        }
        return puiQtOwner
    }
    function deliverExpose(key, payload) {
        exposed(key, payload)

    }
    function setProps(next) { if (puiQtClosed) throw new Error('Qt component disposed'); rawProps = next }
    function update() { ensureOwner().update() }
    function getExposes() { return ensureOwner().getExposes() }
    function dispose() { if (puiQtClosed) return; puiQtClosed = true; puiQtReady = false; if (puiQtOwner) puiQtOwner.dispose() }
    onRawPropsChanged: if (puiQtOwner && !puiQtClosed) puiQtOwner.hydrate(rawProps)
    onParentChanged: if (puiQtOwner && !puiQtClosed) Qt.callLater(function() { if (!puiQtClosed) puiQtOwner.topologyChanged() })
    onNativeWindowChanged: if (puiQtOwner && !puiQtClosed) Qt.callLater(function() { if (!puiQtClosed) puiQtOwner.topologyChanged() })
    onLogicalParentChanged: if (puiQtOwner && !puiQtClosed) Qt.callLater(function() { if (!puiQtClosed) puiQtOwner.topologyChanged() })
    Qml.Component.onCompleted: { ensureOwner(); puiQtOwner.reconcile() }
    Qml.Component.onDestruction: dispose()
}
