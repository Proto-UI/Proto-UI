var OwnerHydrationFixture = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // owner-generated:Component.client.ts
  var Component_client_exports = {};
  __export(Component_client_exports, {
    HydrationMismatch: () => HydrationMismatch,
    OwnerRetirement: () => OwnerRetirement,
    default: () => Component_client_default,
    hydrate: () => hydrate,
    register: () => register
  });

  // owner-generated:.proto-ui/context/scope-v1.ts
  function isData(value, ancestors = /* @__PURE__ */ new Set()) {
    if (value === null || typeof value === "boolean" || typeof value === "string") return true;
    if (typeof value === "number") return Number.isFinite(value);
    if (typeof value !== "object" || ancestors.has(value)) return false;
    const array = Array.isArray(value);
    const prototype = Object.getPrototypeOf(value);
    if (array ? prototype !== Array.prototype : prototype !== Object.prototype && prototype !== null) return false;
    ancestors.add(value);
    try {
      if (array && Object.keys(value).length !== value.length) return false;
      for (const key of Reflect.ownKeys(value)) {
        if (array && key === "length") continue;
        if (typeof key !== "string" || array && !/^(0|[1-9][0-9]*)$/.test(key)) return false;
        const descriptor = Object.getOwnPropertyDescriptor(value, key);
        if (!descriptor.enumerable || !("value" in descriptor) || !isData(descriptor.value, ancestors)) return false;
      }
      return true;
    } finally {
      ancestors.delete(value);
    }
  }
  function acceptsContextValue(type, value, checked = false) {
    if (type === "void") return value === void 0;
    if (!checked && value !== void 0 && !isData(value)) return false;
    if (typeof type === "string") {
      if (type === "null") return value === null;
      return typeof value === type && (type !== "number" || Number.isFinite(value));
    }
    switch (type.kind) {
      case "literal":
        return Object.is(value, type.value);
      case "union":
        return !!type.members?.some((member) => acceptsContextValue(member, value, true));
      case "array":
        return Array.isArray(value) && !!type.element && Object.keys(value).length === value.length && value.every((item) => acceptsContextValue(type.element, item, true));
      case "record":
        return value !== null && typeof value === "object" && !Array.isArray(value) && !!type.fields?.every((field) => !Object.hasOwn(value, field.name) ? !!field.optional : acceptsContextValue(field.type, value[field.name], true));
      default:
        return false;
    }
  }
  var scopeKey = Symbol("ProtoUI.ContextScope");
  var ownerScopes = /* @__PURE__ */ new WeakMap();
  var live = /* @__PURE__ */ new Map();
  var notifications = [];
  var dispatching = false;
  function resolve(record, key) {
    let current = record;
    const visited = /* @__PURE__ */ new Set();
    while (current) {
      if (visited.has(current.scope)) throw new Error("[Context] cyclic logical scope ancestry.");
      visited.add(current.scope);
      if (!current.isAlive()) return null;
      if (current.providers.has(key)) return current;
      const parent = current.getParent();
      current = parent === null ? void 0 : live.get(parent);
    }
    return null;
  }
  function createContextScope(options) {
    let disposed = false;
    let record;
    function ensureAlive() {
      if (disposed || !options.isAlive()) throw new Error("[Context] scope is invalid after terminal disposal.");
    }
    function subscribed(key, mode) {
      const subscription = record.subscriptions.get(key);
      if (!subscription || mode && subscription.mode !== mode)
        throw new Error("[Context] operation requires a declared " + (mode ?? "") + " subscription.");
      return subscription;
    }
    function provider(key) {
      const bound = resolve(record, key);
      if (!bound) throw new Error("[Context] provider missing or disconnected.");
      return bound;
    }
    function write(key, next, bound) {
      const prev = bound.providers.get(key);
      const value = typeof next === "function" ? next(prev) : next;
      ensureAlive();
      if (!live.has(bound.scope) || !bound.isAlive()) throw new Error("[Context] provider disconnected during update.");
      if (!options.validate(key, value)) throw new TypeError("[Context] invalid checked Context value.");
      bound.providers.set(key, value);
      for (const participant of live.values()) {
        const subscription = participant.subscriptions.get(key);
        if (!subscription || !participant.isAlive() || resolve(participant, key) !== bound) continue;
        for (const callback of subscription.callbacks) if (callback.active)
          notifications.push({ record: participant, provider: bound, key, callback, next: value, prev });
      }
      if (dispatching) return;
      dispatching = true;
      let failed = false;
      let failure;
      try {
        for (let index = 0; index < notifications.length; ++index) {
          const task = notifications[index];
          if (!task.callback.active || !live.has(task.record.scope) || !task.record.isAlive()) continue;
          try {
            if (resolve(task.record, task.key) !== task.provider) continue;
            task.record.invoke(() => task.callback.call(task.next, task.prev));
          } catch (error) {
            if (!failed) {
              failed = true;
              failure = error;
            }
          }
        }
      } finally {
        notifications.length = 0;
        dispatching = false;
      }
      if (failed) throw failure;
    }
    const scope = {
      provide(key, value) {
        ensureAlive();
        if (record.providers.has(key)) throw new Error("[Context] duplicate provide.");
        if (!options.validate(key, value)) throw new TypeError("[Context] invalid checked Context value.");
        record.providers.set(key, value);
      },
      subscribe(key, mode, callback) {
        ensureAlive();
        if (mode !== "required" && mode !== "optional") throw new Error("[Context] invalid subscription mode.");
        if (mode === "required") provider(key);
        let subscription = record.subscriptions.get(key);
        if (subscription && subscription.mode !== mode) throw new Error("[Context] subscription mode mismatch.");
        if (!subscription) {
          subscription = { mode, callbacks: [] };
          record.subscriptions.set(key, subscription);
        }
        const entry = callback ? { active: true, call: (next, prev) => callback(next, prev) } : void 0;
        if (entry) subscription.callbacks.push(entry);
        return () => {
          if (entry) entry.active = false;
        };
      },
      read(key) {
        ensureAlive();
        subscribed(key, "required");
        return provider(key).providers.get(key);
      },
      tryRead(key) {
        ensureAlive();
        subscribed(key, "optional");
        return resolve(record, key)?.providers.get(key) ?? null;
      },
      update(key, next) {
        ensureAlive();
        if (!record.providers.has(key)) subscribed(key);
        write(key, next, provider(key));
      },
      tryUpdate(key, next) {
        ensureAlive();
        subscribed(key, "optional");
        const bound = resolve(record, key);
        if (!bound) return false;
        write(key, next, bound);
        return true;
      },
      dispose() {
        if (disposed) return;
        disposed = true;
        live.delete(scope);
        record.providers.clear();
        for (const subscription of record.subscriptions.values()) {
          for (const callback of subscription.callbacks) callback.active = false;
          subscription.callbacks.length = 0;
        }
        record.subscriptions.clear();
      }
    };
    record = { ...options, scope, providers: /* @__PURE__ */ new Map(), subscriptions: /* @__PURE__ */ new Map() };
    live.set(scope, record);
    return Object.freeze(scope);
  }

  // owner-generated:.proto-ui/interaction/ownership-v2.ts
  var owners = /* @__PURE__ */ new Map();
  var targets = /* @__PURE__ */ new WeakMap();
  var hostIds = /* @__PURE__ */ new WeakMap();
  function logicalRoot(owner) {
    let current = owner;
    const visited = /* @__PURE__ */ new Set();
    while (!visited.has(current.identity)) {
      visited.add(current.identity);
      const parent = current.parent(), candidate = parent ? owners.get(parent) : void 0;
      if (!candidate)
        return current;
      current = candidate;
    }
    throw new Error("[Modules] cyclic logical ancestry.");
  }
  var rootOwners = /* @__PURE__ */ new WeakMap();
  var logicalOwners = /* @__PURE__ */ new Map();
  var exposeSignals = /* @__PURE__ */ new WeakSet();

  // owner-generated:.proto-ui/interaction/modules-6eaed2f12f730f2c-v2.ts
  function createNativeAdapterModules(options) {
    let disposed = false;
    let root = null;
    let generation = 0;
    let hostProperties = null;
    let hostPortal = null;
    const cleanups = [];
    const terminalCleanups = [];
    const propertyBaselines = /* @__PURE__ */ new Map();
    const hooks = /* @__PURE__ */ new Set();
    const claims = /* @__PURE__ */ new Map();
    const topologySubscribers = /* @__PURE__ */ new Set();
    const focusConfig = { disabled: false, navParticipation: "auto" };
    const scopeConfig = { trap: false, loop: false, navigation: "tab", orientation: "both", entry: "first", entryFallback: "none", restore: "previous", emptyPolicy: "container" };
    const rovingConfig = { loop: false, navigation: "arrow", orientation: "both", entry: "active", selectOnFocus: false };
    const owner = { identity: options.identity, parent: options.getLogicalParent, target: () => root, host: () => root ? options.getHost?.() ?? root : null, alive: () => !disposed && options.isAlive(), hooks, claims, exposes: () => options.getExposes?.() ?? {}, focusConfig, scopeConfig, rovingConfig, selected: false, active: false, scopeDeclared: false, rovingDeclared: false, focusDeclared: false, entryDeclared: false, scopeActive: false, focus: () => {
      throw new Error("[Focus] owner does not declare focus.");
    }, cancelPendingFocus() {
    }, changed: () => {
      const epoch = generation;
      for (const callback of [...topologySubscribers]) {
        if (epoch !== generation || !ready() || !(options.isReady?.() ?? true))
          break;
        if (topologySubscribers.has(callback))
          options.invoke(callback);
      }
      refresh();
    } };
    if (owners.has(options.identity))
      throw new Error("[Modules] duplicate live owner identity.");
    function alive() {
      if (disposed || !options.isAlive())
        throw new Error("[Modules] owner is terminally disposed.");
    }
    function requestPresentation() {
      if (disposed || !options.isAlive() || !(options.isReady?.() ?? true))
        return;
      const next = rootProperties(), portal = portalTarget();
      const changed = !hostProperties || portal !== hostPortal || Object.keys(next).length !== Object.keys(hostProperties).length || Object.keys(next).some((key) => next[key] !== hostProperties[key]);
      hostProperties = next;
      hostPortal = portal;
      if (changed)
        options.requestHostUpdate?.();
    }
    function ready() {
      return !disposed && options.isAlive() && !!root && root === options.getRoot() && root.isConnected;
    }
    function announceTopology(rootOwner = logicalRoot(owner)) {
      for (const participant of [...owners.values()])
        if (participant.alive() && logicalRoot(participant) === rootOwner)
          participant.changed();
    }
    function rootTag() {
      alive();
      return null;
    }
    function adoptControlState() {
      alive();
      if (root)
        throw new Error("[Modules] adopt control state before the first view mount.");
      const target = options.getRoot();
      if (!target)
        throw new Error("[Modules] hydration requires the adopted physical Root.");
      if (target.id)
        hostIds.set(options.identity, target.id);
    }
    function rootProperties() {
      alive();
      const result = /* @__PURE__ */ Object.create(null);
      return result;
    }
    function projectAttributes() {
      alive();
      const result = /* @__PURE__ */ Object.create(null);
      return result;
    }
    const attributeBaselines = /* @__PURE__ */ new Map();
    function projectModuleAttributes() {
      if (!ready())
        return;
      if (options.requestAttributeRefresh) {
        options.requestAttributeRefresh();
        return;
      }
      for (const [name, value] of Object.entries(projectAttributes())) {
        const current = root.getAttribute(name);
        let ownership = attributeBaselines.get(name);
        if (!ownership) {
          ownership = { baseline: current, projected: current };
          attributeBaselines.set(name, ownership);
        } else if (current !== ownership.projected)
          ownership.baseline = current;
        if (current !== value) {
          if (value === null)
            root.removeAttribute(name);
          else
            root.setAttribute(name, value);
        }
        ownership.projected = value;
      }
    }
    function refresh() {
      if (disposed || !options.isAlive())
        return;
      if (!ready()) {
        requestPresentation();
        return;
      }
      projectModuleAttributes();
      requestPresentation();
    }
    function portalTarget() {
      return null;
    }
    function unmount() {
      const previous = root;
      ++generation;
      root = null;
      if (previous && targets.get(previous) === owner)
        targets.delete(previous);
      const failures = [];
      for (const cleanup of cleanups.splice(0))
        try {
          cleanup();
        } catch (error) {
          failures.push(error);
        }
      if (previous) {
        for (const [name, ownership] of attributeBaselines)
          if (previous.getAttribute(name) === ownership.projected) {
            if (ownership.baseline === null)
              previous.removeAttribute(name);
            else
              previous.setAttribute(name, ownership.baseline);
          }
        for (const [name, ownership] of propertyBaselines)
          if (previous.style.getPropertyValue(name) === ownership.projected) {
            if (ownership.value)
              previous.style.setProperty(name, ownership.value);
            else
              previous.style.removeProperty(name);
          }
      }
      attributeBaselines.clear();
      propertyBaselines.clear();
      if (previous) {
        if (options.isAlive() && (options.isReady?.() ?? true)) {
        }
        announceTopology();
      }
      if (failures.length)
        throw new AggregateError(failures, "[Modules] view cleanup failed.");
    }
    function mount() {
      alive();
      const candidate = options.getRoot();
      if (root === candidate && ready()) {
        refresh();
        return;
      }
      unmount();
      root = candidate;
      if (!root)
        return;
      const mountEpoch = generation;
      targets.set(root, owner);
      if (root.id)
        hostIds.set(options.identity, root.id);
      try {
        const doc = root.ownerDocument;
        refresh();
        announceTopology();
      } catch (error) {
        if (mountEpoch === generation && root === candidate)
          try {
            unmount();
          } catch (cleanup) {
            throw new AggregateError([error, cleanup], "[Modules] mount and cleanup failed.");
          }
        throw error;
      }
    }
    const capabilities = {
      rootTag,
      rootProperties,
      projectAttributes,
      portalTarget,
      adoptControlState,
      refresh,
      mount,
      unmount,
      dispose() {
        if (disposed)
          return;
        const rootOwner = logicalRoot(owner);
        const failures = [];
        try {
          unmount();
        } catch (error) {
          failures.push(error);
        }
        disposed = true;
        owners.delete(options.identity);
        claims.clear();
        hooks.clear();
        topologySubscribers.clear();
        for (const cleanup of terminalCleanups.splice(0))
          try {
            cleanup();
          } catch (error) {
            failures.push(error);
          }
        announceTopology(rootOwner);
        if (failures.length)
          throw new AggregateError(failures, "[Modules] terminal cleanup failed.");
      }
    };
    owners.set(options.identity, owner);
    return capabilities;
  }

  // owner-generated:.proto-ui/interaction/native-6eaed2f12f730f2c-v2.ts
  function markNativeExposeEvent(event) {
    exposeSignals.add(event);
    return event;
  }
  function createNativeInteraction(options) {
    let disposed = false;
    let root = null;
    let host = null;
    let generation = 0;
    let trigger = false;
    const identity = options.identity ?? {};
    const capturedListeners = /* @__PURE__ */ new WeakMap();
    const removals = [];
    const subscriptions = [];
    const attributes = /* @__PURE__ */ new Map();
    function alive() {
      if (disposed || !options.isAlive())
        throw new Error("[Interaction] invalid after terminal disposal.");
    }
    function active(epoch = generation, target = root) {
      return !disposed && options.isAlive() && !!target && target === root && options.getRoot() === target && generation === epoch && rootOwners.get(target)?.identity === identity;
    }
    function project(name, value) {
      if (!root)
        return;
      let ownership = attributes.get(name);
      const current = root.getAttribute(name);
      if (!ownership) {
        ownership = { baseline: current, projected: current };
        attributes.set(name, ownership);
      } else if (current !== ownership.projected)
        ownership.baseline = current;
      if (current !== value) {
        if (value === null)
          root.removeAttribute(name);
        else
          root.setAttribute(name, value);
      }
      ownership.projected = value;
    }
    function clearProjection(target) {
      for (const [name, ownership] of attributes) {
        if (target.getAttribute(name) !== ownership.projected)
          continue;
        if (ownership.baseline === null)
          target.removeAttribute(name);
        else
          target.setAttribute(name, ownership.baseline);
      }
      attributes.clear();
    }
    function visitProjection(write) {
    }
    function projectAttributes() {
      alive();
      const result = /* @__PURE__ */ Object.create(null);
      visitProjection((name, value) => {
        result[name] = value;
      });
      return result;
    }
    function adoptAttributes(snapshot, baselines) {
      alive();
      if (root || attributes.size)
        throw new Error("[Interaction] hydration attributes must be adopted before first projection.");
      const target = options.getRoot();
      if (!target)
        throw new Error("[Interaction] hydration requires the adopted current Root.");
      for (const name of Object.keys(snapshot)) {
        const value = snapshot[name];
        if (target.getAttribute(name) !== value)
          continue;
        const baseline = baselines && Object.hasOwn(baselines, name) ? baselines[name] : null;
        attributes.set(name, { baseline, projected: value });
      }
      modules.adoptControlState();
    }
    function refresh() {
      if (!active())
        return;
      const next = combinedProjectAttributes();
      for (const [name, ownership] of attributes)
        if (!Object.hasOwn(next, name)) {
          if (root.getAttribute(name) === ownership.projected) {
            if (ownership.baseline === null)
              root.removeAttribute(name);
            else
              root.setAttribute(name, ownership.baseline);
          }
          attributes.delete(name);
        }
      for (const [name, value] of Object.entries(next))
        project(name, value);
    }
    function unmount() {
      generation++;
      const previous = root, previousHost = host;
      root = null;
      host = null;
      if (previous && rootOwners.get(previous)?.identity === identity)
        rootOwners.delete(previous);
      if (previousHost && rootOwners.get(previousHost)?.identity === identity)
        rootOwners.delete(previousHost);
      logicalOwners.delete(identity);
      let failure;
      for (const remove of removals.splice(0)) {
        try {
          remove();
        } catch (error) {
          failure ??= error;
        }
      }
      if (previous)
        clearProjection(previous);
      if (failure)
        throw failure;
    }
    function mount() {
      alive();
      const candidate = options.getRoot();
      if (root === candidate && active()) {
        refresh();
        return;
      }
      unmount();
      alive();
      if (!candidate)
        return;
      const target = candidate;
      root = target;
      host = options.getHost?.() ?? target;
      const rootOwner = { identity, parent: options.getLogicalParent ?? (() => null), trigger: () => trigger, target };
      rootOwners.set(target, rootOwner);
      rootOwners.set(host, rootOwner);
      logicalOwners.set(identity, rootOwner);
      refresh();
    }
    const modules = createNativeAdapterModules({
      ensureSetup: options.ensureSetup,
      ensureRuntime: options.ensureRuntime,
      ensureEvent: options.ensureEvent,
      isAlive: () => !disposed && options.isAlive(),
      isReady: options.isReady,
      invoke: options.invoke,
      getRun: options.getRun,
      getResolvedProps: options.getResolvedProps,
      getRoot: options.getRoot,
      getHost: options.getHost,
      declarations: options.declarations ?? [],
      identity,
      getLogicalParent: options.getLogicalParent ?? (() => null),
      tableFamily: options.tableFamily,
      registerObservedState: options.registerGenericObservedState,
      getExposes: options.getExposes,
      setPresent: options.setPresent,
      requestHostUpdate: options.requestHostUpdate,
      emit: options.emit,
      createOwnedState: options.createOwnedState,
      watchState: options.watchState,
      isPropProvided: options.isPropProvided,
      getMeta: options.getMeta,
      registerExpose: options.registerExpose,
      baseFocus: void 0,
      cancelPendingFocus() {
      },
      getAccessibleRole: void 0,
      requestAttributeRefresh: refresh,
      getAttributeBaseline: (name) => attributes.has(name) ? attributes.get(name).baseline : root?.getAttribute(name) ?? null,
      subscribeState: options.subscribeState
    });
    function combinedProjectAttributes() {
      const base = projectAttributes();
      const extended = modules.projectAttributes();
      return Object.freeze({ ...base, ...extended });
    }
    return {
      releaseListener(token) {
        options.ensureSetup("asHook.disposer");
        const registration = capturedListeners.get(token);
        if (!registration)
          throw new Error("[Event] listener token belongs to a different owner.");
        registration.active = false;
      },
      rootTag: () => modules.rootTag(),
      rootProperties: () => modules.rootProperties(),
      portalTarget: () => modules.portalTarget(),
      projectAttributes: combinedProjectAttributes,
      adoptAttributes,
      refresh() {
        modules.refresh();
        refresh();
      },
      mount() {
        mount();
        modules.mount();
      },
      unmount() {
        let failed = false, failure;
        const attempt = (cleanup) => {
          try {
            cleanup();
          } catch (error) {
            if (!failed) {
              failed = true;
              failure = error;
            }
          }
        };
        attempt(() => modules.unmount());
        attempt(unmount);
        if (failed)
          throw failure;
      },
      dispose() {
        if (disposed)
          return;
        disposed = true;
        let failed = false, failure;
        const attempt = (cleanup) => {
          try {
            cleanup();
          } catch (error) {
            if (!failed) {
              failed = true;
              failure = error;
            }
          }
        };
        attempt(() => modules.unmount());
        attempt(unmount);
        attempt(() => modules.dispose());
        for (const off of subscriptions.splice(0))
          attempt(off);
        if (failed)
          throw failure;
      }
    };
  }

  // owner-generated:.proto-ui/web-component/ssr-6eaed2f12f730f2c-v2.ts
  function assertNoInstanceAssociations(input, subject) {
    if (!input || typeof input !== "object")
      return;
    for (const key of ["instanceAssociations", "instance-associations", "instanceassociations"])
      if (Object.prototype.hasOwnProperty.call(input, key))
        throw new TypeError("[InstanceAssociations] " + subject + " cannot carry instance associations; SSR association transport is unsupported, use the dedicated client property");
  }
  var HydrationMismatch = class extends Error {
    constructor(reason, path = "Root", options) {
      super("WC hydration mismatch at " + path + ": " + reason, options);
      this.reason = reason;
      this.path = path;
      this.name = "HydrationMismatch";
    }
    code = "PUI_WC_HYDRATION_MISMATCH";
  };
  function isPresentation(value) {
    return !!value && typeof value === "object" && ["element", "text", "slot"].includes(value.kind);
  }
  function presentationChildren(input) {
    const result = [];
    function append(value) {
      if (value === null)
        return;
      if (Array.isArray(value)) {
        for (const child of value)
          append(child);
        return;
      }
      const node = typeof value === "string" || typeof value === "number" ? { kind: "text", text: String(value) } : value;
      if (!isPresentation(node))
        throw new TypeError("Invalid template child");
      if (node.kind === "text") {
        if (!node.text)
          return;
        const previous = result[result.length - 1];
        if (previous?.kind === "text") {
          previous.text += node.text;
          return;
        }
        result.push({ kind: "text", text: node.text });
      } else
        result.push(node);
    }
    append(input);
    return result;
  }
  function presentationElement(tag, style, children) {
    if (!/^[A-Za-z][A-Za-z0-9:_-]*$/.test(tag))
      throw new TypeError("Invalid template tag");
    return { kind: "element", tag: tag.toLowerCase(), ...style === void 0 ? {} : { style }, children: presentationChildren(children) };
  }
  function cloneInitialData(input) {
    const ancestors = /* @__PURE__ */ new Set();
    let nodes = 0, bytes = 0;
    const encoder = new TextEncoder();
    function fail(detail) {
      throw new TypeError("[Owner initialization] " + detail);
    }
    function text(value) {
      if (value.length > 1048576)
        fail("byte budget exceeded");
      bytes += encoder.encode(JSON.stringify(value)).length;
      if (bytes > 1048576)
        fail("byte budget exceeded");
    }
    function visit(value, depth) {
      if (depth > 64)
        fail("depth budget exceeded");
      if (++nodes > 1e4)
        fail("node budget exceeded");
      bytes += 32;
      if (bytes > 1048576)
        fail("byte budget exceeded");
      if (value === null || value === void 0 || typeof value === "boolean")
        return value;
      if (typeof value === "number") {
        if (!Number.isFinite(value))
          fail("numbers must be finite");
        return value;
      }
      if (typeof value === "string") {
        text(value);
        return value;
      }
      if (typeof value !== "object")
        fail("live capabilities are not data");
      if (ancestors.has(value))
        fail("cyclic data");
      const array = Array.isArray(value), prototype = Object.getPrototypeOf(value);
      if (array ? prototype !== Array.prototype : prototype !== Object.prototype && prototype !== null)
        fail("non-data prototype");
      const keys = Reflect.ownKeys(value);
      if (keys.length > 1e4)
        fail("node budget exceeded");
      if (array && (value.length > 1e4 || keys.length !== value.length + 1))
        fail("sparse or extended array");
      const copy = array ? [] : /* @__PURE__ */ Object.create(null);
      ancestors.add(value);
      try {
        for (const key of keys) {
          if (array && key === "length")
            continue;
          const field = Object.getOwnPropertyDescriptor(value, key);
          if (!field || typeof key !== "string" || !field.enumerable || !("value" in field))
            fail("accessor, symbol or nonenumerable field");
          if (array && (!/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= value.length))
            fail("extended array");
          text(key);
          Object.defineProperty(copy, key, { value: visit(field.value, depth + 1), enumerable: true });
        }
      } finally {
        ancestors.delete(value);
      }
      return Object.freeze(copy);
    }
    return visit(input, 0);
  }
  function decodeInitialData(input) {
    function invalid() {
      throw new TypeError("[Owner initialization] malformed data encoding");
    }
    function decode(value) {
      if (value === null || typeof value === "string" || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value))
        return value;
      if (!Array.isArray(value))
        return invalid();
      if (value.length === 1 && value[0] === "undefined")
        return void 0;
      if (value.length === 1 && value[0] === "negative-zero")
        return -0;
      if (value.length !== 2 || !Array.isArray(value[1]))
        return invalid();
      if (value[0] === "array")
        return Object.freeze(value[1].map(decode));
      if (value[0] !== "record")
        return invalid();
      const record = /* @__PURE__ */ Object.create(null);
      for (const entry of value[1]) {
        if (!Array.isArray(entry) || entry.length !== 2 || typeof entry[0] !== "string" || Object.hasOwn(record, entry[0]))
          return invalid();
        Object.defineProperty(record, entry[0], { value: decode(entry[1]), enumerable: true });
      }
      return Object.freeze(record);
    }
    return decode(cloneInitialData(input));
  }
  function checkData(value, seen = /* @__PURE__ */ new Set()) {
    if (!seen.size)
      value = cloneInitialData(value);
    if (value === null || typeof value === "string" || typeof value === "boolean")
      return;
    if (typeof value === "number" && Number.isFinite(value))
      return;
    if (typeof value !== "object" || seen.has(value))
      throw new TypeError("SSR transport requires finite acyclic JSON data");
    const array = Array.isArray(value), proto = Object.getPrototypeOf(value);
    if (array ? proto !== Array.prototype : proto !== Object.prototype && proto !== null)
      throw new TypeError("SSR transport rejects non-data objects");
    seen.add(value);
    try {
      if (array && Object.keys(value).length !== value.length)
        throw new TypeError("SSR transport rejects sparse arrays");
      for (const key of Reflect.ownKeys(value)) {
        if (array && key === "length")
          continue;
        const field = Object.getOwnPropertyDescriptor(value, key);
        if (typeof key !== "string" || !field.enumerable || !("value" in field))
          throw new TypeError("SSR transport rejects accessor/symbol fields");
        checkData(field.value, seen);
      }
    } finally {
      seen.delete(value);
    }
  }
  function encodeRaw(raw) {
    raw = cloneInitialData(raw);
    function encode(value, seen = /* @__PURE__ */ new Set()) {
      if (value === void 0)
        return ["undefined"];
      if (Object.is(value, -0))
        return ["negative-zero"];
      if (value === null || typeof value === "string" || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value))
        return value;
      if (!value || typeof value !== "object" || seen.has(value))
        throw new TypeError("Non-portable initial data");
      const array = Array.isArray(value), proto = Object.getPrototypeOf(value);
      if (array ? proto !== Array.prototype : proto !== Object.prototype && proto !== null)
        throw new TypeError("Capabilities cannot enter initial data");
      seen.add(value);
      try {
        if (array && Object.keys(value).length !== value.length)
          throw new TypeError("SSR transport rejects sparse arrays");
        for (const key of Reflect.ownKeys(value)) {
          if (array && key === "length")
            continue;
          const field = Object.getOwnPropertyDescriptor(value, key);
          if (typeof key !== "string" || !field.enumerable || !("value" in field))
            throw new TypeError("SSR transport rejects accessor/symbol fields");
        }
        return array ? ["array", value.map((item) => encode(item, seen))] : ["record", Object.entries(value).map(([key, item]) => [key, encode(item, seen)])];
      } finally {
        seen.delete(value);
      }
    }
    encode(raw);
    return Object.keys(raw).map((key) => [key, { kind: "value", value: encode(raw[key]) }]);
  }
  function decodeRaw(data) {
    data = cloneInitialData(data);
    const decode = decodeInitialData;
    const raw = /* @__PURE__ */ Object.create(null);
    for (const [key, value] of data) {
      if (["instanceAssociations", "instance-associations", "instanceassociations"].includes(key))
        throw new HydrationMismatch("instance associations cannot enter serialized Props");
      if (Object.hasOwn(raw, key))
        throw new HydrationMismatch("duplicate raw Prop key");
      raw[key] = value.kind === "undefined" ? void 0 : decode(value.value);
    }
    return raw;
  }
  function checkCarrier(carrier, binding, tag, artifacts) {
    try {
      checkData(carrier);
    } catch (cause) {
      throw new HydrationMismatch("carrier contains non-transport data", "Root", { cause });
    }
    try {
      assertNoInstanceAssociations(carrier, "Carrier");
      assertNoInstanceAssociations(carrier?.attributes, "Root attributes");
      assertNoInstanceAssociations(carrier?.baselines, "Root baselines");
    } catch {
      throw new HydrationMismatch("instance association carrier transport is unsupported");
    }
    if (!carrier || typeof carrier !== "object")
      throw new HydrationMismatch("invalid carrier");
    if (carrier.version !== 1 || carrier.profile !== "web-component-ssr-v1" || carrier.binding !== binding || carrier.tagName !== tag)
      throw new HydrationMismatch("source/profile/tag binding differs");
    if (!carrier.artifacts || artifacts && ["source", "helpers", "css", "environment"].some((key) => carrier.artifacts[key] !== artifacts[key]))
      throw new HydrationMismatch("source/helper/CSS artifact version differs");
    if (typeof carrier.instanceId !== "string" || !/^[a-z0-9-]+$/i.test(carrier.instanceId))
      throw new HydrationMismatch("invalid instance identity");
    if (!["light", "shadow"].includes(carrier.mode) || typeof carrier.present !== "boolean" || !Array.isArray(carrier.raw) || !Array.isArray(carrier.presentation))
      throw new HydrationMismatch("invalid carrier");
    for (const entry of carrier.raw) {
      if (!Array.isArray(entry) || entry.length !== 2 || typeof entry[0] !== "string" || !entry[1] || typeof entry[1] !== "object" || !["undefined", "value"].includes(entry[1].kind) || entry[1].kind === "value" && !Object.hasOwn(entry[1], "value"))
        throw new HydrationMismatch("invalid raw Prop entry");
    }
    for (const snapshot of [carrier.attributes, carrier.interactionAttributes, carrier.baselines]) {
      if (!snapshot || Array.isArray(snapshot) || typeof snapshot !== "object" || Object.values(snapshot).some((value) => value !== null && typeof value !== "string"))
        throw new HydrationMismatch("invalid Root attribute snapshot");
    }
    let slots = 0;
    function checkChildren(children) {
      for (const node of children) {
        if (!node || typeof node !== "object")
          throw new HydrationMismatch("invalid presentation node");
        if (node.kind === "slot") {
          if (++slots > 1)
            throw new HydrationMismatch("multiple slot projection");
        } else if (node.kind === "text") {
          if (typeof node.text !== "string")
            throw new HydrationMismatch("invalid text projection");
        } else if (node.kind === "element") {
          if (typeof node.tag !== "string" || !/^[a-z][a-z0-9:_-]*$/.test(node.tag) || node.style !== void 0 && typeof node.style !== "string" || !Array.isArray(node.children))
            throw new HydrationMismatch("invalid element projection");
          checkChildren(node.children);
        } else
          throw new HydrationMismatch("unknown presentation node");
      }
    }
    checkChildren(carrier.presentation);
    try {
      decodeRaw(carrier.raw);
    } catch (error) {
      if (error instanceof HydrationMismatch)
        throw error;
      throw new HydrationMismatch("invalid initial data encoding");
    }
  }
  function checkInitialProps(raw, carrier) {
    if (JSON.stringify(encodeRaw(raw)) !== JSON.stringify(carrier.raw))
      throw new HydrationMismatch("client initial props differ from server props");
  }
  function checkStylesheet(host, version, cssText, subject = "component") {
    if (!cssText)
      return;
    const styles = Array.from(host.ownerDocument.querySelectorAll("style[data-pui-ssr-css]"));
    if (!styles.some((style) => style.getAttribute("data-pui-ssr-css") === version && style.textContent === cssText))
      throw new HydrationMismatch("bound first-frame " + subject + " CSS artifact is absent or differs");
  }
  function marker(node, text) {
    return !!node && node.nodeType === 8 && node.nodeValue === text;
  }
  function carrierNode(host) {
    const nodes = Array.from(host.children).filter((node) => node.localName === "script" && node.hasAttribute("data-pui-carrier"));
    if (nodes.length > 1)
      throw new HydrationMismatch("multiple transport carriers");
    return nodes[0] ?? null;
  }
  function readCarrier(host) {
    const node = carrierNode(host);
    const marked = ["data-pui-ssr", "data-pui-instance", "data-pui-props"].some((name) => host.hasAttribute(name)) || Array.from(host.childNodes).some((node2) => marker(node2, "pui-root-start") || marker(node2, "pui-root-end"));
    if (!node) {
      if (marked)
        throw new HydrationMismatch("SSR-marked host is missing its carrier");
      return null;
    }
    if (node.getAttribute("type") !== "application/json")
      throw new HydrationMismatch("carrier script type differs");
    let parsed;
    try {
      parsed = JSON.parse(node.textContent ?? "");
    } catch {
      throw new HydrationMismatch("invalid carrier JSON");
    }
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed))
      throw new HydrationMismatch("carrier must be an object");
    const carrier = parsed;
    if (node.getAttribute("data-pui-carrier") !== carrier.binding)
      throw new HydrationMismatch("carrier script binding differs");
    return carrier;
  }
  function checkCarrierHost(host, carrier) {
    if (host.getAttribute("data-pui-instance") !== carrier.instanceId || host.getAttribute("data-pui-ssr") !== carrier.binding)
      throw new HydrationMismatch("physical instance/source binding differs");
    if (host.getAttribute("data-pui-props") !== JSON.stringify(carrier.raw))
      throw new HydrationMismatch("physical initial props differ from carrier");
  }
  function logicalParent(host) {
    if (!host.isConnected)
      return null;
    let node = host;
    while (node) {
      const slot = node.nodeType === 1 ? node.assignedSlot : null;
      node = slot ?? (node.nodeType === 11 && "host" in node ? node.host : node.parentNode);
      if (node) {
        const scope = ownerScopes.get(node);
        if (scope)
          return scope;
      }
    }
    return null;
  }
  function pendingProviderDefinition(host) {
    let node = host;
    while (node) {
      const slot = node.nodeType === 1 ? node.assignedSlot : null;
      node = slot ?? (node.nodeType === 11 && "host" in node ? node.host : node.parentNode);
      if (node?.nodeType !== 1 || ownerScopes.has(node))
        continue;
      const parent = node;
      if (!parent.localName.includes("-") || !carrierNode(parent))
        continue;
      const registry = parent.ownerDocument.defaultView.customElements;
      if (!registry.get(parent.localName))
        return registry.whenDefined(parent.localName);
    }
    return null;
  }
  function createBrowserPort(host, mode, carrier, recovery) {
    const doc = host.ownerDocument;
    const initialAttributes = Array.from(host.attributes, (attribute) => [attribute.name, attribute.value]);
    const projectedAttributes = carrier?.control?.attributes ?? carrier?.attributes;
    const projectionBaselines = carrier?.control ? Object.fromEntries(Object.entries(carrier.control.properties).filter(([name, value]) => value !== null && value !== false && !(carrier.control.tag === "textarea" && name === "value")).map(([name, value]) => [name.toLowerCase(), value === true ? "" : String(value)])) : carrier?.baselines;
    let initialControlAttributes = null;
    if (carrier) {
      checkCarrierHost(host, carrier);
      if (Array.from(doc.querySelectorAll("[data-pui-instance]")).filter((node) => node.getAttribute("data-pui-instance") === carrier.instanceId).length > 1)
        throw new HydrationMismatch("duplicate instance identity");
      for (const [name, value] of Object.entries(carrier.attributes))
        if (host.getAttribute(name) !== value)
          throw new HydrationMismatch("Root attribute differs: " + name);
    }
    let root = host;
    if (recovery) {
      for (const node of Array.from(host.children))
        if (node.localName === "script" && node.hasAttribute("data-pui-carrier"))
          node.remove();
    }
    const script = carrierNode(host);
    if (carrier && mode === "light" && host.shadowRoot)
      throw new HydrationMismatch("light carrier has a physical Shadow Root");
    if (mode === "shadow") {
      if (host.shadowRoot)
        root = host.shadowRoot;
      else {
        const declarative = Array.from(host.children).find((node) => node.localName === "template" && node.getAttribute("shadowrootmode") === "open");
        if (carrier && !declarative)
          throw new HydrationMismatch("declarative Shadow Root is absent");
        root = host.attachShadow({ mode: "open" });
        if (declarative) {
          root.appendChild(declarative.content);
          declarative.remove();
        }
      }
    }
    let accepted = false, disposed = false, hydrating = !!carrier;
    let control = null;
    let portalAnchor = null, portalParent = null;
    const emissions = [];
    let owned = /* @__PURE__ */ new WeakSet(), projected = [], start = null, end = null;
    let rootStart = null, rootEnd = null;
    let observer = null;
    const attributes = /* @__PURE__ */ new Map();
    let display = null;
    if (carrier && !carrier.present) {
      const baseline = doc.createElement("div").style;
      baseline.cssText = carrier.baselines.style ?? "";
      display = { value: baseline.getPropertyValue("display"), priority: baseline.getPropertyPriority("display") };
    }
    let expected = null;
    function slotNodes() {
      if (!start || !end || start.parentNode !== end.parentNode)
        return [];
      const nodes = [];
      for (let node = start.nextSibling; node && node !== end; node = node.nextSibling)
        nodes.push(node);
      return nodes;
    }
    function matchList(parent, first, boundary, children, path, mark) {
      let current = first;
      for (let index = 0; index < children.length; ++index) {
        const expected2 = children[index], at = path + "/" + index;
        if (!current || current === boundary)
          throw new HydrationMismatch("missing physical node", at);
        if (expected2.kind === "slot" && mode === "light") {
          if (!marker(current, "pui-slot-start"))
            throw new HydrationMismatch("light slot start differs", at);
          const slotStart = current;
          let slotEnd = current.nextSibling;
          while (slotEnd && slotEnd !== boundary && !marker(slotEnd, "pui-slot-end"))
            slotEnd = slotEnd.nextSibling;
          if (!marker(slotEnd, "pui-slot-end"))
            throw new HydrationMismatch("light slot end differs", at);
          if (mark) {
            start = slotStart;
            end = slotEnd;
            owned.add(start);
            owned.add(end);
            projected = slotNodes();
          }
          current = slotEnd.nextSibling;
          continue;
        }
        if (expected2.kind === "text") {
          if (current.nodeType !== 3 || current.nodeValue !== expected2.text)
            throw new HydrationMismatch("text differs", at);
        } else {
          const tag = expected2.kind === "slot" ? "slot" : expected2.tag;
          if (current.nodeType !== 1 || current.localName !== tag)
            throw new HydrationMismatch("element tag differs", at);
          const el = current;
          if (expected2.kind === "element" && (el.getAttribute("data-pui-style") ?? void 0) !== expected2.style)
            throw new HydrationMismatch("template style differs", at);
          matchList(el, el.firstChild, null, expected2.kind === "slot" ? [] : expected2.children, at, mark);
        }
        if (mark)
          owned.add(current);
        current = current.nextSibling;
      }
      if (current !== boundary)
        throw new HydrationMismatch("unexpected physical node", path);
    }
    function locateRange() {
      if (mode !== "light")
        return;
      for (const node of Array.from(host.childNodes)) {
        if (marker(node, "pui-root-start")) {
          if (rootStart)
            throw new HydrationMismatch("duplicate Root marker");
          rootStart = node;
        }
        if (marker(node, "pui-root-end")) {
          if (rootEnd)
            throw new HydrationMismatch("duplicate Root marker");
          rootEnd = node;
        }
      }
      if (carrier && (!rootStart || !rootEnd))
        throw new HydrationMismatch("light Root ownership markers are absent");
    }
    function matchControl() {
      const candidate = mode === "light" ? rootStart.nextSibling : root.firstChild;
      if (candidate?.nodeType !== 1 || candidate.localName !== carrier.control.tag || candidate.nextSibling !== (mode === "light" ? rootEnd : null) || control && candidate !== control)
        throw new HydrationMismatch("physical control Root differs");
      for (const [name, value] of Object.entries(carrier.control.attributes))
        if (candidate.getAttribute(name) !== value)
          throw new HydrationMismatch("physical control attribute differs: " + name);
      return candidate;
    }
    locateRange();
    if (carrier) {
      if (carrier.control && carrier.present) {
        control = matchControl();
        owned.add(control);
        initialControlAttributes = Array.from(control.attributes, (attribute) => [attribute.name, attribute.value]);
      } else
        matchList(root, mode === "light" ? rootStart.nextSibling : root.firstChild, mode === "light" ? rootEnd : null, carrier.presentation, "Root", true);
      expected = carrier.presentation;
    }
    function pool() {
      const result = [...projected.filter((node) => !!node.parentNode)];
      if (mode === "light")
        for (const node of Array.from(host.childNodes)) {
          if (node === script || node === rootStart || node === rootEnd || owned.has(node))
            continue;
          result.push(node);
        }
      return [...new Set(result)];
    }
    function projectNewChildren() {
      if (!end?.parentNode || disposed)
        return;
      const inPlace = end.parentNode === host ? new Set(slotNodes()) : null;
      for (const node of Array.from(host.childNodes)) {
        if (node === script || node === rootStart || node === rootEnd || owned.has(node) || node === end || node === start)
          continue;
        if (inPlace?.has(node))
          continue;
        end.parentNode.insertBefore(node, end);
        if (!projected.includes(node))
          projected.push(node);
      }
      projected = projected.filter((node) => !!node.parentNode);
    }
    function observe() {
      if (mode !== "light" || !end)
        return;
      if (!observer) {
        observer = new doc.defaultView.MutationObserver(projectNewChildren);
        observer.observe(host, { childList: true, subtree: true });
      }
    }
    function materialize(parent, children, slotPool) {
      for (const child of children) {
        let node;
        if (child.kind === "slot" && mode === "light") {
          start = doc.createComment("pui-slot-start");
          end = doc.createComment("pui-slot-end");
          owned.add(start);
          owned.add(end);
          parent.appendChild(start);
          for (const external of slotPool)
            parent.appendChild(external);
          parent.appendChild(end);
          projected = slotPool;
          continue;
        }
        if (child.kind === "text")
          node = doc.createTextNode(child.text);
        else {
          const el = doc.createElement(child.kind === "slot" ? "slot" : child.tag);
          if (child.kind === "element") {
            if (child.style !== void 0)
              el.setAttribute("data-pui-style", child.style);
            materialize(el, child.children, slotPool);
          }
          node = el;
        }
        owned.add(node);
        parent.appendChild(node);
      }
    }
    function ownRootRange(first, last) {
      if (first.parentNode !== last.parentNode)
        throw new HydrationMismatch("owned range has different physical parents");
      for (let node = first; node; node = node.nextSibling) {
        owned.add(node);
        if (node === last)
          return;
      }
      throw new HydrationMismatch("owned range end is unreachable");
    }
    function removeOwned() {
      for (const node of Array.from(root.childNodes))
        if (mode === "shadow" || owned.has(node) || node === rootStart || node === rootEnd)
          node.parentNode?.removeChild(node);
      rootStart = null;
      rootEnd = null;
    }
    const port = {
      server: false,
      get isConnected() {
        return host.isConnected && !disposed;
      },
      host,
      get root() {
        return control ?? host;
      },
      validateInitial(snapshot) {
        if (!carrier)
          return;
        if (snapshot.present !== carrier.present)
          throw new HydrationMismatch("initial presence differs");
        for (const [name, value] of Object.entries(snapshot.attributes))
          if ((projectedAttributes?.[name] ?? null) !== value)
            throw new HydrationMismatch("fresh client attribute differs: " + name);
      },
      hydrationAttributes: carrier?.interactionAttributes,
      hydrationBaselines: projectionBaselines,
      createInteraction: createNativeInteraction,
      projectRoot(tag, properties, portal) {
        if (tag && !["input", "textarea", "img"].includes(tag))
          throw new Error("Unsupported physical Root tag");
        if (hydrating && (carrier?.control?.tag ?? null) !== tag)
          throw new HydrationMismatch("client physical Root differs from carrier");
        if (tag && !control) {
          control = doc.createElement(tag);
          control.setAttribute("part", tag === "img" ? "image" : "control");
          owned.add(control);
        }
        if (control && control.localName !== tag)
          throw new Error("Physical control declaration cannot change during an owner lifetime");
        if (control && !hydrating)
          for (const [name, value] of Object.entries(properties)) {
            if (name === "value") {
              if (!accepted)
                control.value = String(value ?? "");
              continue;
            }
            if (value === null || value === false)
              control.removeAttribute(name);
            else
              control.setAttribute(name, value === true ? "" : String(value));
          }
        if (portal) {
          if (!portalAnchor) {
            portalParent = logicalParent(host);
            portalAnchor = doc.createComment("pui-portal");
            host.parentNode?.insertBefore(portalAnchor, host);
          }
          if (host.parentNode !== portal)
            portal.appendChild(host);
        } else if (portalAnchor) {
          portalAnchor.parentNode?.insertBefore(host, portalAnchor);
          portalAnchor.remove();
          portalAnchor = null;
          portalParent = null;
        }
      },
      projectInteraction(snapshot) {
        for (const [key, value] of Object.entries(snapshot))
          port.attribute(key, value);
      },
      attribute(name, value) {
        let entry = attributes.get(name);
        const target = control ?? host;
        const current = target.getAttribute(name);
        if (!entry) {
          const projectedByServer = projectedAttributes && Object.hasOwn(projectedAttributes, name) && current === projectedAttributes[name];
          entry = { baseline: projectedByServer ? projectionBaselines?.[name] ?? null : current, projected: current };
          attributes.set(name, entry);
        } else if (current !== entry.projected)
          entry.baseline = current;
        if (current !== value) {
          if (value === null)
            target.removeAttribute(name);
          else
            target.setAttribute(name, value);
        }
        entry.projected = value;
      },
      commit(children) {
        if (disposed)
          throw new Error("Browser port is disposed");
        if (hydrating) {
          if (JSON.stringify(children) !== JSON.stringify(expected))
            throw new HydrationMismatch("fresh client presentation differs from server projection");
          if (control)
            matchControl();
          else
            matchList(root, mode === "light" ? rootStart.nextSibling : root.firstChild, mode === "light" ? rootEnd : null, children, "Root", false);
          hydrating = false;
          projectNewChildren();
          observe();
          return;
        }
        if (control) {
          if (children.length)
            throw new Error("[Template] physical control Root requires empty children");
          if (control.parentNode !== root)
            root.appendChild(control);
          return;
        }
        const slotPool = mode === "light" ? pool() : [];
        for (const node of slotPool)
          node.parentNode?.removeChild(node);
        observer?.disconnect();
        observer = null;
        removeOwned();
        owned = /* @__PURE__ */ new WeakSet();
        projected = [];
        start = null;
        end = null;
        const fragment = doc.createDocumentFragment();
        materialize(fragment, children, slotPool);
        root.appendChild(fragment);
        if (!start)
          for (const node of slotPool)
            host.appendChild(node);
        observe();
      },
      visible(present) {
        if (!present) {
          if (!display)
            display = { value: host.style.getPropertyValue("display"), priority: host.style.getPropertyPriority("display") };
          host.style.setProperty("display", "none", "important");
        } else if (display) {
          if (host.style.getPropertyValue("display") === "none" && host.style.getPropertyPriority("display") === "important") {
            if (display.value)
              host.style.setProperty("display", display.value, display.priority);
            else
              host.style.removeProperty("display");
          }
          display = null;
        }
      },
      clear() {
        if (!accepted && carrier)
          return;
        const slotPool = mode === "light" ? pool().filter((node) => node !== control) : [];
        for (const node of slotPool)
          node.parentNode?.removeChild(node);
        observer?.disconnect();
        observer = null;
        removeOwned();
        start = null;
        end = null;
        projected = [];
        for (const node of slotPool)
          host.appendChild(node);
      },
      emit(key, payload, options) {
        if (!accepted) {
          emissions.push({ key, payload, options });
          return;
        }
        host.dispatchEvent(markNativeExposeEvent(new doc.defaultView.CustomEvent(key, { detail: payload, bubbles: true, cancelable: true, ...options })));
      },
      parentContext: () => portalAnchor ? portalParent : logicalParent(host),
      bindContext(scope) {
        if (scope)
          ownerScopes.set(host, scope);
        else
          ownerScopes.delete(host);
      },
      accept() {
        if (hydrating && carrier?.present)
          throw new HydrationMismatch("present carrier was not adopted");
        accepted = true;
        if (script)
          script.remove();
        if (carrier && !carrier.present)
          hydrating = false;
        if (rootStart)
          owned.add(rootStart);
        if (rootEnd)
          owned.add(rootEnd);
        for (const emission of emissions.splice(0)) {
          if (disposed)
            break;
          port.emit(emission.key, emission.payload, emission.options);
        }
      },
      dispose() {
        if (disposed)
          return;
        disposed = true;
        emissions.length = 0;
        observer?.disconnect();
        observer = null;
        const target = control ?? host;
        for (const [name, entry] of attributes)
          if (target.getAttribute(name) === entry.projected) {
            if (entry.baseline === null)
              target.removeAttribute(name);
            else
              target.setAttribute(name, entry.baseline);
          }
        attributes.clear();
        ownerScopes.delete(host);
        if (portalAnchor) {
          portalAnchor.parentNode?.insertBefore(host, portalAnchor);
          portalAnchor.remove();
          portalAnchor = null;
        }
        if (display) {
          if (display.value)
            host.style.setProperty("display", display.value, display.priority);
          else
            host.style.removeProperty("display");
          display = null;
        }
        if (carrier && !accepted) {
          for (const attribute of Array.from(host.attributes))
            host.removeAttribute(attribute.name);
          for (const [name, value] of initialAttributes)
            host.setAttribute(name, value);
          if (control && initialControlAttributes) {
            for (const attribute of Array.from(control.attributes))
              control.removeAttribute(attribute.name);
            for (const [name, value] of initialControlAttributes)
              control.setAttribute(name, value);
          }
        }
      }
    };
    if (recovery) {
      if (mode === "light") {
        const walker = doc.createTreeWalker(host, 128);
        for (let node = walker.nextNode(); node; node = walker.nextNode()) {
          if (marker(node, "pui-slot-start") && !start)
            start = node;
          else if (marker(node, "pui-slot-end") && start && node.parentNode === start.parentNode && !end)
            end = node;
        }
        projected = slotNodes();
      }
      if (rootStart && rootEnd)
        ownRootRange(rootStart, rootEnd);
      else if (mode === "shadow")
        for (const node of Array.from(root.childNodes))
          owned.add(node);
    }
    return port;
  }

  // owner-generated:Component.ts
  var hydrationBinding = "0ec9de32aba877df5b3b0662f5b9bd46bbc47d93157c6711db3a2f0910318756";
  var defaultTagName = "pui-browser-owner-retirement";
  var hydrationArtifacts = { "source": "d66264f9ac72f6b5d175d699614eab612e57b28fffb3c9655c0034ebbabae0e8", "helpers": "cd7ecedf80466fcee93bc1ca8ffc51ff7b30ea64b20f3337ec63eb5a9f610b7e", "css": "9e6c94d814da9de6c4ecb52a2678efdce66869b9905126205ac5a042ec330bef", "environment": "" };
  var hydrationCssText = "/* This file is auto-generated by @proto.ui/cli (proto-ui tokens). */\n/* Do not edit by hand. */\n\n@layer proto-ui {\n  :where([data-pui-style]),\n  :where([data-pui-style])::before,\n  :where([data-pui-style])::after {\n    box-sizing: border-box;\n  }\n\n  :where([data-pui-style]) {\n    --pui-ring-offset-shadow: initial;\n    --pui-ring-shadow: initial;\n    --pui-shadow: initial;\n    --pui-ring-inset: initial;\n    --pui-ring-width: initial;\n    --pui-ring-offset-width: initial;\n    --pui-ring-color: initial;\n    --pui-ring-offset-color: initial;\n    --pui-translate-x: initial;\n    --pui-translate-y: initial;\n    --pui-scale-x: initial;\n    --pui-scale-y: initial;\n  }\n\n  :where(button[data-pui-style], input[data-pui-style], select[data-pui-style], textarea[data-pui-style]) {\n    font: inherit;\n    font-feature-settings: inherit;\n    font-variation-settings: inherit;\n    letter-spacing: inherit;\n    color: inherit;\n    margin: 0;\n    padding: 0;\n    border: 0;\n    background: transparent;\n    opacity: 1;\n  }\n\n}\n";
  var hydrationEnvironmentCssText = "";
  var __wcPropTypes = { "seed": "number" };
  function __wcCreateOwner(host) {
    let alive = true, disposing = false, setup = true, callbackDepth = 0;
    let intent = true, view = false, epoch = 0, queued = false, dirty = false, hostScheduled = false;
    let propsWindow = null;
    let resolved = Object.freeze({}), raw = Object.freeze({}), hydrated = false;
    const specs = /* @__PURE__ */ Object.create(null), previous = /* @__PURE__ */ Object.create(null), defaults = [];
    const watchers = [], states = [], emissions = [];
    let emitting = false;
    const exposes = /* @__PURE__ */ Object.create(null), events = /* @__PURE__ */ new Set();
    const lifecycle = { created: [], mounted: [], updated: [], unmounted: [], beforeDispose: [] };
    const own = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);
    const ensure = () => {
      if (!alive) throw new Error("Logical owner is disposed");
    };
    const ensureExternal = () => {
      ensure();
      if (disposing) throw new Error("Logical owner is disposing");
    };
    const ensureSetup = () => {
      ensure();
      if (!setup) throw new Error("Setup capability is closed");
    };
    const runtime = () => {
      ensure();
      if (setup || !callbackDepth) throw new Error("State writes require a live callback scope");
    };
    const context = createContextScope({
      getParent: () => host.parentContext(),
      isAlive: () => alive,
      invoke: (callback) => invoke(callback, [], false),
      validate: (key, value) => false
    });
    function invoke(fn, args = [], withRun = true) {
      ensure();
      const check = () => runtime();
      const run = {
        host: { get() {
          check();
          return view && !disposing ? host.root : null;
        } },
        context: Object.freeze({
          read(key) {
            check();
            return context.read(key);
          },
          tryRead(key) {
            check();
            return context.tryRead(key);
          },
          update(key, next) {
            check();
            runtime();
            context.update(key, next);
          },
          tryUpdate(key, next) {
            check();
            runtime();
            return context.tryUpdate(key, next);
          }
        }),
        update() {
          check();
          if (!disposing) schedule(true);
        },
        props: Object.freeze({ get() {
          check();
          return propsWindow?.resolved ?? resolved;
        }, getRaw() {
          check();
          return propsWindow?.raw ?? raw;
        }, isProvided(key) {
          check();
          return own(propsWindow?.raw ?? raw, key);
        } }),
        lifecycle: { setPresent(next) {
          check();
          if (disposing) return;
          intent = next;
          schedule(false);
        } },
        expose: { emit(key, payload, options) {
          check();
          if (!events.has(key)) throw new Error("Undeclared exposed event: " + key);
          host.emit(key, payload, options);
        } }
      };
      ++callbackDepth;
      try {
        return fn(...withRun ? [run, ...args] : args);
      } finally {
        --callbackDepth;
      }
    }
    ownerScopes.set(host, context);
    host.bindContext(context);
    const contextRead = Object.freeze({
      read(key) {
        ensure();
        if (setup) throw new Error("Context reads require runtime scope");
        return context.read(key);
      },
      tryRead(key) {
        ensure();
        if (setup) throw new Error("Context reads require runtime scope");
        return context.tryRead(key);
      }
    });
    function fire(name) {
      if (name === "unmounted") {
      }
      try {
        for (const fn of lifecycle[name]) invoke(fn);
      } finally {
        if (name === "unmounted") {
        }
      }
    }
    function valid(spec, value) {
      if (spec.schema === void 0) throw new Error("Missing checked Props schema");
      return acceptsContextValue(spec.schema, value) && (!spec.options || spec.options.includes(value)) && (!spec.range || typeof value === "number" && value >= (spec.range.min ?? -Infinity) && value <= (spec.range.max ?? Infinity));
    }
    function resolve2(strict) {
      const next = /* @__PURE__ */ Object.create(null);
      for (const key of Object.keys(specs)) {
        const spec = specs[key], provided = own(raw, key), value = raw[key];
        const requireValue = strict && spec.empty === "error";
        if (provided && value != null && valid(spec, value)) {
          next[key] = value;
          previous[key] = value;
          continue;
        }
        if (provided && value == null && spec.empty === "accept") {
          next[key] = null;
          continue;
        }
        let candidate;
        if (provided && own(previous, key) && valid(spec, previous[key])) candidate = previous[key];
        if (candidate === void 0) for (const layer of defaults) {
          if (!own(layer, key)) continue;
          const value2 = layer[key];
          if (value2 === null && !requireValue || value2 != null && valid(spec, value2)) {
            candidate = value2;
            break;
          }
        }
        if (candidate === void 0 && own(spec, "default")) {
          const value2 = spec.default;
          if (value2 === null && !requireValue || value2 != null && valid(spec, value2)) candidate = value2;
        }
        if (candidate === void 0) {
          if (requireValue) throw new Error("Prop has no valid fallback: " + key);
          candidate = null;
        }
        next[key] = candidate;
        if (provided && next[key] != null) previous[key] = next[key];
      }
      return Object.freeze(next);
    }
    function hydrate2(input) {
      ensure();
      const prev = resolved, previousRaw = raw;
      raw = Object.freeze({ ...input });
      resolved = resolve2(true);
      if (!hydrated) {
        hydrated = true;
        return;
      }
      const changed = Object.keys(specs).filter((key) => !Object.is(prev[key], resolved[key]));
      const rawChanged = watchers.some((watcher) => watcher.raw && watcher.active) ? [.../* @__PURE__ */ new Set([...Object.keys(previousRaw), ...Object.keys(raw)])].filter((key) => !Object.is(previousRaw[key], raw[key])) : changed;
      const next = resolved, nextRaw = raw;
      const previousWindow = propsWindow;
      propsWindow = { raw: nextRaw, resolved: next };
      try {
        for (let group = 0; group < 3; ++group) for (const watcher of [...watchers]) {
          if ((watcher.raw ? watcher.keys === null ? 0 : 1 : 2) !== group) continue;
          const all = watcher.raw ? rawChanged : changed;
          const matched = watcher.keys === null ? all : all.filter((key) => watcher.keys.includes(key));
          if (watcher.active && matched.length) {
            if (watcher.raw) console.warn("[Props] raw watchers are an adapter-snapshot escape hatch; avoid in official prototypes.");
            invoke(watcher.fn, [watcher.raw ? nextRaw : next, watcher.raw ? previousRaw : prev, { changedKeysAll: all, changedKeysMatched: matched }]);
          }
        }
      } finally {
        propsWindow = previousWindow;
      }
    }
    function drainEmissions() {
      if (!emitting) {
        emitting = true;
        const notificationFailures = [];
        let notificationIndex = 0;
        try {
          while (notificationIndex < emissions.length && (alive && !disposing)) {
            try {
              emissions[notificationIndex++]();
            } catch (error) {
              Object.defineProperty(notificationFailures, notificationFailures.length, { value: error, writable: true, enumerable: true, configurable: true });
            }
          }
        } finally {
          emissions.length = 0;
          emitting = false;
        }
        if (notificationFailures.length === 1) throw notificationFailures[0];
        if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, "[State] subscriber failures");
      }
    }
    function state(kind, semantic, initial, options = {}) {
      ensureSetup();
      if (typeof semantic !== "string" || semantic.length === 0) throw new Error("Invalid state semantic");
      const spec = Object.freeze({ ...options, kind });
      function validate(value2) {
        const type = kind === "bool" ? "boolean" : kind === "string" || kind === "enum" ? "string" : "number";
        if (typeof value2 !== type || type === "number" && Number.isNaN(value2)) throw new Error("Invalid state value");
        if (options.options?.length && !options.options.includes(value2)) throw new Error("State value outside options");
        if (kind === "number.range" || kind === "number.discrete" && !options.options?.length) {
          const numeric = typeof value2 === "number" ? value2 : NaN;
          if (numeric < (options.min ?? -Infinity) || numeric > (options.max ?? Infinity)) throw new Error("State value outside range");
          if (kind === "number.discrete" && options.step !== void 0 && options.step > 0 && !Number.isInteger((numeric - (options.min ?? 0)) / options.step)) throw new Error("State value violates step");
        }
      }
      if (kind === "number.range" && options.clamp) initial = Math.max(options.min ?? -Infinity, Math.min(options.max ?? Infinity, initial));
      validate(initial);
      let value = initial;
      const subscribers = /* @__PURE__ */ new Set();
      const external = Object.freeze({
        get() {
          ensureExternal();
          return value;
        },
        spec,
        subscribe(fn) {
          ensureExternal();
          const registration = (event) => fn(event);
          subscribers.add(registration);
          return () => subscribers.delete(registration);
        },
        unsubscribe(off) {
          ensureExternal();
          off();
        }
      });
      const handle = {
        external,
        subscribers,
        get() {
          ensure();
          return value;
        },
        setDefault(next) {
          ensureSetup();
          validate(next);
          value = next;
        },
        set(next, reason) {
          runtime();
          validate(next);
          if (Object.is(value, next)) return;
          const prev = value;
          value = next;
          for (const subscriber of Array.from(subscribers)) {
            Object.defineProperty(emissions, emissions.length, { value: () => {
              if (alive && !disposing && subscribers.has(subscriber)) {
                invoke(subscriber, [{ type: "next", prev, next, reason }], false);
              }
            }, writable: true, enumerable: true, configurable: true });
          }
          drainEmissions();
        }
      };
      states.push(handle);
      return handle;
    }
    function element(tag, a, b) {
      const props = arguments.length > 2 ? a : a != null && typeof a === "object" && !Array.isArray(a) && !isPresentation(a) ? a : void 0;
      const children = arguments.length === 1 ? null : arguments.length > 2 ? b : props === void 0 ? a : null;
      return presentationElement(tag, void 0, children);
    }
    let slotUsed = false;
    function render() {
      slotUsed = false;
      const props = Object.freeze({ get: () => resolved, getRaw: () => raw, isProvided: (key) => own(raw, key) });
      const renderer = { el: element, slot() {
        if (slotUsed) throw new Error("Multiple slots are unsupported");
        slotUsed = true;
        return { kind: "slot" };
      }, props, read: Object.freeze({ props, context: contextRead }) };
      projectHost();
      host.commit(presentationChildren(typeof owner.render === "function" ? owner.render(renderer) : renderer.slot()));
    }
    function projectHost() {
      host.projectRoot(null, {}, null);
    }
    function detach() {
      host.visible(false);
      if (!view) return;
      view = false;
      ++epoch;
      let error;
      try {
        fire("unmounted");
      } catch (caught) {
        error ??= caught;
      } finally {
        host.clear();
      }
      if (error !== void 0) throw error;
    }
    function reconcile() {
      if (!alive || disposing || !host.isConnected || host.server) return;
      if (!intent) {
        detach();
        return;
      }
      host.visible(true);
      if (!view) {
        ++epoch;
        render();
        view = true;
        dirty = false;
        fire("mounted");
      } else if (dirty) {
        dirty = false;
        render();
        fire("updated");
      }
    }
    function schedule(update) {
      ensure();
      dirty ||= update;
      if (host.server || queued || disposing) return;
      queued = true;
      queueMicrotask(() => {
        queued = false;
        if (!alive || disposing) return;
        if (host.isConnected) reconcile();
      });
    }
    function expose(key, value) {
      ensureSetup();
      if (own(exposes, key) || events.has(key)) throw new Error("Duplicate expose: " + key);
      exposes[key] = value;
    }
    const def = {
      context: {
        provide(key, value) {
          ensureSetup();
          context.provide(key, value);
        },
        subscribe(key, callback) {
          ensureSetup();
          return context.subscribe(key, "required", callback ? (next, prev) => {
            invoke(callback, [next, prev]);
          } : void 0);
        },
        trySubscribe(key, callback) {
          ensureSetup();
          return context.subscribe(key, "optional", callback ? (next, prev) => {
            invoke(callback, [next, prev]);
          } : void 0);
        }
      },
      props: {
        define(input) {
          ensureSetup();
          const merged = { ...specs };
          for (const key of Object.keys(input)) {
            const next = input[key], prev = specs[key];
            if (!["boolean", "number", "string", "enum", "object", "any"].includes(next.type)) throw new Error("Unsupported prop type");
            if (next.empty !== void 0 && !["accept", "fallback", "error"].includes(next.empty)) throw new Error("Invalid prop empty policy");
            if (next.range && (next.range.min !== void 0 && (typeof next.range.min !== "number" || Number.isNaN(next.range.min)) || next.range.max !== void 0 && (typeof next.range.max !== "number" || Number.isNaN(next.range.max)))) throw new Error("Invalid prop range");
            if (prev && (prev.type !== next.type || prev.range && next.range && ((next.range.min ?? -Infinity) > (prev.range.min ?? -Infinity) || (next.range.max ?? Infinity) < (prev.range.max ?? Infinity)))) throw new Error("Conflicting prop declaration");
            const rank = (empty) => empty === "accept" ? 0 : empty === "error" ? 2 : 1;
            if (prev && next.empty !== void 0 && rank(next.empty) > rank(prev.empty ?? "fallback")) throw new Error("Conflicting prop empty policy");
            merged[key] = { ...prev, ...next, schema: __wcPropTypes[key], empty: prev?.empty ?? next.empty ?? "fallback", range: next.range ?? prev?.range, ...prev && own(prev, "default") ? { default: prev.default } : {} };
          }
          Object.assign(specs, merged);
          resolved = resolve2(false);
        },
        setDefaults(input) {
          ensureSetup();
          for (const key of Object.keys(input)) if (!own(specs, key)) throw new Error("Undeclared prop default: " + key);
          defaults.unshift({ ...input });
          resolved = resolve2(false);
        },
        watch(keys, fn) {
          ensureSetup();
          const watcher = { keys: [...keys], fn, active: true, raw: false };
          watchers.push(watcher);
          return () => {
            watcher.active = false;
          };
        },
        watchAll(fn) {
          ensureSetup();
          const watcher = { keys: null, fn, active: true, raw: false };
          watchers.push(watcher);
          return () => {
            watcher.active = false;
          };
        },
        watchRaw(keys, fn) {
          ensureSetup();
          const watcher = { keys: [...keys], fn, active: true, raw: true };
          watchers.push(watcher);
          return () => {
            watcher.active = false;
          };
        },
        watchRawAll(fn) {
          ensureSetup();
          const watcher = { keys: null, fn, active: true, raw: true };
          watchers.push(watcher);
          return () => {
            watcher.active = false;
          };
        }
      },
      state: { bool: (s, v) => state("bool", s, v), enum: (s, v, o) => state("enum", s, v, o), string: (s, v, o) => state("string", s, v, o), numberDiscrete: (s, v, o) => state("number.discrete", s, v, o), numberRange: (s, v, o) => state("number.range", s, v, o) },
      expose: {
        value: expose,
        state(key, handle) {
          expose(key, handle.external);
        },
        method(key, fn, project) {
          expose(key, (...args) => {
            ensureExternal();
            const result = invoke(fn, args, false);
            return project ? project(result) : result;
          });
        },
        event(key) {
          ensureSetup();
          if (own(exposes, key) || events.has(key)) throw new Error("Duplicate expose: " + key);
          events.add(key);
        }
      },
      lifecycle: { onCreated(fn) {
        ensureSetup();
        lifecycle.created.push(fn);
      }, onMounted(fn) {
        ensureSetup();
        lifecycle.mounted.push(fn);
      }, onUpdated(fn) {
        ensureSetup();
        lifecycle.updated.push(fn);
      }, onUnmounted(fn) {
        ensureSetup();
        lifecycle.unmounted.push(fn);
      }, onBeforeDispose(fn) {
        ensureSetup();
        lifecycle.beforeDispose.push(fn);
      } }
    };
    const owner = {
      identity: Symbol("compiled-logical-owner"),
      def,
      exposes,
      render: void 0,
      get epoch() {
        return epoch;
      },
      get view() {
        return view;
      },
      hydrate: hydrate2,
      update: () => schedule(true),
      reconcile,
      validateHydration() {
        host.validateInitial?.({ present: intent, attributes: {} });
      },
      serialize() {
        ensure();
        if (!host.server) throw new Error("serialize requires a server owner");
        host.visible(intent);
        if (intent) render();
        else host.commit([]);
        dirty = false;
      },
      created() {
        setup = false;
        fire("created");
      },
      dispose(exhaustive = false) {
        if (!alive || disposing) return;
        disposing = true;
        let error;
        try {
          detach();
        } catch (caught) {
          error = { value: caught };
        }
        try {
          if (exhaustive) {
            for (const callback of lifecycle.beforeDispose) {
              try {
                invoke(callback);
              } catch (caught) {
                error ??= { value: caught };
              }
            }
          } else fire("beforeDispose");
        } catch (caught) {
          error ??= { value: caught };
        } finally {
          ownerScopes.delete(host);
          context.dispose();
          host.bindContext(null);
          alive = false;
          ++epoch;
          dirty = false;
          watchers.length = 0;
          emissions.length = 0;
          for (const handle of states) handle.subscribers.clear();
          for (const callbacks of Object.values(lifecycle)) callbacks.length = 0;
          host.clear();
        }
        if (error) throw error.value;
      }
    };
    return owner;
  }
  function createHydrationOwner(port, raw) {
    assertNoInstanceAssociations(raw, "hydration props");
    const owner = __wcCreateOwner(port);
    const __wcDef = owner.def;
    try {
      owner.render = ((def) => {
        def.props.define({ ["seed"]: { ["type"]: "number", ["default"]: 3 } });
        const value = def.state.numberDiscrete("value", 0);
        def.expose.state("value", value);
        def.expose.event("phase", { ["payload"]: "json" });
        def.props.watch(["seed"], (run, next) => {
          value.set(next["seed"]);
          run.update();
        });
        def.lifecycle.onCreated((run) => {
          value.set(run.props.get()["seed"]);
          run.expose.emit("phase", "created");
        });
        def.lifecycle.onMounted((run) => {
          return run.expose.emit("phase", "mounted");
        });
        def.lifecycle.onUnmounted((run) => {
          return run.expose.emit("phase", "unmounted");
        });
        def.lifecycle.onBeforeDispose((run) => {
          return run.expose.emit("phase", "disposed");
        });
        return (r) => {
          return r.el("output", value.get());
        };
      })(__wcDef);
      owner.hydrate(raw);
      owner.created();
      return owner;
    } catch (error) {
      try {
        owner.dispose(true);
      } catch {
      }
      throw error;
    }
  }

  // owner-generated:Component.client.ts
  var OwnerRetirement = class extends HTMLElement {
    owner = null;
    port = null;
    raw = {};
    hasRaw = false;
    carrier = null;
    closed = false;
    retiring = false;
    disconnectVersion = 0;
    recovering = false;
    initializedCarrier = false;
    acceptedMode = null;
    failedCarrier = null;
    associations;
    hydrationStatus = "pending";
    hydrationDiagnostic = null;
    get logicalOwner() {
      return this.owner?.identity ?? null;
    }
    get viewEpoch() {
      return this.owner?.epoch ?? 0;
    }
    get present() {
      return this.owner?.view ?? false;
    }
    get instanceAssociations() {
      return this.associations;
    }
    set instanceAssociations(value) {
      if (this.closed) throw new Error("Custom element is disposed");
      {
        const PUIInputAssociations = value;
        if (PUIInputAssociations !== void 0) {
          if (PUIInputAssociations === null || typeof PUIInputAssociations !== "object" || Object.getPrototypeOf(PUIInputAssociations) !== Object.prototype)
            throw new TypeError("[InstanceAssociations] expected a plain record");
          for (const key of Reflect.ownKeys(PUIInputAssociations)) if (key !== "controlLabel")
            throw new TypeError("[InstanceAssociations] unknown association key");
          if (Object.prototype.hasOwnProperty.call(PUIInputAssociations, "controlLabel") && Reflect.get(PUIInputAssociations, "controlLabel") != null)
            throw new Error("[ControlLabel] this Prototype has not declared Label or target participation");
        }
      }
      this.associations = value;
    }
    static get observedAttributes() {
      return ["instance-associations", "instanceassociations"];
    }
    attributeChangedCallback(_name, _previous, value) {
      if (value !== null) throw new TypeError("[InstanceAssociations] use the instanceAssociations property, not an attribute string");
    }
    connectedCallback() {
      ++this.disconnectVersion;
      if (this.closed || this.retiring) return;
      if (this.owner) {
        this.owner.reconcile();
        return;
      }
      const definition = pendingProviderDefinition(this);
      if (definition) {
        const version = this.disconnectVersion;
        definition.then(() => {
          if (this.closed || version !== this.disconnectVersion || !this.isConnected || this.owner) return;
          this.connectedCallback();
        });
        return;
      }
      try {
        const carrier = this.recovering ? this.failedCarrier : this.carrier ?? (!this.initializedCarrier ? readCarrier(this) : null);
        this.failedCarrier = carrier;
        if (carrier && !this.recovering) checkCarrier(carrier, hydrationBinding, this.localName, hydrationArtifacts);
        if (carrier && !this.recovering) {
          if (this.hasRaw) checkInitialProps(this.raw, carrier);
          checkStylesheet(this, hydrationArtifacts.css, hydrationCssText);
          checkStylesheet(this, hydrationArtifacts.environment, hydrationEnvironmentCssText, "consumer environment");
        }
        let mode = carrier?.mode ?? this.acceptedMode ?? "light";
        if (this.recovering) mode = carrier?.mode === "shadow" || this.shadowRoot || this.querySelector(':scope > template[shadowrootmode="open"]') ? "shadow" : "light";
        const port = createBrowserPort(this, mode, carrier && !this.recovering ? carrier : null, this.recovering);
        this.port = port;
        const pending = this.hasRaw ? this.raw : null;
        const initial = carrier && !this.recovering ? decodeRaw(carrier.raw) : this.raw;
        if (!pending) this.raw = { ...initial };
        const owner = createHydrationOwner(port, initial);
        this.owner = owner;
        try {
          owner.validateHydration();
          owner.reconcile();
        } catch (error) {
          this.owner = null;
          try {
            owner.dispose();
          } catch (cleanup) {
            throw new AggregateError([error, cleanup], "Hydration and cleanup failed");
          }
          throw error;
        }
        port.accept();
        if (this.closed || this.owner !== owner) return;
        this.acceptedMode = mode;
        this.initializedCarrier = true;
        this.carrier = null;
        this.failedCarrier = null;
        this.hydrationStatus = this.recovering ? "recovered" : carrier ? "adopted" : "client";
        this.recovering = false;
        if (this.hasRaw && carrier) owner.hydrate(this.raw);
      } catch (error) {
        const owner = this.owner;
        this.owner = null;
        let failure = error;
        try {
          owner?.dispose();
        } catch (cleanup) {
          failure = new AggregateError([error, cleanup], "Initialization and cleanup failed");
        } finally {
          this.port?.dispose();
          this.port = null;
        }
        if (error instanceof HydrationMismatch) {
          this.hydrationStatus = "mismatch";
          this.hydrationDiagnostic = error;
        }
        throw failure;
      }
    }
    disconnectedCallback() {
      const version = ++this.disconnectVersion, owner = this.owner, port = this.port;
      queueMicrotask(() => {
        if (version !== this.disconnectVersion || this.isConnected || !owner || owner !== this.owner) return;
        this.owner = null;
        this.port = null;
        this.retiring = true;
        try {
          owner.dispose();
        } finally {
          try {
            port?.dispose();
          } finally {
            this.retiring = false;
            if (!this.closed && this.isConnected) {
              const reconnectedVersion = this.disconnectVersion;
              queueMicrotask(() => {
                if (!this.closed && !this.owner && this.isConnected && reconnectedVersion === this.disconnectVersion) this.connectedCallback();
              });
            }
          }
        }
      });
    }
    setProps(next) {
      if (this.closed) throw new Error("Custom element is disposed");
      assertNoInstanceAssociations(next, "Props");
      this.hasRaw = true;
      this.raw = { ...next };
      if (this.owner) this.owner.hydrate(this.raw);
    }
    update() {
      if (this.closed) throw new Error("Custom element is disposed");
      this.owner?.update();
    }
    getExposes() {
      return this.isConnected && this.owner ? { ...this.owner.exposes } : {};
    }
    hydrate(next) {
      if (this.closed) throw new Error("Custom element is disposed");
      checkCarrier(next, hydrationBinding, this.localName, hydrationArtifacts);
      if (this.owner) throw new Error("Custom element already owns a committed instance");
      if (this.initializedCarrier) throw new Error("Carrier has already been adopted");
      this.carrier = next;
      if (this.isConnected) this.connectedCallback();
    }
    /** Recovery is opt-in and reports recovered, never adopted. Existing external slot nodes are preserved. */
    recover(next) {
      if (this.closed) throw new Error("Custom element is disposed");
      if (this.hydrationStatus !== "mismatch") throw new Error("Recovery requires a diagnosed hydration mismatch");
      if (next) {
        assertNoInstanceAssociations(next, "Props");
        this.raw = { ...next };
        this.hasRaw = true;
      }
      this.carrier = this.failedCarrier;
      this.recovering = true;
      if (this.isConnected) this.connectedCallback();
    }
    dispose() {
      if (this.closed) return;
      this.closed = true;
      ++this.disconnectVersion;
      const owner = this.owner;
      this.owner = null;
      try {
        owner?.dispose();
      } finally {
        this.port?.dispose();
        this.port = null;
        this.carrier = null;
      }
    }
  };
  function register(tagName = defaultTagName, registry = customElements) {
    const existing = registry.get(tagName);
    if (existing && existing !== OwnerRetirement) throw new Error("Custom element tag already registered: " + tagName);
    if (!existing) registry.define(tagName, OwnerRetirement);
    return OwnerRetirement;
  }
  function hydrate(element, carrier) {
    if (!(element instanceof OwnerRetirement)) throw new Error("Register the generated Custom Element before hydrating");
    if (carrier !== void 0) {
      checkCarrier(carrier, hydrationBinding, element.localName, hydrationArtifacts);
      checkCarrierHost(element, carrier);
    }
    if (element.hydrationStatus === "mismatch") throw element.hydrationDiagnostic;
    if (carrier && element.hydrationStatus === "pending") element.hydrate(carrier);
    else if (!element.logicalOwner && element.isConnected) element.connectedCallback();
    return element;
  }
  var Component_client_default = OwnerRetirement;
  return __toCommonJS(Component_client_exports);
})();
