#!/usr/bin/env bash
set -eu -o pipefail
export PATH=/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:$PATH
export CHROME_PATH=/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/playwright-browsers/chromium-1208/chrome-linux64/chrome
export PUI_CHROME_EXECUTABLE=$CHROME_PATH
export TMPDIR=/tank/shared/projects/proto-ui-agent/sprint5-f7b2/t
export ASTRO_TELEMETRY_DISABLED=1
TASK_RUN=/tank/shared/projects/proto-ui-agent/sprint5-f7b2/browser-run-0b7b212d
cd /tank/shared/projects/proto-ui-agent/sprint5-f7b2/repo
node --version
git rev-parse HEAD
df -h /tmp "$TMPDIR"
if command -v fc-match >/dev/null; then fc-match 'Noto Sans CJK SC'; fi
export COMPILER_EVIDENCE_DIR=$TASK_RUN/owner-tank
set +e
corepack pnpm@10.32.1 exec vitest run packages/compiler/test/owner-hydration-retirement.browser.test.ts --maxWorkers=1 --minWorkers=1 --reporter=default --reporter=json --outputFile="$TASK_RUN/owner-tank-vitest.json" 2>&1 | tee "$TASK_RUN/owner-tank.log"
TASK_STATUS=${PIPESTATUS[0]}
set -e
printf '%s\n' "$TASK_STATUS" > "$TASK_RUN/owner-tank.status"
if test "$TASK_STATUS" != 0; then exit "$TASK_STATUS"; fi
node -e 'const r=require(process.argv[1]);if(r.numTotalTests!==4||r.numPassedTests!==4||r.numFailedTests!==0||r.numPendingTests!==0)throw Error("Owner browser denominator mismatch");console.log("Owner browser: 4/4, no skips")' "$TASK_RUN/owner-tank-vitest.json"
export PUI_BROWSER_MODE=production
export PUI_EVIDENCE_DIR=$TASK_RUN/canonical-baseline
export CANDIDATE_SHA=0b7b212d3193ea5c7ae219c0501036ee1255e3f2
set +e
node --import tsx scripts/analysis/browser-compiler-browser.mts 2>&1 | tee "$TASK_RUN/canonical-baseline.log"
TASK_STATUS=${PIPESTATUS[0]}
set -e
printf '%s\n' "$TASK_STATUS" > "$TASK_RUN/canonical-baseline.status"
exit "$TASK_STATUS"
