#!/usr/bin/env bash
set -eu -o pipefail
export PATH=/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:$PATH
export CHROME_PATH=/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/playwright-browsers/chromium-1208/chrome-linux64/chrome
export COMPILER_EVIDENCE_DIR=/tank/shared/projects/proto-ui-agent/sprint5-f7b2/browser-run-0b7b212d/owner-retry
TASK_RUN=/tank/shared/projects/proto-ui-agent/sprint5-f7b2/browser-run-0b7b212d
cd /tank/shared/projects/proto-ui-agent/sprint5-f7b2/repo
pwd
node --version
corepack pnpm@10.32.1 exec vitest --version
node -e 'const fs=require("node:fs"); console.log({cwd:process.cwd(),fixture:fs.statSync("packages/compiler/test/owner-hydration-retirement.browser.test.ts").size,vitest:require.resolve("vitest/package.json")})'
set +e
corepack pnpm@10.32.1 exec vitest run packages/compiler/test/owner-hydration-retirement.browser.test.ts --maxWorkers=1 --minWorkers=1 --reporter=default --reporter=json --outputFile="$TASK_RUN/owner-retry-vitest.json" 2>&1 | tee "$TASK_RUN/owner-retry.log"
TASK_STATUS=${PIPESTATUS[0]}
set -e
printf '%s\n' "$TASK_STATUS" > "$TASK_RUN/owner-retry.status"
exit "$TASK_STATUS"
