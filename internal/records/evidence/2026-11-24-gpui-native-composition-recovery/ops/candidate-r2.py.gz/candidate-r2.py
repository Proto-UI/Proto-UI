from pathlib import Path
import subprocess,os,json,datetime,tempfile,hashlib
r=Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a');o=Path(str(r)+'-ops')
out=o/'candidate-generated';numeric=o/'candidate-numeric';label=o/'candidate-official-label'
env=dict(os.environ);env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:/home/ezra/.cargo/bin:'+env['PATH'];env['CARGO_BUILD_JOBS']='1';env['CARGO_TARGET_DIR']=str(o/'cargo-target');env['CARGO_NET_OFFLINE']='true';env['CI']='true'
prior=json.loads((o/'candidate-status.json').read_text())
assert prior['state']=='failed' and prior['commands'][-1]['name']=='candidate-sdk-controls'
assert prior['sourceBefore']==prior['sourceAfter']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected=prior['sourceBefore']
for name,digest in expected.items():assert sha(r/name)==digest,name
files=set(expected)
for stem in ['gpui-ordinary-values','gpui-control-label','gpui-a11y-value']:
 for p in (r/'packages/compiler/test/fixtures'/stem).iterdir():
  if p.is_file():files.add(str(p.relative_to(r)))
files.update(['scripts/gpui/check-cargo-graph.mjs','.github/workflows/compiler-gpui-source-consumers.yml'])
snap=lambda:{name:sha(r/name)for name in sorted(files)}
state={'state':'running','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':prior['base'],'priorStatus':'candidate-status.json','priorDriverFailure':'SDK package selected through a non-workspace ordinary consumer; corrected to the official numeric-action workspace used by CI. No product source changed.','sourceBefore':snap(),'commands':[]}
def save():(o/'candidate-r2-status.json').write_text(json.dumps(state,indent=2))
def run(name,args,limit=1200):
 item={'name':name,'command':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};state['commands'].append(item);save()
 with (o/(name+'.log')).open('w')as log:
  try:p=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=limit);code=p.returncode
  except subprocess.TimeoutExpired:code=124
 item.update(exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();return code==0
base=['cargo','+1.98.1']
def body():
 if not run('candidate-numeric-producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-a11y-value/produce.mjs',str(numeric)],300):return False
 sdk1=out/'transition/.proto-ui/gpui-native/src';sdk2=numeric/'component/.proto-ui/gpui-native/src'
 a={str(p.relative_to(sdk1)):sha(p)for p in sdk1.rglob('*')if p.is_file()};b={str(p.relative_to(sdk2)):sha(p)for p in sdk2.rglob('*')if p.is_file()}
 state['sdkSourcesOrdinary']=a;state['sdkSourcesNumeric']=b;save()
 assert a==b,'official ordinary and numeric producers emitted different SDK sources'
 if not run('candidate-numeric-metadata',base+['metadata','--offline','--all-features','--format-version','1','--manifest-path',str(numeric/'Cargo.toml')],300):return False
 if not run('candidate-numeric-graph',['node','scripts/gpui/check-cargo-graph.mjs','--manifest-path',str(numeric/'Cargo.toml'),'--git','https://github.com/zed-industries/zed','--rev','62e5991dd0f0c8a3af8d5e7e9c4652490d468db8','--toolchain','1.98.1','--output',str(o/'candidate-numeric-graph.json')],300):return False
 if not run('candidate-sdk-controls-r2',base+['test','--offline','--locked','--manifest-path',str(numeric/'Cargo.toml'),'-p','proto-ui-gpui-native','--features','test-support,gpui/test-support','--lib','--','--test-threads=1','--nocapture']):return False
 manifest=['--manifest-path',str(out/'transition/Cargo.toml')]
 for target in ['ordinary','control_label','style_mapping','a11y_activation','scroll_pause','scroll_reader']:
  if not run('candidate-'+target,base+['test','--offline','--locked']+manifest+['--features','test-support','--test',target,'--','--test-threads=1','--nocapture']):return False
 if not run('candidate-numeric-consumer',base+['test','--offline','--locked','--manifest-path',str(numeric/'Cargo.toml'),'--test','a11y_value','--','--test-threads=1','--nocapture']):return False
 if not run('candidate-official-label-producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-control-label/produce.mjs',str(label)],300):return False
 if not run('candidate-official-label-metadata',base+['metadata','--offline','--all-features','--format-version','1','--manifest-path',str(label/'Cargo.toml')],300):return False
 if not run('candidate-official-label-consumer',base+['test','--offline','--locked','--manifest-path',str(label/'Cargo.toml'),'--test','control_label','--','--test-threads=1','--nocapture']):return False
 return run('native-diff-check',['git','diff','--check'],30)
save()
try:
 with tempfile.TemporaryDirectory(prefix='ncr275d5-',dir='/var/tmp')as tmp:
  env['TMPDIR']=tmp;ok=body()
 state['state']='passed'if ok else'failed'
except Exception as error:state.update(state='failed',exception=repr(error))
finally:
 state.update(sourceAfter=snap(),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
