from pathlib import Path
import os,json,subprocess,tempfile,datetime,hashlib
r=Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a');o=Path(str(r)+'-ops');out=o/'lease-red-numeric'
env=dict(os.environ);env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:/home/ezra/.cargo/bin:'+env['PATH'];env['CARGO_BUILD_JOBS']='1';env['CARGO_TARGET_DIR']=str(o/'cargo-target');env['CARGO_NET_OFFLINE']='true';env['CI']='true'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=list(r.glob('packages/compiler/src/gpui-native*.ts'))+[r/'packages/compiler/test/fixtures/gpui-a11y-value/produce.mjs']
snap=lambda:{str(p.relative_to(r)):sha(p)for p in files}
state={'state':'running','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceBefore':snap(),'commands':[]}
def save():(o/'lease-red-status.json').write_text(json.dumps(state,indent=2))
def run(name,args,limit=1200):
 item={'name':name,'command':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};state['commands'].append(item);save()
 with(o/(name+'.log')).open('w')as log:
  try:code=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=limit).returncode
  except subprocess.TimeoutExpired:code=124
 item.update(exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();return code
save()
try:
 with tempfile.TemporaryDirectory(prefix='nclr75d5-',dir='/var/tmp')as tmp:
  env['TMPDIR']=tmp
  assert run('lease-red-producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-a11y-value/produce.mjs',str(out)],300)==0
  base=['cargo','+1.98.1'];manifest=['--manifest-path',str(out/'Cargo.toml')]
  assert run('lease-red-metadata',base+['metadata','--offline','--all-features','--format-version','1']+manifest,300)==0
  test=base+['test','--offline','--locked']+manifest+['-p','proto-ui-gpui-native','--features','test-support,gpui/test-support','--lib']
  code=run('lease-original-negative',test+['retained_action_leases_cannot_acquire_replacement_physical_nodes','--','--test-threads=1','--nocapture'])
  text=(o/'lease-original-negative.log').read_text()
  assert code==101 and 'an old action lease must not acquire a replacement physical node; target=true' in text and 'test result: FAILED. 0 passed; 1 failed;'in text,'expected behavioral rejection was not observed'
  state['negativeObserved']=True;save()
  assert run('hover-current-app-registration',test+['current_hover_leave_cancels_label_activation_but_retired_leave_does_not','--','--test-threads=1','--nocapture'])==0
 state['state']='expected-rejection-observed'
except Exception as error:state.update(state='failed',exception=repr(error))
finally:
 state.update(sourceAfter=snap(),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
