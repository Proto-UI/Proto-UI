from pathlib import Path
import os,json,subprocess,tempfile,datetime,hashlib
r=Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a');o=Path(str(r)+'-ops');w=o/'immutable-consumers';w.mkdir(exist_ok=False)
prior=json.loads((o/'immutable-action-trial/status.json').read_text());assert prior['state']=='failed'and prior['sourceBefore']==prior['sourceAfter']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in prior['sourceBefore'].items():assert sha(r/name)==digest,name
env=dict(os.environ);env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:/home/ezra/.cargo/bin:'+env['PATH'];env['CARGO_BUILD_JOBS']='1';env['CARGO_TARGET_DIR']='/tank/shared/projects/proto-ui-agent/s5-adapter-readonly-target75d5';env['CARGO_NET_OFFLINE']='true';env['CARGO_PROFILE_DEV_DEBUG']='0';env['CARGO_PROFILE_TEST_DEBUG']='0';env['CI']='true'
state={'state':'running','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceBefore':prior['sourceBefore'],'sdkStatus':'../immutable-action-trial/status.json','sdkResult':'57 passed / 1 failed in unchanged cached same-path target-frame control; this independent run does not replace or hide that failure.','commands':[]}
def save():(w/'status.json').write_text(json.dumps(state,indent=2))
def run(name,args,limit=1200):
 item={'name':name,'command':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};state['commands'].append(item);save()
 with(w/(name+'.log')).open('w')as log:
  try:code=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=limit).returncode
  except subprocess.TimeoutExpired:code=124
 item.update(exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();return code==0
def source_snapshot():return{name:sha(r/name)for name in prior['sourceBefore']}
def generated_snapshot():
 return{str(p.relative_to(w)):sha(p)for stem in ['ordinary','numeric','official-label']for p in (w/stem).rglob('*')if p.is_file()and(p.suffix in ['.rs','.toml']or p.name=='receipt.json')}
tests=['packages/compiler/test/'+name+'.test.ts'for name in ['gpui-control-label','control-label-lowering','gpui-authored-inputs','gpui-sdk-compatibility','scroll-axis-sync','gpui-event-notification','gpui-hook-renderer','gpui-a11y-value']]
base=['cargo','+1.98.1']
def body():
 results=[]
 results.append(run('source-controls',['corepack','pnpm@10.32.1','exec','vitest','run','--maxWorkers=1','--minWorkers=1','--reporter=json','--outputFile='+str(w/'source-controls.json')]+tests,600))
 for stem,fixture in [('ordinary','gpui-ordinary-values'),('numeric','gpui-a11y-value'),('official-label','gpui-control-label')]:
  assert source_snapshot()==state['sourceBefore']
  if not run(stem+'-producer',['node','--import','tsx','packages/compiler/test/fixtures/'+fixture+'/produce.mjs',str(w/stem)],300):return False
 state['sourceAtGeneration']=source_snapshot();assert state['sourceAtGeneration']==state['sourceBefore']
 state['generatedBefore']=generated_snapshot();state['generatedFrozen']=True;save()
 (w/'tested-source.patch').write_text(subprocess.check_output(['git','diff'],cwd=r,text=True))
 for stem in ['numeric','official-label']:
  if not run(stem+'-metadata',base+['metadata','--offline','--all-features','--format-version','1','--manifest-path',str(w/stem/'Cargo.toml')],300):return False
 manifest=['--manifest-path',str(w/'ordinary/transition/Cargo.toml')]
 if not run('ordinary-graph',['node','scripts/gpui/check-cargo-graph.mjs']+manifest+['--git','https://github.com/zed-industries/zed','--rev','62e5991dd0f0c8a3af8d5e7e9c4652490d468db8','--toolchain','1.98.1','--output',str(w/'ordinary-graph.json')],300):return False
 results.append(run('default-check',base+['check','--offline','--locked']+manifest+['--lib']))
 results.append(run('six-native-consumers',base+['test','--offline','--locked','--no-fail-fast']+manifest+['--features','test-support','--tests','--','--test-threads=1','--nocapture']))
 results.append(run('numeric-consumer',base+['test','--offline','--locked','--manifest-path',str(w/'numeric/Cargo.toml'),'--test','a11y_value','--','--test-threads=1','--nocapture']))
 results.append(run('official-label-consumer',base+['test','--offline','--locked','--manifest-path',str(w/'official-label/Cargo.toml'),'--test','control_label','--','--test-threads=1','--nocapture']))
 return all(results)
save()
try:
 with tempfile.TemporaryDirectory(prefix='ncf75d5-',dir='/var/tmp')as tmp:
  env['TMPDIR']=tmp;ok=body()
 state['state']='passed-independent-consumers'if ok else'failed'
except Exception as error:state.update(state='failed',exception=repr(error))
finally:
 state.update(sourceAfter=source_snapshot(),generatedAfter=generated_snapshot(),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
