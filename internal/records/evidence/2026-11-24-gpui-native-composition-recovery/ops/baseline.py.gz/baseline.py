import pathlib,subprocess,os,json,datetime,tempfile,hashlib
r=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a');o=pathlib.Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a-ops');out=o/'baseline-generated'
env=dict(os.environ);env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:/home/ezra/.cargo/bin:'+env['PATH'];env['CARGO_BUILD_JOBS']='1';env['CARGO_TARGET_DIR']=str(o/'cargo-target');env['CI']='true'
files=sorted(r.glob('packages/compiler/src/gpui-native*.ts'))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
state={'state':'running','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'sourceBefore':{str(p.relative_to(r)):digest(p)for p in files},'commands':[]}
def save(): (o/'baseline-status.json').write_text(json.dumps(state,indent=2))
def run(name,command,timeout):
 item={'name':name,'command':command,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};state['commands'].append(item);save()
 with (o/(name+'.log')).open('w')as log:
  try: p=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout);code=p.returncode
  except subprocess.TimeoutExpired: code=124
 item.update(exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();return code
save()
with tempfile.TemporaryDirectory(prefix='ncb75d5-',dir='/var/tmp')as tmp:
 env['TMPDIR']=tmp
 if run('baseline-producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs',str(out)],300)==0:
  run('baseline-cargo-check',['cargo','+1.98.1','check','--offline','--locked','--manifest-path',str(out/'transition/Cargo.toml'),'--lib'],1200)
state.update(state='completed',sourceAfter={str(p.relative_to(r)):digest(p)for p in files},finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
