from pathlib import Path
import os,subprocess,hashlib,json,datetime,sys,tempfile
r=Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a');o=Path(str(r)+'-ops');stage=sys.argv[1];w=o/('capture-spread-'+stage);w.mkdir(exist_ok=False)
files=['packages/compiler/src/ir-validation.ts','packages/compiler/src/parser.ts','packages/compiler/src/capture-types.ts','packages/compiler/test/capture-facade.test.ts','packages/compiler/test/value-ir.test.ts','packages/compiler/test/capture-lookup-integrity.test.ts','packages/compiler/test/authored-hook-language.test.ts']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
snapshot=lambda:{s:sha(r/s) for s in files}
state={'state':'running','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceBefore':snapshot(),'commands':[]}
def save():(w/'status.json').write_text(json.dumps(state,indent=2))
env=dict(os.environ);env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+env['PATH'];env['CI']='true'
save()
try:
 with tempfile.TemporaryDirectory(prefix='csp75d5-',dir='/var/tmp') as tmp:
  env['TMPDIR']=tmp
  cmd=['corepack','pnpm@10.32.1','exec','vitest','run','--maxWorkers=1','--minWorkers=1','--reporter=json','--outputFile='+str(w/'tests.json')]+files[3:]
  entry={'command':cmd};state['commands'].append(entry);save()
  with (w/'tests.log').open('w') as log:
   try:code=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600).returncode
   except subprocess.TimeoutExpired:code=124
  entry['exitCode']=code;state['state']='passed' if code==0 else 'failed'
except Exception as error:state.update(state='failed',exception=repr(error))
finally:state.update(sourceAfter=snapshot(),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
