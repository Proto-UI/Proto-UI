import pathlib,subprocess,os,json,datetime,tempfile,hashlib
r=pathlib.Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a');o=pathlib.Path(str(r)+'-ops');out=o/'candidate-generated';label=o/'candidate-official-label'
env=dict(os.environ);env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:/home/ezra/.cargo/bin:'+env['PATH'];env['CARGO_BUILD_JOBS']='1';env['CARGO_TARGET_DIR']=str(o/'cargo-target');env['CI']='true'
changed=['packages/compiler/src/gpui-native-'+name+'.ts' for name in ['owner','modules','hover','control-label','scroll']]
tests=['packages/compiler/test/'+name+'.test.ts'for name in ['gpui-control-label','control-label-lowering','gpui-authored-inputs','gpui-sdk-compatibility','scroll-axis-sync','gpui-event-notification','gpui-hook-renderer','gpui-a11y-value']]
inputs=sorted(set(list(r.glob('packages/compiler/src/gpui-native*.ts'))+[r/p for p in tests]+[r/'packages/compiler/src/gpui-source.ts',r/'packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs',r/'packages/compiler/test/fixtures/gpui-control-label/produce.mjs']))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
state={'state':'running','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'commands':[]}
def save(): (o/'candidate-status.json').write_text(json.dumps(state,indent=2))
def run(name,args,limit=600):
 item={'name':name,'command':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};state['commands'].append(item);save()
 with (o/(name+'.log')).open('w')as log:
  try:p=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=limit);code=p.returncode
  except subprocess.TimeoutExpired:code=124
 item.update(exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();return code==0
def body():
 if not run('native-format',['node','node_modules/prettier/bin/prettier.cjs','--write']+changed,120):return False
 state['sourceBefore']={str(p.relative_to(r)):sha(p)for p in inputs};save()
 (o/'native-union-candidate.patch').write_text(subprocess.check_output(['git','diff','--']+changed,cwd=r,text=True))
 if not run('native-source-controls',['corepack','pnpm@10.32.1','exec','vitest','run','--maxWorkers=1','--minWorkers=1','--reporter=json','--outputFile='+str(o/'native-source-controls.json')]+tests,600):return False
 if not run('candidate-producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs',str(out)],300):return False
 base=['cargo','+1.98.1']
 manifest=['--manifest-path',str(out/'transition/Cargo.toml')]
 if not run('candidate-cargo-check',base+['check','--offline','--locked']+manifest+['--lib'],1200):return False
 if not run('candidate-sdk-controls',base+['test','--offline','--locked']+manifest+['-p','proto-ui-gpui-native','--features','test-support,gpui/test-support','--lib','--','--test-threads=1','--nocapture'],1200):return False
 for target in ['ordinary','control_label','style_mapping','a11y_activation','scroll_pause','scroll_reader']:
  if not run('candidate-'+target,base+['test','--offline','--locked']+manifest+['--features','test-support','--test',target,'--','--test-threads=1','--nocapture'],1200):return False
 if not run('candidate-official-label-producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-control-label/produce.mjs',str(label)],300):return False
 if not run('candidate-official-label-consumer',base+['test','--offline','--locked','--manifest-path',str(label/'Cargo.toml'),'--test','control_label','--','--test-threads=1','--nocapture'],1200):return False
 return run('native-diff-check',['git','diff','--check'],30)
save()
try:
 with tempfile.TemporaryDirectory(prefix='ncg75d5-',dir='/var/tmp')as tmp:
  env['TMPDIR']=tmp;ok=body()
 state['state']='passed'if ok else'failed'
except Exception as error:
 state.update(state='failed',exception=repr(error))
finally:
 state.update(sourceAfter={str(p.relative_to(r)):sha(p)for p in inputs},finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
