from pathlib import Path
import os,json,subprocess,tempfile,datetime,hashlib
o=Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a-ops');r=Path(str(o)[:-4]);generated=o/'candidate-generated'
prior=json.loads((o/'candidate-r2-status.json').read_text());assert prior['state']=='failed' and prior['sourceBefore']==prior['sourceAfter']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in prior['sourceBefore'].items():assert sha(r/name)==digest,name
files=[p for p in generated.rglob('*')if p.is_file()and(p.suffix in ['.rs','.toml','.lock']or p.name=='receipt.json')]
snap=lambda:{str(p.relative_to(generated)):sha(p)for p in sorted(files)}
command=['cargo','+1.98.1','test','--offline','--locked','--no-fail-fast','--manifest-path',str(generated/'transition/Cargo.toml'),'--features','test-support','--tests','--','--test-threads=1','--nocapture']
state={'state':'running','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'generatedInputsFrom':'candidate-status.json','sourceAtGeneration':prior['sourceBefore'],'generatedBefore':snap(),'command':command,'note':'Executes the six unchanged original consumer test binaries against the frozen official output. Source edits after this launch cannot change that output.'}
path=o/'candidate-consumers-before-lease-status.json'
def save():path.write_text(json.dumps(state,indent=2))
save()
env=dict(os.environ);env['PATH']='/home/ezra/.cargo/bin:'+env['PATH'];env['CARGO_BUILD_JOBS']='1';env['CARGO_TARGET_DIR']=str(o/'cargo-target');env['CARGO_NET_OFFLINE']='true';env['CI']='true'
try:
 with tempfile.TemporaryDirectory(prefix='ncb75d5-',dir='/var/tmp')as tmp:
  env['TMPDIR']=tmp
  with(o/'candidate-consumers-before-lease.log').open('w')as log:
   try:result=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200);code=result.returncode
   except subprocess.TimeoutExpired:code=124
 state.update(state='passed'if code==0 else'failed',exitCode=code)
except Exception as error:state.update(state='failed',exception=repr(error))
finally:
 state.update(generatedAfter=snap(),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
