# Independent source review: retained ControlLabel physical receipts

Reviewer: /root/sprint5_ready
Reviewed at: 2026-11-23 19:05 UTC
Scope: source peer review only; this is not a GitHub approval and is not a claim that Rust compilation, SDK tests, consumers, browser acceptance, or CI have passed.

## Source binding

Worktree: /tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a

The reviewer read the complete r2 candidate patch (SHA-256 d00e8f3db0a80b16b7235f6bdc5e6821a8c92b4a2f5c78b74914c8efb45c04f5), its candidate status, the r3 borrow delta, and the final source contexts for the request factory, current-pair check, associations, disposal, native view retention, and Semantics. The reviewer then read cached-physical-applied.json, the actual applied import, and both actual source hashes.

| File | Applied SHA-256 |
| --- | --- |
| packages/compiler/src/gpui-native-control-label.ts | 7d1f5620cc3e8c2761fd6a50e0678eb19fee6176480ab1540c6ef2279a753018 |
| packages/compiler/src/gpui-native-a11y.ts | ed7bf3e7c768590b09dfcd118b2d67598cbb4fe0332f3a2fdc43d149f07926d5 |

The frozen pre-candidate hashes are 4d507166c005e3571628fb13a6827052222800c8c871a79bc8f2568dfef8a488 (ControlLabel) and 485fd63ff627f3d724a2fea569a61fda21774aeb7186e03c4fab68fe1d43e943 (a11y).

The applied receipt records one correction beyond reviewed r3: the a11y module explicitly imports the existing pub(crate) control_label_manages_native_view boolean helper. The reviewer independently read that actual import and the resulting a11y hash above. The original r3 a11y hash was 34adb9395c6ae5d42a0e14d7e7e2070b256cfc5916c59243b770cddc607e2c3f.

## Source conclusions

No remaining blocking source issue was found in the reviewed scope.

- The real retained NativeViewLease owns the strong physical receipt. Logical ControlLabel state keeps Weak entries; requests and queued tasks do not extend a removed view's authority.
- Release first makes the receipt non-live. An old epoch's destructor cannot revoke a replacement. With one actual survivor, the implementation restores that survivor's recorded window, hitbox, and bounds without assigning mounted or epoch. Zero surviving occurrences follows the existing detach path; multiple occurrences remain ambiguous.
- Uniqueness counts current-epoch physical occurrences across all windows. A physically present but unresolved or ambiguous participant poisons the whole pair instead of being skipped in favor of another logical participant. A member with no live occurrence can be absent.
- Physical proof is sticky. A logical owner that has supplied real retained receipts cannot fall back to legacy frame fields after all receipts disappear. NativeViewLease also retains a sticky managed flag so a withdrawn empty receipt cannot fall back to a recycled window/hitbox identity on later Drop.
- A retained occurrence only receives a NodeId when Semantics actually has an accessibility role. A roleless target still has real physical lifetime, but it cannot acquire a fabricated AccessKit node from ElementId alone. Role acquisition/removal changes receipt identity and group revision.
- Stable physical identity updates geometry without replacing the receipt. Actual add/drop and replacement advance the group revision; monotonic physical serials and immutable request snapshots reject old actions across unique-to-ambiguous-to-unique and same-node ABA changes.
- Cross-frame pairing requires actual unique physical proof on both participants. If either participant is still using the legacy protocol, the original common nonzero layout-frame requirement remains.
- Native wake scheduling does not synchronously borrow App or Window from element-state Drop. It uses weak group, member, and physical-context references, rechecks the physical context before accessing the window and before each member drive, and rechecks association/window/readiness/dirty state. No persistent queue bit suppresses later group changes, and no frame polling was introduced.
- The existing enabled/live Label factory boundary remains Some even when a pair is absent. The contained Option<Request> is captured once; an empty snapshot never lazily binds a later pair. The actual AccessKit Click availability still requires the current unique pair.
- The r3 temporary-lifetime change only binds the borrowed epoch to a local before returning the test tuple. It changes neither product behavior nor assertions.

## Review findings addressed

The independent review identified and communicated these boundaries while the candidate was being assembled:

1. An ambiguous physical participant plus another unique same-kind participant must refuse the complete pair.
2. A managed state that later holds no receipt must not regain legacy Drop authority through a reused hitbox.
3. Actual Semantics role presence is required before assigning a physical NodeId. This issue was also independently identified by root.
4. The sibling module must use a narrow visible boolean helper instead of accessing the private ControlLabel kind field.
5. The final a11y module must import that helper. The applied import and source hash above close this compile-time omission.

The original intermediate candidate files and reported failures were preserved; this review does not reclassify them as successful executions.

## Proposed regression coverage read in the diff

The candidate retains the original 58 SDK tests and adds three tests, for a proposed total of 61. It also extends an existing Drop control without deleting its original assertions. These are source assertions at review time, not an execution result.

The added controls cover permanently inactive bridges created under missing, duplicate, or foreign-window pairing; real cached A to A+B to A retention and surviving geometry/epoch; one ambiguous Label plus another unique Label; actual subtree removal and same-node restoration; actual inner-role None to Some to None to Some; old-bridge non-revival; derived naming and Click availability; and managed-empty Drop with a colliding hitbox.

The pre-candidate SDK receipt remains 57 passed / 1 failed, with the same-path cached target case still failing. Root has started the single actual SDK worker for the applied candidate; no result from that worker is asserted here.

## Validation still required

Use the applied source hashes above for the official producer, generated-source stability checks, actual Rust/SDK and consumer execution, and final combined acceptance. Record any real failure and fix it without removing the original assertions or weakening the physical authority requirements. This review does not justify marking the S5 browser PR Ready while its new combined browser acceptance remains unexecuted or failing.

## Test-fixture successor review

Reviewed at: 2026-11-23 19:17:37 UTC.

The subsequent ControlLabel source SHA-256 is 8d6577abb34c9b88447e16b43115f282b15d2157936cc8ff1c7a0221af7294af; a11y remains ed7bf3e7c768590b09dfcd118b2d67598cbb4fe0332f3a2fdc43d149f07926d5. An independent exact-text comparison against reviewed r3 confirmed exactly two test assignments changing the positive inner role from GenericContainer to Button, with no product code or assertion change. The original full review above remains bound to its original source hashes; this section extends its source conclusion to the test-only successor.

The reviewer read the actual cached-physical-trial-r4/sdk-controls.log: 60 passed, 1 failed, 0 ignored. The unique failure stopped in pinned GPUI Div::role before the new role test's positive/ABA phase. The pinned implementation at https://github.com/zed-industries/zed/blob/62e5991dd0f0c8a3af8d5e7e9c4652490d468db8/crates/gpui/src/elements/div.rs explicitly rejects GenericContainer and otherwise assigns override_role. Button supplies a legal actual inner role while accessible remains false. The None/Some/None/Some sequence, same-path node restoration, exact counts, naming/action assertions and old immutable-bridge refusal all remain unchanged.

No blocking source issue was found in this fixture correction. The original 60/61 execution is retained in native-role-fixture-correction.json and its raw logs. This addendum is source review only; the full-r5 SDK/source/consumer results belong to their own actual terminal receipts and are not asserted by this addendum.
