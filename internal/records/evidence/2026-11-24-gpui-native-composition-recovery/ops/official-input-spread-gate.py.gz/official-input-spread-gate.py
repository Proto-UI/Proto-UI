from pathlib import Path
import os,subprocess,hashlib,json,datetime,tempfile
r=Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a');o=Path(str(r)+'-ops');w=o/'official-input-spread';w.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=list((r/'packages/compiler/src').glob('*.ts'))+list((r/'packages/compiler/test/fixtures/gpui-control-label').rglob('*'))
files=[p for p in files if p.is_file()]
snapshot=lambda:{str(p.relative_to(r)):sha(p) for p in files}
generated=lambda:{str(p.relative_to(w)):sha(p)for p in(w/'generated').rglob('*')if p.is_file()and(p.suffix in ['.rs','.toml']or p.name=='receipt.json')}
state={'state':'running','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceBefore':snapshot(),'priorFailure':'../immutable-consumers/status.json: unchanged official Input projectHandle rejected PUI2002 at lines 273-287','commands':[]}
def save():(w/'status.json').write_text(json.dumps(state,indent=2))
env=dict(os.environ);env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:/home/ezra/.cargo/bin:'+env['PATH'];env['CI']='true';env['CARGO_BUILD_JOBS']='1';env['CARGO_TARGET_DIR']='/tank/shared/projects/proto-ui-agent/s5-adapter-readonly-target75d5';env['CARGO_NET_OFFLINE']='true';env['CARGO_PROFILE_DEV_DEBUG']='0';env['CARGO_PROFILE_TEST_DEBUG']='0'
def run(name,args,limit):
 entry={'name':name,'command':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};state['commands'].append(entry);save()
 with(w/(name+'.log')).open('w')as log:
  try:code=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=limit).returncode
  except subprocess.TimeoutExpired:code=124
 entry.update(exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();return code==0
save()
try:
 with tempfile.TemporaryDirectory(prefix='ois75d5-',dir='/var/tmp')as tmp:
  env['TMPDIR']=tmp
  ok=run('producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-control-label/produce.mjs',str(w/'generated')],300)
  state['sourceAtGeneration']=snapshot();assert state['sourceAtGeneration']==state['sourceBefore'];state['generatedBefore']=generated();save()
  if ok:ok=run('metadata',['cargo','+1.98.1','metadata','--offline','--all-features','--format-version','1','--manifest-path',str(w/'generated/Cargo.toml')],300)
  if ok:ok=run('consumer',['cargo','+1.98.1','test','--offline','--locked','--manifest-path',str(w/'generated/Cargo.toml'),'--test','control_label','--','--test-threads=1','--nocapture'],1200)
  state['state']='passed'if ok else'failed'
except Exception as error:state.update(state='failed',exception=repr(error))
finally:state.update(sourceAfter=snapshot(),generatedAfter=generated(),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
