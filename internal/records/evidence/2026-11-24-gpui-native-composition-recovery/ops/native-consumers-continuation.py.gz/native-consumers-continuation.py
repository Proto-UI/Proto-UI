from pathlib import Path
import os,json,subprocess,tempfile,datetime,hashlib
r=Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a');o=Path(str(r)+'-ops');w=o/'immutable-consumers'
prior=json.loads((w/'status.json').read_text());assert prior['state']=='failed'and prior['sourceBefore']==prior['sourceAfter']
assert prior['commands'][-1]['name']=='official-label-producer'and prior['commands'][-1]['exitCode']==1
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in prior['sourceBefore'].items():assert sha(r/name)==digest,name
env=dict(os.environ);env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:/home/ezra/.cargo/bin:'+env['PATH'];env['CARGO_BUILD_JOBS']='1';env['CARGO_TARGET_DIR']='/tank/shared/projects/proto-ui-agent/s5-adapter-readonly-target75d5';env['CARGO_NET_OFFLINE']='true';env['CARGO_PROFILE_DEV_DEBUG']='0';env['CARGO_PROFILE_TEST_DEBUG']='0';env['CI']='true'
files=[p for stem in ['ordinary','numeric']for p in (w/stem).rglob('*')if p.is_file()and(p.suffix in ['.rs','.toml']or p.name.endswith('receipt.json'))]
snap=lambda:{str(p.relative_to(w)):sha(p)for p in files}
state={'state':'running','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceAtGeneration':prior['sourceBefore'],'generatedBefore':snap(),'blockedSteps':{'sdk':'../immutable-action-trial/status.json: 57 passed / 1 cached-frame failure','officialLabelProducer':'status.json: PUI2002 in current official BaseInput projectHandle spread at lines 273-287; zero official Label suite tests executed'},'commands':[]}
def save():(w/'continuation-status.json').write_text(json.dumps(state,indent=2))
def run(name,args,limit=1200):
 item={'name':name,'command':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};state['commands'].append(item);save()
 with(w/(name+'.log')).open('w')as log:
  try:code=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=limit).returncode
  except subprocess.TimeoutExpired:code=124
 item.update(exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();return code==0
base=['cargo','+1.98.1']
save()
try:
 with tempfile.TemporaryDirectory(prefix='ncc75d5-',dir='/var/tmp')as tmp:
  env['TMPDIR']=tmp
  assert run('remaining-numeric-metadata',base+['metadata','--offline','--all-features','--format-version','1','--manifest-path',str(w/'numeric/Cargo.toml')],300)
  manifest=['--manifest-path',str(w/'ordinary/transition/Cargo.toml')]
  assert run('remaining-ordinary-graph',['node','scripts/gpui/check-cargo-graph.mjs']+manifest+['--git','https://github.com/zed-industries/zed','--rev','62e5991dd0f0c8a3af8d5e7e9c4652490d468db8','--toolchain','1.98.1','--output',str(w/'ordinary-graph.json')],300)
  results=[]
  results.append(run('remaining-default-check',base+['check','--offline','--locked']+manifest+['--lib']))
  results.append(run('remaining-six-native-consumers',base+['test','--offline','--locked','--no-fail-fast']+manifest+['--features','test-support','--tests','--','--test-threads=1','--nocapture']))
  results.append(run('remaining-numeric-consumer',base+['test','--offline','--locked','--manifest-path',str(w/'numeric/Cargo.toml'),'--test','a11y_value','--','--test-threads=1','--nocapture']))
 state.update(state='completed',selectedCommandsPassed=all(results))
except Exception as error:state.update(state='failed',exception=repr(error))
finally:
 state.update(generatedAfter=snap(),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
