import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const repo = process.env.S2_REPO;
const output = process.env.PUI_EVIDENCE_DIR;
assert(repo && output);
await mkdir(output, { recursive: true });
const require = createRequire(path.join(repo, 'package.json'));
const { build } = require('esbuild');
const { chromium } = createRequire(path.join(repo, 'apps/www/package.json'))('playwright-core');
const { collectProtoStyleTokensFromFiles } = await import(
  pathToFileURL(path.join(repo, 'packages/cli/src/services/prototype-style-tokens.ts'))
);
const { renderProtoStyleTokenCss } = await import(
  pathToFileURL(path.join(repo, 'packages/cli/src/services/proto-style-css.ts'))
);
const { renderThemeCss } = await import(
  pathToFileURL(path.join(repo, 'packages/prototypes/bootstrap-2-3-2/src/theme.ts'))
);
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const git = (...args) => execFileSync('git', args, { cwd: repo, encoding: 'utf8' }).trim();
const fixturePath = path.join(repo, 'scripts/analysis/fixtures/bootstrap-collapse-browser.ts');
const fixture = await readFile(fixturePath, 'utf8');
// Diagnostic access to this fixture's actual owned instance and API. No mock
// Runtime, synthetic dimensions, modified clocks or replacement State values.
const calibration = `
export function calibratePublicSnapshotReads() {
  if (!api) throw new Error('Actual Demo API must be mounted.');
  const owned = api.getPublicInstance?.('content') as any;
  if (!owned) throw new Error('Actual Content owner is required.');
  const original = owned.update;
  const descriptor = Object.getOwnPropertyDescriptor(owned, 'update');
  const instrumented = typeof original === 'function';
  let updates = 0;
  if (instrumented) {
    if (descriptor?.get || descriptor?.set) throw new Error('Accessor update is not instrumented.');
    Object.defineProperty(owned, 'update', {
      ...(descriptor ?? { configurable: true, writable: true }),
      value: function (...args: unknown[]) {
        updates++;
        return Reflect.apply(original, this, args);
      },
    });
  }
  try {
    const direct = Array.from({ length: 5 }, () => snapshot());
    const afterDirect = updates;
    const legacy = Array.from({ length: 5 }, () => ({
      hidden: api!.call('content', 'hidden.get'),
      open: api!.call('content', 'open.get'),
      phase: api!.call('content', 'transitionState.get'),
    }));
    return {
      updateMethodPresent: instrumented,
      directUpdateCalls: instrumented ? afterDirect : null,
      legacyUpdateCalls: instrumented ? updates - afterDirect : null,
      direct,
      legacy,
      ownerSame: api!.getPublicInstance?.('content') === owned,
      bodySame: find('body') === formerBody,
      final: snapshot(),
    };
  } finally {
    if (instrumented) {
      if (descriptor) Object.defineProperty(owned, 'update', descriptor);
      else delete owned.update;
      if (owned.update !== original) throw new Error('Original update method was not restored.');
    }
  }
}
`;
const bundle = await build({
  absWorkingDir: repo,
  stdin: {
    contents: fixture + calibration,
    resolveDir: path.dirname(fixturePath),
    sourcefile: 'bootstrap-read-calibration-fixture.ts',
    loader: 'ts',
  },
  write: false,
  bundle: true,
  format: 'iife',
  globalName: 'BootstrapCollapse',
  platform: 'browser',
  target: 'es2022',
  tsconfig: path.join(repo, 'tsconfig.json'),
  metafile: true,
  define: { 'process.env.NODE_ENV': '"production"' },
  plugins: [{
    name: 'fixture-runtime',
    setup(build) {
      build.onResolve({ filter: /^virtual:proto-ui\/runtime-retry-urls$/ }, () => ({
        path: 'retry-urls', namespace: 'fixture-runtime',
      }));
      build.onLoad({ filter: /.*/, namespace: 'fixture-runtime' }, () => ({
        contents: 'export default {};', loader: 'js',
      }));
    },
  }],
});
const script = bundle.outputFiles[0].text;
const inputs = await Promise.all(Object.keys(bundle.metafile.inputs)
  .filter((file) => !file.includes('node_modules') && !file.startsWith('fixture-runtime:') &&
    file !== 'scripts/analysis/fixtures/bootstrap-read-calibration-fixture.ts' &&
    file !== 'bootstrap-read-calibration-fixture.ts')
  .sort()
  .map(async (file) => ({ path: file, sha256: sha(await readFile(path.resolve(repo, file))) })));
const styleFiles = inputs.map((row) => row.path)
  .filter((file) => file.startsWith('packages/prototypes/') && /\.[cm]?tsx?$/.test(file));
const tokens = await collectProtoStyleTokensFromFiles(styleFiles.map((file) => path.join(repo, file)));
const css = renderProtoStyleTokenCss(tokens);
const report = {
  kind: 'bootstrap-public-snapshot-native-calibration',
  started: new Date().toISOString(),
  source: {
    head: git('rev-parse', 'HEAD'), dirty: git('status', '--porcelain'),
    fixtureSha256: sha(fixture), calibrationSha256: sha(calibration),
    bundleSha256: sha(script), cssSha256: sha(css), inputs,
  },
  boundary: 'Actual four-Web authored consumers. Temporary update forwarding counts calls to the current public instance without changing their implementation. Direct observations and legacy DemoRuntimeApi.call read identical public getters. This is not a performance-budget, physical-input or AT result.',
  cases: [], errors: [],
};
await writeFile(path.join(output, 'consumer.js'), script);
await writeFile(path.join(output, 'consumer.css'), css);
await writeFile(path.join(output, 'calibration-fixture.ts'), fixture + calibration);
await writeFile(path.join(output, 'driver.mjs'), await readFile(new URL(import.meta.url)));
const browser = await chromium.launch({
  executablePath: process.env.CHROME_PATH, headless: true, chromiumSandbox: true,
  args: ['--disable-dev-shm-usage'],
});
report.browser = browser.version();
const page = await browser.newPage({ viewport: { width: 960, height: 720 }, colorScheme: 'light' });
page.on('pageerror', (error) => report.errors.push(error.message));
try {
  await page.setContent('<!doctype html><html data-theme="light"><head><meta charset="utf-8"></head><body><main><div id="fixture"></div></main></body></html>');
  await page.addStyleTag({ content: renderThemeCss() + '\n' + css + '\n*,::before,::after{box-sizing:border-box}body{font-family:Arial,sans-serif}main{width:640px;margin:40px auto}.collapse-copy>div{min-height:20px}' });
  await page.addScriptTag({ content: script });
  for (const runtime of ['wc', 'react', 'vue', 'vue2']) {
    const row = { runtime, status: 'running' };
    report.cases.push(row);
    try {
      await page.evaluate((host) => BootstrapCollapse.mount(host, 'collapsible', {
        controlled: true, initialOpen: true, keepMounted: true,
      }), runtime);
      await page.waitForFunction(() => BootstrapCollapse.snapshot().phase === 'entered', null, { timeout: 1000 });
      row.observation = await page.evaluate(() => BootstrapCollapse.calibratePublicSnapshotReads());
      const result = row.observation;
      if (runtime !== 'wc') {
        assert.equal(result.updateMethodPresent, true);
        assert.equal(result.legacyUpdateCalls, 15);
        assert.equal(result.directUpdateCalls, 0);
      } else if (result.updateMethodPresent) {
        assert.equal(result.legacyUpdateCalls, 0);
        assert.equal(result.directUpdateCalls, 0);
      }
      assert.equal(result.ownerSame, true);
      assert.equal(result.bodySame, true);
      for (const sample of result.direct) {
        assert.deepEqual({ hidden: sample.hidden, open: sample.open, phase: sample.phase }, {
          hidden: false, open: true, phase: 'entered',
        });
        assert(sample.height > 110 && sample.bodyVisible && sample.ownerSame);
      }
      assert.deepEqual(result.legacy, result.direct.map(({ hidden, open, phase }) => ({ hidden, open, phase })));
      assert.equal(result.final.hidden, false);
      assert.equal(result.final.open, true);
      assert.equal(result.final.phase, 'entered');
      assert.equal(result.final.ownerSame, true);
      row.status = 'passed';
    } catch (error) {
      row.status = 'failed'; row.error = String(error.stack ?? error);
    } finally {
      row.cleanup = await page.evaluate(() => BootstrapCollapse.dispose());
      if (row.cleanup.children !== 0) {
        row.status = 'failed'; row.cleanupError = 'Authored consumer children remain.';
      }
    }
    await writeFile(path.join(output, 'report.json'), JSON.stringify(report, null, 2));
    console.log(JSON.stringify({ runtime, status: row.status, observation: row.observation && {
      directUpdateCalls: row.observation.directUpdateCalls,
      legacyUpdateCalls: row.observation.legacyUpdateCalls,
      updateMethodPresent: row.observation.updateMethodPresent,
    }, error: row.error }));
  }
} finally {
  await browser.close();
  report.ended = new Date().toISOString();
  report.source.finalHead = git('rev-parse', 'HEAD');
  report.source.finalFixtureSha256 = sha(await readFile(fixturePath));
  report.summary = {
    passed: report.cases.filter((row) => row.status === 'passed').length,
    failed: report.cases.filter((row) => row.status !== 'passed').length,
    pageErrors: report.errors.length,
  };
  await writeFile(path.join(output, 'report.json'), JSON.stringify(report, null, 2));
}
assert.equal(report.source.fixtureSha256, report.source.finalFixtureSha256);
assert.equal(report.summary.passed, 4);
assert.equal(report.summary.failed, 0);
assert.equal(report.summary.pageErrors, 0);
