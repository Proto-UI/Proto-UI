from pathlib import Path
import os,json,subprocess,hashlib
r=Path("/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202");p=r/"Proto-UI-publisher";out=r/"evidence/bootstrap-four-web-pure-read-01"
def run(a):return subprocess.check_output(a,cwd=p,text=True).strip()
assert run(["git","rev-parse","HEAD"])=="3d64911f980957ab78bfb616cdd5b523b5f4482c"
assert run(["git","diff","--name-only"])=="scripts/analysis/fixtures/bootstrap-collapse-browser.ts"
assert hashlib.sha256((p/"scripts/analysis/fixtures/bootstrap-collapse-browser.ts").read_bytes()).hexdigest()=="f061d42f58be9c0118cbf8c3e145d7deb08af6376ca325e2a0caeb1e71f6dd02"
assert json.loads((r/"evidence/bootstrap-read-calibration-02/result.json").read_text())["exitCode"]==0
paths=["scripts/analysis/bootstrap-collapse-browser.mjs","scripts/analysis/bootstrap-collapse-endpoint-oracle.mjs","scripts/analysis/fixtures/bootstrap-collapse-browser.ts","packages/cli/src/services/hook-source-summary.ts","packages/cli/src/services/lowered-hook-coverage.ts","packages/cli/src/services/prototype-style-tokens.ts","packages/cli/src/services/proto-style-css.ts"]
before={x:hashlib.sha256((p/x).read_bytes()).hexdigest() for x in paths};(out/"source-before.json").write_text(json.dumps(before,indent=2)+"\n")
assert before["scripts/analysis/bootstrap-collapse-browser.mjs"]=="97a827748271666c4ab84f91a3672838581c9a5a763acb0fcbe4adbecffb45a6"
assert before["scripts/analysis/bootstrap-collapse-endpoint-oracle.mjs"]=="0984ee83fe85b0006609e8e8d929e85c493760cf0d7c3c496fa46f5eada3ae75"
result=subprocess.run([os.environ["S2_NODE"],"--import","tsx","scripts/analysis/bootstrap-collapse-browser.mjs"],cwd=p)
after={x:hashlib.sha256((p/x).read_bytes()).hexdigest() for x in paths}
report=json.loads((r/"results/bootstrap-four-web-pure-read-01/report.json").read_text())
stable=all(hashlib.sha256((p/x["path"]).read_bytes()).hexdigest()==x["sha256"] for x in report["source"]["inputs"])
value={"exit":result.returncode,"summary":report.get("summary"),"guardedSourcesStable":before==after,"allBundleInputsStable":stable,"head":run(["git","rev-parse","HEAD"]),"dirty":run(["git","status","--porcelain"])}
(out/"verification.json").write_text(json.dumps(value,indent=2)+"\n");print(json.dumps(value));assert result.returncode==0 and before==after and stable
