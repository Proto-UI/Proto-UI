from pathlib import Path
import hashlib,json,tarfile,io,datetime
r=Path('/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202')
out=r/'transfer/s2-compiler-convergence-6b-01'
out.mkdir(parents=True,exist_ok=False)
files=set()
patterns=['compiler-transition-nonconvergence-6b-*','compiler-convergence-*','compiler-payload-free-*','install-compiler-convergence-6b-*','full-compiler-general-0-6b6462','full-compiler-general-1-6b6462']
for top in ['evidence','results']:
 for pattern in patterns:
  for p in (r/top).glob(pattern):
   if p.is_file():files.add(p)
   elif p.is_dir():files.update(f for f in p.rglob('*') if f.is_file())
for name in ['compiler-convergence-candidate-01','compiler-convergence-source-variants','compiler-convergence-diagnostic','compiler-transition-nonconvergence-6b-01','compiler-transition-nonconvergence-6b-02','compiler-transition-nonconvergence-6b-03']:
 p=r/name
 if p.exists():files.update(f for f in p.rglob('*') if f.is_file())
for pattern in patterns:
 files.update((r/'specs').glob(pattern+'.json'))
for name in ['compiler-final-preparation-6b6462/controlled-stop.json','run_compiler_batches.py','remote_jobs.py','package_compiler_convergence_6b.py']:
 p=r/name
 if p.is_file():files.add(p)
rows=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)]
manifest={'kind':'compiler-convergence-raw-evidence','baseHead':'6b6462b526094cee9d3fa385332162c384624e3e','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fileCount':len(rows),'files':rows,'scope':'Original stopped complete queues, all diagnostic attempts including setup failures and disproven variants, exact reconstituted variant bytes checked against original source hashes, final three-file candidate, independent review and 31 complete passing regression/strict/consumer assertions. This archive does not establish full Compiler or library/profile completion.'}
raw=(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n').encode();(out/'manifest.json').write_bytes(raw)
archive=out/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
 info=tarfile.TarInfo('manifest.json');info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
checked=[]
with tarfile.open(archive,'r:gz') as tar:
 members={m.name:m for m in tar.getmembers() if m.isfile()}
 assert len(members)==len(rows)+1
 assert json.load(tar.extractfile('manifest.json'))==manifest
 for row in rows:
  content=tar.extractfile(row['path']).read();assert len(content)==row['bytes'];assert hashlib.sha256(content).hexdigest()==row['sha256'];checked.append(row['path'])
receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'manifestSha256':hashlib.sha256(raw).hexdigest(),'verifiedFiles':len(checked),'readback':'Every archived payload and manifest was read back and matched by path, byte length and SHA-256.'}
(out/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
