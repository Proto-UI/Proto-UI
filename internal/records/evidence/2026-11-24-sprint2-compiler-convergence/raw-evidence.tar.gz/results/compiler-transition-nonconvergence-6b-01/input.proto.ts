import {definePrototype} from '@proto.ui/core';
import {asTransition} from './transition/as-transition.proto';
export default definePrototype({name:'strict-authored-consumer',setup(def){
  const handle=asTransition(); handle.configure({enterDuration:10,leaveDuration:7});
  return renderer=>renderer.el('section',[handle.transitionState.get(),renderer.slot()]);
}});