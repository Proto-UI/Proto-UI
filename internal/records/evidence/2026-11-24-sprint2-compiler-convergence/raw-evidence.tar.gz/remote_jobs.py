#!/usr/bin/env python3
from pathlib import Path
import sys,os,json,subprocess,datetime
ROOT=Path('/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202')
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
 specpath=Path(sys.argv[-1]); spec=json.loads(specpath.read_text())
 out=ROOT/'evidence'/spec['id'];out.mkdir(parents=True,exist_ok=True)
 if '--worker' not in sys.argv:
  marker=out/'start.json'
  try: fd=os.open(marker,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o644)
  except FileExistsError:
   print(marker.read_text());return
  with (out/'worker.log').open('ab') as log:
   p=subprocess.Popen([sys.executable,__file__,'--worker',str(specpath)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  data={'pid':p.pid,'started':now(),'spec':str(specpath)}
  os.write(fd,json.dumps(data).encode());os.close(fd);print(json.dumps(data));return
 env=os.environ.copy();env.update(spec.get('env',{}))
 repo=Path(spec['cwd'])
 def git(*args):
  r=subprocess.run(['git',*args],cwd=repo,text=True,capture_output=True);return r.stdout.strip() if r.returncode==0 else r.stderr.strip()
 data={'id':spec['id'],'command':spec['command'],'cwd':str(repo),'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'dirty':git('status','--porcelain') if spec.get('captureWorktree',True) else None,'worktreeCheck':'launcher' if spec.get('captureWorktree',True) else 'delegated-to-workload','started':now(),'env':spec.get('env',{})}
 if spec.get('expectedHead') and data['head']!=spec['expectedHead']:
  data.update(exitCode=None,error='source-head-mismatch',ended=now());(out/'result.json').write_text(json.dumps(data,indent=2));return
 try:
  with (out/'stdout.log').open('wb') as log:
   p=subprocess.run(spec['command'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
  data['exitCode']=p.returncode
 except BaseException as e:
  data['exitCode']=None;data['error']=repr(e)
 data.update(ended=now(),finalHead=git('rev-parse','HEAD'),finalDirty=git('status','--porcelain') if spec.get('captureWorktree',True) else None)
 (out/'result.json').write_text(json.dumps(data,indent=2))
if __name__=='__main__':main()
