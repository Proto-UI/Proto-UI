import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {Worker} from 'node:worker_threads';
import path from 'node:path';
const output=process.argv[2],root=process.cwd();mkdirSync(output,{recursive:false});
const hash=x=>createHash('sha256').update(x).digest('hex');
const paths=['packages/compiler/src/callable-effects.ts','packages/compiler/src/parser.ts','packages/compiler/src/flow-proof.ts'];
const origin={head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),dirty:execFileSync('git',['status','--porcelain'],{encoding:'utf8'}),inputs:paths.map(file=>({file,sha256:hash(readFileSync(path.join(root,file)))})),purpose:'Independent bounded diagnostic; instrumented worklist stop is not product acceptance.'};
writeFileSync(path.join(output,'origin.json'),JSON.stringify(origin,null,2));
const watchdog=new Worker(`const {workerData}=require('node:worker_threads');const {writeFileSync}=require('node:fs');const path=require('node:path');setTimeout(()=>{writeFileSync(path.join(workerData,'watchdog.json'),JSON.stringify({pid:process.pid,at:new Date().toISOString(),reason:'25 second independent diagnostic watchdog'}));process.kill(process.pid,'SIGTERM');},25000);`,{eval:true,workerData:output});
try{
 const {compilePrototype}=await import(path.join(root,'packages/compiler/src/compile.ts'));
 const source=readFileSync('/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202/results/compiler-transition-nonconvergence-6b-02/input.proto.ts','utf8');
 const files={};for(const name of ['as-transition.proto.ts','machine.ts','types.ts'])files['transition/'+name]=readFileSync(path.join(root,'packages/prototypes/base/src/transition',name),'utf8');
 const start=performance.now();const result=compilePrototype(source,{profile:'react-runtime-v1',fileName:'entry.proto.ts',files});
 writeFileSync(path.join(output,'result.json'),JSON.stringify({ok:result.ok,diagnostics:result.ok?[]:result.diagnostics,elapsedMs:performance.now()-start,sourceSha256:hash(source),fileSha256:Object.fromEntries(Object.entries(files).map(([k,v])=>[k,hash(v)]))},null,2));if(!result.ok)process.exitCode=1;
}catch(error){writeFileSync(path.join(output,'error.json'),JSON.stringify({error:String(error.stack??error)},null,2));process.exitCode=1;}finally{await watchdog.terminate();}
