import {parsePrototype,validateIR} from '/tank/shared/projects/proto-ui-agent/s2-completion-20261124-b202/Proto-UI-compiler-convergence/packages/compiler/src/index.ts';
const cases={
 omitted:"run.expose.emit('done')",
 literal:"run.expose.emit('done',undefined)",
 hiddenUndefined:"const payload:()=>void=()=>({bad:undefined});run.expose.emit('done',payload())",
 hiddenCallable:"const payload:()=>void=()=>({bad:()=>1});run.expose.emit('done',payload())",
 effect:"const payload:()=>void=()=>{def.state.bool('wrong',true)};run.expose.emit('done',payload())"
};
const rows=[];for(const [name,body]of Object.entries(cases)){const source=`import {definePrototype}from '@proto.ui/core';export default definePrototype({name:'void-event',setup(def){def.expose.event('done');def.event.on('press.commit',run=>{${body}});}});`;const parsed=parsePrototype(source);rows.push({name,source,parsed:parsed.ok?{ok:true}:parsed,cold:parsed.ok?validateIR(JSON.parse(JSON.stringify(parsed.value))):undefined});}
console.log(JSON.stringify(rows,null,2));
