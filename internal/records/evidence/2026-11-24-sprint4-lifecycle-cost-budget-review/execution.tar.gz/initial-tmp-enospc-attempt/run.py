import os,json,subprocess,hashlib,traceback,datetime,difflib
from pathlib import Path
E=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/evidence/integration-20261123-0320')
R=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
D=Path(__file__).resolve().parent
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def save():
 p=D/'status.tmp';p.write_text(json.dumps(S,ensure_ascii=False,indent=2)+'\n');os.replace(p,D/'status.json')
env=dict(os.environ)
env['PATH']=str(R/'tools/node-v24.22.3-linux-x64/bin')+':'+env.get('PATH','')
env['COREPACK_HOME']=str(R/'corepack-cache')
env['ASTRO_TELEMETRY_DISABLED']='1'
env['GIT_OPTIONAL_LOCKS']='0';env['GIT_NO_LAZY_FETCH']='1'
def run(name,argv,timeout=120,allowed=(0,)):
 S['stage']=name;save();beg=now()
 with (D/(name+'.stdout')).open('wb') as out,(D/(name+'.stderr')).open('wb') as err:
  p=subprocess.Popen(argv,cwd=C,env=env,stdout=out,stderr=err);S['child']={'pid':p.pid,'argv':argv};save();expired=False
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   expired=True;p.terminate()
   try:code=p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();code=p.wait()
 S.pop('child',None);S['steps'].append({'name':name,'argv':argv,'started':beg,'finished':now(),'exit':code,'timedOut':expired});save()
 assert not expired and code in allowed,name+' exit='+str(code)
 return (D/(name+'.stdout')).read_text()
def failure(e):
 S['status']='failed';S['error']=repr(e);S['traceback']=traceback.format_exc();S['finished']=now();save()
def source(rel): 
 b=(C/rel).read_bytes();return {'sha256':sha(b),'bytes':len(b)}


import tarfile,time,re
C=Path('/var/tmp/proto-ui-s4-scene-c18-20261123-2141')
BASE='a1246a78c6bb98beafd619e1e25342bead02635b'
BRANCH='work/sprint4-completion-20261124-1494'
REL='scripts/analysis/package-budgets.mjs'
S={'status':'running','started':now(),'pid':os.getpid(),'checkout':str(C),'baseHead':BASE,'steps':[],'scope':'Three reviewed numeric literals and source-bound records only. Product/test source unchanged.'}
save()
env.update({'GIT_AUTHOR_NAME':'Codex','GIT_AUTHOR_EMAIL':'codex@openai.com','GIT_COMMITTER_NAME':'Codex','GIT_COMMITTER_EMAIL':'codex@openai.com'})
def pages(raw):
 dec=json.JSONDecoder();out=[];i=0
 while i<len(raw):
  while i<len(raw) and raw[i].isspace():i+=1
  if i==len(raw):break
  v,n=dec.raw_decode(raw,i);out.append(v);i=n
 return out
def report_at(folder):
 info=json.loads((folder/'summary.json').read_text())
 rows=[r for r in info['selected'] if r['path'].endswith('report.json')]
 assert len(rows)==1
 r=rows[0];p=Path(r['absolute']);b=p.read_bytes()
 assert p.resolve().is_relative_to((folder/'selected').resolve()) and len(b)==r['bytes'] and sha(b)==r['sha256']
 return p,b,json.loads(b),info
try:
 assert str(C).startswith('/var/tmp/proto-ui-') and C.is_dir()
 assert run('head-before',['git','rev-parse','HEAD']).strip()==BASE
 assert not run('status-before',['git','status','--porcelain','--untracked-files=normal']).strip()
 assert not run('index-before',['git','diff','--cached','--name-only']).strip()
 pr=json.loads(run('public-before',['gh','pr','view','1754','--repo','Proto-UI/Proto-UI','--json','headRefOid,headRefName,isDraft,reviewDecision,url']))
 assert pr['headRefOid']==BASE and pr['headRefName']==BRANCH and pr['isDraft'] is True
 S['publicBefore']=pr
 perms=json.loads(run('repository-permission',['gh','api','repos/Proto-UI/Proto-UI']))['permissions']
 assert perms.get('push') is True
 S['repositoryPermission']={'push':perms['push']}
 b=(C/REL).read_bytes();assert sha(b)=='2b5cc46351f2243705a650a4e81a252b4630919aa9d1bfd9aaa5a915ca2b8e0b'
 S['sourceBefore']=source(REL)
 oldroot=E/'current-artifact-batch-20261123-2114/s4-budget-9fff'
 newroot=E/'current-artifact-batch-20261123-2307/s4-budget-a124'
 op,ob,old,osi=report_at(oldroot);np,nb,new,nsi=report_at(newroot)
 assert old['source']['head']=='9fff88cf23d4e55375979bc5c68c033e3deaed38' and new['source']['head']==BASE
 assert sha(nb)=='832993941ceed640d7503505612fb460e023cfe77dbc8ac85813764da0783397' and new['exitCode']==1
 assert old['environment']==new['environment'] and old['measurement']==new['measurement']
 assert len(old['results'])==len(new['results'])==9 and len(old['diagnostics'])==len(new['diagnostics'])==2
 compare=E/'current-s4-a124-cost-review-01/comparison.json'
 assert sha(compare.read_bytes())=='63ecbab7bf6e4be5fd3c224e6e7f488a3b25b0ca72290f98754d19338f5954d6'
 visual=E/'current-artifact-batch-20261123-2307/s4-shader-a124/independent-review.json'
 assert sha(visual.read_bytes())=='22ab05b1223d4db08b9b4e30dfca9534c56402f4f95e3cb6fbff331fb6d9e456'
 review=D/'independent-numeric-review.md';assert review.is_file()
 proj={'schema':'proto-ui-budget-numeric-review/v1','comparisonSource':old['source'],'candidateSource':new['source'],'environment':new['environment'],'measurement':new['measurement'],'results':[],'diagnostics':[]}
 for field in ['results','diagnostics']:
  for previous,current in zip(old[field],new[field]):
   assert previous['name']==current['name']
   keys=('name','entry','budget','minifiedBytes','gzipBytes','minifiedSha256','pass','overBudgetBytes')
   row={'before':{k:previous.get(k) for k in keys},'candidate':{k:current.get(k) for k in keys}}
   for side,v in [('before',previous),('candidate',current)]:
    cl=v.get('closure') or {};row[side]['closure']={k:cl.get(k) for k in ('inputCount','retainedInputCount','fingerprintSha256','attributionUnit')}
   proj[field].append(row)
 (D/'measurement-projection.json').write_text(json.dumps(proj,ensure_ascii=False,indent=2)+'\n')
 edits=[
 ("['adapter-react root', 'packages/adapters/react/src/index.ts', 172_800]","['adapter-react root', 'packages/adapters/react/src/index.ts', 172_900]"),
 ("['adapter-vue root', 'packages/adapters/vue/src/index.ts', 171_600]","['adapter-vue root', 'packages/adapters/vue/src/index.ts', 171_700]"),
 ("['adapter-web-component root', 'packages/adapters/web-component/src/index.ts', 207_400]","['adapter-web-component root', 'packages/adapters/web-component/src/index.ts', 207_500]")]
 text=b.decode();out=text
 for before,after in edits:
  assert out.count(before)==1 and after not in out
  out=out.replace(before,after,1)
 restored=out
 for before,after in edits:restored=restored.replace(after,before,1)
 assert restored==text
 (D/'before-package-budgets.mjs').write_bytes(b)
 (C/REL).write_text(out)
 run('normal-format',['node','node_modules/prettier/bin/prettier.cjs','--write',REL])
 assert (C/REL).read_text()==out
 S['sourceAfter']=source(REL)
 S['numericChanges']=[{'entry':'adapter-react root','before':172800,'after':172900,'measured':172879,'headroom':21},{'entry':'adapter-vue root','before':171600,'after':171700,'measured':171658,'headroom':42},{'entry':'adapter-web-component root','before':207400,'after':207500,'measured':207444,'headroom':56}];save()
 policy=run('original-budget-policy',['node','--test','scripts/analysis/test/package-budget-policy.test.mjs','scripts/analysis/test/package-budget-evidence.test.mjs'],timeout=120)
 clean=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',policy)
 totals={m.group(1):int(m.group(2)) for m in re.finditer(r'^\s*(?:#|ℹ)?\s*(tests|suites|pass|fail|cancelled|skipped|todo)\s+(\d+)\s*$',clean,re.M)}
 assert totals.get('tests')==28 and totals.get('pass')==28 and all(totals.get(k)==0 for k in ('fail','cancelled','skipped','todo')),totals
 S['policy']=totals
 folder='2026-11-24-sprint4-lifecycle-cost-budget-review'
 record='internal/records/'+folder+'.md';erel='internal/records/evidence/'+folder
 dest=C/erel;dest.mkdir(parents=True,exist_ok=False)
 sources=[('before-9fff/report.json',op),('before-9fff/artifact.zip',oldroot/'artifact.zip'),('before-9fff/summary.json',oldroot/'summary.json'),('candidate-a124/report.json',np),('candidate-a124/artifact.zip',newroot/'artifact.zip'),('candidate-a124/summary.json',newroot/'summary.json'),('comparison.json',compare),('measurement-projection.json',D/'measurement-projection.json'),('independent-numeric-review.md',review),('a124-artifact-independent-review.json',visual),('normal-format.stdout',D/'normal-format.stdout'),('normal-format.stderr',D/'normal-format.stderr'),('original-budget-policy.stdout',D/'original-budget-policy.stdout'),('original-budget-policy.stderr',D/'original-budget-policy.stderr'),('before-package-budgets.mjs',D/'before-package-budgets.mjs')]
 inventory=[];archive=dest/'execution.tar.gz'
 with tarfile.open(archive,'x:gz') as tar:
  for name,p in sources:
   assert p.is_file() and not p.is_symlink()
   data=p.read_bytes();inventory.append({'path':name,'bytes':len(data),'sha256':sha(data)});tar.add(p,arcname=name,recursive=False)
 with tarfile.open(archive,'r:gz') as tar:
  assert len(tar.getmembers())==len(inventory)
  for row in inventory:assert sha(tar.extractfile(row['path']).read())==row['sha256']
 manifest={'schema':'proto-ui-numeric-budget-transaction/v1','sourceBase':BASE,'sourceTree':'07650d1afd2d660aba4aa2cf26e1fa090ea25a6c','sourceBefore':S['sourceBefore'],'sourceAfter':S['sourceAfter'],'reviewers':{'independentNumericPeer':'image_diagnostic_wiring','secondTechnicalPeer':'root','executor':'sprint3_remote_validation','formalGitHubApproval':False},'changes':S['numericChanges'],'policy':totals,'priorStrictResult':{'run':45285226888,'exitCode':1,'passedEntries':6,'totalEntries':9},'newStrictStatus':'pending exact-head canonical run','acceptanceRequirement':'Nine entries and both existing diagnostics retain a124 minified/gzip bytes, minified hashes and complete input closures; only three caps, derived pass and source metadata may differ.','archive':{'path':'execution.tar.gz','bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'files':inventory}}
 (dest/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
 (C/record).write_text((D/'record-draft.md').read_text())
 run('normal-record-format',['node','node_modules/prettier/bin/prettier.cjs','--write',record,erel+'/manifest.json'])
 run('diff-check',['git','diff','--check']);assert source(REL)==S['sourceAfter']
 allowed={REL,record,erel+'/manifest.json',erel+'/execution.tar.gz'}
 run('stage-reviewed-paths',['git','add','--',*sorted(allowed)])
 assert set(run('staged-scope',['git','diff','--cached','--name-only']).splitlines())==allowed
 S['record']=record;S['archive']=manifest['archive'];save()
 run('normal-signed-commit',['git','commit','--signoff','-m','chore(budgets): account for reviewed scene cleanup cost'],timeout=180)
 head=run('head-after',['git','rev-parse','HEAD']).strip()
 identity=run('commit-identity',['git','show','-s','--format=%H%n%an <%ae>%n%cn <%ce>%n%B','HEAD'])
 assert 'Codex <codex@openai.com>' in identity and 'Signed-off-by: Codex <codex@openai.com>' in identity
 assert set(run('committed-scope',['git','diff-tree','--no-commit-id','--name-only','-r','HEAD']).splitlines())==allowed
 assert not run('status-after-commit',['git','status','--porcelain','--untracked-files=normal']).strip()
 latest=json.loads(run('public-pre-push',['gh','pr','view','1754','--repo','Proto-UI/Proto-UI','--json','headRefOid,headRefName,isDraft']))
 assert latest['headRefOid']==BASE and latest['headRefName']==BRANCH and latest['isDraft'] is True,latest
 run('normal-nonforce-push',['git','push','origin','HEAD:refs/heads/'+BRANCH],timeout=180)
 S['publishedHead']=head
 current=json.loads(run('public-after-push',['gh','pr','view','1754','--repo','Proto-UI/Proto-UI','--json','headRefOid,headRefName,isDraft,reviewDecision,url']))
 assert current['headRefOid']==head and current['isDraft'] is True
 S['publicAfter']=current;S['status']='published-awaiting-canonical-budget';save()
 def candidates(label):
  raw=run(label,['gh','api','--paginate','repos/Proto-UI/Proto-UI/actions/runs?head_sha='+head+'&event=workflow_dispatch&per_page=100'])
  return [r for page in pages(raw) for r in page.get('workflow_runs',[]) if r.get('head_sha')==head and r.get('path')=='.github/workflows/package-budget-evidence.yml']
 runs=candidates('same-head-runs-before')
 if not runs:
  run('dispatch-once',['gh','workflow','run','package-budget-evidence.yml','--repo','Proto-UI/Proto-UI','--ref',BRANCH]);S['dispatched']=True;save()
  for i in range(12):
   runs=candidates('same-head-runs-after-'+str(i))
   if runs:break
   time.sleep(2)
 assert len(runs)==1,[(r['id'],r['status']) for r in runs]
 S['run']={k:runs[0].get(k) for k in ('id','name','path','head_sha','head_branch','event','status','conclusion','created_at','html_url')}
 S['status']='numeric-only-published-exact-head-run-bound';S['finished']=now();save()
except BaseException as e:failure(e);raise
