S4 independent numeric review（可原样归档；这是独立数值审阅，非 GitHub maintainer approval）

审阅对象：PR #1754 的 a1246a78c6bb98beafd619e1e25342bead02635b / tree 07650d1afd2d660aba4aa2cf26e1fa090ea25a6c。比较原始报告实际来源为 9fff88cf23d4e55375979bc5c68c033e3deaed38 / tree 8f284229ff76e51ec109af2fd8f4d9694a739a35；不能把它标为 c18 的新测量。c18bf8f8c35a4ec1f69791468a5952c4cb460f41 是之前数字预算事务，其 canonical run 45269915996 已证明与此前产品 9+2 输出相同。当前 a124 的 run 45285226888 仍如实记录 strict 6/9、exit 1，三入口超原 cap 79 / 58 / 44 B，不覆写此红证据。

可比性：owner 从两个既存原始 report 核对完整 environment 和 measurement 对象完全相等：Node v24.22.3、zlib 1.3.2.1-motley-285e94b、esbuild 0.25.12、linux x64；bundle/minify/treeShaking、ESM/browser/es2020、gzip level 9 一致，external SHA 为 6a8bd56596b933f9a9d941db2a9e325789b44886af2648d6a9795f022787c253。a124 source clean / matchesHead / stable / requireClean 均 true，7831 files，fingerprint 57b483452e325ef426eba746b8b91199d7d704e0025fb973a6d4d2acc0809684。我另独立读取了 GitHub 的 a124 commit、预算 policy / evidence 实现和两版相关源码，确认没有改测量入口、预算工具、lock 或压缩配置；两份 changed source 的 UTF-8 字节和 SHA 与 owner 原报告逐字一致。

9 个 canonical entry，old minified / gzip → a124 minified / gzip：
X 4765 / 1797 → 相同；Lucide root 4083479 / 635917 → 相同；Core 39584 / 12674 → 相同；Runtime 401511 / 104169 → 相同；React 606361 / 172749 → 606707 / 172879（+346 / +130）；Vue 601759 / 171536 → 602139 / 171658（+380 / +122）；Web Component 709361 / 207303 → 709730 / 207444（+369 / +141）；Base Button 14223 / 4197 → 相同；Shadcn Button 30590 / 6741 → 相同。六个不变入口的 minified SHA 也完全相同。

两个原有 diagnostic：light DOM button 739414 / 213513 → 739783 / 213665；direct shadow button 739425 / 213517 → 739794 / 213669。均为 +369 minified / +152 gzip；406 inputs / 299 retained 未变，closure 只有下面两条源码变化。这两项来自之后的 bounded 原报告读取，不能声称已包含于此前只投影 9 entries 的 comparison.json。它们是原 diagnostics，不增加为新的 budget entry。

闭包：React 343 inputs / 242 retained、Vue 342 / 241、WC 371 / 271 前后一致，无新增入口或 retained input。三 adapter 的 changed source SHA 只有两条：
1. shader-scene-host.ts：15048 B / ddd4bf1e5b49e7fae03768f0c009fbcff67011ff637ef24cc0158adc8d82945b → 15119 B / 606d26b36dedf9c0a44762c3f72b7a852e697b267505b4d14e3ab24caddc5047，retained 0 → 0。
2. shader-webgl2.ts：4691 B / fd2b2b31aa2cb6f19451b9666d176a91e40fb6c418f4527c593da1b6140d1024 → 6455 B / c40af0f69e9c2880b747a465146dcd11b8d8702652a8862c717c79c9298559c0，retained 1370 → 1739（+369）。
WC 的其他 inputs 全同；React 60、Vue 25 个 changed rows 包含上述两条，剩余都是相同 source SHA 的 minifier 字节归因变化，不能称为 60 / 25 个源码改动。两 diagnostic 的其他 rows 全同。没有证据表明增长由工具漂移、重复 runtime 或新 closure 引入。whole-entry gzip 才是预算数值，不能相加文件 gzip / retained bytes 来替代。

判断：实际增长集中于已经接受的 WebGL cleanupDepth / pending cleanup / drain / fallback retirement 语义，三 entry 的 gzip 增幅约 0.07525%、0.07112%、0.06802%。我未找到可直接删掉且保持该重入清理语义的冗余成本；这不是全局最优体积证明。按仓库已有下一档 100 B 数值事务方式，建议仅将 React 172800 → 172900（实测 172879，余量 21），Vue 171600 → 171700（实测 171658，余量 42），WC 207400 → 207500（实测 207444，余量 56），各 +100；其余 6 cap 不变。该建议依据已确认的产品新增成本与固定 100 B 档位，不是按超额 79 / 58 / 44 直接自动 padding。

验收要求：独立 numeric-only 正常事务并附此依据；保留 a124 strict red 和旧 9fff 的真实 source 归属。在新 exact head 运行原 canonical strict，9+2 minified / gzip / hashes / input closure 必须逐项等于 a124，只有 cap 与 derived pass 变化。新 9/9、正式维护者 review 及完整 S4 native / browser 验收是不同证据层，互不替代。Root 已二次复核并授权上述三个 cap；我的结论本身不构成 GitHub approval。

证据索引：E/current-s4-a124-cost-review-01/comparison.json SHA 63ecbab7bf6e4be5fd3c224e6e7f488a3b25b0ca72290f98754d19338f5954d6；a124 raw report 1551021 B SHA 832993941ceed640d7503505612fb460e023cfe77dbc8ac85813764da0783397；artifact 14870169685 ZIP 303003 B SHA 189ecffc4c3543ca831d5abf26ef1bbfea049be2b63a5ad6356c2e8e4c690eba；旧 raw 位于 E/current-artifact-batch-20261123-2114/s4-budget-9fff。
