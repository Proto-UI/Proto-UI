# Root readback: one production input profile at ea600

This is diagnostic evidence and independent source review, not a replacement for canonical acceptance or a GitHub APPROVED review.

## Executed source and original result

The sole diagnostic ran the unmodified canonical production entry at `ea60064882924eb455e1dfc3ff7de55a32de4558`, tree `0897b961018877cfcbd41fae6f0c341f755839e2`, from its own detached checkout. The original entry built 684 production pages and owned its static service. The installed browser was Chrome `145.0.7632.6`; the separately retained hosted failure used Chrome `157.0.8103.78`.

The diagnostic completed at `2026-11-23T22:03:25.598489Z`. `captured` means the requested profile was obtained. Its original canonical result remains **17/20**, with the same 250 ms retirement failure, subsequent cancellation/reopen timeout and incomplete actual Worker history. Browser and service closure were confirmed. All 10,686 source inputs and production artifacts remained stable. Root independently read this final status and the source binding.

Original diagnostic receipt SHA-256: `443d491e113925a58bc87ce4f5007abdbab10265480afb3377bc3e21312e9553`.

## Captured input and accounting

The first bad-source edit reached the original ready precondition at revision 11, with one iframe and the Web Component target. The wrapper invoked the original `locator.fill` exactly once with unchanged arguments. The 6,724-byte input has SHA-256 `31cdc45eb20475366ca7ea0162d9e72b3425273629db5e10fc5d608549ad2035` and 179 newlines.

The observer recorded **331 distinct Event identities**, all trusted `insertText` events. First-to-last observer callback time was 763.8 ms; the complete original fill call was 1,331.715 ms. Root independently reread these original observations.

The trace's renderer thread has 331 input `EventDispatch` intervals spanning 769.693 ms. Their inclusive duration sum is 767.807 ms. Within that window, 7,636 `FunctionCall` intervals cover 687.019 ms; one `UpdateLayoutTree` costs 1.153 ms and one `Layout` costs 1.033 ms. Root independently read the retained accounting output. These overlapping categories are **not additive**.

The peer's additional exact containment accounting found 6,951 calls to `xu`, all contained within those input events, with **21 calls in every event** and zero unassigned calls. Their inclusive duration sum is 679.854 ms. The original editor input callback's 331 calls sum to 2.966 ms; the observer input callback's 331 calls sum to 3.581 ms. These measurements localize a repeated listener path; they do not prove that every profiler cost is absent from this observed execution.

The CPU profile's whole 2,301.741 ms interval includes setup, idle time and focus before input. Its whole-profile sampled totals must not be relabelled as input-only durations. The separate performance, trace and profiler clocks were not automatically equated. The containing long task also starts before the first input and must not be described entirely as input work.

## Source attribution and limits

Root read the exact emitted `site-shadcn-controls.YlYgnKvb.js` slices and CPU parent chains. The artifact is 875,707 bytes, SHA-256 `1cb96baf21ebaec413e6c5a291eee3b90c349172f096d08970de1fc6d14b5173`. The repeated path is `xu → K → z → qO → Li/zg`, corresponding to the Web Component entry projection event listener, current projection, descendant eligibility check and composed ancestor/style traversal in `packages/adapters/web-component/src/runtime/modules.ts` and its focus-tree helpers.

Root also read the current dependency collector and input-origin filter. The collector sets a whole-scope input-state flag when any selector contains an unclassified pseudo. The independent static scan of the actually linked production styles found 25 triggering rules among 3,196: 23 rules using known native-control pseudo-elements and two Mozilla pseudo-classes. The latter may be omitted by Chromium CSSOM; static text alone does not establish their runtime presence. The exact CSSOM and listener ownership inventory is separate work. At this record's point in time, no new product patch or successful final acceptance is claimed.

The recorded `disposed` message has the old revision but `sourceMatchesOldFrame=false`. Therefore it is not strict identity-confirmed acknowledgement evidence. The original canonical failure is the authoritative observed retirement result. No timer-start or child-cleanup duration was directly measured by this observer.

## Raw identities

- Final observer status: `e9729500ccb57cea8c9d569f69d07c5f2a48a65a62e9548c2a5f10a338d4ce0d`.
- CPU profile: `2ec46c8ae8f3e8dd8f914f412e33796be475c92c143d273c8c631d7b91083c4c` (301 nodes, 1,343 samples).
- Trace: `fb3e7b9146b84e67e82e8c86945036e3f1a5d024de60bbf22ad018449a8e88d9` (8,163,584 bytes; no reported data loss).
- Accounting: `58ed4965ea02424a2d30ad0bae7696b3b9a14a916867f992c8482bf9602d3d24`.
- Per-event containment: `046acf4411c3fb02cc703d8cc89d0d5db21290443ce26ebca0f78792328d76e1`.
- Observer source: `d7e12fad20693ce2ccddeb936b81db7ac4b717dd00e229149bd980b1d42736e6`.
- Driver source: `09756125b4296c8c629adcf66d120d520edb01928144d4aef4f749f3f0ba7c58`.

Original records reside under `sprint5-ea600-browser-diag-75d5e28a-ops/profile-original-fill-r1`. Preserve them as executed, including all failures, instrumented timing boundaries and the source/browser version distinction.
