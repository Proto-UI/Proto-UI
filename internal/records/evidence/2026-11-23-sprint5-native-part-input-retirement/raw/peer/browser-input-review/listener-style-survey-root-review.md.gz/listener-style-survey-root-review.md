# Root readback of the production listener/CSSOM survey

This independent readback covers the single read-only survey of the sealed ea600 production output, completed on 2026-11-23 at 22:25:18 UTC. It is diagnostic evidence, not a canonical browser pass and not a replay of the previously profiled revision-11 ready state.

## Execution and custody

Root read the complete survey source and supervisor before execution, then independently read their final status/supervisor and the actual listener and classifier JSONs. The survey source SHA-256 is `fab7509c868027d15fd2b5dcb75fe875f60fdde9c3d27687c631a883dec026d7`; supervisor source is `1ebdffb1482e3a054a3180ea9b406c2e97e2003a60a1b1854ae23e4f5c6c423d`. No input, click, fill, focus, synthetic dispatch or profiling action occurred. The survey inspected one initial hydrated page with null compiler phase/revision and zero compiler iframes.

The actual supervisor exited zero. Survey duration was 47.551 seconds. The actual browser and owned service closed successfully, with no errors. The exact head remained `ea60064882924eb455e1dfc3ff7de55a32de4558` and the worktree stayed clean. All 4,853 sealed production files, totaling 205,621,902 bytes, matched before and after. Final status SHA-256 is `87e32b601258b8e1122d8cbf8578710d256eae419af2675572da42aecd3a3991`; supervisor JSON is `381b3363e869c4e6387f39a86722c4e2bad1ae9df45667e22620dc687d2e85d1`. The local diagnostic browser was Chromium 145.0.7632.6; this is distinct from the hosted Chromium 157 result.

## Observed ownership and input-state flags

The actual `listeners.json` is 46,014 bytes, SHA-256 `c1148b5d2ce584354ec327f69bdf9d40201459678a891d79ad542e1aa7fdfa87`. The editor ancestor path contains 22 input listeners: its own panel handler and 21 capture registrations at the exact previously profiled `xu` source location (zero-based line 51, column 49907).

These are registrations for two foreign target elements, not 21 distinct owners. Eleven refer to `pui-runtime-shadcn-tabs-content#pui-a11y-2`; ten refer to `pui-code-example-shadcn-tabs-content#pui-a11y-10`. Both targets are connected and do not contain the editor. The repeated registrations occur along their shared native ancestor path. All 21 closures report input-style dependency `te=true` in scope 0, external-style input `je=false` in scope 1, and target `N` in scope 2. Every node listener has a usable backend-node identity; no descendant-filtering limitation was recorded.

This live initial-page observation complements the earlier profile, where all 331 actual native input events each incurred exactly 21 `xu` callbacks. It does not independently establish closure identities at the earlier revision-11 instant.

## Live CSSOM classification

The actual CSSOM inventory has one document, 38 stylesheets and 3,646 rules, with zero read errors. The 2,257,229-byte JSON is SHA-256 `3d98fe16a5480b88b7d4d188c7991357540ed2822b8f832aa3734ff9ebce6d38`. Of its 3,275 CSS style rules, the exact frozen old helper flags 23; the exact candidate flags zero. All 23 changes concern the bounded native pseudo-element identities already identified in the production CSS. The two Mozilla ordinary pseudo-class rules found by static asset inspection are absent from this actual Chrome CSSOM.

Root also read the complete 4,658-byte offline classifier source, SHA-256 `257eb0508a72ede9690a0c187d7e25de0e7dbbf985a70edd1481efadad07bfe7`. It verifies the frozen module and CSSOM hashes, uses TypeScript 5.9.3 to extract and transpile exactly the two original helper declarations, and applies the existing immediate-parent selector substitution. Its report is SHA-256 `d0d3005068d0da789c6606120bb0716fbd8f112420244cf3608aeea1e2116330`, with oldHits=23, candidateHits=0, changedRules=23, remaining=[]. This is a counterfactual helper evaluation over captured CSSOM, not execution of the complete dependency collector or a new browser acceptance run.

No source or evidence blocker was found for advancing this bounded candidate to its ordinary signed commit, nonforce publication and original production acceptance. The original 250 ms gate, old failures and independent-rebuild requirement remain in force. Root separately compared the candidate test bytes with the b880 Git object and confirmed that all 13,229 original bytes remain an exact prefix of the 16,479-byte test file.
