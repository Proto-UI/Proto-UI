# Root source review: native pseudo-element input-state classification

Reviewed on 2026-11-23 against the candidate based on `b8800d4cef9302718d4514b1ba28508860059929` (tree `4dfcdb3d01bc52b0c202a9d4e05a3c7f50a01651`). This is an independent source/evidence review, not a GitHub approval or a production-browser acceptance result.

## Actual material inspected

The complete two-file `pseudo-input-identity-r1/candidate.patch`, complete execution `status.json`, and the two original Vitest JSONs were read. The original source helper SHA-256 is `075436cbcf17fdcb7ef8e0983048bd2784f993f65f5579b936a7fb1b24172811`. The candidate module is `4406d1a05d0249635250457562a843e0ed247eb2855c5abdcc4ed76bcf8c5bfa`; the candidate test file is `63f88eb9770d99e338bb64ff6f4105bf4bad1e1f735de3eb987fd464dc16acd4`.

The independent read of the original old-helper JSON found 60 cases: 26 passed, 34 failed, and zero pending/todo. All 34 failures report the same intended assertion, `expected true to be false`, at the unrelated-target computed-style-read check. The original old JSON is SHA-256 `6922df095231701e87a821d8a1d175bec1fca021b280251c1b802c64779f4a68`. The same controls on the candidate helper yield 60 passed, zero failed/pending/todo; original new JSON SHA-256 `0d9c4458c19440504783323d9a295010d1534960a8ca6fb4fd1290c6702717c7`. The execution receipt verifies the complete original 18-case file as an unchanged byte prefix. The patch itself appends the new suite and does not remove or weaken existing assertions.

## Source decision

No blocking source issue was found in this bounded change. It adds exactly the 17 observed native pseudo-element identities to the existing state-independent pseudo-element branch. The regular expression is fully anchored. It does not admit a general `-webkit-*` namespace, ordinary Mozilla pseudo-classes, unknown identities, or escaped suffixes.

The parser continues to inspect the rest of the selector. The added controls retain conservative treatment of `:valid`, `:invalid`, `:dir`, `:checked`, `:placeholder-shown`, an unknown state following a known pseudo-element, a future WebKit pseudo-element, and an escaped unknown suffix. The original relationship, form-associated aggregate state, opaque stylesheet, constructed CSSOM, synchronous local projection, and synthetic-event controls remain in the same file. These tests exercise the existing host-model trusted-event branch; they are not a native timing claim.

The implementation changes only the finite native-part identity classification. It does not filter declarations, defer or deduplicate events, alter the compiler/session/sandbox implementation, change the 250 ms acknowledgement bound, or edit the canonical browser assertions. Static production CSS inspection already located these identities in the actual loaded assets. The separate read-only live CSSOM/listener survey must be reported with its initial-hydrated-page boundary; it does not replay the original r11 profile state.

## Remaining acceptance

The original ea600 formal browser result remains 17/20, and the independently instrumented ea600 reproduction also remains 17/20. The 60 host-model controls do not replace an unchanged, uninstrumented production browser run at the published candidate. A final Ready decision needs that browser result, the independent rebuild and delivery gates, current standard CI/DCO, and source/evidence custody at the actual published head. Preserve the old failures and bind all new results to the source that executed them.
