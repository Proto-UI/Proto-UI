#!/usr/bin/env python3
import pathlib,os,subprocess,json,hashlib,datetime,traceback,fcntl,re
T=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
B=pathlib.Path(str(T)+'-ops');O=B/'pseudo-input-identity-r1'
lock=(B/'pseudo-input-identity-r1.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
O.mkdir(exist_ok=False)
P=json.loads((B/'pseudo-input-identity-candidate-v1.json').read_text())
E=dict(os.environ);E['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:'+E.get('PATH','');E['TMPDIR']='/var/tmp/s5g75d5';assert E.get('HUSKY')!='0'
A='ea60064882924eb455e1dfc3ff7de55a32de4558';H=P['sourceBase'];REF='refs/agent/sprint5/b880-20261123-75d5';BR='fix/sprint5-preview-input-bundle-20261123-75d5'
S={'phase':'initial','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'commands':[],'published':False,'committed':False}
def save(phase=None):
 if phase:S['phase']=phase
 (O/'status.json').write_text(json.dumps(S,indent=2)+'\n')
def digest(b):return hashlib.sha256(b).hexdigest()
def sha(p):return digest(p.read_bytes())
def run(name,args,timeout=600,allowed=(0,)):
 save(name);(O/(name+'.command.json')).write_text(json.dumps({'argv':args,'cwd':str(T),'timeoutSeconds':timeout},indent=2)+'\n')
 with (O/(name+'.log')).open('wb') as out:
  proc=subprocess.Popen(args,cwd=T,env=E,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  S['childPid']=proc.pid;save()
  try:code=proc.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   import signal
   os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=10)
   raise
 S.pop('childPid',None);S['commands'].append({'name':name,'argv':args,'exitCode':code});save();assert code in allowed,(name,code)
 return code
def git(*args):return subprocess.check_output(['git',*args],cwd=T,env=E,text=True,timeout=90).strip()
def report(name):
 d=json.loads((O/(name+'.json')).read_text()); assertions=[a for f in d.get('testResults',[]) for a in f.get('assertionResults',[])];return d,assertions
try:
 assert git('rev-parse','HEAD')==A and git('status','--porcelain=v1')==''
 assert git('branch','--show-current')=='codex/sprint5-input-75d5e28a'
 assert not pathlib.Path(git('rev-parse','--git-path','MERGE_HEAD')).exists()
 run('remote-pr',['gh','api','repos/Proto-UI/Proto-UI/pulls/1738'],timeout=90)
 pr=json.loads((O/'remote-pr.log').read_text());assert pr['head']['sha']==H and pr['head']['ref']==BR and pr['state']=='open' and pr['draft']
 run('remote-branch',['git','ls-remote','--heads','origin','refs/heads/'+BR],timeout=90)
 assert (O/'remote-branch.log').read_text().split()[0]==H
 run('fetch-public',['git','fetch','--no-tags','origin','refs/heads/'+BR+':'+REF],timeout=300)
 assert git('rev-parse',REF)==H
 run('require-ancestor',['git','merge-base','--is-ancestor',A,H],timeout=30)
 run('normal-fast-forward',['git','merge','--ff-only',H],timeout=300)
 assert git('rev-parse','HEAD')==H and git('status','--porcelain=v1')==''
 S.update({'baseHead':H,'baseTree':git('rev-parse','HEAD^{tree}'),'fastForwardedFrom':A,'baseClean':True});save()
 (O/'public-source-diff.patch').write_text(git('diff',A,H,'--','.github/workflows/compiler-browser-acceptance.yml','packages','spec')+'\n')
 module=T/P['modulePath'];test=T/P['testPath'];oldModule=module.read_bytes();oldTest=test.read_bytes()
 assert digest(oldModule)==P['originalModuleSha256'] and git('hash-object',P['testPath'])==P['originalTestGitBlob']
 (O/'before-modules.ts').write_bytes(oldModule);(O/'before-focus-entry-input-origin.test.ts').write_bytes(oldTest)
 S['sourceBefore']={P['modulePath']:digest(oldModule),P['testPath']:digest(oldTest)};save()
 test.write_text(oldTest.decode()+P['appendTests'])
 run('format-added-tests',['corepack','pnpm@10.32.1','exec','prettier','--write',P['testPath']],timeout=90)
 assert test.read_bytes().startswith(oldTest),'Original 18-test file prefix changed'
 candidateTest=test.read_bytes();(O/'candidate-focus-entry-input-origin.test.ts').write_bytes(candidateTest)
 assert module.read_bytes()==oldModule
 assert git('diff','--name-only').splitlines()==[P['testPath']]
 base=['corepack','pnpm@10.32.1','exec','vitest','run',P['testPath'],'--maxWorkers=1','--minWorkers=1','--no-file-parallelism','--reporter=default','--reporter=json']
 run('old-helper-new-controls',base+['--outputFile='+str(O/'old-helper-new-controls.json')],timeout=300,allowed=(1,))
 d,assertions=report('old-helper-new-controls');failed=[a for a in assertions if a['status']=='failed']
 assert len(failed)==P['expectedNewNoSampleCases']
 assert all(a['title'].startswith('does not resample an unrelated entry for ') and any('expected true to be false' in m for m in a.get('failureMessages',[])) for a in failed)
 assert d['numPendingTests']==0 and d.get('numTodoTests',0)==0
 assert d['numPassedTests']==26 and d['numTotalTests']==60
 assert module.read_bytes()==oldModule and test.read_bytes()==candidateTest
 S['red']={k:d.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests']}
 S['redFailedTitles']=[a['title'] for a in failed];save('valid-old-helper-red')
 content=oldModule.decode()
 assert content.count(P['oldRegex'])==1 and content.count(P['commentBefore'])==1
 content=content.replace(P['oldRegex'],P['newRegex']).replace(P['commentBefore'],P['commentAfter'])
 module.write_text(content)
 run('format-candidate-module',['corepack','pnpm@10.32.1','exec','prettier','--write',P['modulePath']],timeout=90)
 assert test.read_bytes()==candidateTest
 (O/'candidate-modules.ts').write_bytes(module.read_bytes())
 (O/'candidate.patch').write_text(git('diff','--',P['modulePath'],P['testPath'])+'\n')
 candidateModule=module.read_bytes();S['candidateSource']={P['modulePath']:digest(candidateModule),P['testPath']:digest(candidateTest)};save()
 run('new-helper-same-controls',base+['--outputFile='+str(O/'new-helper-same-controls.json')],timeout=300)
 d,assertions=report('new-helper-same-controls')
 assert d['success'] and d['numTotalTests']==60 and d['numPassedTests']==60 and d['numFailedTests']==0 and d['numPendingTests']==0 and d.get('numTodoTests',0)==0
 assert all(a['status']=='passed' for a in assertions)
 assert module.read_bytes()==candidateModule and test.read_bytes()==candidateTest
 run('format-final',['corepack','pnpm@10.32.1','exec','prettier','--check',P['modulePath'],P['testPath']],timeout=90)
 run('diff-check',['git','diff','--check'],timeout=30)
 assert sorted(git('diff','--name-only').splitlines())==sorted([P['modulePath'],P['testPath']]) and git('diff','--cached','--name-only')=='' and git('ls-files','--others','--exclude-standard')==''
 assert module.read_bytes()==candidateModule and test.read_bytes()==candidateTest
 S.update({'green':{k:d.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests']},'sourceAfter':{P['modulePath']:sha(module),P['testPath']:sha(test)},'originalTestPrefixUnchanged':test.read_bytes().startswith(oldTest),'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'headUnchanged':git('rev-parse','HEAD')==H})
 save('candidate-tested-not-committed')
except BaseException as ex:
 S['error']=repr(ex);S['traceback']=traceback.format_exc();S['failedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save('failed');raise
