#!/usr/bin/env python3
import pathlib,os,subprocess,json,datetime,hashlib,traceback,zipfile,stat,shutil
T=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a')
B=pathlib.Path(str(T)+'-ops'); O=B/'formal-ea600-source-browser'
O.mkdir(exist_ok=False)
H='ea60064882924eb455e1dfc3ff7de55a32de4558'; RUN=45271472592; REPO='Proto-UI/Proto-UI'
E=dict(os.environ); E['TMPDIR']='/var/tmp/s5g75d5'
S={'phase':'initial','head':H,'run':RUN,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'crossDeviceCustodyCopy':True,'executedTests':False,'modifiedSources':False,'jobs':[]}
def save(phase=None):
 if phase:S['phase']=phase
 (O/'status.json').write_text(json.dumps(S,indent=2)+'\n')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def gh(name,endpoint,binary=False):
 save('copying-'+name); p=O/name
 with p.open('wb') as out:
  r=subprocess.run(['gh','api',endpoint],cwd=T,env=E,stdout=out,stderr=subprocess.PIPE,timeout=180)
 (O/(name+'.stderr')).write_bytes(r.stderr)
 assert r.returncode==0,(name,r.returncode,r.stderr.decode(errors='replace'))
 return p if binary else json.loads(p.read_text())
def entry(p,base=O):
 return {'path':str(p.relative_to(base)),'bytes':p.stat().st_size,'sha256':digest(p)}
try:
 peer=B/'formal-ea600-source-browser-peer.json'
 assert digest(peer)=='8ba6b8ba995ecf46f943fad97413325bde537793a267f6f704ddc41729f547ab'
 shutil.copyfile(peer,O/'formal-source-browser-readback.json')
 S['peerReadback']=entry(O/'formal-source-browser-readback.json')
 run=gh('run.json','repos/'+REPO+'/actions/runs/'+str(RUN))
 assert run['head_sha']==H and run['status']=='completed' and run['conclusion']=='failure'
 artifacts=gh('artifacts.json','repos/'+REPO+'/actions/runs/'+str(RUN)+'/artifacts?per_page=100')['artifacts']
 expected=[
 ('browser',138032094383,'failure',14865836984,2126283,'9b56c4470458c16fb6e61f98b05d156409f676d601d3605f802a5e985fedda57',1058753,'cd03911852c11bf31ba28512e25799b763390f1fb1ad3023e5f5176698bd594f'),
 ('source',138032094166,'success',14865037350,97620,'61a8b51b17c015923e6e97777394e073b71a903cc899af6b128a4f6163918bd7',933322,'af47eea2b48af64b8d96bc076e01f7854bef8718a944aaef52d637a00974b858')]
 for key,jid,conclusion,aid,zsize,zsha,lsize,lsha in expected:
  meta=gh(key+'-job.json','repos/'+REPO+'/actions/jobs/'+str(jid))
  assert meta['run_id']==RUN and meta['status']=='completed' and meta['conclusion']==conclusion
  matches=[a for a in artifacts if a['id']==aid]
  assert len(matches)==1; a=matches[0]
  assert not a['expired'] and a['workflow_run']['head_sha']==H
  z=gh(key+'-artifact.zip','repos/'+REPO+'/actions/artifacts/'+str(aid)+'/zip',True)
  assert z.stat().st_size==zsize==a['size_in_bytes']
  assert digest(z)==zsha and a['digest']=='sha256:'+zsha
  log=gh(key+'-job-original.log','repos/'+REPO+'/actions/jobs/'+str(jid)+'/logs',True)
  assert log.stat().st_size==lsize and digest(log)==lsha,(key,entry(log),'expected',lsize,lsha)
  extracted=O/(key+'-artifact'); extracted.mkdir()
  with zipfile.ZipFile(z) as archive:
   assert archive.testzip() is None
   for item in archive.infolist():
    p=pathlib.PurePosixPath(item.filename)
    assert not p.is_absolute() and '..' not in p.parts and not stat.S_ISLNK(item.external_attr>>16)
   archive.extractall(extracted)
  shaFiles=list(extracted.rglob('source-sha.txt'))
  assert len(shaFiles)==1 and shaFiles[0].read_text().strip()==H
  files=sorted([p for p in extracted.rglob('*') if p.is_file()])
  S['jobs'].append({'key':key,'jobId':jid,'conclusion':conclusion,'artifactId':aid,'sourceSha':H,'zip':entry(z),'originalJobLog':entry(log),'extracted':[entry(p) for p in files]})
  save()
 S['extractedFileCount']=sum(len(j['extracted']) for j in S['jobs'])
 S['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 S['summary']='Original hosted artifact and job-log bytes copied across devices and checked against independently retained primary originals. No test/build/browser execution.'
 save('custody-verified')
except BaseException as ex:
 S['error']=repr(ex);S['traceback']=traceback.format_exc();save('failed');raise
