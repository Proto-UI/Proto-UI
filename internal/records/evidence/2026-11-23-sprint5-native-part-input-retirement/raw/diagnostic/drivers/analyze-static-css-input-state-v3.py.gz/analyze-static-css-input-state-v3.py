#!/usr/bin/env python3
import pathlib,html.parser,json,hashlib,subprocess,datetime
T=pathlib.Path('/tank/shared/projects/proto-ui-agent/sprint5-ea600-browser-diag-75d5e28a');D=T/'apps/www/dist';O=pathlib.Path(str(T)+'-ops')/'static-css-input-state-v3';O.mkdir(exist_ok=True)
P=D/'en/ui-libraries/base/button/index.html'
class Parser(html.parser.HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.styles=[];self.current=None;self.inert=0
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag in ('noscript','template'):self.inert+=1
  if not self.inert and tag=='link' and 'stylesheet' in a.get('rel','').split():self.links.append(a)
  if not self.inert and tag=='style':self.current={'attributes':a,'css':''}
 def handle_data(self,data):
  if self.current is not None:self.current['css']+=data
 def handle_endtag(self,tag):
  if tag=='style' and self.current is not None:self.styles.append(self.current);self.current=None
  if tag in ('noscript','template'):self.inert-=1
p=Parser();p.feed(P.read_text());sources=[];seen=set()
for link in p.links:
 href=link.get('href','')
 if href in seen:continue
 seen.add(href)
 if href.startswith('/') and not href.startswith('//'):
  file=D/href.lstrip('/');raw=file.read_bytes();sources.append({'href':href,'path':str(file),'media':link.get('media'),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'css':raw.decode()})
 else:sources.append({'href':href,'opaque':True})
for i,s in enumerate(p.styles):
 raw=s['css'].encode();sources.append({'href':'inline:'+str(i),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'css':s['css']})
data={'root':str(T),'htmlPath':str(P),'htmlSha256':hashlib.sha256(P.read_bytes()).hexdigest(),'sources':sources,'note':'Static served CSS parse, excluding noscript/template; this is not a live CSSOM or event-origin observation.'}
(O/'sources.json').write_text(json.dumps(data,indent=2)+'\n')
js=r"""
const fs=require('node:fs'),crypto=require('node:crypto'),{createRequire}=require('node:module');
const data=JSON.parse(fs.readFileSync(0,'utf8')),req=createRequire(data.root+'/apps/www/package.json'),postcss=require(data.root+'/node_modules/.pnpm/node_modules/postcss'),ts=req('typescript');
const source=fs.readFileSync(data.root+'/packages/adapters/web-component/src/runtime/modules.ts','utf8');
const ast=ts.createSourceFile('modules.ts',source,ts.ScriptTarget.Latest,true);
const selected=ast.statements.filter(x=>ts.isFunctionDeclaration(x)&&['skipSelectorLiteral','selectorMayDependOnInputState'].includes(x.name?.text));
if(selected.length!==2)throw Error('helper selection');
const helpers=selected.map(x=>x.getText(ast)).join('\n');
const js=ts.transpileModule(helpers,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;
const classify=new Function(js+'\nreturn selectorMayDependOnInputState;')();
const hits=[],sheets=[],imports=[];let rules=0;
for(const sheet of data.sources){
 sheets.push(Object.fromEntries(Object.entries(sheet).filter(([k])=>k!=='css')));
 if(sheet.opaque)continue;
 const parsed=postcss.parse(sheet.css,{from:sheet.href});
 parsed.walkAtRules('import',x=>imports.push({href:sheet.href,params:x.params}));
 parsed.walkRules(rule=>{
  rules++;let selector=rule.selector;
  if(rule.parent?.type==='rule')selector=selector.replaceAll('&',':is('+rule.parent.selector+')');
  if(!classify(selector))return;
  const declarations=(rule.nodes||[]).filter(x=>x.type==='decl').map(x=>({property:x.prop,value:x.value,important:!!x.important}));
  const nesting=[];for(let p=rule.parent;p&&p.type!=='root';p=p.parent)if(p.type==='atrule')nesting.push({name:p.name,params:p.params});
  hits.push({href:sheet.href,line:rule.source.start.line,column:rule.source.start.column,selector,rawSelector:rule.selector,declarations,nesting});
 });
}
console.log(JSON.stringify({kind:'static exact-helper input-state CSS candidates',sourceSha256:crypto.createHash('sha256').update(source).digest('hex'),helperSha256:crypto.createHash('sha256').update(helpers).digest('hex'),htmlPath:data.htmlPath,htmlSha256:data.htmlSha256,note:data.note,sheets,rules,imports,hits},null,2));
"""
r=subprocess.run(['/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin/node','-e',js],input=json.dumps(data),text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=T,timeout=60)
(O/'stderr.log').write_text(r.stderr);assert r.returncode==0,(r.returncode,r.stderr)
(O/'analysis.json').write_text(r.stdout);out=json.loads(r.stdout)
print(json.dumps({'output':str(O/'analysis.json'),'rules':out['rules'],'hits':len(out['hits']),'sourceSha256':out['sourceSha256'],'imports':out['imports'],'candidates':out['hits'][:25]},indent=2))
