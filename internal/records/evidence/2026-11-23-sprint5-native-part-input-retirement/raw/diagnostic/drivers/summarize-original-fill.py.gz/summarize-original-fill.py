"""Read-only accounting for the one-fill diagnostic; emits JSON to stdout.

CPU durations are sample-weighted estimates. Native trace durations are inclusive
event intervals and must not be added to CPU estimates or across nested names.
No clock-domain identity or causal source attribution is inferred by this script.
"""
import argparse
import collections
import datetime
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('profile_directory', type=Path)
args = parser.parse_args()


def read(name):
    path = args.profile_directory / name
    raw = path.read_bytes()
    return json.loads(raw), {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


observer, observer_file = read('observer-status.json')
cpu, cpu_file = read('original-fill.cpuprofile')
trace, trace_file = read('original-fill.trace.json')
observation = observer.get('observation') or {}
inputs = observation.get('inputEvents') or []
first = inputs[0]['time'] if inputs else None
last = inputs[-1]['time'] if inputs else None
time_origin = observation.get('timeOrigin')
input_summary = {
    'count': len(inputs), 'uniqueEventIds': len({row['id'] for row in inputs}),
    'trusted': dict(collections.Counter(str(row.get('trusted')) for row in inputs)),
    'inputTypes': dict(collections.Counter(str(row.get('inputType')) for row in inputs)),
    'firstPerformanceMs': first, 'lastPerformanceMs': last,
    'firstToLastMs': last - first if inputs else None,
    'timeOriginMs': time_origin,
    'fillCallDurationMs': observer.get('fillDurationMs'),
    'originalFillCalls': observer.get('originalFillCalls'),
    'profiledFills': observer.get('profiledFills'),
    'longtasks': observation.get('longtasks'),
    'messagesFromOldFrameAndRevision': [
        {**row, 'msAfterFirstInput': row['time'] - first if first is not None else None}
        for row in observer.get('messages', [])
        if row.get('sourceMatchesOldFrame') and row.get('matchesOldRevision')
    ],
}
if first is not None and time_origin is not None:
    input_summary['firstInputWallUtc'] = datetime.datetime.fromtimestamp(
        (time_origin + first) / 1000, datetime.timezone.utc
    ).isoformat()

nodes = {node['id']: node for node in cpu['nodes']}
parents = {}
for node in cpu['nodes']:
    for child in node.get('children', []):
        if child in parents:
            raise ValueError('CPU node has multiple parents')
        parents[child] = node['id']
samples = cpu.get('samples', [])
deltas = cpu.get('timeDeltas', [])
if len(samples) != len(deltas):
    raise ValueError('CPU samples/timeDeltas lengths differ')
self_us, inclusive_us = collections.Counter(), collections.Counter()
for node_id, delta in zip(samples, deltas):
    if node_id not in nodes or delta < 0:
        raise ValueError('Invalid CPU sample')
    self_us[node_id] += delta
    seen = set()
    while node_id is not None:
        if node_id in seen:
            raise ValueError('CPU parent cycle')
        seen.add(node_id)
        inclusive_us[node_id] += delta
        node_id = parents.get(node_id)


def cpu_row(node_id):
    node = nodes[node_id]
    return {
        'nodeId': node_id, 'callFrame': node['callFrame'],
        'approximateSampledSelfMs': self_us[node_id] / 1000,
        'approximateSampledInclusiveMs': inclusive_us[node_id] / 1000,
        'parentNodeId': parents.get(node_id),
    }


events = trace.get('traceEvents', []) if isinstance(trace, dict) else trace
threads, stacks, complete = {}, collections.defaultdict(list), []
unmatched_ends = 0
for event in events:
    key = (event.get('pid'), event.get('tid'))
    phase = event.get('ph')
    if phase == 'M' and event.get('name') == 'thread_name':
        threads[key] = event.get('args', {}).get('name')
    elif phase == 'X' and isinstance(event.get('dur'), (int, float)):
        complete.append(event)
    elif phase == 'B':
        stacks[key].append(event)
    elif phase == 'E':
        if not stacks[key]:
            unmatched_ends += 1
            continue
        begin = stacks[key].pop()
        duration = event['ts'] - begin['ts']
        if duration >= 0:
            complete.append({**begin, 'dur': duration, 'derivedFromBeginEnd': True})


def union_duration(intervals):
    total, start, end = 0, None, None
    for a, b in sorted(intervals):
        if start is None:
            start, end = a, b
        elif a <= end:
            end = max(end, b)
        else:
            total += end - start
            start, end = a, b
    return total + (end - start if start is not None else 0)


input_by_thread = collections.defaultdict(list)
for event in complete:
    if event.get('name') == 'EventDispatch' and event.get('args', {}).get('data', {}).get('type') == 'input':
        input_by_thread[(event.get('pid'), event.get('tid'))].append(event)
native = []
names = {'EventDispatch', 'FunctionCall', 'UpdateLayoutTree', 'Layout', 'PrePaint', 'Paint', 'HitTest', 'RunTask', 'TimerFire'}
for key, rows in input_by_thread.items():
    rows.sort(key=lambda row: row['ts'])
    start = rows[0]['ts']
    end = max(row['ts'] + row['dur'] for row in rows)
    groups = collections.defaultdict(list)
    for event in complete:
        if (event.get('pid'), event.get('tid')) != key or event.get('name') not in names:
            continue
        a, b = max(start, event['ts']), min(end, event['ts'] + event['dur'])
        if b > a:
            groups[event['name']].append((event, a, b))
    metrics = []
    for name, selected in groups.items():
        metrics.append({
            'name': name, 'count': len(selected),
            'wholeInclusiveDurationSumMs': sum(item[0]['dur'] for item in selected) / 1000,
            'maxWholeDurationMs': max(item[0]['dur'] for item in selected) / 1000,
            'clippedUnionWithinInputWindowMs': union_duration([(a, b) for _, a, b in selected]) / 1000,
        })
    native.append({
        'pid': key[0], 'tid': key[1], 'threadName': threads.get(key),
        'inputEventDispatchCount': len(rows), 'firstTsUs': start, 'lastEndTsUs': end,
        'windowMs': (end - start) / 1000,
        'firstDispatchToLastDispatchStartMs': (rows[-1]['ts'] - start) / 1000,
        'nativeEventMetrics': sorted(metrics, key=lambda row: -row['clippedUnionWithinInputWindowMs']),
        'interpretation': 'A trace thread containing input events; equality with the observed textarea event sequence requires independent correlation. Inclusive rows overlap and are not additive.',
    })

print(json.dumps({
    'kind': 'read-only-original-fill-accounting',
    'canonicalAcceptance': False,
    'files': [observer_file, cpu_file, trace_file],
    'observer': input_summary,
    'cpu': {
        'startTimeUs': cpu['startTime'], 'endTimeUs': cpu['endTime'],
        'profileSpanMs': (cpu['endTime'] - cpu['startTime']) / 1000,
        'sampleCount': len(samples), 'sumSampleDeltasMs': sum(deltas) / 1000,
        'topSelfNodes': [cpu_row(node_id) for node_id, _ in self_us.most_common(30)],
        'topInclusiveJavaScriptNodes': [cpu_row(node_id) for node_id, _ in inclusive_us.most_common()
                                       if nodes[node_id]['callFrame'].get('url')][:30],
        'accounting': 'Per-node sample-weighted estimates. Do not add self and inclusive or add to native trace durations. Profiler startup/stop overhead is part of this recorded interval.',
    },
    'nativeTrace': {
        'eventCount': len(events), 'completeEventCount': len(complete),
        'unmatchedEndCount': unmatched_ends,
        'unclosedBeginCount': sum(len(stack) for stack in stacks.values()),
        'inputThreads': native,
        'clockBoundary': 'No automatic equivalence between profiler, trace and performance.now clocks is assumed.',
    },
}, indent=2))
