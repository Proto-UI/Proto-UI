import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tempfile

ROOT = Path('/tank/shared/projects/proto-ui-agent/sprint5-ea600-browser-diag-75d5e28a')
OPS = ROOT.with_name(ROOT.name + '-ops')
HEAD = 'ea60064882924eb455e1dfc3ff7de55a32de4558'
NODE = Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin')
CHROME = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/playwright-browsers/chromium-1208/chrome-linux64/chrome'
OBSERVER = OPS / 'observer-ea600-profile.cjs'
OUT = OPS / 'profile-original-fill-r1'

lock = (OPS / 'profile-original-fill.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
OUT.mkdir(exist_ok=False)
temporary = Path(tempfile.mkdtemp(prefix='pf75-', dir='/var/tmp'))
environment = dict(os.environ)
for key in ('PUI_BROWSER_URL', 'PUI_BROWSER_PORT'):
    environment.pop(key, None)
configured = {
    'TMPDIR': str(temporary),
    'CI': '1',
    'COREPACK_ENABLE_DOWNLOAD_PROMPT': '0',
    'ASTRO_TELEMETRY_DISABLED': '1',
    'NODE_OPTIONS': '--max-old-space-size=6144',
    'PUI_CHROME_EXECUTABLE': CHROME,
    'PUI_BROWSER_MODE': 'production',
    'CANDIDATE_SHA': HEAD,
    'PUI_EVIDENCE_DIR': str(OUT / 'browser'),
    'PUI_PROFILE_ROOT': str(ROOT),
    'PUI_PROFILE_OUTPUT': str(OUT / 'profile'),
}
environment.update(configured)
environment['PATH'] = str(NODE) + ':' + environment['PATH']
files = [
    'apps/www/src/components/PrototypePreviewer/browser-compiler-panel.ts',
    'apps/www/src/components/PrototypePreviewer/compiled-revision-session.ts',
    'apps/www/src/components/PrototypePreviewer/compiled-preview-sandbox.ts',
    'apps/www/astro.config.mjs',
    'apps/www/package.json',
    'packages/compiler/test/browser-source-input.test.ts',
    'scripts/analysis/browser-compiler-browser.mts',
    'scripts/compiler/browser-production.mjs',
    'scripts/compiler/browser-inputs.mjs',
    'scripts/compiler/browser-evidence.mjs',
    '.github/workflows/compiler-browser-acceptance.yml',
    'pnpm-lock.yaml',
    'package.json',
]
status = {
    'kind': 'one-current-source-production-input-profile',
    'canonicalAcceptance': False,
    'expectedHead': HEAD,
    'root': str(ROOT),
    'output': str(OUT),
    'configuredEnvironment': configured,
    'scope': 'The unchanged canonical production runner builds and serves its own exact-head production artifact. One original bad-source fill is CPU-profiled and traced. Instrumentation adds overhead, so even a green observed run is diagnostic only. Original 250ms retirement, input, sandbox and assertions remain unchanged.',
    'steps': [],
}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(file):
    return hashlib.sha256(Path(file).read_bytes()).hexdigest()


def save():
    (OUT / 'status.json').write_text(json.dumps(status, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, env=environment, text=True, timeout=90).strip()


def sources():
    return {file: digest(ROOT / file) for file in files}


process = None
try:
    assert OBSERVER.is_file()
    assert os.statvfs('/var/tmp').f_bavail * os.statvfs('/var/tmp').f_frsize > 1024 ** 3
    status.update(startedAt=now(), head=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'), statusBefore=git('status', '--porcelain'))
    assert status['head'] == HEAD
    assert not status['statusBefore'], 'Exact-head diagnostic must start with clean tracked source.'
    status['sourceSha256Before'] = sources()
    status['observerSha256'] = digest(OBSERVER)
    status['driverSha256'] = digest(__file__)
    status['nodeVersion'] = subprocess.check_output([str(NODE / 'node'), '--version'], env=environment, text=True, timeout=30).strip()
    status['chromeVersion'] = subprocess.check_output([CHROME, '--version'], env=environment, text=True, timeout=30).strip()
    status['hostedBrowserDifference'] = 'Hosted failed receipt used Chrome 157.0.8103.78; this bounded local diagnosis uses the recorded installed Chrome version and does not substitute for hosted acceptance.'
    command = [str(NODE / 'node'), '--require', str(OBSERVER), '--import', 'tsx', 'scripts/analysis/browser-compiler-browser.mts']
    log = OUT / 'canonical-production-profile.log'
    row = {'name': 'unchanged-canonical-production-with-one-profile', 'command': command, 'startedAt': now(), 'state': 'running', 'timeoutSeconds': 1200, 'log': str(log)}
    status['steps'].append(row)
    save()
    print('Starting one exact-head production diagnostic at ' + HEAD, flush=True)
    with log.open('wb') as output:
        process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        row['pid'] = process.pid
        save()
        try:
            code = process.wait(1200)
        except subprocess.TimeoutExpired:
            row['timedOut'] = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                code = process.wait(10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                code = process.wait(10)
    row.update(exitCode=code, state='completed' if code == 0 and not row.get('timedOut') else 'failed', finishedAt=now(), logSha256=digest(log))
    status.update(headAfter=git('rev-parse', 'HEAD'), statusAfter=git('status', '--porcelain'), sourceSha256After=sources())
    receipt = OUT / 'browser' / 'receipt.json'
    if receipt.is_file():
        value = json.loads(receipt.read_text())
        cases = value.get('cases', [])
        status['originalRunnerReceipt'] = {'path': str(receipt), 'sha256': digest(receipt), 'head': value.get('head'), 'browser': value.get('browser'), 'caseCount': len(cases), 'passed': sum(case.get('status') == 'passed' for case in cases), 'failed': [case for case in cases if case.get('status') != 'passed'], 'serviceMode': value.get('service', {}).get('mode'), 'sourceStability': value.get('sourceStability'), 'sourceFileCount': len(value.get('sourceFiles', {}))}
        status['originalRunnerReceipt']['productionStability'] = value.get('service', {}).get('production', {}).get('stability')
        status['originalRunnerReceipt']['serviceClosed'] = value.get('service', {}).get('owner', {}).get('closed')
    observation = OUT / 'profile' / 'observer-status.json'
    if observation.is_file():
        value = json.loads(observation.read_text())
        status['observation'] = {'path': str(observation), 'sha256': digest(observation), 'originalFillCalls': value.get('originalFillCalls'), 'profiledFills': value.get('profiledFills'), 'cpuProfile': value.get('cpuProfile'), 'trace': value.get('trace'), 'errors': value.get('errors'), 'browserClosed': value.get('browserClosed')}
    evidence = status.get('observation', {})
    original_receipt = status.get('originalRunnerReceipt', {})
    stability = original_receipt.get('sourceStability') or {}
    stable = status['headAfter'] == HEAD and not status['statusAfter'] and status['sourceSha256Before'] == status['sourceSha256After']
    original_binding = original_receipt.get('head') == HEAD and original_receipt.get('serviceMode') == 'runner-owned-production-static' and original_receipt.get('sourceFileCount', 0) > 0 and stability.get('status') == 'passed' and stability.get('beforeSha256') == stability.get('afterSha256') and bool(stability.get('beforeSha256'))
    original_binding = original_binding and (original_receipt.get('productionStability') or {}).get('status') == 'passed' and original_receipt.get('serviceClosed') is True
    status['sourceStable'] = stable
    status['originalReceiptBindingVerified'] = original_binding
    status['diagnosticState'] = 'captured' if (stable and original_binding and evidence.get('originalFillCalls') == 1 and evidence.get('profiledFills') == 1 and evidence.get('cpuProfile') and evidence.get('trace') and not evidence.get('errors') and evidence.get('browserClosed')) else 'failed-to-capture'
except Exception as error:
    status.update(diagnosticState='failed-to-capture', error=repr(error))
finally:
    if process is not None and process.poll() is None:
        status['ownedChildRequiredCleanup'] = True
        try:
            os.killpg(process.pid, signal.SIGTERM)
            process.wait(10)
        except ProcessLookupError:
            pass
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(10)
    status['supervisorChildRetired'] = process is None or process.poll() is not None
    shutil.rmtree(temporary)
    status['ownedTemporaryRemoved'] = not temporary.exists()
    status['finishedAt'] = now()
    save()
    print(json.dumps({key: value for key, value in status.items() if key not in ('sourceSha256Before', 'sourceSha256After', 'configuredEnvironment')}, indent=2), flush=True)

raise SystemExit(0 if status.get('diagnosticState') == 'captured' else 1)
