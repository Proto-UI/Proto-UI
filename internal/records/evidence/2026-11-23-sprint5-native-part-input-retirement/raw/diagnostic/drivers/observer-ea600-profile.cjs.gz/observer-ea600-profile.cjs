// Diagnostic only. The canonical runner, input, sandbox and deadlines stay unchanged.
// Profiling adds overhead: this run must never be relabelled unobserved acceptance.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { createRequire } = require('node:module');

const root = process.env.PUI_PROFILE_ROOT;
const output = process.env.PUI_PROFILE_OUTPUT;
if (!root || !output) throw new Error('PUI_PROFILE_ROOT and PUI_PROFILE_OUTPUT are required');
fs.mkdirSync(output, { recursive: true });
const projectRequire = createRequire(path.join(root, 'apps/www/package.json'));
const { chromium } = projectRequire('playwright-core');
const sha = (value) => crypto.createHash('sha256').update(value).digest('hex');
const write = (name, value) => fs.writeFileSync(path.join(output, name), JSON.stringify(value, null, 2) + '\n');
const record = {
  kind: 'one-original-fill-cpu-and-rendering-diagnostic',
  canonicalAcceptance: false,
  sourceHead: process.env.CANDIDATE_SHA,
  startedAt: new Date().toISOString(),
  originalFillCalls: 0,
  profiledFills: 0,
  messages: [],
  errors: [],
  scope: 'One original locator.fill, unchanged input and application. CPU sampling and browser tracing add overhead. No timeout, input dispatch, interception, sandbox or owner-lifetime change.',
};
let consumed = false;
const wrappedPrototypes = new WeakSet();
const ownedPages = new WeakSet();
const save = () => write('observer-status.json', record);
save();

async function within(deadline, label, operation) {
  const remaining = deadline - performance.now();
  if (remaining <= 0) throw new Error(label + ': diagnostic deadline exhausted');
  let timer;
  try {
    return await Promise.race([
      operation(),
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(label + ': diagnostic deadline exceeded')), remaining); }),
    ]);
  } finally { clearTimeout(timer); }
}

async function readStream(session, handle, deadline) {
  const chunks = [];
  try {
    while (true) {
      const chunk = await within(deadline, 'IO.read', () => session.send('IO.read', { handle, size: 1024 * 1024 }));
      chunks.push(Buffer.from(chunk.data, chunk.base64Encoded ? 'base64' : 'utf8'));
      if (chunk.eof) break;
    }
  } finally {
    await within(deadline, 'IO.close', () => session.send('IO.close', { handle }));
  }
  return Buffer.concat(chunks);
}

function wrapLocator(page) {
  const prototype = Object.getPrototypeOf(page.locator('html'));
  if (wrappedPrototypes.has(prototype)) return;
  wrappedPrototypes.add(prototype);
  const originalFill = prototype.fill;
  prototype.fill = async function (value, options) {
    const page = this.page();
    if (!ownedPages.has(page) || consumed || typeof value !== 'string' ||
        !value.startsWith("throw new Error('must-not-evaluate');\n")) {
      return originalFill.call(this, value, options);
    }
    consumed = true;
    record.profiledFills++;
    record.input = { bytes: Buffer.byteLength(value), sha256: sha(value), newlineCount: value.split('\n').length - 1 };
    fs.writeFileSync(path.join(output, 'original-fill-input.txt'), value);
    record.precondition = await this.evaluate((textarea) => {
      const panel = textarea.closest('pui-browser-compiler');
      return {
        tag: textarea.tagName,
        sourceEditor: textarea.hasAttribute('data-source-text'),
        phase: panel?.dataset.compilerPhase,
        revision: panel?.dataset.compilerRevision,
        frames: panel?.querySelectorAll('iframe').length,
        selectedTarget: panel?.querySelector('[data-compiler-target]')?.value,
        value: textarea.value,
      };
    });
    if (record.precondition.tag !== 'TEXTAREA' || !record.precondition.sourceEditor ||
        record.precondition.phase !== 'ready' || record.precondition.frames !== 1 ||
        record.precondition.selectedTarget !== 'web-component-source-v1') {
      record.errors.push('Original invalid edit did not reach its required ready source-editor precondition');
      save();
      throw new Error(record.errors.at(-1));
    }
    fs.writeFileSync(path.join(output, 'original-source-before-fill.txt'), record.precondition.value);
    record.precondition.valueSha256 = sha(record.precondition.value);
    record.precondition.valueBytes = Buffer.byteLength(record.precondition.value);
    delete record.precondition.value;

    const session = await page.context().newCDPSession(page);
    let profilerStarted = false, traceStarted = false, originalError;
    let tracingComplete;
    try {
      await this.evaluate((textarea) => {
        const inputEvents = [], longtasks = [];
        const panel = textarea.closest('pui-browser-compiler');
        const oldFrameWindow = panel.querySelector('iframe').contentWindow;
        const oldRevision = panel.dataset.compilerRevision;
        const ids = new WeakMap();
        let nextId = 0;
        const input = (event) => {
          let id = ids.get(event);
          if (id === undefined) { id = ++nextId; ids.set(event, id); }
          inputEvents.push({ id, time: performance.now(), timeStamp: event.timeStamp,
            trusted: event.isTrusted, inputType: event.inputType,
            dataLength: typeof event.data === 'string' ? event.data.length : null });
        };
        textarea.addEventListener('input', input, { capture: true, passive: true });
        let observer;
        try {
          observer = new PerformanceObserver((list) => {
            for (const entry of list.getEntries()) longtasks.push({ start: entry.startTime, duration: entry.duration });
          });
          observer.observe({ type: 'longtask', buffered: false });
        } catch {}
        const messages = (event) => {
          const data = event.data;
          if (!data || typeof data !== 'object' ||
              !['disposed', 'cleanup-error', 'preview-error', 'preview-listener-ready'].includes(data.type)) return;
          // No DOM scans or source reads in any input callback.
          globalThis.__puiProfileMessage({ time: performance.now(), timeOrigin: performance.timeOrigin,
            type: data.type, revision: data.revision, message: data.message, origin: event.origin,
            sourceMatchesOldFrame: event.source === oldFrameWindow,
            matchesOldRevision: data.revision === oldRevision }).catch(() => {});
        };
        window.addEventListener('message', messages, { capture: true, passive: true });
        const stopInput = () => { textarea.removeEventListener('input', input, true); observer?.disconnect(); };
        globalThis.__puiOriginalFillProfile = { inputEvents, longtasks, timeOrigin: performance.timeOrigin,
          oldRevision, stopInput,
          dispose: () => { stopInput(); window.removeEventListener('message', messages, true); } };
        performance.mark('pui-original-fill-profile-ready');
      });
      await session.send('Profiler.enable');
      await session.send('Profiler.setSamplingInterval', { interval: 1000 });
      await session.send('Profiler.start');
      profilerStarted = true;
      tracingComplete = new Promise((resolve) => session.once('Tracing.tracingComplete', resolve));
      await session.send('Tracing.start', {
        categories: 'devtools.timeline,v8,blink.user_timing,disabled-by-default-devtools.timeline',
        transferMode: 'ReturnAsStream',
        options: 'record-as-much-as-possible',
      });
      traceStarted = true;
      record.fillStartedAt = new Date().toISOString();
      const start = performance.now();
      record.originalFillCalls++;
      try { await originalFill.call(this, value, options); }
      catch (error) { originalError = error; record.originalFillError = String(error?.stack ?? error); }
      record.fillDurationMs = performance.now() - start;
      record.fillFinishedAt = new Date().toISOString();
    } catch (error) {
      record.errors.push(String(error?.stack ?? error));
      if (!originalError) originalError = error;
    } finally {
      // All profiler/trace draining shares one 30-second diagnostic budget.
      // Exhaustion records a diagnostic failure; it never resends the original input.
      const drainDeadline = performance.now() + 30000;
      if (profilerStarted) {
        try {
          const result = await within(drainDeadline, 'Profiler.stop', () => session.send('Profiler.stop'));
          write('original-fill.cpuprofile', result.profile);
          record.cpuProfile = { sha256: sha(fs.readFileSync(path.join(output, 'original-fill.cpuprofile'))), nodes: result.profile.nodes.length, samples: result.profile.samples?.length };
        } catch (error) { record.errors.push('Profiler.stop: ' + error); }
      }
      if (traceStarted) {
        try {
          await within(drainDeadline, 'Tracing.end', () => session.send('Tracing.end'));
          const done = await within(drainDeadline, 'Tracing.tracingComplete', () => tracingComplete);
          if (!done?.stream) throw new Error('Tracing returned no stream');
          const bytes = await readStream(session, done.stream, drainDeadline);
          fs.writeFileSync(path.join(output, 'original-fill.trace.json'), bytes);
          record.trace = { bytes: bytes.length, sha256: sha(bytes), dataLossOccurred: done.dataLossOccurred ?? null };
        } catch (error) { record.errors.push('Tracing.end: ' + error); }
      }
      try {
        record.observation = await within(performance.now() + 5000, 'Final observation', () => page.evaluate(() => {
          const observation = globalThis.__puiOriginalFillProfile;
          if (!observation) return null;
          observation.stopInput();
          const panel = document.querySelector('pui-browser-compiler');
          return { inputEvents: observation.inputEvents, longtasks: observation.longtasks,
            timeOrigin: observation.timeOrigin, oldRevision: observation.oldRevision, phase: panel?.dataset.compilerPhase,
            revision: panel?.dataset.compilerRevision, frames: panel?.querySelectorAll('iframe').length,
            diagnostic: panel?.querySelector('[data-compiler-diagnostics]')?.textContent };
        }));
      } catch (error) { record.errors.push('Final observation: ' + error); }
      await within(performance.now() + 2000, 'CDP detach', () => session.detach())
        .catch((error) => record.errors.push(String(error)));
      record.diagnosticFinishedAt = new Date().toISOString();
      save();
    }
    if (originalError) throw originalError;
  };
}

const originalLaunch = chromium.launch.bind(chromium);
chromium.launch = async function (...args) {
  record.launchOptions = args[0];
  if (args[0]?.chromiumSandbox !== true) throw new Error('The original Chromium OS sandbox must remain enabled');
  save();
  const browser = await originalLaunch(...args);
  record.browser = browser.version();
  const originalNewPage = browser.newPage.bind(browser);
  browser.newPage = async function (...options) {
    const page = await originalNewPage(...options);
    ownedPages.add(page);
    await page.exposeBinding('__puiProfileMessage', ({ frame }, payload) => {
      record.messages.push({ frameURL: frame.url(), ...payload });
    });
    wrapLocator(page);
    return page;
  };
  const originalClose = browser.close.bind(browser);
  browser.close = async function (...args) {
    for (const page of browser.contexts().flatMap((context) => context.pages())) {
      await within(performance.now() + 2000, 'Observer cleanup', () =>
        page.evaluate(() => globalThis.__puiOriginalFillProfile?.dispose()))
        .catch((error) => record.errors.push(String(error)));
    }
    try {
      const result = await originalClose(...args);
      record.browserClosed = true;
      return result;
    } catch (error) {
      record.browserClosed = false;
      record.errors.push('Original browser close: ' + String(error?.stack ?? error));
      throw error;
    } finally { record.finishedAt = new Date().toISOString(); save(); }
  };
  return browser;
};
