"""Single bounded survey supervisor; no application edits or test execution."""
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import tempfile

ROOT = Path('/tank/shared/projects/proto-ui-agent/sprint5-ea600-browser-diag-75d5e28a')
OPS = ROOT.with_name(ROOT.name + '-ops')
OUT = OPS / 'listener-style-survey-r1'
NODE = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin/node'
SCRIPT = OPS / 'listener-style-survey.mjs'
lock = (OPS / 'listener-style-survey.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
OUT.mkdir(exist_ok=False)
temporary = tempfile.mkdtemp(prefix='ls75-', dir='/var/tmp')
environment = dict(os.environ)
for key in ('NODE_OPTIONS', 'PUI_BROWSER_URL', 'PUI_BROWSER_PORT'):
    environment.pop(key, None)
environment['TMPDIR'] = temporary
environment['PUI_LISTENER_SURVEY_OUTPUT'] = str(OUT)
receipt = {'kind': 'bounded-read-only-survey-supervisor', 'canonicalAcceptance': False,
           'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'command': [NODE, str(SCRIPT)], 'cwd': str(ROOT), 'workTimeoutSeconds': 175,
           'totalStopBudgetSeconds': 180,
           'scriptSha256': hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),
           'privateTemporary': temporary}


def save():
    (OUT / 'supervisor.json').write_text(json.dumps(receipt, indent=2) + '\n')


with (OUT / 'run.log').open('wb') as log:
    child = subprocess.Popen(receipt['command'], cwd=ROOT, env=environment,
                             stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    receipt['pid'] = child.pid
    receipt['state'] = 'running'
    save()
    try:
        receipt['exitCode'] = child.wait(timeout=175)
        receipt['state'] = 'completed'
    except subprocess.TimeoutExpired:
        receipt['state'] = 'deadline-exceeded'
        os.killpg(child.pid, signal.SIGTERM)
        try:
            receipt['exitCode'] = child.wait(timeout=3)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            try:
                receipt['exitCode'] = child.wait(timeout=2)
            except subprocess.TimeoutExpired:
                receipt['state'] = 'pending-child'
    finally:
        receipt['completedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        status = OUT / 'status.json'
        if status.exists():
            survey = json.loads(status.read_text())
            receipt['surveyState'] = survey.get('state')
            receipt['surveyStatusSha256'] = hashlib.sha256(status.read_bytes()).hexdigest()
            if receipt['state'] in ('deadline-exceeded', 'pending-child') and survey.get('chromePid'):
                # Kill only the actual launchServer process recorded by this child,
                # after matching its non-reusable /proc start time and executable.
                pid = survey['chromePid']
                try:
                    stat = Path(f'/proc/{pid}/stat').read_text()
                    start = stat[stat.rfind(')')+2:].split()[19]
                    executable = Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0', 1)[0].decode()
                    expected = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/playwright-browsers/chromium-1208/chrome-linux64/chrome'
                    if start != survey.get('chromeStartTimeTicks') or executable != expected:
                        raise RuntimeError('Owned Chrome identity no longer matches')
                    if os.getpgid(pid) == pid:
                        os.killpg(pid, signal.SIGKILL)
                    else:
                        os.kill(pid, signal.SIGKILL)
                    receipt['forcedOwnedChromeCleanup'] = {'pid': pid, 'identityMatched': True}
                except FileNotFoundError:
                    receipt['forcedOwnedChromeCleanup'] = {'pid': pid, 'alreadyExited': True}
                except Exception as error:
                    receipt['forcedOwnedChromeCleanup'] = {'pid': pid, 'error': str(error)}
        save()
