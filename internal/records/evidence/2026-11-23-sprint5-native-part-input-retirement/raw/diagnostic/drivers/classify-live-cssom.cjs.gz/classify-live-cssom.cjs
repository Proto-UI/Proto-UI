// Read-only classification of the sealed CSSOM using the two exact frozen helpers.
const fs = require('node:fs');
const crypto = require('node:crypto');
const { createRequire } = require('node:module');
const root = '/tank/shared/projects/proto-ui-agent/sprint5-ea600-browser-diag-75d5e28a';
const out = root + '-ops/listener-style-survey-r1';
const sourceRoot = '/tank/shared/projects/proto-ui-agent/sprint5-input-75d5e28a-ops/pseudo-input-identity-r1';
const req = createRequire(root + '/apps/www/package.json');
const ts = req('typescript');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const cssBytes = fs.readFileSync(out + '/cssom.json');
if (hash(cssBytes) !== '3d98fe16a5480b88b7d4d188c7991357540ed2822b8f832aa3734ff9ebce6d38') throw Error('CSSOM bytes changed');
const css = JSON.parse(cssBytes);
const sources = [
  ['old', 'before-modules.ts', '075436cbcf17fdcb7ef8e0983048bd2784f993f65f5579b936a7fb1b24172811'],
  ['candidate', 'candidate-modules.ts', '4406d1a05d0249635250457562a843e0ed247eb2855c5abdcc4ed76bcf8c5bfa'],
];
const functions = {}, sourceRecords = {};
for (const [name, file, expected] of sources) {
  const bytes = fs.readFileSync(sourceRoot + '/' + file);
  if (hash(bytes) !== expected) throw Error('Frozen source mismatch: ' + file);
  const ast = ts.createSourceFile(file, bytes.toString('utf8'), ts.ScriptTarget.Latest, true);
  const selected = ast.statements.filter(node => ts.isFunctionDeclaration(node) &&
    ['skipSelectorLiteral', 'selectorMayDependOnInputState'].includes(node.name?.text));
  if (selected.length !== 2) throw Error('Expected exactly two original helper declarations');
  const helpers = selected.map(node => node.getText(ast)).join('\n');
  const js = ts.transpileModule(helpers, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText;
  functions[name] = new Function(js + '\nreturn selectorMayDependOnInputState;')();
  sourceRecords[name] = { file: sourceRoot + '/' + file, sha256: expected, helperSha256: hash(helpers) };
}
const ruleKey = (sheet, route) => sheet + ':' + route.join('/');
const byPath = new Map(css.rules.map(rule => [ruleKey(rule.sheet, rule.path), rule]));
const changed = [], remaining = [], oldHits = [], perSheet = {};
let styleRules = 0;
for (const rule of css.rules) {
  if (rule.type !== 1 || typeof rule.selector !== 'string') continue;
  styleRules++;
  let selector = rule.selector;
  const parent = rule.path.length > 1 ? byPath.get(ruleKey(rule.sheet, rule.path.slice(0,-1))) : null;
  if (parent?.type === 1) selector = selector.replaceAll('&', ':is(' + parent.selector + ')');
  const old = functions.old(selector), candidate = functions.candidate(selector);
  const summary = perSheet[rule.sheet] ??= { sheet: rule.sheet, href: css.sheets[rule.sheet].href,
    disabled: css.sheets[rule.sheet].disabled, styleRules: 0, oldHits: 0, candidateHits: 0 };
  summary.styleRules++; summary.oldHits += Number(old); summary.candidateHits += Number(candidate);
  if (!old && !candidate) continue;
  const row = { sheet: rule.sheet, href: summary.href, path: rule.path, rawSelector: rule.selector,
    selector, old, candidate, declarations: rule.declarations ?? [] };
  if (old) oldHits.push(row);
  if (old !== candidate) changed.push(row);
  if (candidate) remaining.push(row);
}
const report = { kind: 'exact-helper-classification-of-live-cssom', canonicalAcceptance: false,
  cssom: { file: out + '/cssom.json', bytes: cssBytes.length, sha256: hash(cssBytes), errors: css.errors },
  compiler: { package: 'typescript', version: ts.version }, sources: sourceRecords,
  summary: { sheets: css.sheets.length, allRules: css.rules.length, styleRules,
    oldHits: oldHits.length, candidateHits: remaining.length, changedRules: changed.length },
  perSheet: Object.values(perSheet), changed, remaining,
  scope: 'Only the original selectorMayDependOnInputState and skipSelectorLiteral declarations are executed. CSSStyleRule parent nesting substitutes one immediate parent exactly as the runtime does. This is an offline counterfactual classification of the existing live CSSOM; it is not a new browser execution, a complete collectEntryStyleDependencies execution, or canonical acceptance.' };
const target = out + '/helper-classification.json';
fs.writeFileSync(target, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
const bytes = fs.readFileSync(target);
console.log(JSON.stringify({ path: target, bytes: bytes.length, sha256: hash(bytes), summary: report.summary,
  changedSelectors: changed.map(rule => rule.selector), remainingSelectors: remaining.map(rule => rule.selector) }));
