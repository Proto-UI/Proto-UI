// Diagnostic inventory only: no fill, click, focus, event dispatch, profiler or app mutation.
import { createHash } from 'node:crypto';
import { execFile } from 'node:child_process';
import { createRequire } from 'node:module';
import { promisify } from 'node:util';
import { readFileSync, writeFileSync, lstatSync, readdirSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const ROOT = '/tank/shared/projects/proto-ui-agent/sprint5-ea600-browser-diag-75d5e28a';
const OPS = ROOT + '-ops';
const HEAD = 'ea60064882924eb455e1dfc3ff7de55a32de4558';
const CHROME = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/playwright-browsers/chromium-1208/chrome-linux64/chrome';
const OUT = process.env.PUI_LISTENER_SURVEY_OUTPUT;
if (OUT !== path.join(OPS, 'listener-style-survey-r1')) throw new Error('Unexpected survey output');
const started = performance.now();
const operationDeadline = started + 125_000;
const finalDeadline = started + 170_000;
const objectGroup = 'ea600-listener-survey';
const selector = 'pui-browser-compiler[data-prototype-id="base-button"] [data-source-text]';
const hash = value => createHash('sha256').update(value).digest('hex');
const exec = promisify(execFile);
const json = file => JSON.parse(readFileSync(file, 'utf8'));
const write = (name, value) => writeFileSync(path.join(OUT, name), JSON.stringify(value, null, 2) + '\n');
const record = {
  kind: 'read-only-listener-and-live-cssom-survey', canonicalAcceptance: false,
  expectedHead: HEAD, startedAt: new Date().toISOString(), errors: [],
  actions: { input: 0, click: 0, fill: 0, focus: 0, dispatch: 0, profile: 0 },
  scope: 'One navigation to the unchanged production page. Inspect the initial hydrated page without opening the compiler or reproducing the prior r11 ready state. CDP listener and closure inspection may retain objects temporarily and is diagnostic only. Only N/te/je closure fields and short target attributes are emitted. No product callbacks or getters are invoked by the scope reader.',
  browserClosed: false, serviceClosed: false,
};
let server, browserServer, browser, session;
const save = () => write('status.json', record);
async function bounded(label, fn, deadline = operationDeadline) {
  const remaining = deadline - performance.now();
  if (remaining <= 0) throw new Error(label + ': deadline exhausted');
  let timer;
  try {
    return await Promise.race([fn(), new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(label + ': deadline exceeded')), remaining);
    })]);
  } finally { clearTimeout(timer); }
}
const command = async (...args) => (await bounded('git ' + args.join(' '), () => exec('git', args, {
  cwd: ROOT, timeout: 15_000, maxBuffer: 2 * 1024 * 1024,
}), finalDeadline)).stdout.trim();
const sourceFiles = [
  'apps/www/src/components/PrototypePreviewer/browser-compiler-panel.ts',
  'apps/www/src/components/PrototypePreviewer/compiled-revision-session.ts',
  'apps/www/src/components/PrototypePreviewer/compiled-preview-sandbox.ts',
  'apps/www/astro.config.mjs', 'apps/www/package.json',
  'packages/compiler/test/browser-source-input.test.ts',
  'scripts/analysis/browser-compiler-browser.mts', 'scripts/compiler/browser-production.mjs',
  'scripts/compiler/browser-inputs.mjs', 'scripts/compiler/browser-evidence.mjs',
  '.github/workflows/compiler-browser-acceptance.yml', 'pnpm-lock.yaml', 'package.json',
  'scripts/test/sprint3-consumer-evidence.mjs', 'scripts/test/sprint3-source-server.mjs',
];
function sourceHashes() {
  return Object.fromEntries(sourceFiles.map(name => [name, hash(readFileSync(path.join(ROOT, name)))]));
}
const manifestPath = path.join(OPS, 'profile-original-fill-r1/browser/production/dist-files.json');
const manifestRaw = readFileSync(manifestPath);
if (hash(manifestRaw) !== '0818cb7166cd03cf246e21f72b7e4001cae2f4b35ea4e11712ce83fe1cba7f72') throw new Error('Prior seal mismatch');
const sealed = JSON.parse(manifestRaw);
function verifyDist(deadline) {
  const found = [];
  const visit = (directory, prefix = '') => {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      if (performance.now() >= deadline) throw new Error('Dist verification deadline');
      const relative = prefix + entry.name;
      if (entry.isDirectory()) visit(path.join(directory, entry.name), relative + '/');
      else {
        if (!entry.isFile()) throw new Error('Nonregular production path: ' + relative);
        found.push(relative);
      }
    }
  };
  const dist = path.join(ROOT, 'apps/www/dist');
  visit(dist);
  if (JSON.stringify(found.sort()) !== JSON.stringify(Object.keys(sealed).sort())) throw new Error('Dist path set changed');
  let bytes = 0;
  for (const name of found) {
    if (performance.now() >= deadline) throw new Error('Dist digest deadline');
    const full = path.join(dist, name);
    if (!lstatSync(full).isFile()) throw new Error('Nonregular sealed file');
    const raw = readFileSync(full), expected = sealed[name];
    if (raw.length !== expected.bytes || hash(raw) !== expected.sha256) throw new Error('Dist bytes changed: ' + name);
    bytes += raw.length;
  }
  return { files: found.length, bytes, manifestSha256: hash(manifestRaw), allExact: true };
}
const send = (method, params = {}) => bounded(method, () => session.send(method, params));
const shortNodeFunction = `function(editor) {
  if (this === window) return {kind:'window'};
  if (!this || typeof this.nodeType !== 'number') return {kind:'non-node'};
  const attrs = {};
  if (this.nodeType === 1) for (const key of ['id','class','role','data-demo-ref','data-prototype-id']) {
    const value = Element.prototype.getAttribute.call(this,key);
    if (value !== null) attrs[key] = value.slice(0,160);
  }
  return {kind:'node', nodeType:this.nodeType, localName:this.localName ?? null,
    isConnected:this.isConnected, attrs, isEditor:this===editor,
    containsEditor:Node.prototype.contains.call(this,editor)};
}`;
async function describeNode(objectId, editorId) {
  const result = await send('Runtime.callFunctionOn', {
    objectId, functionDeclaration: shortNodeFunction,
    arguments: [{ objectId: editorId }], returnByValue: true, objectGroup,
  });
  if (result.exceptionDetails) return { unavailable: true, exception: result.exceptionDetails.text };
  return result.result.value;
}
async function readClosure(handler, editorId) {
  const fields = {};
  if (!handler?.objectId) return { available: false, reason: 'No handler RemoteObject' };
  try {
    const properties = await send('Runtime.getProperties', { objectId: handler.objectId, ownProperties: true });
    const scopes = properties.internalProperties?.find(item => item.name === '[[Scopes]]')?.value;
    if (!scopes?.objectId) return { available: false, reason: 'No [[Scopes]] internal property' };
    const list = await send('Runtime.getProperties', { objectId: scopes.objectId, ownProperties: true });
    const entries = list.result.filter(item => /^\d+$/.test(item.name)).sort((a,b) => Number(a.name)-Number(b.name));
    const inspected = [];
    for (const entry of entries) {
      if (!entry.value?.objectId) continue;
      const description = entry.value.description ?? '';
      // Global scope is outside the requested three captured fields.
      if (/^Global\b/.test(description)) continue;
      const values = await send('Runtime.getProperties', { objectId: entry.value.objectId, ownProperties: true });
      inspected.push({ index: Number(entry.name), description });
      for (const name of ['N','te','je']) {
        if (Object.hasOwn(fields, name)) continue;
        const descriptor = values.result.find(item => item.name === name);
        if (!descriptor) continue;
        const value = descriptor.value;
        if (!value) { fields[name] = { available: false, reason: 'Accessor or unavailable descriptor' }; continue; }
        if (name === 'N') {
          fields[name] = value.subtype === 'node' && value.objectId
            ? { available: true, target: await describeNode(value.objectId, editorId), scopeIndex: Number(entry.name) }
            : { available: false, type: value.type, subtype: value.subtype ?? null, reason: 'Captured value is not a DOM node' };
        } else fields[name] = value.type === 'boolean'
          ? { available: true, value: value.value, scopeIndex: Number(entry.name) }
          : { available: false, type: value.type, reason: 'Captured value is not boolean' };
      }
      if (Object.keys(fields).length === 3) break;
    }
    return { available: true, inspectedScopes: inspected, fields };
  } catch (error) { return { available: false, error: String(error), fields }; }
}

try {
  record.headBefore = await command('rev-parse', 'HEAD');
  record.gitStatusBefore = await command('status', '--porcelain');
  if (record.headBefore !== HEAD || record.gitStatusBefore) throw new Error('Checkout is not the clean exact head');
  record.sourceBefore = sourceHashes();
  record.distBefore = verifyDist(operationDeadline);
  record.scriptSha256 = hash(readFileSync(new URL(import.meta.url)));
  save();
  const { startOwnedPreview } = await import(pathToFileURL(path.join(ROOT, 'scripts/test/sprint3-consumer-evidence.mjs')));
  server = await bounded('owned preview', () => startOwnedPreview(path.join(ROOT,'apps/www/dist'), HEAD, path.join(OUT,'requests.jsonl')));
  record.serviceUrl = server.url;
  const require = createRequire(path.join(ROOT,'apps/www/package.json'));
  const { chromium } = require('playwright-core');
  browserServer = await bounded('Chrome launch', () => chromium.launchServer({ executablePath: CHROME, headless: true, chromiumSandbox: true, timeout: 25_000 }));
  record.chromePid = browserServer.process().pid;
  const processStat = readFileSync(`/proc/${record.chromePid}/stat`, 'utf8');
  record.chromeStartTimeTicks = processStat.slice(processStat.lastIndexOf(')')+2).split(' ')[19];
  save();
  browser = await bounded('owned Chrome connection', () => chromium.connect(browserServer.wsEndpoint(), { timeout: 10_000 }));
  record.browserVersion = browser.version();
  const page = await browser.newPage({ viewport: { width: 1280, height: 1000 } });
  session = await page.context().newCDPSession(page);
  const scripts = new Map();
  session.on('Debugger.scriptParsed', data => scripts.set(data.scriptId, { url: data.url }));
  await send('Debugger.enable');
  await send('Runtime.enable');
  await bounded('page navigation', () => page.goto(server.url + '/en/ui-libraries/base/button/', { waitUntil: 'domcontentloaded', timeout: 45_000 }));
  await bounded('read-only hydration wait', () => page.waitForFunction(selector =>
    document.readyState === 'complete' && !!customElements.get('pui-browser-compiler') && !!document.querySelector(selector), selector, { timeout: 25_000 }));
  record.pageState = await bounded('page state', () => page.evaluate(selector => {
    const editor = document.querySelector(selector), panel = editor?.closest('pui-browser-compiler');
    return { url: location.href, readyState: document.readyState, timeOrigin: performance.timeOrigin,
      performanceNow: performance.now(), compilerPhase: panel?.dataset.compilerPhase ?? null,
      compilerRevision: panel?.dataset.compilerRevision ?? null, panelHidden: panel?.hidden ?? null,
      editorCount: document.querySelectorAll(selector).length, iframeCount: panel?.querySelectorAll('iframe').length ?? null,
      activeElement: document.activeElement?.localName ?? null };
  }, selector));
  if (record.pageState.editorCount !== 1) throw new Error('Expected one exact source editor');
  const editor = (await send('Runtime.evaluate', { expression: `document.querySelector(${JSON.stringify(selector)})`, objectGroup })).result;
  if (!editor.objectId) throw new Error('No editor object');
  const ancestors = await send('Runtime.callFunctionOn', { objectId: editor.objectId, objectGroup,
    functionDeclaration: `function(){const nodes=[];let n=this;while(n){nodes.push(n);n=n.parentNode ?? (n.nodeType===11?n.host:null)}if(!nodes.includes(document))nodes.push(document);nodes.push(window);return nodes;}` });
  const ancestorProperties = await send('Runtime.getProperties', { objectId: ancestors.result.objectId, ownProperties: true });
  const items = ancestorProperties.result.filter(item => /^\d+$/.test(item.name)).sort((a,b) => Number(a.name)-Number(b.name));
  const inventory = { pageState: record.pageState, ancestors: [], inputListeners: [], limitations: [] };
  for (const item of items) {
    const target = item.value;
    if (!target?.objectId) throw new Error('Missing ancestor RemoteObject');
    const description = await describeNode(target.objectId, editor.objectId);
    let backendNodeId = null;
    if (description.kind === 'node') backendNodeId = (await send('DOM.describeNode', { objectId: target.objectId, depth: 0 })).node.backendNodeId;
    const listeners = await send('DOMDebugger.getEventListeners', { objectId: target.objectId, depth: 1, pierce: false });
    const input = listeners.listeners.filter(listener => listener.type === 'input' &&
      (backendNodeId === null || listener.backendNodeId === undefined || listener.backendNodeId === backendNodeId));
    inventory.ancestors.push({ index: Number(item.name), target: description, backendNodeId,
      inputListenerCount: input.length, excludedDescendantInputListeners: listeners.listeners.filter(x => x.type === 'input').length-input.length });
    for (const listener of input) {
      const scriptUrl = scripts.get(listener.scriptId)?.url ?? null;
      const isXu = scriptUrl?.endsWith('/_astro/site-shadcn-controls.YlYgnKvb.js') && listener.lineNumber === 51 && listener.columnNumber === 49907;
      const row = { ancestorIndex: Number(item.name), type: listener.type, useCapture: listener.useCapture,
        passive: listener.passive, once: listener.once, scriptId: listener.scriptId, scriptUrl,
        lineNumberZeroBased: listener.lineNumber, columnNumberZeroBased: listener.columnNumber,
        backendNodeId: listener.backendNodeId ?? null, matchedProfileXuLocation: !!isXu,
        handlerDescription: (listener.originalHandler ?? listener.handler)?.description?.slice(0,160) ?? null };
      if (isXu) row.closure = await readClosure(listener.originalHandler ?? listener.handler, editor.objectId);
      if (backendNodeId !== null && listener.backendNodeId === undefined) inventory.limitations.push('A node listener lacks backendNodeId; self ownership cannot be filtered independently.');
      inventory.inputListeners.push(row);
    }
  }
  inventory.summary = { inputListeners: inventory.inputListeners.length,
    matchingXu: inventory.inputListeners.filter(row => row.matchedProfileXuLocation).length,
    readableXuClosures: inventory.inputListeners.filter(row => row.matchedProfileXuLocation && row.closure?.available).length };
  write('listeners.json', inventory);
  record.listeners = inventory.summary;
  save();
  const cssom = await bounded('one live CSSOM inventory', () => page.evaluate(() => {
    const roots = [document], rootRecords = [], sheets = [], rules = [], errors = [];
    const ids = new WeakMap(), visited = new WeakSet();
    const short = node => node ? { localName: node.localName ?? null, id: node.id ?? null, class: typeof node.className === 'string' ? node.className.slice(0,160) : null } : null;
    const collect = (sheet, association) => {
      if (!sheet) return;
      if (!ids.has(sheet)) ids.set(sheet, sheets.length);
      const id = ids.get(sheet);
      if (!sheets[id]) sheets[id] = { id, href: sheet.href, disabled: sheet.disabled, media: sheet.media?.mediaText ?? null, ownerNode: short(sheet.ownerNode), associations: [] };
      sheets[id].associations.push(association);
      if (visited.has(sheet)) return;
      visited.add(sheet);
      const walk = (list, trail) => {
        for (let i = 0; i < list.length; i++) {
          if (rules.length >= 30_000) throw new Error('CSSOM rule limit');
          const rule = list[i], route = [...trail,i];
          const row = { sheet: id, path: route, type: rule.type,
            selector: typeof rule.selectorText === 'string' ? rule.selectorText : null,
            condition: typeof rule.conditionText === 'string' ? rule.conditionText : null,
            name: typeof rule.name === 'string' ? rule.name : null };
          if (rule.style) row.declarations = Array.from(rule.style, property => ({ property, value: rule.style.getPropertyValue(property), priority: rule.style.getPropertyPriority(property) }));
          rules.push(row);
          if (rule.styleSheet) collect(rule.styleSheet, { importedBy: id, path: route });
          if (rule.cssRules) walk(rule.cssRules, route);
        }
      };
      try { walk(sheet.cssRules, []); } catch (error) { errors.push({ sheet: id, error: String(error) }); }
    };
    for (let cursor = 0; cursor < roots.length; cursor++) {
      if (roots.length > 200) throw new Error('Shadow-root inventory limit');
      const root = roots[cursor];
      rootRecords.push({ id: cursor, kind: root === document ? 'document' : 'open-shadow-root', host: short(root.host) });
      const regular = root === document ? Array.from(document.styleSheets) : Array.from(root.querySelectorAll('style,link[rel="stylesheet"]'), node => node.sheet).filter(Boolean);
      regular.forEach(sheet => collect(sheet, { root: cursor, kind: 'regular' }));
      Array.from(root.adoptedStyleSheets ?? []).forEach(sheet => collect(sheet, { root: cursor, kind: 'adopted' }));
      for (const element of root.querySelectorAll('*')) if (element.shadowRoot) roots.push(element.shadowRoot);
    }
    return { capturedAt: new Date().toISOString(), roots: rootRecords, sheets, rules, errors,
      scope: 'Readable document and open-shadow-root regular/adopted CSSOM only. Closed shadows and inaccessible cross-origin sheets are not represented as complete.' };
  }));
  write('cssom.json', cssom);
  record.cssom = { roots: cssom.roots.length, sheets: cssom.sheets.length, rules: cssom.rules.length, errors: cssom.errors };
  record.state = 'observed';
} catch (error) {
  record.state = 'failed'; record.errors.push(String(error));
} finally {
  if (session) {
    try { await bounded('release observer remote objects', () => session.send('Runtime.releaseObjectGroup', { objectGroup }), Math.min(finalDeadline, performance.now()+2_000)); } catch (e) { record.errors.push(String(e)); }
    try { await bounded('detach observer session', () => session.detach(), Math.min(finalDeadline, performance.now()+2_000)); } catch (e) { record.errors.push(String(e)); }
  }
  if (browserServer) {
    try { await bounded('close owned browser server', () => browserServer.close(), Math.min(finalDeadline, performance.now()+10_000)); record.browserClosed = true; }
    catch (e) {
      record.errors.push(String(e));
      try { await bounded('kill owned browser server after close failure', () => browserServer.kill(), Math.min(finalDeadline, performance.now()+5_000)); record.browserKilled = true; }
      catch (killError) { record.errors.push(String(killError)); }
    }
  }
  if (server) {
    try { await bounded('close owned static service', () => server.close(), Math.min(finalDeadline, performance.now()+3_000)); record.serviceClosed = true; }
    catch (e) { record.errors.push(String(e)); }
  }
  try {
    record.headAfter = await command('rev-parse','HEAD');
    record.gitStatusAfter = await command('status','--porcelain');
    record.sourceAfter = sourceHashes();
    record.sourceStable = record.headAfter === HEAD && record.gitStatusAfter === '' && JSON.stringify(record.sourceBefore) === JSON.stringify(record.sourceAfter);
    record.distAfter = verifyDist(finalDeadline);
    record.distStable = JSON.stringify(record.distBefore) === JSON.stringify(record.distAfter);
  } catch (e) { record.errors.push(String(e)); }
  const okay = record.state === 'observed' && record.errors.length === 0 && record.browserClosed && record.serviceClosed && record.sourceStable && record.distStable;
  record.state = okay ? 'captured-read-only-inventory' : 'failed';
  record.completedAt = new Date().toISOString(); record.elapsedMs = performance.now()-started;
  save();
  process.exitCode = okay ? 0 : 1;
}
