from pathlib import Path
import subprocess,json,os,datetime
root=Path('/home/ezra/proto-ui-sprint1-validation-3148794d');out=Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation')
node='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/node/bin/node'
env=os.environ.copy();env.update({'PATH':str(Path(node).parent)+os.pathsep+env['PATH'],'NODE_OPTIONS':'--max-old-space-size=768'})
prefix=['systemd-run','--user','--scope','--property=MemoryMax=1536M','--property=MemorySwapMax=0','--','/home/ezra/.omp/agent/bin/agent-heavy','timeout','--signal=TERM','--kill-after=5s','90s',node]
commands=[('bootstrap-format',['node_modules/prettier/bin/prettier.cjs','--write','apps/www/src/pages/en/test/bootstrap-state-controls.astro','apps/www/src/content/docs/zh-cn/demo-bootstrap-state-controls.browser.test.ts','scripts/test/bootstrap-state-controls-evidence.test.mjs']),('bootstrap-controls',['--test','scripts/test/bootstrap-state-controls-evidence.test.mjs'])]
receipts=[]
for name,cmd in commands:
 args=prefix+cmd;start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt={'args':args,'exit':p.returncode,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};receipts.append(receipt)
 (out/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 print(name,p.returncode,flush=True)
 if p.returncode!=0:break
