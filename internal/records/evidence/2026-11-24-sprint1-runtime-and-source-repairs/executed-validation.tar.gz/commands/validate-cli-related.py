from pathlib import Path
import subprocess,json,os,datetime
root=Path('/home/ezra/proto-ui-sprint1-validation-3148794d');out=Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation')
node='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/node/bin/node'
env=os.environ.copy();env.update({'PATH':str(Path(node).parent)+os.pathsep+env['PATH'],'NODE_OPTIONS':'--max-old-space-size=768'})
args=['systemd-run','--user','--scope','--unit=proto-s1-cli-related-20261123','--property=MemoryMax=1536M','--property=MemorySwapMax=0','--','/home/ezra/.omp/agent/bin/agent-heavy','timeout','--signal=TERM','--kill-after=5s','90s',node,'node_modules/vitest/vitest.mjs','run','packages/cli/test/hook-source-collision-order.test.ts','packages/cli/test/hook-source-export-patterns.test.ts','packages/cli/test/hook-source-lexical-index.test.ts','packages/cli/test/hook-source-projection-accessors.test.ts','packages/cli/test/hook-source-projector-scope.test.ts','packages/cli/test/hook-source-receiver-mutation.test.ts','packages/cli/test/hook-source-resolution-mode.test.ts','packages/cli/test/hook-source-write-index.test.ts','packages/cli/test/lowered-hook-coverage.test.ts','packages/cli/test/prototype-style-tokens.test.ts','packages/cli/test/default-import-hook-binding.test.ts','packages/cli/test/family-style-closure.test.ts','packages/cli/test/brutalist-preset-generator.test.ts','--no-file-parallelism','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/'cli-related-vitest.json')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/'cli-related.log').open('w') as log:p=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'cli-related.receipt.json').write_text(json.dumps({'args':args,'exit':p.returncode,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
print('CLI-RELATED terminal exit',p.returncode)
