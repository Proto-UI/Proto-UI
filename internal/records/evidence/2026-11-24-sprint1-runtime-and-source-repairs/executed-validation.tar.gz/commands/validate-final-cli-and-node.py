from pathlib import Path
import subprocess,json,os,datetime
root=Path('/home/ezra/proto-ui-sprint1-validation-3148794d');out=Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation')
node='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/node/bin/node';env=os.environ.copy();env.update({'PATH':str(Path(node).parent)+os.pathsep+env['PATH'],'NODE_OPTIONS':'--max-old-space-size=768'})

selection=json.loads(subprocess.check_output([node,'--input-type=module','-e',"import {SPRINT1_NODE_SUITES as controls} from './scripts/test/sprint1-evidence.mjs'; console.log(JSON.stringify({controls}));"],cwd=root,env=env,text=True))
cli=['packages/cli/test/'+x+'.test.ts' for x in ['hook-source-export-patterns','hook-source-receiver-mutation','hook-source-write-index','hook-source-projector-scope','prototype-style-tokens','hook-source-resolution-mode','hook-source-collision-order','hook-source-lexical-index','hook-source-projection-accessors']]
jobs=[
 ('cli-related-final',[node,'node_modules/vitest/vitest.mjs','run',*cli,'--no-file-parallelism','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/'cli-related-final-vitest.json')],90),
 ('sprint1-node-controls-final',[node,'--test','--test-reporter=tap',*selection['controls']],90),
]
for name,inner,seconds in jobs:
 args=['systemd-run','--user','--scope','--property=MemoryMax=1536M','--property=MemorySwapMax=0','--','/home/ezra/.omp/agent/bin/agent-heavy','timeout','--signal=TERM','--kill-after=5s',str(seconds)+'s',*inner]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/(name+'.receipt.json')).write_text(json.dumps({'args':args,'exit':p.returncode,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n');print(name,p.returncode,flush=True)
