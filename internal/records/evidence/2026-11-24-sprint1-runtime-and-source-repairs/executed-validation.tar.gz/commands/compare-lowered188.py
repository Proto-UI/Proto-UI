from pathlib import Path
import subprocess,json,os,datetime,hashlib
root=Path('/home/ezra/proto-ui-sprint1-validation-3148794d');out=Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation')
node='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/node/bin/node'
env=os.environ.copy();env.update({'PATH':str(Path(node).parent)+os.pathsep+env['PATH'],'NODE_OPTIONS':'--max-old-space-size=768'})
paths=['packages/cli/src/services/hook-source-summary.ts','packages/cli/src/services/hook-source-module.ts']
candidates={p:(root/p).read_bytes() for p in paths};baseline={p:subprocess.check_output(['git','show','HEAD:'+p],cwd=root) for p in paths}
for p,b in candidates.items():(out/('lowered-candidate-'+Path(p).name+'.before')).write_bytes(b)
source=lambda:{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
def run(name):
 args=['systemd-run','--user','--scope','--property=MemoryMax=1536M','--property=MemorySwapMax=0','--','/home/ezra/.omp/agent/bin/agent-heavy','timeout','--signal=TERM','--kill-after=5s','120s',node,'node_modules/vitest/vitest.mjs','run','packages/cli/test/lowered-hook-coverage.test.ts','--no-file-parallelism','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/(name+'-vitest.json'))]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();before=source()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt={'args':args,'exit':p.returncode,'sourceBefore':before,'sourceAfter':source(),'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'caseTimeoutsUnchanged':True,'comparison':'Original d71 summary+module versus reviewed candidate; only this source pair is swapped; no acceptance verdict is weakened'}
 (out/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(name,p.returncode,flush=True)
 return p.returncode
try:
 for p,b in baseline.items():(root/p).write_bytes(b)
 run('lowered188-d71-baseline')
finally:
 for p,b in candidates.items():(root/p).write_bytes(b)
 (out/'lowered-source-restored.json').write_text(json.dumps({'restored':source(),'expected':{p:hashlib.sha256(b).hexdigest() for p,b in candidates.items()}},indent=2)+'\n')
run('lowered188-candidate')
