from pathlib import Path
import subprocess,json,os,datetime
root=Path('/home/ezra/proto-ui-sprint1-validation-3148794d');out=Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation')
node='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/node/bin/node'
env=os.environ.copy();env.update({'PATH':str(Path(node).parent)+os.pathsep+env['PATH'],'NODE_OPTIONS':'--max-old-space-size=768'})
args=['systemd-run','--user','--scope','--unit=proto-s1-shadow-cache-baseline-20261123','--property=MemoryMax=1536M','--property=MemorySwapMax=0','--','/home/ezra/.omp/agent/bin/agent-heavy','timeout','--signal=TERM','--kill-after=5s','90s',node,'node_modules/vitest/vitest.mjs','run','packages/adapters/web-component/test/shadow-style-artifact.test.ts','packages/adapters/web-component/test/shadow-split-effects.test.ts','--no-file-parallelism','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/'shadow-cache-baseline-vitest.json')]
subprocess.run([node,'node_modules/prettier/bin/prettier.cjs','--write','packages/adapters/web-component/test/shadow-style-artifact.test.ts','packages/adapters/web-component/test/shadow-split-effects.test.ts'],cwd=root,env=env,check=True)
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/'shadow-cache-baseline.log').open('w') as log:p=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'shadow-cache-baseline.receipt.json').write_text(json.dumps({'args':args,'exit':p.returncode,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
print('SHADOW-CACHE-BASELINE terminal exit',p.returncode)
