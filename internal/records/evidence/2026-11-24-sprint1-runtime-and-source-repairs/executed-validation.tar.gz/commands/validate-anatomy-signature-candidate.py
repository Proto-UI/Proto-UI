from pathlib import Path
import subprocess,json,os,datetime
root=Path('/home/ezra/proto-ui-sprint1-validation-3148794d');out=Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation')
node='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/node/bin/node'
env=os.environ.copy();env.update({'PATH':str(Path(node).parent)+os.pathsep+env['PATH'],'NODE_OPTIONS':'--max-old-space-size=768'})
args=['systemd-run','--user','--scope','--unit=proto-s1-anatomy-signature-candidate-20261123','--property=MemoryMax=1536M','--property=MemorySwapMax=0','--','/home/ezra/.omp/agent/bin/agent-heavy','timeout','--signal=TERM','--kill-after=5s','90s',node,'node_modules/vitest/vitest.mjs','run','packages/modules/anatomy/test/subscriber-fanout.test.ts','packages/modules/anatomy/test/contract/anatomy-order.v0.contract.test.ts','packages/runtime/test/contract/anatomy.order-fanout-cost.contract.test.ts','packages/runtime/test/contract/anatomy.domain-fanout-cost.contract.test.ts','packages/runtime/test/contract/anatomy.catalog-lifecycle.contract.test.ts','packages/runtime/test/contract/anatomy.order.v0.contract.test.ts','--no-file-parallelism','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/'anatomy-signature-candidate-vitest.json')]
subprocess.run([node,'node_modules/prettier/bin/prettier.cjs','--write','packages/modules/anatomy/src/impl.ts','packages/modules/anatomy/test/subscriber-fanout.test.ts'],cwd=root,env=env,check=True)
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/'anatomy-signature-candidate.log').open('w') as log:p=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'anatomy-signature-candidate.receipt.json').write_text(json.dumps({'args':args,'exit':p.returncode,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
print('ANATOMY-SIGNATURE-CANDIDATE terminal exit',p.returncode)
