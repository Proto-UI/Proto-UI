from pathlib import Path
import subprocess,json,os,datetime
root=Path('/home/ezra/proto-ui-sprint1-validation-3148794d');out=Path('/home/ezra/proto-ui-sprint1-ready-20261123-56f6684-control/d71-remote-continuation')
node='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/node/bin/node';env=os.environ.copy();env.update({'PATH':str(Path(node).parent)+os.pathsep+env['PATH'],'NODE_OPTIONS':'--max-old-space-size=768'})

pnpm='/home/ezra/.npm/_npx/4fc28b94641d1e5b/node_modules/pnpm/bin/pnpm.cjs'
selection=json.loads(subprocess.check_output([node,'--input-type=module','-e',"import {SPRINT1_INTEGRATION_UNIT_SUITES as integration,SPRINT1_NODE_SUITES as controls} from './scripts/test/sprint1-evidence.mjs'; console.log(JSON.stringify({integration,controls}));"],cwd=root,env=env,text=True))
jobs=[
 ('styles-preset-generate',[node,pnpm,'run','styles:preset:generate'],180),
 ('styles-preset-check',[node,pnpm,'run','check:styles:preset'],180),
 ('sprint1-integration-candidate',[node,'node_modules/vitest/vitest.mjs','run',*selection['integration'],'--no-file-parallelism','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/'sprint1-integration-candidate-vitest.json')],90),
 ('sprint1-node-controls-candidate',[node,'--test','--test-reporter=tap',*selection['controls']],90),
]
for name,inner,seconds in jobs:
 args=['systemd-run','--user','--scope','--property=MemoryMax=1536M','--property=MemorySwapMax=0','--','/home/ezra/.omp/agent/bin/agent-heavy','timeout','--signal=TERM','--kill-after=5s',str(seconds)+'s',*inner]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/(name+'.receipt.json')).write_text(json.dumps({'args':args,'exit':p.returncode,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n');print(name,p.returncode,flush=True)
