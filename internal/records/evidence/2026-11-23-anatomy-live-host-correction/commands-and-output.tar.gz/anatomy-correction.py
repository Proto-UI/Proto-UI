import os,pathlib,subprocess,json,datetime,traceback,hashlib,signal,difflib,shutil
base=pathlib.Path('/tank/shared/projects/proto-ui-agent/compiler-reconcile-cc618');repo=base/'source'
shared=pathlib.Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
logs=base/'anatomy-correction-logs';logs.mkdir(exist_ok=True)
payload=json.loads((base/'anatomy-correction.json').read_text())
status={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':payload['head'],'upstream':payload['upstream'],'steps':[]}
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
env['PATH']=str(shared/'tools/node-v24.22.3-linux-x64/bin')+':'+env.get('PATH','');env['COREPACK_HOME']=str(shared/'corepack-cache')
def save():(base/'anatomy-correction-status.json').write_text(json.dumps(status,indent=2)+'\n')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.run(['git',*args],cwd=repo,env=env,capture_output=True,text=True,check=True,timeout=30).stdout
def run(name,args,timeout=90,expected=0):
 log=logs/(name+'.log');row={'name':name,'command':args,'cwd':str(repo),'state':'running','log':str(log),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};status['steps'].append(row);save()
 with log.open('wb') as out:
  p=subprocess.Popen(args,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=p.pid;save()
  try:code=p.wait(timeout)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   row.update(state='timeout',logSha256=digest(log));save();raise
 row.update(exitCode=code,expectedExitCode=expected,state='passed' if code==expected else 'failed',logSha256=digest(log),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
 if code!=expected:raise RuntimeError(name+' exit '+str(code)+' expected '+str(expected))
try:
 assert git('rev-parse','HEAD').strip()==payload['head'],'source head changed'
 assert not git('status','--porcelain=v1').strip(),'source is not clean'
 status['beforeTree']=git('rev-parse','HEAD^{tree}').strip()
 for entry in payload['files']:
  p=repo/entry['path'];assert p.read_text()==entry['before'],'source drift '+entry['path']
  (logs/(p.name+'.before')).write_text(entry['before'])
 sub=payload['files'][1];(repo/sub['path']).write_text(sub['after'])
 run('new-live-getter-negative-control',['corepack','pnpm@10.32.1','exec','vitest','run',sub['path'],'--maxWorkers=1','--no-file-parallelism','-t',payload['newRegression']],expected=1)
 red=(logs/'new-live-getter-negative-control.log').read_text()
 assert 'expected \"spy\" to be called once' in red and 'FAIL' in red,'negative failed for different reason'
 for entry in payload['files']:(repo/entry['path']).write_text(entry['after'])
 run('format',['corepack','pnpm@10.32.1','exec','prettier','--write',*[entry['path']for entry in payload['files']]],timeout=300)
 status['sourceFilesBefore']={entry['path']:digest(repo/entry['path'])for entry in payload['files']};save()
 suites=['packages/modules/anatomy/test/subscriber-fanout.test.ts','packages/modules/anatomy/test/contract/anatomy-order.v0.contract.test.ts','packages/runtime/test/contract/anatomy.order-fanout-cost.contract.test.ts','packages/runtime/test/contract/anatomy.domain-fanout-cost.contract.test.ts','packages/runtime/test/contract/anatomy.catalog-lifecycle.contract.test.ts']
 run('complete-anatomy-controls',['corepack','pnpm@10.32.1','exec','vitest','run',*suites,'--maxWorkers=1','--no-file-parallelism','--reporter=default','--reporter=json','--outputFile='+str(logs/'complete-anatomy-controls.json')],timeout=90)
 status['sourceFilesAfter']={entry['path']:digest(repo/entry['path'])for entry in payload['files']};assert status['sourceFilesBefore']==status['sourceFilesAfter']
 for entry in payload['files']:
  after=(repo/entry['path']).read_text();(logs/(pathlib.Path(entry['path']).name+'.patch')).write_text(''.join(difflib.unified_diff(entry['before'].splitlines(True),after.splitlines(True),fromfile='a/'+entry['path'],tofile='b/'+entry['path'])))
 git('add','--',*[entry['path']for entry in payload['files']]);status['stagedTree']=git('write-tree').strip()
 (logs/'anatomy-correction.patch').write_text(git('diff','--cached','--binary'))
 status['state']='passed'
except BaseException as e:status.update(state='failed',error=repr(e),traceback=traceback.format_exc())
status['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
