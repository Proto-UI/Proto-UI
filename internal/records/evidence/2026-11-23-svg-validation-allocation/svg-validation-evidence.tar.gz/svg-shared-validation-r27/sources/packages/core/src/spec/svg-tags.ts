import type { SvgTemplateTag } from './template';

// One closed tag schema is shared by ordinary factories and owned snapshots.
// These are tag-specific fields; shared presentation fields are checked by
// the factory without constructing a new set for each node.
export const SVG_TAG_KEYS: Record<SvgTemplateTag, ReadonlyArray<string>> = {
  svg: ['viewBox', 'width', 'height', 'aria-hidden'],
  g: [],
  path: ['d'],
  circle: ['cx', 'cy', 'r'],
  rect: ['x', 'y', 'width', 'height', 'rx', 'ry'],
  line: ['x1', 'y1', 'x2', 'y2'],
  polyline: ['points'],
  ellipse: ['cx', 'cy', 'rx', 'ry'],
  polygon: ['points'],
};

export function isSvgNodeTag(tag: unknown): tag is SvgTemplateTag {
  return typeof tag === 'string' && Object.prototype.hasOwnProperty.call(SVG_TAG_KEYS, tag);
}
