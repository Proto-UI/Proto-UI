from pathlib import Path
import os,json,subprocess,time,hashlib,traceback
B=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
K=B/'continuation-root-analysis-4deb'
E=B/'evidence/continuation-root-4deb/selector-integration-r5-6e2cebee/svg-private-validation-r31'
E.mkdir(exist_ok=False)
N=B/'tools/node-v24.22.3-linux-x64'
env=os.environ.copy();env['PATH']=str(N/'bin')+':'+str(K/'node_modules/.bin')+':'+env.get('PATH','')
s={'state':'running','startedAt':time.time(),'publicWrites':0,'commands':[]}
def save():(E/'receipt.json').write_text(json.dumps(s,indent=2)+'\n')
def run(args,label,timeout=180):
 s['activeCommand']=args;save()
 with (E/(label+'.stdout')).open('w') as out,(E/(label+'.stderr')).open('w') as err:
  start=time.time();p=subprocess.run(args,cwd=K,env=env,stdout=out,stderr=err,text=True,timeout=timeout)
 s['commands'].append({'argv':args,'label':label,'exitCode':p.returncode,'seconds':time.time()-start});s.pop('activeCommand',None);save()
 return p.returncode,(E/(label+'.stdout')).read_text()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
try:
 assert run(['git','rev-parse','HEAD'],'head')[1].strip()=='03fd99367e397182809cc279e167ab7fe16ad1ad'
 assert sha(K/'packages/core/src/spec/template.ts')=='4b13ee47f7bbd06903454a85c8412749e58f1643da7042ad50069c7879ef65d2'
 code,_=run([str(N/'bin/node'),'node_modules/prettier/bin/prettier.cjs','--write','packages/core/src/spec/template.ts','packages/core/src/spec/owned-template-blueprint.ts','packages/core/src/spec/svg-tags.ts'],'format');assert code==0
 paths=['packages/core/src/spec/template.ts','packages/core/src/spec/owned-template-blueprint.ts','packages/core/src/spec/svg-tags.ts']
 s['sourceHashes']={path:sha(K/path) for path in paths}
 s['sourceSha256']=sha(K/'packages/core/src/spec/template.ts')
 for path in paths:
  destination=E/'sources'/path;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes((K/path).read_bytes())
 config={'extends':str(K/'tsconfig.json'),'include':[str(K/path) for path in paths]}
 (E/'scoped-tsconfig.json').write_text(json.dumps(config,indent=2)+'\n')
 s['typeExitCode']=run([str(N/'bin/node'),'node_modules/typescript/bin/tsc','-p',str(E/'scoped-tsconfig.json')],'source-types',120)[0]
 (E/'candidate-template.ts').write_bytes((K/'packages/core/src/spec/template.ts').read_bytes())
 code,diff=run(['git','diff','--','packages/core/src/spec/template.ts','packages/core/src/spec/owned-template-blueprint.ts'],'source-diff');assert code==0
 code,_=run(['git','diff','--check'],'whitespace');assert code==0
 unitCode,_=run([str(N/'bin/node'),'node_modules/vitest/vitest.mjs','run','packages/core/test','--minWorkers=1','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(E/'vitest.json')],'core-tests',240)
 s['unitExitCode']=unitCode
 if (E/'vitest.json').exists():
  report=json.loads((E/'vitest.json').read_text())
  s['unitFileCount']=len(report.get('testResults',[]))
  s['unitTests']={key:report.get(key) for key in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTotalTestSuites','numPassedTestSuites','numFailedTestSuites']}
 code,raw=run([str(N/'bin/node'),'scripts/analysis/package-budgets.mjs','--json'],'package-budgets',240)
 s['budgetExitCode']=code
 report=json.loads(raw);(E/'package-budget-report.json').write_text(raw)
 s['budgets']=[{key:r[key] for key in ['name','gzipBytes','budget','pass','overBudgetBytes','minifiedBytes']} for r in report['results']]
 assert report['source']['stableDuringMeasurement']
 assert sha(K/'packages/core/src/spec/template.ts')==s['sourceSha256']
 assert all(sha(K/path)==value for path,value in s['sourceHashes'].items())
 s['sourceStable']=True
 s['state']='completed';s['finishedAt']=time.time();save()
except BaseException as e:
 s.update(state='failed',error=str(e),traceback=traceback.format_exc(),finishedAt=time.time());save();raise
