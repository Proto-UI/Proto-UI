import * as React from 'react';
import { createPortal } from 'react-dom';
const portal: React.ReactPortal = createPortal(React.createElement('button', null, 'typed'), document.body);
void portal;
