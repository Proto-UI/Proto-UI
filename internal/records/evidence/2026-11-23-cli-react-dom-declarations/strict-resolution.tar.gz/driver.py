from pathlib import Path
import os,json,subprocess,time,hashlib,traceback,shutil
B=Path('/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono')
K=B/'continuation-root-analysis-4deb'
E=B/'evidence/continuation-root-4deb/selector-integration-r5-6e2cebee/cli-types-r20'
E.mkdir(exist_ok=False);C=E/'consumer';C.mkdir()
N=B/'tools/node-v24.22.3-linux-x64'
env=os.environ.copy();env['PATH']=str(N/'bin')+':'+env.get('PATH','')
s={'state':'running','startedAt':time.time(),'publicWrites':0,'scope':'strict React DOM declaration-resolution control; not the complete packed consumer smoke','commands':[]}
def save():(E/'receipt.json').write_text(json.dumps(s,indent=2)+'\n')
def run(args,label,expected=0,cwd=C):
 with (E/(label+'.stdout')).open('w') as out,(E/(label+'.stderr')).open('w') as err:
  start=time.time();p=subprocess.run(args,cwd=cwd,env=env,stdout=out,stderr=err,text=True,timeout=180)
 s['commands'].append({'argv':args,'label':label,'exitCode':p.returncode,'seconds':time.time()-start});save()
 assert p.returncode==expected,(label,p.returncode)
 return (E/(label+'.stdout')).read_text()+(E/(label+'.stderr')).read_text()
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
try:
 s['candidateScriptSha256']=digest(K/'scripts/release/consumer-smoke-cli.mjs')
 assert s['candidateScriptSha256']=='fae1163751ee2c94a0146698420b35e37d18cbc4c62bbb9e8ac43ad0ed1a2040'
 run([str(N/'bin/node'),'--check','scripts/release/consumer-smoke-cli.mjs'],'syntax',cwd=K)
 original=json.loads((K/'scripts/release/consumer-smoke/adapter-types.tsconfig.json').read_text())
 (E/'original-adapter-types.tsconfig.json').write_text(json.dumps(original,indent=2)+'\n')
 original['include']=['probe.tsx']
 (C/'tsconfig.json').write_text(json.dumps(original,indent=2)+'\n')
 (C/'probe.tsx').write_text("import * as React from 'react';\nimport { createPortal } from 'react-dom';\nconst portal: React.ReactPortal = createPortal(React.createElement('button', null, 'typed'), document.body);\nvoid portal;\n")
 manifest={'name':'pui-cli-react-dom-declaration-control','private':True,'type':'module','dependencies':{'@types/react':'19.2.14','react':'19.2.6','react-dom':'19.2.6','typescript':'5.9.3'}}
 (C/'package.json').write_text(json.dumps(manifest,indent=2)+'\n')
 run([str(N/'bin/npm'),'install','--no-audit','--no-fund'],'negative-install')
 shutil.copyfile(C/'package-lock.json',E/'negative-package-lock.json')
 text=run([str(N/'bin/node'),str(C/'node_modules/typescript/bin/tsc'),'-p','tsconfig.json'],'negative-tsc',2)
 assert 'error TS7016' in text and "module 'react-dom'" in text
 manifest['dependencies']['@types/react-dom']='19.2.3'
 (C/'package.json').write_text(json.dumps(manifest,indent=2)+'\n')
 run([str(N/'bin/npm'),'install','--no-audit','--no-fund'],'positive-install')
 shutil.copyfile(C/'package-lock.json',E/'positive-package-lock.json')
 run([str(N/'bin/node'),str(C/'node_modules/typescript/bin/tsc'),'-p','tsconfig.json'],'positive-tsc')
 lock=json.loads((C/'package-lock.json').read_text())
 s['installed']={name:{'version':lock['packages']['node_modules/'+name]['version'],'integrity':lock['packages']['node_modules/'+name].get('integrity')} for name in manifest['dependencies']}
 assert all(s['installed'][name]['version']==version for name,version in manifest['dependencies'].items())
 s['sourceStable']=digest(K/'scripts/release/consumer-smoke-cli.mjs')==s['candidateScriptSha256']
 assert s['sourceStable']
 s['state']='passed';s['finishedAt']=time.time();save()
except BaseException as e:
 s.update(state='failed',error=str(e),traceback=traceback.format_exc(),finishedAt=time.time());save();raise
