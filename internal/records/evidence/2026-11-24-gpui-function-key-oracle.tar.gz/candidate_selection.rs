// Extracted Rust input-selection probe. No GPUI window or event dispatch is replaced or claimed here.
pub const NAMED_KEYS: &[(&str, &str)] = &[
    ("space", " "),
    ("enter", "Enter"),
    ("tab", "Tab"),
    ("escape", "Escape"),
    ("up", "ArrowUp"),
    ("down", "ArrowDown"),
    ("left", "ArrowLeft"),
    ("right", "ArrowRight"),
    ("home", "Home"),
    ("end", "End"),
    ("pageup", "PageUp"),
    ("pagedown", "PageDown"),
    ("backspace", "Backspace"),
    ("delete", "Delete"),
    ("insert", "Insert"),
    // Windows VK_APPS and the native context-menu key use GPUI `menu`.
    ("menu", "ContextMenu"),
    ("back", "BrowserBack"),
    ("forward", "BrowserForward"),
    // GPUI's keystroke parser accepts a bare modifier as the key itself
    // (`Keystroke::parse("shift")`), and its simulated input then fills
    // `key_char` with the modifier's own name. Without these entries that name
    // would leak through as if it were a typed character.
    ("shift", "Shift"),
    ("control", "Control"),
    ("alt", "Alt"),
    ("platform", "Meta"),
    ("function", "Fn"),
];

/// The highest function key GPUI names.
const HIGHEST_FUNCTION_KEY: u8 = 35;

/// Translates a GPUI key name, for the keys the web spells differently.
pub fn named_key(gpui: &str) -> Option<String> {
    if let Some((_, web)) = NAMED_KEYS.iter().find(|(name, _)| *name == gpui) {
        return Some((*web).to_string());
    }
    // `f1` through `f35`. Parsed rather than listed so a new one cannot be
    // half-supported, and bounded so an arbitrary `f<n>` is not invented.
    if let Some(number) = gpui.strip_prefix('f') {
        if let Ok(index) = number.parse::<u8>() {
            if (1..=HIGHEST_FUNCTION_KEY).contains(&index) && !number.starts_with('0') {
                return Some(format!("F{index}"));
            }
        }
    }
    None
}


fn gpui_function_key_input(web_key: &str) -> Option<String> {
    let number = web_key.strip_prefix('F')?;
    let index = number.parse::<u8>().ok()?;
    ((1..=35).contains(&index) && number == index.to_string()).then(|| format!("f{index}"))
}

#[test]
fn source_scan_function_key_inputs_are_canonical_and_bounded() {
    for index in 1..=35 {
        assert_eq!(
            gpui_function_key_input(&format!("F{index}")),
            Some(format!("f{index}"))
        );
    }
    for key in ["F0", "F36", "F01", "F", "F256", "F+1", "F-1", "f10"] {
        assert_eq!(gpui_function_key_input(key), None, "`{key}`");
    }
}

const NOT_A_KEYBOARD_KEY: &[(&str, &str)] = &[(
    "colorScheme",
    "the meta key of a Rule dependency, compared in packages/modules/rule-meta/src/create.ts",
)];


const COMPARED_KEYS: &[&str] = &[" ", "ArrowDown", "ArrowLeft", "ArrowRight", "ArrowUp", "ContextMenu", "End", "Enter", "Escape", "F10", "Home", "PageDown", "PageUp", "Tab", "colorScheme"];

fn input_for_key(key: &String) -> String {
        let gpui_name = NAMED_KEYS
            .iter()
            .find(|(_, web)| web == key)
            .map(|(gpui, _)| (*gpui).to_string())
            .or_else(|| gpui_function_key_input(key))
            .or_else(|| (key.chars().count() == 1).then(|| key.clone()))
            .unwrap_or_else(|| {
                panic!(
                    "`{key}` is compared by a Prototype but has no verified GPUI input spelling; \
                     add a supported input mapping or classify a non-key comparison with a reason"
                )
            });
    gpui_name
}

#[test]
fn actual_fixture_keys_have_inputs_and_existing_portable_spellings() {
    assert_eq!(named_key("f10").as_deref(), Some("F10"));
    for key in COMPARED_KEYS {
        if NOT_A_KEYBOARD_KEY.iter().any(|(entry, _)| entry == key) { continue; }
        let input = input_for_key(&key.to_string());
        let produced = named_key(&input).unwrap_or(input);
        assert_eq!(&produced, key, "input spelling for {key}");
    }
}
