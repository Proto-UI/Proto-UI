import datetime
import hashlib
import json
import os
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
rustc = '/home/ezra/.cargo/bin/rustc'
rustfmt = '/home/ezra/.cargo/bin/rustfmt'
run_env = dict(os.environ)
run_env['RUSTUP_AUTO_INSTALL'] = '0'
manifest = json.loads((ROOT / 'input-manifest.json').read_text())
for name, digest in manifest['sha256'].items():
    if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest:
        raise RuntimeError('Input digest mismatch: ' + name)
receipt = {
    'startedAt': now(),
    'sourceBase': manifest['sourceBase'],
    'inputSha256': manifest['sha256'],
    'scope': 'Rust formatting and extracted input-selection functions only; no Cargo/GPUI build, window dispatch, native device lane, network install or GitHub writes.',
    'commands': [],
}

def run(name, command):
    start = now()
    result = subprocess.run(command, cwd=ROOT, env=run_env, capture_output=True, text=True, timeout=30)
    (ROOT / (name + '.stdout.log')).write_text(result.stdout)
    (ROOT / (name + '.stderr.log')).write_text(result.stderr)
    item = {'name': name, 'command': command, 'startedAt': start, 'finishedAt': now(), 'exitCode': result.returncode}
    receipt['commands'].append(item)
    (ROOT / 'validation-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return result

installed = run('rustup-toolchains', ['/home/ezra/.cargo/bin/rustup', 'toolchain', 'list'])
toolchains = [line.split()[0] for line in installed.stdout.splitlines() if line.strip() and not line.startswith('no installed')]
if installed.returncode or not toolchains:
    raise RuntimeError('No installed Rust toolchain; no installation attempted')
selected = next((name for name in toolchains if name.startswith('stable-')), toolchains[0])
run_env['RUSTUP_TOOLCHAIN'] = selected
receipt['selectedInstalledToolchain'] = selected
for name, command in [('rustc-version', [rustc, '--version']), ('rustfmt-version', [rustfmt, '--version'])]:
    result = run(name, command)
    if result.returncode:
        raise RuntimeError(name + ' unavailable')
    receipt[name] = result.stdout.strip()

if run('rustfmt-format', [rustfmt, '--edition', '2021', 'key_names.rs']).returncode:
    raise RuntimeError('Full changed test did not parse/format')
if run('rustfmt-check', [rustfmt, '--edition', '2021', '--check', 'key_names.rs']).returncode:
    raise RuntimeError('Formatted changed test failed formatter check')
receipt['formattedTestSha256'] = hashlib.sha256((ROOT / 'key_names.rs').read_bytes()).hexdigest()

for kind in ['baseline', 'candidate']:
    binary = kind + '_selection_tests'
    command = [rustc, '--edition=2021', '--test', kind + '_selection.rs', '-o', binary]
    if run(kind + '-compile', command).returncode:
        raise RuntimeError(kind + ' extracted selection failed compilation')
    result = run(kind + '-test', ['./' + binary, '--nocapture'])
    expected = 101 if kind == 'baseline' else 0
    receipt[kind + 'ExpectedExit'] = expected
    receipt[kind + 'ActualExit'] = result.returncode
    if result.returncode != expected:
        raise RuntimeError(kind + ' did not produce the expected discriminating outcome')
    if kind == 'baseline' and '`F10`' not in result.stderr:
        raise RuntimeError('Baseline did not fail for the intended F10 lookup')

receipt.update(finishedAt=now(), result='passed-bounded-format-and-input-selection-controls', nativeGpuiWindowTests='not-run')
(ROOT / 'validation-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
