from pathlib import Path
import gzip, json, subprocess, collections, os

root = Path('/workspace/scratch/62ffef219b8e/proto-ui-sprint1')
out = Path('/workspace/scratch/62ffef219b8e/lifecycle-evidence')
inv = json.loads((out / 'merged-pr-inventory-original.json').read_text())
ids = set(inv['ids'])
source = root / 'internal/records/2026-11-22-sprint-7-history-sources'
index = json.loads((source / 'index.json').read_text())
packed = json.loads(gzip.decompress(b''.join((source / part['path']).read_bytes() for part in index['parts'])))
snapshot = json.loads(gzip.decompress((root / 'internal/records/2026-11-22-sprint-7-history.snapshot.json.gz').read_bytes()))
titles = {row['number']: row for page in snapshot['issuePages'] for row in page['rows']}

def resolve(value):
    if isinstance(value, list):
        return [resolve(item) for item in value]
    if isinstance(value, dict):
        if list(value) == ['$s7text']:
            return packed['strings'][value['$s7text']]
        if list(value) == ['$s7commit']:
            return {'commit': resolve(packed['commits'][value['$s7commit']])}
        return {key: resolve(item) for key, item in value.items()}
    return value

def group(path):
    if path.startswith(('packages/compiler/', 'packages/cli/')):
        return 'compiler-cli'
    if path.startswith(('packages/adapters/', 'packages/runtime/', 'packages/modules/focus/', 'packages/modules/context/', 'packages/modules/state/', 'packages/modules/event/', 'packages/modules/expose/')):
        return 'runtime-adapter-owner'
    if path.startswith(('apps/www/src/components/', 'apps/www/src/override/')):
        return 'website-projection-controls'
    if path.startswith('packages/prototypes/'):
        return 'prototype-components'
    if path.startswith(('packages/modules/material/', 'packages/modules/presentation/', 'packages/modules/positioning/', 'packages/modules/transition/', 'packages/modules/portal/', 'packages/modules/presence/')):
        return 'presentation-geometry-material'
    if path.startswith('packages/'):
        return 'other-foundation-package'
    if path.startswith(('scripts/agent-operations/', 'internal/agent-operations/', 'apps/dcbot/', 'skills/')):
        return 'agent-operations-governance'
    if path.startswith(('.github/', 'scripts/ci/', 'scripts/test/', 'scripts/release/', 'scripts/build/')):
        return 'ci-release-harness'
    if path.startswith(('apps/www/test/', 'apps/www/scripts/')):
        return 'website-evidence-tooling'
    if path.startswith('apps/www/src/content/'):
        return 'documentation-demo'
    if path.startswith(('spec/', 'internal/contracts/')):
        return 'spec-contracts'
    if path.startswith('internal/records/'):
        return 'retained-records'
    return 'other-doc-config'

rows = []
groups = collections.defaultdict(list)
for captured in packed['pullRequests']:
    pr = captured['pullRequest']
    number = pr['number']
    if number not in ids:
        continue
    files = resolve(pr['files']['nodes'])
    grouped = collections.defaultdict(list)
    for file in files:
        grouped[group(file['path'])].append(file['path'])
    for key in grouped:
        groups[key].append(number)
    rows.append({
        'number': number,
        'url': pr['url'],
        'title': titles[number]['title'],
        'originalScopeBody': titles[number]['body'],
        'originalAuditDepth': None,
        'originalAuditDepthReason': 'Original per-PR86/142/173 mapping not recovered; aggregate and401membership preserved.',
        'archivedHead': pr['headRefOid'],
        'archivedBaseRef': pr['baseRefOid'],
        'mergeCommit': (pr.get('mergeCommit') or {}).get('oid'),
        'mergedAt': pr['mergedAt'],
        'filesTotal': pr['files']['totalCount'],
        'filesPresent': len(files),
        'filesTruncated': pr['files']['pageInfo']['hasNextPage'],
        'groups': dict(grouped),
        'changedFiles': files,
        'reviewDisposition': 'not-yet-substantively-rechecked',
    })

env = dict(os.environ, GIT_NO_LAZY_FETCH='1')
shas = sorted({sha for row in rows for sha in [row['archivedHead'], row['mergeCommit']] if sha})
checks = subprocess.check_output(['git', 'cat-file', '--batch-check'], input='\n'.join(shas) + '\n', cwd=root, env=env, text=True)
present = {line.split()[0] for line in checks.splitlines() if ' missing' not in line}
merges = sorted({row['mergeCommit'] for row in rows if row['mergeCommit'] in present})
log = subprocess.check_output(['git', 'log', '--no-walk', '--format=%H%x09%P', *merges], cwd=root, env=env, text=True)
parents = {line.split('\t')[0]: line.split('\t')[1].split() for line in log.splitlines()}
for row in rows:
    row.update(localObjects={'head': row['archivedHead'] in present, 'merge': row['mergeCommit'] in present}, mergeParents=parents.get(row['mergeCommit'], []))
result = {
    'schemaVersion': 1,
    'scope': 'Original401PR inventory with recovered public source boundaries, not historical category reconstruction or correctness acceptance.',
    'sourceArchive': {'file': 'internal/records/2026-11-22-sprint-7-history-sources/index.json', 'archiveSha256': index['archiveSha256']},
    'counts': {'originalTotal': 401, 'originalBoundedStatic': 86, 'originalPartial': 142, 'originalMetadata': 173, 'originalFreshExecutions': 0, 'metadataRecovered': len(rows), 'missingMetadata': sorted(ids - {row['number'] for row in rows})},
    'groups': {key: {'count': len(numbers), 'prs': numbers} for key, numbers in groups.items()},
    'rows': sorted(rows, key=lambda row: row['number']),
}
(out / 'merged-pr-current-boundaries.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print('metadata', len(rows), 'missing', result['counts']['missingMetadata'], 'truncated', sum(row['filesTruncated'] for row in rows), 'absent-head', sum(not row['localObjects']['head'] for row in rows), 'absent-merge', sum(not row['localObjects']['merge'] for row in rows))
print('groups', {key: len(numbers) for key, numbers in groups.items()})
print('ownerPRs', groups['runtime-adapter-owner'])
