// Editable Vue 3 source. Profile: vue-source-v1; no Proto Runtime or Adapter dependency.
// Inline native costs: owner/update queue, constrained state subscriptions, prop resolution/watchers,
// public boundary guards, view commit lifecycle and native element/slot composition.
// Source graph SHA-256: b73c3bc9ba9778927c557752ba5a485793ae406eef1ffc0097945232bc9335d1
import { releaseNativeMeta as __puiVueReleaseMeta } from './.proto-ui/meta/subscription-v1';
import { readNativeWebMeta as __puiVueReadMeta } from './.proto-ui/meta/web-snapshot-v1';
import { subscribeNativeRulePreferences as __puiVueSubscribePreferences, readNativeRulePreference as __puiVueReadPreference } from './.proto-ui/meta/preference-source-v1';


import { createNativeAuthoredHooks as __puiVueCreateAuthored } from './.proto-ui/owner/authored-hooks-v1';
import * as __puiVueVue from 'vue';

import { createNativeStyle as __puiVueCreateStyle, templateStyleTokens as __puiVueTemplateStyleTokens, type NativeStyle as __puiVueNativeStyle, type NativeStyleHandle as __puiVueStyleHandle, type NativeRuleHandle as __puiVueRuleHandle } from './.proto-ui/style/native-v1';
import { createNativeInteraction as __puiVueCreateInteraction, type NativeInteraction as __puiVueNativeInteraction, type NativeFocus as __puiVueFocus, type NativeAccessible as __puiVueAccessible, type NativeObservedState as __puiVueObservedState, type NativeInput as __puiVueInput } from './.proto-ui/interaction/native-e6807d4f71af1465-v2';
import type { NativeModuleCapability as __puiVueModuleCapability } from './.proto-ui/interaction/modules-e6807d4f71af1465-v2';
import { createContextScope as __puiVueCreateContextScope, scopeKey as __puiVueScopeKey, acceptsContextValue as __puiVueAcceptsContextValue, type ContextScope as __puiVueContextScope } from './.proto-ui/context/scope-v1';




type __puiVueDef = Readonly<{ feedback: Readonly<{ style: __puiVueNativeStyle }> }>;
type __puiVueRun = Readonly<{ readonly owner: symbol; readonly feedback: __puiVueDef['feedback'] }>;
type __puiVueStateEvent<T> = { type: 'next'; prev: T; next: T; reason?: unknown } | {type:'disconnect';reason:'unmount'};
type __puiVueSpec = Readonly<{ kind: 'bool' | 'enum' | 'string' | 'number.range' | 'number.discrete'; options?: readonly (string | number)[]; min?: number; max?: number; step?: number; clamp?: boolean }>;
type __puiVuePropSpec = { type: unknown; default?: unknown; empty?: 'accept' | 'fallback' | 'error'; range?: { min?: number; max?: number }; options?: readonly unknown[] };
type __puiVueWatchInfo = { changedKeysAll: string[]; changedKeysMatched: string[] };
export type __puiVuePublicState<T> = { get(): T; subscribe(callback: (event: __puiVueStateEvent<T>) => void): () => void; unsubscribe(off: () => void): void; readonly spec: __puiVueSpec };
type __puiVueState<T> = __puiVuePublicState<T> & { setDefault(next: T): void; set(next: T, reason?: unknown): void };
type __puiVueEpoch = { id: number; active: boolean; committed: boolean };
type __puiVueFrame = { epoch: __puiVueEpoch; slotUsed: boolean };
export type GeneratedProps = {
  "variant"?: "solid" | "surface" | "destructive" | null;
  "color"?: "main" | "mint" | "lavender" | "coral" | "sky" | null;
  "size"?: "default" | "sm" | "lg" | "icon" | null;
  "wrap"?: boolean | null;
  "disabled"?: boolean | null;
};
export type GeneratedResolvedProps = {
  readonly "variant": "solid" | "surface" | "destructive";
  readonly "color": "main" | "mint" | "lavender" | "coral" | "sky";
  readonly "size": "default" | "sm" | "lg" | "icon";
  readonly "wrap": boolean;
  readonly "disabled": boolean;
};
export type GeneratedExposes = {
  readonly "disabled": __puiVuePublicState<boolean>;
  readonly "hovered": __puiVuePublicState<boolean>;
  readonly "focused": __puiVuePublicState<boolean>;
  readonly "focusVisible": __puiVuePublicState<boolean>;
  readonly "focusSelf": (options?: { "reason"?: "programmatic" | "keyboard" | "pointer"; "preventScroll"?: boolean }) => void;
  readonly "pressed": __puiVuePublicState<boolean>;
  readonly "click": { readonly kind: 'event' };
};
export type GeneratedHandle = { update(): void; getExposes(): GeneratedExposes };

// The slot is a real Vue child render, so authored Vue children retain native ownership.
const __puiVueSlotView = __puiVueVue.defineComponent({
  name: 'CompiledSlot', inheritAttrs: false,
  props: { read: { type: Function as __puiVueVue.PropType<() => __puiVueVue.VNodeChild>, required: true } },
  setup(props) { return () => props.read!(); },
});

export const CompiledComponent = __puiVueVue.defineComponent({
  name: "brutalist-button", inheritAttrs: false,
  props: { instanceAssociations: { type: Object as __puiVueVue.PropType<Readonly<{controlLabel?: object | null}>>, default: undefined } },
  emits: ["click"],
  setup(_props, __puiVueContext) {
    // Protocol values intentionally do not enter Vue's reactive state graph.
    const __puiVueInstance = __puiVueVue.getCurrentInstance()!;

    const __puiVueRevision = __puiVueVue.shallowRef(0);
    const __puiVueHostRevision = __puiVueVue.shallowRef(0);
    let __puiVueHostScheduled = false;
    const __puiVuePresent = __puiVueVue.shallowRef(true);
    const __puiVueSlotRevision = __puiVueVue.shallowRef(0);
    let __puiVueDisposed = false, __puiVueDisposing = false, __puiVueInternalTeardown = false;
    let __puiVueQueued = false, __puiVueRequested = false, __puiVueQueueTicket = 0;
    let __puiVueEpochId = 0;
    let __puiVueCurrentEpoch: __puiVueEpoch | undefined;

    const __puiVueLife: Record<'created' | 'mounted' | 'updated' | 'unmounted' | 'beforeDispose', Array<(run: __puiVueRun) => void>> = { created: [], mounted: [], updated: [], unmounted: [], beforeDispose: [] };
    const __puiVueExposes: Record<string, unknown> = Object.create(null);
    const __puiVueStates = new Set<object>();
    const __puiVuePublicStates = new WeakMap<object, object>();
    const __puiVueInternalSubscriptions = new WeakMap<object, (callback: (event: __puiVueStateEvent<unknown>) => void) => () => void>();
    const __puiVueStateCleanup: Array<() => void> = [];
    const __puiVueEvents = new Set<string>();
    const __puiVuePropChecks: Record<string, (value: unknown) => boolean> = {
    ["variant"]: (__puiVueValue: unknown) => (__puiVueValue === "solid" || __puiVueValue === "surface" || __puiVueValue === "destructive"),
    ["color"]: (__puiVueValue: unknown) => (__puiVueValue === "main" || __puiVueValue === "mint" || __puiVueValue === "lavender" || __puiVueValue === "coral" || __puiVueValue === "sky"),
    ["size"]: (__puiVueValue: unknown) => (__puiVueValue === "default" || __puiVueValue === "sm" || __puiVueValue === "lg" || __puiVueValue === "icon"),
    ["wrap"]: (__puiVueValue: unknown) => (typeof __puiVueValue === 'boolean'),
    ["disabled"]: (__puiVueValue: unknown) => (typeof __puiVueValue === 'boolean'),
    };
    const __puiVueMethodChecks: Record<string, { args(args: unknown[]): boolean; result(value: unknown): boolean }> = {
    ["focusSelf"]: { args: (__puiVueArgs: unknown[]) => __puiVueArgs.length <= 1 && (__puiVueArgs[0] === undefined || (__puiVueIsRecord(__puiVueArgs[0]) && Object.keys(__puiVueArgs[0]).every((__puiVueKey0) => ["reason","preventScroll"].includes(__puiVueKey0)) && (!Object.hasOwn(__puiVueArgs[0], "reason") || (__puiVueArgs[0]["reason"] === "programmatic" || __puiVueArgs[0]["reason"] === "keyboard" || __puiVueArgs[0]["reason"] === "pointer")) && (!Object.hasOwn(__puiVueArgs[0], "preventScroll") || (typeof __puiVueArgs[0]["preventScroll"] === 'boolean')))), result: (__puiVueValue: unknown) => __puiVueValue === undefined },
    };
    const __puiVueEventChecks: Record<string, (value: unknown) => boolean> = {
    ["click"]: (__puiVueValue: unknown) => __puiVueValue === undefined,
    };
    const __puiVuePropSpecs: Record<string, __puiVuePropSpec> = Object.create(null);
    const __puiVueDefaults: Array<Record<string, unknown>> = [];
    const __puiVuePreviousValid: Record<string, unknown> = Object.create(null);
    // Setup declarations precede hydration; the final snapshot is validated before created.
    let __puiVueProps: Readonly<GeneratedResolvedProps>;
    let __puiVueRawProps: Record<string, unknown> = Object.create(null);
    let __puiVuePropsWindow: {raw: Readonly<Record<string, unknown>>; resolved: Readonly<GeneratedResolvedProps>} | null = null;
    const __puiVueWatchers: Array<{ keys: readonly string[] | null; active: boolean; callback: (run: __puiVueRun, next: Readonly<GeneratedResolvedProps>, previous: Readonly<GeneratedResolvedProps>, info: __puiVueWatchInfo) => void }> = [];

    const __puiVueStateQueue: Array<() => void> = [];
    let __puiVueEmittingState = false;
    let __puiVueSetup = true;
    let __puiVueRootElement: HTMLElement | null = null;
    let __puiVueRootEpoch: __puiVueEpoch | undefined;

    const __puiVueParentScope = __puiVueVue.inject<__puiVueContextScope | null>(__puiVueScopeKey, null);
    const __puiVueContextChecks = new Map<object, (value: unknown) => boolean>([

    ]);
    const __puiVueScope = __puiVueCreateContextScope({
      getParent: () => __puiVueParentScope, isAlive: () => !__puiVueDisposed,
      invoke: (callback) => { __puiVueAlive(); return callback(); },
      validate: (key, value) => __puiVueContextChecks.get(key)?.(value) === true,
    });
    __puiVueVue.provide(__puiVueScopeKey, __puiVueScope);
    function __puiVueReadContext(run: __puiVueRun, key: object, optional: boolean): unknown {
      __puiVueRequireRun(run); return optional ? __puiVueScope.tryRead(key) : __puiVueScope.read(key);
    }
    function __puiVueUpdateContext(run: __puiVueRun, key: object, value: unknown, optional: boolean): void | boolean {
      __puiVueRequireRun(run); return optional ? __puiVueScope.tryUpdate(key, value) : __puiVueScope.update(key, value);
    }
    function __puiVueReadFrameContext(frame: __puiVueFrame, key: object, optional: boolean): unknown {
      __puiVueActiveFrame(frame); return optional ? __puiVueScope.tryRead(key) : __puiVueScope.read(key);
    }

    let __puiVueCallbackScope: string | undefined;
    function __puiVueInvoke<T>(scope: string, callback: () => T): T {
      __puiVueAlive();
      if (!__puiVueSetup && !__puiVueDisposing && (scope === 'event' || scope === 'expose-method')) __puiVueNotifyProps();
      const previous = __puiVueCallbackScope; __puiVueCallbackScope = scope;
      try { return callback(); } finally { __puiVueCallbackScope = previous; }
    }

    function __puiVueRegisterObservedState<T extends boolean | string | number>(state: __puiVueObservedState<T>): void {
      const subscribers = new Set<(event: __puiVueStateEvent<T>) => void>();
      const projection: __puiVuePublicState<T> = Object.freeze({
        spec: Object.freeze({ kind: typeof state.get() === 'boolean' ? 'bool' as const : typeof state.get() === 'number' ? 'number.discrete' as const : 'string' as const }),
        get() { __puiVuePublicAlive(); return state.get(); },
        subscribe(callback: (event: __puiVueStateEvent<T>) => void) {
          __puiVuePublicAlive();
          const registration = (event: __puiVueStateEvent<T>) => callback(event);
          subscribers.add(registration);
          return () => { if (!__puiVueDisposed && !__puiVueDisposing) subscribers.delete(registration); };
        },
        unsubscribe(off: () => void) { __puiVuePublicAlive(); off(); },
      });
      __puiVueStates.add(state); __puiVuePublicStates.set(state, projection);
      
      __puiVueInternalSubscriptions.set(state, callback => state.subscribe(callback));
      const refresh = state.subscribe((event) => {
        __puiVueStyle.refresh();
        
        __puiVueInteraction.refresh();
        for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(__puiVueStateQueue, __puiVueStateQueue.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!__puiVueEmittingState) {
  __puiVueEmittingState = true;
  const notificationFailures: unknown[] = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < __puiVueStateQueue.length) {
      try { __puiVueStateQueue[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { __puiVueStateQueue.length = 0; __puiVueEmittingState = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
      });
      __puiVueStateCleanup.push(() => { refresh(); subscribers.clear(); });
    }
    const __puiVueInteraction: __puiVueNativeInteraction<__puiVueRun> = __puiVueCreateInteraction<__puiVueRun>({
      ensureSetup(operation) { __puiVueAlive(); if (!__puiVueSetup) throw new Error('[Vue source] ' + operation + ' requires setup'); },
      ensureRuntime(operation) {
        __puiVueAlive();
        if (__puiVueSetup || !__puiVueCallbackScope || __puiVueDisposing && !__puiVueInternalTeardown) throw new Error('[Vue source] ' + operation + ' requires an owned runtime callback');
      },
      ensureEvent(operation) {
        __puiVueAlive();
        if (__puiVueSetup || __puiVueCallbackScope !== 'event' || __puiVueDisposing) throw new Error('[Vue source] ' + operation + ' requires an input callback');
      },
      isAlive: () => !__puiVueDisposed && (!__puiVueDisposing || __puiVueInternalTeardown),
      isSetupComplete: () => !__puiVueSetup,
      isReady: () => !__puiVueSetup && !__puiVueDisposing && !!__puiVueCurrentEpoch?.committed && __puiVuePresent.value,
      invoke: (callback) => __puiVueInvoke('event', callback),
      getRun: () => __puiVueRunValue, getResolvedProps: () => __puiVueProps,
      getAssociations: () => _props.instanceAssociations,

      subscribeState(state, callback) { return __puiVueSubscribeInternal(state, callback); },
      getRoot: () => __puiVueRootEpoch?.active && __puiVueRootEpoch === __puiVueCurrentEpoch ? __puiVueRootElement : null,
      identity: __puiVueScope, getLogicalParent: () => __puiVueParentScope,
      declarations: [],
      tableFamily: undefined,
      getExposes: () => __puiVueExposes,
      registerExpose: (key, value) => {
        if (value && typeof value === 'object' && __puiVueStates.has(value)) __puiVueExposeState(key, value as __puiVueState<unknown>);
        else if (typeof value === 'function') __puiVueDeclare(key, (...args: unknown[]) => { __puiVuePublicAlive(); return __puiVueInvoke('expose-method', () => value(...args)); });
        else __puiVueDeclare(key, value);
      },
      createOwnedState: <T extends boolean | string | number>(name: string, value: T, spec?: __puiVueSpec) => __puiVueCreateState(spec?.kind ?? (typeof value === 'boolean' ? 'bool' : typeof value === 'number' ? 'number.discrete' : 'string'), name, value, spec) as __puiVueState<T>,
      watchState<T>(state: {get(): T}, callback: (run: __puiVueRun, event: __puiVueStateEvent<T>) => void) {
        const off = __puiVueSubscribeInternal(state, event => __puiVueInvoke('state-watch', () => callback(__puiVueRunValue, event)));
        __puiVueStateCleanup.push(off); return off;
      },
      isPropProvided: key => Object.hasOwn(__puiVueRawProps, key),
        setPresent: value => __puiVueSetPresent(__puiVueRunValue, value),
      requestHostUpdate() {
        if (__puiVueHostScheduled || __puiVueDisposed || __puiVueDisposing) return;
        __puiVueHostScheduled = true;
        queueMicrotask(() => { __puiVueHostScheduled = false; if (!__puiVueDisposed && !__puiVueDisposing) __puiVueHostRevision.value += 1; });
      },
      registerGenericObservedState: __puiVueRegisterObservedState,
      emit: key => __puiVueEmit(__puiVueRunValue, key),
    });
    const __puiVueStyle = __puiVueCreateStyle({
      getMeta: (key: string) => key.startsWith('preference.') ? __puiVueReadPreference(__puiVueRootElement?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), key) : __puiVueReadMeta(__puiVueRootElement?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), key), subscribeMeta: (notify: () => void) => { const leases: (() => void)[] = []; try { leases.push(__puiVueSubscribePreferences(__puiVueRootElement?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), ["preference.reducedMotion"], notify)); } catch (error) { __puiVueReleaseMeta([() => { throw error; }, ...leases]); } return () => __puiVueReleaseMeta(leases); },
      ensureSetup() { __puiVueAlive(); if (!__puiVueSetup) throw new Error('[Vue source] style declaration requires setup'); },
      ensureRuntime() { __puiVueAlive(); if (__puiVueSetup) throw new Error('[Vue source] style writes require runtime'); },
      isAlive: () => !__puiVueDisposed && (!__puiVueDisposing || __puiVueInternalTeardown),
      project(tokens) {
        const root = __puiVueRootElement;
        if (!root || !__puiVueRootEpoch?.active || __puiVueRootEpoch !== __puiVueCurrentEpoch) return;
        if (tokens.length) root.setAttribute('data-pui-style', tokens.join(' '));
        else root.removeAttribute('data-pui-style');
      },
    });
    const __puiVueDefValue: __puiVueDef = Object.freeze({ feedback: Object.freeze({ style: __puiVueStyle }) });
    const __puiVueMeta = (key: string) => __puiVueReadMeta(__puiVueRootElement?.ownerDocument ?? (typeof document === 'undefined' ? undefined : document), key);
    const __puiVueAuthored = __puiVueCreateAuthored({ setup() { __puiVueAlive(); if (!__puiVueSetup) throw new Error('Setup capability is closed'); }, borrow(value) {
      const state = value as __puiVueState<unknown>;
      const borrowed = Object.freeze({get: () => state.get(), setDefault: (value: unknown) => state.setDefault(value), set: (value: unknown, reason?: unknown) => state.set(value, reason), watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<unknown>) => void) { if (!__puiVueSetup) throw new Error('State watch requires setup'); const off = __puiVueSubscribeInternal(state, event => __puiVueInvoke('state-watch', () => callback(__puiVueRunValue, event))); __puiVueStateCleanup.push(off); return off; }});
      
      return borrowed;
    } });
    
    const __puiVueRunValue: __puiVueRun = Object.freeze({ owner: Symbol("brutalist-button"), feedback: __puiVueDefValue.feedback });

    function __puiVueIsRecord(value: unknown): value is Record<string, unknown> {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
      const prototype = Object.getPrototypeOf(value);
      return (prototype === Object.prototype || prototype === null) && Reflect.ownKeys(value).every((key) => {
        const descriptor = Object.getOwnPropertyDescriptor(value, key)!;
        return typeof key === 'string' && descriptor.enumerable && Object.hasOwn(descriptor, 'value');
      });
    }
    function __puiVueIsArray(value: unknown): value is unknown[] {
      if (!Array.isArray(value) || Object.keys(value).length !== value.length) return false;
      const prototype = Object.getPrototypeOf(value);
      if (prototype !== Array.prototype && prototype !== null) return false;
      return Reflect.ownKeys(value).every((key) => {
        if (key === 'length') return true;
        const descriptor = Object.getOwnPropertyDescriptor(value, key)!;
        return typeof key === 'string' && /^(0|[1-9]\d*)$/.test(key) && Number(key) < value.length && descriptor.enumerable && Object.hasOwn(descriptor, 'value');
      });
    }

    function __puiVueAlive(): void {
      if (__puiVueDisposed || (__puiVueDisposing && !__puiVueInternalTeardown)) throw new Error('[Vue source] owner is disposed');
    }
    function __puiVuePublicAlive(): void {
      if (__puiVueDisposed || __puiVueDisposing) throw new Error('[Vue source] owner is disposed');
    }
    function __puiVueSubscribeInternal<T>(state: {get(): T}, callback: (event: __puiVueStateEvent<T>) => void): () => void {
      __puiVueAlive();
      const subscribe = __puiVueInternalSubscriptions.get(state);
      if (!subscribe) throw new Error('[State] unknown owner subscription target');
      return subscribe(event => callback(event as __puiVueStateEvent<T>));
    }
    function __puiVueRequireRun(run: __puiVueRun): void {
      __puiVueAlive();
      if (run !== __puiVueRunValue) throw new Error('[Vue source] foreign run handle');
    }
    function __puiVueRequestUpdate(run: __puiVueRun): void {
      __puiVueRequireRun(run);
      if (__puiVueDisposing) return;
      __puiVueRequested = true;

      if (__puiVueQueued) return;
      __puiVueQueued = true;
      const ticket = __puiVueQueueTicket;
      queueMicrotask(() => {
        if (ticket !== __puiVueQueueTicket || __puiVueDisposed || __puiVueDisposing) return;
        __puiVueQueued = false;
        if (!__puiVueRequested) return;
        __puiVueRequested = false;
        if (__puiVuePresent.value) __puiVueRevision.value += 1;
      });
    }
    function __puiVueSetPresent(run: __puiVueRun, present: boolean): void {
      __puiVueRequireRun(run);
      if (__puiVueDisposing) throw new Error('[Vue source] terminal presence is locked');
      if (typeof present !== 'boolean') throw new TypeError('[Vue source] presence must be boolean');
      __puiVuePresent.value = present;
    }
    function __puiVueInvokeLife(kind: keyof typeof __puiVueLife): void {
      if (kind === 'unmounted') {  }
      try { for (const callback of __puiVueLife[kind]) callback(__puiVueRunValue); }
      finally { if (kind === 'unmounted') {  } }
    }
    function __puiVueUnbindRoot(epoch: __puiVueEpoch): void {
      if (__puiVueRootEpoch !== epoch) return;
      const root = __puiVueRootElement;
      
      __puiVueRootElement = null; __puiVueRootEpoch = undefined;
      try { __puiVueInteraction.unmount(); }
      finally { __puiVueStyle.unmount(); root?.removeAttribute('data-pui-style'); }
    }
    function __puiVueCommitUnmount(epoch: __puiVueEpoch): void {
      epoch.active = false;
      __puiVueUnbindRoot(epoch);
      if (!epoch.committed) return;
      epoch.committed = false;
      const previous = __puiVueInternalTeardown;
      __puiVueInternalTeardown = __puiVueDisposing;
      try { __puiVueInvokeLife('unmounted'); } finally { __puiVueInternalTeardown = previous; }
    }
    function __puiVueCreateState(kind: 'bool', semantic: string, initial: boolean): __puiVueState<boolean>;
    function __puiVueCreateState(kind: 'string' | 'enum', semantic: string, initial: string, options?: Omit<__puiVueSpec, 'kind'>): __puiVueState<string>;
    function __puiVueCreateState(kind: 'number.range' | 'number.discrete', semantic: string, initial: number, options?: Omit<__puiVueSpec, 'kind'>): __puiVueState<number>;
    function __puiVueCreateState(kind: __puiVueSpec['kind'], semantic: string, initial: boolean | number | string, options?: Omit<__puiVueSpec, 'kind'>): __puiVueState<boolean | number | string>;
    function __puiVueCreateState(kind: __puiVueSpec['kind'], semantic: string, initial: boolean | number | string, options: Omit<__puiVueSpec, 'kind'> = {}): unknown {
      __puiVueAuthored.claimState(semantic);
      if (typeof semantic !== 'string' || semantic.length === 0) throw new Error('[Vue source] invalid state semantic');
      const spec: __puiVueSpec = Object.freeze({ ...options, ...(options.options ? { options: Object.freeze([...options.options]) } : {}), kind });
      function validate(value: boolean | number | string): void {
        if (kind === 'bool' ? typeof value !== 'boolean' : kind === 'string' || kind === 'enum' ? typeof value !== 'string' : typeof value !== 'number' || !Number.isFinite(value)) throw new TypeError('[Vue source] invalid state value');
        if (spec.options?.length && (typeof value === 'boolean' || !spec.options.includes(value))) throw new RangeError('[Vue source] state value not in options');
        if (typeof value === 'number' && (kind === 'number.range' || (kind === 'number.discrete' && !spec.options?.length)) && (spec.min !== undefined && value < spec.min || spec.max !== undefined && value > spec.max)) throw new RangeError('[Vue source] state value out of range');
        if (typeof value === 'number' && kind === 'number.discrete' && !spec.options?.length && spec.step !== undefined && spec.step > 0 && !Number.isInteger((value - (spec.min ?? 0)) / spec.step)) throw new RangeError('[Vue source] state value violates step');
      }
      if (kind === 'number.range' && (typeof spec.min !== 'number' || typeof spec.max !== 'number' || Number.isNaN(spec.min) || Number.isNaN(spec.max) || spec.min > spec.max)) throw new RangeError('[Vue source] invalid state range');
      let value = initial;
      if (kind === 'number.range' && spec.clamp && typeof value === 'number') value = Math.min(spec.max!, Math.max(spec.min!, value));
      validate(value);
      const subscribers = new Set<(event: __puiVueStateEvent<boolean | number | string>) => void>();
      const handle: __puiVueState<boolean | number | string> = {
        spec,
        get() { __puiVueAlive(); return value; },
        setDefault(next) { __puiVueAlive(); if (!__puiVueSetup) throw new Error('[State] setDefault requires setup'); validate(next); value = next; },
        set(next, reason) {
          __puiVueAlive(); validate(next);
          if (Object.is(value, next)) return;
          const event: __puiVueStateEvent<boolean | number | string> = { type: 'next', prev: value, next, reason };
          value = next;
          __puiVueStyle.refresh();
          
          __puiVueInteraction.refresh();
          for (const subscriber of Array.from(subscribers)) {
  Object.defineProperty(__puiVueStateQueue, __puiVueStateQueue.length, {value: () => { if (subscribers.has(subscriber)) { subscriber(event); } }, writable:true, enumerable:true, configurable:true});
}
if (!__puiVueEmittingState) {
  __puiVueEmittingState = true;
  const notificationFailures: unknown[] = [];
  let notificationIndex = 0;
  try {
    while (notificationIndex < __puiVueStateQueue.length) {
      try { __puiVueStateQueue[notificationIndex++](); } catch (error) {
        Object.defineProperty(notificationFailures, notificationFailures.length, {value:error, writable:true, enumerable:true, configurable:true});
      }
    }
  } finally { __puiVueStateQueue.length = 0; __puiVueEmittingState = false; }
  if (notificationFailures.length === 1) throw notificationFailures[0];
  if (notificationFailures.length > 1) throw new AggregateError(notificationFailures, '[State] subscriber failures');
}
        },
        subscribe(callback) { __puiVuePublicAlive(); const registration: typeof callback = event => callback(event); subscribers.add(registration); return () => { if (!__puiVueDisposed && !__puiVueDisposing) subscribers.delete(registration); }; },
        unsubscribe(off) { __puiVuePublicAlive(); off(); },
      };
      __puiVueStates.add(handle);
      
      __puiVueInternalSubscriptions.set(handle, callback => {
        const registration: typeof callback = event => callback(event); subscribers.add(registration);
        return () => { subscribers.delete(registration); };
      });
      __puiVueStateCleanup.push(() => subscribers.clear());
      __puiVueAuthored.state(semantic, handle);
      return handle;
    }
    function __puiVueDeclare(key: string, value: unknown): void {
      if (Object.hasOwn(__puiVueExposes, key)) throw new Error('[Vue source] duplicate exposure: ' + key);
      Object.defineProperty(__puiVueExposes, key, { value, enumerable: true });
    }
    function __puiVueExposeState<T>(key: string, handle: __puiVuePublicState<T> | __puiVueObservedState<T>): void {
      if (!__puiVueStates.has(handle)) throw new Error('[Vue source] foreign state handle');
      let projection = __puiVuePublicStates.get(handle);
      if (!projection) {
        if (!('spec' in handle)) throw new Error('[Vue source] unregistered observed state');
        projection = Object.freeze({ get() { __puiVuePublicAlive(); return handle.get(); }, subscribe: handle.subscribe, unsubscribe: handle.unsubscribe, spec: handle.spec });
        __puiVuePublicStates.set(handle, projection);
      }
      __puiVueDeclare(key, projection);
      __puiVueAuthored.introduceObserved(handle);
    }
    function __puiVueExposeMethod<Args extends unknown[], Result>(key: string, callback: (...args: Args) => Result, project?: (value: Result) => Result): void {

      const boundary = __puiVueMethodChecks[key];
      __puiVueDeclare(key, (...args: unknown[]) => {
        __puiVuePublicAlive();
        if (!boundary.args(args)) throw new TypeError('[Vue source] invalid method arguments: ' + key);
        // The specialized predicate just checked the concrete declared argument tuple.
        const checkedArgs = args as Args;
        const result = __puiVueInvoke('expose-method', () => callback(...checkedArgs));
        if (!boundary.result(result)) throw new TypeError('[Vue source] invalid method result: ' + key);
        return project ? project(result) : result;
      });
    }
    function __puiVueExposeEvent(key: string, _spec?: unknown): void {
      __puiVueEvents.add(key);
      __puiVueDeclare(key, Object.freeze({ kind: 'event' as const }));
    }
    function __puiVueEmit(run: __puiVueRun, key: string, payload?: unknown, options?: unknown): void {
      __puiVueRequireRun(run);
      if (!__puiVueEvents.has(key) || !__puiVueEventChecks[key](payload)) throw new TypeError('[Vue source] undeclared event or invalid payload: ' + key);
      __puiVueContext.emit(key as "click", payload, options);
    }
    function __puiVueValidProp(key: string, value: unknown): boolean {
      const spec = __puiVuePropSpecs[key];
      return __puiVuePropChecks[key](value) && (!spec.options || spec.options.includes(value)) && (!spec.range || typeof value === 'number' && value >= (spec.range.min ?? -Infinity) && value <= (spec.range.max ?? Infinity));
    }
    function __puiVueResolveProps(raw: Record<string, unknown>, strict: boolean): Readonly<GeneratedResolvedProps> {
      const next: Record<string, unknown> = Object.create(null);
      for (const key of Object.keys(__puiVuePropSpecs)) {
        const spec = __puiVuePropSpecs[key], provided = Object.hasOwn(raw, key), candidate = raw[key];
        const empty = spec.empty ?? 'fallback';
        if (provided && candidate != null && __puiVueValidProp(key, candidate)) {
          next[key] = candidate; __puiVuePreviousValid[key] = candidate; continue;
        }
        if (provided && candidate == null && empty === 'accept') { next[key] = null; continue; }
        const required = strict && empty === 'error';
        let found = false;
        function take(value: unknown): void {
          if (found || value === undefined || required && value === null || value !== null && !__puiVueValidProp(key, value)) return;
          next[key] = value; found = true;
        }
        if (provided && Object.hasOwn(__puiVuePreviousValid, key)) take(__puiVuePreviousValid[key]);
        for (const layer of __puiVueDefaults) if (Object.hasOwn(layer, key)) take(layer[key]);
        if (Object.hasOwn(spec, 'default')) take(spec.default);
        if (!found && required) throw new TypeError('[Vue source] missing/invalid required prop: ' + key);
        if (!found) next[key] = null;
        if (provided && next[key] !== null) __puiVuePreviousValid[key] = next[key];
      }
      // Every declared key above passed its specialized predicate or canonical null fallback.
      const snapshot = Object.freeze(next) as Readonly<GeneratedResolvedProps>;
      return snapshot;
    }
    function __puiVueDefineProps(declarations: Record<string, __puiVuePropSpec>): void {
      for (const key of Object.keys(declarations)) {
        const incoming = declarations[key], previous = __puiVuePropSpecs[key];
        if (!Object.hasOwn(__puiVuePropChecks, key)) throw new Error('[Vue source] undeclared prop schema');
        const rank = (empty: string) => empty === 'accept' ? 0 : empty === 'error' ? 2 : 1;
        if (previous && incoming.empty && rank(incoming.empty) > rank(previous.empty ?? 'fallback')) throw new Error('[Vue source] props cannot become stricter');
        if (previous?.options && (!incoming.options || previous.options.some((value) => !incoming.options!.includes(value)))) throw new Error('[Vue source] prop options cannot narrow');
        if (previous?.range && ((incoming.range?.min ?? -Infinity) > (previous.range.min ?? -Infinity) || (incoming.range?.max ?? Infinity) < (previous.range.max ?? Infinity))) throw new Error('[Vue source] prop range cannot narrow');
        __puiVuePropSpecs[key] = { ...previous, ...incoming, ...(previous ? { empty: previous.empty ?? 'fallback' } : {}), ...(previous && Object.hasOwn(previous, 'default') ? { default: previous.default } : {}) };
      }
      __puiVueProps = __puiVueResolveProps(__puiVueRawProps, false);
      __puiVueStyle.refresh();
      __puiVueInteraction.refresh();
    }
    function __puiVueSetDefaults(defaults: Record<string, unknown>): void {
      for (const key of Object.keys(defaults)) if (!Object.hasOwn(__puiVuePropSpecs, key)) throw new Error('[Vue source] defaults require a declared prop');
      __puiVueDefaults.unshift({ ...defaults });
      __puiVueProps = __puiVueResolveProps(__puiVueRawProps, false);
      __puiVueStyle.refresh();
      __puiVueInteraction.refresh();
    }
    function __puiVueWatchProps(keys: readonly string[] | null, callback: (run: __puiVueRun, next: Readonly<GeneratedResolvedProps>, previous: Readonly<GeneratedResolvedProps>, info: __puiVueWatchInfo) => void): () => void {
      if (keys && (!keys.length || keys.some((key) => !Object.hasOwn(__puiVuePropSpecs, key)))) throw new Error('[Vue source] watch requires declared prop keys');
      const entry = { keys: keys && [...keys], callback, active: true };
      __puiVueWatchers.push(entry);
      return () => { __puiVueAlive(); entry.active = false; };
    }

    function __puiVueReadProps(run: __puiVueRun): Readonly<GeneratedResolvedProps> { __puiVueRequireRun(run); return __puiVuePropsWindow?.resolved ?? __puiVueProps; }
    function __puiVueReadRawProps(run: __puiVueRun): Readonly<Record<string, unknown>> { __puiVueRequireRun(run); return __puiVuePropsWindow?.raw ?? Object.freeze({ ...__puiVueRawProps }); }
    function __puiVueIsProvided(run: __puiVueRun, key: string): boolean { __puiVueRequireRun(run); return Object.hasOwn(__puiVuePropsWindow?.raw ?? __puiVueRawProps, key); }
    function __puiVueGetHostProps(): Record<string, unknown> {

      // Read the authored host snapshot, bypassing Vue Boolean casts and camelization.
      const raw: Record<string, unknown> = Object.create(null);
      for (const key of Object.keys(__puiVueInstance.vnode.props ?? {})) {
        const value = __puiVueInstance.vnode.props![key];
        if (['key', 'ref', 'ref_for', 'ref_key', 'instanceAssociations', 'instance-associations'].includes(key) || key.startsWith('onVnode')) continue;
        if (!Object.hasOwn(__puiVuePropChecks, key) && (
          ['class', 'hostClass', 'surfaceClass', 'style', 'hostStyle', 'surfaceStyle'].includes(key) ||
          /^on[A-Z]/.test(key) && typeof value === 'function'
        )) continue;
        raw[key] = value;
      }
      return raw;
    }
    function __puiVueNotifyProps(): void {
      if (__puiVueDisposed || __puiVueDisposing) return;
      __puiVueInteraction.refresh();
      const raw = __puiVueGetHostProps();
      const changed = Object.keys({ ...__puiVueRawProps, ...raw }).some((key) => Object.hasOwn(raw, key) !== Object.hasOwn(__puiVueRawProps, key) || !Object.is(raw[key], __puiVueRawProps[key]));
      if (!changed) return;

      const previous = __puiVueProps;
      const next = __puiVueResolveProps(raw, true);
      __puiVueRawProps = raw; __puiVueProps = next;
      __puiVueStyle.refresh();
      __puiVueInteraction.refresh();
      const previousWindow = __puiVuePropsWindow;
      __puiVuePropsWindow = {raw: Object.freeze({...raw}), resolved: next};
      try {
      const all = Object.keys(__puiVuePropSpecs).filter((key) => !Object.is(Reflect.get(previous, key), Reflect.get(next, key)));

      for (const watcher of __puiVueWatchers) {
        if (!watcher.active) continue;
        const matched = watcher.keys ? watcher.keys.filter((key) => all.includes(key)) : all;
        if (matched.length) watcher.callback(__puiVueRunValue, next, previous, { changedKeysAll: all, changedKeysMatched: matched });
      }

      } finally { __puiVuePropsWindow = previousWindow; }
    }
    function __puiVueActiveFrame(frame: __puiVueFrame): void {
      __puiVueAlive();
      if (!frame.epoch.active || frame.epoch !== __puiVueCurrentEpoch || !__puiVuePresent.value) throw new Error('[Vue source] stale view work');
    }
    function __puiVueReadFrameProps(frame: __puiVueFrame): Readonly<GeneratedResolvedProps> { __puiVueActiveFrame(frame); return __puiVueProps; }
    function __puiVueReadFrameRawProps(frame: __puiVueFrame): Readonly<Record<string, unknown>> { __puiVueActiveFrame(frame); return Object.freeze({ ...__puiVueRawProps }); }
    function __puiVueFrameProvided(frame: __puiVueFrame, key: string): boolean { __puiVueActiveFrame(frame); return Object.hasOwn(__puiVueRawProps, key); }
    function __puiVueChildren(input: unknown): __puiVueVue.VNode | string | number | null | __puiVueVue.VNodeArrayChildren {
      if (input === null) return null;
      if (Array.isArray(input)) return input.map(__puiVueChildren);
      if (typeof input === 'string' || typeof input === 'number' || __puiVueVue.isVNode(input)) return input;
      throw new TypeError('[Vue source] invalid template child');
    }
    function __puiVueElement(frame: __puiVueFrame, tag: string, ...args: unknown[]): __puiVueVue.VNode {
      __puiVueActiveFrame(frame);
      let children: unknown = null;
      let attributes: Record<string, string> | null = null;
      if (args.length > 1 || args.length === 1 && args[0] !== null && typeof args[0] === 'object' && !Array.isArray(args[0]) && !__puiVueVue.isVNode(args[0])) {
        if (!__puiVueIsRecord(args[0])) throw new Error('[Vue source] unsupported template props');
        const keys = Object.keys(args[0]);
        if (keys.length) {
          if (keys.length !== 1 || keys[0] !== 'style') throw new Error('[Vue source] unsupported template props');
          attributes = { 'data-pui-style': __puiVueTemplateStyleTokens(args[0].style as __puiVueStyleHandle) };
        }
        children = args.length > 1 ? args[1] : null;
      } else if (args.length) children = args[0];
      const normalized = __puiVueChildren(children);
      return __puiVueVue.h(tag, attributes, normalized ?? undefined);
    }
    function __puiVueSlot(frame: __puiVueFrame): __puiVueVue.VNode {
      __puiVueActiveFrame(frame);
      if (frame.slotUsed) throw new Error('[Vue source] multiple slots are not supported');
      frame.slotUsed = true;
      return __puiVueVue.h(__puiVueSlotView, { read: () => {
        __puiVueSlotRevision.value;
        if (__puiVueDisposed || __puiVueDisposing || !frame.epoch.active || frame.epoch !== __puiVueCurrentEpoch || !__puiVuePresent.value) return null;
        return __puiVueContext.slots.default?.() ?? null;
      } });
    }

    const __puiVueHook0 = (options?: unknown) => (__puiVueAuthored.install({name: "as-button", mode: "once", setup: (options, api) => ((def: __puiVueDef) => {
      // Source "packages/prototypes/base/src/button/button.proto.ts":12:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = ({"kind":"tw","tokens":["select-none"],"groups":["content-selection affordance"]} as const);
const __puiVueCaptureResult = __puiVueStyle.use(__puiVueCaptureArg0); __puiVueAuthored.effect("feedback", __puiVueCaptureResult); __puiVueAuthored.disposer("feedback", __puiVueCaptureResult); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":13:9
      const accessible = __puiVueAuthored.privileged("asAccessible", () => __puiVueInteraction.asAccessible());
      // Source "packages/prototypes/base/src/button/button.proto.ts":15:3
      __puiVueAuthored.privileged("asTrigger", () => __puiVueInteraction.asTrigger());
      // Source "packages/prototypes/base/src/button/button.proto.ts":18:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0: Parameters<typeof __puiVueDefineProps>[0] = { ["disabled"]: { ["type"]: "boolean", ["empty"]: "fallback" } };
const __puiVueCaptureResult = __puiVueDefineProps(__puiVueCaptureArg0); __puiVueAuthored.effect("props", {"op": "define", "specMap": __puiVueCaptureArg0}); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":21:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = { ["disabled"]: false };
const __puiVueCaptureResult = __puiVueSetDefaults(__puiVueCaptureArg0); __puiVueAuthored.effect("props", {"op": "setDefaults", "partial": __puiVueCaptureArg0}); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":26:9
      const disabled = (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "disabled";
const __puiVueCaptureArg1 = false;
const __puiVueCaptureResult = __puiVueCreateState('bool', __puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("state", __puiVueCaptureResult); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":27:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "disabled";
const __puiVueCaptureArg1 = disabled;
const __puiVueCaptureResult = __puiVueExposeState(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("state", {"op": "expose.state", "key": __puiVueCaptureArg0, "handle": __puiVueCaptureArg1}); __puiVueAuthored.introduceObserved(__puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":28:3
      (() => {
const __puiVueCaptureReceiver = accessible;
const __puiVueCaptureArg0 = "disabled";
const __puiVueCaptureArg1 = disabled;
const __puiVueCaptureResult = __puiVueCaptureReceiver.state(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("state", {"op": "a11y.state", "key": __puiVueCaptureArg0, "handle": __puiVueCaptureArg1, "options": undefined}); __puiVueAuthored.introduceObserved(__puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":31:9
      const hovered = (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "hovered";
const __puiVueCaptureArg1 = false;
const __puiVueCaptureResult = __puiVueCreateState('bool', __puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("state", __puiVueCaptureResult); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":32:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "hovered";
const __puiVueCaptureArg1 = hovered;
const __puiVueCaptureResult = __puiVueExposeState(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("state", {"op": "expose.state", "key": __puiVueCaptureArg0, "handle": __puiVueCaptureArg1}); __puiVueAuthored.introduceObserved(__puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":35:9
      const focusable = __puiVueAuthored.privileged("asFocusable", () => __puiVueInteraction.asFocusable(), ["focused","focusVisible","focusable"]);
      // Source "packages/prototypes/base/src/button/button.proto.ts":36:3
      focusable.configure({ ["disabled"]: false });
      // Source "packages/prototypes/base/src/button/button.proto.ts":38:9
      const focused = (focusable)["focused"];
      // Source "packages/prototypes/base/src/button/button.proto.ts":39:9
      const focusVisible = (focusable)["focusVisible"];
      // Source "packages/prototypes/base/src/button/button.proto.ts":42:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "focused";
const __puiVueCaptureArg1 = focused;
const __puiVueCaptureResult = __puiVueExposeState(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("state", {"op": "expose.state", "key": __puiVueCaptureArg0, "handle": __puiVueCaptureArg1}); __puiVueAuthored.introduceObserved(__puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":43:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "focusVisible";
const __puiVueCaptureArg1 = focusVisible;
const __puiVueCaptureResult = __puiVueExposeState(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("state", {"op": "expose.state", "key": __puiVueCaptureArg0, "handle": __puiVueCaptureArg1}); __puiVueAuthored.introduceObserved(__puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":46:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "focusSelf";
const __puiVueCaptureArg1 = (options?: { "reason"?: "programmatic" | "keyboard" | "pointer"; "preventScroll"?: boolean }): void => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":47:5
        if ((disabled.get() as boolean)) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":47:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":48:5
        focusable.focusSelf(options);
      };
const __puiVueCaptureResult = __puiVueExposeMethod(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("context", {"op": "expose.method", "key": __puiVueCaptureArg0, "fn": __puiVueCaptureArg1}); __puiVueAuthored.method(__puiVueCaptureArg0, __puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":52:9
      const pressed = (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "pressed";
const __puiVueCaptureArg1 = false;
const __puiVueCaptureResult = __puiVueCreateState('bool', __puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("state", __puiVueCaptureResult); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":53:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "pressed";
const __puiVueCaptureArg1 = pressed;
const __puiVueCaptureResult = __puiVueExposeState(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("state", {"op": "expose.state", "key": __puiVueCaptureArg0, "handle": __puiVueCaptureArg1}); __puiVueAuthored.introduceObserved(__puiVueCaptureArg1); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":55:9
      const clearTransientInteraction = (reason: string): void => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":56:5
        hovered.set(false, reason);
        // Source "packages/prototypes/base/src/button/button.proto.ts":57:5
        pressed.set(false, reason);
      };
      // Source "packages/prototypes/base/src/button/button.proto.ts":61:3
      __puiVueLife.unmounted.push(() => __puiVueInvoke("unmounted", () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":62:5
        (clearTransientInteraction)("reason: button view unmounted => reset transient interaction");
      }));
      // Source "packages/prototypes/base/src/button/button.proto.ts":66:9
      const syncDisabled = (nextDisabled: boolean): void => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":67:5
        disabled.set(nextDisabled, "reason: sync disabled");
        // Source "packages/prototypes/base/src/button/button.proto.ts":68:5
        focusable.setDisabled(nextDisabled);
        // Source "packages/prototypes/base/src/button/button.proto.ts":69:5
        if (nextDisabled) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":70:7
          (clearTransientInteraction)("reason: button disabled => reset transient interaction");
        }
      };
      // Source "packages/prototypes/base/src/button/button.proto.ts":73:3
      __puiVueLife.created.push((run: __puiVueRun) => __puiVueInvoke("created", () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":74:5
        (syncDisabled)((__puiVueReadProps(run))["disabled"]);
      }));
      // Source "packages/prototypes/base/src/button/button.proto.ts":76:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = ["disabled"];
const __puiVueCaptureArg1 = (_run: __puiVueRun, next: Readonly<GeneratedResolvedProps>) => __puiVueInvoke("props-watch", () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":77:5
        (syncDisabled)((next)["disabled"]);
      });
const __puiVueCaptureResult = __puiVueWatchProps(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("props", {"op": "watch", "keys": __puiVueCaptureArg0, "off": __puiVueCaptureResult}); __puiVueAuthored.disposer("props", __puiVueCaptureResult); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":81:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "click";
const __puiVueCaptureArg1 = { ["payload"]: "void" };
const __puiVueCaptureResult = __puiVueExposeEvent(__puiVueCaptureArg0, __puiVueCaptureArg1); __puiVueAuthored.effect("event", {"op": "expose.event", "key": __puiVueCaptureArg0, "spec": __puiVueCaptureArg1}); __puiVueAuthored.eventKey(__puiVueCaptureArg0); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":83:3
      accessible.action("activate", { ["event"]: "click" });
      // Source "packages/prototypes/base/src/button/button.proto.ts":86:3
      accessible.role("button");
      // Source "packages/prototypes/base/src/button/button.proto.ts":89:3
      accessible.nameFromContent();
      // Source "packages/prototypes/base/src/button/button.proto.ts":91:9
      const activate = (run: __puiVueRun, isCurrent: () => boolean = (): boolean => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":91:83
        return true;
      }): void => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":92:5
        if (((disabled.get() as boolean) || (!(isCurrent)()))) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":92:41
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":93:5
        pressed.set(false, "reason: button activation => pressed");
        // Source "packages/prototypes/base/src/button/button.proto.ts":94:5
        if (((disabled.get() as boolean) || (!(isCurrent)()))) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":94:41
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":95:5
        __puiVueEmit(run, "click");
      };
      // Source "packages/prototypes/base/src/button/button.proto.ts":97:3
      __puiVueAuthored.privileged("asControlLabel", () => __puiVueInteraction.asControlLabel()).target((run: __puiVueRun, request: __puiVueModuleCapability<"control-label-request", __puiVueRun>) => __puiVueInvoke("control-label-target", () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":98:11
        const isCurrent = (): boolean => {
          // Source "packages/prototypes/base/src/button/button.proto.ts":98:29
          return ((!(disabled.get() as boolean)) && request.isCurrent());
        };
        // Source "packages/prototypes/base/src/button/button.proto.ts":99:5
        if ((!(isCurrent)())) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":99:23
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":100:5
        focusable.focusSelf({ ["reason"]: (((request)["source"] === "pointer") ? "pointer" : "programmatic") });
        // Source "packages/prototypes/base/src/button/button.proto.ts":101:5
        if ((isCurrent)()) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":101:22
          (activate)(run, isCurrent);
        }
      }));
      // Source "packages/prototypes/base/src/button/button.proto.ts":107:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "key.down";
const __puiVueCaptureArg1 = (_run: __puiVueRun, ev: __puiVueInput) => __puiVueInvoke("event", () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":108:11
        const detail = ev;
        // Source "packages/prototypes/base/src/button/button.proto.ts":109:5
        if ((disabled.get() as boolean)) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":109:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":110:5
        if ((!(focused.get() as boolean))) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":110:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":111:5
        if (((detail)?.["key"] !== " ")) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":111:30
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":112:5
        ev.control.requestDefaultActionPrevention({ ["reason"]: "button.space-activation", ["source"]: "base-button" });
      });
const __puiVueCaptureResult = __puiVueInteraction.event.onGlobal(__puiVueCaptureArg0, __puiVueCaptureArg1); const __puiVueCaptureOff = () => __puiVueInteraction.releaseListener(__puiVueCaptureResult); __puiVueAuthored.effect("event", {token: __puiVueCaptureResult, off: __puiVueCaptureOff}); __puiVueAuthored.disposer("event", __puiVueCaptureOff); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":119:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "pointer.enter";
const __puiVueCaptureArg1 = () => __puiVueInvoke("event", () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":120:5
        if ((disabled.get() as boolean)) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":120:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":121:5
        hovered.set(true, "reason: button pointer.enter => hovered");
      });
const __puiVueCaptureResult = __puiVueInteraction.event.on(__puiVueCaptureArg0, __puiVueCaptureArg1); const __puiVueCaptureOff = () => __puiVueInteraction.releaseListener(__puiVueCaptureResult); __puiVueAuthored.effect("event", {token: __puiVueCaptureResult, off: __puiVueCaptureOff}); __puiVueAuthored.disposer("event", __puiVueCaptureOff); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":123:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "pointer.leave";
const __puiVueCaptureArg1 = () => __puiVueInvoke("event", () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":124:5
        hovered.set(false, "reason: button pointer.leave => hovered");
        // Source "packages/prototypes/base/src/button/button.proto.ts":125:5
        pressed.set(false, "reason: button pointer.leave => pressed");
      });
const __puiVueCaptureResult = __puiVueInteraction.event.on(__puiVueCaptureArg0, __puiVueCaptureArg1); const __puiVueCaptureOff = () => __puiVueInteraction.releaseListener(__puiVueCaptureResult); __puiVueAuthored.effect("event", {token: __puiVueCaptureResult, off: __puiVueCaptureOff}); __puiVueAuthored.disposer("event", __puiVueCaptureOff); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":127:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "pointer.cancel";
const __puiVueCaptureArg1 = () => __puiVueInvoke("event", () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":128:5
        hovered.set(false, "reason: button pointer.cancel => hovered");
        // Source "packages/prototypes/base/src/button/button.proto.ts":129:5
        pressed.set(false, "reason: button pointer.cancel => pressed");
      });
const __puiVueCaptureResult = __puiVueInteraction.event.on(__puiVueCaptureArg0, __puiVueCaptureArg1); const __puiVueCaptureOff = () => __puiVueInteraction.releaseListener(__puiVueCaptureResult); __puiVueAuthored.effect("event", {token: __puiVueCaptureResult, off: __puiVueCaptureOff}); __puiVueAuthored.disposer("event", __puiVueCaptureOff); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":132:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "press.cancel";
const __puiVueCaptureArg1 = () => __puiVueInvoke("event", () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":133:5
        (clearTransientInteraction)("reason: button press.cancel => reset transient interaction");
      });
const __puiVueCaptureResult = __puiVueInteraction.event.on(__puiVueCaptureArg0, __puiVueCaptureArg1); const __puiVueCaptureOff = () => __puiVueInteraction.releaseListener(__puiVueCaptureResult); __puiVueAuthored.effect("event", {token: __puiVueCaptureResult, off: __puiVueCaptureOff}); __puiVueAuthored.disposer("event", __puiVueCaptureOff); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":137:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "pointer.down";
const __puiVueCaptureArg1 = () => __puiVueInvoke("event", () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":138:5
        if ((disabled.get() as boolean)) {
          // Source "packages/prototypes/base/src/button/button.proto.ts":138:25
          return;
        }
        // Source "packages/prototypes/base/src/button/button.proto.ts":139:5
        pressed.set(true, "reason: button pointer.down => pressed");
      });
const __puiVueCaptureResult = __puiVueInteraction.event.on(__puiVueCaptureArg0, __puiVueCaptureArg1); const __puiVueCaptureOff = () => __puiVueInteraction.releaseListener(__puiVueCaptureResult); __puiVueAuthored.effect("event", {token: __puiVueCaptureResult, off: __puiVueCaptureOff}); __puiVueAuthored.disposer("event", __puiVueCaptureOff); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":141:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "pointer.up";
const __puiVueCaptureArg1 = () => __puiVueInvoke("event", () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":142:5
        pressed.set(false, "reason: button pointer.up => pressed");
      });
const __puiVueCaptureResult = __puiVueInteraction.event.on(__puiVueCaptureArg0, __puiVueCaptureArg1); const __puiVueCaptureOff = () => __puiVueInteraction.releaseListener(__puiVueCaptureResult); __puiVueAuthored.effect("event", {token: __puiVueCaptureResult, off: __puiVueCaptureOff}); __puiVueAuthored.disposer("event", __puiVueCaptureOff); return __puiVueCaptureResult; })();
      // Source "packages/prototypes/base/src/button/button.proto.ts":146:3
      (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = "press.commit";
const __puiVueCaptureArg1 = (run: __puiVueRun) => __puiVueInvoke("event", () => {
        // Source "packages/prototypes/base/src/button/button.proto.ts":147:5
        pressed.set(false, "reason: button press.commit => pressed");
        // Source "packages/prototypes/base/src/button/button.proto.ts":148:5
        (activate)(run);
      });
const __puiVueCaptureResult = __puiVueInteraction.event.on(__puiVueCaptureArg0, __puiVueCaptureArg1); const __puiVueCaptureOff = () => __puiVueInteraction.releaseListener(__puiVueCaptureResult); __puiVueAuthored.effect("event", {token: __puiVueCaptureResult, off: __puiVueCaptureOff}); __puiVueAuthored.disposer("event", __puiVueCaptureOff); return __puiVueCaptureResult; })();
    })(__puiVueDefValue)}, options) as { readonly stateHandles?: Readonly<Record<string, unknown>>; readonly getState?: (name: string) => unknown; readonly getMethod?: (name: string) => unknown; readonly getAsHook?: (name: string) => unknown; readonly getAsHookHandle?: (name: string) => unknown; readonly render?: unknown });
    const __puiVueRenderer = ((): ((frame: __puiVueFrame) => __puiVueVue.VNodeChild) | void => {
      try {
        const renderer = ((def: __puiVueDef) => {
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":77:5
        (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0: Parameters<typeof __puiVueDefineProps>[0] = { ["variant"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["solid", "surface", "destructive"] }, ["color"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["main", "mint", "lavender", "coral", "sky"] }, ["size"]: { ["type"]: "enum", ["empty"]: "fallback", ["options"]: ["default", "sm", "lg", "icon"] }, ["wrap"]: { ["type"]: "boolean", ["empty"]: "fallback" }, ["disabled"]: { ["type"]: "boolean", ["empty"]: "fallback" } };
const __puiVueCaptureResult = __puiVueDefineProps(__puiVueCaptureArg0); __puiVueAuthored.effect("props", {"op": "define", "specMap": __puiVueCaptureArg0}); return __puiVueCaptureResult; })();
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":94:5
        (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = { ["variant"]: "solid", ["color"]: "main", ["size"]: "default", ["wrap"]: false, ["disabled"]: false };
const __puiVueCaptureResult = __puiVueSetDefaults(__puiVueCaptureArg0); __puiVueAuthored.effect("props", {"op": "setDefaults", "partial": __puiVueCaptureArg0}); return __puiVueCaptureResult; })();
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":103:11
        const buttonState = ((__puiVueHook0())["stateHandles"] as { readonly "disabled": __puiVueState<boolean> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<boolean>) => void): () => void}; readonly "hovered": __puiVueState<boolean> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<boolean>) => void): () => void}; readonly "focused": __puiVueObservedState<boolean>; readonly "focusVisible": __puiVueObservedState<boolean>; readonly "pressed": __puiVueState<boolean> & {watch(callback: (run: __puiVueRun, event: __puiVueStateEvent<boolean>) => void): () => void} });
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":104:5
        if ((!buttonState)) {
          // Source "packages/prototypes/brutalist/src/button/button.proto.ts":105:7
          throw new Error("[brutalist-button] asButton must project Button state handles.");
        }
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":107:13
        const disabled = (buttonState)["disabled"];
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":107:23
        const hovered = (buttonState)["hovered"];
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":107:32
        const focusVisible = (buttonState)["focusVisible"];
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":107:46
        const pressed = (buttonState)["pressed"];
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":109:5
        (() => {
const __puiVueCaptureReceiver = def;
const __puiVueCaptureArg0 = ({"kind":"tw","tokens":["group/brutalist-button","inline-flex","shrink-0","items-center","justify-center","gap-2","font-sans","font-medium","rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium"],"groups":["group/brutalist-button","display","shrink-0","items-","justify-","gap-2","font-sans","font weight","rounded","border-width","border-color","shadow-","font-sans","font weight"]} as const);
const __puiVueCaptureResult = __puiVueStyle.use(__puiVueCaptureArg0); __puiVueAuthored.effect("feedback", __puiVueCaptureResult); __puiVueAuthored.disposer("feedback", __puiVueCaptureResult); return __puiVueCaptureResult; })();
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":114:5
        __puiVueAuthored.rule(__puiVueStyle.rule(() => (__puiVueStyle.meta("preference.reducedMotion") === "no-preference"), [({"kind":"tw","tokens":["transition-all"],"groups":["transition-"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":118:5
        __puiVueAuthored.rule(__puiVueStyle.rule(() => !((__puiVueStyle.meta("preference.reducedMotion") === "no-preference")), [({"kind":"tw","tokens":["transition-none"],"groups":["transition-"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
        __puiVueAuthored.rule(__puiVueStyle.rule(() => ((__puiVueProps["variant"] === "solid") && (__puiVueProps["color"] === "main")), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-main","text-main-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
        __puiVueAuthored.rule(__puiVueStyle.rule(() => ((__puiVueProps["variant"] === "solid") && (__puiVueProps["color"] === "mint")), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-mint","text-mint-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
        __puiVueAuthored.rule(__puiVueStyle.rule(() => ((__puiVueProps["variant"] === "solid") && (__puiVueProps["color"] === "lavender")), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-lavender","text-lavender-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
        __puiVueAuthored.rule(__puiVueStyle.rule(() => ((__puiVueProps["variant"] === "solid") && (__puiVueProps["color"] === "coral")), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-coral","text-coral-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":125:7
        __puiVueAuthored.rule(__puiVueStyle.rule(() => ((__puiVueProps["variant"] === "solid") && (__puiVueProps["color"] === "sky")), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-sky","text-sky-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":134:9
        __puiVueAuthored.rule(__puiVueStyle.rule(() => (__puiVueProps["variant"] === "surface"), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-secondary-background","text-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":134:9
        __puiVueAuthored.rule(__puiVueStyle.rule(() => (__puiVueProps["variant"] === "destructive"), [({"kind":"tw","tokens":["rounded-base","border-2","border-black","shadow-[4px_4px_0_0_#000]","font-sans","font-medium","bg-destructive","text-destructive-foreground"],"groups":["rounded","border-width","border-color","shadow-","font-sans","font weight","bg-","text-color"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":143:7
        __puiVueAuthored.rule(__puiVueStyle.rule(() => ((__puiVueProps["size"] === "default") && (__puiVueProps["wrap"] === false)), [({"kind":"tw","tokens":["h-10","px-4","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":143:7
        __puiVueAuthored.rule(__puiVueStyle.rule(() => ((__puiVueProps["size"] === "sm") && (__puiVueProps["wrap"] === false)), [({"kind":"tw","tokens":["h-9","px-3","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":143:7
        __puiVueAuthored.rule(__puiVueStyle.rule(() => ((__puiVueProps["size"] === "lg") && (__puiVueProps["wrap"] === false)), [({"kind":"tw","tokens":["h-11","px-8","text-sm","whitespace-nowrap"],"groups":["h-","px-","text-size","whitespace-nowrap"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":143:7
        __puiVueAuthored.rule(__puiVueStyle.rule(() => (__puiVueProps["size"] === "icon"), [({"kind":"tw","tokens":["size-10","whitespace-nowrap"],"groups":["size-10","whitespace-nowrap"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":154:7
        __puiVueAuthored.rule(__puiVueStyle.rule(() => ((__puiVueProps["size"] === "default") && (__puiVueProps["wrap"] === true)), [({"kind":"tw","tokens":["min-h-10","h-auto","px-4","py-1","text-sm","whitespace-normal","min-w-0","max-w-full","wrap-anywhere","text-center"],"groups":["min-h-","h-","px-","py-","text-size","whitespace-normal","min-w-","max-w-","wrap-anywhere","text-align"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":154:7
        __puiVueAuthored.rule(__puiVueStyle.rule(() => ((__puiVueProps["size"] === "sm") && (__puiVueProps["wrap"] === true)), [({"kind":"tw","tokens":["min-h-9","h-auto","px-3","py-1","text-sm","whitespace-normal","min-w-0","max-w-full","wrap-anywhere","text-center"],"groups":["min-h-","h-","px-","py-","text-size","whitespace-normal","min-w-","max-w-","wrap-anywhere","text-align"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":154:7
        __puiVueAuthored.rule(__puiVueStyle.rule(() => ((__puiVueProps["size"] === "lg") && (__puiVueProps["wrap"] === true)), [({"kind":"tw","tokens":["min-h-11","h-auto","px-8","py-1","text-sm","whitespace-normal","min-w-0","max-w-full","wrap-anywhere","text-center"],"groups":["min-h-","h-","px-","py-","text-size","whitespace-normal","min-w-","max-w-","wrap-anywhere","text-align"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":161:5
        __puiVueAuthored.rule(__puiVueStyle.rule(() => (hovered.get() === true), [({"kind":"tw","tokens":["translate-x-1","translate-y-1","shadow-none","relative","hit-envelope-translate-1"],"groups":["translate-x-","translate-y-","shadow-","relative","hit-envelope-translate-1"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":167:5
        __puiVueAuthored.rule(__puiVueStyle.rule(() => (pressed.get() === true), [({"kind":"tw","tokens":["translate-x-1","translate-y-1","shadow-none","relative","hit-envelope-translate-1"],"groups":["translate-x-","translate-y-","shadow-","relative","hit-envelope-translate-1"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":173:5
        __puiVueAuthored.rule(__puiVueStyle.rule(() => (focusVisible.get() === true), [({"kind":"tw","tokens":["outline-none","ring-2","ring-ring","ring-offset-2","ring-offset-background"],"groups":["outline-none","ring-2","ring-ring","ring-offset-2","ring-offset-background"]} as const)]));
        // Source "packages/prototypes/brutalist/src/button/button.proto.ts":178:5
        __puiVueAuthored.rule(__puiVueStyle.rule(() => (disabled.get() === true), [({"kind":"tw","tokens":["pointer-events-none","opacity-50"],"groups":["pointer-events-none","opacity-"]} as const)]));
      })(__puiVueDefValue);
        __puiVueSetup = false;
        __puiVueRawProps = __puiVueGetHostProps();

        __puiVueProps = __puiVueResolveProps(__puiVueRawProps, true);
        __puiVueStyle.refresh();
        
        __puiVueInteraction.refresh();
        __puiVueInvokeLife('created');
        return renderer;
      } catch (error) {
        __puiVueDisposing = true;
        try { __puiVueInteraction.dispose(); }
        finally {
          try { __puiVueStyle.dispose(); }
          finally {
            try { __puiVueScope.dispose(); }
            finally {
              __puiVueDisposed = true; __puiVueAuthored.dispose();
              for (const cleanup of __puiVueStateCleanup) cleanup();
              __puiVueStateQueue.length = 0; __puiVueWatchers.length = 0;
            }
          }
        }
        throw error;
      }
    })();

    const __puiVueHandle: GeneratedHandle = Object.freeze({
      update() { __puiVuePublicAlive(); __puiVueRequestUpdate(__puiVueRunValue); },
      getExposes() { __puiVuePublicAlive(); return __puiVueExposes as GeneratedExposes; },
    });
    __puiVueContext.expose(__puiVueHandle);

    const __puiVueView = __puiVueVue.defineComponent({
      name: 'CompiledView', inheritAttrs: false,
      props: { revision: { type: Number, required: true } },
      setup(viewProps) {
        let epoch: __puiVueEpoch = { id: ++__puiVueEpochId, active: true, committed: false };
        __puiVueCurrentEpoch = epoch;
        const activation = __puiVueVue.shallowRef(0);
        let deactivated = false;

        let drawnRevision = -1, drawnActivation = -1, committedRevision = -1;
        let cached: __puiVueVue.VNodeArrayChildren = [];
        let root: HTMLElement | null = null;
        function bindRoot(element: Element | __puiVueVue.ComponentPublicInstance | null): void {
          if (!element) { __puiVueUnbindRoot(epoch); return; }
          if (!(element instanceof HTMLElement)) throw new TypeError('[Vue source] Root must be an HTMLElement');
          root = element;
          if (epoch !== __puiVueCurrentEpoch || !epoch.active) return;
          if (__puiVueRootEpoch && (__puiVueRootElement !== root || __puiVueRootEpoch !== epoch)) __puiVueUnbindRoot(__puiVueRootEpoch);
          __puiVueRootElement = root; __puiVueRootEpoch = root ? epoch : undefined;
          if (epoch.committed) {
            __puiVueStyle.mount();
            
            __puiVueInteraction.mount();
          }
        }
        function commit(): void {

          if (__puiVueDisposed || __puiVueDisposing || deactivated || !epoch.active || epoch !== __puiVueCurrentEpoch || !__puiVuePresent.value) return;
          if (!epoch.committed) {

            epoch.committed = true;
            committedRevision = drawnRevision;
            __puiVueStyle.mount();
            

            __puiVueInteraction.mount();
            __puiVueInvokeLife('mounted');

          }
          else if (committedRevision !== drawnRevision) { committedRevision = drawnRevision; __puiVueInvokeLife('updated'); }
        }
        __puiVueVue.onMounted(commit);
        __puiVueVue.onUpdated(commit);
        __puiVueVue.onBeforeUnmount(() => { epoch.active = false; __puiVueUnbindRoot(epoch); });
        __puiVueVue.onUnmounted(() => { __puiVueCommitUnmount(epoch); });
        __puiVueVue.onDeactivated(() => { deactivated = true; __puiVueCommitUnmount(epoch); });
        __puiVueVue.onActivated(() => {
          if (!deactivated || __puiVueDisposed || __puiVueDisposing) return;
          deactivated = false;
          epoch = { id: ++__puiVueEpochId, active: true, committed: false };
          __puiVueCurrentEpoch = epoch;
          __puiVueRootElement = root; __puiVueRootEpoch = root ? epoch : undefined;
          activation.value += 1;
        });
        return () => {
          __puiVueHostRevision.value;
          const revision = viewProps.revision!, active = activation.value;
          if (__puiVueDisposed || __puiVueDisposing || deactivated || !epoch.active || epoch !== __puiVueCurrentEpoch || !__puiVuePresent.value) return null;
          if (drawnRevision !== revision || drawnActivation !== active) {
            drawnRevision = revision; drawnActivation = active;
            __puiVueRequested = false;
            const frame: __puiVueFrame = { epoch, slotUsed: false };
            const children = typeof __puiVueRenderer === 'function' ? __puiVueChildren(__puiVueRenderer(frame)) : __puiVueSlot(frame);
            cached = children == null ? [] : Array.isArray(children) ? children : [children];
          }
          const tag = __puiVueInteraction.rootTag() ?? 'div';
          if (['input', 'textarea', 'img'].includes(tag) && cached.length) throw new Error('[Template] physical control Root requires empty children');
          const physical = __puiVueVue.h(tag, { 'data-pui-root': '', ...__puiVueInteraction.rootProperties(), ref: bindRoot }, cached.length ? cached : undefined);
          const portal = __puiVueInteraction.portalTarget();
          return portal ? __puiVueVue.h(__puiVueVue.Teleport, { to: portal }, [physical]) : physical;
        };
      },
    });
    __puiVueVue.onBeforeUpdate(() => { __puiVueNotifyProps(); __puiVueSlotRevision.value += 1; });
    __puiVueVue.onBeforeUnmount(() => {
      __puiVueDisposing = true;
      __puiVueQueueTicket += 1;
      __puiVueRequested = false;
      if (__puiVueCurrentEpoch) __puiVueUnbindRoot(__puiVueCurrentEpoch);
      if (__puiVueCurrentEpoch) __puiVueCurrentEpoch.active = false;
    });
    __puiVueVue.onUnmounted(() => {
      __puiVueInternalTeardown = true;
      try { __puiVueInvokeLife('beforeDispose'); }

      finally {
        try { __puiVueScope.dispose(); }

        finally {
          try { __puiVueInteraction.dispose(); }

          finally {
            try { __puiVueStyle.dispose(); }

            finally {
              __puiVueInternalTeardown = false; __puiVueDisposed = true;
              __puiVueAuthored.dispose();
              for (const cleanup of __puiVueStateCleanup) cleanup();
              __puiVueStateQueue.length = 0; __puiVueWatchers.length = 0;
            }
          }
        }
      }
    });
    return () => __puiVuePresent.value && !__puiVueDisposing ? __puiVueVue.h(__puiVueView, { revision: __puiVueRevision.value }) : null;
  },
});

export default CompiledComponent;

//# sourceMappingURL=Component.ts.map
