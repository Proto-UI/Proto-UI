import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const [root, graphFile, resultFile] = process.argv.slice(2);
const checkerFile = path.join(root, 'scripts/coverage-matrices/check-website-production-bundle.mjs');
const { collectWebsiteProductionBundleIssues } = await import(pathToFileURL(checkerFile).href);
const digest = (file) => createHash('sha256').update(readFileSync(file)).digest('hex');
const graphSha256 = digest(graphFile);
if (graphSha256 !== '822cb367cf0eb8addece00c3e97154626530b7a8d3624ca962cdb744ad88c975')
  throw new Error('The historical production graph does not match its retained SHA-256.');
const graph = JSON.parse(readFileSync(graphFile, 'utf8'));
const issues = collectWebsiteProductionBundleIssues({ rootDir: root, graph });
const result = {
  scopeId: 'pull-request:1743',
  sourceHead: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(),
  sourceStatus: execFileSync('git', ['status', '--porcelain=v1'], { cwd: root, encoding: 'utf8' }),
  checkerSha256: digest(checkerFile),
  graphSha256,
  historicalProductionHead: 'd9958d163436ea08d4a19b325d9e7f5dad3dc951',
  artifactId: 14837573771,
  mode: 'historical-actual-production-graph-replay',
  freshProductionBuild: false,
  issues,
};
writeFileSync(resultFile, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
process.exitCode = issues.length ? 1 : 0;

