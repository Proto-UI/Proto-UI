import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys

ROOT = pathlib.Path('/home/agent/Proto-UI-focus-projection-v6')
EVIDENCE = pathlib.Path('/home/agent/s3-focus-projection-v6-evidence')
name = sys.argv[1]
tests = sys.argv[2:]
assert tests and all((ROOT / path).is_file() for path in tests)
bound = ['packages/adapters/web-component/src/runtime/modules.ts', *tests]
snapshot = EVIDENCE / f'{name}-source'
snapshot.mkdir(parents=True, exist_ok=True)
before = {}
for path in bound:
    content = (ROOT / path).read_bytes()
    before[path] = hashlib.sha256(content).hexdigest()
    destination = snapshot / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(content)
log = EVIDENCE / f'{name}.log'
result = EVIDENCE / f'{name}.vitest.json'
command = [
    'corepack', 'pnpm@10.32.1', 'exec', 'vitest', 'run', *tests,
    '--pool=forks', '--no-file-parallelism', '--reporter=json',
    f'--outputFile={result}',
]
environment = dict(os.environ)
environment['NODE_OPTIONS'] = '--max-old-space-size=512'
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with log.open('wb') as stream:
    process = subprocess.run(
        command, cwd=ROOT, env=environment, stdout=stream, stderr=subprocess.STDOUT
    )
after = {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() for path in bound}
receipt = {
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'node': subprocess.check_output(['node', '--version'], cwd=ROOT, text=True).strip(),
    'command': command,
    'nodeOptions': environment['NODE_OPTIONS'],
    'startedAtUtc': started,
    'endedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exitCode': process.returncode,
    'sourceBefore': before,
    'sourceAfter': after,
    'sourceUnchanged': before == after,
    'sourceSnapshot': str(snapshot),
    'log': str(log),
    'logBytes': log.stat().st_size,
    'logSha256': hashlib.sha256(log.read_bytes()).hexdigest(),
}
if result.exists():
    data = json.loads(result.read_text())
    receipt['resultJson'] = str(result)
    receipt['resultSha256'] = hashlib.sha256(result.read_bytes()).hexdigest()
    receipt['counts'] = {key: data[key] for key in [
        'numTotalTests', 'numPassedTests', 'numFailedTests', 'numPendingTests',
        'numTodoTests', 'success',
    ] if key in data}
    receipt['cases'] = [
        {'file': item['name'], 'name': assertion['fullName'], 'status': assertion['status'],
         'failureMessages': assertion['failureMessages']}
        for item in data['testResults'] for assertion in item['assertionResults']
    ]
(EVIDENCE / f'{name}.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key != 'cases'}))
for case in receipt.get('cases', []):
    print(json.dumps({'name': case['name'], 'status': case['status'],
                      'failure': '\n'.join(case['failureMessages'])[:1800]}))
sys.exit(process.returncode)
