# Focus Entry V3 插槽补充证据

固定 95 个测试（原 92 + 3 个插槽反例）在精确 V3 源上全部通过，0 skip；同配置受影响模块类型检查 exit 0。新增 3 例在 V2 精确源上全部失败，原 14 个事件来源控制仍全部通过。红绿使用完全相同的测试文件。

Entry 为 open ShadowRoot 内含 slot 的 wrapper，assigned light DOM radio 和外部同组 radio 不在 owned root 的 contains/querySelector 范围中。原 resolver 能遍历 assigned 内容，但 V2 的 trusted 事件过滤遗漏这条归属路径。V3 仅在该 observation scope 含 slot 时保留原 input/change 刷新，不改 resolver、radioTrees 或 hasExternalStyleInputs。

新增测试没有 CSS、可见性或 assignedSlot 注入。实际 assignedNodes、原生 radio checkedness 模型与真实 resolver 产生断言结果。isTrusted 是 Happy DOM 分支注入，不能将其表述为新的原生浏览器通过。21 独立 Entry 的单测也是独立压力控制，原生产 trace 的 21 次回调并不证明 21 个 Entry owner。

本包保留 V2 新反例原始红日志、V3 固定 95 绿日志、5 个源文件快照、类型检查、全部补丁和来源记录。旧 V2 完整包保持原样，精确路径/hash 见 focus-owner-v3-evidence-report.json；它保存原基线三红、V1 两个实际回归、V2 92 绿与旧类型结果。新增独立审查沿用原 V2 finding 历史，V3 reviewer packet 由审阅者单独交付。

所有结果绑定独立 clone 的 1af HEAD 加显式 working-tree 源 hash。root 拥有最终整合/格式化后的源绑定、原生 250 ms 全旅程、正式 CI、DCO 与平台合入条件。本包不构成 GitHub approval 或 Ready 决定。
