# Focus Entry input/change 证据包

基线固定为 `1af0cda3f5976bb21ea67f6d083053b8ed20d83d`。实现由 website lane 提供，本 lane 仅在独立副本应用并负责测试和证据。

## 实际结果

| 阶段 | 结果 | 说明 |
| --- | --- | --- |
| 最终 v4 原实现红测 | 14 例：3 失败、11 通过 | 三个无关 trusted 分支采样计数为 662、126、189，期待均为 0 |
| 相邻既有基线 | 78/78 通过 | observer、refresh-coalescing、motion-origin 三文件 |
| owner V1 | 90/92 通过、2 失败 | 新 14 全过；原有 partial CSSRule 兼容和 imported media 两处回归，完整保留 |
| owner V2 | 92/92 通过 | 同一测试源和断言，0 skip / todo；执行前后源哈希一致 |
| affected focused types | exit 0 | 原 tsconfig.workspace 编译选项，限定 modules.ts 与相同四测试文件；512 MiB |

`focus-owner-v2-evidence-report.json` 汇集运行、限制和行动项；各 `*.receipt.json` 记录真实命令、时间、退出码及源哈希。`*.log` 和 `*.vitest.json` 是未删改的原始输出。类型检查成功日志为空文件，receipt 记录了真实 exit 0。

## 应用材料

- `production-owner-v2.patch`：website owner 原件，从 1af 原始 modules.ts 应用。
- `focus-entry-form-origin-tests-v4.patch`：同一组 14 测试原件。
- `focus-entry-owner-v2-with-tests-v4.patch`：上述最终源码和测试的合并 diff。
- `owner-v2-candidate-fixed92-source/`：实际测试时的生产与四个测试文件。
- `governance-source/`：对应约束、测试方法与原编译配置快照。

## 判断边界

三项无关事件负控归零；11 个正控保留内部 input/change、兄弟和祖先 form validity、外部 form-associated 输入、escaped CSS、全局/局部 :has、filtered position、opaque stylesheet 及反复 synthetic author notification。旧 78 例继续验证现有观察、替换、清理与 motion-origin 行为。

测试通过 Happy DOM 的 isTrusted 注入选择真实生产代码分支，不代表浏览器原生事件。可见性代理根据实际 input validity/checked 变化驱动宿主反馈，用以隔离模拟器 CSS 级联的缺口。零采样断言在完整 observer 交付后执行，不借助同步 dispatchEvent 模型声称 native microtask 可合并。

原生 trace 约 21 次 callback/dispatch，可能是同一 closure 在多个 capture 节点重复进入；本测试特意创建 21 个独立 Entry owner 是另一层压力边界，不能把两个数字等同。原 38 MB trace 在 Linux 已保留，本小包只引用它的准确 SHA 与 partial 状态。

首次夹具的 tabIndex 反射问题、后续 styleSheets getter 清理问题、V1 两项回归都保留原始失败，未重写历史。V1 还因全 cssText 扫描把 cursor:default 声明误作伪类而由 owner 撤回；V2 改为 selector/prelude。

原生 250 验收、最终合并和正式 CI 仍由 root 负责。本包不构成原生通过、PR approval 或合并授权。`test-to-validate-handoff-owner-v2.json` 是本 lane 唯一当前 handoff，先前 handoff 仅作为历史证据。
