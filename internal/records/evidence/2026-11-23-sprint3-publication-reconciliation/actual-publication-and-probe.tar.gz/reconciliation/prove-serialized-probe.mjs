import fs from 'node:fs';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
const require=createRequire(import.meta.url);
const {transformSync}=require('/dev/shm/proto-ui-s3-cc618/node_modules/esbuild');
const [beforePath,afterPath]=process.argv.slice(2);
function callback(source){
 const start='child.evaluate(() => {', end='\n        })';
 assert.equal(source.split(start).length,2,'Exactly one actual serialized security probe');
 const at=source.indexOf(start)+'child.evaluate('.length;
 const until=source.indexOf(end,at);assert.ok(until>at);
 return source.slice(at,until)+'\n        }';
}
function serialized(source){
 const code=transformSync('const probe='+callback(source)+';module.exports=probe;',{
  loader:'ts',target:'es2022',format:'cjs',keepNames:true
 }).code;
 const module={exports:undefined};
 vm.runInNewContext(code,{module});
 assert.equal(typeof module.exports,'function');
 return {code,source:Function.prototype.toString.call(module.exports)};
}
function execute(serialized,mask){
 const deny=()=>{throw new Error('Blocked by isolated origin');};
 const parent=Object.defineProperty({},'document',{get:mask&1?deny:()=>({})});
 const document=Object.defineProperty({},'cookie',{get:mask&4?deny:()=>''});
 const localStorage={getItem:mask&2?deny:()=>null};
 return JSON.parse(JSON.stringify(vm.runInNewContext('('+serialized+')()',{parent,document,localStorage})));
}
const oldText=fs.readFileSync(beforePath,'utf8'),newText=fs.readFileSync(afterPath,'utf8');
const old=serialized(oldText),current=serialized(newText);
let previousError;try{execute(old.source,7);}catch(error){previousError=String(error);}
assert.match(previousError??'',/__name is not defined/);
const controls=[];
for(let mask=0;mask<8;mask++){
 const actual=execute(current.source,mask);
 const expected={parent:!!(mask&1),storage:!!(mask&2),cookie:!!(mask&4)};
 assert.deepEqual(actual,expected);controls.push({mask,actual,status:'passed'});
}
console.log(JSON.stringify({kind:'serialized-actual-probe-regression',scope:'Actual source callback transformed with keepNames and serialized into a separate JavaScript realm; not native-browser or full WASM acceptance.',sourceBeforeSha256:createHash('sha256').update(oldText).digest('hex'),sourceAfterSha256:createHash('sha256').update(newText).digest('hex'),oldFailure:previousError,controls,oldSerialized:old.source,newSerialized:current.source,transform:{loader:'ts',target:'es2022',format:'cjs',keepNames:true}}));
