# Sprint 4 canonical package-budget independent factual review

## Conclusion

The baseline and implementation-candidate canonical measurements are comparable. The candidate at `9fff88cf23d4e55375979bc5c68c033e3deaed38` genuinely failed the unchanged strict gate: **6/9**, with React, Vue and WC exceeding their existing caps by **149, 136 and 103 gzip bytes**. Those original failures remain unmodified. This review provides facts for a subsequent bounded numerical decision; it selects no ceilings and does not validate a later numeric candidate.

The added scene implementation is not retained in the measured default Adapter roots or the two diagnostic consumers. Their retained Runtime paths and total retained Runtime bytes also remain unchanged. Growth is concentrated in the Core source-contract validation, the sink publication/source-kind/retirement boundary, and small Adapter host-option plumbing. This is a finite code-cost finding, not whole-Sprint or GPU-performance acceptance.

## Exact source and original receipts

| Role | Exact HEAD | Actions run | Original strict result |
|---|---|---:|---|
| baseline | `31239ef95dfe610ddeb415976721adb7f12d5ba0` | [45257565727](https://github.com/Proto-UI/Proto-UI/actions/runs/45257565727) | 9/9; exit 0 |
| candidate | `9fff88cf23d4e55375979bc5c68c033e3deaed38` | [45262013762](https://github.com/Proto-UI/Proto-UI/actions/runs/45262013762) | 6/9; exit 1 |

Both archives were independently hashed and all six extracted files per archive were matched byte-for-byte to their original tar members. All closure fingerprints, counts, and package contributions were recalculated. The entire source fingerprints were independently reconstructed from immutable Git blobs: **7,826 baseline files** and **7,831 candidate files**. All **3,830 / 3,831 unique closure inputs**, including zero-retained inputs, match the source bytes and SHA-256 at their exact respective Git commits. The original source receipts also report clean trees, expected SHA match, and stable before/after measurement.

| Archive | SHA-256 |
|---|---|
| baseline | `e61a507e5b2df20e1573e6ad2655c00a63e7463d721b12367be86af3cb2e98e2` |
| candidate | `0656c0b1e50f1490e904ab73010194a2f254a3186785ebf13cb8b3cd3741805b` |

## Comparability

Both original runs used Node `v24.22.3`, zlib `1.3.2.1-motley-285e94b`, esbuild `0.25.12`, Linux x64, and pnpm `10.32.1`. Both installed the unchanged lockfile without resolution, built **47/47 public packages**, checked **47 public manifests**, and passed the same **28/28 budget-policy/evidence controls**. Adapter-base now builds 120 files instead of 118 because the explicit scene helper adds its JavaScript and declaration outputs; the number of public packages remains 47.

Bundling, minification, tree shaking, ESM/browser/es2020 and gzip level 9 are identical. The external list is identical, SHA-256 `6a8bd56596b933f9a9d941db2a9e325789b44886af2648d6a9795f022787c253`. Git confirms no baseline-to-candidate change to the measurement implementation, strict policy, measurement workflow, build scripts, root package metadata, lockfile, workspace config, root TypeScript config, or Finf source ledger.

## Whole-entry measurements

All values below are bytes. The caps shown are the unchanged original caps.

| Entry | Baseline gzip | Candidate gzip | Delta | Current cap | Candidate excess |
|---|---:|---:|---:|---:|---:|
| lucide/icons/x | 1,797 | 1,797 | +0 | 3,000 | 0 |
| lucide root | 635,917 | 635,917 | +0 | 700,000 | 0 |
| core root | 12,605 | 12,674 | +69 | 12,800 | 0 |
| runtime root | 104,105 | 104,169 | +64 | 104,300 | 0 |
| adapter-react root | 172,338 | 172,749 | +411 | 172,600 | 149 |
| adapter-vue root | 171,098 | 171,536 | +438 | 171,400 | 136 |
| adapter-web-component root | 206,862 | 207,303 | +441 | 207,200 | 103 |
| prototypes-base/button | 4,198 | 4,197 | -1 | 6,000 | 0 |
| prototypes-shadcn/button | 6,741 | 6,741 | +0 | 7,900 | 0 |

The two informational consumer profiles remain separate from the nine strict gate rows. Light DOM increases from 213,036 to 213,513 gzip bytes, and direct shadow from 213,040 to 213,517 bytes, both +477. Each has a +1,125 minified-byte change. They do not replace a failing root entry.

## Retained closure and growth attribution

The attribution unit is esbuild minified `bytesInOutput`, before gzip. These contributions cannot be summed or subtracted as gzip costs.

| Changed retained source | React delta | Vue delta | WC / each consumer delta |
|---|---:|---:|---:|
| Core `shader-presentation.ts` | +337 | +337 | +337 |
| Sink `shader-webgl2.ts` | +852 | +852 | +852 |
| Physical host `shader-webgl2-host.ts` | -84 | -84 | -89 |
| Adapter adapt + modules | +28 | +23 | +25 |
| Scene host implementation | 0 | 0 | 0 |

The new scene host is an input visited through the export graph, with **0 retained bytes** in all five affected root/consumer closures. Each adds one visited input; the number of retained inputs is unchanged: React 242, Vue 241, WC 271, and each consumer 299. This distinguishes package availability from default retained implementation cost.

Runtime retention is unchanged at 33,046 minified bytes for React and Vue, and 33,015 for WC and both consumers. The retained Runtime path sets are identical; the closure contains no additional Runtime copy. React/Vue have small per-file retained-byte shifts in unchanged source inputs, but their net Runtime contribution is zero. The raw report preserves every affected input rather than assigning those shifts an unsupported causal explanation.

Eleven files from the earlier independent owned-pixels/API/cleanup/closure review at `27b5429b46fdc31ae94d1f6a1bd37fb1c6a8323c` match this candidate byte-for-byte. That prior review found no diagnostic `createWebShaderDevice` factory in the default bundled sink and no diagnostic `readPixels` or scene implementation in the copy-only, tint-only, or combined native reached-kernel closures. The exact host source is `df6a869ee639e5aa94899c83c00ed8854d1ed0f5a7629a7b21db312868ba6496`; the scene source is `ddd4bf1e5b49e7fae03768f0c009fbcff67011ff637ef24cc0158adc8d82945b`. These remain source-bound prior checks, not relabeled new canonical executions. The canonical file-level metadata alone does not identify individual retained functions.

The explicit internal diagnostic device still preserves its `read` API. The declared adapter-base export paths did not promise a public presenter callback/device read contract. Prior differential cleanup and failure controls, including the original failures and their successors, are retained in the separate owned-pixels review archive.

## Numeric transaction handoff

Facts now support passing the integrated candidate to the package-budget numerical decision leaf, together with the accepted capability, current authority map and implementation authorization. Only the three affected caps need a decision; this audit does not recommend changing unrelated entries or relaxing strict policy. Any selected margin must be stated against the actual integrated candidate values above, rather than isolated deltas.

Keep the numeric edit separately reviewable: only the affected literals, necessary comments and the transaction record. Preserve the original baseline, red candidate report, exact minified hashes, closure attribution, source fingerprints and archives. After committing that numeric candidate, return it to `pui-validate` for a **fresh canonical strict run on the new exact SHA**, with the original build/manifest/measurement-control gates. The current pre-edit evidence cannot validate the new head. Independent exact-head review follows the actual new validation result.

## Limits and probe transparency

This audit did not rebuild bundles, rerun browser tests, edit source, or alter budget values. Canonical minified/gzip values come from the original Actions reports; all source identities and report accounting were independently checked. Archive matching proves content integrity against the supplied originals, not a separate cryptographic claim about GitHub provenance. The 37-case browser result reported by the integrator is outside this budget audit until its originals are examined.

The first audit-reader run reached the prior-review binding and failed because it assumed the compiler generator belonged to the narrower package measurement scope. The corrected reader obtains that extra prior-review file from the exact immutable Git commit; it does not broaden or change the canonical measurement scope. This probe setup failure is recorded in the JSON report.

## Files

- Machine-readable findings and all row/source/archive details: `canonical-package-budget-independent-review.json`.
- Reproducible read-only audit: `audit-canonical-package-budget.py`.
- Prior behavior/closure review: `owned-pixels-final-review.json` and its compact submission archive.
