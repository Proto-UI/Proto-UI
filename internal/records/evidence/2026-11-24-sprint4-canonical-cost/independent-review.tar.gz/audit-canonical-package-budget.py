#!/usr/bin/env python3
"""Independent read-only audit of original canonical budget receipts."""
from collections import defaultdict
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/1494db44bb7b')
REPO = ROOT / 'Proto-UI'
OUT = ROOT / 'ir10-semantics-evidence'
CASES = {
    'baseline': {
        'directory': ROOT / 'integration-evidence/canonical-baseline-originals',
        'archive': ROOT / 'integration-evidence/canonical-baseline-originals.tar.gz',
        'archiveSha256': 'e61a507e5b2df20e1573e6ad2655c00a63e7463d721b12367be86af3cb2e98e2',
        'head': '31239ef95dfe610ddeb415976721adb7f12d5ba0',
        'runId': 45257565727,
    },
    'candidate': {
        'directory': ROOT / 'integration-evidence/canonical-candidate-originals/package-budgets-9fff88cf23d4e55375979bc5c68c033e3deaed38-45262013762-attempt-1-logs',
        'archive': ROOT / 'integration-evidence/canonical-candidate-originals.tar.gz',
        'archiveSha256': '0656c0b1e50f1490e904ab73010194a2f254a3186785ebf13cb8b3cd3741805b',
        'head': '9fff88cf23d4e55375979bc5c68c033e3deaed38',
        'runId': 45262013762,
    },
}

def digest(value):
    return sha256(value).hexdigest()

def encoded(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()

def git(*args, data=None):
    return subprocess.run(['git', *args], cwd=REPO, input=data, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, check=True).stdout

def owner(path):
    parts = path.split('/')
    return '/'.join(parts[:3 if parts[0] == 'packages' and
                           parts[1] in ['adapters', 'modules', 'prototypes', 'spec'] else 2])

reports = {}
result = {
    'schemaVersion': 1,
    'kind': 'independent canonical package-budget factual review before numeric decision',
    'reviewer': '/root/ir10_semantics',
    'mode': 'human-assisted/current-user',
    'numericEditsMade': False,
    'proposedCeilings': None,
    'cases': {},
    'checks': {},
}

for name, case in CASES.items():
    archive_bytes = case['archive'].read_bytes()
    assert digest(archive_bytes) == case['archiveSha256'], f'{name}: archive hash'
    artifact_files = {}
    with tarfile.open(case['archive'], 'r:gz') as archive:
        by_name = defaultdict(list)
        for member in archive.getmembers():
            if member.isfile():
                by_name[Path(member.name).name].append(member)
        for file_name in ['report.json', 'terminal.json', 'setup.log', 'build.log', 'controls.log', 'gate.log']:
            data = (case['directory'] / file_name).read_bytes()
            assert len(by_name[file_name]) == 1, f'{name}: unique archive member {file_name}'
            member = by_name[file_name][0]
            assert archive.extractfile(member).read() == data, f'{name}: extracted original {file_name}'
            artifact_files[file_name] = {'bytes': len(data), 'sha256': digest(data), 'archiveMember': member.name}
    report = json.loads((case['directory'] / 'report.json').read_text())
    terminal = json.loads((case['directory'] / 'terminal.json').read_text())
    reports[name] = report
    source = report['source']
    assert source['head'] == case['head'] == source['expectedSha']
    assert source['tree'] == git('rev-parse', case['head'] + '^{tree}').decode().strip()
    for field in ['workingTreeClean', 'measuredSourceMatchesHead', 'stableDuringMeasurement', 'requireClean']:
        assert source[field] is True, f'{name}: source {field}'
    assert source['statusSha256'] == digest(b'')
    setup = (case['directory'] / 'setup.log').read_text()
    build = (case['directory'] / 'build.log').read_text()
    controls = (case['directory'] / 'controls.log').read_text()
    assert setup.splitlines()[0] == case['head']
    assert 'Lockfile is up to date, resolution step is skipped' in setup
    assert 'Done in ' in setup and 'using pnpm v10.32.1' in setup
    assert '[build:packages] complete: 47/47 public packages' in build
    assert 'checked 47 public manifests' in controls
    for line in ['tests 28', 'pass 28', 'fail 0', 'cancelled 0', 'skipped 0', 'todo 0']:
        assert '\u2139 ' + line in controls, f'{name}: controls {line}'
    result['cases'][name] = {
        'head': case['head'], 'runId': case['runId'], 'attempt': 1,
        'runUrl': f"https://github.com/Proto-UI/Proto-UI/actions/runs/{case['runId']}",
        'archive': str(case['archive']), 'archiveSha256': digest(archive_bytes),
        'originals': artifact_files, 'terminal': terminal, 'source': source,
        'environment': report['environment'], 'measurement': report['measurement'],
        'policy': report['policy'], 'withinBudgets': report['withinBudgets'],
        'exitCode': report['exitCode'], 'strictPassed': sum(row['pass'] for row in report['results']),
        'strictTotal': len(report['results']),
        'logChecks': {'frozenPnpmInstall': True, 'publicPackagesBuilt': '47/47',
                      'publicManifestsChecked': 47, 'measurementControlsPassed': '28/28'},
    }

trees = {}
all_blobs = set()
for name, case in CASES.items():
    paths = {}
    listing = git('ls-tree', '-r', '-z', '--full-tree', case['head'], '--', *reports[name]['source']['scope'])
    for item in listing.split(b'\0'):
        if not item:
            continue
        meta, path = item.split(b'\t', 1)
        mode, kind, oid = meta.decode().split()
        assert kind == 'blob' and mode in ['100644', '100755'], f'unexpected tree entry {path!r}'
        paths[path.decode()] = oid
        all_blobs.add(oid)
    trees[name] = paths

# Batch read unique immutable Git objects; this does not check out, build or edit anything.
ordered_blobs = sorted(all_blobs)
blob_data = git('cat-file', '--batch', data=''.join(oid + '\n' for oid in ordered_blobs).encode())
blob_receipts = {}
offset = 0
for expected_oid in ordered_blobs:
    end = blob_data.index(b'\n', offset)
    oid, kind, size = blob_data[offset:end].decode().split()
    assert oid == expected_oid and kind == 'blob'
    length = int(size)
    value = blob_data[end + 1:end + 1 + length]
    assert len(value) == length and blob_data[end + 1 + length:end + 2 + length] == b'\n'
    offset = end + 2 + length
    blob_receipts[oid] = {'bytes': length, 'sha256': digest(value)}
assert offset == len(blob_data)

for name, report in reports.items():
    files = [[path, blob_receipts[oid]] for path, oid in sorted(trees[name].items())]
    assert len(files) == report['source']['fileCount'], f'{name}: full Git source inventory count'
    assert digest(encoded(files)) == report['source']['fingerprintSha256'], f'{name}: full source fingerprint'
    unique_inputs = {}
    checked_inputs = 0
    for row in report['results'] + report['diagnostics']:
        closure = row['closure']
        inputs = closure['inputs']
        assert digest(encoded(inputs)) == closure['fingerprintSha256'], f"{name}/{row['name']}: closure fingerprint"
        assert len(inputs) == closure['inputCount'] == len(set(i['path'] for i in inputs))
        assert sum(i['retainedBytes'] > 0 for i in inputs) == closure['retainedInputCount']
        contributions = defaultdict(int)
        for item in inputs:
            actual = blob_receipts[trees[name][item['path']]]
            assert item['sourceBytes'] == actual['bytes'], f"{name}: bytes {item['path']}"
            assert item['sourceSha256'] == actual['sha256'], f"{name}: source hash {item['path']}"
            assert isinstance(item['retainedBytes'], int) and item['retainedBytes'] >= 0
            contributions[owner(item['path'])] += item['retainedBytes']
            unique_inputs[item['path']] = actual
            checked_inputs += 1
        assert dict(contributions) == {i['path']: i['retainedBytes'] for i in closure['contributions']}
        assert row['minifiedBytes'] > 0 and row['gzipBytes'] > 0
        if 'budget' in row:
            assert row['overBudgetBytes'] == max(0, row['gzipBytes'] - row['budget'])
            assert row['pass'] == (row['gzipBytes'] <= row['budget'])
            assert row['blocking'] == (not row['pass'])
    result['cases'][name]['independentGitCheck'] = {
        'treeIdentityMatches': True, 'fullSourceFingerprintMatches': True,
        'sourceFileCount': len(files), 'uniqueClosureInputsChecked': len(unique_inputs),
        'totalClosureInputReferencesChecked': checked_inputs,
        'allClosureInputBytesAndHashesMatchExactGitBlobs': True,
        'allClosureFingerprintsAndContributionsConsistent': True,
    }

baseline, candidate = reports['baseline'], reports['candidate']
for field in ['environment', 'measurement', 'policy']:
    assert baseline[field] == candidate[field], f'comparison {field}'
assert baseline['source']['scope'] == candidate['source']['scope']
assert baseline['exitCode'] == 0 and baseline['withinBudgets'] is True
assert candidate['exitCode'] == 1 and candidate['withinBudgets'] is False
measurement_paths = ['scripts/analysis', 'scripts/build', '.github/workflows/package-budget-evidence.yml',
                     'package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'tsconfig.json',
                     'internal/coverage-matrices/prototype-coverage-matrix.json']
unchanged = not git('diff', '--name-only', CASES['baseline']['head'], CASES['candidate']['head'], '--', *measurement_paths).strip()
assert unchanged, 'measurement, policy, build, resolution or ledger changed'
result['checks']['comparableEnvironmentMeasurementPolicyAndSourceScope'] = True
result['checks']['measurementBuildPolicyResolutionAndLedgerGitPathsUnchanged'] = measurement_paths
result['checks']['rawArchivesAndExtractedOriginalsVerified'] = True
result['checks']['fullSourceFingerprintsRecomputedFromExactGitObjects'] = True
result['checks']['minifiedAndGzipArtifactsNotIndependentlyRebuilt'] = True

comparisons = []
for old, new in zip(baseline['results'] + baseline['diagnostics'], candidate['results'] + candidate['diagnostics']):
    assert old['name'] == new['name'] and old['entry'] == new['entry']
    assert old.get('budget') == new.get('budget')
    before = {v['path']: v for v in old['closure']['inputs']}
    after = {v['path']: v for v in new['closure']['inputs']}
    changes = []
    for path in sorted(before.keys() | after.keys()):
        a, b = before.get(path, {}), after.get(path, {})
        if a != b:
            changes.append({'path': path, 'retainedBefore': a.get('retainedBytes', 0),
                            'retainedAfter': b.get('retainedBytes', 0),
                            'retainedDelta': b.get('retainedBytes', 0) - a.get('retainedBytes', 0),
                            'sourceChanged': a.get('sourceSha256') != b.get('sourceSha256')})
    old_runtime = [v for v in old['closure']['inputs'] if v['path'].startswith('packages/runtime/') and v['retainedBytes'] > 0]
    new_runtime = [v for v in new['closure']['inputs'] if v['path'].startswith('packages/runtime/') and v['retainedBytes'] > 0]
    comparisons.append({
        'name': new['name'], 'entry': new['entry'], 'budgetUnchanged': new.get('budget'),
        'baselineGzipBytes': old['gzipBytes'], 'candidateGzipBytes': new['gzipBytes'],
        'gzipDelta': new['gzipBytes'] - old['gzipBytes'],
        'baselineMinifiedBytes': old['minifiedBytes'], 'candidateMinifiedBytes': new['minifiedBytes'],
        'minifiedDelta': new['minifiedBytes'] - old['minifiedBytes'],
        'baselineMinifiedSha256': old['minifiedSha256'], 'candidateMinifiedSha256': new['minifiedSha256'],
        'candidatePass': new.get('pass'), 'candidateOverBudgetBytes': new.get('overBudgetBytes'),
        'inputCountBeforeAfter': [old['closure']['inputCount'], new['closure']['inputCount']],
        'retainedInputCountBeforeAfter': [old['closure']['retainedInputCount'], new['closure']['retainedInputCount']],
        'sceneHost': after.get('packages/adapters/base/src/material/shader-scene-host.ts'),
        'retainedRuntimePathsUnchanged': [v['path'] for v in old_runtime] == [v['path'] for v in new_runtime],
        'retainedRuntimeBytesBeforeAfter': [sum(v['retainedBytes'] for v in old_runtime), sum(v['retainedBytes'] for v in new_runtime)],
        'changedInputs': changes,
    })
result['comparisons'] = comparisons

previous = json.loads((OUT / 'owned-pixels-final-review.json').read_text())
source_identity = []
for path, expected in previous['sourceHashes'].items():
    actual = (blob_receipts[trees['candidate'][path]]['sha256']
              if path in trees['candidate'] else
              digest(git('show', CASES['candidate']['head'] + ':' + path)))
    assert actual == expected, f'prior bounded review source changed: {path}'
    source_identity.append({'path': path, 'sha256': actual})
result['priorBoundedReviewBinding'] = {
    'executedOn': previous['candidateSha'], 'currentCandidate': CASES['candidate']['head'],
    'sourceHashesMatch': source_identity,
    'report': str(OUT / 'owned-pixels-final-review.json'),
    'reportSha256': digest((OUT / 'owned-pixels-final-review.json').read_bytes()),
    'diagnosticReadClosureFinding': 'Prior source-bound local bundle checks found no diagnostic read factory in the default sink, and no readPixels in the three reached-kernel native closures. This audit does not relabel those checks as a new canonical bundle execution.',
}
result['auditSetupFailure'] = {
    'stage': 'prior review binding after complete canonical source checks',
    'error': "KeyError: 'scripts/compiler/generate-shader-host.mjs'",
    'cause': 'The first audit reader assumed all prior review files belong to the package measurement source scope; the compiler generator is outside that explicit scope.',
    'disposition': 'Read the additional prior-review file from the exact immutable Git commit. The declared measurement scope and its complete fingerprint were kept unchanged.',
}
result['conclusions'] = [
    'The original baseline and implementation-candidate canonical measurements are comparable.',
    'The implementation candidate really failed strict budgets: 6/9, with three unchanged-cap overruns; the original failure remains intact.',
    'All measured closure source hashes and the entire measurement source fingerprint agree with each exact Git candidate.',
    'The optional scene-host source is visited but has zero retained bytes in all five Adapter/consumer measured closures; the number of retained inputs does not increase.',
    'The retained Runtime paths and total retained Runtime bytes in the three Adapter roots and both consumer profiles are unchanged; there is no extra retained Runtime copy in these measured closures.',
    'The dominant retained minified growth is the Core source validation and sink publication/source-kind/lifetime boundary, with small Adapter option wiring; physical shader host retention decreased.',
    'Retained minified byte contributions explain closure costs but are not additive gzip contributions.',
    'These factual receipts can support a bounded numerical decision after the accepted capability and current authority are attached; this review selects no ceiling.',
]
result['limitations'] = [
    'No numeric budget, package implementation, test, workflow or root checkout was edited by this audit.',
    'No package bundle was rebuilt here. Canonical minified/gzip bytes and minified hashes come from the original source-bound Actions reports.',
    'The original archive contents were independently matched to the local extracted raw files; this is a content integrity check, not a GitHub artifact cryptographic provenance claim.',
    'The file-level canonical closure metadata does not identify individual retained functions. Diagnostic-read elimination also relies on the prior same-source bounded bundle review.',
    'The reported 37-case browser result is outside this factual budget audit until its originals are independently examined.',
    'A numeric edit still requires a new exact-head canonical strict run and independent review; this pre-edit receipt cannot validate a later candidate.',
]
result['recordedAtUtc'] = datetime.now(timezone.utc).isoformat()
out = OUT / 'canonical-package-budget-independent-review.json'
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'report': str(out), 'sha256': digest(out.read_bytes()),
                  'baseline': result['cases']['baseline']['independentGitCheck'],
                  'candidate': result['cases']['candidate']['independentGitCheck'],
                  'cases': [{'name': name, 'passed': data['strictPassed'], 'total': data['strictTotal'],
                             'exitCode': data['exitCode']} for name, data in result['cases'].items()]}, indent=2))
