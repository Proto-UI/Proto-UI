#!/usr/bin/env python3
"""Prepare evidence only; never stage, commit, edit source, or modify a run directory."""
from pathlib import Path
import datetime, fcntl, gzip, hashlib, json, os, re, string, subprocess, sys

ROOT = Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a')
OPS = Path(str(ROOT) + '-ops')
PACKET = Path(__file__).resolve().parent
VALIDATION_PACKET = OPS / 'diagnostic-validation-packet-v1'
HEAD = 'e470d1b0c21fc40e99e71cd7c49a76470444c6e7'
TREE = '1b273ac7d664a807a399e3f45d677f14aae8d43a'
SOURCE = 'packages/compiler/src/gpui-native-control-label.ts'
BEFORE = 'ee07845235af39b8a1fd723ba9f50ab0004093ea36b485873bc18d1be5bbe77a'
RED = 'e121c08e190660001b8faa0c0a379a216df8a1b11e76096ff6dd9a411c0cc819'
GREEN = 'f7290b713dfe98b38feafce0c894f3c16c4711e7018fc0f134d16e040291278d'
PRIOR = 'combined-native-union-r1'
AB = 'diagnostic-delivery-ab-r1'
FOLLOWUP = 'diagnostic-delivery-followup-r1'
SLUG = '2026-11-24-gpui-control-label-diagnostic-delivery'
RECORD = ROOT / 'internal/records' / (SLUG + '.md')
EVIDENCE = ROOT / 'internal/records/evidence' / SLUG
RECEIPT = OPS / 'diagnostic-delivery-archive-r1.json'
NODE = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin'
CASE = 'inactive_action_bridge_never_acquires_a_later_valid_pair'
ASSERTION = 'fresh same missing refusal after take is buffered once before the next take'
OFFICIAL_CASE = 'one_logical_participant_with_two_physical_views_cannot_name_or_activate'
OFFICIAL_ASSERTION = 'a refused current pairing must retain its diagnostic'
PINNED = {
    OPS / 'native-sdk-phase.py': '319a473c455524d64c4e95f692cabc7443e537f63b9fccfbf9f0d07c0564c9ea',
    OPS / 'native-union-phase.py': '49b709cc80e3f4d5294968a4e20ed0781251f043ef58726c8db322a2e9a4dbf8',
    OPS / 'native-union-archive.py': '8749f0284be3fd4e713083b0b1ce663c98e7838c1a419b3aecc3cb0c27c8125e',
    VALIDATION_PACKET / 'diagnostic-delivery-ab.py': 'e5531a85319c2e1aec0a42ba231dc37299735ab7f17f749b44dfa15736b92f72',
    VALIDATION_PACKET / 'diagnostic-delivery-followup.py': '73c298fdfbc9e61916cca05951ec17303ff80b6de1b3d319b2d393357f86facd',
    VALIDATION_PACKET / 'diagnostic-delivery-controls-only.patch': '915a7530b415c09563d474b04b1f2b0f42e291e37c4a3c540d5837f9aa32620c',
    VALIDATION_PACKET / 'diagnostic-delivery-product-only.patch': '88014e239bae52615342cc89f2972a1a8023f7bbf057cb2a814da0bfccda9c30',
    VALIDATION_PACKET / 'root-diagnostic-source-review.md': '544faa7f23ee5a116734a4dfa1e654a8fed83a3aac72ee63364105e68fb15479',
}
CI = {
    'job-137990901268.log': (1930782, 'dfe7848478a431859ae21a711507e61fa58feacb192ce5a9359eb79ef13883cd'),
    'job-137990901202.log': (1900945, 'd2668cc9fc185e5e7a94c6ebe58fa0d86fc2fae6c4decd93ab95f902eb96aaad'),
}
NOW = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
DIGEST = lambda raw: hashlib.sha256(raw).hexdigest()
SHA = lambda path: DIGEST(Path(path).read_bytes())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, timeout=90)

def load(path):
    return json.loads(Path(path).read_text())

def rust(path):
    text = re.sub(r'\x1b\[[0-9;]*m', '', Path(path).read_text(errors='replace'))
    return [dict(result=m[0], passed=int(m[1]), failed=int(m[2]), ignored=int(m[3]),
                 measured=int(m[4]), filtered=int(m[5])) for m in re.findall(
        r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', text)]

def total(rows):
    return {k: sum(x[k] for x in rows) for k in ['passed', 'failed', 'ignored', 'measured', 'filtered']}

def check_rust(path, passed, failed=0, filtered=0):
    rows = rust(path)
    result = total(rows)
    assert rows and result == dict(passed=passed, failed=failed, ignored=0, measured=0, filtered=filtered), (path, rows)
    assert all(x['result'] == ('FAILED' if x['failed'] else 'ok') for x in rows), path
    return result

def by_name(result):
    rows = result['commands']
    assert len({r['name'] for r in rows}) == len(rows)
    return {r['name']: r for r in rows}

def inventory(folder):
    assert folder.is_dir(), folder
    files = {}
    for p in sorted(folder.rglob('*')):
        assert not p.is_symlink(), ('Unexpected artifact symlink', p)
        if p.is_file():
            assert not {'target', '.git', 'node_modules', '__pycache__'}.intersection(p.relative_to(folder).parts), p
            files[str(p.relative_to(folder))] = SHA(p)
    assert files, folder
    return files

def check_vitest(path, count, expected_paths):
    value = load(path)
    assert value['success'] is True
    assert value['numTotalTests'] == value['numPassedTests'] == count
    assert all(value.get(k, 0) == 0 for k in ['numFailedTests', 'numPendingTests', 'numTodoTests'])
    assert {r['name'] for r in value['testResults']} == {str(ROOT / p) for p in expected_paths}
    assert all(r['status'] == 'passed' and r['assertionResults'] and
               all(a['status'] == 'passed' for a in r['assertionResults']) for r in value['testResults'])
    return {k: value.get(k) for k in ['success', 'numTotalTests', 'numPassedTests',
                                    'numFailedTests', 'numPendingTests', 'numTodoTests']}

def main():
    assert len(sys.argv) == 1, 'This archive is bound to the named completed phases; it does not run tests.'
    lock = (OPS / 'diagnostic-delivery.lock').open('a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    active = load(OPS / 'diagnostic-delivery-active.json')
    assert active['state'] in ['passed', 'failed'] and not active.get('pendingChild'), active
    assert not RECEIPT.exists() and not RECORD.exists() and not EVIDENCE.exists(), 'Reconcile any prior archive attempt'
    state = {'state': 'preflight', 'startedAt': NOW(), 'scope': 'Evidence preparation only; no git add or commit'}
    def save():
        RECEIPT.write_text(json.dumps(state, indent=2) + '\n')
    save()
    try:
        assert git('rev-parse', 'HEAD').decode().strip() == HEAD
        assert git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
        assert not git('diff', '--cached', '--name-only').strip()
        assert git('status', '--porcelain=v1', '--untracked-files=all').decode().strip() == 'M ' + SOURCE
        for path, digest in PINNED.items():
            assert SHA(path) == digest, ('Changed reviewed input', path)
        prior_path = OPS / PRIOR / 'status.json'
        prior = load(prior_path)
        assert SHA(prior_path) == '4f15fc9b5cc8a8fc06f9ff5c10ba1aa66c4f597603b3530a0e2d6436527be91b'
        assert prior['state'] == 'failed' and prior['sourceStable'] is True
        assert prior['sourceHead'] == prior['headAfter'] == HEAD
        assert prior['sourceTree'] == prior['treeAfter'] == TREE
        baseline = prior['sourceBefore']
        assert baseline == prior['sourceAfter'] and len(baseline) == 294 and baseline[SOURCE] == BEFORE
        expected = dict(baseline); expected[SOURCE] = GREEN
        assert {name: SHA(ROOT / name) for name in expected} == expected
        prior_commands = by_name(prior)
        assert len(prior_commands) == 12
        assert prior_commands['official-label-consumer']['exitCode'] == 101
        assert all(r['exitCode'] == 0 for name, r in prior_commands.items() if name != 'official-label-consumer')
        prior_checks = {name: check_rust(OPS / PRIOR / (name + '.log'), n, failed)
                        for name, n, failed in [('sdk-controls', 62, 0), ('six-native-consumers', 74, 0),
                                               ('numeric-consumer', 9, 0), ('official-label-consumer', 8, 1)]}
        prior_source_files = [x for x in prior_commands['source-controls']['command'] if x.endswith('.test.ts')]
        assert len(prior_source_files) == 18
        prior_source = check_vitest(OPS / PRIOR / 'source-controls.json', 343, prior_source_files)
        original_failure = (OPS / PRIOR / 'official-label-consumer.log').read_text()
        assert OFFICIAL_ASSERTION in original_failure and OFFICIAL_CASE in original_failure
        ab_path = OPS / AB / 'status.json'; ab = load(ab_path)
        assert SHA(ab_path) == '453719e6522df32887767d1471b33d4367e279a637d5c9a4a94f59f70096faeb'
        assert ab['state'] == 'passed' and ab['candidateSha256'] == GREEN and ab['sourceAfter'] == expected
        assert ab['expectedHead'] == HEAD and ab['expectedTree'] == TREE
        assert ab['priorReceipt']['sha256'] == SHA(prior_path)
        assert ab['runnerSha256'] == PINNED[VALIDATION_PACKET / 'diagnostic-delivery-ab.py']
        assert not ab.get('pendingChild') and all(r['exitCode'] == 0 for r in ab['commands'])
        red_map = dict(baseline); red_map[SOURCE] = RED
        for label, mapping in [('baseline', baseline), ('controls-applied', red_map),
                               ('after-sdk-red', red_map), ('full-applied', expected), ('after-sdk-green', expected)]:
            assert ab['snapshots'][label] == mapping, label
        sdk_checks = {}
        for suffix, source_map, exit_codes, counts in [
                ('red', red_map, [0, 0, 101], (61, 1)), ('green', expected, [0, 0, 0], (62, 0))]:
            folder = OPS / (AB + '-sdk-' + suffix); receipt = load(folder / 'status.json')
            index = 0 if suffix == 'red' else 1
            binding = ab['sdkReceipts'][index]
            assert binding['sha256'] == SHA(folder / 'status.json') and binding['rawSha256'] == SHA(folder / 'sdk-controls.log')
            assert receipt['state'] == ('failed' if suffix == 'red' else 'passed') and receipt['full'] is False
            assert receipt['sourceHead'] == HEAD and receipt['sourceBefore'] == receipt['sourceAfter']
            assert receipt['sourceBefore'].get(SOURCE) == source_map[SOURCE]
            assert receipt['sourceBefore'] and all(source_map.get(p) == h for p, h in receipt['sourceBefore'].items())
            assert [r['name'] for r in receipt['commands']] == ['numeric-producer', 'numeric-metadata', 'sdk-controls']
            assert [r['exitCode'] for r in receipt['commands']] == exit_codes
            sdk_checks[suffix] = check_rust(folder / 'sdk-controls.log', *counts)
        red_text = (OPS / (AB + '-sdk-red') / 'sdk-controls.log').read_text()
        assert ASSERTION in red_text
        failures = [x.strip() for x in red_text.rsplit('failures:', 1)[-1].split('test result:', 1)[0].splitlines() if x.strip()]
        assert len(failures) == 1 and failures[0].endswith('::' + CASE), failures
        follow_path = OPS / FOLLOWUP / 'status.json'; follow = load(follow_path)
        assert follow['state'] in ['passed', 'failed'] and not follow.get('pendingChild'), 'Follow-up must be terminal'
        assert follow['sourceHead'] == HEAD and follow['sourceTree'] == TREE and follow['candidateSha256'] == GREEN
        assert follow['priorAb']['sha256'] == SHA(ab_path)
        assert follow['runnerSha256'] == PINNED[VALIDATION_PACKET / 'diagnostic-delivery-followup.py']
        assert follow['sourceBefore'] == follow['sourceFinal'] == expected
        if 'sourceAfter' in follow:
            assert follow['sourceAfter'] == expected
        follow_commands = by_name(follow)
        required = {'official-label-consumer': (9, 0), 'ordinary-control-label': (14, 0),
                    'adapter-projection': (19, 0), 'adapter-a11y-state-nodes': (2, 6),
                    'adapter-accessibility-flag-nodes': (1, 7)}
        follow_checks = {}
        for name, (n, filtered) in required.items():
            path = OPS / FOLLOWUP / (name + '.log')
            if name in follow_commands:
                follow_checks[name] = {'exitCode': follow_commands[name].get('exitCode'),
                                       'rustResults': rust(path), 'totals': total(rust(path))}
                if follow['state'] == 'passed':
                    check_rust(path, n, filtered=filtered)
        follow_source = None
        source_path = OPS / FOLLOWUP / 'source-controls.json'
        focused = ['packages/compiler/test/' + n + '.test.ts' for n in
                   ['gpui-control-label', 'control-label-lowering', 'gpui-sdk-compatibility']]
        if follow['state'] == 'passed':
            assert all(r['exitCode'] == 0 for r in follow['commands'])
            assert set(required).issubset(follow_commands)
            assert {'official-label-producer', 'official-label-metadata', 'official-label-graph',
                    'ordinary-producer', 'ordinary-graph', 'source-controls', 'diff-check'}.issubset(follow_commands)
            follow_source = check_vitest(source_path, 106, focused)
            assert follow_source == follow['sourceControls']
        generated_claims = {}
        for stem, key in [('official-label', 'official'), ('ordinary', 'ordinary')]:
            if key + 'GeneratedAfter' in follow:
                actual = inventory(OPS / FOLLOWUP / stem)
                assert actual == follow[key + 'GeneratedBefore'] == follow[key + 'GeneratedAfter']
                generated_claims[stem] = {'fileCount': len(actual), 'beforeEqualsAfterEqualsArchive': True}
        if follow['state'] == 'passed':
            assert set(generated_claims) == {'official-label', 'ordinary'}
        ci_dir = OPS / 'diagnostic-ci-first-failures'
        ci = []
        for name, (size, digest) in CI.items():
            raw = (ci_dir / name).read_bytes()
            assert len(raw) == size and DIGEST(raw) == digest
            text = raw.decode('utf-8')
            assert OFFICIAL_CASE in text and OFFICIAL_ASSERTION in text
            assert 'test result: FAILED. 8 passed; 1 failed; 0 ignored;' in text
            ci.append({'job': name, 'bytes': size, 'sha256': digest, 'passed': 8, 'failed': 1})
        assert load(ci_dir / 'download-status.json')['state'] == 'passed'
        state.update(state='archiving', validationState=follow['state']); save()
        EVIDENCE.mkdir(parents=True)
        selected = {}
        def add(path, origin):
            path = Path(path)
            assert path.is_file() and not path.is_symlink(), path
            assert origin not in selected, origin
            selected[origin] = path
        phases = [PRIOR, AB, AB + '-sdk-red', AB + '-sdk-green', FOLLOWUP]
        inventories = {}
        for phase in phases:
            folder = OPS / phase
            for p in sorted(folder.iterdir()):
                if p.is_file() and p.suffix in {'.json', '.log'}:
                    add(p, 'runs/' + phase + '/' + p.name)
            for stem in ['numeric', 'ordinary', 'official-label']:
                if (folder / stem).is_dir():
                    values = inventory(folder / stem)
                    inventories[phase + '/' + stem] = {'timing': 'Inventory captured at archive preparation; not by itself a before/after run claim',
                                                        'fileCount': len(values), 'files': values}
                    for name in values:
                        add(folder / stem / name, 'runs/' + phase + '/' + stem + '/' + name)
        for path in PINNED:
            add(path, 'scripts/' + path.name)
        add(Path(__file__), 'scripts/diagnostic-delivery-archive.py')
        add(PACKET / 'diagnostic-delivery-record-template.md', 'scripts/diagnostic-delivery-record-template.md')
        add(PACKET / 'archive-packet-manifest.json', 'scripts/archive-packet-manifest.json')
        add(PACKET / 'ARCHIVE-README.md', 'scripts/ARCHIVE-README.md')
        add(PACKET / 's5-independent-diagnostic-review.md', 'reviews/s5-independent-diagnostic-review.md')
        for name in CI:
            add(ci_dir / name, 'ci/' + name)
        add(ci_dir / 'download-status.json', 'ci/download-status.json')
        for name in ['linux-readback.json', 'mac-readback.json', 'final-api-readback.json', 'source-log-manifest.json']:
            add(PACKET / name, 'ci/' + name)
        for name in ['diagnostic-ab-launch.json', 'diagnostic-ab-launch-preflight.json', 'diagnostic-ab-launch.log']:
            if (OPS / name).is_file():
                if not name.endswith('.log') or (OPS / name).stat().st_size > 0:
                    add(OPS / name, 'ops/' + name)
        for name in ['diagnostic-followup-launch.json', 'diagnostic-followup-launch.log']:
            add(OPS / name, 'ops/' + name)
        files = []
        original_hashes = {}
        def store(raw, origin):
            packed = gzip.compress(raw, compresslevel=9, mtime=0)
            path = EVIDENCE / (origin + '.gz')
            path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(packed)
            assert gzip.decompress(path.read_bytes()) == raw
            files.append({'path': str(path.relative_to(EVIDENCE)), 'origin': origin,
                          'rawBytes': len(raw), 'rawSha256': DIGEST(raw),
                          'gzipBytes': len(packed), 'gzipSha256': DIGEST(packed)})
        for origin, path in selected.items():
            raw = path.read_bytes(); original_hashes[str(path)] = DIGEST(raw); store(raw, origin)
        original = git('show', HEAD + ':' + SOURCE)
        assert DIGEST(original) == BEFORE
        store(original, 'source/before/' + SOURCE)
        store((ROOT / SOURCE).read_bytes(), 'source/after/' + SOURCE)
        store(git('diff', '--binary', '--', SOURCE), 'source/diagnostic-delivery-applied.patch')
        manifest = {
            'schemaVersion': 1, 'baseHead': HEAD, 'baseTree': TREE, 'preparedSourceSha256': GREEN,
            'sourcePath': SOURCE, 'sourceFileCount': 294, 'sourceBefore': baseline, 'sourceAfter': expected,
            'changedSourcePaths': [SOURCE], 'priorPhase': PRIOR, 'abPhase': AB, 'followupPhase': FOLLOWUP,
            'validationState': follow['state'], 'priorChecks': prior_checks, 'priorSourceControls': prior_source,
            'sdkAb': sdk_checks, 'focusedChecks': follow_checks, 'focusedSourceControls': follow_source,
            'generatedInventoriesAtArchive': inventories, 'followupGeneratedIdentityClaims': generated_claims,
            'ciFirstFailures': ci, 'commands': {PRIOR: prior['commands'], AB: ab['commands'], FOLLOWUP: follow['commands']},
            'scope': 'One diagnostic queue helper and assertions in one existing SDK case; focused generated native and Adapter checks. Prior broader passes were not rerun in full.',
            'notClaims': ['GitHub approval', 'new macOS repair run', 'OS or assistive-technology delivery',
                          'whole Adapter workspace', 'browser retirement', 'full 18-source rerun on the repaired source'],
            'roundtripVerified': True, 'originalPhaseFilesUnchangedDuringArchive': True, 'files': files,
        }
        manifest_path = EVIDENCE / 'manifest.json'
        manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
        def counts_text(value):
            return ', '.join(str(value[k]) + ' ' + k for k in ['passed', 'failed', 'ignored', 'filtered'])
        prior_rows = '\n'.join('| ' + name + ' | ' + counts_text(value) + ' |' for name, value in prior_checks.items())
        follow_rows = '\n'.join('| ' + name + ' | ' +
                               (counts_text(follow_checks[name]['totals']) + '; exit ' + str(follow_checks[name]['exitCode'])
                                if name in follow_checks else 'Not executed in this receipt') + ' |' for name in required)
        outcome = ('The focused repair verification passed. The original failed runs remain failed and are preserved below.'
                   if follow['state'] == 'passed' else
                   'The focused continuation failed. This record preserves that failure and does not establish readiness.')
        template = string.Template((PACKET / 'diagnostic-delivery-record-template.md').read_text())
        RECORD.write_text(template.substitute(
            OUTCOME=outcome, BASE=HEAD, TREE=TREE, SOURCE=SOURCE, BEFORE=BEFORE, RED=RED, GREEN=GREEN,
            PRIOR=PRIOR, AB=AB, FOLLOWUP=FOLLOWUP, PRIOR_ROWS=prior_rows, FOLLOWUP_ROWS=follow_rows,
            PRIOR_SOURCE=str(prior_source['numPassedTests']), FOLLOWUP_STATE=follow['state'],
            FOCUSED_SOURCE=(str(follow_source['numPassedTests']) + ' passed, 0 failed, 0 pending, 0 todo across three files'
                            if follow_source else 'No successful complete three-file receipt'),
            RED_COUNTS=counts_text(sdk_checks['red']), GREEN_COUNTS=counts_text(sdk_checks['green']),
            GENERATED=json.dumps(generated_claims, sort_keys=True), SLUG=SLUG,
            PRIOR_FINISHED=prior['finishedAt'], AB_FINISHED=ab['finishedAt'], FOLLOWUP_FINISHED=follow['finishedAt']))
        env = dict(os.environ); env['PATH'] = NODE + ':' + env['PATH']
        with (OPS / 'diagnostic-delivery-archive-format.log').open('w') as log:
            subprocess.run(['node', 'node_modules/prettier/bin/prettier.cjs', '--write',
                            str(RECORD.relative_to(ROOT)), str(manifest_path.relative_to(ROOT))],
                           cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=120, check=True)
        assert git('rev-parse', 'HEAD').decode().strip() == HEAD
        assert not git('diff', '--cached', '--name-only').strip()
        assert git('diff', '--name-only').decode().splitlines() == [SOURCE]
        assert {name: SHA(ROOT / name) for name in expected} == expected
        assert all(SHA(path) == digest for path, digest in original_hashes.items()), 'Original evidence changed during archive'
        for entry in files:
            packed = (EVIDENCE / entry['path']).read_bytes()
            assert DIGEST(packed) == entry['gzipSha256'] and DIGEST(gzip.decompress(packed)) == entry['rawSha256']
        new_paths = [str(RECORD.relative_to(ROOT)), str(manifest_path.relative_to(ROOT))] + [
            str((EVIDENCE / entry['path']).relative_to(ROOT)) for entry in files]
        state.update(state='prepared', validationState=follow['state'], sourceHead=HEAD, sourceTree=TREE,
                     sourcePath=SOURCE, sourceSha256=GREEN, sourceFileCount=294, sourceStable=True,
                     sourceChanges=[SOURCE], recordPath=str(RECORD), recordSha256=SHA(RECORD),
                     manifestPath=str(manifest_path), manifestSha256=SHA(manifest_path),
                     createdPaths=sorted(new_paths), stagePaths=[SOURCE] + sorted(new_paths),
                     artifactCount=len(files), rawBytes=sum(x['rawBytes'] for x in files),
                     gzipBytes=sum(x['gzipBytes'] for x in files),
                     originalPhaseFilesUnchanged=True, gitAddExecuted=False, gitCommitExecuted=False)
    except Exception as error:
        state.update(state='failed', error=repr(error))
        raise
    finally:
        state['finishedAt'] = NOW(); save()
    return 0 if state['validationState'] == 'passed' else 2

if __name__ == '__main__':
    raise SystemExit(main())
