from pathlib import Path
import datetime, gzip, hashlib, json, os, re, subprocess, sys

root = Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a')
ops = Path(str(root) + '-ops')
phase = sys.argv[1]
assert re.fullmatch('[a-z0-9-]+', phase)
work = ops / phase
slug = '2026-11-24-gpui-native-integrated-validation'
record = root / 'internal/records' / (slug + '.md')
evidence = root / 'internal/records/evidence' / slug
receipt = ops / ('archive-' + phase + '.json')
digest = lambda data: hashlib.sha256(data).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True, timeout=90).strip()
state = {'state': 'preflight', 'startedAt': now(), 'phase': phase}
def save():
    receipt.write_text(json.dumps(state, indent=2) + '\n')
save()
try:
    result = json.loads((work / 'status.json').read_text())
    assert result['state'] == 'passed' and result['sourceStable']
    assert result['sourceBefore'] == result['sourceAfter']
    assert result['sourceHead'] == git('rev-parse', 'HEAD')
    assert not git('status', '--porcelain=v1', '--untracked-files=normal')
    assert len(result['commands']) == 16 and all(row['exitCode'] == 0 for row in result['commands'])
    before = result['sourceBefore']
    assert all(digest((root / path).read_bytes()) == sha for path, sha in before.items())
    by_name = {row['name']: row for row in result['commands']}
    source_report = by_name['source-controls']['vitest']
    assert source_report['success'] and not any(source_report.get(key) for key in ['numFailedTests', 'numPendingTests', 'numTodoTests'])
    totals = {}
    for name in ['sdk-controls', 'six-native-consumers', 'numeric-consumer', 'official-label-consumer',
                 'adapter-projection', 'adapter-a11y-state-nodes', 'adapter-accessibility-flag-nodes']:
        rows = by_name[name]['rustTestResults']
        totals[name] = {key: sum(row[key] for row in rows) for key in ['passed', 'failed', 'ignored', 'measured', 'filtered']}
        assert totals[name]['passed'] > 0 and totals[name]['failed'] == totals[name]['ignored'] == 0
    assert all(by_name[name]['exactCountMatched'] for name in ['adapter-projection', 'adapter-a11y-state-nodes', 'adapter-accessibility-flag-nodes'])
    generated = {}
    for stem in ['ordinary', 'numeric', 'official-label']:
        for path in sorted((work / stem).rglob('*')):
            if path.is_file() and path.suffix in {'.rs', '.toml', '.lock', '.json'}:
                raw = path.read_bytes()
                generated[str(path.relative_to(work))] = {'bytes': len(raw), 'sha256': digest(raw)}
    generated_path = work / 'generated-after.json'
    assert not generated_path.exists()
    generated_path.write_text(json.dumps({'timing': 'After all commands completed. This is not a generated before/after identity claim.',
                                         'sourceHead': result['sourceHead'], 'files': generated}, indent=2) + '\n')
    assert not record.exists() and not evidence.exists()
    evidence.mkdir(parents=True)
    selected = [(path, 'run/' + path.name) for path in sorted(work.iterdir())
                if path.is_file() and path.suffix in {'.json', '.log'}]
    selected += [(ops / 'native-union-phase.py', 'scripts/native-union-phase.py'),
                 (Path(__file__), 'scripts/native-union-archive.py')]
    files = []
    for path, origin in selected:
        raw = path.read_bytes()
        packed = gzip.compress(raw, compresslevel=9, mtime=0)
        target = evidence / (origin + '.gz')
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(packed)
        assert gzip.decompress(target.read_bytes()) == raw
        files.append({'path': str(target.relative_to(evidence)), 'origin': origin,
                      'rawBytes': len(raw), 'rawSha256': digest(raw),
                      'gzipBytes': len(packed), 'gzipSha256': digest(packed)})
    manifest = {
        'schemaVersion': 1, 'sourceHead': result['sourceHead'], 'sourceTree': result['sourceTree'],
        'phase': phase, 'startedAt': result['startedAt'], 'finishedAt': result['finishedAt'],
        'sourceFileCount': len(before), 'sourceBeforeEqualsAfter': True,
        'sourceHashes': before, 'checks': totals, 'sourceTests': source_report,
        'requestedSourceFiles': 18, 'generatedFileCountAfter': len(generated),
        'generatedAfterOnly': True, 'commands': result['commands'],
        'scope': 'Generated native and targeted Adapter integration, not OS/AT acceptance or browser timing.',
        'roundtripVerified': True, 'files': files,
    }
    (evidence / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    rows = [
        ('Generated GPUI SDK controls', 'sdk-controls'),
        ('Six official ordinary consumer suites', 'six-native-consumers'),
        ('Official numeric accessibility consumer', 'numeric-consumer'),
        ('Official BaseButton / Label / Input / InputDelegate consumer', 'official-label-consumer'),
        ('Adapter accessibility projection', 'adapter-projection'),
        ('Adapter readOnly/disabled node controls', 'adapter-a11y-state-nodes'),
        ('Adapter combined accessibility flags node control', 'adapter-accessibility-flag-nodes'),
    ]
    table = '\n'.join('| ' + label + ' | ' + str(totals[name]['passed']) + ' passed, 0 failed, 0 ignored |' for label, name in rows)
    text = f"""# Integrated GPUI native validation — 2026-11-24

This record verifies the combined native/compiler/Adapter source after the previously separate repairs and concurrent changes were integrated. It supplies review evidence for PR #1738. It does not promote a draft host capability or claim release, operating-system accessibility, assistive-technology delivery, or GitHub approval.

## Source and integration

The actual tested commit is `{result['sourceHead']}`, with tree `{result['sourceTree']}`. All {len(before)} recorded source and fixture hashes are identical before and after the complete run; the checkout remained clean and at that same commit. This later evidence-only commit does not change those test inputs.

The integrated history includes the native composition and retained physical ControlLabel repair from `52c87232f593d85a28cbd04ad205f0d5fe6f03a3`, the independent changes already published at `0b7b212d3193ea5c7ae219c0501036ee1255e3f2`, and main `0fbb52ef832cc27c78e24c28c59a55a16f51d7fe`. The callable getter repair is included in the exact source hashes and has its own provenance record.

The native merge retains the additional physical replacement/ambiguity SDK case, actual Scroll readiness rejection, detach input/observation cleanup, the pending-end epoch fence, and both additional pause consumers. It keeps the restored external_scroll producer output and the single scroll_reader output. The GPUI source profile retains exactly one scroll.sync admission after reconciling two independent duplicate-removal commits. Official ControlLabel consumers use the canonical action lease and preserve diagnostic assertions.

Adapter integration keeps exact boolean readOnly/disabled projection semantics, the production renderer's accessibility-flag downcasts, the existing controls, and both branches' additional node and projection controls. Read-only state does not remove the enabled actions or become disabled state.

The merged source checks include nine native/profile source files, the seven capture/callable regression files, and two new presence-control files. In particular, the concurrently added official Input capture-facade cases remain present. Getter authority comes from actual captured provenance; missing own keys and own undefined values remain separate alternatives.

## Executed checks

All {len(result['commands'])} commands in `{phase}` exited zero. The run used Node 24, pnpm 10.32.1, Rust 1.98.1, offline locked Cargo, one build worker, the existing task-owned Cargo target, and a fresh short temporary directory. Generated Rust came from the repository's official producers and was not edited manually.

| Check | Actual result |
| --- | --- |
{table}
| Eighteen focused compiler source files | {source_report['numPassedTests']} passed, 0 failed, 0 pending, 0 todo |
| Official ordinary producer, pinned Cargo graph, and default library compilation | Passed |
| Working-tree whitespace check | Passed |

Adapter unit filters intentionally select the two named readOnly/disabled controls and the separately added combined-flags control. Other Adapter unit tests are filtered, not newly claimed as a full workspace pass. The manifest records the exact filtered counts.

## Preserved evidence and boundaries

The [earlier composition record](2026-11-24-gpui-native-composition-recovery.md) retains the original Rust compilation failures, consumer failures, fixture corrections, and its own successful 61-SDK/72-consumer result. Those counts describe that earlier source. This record reports the actual new combined run above.

The [getter provenance and presence record](2026-11-23-capture-getter-provenance-and-presence.md) retains the unsafe counterexamples, the admitted host-spread red/green pair, the failed fixture admission attempts, and the original 113 passing tests. Its old-checkout workspace type check exhausted a 240-second budget without diagnostics; that timeout is not changed into a pass here. Final published-head type and CI validation are separate gates.

This native run does not verify the browser's 250 ms retirement deadline, web production bundle budgets, the complete Adapter workspace, other operating systems, or physical assistive technologies. Those claims require their separate actual results. No browser deadline or semantic assertion was relaxed for this record.

The [manifest](evidence/{slug}/manifest.json) contains the complete source hash map, exact commands, raw and compressed artifact sizes and SHA-256 digests, actual test counts, and a generated-file inventory. The generated-file inventory was taken after the run and is explicitly not a before/after comparison. Every compressed artifact was decompressed and verified byte-for-byte. Historical records and evidence files remain untouched.
"""
    record.write_text(text)
    env = dict(os.environ)
    env['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:' + env['PATH']
    with (ops / ('archive-' + phase + '-format.log')).open('w') as log:
        subprocess.run(['node', 'node_modules/prettier/bin/prettier.cjs', '--write',
                        str(record.relative_to(root)), str((evidence / 'manifest.json').relative_to(root))],
                       cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=120)
    assert all(digest((root / path).read_bytes()) == sha for path, sha in before.items())
    assert not git('diff', '--name-only'), 'Existing tracked files changed during archive creation'
    for entry in files:
        raw = (evidence / entry['path']).read_bytes()
        assert digest(raw) == entry['gzipSha256'] and digest(gzip.decompress(raw)) == entry['rawSha256']
    state.update(state='prepared', sourceHead=result['sourceHead'], sourceTree=result['sourceTree'],
                 sourceFileCount=len(before), sourceStable=True, checks=totals, sourceTests=source_report,
                 recordPath=str(record), recordSha256=digest(record.read_bytes()),
                 manifestPath=str(evidence / 'manifest.json'), manifestSha256=digest((evidence / 'manifest.json').read_bytes()),
                 artifactCount=len(files), generatedFilesAfter=len(generated),
                 rawBytes=sum(f['rawBytes'] for f in files), gzipBytes=sum(f['gzipBytes'] for f in files))
except Exception as error:
    state.update(state='failed', error=repr(error))
    raise
finally:
    state['finishedAt'] = now()
    save()

