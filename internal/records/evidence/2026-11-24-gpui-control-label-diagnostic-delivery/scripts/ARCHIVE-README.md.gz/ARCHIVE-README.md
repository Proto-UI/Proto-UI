# Diagnostic-delivery evidence archive packet

Prepared in primary scratch only. The archive program has been parsed with Python AST; it has not been imported or executed. No live source, generated Rust, test worker, index, or commit was changed by packet preparation.

## Run after source review

Extract this packet to a fresh ops directory, for example:

`/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a-ops/diagnostic-archive-packet-v2`

Then run its `diagnostic-delivery-archive.py` with no arguments. The script is deliberately bound to:

- Original failed `combined-native-union-r1` on clean e470, before the repair.
- Completed `diagnostic-delivery-ab-r1` and its two SDK child phases.
- Terminal `diagnostic-delivery-followup-r1` on the uncommitted f729 source.
- Reviewed drivers and patches in `diagnostic-validation-packet-v1`.
- Exact Linux/macOS first-failure logs in `diagnostic-ci-first-failures`.

The existing diagnostic lock and active receipt must be terminal. HEAD must still be e470, the index must be empty, and the only working-tree change must be `packages/compiler/src/gpui-native-control-label.ts`. Existing archive outputs cause a refusal so that a partial or prior attempt can be reconciled without overwriting it.

## Outputs and conclusions

The record slug is `2026-11-24-gpui-control-label-diagnostic-delivery`. The script writes only the new record, its evidence/manifest, individual gzip artifacts, and its own new ops receipt/format log. It never writes to any original run directory and never stages or commits.

The receipt is `root-native-compose-75d5e28a-ops/diagnostic-delivery-archive-r1.json`. A successful preparation returns exact `createdPaths` and `stagePaths`; the latter includes the sole source path plus the record, manifest, and every gzip. It also records current source, record, manifest and artifact hashes, actual validation state, and `gitAddExecuted: false` / `gitCommitExecuted: false`.

A completed passing follow-up is checked against raw counts 9 official, 14 ordinary ControlLabel, 106 tests in the three named source files, and Adapter 19 + 2 (6 filtered) + 1 (7 filtered), all with zero ignored. A terminal failed follow-up can be preserved with a failed conclusion; the archive program then returns 2, not readiness. Pending work or drift is refused.

The original full run remains failed at official 8/9. Its broader 62 SDK, 343 source, 74 ordinary and nine numeric passes remain tied to that original source. The SDK A/B receipts retain the real 61/1 expected failure and 62/62 correction. No counts are synthesized into a fictitious single all-green full run.

Generated files from the original run and both SDK phases are archived as archive-time inventories. Only the focused continuation already recorded generated before/after maps; the script independently compares those maps with current archived files. It does not invent older before/after receipts.

All original selected files and all 294 source hashes are rechecked after compression and formatting. Every gzip is decompressed and hashed. Formatting is limited to the two new record/manifest files. Ordinary hook execution, prepared/committed tree comparison, and published-head CI remain subsequent root-owned steps.

The original `native-union-archive.py` was read in full and its exact 11,944 bytes / SHA-256 `8749f0284be3fd4e713083b0b1ce663c98e7838c1a419b3aecc3cb0c27c8125e` were verified. This adaptation reuses its gzip/hash custody approach, but not its prior all-16-commands-passed assumptions or in-place generated-inventory write.
