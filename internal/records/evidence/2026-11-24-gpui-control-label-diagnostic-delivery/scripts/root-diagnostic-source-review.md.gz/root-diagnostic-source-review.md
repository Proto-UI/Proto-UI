# Root diagnostic-delivery source review

Reviewed 2026-11-23, before executing the diagnostic A/B drivers.

## Bound candidate

- Base: `e470d1b0c21fc40e99e71cd7c49a76470444c6e7`, tree `1b273ac7d664a807a399e3f45d677f14aae8d43a`.
- Sole source: `packages/compiler/src/gpui-native-control-label.ts`.
- Original SHA-256: `ee07845235af39b8a1fd723ba9f50ab0004093ea36b485873bc18d1be5bbe77a`.
- Controls-only SHA-256: `e121c08e190660001b8faa0c0a379a216df8a1b11e76096ff6dd9a411c0cc819`.
- Full candidate SHA-256: `f7290b713dfe98b38feafce0c894f3c16c4711e7018fc0f134d16e040291278d`.

The original integrated native run failed at the official consumer's diagnostic assertion after its SDK, source selection, ordinary consumers and numeric consumer passed. The consumer drains the diagnostic queue and creates a fresh refused action. The old helper tied both queue insertion and stderr throttling to the last message, so draining the queue prevented a subsequent equal refusal from being observed.

The candidate separates queue availability from stderr throttling. An empty queue receives the current refusal, while repeated equal refusals before the next take remain coalesced. Changes of message continue to be recorded. No authority lookup, physical receipt validation, capture, or invocation function is changed. In particular, an earlier inert action does not acquire a newly valid pair.

The extended existing SDK case exercises missing, ambiguous and foreign pairs through the real factory, take and request APIs. It checks initial diagnostics, a fresh equal refusal after a take, coalescing before the next take, and silence and inactivity of old refused actions after repair. The existing assertions are retained; the SDK case count remains 62.

## Reviewed execution plan

The A/B driver `e5531a85319c2e1aec0a42ba231dc37299735ab7f17f749b44dfa15736b92f72` requires the original failed/stable 294-source receipt and clean exact base. It applies only the new controls, requires exactly 61 passed and one failed at the fresh-refusal assertion, and only then applies the helper correction and requires 62 passed. It reads the SDK runner's original status and raw results rather than relying on its outer exit status.

The continuation driver `73c298fdfbc9e61916cca05951ec17303ff80b6de1b3d319b2d393357f86facd` requires the successful A/B and exact final source. It runs the official generated Label nine cases, ordinary ControlLabel fourteen, the three existing source suites, and Adapter projection/state/flag selections of 19, two and one. It does not repeat the unchanged ordinary resource/Scroll or numeric consumers. Both drivers preserve pinned tools, offline single-job Cargo and the owned target, and stop on unexpected source drift, failures or unresolved owned processes.

No source-review blocker was found in this bounded change. This is source and driver review, not an executed validation result, GitHub APPROVE, native platform acceptance or permission to merge. Actual A/B and continuation outcomes must be recorded separately without rewriting the original failure.
