from pathlib import Path
import datetime, hashlib, json, os, re, signal, subprocess, sys, tempfile

root = Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a')
ops = Path(str(root) + '-ops')
phase, expected_head = sys.argv[1:3]
assert re.fullmatch('[a-z0-9-]+', phase)
assert re.fullmatch('[0-9a-f]{40}', expected_head)
work = ops / phase
work.mkdir(exist_ok=False)
numeric, ordinary, label = work / 'numeric', work / 'ordinary', work / 'official-label'
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

env = dict(os.environ)
env['PATH'] = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:/home/ezra/.cargo/bin:' + env['PATH']
env.update(CARGO_BUILD_JOBS='1', CARGO_TARGET_DIR='/tank/shared/projects/proto-ui-agent/s5-adapter-readonly-target75d5',
           CARGO_NET_OFFLINE='true', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CI='true')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True, timeout=60).strip()

tests = ['packages/compiler/test/' + name + '.test.ts' for name in [
    'gpui-control-label', 'control-label-lowering', 'gpui-authored-inputs', 'gpui-sdk-compatibility',
    'gpui-capabilities',
    'scroll-axis-sync', 'gpui-event-notification', 'gpui-hook-renderer', 'gpui-a11y-value',
    'capture-facade', 'value-ir', 'capture-lookup-integrity', 'authored-hook-language',
    'mutable-callable-orders', 'module-helper-capture-boundary', 'privileged-capture-metadata',
    'capture-getter-presence', 'capture-host-presence',
]]
files = set(root.glob('packages/compiler/src/*.ts'))
for stem in ['gpui-ordinary-values', 'gpui-a11y-value', 'gpui-control-label']:
    files.update(path for path in (root / 'packages/compiler/test/fixtures' / stem).iterdir() if path.is_file())
files.update(root / name for name in tests)
adapter = root / 'native/gpui'
files.update(path for path in (adapter / 'crates').rglob('*') if path.is_file() and
             (path.suffix == '.rs' or path.name in ['Cargo.toml', 'Cargo.lock']))
files.update(path for path in [adapter / 'Cargo.toml', adapter / 'Cargo.lock'] if path.is_file())
def snapshot():
    return {str(path.relative_to(root)): sha(path) for path in sorted(files)}

state = {'state': 'preflight', 'phase': phase, 'startedAt': now(), 'expectedHead': expected_head,
         'runnerSha256': sha(Path(__file__)), 'commands': [], 'scope':
         'Final merged source/native/Adapter union. Reuses the owned hot Cargo target without cleaning. Does not run browser or change source.'}
def save():
    temp = work / 'status.tmp'
    temp.write_text(json.dumps(state, indent=2) + '\n')
    temp.replace(work / 'status.json')

def run(name, args, limit=1200, expected_count=None):
    item = {'name': name, 'command': args, 'startedAt': now(), 'timeoutSeconds': limit}
    state['commands'].append(item)
    save()
    path = work / (name + '.log')
    with path.open('w') as log:
        child = subprocess.Popen(args, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        item['pid'] = child.pid
        save()
        try:
            code = child.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            code = 124
            item['timedOut'] = True
            for sig, seconds in [(signal.SIGTERM, 15), (signal.SIGKILL, 5)]:
                try:
                    os.killpg(child.pid, sig)
                    child.wait(timeout=seconds)
                    break
                except ProcessLookupError:
                    break
                except subprocess.TimeoutExpired:
                    continue
            if child.poll() is None:
                state['pendingChild'] = child.pid
                item['pendingChild'] = True
    item.update(exitCode=code, finishedAt=now())
    output = path.read_text(errors='replace')
    summaries = []
    for match in re.finditer(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', output):
        summaries.append(dict(result=match.group(1), passed=int(match.group(2)), failed=int(match.group(3)),
                              ignored=int(match.group(4)), measured=int(match.group(5)), filtered=int(match.group(6))))
    if summaries:
        item['rustTestResults'] = summaries
    if expected_count is not None:
        item['expectedTests'] = expected_count
        item['exactCountMatched'] = (sum(s['passed'] for s in summaries) == expected_count and
                                     sum(s['failed'] + s['ignored'] for s in summaries) == 0)
    if name == 'source-controls' and (work / 'source-controls.json').is_file():
        report = json.loads((work / 'source-controls.json').read_text())
        item['vitest'] = {key: report.get(key) for key in [
            'numTotalTestSuites', 'numPassedTestSuites', 'numFailedTestSuites',
            'numTotalTests', 'numPassedTests', 'numFailedTests', 'numPendingTests', 'numTodoTests', 'success']}
    save()
    return code == 0 and not item.get('pendingChild') and item.get('exactCountMatched', True)

base = ['cargo', '+1.98.1']
def body():
    if not run('numeric-producer', ['node', '--import', 'tsx', 'packages/compiler/test/fixtures/gpui-a11y-value/produce.mjs', str(numeric)], 300): return False
    if not run('numeric-metadata', base + ['metadata', '--offline', '--all-features', '--format-version', '1', '--manifest-path', str(numeric / 'Cargo.toml')], 300): return False
    if not run('sdk-controls', base + ['test', '--offline', '--locked', '--manifest-path', str(numeric / 'Cargo.toml'),
                                     '-p', 'proto-ui-gpui-native', '--features', 'test-support,gpui/test-support',
                                     '--lib', '--', '--test-threads=1', '--nocapture']): return False
    if not run('source-controls', ['corepack', 'pnpm@10.32.1', 'exec', 'vitest', 'run', '--maxWorkers=1',
                                   '--minWorkers=1', '--reporter=json', '--outputFile=' + str(work / 'source-controls.json')] + tests, 900): return False
    if not run('ordinary-producer', ['node', '--import', 'tsx', 'packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs', str(ordinary)], 300): return False
    manifest = ['--manifest-path', str(ordinary / 'transition/Cargo.toml')]
    if not run('ordinary-graph', ['node', 'scripts/gpui/check-cargo-graph.mjs'] + manifest +
               ['--git', 'https://github.com/zed-industries/zed', '--rev', '62e5991dd0f0c8a3af8d5e7e9c4652490d468db8',
                '--toolchain', '1.98.1', '--output', str(work / 'ordinary-graph.json')], 300): return False
    if not run('default-check', base + ['check', '--offline', '--locked'] + manifest + ['--lib']): return False
    if not run('six-native-consumers', base + ['test', '--offline', '--locked', '--no-fail-fast'] + manifest +
               ['--features', 'test-support', '--tests', '--', '--test-threads=1', '--nocapture']): return False
    if not run('numeric-consumer', base + ['test', '--offline', '--locked', '--manifest-path', str(numeric / 'Cargo.toml'),
                                         '--test', 'a11y_value', '--', '--test-threads=1', '--nocapture']): return False
    if not run('official-label-producer', ['node', '--import', 'tsx', 'packages/compiler/test/fixtures/gpui-control-label/produce.mjs', str(label)], 300): return False
    if not run('official-label-metadata', base + ['metadata', '--offline', '--all-features', '--format-version', '1',
                                                 '--manifest-path', str(label / 'Cargo.toml')], 300): return False
    if not run('official-label-consumer', base + ['test', '--offline', '--locked', '--manifest-path', str(label / 'Cargo.toml'),
                                                 '--test', 'control_label', '--', '--test-threads=1', '--nocapture']): return False
    adapter_args = base + ['test', '--offline', '--locked', '--manifest-path', str(adapter / 'Cargo.toml'), '-p', 'proto-ui-gpui']
    if not run('adapter-projection', adapter_args + ['--test', 'a11y_projection', '--', '--test-threads=1'], expected_count=19): return False
    if not run('adapter-a11y-state-nodes', adapter_args + ['--lib', 'a11y_state_tests', '--', '--test-threads=1'], expected_count=2): return False
    if not run('adapter-accessibility-flag-nodes', adapter_args + ['--lib', 'accessibility_flags_tests', '--', '--test-threads=1'], expected_count=1): return False
    return run('diff-check', ['git', 'diff', '--check'], 60)

save()
try:
    state.update(sourceHead=git('rev-parse', 'HEAD'), sourceTree=git('rev-parse', 'HEAD^{tree}'),
                 statusBefore=git('status', '--porcelain=v1', '--untracked-files=normal'))
    assert state['sourceHead'] == expected_head, 'unexpected source HEAD'
    assert not state['statusBefore'], 'working tree is not clean'
    state['sourceBefore'] = snapshot()
    state['environment'] = {key: env[key] for key in ['CARGO_BUILD_JOBS', 'CARGO_TARGET_DIR', 'CARGO_NET_OFFLINE',
                                                    'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG']}
    state['state'] = 'running'
    save()
    with tempfile.TemporaryDirectory(prefix='ncu75d5-', dir='/var/tmp') as tmp:
        env['TMPDIR'] = tmp
        ok = body()
    state['state'] = 'pending-child' if state.get('pendingChild') else ('passed' if ok else 'failed')
except Exception as error:
    state.update(state='failed', exception=repr(error))
finally:
    try:
        state.update(sourceAfter=snapshot(), headAfter=git('rev-parse', 'HEAD'), treeAfter=git('rev-parse', 'HEAD^{tree}'),
                     statusAfter=git('status', '--porcelain=v1', '--untracked-files=normal'))
        state['sourceStable'] = (state.get('sourceBefore') == state['sourceAfter'] and
                                 state.get('sourceHead') == state['headAfter'] and
                                 state.get('sourceTree') == state['treeAfter'] and not state['statusAfter'])
        if state['state'] == 'passed' and not state['sourceStable']:
            state['state'] = 'failed-source-drift'
    except Exception as error:
        state['readbackException'] = repr(error)
        if state['state'] == 'passed': state['state'] = 'failed-readback'
    state['finishedAt'] = now()
    save()
raise SystemExit(0 if state['state'] == 'passed' else 1)

