#!/usr/bin/env python3
"""Prepared only: focused follow-up after the strict diagnostic SDK A/B passes."""
from pathlib import Path
import datetime, fcntl, hashlib, importlib.util, json, os, re, shutil, subprocess, sys, tempfile

PACKET = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('diagnostic_ab', PACKET / 'diagnostic-delivery-ab.py')
ab = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ab)
ROOT, OPS, HEAD, TREE, SOURCE, GREEN = ab.ROOT, ab.OPS, ab.HEAD, ab.TREE, ab.SOURCE, ab.GREEN
now, sha = ab.now, ab.sha
BASE = ['cargo', '+1.98.1']
TESTS = ['packages/compiler/test/' + name + '.test.ts' for name in
         ['gpui-control-label', 'control-label-lowering', 'gpui-sdk-compatibility']]
PIN = '62e5991dd0f0c8a3af8d5e7e9c4652490d468db8'

def main():
    if len(sys.argv) != 3 or any(not re.fullmatch('[a-z0-9][a-z0-9-]{2,80}', x) for x in sys.argv[1:]):
        raise SystemExit('Usage: diagnostic-delivery-followup.py FRESH-PHASE PASSED-AB-PHASE')
    phase, previous_phase = sys.argv[1:]
    lock = (OPS / 'diagnostic-delivery.lock').open('a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    active = OPS / 'diagnostic-delivery-active.json'
    if active.exists():
        prior_active = json.loads(active.read_text())
        assert prior_active['state'] not in ['preflight', 'running', 'pending-child'], prior_active
    previous = OPS / previous_phase / 'status.json'
    prior = json.loads(previous.read_text())
    assert prior['state'] == 'passed' and prior['candidateSha256'] == GREEN
    assert [r['classification'] for r in prior['sdkReceipts']] == ['expected-red-61/1', 'green-62/62']
    expected = prior['sourceAfter']
    assert len(expected) == 294 and expected[SOURCE] == GREEN
    work = OPS / phase; work.mkdir(exist_ok=False)
    label, ordinary = work / 'official-label', work / 'ordinary'
    env = dict(os.environ)
    env['PATH'] = ab.NODE + ':/home/ezra/.cargo/bin:' + env['PATH']
    env.update(CARGO_BUILD_JOBS='1', CARGO_TARGET_DIR=ab.TARGET, CARGO_NET_OFFLINE='true',
               CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CI='true')
    temporary = Path(tempfile.mkdtemp(prefix='ncd75d5-', dir='/var/tmp')); env['TMPDIR'] = str(temporary)
    state = {'state': 'preflight', 'phase': phase, 'pid': os.getpid(), 'startedAt': now(),
             'runnerSha256': sha(__file__), 'abRunnerSha256': sha(PACKET / 'diagnostic-delivery-ab.py'),
             'priorAb': {'path': str(previous), 'sha256': sha(previous)},
             'sourceHead': HEAD, 'sourceTree': TREE, 'candidateSha256': GREEN, 'commands': [],
             'temporaryDirectory': str(temporary), 'scope': 'Official9, ordinary ControlLabel14, source3, Adapter19+2+1; no commit',
             'environment': {k: env[k] for k in ['CARGO_BUILD_JOBS', 'CARGO_TARGET_DIR',
                 'CARGO_NET_OFFLINE', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG']}}
    def save():
        (work / 'status.tmp').write_text(json.dumps(state, indent=2) + '\n')
        (work / 'status.tmp').replace(work / 'status.json')
        active.write_text(json.dumps({'phase': phase, 'pid': os.getpid(), 'state': state['state'],
            'status': str(work / 'status.json'), 'pendingChild': state.get('pendingChild')}, indent=2) + '\n')
    def run(name, args, limit=1200, count=None, filtered=False):
        item = {'name': name, 'command': args, 'startedAt': now(), 'timeoutSeconds': limit}
        state['commands'].append(item); save(); path = work / (name + '.log')
        with path.open('wb') as output:
            child = subprocess.Popen(args, cwd=ROOT, env=env, stdout=output,
                                     stderr=subprocess.STDOUT, start_new_session=True)
            item['pid'] = child.pid; save()
            try: code = child.wait(limit)
            except subprocess.TimeoutExpired:
                item.update(timedOut=True, pendingChild=child.pid)
                state['pendingChild'] = {'pid': child.pid, 'members': ab.members(child.pid)}
                save(); raise ab.PendingChild(name + ': keep this worker; do not repeat')
        live = ab.members(child.pid)
        item.update(exitCode=code, finishedAt=now(), log=str(path), logSha256=sha(path))
        if live:
            state['pendingChild'] = {'pgid': child.pid, 'members': live}; save()
            raise ab.PendingChild(name + ': descendants remain live')
        output = path.read_text(errors='replace')
        results = [dict(result=m[0], passed=int(m[1]), failed=int(m[2]), ignored=int(m[3]),
                        measured=int(m[4]), filtered=int(m[5])) for m in re.findall(
            r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', output)]
        if results: item['rustTestResults'] = results
        save(); assert code == 0, (name, code, str(path))
        if count is not None:
            assert results and sum(x['passed'] for x in results) == count, (name, results)
            assert all(x['result'] == 'ok' and x['failed'] == x['ignored'] == x['measured'] == 0
                       and (filtered or x['filtered'] == 0) for x in results), (name, results)
            item['exactTests'] = count; save()
        return output
    def snapshot():
        return {name: sha(ROOT / name) for name in expected}
    def guard(label):
        assert run(label + '-head', ['git', 'rev-parse', 'HEAD'], 60).strip() == HEAD
        assert run(label + '-tree', ['git', 'rev-parse', 'HEAD^{tree}'], 60).strip() == TREE
        assert run(label + '-status', ['git', 'status', '--porcelain=v1',
                   '--untracked-files=normal'], 60).strip() == 'M ' + SOURCE
        assert not run(label + '-index', ['git', 'diff', '--cached', '--name-only'], 60).strip()
        actual = snapshot(); state['source' + label] = actual; save()
        assert actual == expected, '294-source drift at ' + label
    def generated(folder):
        return {str(p.relative_to(folder)): sha(p) for p in sorted(folder.rglob('*')) if p.is_file()}
    def graph(name, manifest):
        run(name, ['node', 'scripts/gpui/check-cargo-graph.mjs', '--manifest-path', str(manifest),
                   '--git', 'https://github.com/zed-industries/zed', '--rev', PIN,
                   '--toolchain', '1.98.1', '--output', str(work / (name + '.json'))], 300)
    save()
    try:
        guard('Before'); state['state'] = 'running'; save()
        run('official-label-producer', ['node', '--import', 'tsx',
            'packages/compiler/test/fixtures/gpui-control-label/produce.mjs', str(label)], 300)
        receipt = json.loads((label / 'receipt.json').read_text())
        assert receipt['generatedRustEdited'] is False
        assert [x['stem'] for x in receipt['sources']] == ['button', 'label', 'input', 'input_delegate']
        authored = {x['source']: x['sourceSha256'] for x in receipt['sources']}
        assert all(sha(ROOT / name) == value for name, value in authored.items())
        state['officialAuthoredInputs'] = authored; save()
        run('official-label-metadata', BASE + ['metadata', '--offline', '--all-features',
            '--format-version', '1', '--manifest-path', str(label / 'Cargo.toml')], 300)
        graph('official-label-graph', label / 'Cargo.toml')
        state['officialGeneratedBefore'] = generated(label); save()
        run('official-label-consumer', BASE + ['test', '--offline', '--locked', '--manifest-path',
            str(label / 'Cargo.toml'), '--test', 'control_label', '--', '--test-threads=1', '--nocapture'], count=9)
        state['officialGeneratedAfter'] = generated(label)
        assert state['officialGeneratedAfter'] == state['officialGeneratedBefore']
        assert all(sha(ROOT / name) == value for name, value in authored.items()); save()

        run('ordinary-producer', ['node', '--import', 'tsx',
            'packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs', str(ordinary)], 300)
        manifest = ordinary / 'transition/Cargo.toml'
        graph('ordinary-graph', manifest)
        state['ordinaryGeneratedBefore'] = generated(ordinary); save()
        run('ordinary-control-label', BASE + ['test', '--offline', '--locked', '--manifest-path',
            str(manifest), '--features', 'test-support', '--test', 'control_label',
            '--', '--test-threads=1', '--nocapture'], count=14)
        state['ordinaryGeneratedAfter'] = generated(ordinary)
        assert state['ordinaryGeneratedAfter'] == state['ordinaryGeneratedBefore']; save()

        source_json = work / 'source-controls.json'
        run('source-controls', ['corepack', 'pnpm@10.32.1', 'exec', 'vitest', 'run',
            '--maxWorkers=1', '--minWorkers=1', '--reporter=json',
            '--outputFile=' + str(source_json)] + TESTS, 900)
        source = json.loads(source_json.read_text())
        assert source.get('success') is True and source['numPassedTests'] == source['numTotalTests'] > 0
        assert all(source.get(key, 0) == 0 for key in ['numFailedTests', 'numPendingTests', 'numTodoTests'])
        files = source['testResults']
        assert {x['name'] for x in files} == {str(ROOT / name) for name in TESTS}
        assert all(x['status'] == 'passed' and x['assertionResults']
                   and all(a['status'] == 'passed' for a in x['assertionResults']) for x in files)
        state['sourceControls'] = {k: source.get(k) for k in
            ['numTotalTests', 'numPassedTests', 'numFailedTests', 'numPendingTests', 'numTodoTests', 'success']}; save()

        adapter = BASE + ['test', '--offline', '--locked', '--manifest-path',
            str(ROOT / 'native/gpui/Cargo.toml'), '-p', 'proto-ui-gpui']
        run('adapter-projection', adapter + ['--test', 'a11y_projection', '--', '--test-threads=1'], count=19)
        run('adapter-a11y-state-nodes', adapter + ['--lib', 'a11y_state_tests', '--', '--test-threads=1'], count=2, filtered=True)
        run('adapter-accessibility-flag-nodes', adapter + ['--lib', 'accessibility_flags_tests',
            '--', '--test-threads=1'], count=1, filtered=True)
        run('diff-check', ['git', 'diff', '--check'], 60)
        guard('After'); state['state'] = 'passed'
    except ab.PendingChild as error:
        state.update(state='pending-child', error=str(error))
    except Exception as error:
        state.update(state='failed', error=repr(error))
    finally:
        state['sourceFinal'] = snapshot()
        if state['state'] != 'pending-child':
            shutil.rmtree(temporary); state['temporaryDirectoryRemoved'] = not temporary.exists()
        else: state['temporaryDirectoryRetainedForPendingChild'] = True
        state['finishedAt'] = now(); save()
    return 0 if state['state'] == 'passed' else 75 if state['state'] == 'pending-child' else 1

if __name__ == '__main__':
    raise SystemExit(main())
