from pathlib import Path
import os,json,subprocess,tempfile,datetime,hashlib,sys,re
r=Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a');o=Path(str(r)+'-ops')
phase=sys.argv[1];assert re.fullmatch('[a-z0-9-]+',phase)
full='--full'in sys.argv
work=o/phase;work.mkdir(exist_ok=False);numeric=work/'numeric';ordinary=work/'ordinary';label=work/'official-label'
env=dict(os.environ);env['PATH']='/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin:/home/ezra/.cargo/bin:'+env['PATH'];env['CARGO_BUILD_JOBS']='1';env['CARGO_TARGET_DIR']='/tank/shared/projects/proto-ui-agent/s5-adapter-readonly-target75d5';env['CARGO_NET_OFFLINE']='true';env['CARGO_PROFILE_DEV_DEBUG']='0';env['CARGO_PROFILE_TEST_DEBUG']='0';env['CI']='true'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=set(r.glob('packages/compiler/src/*.ts'))
for stem in ['gpui-ordinary-values','gpui-a11y-value','gpui-control-label']:
 files.update(p for p in (r/'packages/compiler/test/fixtures'/stem).iterdir()if p.is_file())
tests=['packages/compiler/test/'+name+'.test.ts'for name in ['gpui-control-label','control-label-lowering','gpui-authored-inputs','gpui-sdk-compatibility','scroll-axis-sync','gpui-event-notification','gpui-hook-renderer','gpui-a11y-value']]
files.update(r/p for p in tests)
snap=lambda:{str(p.relative_to(r)):sha(p)for p in sorted(files)}
state={'state':'running','phase':phase,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'sourceBefore':snap(),'full':full,'environment':{key:env[key]for key in ['CARGO_BUILD_JOBS','CARGO_TARGET_DIR','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG']},'commands':[]}
def save():(work/'status.json').write_text(json.dumps(state,indent=2))
def run(name,args,limit=1200):
 item={'name':name,'command':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};state['commands'].append(item);save()
 with(work/(name+'.log')).open('w')as log:
  try:code=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=limit).returncode
  except subprocess.TimeoutExpired:code=124
 item.update(exitCode=code,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();return code==0
base=['cargo','+1.98.1']
def body():
 if not run('numeric-producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-a11y-value/produce.mjs',str(numeric)],300):return False
 if not run('numeric-metadata',base+['metadata','--offline','--all-features','--format-version','1','--manifest-path',str(numeric/'Cargo.toml')],300):return False
 if not run('sdk-controls',base+['test','--offline','--locked','--manifest-path',str(numeric/'Cargo.toml'),'-p','proto-ui-gpui-native','--features','test-support,gpui/test-support','--lib','--','--test-threads=1','--nocapture']):return False
 if not full:return True
 if not run('source-controls',['corepack','pnpm@10.32.1','exec','vitest','run','--maxWorkers=1','--minWorkers=1','--reporter=json','--outputFile='+str(work/'source-controls.json')]+tests,600):return False
 if not run('ordinary-producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-ordinary-values/produce.mjs',str(ordinary)],300):return False
 manifest=['--manifest-path',str(ordinary/'transition/Cargo.toml')]
 if not run('ordinary-graph',['node','scripts/gpui/check-cargo-graph.mjs']+manifest+['--git','https://github.com/zed-industries/zed','--rev','62e5991dd0f0c8a3af8d5e7e9c4652490d468db8','--toolchain','1.98.1','--output',str(work/'ordinary-graph.json')],300):return False
 if not run('default-check',base+['check','--offline','--locked']+manifest+['--lib']):return False
 if not run('six-native-consumers',base+['test','--offline','--locked','--no-fail-fast']+manifest+['--features','test-support','--tests','--','--test-threads=1','--nocapture']):return False
 if not run('numeric-consumer',base+['test','--offline','--locked','--manifest-path',str(numeric/'Cargo.toml'),'--test','a11y_value','--','--test-threads=1','--nocapture']):return False
 if not run('official-label-producer',['node','--import','tsx','packages/compiler/test/fixtures/gpui-control-label/produce.mjs',str(label)],300):return False
 if not run('official-label-metadata',base+['metadata','--offline','--all-features','--format-version','1','--manifest-path',str(label/'Cargo.toml')],300):return False
 if not run('official-label-consumer',base+['test','--offline','--locked','--manifest-path',str(label/'Cargo.toml'),'--test','control_label','--','--test-threads=1','--nocapture']):return False
 return run('diff-check',['git','diff','--check'],30)
save()
try:
 with tempfile.TemporaryDirectory(prefix='ncp75d5-',dir='/var/tmp')as tmp:
  env['TMPDIR']=tmp;ok=body()
 state['state']='passed'if ok else'failed'
except Exception as error:state.update(state='failed',exception=repr(error))
finally:
 state.update(sourceAfter=snap(),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
