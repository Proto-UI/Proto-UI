#!/usr/bin/env python3
"""Prepared only: strict diagnostic SDK A/B; leaves the full candidate uncommitted."""
from pathlib import Path
import datetime, fcntl, hashlib, json, os, re, shutil, subprocess, sys, tempfile

ROOT = Path('/tank/shared/projects/proto-ui-agent/root-native-compose-75d5e28a')
OPS = Path(str(ROOT) + '-ops')
PACKET = Path(__file__).resolve().parent
SOURCE = 'packages/compiler/src/gpui-native-control-label.ts'
HEAD = 'e470d1b0c21fc40e99e71cd7c49a76470444c6e7'
TREE = '1b273ac7d664a807a399e3f45d677f14aae8d43a'
BEFORE = 'ee07845235af39b8a1fd723ba9f50ab0004093ea36b485873bc18d1be5bbe77a'
RED = 'e121c08e190660001b8faa0c0a379a216df8a1b11e76096ff6dd9a411c0cc819'
GREEN = 'f7290b713dfe98b38feafce0c894f3c16c4711e7018fc0f134d16e040291278d'
SDK_SHA = '319a473c455524d64c4e95f692cabc7443e537f63b9fccfbf9f0d07c0564c9ea'
PATCHES = [
    ('diagnostic-delivery-controls-only.patch', '915a7530b415c09563d474b04b1f2b0f42e291e37c4a3c540d5837f9aa32620c', BEFORE, RED),
    ('diagnostic-delivery-product-only.patch', '88014e239bae52615342cc89f2972a1a8023f7bbf057cb2a814da0bfccda9c30', RED, GREEN),
]
CASE = 'inactive_action_bridge_never_acquires_a_later_valid_pair'
ASSERTION = 'fresh same missing refusal after take is buffered once before the next take'
NODE = '/tank/shared/projects/proto-ui-agent/seven-sprints-20261123-chvf1ono/tools/node-v24.22.3-linux-x64/bin'
TARGET = '/tank/shared/projects/proto-ui-agent/s5-adapter-readonly-target75d5'
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

class PendingChild(Exception):
    pass

def members(pgid):
    result = []
    for path in Path('/proc').glob('[0-9]*/stat'):
        try:
            raw = path.read_text()
            fields = raw[raw.rfind(')') + 2:].split()
            if int(fields[2]) == pgid and fields[0] != 'Z':
                result.append({'pid': int(path.parent.name), 'state': fields[0],
                               'ppid': int(fields[1]), 'pgid': int(fields[2])})
        except (FileNotFoundError, ProcessLookupError, PermissionError, ValueError):
            pass
    return result

def main():
    if len(sys.argv) != 2 or not re.fullmatch('[a-z0-9][a-z0-9-]{2,80}', sys.argv[1]):
        raise SystemExit('Usage: diagnostic-delivery-ab.py FRESH-PHASE')
    phase = sys.argv[1]
    lock = (OPS / 'diagnostic-delivery.lock').open('a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    active = OPS / 'diagnostic-delivery-active.json'
    if active.exists():
        previous = json.loads(active.read_text())
        assert previous['state'] not in ['preflight', 'running', 'pending-child'], (
            'Reconcile the recorded existing worker before starting another one', previous)
    work = OPS / phase
    work.mkdir(exist_ok=False)
    sdk_dirs = [OPS / (phase + '-sdk-red'), OPS / (phase + '-sdk-green')]
    assert all(not p.exists() for p in sdk_dirs), 'SDK phase names must be fresh'
    env = dict(os.environ)
    env['PATH'] = NODE + ':/home/ezra/.cargo/bin:' + env['PATH']
    env.update(CARGO_BUILD_JOBS='1', CARGO_TARGET_DIR=TARGET, CARGO_NET_OFFLINE='true',
               CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CI='true')
    tmp = Path(tempfile.mkdtemp(prefix='ncd75d5-', dir='/var/tmp'))
    env['TMPDIR'] = str(tmp)
    state = {'state': 'preflight', 'phase': phase, 'pid': os.getpid(), 'startedAt': now(),
             'expectedHead': HEAD, 'expectedTree': TREE, 'scope': 'SDK A/B only; no commit or generated-Rust edit',
             'commands': [], 'snapshots': {}, 'sdkReceipts': [],
             'temporaryDirectory': str(tmp), 'runnerSha256': sha(__file__),
             'environment': {k: env[k] for k in ['CARGO_BUILD_JOBS', 'CARGO_TARGET_DIR',
                 'CARGO_NET_OFFLINE', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG']}}
    baseline = None
    def save():
        text = json.dumps(state, indent=2) + '\n'
        (work / 'status.tmp').write_text(text)
        (work / 'status.tmp').replace(work / 'status.json')
        active.write_text(json.dumps({'phase': phase, 'pid': os.getpid(), 'state': state['state'],
                                      'status': str(work / 'status.json'),
                                      'pendingChild': state.get('pendingChild')}, indent=2) + '\n')
    def run(name, args, limit=60):
        item = {'name': name, 'command': args, 'startedAt': now(), 'timeoutSeconds': limit}
        state['commands'].append(item); save()
        log = work / (name + '.log')
        with log.open('wb') as output:
            child = subprocess.Popen(args, cwd=ROOT, env=env, stdout=output,
                                     stderr=subprocess.STDOUT, start_new_session=True)
            item['pid'] = child.pid; save()
            try:
                code = child.wait(limit)
            except subprocess.TimeoutExpired:
                item.update(timedOut=True, pendingChild=child.pid)
                state['pendingChild'] = {'pid': child.pid, 'members': members(child.pid)}
                save()
                raise PendingChild(name + ': original process is still pending; do not repeat')
        live = members(child.pid)
        item.update(exitCode=code, finishedAt=now(), log=str(log), logSha256=sha(log))
        if live:
            item['pendingDescendants'] = live
            state['pendingChild'] = {'pgid': child.pid, 'members': live}
            save()
            raise PendingChild(name + ': descendants are still alive; do not change source')
        save()
        assert code == 0, (name, code, str(log))
        return log.read_text(errors='replace')
    def snapshot():
        return {name: sha(ROOT / name) for name in baseline}
    def guard(label, source_sha, clean=False):
        assert run(label + '-head', ['git', 'rev-parse', 'HEAD']).strip() == HEAD
        assert run(label + '-tree', ['git', 'rev-parse', 'HEAD^{tree}']).strip() == TREE
        expected = dict(baseline); expected[SOURCE] = source_sha
        actual = snapshot()
        state['snapshots'][label] = actual; save()
        assert actual == expected, ('294-source drift', label)
        status = run(label + '-git-status',
                     ['git', 'status', '--porcelain=v1', '--untracked-files=normal']).strip()
        assert status == ('' if clean else 'M ' + SOURCE), (label, status)
        assert not run(label + '-index', ['git', 'diff', '--cached', '--name-only']).strip()
    def validate_sdk(folder, red):
        receipt_path = folder / 'status.json'
        receipt = json.loads(receipt_path.read_text())
        expected = dict(baseline); expected[SOURCE] = RED if red else GREEN
        commands = receipt.get('commands', [])
        assert receipt.get('phase') == folder.name and receipt.get('full') is False
        assert receipt.get('sourceHead') == HEAD and not receipt.get('exception')
        assert receipt.get('sourceBefore') == receipt.get('sourceAfter')
        assert receipt.get('sourceBefore') and all(
            name in expected and expected[name] == value
            for name, value in receipt['sourceBefore'].items())
        assert [c['name'] for c in commands] == ['numeric-producer', 'numeric-metadata', 'sdk-controls']
        assert [c.get('exitCode') for c in commands] == ([0, 0, 101] if red else [0, 0, 0])
        assert receipt['state'] == ('failed' if red else 'passed')
        output = (folder / 'sdk-controls.log').read_text(errors='replace')
        output = re.sub(r'\x1b\[[0-9;]*m', '', output)
        matches = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', output)
        assert matches == ([('FAILED', '61', '1', '0', '0', '0')] if red else
                           [('ok', '62', '0', '0', '0', '0')]), matches
        if red:
            assert ASSERTION in output, 'Failure did not reach the new fresh-refusal assertion'
            tail = output.rsplit('failures:', 1)[-1].split('test result:', 1)[0]
            failed = [line.strip() for line in tail.splitlines() if line.strip()]
            assert len(failed) == 1 and failed[0].endswith('::' + CASE), failed
        result = {'path': str(receipt_path), 'sha256': sha(receipt_path),
                  'rawLog': str(folder / 'sdk-controls.log'), 'rawSha256': sha(folder / 'sdk-controls.log'),
                  'classification': 'expected-red-61/1' if red else 'green-62/62',
                  'rustResults': matches}
        state['sdkReceipts'].append(result); save()
    save()
    try:
        prior_path = OPS / 'combined-native-union-r1/status.json'
        prior = json.loads(prior_path.read_text())
        assert prior['state'] == 'failed' and prior['sourceStable'] is True and not prior.get('pendingChild')
        assert prior['sourceHead'] == prior['headAfter'] == HEAD
        assert prior['sourceTree'] == prior['treeAfter'] == TREE
        assert prior['sourceBefore'] == prior['sourceAfter'] and len(prior['sourceBefore']) == 294
        baseline = prior['sourceBefore']
        assert baseline[SOURCE] == BEFORE
        state['priorReceipt'] = {'path': str(prior_path), 'sha256': sha(prior_path)}
        assert sha(OPS / 'native-sdk-phase.py') == SDK_SHA, 'SDK runner changed'
        for filename, digest, _, _ in PATCHES:
            assert sha(PACKET / filename) == digest, filename
        assert run('node-version', [NODE + '/node', '--version']).strip() == 'v24.22.3'
        assert run('rust-version', ['rustc', '+1.98.1', '--version']).startswith('rustc 1.98.1 ')
        guard('baseline', BEFORE, clean=True)
        state['state'] = 'running'; save()
        for index, (filename, _, old, new) in enumerate(PATCHES):
            assert sha(ROOT / SOURCE) == old
            patch = str(PACKET / filename)
            run('apply-check-' + str(index), ['git', 'apply', '--check', patch])
            run('apply-' + str(index), ['git', 'apply', patch])
            assert sha(ROOT / SOURCE) == new
            guard('controls-applied' if index == 0 else 'full-applied', new)
            folder = sdk_dirs[index]
            # The pinned runner may exit 0 with a failed receipt. validate_sdk
            # checks that receipt and the exact raw test failure independently.
            run('sdk-red-wrapper' if index == 0 else 'sdk-green-wrapper',
                [sys.executable, str(OPS / 'native-sdk-phase.py'), folder.name], 2100)
            validate_sdk(folder, red=index == 0)
            guard('after-sdk-red' if index == 0 else 'after-sdk-green', new)
        run('diff-check', ['git', 'diff', '--check'])
        state['state'] = 'passed'
        state['candidateSha256'] = sha(ROOT / SOURCE)
        state['next'] = 'Full candidate remains uncommitted; run official Label9, ordinary ControlLabel14, source3, Adapter19+2+1.'
    except PendingChild as error:
        state.update(state='pending-child', error=str(error))
    except Exception as error:
        state.update(state='failed', error=repr(error))
    finally:
        if baseline is not None:
            state['sourceAfter'] = snapshot()
        if state['state'] != 'pending-child':
            shutil.rmtree(tmp)
            state['temporaryDirectoryRemoved'] = not tmp.exists()
        else:
            state['temporaryDirectoryRetainedForPendingChild'] = True
        state['finishedAt'] = now(); save()
    return 0 if state['state'] == 'passed' else 75 if state['state'] == 'pending-child' else 1

if __name__ == '__main__':
    raise SystemExit(main())
