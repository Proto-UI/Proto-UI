// Direct checked-source GPUI component. Supporting files are ordinary editable Rust.
  #[cfg(panic = "abort")] compile_error!("Authored exception lowering requires panic=unwind");
  pub use proto_ui_gpui_native as native;
  pub use native::gpui_native_owner::{ControlLabelRef, InstanceAssociations};
  use gpui::{prelude::*, App, Context, FocusHandle, Subscription, Window};
  use std::rc::Rc;
  use serde_json::Value as Json;
  use native::gpui_native_owner::*;
  std::thread_local! { static v_5f5f7075694d6f64756c6530: native::gpui_native_owner::NativeCallable<dyn Fn(f64) -> Value> = {   let call:Rc<dyn Fn(f64)->Value>=Rc::new(move |argument_0: f64| -> Value {
    let v_73656564: f64 = argument_0;
    let v_76616c75655f5f37356563663836386137313164393437: LexicalBinding<Value> = lexical_binding();
    let v_616c6961735f5f36643763376438316361343632346261: LexicalBinding<Value> = lexical_binding();
    // Source "ordinary.proto.ts":31:9
    v_76616c75655f5f37356563663836386137313164393437.initialize(record(vec![("count", Value::number(v_73656564.clone()))]));
    // Source "ordinary.proto.ts":32:9
    v_616c6961735f5f36643763376438316361343632346261.initialize(v_76616c75655f5f37356563663836386137313164393437.read());
    // Source "ordinary.proto.ts":33:3
    return record(vec![("increment", ({  let v_76616c75655f5f37356563663836386137313164393437 = v_76616c75655f5f37356563663836386137313164393437.clone(); let call:Rc<dyn Fn()->f64>=Rc::new(move || -> f64 {
        // Source "ordinary.proto.ts":35:7
        Value::number((set_member(v_76616c75655f5f37356563663836386137313164393437.read(), "count", Value::number({ let pui_native_9:f64=((v_76616c75655f5f37356563663836386137313164393437.read()).member("count", false)).num(); let pui_native_10:f64=1.0_f64; pui_native_9 + pui_native_10 }))).num());
        // Source "ordinary.proto.ts":36:7
        return ((v_76616c75655f5f37356563663836386137313164393437.read()).member("count", false)).num();
    }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")), ("read", ({  let v_616c6961735f5f36643763376438316361343632346261 = v_616c6961735f5f36643763376438316361343632346261.clone(); let call:Rc<dyn Fn()->f64>=Rc::new(move || -> f64 {
        // Source "ordinary.proto.ts":38:17
        return ((v_616c6961735f5f36643763376438316361343632346261.read()).member("count", false)).num();
    }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")), ("same", ({  let v_76616c75655f5f37356563663836386137313164393437 = v_76616c75655f5f37356563663836386137313164393437.clone(); let v_616c6961735f5f36643763376438316361343632346261 = v_616c6961735f5f36643763376438316361343632346261.clone(); let call:Rc<dyn Fn()->bool>=Rc::new(move || -> bool {
        // Source "ordinary.proto.ts":39:17
        return (Value::boolean(strict_equal(&(v_616c6961735f5f36643763376438316361343632346261.read()), &(v_76616c75655f5f37356563663836386137313164393437.read())))).bool();
    }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"))]);
}); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).num())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }; }
std::thread_local! { static v_5f5f7075694d6f64756c6531: std::cell::RefCell<f64> = std::cell::RefCell::new(0.0_f64); }
std::thread_local! { static v_5f5f7075694d6f64756c6532: native::gpui_native_owner::NativeCallable<dyn Fn(Value, f64) -> f64> = {   let call:Rc<dyn Fn(Value, f64)->f64>=Rc::new(move |argument_0: Value, argument_1: f64| -> f64 {
    let v_66697273745f5f61306134653232363436616539306163: Value = { let argument = argument_0; if matches!(&argument, Value::Undefined) { Value::number(7.0_f64) } else { argument } };
    let v_6c617374: f64 = argument_1;
    // Source "ordinary.proto.ts":28:3
    return { let pui_native_13:f64=(v_66697273745f5f61306134653232363436616539306163.clone()).num(); let pui_native_14:f64=v_6c617374.clone(); pui_native_13 + pui_native_14 };
}); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call(arg(&arguments,0), (arg(&arguments,1)).num()))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }; }
std::thread_local! { static v_5f5f7075694d6f64756c6533: std::cell::RefCell<bool> = std::cell::RefCell::new(false); }
  
  fn style_vocabulary() -> &'static native::gpui_native_style::StyleVocabulary {
      static VOCABULARY: std::sync::OnceLock<native::gpui_native_style::StyleVocabulary> = std::sync::OnceLock::new();
      VOCABULARY.get_or_init(|| native::gpui_native_style::StyleVocabulary::from_json(include_str!(".proto-ui/fixtures/style-tokens.json")).expect("compiler-produced style vocabulary"))
  }
  fn accepts_context(key: &str, value: &Json) -> bool {
      match key {
          "ordinary.proto.ts#CHANNEL_A" => (value.is_object() && value.get("value").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite))),
        "ordinary.proto.ts#CHANNEL_B" => (value.is_object() && value.get("value").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite))),
          _ => false,
      }
  }
  fn accepts_props(value: &Json) -> bool { value.is_object() && value.get("contextWrite").map_or(true, |prop| prop.is_null() || prop.as_f64().is_some_and(f64::is_finite)) && value.get("present").map_or(true, |prop| prop.is_null() || prop.is_boolean()) && value.get("rearmOnUnmount").map_or(true, |prop| prop.is_null() || prop.is_boolean()) && value.get("throwUnmount").map_or(true, |prop| prop.is_null() || prop.is_boolean()) && value.get("failDispose").map_or(true, |prop| prop.is_null() || prop.is_boolean()) }
  fn prop_valid(key: &str, value: &Json) -> bool { match key { "contextWrite" => value.as_f64().is_some_and(f64::is_finite),
        "present" => value.is_boolean(),
        "rearmOnUnmount" => value.is_boolean(),
        "throwUnmount" => value.is_boolean(),
        "failDispose" => value.is_boolean(), _ => false } }
  fn check_method(name: &str, arguments: &[Value]) { match name {
          "write" => if !(arguments.len() <= 1 && arguments.get(0).map_or(false, |value| (value).try_data().is_some_and(|data| data.as_f64().is_some_and(f64::is_finite)))) { value_type_error("invalid exposed method arguments") },
        "watchTrace" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "contextTrace" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "increment" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "read" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "same" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "forward" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "even" => if !(arguments.len() <= 1 && arguments.get(0).map_or(false, |value| (value).try_data().is_some_and(|data| data.as_f64().is_some_and(f64::is_finite)))) { value_type_error("invalid exposed method arguments") },
        "defaults" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "explicitDefault" => if !(arguments.len() <= 1 && arguments.get(0).map_or(false, |value| (value).try_data().is_some_and(|data| data.as_f64().is_some_and(f64::is_finite)))) { value_type_error("invalid exposed method arguments") },
        "defaultCapture" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "shared" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "freezeAlias" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "caughtIdentity" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "optional" => if !(arguments.len() <= 1 && arguments.get(0).map_or(false, |value| (value).try_data().is_some_and(|data| data.is_boolean()))) { value_type_error("invalid exposed method arguments") },
        "spread" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "schedule" => if !(arguments.len() <= 1 && arguments.get(0).map_or(false, |value| (value).try_data().is_some_and(|data| data.as_f64().is_some_and(f64::is_finite)))) { value_type_error("invalid exposed method arguments") },
        "cancel" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "completed" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "returnControls" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "returnFunction" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "returnPure" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "decide" => if !(arguments.len() <= 2 && arguments.get(0).map_or(true, |value| matches!(value, Value::Undefined) || (value).try_data().is_some_and(|data| data.as_f64().is_some_and(f64::is_finite))) && arguments.get(1).map_or(false, |value| (value).try_data().is_some_and(|data| data.as_f64().is_some_and(f64::is_finite)))) { value_type_error("invalid exposed method arguments") },
        "conditionalDecide" => if !(arguments.len() <= 2 && arguments.get(0).map_or(true, |value| matches!(value, Value::Undefined) || (value).try_data().is_some_and(|data| data.as_f64().is_some_and(f64::is_finite))) && arguments.get(1).map_or(false, |value| (value).try_data().is_some_and(|data| data.as_f64().is_some_and(f64::is_finite)))) { value_type_error("invalid exposed method arguments") },
          _ => value_error("unknown exposed method"),
  } }
  static PUI_CONTEXT_KEY_0: std::sync::OnceLock<NativeContextKey> = std::sync::OnceLock::new();
static PUI_CONTEXT_KEY_1: std::sync::OnceLock<NativeContextKey> = std::sync::OnceLock::new();
  #[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData0 {
    #[serde(rename = "contextWrite", default, skip_serializing_if = "Option::is_none")]
    pub field_0: Option<f64>,
    #[serde(rename = "present", default, skip_serializing_if = "Option::is_none")]
    pub field_1: Option<bool>,
    #[serde(rename = "rearmOnUnmount", default, skip_serializing_if = "Option::is_none")]
    pub field_2: Option<bool>,
    #[serde(rename = "throwUnmount", default, skip_serializing_if = "Option::is_none")]
    pub field_3: Option<bool>,
    #[serde(rename = "failDispose", default, skip_serializing_if = "Option::is_none")]
    pub field_4: Option<bool>,
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData1 {
    #[serde(rename = "calls")]
    pub field_0: f64,
    #[serde(rename = "value")]
    pub field_1: f64,
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData2 {
    #[serde(rename = "independent")]
    pub field_0: bool,
    #[serde(rename = "overwrite")]
    pub field_1: bool,
    #[serde(rename = "own")]
    pub field_2: bool,
    #[serde(rename = "finite")]
    pub field_3: bool,
}
  
  pub type GeneratedProps = GeneratedData0;
  fn authored_hook_0(definition: Value, input: Value) -> Value {
    let owner = definition.owner();
    authored_hook(&owner, "native-notification-source", "once", input, { let owner = owner.clone();  Value::Function(Rc::new(move |arguments: Vec<Value>| {
        let v_6465665f5f61376566633736326234323866666435: Value = arg(&arguments, 0);
        let v_6e5f5f66363236643265356637643166643966: LexicalBinding<Value> = lexical_binding();
        // Source "ordinary.proto.ts":20:11
        v_6e5f5f66363236643265356637643166643966.initialize({ let v_7075695f6e61746976655f30 = v_6465665f5f61376566633736326234323866666435.clone(); { let v_3c636170747572653a7075695f6e61746976655f313e = Value::string("n"); let v_3c636170747572653a7075695f6e61746976655f323e = Value::number(0.0_f64); let v_7075695f6e61746976655f33 = create_state(&owner, "discrete", v_3c636170747572653a7075695f6e61746976655f313e.clone(), Value::number((v_3c636170747572653a7075695f6e61746976655f323e.clone()).num()), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f33.clone());    v_7075695f6e61746976655f33 } });
        // Source "ordinary.proto.ts":21:5
        { let v_7075695f6e61746976655f34 = v_6465665f5f61376566633736326234323866666435.clone(); { let v_3c636170747572653a7075695f6e61746976655f363e = Value::string("write"); let v_3c636170747572653a7075695f6e61746976655f373e = ({  let v_6e5f5f66363236643265356637643166643966 = v_6e5f5f66363236643265356637643166643966.clone(); let call:Rc<dyn Fn(f64)->Value>=Rc::new(move |argument_0: f64| -> Value {
            let v_76616c75655f5f62613965313438393630393238333162: f64 = argument_0;
            // Source "ordinary.proto.ts":21:51
            return { let v_7075695f6e61746976655f35 = v_6e5f5f66363236643265356637643166643966.read(); state_set(v_7075695f6e61746976655f35.clone(), Value::number(v_76616c75655f5f62613965313438393630393238333162.clone()), Value::Undefined) };
        }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).num())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"); let v_7075695f6e61746976655f38 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f363e.clone(), v_3c636170747572653a7075695f6e61746976655f373e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f363e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f373e.clone())]));    v_7075695f6e61746976655f38 } };
        Value::Undefined
    })) }, Value::Undefined, Value::Undefined)
}
  #[derive(Clone)]
  pub struct CompiledComponentHandle { pub owner: OwnerRef }
  impl CompiledComponentHandle {
      pub fn method_0(&self, argument_0: f64, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![Value::json(serde_json::to_value(argument_0).expect("portable argument"))];
        let callback = self.owner.borrow().exposes.get("write").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("write", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn state_1(&self) -> Result<f64, Value> { self.state("watched").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn method_2(&self, window: &mut Window, cx: &mut App) -> Result<String, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("watchTrace").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("watchTrace", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_string()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_3(&self, window: &mut Window, cx: &mut App) -> Result<String, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("contextTrace").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("contextTrace", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_string()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn value_4(&self) -> Result<Value, Value> { catch_authored(|| { ensure(&Rc::downgrade(&self.owner)); self.owner.borrow().exposes.get("lifecycle").cloned().unwrap_or_else(|| value_error("unknown exposed value")) }) }
    pub fn method_5(&self, window: &mut Window, cx: &mut App) -> Result<f64, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("increment").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("increment", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.as_f64().is_some_and(f64::is_finite)) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_6(&self, window: &mut Window, cx: &mut App) -> Result<f64, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("read").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("read", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.as_f64().is_some_and(f64::is_finite)) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_7(&self, window: &mut Window, cx: &mut App) -> Result<bool, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("same").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("same", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_boolean()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_8(&self, window: &mut Window, cx: &mut App) -> Result<String, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("forward").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("forward", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_string()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_9(&self, argument_0: f64, window: &mut Window, cx: &mut App) -> Result<bool, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![Value::json(serde_json::to_value(argument_0).expect("portable argument"))];
        let callback = self.owner.borrow().exposes.get("even").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("even", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_boolean()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_10(&self, window: &mut Window, cx: &mut App) -> Result<f64, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("defaults").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("defaults", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.as_f64().is_some_and(f64::is_finite)) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_11(&self, argument_0: f64, window: &mut Window, cx: &mut App) -> Result<f64, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![Value::json(serde_json::to_value(argument_0).expect("portable argument"))];
        let callback = self.owner.borrow().exposes.get("explicitDefault").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("explicitDefault", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.as_f64().is_some_and(f64::is_finite)) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_12(&self, window: &mut Window, cx: &mut App) -> Result<f64, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("defaultCapture").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("defaultCapture", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.as_f64().is_some_and(f64::is_finite)) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_13(&self, window: &mut Window, cx: &mut App) -> Result<f64, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("shared").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("shared", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.as_f64().is_some_and(f64::is_finite)) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_14(&self, window: &mut Window, cx: &mut App) -> Result<bool, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("freezeAlias").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("freezeAlias", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_boolean()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_15(&self, window: &mut Window, cx: &mut App) -> Result<bool, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("caughtIdentity").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("caughtIdentity", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_boolean()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_16(&self, argument_0: bool, window: &mut Window, cx: &mut App) -> Result<GeneratedData1, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![Value::json(serde_json::to_value(argument_0).expect("portable argument"))];
        let callback = self.owner.borrow().exposes.get("optional").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("optional", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !((result.is_object() && result.get("calls").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("value").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_17(&self, window: &mut Window, cx: &mut App) -> Result<GeneratedData2, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("spread").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("spread", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !((result.is_object() && result.get("independent").map_or(false, |field| field.is_boolean()) && result.get("overwrite").map_or(false, |field| field.is_boolean()) && result.get("own").map_or(false, |field| field.is_boolean()) && result.get("finite").map_or(false, |field| field.is_boolean()))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_18(&self, argument_0: f64, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![Value::json(serde_json::to_value(argument_0).expect("portable argument"))];
        let callback = self.owner.borrow().exposes.get("schedule").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("schedule", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_19(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("cancel").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("cancel", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_20(&self, window: &mut Window, cx: &mut App) -> Result<f64, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("completed").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("completed", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.as_f64().is_some_and(f64::is_finite)) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn value_21(&self) -> Result<Value, Value> { catch_authored(|| { ensure(&Rc::downgrade(&self.owner)); self.owner.borrow().exposes.get("controls").cloned().unwrap_or_else(|| value_error("unknown exposed value")) }) }
    pub fn value_22(&self) -> Result<Value, Value> { catch_authored(|| { ensure(&Rc::downgrade(&self.owner)); self.owner.borrow().exposes.get("controlsAlias").cloned().unwrap_or_else(|| value_error("unknown exposed value")) }) }
    pub fn method_23(&self, window: &mut Window, cx: &mut App) -> Result<Value, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("returnControls").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("returnControls", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        result
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_24(&self, window: &mut Window, cx: &mut App) -> Result<Value, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("returnFunction").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("returnFunction", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        result
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_25(&self, window: &mut Window, cx: &mut App) -> Result<Value, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("returnPure").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("returnPure", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        result
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_26(&self, argument_0: Option<f64>, argument_1: f64, window: &mut Window, cx: &mut App) -> Result<f64, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![argument_0.map(|value| Value::json(serde_json::to_value(value).expect("portable argument"))).unwrap_or(Value::Undefined), Value::json(serde_json::to_value(argument_1).expect("portable argument"))];
        let callback = self.owner.borrow().exposes.get("decide").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("decide", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.as_f64().is_some_and(f64::is_finite)) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn value_27(&self) -> Result<Value, Value> { catch_authored(|| { ensure(&Rc::downgrade(&self.owner)); self.owner.borrow().exposes.get("dataRegistered").cloned().unwrap_or_else(|| value_error("unknown exposed value")) }) }
    pub fn method_28(&self, argument_0: Option<f64>, argument_1: f64, window: &mut Window, cx: &mut App) -> Result<f64, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![argument_0.map(|value| Value::json(serde_json::to_value(value).expect("portable argument"))).unwrap_or(Value::Undefined), Value::json(serde_json::to_value(argument_1).expect("portable argument"))];
        let callback = self.owner.borrow().exposes.get("conditionalDecide").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("conditionalDecide", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.as_f64().is_some_and(f64::is_finite)) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
      /// Calls this live instance's registered data-only method. None preserves an undefined argument slot.
      pub fn call_data_method(&self, name: &str, arguments: Vec<Option<Json>>) -> Result<Json, Value> {
          catch_authored(|| { ensure(&self.owner()); match name {
          "decide" => {
            let arguments: Vec<Value> = arguments.into_iter().map(|value| value.map(Value::json).unwrap_or(Value::Undefined)).collect();
            check_method(name, &arguments);
            let callback = self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed method"));
            let result = invoke(&self.owner, "expose-method", &callback, arguments);
            let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.as_f64().is_some_and(f64::is_finite)) { value_type_error("exposed method returned invalid portable data") }
            result
        },
        "conditionalDecide" => {
            let arguments: Vec<Value> = arguments.into_iter().map(|value| value.map(Value::json).unwrap_or(Value::Undefined)).collect();
            check_method(name, &arguments);
            let callback = self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed method"));
            let result = invoke(&self.owner, "expose-method", &callback, arguments);
            let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.as_f64().is_some_and(f64::is_finite)) { value_type_error("exposed method returned invalid portable data") }
            result
        },
              _ => value_error("unknown or ineligible data method"),
          } })
      }
      pub fn owner(&self) -> OwnerWeak { Rc::downgrade(&self.owner) }
      pub fn state(&self, name: &str) -> Result<Json, Value> { catch_authored(|| { let state=self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed State")); state.get().data() }) }
      pub fn call(&self, name: &str, arguments: Vec<Json>, window: &mut Window, cx: &mut App) -> Result<Json, Value> {
          let outcome = catch_authored(|| {
          refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
          let callback = self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed method"));
          let arguments: Vec<Value> = arguments.into_iter().map(Value::json).collect(); check_method(name, &arguments);
          let result = invoke(&self.owner, "expose-method", &callback, arguments);
          let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
          if matches!(result, Value::Undefined) { Json::Null } else { result.data() }
          });
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome
      }
      pub fn host_target(&self) -> Result<Value, Value> { catch_authored(|| { ensure(&self.owner()); Value::HostTarget(self.owner()) }) }
      pub fn take_events(&self) -> Vec<(String, Json)> { std::mem::take(&mut self.owner.borrow_mut().emitted) }
      pub fn take_failures(&self) -> Vec<NativeFailure> { take_native_failures(&self.owner) }
      pub fn dispose(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
          catch_authored(|| {
          let drive = self.owner.borrow().native_drive.clone();
          let failure = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| Owner::dispose(&self.owner)));
          let driven = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| { if let Some(drive) = drive { drive(window, cx); } }));
          if let Err(failure) = failure { std::panic::resume_unwind(failure); }
          if let Err(failure) = driven { std::panic::resume_unwind(failure); }
          })
      }
  }
  pub struct CompiledComponent { pub owner: OwnerRef, focus: FocusHandle, window_input: Option<FocusHandle>, _focus_subscriptions: Vec<Subscription>, _window_activation: Option<(gpui::WindowId, Subscription)>, _focus_lost: Option<Subscription>, _global_key_capture: Option<Subscription>, _entry_readiness: Option<(gpui::WindowId, Subscription)> }
  impl CompiledComponent {
      pub fn create_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> { Self::create(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn create(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          Self::create_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn create_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          let mut failure = None;
          let entity = cx.new(|cx| Self::new_with_associations(raw_props, parent, associations, window, cx).unwrap_or_else(|error| {
              failure = Some(error);
              // A failed construction still returns normally through GPUI's
              // entity insertion. This inert temporary is dropped immediately
              // below; it is never published or mounted as a native component.
              let owner = Owner::new(Json::Object(Default::default()), Default::default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
              { let mut owner = owner.borrow_mut(); owner.disposed = true; owner.present = false; }
              Self { owner, focus: cx.focus_handle(), window_input: None, _focus_subscriptions: Vec::new(), _window_activation: None, _focus_lost: None, _global_key_capture: None, _entry_readiness: None }
          }));
          match failure { Some(error) => Err(error), None => Ok(entity) }
      }
      pub fn new_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> { Self::new(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn new(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          Self::new_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn new_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          catch_authored(|| {
          let owner_ref = Owner::new(raw_props, parent.unwrap_or_default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
          initialize_instance_associations(&owner_ref, associations);
          let owner = Rc::downgrade(&owner_ref);
          let focus = cx.focus_handle();
          let view = cx.entity().downgrade();
          let drive_owner=owner.clone(); let drive_focus=focus.clone();
          let driving = Rc::new(std::cell::Cell::new(false));
          let drive_pending = Rc::new(std::cell::Cell::new(false));
          let drive: Drive = Rc::new(move |window, cx| {
              // Platform effects need owner storage and its real FocusHandle,
              // not another lease of the generated component. Preserve their
              // synchronous effect (notably physical focus) under public calls.
              if !driving.replace(true) {
                  if let Some(owner)=drive_owner.upgrade() {
                      native_host_callback(&owner, "drive", || { modules_drive(&owner, &drive_focus, window, cx); drive_queued_focus(&owner, window, cx); });
                  }
                  driving.set(false);
              }
              if drive_pending.replace(true) { return; }
              let view=view.clone(); let pending=drive_pending.clone();
              // A public handle can be called from Entity::update. Return the
              // current host lease before requesting another component update.
              // Authored calls, State writes and platform commands remain
              // synchronous; component refresh is coalesced at the host boundary.
              window.defer(cx, move |window, cx| {
                  pending.set(false);
                  let _ = view.update(cx, |view, cx| { if let Err(error) = view.drive(window, cx) { report_native_failure(&view.owner, "drive", error); } });
              });
          });
          { let mut owner = owner_ref.borrow_mut(); owner.native_drive = Some(drive); owner.window_id = Some(window.window_handle().window_id()); }
  
          configure_native_atoms(&owner_ref, true, false);
          refresh_native_atoms(&owner_ref, window, cx);
          let _lexical_owner = enter_lexical_owner(&owner);
          let renderer = { let owner = owner.clone();  Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_6465665f5f37313630613761653830323735653834: Value = arg(&arguments, 0);
            let v_7772697465: LexicalBinding<Value> = lexical_binding();
            let v_77617463685472616365: LexicalBinding<Rc<std::cell::RefCell<Value>>> = lexical_binding();
            let v_636f6e746578745472616365: LexicalBinding<Rc<std::cell::RefCell<Value>>> = lexical_binding();
            let v_63616e63656c5365636f6e64: LexicalBinding<Value> = lexical_binding();
            let v_636f756e746572: LexicalBinding<Value> = lexical_binding();
            let v_6c617465725f5f31393132666632613933613931633264: LexicalBinding<Value> = lexical_binding();
            let v_6576656e: LexicalBinding<native::gpui_native_owner::NativeCallable<dyn Fn(f64) -> bool>> = lexical_binding();
            let v_6f6464: LexicalBinding<native::gpui_native_owner::NativeCallable<dyn Fn(f64) -> bool>> = lexical_binding();
            let v_73657175656e6365: LexicalBinding<Rc<std::cell::RefCell<f64>>> = lexical_binding();
            let v_64656661756c7473: LexicalBinding<native::gpui_native_owner::NativeCallable<dyn Fn(Value, Value) -> f64>> = lexical_binding();
            let v_64656661756c74436c6f73757265: LexicalBinding<native::gpui_native_owner::NativeCallable<dyn Fn(Value, Value) -> f64>> = lexical_binding();
            let v_7461736b: LexicalBinding<Rc<std::cell::RefCell<Value>>> = lexical_binding();
            let v_636f6d706c65746564: LexicalBinding<Rc<std::cell::RefCell<f64>>> = lexical_binding();
            let v_6c6966656379636c65: LexicalBinding<Value> = lexical_binding();
            let v_7075626c6963436f756e74: LexicalBinding<Value> = lexical_binding();
            let v_72657475726e6564: LexicalBinding<Value> = lexical_binding();
            // Source "ordinary.proto.ts":46:11
            let v_63617074757265 = authored_hook_0(definition_capability(&owner), Value::Undefined);
            // Source "ordinary.proto.ts":47:11
            let v_77617463686564 = { let v_7075695f6e61746976655f3135 = v_63617074757265.clone(); { let capture_getter = (v_7075695f6e61746976655f3135.clone()).member("getState", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("n")]) } } };
            // Source "ordinary.proto.ts":48:11
            v_7772697465.initialize({ let v_7075695f6e61746976655f3136 = v_63617074757265.clone(); { let capture_getter = (v_7075695f6e61746976655f3136.clone()).member("getMethod", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("write")]) } } });
            // Source "ordinary.proto.ts":49:9
            v_77617463685472616365.initialize(Rc::new(std::cell::RefCell::new(Value::string(""))));
            // Source "ordinary.proto.ts":50:5
            { let v_7075695f6e61746976655f3137 = v_77617463686564.clone(); watch_state(&owner, v_7075695f6e61746976655f3137.clone(), {  let v_7772697465 = v_7772697465.clone(); let v_77617463685472616365 = v_77617463685472616365.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_5f72756e5f5f30346635333164653066306561656364: Value = arg(&arguments, 0);
                let v_6576656e745f5f32613934333763366435636633656239: Value = arg(&arguments, 1);
                // Source "ordinary.proto.ts":51:7
                if (Value::boolean(strict_equal(&((v_6576656e745f5f32613934333763366435636633656239.clone()).member("type", false)), &(Value::string("next"))))).bool() {
                    // Source "ordinary.proto.ts":52:9
                    { let value = add(add(add({ let value = (v_77617463685472616365.read()).borrow().clone(); value }, Value::string("a")), Value::number(((v_6576656e745f5f32613934333763366435636633656239.clone()).member("next", false)).num())), Value::string(",")); *(v_77617463685472616365.read()).borrow_mut() = value; }
                    // Source "ordinary.proto.ts":53:9
                    if { let pui_native_20=((v_6576656e745f5f32613934333763366435636633656239.clone()).member("next", false)).num(); let pui_native_21=1.0_f64; (pui_native_20==pui_native_21) } {
                        // Source "ordinary.proto.ts":54:11
                        { let callable = v_7772697465.read(); callable.call_authored(vec![Value::number(2.0_f64)]) };
                        // Source "ordinary.proto.ts":55:11
                        throw_value(Value::number(0.0_f64));
                    }
                }
                Value::Undefined
            })) }) };
            // Source "ordinary.proto.ts":59:5
            { let v_7075695f6e61746976655f3232 = v_77617463686564.clone(); watch_state(&owner, v_7075695f6e61746976655f3232.clone(), {  let v_77617463685472616365 = v_77617463685472616365.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_5f72756e5f5f62336465643230343436626166616137: Value = arg(&arguments, 0);
                let v_6576656e745f5f39623437333666356464393137666365: Value = arg(&arguments, 1);
                // Source "ordinary.proto.ts":60:7
                if (Value::boolean(strict_equal(&((v_6576656e745f5f39623437333666356464393137666365.clone()).member("type", false)), &(Value::string("next"))))).bool() {
                    // Source "ordinary.proto.ts":60:34
                    { let value = add(add(add({ let value = (v_77617463685472616365.read()).borrow().clone(); value }, Value::string("b")), Value::number(((v_6576656e745f5f39623437333666356464393137666365.clone()).member("next", false)).num())), Value::string(",")); *(v_77617463685472616365.read()).borrow_mut() = value; }
                }
                Value::Undefined
            })) }) };
            // Source "ordinary.proto.ts":62:5
            { let v_7075695f6e61746976655f3235 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f32363e = Value::string("watched"); let v_3c636170747572653a7075695f6e61746976655f32373e = v_77617463686564.clone(); let v_7075695f6e61746976655f3238 = expose_state(&owner, v_3c636170747572653a7075695f6e61746976655f32363e.clone(), v_3c636170747572653a7075695f6e61746976655f32373e.clone()); capture_effect(&owner, "state", record(vec![("op", Value::string("expose.state")), ("key", v_3c636170747572653a7075695f6e61746976655f32363e.clone()), ("handle", v_3c636170747572653a7075695f6e61746976655f32373e.clone())]));   capture_introduced_state(&owner, v_3c636170747572653a7075695f6e61746976655f32373e.clone()); v_7075695f6e61746976655f3238 } };
            // Source "ordinary.proto.ts":63:5
            { let v_7075695f6e61746976655f3239 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f33303e = Value::string("watchTrace"); let v_3c636170747572653a7075695f6e61746976655f33313e = {  let v_77617463685472616365 = v_77617463685472616365.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "ordinary.proto.ts":63:43
                return { let value = (v_77617463685472616365.read()).borrow().clone(); value };
            })) }; let v_7075695f6e61746976655f3332 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f33303e.clone(), v_3c636170747572653a7075695f6e61746976655f33313e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f33303e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f33313e.clone())]));    v_7075695f6e61746976655f3332 } };
            // Source "ordinary.proto.ts":64:5
            { let v_7075695f6e61746976655f3333 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f33343e = native_context_key(&PUI_CONTEXT_KEY_0, "ordinary.proto.ts#CHANNEL_A"); let v_3c636170747572653a7075695f6e61746976655f33353e = record(vec![("value", Value::number(0.0_f64))]); let v_7075695f6e61746976655f3336 = context_provide(&owner, v_3c636170747572653a7075695f6e61746976655f33343e.clone(), v_3c636170747572653a7075695f6e61746976655f33353e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("provide")), ("key", v_3c636170747572653a7075695f6e61746976655f33343e.clone())]));    v_7075695f6e61746976655f3336 } };
            // Source "ordinary.proto.ts":65:5
            { let v_7075695f6e61746976655f3337 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f33383e = native_context_key(&PUI_CONTEXT_KEY_1, "ordinary.proto.ts#CHANNEL_B"); let v_3c636170747572653a7075695f6e61746976655f33393e = record(vec![("value", Value::number(0.0_f64))]); let v_7075695f6e61746976655f3430 = context_provide(&owner, v_3c636170747572653a7075695f6e61746976655f33383e.clone(), v_3c636170747572653a7075695f6e61746976655f33393e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("provide")), ("key", v_3c636170747572653a7075695f6e61746976655f33383e.clone())]));    v_7075695f6e61746976655f3430 } };
            // Source "ordinary.proto.ts":66:9
            v_636f6e746578745472616365.initialize(Rc::new(std::cell::RefCell::new(Value::string(""))));
            // Source "ordinary.proto.ts":67:5
            { let v_7075695f6e61746976655f3431 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f35303e = native_context_key(&PUI_CONTEXT_KEY_0, "ordinary.proto.ts#CHANNEL_A"); let v_3c636170747572653a7075695f6e61746976655f35313e = {  let v_636f6e746578745472616365 = v_636f6e746578745472616365.clone(); let v_63616e63656c5365636f6e64 = v_63616e63656c5365636f6e64.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f34343864363963383434633636366163: Value = arg(&arguments, 0);
                let v_6e6578745f5f66623961356439623637313731353438: Value = arg(&arguments, 1);
                // Source "ordinary.proto.ts":68:7
                { let value = add(add(add({ let value = (v_636f6e746578745472616365.read()).borrow().clone(); value }, Value::string("a")), Value::number(((v_6e6578745f5f66623961356439623637313731353438.clone()).member("value", false)).num())), Value::string(",")); *(v_636f6e746578745472616365.read()).borrow_mut() = value; }
                // Source "ordinary.proto.ts":69:7
                if { let pui_native_42=((v_6e6578745f5f66623961356439623637313731353438.clone()).member("value", false)).num(); let pui_native_43=1.0_f64; (pui_native_42==pui_native_43) } {
                    // Source "ordinary.proto.ts":70:9
                    { let v_7075695f6e61746976655f3434 = v_72756e5f5f34343864363963383434633636366163.clone(); context_update(&(v_7075695f6e61746976655f3434.clone()).owner(), native_context_key(&PUI_CONTEXT_KEY_1, "ordinary.proto.ts#CHANNEL_B"), record(vec![("value", Value::number(1.0_f64))]), false) };
                    // Source "ordinary.proto.ts":71:9
                    { let v_7075695f6e61746976655f3435 = v_72756e5f5f34343864363963383434633636366163.clone(); context_update(&(v_7075695f6e61746976655f3435.clone()).owner(), native_context_key(&PUI_CONTEXT_KEY_0, "ordinary.proto.ts#CHANNEL_A"), record(vec![("value", Value::number(2.0_f64))]), false) };
                    // Source "ordinary.proto.ts":72:9
                    throw_value(Value::number(0.0_f64));
                }
                // Source "ordinary.proto.ts":74:7
                if { let pui_native_46=((v_6e6578745f5f66623961356439623637313731353438.clone()).member("value", false)).num(); let pui_native_47=3.0_f64; (pui_native_46==pui_native_47) } {
                    // Source "ordinary.proto.ts":74:29
                    { let callable = v_63616e63656c5365636f6e64.read(); callable.call_authored(vec![]) };
                }
                // Source "ordinary.proto.ts":75:7
                if { let pui_native_48=((v_6e6578745f5f66623961356439623637313731353438.clone()).member("value", false)).num(); let pui_native_49=5.0_f64; (pui_native_48==pui_native_49) } {
                    // Source "ordinary.proto.ts":75:29
                    throw_value(Value::number(0.0_f64));
                }
                Value::Undefined
            })) }; let v_7075695f6e61746976655f3532 = context_subscribe(&owner, v_3c636170747572653a7075695f6e61746976655f35303e.clone(), false, v_3c636170747572653a7075695f6e61746976655f35313e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("subscribe")), ("key", v_3c636170747572653a7075695f6e61746976655f35303e.clone()), ("off", v_7075695f6e61746976655f3532.clone())])); capture_disposer(&owner, "context", v_7075695f6e61746976655f3532.clone());   v_7075695f6e61746976655f3532 } };
            // Source "ordinary.proto.ts":77:11
            v_63616e63656c5365636f6e64.initialize({ let v_7075695f6e61746976655f3533 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f35363e = native_context_key(&PUI_CONTEXT_KEY_0, "ordinary.proto.ts#CHANNEL_A"); let v_3c636170747572653a7075695f6e61746976655f35373e = {  let v_636f6e746578745472616365 = v_636f6e746578745472616365.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_5f72756e5f5f38386366633865666130343237663362: Value = arg(&arguments, 0);
                let v_6e6578745f5f37376535666332653734343737393166: Value = arg(&arguments, 1);
                // Source "ordinary.proto.ts":78:7
                { let value = add(add(add({ let value = (v_636f6e746578745472616365.read()).borrow().clone(); value }, Value::string("b")), Value::number(((v_6e6578745f5f37376535666332653734343737393166.clone()).member("value", false)).num())), Value::string(",")); *(v_636f6e746578745472616365.read()).borrow_mut() = value; }
                // Source "ordinary.proto.ts":79:7
                if { let pui_native_54=((v_6e6578745f5f37376535666332653734343737393166.clone()).member("value", false)).num(); let pui_native_55=5.0_f64; (pui_native_54==pui_native_55) } {
                    // Source "ordinary.proto.ts":79:29
                    throw_value(Value::boolean(false));
                }
                Value::Undefined
            })) }; let v_7075695f6e61746976655f3538 = context_subscribe(&owner, v_3c636170747572653a7075695f6e61746976655f35363e.clone(), false, v_3c636170747572653a7075695f6e61746976655f35373e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("subscribe")), ("key", v_3c636170747572653a7075695f6e61746976655f35363e.clone()), ("off", v_7075695f6e61746976655f3538.clone())])); capture_disposer(&owner, "context", v_7075695f6e61746976655f3538.clone());   v_7075695f6e61746976655f3538 } });
            // Source "ordinary.proto.ts":81:5
            { let v_7075695f6e61746976655f3539 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f36303e = native_context_key(&PUI_CONTEXT_KEY_1, "ordinary.proto.ts#CHANNEL_B"); let v_3c636170747572653a7075695f6e61746976655f36313e = {  let v_636f6e746578745472616365 = v_636f6e746578745472616365.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_5f72756e5f5f32613834623731336432323461653738: Value = arg(&arguments, 0);
                let v_6e6578745f5f33643039373335383164633034353134: Value = arg(&arguments, 1);
                // Source "ordinary.proto.ts":82:7
                { let value = add(add(add({ let value = (v_636f6e746578745472616365.read()).borrow().clone(); value }, Value::string("x")), Value::number(((v_6e6578745f5f33643039373335383164633034353134.clone()).member("value", false)).num())), Value::string(",")); *(v_636f6e746578745472616365.read()).borrow_mut() = value; }
                Value::Undefined
            })) }; let v_7075695f6e61746976655f3632 = context_subscribe(&owner, v_3c636170747572653a7075695f6e61746976655f36303e.clone(), false, v_3c636170747572653a7075695f6e61746976655f36313e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("subscribe")), ("key", v_3c636170747572653a7075695f6e61746976655f36303e.clone()), ("off", v_7075695f6e61746976655f3632.clone())])); capture_disposer(&owner, "context", v_7075695f6e61746976655f3632.clone());   v_7075695f6e61746976655f3632 } };
            // Source "ordinary.proto.ts":84:5
            { let v_7075695f6e61746976655f3633 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f36343e = Value::string("contextTrace"); let v_3c636170747572653a7075695f6e61746976655f36353e = {  let v_636f6e746578745472616365 = v_636f6e746578745472616365.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "ordinary.proto.ts":84:45
                return { let value = (v_636f6e746578745472616365.read()).borrow().clone(); value };
            })) }; let v_7075695f6e61746976655f3636 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f36343e.clone(), v_3c636170747572653a7075695f6e61746976655f36353e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f36343e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f36353e.clone())]));    v_7075695f6e61746976655f3636 } };
            // Source "ordinary.proto.ts":85:5
            { let v_7075695f6e61746976655f3637 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f36383e = record(vec![("contextWrite", record(vec![("type", Value::string("number")), ("default", Value::number(0.0_f64))])), ("present", record(vec![("type", Value::string("boolean")), ("default", Value::boolean(true))])), ("rearmOnUnmount", record(vec![("type", Value::string("boolean")), ("default", Value::boolean(false))])), ("throwUnmount", record(vec![("type", Value::string("boolean")), ("default", Value::boolean(false))])), ("failDispose", record(vec![("type", Value::string("boolean")), ("default", Value::boolean(false))]))]); let v_7075695f6e61746976655f3639 = props_define(&owner, v_3c636170747572653a7075695f6e61746976655f36383e.clone()); capture_effect(&owner, "props", record(vec![("op", Value::string("define")), ("specMap", v_3c636170747572653a7075695f6e61746976655f36383e.clone())]));    v_7075695f6e61746976655f3639 } };
            // Source "ordinary.proto.ts":92:5
            { let v_7075695f6e61746976655f3730 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f37323e = Value::Array(Rc::new(vec![Value::string("contextWrite")])); let v_3c636170747572653a7075695f6e61746976655f37333e = {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f30386165666632656434323964663065: Value = arg(&arguments, 0);
                let v_6e6578745f5f33363363393763306537343738376433: Value = arg(&arguments, 1);
                // Source "ordinary.proto.ts":93:7
                return { let v_7075695f6e61746976655f3731 = v_72756e5f5f30386165666632656434323964663065.clone(); context_update(&(v_7075695f6e61746976655f3731.clone()).owner(), native_context_key(&PUI_CONTEXT_KEY_0, "ordinary.proto.ts#CHANNEL_A"), record(vec![("value", Value::number(((v_6e6578745f5f33363363393763306537343738376433.clone()).member("contextWrite", false)).num()))]), false) };
            })) }; let v_7075695f6e61746976655f3734 = watch_props(&owner, Some(v_3c636170747572653a7075695f6e61746976655f37323e.clone()), false, v_3c636170747572653a7075695f6e61746976655f37333e.clone()); capture_effect(&owner, "props", record(vec![("op", Value::string("watch")), ("keys", v_3c636170747572653a7075695f6e61746976655f37323e.clone()), ("off", v_7075695f6e61746976655f3734.clone())])); capture_disposer(&owner, "props", v_7075695f6e61746976655f3734.clone());   v_7075695f6e61746976655f3734 } };
            // Source "ordinary.proto.ts":95:5
            { let v_7075695f6e61746976655f3735 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f37373e = Value::Array(Rc::new(vec![Value::string("present")])); let v_3c636170747572653a7075695f6e61746976655f37383e = {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f39306166336466396661373263623866: Value = arg(&arguments, 0);
                let v_6e6578745f5f33303439393337643563316532313538: Value = arg(&arguments, 1);
                // Source "ordinary.proto.ts":95:49
                return { let v_7075695f6e61746976655f3736 = v_72756e5f5f39306166336466396661373263623866.clone(); set_present(&(v_7075695f6e61746976655f3736.clone()).owner(), Value::boolean(((v_6e6578745f5f33303439393337643563316532313538.clone()).member("present", false)).bool())) };
            })) }; let v_7075695f6e61746976655f3739 = watch_props(&owner, Some(v_3c636170747572653a7075695f6e61746976655f37373e.clone()), false, v_3c636170747572653a7075695f6e61746976655f37383e.clone()); capture_effect(&owner, "props", record(vec![("op", Value::string("watch")), ("keys", v_3c636170747572653a7075695f6e61746976655f37373e.clone()), ("off", v_7075695f6e61746976655f3739.clone())])); capture_disposer(&owner, "props", v_7075695f6e61746976655f3739.clone());   v_7075695f6e61746976655f3739 } };
            // Source "ordinary.proto.ts":96:11
            v_636f756e746572.initialize(v_5f5f7075694d6f64756c6530.with(|function| (function.call)(0.0_f64)));
            // Source "ordinary.proto.ts":97:11
            let v_666f7277617264 = {  let v_6c617465725f5f31393132666632613933613931633264 = v_6c617465725f5f31393132666632613933613931633264.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "ordinary.proto.ts":97:27
                return v_6c617465725f5f31393132666632613933613931633264.read().call_authored(vec![]);
            })) };
            // Source "ordinary.proto.ts":98:11
            v_6c617465725f5f31393132666632613933613931633264.initialize({   Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "ordinary.proto.ts":98:25
                return Value::string("later");
            })) });
            // Source "ordinary.proto.ts":99:11
            v_6576656e.initialize({  let v_6f6464 = v_6f6464.clone(); let call:Rc<dyn Fn(f64)->bool>=Rc::new(move |argument_0: f64| -> bool {
                let v_6e5f5f37393731643438663465663836633963: f64 = argument_0;
                // Source "ordinary.proto.ts":99:42
                return if { let pui_native_80=v_6e5f5f37393731643438663465663836633963.clone(); let pui_native_81=0.0_f64; (pui_native_80==pui_native_81) } {true} else {(v_6f6464.read().call)({ let pui_native_82:f64=v_6e5f5f37393731643438663465663836633963.clone(); let pui_native_83:f64=1.0_f64; pui_native_82 - pui_native_83 })};
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call((arg(&arguments,0)).num()))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } });
            // Source "ordinary.proto.ts":100:11
            v_6f6464.initialize({  let v_6576656e = v_6576656e.clone(); let call:Rc<dyn Fn(f64)->bool>=Rc::new(move |argument_0: f64| -> bool {
                let v_6e5f5f61343338636361383433336336643163: f64 = argument_0;
                // Source "ordinary.proto.ts":100:41
                return if { let pui_native_84=v_6e5f5f61343338636361383433336336643163.clone(); let pui_native_85=0.0_f64; (pui_native_84==pui_native_85) } {false} else {(v_6576656e.read().call)({ let pui_native_86:f64=v_6e5f5f61343338636361383433336336643163.clone(); let pui_native_87:f64=1.0_f64; pui_native_86 - pui_native_87 })};
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call((arg(&arguments,0)).num()))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } });
            // Source "ordinary.proto.ts":101:9
            v_73657175656e6365.initialize(Rc::new(std::cell::RefCell::new(0.0_f64)));
            // Source "ordinary.proto.ts":102:11
            v_64656661756c7473.initialize({  let v_73657175656e6365 = v_73657175656e6365.clone(); let call:Rc<dyn Fn(Value, Value)->f64>=Rc::new(move |argument_0: Value, argument_1: Value| -> f64 {
                let v_66697273745f5f32336235363761643936623533386434: Value = { let argument = argument_0; if matches!(&argument, Value::Undefined) { Value::number({ let cell=v_73657175656e6365.read(); let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; value }) } else { argument } };
                let v_7365636f6e64: Value = { let argument = argument_1; if matches!(&argument, Value::Undefined) { Value::number({ let pui_native_88:f64=(v_66697273745f5f32336235363761643936623533386434.clone()).num(); let pui_native_89:f64=1.0_f64; pui_native_88 + pui_native_89 }) } else { argument } };
                // Source "ordinary.proto.ts":103:7
                return { let pui_native_90:f64={ let pui_native_92:f64=(v_66697273745f5f32336235363761643936623533386434.clone()).num(); let pui_native_93:f64=10.0_f64; pui_native_92 * pui_native_93 }; let pui_native_91:f64=(v_7365636f6e64.clone()).num(); pui_native_90 + pui_native_91 };
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call(arg(&arguments,0), arg(&arguments,1)))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } });
            // Source "ordinary.proto.ts":104:11
            v_64656661756c74436c6f73757265.initialize({   let call:Rc<dyn Fn(Value, Value)->f64>=Rc::new(move |argument_0: Value, argument_1: Value| -> f64 {
                let v_6c617465725f5f30623839383261313030323464376366: LexicalBinding<Value> = lexical_binding();
                let v_72656164: Value = { let argument = argument_0; if matches!(&argument, Value::Undefined) { ({  let v_6c617465725f5f30623839383261313030323464376366 = v_6c617465725f5f30623839383261313030323464376366.clone(); let call:Rc<dyn Fn()->f64>=Rc::new(move || -> f64 {
                    // Source "ordinary.proto.ts":104:42
                    return (v_6c617465725f5f30623839383261313030323464376366.read()).num();
                }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable") } else { argument } };
                v_6c617465725f5f30623839383261313030323464376366.initialize({ let argument = argument_1; if matches!(&argument, Value::Undefined) { Value::number(7.0_f64) } else { argument } });
                // Source "ordinary.proto.ts":104:63
                return ({ let callable = v_72656164.clone(); callable.call_authored(vec![]) }).num();
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call(arg(&arguments,0), arg(&arguments,1)))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } });
            // Source "ordinary.proto.ts":105:9
            v_7461736b.initialize(Rc::new(std::cell::RefCell::new(Value::Json(Json::Null))));
            // Source "ordinary.proto.ts":106:9
            v_636f6d706c65746564.initialize(Rc::new(std::cell::RefCell::new(0.0_f64)));
            // Source "ordinary.proto.ts":107:11
            v_6c6966656379636c65.initialize(record(vec![("first", Value::number(0.0_f64)), ("second", Value::number(0.0_f64)), ("delayed", Value::number(0.0_f64))]));
            // Source "ordinary.proto.ts":108:5
            { let v_7075695f6e61746976655f3934 = v_6465665f5f37313630613761653830323735653834.clone(); register_life(&owner, "unmounted", { let owner = owner.clone(); let v_6c6966656379636c65 = v_6c6966656379636c65.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f64633466383761396136303732613466: Value = arg(&arguments, 0);
                // Source "ordinary.proto.ts":109:7
                if (({ let v_7075695f6e61746976655f3935 = v_72756e5f5f64633466383761396136303732613466.clone(); read_props(&(v_7075695f6e61746976655f3935.clone()).owner(), false) }).member("rearmOnUnmount", false)).bool() {
                    // Source "ordinary.proto.ts":110:9
                    schedule_delay(&owner, Value::number(1.0_f64), {  let v_6c6966656379636c65 = v_6c6966656379636c65.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                        // Source "ordinary.proto.ts":111:11
                        Value::number((set_member(v_6c6966656379636c65.read(), "delayed", Value::number({ let pui_native_96:f64=((v_6c6966656379636c65.read()).member("delayed", false)).num(); let pui_native_97:f64=1.0_f64; pui_native_96 + pui_native_97 }))).num());
                        Value::Undefined
                    })) });
                    // Source "ordinary.proto.ts":113:9
                    if (({ let v_7075695f6e61746976655f3938 = v_72756e5f5f64633466383761396136303732613466.clone(); read_props(&(v_7075695f6e61746976655f3938.clone()).owner(), false) }).member("throwUnmount", false)).bool() {
                        // Source "ordinary.proto.ts":113:43
                        throw_value(Value::number(0.0_f64));
                    }
                }
                Value::Undefined
            })) }) };
            // Source "ordinary.proto.ts":116:5
            { let v_7075695f6e61746976655f3939 = v_6465665f5f37313630613761653830323735653834.clone(); register_life(&owner, "before-dispose", {  let v_6c6966656379636c65 = v_6c6966656379636c65.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f39636532613635613334313431396138: Value = arg(&arguments, 0);
                // Source "ordinary.proto.ts":117:7
                Value::number((set_member(v_6c6966656379636c65.read(), "first", Value::number({ let pui_native_100:f64=((v_6c6966656379636c65.read()).member("first", false)).num(); let pui_native_101:f64=1.0_f64; pui_native_100 + pui_native_101 }))).num());
                // Source "ordinary.proto.ts":118:7
                if (({ let v_7075695f6e61746976655f313032 = v_72756e5f5f39636532613635613334313431396138.clone(); read_props(&(v_7075695f6e61746976655f313032.clone()).owner(), false) }).member("failDispose", false)).bool() {
                    // Source "ordinary.proto.ts":118:40
                    throw_value(Value::number(0.0_f64));
                }
                Value::Undefined
            })) }) };
            // Source "ordinary.proto.ts":120:5
            { let v_7075695f6e61746976655f313033 = v_6465665f5f37313630613761653830323735653834.clone(); register_life(&owner, "before-dispose", {  let v_6c6966656379636c65 = v_6c6966656379636c65.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "ordinary.proto.ts":121:7
                Value::number((set_member(v_6c6966656379636c65.read(), "second", Value::number({ let pui_native_104:f64=((v_6c6966656379636c65.read()).member("second", false)).num(); let pui_native_105:f64=1.0_f64; pui_native_104 + pui_native_105 }))).num());
                Value::Undefined
            })) }) };
            // Source "ordinary.proto.ts":123:5
            { let v_7075695f6e61746976655f313036 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3130373e = Value::string("lifecycle"); let v_3c636170747572653a7075695f6e61746976655f3130383e = v_6c6966656379636c65.read(); let v_7075695f6e61746976655f313039 = expose_value(&owner, v_3c636170747572653a7075695f6e61746976655f3130373e.clone(), v_3c636170747572653a7075695f6e61746976655f3130383e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.value")), ("key", v_3c636170747572653a7075695f6e61746976655f3130373e.clone()), ("value", v_3c636170747572653a7075695f6e61746976655f3130383e.clone())]));    v_7075695f6e61746976655f313039 } };
            // Source "ordinary.proto.ts":124:5
            { let v_7075695f6e61746976655f313130 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3131313e = Value::string("increment"); let v_3c636170747572653a7075695f6e61746976655f3131323e = ({  let v_636f756e746572 = v_636f756e746572.clone(); let call:Rc<dyn Fn()->f64>=Rc::new(move || -> f64 {
                // Source "ordinary.proto.ts":124:42
                return ({ let callable = (v_636f756e746572.read()).member("increment", false); callable.call_authored(vec![]) }).num();
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"); let v_7075695f6e61746976655f313133 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3131313e.clone(), v_3c636170747572653a7075695f6e61746976655f3131323e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3131313e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3131323e.clone())]));    v_7075695f6e61746976655f313133 } };
            // Source "ordinary.proto.ts":125:5
            { let v_7075695f6e61746976655f313134 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3131353e = Value::string("read"); let v_3c636170747572653a7075695f6e61746976655f3131363e = ({  let v_636f756e746572 = v_636f756e746572.clone(); let call:Rc<dyn Fn()->f64>=Rc::new(move || -> f64 {
                // Source "ordinary.proto.ts":125:37
                return ({ let callable = (v_636f756e746572.read()).member("read", false); callable.call_authored(vec![]) }).num();
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"); let v_7075695f6e61746976655f313137 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3131353e.clone(), v_3c636170747572653a7075695f6e61746976655f3131363e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3131353e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3131363e.clone())]));    v_7075695f6e61746976655f313137 } };
            // Source "ordinary.proto.ts":126:5
            { let v_7075695f6e61746976655f313138 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3131393e = Value::string("same"); let v_3c636170747572653a7075695f6e61746976655f3132303e = ({  let v_636f756e746572 = v_636f756e746572.clone(); let call:Rc<dyn Fn()->bool>=Rc::new(move || -> bool {
                // Source "ordinary.proto.ts":126:37
                return ({ let callable = (v_636f756e746572.read()).member("same", false); callable.call_authored(vec![]) }).bool();
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"); let v_7075695f6e61746976655f313231 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3131393e.clone(), v_3c636170747572653a7075695f6e61746976655f3132303e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3131393e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3132303e.clone())]));    v_7075695f6e61746976655f313231 } };
            // Source "ordinary.proto.ts":127:5
            { let v_7075695f6e61746976655f313232 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3132333e = Value::string("forward"); let v_3c636170747572653a7075695f6e61746976655f3132343e = v_666f7277617264.clone(); let v_7075695f6e61746976655f313235 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3132333e.clone(), v_3c636170747572653a7075695f6e61746976655f3132343e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3132333e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3132343e.clone())]));    v_7075695f6e61746976655f313235 } };
            // Source "ordinary.proto.ts":128:5
            { let v_7075695f6e61746976655f313236 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3132373e = Value::string("even"); let v_3c636170747572653a7075695f6e61746976655f3132383e = (v_6576656e.read()).ordinary.clone().expect("checked native data callable"); let v_7075695f6e61746976655f313239 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3132373e.clone(), v_3c636170747572653a7075695f6e61746976655f3132383e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3132373e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3132383e.clone())]));    v_7075695f6e61746976655f313239 } };
            // Source "ordinary.proto.ts":129:5
            { let v_7075695f6e61746976655f313330 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3133313e = Value::string("defaults"); let v_3c636170747572653a7075695f6e61746976655f3133323e = ({  let v_64656661756c7473 = v_64656661756c7473.clone(); let call:Rc<dyn Fn()->f64>=Rc::new(move || -> f64 {
                // Source "ordinary.proto.ts":129:41
                return (v_64656661756c7473.read().call)(Value::Undefined, Value::Undefined);
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"); let v_7075695f6e61746976655f313333 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3133313e.clone(), v_3c636170747572653a7075695f6e61746976655f3133323e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3133313e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3133323e.clone())]));    v_7075695f6e61746976655f313333 } };
            // Source "ordinary.proto.ts":130:5
            { let v_7075695f6e61746976655f313334 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3133353e = Value::string("explicitDefault"); let v_3c636170747572653a7075695f6e61746976655f3133363e = ({  let v_64656661756c7473 = v_64656661756c7473.clone(); let call:Rc<dyn Fn(f64)->f64>=Rc::new(move |argument_0: f64| -> f64 {
                let v_76616c75655f5f34333737363564656236316665613936: f64 = argument_0;
                // Source "ordinary.proto.ts":130:61
                return (v_64656661756c7473.read().call)(Value::number(v_76616c75655f5f34333737363564656236316665613936.clone()), Value::Undefined);
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call((arg(&arguments,0)).num()))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"); let v_7075695f6e61746976655f313337 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3133353e.clone(), v_3c636170747572653a7075695f6e61746976655f3133363e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3133353e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3133363e.clone())]));    v_7075695f6e61746976655f313337 } };
            // Source "ordinary.proto.ts":131:5
            { let v_7075695f6e61746976655f313338 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3133393e = Value::string("defaultCapture"); let v_3c636170747572653a7075695f6e61746976655f3134303e = ({  let v_64656661756c74436c6f73757265 = v_64656661756c74436c6f73757265.clone(); let call:Rc<dyn Fn()->f64>=Rc::new(move || -> f64 {
                // Source "ordinary.proto.ts":131:47
                return (v_64656661756c74436c6f73757265.read().call)(Value::Undefined, Value::Undefined);
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"); let v_7075695f6e61746976655f313431 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3133393e.clone(), v_3c636170747572653a7075695f6e61746976655f3134303e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3133393e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3134303e.clone())]));    v_7075695f6e61746976655f313431 } };
            // Source "ordinary.proto.ts":132:5
            { let v_7075695f6e61746976655f313432 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3134333e = Value::string("shared"); let v_3c636170747572653a7075695f6e61746976655f3134343e = ({   let call:Rc<dyn Fn()->f64>=Rc::new(move || -> f64 {
                // Source "ordinary.proto.ts":132:39
                return v_5f5f7075694d6f64756c6531.with(|cell| {let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; value});
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"); let v_7075695f6e61746976655f313435 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3134333e.clone(), v_3c636170747572653a7075695f6e61746976655f3134343e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3134333e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3134343e.clone())]));    v_7075695f6e61746976655f313435 } };
            // Source "ordinary.proto.ts":133:5
            { let v_7075695f6e61746976655f313436 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3135313e = Value::string("freezeAlias"); let v_3c636170747572653a7075695f6e61746976655f3135323e = ({   let call:Rc<dyn Fn()->bool>=Rc::new(move || -> bool {
                // Source "ordinary.proto.ts":134:13
                let v_76616c75655f5f36633861633166366534393961336463 = record(vec![("count", Value::number(1.0_f64))]);
                // Source "ordinary.proto.ts":135:13
                let v_616c6961735f5f30636661343434393365633761653637 = v_76616c75655f5f36633861633166366534393961336463.clone();
                // Source "ordinary.proto.ts":136:13
                let v_66726f7a656e = freeze(v_76616c75655f5f36633861633166366534393961336463.clone());
                // Source "ordinary.proto.ts":137:7
                if (Value::boolean(!strict_equal(&(v_66726f7a656e.clone()), &(v_76616c75655f5f36633861633166366534393961336463.clone())))).bool() {
                    // Source "ordinary.proto.ts":137:29
                    return false;
                }
                // Source "ordinary.proto.ts":138:7
                match match catch_authored::<std::ops::ControlFlow<bool>>(|| {
                        // Source "ordinary.proto.ts":139:9
                        Value::number((set_member(v_616c6961735f5f30636661343434393365633761653637.clone(), "count", Value::number(2.0_f64))).num());
                        std::ops::ControlFlow::Continue(())
                    }) {
                        Ok(flow) => flow,
                        Err(_) => (|| -> std::ops::ControlFlow<bool> {
                            // Source "ordinary.proto.ts":141:9
                            return std::ops::ControlFlow::Break({ let pui_native_149=((v_616c6961735f5f30636661343434393365633761653637.clone()).member("count", false)).num(); let pui_native_150=1.0_f64; (pui_native_149==pui_native_150) });
                        })()
                    } {
                    std::ops::ControlFlow::Break(value) => return value,
                    std::ops::ControlFlow::Continue(()) => {}
                }
                // Source "ordinary.proto.ts":143:7
                return false;
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"); let v_7075695f6e61746976655f313533 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3135313e.clone(), v_3c636170747572653a7075695f6e61746976655f3135323e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3135313e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3135323e.clone())]));    v_7075695f6e61746976655f313533 } };
            // Source "ordinary.proto.ts":145:5
            { let v_7075695f6e61746976655f313534 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3135373e = Value::string("caughtIdentity"); let v_3c636170747572653a7075695f6e61746976655f3135383e = ({   let call:Rc<dyn Fn()->bool>=Rc::new(move || -> bool {
                // Source "ordinary.proto.ts":146:13
                let v_6578706563746564 = record(vec![("name", Value::string("example"))]);
                // Source "ordinary.proto.ts":147:7
                match match catch_authored::<std::ops::ControlFlow<bool>>(|| {
                        // Source "ordinary.proto.ts":148:9
                        throw_value(v_6578706563746564.clone());
                    }) {
                        Ok(flow) => flow,
                        Err(v_6572726f72) => (|| -> std::ops::ControlFlow<bool> {
                            // Source "ordinary.proto.ts":150:9
                            return std::ops::ControlFlow::Break((Value::boolean(strict_equal(&(v_6572726f72.clone()), &(v_6578706563746564.clone())))).bool());
                        })()
                    } {
                    std::ops::ControlFlow::Break(value) => return value,
                    std::ops::ControlFlow::Continue(()) => {}
                }
                unreachable!("checked scalar function did not return")
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"); let v_7075695f6e61746976655f313539 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3135373e.clone(), v_3c636170747572653a7075695f6e61746976655f3135383e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3135373e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3135383e.clone())]));    v_7075695f6e61746976655f313539 } };
            // Source "ordinary.proto.ts":153:5
            { let v_7075695f6e61746976655f313630 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3136333e = Value::string("optional"); let v_3c636170747572653a7075695f6e61746976655f3136343e = ({   let call:Rc<dyn Fn(bool)->Value>=Rc::new(move |argument_0: bool| -> Value {
                let v_6d697373696e67: bool = argument_0;
                let v_63616c6c73: LexicalBinding<Rc<std::cell::RefCell<f64>>> = lexical_binding();
                // Source "ordinary.proto.ts":154:11
                v_63616c6c73.initialize(Rc::new(std::cell::RefCell::new(0.0_f64)));
                // Source "ordinary.proto.ts":155:13
                let v_617267756d656e74 = {  let v_63616c6c73 = v_63616c6c73.clone(); let call:Rc<dyn Fn()->f64>=Rc::new(move || -> f64 {
                    // Source "ordinary.proto.ts":156:9
                    Value::number({ let cell=v_63616c6c73.read(); let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; previous });
                    // Source "ordinary.proto.ts":157:9
                    return 42.0_f64;
                }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } };
                // Source "ordinary.proto.ts":159:13
                let v_63616c6c6261636b = if (Value::boolean(v_6d697373696e67.clone())).truthy() { Value::Undefined } else { ({   let call:Rc<dyn Fn(f64)->f64>=Rc::new(move |argument_0: f64| -> f64 {
                    let v_76616c75655f5f32363462316433306461393833363934: f64 = argument_0;
                    // Source "ordinary.proto.ts":159:65
                    return v_76616c75655f5f32363462316433306461393833363934.clone();
                }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call((arg(&arguments,0)).num()))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable") };
                // Source "ordinary.proto.ts":160:13
                let v_76616c75655f5f31356362633562323434626236346536 = { let callable = v_63616c6c6261636b.clone(); if callable.nullish() { Value::Undefined } else { callable.call_authored(vec![Value::number((v_617267756d656e74.call)())]) } };
                // Source "ordinary.proto.ts":161:7
                return record(vec![("calls", Value::number({ let value=(v_63616c6c73.read()).borrow().clone(); value })), ("value", Value::number({ let pui_native_161=v_76616c75655f5f31356362633562323434626236346536.clone(); if pui_native_161.nullish() {-(1.0_f64)} else {(pui_native_161).num()} }))]);
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).bool())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"); let v_7075695f6e61746976655f313635 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3136333e.clone(), v_3c636170747572653a7075695f6e61746976655f3136343e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3136333e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3136343e.clone())]));    v_7075695f6e61746976655f313635 } };
            // Source "ordinary.proto.ts":163:5
            { let v_7075695f6e61746976655f313636 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3137313e = Value::string("spread"); let v_3c636170747572653a7075695f6e61746976655f3137323e = {   Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "ordinary.proto.ts":164:13
                let v_736f75726365 = record(vec![("first", Value::number(1.0_f64)), ("second", Value::number(2.0_f64))]);
                // Source "ordinary.proto.ts":165:13
                let v_636f7079 = { let mut fields = std::collections::BTreeMap::new(); fields.extend(own_entries(v_736f75726365.clone())); fields.insert("first".into(), Value::number(3.0_f64)); record_map(fields) };
                // Source "ordinary.proto.ts":166:7
                Value::number((set_member(v_736f75726365.clone(), "second", Value::number(8.0_f64))).num());
                // Source "ordinary.proto.ts":167:7
                return record(vec![("independent", Value::boolean({ let pui_native_167=((v_636f7079.clone()).member("second", false)).num(); let pui_native_168=2.0_f64; (pui_native_167==pui_native_168) })), ("overwrite", Value::boolean({ let pui_native_169=((v_636f7079.clone()).member("first", false)).num(); let pui_native_170=3.0_f64; (pui_native_169==pui_native_170) })), ("own", Value::boolean((has_own(&(v_636f7079.clone()), &(Value::string("second")))).bool())), ("finite", Value::boolean((array_every(Value::Array(Rc::new(vec![Value::number(1.0_f64), Value::number(2.0_f64), Value::number(3.0_f64)])), ({   let call:Rc<dyn Fn(f64)->bool>=Rc::new(move |argument_0: f64| -> bool {
                    let v_76616c75655f5f64366361356538613962386162656234: f64 = argument_0;
                    // Source "ordinary.proto.ts":171:44
                    return (v_76616c75655f5f64366361356538613962386162656234.clone()).is_finite();
                }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call((arg(&arguments,0)).num()))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"))).bool()))]);
            })) }; let v_7075695f6e61746976655f313733 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3137313e.clone(), v_3c636170747572653a7075695f6e61746976655f3137323e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3137313e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3137323e.clone())]));    v_7075695f6e61746976655f313733 } };
            // Source "ordinary.proto.ts":174:5
            { let v_7075695f6e61746976655f313734 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3137353e = Value::string("schedule"); let v_3c636170747572653a7075695f6e61746976655f3137363e = ({ let owner = owner.clone(); let v_7461736b = v_7461736b.clone(); let v_636f6d706c65746564 = v_636f6d706c65746564.clone(); let call:Rc<dyn Fn(f64)->Value>=Rc::new(move |argument_0: f64| -> Value {
                let v_6475726174696f6e: f64 = argument_0;
                // Source "ordinary.proto.ts":175:7
                { let value = schedule_delay(&owner, Value::number(v_6475726174696f6e.clone()), {  let v_636f6d706c65746564 = v_636f6d706c65746564.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                    // Source "ordinary.proto.ts":176:9
                    Value::number({ let cell=v_636f6d706c65746564.read(); let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; previous });
                    Value::Undefined
                })) }); *(v_7461736b.read()).borrow_mut() = value; }
                Value::Undefined
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).num())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"); let v_7075695f6e61746976655f313737 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3137353e.clone(), v_3c636170747572653a7075695f6e61746976655f3137363e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3137353e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3137363e.clone())]));    v_7075695f6e61746976655f313737 } };
            // Source "ordinary.proto.ts":179:5
            { let v_7075695f6e61746976655f313738 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3138303e = Value::string("cancel"); let v_3c636170747572653a7075695f6e61746976655f3138313e = {  let v_7461736b = v_7461736b.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "ordinary.proto.ts":180:7
                { let v_7075695f6e61746976655f313739 = { let value = (v_7461736b.read()).borrow().clone(); value }; if v_7075695f6e61746976655f313739.nullish() { Value::Undefined } else { (v_7075695f6e61746976655f313739.clone()).member("cancel", false).call_authored(vec![]) } };
                Value::Undefined
            })) }; let v_7075695f6e61746976655f313832 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3138303e.clone(), v_3c636170747572653a7075695f6e61746976655f3138313e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3138303e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3138313e.clone())]));    v_7075695f6e61746976655f313832 } };
            // Source "ordinary.proto.ts":182:5
            { let v_7075695f6e61746976655f313833 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3138343e = Value::string("completed"); let v_3c636170747572653a7075695f6e61746976655f3138353e = ({  let v_636f6d706c65746564 = v_636f6d706c65746564.clone(); let call:Rc<dyn Fn()->f64>=Rc::new(move || -> f64 {
                // Source "ordinary.proto.ts":182:42
                return { let value=(v_636f6d706c65746564.read()).borrow().clone(); value };
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"); let v_7075695f6e61746976655f313836 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3138343e.clone(), v_3c636170747572653a7075695f6e61746976655f3138353e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3138343e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3138353e.clone())]));    v_7075695f6e61746976655f313836 } };
            // Source "ordinary.proto.ts":183:11
            v_7075626c6963436f756e74.initialize({ let v_7075695f6e61746976655f313837 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3138383e = Value::string("publicCount"); let v_3c636170747572653a7075695f6e61746976655f3138393e = Value::number(0.0_f64); let v_7075695f6e61746976655f313930 = create_state(&owner, "discrete", v_3c636170747572653a7075695f6e61746976655f3138383e.clone(), Value::number((v_3c636170747572653a7075695f6e61746976655f3138393e.clone()).num()), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f313930.clone());    v_7075695f6e61746976655f313930 } });
            // Source "ordinary.proto.ts":184:11
            let v_636f6e74726f6c73 = record(vec![("increment", ({  let v_636f756e746572 = v_636f756e746572.clone(); let call:Rc<dyn Fn()->f64>=Rc::new(move || -> f64 {
                // Source "ordinary.proto.ts":184:41
                return ({ let callable = (v_636f756e746572.read()).member("increment", false); callable.call_authored(vec![]) }).num();
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")), ("read", ({  let v_636f756e746572 = v_636f756e746572.clone(); let call:Rc<dyn Fn()->f64>=Rc::new(move || -> f64 {
                // Source "ordinary.proto.ts":184:74
                return ({ let callable = (v_636f756e746572.read()).member("read", false); callable.call_authored(vec![]) }).num();
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"))]);
            // Source "ordinary.proto.ts":185:11
            v_72657475726e6564.initialize(record(vec![("value", Value::number(0.0_f64)), ("increment", ({  let v_7075626c6963436f756e74 = v_7075626c6963436f756e74.clone(); let v_72657475726e6564 = v_72657475726e6564.clone(); let call:Rc<dyn Fn()->f64>=Rc::new(move || -> f64 {
                // Source "ordinary.proto.ts":188:9
                { let v_7075695f6e61746976655f313931 = v_7075626c6963436f756e74.read(); state_set(v_7075695f6e61746976655f313931.clone(), Value::number({ let pui_native_192:f64=({ let v_7075695f6e61746976655f313934 = v_7075626c6963436f756e74.read(); Value::number(((v_7075695f6e61746976655f313934.clone()).get()).num()) }).num(); let pui_native_193:f64=1.0_f64; pui_native_192 + pui_native_193 }), Value::Undefined) };
                // Source "ordinary.proto.ts":189:9
                Value::number((set_member(v_72657475726e6564.read(), "value", Value::number(({ let v_7075695f6e61746976655f313935 = v_7075626c6963436f756e74.read(); Value::number(((v_7075695f6e61746976655f313935.clone()).get()).num()) }).num()))).num());
                // Source "ordinary.proto.ts":190:9
                return ({ let v_7075695f6e61746976655f313936 = v_7075626c6963436f756e74.read(); Value::number(((v_7075695f6e61746976655f313936.clone()).get()).num()) }).num();
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")), ("pure", ({   let call:Rc<dyn Fn()->f64>=Rc::new(move || -> f64 {
                // Source "ordinary.proto.ts":192:19
                return 42.0_f64;
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"))]));
            // Source "ordinary.proto.ts":194:5
            { let v_7075695f6e61746976655f313937 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3139383e = Value::string("controls"); let v_3c636170747572653a7075695f6e61746976655f3139393e = v_636f6e74726f6c73.clone(); let v_7075695f6e61746976655f323030 = expose_value(&owner, v_3c636170747572653a7075695f6e61746976655f3139383e.clone(), v_3c636170747572653a7075695f6e61746976655f3139393e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.value")), ("key", v_3c636170747572653a7075695f6e61746976655f3139383e.clone()), ("value", v_3c636170747572653a7075695f6e61746976655f3139393e.clone())]));    v_7075695f6e61746976655f323030 } };
            // Source "ordinary.proto.ts":195:5
            { let v_7075695f6e61746976655f323031 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3230323e = Value::string("controlsAlias"); let v_3c636170747572653a7075695f6e61746976655f3230333e = v_636f6e74726f6c73.clone(); let v_7075695f6e61746976655f323034 = expose_value(&owner, v_3c636170747572653a7075695f6e61746976655f3230323e.clone(), v_3c636170747572653a7075695f6e61746976655f3230333e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.value")), ("key", v_3c636170747572653a7075695f6e61746976655f3230323e.clone()), ("value", v_3c636170747572653a7075695f6e61746976655f3230333e.clone())]));    v_7075695f6e61746976655f323034 } };
            // Source "ordinary.proto.ts":196:5
            { let v_7075695f6e61746976655f323035 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3230363e = Value::string("returnControls"); let v_3c636170747572653a7075695f6e61746976655f3230373e = {  let v_72657475726e6564 = v_72657475726e6564.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "ordinary.proto.ts":196:47
                return v_72657475726e6564.read();
            })) }; let v_7075695f6e61746976655f323038 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3230363e.clone(), v_3c636170747572653a7075695f6e61746976655f3230373e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3230363e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3230373e.clone())]));    v_7075695f6e61746976655f323038 } };
            // Source "ordinary.proto.ts":197:5
            { let v_7075695f6e61746976655f323039 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3231303e = Value::string("returnFunction"); let v_3c636170747572653a7075695f6e61746976655f3231313e = {  let v_72657475726e6564 = v_72657475726e6564.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "ordinary.proto.ts":197:47
                return (v_72657475726e6564.read()).member("increment", false);
            })) }; let v_7075695f6e61746976655f323132 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3231303e.clone(), v_3c636170747572653a7075695f6e61746976655f3231313e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3231303e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3231313e.clone())]));    v_7075695f6e61746976655f323132 } };
            // Source "ordinary.proto.ts":198:5
            { let v_7075695f6e61746976655f323133 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3231343e = Value::string("returnPure"); let v_3c636170747572653a7075695f6e61746976655f3231353e = {  let v_72657475726e6564 = v_72657475726e6564.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "ordinary.proto.ts":198:43
                return (v_72657475726e6564.read()).member("pure", false);
            })) }; let v_7075695f6e61746976655f323136 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3231343e.clone(), v_3c636170747572653a7075695f6e61746976655f3231353e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3231343e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3231353e.clone())]));    v_7075695f6e61746976655f323136 } };
            // Source "ordinary.proto.ts":199:5
            { let v_7075695f6e61746976655f323137 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3231383e = Value::string("decide"); let v_3c636170747572653a7075695f6e61746976655f3231393e = (v_5f5f7075694d6f64756c6532.with(|value| value.clone())).ordinary.clone().expect("checked native data callable"); let v_7075695f6e61746976655f323230 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3231383e.clone(), v_3c636170747572653a7075695f6e61746976655f3231393e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3231383e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3231393e.clone())]));    v_7075695f6e61746976655f323230 } };
            // Source "ordinary.proto.ts":200:5
            Value::boolean({ let value=!(v_5f5f7075694d6f64756c6533.with(|cell| cell.borrow().clone())); v_5f5f7075694d6f64756c6533.with(|cell| *cell.borrow_mut()=value.clone()); value });
            // Source "ordinary.proto.ts":201:5
            { let v_7075695f6e61746976655f323231 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3232323e = Value::string("dataRegistered"); let v_3c636170747572653a7075695f6e61746976655f3232333e = Value::boolean(v_5f5f7075694d6f64756c6533.with(|cell| cell.borrow().clone())); let v_7075695f6e61746976655f323234 = expose_value(&owner, v_3c636170747572653a7075695f6e61746976655f3232323e.clone(), Value::boolean((v_3c636170747572653a7075695f6e61746976655f3232333e.clone()).bool())); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.value")), ("key", v_3c636170747572653a7075695f6e61746976655f3232323e.clone()), ("value", v_3c636170747572653a7075695f6e61746976655f3232333e.clone())]));    v_7075695f6e61746976655f323234 } };
            // Source "ordinary.proto.ts":202:5
            if v_5f5f7075694d6f64756c6533.with(|cell| cell.borrow().clone()) {
                // Source "ordinary.proto.ts":202:23
                { let v_7075695f6e61746976655f323235 = v_6465665f5f37313630613761653830323735653834.clone(); { let v_3c636170747572653a7075695f6e61746976655f3232363e = Value::string("conditionalDecide"); let v_3c636170747572653a7075695f6e61746976655f3232373e = (v_5f5f7075694d6f64756c6532.with(|value| value.clone())).ordinary.clone().expect("checked native data callable"); let v_7075695f6e61746976655f323238 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3232363e.clone(), v_3c636170747572653a7075695f6e61746976655f3232373e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3232363e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3232373e.clone())]));    v_7075695f6e61746976655f323238 } };
            }
            // Source "ordinary.proto.ts":203:5
            return { let callable={ let pui_native_229={   let call:Rc<dyn Fn(Value)->native::gpui_native_owner::NativeSnapshot>=Rc::new(move |argument_0: Value| -> native::gpui_native_owner::NativeSnapshot {
                let v_72656e6465726572: Value = argument_0;
                // Source "ordinary.proto.ts":203:26
                return { let v_7075695f6e61746976655f323330 = v_72656e6465726572.clone(); { let pui_native_231 = Value::string("div"); let _ = pui_native_231; let pui_native_232 = Value::Undefined; let pui_native_233 = native::gpui_native_owner::NativeSnapshot::text_value(Value::string("ordinary"));
      let pui_native_234 = if pui_native_232.nullish() { Vec::new() } else { let style = pui_native_232.member("style",false); if style.nullish(){Vec::new()}else{style_items(vec![style])} };
      let frame_children = pui_native_233.clone(); let text_children = pui_native_233.clone();
      native::gpui_native_owner::NativeSnapshot { identity:Rc::new(()),observation:None,valid:pui_native_233.valid,slot_count:pui_native_233.slot_count,passive_content:pui_native_233.passive_content,
        frame:Rc::new(move |owner,focus,parent_path,drive,slot,index| {
          let path=format!("{parent_path}-{}",*index);*index+=1;
          let tokens:Vec<String> = pui_native_234.iter().map(|(token,_)|token.clone()).collect();
          let(style,fixed,translation)=native_presentation(owner,&tokens);
          let mut element=gpui::div().id(gpui::ElementId::Name(path.to_owned().into())); *element.style()=style;
          let mut child_index=0;for child in (frame_children.frame)(owner,focus,&path,drive,slot,&mut child_index){element=element.child(child);}
          let element=translated_element(element.into_any_element(),translation,None); vec![if fixed{viewport_root(element)}else{element}]
        }),text:Rc::new(move|slot|(text_children.text)(slot)) }
    } };
            }); native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:None } }; Value::NativeFunction{identity:pui_native_229.identity.clone(),render:Rc::new(move |arguments:Vec<Value>| {(pui_native_229.call)(arg(&arguments,0))})} }; match callable {
      Value::NativeFunction{identity,render} => capture_renderer(Value::NativeFunction{identity,render:render.clone()},render),
      Value::Renderer(adapter) => Value::Renderer(adapter),
      Value::Function(callback) => capture_renderer(Value::Function(callback.clone()),Rc::new(move |arguments:Vec<Value>| { panic!("checked native renderer entry has no scalar callback alternative") })),
      _ => panic!("checked setup result must be a callable")
    } };
        })) }.call_authored(vec![definition_capability(&owner)]);
          Owner::finish(&owner_ref, renderer);
          // Establish the App's default-action snapshot before any authored
          // global key capture can replace focus during the same keystroke.
          register_sequential_focus_owner(&owner_ref, cx);
          let focus_subscriptions = if native_focus_observation_needed(&owner_ref) {
          let focus_owner = owner_ref.clone();
          let on_focus = cx.on_focus(&focus, window, move |view, window, cx| {
              native_host_callback(&focus_owner, "focus", || {
              let epoch = focus_owner.borrow().epoch;
              if !ready(&focus_owner) || focus_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&focus_owner, window);
              native_focus_fact(&focus_owner, view.focus.is_focused(window));
              if !ready(&focus_owner) || focus_owner.borrow().epoch != epoch { return; }
              dispatch(&focus_owner, "host:focus", false, event_fields("host:focus"));
              if ready(&focus_owner) && focus_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          let blur_owner = owner_ref.clone();
          let on_blur = cx.on_blur(&focus, window, move |view, window, cx| {
              native_host_callback(&blur_owner, "blur", || {
              let epoch = blur_owner.borrow().epoch;
              if !ready(&blur_owner) || blur_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&blur_owner, window);
              native_focus_fact(&blur_owner, view.focus.is_focused(window));
              if !ready(&blur_owner) || blur_owner.borrow().epoch != epoch { return; }
              text_blur(&blur_owner, window, cx);
              dispatch(&blur_owner, "host:blur", false, event_fields("host:blur"));
              if ready(&blur_owner) && blur_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          // A native slot descendant can start this root's keyboard press
          // while the root FocusHandle itself is not focused. Its departure
          // from the physical subtree is distinct from the root's own blur.
          let focus_out_owner = Rc::downgrade(&owner_ref);
          let on_focus_out = cx.on_focus_out(&focus, window, move |view, _, window, cx| {
              let Some(owner) = focus_out_owner.upgrade() else { return; };
              native_host_callback(&owner, "focus-out", || {
              let epoch = owner.borrow().epoch;
              if !ready(&owner) || owner.borrow().window_id != Some(window.window_handle().window_id()) || view.focus.contains_focused(window, cx) { return; }
              // This retires only an existing root press lease. Do not forge
              // host:blur or change the root's own Focus observation here.
              native_press_blur(&owner);
              if ready(&owner) && owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          vec![on_focus, on_blur, on_focus_out]
          } else { Vec::new() };
          let global_key_capture = subscribe_global_key_capture(&owner_ref, cx);
          let window_input = window_input_needed(&owner_ref).then(|| cx.focus_handle().tab_stop(false));
          let focus_lost = window_input.as_ref().map(|_| cx.on_focus_lost(window, |view, window, cx| { let owner=view.owner.clone(); native_host_callback(&owner, "focus-lost", || { if view.owner.borrow().window_id == Some(window.window_handle().window_id()) { if let Some(focus) = &view.window_input { restore_window_input(&view.owner, focus, window, cx); } } }); }));
          let mut view = Self { owner: owner_ref, focus, window_input, _focus_subscriptions: focus_subscriptions, _window_activation: None, _focus_lost: focus_lost, _global_key_capture: global_key_capture, _entry_readiness: None };
          view.bind_window_activation(window, cx);
          view
          })
      }
      #[cfg(feature="test-support")]
      pub fn native_resource_counts(&self) -> Json { let mut counts=native::gpui_native_owner::native_resource_counts(&self.owner); counts["nativeSubscriptions"] = Json::from(self._focus_subscriptions.len() + usize::from(self._window_activation.is_some()) + usize::from(self._focus_lost.is_some()) + usize::from(self._global_key_capture.is_some()) + usize::from(self._entry_readiness.is_some())); counts }
      pub fn handle(&self) -> CompiledComponentHandle { CompiledComponentHandle { owner: self.owner.clone() } }
      pub fn set_props(&mut self, raw: Json, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_props(&self.owner, raw));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; self.drive(window, cx)
      }
      pub fn set_instance_associations(&mut self, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_instance_associations(&self.owner, associations));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; drive_owners(window, cx); self.drive(window, cx)
      }
      pub fn set_slot(&mut self, slot: Vec<native::gpui_native_owner::NativeSnapshot>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { ensure(&Rc::downgrade(&self.owner)); assert_native_slot_children(&slot); let mut owner = self.owner.borrow_mut(); owner.slot = slot; owner.dirty = true; cx.notify(); }) }
      pub fn set_parent(&mut self, parent: Option<OwnerWeak>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { if let Err(error)=set_native_parent(&self.owner, parent.unwrap_or_default()){throw_error("NATIVE_PARENT_INVALID", error)} cx.notify(); }) }
      fn bind_window_activation(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !native_focus_observation_needed(&self.owner) && !native::gpui_native_move::move_owner_has_binding(&self.owner) && !control_label_is_label(&self.owner) { self._window_activation.take(); return; }
          let id = window.window_handle().window_id();
          if self._window_activation.as_ref().is_some_and(|(bound, _)| *bound == id) { return; }
          self._window_activation.take();
          let owner = self.owner.clone();
          let subscription = cx.observe_window_activation(window, move |view, window, cx| {
              let deactivated = owner.borrow().window_id == Some(window.window_handle().window_id()) && !window.is_window_active();
              native_host_callback(&owner, "window-activation", || {
                  if deactivated {
                      native_window_blur(&owner);
                      view.drive(window, cx).unwrap_or_else(|error| throw_value(error));
                  }
              });
              if deactivated { notify_native_change(cx); }
          });
          self._window_activation = Some((id, subscription));
      }
      #[cfg(feature = "experimental-focus-tree")]
      fn bind_entry_readiness(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !self.owner.borrow().modules.hooks.contains("focus-entry") { return; }
          let window_id = window.window_handle().window_id();
          if self._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window_id) { return; }
          self._entry_readiness.take();
          let view = cx.entity().downgrade();
          let subscription = window.observe_focus_tree(cx, move |_, window, cx| {
              let _ = view.update(cx, |view, cx| {
                  if view._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window.window_handle().window_id()) { if let Err(error)=view.drive(window, cx){report_native_failure(&view.owner,"entry-readiness",error)} }
              });
          });
          self._entry_readiness = Some((window_id, subscription));
      }
      fn notify_after_turn(&self, cx: &mut Context<Self>) {
          // GPUI suppresses Entity observer effects while a window is drawing,
          // including its focus/blur phase. Keep authored state synchronous,
          // then publish the host change after that physical draw lease ends.
          // A weak target cannot keep a detached component alive for delivery.
          notify_native_change(cx);
      }
      pub fn drive(&mut self, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let result = catch_authored(|| {
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          modules_drive(&self.owner, &self.focus, window, cx);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          drive_queued_focus(&self.owner, window, cx);
          });
          // A callback can publish before failing or retiring its owner. That
          // output is independent from repaint dirtiness and an unread queue.
          let dirty = std::mem::take(&mut self.owner.borrow_mut().dirty);
          if !notify_native_events(&self.owner, cx) && dirty { self.notify_after_turn(cx); }
          result
      }
  }
  impl Drop for CompiledComponent { fn drop(&mut self) { native_host_callback(&self.owner, "drop", || Owner::dispose(&self.owner)); } }
  impl gpui::Focusable for CompiledComponent { fn focus_handle(&self, _: &App) -> FocusHandle { self.focus.clone() } }
  impl Render for CompiledComponent {
      fn render(&mut self, window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
          let report_owner = self.owner.clone();
          native_host_callback(&report_owner, "render", || {
          refresh_native_atoms(&self.owner, window, cx);
          Owner::project(&self.owner);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); return gpui::div().into_any_element(); }
          if !self.owner.borrow().present { self._window_activation.take(); detach_native_view(&self.owner); return gpui::div().into_any_element(); }
          bind_native_focus_window(&self.owner, window);
          self.bind_window_activation(window, cx);
          #[cfg(feature = "experimental-focus-tree")] self.bind_entry_readiness(window, cx);
          let drive = self.owner.borrow().native_drive.as_ref().expect("live native owner drive").clone();
          // Drawing consumes only repaint dirtiness. A parent Render can call
          // an exposed method before this child is laid out: its independent
          // pending_native_events flag survives until the coalesced drive wakes
          // the consumer. Repeated slot projection cannot create a notify loop.
          self.owner.borrow_mut().dirty = false;
          let snapshot = self.owner.borrow().projection.clone().expect("live native projection");
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          let element = paint_native_root(&snapshot, &self.owner, &self.focus, format!("compiled-root-{}", Rc::as_ptr(&self.owner) as usize), drive);
          if let Some(focus) = &self.window_input { window_input_scope(element, focus, &self.owner) } else { element }
          }).unwrap_or_else(|| gpui::div().into_any_element())
      }
  }
  