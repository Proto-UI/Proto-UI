// Original static declaration "private/context.proto.ts#FAMILY"
use crate::native::gpui_native_owner::*;
use std::rc::Rc;
use serde_json::Value as Json;
pub static DECLARATION: StaticDeclaration = StaticDeclaration { id: "private/context.proto.ts#FAMILY", kind: "anatomy-family", config: || record(vec![("roles", record(vec![("root", record(vec![("cardinality", record(vec![("min", Value::number(1.0_f64)), ("max", Value::number(1.0_f64))]))])), ("item", record(vec![("cardinality", record(vec![("min", Value::number(0.0_f64)), ("max", Value::string("*"))]))]))]))]) };
