// Direct checked-source GPUI component. Supporting files are ordinary editable Rust.
  
  pub use proto_ui_gpui_native as native;
  pub use native::gpui_native_owner::{ControlLabelRef, InstanceAssociations};
  use gpui::{prelude::*, App, Context, FocusHandle, Subscription, Window};
  use std::rc::Rc;
  use serde_json::Value as Json;
  use native::gpui_native_owner::*;
  
  
  fn style_vocabulary() -> &'static native::gpui_native_style::StyleVocabulary {
      static VOCABULARY: std::sync::OnceLock<native::gpui_native_style::StyleVocabulary> = std::sync::OnceLock::new();
      VOCABULARY.get_or_init(|| native::gpui_native_style::StyleVocabulary::from_json(include_str!(".proto-ui/fixtures/style-tokens.json")).expect("compiler-produced style vocabulary"))
  }
  fn accepts_context(key: &str, value: &Json) -> bool {
      match key {
          
          _ => false,
      }
  }
  fn accepts_props(value: &Json) -> bool { value.is_object() && true }
  fn prop_valid(key: &str, value: &Json) -> bool { match key {  _ => false } }
  fn check_method(name: &str, arguments: &[Value]) { match name {
          "first" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "next" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "last" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
          _ => value_error("unknown exposed method"),
  } }
  
  #[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData0 {

}
  
  pub type GeneratedProps = GeneratedData0;
  fn authored_hook_0(definition: Value, input: Value) -> Value {
    let owner = definition.owner();
    authored_hook(&owner, "native-after", "once", input, {   Value::Function(Rc::new(move |_: Vec<Value>| {
        Value::Undefined
    })) }, Value::Undefined, Value::Undefined)
}
fn authored_hook_1(definition: Value, input: Value) -> Value {
    let owner = definition.owner();
    authored_hook(&owner, "native-outer", "once", input, { let owner = owner.clone();  Value::Function(Rc::new(move |_: Vec<Value>| {
        // Source "focus_scope.proto.ts":8:5
        native_builtin_hook(&owner, "asFocusable", || as_focusable(&owner));
        // Source "focus_scope.proto.ts":9:5
        authored_hook_0(definition_capability(&owner), Value::Undefined);
        // Source "focus_scope.proto.ts":10:5
        native_builtin_hook(&owner, "asFocusable", || as_focusable(&owner));
        Value::Undefined
    })) }, Value::Undefined, Value::Undefined)
}
  #[derive(Clone)]
  pub struct CompiledComponentHandle { pub owner: OwnerRef }
  impl CompiledComponentHandle {
      pub fn value_0(&self) -> Result<Value, Value> { catch_authored(|| { ensure(&Rc::downgrade(&self.owner)); self.owner.borrow().exposes.get("builtinCaptureProof").cloned().unwrap_or_else(|| value_error("unknown exposed value")) }) }
    pub fn method_1(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("first").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("first", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_2(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("next").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("next", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_3(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("last").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("last", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn state_4(&self) -> Result<bool, Value> { self.state("pressed").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_5(&self) -> Result<f64, Value> { self.state("pressStarts").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_6(&self) -> Result<f64, Value> { self.state("pressCommits").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_7(&self) -> Result<f64, Value> { self.state("pressCancels").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_8(&self) -> Result<f64, Value> { self.state("pressEnds").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_9(&self) -> Result<f64, Value> { self.state("hostBlurs").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
      pub fn owner(&self) -> OwnerWeak { Rc::downgrade(&self.owner) }
      pub fn state(&self, name: &str) -> Result<Json, Value> { catch_authored(|| { let state=self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed State")); state.get().data() }) }
      pub fn call(&self, name: &str, arguments: Vec<Json>, window: &mut Window, cx: &mut App) -> Result<Json, Value> {
          let outcome = catch_authored(|| {
          refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
          let callback = self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed method"));
          let arguments: Vec<Value> = arguments.into_iter().map(Value::json).collect(); check_method(name, &arguments);
          let result = invoke(&self.owner, "expose-method", &callback, arguments);
          let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
          if matches!(result, Value::Undefined) { Json::Null } else { result.data() }
          });
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome
      }
      pub fn host_target(&self) -> Result<Value, Value> { catch_authored(|| { ensure(&self.owner()); Value::HostTarget(self.owner()) }) }
      pub fn take_events(&self) -> Vec<(String, Json)> { std::mem::take(&mut self.owner.borrow_mut().emitted) }
      pub fn take_failures(&self) -> Vec<NativeFailure> { take_native_failures(&self.owner) }
      pub fn dispose(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
          catch_authored(|| {
          let drive = self.owner.borrow().native_drive.clone();
          let failure = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| Owner::dispose(&self.owner)));
          let driven = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| { if let Some(drive) = drive { drive(window, cx); } }));
          if let Err(failure) = failure { std::panic::resume_unwind(failure); }
          if let Err(failure) = driven { std::panic::resume_unwind(failure); }
          })
      }
  }
  pub struct CompiledComponent { pub owner: OwnerRef, focus: FocusHandle, window_input: Option<FocusHandle>, _focus_subscriptions: Vec<Subscription>, _window_activation: Option<(gpui::WindowId, Subscription)>, _focus_lost: Option<Subscription>, _global_key_capture: Option<Subscription>, _entry_readiness: Option<(gpui::WindowId, Subscription)> }
  impl CompiledComponent {
      pub fn create_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> { Self::create(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn create(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          Self::create_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn create_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          let mut failure = None;
          let entity = cx.new(|cx| Self::new_with_associations(raw_props, parent, associations, window, cx).unwrap_or_else(|error| {
              failure = Some(error);
              // A failed construction still returns normally through GPUI's
              // entity insertion. This inert temporary is dropped immediately
              // below; it is never published or mounted as a native component.
              let owner = Owner::new(Json::Object(Default::default()), Default::default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
              { let mut owner = owner.borrow_mut(); owner.disposed = true; owner.present = false; }
              Self { owner, focus: cx.focus_handle(), window_input: None, _focus_subscriptions: Vec::new(), _window_activation: None, _focus_lost: None, _global_key_capture: None, _entry_readiness: None }
          }));
          match failure { Some(error) => Err(error), None => Ok(entity) }
      }
      pub fn new_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> { Self::new(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn new(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          Self::new_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn new_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          catch_authored(|| {
          let owner_ref = Owner::new(raw_props, parent.unwrap_or_default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
          initialize_instance_associations(&owner_ref, associations);
          let owner = Rc::downgrade(&owner_ref);
          let focus = cx.focus_handle();
          let view = cx.entity().downgrade();
          let drive_owner=owner.clone(); let drive_focus=focus.clone();
          let driving = Rc::new(std::cell::Cell::new(false));
          let drive_pending = Rc::new(std::cell::Cell::new(false));
          let drive: Drive = Rc::new(move |window, cx| {
              // Platform effects need owner storage and its real FocusHandle,
              // not another lease of the generated component. Preserve their
              // synchronous effect (notably physical focus) under public calls.
              if !driving.replace(true) {
                  if let Some(owner)=drive_owner.upgrade() {
                      native_host_callback(&owner, "drive", || { modules_drive(&owner, &drive_focus, window, cx); drive_queued_focus(&owner, window, cx); });
                  }
                  driving.set(false);
              }
              if drive_pending.replace(true) { return; }
              let view=view.clone(); let pending=drive_pending.clone();
              // A public handle can be called from Entity::update. Return the
              // current host lease before requesting another component update.
              // Authored calls, State writes and platform commands remain
              // synchronous; component refresh is coalesced at the host boundary.
              window.defer(cx, move |window, cx| {
                  pending.set(false);
                  let _ = view.update(cx, |view, cx| { if let Err(error) = view.drive(window, cx) { report_native_failure(&view.owner, "drive", error); } });
              });
          });
          { let mut owner = owner_ref.borrow_mut(); owner.native_drive = Some(drive); owner.window_id = Some(window.window_handle().window_id()); }
  
          configure_native_atoms(&owner_ref, false, false);
          refresh_native_atoms(&owner_ref, window, cx);
          let _lexical_owner = enter_lexical_owner(&owner);
          let renderer = { let owner = owner.clone();  Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_646566: Value = arg(&arguments, 0);
            let v_73636f7065: LexicalBinding<Value> = lexical_binding();
            let v_726f76696e67: LexicalBinding<Value> = lexical_binding();
            let v_70726573736564: LexicalBinding<Value> = lexical_binding();
            let v_737461727473: LexicalBinding<Value> = lexical_binding();
            let v_636f6d6d697473: LexicalBinding<Value> = lexical_binding();
            let v_63616e63656c73: LexicalBinding<Value> = lexical_binding();
            let v_656e6473: LexicalBinding<Value> = lexical_binding();
            let v_686f7374426c757273: LexicalBinding<Value> = lexical_binding();
            // Source "focus_scope.proto.ts":17:11
            let v_746f70 = native_builtin_hook(&owner, "asFocusable", || as_focusable(&owner));
            // Source "focus_scope.proto.ts":18:11
            let v_63617074757265 = authored_hook_1(definition_capability(&owner), Value::Undefined);
            // Source "focus_scope.proto.ts":19:11
            let v_6368696c64 = { let v_7075695f6e61746976655f30 = v_63617074757265.clone(); { let capture_getter = (v_7075695f6e61746976655f30.clone()).member("getAsHook", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("asFocusable")]) } } };
            // Source "focus_scope.proto.ts":20:11
            let v_6166746572 = { let v_7075695f6e61746976655f31 = v_63617074757265.clone(); { let capture_getter = (v_7075695f6e61746976655f31.clone()).member("getAsHook", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("native-after")]) } } };
            // Source "focus_scope.proto.ts":21:11
            let v_68616e646c65 = { let v_7075695f6e61746976655f32 = v_63617074757265.clone(); { let capture_getter = (v_7075695f6e61746976655f32.clone()).member("getAsHookHandle", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("asFocusable")]) } } };
            // Source "focus_scope.proto.ts":22:5
            { let v_7075695f6e61746976655f33 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f31313e = Value::string("builtinCaptureProof"); let v_3c636170747572653a7075695f6e61746976655f31323e = record(vec![("name", (v_6368696c64.clone()).member("name", false)), ("privileged", Value::boolean(((v_6368696c64.clone()).member("privileged", false)).bool())), ("mode", (v_6368696c64.clone()).member("mode", false)), ("order", Value::number(((v_6368696c64.clone()).member("order", false)).num())), ("afterOrder", Value::number(((v_6166746572.clone()).member("order", false)).num())), ("afterPrivileged", Value::boolean(((v_6166746572.clone()).member("privileged", false)).bool())), ("sameRaw", Value::boolean((Value::boolean(strict_equal(&((v_6368696c64.clone()).member("result", false)), &(v_746f70.clone())))).bool())), ("sameHandle", Value::boolean((Value::boolean(strict_equal(&((v_6368696c64.clone()).member("handle", false)), &(v_746f70.clone())))).bool())), ("sameGetter", Value::boolean((Value::boolean(strict_equal(&(v_68616e646c65.clone()), &(v_746f70.clone())))).bool())), ("initiallyFocused", Value::boolean(({ let v_7075695f6e61746976655f3130 = (v_68616e646c65.clone()).member("focused", false); Value::boolean(((v_7075695f6e61746976655f3130.clone()).get()).bool()) }).bool()))]); let v_7075695f6e61746976655f3133 = expose_value(&owner, v_3c636170747572653a7075695f6e61746976655f31313e.clone(), v_3c636170747572653a7075695f6e61746976655f31323e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.value")), ("key", v_3c636170747572653a7075695f6e61746976655f31313e.clone()), ("value", v_3c636170747572653a7075695f6e61746976655f31323e.clone())]));    v_7075695f6e61746976655f3133 } };
            // Source "focus_scope.proto.ts":34:11
            v_73636f7065.initialize(native_builtin_hook(&owner, "asFocusScope", || focus_setup(&owner, "focus-scope")));
            // Source "focus_scope.proto.ts":35:11
            v_726f76696e67.initialize(native_builtin_hook(&owner, "asFocusRoving", || focus_setup(&owner, "focus-roving")));
            // Source "focus_scope.proto.ts":36:5
            { let v_7075695f6e61746976655f3134 = v_73636f7065.read(); focus_setup_config(&(v_7075695f6e61746976655f3134.clone()).owner(), "focus-scope", record(vec![("entry", Value::string("manual")), ("restore", Value::string("none")), ("emptyPolicy", Value::string("none"))])) };
            // Source "focus_scope.proto.ts":37:5
            { let v_7075695f6e61746976655f3135 = v_726f76696e67.read(); focus_setup_config(&(v_7075695f6e61746976655f3135.clone()).owner(), "focus-roving", record(vec![("navigation", Value::string("arrow")), ("orientation", Value::string("horizontal")), ("loop", Value::boolean(true))])) };
            // Source "focus_scope.proto.ts":38:5
            { let v_7075695f6e61746976655f3136 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f31383e = Value::string("first"); let v_3c636170747572653a7075695f6e61746976655f31393e = {  let v_73636f7065 = v_73636f7065.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "focus_scope.proto.ts":38:38
                return { let v_7075695f6e61746976655f3137 = v_73636f7065.read(); focus_navigate(&(v_7075695f6e61746976655f3137.clone()).owner(), false, "first", Value::Undefined) };
            })) }; let v_7075695f6e61746976655f3230 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f31383e.clone(), v_3c636170747572653a7075695f6e61746976655f31393e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f31383e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f31393e.clone())]));    v_7075695f6e61746976655f3230 } };
            // Source "focus_scope.proto.ts":39:5
            { let v_7075695f6e61746976655f3231 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f32333e = Value::string("next"); let v_3c636170747572653a7075695f6e61746976655f32343e = {  let v_726f76696e67 = v_726f76696e67.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "focus_scope.proto.ts":39:37
                return { let v_7075695f6e61746976655f3232 = v_726f76696e67.read(); focus_navigate(&(v_7075695f6e61746976655f3232.clone()).owner(), true, "next", Value::Undefined) };
            })) }; let v_7075695f6e61746976655f3235 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f32333e.clone(), v_3c636170747572653a7075695f6e61746976655f32343e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f32333e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f32343e.clone())]));    v_7075695f6e61746976655f3235 } };
            // Source "focus_scope.proto.ts":40:5
            { let v_7075695f6e61746976655f3236 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f32383e = Value::string("last"); let v_3c636170747572653a7075695f6e61746976655f32393e = {  let v_726f76696e67 = v_726f76696e67.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "focus_scope.proto.ts":40:37
                return { let v_7075695f6e61746976655f3237 = v_726f76696e67.read(); focus_navigate(&(v_7075695f6e61746976655f3237.clone()).owner(), true, "last", Value::Undefined) };
            })) }; let v_7075695f6e61746976655f3330 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f32383e.clone(), v_3c636170747572653a7075695f6e61746976655f32393e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f32383e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f32393e.clone())]));    v_7075695f6e61746976655f3330 } };
            // Source "focus_scope.proto.ts":42:11
            v_70726573736564.initialize({ let v_7075695f6e61746976655f3331 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f33323e = Value::string("pressed"); let v_3c636170747572653a7075695f6e61746976655f33333e = Value::boolean(false); let v_7075695f6e61746976655f3334 = create_state(&owner, "bool", v_3c636170747572653a7075695f6e61746976655f33323e.clone(), Value::boolean((v_3c636170747572653a7075695f6e61746976655f33333e.clone()).bool()), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3334.clone());    v_7075695f6e61746976655f3334 } });
            // Source "focus_scope.proto.ts":43:11
            v_737461727473.initialize({ let v_7075695f6e61746976655f3335 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f33363e = Value::string("pressStarts"); let v_3c636170747572653a7075695f6e61746976655f33373e = Value::number(0.0_f64); let v_7075695f6e61746976655f3338 = create_state(&owner, "discrete", v_3c636170747572653a7075695f6e61746976655f33363e.clone(), Value::number((v_3c636170747572653a7075695f6e61746976655f33373e.clone()).num()), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3338.clone());    v_7075695f6e61746976655f3338 } });
            // Source "focus_scope.proto.ts":44:11
            v_636f6d6d697473.initialize({ let v_7075695f6e61746976655f3339 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f34303e = Value::string("pressCommits"); let v_3c636170747572653a7075695f6e61746976655f34313e = Value::number(0.0_f64); let v_7075695f6e61746976655f3432 = create_state(&owner, "discrete", v_3c636170747572653a7075695f6e61746976655f34303e.clone(), Value::number((v_3c636170747572653a7075695f6e61746976655f34313e.clone()).num()), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3432.clone());    v_7075695f6e61746976655f3432 } });
            // Source "focus_scope.proto.ts":45:11
            v_63616e63656c73.initialize({ let v_7075695f6e61746976655f3433 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f34343e = Value::string("pressCancels"); let v_3c636170747572653a7075695f6e61746976655f34353e = Value::number(0.0_f64); let v_7075695f6e61746976655f3436 = create_state(&owner, "discrete", v_3c636170747572653a7075695f6e61746976655f34343e.clone(), Value::number((v_3c636170747572653a7075695f6e61746976655f34353e.clone()).num()), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3436.clone());    v_7075695f6e61746976655f3436 } });
            // Source "focus_scope.proto.ts":46:11
            v_656e6473.initialize({ let v_7075695f6e61746976655f3437 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f34383e = Value::string("pressEnds"); let v_3c636170747572653a7075695f6e61746976655f34393e = Value::number(0.0_f64); let v_7075695f6e61746976655f3530 = create_state(&owner, "discrete", v_3c636170747572653a7075695f6e61746976655f34383e.clone(), Value::number((v_3c636170747572653a7075695f6e61746976655f34393e.clone()).num()), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3530.clone());    v_7075695f6e61746976655f3530 } });
            // Source "focus_scope.proto.ts":47:11
            v_686f7374426c757273.initialize({ let v_7075695f6e61746976655f3531 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f35323e = Value::string("hostBlurs"); let v_3c636170747572653a7075695f6e61746976655f35333e = Value::number(0.0_f64); let v_7075695f6e61746976655f3534 = create_state(&owner, "discrete", v_3c636170747572653a7075695f6e61746976655f35323e.clone(), Value::number((v_3c636170747572653a7075695f6e61746976655f35333e.clone()).num()), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3534.clone());    v_7075695f6e61746976655f3534 } });
            // Source "focus_scope.proto.ts":48:5
            { let v_7075695f6e61746976655f3535 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f36313e = Value::string("press.start"); let v_3c636170747572653a7075695f6e61746976655f36323e = {  let v_70726573736564 = v_70726573736564.clone(); let v_737461727473 = v_737461727473.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "focus_scope.proto.ts":49:7
                { let v_7075695f6e61746976655f3536 = v_70726573736564.read(); state_set(v_7075695f6e61746976655f3536.clone(), Value::boolean(true), Value::Undefined) };
                // Source "focus_scope.proto.ts":50:7
                { let v_7075695f6e61746976655f3537 = v_737461727473.read(); state_set(v_7075695f6e61746976655f3537.clone(), Value::number({ let pui_native_58:f64=({ let v_7075695f6e61746976655f3630 = v_737461727473.read(); Value::number(((v_7075695f6e61746976655f3630.clone()).get()).num()) }).num(); let pui_native_59:f64=1.0_f64; pui_native_58 + pui_native_59 }), Value::Undefined) };
                Value::Undefined
            })) }; let v_7075695f6e61746976655f3633 = listen(&owner, v_3c636170747572653a7075695f6e61746976655f36313e.clone(), false, v_3c636170747572653a7075695f6e61746976655f36323e.clone(), Value::Undefined); capture_effect(&owner, "event", record(vec![("off", v_7075695f6e61746976655f3633.clone())])); capture_disposer(&owner, "event", v_7075695f6e61746976655f3633.clone());   v_7075695f6e61746976655f3633 } };
            // Source "focus_scope.proto.ts":52:5
            { let v_7075695f6e61746976655f3634 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f36393e = Value::string("press.commit"); let v_3c636170747572653a7075695f6e61746976655f37303e = {  let v_636f6d6d697473 = v_636f6d6d697473.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "focus_scope.proto.ts":52:40
                return { let v_7075695f6e61746976655f3635 = v_636f6d6d697473.read(); state_set(v_7075695f6e61746976655f3635.clone(), Value::number({ let pui_native_66:f64=({ let v_7075695f6e61746976655f3638 = v_636f6d6d697473.read(); Value::number(((v_7075695f6e61746976655f3638.clone()).get()).num()) }).num(); let pui_native_67:f64=1.0_f64; pui_native_66 + pui_native_67 }), Value::Undefined) };
            })) }; let v_7075695f6e61746976655f3731 = listen(&owner, v_3c636170747572653a7075695f6e61746976655f36393e.clone(), false, v_3c636170747572653a7075695f6e61746976655f37303e.clone(), Value::Undefined); capture_effect(&owner, "event", record(vec![("off", v_7075695f6e61746976655f3731.clone())])); capture_disposer(&owner, "event", v_7075695f6e61746976655f3731.clone());   v_7075695f6e61746976655f3731 } };
            // Source "focus_scope.proto.ts":53:5
            { let v_7075695f6e61746976655f3732 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f37383e = Value::string("press.end"); let v_3c636170747572653a7075695f6e61746976655f37393e = {  let v_70726573736564 = v_70726573736564.clone(); let v_656e6473 = v_656e6473.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "focus_scope.proto.ts":54:7
                { let v_7075695f6e61746976655f3733 = v_70726573736564.read(); state_set(v_7075695f6e61746976655f3733.clone(), Value::boolean(false), Value::Undefined) };
                // Source "focus_scope.proto.ts":55:7
                { let v_7075695f6e61746976655f3734 = v_656e6473.read(); state_set(v_7075695f6e61746976655f3734.clone(), Value::number({ let pui_native_75:f64=({ let v_7075695f6e61746976655f3737 = v_656e6473.read(); Value::number(((v_7075695f6e61746976655f3737.clone()).get()).num()) }).num(); let pui_native_76:f64=1.0_f64; pui_native_75 + pui_native_76 }), Value::Undefined) };
                Value::Undefined
            })) }; let v_7075695f6e61746976655f3830 = listen(&owner, v_3c636170747572653a7075695f6e61746976655f37383e.clone(), false, v_3c636170747572653a7075695f6e61746976655f37393e.clone(), Value::Undefined); capture_effect(&owner, "event", record(vec![("off", v_7075695f6e61746976655f3830.clone())])); capture_disposer(&owner, "event", v_7075695f6e61746976655f3830.clone());   v_7075695f6e61746976655f3830 } };
            // Source "focus_scope.proto.ts":57:5
            { let v_7075695f6e61746976655f3831 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f38373e = Value::string("press.cancel"); let v_3c636170747572653a7075695f6e61746976655f38383e = {  let v_70726573736564 = v_70726573736564.clone(); let v_63616e63656c73 = v_63616e63656c73.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "focus_scope.proto.ts":58:7
                { let v_7075695f6e61746976655f3832 = v_70726573736564.read(); state_set(v_7075695f6e61746976655f3832.clone(), Value::boolean(false), Value::Undefined) };
                // Source "focus_scope.proto.ts":59:7
                { let v_7075695f6e61746976655f3833 = v_63616e63656c73.read(); state_set(v_7075695f6e61746976655f3833.clone(), Value::number({ let pui_native_84:f64=({ let v_7075695f6e61746976655f3836 = v_63616e63656c73.read(); Value::number(((v_7075695f6e61746976655f3836.clone()).get()).num()) }).num(); let pui_native_85:f64=1.0_f64; pui_native_84 + pui_native_85 }), Value::Undefined) };
                Value::Undefined
            })) }; let v_7075695f6e61746976655f3839 = listen(&owner, v_3c636170747572653a7075695f6e61746976655f38373e.clone(), false, v_3c636170747572653a7075695f6e61746976655f38383e.clone(), Value::Undefined); capture_effect(&owner, "event", record(vec![("off", v_7075695f6e61746976655f3839.clone())])); capture_disposer(&owner, "event", v_7075695f6e61746976655f3839.clone());   v_7075695f6e61746976655f3839 } };
            // Source "focus_scope.proto.ts":61:5
            { let v_7075695f6e61746976655f3930 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f39353e = Value::string("host:blur"); let v_3c636170747572653a7075695f6e61746976655f39363e = {  let v_686f7374426c757273 = v_686f7374426c757273.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "focus_scope.proto.ts":61:37
                return { let v_7075695f6e61746976655f3931 = v_686f7374426c757273.read(); state_set(v_7075695f6e61746976655f3931.clone(), Value::number({ let pui_native_92:f64=({ let v_7075695f6e61746976655f3934 = v_686f7374426c757273.read(); Value::number(((v_7075695f6e61746976655f3934.clone()).get()).num()) }).num(); let pui_native_93:f64=1.0_f64; pui_native_92 + pui_native_93 }), Value::Undefined) };
            })) }; let v_7075695f6e61746976655f3937 = listen(&owner, v_3c636170747572653a7075695f6e61746976655f39353e.clone(), false, v_3c636170747572653a7075695f6e61746976655f39363e.clone(), Value::Undefined); capture_effect(&owner, "event", record(vec![("off", v_7075695f6e61746976655f3937.clone())])); capture_disposer(&owner, "event", v_7075695f6e61746976655f3937.clone());   v_7075695f6e61746976655f3937 } };
            // Source "focus_scope.proto.ts":62:5
            { let v_7075695f6e61746976655f3938 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f39393e = Value::string("pressed"); let v_3c636170747572653a7075695f6e61746976655f3130303e = v_70726573736564.read(); let v_7075695f6e61746976655f313031 = expose_state(&owner, v_3c636170747572653a7075695f6e61746976655f39393e.clone(), v_3c636170747572653a7075695f6e61746976655f3130303e.clone()); capture_effect(&owner, "state", record(vec![("op", Value::string("expose.state")), ("key", v_3c636170747572653a7075695f6e61746976655f39393e.clone()), ("handle", v_3c636170747572653a7075695f6e61746976655f3130303e.clone())]));   capture_introduced_state(&owner, v_3c636170747572653a7075695f6e61746976655f3130303e.clone()); v_7075695f6e61746976655f313031 } };
            // Source "focus_scope.proto.ts":63:5
            { let v_7075695f6e61746976655f313032 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f3130333e = Value::string("pressStarts"); let v_3c636170747572653a7075695f6e61746976655f3130343e = v_737461727473.read(); let v_7075695f6e61746976655f313035 = expose_state(&owner, v_3c636170747572653a7075695f6e61746976655f3130333e.clone(), v_3c636170747572653a7075695f6e61746976655f3130343e.clone()); capture_effect(&owner, "state", record(vec![("op", Value::string("expose.state")), ("key", v_3c636170747572653a7075695f6e61746976655f3130333e.clone()), ("handle", v_3c636170747572653a7075695f6e61746976655f3130343e.clone())]));   capture_introduced_state(&owner, v_3c636170747572653a7075695f6e61746976655f3130343e.clone()); v_7075695f6e61746976655f313035 } };
            // Source "focus_scope.proto.ts":64:5
            { let v_7075695f6e61746976655f313036 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f3130373e = Value::string("pressCommits"); let v_3c636170747572653a7075695f6e61746976655f3130383e = v_636f6d6d697473.read(); let v_7075695f6e61746976655f313039 = expose_state(&owner, v_3c636170747572653a7075695f6e61746976655f3130373e.clone(), v_3c636170747572653a7075695f6e61746976655f3130383e.clone()); capture_effect(&owner, "state", record(vec![("op", Value::string("expose.state")), ("key", v_3c636170747572653a7075695f6e61746976655f3130373e.clone()), ("handle", v_3c636170747572653a7075695f6e61746976655f3130383e.clone())]));   capture_introduced_state(&owner, v_3c636170747572653a7075695f6e61746976655f3130383e.clone()); v_7075695f6e61746976655f313039 } };
            // Source "focus_scope.proto.ts":65:5
            { let v_7075695f6e61746976655f313130 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f3131313e = Value::string("pressCancels"); let v_3c636170747572653a7075695f6e61746976655f3131323e = v_63616e63656c73.read(); let v_7075695f6e61746976655f313133 = expose_state(&owner, v_3c636170747572653a7075695f6e61746976655f3131313e.clone(), v_3c636170747572653a7075695f6e61746976655f3131323e.clone()); capture_effect(&owner, "state", record(vec![("op", Value::string("expose.state")), ("key", v_3c636170747572653a7075695f6e61746976655f3131313e.clone()), ("handle", v_3c636170747572653a7075695f6e61746976655f3131323e.clone())]));   capture_introduced_state(&owner, v_3c636170747572653a7075695f6e61746976655f3131323e.clone()); v_7075695f6e61746976655f313133 } };
            // Source "focus_scope.proto.ts":66:5
            { let v_7075695f6e61746976655f313134 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f3131353e = Value::string("pressEnds"); let v_3c636170747572653a7075695f6e61746976655f3131363e = v_656e6473.read(); let v_7075695f6e61746976655f313137 = expose_state(&owner, v_3c636170747572653a7075695f6e61746976655f3131353e.clone(), v_3c636170747572653a7075695f6e61746976655f3131363e.clone()); capture_effect(&owner, "state", record(vec![("op", Value::string("expose.state")), ("key", v_3c636170747572653a7075695f6e61746976655f3131353e.clone()), ("handle", v_3c636170747572653a7075695f6e61746976655f3131363e.clone())]));   capture_introduced_state(&owner, v_3c636170747572653a7075695f6e61746976655f3131363e.clone()); v_7075695f6e61746976655f313137 } };
            // Source "focus_scope.proto.ts":67:5
            { let v_7075695f6e61746976655f313138 = v_646566.clone(); { let v_3c636170747572653a7075695f6e61746976655f3131393e = Value::string("hostBlurs"); let v_3c636170747572653a7075695f6e61746976655f3132303e = v_686f7374426c757273.read(); let v_7075695f6e61746976655f313231 = expose_state(&owner, v_3c636170747572653a7075695f6e61746976655f3131393e.clone(), v_3c636170747572653a7075695f6e61746976655f3132303e.clone()); capture_effect(&owner, "state", record(vec![("op", Value::string("expose.state")), ("key", v_3c636170747572653a7075695f6e61746976655f3131393e.clone()), ("handle", v_3c636170747572653a7075695f6e61746976655f3132303e.clone())]));   capture_introduced_state(&owner, v_3c636170747572653a7075695f6e61746976655f3132303e.clone()); v_7075695f6e61746976655f313231 } };
            // Source "focus_scope.proto.ts":68:5
            return { let callable={ let pui_native_122={   let call:Rc<dyn Fn(Value)->native::gpui_native_owner::NativeSnapshot>=Rc::new(move |argument_0: Value| -> native::gpui_native_owner::NativeSnapshot {
                let v_72656e6465726572: Value = argument_0;
                // Source "focus_scope.proto.ts":68:26
                return { let v_7075695f6e61746976655f313233 = v_72656e6465726572.clone(); { let pui_native_124 = Value::string("section"); let _ = pui_native_124; let pui_native_125 = Value::Undefined; let pui_native_126 = { let v_7075695f6e61746976655f313238 = v_72656e6465726572.clone(); native::gpui_native_owner::NativeSnapshot::slot() };
      let pui_native_127 = if pui_native_125.nullish() { Vec::new() } else { let style = pui_native_125.member("style",false); if style.nullish(){Vec::new()}else{style_items(vec![style])} };
      let frame_children = pui_native_126.clone(); let text_children = pui_native_126.clone();
      native::gpui_native_owner::NativeSnapshot { identity:Rc::new(()),observation:None,valid:pui_native_126.valid,slot_count:pui_native_126.slot_count,passive_content:pui_native_126.passive_content,
        frame:Rc::new(move |owner,focus,parent_path,drive,slot,index| {
          let path=format!("{parent_path}-{}",*index);*index+=1;
          let tokens:Vec<String> = pui_native_127.iter().map(|(token,_)|token.clone()).collect();
          let(style,fixed,translation)=native_presentation(owner,&tokens);
          let mut element=gpui::div().id(gpui::ElementId::Name(path.to_owned().into())); *element.style()=style;
          let mut child_index=0;for child in (frame_children.frame)(owner,focus,&path,drive,slot,&mut child_index){element=element.child(child);}
          let element=translated_element(element.into_any_element(),translation,None); vec![if fixed{viewport_root(element)}else{element}]
        }),text:Rc::new(move|slot|(text_children.text)(slot)) }
    } };
            }); native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:None } }; Value::NativeFunction{identity:pui_native_122.identity.clone(),render:Rc::new(move |arguments:Vec<Value>| {(pui_native_122.call)(arg(&arguments,0))})} }; match callable {
      Value::NativeFunction{identity,render} => capture_renderer(Value::NativeFunction{identity,render:render.clone()},render),
      Value::Renderer(adapter) => Value::Renderer(adapter),
      Value::Function(callback) => capture_renderer(Value::Function(callback.clone()),Rc::new(move |arguments:Vec<Value>| { panic!("checked native renderer entry has no scalar callback alternative") })),
      _ => panic!("checked setup result must be a callable")
    } };
        })) }.call_authored(vec![definition_capability(&owner)]);
          Owner::finish(&owner_ref, renderer);
          // Establish the App's default-action snapshot before any authored
          // global key capture can replace focus during the same keystroke.
          register_sequential_focus_owner(&owner_ref, cx);
          let focus_subscriptions = if native_focus_observation_needed(&owner_ref) {
          let focus_owner = owner_ref.clone();
          let on_focus = cx.on_focus(&focus, window, move |view, window, cx| {
              native_host_callback(&focus_owner, "focus", || {
              let epoch = focus_owner.borrow().epoch;
              if !ready(&focus_owner) || focus_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&focus_owner, window);
              native_focus_fact(&focus_owner, view.focus.is_focused(window));
              if !ready(&focus_owner) || focus_owner.borrow().epoch != epoch { return; }
              dispatch(&focus_owner, "host:focus", false, event_fields("host:focus"));
              if ready(&focus_owner) && focus_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          let blur_owner = owner_ref.clone();
          let on_blur = cx.on_blur(&focus, window, move |view, window, cx| {
              native_host_callback(&blur_owner, "blur", || {
              let epoch = blur_owner.borrow().epoch;
              if !ready(&blur_owner) || blur_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&blur_owner, window);
              native_focus_fact(&blur_owner, view.focus.is_focused(window));
              if !ready(&blur_owner) || blur_owner.borrow().epoch != epoch { return; }
              text_blur(&blur_owner, window, cx);
              dispatch(&blur_owner, "host:blur", false, event_fields("host:blur"));
              if ready(&blur_owner) && blur_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          // A native slot descendant can start this root's keyboard press
          // while the root FocusHandle itself is not focused. Its departure
          // from the physical subtree is distinct from the root's own blur.
          let focus_out_owner = Rc::downgrade(&owner_ref);
          let on_focus_out = cx.on_focus_out(&focus, window, move |view, _, window, cx| {
              let Some(owner) = focus_out_owner.upgrade() else { return; };
              native_host_callback(&owner, "focus-out", || {
              let epoch = owner.borrow().epoch;
              if !ready(&owner) || owner.borrow().window_id != Some(window.window_handle().window_id()) || view.focus.contains_focused(window, cx) { return; }
              // This retires only an existing root press lease. Do not forge
              // host:blur or change the root's own Focus observation here.
              native_press_blur(&owner);
              if ready(&owner) && owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          vec![on_focus, on_blur, on_focus_out]
          } else { Vec::new() };
          let global_key_capture = subscribe_global_key_capture(&owner_ref, cx);
          let window_input = window_input_needed(&owner_ref).then(|| cx.focus_handle().tab_stop(false));
          let focus_lost = window_input.as_ref().map(|_| cx.on_focus_lost(window, |view, window, cx| { let owner=view.owner.clone(); native_host_callback(&owner, "focus-lost", || { if view.owner.borrow().window_id == Some(window.window_handle().window_id()) { if let Some(focus) = &view.window_input { restore_window_input(&view.owner, focus, window, cx); } } }); }));
          let mut view = Self { owner: owner_ref, focus, window_input, _focus_subscriptions: focus_subscriptions, _window_activation: None, _focus_lost: focus_lost, _global_key_capture: global_key_capture, _entry_readiness: None };
          view.bind_window_activation(window, cx);
          view
          })
      }
      #[cfg(feature="test-support")]
      pub fn native_resource_counts(&self) -> Json { let mut counts=native::gpui_native_owner::native_resource_counts(&self.owner); counts["nativeSubscriptions"] = Json::from(self._focus_subscriptions.len() + usize::from(self._window_activation.is_some()) + usize::from(self._focus_lost.is_some()) + usize::from(self._global_key_capture.is_some()) + usize::from(self._entry_readiness.is_some())); counts }
      pub fn handle(&self) -> CompiledComponentHandle { CompiledComponentHandle { owner: self.owner.clone() } }
      pub fn set_props(&mut self, raw: Json, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_props(&self.owner, raw));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; self.drive(window, cx)
      }
      pub fn set_instance_associations(&mut self, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_instance_associations(&self.owner, associations));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; drive_owners(window, cx); self.drive(window, cx)
      }
      pub fn set_slot(&mut self, slot: Vec<native::gpui_native_owner::NativeSnapshot>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { ensure(&Rc::downgrade(&self.owner)); assert_native_slot_children(&slot); let mut owner = self.owner.borrow_mut(); owner.slot = slot; owner.dirty = true; cx.notify(); }) }
      pub fn set_parent(&mut self, parent: Option<OwnerWeak>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { if let Err(error)=set_native_parent(&self.owner, parent.unwrap_or_default()){throw_error("NATIVE_PARENT_INVALID", error)} cx.notify(); }) }
      fn bind_window_activation(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !native_focus_observation_needed(&self.owner) && !native::gpui_native_move::move_owner_has_binding(&self.owner) && !control_label_is_label(&self.owner) { self._window_activation.take(); return; }
          let id = window.window_handle().window_id();
          if self._window_activation.as_ref().is_some_and(|(bound, _)| *bound == id) { return; }
          self._window_activation.take();
          let owner = self.owner.clone();
          let subscription = cx.observe_window_activation(window, move |view, window, cx| {
              let deactivated = owner.borrow().window_id == Some(window.window_handle().window_id()) && !window.is_window_active();
              native_host_callback(&owner, "window-activation", || {
                  if deactivated {
                      native_window_blur(&owner);
                      view.drive(window, cx).unwrap_or_else(|error| throw_value(error));
                  }
              });
              if deactivated { notify_native_change(cx); }
          });
          self._window_activation = Some((id, subscription));
      }
      #[cfg(feature = "experimental-focus-tree")]
      fn bind_entry_readiness(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !self.owner.borrow().modules.hooks.contains("focus-entry") { return; }
          let window_id = window.window_handle().window_id();
          if self._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window_id) { return; }
          self._entry_readiness.take();
          let view = cx.entity().downgrade();
          let subscription = window.observe_focus_tree(cx, move |_, window, cx| {
              let _ = view.update(cx, |view, cx| {
                  if view._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window.window_handle().window_id()) { if let Err(error)=view.drive(window, cx){report_native_failure(&view.owner,"entry-readiness",error)} }
              });
          });
          self._entry_readiness = Some((window_id, subscription));
      }
      fn notify_after_turn(&self, cx: &mut Context<Self>) {
          // GPUI suppresses Entity observer effects while a window is drawing,
          // including its focus/blur phase. Keep authored state synchronous,
          // then publish the host change after that physical draw lease ends.
          // A weak target cannot keep a detached component alive for delivery.
          notify_native_change(cx);
      }
      pub fn drive(&mut self, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let result = catch_authored(|| {
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          modules_drive(&self.owner, &self.focus, window, cx);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          drive_queued_focus(&self.owner, window, cx);
          });
          // A callback can publish before failing or retiring its owner. That
          // output is independent from repaint dirtiness and an unread queue.
          let dirty = std::mem::take(&mut self.owner.borrow_mut().dirty);
          if !notify_native_events(&self.owner, cx) && dirty { self.notify_after_turn(cx); }
          result
      }
  }
  impl Drop for CompiledComponent { fn drop(&mut self) { native_host_callback(&self.owner, "drop", || Owner::dispose(&self.owner)); } }
  impl gpui::Focusable for CompiledComponent { fn focus_handle(&self, _: &App) -> FocusHandle { self.focus.clone() } }
  impl Render for CompiledComponent {
      fn render(&mut self, window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
          let report_owner = self.owner.clone();
          native_host_callback(&report_owner, "render", || {
          refresh_native_atoms(&self.owner, window, cx);
          Owner::project(&self.owner);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); return gpui::div().into_any_element(); }
          if !self.owner.borrow().present { self._window_activation.take(); detach_native_view(&self.owner); return gpui::div().into_any_element(); }
          bind_native_focus_window(&self.owner, window);
          self.bind_window_activation(window, cx);
          #[cfg(feature = "experimental-focus-tree")] self.bind_entry_readiness(window, cx);
          let drive = self.owner.borrow().native_drive.as_ref().expect("live native owner drive").clone();
          // Drawing consumes only repaint dirtiness. A parent Render can call
          // an exposed method before this child is laid out: its independent
          // pending_native_events flag survives until the coalesced drive wakes
          // the consumer. Repeated slot projection cannot create a notify loop.
          self.owner.borrow_mut().dirty = false;
          let snapshot = self.owner.borrow().projection.clone().expect("live native projection");
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          let element = paint_native_root(&snapshot, &self.owner, &self.focus, format!("compiled-root-{}", Rc::as_ptr(&self.owner) as usize), drive);
          if let Some(focus) = &self.window_input { window_input_scope(element, focus, &self.owner) } else { element }
          }).unwrap_or_else(|| gpui::div().into_any_element())
      }
  }
  