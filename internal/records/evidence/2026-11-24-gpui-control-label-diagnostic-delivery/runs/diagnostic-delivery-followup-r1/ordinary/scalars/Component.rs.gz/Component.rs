// Direct checked-source GPUI component. Supporting files are ordinary editable Rust.
  #[cfg(panic = "abort")] compile_error!("Authored exception lowering requires panic=unwind");
  pub use proto_ui_gpui_native as native;
  pub use native::gpui_native_owner::{ControlLabelRef, InstanceAssociations};
  use gpui::{prelude::*, App, Context, FocusHandle, Subscription, Window};
  use std::rc::Rc;
  use serde_json::Value as Json;
  use native::gpui_native_owner::*;
  std::thread_local! { static v_5f5f7075694d6f64756c6530: Value = Value::Array(Rc::new(vec![Value::string("vega"), Value::string("nova")])); }
  
  fn style_vocabulary() -> &'static native::gpui_native_style::StyleVocabulary {
      static VOCABULARY: std::sync::OnceLock<native::gpui_native_style::StyleVocabulary> = std::sync::OnceLock::new();
      VOCABULARY.get_or_init(|| native::gpui_native_style::StyleVocabulary::from_json(include_str!(".proto-ui/fixtures/style-tokens.json")).expect("compiler-produced style vocabulary"))
  }
  fn accepts_context(key: &str, value: &Json) -> bool {
      match key {
          
          _ => false,
      }
  }
  fn accepts_props(value: &Json) -> bool { value.is_object() && true }
  fn prop_valid(key: &str, value: &Json) -> bool { match key {  _ => false } }
  fn check_method(name: &str, arguments: &[Value]) { match name {
          "probe" => if !(arguments.len() <= 1 && arguments.get(0).map_or(false, |value| (value).try_data().is_some_and(|data| data.is_string()))) { value_type_error("invalid exposed method arguments") },
        "arithmeticTexts" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "typedCallable" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "typedDefaults" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "numericLiterals" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "membership" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "assignment" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "assignmentFailure" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "caughtUnits" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
          _ => value_error("unknown exposed method"),
  } }
  
  #[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData0 {

}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
#[serde(untagged)]
pub enum GeneratedData2 {
    Alternative0(f64),
    Alternative1(()),
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData1 {
    #[serde(rename = "finite")]
    pub field_0: bool,
    #[serde(rename = "nan")]
    pub field_1: bool,
    #[serde(rename = "negativeZero")]
    pub field_2: bool,
    #[serde(rename = "number")]
    pub field_3: GeneratedData2,
    #[serde(rename = "text")]
    pub field_4: String,
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData3 {
    #[serde(rename = "negativeZero")]
    pub field_0: String,
    #[serde(rename = "positiveInfinity")]
    pub field_1: String,
    #[serde(rename = "negativeInfinity")]
    pub field_2: String,
    #[serde(rename = "nan")]
    pub field_3: String,
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData4 {
    #[serde(rename = "same")]
    pub field_0: bool,
    #[serde(rename = "boxed")]
    pub field_1: bool,
    #[serde(rename = "distinct")]
    pub field_2: bool,
    #[serde(rename = "first")]
    pub field_3: f64,
    #[serde(rename = "second")]
    pub field_4: f64,
    #[serde(rename = "count")]
    pub field_5: f64,
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData5 {
    #[serde(rename = "missing")]
    pub field_0: f64,
    #[serde(rename = "explicit")]
    pub field_1: f64,
    #[serde(rename = "zero")]
    pub field_2: f64,
    #[serde(rename = "defaultCallback")]
    pub field_3: f64,
    #[serde(rename = "explicitCallback")]
    pub field_4: f64,
    #[serde(rename = "explicitUndefined")]
    pub field_5: f64,
    #[serde(rename = "success")]
    pub field_6: f64,
    #[serde(rename = "failure")]
    pub field_7: f64,
    #[serde(rename = "count")]
    pub field_8: f64,
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData6 {
    #[serde(rename = "huge")]
    pub field_0: f64,
    #[serde(rename = "negativeHuge")]
    pub field_1: f64,
    #[serde(rename = "boundary")]
    pub field_2: f64,
    #[serde(rename = "tiny")]
    pub field_3: f64,
    #[serde(rename = "negativeTiny")]
    pub field_4: f64,
    #[serde(rename = "negativeZero")]
    pub field_5: bool,
    #[serde(rename = "nan")]
    pub field_6: bool,
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData7 {
    #[serde(rename = "present")]
    pub field_0: bool,
    #[serde(rename = "absent")]
    pub field_1: bool,
    #[serde(rename = "noCoercion")]
    pub field_2: bool,
    #[serde(rename = "empty")]
    pub field_3: String,
    #[serde(rename = "number")]
    pub field_4: String,
    #[serde(rename = "boolean")]
    pub field_5: String,
    #[serde(rename = "nil")]
    pub field_6: String,
    #[serde(rename = "missing")]
    pub field_7: String,
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData8 {
    #[serde(rename = "value")]
    pub field_0: f64,
    #[serde(rename = "last")]
    pub field_1: f64,
    #[serde(rename = "same")]
    pub field_2: bool,
    #[serde(rename = "nested")]
    pub field_3: f64,
    #[serde(rename = "trace")]
    pub field_4: String,
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData9 {
    #[serde(rename = "same")]
    pub field_0: bool,
    #[serde(rename = "trace")]
    pub field_1: String,
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData10 {
    #[serde(rename = "order")]
    pub field_0: bool,
    #[serde(rename = "before")]
    pub field_1: bool,
    #[serde(rename = "length")]
    pub field_2: f64,
    #[serde(rename = "same")]
    pub field_3: bool,
    #[serde(rename = "converted")]
    pub field_4: bool,
    #[serde(rename = "assembled")]
    pub field_5: String,
    #[serde(rename = "unpaired")]
    pub field_6: bool,
    #[serde(rename = "finite")]
    pub field_7: bool,
    #[serde(rename = "errorMessage")]
    pub field_8: bool,
}
  
  pub type GeneratedProps = GeneratedData0;
  
  #[derive(Clone)]
  pub struct CompiledComponentHandle { pub owner: OwnerRef }
  impl CompiledComponentHandle {
      pub fn method_0(&self, argument_0: String, window: &mut Window, cx: &mut App) -> Result<GeneratedData1, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![Value::json(serde_json::to_value(argument_0).expect("portable argument"))];
        let callback = self.owner.borrow().exposes.get("probe").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("probe", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !((result.is_object() && result.get("finite").map_or(false, |field| field.is_boolean()) && result.get("nan").map_or(false, |field| field.is_boolean()) && result.get("negativeZero").map_or(false, |field| field.is_boolean()) && result.get("number").map_or(false, |field| (field.as_f64().is_some_and(f64::is_finite) || field.is_null())) && result.get("text").map_or(false, |field| field.is_string()))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_1(&self, window: &mut Window, cx: &mut App) -> Result<GeneratedData3, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("arithmeticTexts").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("arithmeticTexts", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !((result.is_object() && result.get("negativeZero").map_or(false, |field| field.is_string()) && result.get("positiveInfinity").map_or(false, |field| field.is_string()) && result.get("negativeInfinity").map_or(false, |field| field.is_string()) && result.get("nan").map_or(false, |field| field.is_string()))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_2(&self, window: &mut Window, cx: &mut App) -> Result<GeneratedData4, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("typedCallable").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("typedCallable", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !((result.is_object() && result.get("same").map_or(false, |field| field.is_boolean()) && result.get("boxed").map_or(false, |field| field.is_boolean()) && result.get("distinct").map_or(false, |field| field.is_boolean()) && result.get("first").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("second").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("count").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_3(&self, window: &mut Window, cx: &mut App) -> Result<GeneratedData5, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("typedDefaults").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("typedDefaults", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !((result.is_object() && result.get("missing").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("explicit").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("zero").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("defaultCallback").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("explicitCallback").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("explicitUndefined").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("success").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("failure").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("count").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_4(&self, window: &mut Window, cx: &mut App) -> Result<GeneratedData6, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("numericLiterals").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("numericLiterals", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !((result.is_object() && result.get("huge").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("negativeHuge").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("boundary").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("tiny").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("negativeTiny").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("negativeZero").map_or(false, |field| field.is_boolean()) && result.get("nan").map_or(false, |field| field.is_boolean()))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_5(&self, window: &mut Window, cx: &mut App) -> Result<GeneratedData7, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("membership").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("membership", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !((result.is_object() && result.get("present").map_or(false, |field| field.is_boolean()) && result.get("absent").map_or(false, |field| field.is_boolean()) && result.get("noCoercion").map_or(false, |field| field.is_boolean()) && result.get("empty").map_or(false, |field| field.is_string()) && result.get("number").map_or(false, |field| field.is_string()) && result.get("boolean").map_or(false, |field| field.is_string()) && result.get("nil").map_or(false, |field| field.is_string()) && result.get("missing").map_or(false, |field| field.is_string()))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_6(&self, window: &mut Window, cx: &mut App) -> Result<GeneratedData8, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("assignment").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("assignment", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !((result.is_object() && result.get("value").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("last").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("same").map_or(false, |field| field.is_boolean()) && result.get("nested").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("trace").map_or(false, |field| field.is_string()))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_7(&self, window: &mut Window, cx: &mut App) -> Result<GeneratedData9, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("assignmentFailure").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("assignmentFailure", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !((result.is_object() && result.get("same").map_or(false, |field| field.is_boolean()) && result.get("trace").map_or(false, |field| field.is_string()))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_8(&self, window: &mut Window, cx: &mut App) -> Result<GeneratedData10, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("caughtUnits").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("caughtUnits", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !((result.is_object() && result.get("order").map_or(false, |field| field.is_boolean()) && result.get("before").map_or(false, |field| field.is_boolean()) && result.get("length").map_or(false, |field| field.as_f64().is_some_and(f64::is_finite)) && result.get("same").map_or(false, |field| field.is_boolean()) && result.get("converted").map_or(false, |field| field.is_boolean()) && result.get("assembled").map_or(false, |field| field.is_string()) && result.get("unpaired").map_or(false, |field| field.is_boolean()) && result.get("finite").map_or(false, |field| field.is_boolean()) && result.get("errorMessage").map_or(false, |field| field.is_boolean()))) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
      pub fn owner(&self) -> OwnerWeak { Rc::downgrade(&self.owner) }
      pub fn state(&self, name: &str) -> Result<Json, Value> { catch_authored(|| { let state=self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed State")); state.get().data() }) }
      pub fn call(&self, name: &str, arguments: Vec<Json>, window: &mut Window, cx: &mut App) -> Result<Json, Value> {
          let outcome = catch_authored(|| {
          refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
          let callback = self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed method"));
          let arguments: Vec<Value> = arguments.into_iter().map(Value::json).collect(); check_method(name, &arguments);
          let result = invoke(&self.owner, "expose-method", &callback, arguments);
          let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
          if matches!(result, Value::Undefined) { Json::Null } else { result.data() }
          });
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome
      }
      pub fn host_target(&self) -> Result<Value, Value> { catch_authored(|| { ensure(&self.owner()); Value::HostTarget(self.owner()) }) }
      pub fn take_events(&self) -> Vec<(String, Json)> { std::mem::take(&mut self.owner.borrow_mut().emitted) }
      pub fn take_failures(&self) -> Vec<NativeFailure> { take_native_failures(&self.owner) }
      pub fn dispose(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
          catch_authored(|| {
          let drive = self.owner.borrow().native_drive.clone();
          let failure = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| Owner::dispose(&self.owner)));
          let driven = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| { if let Some(drive) = drive { drive(window, cx); } }));
          if let Err(failure) = failure { std::panic::resume_unwind(failure); }
          if let Err(failure) = driven { std::panic::resume_unwind(failure); }
          })
      }
  }
  pub struct CompiledComponent { pub owner: OwnerRef, focus: FocusHandle, window_input: Option<FocusHandle>, _focus_subscriptions: Vec<Subscription>, _window_activation: Option<(gpui::WindowId, Subscription)>, _focus_lost: Option<Subscription>, _global_key_capture: Option<Subscription>, _entry_readiness: Option<(gpui::WindowId, Subscription)> }
  impl CompiledComponent {
      pub fn create_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> { Self::create(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn create(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          Self::create_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn create_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          let mut failure = None;
          let entity = cx.new(|cx| Self::new_with_associations(raw_props, parent, associations, window, cx).unwrap_or_else(|error| {
              failure = Some(error);
              // A failed construction still returns normally through GPUI's
              // entity insertion. This inert temporary is dropped immediately
              // below; it is never published or mounted as a native component.
              let owner = Owner::new(Json::Object(Default::default()), Default::default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
              { let mut owner = owner.borrow_mut(); owner.disposed = true; owner.present = false; }
              Self { owner, focus: cx.focus_handle(), window_input: None, _focus_subscriptions: Vec::new(), _window_activation: None, _focus_lost: None, _global_key_capture: None, _entry_readiness: None }
          }));
          match failure { Some(error) => Err(error), None => Ok(entity) }
      }
      pub fn new_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> { Self::new(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn new(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          Self::new_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn new_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          catch_authored(|| {
          let owner_ref = Owner::new(raw_props, parent.unwrap_or_default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
          initialize_instance_associations(&owner_ref, associations);
          let owner = Rc::downgrade(&owner_ref);
          let focus = cx.focus_handle();
          let view = cx.entity().downgrade();
          let drive_owner=owner.clone(); let drive_focus=focus.clone();
          let driving = Rc::new(std::cell::Cell::new(false));
          let drive_pending = Rc::new(std::cell::Cell::new(false));
          let drive: Drive = Rc::new(move |window, cx| {
              // Platform effects need owner storage and its real FocusHandle,
              // not another lease of the generated component. Preserve their
              // synchronous effect (notably physical focus) under public calls.
              if !driving.replace(true) {
                  if let Some(owner)=drive_owner.upgrade() {
                      native_host_callback(&owner, "drive", || { modules_drive(&owner, &drive_focus, window, cx); drive_queued_focus(&owner, window, cx); });
                  }
                  driving.set(false);
              }
              if drive_pending.replace(true) { return; }
              let view=view.clone(); let pending=drive_pending.clone();
              // A public handle can be called from Entity::update. Return the
              // current host lease before requesting another component update.
              // Authored calls, State writes and platform commands remain
              // synchronous; component refresh is coalesced at the host boundary.
              window.defer(cx, move |window, cx| {
                  pending.set(false);
                  let _ = view.update(cx, |view, cx| { if let Err(error) = view.drive(window, cx) { report_native_failure(&view.owner, "drive", error); } });
              });
          });
          { let mut owner = owner_ref.borrow_mut(); owner.native_drive = Some(drive); owner.window_id = Some(window.window_handle().window_id()); }
  
          configure_native_atoms(&owner_ref, false, false);
          refresh_native_atoms(&owner_ref, window, cx);
          let _lexical_owner = enter_lexical_owner(&owner);
          let renderer = { let owner = owner.clone();  Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_646566: Value = arg(&arguments, 0);
            let v_6d61726b: LexicalBinding<native::gpui_native_owner::NativeCallable<dyn Fn(Value, f64, Value) -> f64>> = lexical_binding();
            let v_66696e616c6c7956616c7565: LexicalBinding<native::gpui_native_owner::NativeCallable<dyn Fn(f64) -> f64>> = lexical_binding();
            let v_6170706c79: LexicalBinding<native::gpui_native_owner::NativeCallable<dyn Fn(f64, Value) -> f64>> = lexical_binding();
            let v_6f7074696f6e616c: LexicalBinding<native::gpui_native_owner::NativeCallable<dyn Fn(Value) -> f64>> = lexical_binding();
            let v_636f756e74: LexicalBinding<Rc<std::cell::RefCell<f64>>> = lexical_binding();
            let v_7472616365: LexicalBinding<Rc<std::cell::RefCell<Value>>> = lexical_binding();
            let v_73746570: LexicalBinding<native::gpui_native_owner::NativeCallable<dyn Fn(f64) -> f64>> = lexical_binding();
            let v_6964656e74697479: LexicalBinding<native::gpui_native_owner::NativeCallable<dyn Fn(f64) -> f64>> = lexical_binding();
            let v_626f786564: LexicalBinding<Value> = lexical_binding();
            // Source "scalars.proto.ts":52:5
            v_6d61726b.initialize({  let v_7472616365 = v_7472616365.clone(); let call:Rc<dyn Fn(Value, f64, Value)->f64>=Rc::new(move |argument_0: Value, argument_1: f64, argument_2: Value| -> f64 {
                let v_6c6162656c: Value = argument_0;
                let v_76616c75655f5f38663932363934323765376232613162: f64 = argument_1;
                let v_6661696c: Value = { let argument = argument_2; if matches!(&argument, Value::Undefined) { Value::boolean(false) } else { argument } };
                // Source "scalars.proto.ts":53:7
                { let value = add({ let value = (v_7472616365.read()).borrow().clone(); value }, v_6c6162656c.clone()); *(v_7472616365.read()).borrow_mut() = value; }
                // Source "scalars.proto.ts":54:7
                if (v_6661696c.clone()).bool() {
                    // Source "scalars.proto.ts":54:17
                    throw_value(Value::boolean(false));
                }
                // Source "scalars.proto.ts":55:7
                return v_76616c75655f5f38663932363934323765376232613162.clone();
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call(arg(&arguments,0), (arg(&arguments,1)).num(), arg(&arguments,2)))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } });
            // Source "scalars.proto.ts":41:5
            v_66696e616c6c7956616c7565.initialize({  let v_636f756e74 = v_636f756e74.clone(); let call:Rc<dyn Fn(f64)->f64>=Rc::new(move |argument_0: f64| -> f64 {
                let v_76616c75655f5f62326164363738656266303762326234: f64 = argument_0;
                // Source "scalars.proto.ts":42:7
                match authored_finally(|| -> std::ops::ControlFlow<f64> {
                        match catch_authored::<std::ops::ControlFlow<f64>>(|| {
                            // Source "scalars.proto.ts":43:9
                            if { let pui_native_0:f64=v_76616c75655f5f62326164363738656266303762326234.clone(); let pui_native_1:f64=0.0_f64; pui_native_0 < pui_native_1 } {
                                // Source "scalars.proto.ts":43:24
                                throw_value(Value::boolean(false));
                            }
                            // Source "scalars.proto.ts":44:9
                            return std::ops::ControlFlow::Break({ let pui_native_2:f64=v_76616c75655f5f62326164363738656266303762326234.clone(); let pui_native_3:f64=1.0_f64; pui_native_2 + pui_native_3 });
                        }) {
                            Ok(flow) => flow,
                            Err(v_6572726f72) => (|| -> std::ops::ControlFlow<f64> {
                                // Source "scalars.proto.ts":46:9
                                if (Value::boolean(strict_equal(&(v_6572726f72.clone()), &(Value::boolean(false))))).bool() {
                                    // Source "scalars.proto.ts":46:30
                                    return std::ops::ControlFlow::Break(41.0_f64);
                                }
                                // Source "scalars.proto.ts":47:9
                                throw_value(v_6572726f72.clone());
                            })()
                        }
                    }, || -> std::ops::ControlFlow<f64> {
                        // Source "scalars.proto.ts":49:9
                        Value::number({ let cell=v_636f756e74.read(); let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; previous });
                        std::ops::ControlFlow::Continue(())
                    }) {
                    std::ops::ControlFlow::Break(value) => return value,
                    std::ops::ControlFlow::Continue(()) => {}
                }
                unreachable!("checked scalar function did not return")
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call((arg(&arguments,0)).num()))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } });
            // Source "scalars.proto.ts":38:5
            v_6170706c79.initialize({   let call:Rc<dyn Fn(f64, Value)->f64>=Rc::new(move |argument_0: f64, argument_1: Value| -> f64 {
                let v_76616c75655f5f65396337643230616664373331613166: f64 = argument_0;
                let v_63616c6c6261636b: Value = { let argument = argument_1; if matches!(&argument, Value::Undefined) { ({   let call:Rc<dyn Fn(f64)->f64>=Rc::new(move |argument_0: f64| -> f64 {
                    let v_696e7075745f5f31313134653462626261313061316133: f64 = argument_0;
                    // Source "scalars.proto.ts":38:84
                    return { let pui_native_6:f64=v_696e7075745f5f31313134653462626261313061316133.clone(); let pui_native_7:f64=1.0_f64; pui_native_6 + pui_native_7 };
                }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call((arg(&arguments,0)).num()))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable") } else { argument } };
                // Source "scalars.proto.ts":39:7
                return ({ let callable = v_63616c6c6261636b.clone(); callable.call_authored(vec![Value::number(v_76616c75655f5f65396337643230616664373331613166.clone())]) }).num();
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call((arg(&arguments,0)).num(), arg(&arguments,1)))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } });
            // Source "scalars.proto.ts":34:5
            v_6f7074696f6e616c.initialize({   let call:Rc<dyn Fn(Value)->f64>=Rc::new(move |argument_0: Value| -> f64 {
                let v_76616c75655f5f32323433316166643530643535623265: Value = argument_0;
                // Source "scalars.proto.ts":35:7
                if (Value::boolean(!strict_equal(&(typeof_value(&(v_76616c75655f5f32323433316166643530643535623265.clone()))), &(Value::string("number"))))).bool() {
                    // Source "scalars.proto.ts":35:38
                    return 17.0_f64;
                }
                // Source "scalars.proto.ts":36:7
                return (v_76616c75655f5f32323433316166643530643535623265.clone()).num();
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call(arg(&arguments,0)))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } });
            // Source "scalars.proto.ts":8:5
            { let v_7075695f6e61746976655f3130 = v_646566.clone(); expose_method(&owner, Value::string("probe"), {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_696e7075745f5f34353530366433666435353635373935: Value = arg(&arguments, 0);
                // Source "scalars.proto.ts":9:13
                let v_76616c75655f5f63383632393031323632383366613335: f64 = ((v_696e7075745f5f34353530366433666435353635373935.clone()).scalar_number());
                // Source "scalars.proto.ts":10:13
                let v_66696e697465: bool = (v_76616c75655f5f63383632393031323632383366613335.clone()).is_finite();
                // Source "scalars.proto.ts":11:7
                return record(vec![("finite", Value::boolean(v_66696e697465.clone())), ("nan", Value::boolean({ let pui_native_11=v_76616c75655f5f63383632393031323632383366613335.clone(); let pui_native_12=v_76616c75655f5f63383632393031323632383366613335.clone(); !(pui_native_11==pui_native_12) })), ("negativeZero", Value::boolean({ let pui_native_13={ let pui_native_15=v_76616c75655f5f63383632393031323632383366613335.clone(); let pui_native_16=0.0_f64; (pui_native_15==pui_native_16) }; if (pui_native_13) {{ let pui_native_17:f64={ let pui_native_19:f64=1.0_f64; let pui_native_20:f64=v_76616c75655f5f63383632393031323632383366613335.clone(); pui_native_19 / pui_native_20 }; let pui_native_18:f64=0.0_f64; pui_native_17 < pui_native_18 }} else {pui_native_13} })), ("number", if (Value::boolean(v_66696e697465.clone())).truthy() { Value::number(v_76616c75655f5f63383632393031323632383366613335.clone()) } else { Value::Json(Json::Null) }), ("text", add(Value::number(v_76616c75655f5f63383632393031323632383366613335.clone()), Value::string("")))]);
            })) }) };
            // Source "scalars.proto.ts":19:5
            { let v_7075695f6e61746976655f3231 = v_646566.clone(); expose_method(&owner, Value::string("arithmeticTexts"), {   Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "scalars.proto.ts":19:48
                return record(vec![("negativeZero", add(Value::number(-(0.0_f64)), Value::string(""))), ("positiveInfinity", add(Value::number({ let pui_native_22:f64=1.0_f64; let pui_native_23:f64=0.0_f64; pui_native_22 / pui_native_23 }), Value::string(""))), ("negativeInfinity", add(Value::number({ let pui_native_24:f64=-(1.0_f64); let pui_native_25:f64=0.0_f64; pui_native_24 / pui_native_25 }), Value::string(""))), ("nan", add(Value::number({ let pui_native_26:f64=0.0_f64; let pui_native_27:f64=0.0_f64; pui_native_26 / pui_native_27 }), Value::string("")))]);
            })) }) };
            // Source "scalars.proto.ts":25:9
            v_636f756e74.initialize(Rc::new(std::cell::RefCell::new(0.0_f64)));
            // Source "scalars.proto.ts":26:9
            v_7472616365.initialize(Rc::new(std::cell::RefCell::new(Value::string(""))));
            // Source "scalars.proto.ts":27:11
            v_73746570.initialize({  let v_636f756e74 = v_636f756e74.clone(); let call:Rc<dyn Fn(f64)->f64>=Rc::new(move |argument_0: f64| -> f64 {
                let v_76616c75655f5f33626433653837316165363035313633: f64 = argument_0;
                // Source "scalars.proto.ts":28:13
                let v_6265666f7265: f64 = { let cell=v_636f756e74.read(); let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; previous };
                // Source "scalars.proto.ts":29:7
                Value::number({ let value={ let pui_native_28:f64={ let value=(v_636f756e74.read()).borrow().clone(); value }; let pui_native_29:f64=v_76616c75655f5f33626433653837316165363035313633.clone(); pui_native_28 + pui_native_29 }; *(v_636f756e74.read()).borrow_mut()=value.clone(); value });
                // Source "scalars.proto.ts":30:7
                return { let pui_native_30:f64=v_6265666f7265.clone(); let pui_native_31:f64={ let value=(v_636f756e74.read()).borrow().clone(); value }; pui_native_30 + pui_native_31 };
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call((arg(&arguments,0)).num()))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } });
            // Source "scalars.proto.ts":32:11
            v_6964656e74697479.initialize(v_73746570.read());
            // Source "scalars.proto.ts":33:11
            v_626f786564.initialize(record(vec![("callback", (v_73746570.read()).ordinary.clone().expect("checked native data callable"))]));
            // Source "scalars.proto.ts":57:5
            { let v_7075695f6e61746976655f3332 = v_646566.clone(); expose_method(&owner, Value::string("typedCallable"), {  let v_636f756e74 = v_636f756e74.clone(); let v_73746570 = v_73746570.clone(); let v_6964656e74697479 = v_6964656e74697479.clone(); let v_626f786564 = v_626f786564.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "scalars.proto.ts":57:46
                return record(vec![("same", Value::boolean(({ let pui_native_35 = v_73746570.read(); let pui_native_36 = v_6964656e74697479.read(); Value::boolean(pui_native_35.equals_native(&pui_native_36)) }).bool())), ("boxed", Value::boolean(({ let pui_native_39 = v_73746570.read(); let pui_native_40 = (v_626f786564.read()).member("callback", false); Value::boolean(pui_native_39.equals_value(&pui_native_40)) }).bool())), ("distinct", Value::boolean(({ let pui_native_43 = v_73746570.read(); let pui_native_44 = { let call:Rc<dyn Fn(f64)->f64>=Rc::new(move |_argument_0: f64| -> f64 { panic!("compiler-proven uninvoked callable was invoked") }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call((arg(&arguments,0)).num()))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }; Value::boolean(!pui_native_43.equals_native(&pui_native_44)) }).bool())), ("first", Value::number((v_73746570.read().call)(2.0_f64))), ("second", Value::number(({ let callable = (v_626f786564.read()).member("callback", false); callable.call_authored(vec![Value::number(3.0_f64)]) }).num())), ("count", Value::number({ let value=(v_636f756e74.read()).borrow().clone(); value }))]);
            })) }) };
            // Source "scalars.proto.ts":65:5
            { let v_7075695f6e61746976655f3435 = v_646566.clone(); expose_method(&owner, Value::string("typedDefaults"), {  let v_66696e616c6c7956616c7565 = v_66696e616c6c7956616c7565.clone(); let v_6170706c79 = v_6170706c79.clone(); let v_6f7074696f6e616c = v_6f7074696f6e616c.clone(); let v_636f756e74 = v_636f756e74.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "scalars.proto.ts":65:46
                return record(vec![("missing", Value::number((v_6f7074696f6e616c.read().call)(Value::Undefined))), ("explicit", Value::number((v_6f7074696f6e616c.read().call)(Value::Undefined))), ("zero", Value::number((v_6f7074696f6e616c.read().call)(Value::number(0.0_f64)))), ("defaultCallback", Value::number((v_6170706c79.read().call)(4.0_f64, Value::Undefined))), ("explicitCallback", Value::number((v_6170706c79.read().call)(4.0_f64, ({   let call:Rc<dyn Fn(f64)->f64>=Rc::new(move |argument_0: f64| -> f64 {
                    let v_696e7075745f5f32303331313433333163663636626664: f64 = argument_0;
                    // Source "scalars.proto.ts":70:45
                    return { let pui_native_46:f64=v_696e7075745f5f32303331313433333163663636626664.clone(); let pui_native_47:f64=3.0_f64; pui_native_46 * pui_native_47 };
                }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call((arg(&arguments,0)).num()))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")))), ("explicitUndefined", Value::number((v_6170706c79.read().call)(4.0_f64, Value::Undefined))), ("success", Value::number((v_66696e616c6c7956616c7565.read().call)(4.0_f64))), ("failure", Value::number((v_66696e616c6c7956616c7565.read().call)(-(1.0_f64)))), ("count", Value::number({ let value=(v_636f756e74.read()).borrow().clone(); value }))]);
            })) }) };
            // Source "scalars.proto.ts":76:5
            { let v_7075695f6e61746976655f3438 = v_646566.clone(); expose_method(&owner, Value::string("numericLiterals"), {   Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "scalars.proto.ts":76:48
                return record(vec![("huge", Value::number(1e+30_f64)), ("negativeHuge", Value::number(-(1e+30_f64))), ("boundary", Value::number(1e+21_f64)), ("tiny", Value::number(5e-324_f64)), ("negativeTiny", Value::number(-(5e-324_f64))), ("negativeZero", Value::boolean({ let pui_native_49:f64={ let pui_native_51:f64=1.0_f64; let pui_native_52:f64=-(0.0_f64); pui_native_51 / pui_native_52 }; let pui_native_50:f64=0.0_f64; pui_native_49 < pui_native_50 })), ("nan", Value::boolean({ let pui_native_53={ let pui_native_55:f64=0.0_f64; let pui_native_56:f64=0.0_f64; pui_native_55 / pui_native_56 }; let pui_native_54={ let pui_native_57:f64=0.0_f64; let pui_native_58:f64=0.0_f64; pui_native_57 / pui_native_58 }; !(pui_native_53==pui_native_54) }))]);
            })) }) };
            // Source "scalars.proto.ts":85:5
            { let v_7075695f6e61746976655f3539 = v_646566.clone(); expose_method(&owner, Value::string("membership"), {   Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "scalars.proto.ts":85:43
                return record(vec![("present", Value::boolean(({ let pui_native_60=v_5f5f7075694d6f64756c6530.with(|value| value.clone()); let pui_native_61=Value::string("vega"); Value::boolean(pui_native_60.items().iter().any(|item| strict_equal(item,&pui_native_61))) }).bool())), ("absent", Value::boolean(({ let pui_native_62=v_5f5f7075694d6f64756c6530.with(|value| value.clone()); let pui_native_63=Value::string("other"); Value::boolean(pui_native_62.items().iter().any(|item| strict_equal(item,&pui_native_63))) }).bool())), ("noCoercion", Value::boolean(({ let pui_native_64=v_5f5f7075694d6f64756c6530.with(|value| value.clone()); let pui_native_65=record(vec![("value", Value::string("vega"))]); Value::boolean(pui_native_64.items().iter().any(|item| strict_equal(item,&pui_native_65))) }).bool())), ("empty", Value::string("")), ("number", (Value::number(1e+21_f64)).string_value()), ("boolean", (Value::boolean(false)).string_value()), ("nil", (Value::Json(Json::Null)).string_value()), ("missing", (Value::Undefined).string_value())]);
            })) }) };
            // Source "scalars.proto.ts":97:5
            { let v_7075695f6e61746976655f3636 = v_646566.clone(); expose_method(&owner, Value::string("assignment"), {  let v_6d61726b = v_6d61726b.clone(); let v_7472616365 = v_7472616365.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "scalars.proto.ts":98:7
                { let value = Value::string(""); *(v_7472616365.read()).borrow_mut() = value; }
                // Source "scalars.proto.ts":99:13
                let v_6e6573746564 = record(vec![("value", Value::number(3.0_f64))]);
                // Source "scalars.proto.ts":100:13
                let v_726573756c74 = { let pui_native_67=v_6e6573746564.clone(); let pui_native_68=Value::number((v_6d61726b.read().call)(Value::string("target;"), 1.0_f64, Value::Undefined)); let pui_native_69=Value::number((v_6d61726b.read().call)(Value::string("first;"), 2.0_f64, Value::Undefined)); let pui_native_70=Value::number((v_6d61726b.read().call)(Value::string("last;"), 4.0_f64, Value::Undefined)); record(vec![("nested",pui_native_67), ("value",pui_native_68), ("value",pui_native_69), ("last",pui_native_70)]) };
                // Source "scalars.proto.ts":105:7
                Value::number((set_member(v_6e6573746564.clone(), "value", Value::number(7.0_f64))).num());
                // Source "scalars.proto.ts":106:7
                return record(vec![("value", Value::number(((v_726573756c74.clone()).member("value", false)).num())), ("last", Value::number(((v_726573756c74.clone()).member("last", false)).num())), ("same", Value::boolean((Value::boolean(strict_equal(&((v_726573756c74.clone()).member("nested", false)), &(v_6e6573746564.clone())))).bool())), ("nested", Value::number((((v_726573756c74.clone()).member("nested", false)).member("value", false)).num())), ("trace", { let value = (v_7472616365.read()).borrow().clone(); value })]);
            })) }) };
            // Source "scalars.proto.ts":114:5
            { let v_7075695f6e61746976655f3733 = v_646566.clone(); expose_method(&owner, Value::string("assignmentFailure"), {  let v_6d61726b = v_6d61726b.clone(); let v_7472616365 = v_7472616365.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "scalars.proto.ts":115:7
                { let value = Value::string(""); *(v_7472616365.read()).borrow_mut() = value; }
                // Source "scalars.proto.ts":116:7
                match match catch_authored::<std::ops::ControlFlow<Value>>(|| {
                        // Source "scalars.proto.ts":117:9
                        { let pui_native_74=Value::number((v_6d61726b.read().call)(Value::string("before;"), 1.0_f64, Value::Undefined)); let pui_native_75=Value::number((v_6d61726b.read().call)(Value::string("failure;"), 2.0_f64, Value::boolean(true))); let pui_native_76=Value::number((v_6d61726b.read().call)(Value::string("after;"), 3.0_f64, Value::Undefined)); record(vec![("before",pui_native_74), ("failure",pui_native_75), ("after",pui_native_76)]) };
                        std::ops::ControlFlow::Continue(())
                    }) {
                        Ok(flow) => flow,
                        Err(v_6572726f72) => (|| -> std::ops::ControlFlow<Value> {
                            // Source "scalars.proto.ts":123:9
                            return std::ops::ControlFlow::Break(record(vec![("same", Value::boolean((Value::boolean(strict_equal(&(v_6572726f72.clone()), &(Value::boolean(false))))).bool())), ("trace", { let value = (v_7472616365.read()).borrow().clone(); value })]));
                        })()
                    } {
                    std::ops::ControlFlow::Break(value) => return value,
                    std::ops::ControlFlow::Continue(()) => {}
                }
                // Source "scalars.proto.ts":125:7
                return record(vec![("same", Value::boolean(false)), ("trace", { let value = (v_7472616365.read()).borrow().clone(); value })]);
            })) }) };
            // Source "scalars.proto.ts":127:5
            { let v_7075695f6e61746976655f3739 = v_646566.clone(); expose_method(&owner, Value::string("caughtUnits"), {   Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "scalars.proto.ts":128:7
                match match catch_authored::<std::ops::ControlFlow<Value>>(|| {
                        // Source "scalars.proto.ts":129:9
                        throw_value(Value::string("𐀀"));
                    }) {
                        Ok(flow) => flow,
                        Err(v_6572726f72) => (|| -> std::ops::ControlFlow<Value> {
                            // Source "scalars.proto.ts":132:15
                            let v_68696768 = (v_6572726f72.clone()).caught_member("0", false);
                            // Source "scalars.proto.ts":133:15
                            let v_6c6f77 = (v_6572726f72.clone()).caught_member("1", false);
                            // Source "scalars.proto.ts":134:15
                            let v_6c656e677468 = (v_68696768.clone()).caught_member("length", false);
                            // Source "scalars.proto.ts":135:9
                            if { let pui_native_80={ let pui_native_82=(Value::boolean(strict_equal(&(typeof_value(&(v_68696768.clone()))), &(Value::string("string"))))).bool(); if (pui_native_82) {(Value::boolean(strict_equal(&(typeof_value(&(v_6c6f77.clone()))), &(Value::string("string"))))).bool()} else {pui_native_82} }; if (pui_native_80) {(Value::boolean(strict_equal(&(typeof_value(&(v_6c656e677468.clone()))), &(Value::string("number"))))).bool()} else {pui_native_80} } {
                                // Source "scalars.proto.ts":136:11
                                return std::ops::ControlFlow::Break(record(vec![("order", Value::boolean(({ let relational_left = v_68696768.clone(); let relational_right = v_6c6f77.clone(); Value::boolean(relational_left.string_units().cmp(&relational_right.string_units()) < std::cmp::Ordering::Equal) }).bool())), ("before", Value::boolean(({ let relational_left = v_68696768.clone(); let relational_right = Value::string("a"); Value::boolean(relational_left.string_units().cmp(&relational_right.string_units()) < std::cmp::Ordering::Equal) }).bool())), ("length", Value::number((v_6c656e677468.clone()).num())), ("same", Value::boolean((Value::boolean(strict_equal(&(v_68696768.clone()), &((v_6572726f72.clone()).caught_member("0", false))))).bool())), ("converted", Value::boolean((Value::boolean(strict_equal(&((v_68696768.clone()).string_value()), &(v_68696768.clone())))).bool())), ("assembled", add((v_68696768.clone()).string_value(), v_6c6f77.clone())), ("unpaired", Value::boolean(({ let relational_left = add(v_68696768.clone(), Value::string("a")); let relational_right = Value::string(""); Value::boolean(relational_left.string_units().cmp(&relational_right.string_units()) < std::cmp::Ordering::Equal) }).bool())), ("finite", Value::boolean((((v_68696768.clone()).scalar_number())).is_finite())), ("errorMessage", Value::boolean((Value::boolean(strict_equal(&((record(vec![("name", Value::string("Error")), ("message", (v_68696768.clone()).error_message_value())])).caught_member("message", false)), &(v_68696768.clone())))).bool()))]));
                            }
                            // Source "scalars.proto.ts":147:9
                            return std::ops::ControlFlow::Break(record(vec![("order", Value::boolean(false)), ("before", Value::boolean(true)), ("length", Value::number(0.0_f64)), ("same", Value::boolean(false)), ("converted", Value::boolean(false)), ("assembled", Value::string("")), ("unpaired", Value::boolean(false)), ("finite", Value::boolean(true)), ("errorMessage", Value::boolean(false))]));
                        })()
                    } {
                    std::ops::ControlFlow::Break(value) => return value,
                    std::ops::ControlFlow::Continue(()) => {}
                }
                Value::Undefined
            })) }) };
            // Source "scalars.proto.ts":160:5
            return { let callable={ let pui_native_102={   let call:Rc<dyn Fn(Value)->native::gpui_native_owner::NativeSnapshot>=Rc::new(move |argument_0: Value| -> native::gpui_native_owner::NativeSnapshot {
                let v_72: Value = argument_0;
                // Source "scalars.proto.ts":160:19
                return { let v_7075695f6e61746976655f313033 = v_72.clone(); { let pui_native_104 = Value::string("div"); let _ = pui_native_104; let pui_native_105 = Value::Undefined; let pui_native_106 = { let pui_native_108 = Value::Array(Rc::new(vec![])); native::gpui_native_owner::NativeSnapshot::sequence(pui_native_108.items().into_iter().map(|pui_native_109| { let pui_native_110 = pui_native_109; { native::gpui_native_owner::NativeSnapshot::invalid(pui_native_110) } }).collect(), Some(pui_native_108)) };
      let pui_native_107 = if pui_native_105.nullish() { Vec::new() } else { let style = pui_native_105.member("style",false); if style.nullish(){Vec::new()}else{style_items(vec![style])} };
      let frame_children = pui_native_106.clone(); let text_children = pui_native_106.clone();
      native::gpui_native_owner::NativeSnapshot { identity:Rc::new(()),observation:None,valid:pui_native_106.valid,slot_count:pui_native_106.slot_count,passive_content:pui_native_106.passive_content,
        frame:Rc::new(move |owner,focus,parent_path,drive,slot,index| {
          let path=format!("{parent_path}-{}",*index);*index+=1;
          let tokens:Vec<String> = pui_native_107.iter().map(|(token,_)|token.clone()).collect();
          let(style,fixed,translation)=native_presentation(owner,&tokens);
          let mut element=gpui::div().id(gpui::ElementId::Name(path.to_owned().into())); *element.style()=style;
          let mut child_index=0;for child in (frame_children.frame)(owner,focus,&path,drive,slot,&mut child_index){element=element.child(child);}
          let element=translated_element(element.into_any_element(),translation,None); vec![if fixed{viewport_root(element)}else{element}]
        }),text:Rc::new(move|slot|(text_children.text)(slot)) }
    } };
            }); native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:None } }; Value::NativeFunction{identity:pui_native_102.identity.clone(),render:Rc::new(move |arguments:Vec<Value>| {(pui_native_102.call)(arg(&arguments,0))})} }; match callable {
      Value::NativeFunction{identity,render} => capture_renderer(Value::NativeFunction{identity,render:render.clone()},render),
      Value::Renderer(adapter) => Value::Renderer(adapter),
      Value::Function(callback) => capture_renderer(Value::Function(callback.clone()),Rc::new(move |arguments:Vec<Value>| { panic!("checked native renderer entry has no scalar callback alternative") })),
      _ => panic!("checked setup result must be a callable")
    } };
        })) }.call_authored(vec![definition_capability(&owner)]);
          Owner::finish(&owner_ref, renderer);
          // Establish the App's default-action snapshot before any authored
          // global key capture can replace focus during the same keystroke.
          register_sequential_focus_owner(&owner_ref, cx);
          let focus_subscriptions = if native_focus_observation_needed(&owner_ref) {
          let focus_owner = owner_ref.clone();
          let on_focus = cx.on_focus(&focus, window, move |view, window, cx| {
              native_host_callback(&focus_owner, "focus", || {
              let epoch = focus_owner.borrow().epoch;
              if !ready(&focus_owner) || focus_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&focus_owner, window);
              native_focus_fact(&focus_owner, view.focus.is_focused(window));
              if !ready(&focus_owner) || focus_owner.borrow().epoch != epoch { return; }
              dispatch(&focus_owner, "host:focus", false, event_fields("host:focus"));
              if ready(&focus_owner) && focus_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          let blur_owner = owner_ref.clone();
          let on_blur = cx.on_blur(&focus, window, move |view, window, cx| {
              native_host_callback(&blur_owner, "blur", || {
              let epoch = blur_owner.borrow().epoch;
              if !ready(&blur_owner) || blur_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&blur_owner, window);
              native_focus_fact(&blur_owner, view.focus.is_focused(window));
              if !ready(&blur_owner) || blur_owner.borrow().epoch != epoch { return; }
              text_blur(&blur_owner, window, cx);
              dispatch(&blur_owner, "host:blur", false, event_fields("host:blur"));
              if ready(&blur_owner) && blur_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          // A native slot descendant can start this root's keyboard press
          // while the root FocusHandle itself is not focused. Its departure
          // from the physical subtree is distinct from the root's own blur.
          let focus_out_owner = Rc::downgrade(&owner_ref);
          let on_focus_out = cx.on_focus_out(&focus, window, move |view, _, window, cx| {
              let Some(owner) = focus_out_owner.upgrade() else { return; };
              native_host_callback(&owner, "focus-out", || {
              let epoch = owner.borrow().epoch;
              if !ready(&owner) || owner.borrow().window_id != Some(window.window_handle().window_id()) || view.focus.contains_focused(window, cx) { return; }
              // This retires only an existing root press lease. Do not forge
              // host:blur or change the root's own Focus observation here.
              native_press_blur(&owner);
              if ready(&owner) && owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          vec![on_focus, on_blur, on_focus_out]
          } else { Vec::new() };
          let global_key_capture = subscribe_global_key_capture(&owner_ref, cx);
          let window_input = window_input_needed(&owner_ref).then(|| cx.focus_handle().tab_stop(false));
          let focus_lost = window_input.as_ref().map(|_| cx.on_focus_lost(window, |view, window, cx| { let owner=view.owner.clone(); native_host_callback(&owner, "focus-lost", || { if view.owner.borrow().window_id == Some(window.window_handle().window_id()) { if let Some(focus) = &view.window_input { restore_window_input(&view.owner, focus, window, cx); } } }); }));
          let mut view = Self { owner: owner_ref, focus, window_input, _focus_subscriptions: focus_subscriptions, _window_activation: None, _focus_lost: focus_lost, _global_key_capture: global_key_capture, _entry_readiness: None };
          view.bind_window_activation(window, cx);
          view
          })
      }
      #[cfg(feature="test-support")]
      pub fn native_resource_counts(&self) -> Json { let mut counts=native::gpui_native_owner::native_resource_counts(&self.owner); counts["nativeSubscriptions"] = Json::from(self._focus_subscriptions.len() + usize::from(self._window_activation.is_some()) + usize::from(self._focus_lost.is_some()) + usize::from(self._global_key_capture.is_some()) + usize::from(self._entry_readiness.is_some())); counts }
      pub fn handle(&self) -> CompiledComponentHandle { CompiledComponentHandle { owner: self.owner.clone() } }
      pub fn set_props(&mut self, raw: Json, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_props(&self.owner, raw));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; self.drive(window, cx)
      }
      pub fn set_instance_associations(&mut self, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_instance_associations(&self.owner, associations));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; drive_owners(window, cx); self.drive(window, cx)
      }
      pub fn set_slot(&mut self, slot: Vec<native::gpui_native_owner::NativeSnapshot>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { ensure(&Rc::downgrade(&self.owner)); assert_native_slot_children(&slot); let mut owner = self.owner.borrow_mut(); owner.slot = slot; owner.dirty = true; cx.notify(); }) }
      pub fn set_parent(&mut self, parent: Option<OwnerWeak>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { if let Err(error)=set_native_parent(&self.owner, parent.unwrap_or_default()){throw_error("NATIVE_PARENT_INVALID", error)} cx.notify(); }) }
      fn bind_window_activation(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !native_focus_observation_needed(&self.owner) && !native::gpui_native_move::move_owner_has_binding(&self.owner) && !control_label_is_label(&self.owner) { self._window_activation.take(); return; }
          let id = window.window_handle().window_id();
          if self._window_activation.as_ref().is_some_and(|(bound, _)| *bound == id) { return; }
          self._window_activation.take();
          let owner = self.owner.clone();
          let subscription = cx.observe_window_activation(window, move |view, window, cx| {
              let deactivated = owner.borrow().window_id == Some(window.window_handle().window_id()) && !window.is_window_active();
              native_host_callback(&owner, "window-activation", || {
                  if deactivated {
                      native_window_blur(&owner);
                      view.drive(window, cx).unwrap_or_else(|error| throw_value(error));
                  }
              });
              if deactivated { notify_native_change(cx); }
          });
          self._window_activation = Some((id, subscription));
      }
      #[cfg(feature = "experimental-focus-tree")]
      fn bind_entry_readiness(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !self.owner.borrow().modules.hooks.contains("focus-entry") { return; }
          let window_id = window.window_handle().window_id();
          if self._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window_id) { return; }
          self._entry_readiness.take();
          let view = cx.entity().downgrade();
          let subscription = window.observe_focus_tree(cx, move |_, window, cx| {
              let _ = view.update(cx, |view, cx| {
                  if view._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window.window_handle().window_id()) { if let Err(error)=view.drive(window, cx){report_native_failure(&view.owner,"entry-readiness",error)} }
              });
          });
          self._entry_readiness = Some((window_id, subscription));
      }
      fn notify_after_turn(&self, cx: &mut Context<Self>) {
          // GPUI suppresses Entity observer effects while a window is drawing,
          // including its focus/blur phase. Keep authored state synchronous,
          // then publish the host change after that physical draw lease ends.
          // A weak target cannot keep a detached component alive for delivery.
          notify_native_change(cx);
      }
      pub fn drive(&mut self, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let result = catch_authored(|| {
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          modules_drive(&self.owner, &self.focus, window, cx);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          drive_queued_focus(&self.owner, window, cx);
          });
          // A callback can publish before failing or retiring its owner. That
          // output is independent from repaint dirtiness and an unread queue.
          let dirty = std::mem::take(&mut self.owner.borrow_mut().dirty);
          if !notify_native_events(&self.owner, cx) && dirty { self.notify_after_turn(cx); }
          result
      }
  }
  impl Drop for CompiledComponent { fn drop(&mut self) { native_host_callback(&self.owner, "drop", || Owner::dispose(&self.owner)); } }
  impl gpui::Focusable for CompiledComponent { fn focus_handle(&self, _: &App) -> FocusHandle { self.focus.clone() } }
  impl Render for CompiledComponent {
      fn render(&mut self, window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
          let report_owner = self.owner.clone();
          native_host_callback(&report_owner, "render", || {
          refresh_native_atoms(&self.owner, window, cx);
          Owner::project(&self.owner);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); return gpui::div().into_any_element(); }
          if !self.owner.borrow().present { self._window_activation.take(); detach_native_view(&self.owner); return gpui::div().into_any_element(); }
          bind_native_focus_window(&self.owner, window);
          self.bind_window_activation(window, cx);
          #[cfg(feature = "experimental-focus-tree")] self.bind_entry_readiness(window, cx);
          let drive = self.owner.borrow().native_drive.as_ref().expect("live native owner drive").clone();
          // Drawing consumes only repaint dirtiness. A parent Render can call
          // an exposed method before this child is laid out: its independent
          // pending_native_events flag survives until the coalesced drive wakes
          // the consumer. Repeated slot projection cannot create a notify loop.
          self.owner.borrow_mut().dirty = false;
          let snapshot = self.owner.borrow().projection.clone().expect("live native projection");
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          let element = paint_native_root(&snapshot, &self.owner, &self.focus, format!("compiled-root-{}", Rc::as_ptr(&self.owner) as usize), drive);
          if let Some(focus) = &self.window_input { window_input_scope(element, focus, &self.owner) } else { element }
          }).unwrap_or_else(|| gpui::div().into_any_element())
      }
  }
  