pub use crate::native::gpui_native_owner::TABLE_STRUCTURE_FAMILY as DECLARATION;
