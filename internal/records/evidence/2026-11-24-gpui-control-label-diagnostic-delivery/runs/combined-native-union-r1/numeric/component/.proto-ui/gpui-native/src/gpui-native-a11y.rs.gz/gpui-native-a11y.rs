use gpui::{App, Bounds, Element, ElementId, GlobalElementId, InspectorElementId, LayoutId, Pixels, Window};
use crate::gpui_native_owner::{OwnerWeak,Value,text_content,resolved,detach_native_view,control_label_commit,ControlLabelNativeView,control_label_retain_native_view,control_label_release_native_view,control_label_manages_native_view};
use std::hash::{Hash,Hasher};
#[cfg(not(feature = "gpui-modern-element-api"))]
fn node_id(id: &GlobalElementId) -> gpui::accesskit::NodeId {
    let mut hasher = std::hash::DefaultHasher::default();
    id.hash(&mut hasher);
    gpui::accesskit::NodeId(hasher.finish())
}

#[cfg(feature = "gpui-modern-element-api")]
fn node_id(id: &GlobalElementId) -> gpui::accesskit::NodeId {
    // GPUI's GlobalElementId writes its cached path hash as one u64 and
    // uses that same hash for the AccessKit node ID.
    #[derive(Default)]
    struct PathHash(Option<u64>);
    impl Hasher for PathHash {
        fn write(&mut self, _: &[u8]) {
            panic!("GPUI GlobalElementId no longer hashes as one u64");
        }
        fn write_u64(&mut self, value: u64) {
            assert!(self.0.replace(value).is_none(), "GPUI GlobalElementId wrote multiple hashes");
        }
        fn finish(&self) -> u64 {
            self.0.expect("GPUI GlobalElementId did not write a hash")
        }
    }
    let mut hasher = PathHash::default();
    id.hash(&mut hasher);
    gpui::accesskit::NodeId(hasher.finish())
}

struct LayoutFrame{serial:u64,names:std::collections::HashMap<String,Option<OwnerWeak>>}
thread_local!{
static A11Y_LAYOUT_FRAMES:std::cell::RefCell<std::collections::HashMap<gpui::WindowId,LayoutFrame>>=std::cell::RefCell::new(std::collections::HashMap::new());
static A11Y_NEXT_FRAME:std::cell::Cell<u64>=const{std::cell::Cell::new(0)};
}
// SDK semantics precede prepaint and mounted. Only this draw's layout bindings
// are targets; a still-mounted owner from the previous draw is not evidence.
fn layout_frame(window:&mut Window,cx:&mut App)->u64{
let window_id=window.window_handle().window_id();let(frame,started)=A11Y_LAYOUT_FRAMES.with(|frames|{let mut frames=frames.borrow_mut();if let Some(frame)=frames.get(&window_id){(frame.serial,false)}else{let frame=A11Y_NEXT_FRAME.with(|next|{let frame=next.get().checked_add(1).expect("native accessibility frame overflow");next.set(frame);frame});frames.insert(window_id,LayoutFrame{serial:frame,names:std::collections::HashMap::new()});(frame,true)}});
if started{window.defer(cx,move|_,_|A11Y_LAYOUT_FRAMES.with(|frames|{let mut frames=frames.borrow_mut();if frames.get(&window_id).is_some_and(|current|current.serial==frame){frames.remove(&window_id);}}));}frame
}
fn object_node(target:&OwnerWeak,frame:u64)->Option<gpui::accesskit::NodeId>{let target=target.upgrade()?;let target=target.borrow();if target.disposed||!target.present||target.modules.a11y_frame!=frame||target.modules.a11y_bindings!=1{return None}target.modules.a11y_node}
fn named_node(window:Option<gpui::WindowId>,frame:u64,name:&str)->Option<gpui::accesskit::NodeId>{let window=window?;let target=A11Y_LAYOUT_FRAMES.with(|frames|{let frames=frames.borrow();let current=frames.get(&window)?;if current.serial!=frame{return None}current.names.get(name)?.clone()})?;object_node(&target,frame)}
fn relation_nodes(target:&Value,frame:u64,window:Option<gpui::WindowId>)->Option<Vec<gpui::accesskit::NodeId>>{
let mut ids=Vec::new();match target{
Value::ObjectRef(target)=>ids.push(object_node(target,frame)?),
Value::Array(targets)=>{for target in targets.iter(){let Value::ObjectRef(target)=target else{return None};let id=object_node(target,frame)?;if !ids.contains(&id){ids.push(id);}}},
Value::Json(serde_json::Value::String(names))=>{for name in names.split_whitespace(){if let Some(id)=named_node(window,frame,name){if !ids.contains(&id){ids.push(id);}}}},
Value::Undefined|Value::Json(serde_json::Value::Null)=>{},_=>return None,
}if ids.is_empty(){None}else{Some(ids)}
}
fn project_relation(node:&mut gpui::accesskit::Node,key:&str,spec:&Value,frame:u64,window:Option<gpui::WindowId>){
if !matches!(key,"controls"|"describedBy"|"labelledBy"|"owns"|"flowTo"|"details"|"activeDescendant"|"errorMessage"){return}
let target=resolved(&spec.member("target",false));let Some(ids)=relation_nodes(&target,frame,window)else{return};let append=matches!(spec.member("mode",true),Value::Json(serde_json::Value::String(mode))if mode=="append");match key{
"controls"=>{if append{for id in ids{if !node.controls().contains(&id){node.push_controlled(id)}}}else{node.set_controls(ids)}},
"describedBy"=>{if append{for id in ids{if !node.described_by().contains(&id){node.push_described_by(id)}}}else{node.set_described_by(ids)}},
"labelledBy"=>{if append{for id in ids{if !node.labelled_by().contains(&id){node.push_labelled_by(id)}}}else{node.set_labelled_by(ids)}},
"owns"=>{if append{for id in ids{if !node.owns().contains(&id){node.push_owned(id)}}}else{node.set_owns(ids)}},
"flowTo"=>{if append{for id in ids{if !node.flow_to().contains(&id){node.push_flow_to(id)}}}else{node.set_flow_to(ids)}},
"details"=>{if append{for id in ids{if !node.details().contains(&id){node.push_detail(id)}}}else{node.set_details(ids)}},
"activeDescendant"=>node.set_active_descendant(ids[0]),"errorMessage"=>node.set_error_message(ids[0]),
// Unmapped relationships remain semantic IR rather than invented host fields.
_=>{},
}}
fn positive_integer(value:&Value)->Option<usize>{let number=match value{Value::Number(number)=>*number,Value::Json(serde_json::Value::Number(number))=>number.as_f64()?,_=>return None};if number>=1.&&number<=9007199254740991.&&number.fract()==0.{Some(number as usize)}else{None}}
fn finite_number(value:&Value)->Option<f64>{let number=match value{Value::Number(number)=>*number,Value::Json(serde_json::Value::Number(number))=>number.as_f64()?,_=>return None};number.is_finite().then_some(number)}
fn token_is(value:&Value,token:&str)->bool{matches!(value,Value::Json(serde_json::Value::String(value))if value.eq_ignore_ascii_case(token))}
fn aria_boolean(value:&Value)->Option<bool>{match value{Value::Json(serde_json::Value::Bool(value))=>Some(*value),_ if token_is(value,"true")=>Some(true),_ if token_is(value,"false")=>Some(false),_=>None}}
struct NativeViewLease{owner:OwnerWeak,window:gpui::WindowId,hitbox:gpui::HitboxId,control_label_managed:bool,control_label:Option<std::rc::Rc<ControlLabelNativeView>>}
impl Drop for NativeViewLease{fn drop(&mut self){
if let Some(view)=self.control_label.take(){control_label_release_native_view(&view);return;}
// A managed state remains managed even if admission later withdraws its receipt.
// Its late Drop must not fall back to a recycled window/hitbox identity.
if self.control_label_managed{return;}
if let Some(owner)=self.owner.upgrade(){let live={let owner=owner.borrow();owner.window_id==Some(self.window)&&owner.native_hitbox.as_ref().is_some_and(|hitbox|hitbox.id==self.hitbox)};if live{detach_native_view(&owner);}}
}}
pub struct Semantics<E:Element>{pub element:E,pub owner:OwnerWeak,pub role:Option<gpui::Role>}
#[cfg(not(feature = "gpui-modern-element-api"))]
impl<E:Element> gpui::IntoElement for Semantics<E>{type Element=Self;fn into_element(self)->Self{self}}
impl<E:Element> Element for Semantics<E>{
type RequestLayoutState=E::RequestLayoutState;
type PrepaintState=E::PrepaintState;
fn id(&self)->Option<ElementId>{self.element.id()}
fn source_location(&self)->Option<&'static std::panic::Location<'static>>{self.element.source_location()}
fn request_layout(&mut self,id:Option<&GlobalElementId>,inspector:Option<&InspectorElementId>,window:&mut Window,cx:&mut App)->(LayoutId,Self::RequestLayoutState){
if let Some(owner)=self.owner.upgrade(){let window_id=window.window_handle().window_id();owner.borrow_mut().window_id=Some(window_id);if self.a11y_role().is_some(){if let Some(id)=id{let frame=layout_frame(window,cx);{let mut owner=owner.borrow_mut();if owner.modules.a11y_frame!=frame{owner.modules.a11y_frame=frame;owner.modules.a11y_bindings=0;}owner.modules.a11y_bindings+=1;owner.modules.a11y_node=Some(node_id(id));}let name=owner.borrow().modules.accessible_text.get("id").map(resolved);if let Some(Value::Json(serde_json::Value::String(name)))=name{if !name.is_empty(){A11Y_LAYOUT_FRAMES.with(|frames|{let mut frames=frames.borrow_mut();let names=&mut frames.get_mut(&window_id).expect("current native layout frame").names;match names.entry(name){std::collections::hash_map::Entry::Vacant(entry)=>{entry.insert(Some(self.owner.clone()));},std::collections::hash_map::Entry::Occupied(mut entry)=>{entry.insert(None);}}});}}}}}self.element.request_layout(id,inspector,window,cx)
}
fn prepaint(&mut self,id:Option<&GlobalElementId>,inspector:Option<&InspectorElementId>,bounds:Bounds<Pixels>,layout:&mut Self::RequestLayoutState,window:&mut Window,cx:&mut App)->Self::PrepaintState{
if let Some(owner)=self.owner.upgrade(){let hitbox=window.insert_hitbox(bounds,gpui::HitboxBehavior::Normal);let hitbox_id=hitbox.id;let window_id=window.window_handle().window_id();{let mut owner=owner.borrow_mut();owner.bounds=Some(bounds);owner.native_hitbox=Some(hitbox.clone());}
// GPUI retains accessed element state through cached frames and drops it when
// the actual native subtree disappears. No frame polling or owner disposal.
if let Some(id)=id{let a11y_node=self.a11y_role().map(|_|node_id(id));window.with_element_state(id,|state:Option<NativeViewLease>,window|{
let mut state=state.filter(|state|std::rc::Weak::ptr_eq(&state.owner,&self.owner)).unwrap_or_else(||NativeViewLease{owner:self.owner.clone(),window:window_id,hitbox:hitbox_id,control_label_managed:false,control_label:None});
state.window=window_id;state.hitbox=hitbox_id;
state.control_label_managed|=state.control_label.is_some()||control_label_manages_native_view(&owner);
state.control_label=control_label_retain_native_view(&owner,state.control_label.take(),a11y_node,hitbox.clone(),bounds,window,cx);
((),state)});}
// A cached authored projection can acquire a different physical binding without
// another Owner::commit. Cached native views may enter layout during prepaint;
// observe each binding here and defer associated redraws until after this draw.
control_label_commit(&owner);}
self.element.prepaint(id,inspector,bounds,layout,window,cx)
}
fn paint(&mut self,id:Option<&GlobalElementId>,inspector:Option<&InspectorElementId>,bounds:Bounds<Pixels>,layout:&mut Self::RequestLayoutState,prepaint:&mut Self::PrepaintState,window:&mut Window,cx:&mut App){self.element.paint(id,inspector,bounds,layout,prepaint,window,cx)}
fn a11y_role(&self)->Option<gpui::Role>{let owner=self.owner.upgrade()?;if crate::gpui_native_owner::control_label_is_label(&owner){return Some(gpui::Role::Label)}if !owner.borrow().accessible{return self.element.a11y_role()}self.role.or_else(||self.element.a11y_role()).or(Some(gpui::Role::GenericContainer))}
fn a11y_synthetic_children(&mut self,prepaint:&mut Self::PrepaintState,builder:&mut gpui::A11ySubtreeBuilder){self.element.a11y_synthetic_children(prepaint,builder);let Some(owner)=self.owner.upgrade()else{return};let merge=resolved(&owner.borrow().modules.accessible_tree.member("mergeChildren",true));if !merge.nullish()&&merge.bool(){builder.parent_node().clear_children();builder.parent_node().set_label(text_content(&owner.borrow().projection,&owner.borrow().slot));}}
fn write_a11y_info(&self,node:&mut gpui::accesskit::Node){
self.element.write_a11y_info(node);
let Some(owner_ref)=self.owner.upgrade()else{return};
crate::gpui_native_owner::text_accessible(&owner_ref,node);
crate::gpui_native_owner::image_accessible(&owner_ref,node);
let native_disabled=node.is_disabled();
let label=crate::gpui_native_owner::control_label_is_label(&owner_ref);
let derived_name=crate::gpui_native_owner::control_label_name(&owner_ref);
if label{if crate::gpui_native_owner::control_label_action_available(&owner_ref){node.add_action(gpui::accesskit::Action::Click);}else{node.remove_action(gpui::accesskit::Action::Click);}}
let owner=owner_ref.borrow();
for(key,spec)in &owner.modules.accessible_relations{project_relation(node,key,spec,owner.modules.a11y_frame,owner.window_id);}
if let Some(label_node)=derived_name{node.clear_label();node.set_labelled_by(vec![label_node]);}
else if owner.name_content{node.set_label(text_content(&owner.projection,&owner.slot));}
if label{let text=text_content(&owner.projection,&owner.slot);if !text.is_empty(){node.set_label(text);}}
for(key,value)in &owner.modules.accessible_text{let value=resolved(value);if value.nullish(){continue}match key.as_str(){"name"=>{if derived_name.is_none()||!value.text().is_empty(){node.set_label(value.text());}},"description"=>node.set_description(value.text()),"id"=>{},_=>panic!("unmapped accessible text field")}}
if matches!(resolved(&owner.accessible_role),Value::Json(serde_json::Value::String(role))if role=="heading"){if let Some(level)=crate::gpui_native_owner::accessible_level_value(&owner.modules.accessible_level){node.set_level(level);}}
for(key,state)in &owner.accessible_states{let value=state.get();if owner.accessible_state_conditions.get(key).is_some_and(|condition|!matches!(condition.get(),Value::Json(serde_json::Value::Bool(true)))){continue}if value.nullish()||token_is(&value,""){continue}match key.as_str(){
"valueNow"=>{if let Some(value)=finite_number(&value){node.set_numeric_value(value)}},
"valueMin"=>{if let Some(value)=finite_number(&value){node.set_min_numeric_value(value)}},
"valueMax"=>{if let Some(value)=finite_number(&value){node.set_max_numeric_value(value)}},
"valueText"=>{if let Value::Json(serde_json::Value::String(value))=value{node.set_value(value)}},
"selected"=>{if let Some(value)=aria_boolean(&value){node.set_selected(value)}},"expanded"=>{if let Some(value)=aria_boolean(&value){node.set_expanded(value)}},
"checked"|"pressed"=>{if let Some(value)=aria_boolean(&value){node.set_toggled(if value{gpui::Toggled::True}else{gpui::Toggled::False});}else if token_is(&value,"mixed"){node.set_toggled(gpui::Toggled::Mixed);}},
"disabled"=>{if let Some(value)=aria_boolean(&value){if value{node.set_disabled()}else if !native_disabled{node.clear_disabled()}}},
"hidden"=>{if let Some(value)=aria_boolean(&value){if value{node.set_hidden()}else{node.clear_hidden()}}},
"busy"=>{if let Some(value)=aria_boolean(&value){if value{node.set_busy()}else{node.clear_busy()}}},
"atomic"=>{if let Some(value)=aria_boolean(&value){if value{node.set_live_atomic()}else{node.clear_live_atomic()}}},
"modal"=>{if let Some(value)=aria_boolean(&value){if value{node.set_modal()}else{node.clear_modal()}}},
"readOnly"=>{if let Some(value)=aria_boolean(&value){if value{node.set_read_only()}else{node.clear_read_only()}}},
"orientation"=>{if token_is(&value,"vertical"){node.set_orientation(gpui::Orientation::Vertical)}else if token_is(&value,"horizontal"){node.set_orientation(gpui::Orientation::Horizontal)}},
"rowCount"=>{if let Some(value)=positive_integer(&value){node.set_row_count(value)}},"columnCount"=>{if let Some(value)=positive_integer(&value){node.set_column_count(value)}},"rowIndex"=>{if let Some(value)=positive_integer(&value){node.set_row_index(value-1)}},"columnIndex"=>{if let Some(value)=positive_integer(&value){node.set_column_index(value-1)}},"rowSpan"=>{if let Some(value)=positive_integer(&value){node.set_row_span(value)}},"columnSpan"=>{if let Some(value)=positive_integer(&value){node.set_column_span(value)}},
"invalid"=>{if aria_boolean(&value)==Some(false){node.clear_invalid()}else{node.set_invalid(if token_is(&value,"grammar"){gpui::accesskit::Invalid::Grammar}else if token_is(&value,"spelling"){gpui::accesskit::Invalid::Spelling}else{gpui::accesskit::Invalid::True})}},
"live"=>{if token_is(&value,"off"){node.set_live(gpui::accesskit::Live::Off)}else if token_is(&value,"polite"){node.set_live(gpui::accesskit::Live::Polite)}else if token_is(&value,"assertive"){node.set_live(gpui::accesskit::Live::Assertive)}},
"hasPopup"=>{if aria_boolean(&value)==Some(false){node.clear_has_popup()}else if aria_boolean(&value)==Some(true)||token_is(&value,"menu"){node.set_has_popup(gpui::accesskit::HasPopup::Menu)}else if token_is(&value,"listbox"){node.set_has_popup(gpui::accesskit::HasPopup::Listbox)}else if token_is(&value,"tree"){node.set_has_popup(gpui::accesskit::HasPopup::Tree)}else if token_is(&value,"grid"){node.set_has_popup(gpui::accesskit::HasPopup::Grid)}else if token_is(&value,"dialog"){node.set_has_popup(gpui::accesskit::HasPopup::Dialog)}},
// State keys are open-ended semantic facts. Unmapped keys remain in the
// owner's IR without inventing an AccessKit property (C-A11Y-0001-G).
_=>{},
}}
let hidden=resolved(&owner.modules.accessible_tree.member("hidden",true));if !hidden.nullish(){if hidden.bool(){node.set_hidden()}else{node.clear_hidden()}}
}
}

#[cfg(all(test,feature="test-support"))]
mod conditional_state_tests {
    use super::*;
    use crate::gpui_native_owner::{Owner,OwnerRef,create_state,accessible_state,action_from_name,record};
    use std::rc::Rc;
    fn owner()->OwnerRef {Owner::new(serde_json::json!({}),Default::default(),|_,_|true,|_|true,|_,_|true,crate::gpui_native_style::vocabulary())}
    fn flag(owner:&OwnerRef,name:&str,value:bool)->Value {
        create_state(&Rc::downgrade(owner),"bool",Value::string(name),Value::boolean(value),Value::Undefined)
    }
    fn change(state:&Value,value:Value) {let Value::State(state)=state else{panic!("expected state")};*state.value.borrow_mut()=value;}
    fn project(owner:&OwnerRef)->gpui::accesskit::Node {
        let semantics=Semantics{element:gpui::div(),owner:Rc::downgrade(owner),role:Some(gpui::Role::Button)};
        let mut node=gpui::accesskit::Node::new(gpui::Role::Button);semantics.write_a11y_info(&mut node);node
    }
    #[test]
    fn portable_activation_projects_the_native_click_action() {
        assert_eq!(action_from_name("activate"),gpui::AccessibleAction::Click);
        assert_eq!(action_from_name("press"),gpui::AccessibleAction::Click);
        assert_eq!(action_from_name("click"),gpui::AccessibleAction::Click);
    }

    #[test]
    fn native_condition_omits_and_reactivates_current_state() {
        let owner=owner();let value=flag(&owner,"value",false);let when=flag(&owner,"when",false);
        accessible_state(&Rc::downgrade(&owner),Value::string("pressed"),value.clone(),record(vec![("when",when.clone())]));
        owner.borrow_mut().phase="callback";
        assert_eq!(project(&owner).toggled(),None);
        change(&value,Value::boolean(true));assert_eq!(project(&owner).toggled(),None);
        change(&when,Value::boolean(true));assert_eq!(project(&owner).toggled(),Some(gpui::Toggled::True));
        change(&value,Value::boolean(false));assert_eq!(project(&owner).toggled(),Some(gpui::Toggled::False));
        change(&when,Value::boolean(false));assert_eq!(project(&owner).toggled(),None);
        change(&when,Value::Undefined);assert_eq!(project(&owner).toggled(),None);
        Owner::dispose(&owner);
    }
    #[test]
    fn last_native_state_registration_replaces_its_condition() {
        let owner=owner();let old=flag(&owner,"old",true);let current=flag(&owner,"current",false);let when=flag(&owner,"when",false);
        accessible_state(&Rc::downgrade(&owner),Value::string("pressed"),old,record(vec![("when",when)]));
        accessible_state(&Rc::downgrade(&owner),Value::string("pressed"),current,Value::Undefined);
        owner.borrow_mut().phase="callback";
        assert_eq!(project(&owner).toggled(),Some(gpui::Toggled::False));
        assert!(!owner.borrow().accessible_state_conditions.contains_key("pressed"));Owner::dispose(&owner);
    }
    #[test]
    fn condition_validity_is_checked_initially_and_at_final_setup() {
        use crate::gpui_native_owner::{catch_authored,accessible_alive};
        let owner=owner();let value=flag(&owner,"value",false);
        for invalid in [Value::Json(serde_json::Value::Null),Value::boolean(true),Value::number(1.)] {
            assert!(catch_authored(||accessible_state(&Rc::downgrade(&owner),Value::string("pressed"),value.clone(),record(vec![("when",invalid)]))).is_err());
            assert!(!owner.borrow().accessible_states.contains_key("pressed"));
        }
        let when=flag(&owner,"when",true);
        accessible_state(&Rc::downgrade(&owner),Value::string("pressed"),value,record(vec![("when",when.clone())]));
        change(&when,Value::Undefined);
        assert!(catch_authored(||accessible_alive(&owner)).is_err());
        Owner::dispose(&owner);
    }
    #[test]
    fn inactive_condition_cannot_hide_value_read_failure_or_replace_host_fact() {
        use crate::gpui_native_owner::catch_authored;
        let owner=owner();let value=flag(&owner,"value",true);let when=flag(&owner,"when",false);
        accessible_state(&Rc::downgrade(&owner),Value::string("pressed"),value.clone(),record(vec![("when",when)]));
        let semantics=Semantics{element:gpui::div(),owner:Rc::downgrade(&owner),role:Some(gpui::Role::Button)};
        let mut node=gpui::accesskit::Node::new(gpui::Role::Button);node.set_toggled(gpui::Toggled::True);
        semantics.write_a11y_info(&mut node);assert_eq!(node.toggled(),Some(gpui::Toggled::True));
        // The false condition must not turn an invalid bound State read into omission.
        let broken=Owner::new(serde_json::json!({}),Default::default(),|_,_|true,|_|true,|_,_|true,crate::gpui_native_style::vocabulary());let broken_value=flag(&broken,"broken",false);Owner::dispose(&broken);
        owner.borrow_mut().accessible_states.insert("pressed".into(),broken_value);
        assert!(catch_authored(||project(&owner)).is_err());Owner::dispose(&owner);
    }
}

#[cfg(all(test,feature="test-support"))]
mod native_view_scope_tests {
    use super::*;
    use crate::gpui_native_owner::{Owner,ready};
    use gpui::{AppContext,Render,Context,TestAppContext,IntoElement};
    use std::rc::Rc;
    struct Empty;
    impl Render for Empty {fn render(&mut self,_:&mut Window,_:&mut Context<Self>)->impl IntoElement{gpui::div()}}
    #[gpui::test]
    fn an_old_window_hitbox_cannot_retire_a_successor_with_the_same_id(cx:&mut TestAppContext){
        let first=cx.update(|cx|cx.open_window(Default::default(),|_,cx|cx.new(|_|Empty)).unwrap());
        let second=cx.update(|cx|cx.open_window(Default::default(),|_,cx|cx.new(|_|Empty)).unwrap());
        let first_id=first.update(cx,|_,window,_|window.window_handle().window_id()).unwrap();
        second.update(cx,|_,window,_|{
            let second_id=window.window_handle().window_id();assert_ne!(first_id,second_id);
            let owner=Owner::new(serde_json::json!({}),Default::default(),|_,_|true,|_|true,|_,_|true,crate::gpui_native_style::vocabulary());
            // GPUI starts each window's HitboxId counter at zero. This exact
            // collision is valid across windows and must not identify a lease.
            let id=gpui::HitboxId::placeholder();
            {let mut o=owner.borrow_mut();o.phase="idle";o.mounted=true;o.window_id=Some(second_id);o.bounds=Some(Bounds::default());o.native_hitbox=Some(gpui::Hitbox{id,bounds:Bounds::default(),content_mask:gpui::ContentMask::default(),behavior:gpui::HitboxBehavior::Normal});}
            drop(NativeViewLease{owner:Rc::downgrade(&owner),window:first_id,hitbox:id,control_label_managed:false,control_label:None});assert!(ready(&owner));
            // A previously managed state may have withdrawn its receipt while
            // absent, then be dropped after a newer native epoch reused this id.
            drop(NativeViewLease{owner:Rc::downgrade(&owner),window:second_id,hitbox:id,control_label_managed:true,control_label:None});
            assert!(ready(&owner), "a withdrawn managed state cannot fall back to legacy hitbox identity");
            drop(NativeViewLease{owner:Rc::downgrade(&owner),window:second_id,hitbox:id,control_label_managed:false,control_label:None});assert!(!ready(&owner));Owner::dispose(&owner);
        }).unwrap();
    }
}
