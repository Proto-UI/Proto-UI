// Direct checked-source GPUI component. Supporting files are ordinary editable Rust.
  
  pub use proto_ui_gpui_native as native;
  pub use native::gpui_native_owner::{ControlLabelRef, InstanceAssociations};
  use gpui::{prelude::*, App, Context, FocusHandle, Subscription, Window};
  use std::rc::Rc;
  use serde_json::Value as Json;
  use native::gpui_native_owner::*;
  
  
  fn style_vocabulary() -> &'static native::gpui_native_style::StyleVocabulary {
      static VOCABULARY: std::sync::OnceLock<native::gpui_native_style::StyleVocabulary> = std::sync::OnceLock::new();
      VOCABULARY.get_or_init(|| native::gpui_native_style::StyleVocabulary::from_json(include_str!(".proto-ui/fixtures/style-tokens.json")).expect("compiler-produced style vocabulary"))
  }
  fn accepts_context(key: &str, value: &Json) -> bool {
      match key {
          
          _ => false,
      }
  }
  fn accepts_props(value: &Json) -> bool { value.is_object() && value.get("disabled").map_or(true, |prop| prop.is_null() || prop.is_boolean()) }
  fn prop_valid(key: &str, value: &Json) -> bool { match key { "disabled" => value.is_boolean(), _ => false } }
  fn check_method(name: &str, arguments: &[Value]) { match name {
          "focusSelf" => if !(arguments.len() <= 1 && arguments.get(0).map_or(true, |value| matches!(value, Value::Undefined) || (value).try_data().is_some_and(|data| (data.is_object() && data.get("reason").map_or(true, |field| (field.as_str() == Some("programmatic") || field.as_str() == Some("keyboard") || field.as_str() == Some("pointer"))) && data.get("preventScroll").map_or(true, |field| field.is_boolean()))))) { value_type_error("invalid exposed method arguments") },
          _ => value_error("unknown exposed method"),
  } }
  
  #[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData0 {
    #[serde(rename = "disabled", default, skip_serializing_if = "Option::is_none")]
    pub field_0: Option<bool>,
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
#[serde(untagged)]
pub enum GeneratedData2 {
    Alternative0(String),
    Alternative1(String),
    Alternative2(String),
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData1 {
    #[serde(rename = "reason", default, skip_serializing_if = "Option::is_none")]
    pub field_0: Option<GeneratedData2>,
    #[serde(rename = "preventScroll", default, skip_serializing_if = "Option::is_none")]
    pub field_1: Option<bool>,
}
  
  pub type GeneratedProps = GeneratedData0;
  
  #[derive(Clone)]
  pub struct CompiledComponentHandle { pub owner: OwnerRef }
  impl CompiledComponentHandle {
      pub fn state_0(&self) -> Result<bool, Value> { self.state("disabled").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_1(&self) -> Result<bool, Value> { self.state("hovered").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_2(&self) -> Result<bool, Value> { self.state("focused").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_3(&self) -> Result<bool, Value> { self.state("focusVisible").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn method_4(&self, argument_0: Option<GeneratedData1>, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![argument_0.map(|value| Value::json(serde_json::to_value(value).expect("portable argument"))).unwrap_or(Value::Undefined)];
        let callback = self.owner.borrow().exposes.get("focusSelf").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("focusSelf", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn state_5(&self) -> Result<bool, Value> { self.state("pressed").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
      pub fn owner(&self) -> OwnerWeak { Rc::downgrade(&self.owner) }
      pub fn state(&self, name: &str) -> Result<Json, Value> { catch_authored(|| { let state=self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed State")); state.get().data() }) }
      pub fn call(&self, name: &str, arguments: Vec<Json>, window: &mut Window, cx: &mut App) -> Result<Json, Value> {
          let outcome = catch_authored(|| {
          refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
          let callback = self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed method"));
          let arguments: Vec<Value> = arguments.into_iter().map(Value::json).collect(); check_method(name, &arguments);
          let result = invoke(&self.owner, "expose-method", &callback, arguments);
          let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
          if matches!(result, Value::Undefined) { Json::Null } else { result.data() }
          });
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome
      }
      pub fn host_target(&self) -> Result<Value, Value> { catch_authored(|| { ensure(&self.owner()); Value::HostTarget(self.owner()) }) }
      pub fn take_events(&self) -> Vec<(String, Json)> { std::mem::take(&mut self.owner.borrow_mut().emitted) }
      pub fn take_failures(&self) -> Vec<NativeFailure> { take_native_failures(&self.owner) }
      pub fn dispose(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
          catch_authored(|| {
          let drive = self.owner.borrow().native_drive.clone();
          let failure = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| Owner::dispose(&self.owner)));
          let driven = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| { if let Some(drive) = drive { drive(window, cx); } }));
          if let Err(failure) = failure { std::panic::resume_unwind(failure); }
          if let Err(failure) = driven { std::panic::resume_unwind(failure); }
          })
      }
  }
  pub struct CompiledComponent { pub owner: OwnerRef, focus: FocusHandle, window_input: Option<FocusHandle>, _focus_subscriptions: Vec<Subscription>, _window_activation: Option<(gpui::WindowId, Subscription)>, _focus_lost: Option<Subscription>, _global_key_capture: Option<Subscription>, _entry_readiness: Option<(gpui::WindowId, Subscription)> }
  impl CompiledComponent {
      pub fn create_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> { Self::create(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn create(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          Self::create_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn create_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          let mut failure = None;
          let entity = cx.new(|cx| Self::new_with_associations(raw_props, parent, associations, window, cx).unwrap_or_else(|error| {
              failure = Some(error);
              // A failed construction still returns normally through GPUI's
              // entity insertion. This inert temporary is dropped immediately
              // below; it is never published or mounted as a native component.
              let owner = Owner::new(Json::Object(Default::default()), Default::default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
              { let mut owner = owner.borrow_mut(); owner.disposed = true; owner.present = false; }
              Self { owner, focus: cx.focus_handle(), window_input: None, _focus_subscriptions: Vec::new(), _window_activation: None, _focus_lost: None, _global_key_capture: None, _entry_readiness: None }
          }));
          match failure { Some(error) => Err(error), None => Ok(entity) }
      }
      pub fn new_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> { Self::new(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn new(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          Self::new_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn new_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          catch_authored(|| {
          let owner_ref = Owner::new(raw_props, parent.unwrap_or_default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
          initialize_instance_associations(&owner_ref, associations);
          let owner = Rc::downgrade(&owner_ref);
          let focus = cx.focus_handle();
          let view = cx.entity().downgrade();
          let drive_owner=owner.clone(); let drive_focus=focus.clone();
          let driving = Rc::new(std::cell::Cell::new(false));
          let drive_pending = Rc::new(std::cell::Cell::new(false));
          let drive: Drive = Rc::new(move |window, cx| {
              // Platform effects need owner storage and its real FocusHandle,
              // not another lease of the generated component. Preserve their
              // synchronous effect (notably physical focus) under public calls.
              if !driving.replace(true) {
                  if let Some(owner)=drive_owner.upgrade() {
                      native_host_callback(&owner, "drive", || { modules_drive(&owner, &drive_focus, window, cx); drive_queued_focus(&owner, window, cx); });
                  }
                  driving.set(false);
              }
              if drive_pending.replace(true) { return; }
              let view=view.clone(); let pending=drive_pending.clone();
              // A public handle can be called from Entity::update. Return the
              // current host lease before requesting another component update.
              // Authored calls, State writes and platform commands remain
              // synchronous; component refresh is coalesced at the host boundary.
              window.defer(cx, move |window, cx| {
                  pending.set(false);
                  let _ = view.update(cx, |view, cx| { if let Err(error) = view.drive(window, cx) { report_native_failure(&view.owner, "drive", error); } });
              });
          });
          { let mut owner = owner_ref.borrow_mut(); owner.native_drive = Some(drive); owner.window_id = Some(window.window_handle().window_id()); }
  
          configure_native_atoms(&owner_ref, false, false);
          refresh_native_atoms(&owner_ref, window, cx);
          let _lexical_owner = enter_lexical_owner(&owner);
          let renderer = { let owner = owner.clone();  Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_646566: Value = arg(&arguments, 0);
            let v_64697361626c6564: LexicalBinding<Value> = lexical_binding();
            let v_686f7665726564: LexicalBinding<Value> = lexical_binding();
            let v_666f63757361626c65: LexicalBinding<Value> = lexical_binding();
            let v_666f6375736564: LexicalBinding<Value> = lexical_binding();
            let v_70726573736564: LexicalBinding<Value> = lexical_binding();
            let v_636c6561725472616e7369656e74496e746572616374696f6e: LexicalBinding<Value> = lexical_binding();
            let v_73796e6344697361626c6564: LexicalBinding<native::gpui_native_owner::NativeCallable<dyn Fn(bool) -> Value>> = lexical_binding();
            let v_6163746976617465: LexicalBinding<Value> = lexical_binding();
            // Source "packages/prototypes/base/src/button/button.proto.ts":12:3
            { let v_7075695f6e61746976655f30 = v_646566.clone(); style_use(&owner, vec![Value::Style(vec![("select-none".into(), "content-selection affordance".into())])]) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":13:9
            let v_61636365737369626c65 = native_builtin_hook(&owner, "asAccessible", || as_accessible(&owner));
            // Source "packages/prototypes/base/src/button/button.proto.ts":15:3
            native_builtin_hook(&owner, "asTrigger", || as_trigger(&owner));
            // Source "packages/prototypes/base/src/button/button.proto.ts":18:3
            { let v_7075695f6e61746976655f31 = v_646566.clone(); props_define(&owner, record(vec![("disabled", record(vec![("type", Value::string("boolean")), ("empty", Value::string("fallback"))]))])) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":21:3
            { let v_7075695f6e61746976655f32 = v_646566.clone(); set_defaults(&owner, record(vec![("disabled", Value::boolean(false))])) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":26:9
            v_64697361626c6564.initialize({ let v_7075695f6e61746976655f33 = v_646566.clone(); create_state(&owner, "bool", Value::string("disabled"), Value::boolean(false), Value::Undefined) });
            // Source "packages/prototypes/base/src/button/button.proto.ts":27:3
            { let v_7075695f6e61746976655f34 = v_646566.clone(); expose_state(&owner, Value::string("disabled"), v_64697361626c6564.read()) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":28:3
            { let v_7075695f6e61746976655f35 = v_61636365737369626c65.clone(); accessible_state(&(v_7075695f6e61746976655f35.clone()).owner(), Value::string("disabled"), v_64697361626c6564.read(), Value::Undefined) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":31:9
            v_686f7665726564.initialize({ let v_7075695f6e61746976655f36 = v_646566.clone(); create_state(&owner, "bool", Value::string("hovered"), Value::boolean(false), Value::Undefined) });
            // Source "packages/prototypes/base/src/button/button.proto.ts":32:3
            { let v_7075695f6e61746976655f37 = v_646566.clone(); expose_state(&owner, Value::string("hovered"), v_686f7665726564.read()) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":35:9
            v_666f63757361626c65.initialize(native_builtin_hook(&owner, "asFocusable", || as_focusable(&owner)));
            // Source "packages/prototypes/base/src/button/button.proto.ts":36:3
            { let v_7075695f6e61746976655f38 = v_666f63757361626c65.read(); focus_setup_config(&(v_7075695f6e61746976655f38.clone()).owner(), "focus", record(vec![("disabled", Value::boolean(false))])) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":38:9
            v_666f6375736564.initialize((v_666f63757361626c65.read()).member("focused", false));
            // Source "packages/prototypes/base/src/button/button.proto.ts":39:9
            let v_666f63757356697369626c65 = (v_666f63757361626c65.read()).member("focusVisible", false);
            // Source "packages/prototypes/base/src/button/button.proto.ts":42:3
            { let v_7075695f6e61746976655f39 = v_646566.clone(); expose_state(&owner, Value::string("focused"), v_666f6375736564.read()) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":43:3
            { let v_7075695f6e61746976655f3130 = v_646566.clone(); expose_state(&owner, Value::string("focusVisible"), v_666f63757356697369626c65.clone()) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":46:3
            { let v_7075695f6e61746976655f3131 = v_646566.clone(); expose_method(&owner, Value::string("focusSelf"), {  let v_64697361626c6564 = v_64697361626c6564.clone(); let v_666f63757361626c65 = v_666f63757361626c65.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_6f7074696f6e73: Value = arg(&arguments, 0);
                // Source "packages/prototypes/base/src/button/button.proto.ts":47:5
                if ({ let v_7075695f6e61746976655f3132 = v_64697361626c6564.read(); Value::boolean(((v_7075695f6e61746976655f3132.clone()).get()).bool()) }).bool() {
                    // Source "packages/prototypes/base/src/button/button.proto.ts":47:25
                    return Value::Undefined;
                }
                // Source "packages/prototypes/base/src/button/button.proto.ts":48:5
                { let v_7075695f6e61746976655f3133 = v_666f63757361626c65.read(); focus_request(&(v_7075695f6e61746976655f3133.clone()).owner(), v_6f7074696f6e73.clone(), false) };
                Value::Undefined
            })) }) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":52:9
            v_70726573736564.initialize({ let v_7075695f6e61746976655f3134 = v_646566.clone(); create_state(&owner, "bool", Value::string("pressed"), Value::boolean(false), Value::Undefined) });
            // Source "packages/prototypes/base/src/button/button.proto.ts":53:3
            { let v_7075695f6e61746976655f3135 = v_646566.clone(); expose_state(&owner, Value::string("pressed"), v_70726573736564.read()) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":55:9
            v_636c6561725472616e7369656e74496e746572616374696f6e.initialize({  let v_686f7665726564 = v_686f7665726564.clone(); let v_70726573736564 = v_70726573736564.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_726561736f6e: Value = arg(&arguments, 0);
                // Source "packages/prototypes/base/src/button/button.proto.ts":56:5
                { let v_7075695f6e61746976655f3136 = v_686f7665726564.read(); state_set(v_7075695f6e61746976655f3136.clone(), Value::boolean(false), v_726561736f6e.clone()) };
                // Source "packages/prototypes/base/src/button/button.proto.ts":57:5
                { let v_7075695f6e61746976655f3137 = v_70726573736564.read(); state_set(v_7075695f6e61746976655f3137.clone(), Value::boolean(false), v_726561736f6e.clone()) };
                Value::Undefined
            })) });
            // Source "packages/prototypes/base/src/button/button.proto.ts":61:3
            { let v_7075695f6e61746976655f3138 = v_646566.clone(); register_life(&owner, "unmounted", {  let v_636c6561725472616e7369656e74496e746572616374696f6e = v_636c6561725472616e7369656e74496e746572616374696f6e.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "packages/prototypes/base/src/button/button.proto.ts":62:5
                v_636c6561725472616e7369656e74496e746572616374696f6e.read().call_authored(vec![Value::string("reason: button view unmounted => reset transient interaction")]);
                Value::Undefined
            })) }) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":66:9
            v_73796e6344697361626c6564.initialize({  let v_64697361626c6564 = v_64697361626c6564.clone(); let v_666f63757361626c65 = v_666f63757361626c65.clone(); let v_636c6561725472616e7369656e74496e746572616374696f6e = v_636c6561725472616e7369656e74496e746572616374696f6e.clone(); let call:Rc<dyn Fn(bool)->Value>=Rc::new(move |argument_0: bool| -> Value {
                let v_6e65787444697361626c6564: bool = argument_0;
                // Source "packages/prototypes/base/src/button/button.proto.ts":67:5
                { let v_7075695f6e61746976655f3139 = v_64697361626c6564.read(); state_set(v_7075695f6e61746976655f3139.clone(), Value::boolean(v_6e65787444697361626c6564.clone()), Value::string("reason: sync disabled")) };
                // Source "packages/prototypes/base/src/button/button.proto.ts":68:5
                { let v_7075695f6e61746976655f3230 = v_666f63757361626c65.read(); focus_disabled(&(v_7075695f6e61746976655f3230.clone()).owner(), Value::boolean(v_6e65787444697361626c6564.clone())) };
                // Source "packages/prototypes/base/src/button/button.proto.ts":69:5
                if v_6e65787444697361626c6564.clone() {
                    // Source "packages/prototypes/base/src/button/button.proto.ts":70:7
                    v_636c6561725472616e7369656e74496e746572616374696f6e.read().call_authored(vec![Value::string("reason: button disabled => reset transient interaction")]);
                }
                Value::Undefined
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).bool())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } });
            // Source "packages/prototypes/base/src/button/button.proto.ts":73:3
            { let v_7075695f6e61746976655f3231 = v_646566.clone(); register_life(&owner, "created", {  let v_73796e6344697361626c6564 = v_73796e6344697361626c6564.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f31373831653039613465353164623032: Value = arg(&arguments, 0);
                // Source "packages/prototypes/base/src/button/button.proto.ts":74:5
                (v_73796e6344697361626c6564.read().call)((({ let v_7075695f6e61746976655f3232 = v_72756e5f5f31373831653039613465353164623032.clone(); read_props(&(v_7075695f6e61746976655f3232.clone()).owner(), false) }).member("disabled", false)).bool());
                Value::Undefined
            })) }) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":76:3
            { let v_7075695f6e61746976655f3233 = v_646566.clone(); watch_props(&owner, Some(Value::Array(Rc::new(vec![Value::string("disabled")]))), false, {  let v_73796e6344697361626c6564 = v_73796e6344697361626c6564.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_5f72756e5f5f62313466666637393730663966356531: Value = arg(&arguments, 0);
                let v_6e657874: Value = arg(&arguments, 1);
                // Source "packages/prototypes/base/src/button/button.proto.ts":77:5
                (v_73796e6344697361626c6564.read().call)(((v_6e657874.clone()).member("disabled", false)).bool());
                Value::Undefined
            })) }) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":81:3
            { let v_7075695f6e61746976655f3234 = v_646566.clone(); expose_event(&owner, Value::string("click")) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":83:3
            { let v_7075695f6e61746976655f3235 = v_61636365737369626c65.clone(); accessible_action_spec(&(v_7075695f6e61746976655f3235.clone()).owner(), Value::string("activate"), record(vec![("event", Value::string("click"))])) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":86:3
            { let v_7075695f6e61746976655f3236 = v_61636365737369626c65.clone(); accessible_role(&(v_7075695f6e61746976655f3236.clone()).owner(), Value::string("button")) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":89:3
            { let v_7075695f6e61746976655f3237 = v_61636365737369626c65.clone(); name_content(&(v_7075695f6e61746976655f3237.clone()).owner()) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":91:9
            v_6163746976617465.initialize({  let v_64697361626c6564 = v_64697361626c6564.clone(); let v_70726573736564 = v_70726573736564.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f61363435356634336464333663633963: Value = arg(&arguments, 0);
                let v_697343757272656e745f5f30643664623662373162366466323238: Value = { let argument = arg(&arguments, 1); if matches!(&argument, Value::Undefined) { ({   let call:Rc<dyn Fn()->bool>=Rc::new(move || -> bool {
                    // Source "packages/prototypes/base/src/button/button.proto.ts":91:83
                    return true;
                }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable") } else { argument } };
                // Source "packages/prototypes/base/src/button/button.proto.ts":92:5
                if { let pui_native_28=({ let v_7075695f6e61746976655f3330 = v_64697361626c6564.read(); Value::boolean(((v_7075695f6e61746976655f3330.clone()).get()).bool()) }).bool(); if !(pui_native_28) {!(({ let callable = v_697343757272656e745f5f30643664623662373162366466323238.clone(); callable.call_authored(vec![]) }).bool())} else {pui_native_28} } {
                    // Source "packages/prototypes/base/src/button/button.proto.ts":92:41
                    return Value::Undefined;
                }
                // Source "packages/prototypes/base/src/button/button.proto.ts":93:5
                { let v_7075695f6e61746976655f3331 = v_70726573736564.read(); state_set(v_7075695f6e61746976655f3331.clone(), Value::boolean(false), Value::string("reason: button activation => pressed")) };
                // Source "packages/prototypes/base/src/button/button.proto.ts":94:5
                if { let pui_native_32=({ let v_7075695f6e61746976655f3334 = v_64697361626c6564.read(); Value::boolean(((v_7075695f6e61746976655f3334.clone()).get()).bool()) }).bool(); if !(pui_native_32) {!(({ let callable = v_697343757272656e745f5f30643664623662373162366466323238.clone(); callable.call_authored(vec![]) }).bool())} else {pui_native_32} } {
                    // Source "packages/prototypes/base/src/button/button.proto.ts":94:41
                    return Value::Undefined;
                }
                // Source "packages/prototypes/base/src/button/button.proto.ts":95:5
                { let v_7075695f6e61746976655f3335 = v_72756e5f5f61363435356634336464333663633963.clone(); emit(&(v_7075695f6e61746976655f3335.clone()).owner(), Value::string("click"), Value::Undefined) };
                Value::Undefined
            })) });
            // Source "packages/prototypes/base/src/button/button.proto.ts":97:3
            { let v_7075695f6e61746976655f3336 = native_builtin_hook(&owner, "asControlLabel", || module_handle(&owner, "control-label")); control_label_declare(&(v_7075695f6e61746976655f3336.clone()).owner(), true, {  let v_64697361626c6564 = v_64697361626c6564.clone(); let v_666f63757361626c65 = v_666f63757361626c65.clone(); let v_6163746976617465 = v_6163746976617465.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72657175657374: LexicalBinding<Value> = lexical_binding();
                let v_72756e5f5f64306466633634343134333938633064: Value = arg(&arguments, 0);
                v_72657175657374.initialize(arg(&arguments, 1));
                // Source "packages/prototypes/base/src/button/button.proto.ts":98:11
                let v_697343757272656e745f5f35343134626134303939633239666164 = {  let v_64697361626c6564 = v_64697361626c6564.clone(); let v_72657175657374 = v_72657175657374.clone(); let call:Rc<dyn Fn()->bool>=Rc::new(move || -> bool {
                    // Source "packages/prototypes/base/src/button/button.proto.ts":98:29
                    return { let pui_native_37=!(({ let v_7075695f6e61746976655f3339 = v_64697361626c6564.read(); Value::boolean(((v_7075695f6e61746976655f3339.clone()).get()).bool()) }).bool()); if (pui_native_37) {({ let v_7075695f6e61746976655f3430 = v_72657175657374.read(); Value::boolean((control_label_request_current(v_7075695f6e61746976655f3430.clone())).bool()) }).bool()} else {pui_native_37} };
                }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } };
                // Source "packages/prototypes/base/src/button/button.proto.ts":99:5
                if !((v_697343757272656e745f5f35343134626134303939633239666164.call)()) {
                    // Source "packages/prototypes/base/src/button/button.proto.ts":99:23
                    return Value::Undefined;
                }
                // Source "packages/prototypes/base/src/button/button.proto.ts":100:5
                { let v_7075695f6e61746976655f3431 = v_666f63757361626c65.read(); focus_request(&(v_7075695f6e61746976655f3431.clone()).owner(), record(vec![("reason", if (Value::boolean((Value::boolean(strict_equal(&((v_72657175657374.read()).member("source", false)), &(Value::string("pointer"))))).bool())).truthy() { Value::string("pointer") } else { Value::string("programmatic") })]), false) };
                // Source "packages/prototypes/base/src/button/button.proto.ts":101:5
                if (v_697343757272656e745f5f35343134626134303939633239666164.call)() {
                    // Source "packages/prototypes/base/src/button/button.proto.ts":101:22
                    v_6163746976617465.read().call_authored(vec![v_72756e5f5f64306466633634343134333938633064.clone(), (v_697343757272656e745f5f35343134626134303939633239666164.clone()).ordinary.clone().expect("checked native data callable")]);
                }
                Value::Undefined
            })) }, Value::Undefined) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":107:3
            { let v_7075695f6e61746976655f3434 = v_646566.clone(); listen(&owner, Value::string("key.down"), true, {  let v_64697361626c6564 = v_64697361626c6564.clone(); let v_666f6375736564 = v_666f6375736564.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_5f72756e5f5f66376138656232313366666438363334: Value = arg(&arguments, 0);
                let v_6576: Value = arg(&arguments, 1);
                // Source "packages/prototypes/base/src/button/button.proto.ts":108:11
                let v_64657461696c = v_6576.clone();
                // Source "packages/prototypes/base/src/button/button.proto.ts":109:5
                if ({ let v_7075695f6e61746976655f3435 = v_64697361626c6564.read(); Value::boolean(((v_7075695f6e61746976655f3435.clone()).get()).bool()) }).bool() {
                    // Source "packages/prototypes/base/src/button/button.proto.ts":109:25
                    return Value::Undefined;
                }
                // Source "packages/prototypes/base/src/button/button.proto.ts":110:5
                if !(({ let v_7075695f6e61746976655f3436 = v_666f6375736564.read(); Value::boolean(((v_7075695f6e61746976655f3436.clone()).get()).bool()) }).bool()) {
                    // Source "packages/prototypes/base/src/button/button.proto.ts":110:25
                    return Value::Undefined;
                }
                // Source "packages/prototypes/base/src/button/button.proto.ts":111:5
                if (Value::boolean(!strict_equal(&((v_64657461696c.clone()).member("key", true)), &(Value::string(" "))))).bool() {
                    // Source "packages/prototypes/base/src/button/button.proto.ts":111:30
                    return Value::Undefined;
                }
                // Source "packages/prototypes/base/src/button/button.proto.ts":112:5
                { let v_7075695f6e61746976655f3439 = v_6576.clone(); prevent(v_7075695f6e61746976655f3439.clone()) };
                Value::Undefined
            })) }, Value::Undefined) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":119:3
            { let v_7075695f6e61746976655f3530 = v_646566.clone(); listen(&owner, Value::string("pointer.enter"), false, {  let v_64697361626c6564 = v_64697361626c6564.clone(); let v_686f7665726564 = v_686f7665726564.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "packages/prototypes/base/src/button/button.proto.ts":120:5
                if ({ let v_7075695f6e61746976655f3531 = v_64697361626c6564.read(); Value::boolean(((v_7075695f6e61746976655f3531.clone()).get()).bool()) }).bool() {
                    // Source "packages/prototypes/base/src/button/button.proto.ts":120:25
                    return Value::Undefined;
                }
                // Source "packages/prototypes/base/src/button/button.proto.ts":121:5
                { let v_7075695f6e61746976655f3532 = v_686f7665726564.read(); state_set(v_7075695f6e61746976655f3532.clone(), Value::boolean(true), Value::string("reason: button pointer.enter => hovered")) };
                Value::Undefined
            })) }, Value::Undefined) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":123:3
            { let v_7075695f6e61746976655f3533 = v_646566.clone(); listen(&owner, Value::string("pointer.leave"), false, {  let v_686f7665726564 = v_686f7665726564.clone(); let v_70726573736564 = v_70726573736564.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "packages/prototypes/base/src/button/button.proto.ts":124:5
                { let v_7075695f6e61746976655f3534 = v_686f7665726564.read(); state_set(v_7075695f6e61746976655f3534.clone(), Value::boolean(false), Value::string("reason: button pointer.leave => hovered")) };
                // Source "packages/prototypes/base/src/button/button.proto.ts":125:5
                { let v_7075695f6e61746976655f3535 = v_70726573736564.read(); state_set(v_7075695f6e61746976655f3535.clone(), Value::boolean(false), Value::string("reason: button pointer.leave => pressed")) };
                Value::Undefined
            })) }, Value::Undefined) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":127:3
            { let v_7075695f6e61746976655f3536 = v_646566.clone(); listen(&owner, Value::string("pointer.cancel"), false, {  let v_686f7665726564 = v_686f7665726564.clone(); let v_70726573736564 = v_70726573736564.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "packages/prototypes/base/src/button/button.proto.ts":128:5
                { let v_7075695f6e61746976655f3537 = v_686f7665726564.read(); state_set(v_7075695f6e61746976655f3537.clone(), Value::boolean(false), Value::string("reason: button pointer.cancel => hovered")) };
                // Source "packages/prototypes/base/src/button/button.proto.ts":129:5
                { let v_7075695f6e61746976655f3538 = v_70726573736564.read(); state_set(v_7075695f6e61746976655f3538.clone(), Value::boolean(false), Value::string("reason: button pointer.cancel => pressed")) };
                Value::Undefined
            })) }, Value::Undefined) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":132:3
            { let v_7075695f6e61746976655f3539 = v_646566.clone(); listen(&owner, Value::string("press.cancel"), false, {  let v_636c6561725472616e7369656e74496e746572616374696f6e = v_636c6561725472616e7369656e74496e746572616374696f6e.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "packages/prototypes/base/src/button/button.proto.ts":133:5
                v_636c6561725472616e7369656e74496e746572616374696f6e.read().call_authored(vec![Value::string("reason: button press.cancel => reset transient interaction")]);
                Value::Undefined
            })) }, Value::Undefined) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":137:3
            { let v_7075695f6e61746976655f3630 = v_646566.clone(); listen(&owner, Value::string("pointer.down"), false, {  let v_64697361626c6564 = v_64697361626c6564.clone(); let v_70726573736564 = v_70726573736564.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "packages/prototypes/base/src/button/button.proto.ts":138:5
                if ({ let v_7075695f6e61746976655f3631 = v_64697361626c6564.read(); Value::boolean(((v_7075695f6e61746976655f3631.clone()).get()).bool()) }).bool() {
                    // Source "packages/prototypes/base/src/button/button.proto.ts":138:25
                    return Value::Undefined;
                }
                // Source "packages/prototypes/base/src/button/button.proto.ts":139:5
                { let v_7075695f6e61746976655f3632 = v_70726573736564.read(); state_set(v_7075695f6e61746976655f3632.clone(), Value::boolean(true), Value::string("reason: button pointer.down => pressed")) };
                Value::Undefined
            })) }, Value::Undefined) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":141:3
            { let v_7075695f6e61746976655f3633 = v_646566.clone(); listen(&owner, Value::string("pointer.up"), false, {  let v_70726573736564 = v_70726573736564.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                // Source "packages/prototypes/base/src/button/button.proto.ts":142:5
                { let v_7075695f6e61746976655f3634 = v_70726573736564.read(); state_set(v_7075695f6e61746976655f3634.clone(), Value::boolean(false), Value::string("reason: button pointer.up => pressed")) };
                Value::Undefined
            })) }, Value::Undefined) };
            // Source "packages/prototypes/base/src/button/button.proto.ts":146:3
            { let v_7075695f6e61746976655f3635 = v_646566.clone(); listen(&owner, Value::string("press.commit"), false, {  let v_70726573736564 = v_70726573736564.clone(); let v_6163746976617465 = v_6163746976617465.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
                let v_72756e5f5f64616639353063653333323965366633: Value = arg(&arguments, 0);
                // Source "packages/prototypes/base/src/button/button.proto.ts":147:5
                { let v_7075695f6e61746976655f3636 = v_70726573736564.read(); state_set(v_7075695f6e61746976655f3636.clone(), Value::boolean(false), Value::string("reason: button press.commit => pressed")) };
                // Source "packages/prototypes/base/src/button/button.proto.ts":148:5
                v_6163746976617465.read().call_authored(vec![v_72756e5f5f64616639353063653333323965366633.clone()]);
                Value::Undefined
            })) }, Value::Undefined) };
            Value::Undefined
        })) }.call_authored(vec![definition_capability(&owner)]);
          Owner::finish(&owner_ref, renderer);
          // Establish the App's default-action snapshot before any authored
          // global key capture can replace focus during the same keystroke.
          register_sequential_focus_owner(&owner_ref, cx);
          let focus_subscriptions = if native_focus_observation_needed(&owner_ref) {
          let focus_owner = owner_ref.clone();
          let on_focus = cx.on_focus(&focus, window, move |view, window, cx| {
              native_host_callback(&focus_owner, "focus", || {
              let epoch = focus_owner.borrow().epoch;
              if !ready(&focus_owner) || focus_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&focus_owner, window);
              native_focus_fact(&focus_owner, view.focus.is_focused(window));
              if !ready(&focus_owner) || focus_owner.borrow().epoch != epoch { return; }
              dispatch(&focus_owner, "host:focus", false, event_fields("host:focus"));
              if ready(&focus_owner) && focus_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          let blur_owner = owner_ref.clone();
          let on_blur = cx.on_blur(&focus, window, move |view, window, cx| {
              native_host_callback(&blur_owner, "blur", || {
              let epoch = blur_owner.borrow().epoch;
              if !ready(&blur_owner) || blur_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&blur_owner, window);
              native_focus_fact(&blur_owner, view.focus.is_focused(window));
              if !ready(&blur_owner) || blur_owner.borrow().epoch != epoch { return; }
              text_blur(&blur_owner, window, cx);
              dispatch(&blur_owner, "host:blur", false, event_fields("host:blur"));
              if ready(&blur_owner) && blur_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          // A native slot descendant can start this root's keyboard press
          // while the root FocusHandle itself is not focused. Its departure
          // from the physical subtree is distinct from the root's own blur.
          let focus_out_owner = Rc::downgrade(&owner_ref);
          let on_focus_out = cx.on_focus_out(&focus, window, move |view, _, window, cx| {
              let Some(owner) = focus_out_owner.upgrade() else { return; };
              native_host_callback(&owner, "focus-out", || {
              let epoch = owner.borrow().epoch;
              if !ready(&owner) || owner.borrow().window_id != Some(window.window_handle().window_id()) || view.focus.contains_focused(window, cx) { return; }
              // This retires only an existing root press lease. Do not forge
              // host:blur or change the root's own Focus observation here.
              native_press_blur(&owner);
              if ready(&owner) && owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          vec![on_focus, on_blur, on_focus_out]
          } else { Vec::new() };
          let global_key_capture = subscribe_global_key_capture(&owner_ref, cx);
          let window_input = window_input_needed(&owner_ref).then(|| cx.focus_handle().tab_stop(false));
          let focus_lost = window_input.as_ref().map(|_| cx.on_focus_lost(window, |view, window, cx| { let owner=view.owner.clone(); native_host_callback(&owner, "focus-lost", || { if view.owner.borrow().window_id == Some(window.window_handle().window_id()) { if let Some(focus) = &view.window_input { restore_window_input(&view.owner, focus, window, cx); } } }); }));
          let mut view = Self { owner: owner_ref, focus, window_input, _focus_subscriptions: focus_subscriptions, _window_activation: None, _focus_lost: focus_lost, _global_key_capture: global_key_capture, _entry_readiness: None };
          view.bind_window_activation(window, cx);
          view
          })
      }
      #[cfg(feature="test-support")]
      pub fn native_resource_counts(&self) -> Json { let mut counts=native::gpui_native_owner::native_resource_counts(&self.owner); counts["nativeSubscriptions"] = Json::from(self._focus_subscriptions.len() + usize::from(self._window_activation.is_some()) + usize::from(self._focus_lost.is_some()) + usize::from(self._global_key_capture.is_some()) + usize::from(self._entry_readiness.is_some())); counts }
      pub fn handle(&self) -> CompiledComponentHandle { CompiledComponentHandle { owner: self.owner.clone() } }
      pub fn set_props(&mut self, raw: Json, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_props(&self.owner, raw));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; self.drive(window, cx)
      }
      pub fn set_instance_associations(&mut self, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_instance_associations(&self.owner, associations));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; drive_owners(window, cx); self.drive(window, cx)
      }
      pub fn set_slot(&mut self, slot: Vec<native::gpui_native_owner::NativeSnapshot>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { ensure(&Rc::downgrade(&self.owner)); assert_native_slot_children(&slot); let mut owner = self.owner.borrow_mut(); owner.slot = slot; owner.dirty = true; cx.notify(); }) }
      pub fn set_parent(&mut self, parent: Option<OwnerWeak>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { if let Err(error)=set_native_parent(&self.owner, parent.unwrap_or_default()){throw_error("NATIVE_PARENT_INVALID", error)} cx.notify(); }) }
      fn bind_window_activation(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !native_focus_observation_needed(&self.owner) && !native::gpui_native_move::move_owner_has_binding(&self.owner) && !control_label_is_label(&self.owner) { self._window_activation.take(); return; }
          let id = window.window_handle().window_id();
          if self._window_activation.as_ref().is_some_and(|(bound, _)| *bound == id) { return; }
          self._window_activation.take();
          let owner = self.owner.clone();
          let subscription = cx.observe_window_activation(window, move |view, window, cx| {
              let deactivated = owner.borrow().window_id == Some(window.window_handle().window_id()) && !window.is_window_active();
              native_host_callback(&owner, "window-activation", || {
                  if deactivated {
                      native_window_blur(&owner);
                      view.drive(window, cx).unwrap_or_else(|error| throw_value(error));
                  }
              });
              if deactivated { notify_native_change(cx); }
          });
          self._window_activation = Some((id, subscription));
      }
      #[cfg(feature = "experimental-focus-tree")]
      fn bind_entry_readiness(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !self.owner.borrow().modules.hooks.contains("focus-entry") { return; }
          let window_id = window.window_handle().window_id();
          if self._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window_id) { return; }
          self._entry_readiness.take();
          let view = cx.entity().downgrade();
          let subscription = window.observe_focus_tree(cx, move |_, window, cx| {
              let _ = view.update(cx, |view, cx| {
                  if view._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window.window_handle().window_id()) { if let Err(error)=view.drive(window, cx){report_native_failure(&view.owner,"entry-readiness",error)} }
              });
          });
          self._entry_readiness = Some((window_id, subscription));
      }
      fn notify_after_turn(&self, cx: &mut Context<Self>) {
          // GPUI suppresses Entity observer effects while a window is drawing,
          // including its focus/blur phase. Keep authored state synchronous,
          // then publish the host change after that physical draw lease ends.
          // A weak target cannot keep a detached component alive for delivery.
          notify_native_change(cx);
      }
      pub fn drive(&mut self, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let result = catch_authored(|| {
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          modules_drive(&self.owner, &self.focus, window, cx);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          drive_queued_focus(&self.owner, window, cx);
          });
          // A callback can publish before failing or retiring its owner. That
          // output is independent from repaint dirtiness and an unread queue.
          let dirty = std::mem::take(&mut self.owner.borrow_mut().dirty);
          if !notify_native_events(&self.owner, cx) && dirty { self.notify_after_turn(cx); }
          result
      }
  }
  impl Drop for CompiledComponent { fn drop(&mut self) { native_host_callback(&self.owner, "drop", || Owner::dispose(&self.owner)); } }
  impl gpui::Focusable for CompiledComponent { fn focus_handle(&self, _: &App) -> FocusHandle { self.focus.clone() } }
  impl Render for CompiledComponent {
      fn render(&mut self, window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
          let report_owner = self.owner.clone();
          native_host_callback(&report_owner, "render", || {
          refresh_native_atoms(&self.owner, window, cx);
          Owner::project(&self.owner);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); return gpui::div().into_any_element(); }
          if !self.owner.borrow().present { self._window_activation.take(); detach_native_view(&self.owner); return gpui::div().into_any_element(); }
          bind_native_focus_window(&self.owner, window);
          self.bind_window_activation(window, cx);
          #[cfg(feature = "experimental-focus-tree")] self.bind_entry_readiness(window, cx);
          let drive = self.owner.borrow().native_drive.as_ref().expect("live native owner drive").clone();
          // Drawing consumes only repaint dirtiness. A parent Render can call
          // an exposed method before this child is laid out: its independent
          // pending_native_events flag survives until the coalesced drive wakes
          // the consumer. Repeated slot projection cannot create a notify loop.
          self.owner.borrow_mut().dirty = false;
          let snapshot = self.owner.borrow().projection.clone().expect("live native projection");
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          let element = paint_native_root(&snapshot, &self.owner, &self.focus, format!("compiled-root-{}", Rc::as_ptr(&self.owner) as usize), drive);
          if let Some(focus) = &self.window_input { window_input_scope(element, focus, &self.owner) } else { element }
          }).unwrap_or_else(|| gpui::div().into_any_element())
      }
  }
  
//# sourceMappingURL=Component.rs.map
