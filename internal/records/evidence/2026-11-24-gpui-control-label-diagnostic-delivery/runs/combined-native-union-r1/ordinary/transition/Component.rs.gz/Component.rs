// Direct checked-source GPUI component. Supporting files are ordinary editable Rust.
  #[cfg(panic = "abort")] compile_error!("Authored exception lowering requires panic=unwind");
  pub use proto_ui_gpui_native as native;
  pub use native::gpui_native_owner::{ControlLabelRef, InstanceAssociations};
  use gpui::{prelude::*, App, Context, FocusHandle, Subscription, Window};
  use std::rc::Rc;
  use serde_json::Value as Json;
  use native::gpui_native_owner::*;
  std::thread_local! { static v_5f5f7075694d6f64756c6530: Value = {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
    let v_6472697665725f5f66643335663962313031386337303063: LexicalBinding<Value> = lexical_binding();
    v_6472697665725f5f66643335663962313031386337303063.initialize(arg(&arguments, 0));
    let v_7461726765744f70656e: LexicalBinding<Rc<std::cell::RefCell<bool>>> = lexical_binding();
    let v_766965774d6f756e746564: LexicalBinding<Rc<std::cell::RefCell<bool>>> = lexical_binding();
    let v_717565756564496e74656e74: LexicalBinding<Rc<std::cell::RefCell<Value>>> = lexical_binding();
    let v_70656e64696e675461736b: LexicalBinding<Rc<std::cell::RefCell<Value>>> = lexical_binding();
    let v_67656e65726174696f6e: LexicalBinding<Rc<std::cell::RefCell<f64>>> = lexical_binding();
    let v_6f776e657245706f6368: LexicalBinding<Rc<std::cell::RefCell<f64>>> = lexical_binding();
    let v_7068617365417474656d7074: LexicalBinding<Rc<std::cell::RefCell<f64>>> = lexical_binding();
    let v_7265766973696f6e: LexicalBinding<Rc<std::cell::RefCell<f64>>> = lexical_binding();
    let v_7075626c697368696e67: LexicalBinding<Rc<std::cell::RefCell<bool>>> = lexical_binding();
    let v_7374616765645374617465: LexicalBinding<Rc<std::cell::RefCell<Value>>> = lexical_binding();
    let v_61636b6e6f776c6564676564: LexicalBinding<Rc<std::cell::RefCell<bool>>> = lexical_binding();
    let v_61636b6e6f776c656467656d656e7443757272656e74: LexicalBinding<Rc<std::cell::RefCell<Value>>> = lexical_binding();
    let v_696e76616c69644475726174696f6e: LexicalBinding<Rc<std::cell::RefCell<bool>>> = lexical_binding();
    let v_7075626c69636174696f6e4661696c6564: LexicalBinding<Rc<std::cell::RefCell<bool>>> = lexical_binding();
    let v_61637469766550726573656e746174696f6e: LexicalBinding<Rc<std::cell::RefCell<Value>>> = lexical_binding();
    let v_73616d65417474656d7074: LexicalBinding<native::gpui_native_owner::NativeCallable<dyn Fn(Value) -> bool>> = lexical_binding();
    let v_63616e63656c5461736b: LexicalBinding<Value> = lexical_binding();
    let v_7465726d696e616c: LexicalBinding<Rc<std::cell::RefCell<bool>>> = lexical_binding();
    let v_6f7065726174696f6e56657273696f6e: LexicalBinding<Rc<std::cell::RefCell<f64>>> = lexical_binding();
    let v_7374617274696e67: LexicalBinding<Rc<std::cell::RefCell<Value>>> = lexical_binding();
    let v_63757272656e744f7065726174696f6e: LexicalBinding<native::gpui_native_owner::NativeCallable<dyn Fn(f64) -> bool>> = lexical_binding();
    let v_757064617465546172676574: LexicalBinding<native::gpui_native_owner::NativeCallable<dyn Fn(bool) -> Value>> = lexical_binding();
    let v_7072657061726174696f6e: LexicalBinding<Rc<std::cell::RefCell<Value>>> = lexical_binding();
    let v_63616e63656c5072657061726174696f6e: LexicalBinding<Value> = lexical_binding();
    let v_6973507265706172696e67: LexicalBinding<native::gpui_native_owner::NativeCallable<dyn Fn(Value) -> bool>> = lexical_binding();
    let v_66696e6973685072657061726174696f6e: LexicalBinding<Value> = lexical_binding();
    let v_626567696e5072657061726174696f6e: LexicalBinding<native::gpui_native_owner::NativeCallable<dyn Fn(bool) -> Value>> = lexical_binding();
    let v_696e76616c6964617465436f6d706c6574696f6e: LexicalBinding<Value> = lexical_binding();
    let v_7365745374617465: LexicalBinding<Value> = lexical_binding();
    let v_736574746c6550726573656e746174696f6e: LexicalBinding<Value> = lexical_binding();
    let v_61726d436f6d706c6574696f6e: LexicalBinding<Value> = lexical_binding();
    let v_626567696e456e746572: LexicalBinding<Value> = lexical_binding();
    let v_626567696e4c65617665: LexicalBinding<Value> = lexical_binding();
    let v_636f6e73756d65517565756564496e74656e74: LexicalBinding<Value> = lexical_binding();
    let v_636f6d706c65746543757272656e74: LexicalBinding<native::gpui_native_owner::NativeCallable<dyn Fn(bool) -> bool>> = lexical_binding();
    let v_656e7465725f5f34333965343333333766333433663737: LexicalBinding<Value> = lexical_binding();
    let v_6c656176655f5f34306631303637396166373934313764: LexicalBinding<Value> = lexical_binding();
    // Source "transition/machine.ts":43:7
    v_7461726765744f70656e.initialize(Rc::new(std::cell::RefCell::new(false)));
    // Source "transition/machine.ts":44:7
    v_766965774d6f756e746564.initialize(Rc::new(std::cell::RefCell::new(false)));
    // Source "transition/machine.ts":45:7
    v_717565756564496e74656e74.initialize(Rc::new(std::cell::RefCell::new(Value::Json(Json::Null))));
    // Source "transition/machine.ts":46:7
    v_70656e64696e675461736b.initialize(Rc::new(std::cell::RefCell::new(Value::Json(Json::Null))));
    // Source "transition/machine.ts":47:7
    v_67656e65726174696f6e.initialize(Rc::new(std::cell::RefCell::new(0.0_f64)));
    // Source "transition/machine.ts":48:7
    v_6f776e657245706f6368.initialize(Rc::new(std::cell::RefCell::new(0.0_f64)));
    // Source "transition/machine.ts":49:7
    v_7068617365417474656d7074.initialize(Rc::new(std::cell::RefCell::new(0.0_f64)));
    // Source "transition/machine.ts":50:7
    v_7265766973696f6e.initialize(Rc::new(std::cell::RefCell::new(0.0_f64)));
    // Source "transition/machine.ts":51:7
    v_7075626c697368696e67.initialize(Rc::new(std::cell::RefCell::new(false)));
    // Source "transition/machine.ts":52:7
    v_7374616765645374617465.initialize(Rc::new(std::cell::RefCell::new(Value::Json(Json::Null))));
    // Source "transition/machine.ts":53:7
    v_61636b6e6f776c6564676564.initialize(Rc::new(std::cell::RefCell::new(false)));
    // Source "transition/machine.ts":54:7
    v_61636b6e6f776c656467656d656e7443757272656e74.initialize(Rc::new(std::cell::RefCell::new(Value::Json(Json::Null))));
    // Source "transition/machine.ts":55:7
    v_696e76616c69644475726174696f6e.initialize(Rc::new(std::cell::RefCell::new(false)));
    // Source "transition/machine.ts":56:7
    v_7075626c69636174696f6e4661696c6564.initialize(Rc::new(std::cell::RefCell::new(false)));
    // Source "transition/machine.ts":57:7
    v_61637469766550726573656e746174696f6e.initialize(Rc::new(std::cell::RefCell::new(Value::Json(Json::Null))));
    // Source "transition/machine.ts":58:9
    v_73616d65417474656d7074.initialize({  let v_61637469766550726573656e746174696f6e = v_61637469766550726573656e746174696f6e.clone(); let v_7465726d696e616c = v_7465726d696e616c.clone(); let call:Rc<dyn Fn(Value)->bool>=Rc::new(move |argument_0: Value| -> bool {
        let v_617474656d70745f5f66663237613538616164383533313839: Value = argument_0;
        // Source "transition/machine.ts":59:5
        return { let pui_native_230={ let pui_native_232=!({ let value=(v_7465726d696e616c.read()).borrow().clone(); value }); if (pui_native_232) {(Value::boolean(strict_equal(&((({ let value = (v_61637469766550726573656e746174696f6e.read()).borrow().clone(); value }).member("attempt", true)).member("ownerEpoch", true)), &(Value::number(((v_617474656d70745f5f66663237613538616164383533313839.clone()).member("ownerEpoch", false)).num()))))).bool()} else {pui_native_232} }; if (pui_native_230) {{ let pui_native_236=((({ let value = (v_61637469766550726573656e746174696f6e.read()).borrow().clone(); value }).member("attempt", false)).member("phaseAttempt", false)).num(); let pui_native_237=((v_617474656d70745f5f66663237613538616164383533313839.clone()).member("phaseAttempt", false)).num(); (pui_native_236==pui_native_237) }} else {pui_native_230} };
    }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call(arg(&arguments,0)))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } });
    // Source "transition/machine.ts":62:9
    v_63616e63656c5461736b.initialize({  let v_70656e64696e675461736b = v_70656e64696e675461736b.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
        // Source "transition/machine.ts":63:11
        let v_7461736b5f5f63356237326664366536306138623738 = { let value = (v_70656e64696e675461736b.read()).borrow().clone(); value };
        // Source "transition/machine.ts":64:5
        { let value = Value::Json(Json::Null); *(v_70656e64696e675461736b.read()).borrow_mut() = value; }
        // Source "transition/machine.ts":65:5
        match match catch_authored::<std::ops::ControlFlow<Value>>(|| {
                // Source "transition/machine.ts":66:7
                { let v_7075695f6e61746976655f323338 = v_7461736b5f5f63356237326664366536306138623738.clone(); if v_7075695f6e61746976655f323338.nullish() { Value::Undefined } else { (v_7075695f6e61746976655f323338.clone()).member("cancel", false).call_authored(vec![]) } };
                std::ops::ControlFlow::Continue(())
            }) {
                Ok(flow) => flow,
                Err(_) => (|| -> std::ops::ControlFlow<Value> {
                    std::ops::ControlFlow::Continue(())
                })()
            } {
            std::ops::ControlFlow::Break(value) => return value,
            std::ops::ControlFlow::Continue(()) => {}
        }
        Value::Undefined
    })) });
    // Source "transition/machine.ts":71:7
    v_7465726d696e616c.initialize(Rc::new(std::cell::RefCell::new(false)));
    // Source "transition/machine.ts":72:7
    v_6f7065726174696f6e56657273696f6e.initialize(Rc::new(std::cell::RefCell::new(0.0_f64)));
    // Source "transition/machine.ts":73:7
    v_7374617274696e67.initialize(Rc::new(std::cell::RefCell::new(Value::Json(Json::Null))));
    // Source "transition/machine.ts":74:9
    v_63757272656e744f7065726174696f6e.initialize({  let v_7465726d696e616c = v_7465726d696e616c.clone(); let v_6f7065726174696f6e56657273696f6e = v_6f7065726174696f6e56657273696f6e.clone(); let call:Rc<dyn Fn(f64)->bool>=Rc::new(move |argument_0: f64| -> bool {
        let v_76657273696f6e: f64 = argument_0;
        // Source "transition/machine.ts":74:49
        return { let pui_native_239=!({ let value=(v_7465726d696e616c.read()).borrow().clone(); value }); if (pui_native_239) {{ let pui_native_241={ let value=(v_6f7065726174696f6e56657273696f6e.read()).borrow().clone(); value }; let pui_native_242=v_76657273696f6e.clone(); (pui_native_241==pui_native_242) }} else {pui_native_239} };
    }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call((arg(&arguments,0)).num()))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } });
    // Source "transition/machine.ts":75:9
    v_757064617465546172676574.initialize({  let v_7461726765744f70656e = v_7461726765744f70656e.clone(); let v_6f7065726174696f6e56657273696f6e = v_6f7065726174696f6e56657273696f6e.clone(); let call:Rc<dyn Fn(bool)->Value>=Rc::new(move |argument_0: bool| -> Value {
        let v_6f70656e5f5f37313734373438323136313936383435: bool = argument_0;
        // Source "transition/machine.ts":76:5
        if { let pui_native_243={ let value=(v_7461726765744f70656e.read()).borrow().clone(); value }; let pui_native_244=v_6f70656e5f5f37313734373438323136313936383435.clone(); !(pui_native_243==pui_native_244) } {
            // Source "transition/machine.ts":76:30
            Value::number({ let value={ let pui_native_245:f64={ let value=(v_6f7065726174696f6e56657273696f6e.read()).borrow().clone(); value }; let pui_native_246:f64=1.0_f64; pui_native_245 + pui_native_246 }; *(v_6f7065726174696f6e56657273696f6e.read()).borrow_mut()=value.clone(); value });
        }
        // Source "transition/machine.ts":77:5
        Value::boolean({ let value=v_6f70656e5f5f37313734373438323136313936383435.clone(); *(v_7461726765744f70656e.read()).borrow_mut()=value.clone(); value });
        Value::Undefined
    }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).bool())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } });
    // Source "transition/machine.ts":85:7
    v_7072657061726174696f6e.initialize(Rc::new(std::cell::RefCell::new(Value::Json(Json::Null))));
    // Source "transition/machine.ts":87:9
    v_63616e63656c5072657061726174696f6e.initialize({  let v_7072657061726174696f6e = v_7072657061726174696f6e.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
        // Source "transition/machine.ts":88:5
        { let value = Value::Json(Json::Null); *(v_7072657061726174696f6e.read()).borrow_mut() = value; }
        Value::Undefined
    })) });
    // Source "transition/machine.ts":90:9
    v_6973507265706172696e67.initialize({  let v_6472697665725f5f66643335663962313031386337303063 = v_6472697665725f5f66643335663962313031386337303063.clone(); let v_7461726765744f70656e = v_7461726765744f70656e.clone(); let v_7465726d696e616c = v_7465726d696e616c.clone(); let v_7072657061726174696f6e = v_7072657061726174696f6e.clone(); let call:Rc<dyn Fn(Value)->bool>=Rc::new(move |argument_0: Value| -> bool {
        let v_617474656d70745f5f65383963313531626665626564653232: Value = argument_0;
        // Source "transition/machine.ts":91:5
        return { let pui_native_247={ let pui_native_249={ let pui_native_251=!({ let value=(v_7465726d696e616c.read()).borrow().clone(); value }); if (pui_native_251) {{ let value=(v_7461726765744f70656e.read()).borrow().clone(); value }} else {pui_native_251} }; if (pui_native_249) {(Value::boolean(strict_equal(&({ let value = (v_7072657061726174696f6e.read()).borrow().clone(); value }), &(v_617474656d70745f5f65383963313531626665626564653232.clone())))).bool()} else {pui_native_249} }; if (pui_native_247) {(Value::boolean(strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) }), &(Value::string("preparing"))))).bool()} else {pui_native_247} };
    }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call(arg(&arguments,0)))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } });
    // Source "transition/machine.ts":93:9
    v_66696e6973685072657061726174696f6e.initialize({  let v_6472697665725f5f66643335663962313031386337303063 = v_6472697665725f5f66643335663962313031386337303063.clone(); let v_7461726765744f70656e = v_7461726765744f70656e.clone(); let v_766965774d6f756e746564 = v_766965774d6f756e746564.clone(); let v_61637469766550726573656e746174696f6e = v_61637469766550726573656e746174696f6e.clone(); let v_7465726d696e616c = v_7465726d696e616c.clone(); let v_7072657061726174696f6e = v_7072657061726174696f6e.clone(); let v_6973507265706172696e67 = v_6973507265706172696e67.clone(); let v_7365745374617465 = v_7365745374617465.clone(); let v_61726d436f6d706c6574696f6e = v_61726d436f6d706c6574696f6e.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
        let v_617474656d70745f5f37663761613536363065333535363562: Value = arg(&arguments, 0);
        // Source "transition/machine.ts":94:5
        if { let pui_native_257={ let pui_native_259={ let pui_native_261={ let pui_native_263=!((v_6973507265706172696e67.read().call)(v_617474656d70745f5f37663761613536363065333535363562.clone())); if !(pui_native_263) {!(((v_617474656d70745f5f37663761613536363065333535363562.clone()).member("presentRequested", false)).bool())} else {pui_native_263} }; if !(pui_native_261) {!({ let value=(v_766965774d6f756e746564.read()).borrow().clone(); value })} else {pui_native_261} }; if !(pui_native_259) {!(((v_617474656d70745f5f37663761613536363065333535363562.clone()).member("ready", false)).bool())} else {pui_native_259} }; if !(pui_native_257) {((v_617474656d70745f5f37663761613536363065333535363562.clone()).member("finishing", false)).bool()} else {pui_native_257} } {
            // Source "transition/machine.ts":101:7
            return Value::Undefined;
        }
        // Source "transition/machine.ts":102:5
        Value::boolean((set_member(v_617474656d70745f5f37663761613536363065333535363562.clone(), "finishing", Value::boolean(true))).bool());
        // Source "transition/machine.ts":103:5
        if !(((v_617474656d70745f5f37663761613536363065333535363562.clone()).member("animate", false)).bool()) {
            // Source "transition/machine.ts":104:7
            { let value = Value::Json(Json::Null); *(v_7072657061726174696f6e.read()).borrow_mut() = value; }
            // Source "transition/machine.ts":105:7
            v_7365745374617465.read().call_authored(vec![Value::string("entered")]);
            // Source "transition/machine.ts":106:7
            return Value::Undefined;
        }
        // Source "transition/machine.ts":108:5
        { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("emit", false); callable.call_authored(vec![Value::string("beforeEnter")]) };
        // Source "transition/machine.ts":109:5
        if { let pui_native_265=!((v_6973507265706172696e67.read().call)(v_617474656d70745f5f37663761613536363065333535363562.clone())); if !(pui_native_265) {!({ let value=(v_766965774d6f756e746564.read()).borrow().clone(); value })} else {pui_native_265} } {
            // Source "transition/machine.ts":109:48
            return Value::Undefined;
        }
        // Source "transition/machine.ts":110:11
        let v_6672616d655f5f34353661353231383238383763386233 = v_7365745374617465.read().call_authored(vec![Value::string("entering")]);
        // Source "transition/machine.ts":111:5
        if ({ let left = { let left = { let left = { let left = v_6672616d655f5f34353661353231383238383763386233.clone(); if left.truthy() { Value::boolean((Value::boolean(strict_equal(&({ let value = (v_61637469766550726573656e746174696f6e.read()).borrow().clone(); value }), &(v_6672616d655f5f34353661353231383238383763386233.clone())))).bool()) } else { left } }; if left.truthy() { Value::boolean(!({ let value=(v_7465726d696e616c.read()).borrow().clone(); value })) } else { left } }; if left.truthy() { Value::boolean({ let value=(v_766965774d6f756e746564.read()).borrow().clone(); value }) } else { left } }; if left.truthy() { Value::boolean((Value::boolean(strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) }), &(Value::string("entering"))))).bool()) } else { left } }).truthy() {
            // Source "transition/machine.ts":118:7
            if (Value::boolean(strict_equal(&({ let value = (v_7072657061726174696f6e.read()).borrow().clone(); value }), &(v_617474656d70745f5f37663761613536363065333535363562.clone())))).bool() {
                // Source "transition/machine.ts":118:36
                { let value = Value::Json(Json::Null); *(v_7072657061726174696f6e.read()).borrow_mut() = value; }
            }
            // Source "transition/machine.ts":119:7
            v_61726d436f6d706c6574696f6e.read().call_authored(vec![Value::string("entering")]);
            // Source "transition/machine.ts":120:7
            return Value::Undefined;
        }
        // Source "transition/machine.ts":122:5
        if { let pui_native_273={ let pui_native_275={ let pui_native_277={ let pui_native_279=(Value::boolean(!strict_equal(&({ let value = (v_7072657061726174696f6e.read()).borrow().clone(); value }), &(v_617474656d70745f5f37663761613536363065333535363562.clone())))).bool(); if !(pui_native_279) {{ let value=(v_7465726d696e616c.read()).borrow().clone(); value }} else {pui_native_279} }; if !(pui_native_277) {!({ let value=(v_7461726765744f70656e.read()).borrow().clone(); value })} else {pui_native_277} }; if !(pui_native_275) {!({ let value=(v_766965774d6f756e746564.read()).borrow().clone(); value })} else {pui_native_275} }; if !(pui_native_273) {(Value::boolean(!strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) }), &(Value::string("entering"))))).bool()} else {pui_native_273} } {
            // Source "transition/machine.ts":129:7
            if (Value::boolean(strict_equal(&({ let value = (v_7072657061726174696f6e.read()).borrow().clone(); value }), &(v_617474656d70745f5f37663761613536363065333535363562.clone())))).bool() {
                // Source "transition/machine.ts":129:36
                { let value = Value::Json(Json::Null); *(v_7072657061726174696f6e.read()).borrow_mut() = value; }
            }
            // Source "transition/machine.ts":130:7
            return Value::Undefined;
        }
        // Source "transition/machine.ts":132:5
        { let value = Value::Json(Json::Null); *(v_7072657061726174696f6e.read()).borrow_mut() = value; }
        // Source "transition/machine.ts":133:5
        v_61726d436f6d706c6574696f6e.read().call_authored(vec![Value::string("entering")]);
        Value::Undefined
    })) });
    // Source "transition/machine.ts":136:9
    v_626567696e5072657061726174696f6e.initialize({  let v_6472697665725f5f66643335663962313031386337303063 = v_6472697665725f5f66643335663962313031386337303063.clone(); let v_717565756564496e74656e74 = v_717565756564496e74656e74.clone(); let v_6f7065726174696f6e56657273696f6e = v_6f7065726174696f6e56657273696f6e.clone(); let v_63757272656e744f7065726174696f6e = v_63757272656e744f7065726174696f6e.clone(); let v_7072657061726174696f6e = v_7072657061726174696f6e.clone(); let v_6973507265706172696e67 = v_6973507265706172696e67.clone(); let v_66696e6973685072657061726174696f6e = v_66696e6973685072657061726174696f6e.clone(); let v_696e76616c6964617465436f6d706c6574696f6e = v_696e76616c6964617465436f6d706c6574696f6e.clone(); let v_7365745374617465 = v_7365745374617465.clone(); let call:Rc<dyn Fn(bool)->Value>=Rc::new(move |argument_0: bool| -> Value {
        let v_616e696d617465: bool = argument_0;
        // Source "transition/machine.ts":137:11
        let v_6f7065726174696f6e5f5f36663665663534323535383538653230: f64 = { let cell=v_6f7065726174696f6e56657273696f6e.read(); let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; value };
        // Source "transition/machine.ts":138:5
        v_696e76616c6964617465436f6d706c6574696f6e.read().call_authored(vec![]);
        // Source "transition/machine.ts":139:5
        if !((v_63757272656e744f7065726174696f6e.read().call)(v_6f7065726174696f6e5f5f36663665663534323535383538653230.clone())) {
            // Source "transition/machine.ts":139:39
            return Value::Undefined;
        }
        // Source "transition/machine.ts":140:5
        { let value = Value::Json(Json::Null); *(v_717565756564496e74656e74.read()).borrow_mut() = value; }
        // Source "transition/machine.ts":141:11
        let v_617474656d70745f5f31636334646465326433333236613731 = record(vec![("ready", Value::boolean(false)), ("finishing", Value::boolean(false)), ("animate", Value::boolean(v_616e696d617465.clone())), ("presentRequested", Value::boolean(false))]);
        // Source "transition/machine.ts":147:5
        { let value = v_617474656d70745f5f31636334646465326433333236613731.clone(); *(v_7072657061726174696f6e.read()).borrow_mut() = value; }
        // Source "transition/machine.ts":148:5
        v_7365745374617465.read().call_authored(vec![Value::string("preparing")]);
        // Source "transition/machine.ts":149:5
        if !((v_6973507265706172696e67.read().call)(v_617474656d70745f5f31636334646465326433333236613731.clone())) {
            // Source "transition/machine.ts":149:32
            return Value::Undefined;
        }
        // Source "transition/machine.ts":150:5
        { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("setViewPresent", false); callable.call_authored(vec![Value::boolean(true)]) };
        // Source "transition/machine.ts":151:5
        if !((v_6973507265706172696e67.read().call)(v_617474656d70745f5f31636334646465326433333236613731.clone())) {
            // Source "transition/machine.ts":151:32
            return Value::Undefined;
        }
        // Source "transition/machine.ts":152:5
        Value::boolean((set_member(v_617474656d70745f5f31636334646465326433333236613731.clone(), "presentRequested", Value::boolean(true))).bool());
        // Source "transition/machine.ts":153:5
        v_66696e6973685072657061726174696f6e.read().call_authored(vec![v_617474656d70745f5f31636334646465326433333236613731.clone()]);
        Value::Undefined
    }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).bool())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } });
    // Source "transition/machine.ts":156:9
    v_696e76616c6964617465436f6d706c6574696f6e.initialize({  let v_67656e65726174696f6e = v_67656e65726174696f6e.clone(); let v_61636b6e6f776c6564676564 = v_61636b6e6f776c6564676564.clone(); let v_61636b6e6f776c656467656d656e7443757272656e74 = v_61636b6e6f776c656467656d656e7443757272656e74.clone(); let v_61637469766550726573656e746174696f6e = v_61637469766550726573656e746174696f6e.clone(); let v_63616e63656c5461736b = v_63616e63656c5461736b.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
        // Source "transition/machine.ts":157:5
        Value::number({ let value={ let pui_native_287:f64={ let value=(v_67656e65726174696f6e.read()).borrow().clone(); value }; let pui_native_288:f64=1.0_f64; pui_native_287 + pui_native_288 }; *(v_67656e65726174696f6e.read()).borrow_mut()=value.clone(); value });
        // Source "transition/machine.ts":158:5
        { let value = Value::Json(Json::Null); *(v_61637469766550726573656e746174696f6e.read()).borrow_mut() = value; }
        // Source "transition/machine.ts":159:5
        Value::boolean({ let value=false; *(v_61636b6e6f776c6564676564.read()).borrow_mut()=value.clone(); value });
        // Source "transition/machine.ts":160:5
        { let value = Value::Json(Json::Null); *(v_61636b6e6f776c656467656d656e7443757272656e74.read()).borrow_mut() = value; }
        // Source "transition/machine.ts":161:5
        v_63616e63656c5461736b.read().call_authored(vec![]);
        Value::Undefined
    })) });
    // Source "transition/machine.ts":164:9
    v_7365745374617465.initialize({  let v_6472697665725f5f66643335663962313031386337303063 = v_6472697665725f5f66643335663962313031386337303063.clone(); let v_6f776e657245706f6368 = v_6f776e657245706f6368.clone(); let v_7068617365417474656d7074 = v_7068617365417474656d7074.clone(); let v_7265766973696f6e = v_7265766973696f6e.clone(); let v_7075626c697368696e67 = v_7075626c697368696e67.clone(); let v_7374616765645374617465 = v_7374616765645374617465.clone(); let v_61636b6e6f776c6564676564 = v_61636b6e6f776c6564676564.clone(); let v_61636b6e6f776c656467656d656e7443757272656e74 = v_61636b6e6f776c656467656d656e7443757272656e74.clone(); let v_696e76616c69644475726174696f6e = v_696e76616c69644475726174696f6e.clone(); let v_7075626c69636174696f6e4661696c6564 = v_7075626c69636174696f6e4661696c6564.clone(); let v_61637469766550726573656e746174696f6e = v_61637469766550726573656e746174696f6e.clone(); let v_7465726d696e616c = v_7465726d696e616c.clone(); let v_6f7065726174696f6e56657273696f6e = v_6f7065726174696f6e56657273696f6e.clone(); let v_63757272656e744f7065726174696f6e = v_63757272656e744f7065726174696f6e.clone(); let v_696e76616c6964617465436f6d706c6574696f6e = v_696e76616c6964617465436f6d706c6574696f6e.clone(); let v_7365745374617465 = v_7365745374617465.clone(); let v_61726d436f6d706c6574696f6e = v_61726d436f6d706c6574696f6e.clone(); let v_636f6d706c65746543757272656e74 = v_636f6d706c65746543757272656e74.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
        let v_73746174655f5f64353334633663303930383764366535: Value = arg(&arguments, 0);
        // Source "transition/machine.ts":165:11
        let v_706f6c6963795f5f66636135326335353533343539366364 = { let left = { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getCompletion", false); if callable.nullish() { Value::Undefined } else { callable.call_authored(vec![]) } }; if left.nullish() { Value::string("timer") } else { left } };
        // Source "transition/machine.ts":166:5
        if (Value::boolean(strict_equal(&(v_706f6c6963795f5f66636135326335353533343539366364.clone()), &(Value::string("timer"))))).bool() {
            // Source "transition/machine.ts":167:7
            { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("setState", false); callable.call_authored(vec![v_73746174655f5f64353334633663303930383764366535.clone()]) };
            // Source "transition/machine.ts":168:7
            return Value::Undefined;
        }
        // Source "transition/machine.ts":170:11
        let v_6d6f76696e67: bool = { let pui_native_291=(Value::boolean(strict_equal(&(v_73746174655f5f64353334633663303930383764366535.clone()), &(Value::string("entering"))))).bool(); if !(pui_native_291) {(Value::boolean(strict_equal(&(v_73746174655f5f64353334633663303930383764366535.clone()), &(Value::string("leaving"))))).bool()} else {pui_native_291} };
        // Source "transition/machine.ts":171:11
        let v_6475726174696f6e: f64 = if v_6d6f76696e67.clone() {({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getDuration", false); callable.call_authored(vec![v_73746174655f5f64353334633663303930383764366535.clone()]) }).num()} else {0.0_f64};
        // Source "transition/machine.ts":172:5
        Value::boolean({ let value={ let pui_native_297={ let pui_native_299=!((v_6475726174696f6e.clone()).is_finite()); if !(pui_native_299) {{ let pui_native_301:f64=v_6475726174696f6e.clone(); let pui_native_302:f64=0.0_f64; pui_native_301 < pui_native_302 }} else {pui_native_299} }; if !(pui_native_297) {{ let pui_native_303=v_6d6f76696e67.clone(); if (pui_native_303) {{ let pui_native_305:f64=v_6475726174696f6e.clone(); let pui_native_306:f64=((v_706f6c6963795f5f66636135326335353533343539366364.clone()).member("timeoutMs", false)).num(); pui_native_305 >= pui_native_306 }} else {pui_native_303} }} else {pui_native_297} }; *(v_696e76616c69644475726174696f6e.read()).borrow_mut()=value.clone(); value });
        // Source "transition/machine.ts":174:5
        Value::boolean({ let value=false; *(v_7075626c69636174696f6e4661696c6564.read()).borrow_mut()=value.clone(); value });
        // Source "transition/machine.ts":175:11
        let v_6672616d655f5f61623030633636313166333137363838 = freeze(record(vec![("revision", Value::number({ let cell=v_7265766973696f6e.read(); let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; value })), ("phase", v_73746174655f5f64353334633663303930383764366535.clone()), ("attempt", if (Value::boolean(v_6d6f76696e67.clone())).truthy() { freeze(record(vec![("ownerEpoch", Value::number({ let value=(v_6f776e657245706f6368.read()).borrow().clone(); value })), ("phaseAttempt", Value::number({ let cell=v_7068617365417474656d7074.read(); let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; value }))])) } else { Value::Json(Json::Null) }), ("completion", Value::string("presentation")), ("durationMs", Value::number(if { let pui_native_307=(v_6475726174696f6e.clone()).is_finite(); if (pui_native_307) {{ let pui_native_309:f64=v_6475726174696f6e.clone(); let pui_native_310:f64=0.0_f64; pui_native_309 >= pui_native_310 }} else {pui_native_307} } {v_6475726174696f6e.clone()} else {((v_706f6c6963795f5f66636135326335353533343539366364.clone()).member("timeoutMs", false)).num()})), ("timeoutMs", Value::number(((v_706f6c6963795f5f66636135326335353533343539366364.clone()).member("timeoutMs", false)).num()))]));
        // Source "transition/machine.ts":184:5
        { let value = if (Value::boolean(v_6d6f76696e67.clone())).truthy() { v_6672616d655f5f61623030633636313166333137363838.clone() } else { Value::Json(Json::Null) }; *(v_61637469766550726573656e746174696f6e.read()).borrow_mut() = value; }
        // Source "transition/machine.ts":185:5
        Value::boolean({ let value=false; *(v_61636b6e6f776c6564676564.read()).borrow_mut()=value.clone(); value });
        // Source "transition/machine.ts":186:11
        let v_6f7065726174696f6e5f5f38353163393436636338356331653965: f64 = { let value=(v_6f7065726174696f6e56657273696f6e.read()).borrow().clone(); value };
        // Source "transition/machine.ts":187:11
        let v_70726576696f75735374616765 = { let value = (v_7374616765645374617465.read()).borrow().clone(); value };
        // Source "transition/machine.ts":188:5
        { let value = v_73746174655f5f64353334633663303930383764366535.clone(); *(v_7374616765645374617465.read()).borrow_mut() = value; }
        // Source "transition/machine.ts":189:5
        Value::boolean({ let value=true; *(v_7075626c697368696e67.read()).borrow_mut()=value.clone(); value });
        // Source "transition/machine.ts":190:5
        match authored_finally(|| -> std::ops::ControlFlow<Value> {
                {
                    // Source "transition/machine.ts":191:7
                    match match catch_authored::<std::ops::ControlFlow<Value>>(|| {
                            // Source "transition/machine.ts":192:9
                            { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("publishPresentation", false); if callable.nullish() { Value::Undefined } else { callable.call_authored(vec![v_6672616d655f5f61623030633636313166333137363838.clone()]) } };
                            std::ops::ControlFlow::Continue(())
                        }) {
                            Ok(flow) => flow,
                            Err(_) => (|| -> std::ops::ControlFlow<Value> {
                                // Source "transition/machine.ts":194:9
                                Value::boolean({ let value=true; *(v_7075626c69636174696f6e4661696c6564.read()).borrow_mut()=value.clone(); value });
                                std::ops::ControlFlow::Continue(())
                            })()
                        } {
                        std::ops::ControlFlow::Break(value) => return std::ops::ControlFlow::Break(value),
                        std::ops::ControlFlow::Continue(()) => {}
                    }
                    // Source "transition/machine.ts":196:13
                    let v_77616974696e674f6e53616d65417474656d7074: bool = { let pui_native_311={ let pui_native_313={ let pui_native_315=v_6d6f76696e67.clone(); if (pui_native_315) {(Value::boolean(strict_equal(&({ let value = (v_61637469766550726573656e746174696f6e.read()).borrow().clone(); value }), &(v_6672616d655f5f61623030633636313166333137363838.clone())))).bool()} else {pui_native_315} }; if (pui_native_313) {(Value::boolean(strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getInterrupt", false); callable.call_authored(vec![]) }), &(Value::string("wait"))))).bool()} else {pui_native_313} }; if (pui_native_311) {!({ let value=(v_7465726d696e616c.read()).borrow().clone(); value })} else {pui_native_311} };
                    // Source "transition/machine.ts":198:7
                    if { let pui_native_321={ let pui_native_323=!((v_63757272656e744f7065726174696f6e.read().call)(v_6f7065726174696f6e5f5f38353163393436636338356331653965.clone())); if (pui_native_323) {!(v_77616974696e674f6e53616d65417474656d7074.clone())} else {pui_native_323} }; if !(pui_native_321) {{ let pui_native_325=v_6d6f76696e67.clone(); if (pui_native_325) {(Value::boolean(!strict_equal(&({ let value = (v_61637469766550726573656e746174696f6e.read()).borrow().clone(); value }), &(v_6672616d655f5f61623030633636313166333137363838.clone())))).bool()} else {pui_native_325} }} else {pui_native_321} } {
                        // Source "transition/machine.ts":204:9
                        if { let pui_native_329={ let pui_native_331=!({ let value=(v_7465726d696e616c.read()).borrow().clone(); value }); if (pui_native_331) {v_6d6f76696e67.clone()} else {pui_native_331} }; if (pui_native_329) {(Value::boolean(strict_equal(&({ let value = (v_61637469766550726573656e746174696f6e.read()).borrow().clone(); value }), &(v_6672616d655f5f61623030633636313166333137363838.clone())))).bool()} else {pui_native_329} } {
                            // Source "transition/machine.ts":205:17
                            let v_7265706169724f7065726174696f6e: f64 = { let value=(v_6f7065726174696f6e56657273696f6e.read()).borrow().clone(); value };
                            // Source "transition/machine.ts":206:11
                            v_696e76616c6964617465436f6d706c6574696f6e.read().call_authored(vec![]);
                            // Source "transition/machine.ts":207:11
                            if !((v_63757272656e744f7065726174696f6e.read().call)(v_7265706169724f7065726174696f6e.clone())) {
                                // Source "transition/machine.ts":207:51
                                return std::ops::ControlFlow::Break(Value::Undefined);
                            }
                            // Source "transition/machine.ts":208:17
                            let v_61637475616c = { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) };
                            // Source "transition/machine.ts":209:17
                            let v_7265706169726564 = v_7365745374617465.read().call_authored(vec![v_61637475616c.clone()]);
                            // Source "transition/machine.ts":210:11
                            if ({ let left = { let left = v_7265706169726564.clone(); if left.truthy() { Value::boolean((Value::boolean(strict_equal(&({ let value = (v_61637469766550726573656e746174696f6e.read()).borrow().clone(); value }), &(v_7265706169726564.clone())))).bool()) } else { left } }; if left.truthy() { Value::boolean({ let pui_native_337=(Value::boolean(strict_equal(&(v_61637475616c.clone()), &(Value::string("entering"))))).bool(); if !(pui_native_337) {(Value::boolean(strict_equal(&(v_61637475616c.clone()), &(Value::string("leaving"))))).bool()} else {pui_native_337} }) } else { left } }).truthy() {
                                // Source "transition/machine.ts":215:13
                                v_61726d436f6d706c6574696f6e.read().call_authored(vec![v_61637475616c.clone()]);
                            }
                        }
                        // Source "transition/machine.ts":217:9
                        return std::ops::ControlFlow::Break(Value::Undefined);
                    }
                    // Source "transition/machine.ts":219:7
                    { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("setState", false); callable.call_authored(vec![v_73746174655f5f64353334633663303930383764366535.clone()]) };
                    std::ops::ControlFlow::Continue(())
                }
            }, || -> std::ops::ControlFlow<Value> {
                // Source "transition/machine.ts":221:7
                { let value = v_70726576696f75735374616765.clone(); *(v_7374616765645374617465.read()).borrow_mut() = value; }
                // Source "transition/machine.ts":222:7
                Value::boolean({ let value=(Value::boolean(!strict_equal(&(v_70726576696f75735374616765.clone()), &(Value::Json(Json::Null))))).bool(); *(v_7075626c697368696e67.read()).borrow_mut()=value.clone(); value });
                std::ops::ControlFlow::Continue(())
            }) {
            std::ops::ControlFlow::Break(value) => return value,
            std::ops::ControlFlow::Continue(()) => {}
        }
        // Source "transition/machine.ts":224:5
        if ({ let left = { let left = { let left = { let left = Value::boolean({ let pui_native_345={ let pui_native_347={ let pui_native_349={ let pui_native_351=v_6d6f76696e67.clone(); if (pui_native_351) {{ let value=(v_61636b6e6f776c6564676564.read()).borrow().clone(); value }} else {pui_native_351} }; if (pui_native_349) {(Value::boolean(strict_equal(&({ let value = (v_61637469766550726573656e746174696f6e.read()).borrow().clone(); value }), &(v_6672616d655f5f61623030633636313166333137363838.clone())))).bool()} else {pui_native_349} }; if (pui_native_347) {!({ let value=(v_7465726d696e616c.read()).borrow().clone(); value })} else {pui_native_347} }; if (pui_native_345) {(Value::boolean(strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) }), &(v_73746174655f5f64353334633663303930383764366535.clone())))).bool()} else {pui_native_345} }); if left.truthy() { { let callable = { let value = (v_61636b6e6f776c656467656d656e7443757272656e74.read()).borrow().clone(); value }; if callable.nullish() { Value::Undefined } else { callable.call_authored(vec![]) } } } else { left } }; if left.truthy() { Value::boolean((Value::boolean(strict_equal(&({ let value = (v_61637469766550726573656e746174696f6e.read()).borrow().clone(); value }), &(v_6672616d655f5f61623030633636313166333137363838.clone())))).bool()) } else { left } }; if left.truthy() { Value::boolean(!({ let value=(v_7465726d696e616c.read()).borrow().clone(); value })) } else { left } }; if left.truthy() { Value::boolean((Value::boolean(strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) }), &(v_73746174655f5f64353334633663303930383764366535.clone())))).bool()) } else { left } }).truthy() {
            // Source "transition/machine.ts":235:7
            Value::boolean((v_636f6d706c65746543757272656e74.read().call)(true));
        }
        // Source "transition/machine.ts":236:5
        return v_6672616d655f5f61623030633636313166333137363838.clone();
    })) });
    // Source "transition/machine.ts":239:9
    v_736574746c6550726573656e746174696f6e.initialize({  let v_6472697665725f5f66643335663962313031386337303063 = v_6472697665725f5f66643335663962313031386337303063.clone(); let v_73616d65417474656d7074 = v_73616d65417474656d7074.clone(); let v_636f6d706c65746543757272656e74 = v_636f6d706c65746543757272656e74.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
        let v_6672616d655f5f65306261336133333835653030663764: Value = arg(&arguments, 0);
        let v_6f7574636f6d655f5f64343164636237656439343630643237: Value = arg(&arguments, 1);
        // Source "transition/machine.ts":240:5
        if { let pui_native_361=!(((v_6672616d655f5f65306261336133333835653030663764.clone()).member("attempt", false)).truthy()); if !(pui_native_361) {!((v_73616d65417474656d7074.read().call)((v_6672616d655f5f65306261336133333835653030663764.clone()).member("attempt", false)))} else {pui_native_361} } {
            // Source "transition/machine.ts":240:56
            return Value::Undefined;
        }
        // Source "transition/machine.ts":241:5
        match match catch_authored::<std::ops::ControlFlow<Value>>(|| {
                // Source "transition/machine.ts":242:7
                { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("settlePresentation", false); if callable.nullish() { Value::Undefined } else { callable.call_authored(vec![v_6f7574636f6d655f5f64343164636237656439343630643237.clone()]) } };
                std::ops::ControlFlow::Continue(())
            }) {
                Ok(flow) => flow,
                Err(_) => (|| -> std::ops::ControlFlow<Value> {
                    std::ops::ControlFlow::Continue(())
                })()
            } {
            std::ops::ControlFlow::Break(value) => return value,
            std::ops::ControlFlow::Continue(()) => {}
        }
        // Source "transition/machine.ts":246:5
        if (v_73616d65417474656d7074.read().call)((v_6672616d655f5f65306261336133333835653030663764.clone()).member("attempt", false)) {
            // Source "transition/machine.ts":246:37
            Value::boolean((v_636f6d706c65746543757272656e74.read().call)(true));
        }
        Value::Undefined
    })) });
    // Source "transition/machine.ts":249:9
    v_61726d436f6d706c6574696f6e.initialize({  let v_6472697665725f5f66643335663962313031386337303063 = v_6472697665725f5f66643335663962313031386337303063.clone(); let v_70656e64696e675461736b = v_70656e64696e675461736b.clone(); let v_67656e65726174696f6e = v_67656e65726174696f6e.clone(); let v_696e76616c69644475726174696f6e = v_696e76616c69644475726174696f6e.clone(); let v_7075626c69636174696f6e4661696c6564 = v_7075626c69636174696f6e4661696c6564.clone(); let v_61637469766550726573656e746174696f6e = v_61637469766550726573656e746174696f6e.clone(); let v_73616d65417474656d7074 = v_73616d65417474656d7074.clone(); let v_696e76616c6964617465436f6d706c6574696f6e = v_696e76616c6964617465436f6d706c6574696f6e.clone(); let v_736574746c6550726573656e746174696f6e = v_736574746c6550726573656e746174696f6e.clone(); let v_636f6d706c65746543757272656e74 = v_636f6d706c65746543757272656e74.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
        let v_73746174655f5f64396337623137333832626265393732: LexicalBinding<Value> = lexical_binding();
        v_73746174655f5f64396337623137333832626265393732.initialize(arg(&arguments, 0));
        let v_6672616d655f5f66346230376530643965376338646131: LexicalBinding<Value> = lexical_binding();
        let v_61637469766547656e65726174696f6e: LexicalBinding<f64> = lexical_binding();
        // Source "transition/machine.ts":250:11
        v_6672616d655f5f66346230376530643965376338646131.initialize({ let value = (v_61637469766550726573656e746174696f6e.read()).borrow().clone(); value });
        // Source "transition/machine.ts":251:5
        if ((v_6672616d655f5f66346230376530643965376338646131.read()).member("attempt", true)).truthy() {
            // Source "transition/machine.ts":252:7
            if { let value=(v_696e76616c69644475726174696f6e.read()).borrow().clone(); value } {
                // Source "transition/machine.ts":253:9
                v_736574746c6550726573656e746174696f6e.read().call_authored(vec![v_6672616d655f5f66346230376530643965376338646131.read(), Value::string("invalid-policy")]);
                // Source "transition/machine.ts":254:9
                return Value::Undefined;
            }
            // Source "transition/machine.ts":256:7
            if { let value=(v_7075626c69636174696f6e4661696c6564.read()).borrow().clone(); value } {
                // Source "transition/machine.ts":257:9
                v_736574746c6550726573656e746174696f6e.read().call_authored(vec![v_6672616d655f5f66346230376530643965376338646131.read(), Value::string("projection-failed")]);
                // Source "transition/machine.ts":258:9
                return Value::Undefined;
            }
            // Source "transition/machine.ts":260:7
            if { let pui_native_363=((v_6672616d655f5f66346230376530643965376338646131.read()).member("durationMs", false)).num(); let pui_native_364=0.0_f64; (pui_native_363==pui_native_364) } {
                // Source "transition/machine.ts":261:9
                v_736574746c6550726573656e746174696f6e.read().call_authored(vec![v_6672616d655f5f66346230376530643965376338646131.read(), Value::string("zero-duration")]);
                // Source "transition/machine.ts":262:9
                return Value::Undefined;
            }
            // Source "transition/machine.ts":264:7
            match match catch_authored::<std::ops::ControlFlow<Value>>(|| {
                    // Source "transition/machine.ts":265:15
                    let v_7461736b5f5f65653737356166623033303033623638 = { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("schedule", false); callable.call_authored(vec![Value::number(((v_6672616d655f5f66346230376530643965376338646131.read()).member("timeoutMs", false)).num()), {  let v_70656e64696e675461736b = v_70656e64696e675461736b.clone(); let v_73616d65417474656d7074 = v_73616d65417474656d7074.clone(); let v_736574746c6550726573656e746174696f6e = v_736574746c6550726573656e746174696f6e.clone(); let v_6672616d655f5f66346230376530643965376338646131 = v_6672616d655f5f66346230376530643965376338646131.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
                        // Source "transition/machine.ts":266:11
                        if { let pui_native_365=!(((v_6672616d655f5f66346230376530643965376338646131.read()).member("attempt", false)).truthy()); if !(pui_native_365) {!((v_73616d65417474656d7074.read().call)((v_6672616d655f5f66346230376530643965376338646131.read()).member("attempt", false)))} else {pui_native_365} } {
                            // Source "transition/machine.ts":266:62
                            return Value::Undefined;
                        }
                        // Source "transition/machine.ts":267:11
                        { let value = Value::Json(Json::Null); *(v_70656e64696e675461736b.read()).borrow_mut() = value; }
                        // Source "transition/machine.ts":268:11
                        v_736574746c6550726573656e746174696f6e.read().call_authored(vec![v_6672616d655f5f66346230376530643965376338646131.read(), Value::string("deadline")]);
                        Value::Undefined
                    })) }]) };
                    // Source "transition/machine.ts":270:9
                    if (v_73616d65417474656d7074.read().call)((v_6672616d655f5f66346230376530643965376338646131.read()).member("attempt", false)) {
                        // Source "transition/machine.ts":270:41
                        { let value = v_7461736b5f5f65653737356166623033303033623638.clone(); *(v_70656e64696e675461736b.read()).borrow_mut() = value; }
                    } else {
                        // Source "transition/machine.ts":272:11
                        match match catch_authored::<std::ops::ControlFlow<Value>>(|| {
                                // Source "transition/machine.ts":273:13
                                { let v_7075695f6e61746976655f333637 = v_7461736b5f5f65653737356166623033303033623638.clone(); (v_7075695f6e61746976655f333637.clone()).member("cancel", false).call_authored(vec![]) };
                                std::ops::ControlFlow::Continue(())
                            }) {
                                Ok(flow) => flow,
                                Err(_) => (|| -> std::ops::ControlFlow<Value> {
                                    std::ops::ControlFlow::Continue(())
                                })()
                            } {
                            std::ops::ControlFlow::Break(value) => return std::ops::ControlFlow::Break(value),
                            std::ops::ControlFlow::Continue(()) => {}
                        }
                    }
                    std::ops::ControlFlow::Continue(())
                }) {
                    Ok(flow) => flow,
                    Err(_) => (|| -> std::ops::ControlFlow<Value> {
                        // Source "transition/machine.ts":277:9
                        v_736574746c6550726573656e746174696f6e.read().call_authored(vec![v_6672616d655f5f66346230376530643965376338646131.read(), Value::string("scheduler-failed")]);
                        std::ops::ControlFlow::Continue(())
                    })()
                } {
                std::ops::ControlFlow::Break(value) => return value,
                std::ops::ControlFlow::Continue(()) => {}
            }
            // Source "transition/machine.ts":279:7
            return Value::Undefined;
        }
        // Source "transition/machine.ts":281:5
        v_696e76616c6964617465436f6d706c6574696f6e.read().call_authored(vec![]);
        // Source "transition/machine.ts":282:11
        v_61637469766547656e65726174696f6e.initialize({ let value=(v_67656e65726174696f6e.read()).borrow().clone(); value });
        // Source "transition/machine.ts":283:5
        { let value = { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("schedule", false); callable.call_authored(vec![Value::number(({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getDuration", false); callable.call_authored(vec![v_73746174655f5f64396337623137333832626265393732.read()]) }).num()), {  let v_6472697665725f5f66643335663962313031386337303063 = v_6472697665725f5f66643335663962313031386337303063.clone(); let v_70656e64696e675461736b = v_70656e64696e675461736b.clone(); let v_67656e65726174696f6e = v_67656e65726174696f6e.clone(); let v_636f6d706c65746543757272656e74 = v_636f6d706c65746543757272656e74.clone(); let v_73746174655f5f64396337623137333832626265393732 = v_73746174655f5f64396337623137333832626265393732.clone(); let v_61637469766547656e65726174696f6e = v_61637469766547656e65726174696f6e.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
            // Source "transition/machine.ts":284:7
            if { let pui_native_368={ let pui_native_370=v_61637469766547656e65726174696f6e.read(); let pui_native_371={ let value=(v_67656e65726174696f6e.read()).borrow().clone(); value }; !(pui_native_370==pui_native_371) }; if !(pui_native_368) {(Value::boolean(!strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) }), &(v_73746174655f5f64396337623137333832626265393732.read())))).bool()} else {pui_native_368} } {
                // Source "transition/machine.ts":284:75
                return Value::Undefined;
            }
            // Source "transition/machine.ts":285:7
            { let value = Value::Json(Json::Null); *(v_70656e64696e675461736b.read()).borrow_mut() = value; }
            // Source "transition/machine.ts":286:7
            Value::boolean((v_636f6d706c65746543757272656e74.read().call)(true));
            Value::Undefined
        })) }]) }; *(v_70656e64696e675461736b.read()).borrow_mut() = value; }
        Value::Undefined
    })) });
    // Source "transition/machine.ts":290:9
    v_626567696e456e746572.initialize({  let v_6472697665725f5f66643335663962313031386337303063 = v_6472697665725f5f66643335663962313031386337303063.clone(); let v_7461726765744f70656e = v_7461726765744f70656e.clone(); let v_766965774d6f756e746564 = v_766965774d6f756e746564.clone(); let v_717565756564496e74656e74 = v_717565756564496e74656e74.clone(); let v_61637469766550726573656e746174696f6e = v_61637469766550726573656e746174696f6e.clone(); let v_7465726d696e616c = v_7465726d696e616c.clone(); let v_6f7065726174696f6e56657273696f6e = v_6f7065726174696f6e56657273696f6e.clone(); let v_7374617274696e67 = v_7374617274696e67.clone(); let v_63757272656e744f7065726174696f6e = v_63757272656e744f7065726174696f6e.clone(); let v_626567696e5072657061726174696f6e = v_626567696e5072657061726174696f6e.clone(); let v_696e76616c6964617465436f6d706c6574696f6e = v_696e76616c6964617465436f6d706c6574696f6e.clone(); let v_7365745374617465 = v_7365745374617465.clone(); let v_61726d436f6d706c6574696f6e = v_61726d436f6d706c6574696f6e.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
        let v_636f6c64: Value = { let argument = arg(&arguments, 0); if matches!(&argument, Value::Undefined) { Value::boolean(true) } else { argument } };
        let v_6f7065726174696f6e5f5f66383164306436363335643536616438: LexicalBinding<Value> = lexical_binding();
        // Source "transition/machine.ts":291:5
        if { let pui_native_374={ let value=(v_7465726d696e616c.read()).borrow().clone(); value }; if !(pui_native_374) {!({ let value=(v_7461726765744f70656e.read()).borrow().clone(); value })} else {pui_native_374} } {
            // Source "transition/machine.ts":291:34
            return Value::Undefined;
        }
        // Source "transition/machine.ts":292:5
        if { let pui_native_376=(Value::boolean(strict_equal(&(({ let value = (v_7374617274696e67.read()).borrow().clone(); value }).member("kind", true)), &(Value::string("enter"))))).bool(); if (pui_native_376) {(v_63757272656e744f7065726174696f6e.read().call)((({ let value = (v_7374617274696e67.read()).borrow().clone(); value }).member("version", false)).num())} else {pui_native_376} } {
            // Source "transition/machine.ts":292:75
            return Value::Undefined;
        }
        // Source "transition/machine.ts":293:5
        if ({ let left = Value::boolean((v_636f6c64.clone()).bool()); if left.truthy() { { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("requiresColdPreparation", false); if callable.nullish() { Value::Undefined } else { callable.call_authored(vec![]) } } } else { left } }).truthy() {
            // Source "transition/machine.ts":294:7
            (v_626567696e5072657061726174696f6e.read().call)(true);
            // Source "transition/machine.ts":295:7
            return Value::Undefined;
        }
        // Source "transition/machine.ts":297:11
        v_6f7065726174696f6e5f5f66383164306436363335643536616438.initialize(record(vec![("kind", Value::string("enter")), ("version", Value::number({ let cell=v_6f7065726174696f6e56657273696f6e.read(); let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; value }))]));
        // Source "transition/machine.ts":298:5
        { let value = v_6f7065726174696f6e5f5f66383164306436363335643536616438.read(); *(v_7374617274696e67.read()).borrow_mut() = value; }
        // Source "transition/machine.ts":299:11
        let v_63757272656e745f5f39306533386366376136623065643165 = {  let v_7461726765744f70656e = v_7461726765744f70656e.clone(); let v_63757272656e744f7065726174696f6e = v_63757272656e744f7065726174696f6e.clone(); let v_6f7065726174696f6e5f5f66383164306436363335643536616438 = v_6f7065726174696f6e5f5f66383164306436363335643536616438.clone(); let call:Rc<dyn Fn()->bool>=Rc::new(move || -> bool {
            // Source "transition/machine.ts":299:27
            return { let pui_native_380=(v_63757272656e744f7065726174696f6e.read().call)(((v_6f7065726174696f6e5f5f66383164306436363335643536616438.read()).member("version", false)).num()); if (pui_native_380) {{ let value=(v_7461726765744f70656e.read()).borrow().clone(); value }} else {pui_native_380} };
        }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } };
        // Source "transition/machine.ts":300:5
        match authored_finally(|| -> std::ops::ControlFlow<Value> {
                {
                    // Source "transition/machine.ts":301:7
                    { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("setViewPresent", false); callable.call_authored(vec![Value::boolean(true)]) };
                    // Source "transition/machine.ts":302:7
                    if { let pui_native_382=!((v_63757272656e745f5f39306533386366376136623065643165.call)()); if !(pui_native_382) {!({ let value=(v_766965774d6f756e746564.read()).borrow().clone(); value })} else {pui_native_382} } {
                        // Source "transition/machine.ts":302:39
                        return std::ops::ControlFlow::Break(Value::Undefined);
                    }
                    // Source "transition/machine.ts":303:7
                    { let value = Value::Json(Json::Null); *(v_717565756564496e74656e74.read()).borrow_mut() = value; }
                    // Source "transition/machine.ts":304:7
                    { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("emit", false); callable.call_authored(vec![Value::string("beforeEnter")]) };
                    // Source "transition/machine.ts":305:7
                    if { let pui_native_384=!((v_63757272656e745f5f39306533386366376136623065643165.call)()); if !(pui_native_384) {!({ let value=(v_766965774d6f756e746564.read()).borrow().clone(); value })} else {pui_native_384} } {
                        // Source "transition/machine.ts":305:39
                        return std::ops::ControlFlow::Break(Value::Undefined);
                    }
                    // Source "transition/machine.ts":306:7
                    v_696e76616c6964617465436f6d706c6574696f6e.read().call_authored(vec![]);
                    // Source "transition/machine.ts":307:7
                    if !((v_63757272656e745f5f39306533386366376136623065643165.call)()) {
                        // Source "transition/machine.ts":307:23
                        return std::ops::ControlFlow::Break(Value::Undefined);
                    }
                    // Source "transition/machine.ts":308:13
                    let v_6672616d655f5f35393431623366333864646461646366 = v_7365745374617465.read().call_authored(vec![Value::string("entering")]);
                    // Source "transition/machine.ts":309:7
                    if ({ let left = { let left = { let left = { let left = { let left = v_6672616d655f5f35393431623366333864646461646366.clone(); if left.truthy() { Value::boolean((Value::boolean(strict_equal(&({ let value = (v_61637469766550726573656e746174696f6e.read()).borrow().clone(); value }), &(v_6672616d655f5f35393431623366333864646461646366.clone())))).bool()) } else { left } }; if left.truthy() { Value::boolean((Value::boolean(strict_equal(&(({ let value = (v_61637469766550726573656e746174696f6e.read()).borrow().clone(); value }).member("phase", true)), &(Value::string("entering"))))).bool()) } else { left } }; if left.truthy() { Value::boolean(!({ let value=(v_7465726d696e616c.read()).borrow().clone(); value })) } else { left } }; if left.truthy() { Value::boolean({ let value=(v_766965774d6f756e746564.read()).borrow().clone(); value }) } else { left } }; if left.truthy() { Value::boolean((Value::boolean(strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) }), &(Value::string("entering"))))).bool()) } else { left } }).truthy() {
                        // Source "transition/machine.ts":317:9
                        v_61726d436f6d706c6574696f6e.read().call_authored(vec![Value::string("entering")]);
                        // Source "transition/machine.ts":318:9
                        return std::ops::ControlFlow::Break(Value::Undefined);
                    }
                    // Source "transition/machine.ts":320:7
                    if { let pui_native_392={ let pui_native_394=!((v_63757272656e745f5f39306533386366376136623065643165.call)()); if !(pui_native_394) {!({ let value=(v_766965774d6f756e746564.read()).borrow().clone(); value })} else {pui_native_394} }; if !(pui_native_392) {(Value::boolean(!strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) }), &(Value::string("entering"))))).bool()} else {pui_native_392} } {
                        // Source "transition/machine.ts":320:75
                        return std::ops::ControlFlow::Break(Value::Undefined);
                    }
                    // Source "transition/machine.ts":321:7
                    v_61726d436f6d706c6574696f6e.read().call_authored(vec![Value::string("entering")]);
                    std::ops::ControlFlow::Continue(())
                }
            }, || -> std::ops::ControlFlow<Value> {
                // Source "transition/machine.ts":323:7
                if (Value::boolean(strict_equal(&({ let value = (v_7374617274696e67.read()).borrow().clone(); value }), &(v_6f7065726174696f6e5f5f66383164306436363335643536616438.read())))).bool() {
                    // Source "transition/machine.ts":323:35
                    { let value = Value::Json(Json::Null); *(v_7374617274696e67.read()).borrow_mut() = value; }
                }
                std::ops::ControlFlow::Continue(())
            }) {
            std::ops::ControlFlow::Break(value) => return value,
            std::ops::ControlFlow::Continue(()) => {}
        }
        Value::Undefined
    })) });
    // Source "transition/machine.ts":327:9
    v_626567696e4c65617665.initialize({  let v_6472697665725f5f66643335663962313031386337303063 = v_6472697665725f5f66643335663962313031386337303063.clone(); let v_7461726765744f70656e = v_7461726765744f70656e.clone(); let v_717565756564496e74656e74 = v_717565756564496e74656e74.clone(); let v_61637469766550726573656e746174696f6e = v_61637469766550726573656e746174696f6e.clone(); let v_7465726d696e616c = v_7465726d696e616c.clone(); let v_6f7065726174696f6e56657273696f6e = v_6f7065726174696f6e56657273696f6e.clone(); let v_7374617274696e67 = v_7374617274696e67.clone(); let v_63757272656e744f7065726174696f6e = v_63757272656e744f7065726174696f6e.clone(); let v_696e76616c6964617465436f6d706c6574696f6e = v_696e76616c6964617465436f6d706c6574696f6e.clone(); let v_7365745374617465 = v_7365745374617465.clone(); let v_61726d436f6d706c6574696f6e = v_61726d436f6d706c6574696f6e.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
        let v_6f7065726174696f6e5f5f64396563393566323838326535633161: LexicalBinding<Value> = lexical_binding();
        // Source "transition/machine.ts":328:5
        if { let pui_native_400={ let value=(v_7465726d696e616c.read()).borrow().clone(); value }; if !(pui_native_400) {{ let value=(v_7461726765744f70656e.read()).borrow().clone(); value }} else {pui_native_400} } {
            // Source "transition/machine.ts":328:33
            return Value::Undefined;
        }
        // Source "transition/machine.ts":329:11
        v_6f7065726174696f6e5f5f64396563393566323838326535633161.initialize(record(vec![("kind", Value::string("leave")), ("version", Value::number({ let cell=v_6f7065726174696f6e56657273696f6e.read(); let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; value }))]));
        // Source "transition/machine.ts":330:5
        { let value = v_6f7065726174696f6e5f5f64396563393566323838326535633161.read(); *(v_7374617274696e67.read()).borrow_mut() = value; }
        // Source "transition/machine.ts":331:11
        let v_63757272656e745f5f30306131306565613339303836656461 = {  let v_7461726765744f70656e = v_7461726765744f70656e.clone(); let v_63757272656e744f7065726174696f6e = v_63757272656e744f7065726174696f6e.clone(); let v_6f7065726174696f6e5f5f64396563393566323838326535633161 = v_6f7065726174696f6e5f5f64396563393566323838326535633161.clone(); let call:Rc<dyn Fn()->bool>=Rc::new(move || -> bool {
            // Source "transition/machine.ts":331:27
            return { let pui_native_402=(v_63757272656e744f7065726174696f6e.read().call)(((v_6f7065726174696f6e5f5f64396563393566323838326535633161.read()).member("version", false)).num()); if (pui_native_402) {!({ let value=(v_7461726765744f70656e.read()).borrow().clone(); value })} else {pui_native_402} };
        }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } };
        // Source "transition/machine.ts":332:5
        match authored_finally(|| -> std::ops::ControlFlow<Value> {
                {
                    // Source "transition/machine.ts":333:7
                    { let value = Value::Json(Json::Null); *(v_717565756564496e74656e74.read()).borrow_mut() = value; }
                    // Source "transition/machine.ts":334:7
                    { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("emit", false); callable.call_authored(vec![Value::string("beforeLeave")]) };
                    // Source "transition/machine.ts":335:7
                    if !((v_63757272656e745f5f30306131306565613339303836656461.call)()) {
                        // Source "transition/machine.ts":335:23
                        return std::ops::ControlFlow::Break(Value::Undefined);
                    }
                    // Source "transition/machine.ts":336:7
                    v_696e76616c6964617465436f6d706c6574696f6e.read().call_authored(vec![]);
                    // Source "transition/machine.ts":337:7
                    if !((v_63757272656e745f5f30306131306565613339303836656461.call)()) {
                        // Source "transition/machine.ts":337:23
                        return std::ops::ControlFlow::Break(Value::Undefined);
                    }
                    // Source "transition/machine.ts":338:13
                    let v_6672616d655f5f32306631386663363436663134363838 = v_7365745374617465.read().call_authored(vec![Value::string("leaving")]);
                    // Source "transition/machine.ts":339:7
                    if ({ let left = { let left = { let left = { let left = v_6672616d655f5f32306631386663363436663134363838.clone(); if left.truthy() { Value::boolean((Value::boolean(strict_equal(&({ let value = (v_61637469766550726573656e746174696f6e.read()).borrow().clone(); value }), &(v_6672616d655f5f32306631386663363436663134363838.clone())))).bool()) } else { left } }; if left.truthy() { Value::boolean((Value::boolean(strict_equal(&(({ let value = (v_61637469766550726573656e746174696f6e.read()).borrow().clone(); value }).member("phase", true)), &(Value::string("leaving"))))).bool()) } else { left } }; if left.truthy() { Value::boolean(!({ let value=(v_7465726d696e616c.read()).borrow().clone(); value })) } else { left } }; if left.truthy() { Value::boolean((Value::boolean(strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) }), &(Value::string("leaving"))))).bool()) } else { left } }).truthy() {
                        // Source "transition/machine.ts":346:9
                        v_61726d436f6d706c6574696f6e.read().call_authored(vec![Value::string("leaving")]);
                        // Source "transition/machine.ts":347:9
                        return std::ops::ControlFlow::Break(Value::Undefined);
                    }
                    // Source "transition/machine.ts":349:7
                    if { let pui_native_410=!((v_63757272656e745f5f30306131306565613339303836656461.call)()); if !(pui_native_410) {(Value::boolean(!strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) }), &(Value::string("leaving"))))).bool()} else {pui_native_410} } {
                        // Source "transition/machine.ts":349:58
                        return std::ops::ControlFlow::Break(Value::Undefined);
                    }
                    // Source "transition/machine.ts":350:7
                    v_61726d436f6d706c6574696f6e.read().call_authored(vec![Value::string("leaving")]);
                    std::ops::ControlFlow::Continue(())
                }
            }, || -> std::ops::ControlFlow<Value> {
                // Source "transition/machine.ts":352:7
                if (Value::boolean(strict_equal(&({ let value = (v_7374617274696e67.read()).borrow().clone(); value }), &(v_6f7065726174696f6e5f5f64396563393566323838326535633161.read())))).bool() {
                    // Source "transition/machine.ts":352:35
                    { let value = Value::Json(Json::Null); *(v_7374617274696e67.read()).borrow_mut() = value; }
                }
                std::ops::ControlFlow::Continue(())
            }) {
            std::ops::ControlFlow::Break(value) => return value,
            std::ops::ControlFlow::Continue(()) => {}
        }
        Value::Undefined
    })) });
    // Source "transition/machine.ts":356:9
    v_636f6e73756d65517565756564496e74656e74.initialize({  let v_717565756564496e74656e74 = v_717565756564496e74656e74.clone(); let v_656e7465725f5f34333965343333333766333433663737 = v_656e7465725f5f34333965343333333766333433663737.clone(); let v_6c656176655f5f34306631303637396166373934313764 = v_6c656176655f5f34306631303637396166373934313764.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
        // Source "transition/machine.ts":357:11
        let v_6e6578745f5f31346637326535356563643964653338 = { let value = (v_717565756564496e74656e74.read()).borrow().clone(); value };
        // Source "transition/machine.ts":358:5
        { let value = Value::Json(Json::Null); *(v_717565756564496e74656e74.read()).borrow_mut() = value; }
        // Source "transition/machine.ts":359:5
        if (Value::boolean(strict_equal(&(v_6e6578745f5f31346637326535356563643964653338.clone()), &(Value::string("enter"))))).bool() {
            // Source "transition/machine.ts":359:27
            v_656e7465725f5f34333965343333333766333433663737.read().call_authored(vec![]);
        } else {
            // Source "transition/machine.ts":360:10
            if (Value::boolean(strict_equal(&(v_6e6578745f5f31346637326535356563643964653338.clone()), &(Value::string("leave"))))).bool() {
                // Source "transition/machine.ts":360:32
                v_6c656176655f5f34306631303637396166373934313764.read().call_authored(vec![]);
            }
        }
        Value::Undefined
    })) });
    // Source "transition/machine.ts":363:9
    v_636f6d706c65746543757272656e74.initialize({  let v_6472697665725f5f66643335663962313031386337303063 = v_6472697665725f5f66643335663962313031386337303063.clone(); let v_6f7065726174696f6e56657273696f6e = v_6f7065726174696f6e56657273696f6e.clone(); let v_63757272656e744f7065726174696f6e = v_63757272656e744f7065726174696f6e.clone(); let v_696e76616c6964617465436f6d706c6574696f6e = v_696e76616c6964617465436f6d706c6574696f6e.clone(); let v_7365745374617465 = v_7365745374617465.clone(); let v_636f6e73756d65517565756564496e74656e74 = v_636f6e73756d65517565756564496e74656e74.clone(); let call:Rc<dyn Fn(bool)->bool>=Rc::new(move |argument_0: bool| -> bool {
        let v_636f6e73756d655175657565: bool = argument_0;
        // Source "transition/machine.ts":364:11
        let v_63757272656e745f5f63316536363239613431363931336239 = { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) };
        // Source "transition/machine.ts":365:5
        if { let pui_native_420=(Value::boolean(!strict_equal(&(v_63757272656e745f5f63316536363239613431363931336239.clone()), &(Value::string("entering"))))).bool(); if (pui_native_420) {(Value::boolean(!strict_equal(&(v_63757272656e745f5f63316536363239613431363931336239.clone()), &(Value::string("leaving"))))).bool()} else {pui_native_420} } {
            // Source "transition/machine.ts":365:58
            return false;
        }
        // Source "transition/machine.ts":366:11
        let v_6f7065726174696f6e5f5f36653464633337383866666365353263: f64 = { let cell=v_6f7065726174696f6e56657273696f6e.read(); let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; value };
        // Source "transition/machine.ts":367:5
        v_696e76616c6964617465436f6d706c6574696f6e.read().call_authored(vec![]);
        // Source "transition/machine.ts":368:5
        if !((v_63757272656e744f7065726174696f6e.read().call)(v_6f7065726174696f6e5f5f36653464633337383866666365353263.clone())) {
            // Source "transition/machine.ts":368:39
            return false;
        }
        // Source "transition/machine.ts":370:5
        if (Value::boolean(strict_equal(&(v_63757272656e745f5f63316536363239613431363931336239.clone()), &(Value::string("entering"))))).bool() {
            // Source "transition/machine.ts":371:7
            v_7365745374617465.read().call_authored(vec![Value::string("entered")]);
            // Source "transition/machine.ts":372:7
            if { let pui_native_428=!((v_63757272656e744f7065726174696f6e.read().call)(v_6f7065726174696f6e5f5f36653464633337383866666365353263.clone())); if !(pui_native_428) {(Value::boolean(!strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) }), &(Value::string("entered"))))).bool()} else {pui_native_428} } {
                // Source "transition/machine.ts":372:76
                return false;
            }
            // Source "transition/machine.ts":373:7
            { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("emit", false); callable.call_authored(vec![Value::string("afterEnter")]) };
        } else {
            // Source "transition/machine.ts":375:7
            v_7365745374617465.read().call_authored(vec![Value::string("closed")]);
            // Source "transition/machine.ts":376:7
            if { let pui_native_432=!((v_63757272656e744f7065726174696f6e.read().call)(v_6f7065726174696f6e5f5f36653464633337383866666365353263.clone())); if !(pui_native_432) {(Value::boolean(!strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) }), &(Value::string("closed"))))).bool()} else {pui_native_432} } {
                // Source "transition/machine.ts":376:75
                return false;
            }
            // Source "transition/machine.ts":377:7
            { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("emit", false); callable.call_authored(vec![Value::string("afterLeave")]) };
            // Source "transition/machine.ts":378:7
            if { let pui_native_436=!((v_63757272656e744f7065726174696f6e.read().call)(v_6f7065726174696f6e5f5f36653464633337383866666365353263.clone())); if !(pui_native_436) {(Value::boolean(!strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) }), &(Value::string("closed"))))).bool()} else {pui_native_436} } {
                // Source "transition/machine.ts":378:75
                return false;
            }
            // Source "transition/machine.ts":379:7
            { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("setViewPresent", false); callable.call_authored(vec![Value::boolean(false)]) };
        }
        // Source "transition/machine.ts":382:5
        if { let pui_native_440=v_636f6e73756d655175657565.clone(); if (pui_native_440) {(v_63757272656e744f7065726174696f6e.read().call)(v_6f7065726174696f6e5f5f36653464633337383866666365353263.clone())} else {pui_native_440} } {
            // Source "transition/machine.ts":382:54
            v_636f6e73756d65517565756564496e74656e74.read().call_authored(vec![]);
        }
        // Source "transition/machine.ts":383:5
        return (v_63757272656e744f7065726174696f6e.read().call)(v_6f7065726174696f6e5f5f36653464633337383866666365353263.clone());
    }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call((arg(&arguments,0)).bool()))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } });
    // Source "transition/machine.ts":386:9
    v_656e7465725f5f34333965343333333766333433663737.initialize({  let v_6472697665725f5f66643335663962313031386337303063 = v_6472697665725f5f66643335663962313031386337303063.clone(); let v_717565756564496e74656e74 = v_717565756564496e74656e74.clone(); let v_7374616765645374617465 = v_7374616765645374617465.clone(); let v_61637469766550726573656e746174696f6e = v_61637469766550726573656e746174696f6e.clone(); let v_7465726d696e616c = v_7465726d696e616c.clone(); let v_7374617274696e67 = v_7374617274696e67.clone(); let v_63757272656e744f7065726174696f6e = v_63757272656e744f7065726174696f6e.clone(); let v_757064617465546172676574 = v_757064617465546172676574.clone(); let v_626567696e456e746572 = v_626567696e456e746572.clone(); let v_636f6d706c65746543757272656e74 = v_636f6d706c65746543757272656e74.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
        // Source "transition/machine.ts":387:5
        if { let value=(v_7465726d696e616c.read()).borrow().clone(); value } {
            // Source "transition/machine.ts":387:19
            return Value::Undefined;
        }
        // Source "transition/machine.ts":388:5
        (v_757064617465546172676574.read().call)(true);
        // Source "transition/machine.ts":389:5
        if { let pui_native_442=(Value::boolean(strict_equal(&(({ let value = (v_7374617274696e67.read()).borrow().clone(); value }).member("kind", true)), &(Value::string("enter"))))).bool(); if (pui_native_442) {(v_63757272656e744f7065726174696f6e.read().call)((({ let value = (v_7374617274696e67.read()).borrow().clone(); value }).member("version", false)).num())} else {pui_native_442} } {
            // Source "transition/machine.ts":389:75
            return Value::Undefined;
        }
        // Source "transition/machine.ts":390:11
        let v_63757272656e745f5f62313333666538316131636635666363 = { let left = { let value = (v_7374616765645374617465.read()).borrow().clone(); value }; if left.nullish() { { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) } } else { left } };
        // Source "transition/machine.ts":391:5
        if { let pui_native_446=(Value::boolean(strict_equal(&(v_63757272656e745f5f62313333666538316131636635666363.clone()), &(Value::string("entered"))))).bool(); if !(pui_native_446) {(Value::boolean(strict_equal(&(v_63757272656e745f5f62313333666538316131636635666363.clone()), &(Value::string("preparing"))))).bool()} else {pui_native_446} } {
            // Source "transition/machine.ts":391:59
            return Value::Undefined;
        }
        // Source "transition/machine.ts":393:5
        if (Value::boolean(strict_equal(&(v_63757272656e745f5f62313333666538316131636635666363.clone()), &(Value::string("closed"))))).bool() {
            // Source "transition/machine.ts":394:7
            v_626567696e456e746572.read().call_authored(vec![]);
            // Source "transition/machine.ts":395:7
            return Value::Undefined;
        }
        // Source "transition/machine.ts":398:5
        if (Value::boolean(strict_equal(&(v_63757272656e745f5f62313333666538316131636635666363.clone()), &(Value::string("entering"))))).bool() {
            // Source "transition/machine.ts":399:7
            if ({ let left = Value::boolean({ let pui_native_456={ let pui_native_458=(Value::boolean(strict_equal(&(({ let value = (v_7374617274696e67.read()).borrow().clone(); value }).member("kind", true)), &(Value::string("leave"))))).bool(); if (pui_native_458) {!(({ let value = (v_61637469766550726573656e746174696f6e.read()).borrow().clone(); value }).truthy())} else {pui_native_458} }; if (pui_native_456) {(Value::boolean(!strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getCompletion", false); if callable.nullish() { Value::Undefined } else { callable.call_authored(vec![]) } }), &(Value::string("timer"))))).bool()} else {pui_native_456} }); if left.truthy() { (v_6472697665725f5f66643335663962313031386337303063.read()).member("getCompletion", false) } else { left } }).truthy() {
                // Source "transition/machine.ts":405:9
                v_626567696e456e746572.read().call_authored(vec![Value::boolean(false)]);
                // Source "transition/machine.ts":406:9
                return Value::Undefined;
            }
            // Source "transition/machine.ts":408:7
            if (Value::boolean(strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getInterrupt", false); callable.call_authored(vec![]) }), &(Value::string("wait"))))).bool() {
                // Source "transition/machine.ts":408:45
                { let value = Value::Json(Json::Null); *(v_717565756564496e74656e74.read()).borrow_mut() = value; }
            }
            // Source "transition/machine.ts":409:7
            return Value::Undefined;
        }
        // Source "transition/machine.ts":412:11
        let v_696e746572727570745f5f30626438636166303563333961613936 = { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getInterrupt", false); callable.call_authored(vec![]) };
        // Source "transition/machine.ts":413:5
        if (Value::boolean(strict_equal(&(v_696e746572727570745f5f30626438636166303563333961613936.clone()), &(Value::string("wait"))))).bool() {
            // Source "transition/machine.ts":414:7
            { let value = Value::string("enter"); *(v_717565756564496e74656e74.read()).borrow_mut() = value; }
        } else {
            // Source "transition/machine.ts":415:12
            if (Value::boolean(strict_equal(&(v_696e746572727570745f5f30626438636166303563333961613936.clone()), &(Value::string("immediate"))))).bool() {
                // Source "transition/machine.ts":416:7
                if (v_636f6d706c65746543757272656e74.read().call)(false) {
                    // Source "transition/machine.ts":416:35
                    v_626567696e456e746572.read().call_authored(vec![Value::boolean(false)]);
                }
            } else {
                // Source "transition/machine.ts":418:7
                v_626567696e456e746572.read().call_authored(vec![Value::boolean(false)]);
            }
        }
        Value::Undefined
    })) });
    // Source "transition/machine.ts":422:9
    v_6c656176655f5f34306631303637396166373934313764.initialize({  let v_6472697665725f5f66643335663962313031386337303063 = v_6472697665725f5f66643335663962313031386337303063.clone(); let v_7461726765744f70656e = v_7461726765744f70656e.clone(); let v_717565756564496e74656e74 = v_717565756564496e74656e74.clone(); let v_7374616765645374617465 = v_7374616765645374617465.clone(); let v_61637469766550726573656e746174696f6e = v_61637469766550726573656e746174696f6e.clone(); let v_7465726d696e616c = v_7465726d696e616c.clone(); let v_7374617274696e67 = v_7374617274696e67.clone(); let v_63757272656e744f7065726174696f6e = v_63757272656e744f7065726174696f6e.clone(); let v_757064617465546172676574 = v_757064617465546172676574.clone(); let v_63616e63656c5072657061726174696f6e = v_63616e63656c5072657061726174696f6e.clone(); let v_696e76616c6964617465436f6d706c6574696f6e = v_696e76616c6964617465436f6d706c6574696f6e.clone(); let v_7365745374617465 = v_7365745374617465.clone(); let v_626567696e4c65617665 = v_626567696e4c65617665.clone(); let v_636f6d706c65746543757272656e74 = v_636f6d706c65746543757272656e74.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
        // Source "transition/machine.ts":423:5
        if { let value=(v_7465726d696e616c.read()).borrow().clone(); value } {
            // Source "transition/machine.ts":423:19
            return Value::Undefined;
        }
        // Source "transition/machine.ts":424:5
        (v_757064617465546172676574.read().call)(false);
        // Source "transition/machine.ts":425:5
        if { let pui_native_470=(Value::boolean(strict_equal(&(({ let value = (v_7374617274696e67.read()).borrow().clone(); value }).member("kind", true)), &(Value::string("leave"))))).bool(); if (pui_native_470) {(v_63757272656e744f7065726174696f6e.read().call)((({ let value = (v_7374617274696e67.read()).borrow().clone(); value }).member("version", false)).num())} else {pui_native_470} } {
            // Source "transition/machine.ts":425:75
            return Value::Undefined;
        }
        // Source "transition/machine.ts":426:11
        let v_63757272656e745f5f32303233303766633464353334386438 = { let left = { let value = (v_7374616765645374617465.read()).borrow().clone(); value }; if left.nullish() { { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) } } else { left } };
        // Source "transition/machine.ts":427:5
        if (Value::boolean(strict_equal(&(v_63757272656e745f5f32303233303766633464353334386438.clone()), &(Value::string("preparing"))))).bool() {
            // Source "transition/machine.ts":428:7
            v_63616e63656c5072657061726174696f6e.read().call_authored(vec![]);
            // Source "transition/machine.ts":429:7
            v_696e76616c6964617465436f6d706c6574696f6e.read().call_authored(vec![]);
            // Source "transition/machine.ts":430:7
            { let value = Value::Json(Json::Null); *(v_717565756564496e74656e74.read()).borrow_mut() = value; }
            // Source "transition/machine.ts":431:7
            v_7365745374617465.read().call_authored(vec![Value::string("closed")]);
            // Source "transition/machine.ts":432:7
            if { let pui_native_476=!({ let value=(v_7461726765744f70656e.read()).borrow().clone(); value }); if (pui_native_476) {(Value::boolean(strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) }), &(Value::string("closed"))))).bool()} else {pui_native_476} } {
                // Source "transition/machine.ts":432:58
                { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("setViewPresent", false); callable.call_authored(vec![Value::boolean(false)]) };
            }
            // Source "transition/machine.ts":433:7
            return Value::Undefined;
        }
        // Source "transition/machine.ts":436:5
        if (Value::boolean(strict_equal(&(v_63757272656e745f5f32303233303766633464353334386438.clone()), &(Value::string("closed"))))).bool() {
            // Source "transition/machine.ts":437:7
            { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("setViewPresent", false); callable.call_authored(vec![Value::boolean(false)]) };
            // Source "transition/machine.ts":438:7
            return Value::Undefined;
        }
        // Source "transition/machine.ts":441:5
        if (Value::boolean(strict_equal(&(v_63757272656e745f5f32303233303766633464353334386438.clone()), &(Value::string("leaving"))))).bool() {
            // Source "transition/machine.ts":442:7
            if ({ let left = Value::boolean({ let pui_native_484={ let pui_native_486=(Value::boolean(strict_equal(&(({ let value = (v_7374617274696e67.read()).borrow().clone(); value }).member("kind", true)), &(Value::string("enter"))))).bool(); if (pui_native_486) {!(({ let value = (v_61637469766550726573656e746174696f6e.read()).borrow().clone(); value }).truthy())} else {pui_native_486} }; if (pui_native_484) {(Value::boolean(!strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getCompletion", false); if callable.nullish() { Value::Undefined } else { callable.call_authored(vec![]) } }), &(Value::string("timer"))))).bool()} else {pui_native_484} }); if left.truthy() { (v_6472697665725f5f66643335663962313031386337303063.read()).member("getCompletion", false) } else { left } }).truthy() {
                // Source "transition/machine.ts":448:9
                v_626567696e4c65617665.read().call_authored(vec![]);
                // Source "transition/machine.ts":449:9
                return Value::Undefined;
            }
            // Source "transition/machine.ts":451:7
            if (Value::boolean(strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getInterrupt", false); callable.call_authored(vec![]) }), &(Value::string("wait"))))).bool() {
                // Source "transition/machine.ts":451:45
                { let value = Value::Json(Json::Null); *(v_717565756564496e74656e74.read()).borrow_mut() = value; }
            }
            // Source "transition/machine.ts":452:7
            return Value::Undefined;
        }
        // Source "transition/machine.ts":455:5
        if (Value::boolean(strict_equal(&(v_63757272656e745f5f32303233303766633464353334386438.clone()), &(Value::string("entered"))))).bool() {
            // Source "transition/machine.ts":456:7
            v_626567696e4c65617665.read().call_authored(vec![]);
            // Source "transition/machine.ts":457:7
            return Value::Undefined;
        }
        // Source "transition/machine.ts":460:11
        let v_696e746572727570745f5f64333933363635313231396262303830 = { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getInterrupt", false); callable.call_authored(vec![]) };
        // Source "transition/machine.ts":461:5
        if (Value::boolean(strict_equal(&(v_696e746572727570745f5f64333933363635313231396262303830.clone()), &(Value::string("wait"))))).bool() {
            // Source "transition/machine.ts":462:7
            { let value = Value::string("leave"); *(v_717565756564496e74656e74.read()).borrow_mut() = value; }
        } else {
            // Source "transition/machine.ts":463:12
            if (Value::boolean(strict_equal(&(v_696e746572727570745f5f64333933363635313231396262303830.clone()), &(Value::string("immediate"))))).bool() {
                // Source "transition/machine.ts":464:7
                if (v_636f6d706c65746543757272656e74.read().call)(false) {
                    // Source "transition/machine.ts":464:35
                    v_626567696e4c65617665.read().call_authored(vec![]);
                }
            } else {
                // Source "transition/machine.ts":466:7
                v_626567696e4c65617665.read().call_authored(vec![]);
            }
        }
        Value::Undefined
    })) });
    // Source "transition/machine.ts":470:9
    let v_696e697469616c697a65 = {  let v_6472697665725f5f66643335663962313031386337303063 = v_6472697665725f5f66643335663962313031386337303063.clone(); let v_7461726765744f70656e = v_7461726765744f70656e.clone(); let v_717565756564496e74656e74 = v_717565756564496e74656e74.clone(); let v_6f776e657245706f6368 = v_6f776e657245706f6368.clone(); let v_7465726d696e616c = v_7465726d696e616c.clone(); let v_6f7065726174696f6e56657273696f6e = v_6f7065726174696f6e56657273696f6e.clone(); let v_63757272656e744f7065726174696f6e = v_63757272656e744f7065726174696f6e.clone(); let v_63616e63656c5072657061726174696f6e = v_63616e63656c5072657061726174696f6e.clone(); let v_626567696e5072657061726174696f6e = v_626567696e5072657061726174696f6e.clone(); let v_696e76616c6964617465436f6d706c6574696f6e = v_696e76616c6964617465436f6d706c6574696f6e.clone(); let v_7365745374617465 = v_7365745374617465.clone(); let call:Rc<dyn Fn(bool, bool)->Value>=Rc::new(move |argument_0: bool, argument_1: bool| -> Value {
        let v_6f70656e5f5f38366535643837616535306133363036: bool = argument_0;
        let v_6170706561725f5f65653863633739616435333965323163: bool = argument_1;
        // Source "transition/machine.ts":471:5
        if { let value=(v_7465726d696e616c.read()).borrow().clone(); value } {
            // Source "transition/machine.ts":471:19
            return Value::Undefined;
        }
        // Source "transition/machine.ts":472:11
        let v_6f7065726174696f6e5f5f36373561336361343234633666336334: f64 = { let cell=v_6f7065726174696f6e56657273696f6e.read(); let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; value };
        // Source "transition/machine.ts":473:5
        Value::number({ let value={ let pui_native_500:f64={ let value=(v_6f776e657245706f6368.read()).borrow().clone(); value }; let pui_native_501:f64=1.0_f64; pui_native_500 + pui_native_501 }; *(v_6f776e657245706f6368.read()).borrow_mut()=value.clone(); value });
        // Source "transition/machine.ts":474:5
        v_63616e63656c5072657061726174696f6e.read().call_authored(vec![]);
        // Source "transition/machine.ts":475:5
        Value::boolean({ let value=v_6f70656e5f5f38366535643837616535306133363036.clone(); *(v_7461726765744f70656e.read()).borrow_mut()=value.clone(); value });
        // Source "transition/machine.ts":476:5
        { let value = Value::Json(Json::Null); *(v_717565756564496e74656e74.read()).borrow_mut() = value; }
        // Source "transition/machine.ts":477:5
        v_696e76616c6964617465436f6d706c6574696f6e.read().call_authored(vec![]);
        // Source "transition/machine.ts":478:5
        if !((v_63757272656e744f7065726174696f6e.read().call)(v_6f7065726174696f6e5f5f36373561336361343234633666336334.clone())) {
            // Source "transition/machine.ts":478:39
            return Value::Undefined;
        }
        // Source "transition/machine.ts":480:5
        if !(v_6f70656e5f5f38366535643837616535306133363036.clone()) {
            // Source "transition/machine.ts":481:7
            v_7365745374617465.read().call_authored(vec![Value::string("closed")]);
            // Source "transition/machine.ts":482:7
            if { let pui_native_502=!((v_63757272656e744f7065726174696f6e.read().call)(v_6f7065726174696f6e5f5f36373561336361343234633666336334.clone())); if !(pui_native_502) {{ let value=(v_7461726765744f70656e.read()).borrow().clone(); value }} else {pui_native_502} } {
                // Source "transition/machine.ts":482:55
                return Value::Undefined;
            }
            // Source "transition/machine.ts":483:7
            { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("setViewPresent", false); callable.call_authored(vec![Value::boolean(false)]) };
            // Source "transition/machine.ts":484:7
            return Value::Undefined;
        }
        // Source "transition/machine.ts":487:5
        if ({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("requiresColdPreparation", false); if callable.nullish() { Value::Undefined } else { callable.call_authored(vec![]) } }).truthy() {
            // Source "transition/machine.ts":488:7
            (v_626567696e5072657061726174696f6e.read().call)(v_6170706561725f5f65653863633739616435333965323163.clone());
            // Source "transition/machine.ts":489:7
            return Value::Undefined;
        }
        // Source "transition/machine.ts":491:5
        { let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("setViewPresent", false); callable.call_authored(vec![Value::boolean(true)]) };
        // Source "transition/machine.ts":492:5
        if { let pui_native_504=!((v_63757272656e744f7065726174696f6e.read().call)(v_6f7065726174696f6e5f5f36373561336361343234633666336334.clone())); if !(pui_native_504) {!({ let value=(v_7461726765744f70656e.read()).borrow().clone(); value })} else {pui_native_504} } {
            // Source "transition/machine.ts":492:54
            return Value::Undefined;
        }
        // Source "transition/machine.ts":493:5
        if !(v_6170706561725f5f65653863633739616435333965323163.clone()) {
            // Source "transition/machine.ts":493:18
            v_7365745374617465.read().call_authored(vec![Value::string("entered")]);
        }
        Value::Undefined
    }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).bool(), (arg(&arguments,1)).bool())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } };
    // Source "transition/machine.ts":496:9
    let v_6d6f756e746564 = {  let v_6472697665725f5f66643335663962313031386337303063 = v_6472697665725f5f66643335663962313031386337303063.clone(); let v_7461726765744f70656e = v_7461726765744f70656e.clone(); let v_766965774d6f756e746564 = v_766965774d6f756e746564.clone(); let v_7465726d696e616c = v_7465726d696e616c.clone(); let v_7072657061726174696f6e = v_7072657061726174696f6e.clone(); let v_66696e6973685072657061726174696f6e = v_66696e6973685072657061726174696f6e.clone(); let v_626567696e456e746572 = v_626567696e456e746572.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
        // Source "transition/machine.ts":497:5
        if { let value=(v_7465726d696e616c.read()).borrow().clone(); value } {
            // Source "transition/machine.ts":497:19
            return Value::Undefined;
        }
        // Source "transition/machine.ts":498:5
        Value::boolean({ let value=true; *(v_766965774d6f756e746564.read()).borrow_mut()=value.clone(); value });
        // Source "transition/machine.ts":499:5
        if ({ let value = (v_7072657061726174696f6e.read()).borrow().clone(); value }).truthy() {
            // Source "transition/machine.ts":500:7
            v_66696e6973685072657061726174696f6e.read().call_authored(vec![{ let value = (v_7072657061726174696f6e.read()).borrow().clone(); value }]);
            // Source "transition/machine.ts":501:7
            return Value::Undefined;
        }
        // Source "transition/machine.ts":503:5
        if { let pui_native_506={ let value=(v_7461726765744f70656e.read()).borrow().clone(); value }; if (pui_native_506) {(Value::boolean(strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) }), &(Value::string("closed"))))).bool()} else {pui_native_506} } {
            // Source "transition/machine.ts":503:55
            v_626567696e456e746572.read().call_authored(vec![]);
        }
        Value::Undefined
    })) };
    // Source "transition/machine.ts":506:9
    let v_756e6d6f756e746564 = {  let v_6472697665725f5f66643335663962313031386337303063 = v_6472697665725f5f66643335663962313031386337303063.clone(); let v_766965774d6f756e746564 = v_766965774d6f756e746564.clone(); let v_717565756564496e74656e74 = v_717565756564496e74656e74.clone(); let v_6f776e657245706f6368 = v_6f776e657245706f6368.clone(); let v_6f7065726174696f6e56657273696f6e = v_6f7065726174696f6e56657273696f6e.clone(); let v_63757272656e744f7065726174696f6e = v_63757272656e744f7065726174696f6e.clone(); let v_63616e63656c5072657061726174696f6e = v_63616e63656c5072657061726174696f6e.clone(); let v_696e76616c6964617465436f6d706c6574696f6e = v_696e76616c6964617465436f6d706c6574696f6e.clone(); let v_7365745374617465 = v_7365745374617465.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
        // Source "transition/machine.ts":507:5
        Value::number({ let value={ let pui_native_510:f64={ let value=(v_6f776e657245706f6368.read()).borrow().clone(); value }; let pui_native_511:f64=1.0_f64; pui_native_510 + pui_native_511 }; *(v_6f776e657245706f6368.read()).borrow_mut()=value.clone(); value });
        // Source "transition/machine.ts":508:11
        let v_6f7065726174696f6e5f5f37306161366362656638373464356432: f64 = { let cell=v_6f7065726174696f6e56657273696f6e.read(); let previous=cell.borrow().clone(); let value=previous + 1.0; *cell.borrow_mut()=value; value };
        // Source "transition/machine.ts":509:5
        v_63616e63656c5072657061726174696f6e.read().call_authored(vec![]);
        // Source "transition/machine.ts":510:5
        Value::boolean({ let value=false; *(v_766965774d6f756e746564.read()).borrow_mut()=value.clone(); value });
        // Source "transition/machine.ts":511:5
        v_696e76616c6964617465436f6d706c6574696f6e.read().call_authored(vec![]);
        // Source "transition/machine.ts":512:5
        if !((v_63757272656e744f7065726174696f6e.read().call)(v_6f7065726174696f6e5f5f37306161366362656638373464356432.clone())) {
            // Source "transition/machine.ts":512:39
            return Value::Undefined;
        }
        // Source "transition/machine.ts":513:5
        { let value = Value::Json(Json::Null); *(v_717565756564496e74656e74.read()).borrow_mut() = value; }
        // Source "transition/machine.ts":514:5
        if (Value::boolean(!strict_equal(&({ let callable = (v_6472697665725f5f66643335663962313031386337303063.read()).member("getState", false); callable.call_authored(vec![]) }), &(Value::string("closed"))))).bool() {
            // Source "transition/machine.ts":514:41
            v_7365745374617465.read().call_authored(vec![Value::string("closed")]);
        }
        Value::Undefined
    })) };
    // Source "transition/machine.ts":517:9
    let v_646973706f7365 = {  let v_766965774d6f756e746564 = v_766965774d6f756e746564.clone(); let v_717565756564496e74656e74 = v_717565756564496e74656e74.clone(); let v_6f776e657245706f6368 = v_6f776e657245706f6368.clone(); let v_7465726d696e616c = v_7465726d696e616c.clone(); let v_6f7065726174696f6e56657273696f6e = v_6f7065726174696f6e56657273696f6e.clone(); let v_63616e63656c5072657061726174696f6e = v_63616e63656c5072657061726174696f6e.clone(); let v_696e76616c6964617465436f6d706c6574696f6e = v_696e76616c6964617465436f6d706c6574696f6e.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
        // Source "transition/machine.ts":518:5
        Value::boolean({ let value=true; *(v_7465726d696e616c.read()).borrow_mut()=value.clone(); value });
        // Source "transition/machine.ts":519:5
        Value::number({ let value={ let pui_native_514:f64={ let value=(v_6f776e657245706f6368.read()).borrow().clone(); value }; let pui_native_515:f64=1.0_f64; pui_native_514 + pui_native_515 }; *(v_6f776e657245706f6368.read()).borrow_mut()=value.clone(); value });
        // Source "transition/machine.ts":520:5
        Value::number({ let value={ let pui_native_516:f64={ let value=(v_6f7065726174696f6e56657273696f6e.read()).borrow().clone(); value }; let pui_native_517:f64=1.0_f64; pui_native_516 + pui_native_517 }; *(v_6f7065726174696f6e56657273696f6e.read()).borrow_mut()=value.clone(); value });
        // Source "transition/machine.ts":521:5
        v_63616e63656c5072657061726174696f6e.read().call_authored(vec![]);
        // Source "transition/machine.ts":522:5
        Value::boolean({ let value=false; *(v_766965774d6f756e746564.read()).borrow_mut()=value.clone(); value });
        // Source "transition/machine.ts":523:5
        { let value = Value::Json(Json::Null); *(v_717565756564496e74656e74.read()).borrow_mut() = value; }
        // Source "transition/machine.ts":524:5
        v_696e76616c6964617465436f6d706c6574696f6e.read().call_authored(vec![]);
        Value::Undefined
    })) };
    // Source "transition/machine.ts":527:3
    return record(vec![("initialize", (v_696e697469616c697a65.clone()).ordinary.clone().expect("checked native data callable")), ("setTarget", ({  let v_7461726765744f70656e = v_7461726765744f70656e.clone(); let v_7465726d696e616c = v_7465726d696e616c.clone(); let v_656e7465725f5f34333965343333333766333433663737 = v_656e7465725f5f34333965343333333766333433663737.clone(); let v_6c656176655f5f34306631303637396166373934313764 = v_6c656176655f5f34306631303637396166373934313764.clone(); let call:Rc<dyn Fn(bool)->Value>=Rc::new(move |argument_0: bool| -> Value {
        let v_6f70656e5f5f32386339383230623661396437633032: bool = argument_0;
        // Source "transition/machine.ts":530:7
        if { let value=(v_7465726d696e616c.read()).borrow().clone(); value } {
            // Source "transition/machine.ts":530:21
            return Value::Undefined;
        }
        // Source "transition/machine.ts":531:7
        if { let pui_native_518=v_6f70656e5f5f32386339383230623661396437633032.clone(); let pui_native_519={ let value=(v_7461726765744f70656e.read()).borrow().clone(); value }; (pui_native_518==pui_native_519) } {
            // Source "transition/machine.ts":531:32
            return Value::Undefined;
        }
        // Source "transition/machine.ts":532:7
        if v_6f70656e5f5f32386339383230623661396437633032.clone() {
            // Source "transition/machine.ts":532:17
            v_656e7465725f5f34333965343333333766333433663737.read().call_authored(vec![]);
        } else {
            // Source "transition/machine.ts":533:12
            v_6c656176655f5f34306631303637396166373934313764.read().call_authored(vec![]);
        }
        Value::Undefined
    }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).bool())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")), ("enter", v_656e7465725f5f34333965343333333766333433663737.read()), ("leave", v_6c656176655f5f34306631303637396166373934313764.read()), ("complete", {  let v_7465726d696e616c = v_7465726d696e616c.clone(); let v_636f6d706c65746543757272656e74 = v_636f6d706c65746543757272656e74.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
        // Source "transition/machine.ts":538:7
        if !({ let value=(v_7465726d696e616c.read()).borrow().clone(); value }) {
            // Source "transition/machine.ts":538:22
            Value::boolean((v_636f6d706c65746543757272656e74.read().call)(true));
        }
        Value::Undefined
    })) }), ("completePresentation", ({  let v_7075626c697368696e67 = v_7075626c697368696e67.clone(); let v_61636b6e6f776c6564676564 = v_61636b6e6f776c6564676564.clone(); let v_61636b6e6f776c656467656d656e7443757272656e74 = v_61636b6e6f776c656467656d656e7443757272656e74.clone(); let v_73616d65417474656d7074 = v_73616d65417474656d7074.clone(); let v_636f6d706c65746543757272656e74 = v_636f6d706c65746543757272656e74.clone(); let call:Rc<dyn Fn(Value, Value)->bool>=Rc::new(move |argument_0: Value, argument_1: Value| -> bool {
        let v_697343757272656e74: LexicalBinding<Value> = lexical_binding();
        let v_617474656d70745f5f37666431663031383731333339386264: Value = argument_0;
        v_697343757272656e74.initialize({ let argument = argument_1; if matches!(&argument, Value::Undefined) { ({   let call:Rc<dyn Fn()->bool>=Rc::new(move || -> bool {
            // Source "transition/machine.ts":540:55
            return true;
        }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable") } else { argument } });
        // Source "transition/machine.ts":541:13
        let v_76616c6964617465 = {  let v_697343757272656e74 = v_697343757272656e74.clone(); let call:Rc<dyn Fn()->bool>=Rc::new(move || -> bool {
            // Source "transition/machine.ts":542:9
            match match catch_authored::<std::ops::ControlFlow<bool>>(|| {
                    // Source "transition/machine.ts":543:11
                    return std::ops::ControlFlow::Break(({ let callable = v_697343757272656e74.read(); callable.call_authored(vec![]) }).bool());
                }) {
                    Ok(flow) => flow,
                    Err(_) => (|| -> std::ops::ControlFlow<bool> {
                        // Source "transition/machine.ts":545:11
                        return std::ops::ControlFlow::Break(false);
                    })()
                } {
                std::ops::ControlFlow::Break(value) => return value,
                std::ops::ControlFlow::Continue(()) => {}
            }
            unreachable!("checked scalar function did not return")
        }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } };
        // Source "transition/machine.ts":548:7
        if { let pui_native_520={ let pui_native_522=!((v_73616d65417474656d7074.read().call)(v_617474656d70745f5f37666431663031383731333339386264.clone())); if !(pui_native_522) {!((v_76616c6964617465.call)())} else {pui_native_522} }; if !(pui_native_520) {!((v_73616d65417474656d7074.read().call)(v_617474656d70745f5f37666431663031383731333339386264.clone()))} else {pui_native_520} } {
            // Source "transition/machine.ts":548:74
            return false;
        }
        // Source "transition/machine.ts":549:7
        if { let value=(v_7075626c697368696e67.read()).borrow().clone(); value } {
            // Source "transition/machine.ts":550:9
            Value::boolean({ let value=true; *(v_61636b6e6f776c6564676564.read()).borrow_mut()=value.clone(); value });
            // Source "transition/machine.ts":551:9
            { let value = (v_76616c6964617465.clone()).ordinary.clone().expect("checked native data callable"); *(v_61636b6e6f776c656467656d656e7443757272656e74.read()).borrow_mut() = value; }
            // Source "transition/machine.ts":552:9
            return true;
        }
        // Source "transition/machine.ts":554:7
        return (v_636f6d706c65746543757272656e74.read().call)(true);
    }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call(arg(&arguments,0), arg(&arguments,1)))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")), ("capturePreparation", {  let v_7072657061726174696f6e = v_7072657061726174696f6e.clone(); let v_6973507265706172696e67 = v_6973507265706172696e67.clone(); let v_66696e6973685072657061726174696f6e = v_66696e6973685072657061726174696f6e.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
        let v_617474656d70745f5f61343834613536623735353332363461: LexicalBinding<Value> = lexical_binding();
        // Source "transition/machine.ts":557:13
        v_617474656d70745f5f61343834613536623735353332363461.initialize({ let value = (v_7072657061726174696f6e.read()).borrow().clone(); value });
        // Source "transition/machine.ts":558:7
        if { let pui_native_524=!((v_617474656d70745f5f61343834613536623735353332363461.read()).truthy()); if !(pui_native_524) {!((v_6973507265706172696e67.read().call)(v_617474656d70745f5f61343834613536623735353332363461.read()))} else {pui_native_524} } {
            // Source "transition/machine.ts":558:46
            return Value::Json(Json::Null);
        }
        // Source "transition/machine.ts":559:7
        return {  let v_6973507265706172696e67 = v_6973507265706172696e67.clone(); let v_66696e6973685072657061726174696f6e = v_66696e6973685072657061726174696f6e.clone(); let v_617474656d70745f5f61343834613536623735353332363461 = v_617474656d70745f5f61343834613536623735353332363461.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
            // Source "transition/machine.ts":560:9
            if { let pui_native_526=!((v_6973507265706172696e67.read().call)(v_617474656d70745f5f61343834613536623735353332363461.read())); if !(pui_native_526) {((v_617474656d70745f5f61343834613536623735353332363461.read()).member("finishing", false)).bool()} else {pui_native_526} } {
                // Source "transition/machine.ts":560:57
                return Value::Undefined;
            }
            // Source "transition/machine.ts":561:9
            Value::boolean((set_member(v_617474656d70745f5f61343834613536623735353332363461.read(), "ready", Value::boolean(true))).bool());
            // Source "transition/machine.ts":562:9
            v_66696e6973685072657061726174696f6e.read().call_authored(vec![v_617474656d70745f5f61343834613536623735353332363461.read()]);
            Value::Undefined
        })) };
    })) }), ("mounted", v_6d6f756e746564.clone()), ("unmounted", v_756e6d6f756e746564.clone()), ("dispose", v_646973706f7365.clone())]);
})) }; }
std::thread_local! { static v_5f5f7075694d6f64756c6531: Value = {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
    let v_76616c75655f5f64356534303236656235386562663565: Value = arg(&arguments, 0);
    let v_6e616d65: Value = arg(&arguments, 1);
    // Source "transition/as-transition.proto.ts":24:3
    if (Value::boolean(strict_equal(&(typeof_value(&(v_76616c75655f5f64356534303236656235386562663565.clone()))), &(Value::string("undefined"))))).bool() {
        // Source "transition/as-transition.proto.ts":25:5
        throw_value(record(vec![("name", Value::string("Error")), ("message", (add(add(Value::string("[asTransition] missing captured handle: "), v_6e616d65.clone()), Value::string("."))).error_message_value())]));
    }
    // Source "transition/as-transition.proto.ts":27:3
    return v_76616c75655f5f64356534303236656235386562663565.clone();
})) }; }
std::thread_local! { static v_5f5f7075694d6f64756c6532: Value = {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
    let v_76616c75655f5f64356534303236656235386562663565: Value = arg(&arguments, 0);
    let v_6e616d65: Value = arg(&arguments, 1);
    // Source "transition/as-transition.proto.ts":24:3
    if (Value::boolean(strict_equal(&(typeof_value(&(v_76616c75655f5f64356534303236656235386562663565.clone()))), &(Value::string("undefined"))))).bool() {
        // Source "transition/as-transition.proto.ts":25:5
        throw_value(record(vec![("name", Value::string("Error")), ("message", (add(add(Value::string("[asTransition] missing captured handle: "), v_6e616d65.clone()), Value::string("."))).error_message_value())]));
    }
    // Source "transition/as-transition.proto.ts":27:3
    return v_76616c75655f5f64356534303236656235386562663565.clone();
})) }; }
std::thread_local! { static v_5f5f7075694d6f64756c6533: Value = {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
    let v_76616c75655f5f64356534303236656235386562663565: Value = arg(&arguments, 0);
    let v_6e616d65: Value = arg(&arguments, 1);
    // Source "transition/as-transition.proto.ts":24:3
    if (Value::boolean(strict_equal(&(typeof_value(&(v_76616c75655f5f64356534303236656235386562663565.clone()))), &(Value::string("undefined"))))).bool() {
        // Source "transition/as-transition.proto.ts":25:5
        throw_value(record(vec![("name", Value::string("Error")), ("message", (add(add(Value::string("[asTransition] missing captured handle: "), v_6e616d65.clone()), Value::string("."))).error_message_value())]));
    }
    // Source "transition/as-transition.proto.ts":27:3
    return v_76616c75655f5f64356534303236656235386562663565.clone();
})) }; }
std::thread_local! { static v_5f5f7075694d6f64756c6534: Value = {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
    let v_76616c75655f5f64356534303236656235386562663565: Value = arg(&arguments, 0);
    let v_6e616d65: Value = arg(&arguments, 1);
    // Source "transition/as-transition.proto.ts":24:3
    if (Value::boolean(strict_equal(&(typeof_value(&(v_76616c75655f5f64356534303236656235386562663565.clone()))), &(Value::string("undefined"))))).bool() {
        // Source "transition/as-transition.proto.ts":25:5
        throw_value(record(vec![("name", Value::string("Error")), ("message", (add(add(Value::string("[asTransition] missing captured handle: "), v_6e616d65.clone()), Value::string("."))).error_message_value())]));
    }
    // Source "transition/as-transition.proto.ts":27:3
    return v_76616c75655f5f64356534303236656235386562663565.clone();
})) }; }
std::thread_local! { static v_5f5f7075694d6f64756c6535: Value = {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
    let v_76616c75655f5f64356534303236656235386562663565: Value = arg(&arguments, 0);
    let v_6e616d65: Value = arg(&arguments, 1);
    // Source "transition/as-transition.proto.ts":24:3
    if (Value::boolean(strict_equal(&(typeof_value(&(v_76616c75655f5f64356534303236656235386562663565.clone()))), &(Value::string("undefined"))))).bool() {
        // Source "transition/as-transition.proto.ts":25:5
        throw_value(record(vec![("name", Value::string("Error")), ("message", (add(add(Value::string("[asTransition] missing captured handle: "), v_6e616d65.clone()), Value::string("."))).error_message_value())]));
    }
    // Source "transition/as-transition.proto.ts":27:3
    return v_76616c75655f5f64356534303236656235386562663565.clone();
})) }; }
std::thread_local! { static v_5f5f7075694d6f64756c6536: Value = {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
    let v_76616c75655f5f64356534303236656235386562663565: Value = arg(&arguments, 0);
    let v_6e616d65: Value = arg(&arguments, 1);
    // Source "transition/as-transition.proto.ts":24:3
    if (Value::boolean(strict_equal(&(typeof_value(&(v_76616c75655f5f64356534303236656235386562663565.clone()))), &(Value::string("undefined"))))).bool() {
        // Source "transition/as-transition.proto.ts":25:5
        throw_value(record(vec![("name", Value::string("Error")), ("message", (add(add(Value::string("[asTransition] missing captured handle: "), v_6e616d65.clone()), Value::string("."))).error_message_value())]));
    }
    // Source "transition/as-transition.proto.ts":27:3
    return v_76616c75655f5f64356534303236656235386562663565.clone();
})) }; }
std::thread_local! { static v_5f5f7075694d6f64756c6537: Value = {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
    let v_76616c75655f5f64356534303236656235386562663565: Value = arg(&arguments, 0);
    let v_6e616d65: Value = arg(&arguments, 1);
    // Source "transition/as-transition.proto.ts":24:3
    if (Value::boolean(strict_equal(&(typeof_value(&(v_76616c75655f5f64356534303236656235386562663565.clone()))), &(Value::string("undefined"))))).bool() {
        // Source "transition/as-transition.proto.ts":25:5
        throw_value(record(vec![("name", Value::string("Error")), ("message", (add(add(Value::string("[asTransition] missing captured handle: "), v_6e616d65.clone()), Value::string("."))).error_message_value())]));
    }
    // Source "transition/as-transition.proto.ts":27:3
    return v_76616c75655f5f64356534303236656235386562663565.clone();
})) }; }
std::thread_local! { static v_5f5f7075694d6f64756c6538: Value = {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
    let v_76616c75655f5f64356534303236656235386562663565: Value = arg(&arguments, 0);
    let v_6e616d65: Value = arg(&arguments, 1);
    // Source "transition/as-transition.proto.ts":24:3
    if (Value::boolean(strict_equal(&(typeof_value(&(v_76616c75655f5f64356534303236656235386562663565.clone()))), &(Value::string("undefined"))))).bool() {
        // Source "transition/as-transition.proto.ts":25:5
        throw_value(record(vec![("name", Value::string("Error")), ("message", (add(add(Value::string("[asTransition] missing captured handle: "), v_6e616d65.clone()), Value::string("."))).error_message_value())]));
    }
    // Source "transition/as-transition.proto.ts":27:3
    return v_76616c75655f5f64356534303236656235386562663565.clone();
})) }; }
  
  fn style_vocabulary() -> &'static native::gpui_native_style::StyleVocabulary {
      static VOCABULARY: std::sync::OnceLock<native::gpui_native_style::StyleVocabulary> = std::sync::OnceLock::new();
      VOCABULARY.get_or_init(|| native::gpui_native_style::StyleVocabulary::from_json(include_str!(".proto-ui/fixtures/style-tokens.json")).expect("compiler-produced style vocabulary"))
  }
  fn accepts_context(key: &str, value: &Json) -> bool {
      match key {
          
          _ => false,
      }
  }
  fn accepts_props(value: &Json) -> bool { value.is_object() && value.get("open").map_or(true, |prop| prop.is_null() || prop.is_boolean()) && value.get("defaultOpen").map_or(true, |prop| prop.is_null() || prop.is_boolean()) && value.get("appear").map_or(true, |prop| prop.is_null() || prop.is_boolean()) && value.get("enterDuration").map_or(true, |prop| prop.is_null() || prop.as_f64().is_some_and(f64::is_finite)) && value.get("leaveDuration").map_or(true, |prop| prop.is_null() || prop.as_f64().is_some_and(f64::is_finite)) && value.get("interrupt").map_or(true, |prop| prop.is_null() || (prop.as_str() == Some("reverse") || prop.as_str() == Some("wait") || prop.as_str() == Some("immediate"))) }
  fn prop_valid(key: &str, value: &Json) -> bool { match key { "open" => value.is_boolean(),
        "defaultOpen" => value.is_boolean(),
        "appear" => value.is_boolean(),
        "enterDuration" => value.as_f64().is_some_and(f64::is_finite),
        "leaveDuration" => value.as_f64().is_some_and(f64::is_finite),
        "interrupt" => (value.as_str() == Some("reverse") || value.as_str() == Some("wait") || value.as_str() == Some("immediate")), _ => false } }
  fn check_method(name: &str, arguments: &[Value]) { match name {
          "bindInitialOpen" => if !(arguments.len() <= 1 && arguments.get(0).map_or(false, |value| (matches!(value, Value::Record(_)) && {let member=(value).member("context",false); matches!(&member, Value::ContextKey(_))} && {let member=(value).member("field",false); (&member).try_data().is_some_and(|data| data.is_string())}))) { value_type_error("invalid exposed method arguments") },
        "getPresentationOwner" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "configurePresentation" => if !(arguments.len() <= 1 && arguments.get(0).map_or(false, |value| (matches!(value, Value::Record(_)) && {let member=(value).member("completion",false); matches!(&member,Value::Undefined) || ((&member).try_data().is_some_and(|data| data.as_str() == Some("timer")) || (matches!(&member, Value::Record(_)) && {let member=(&member).member("kind",false); (&member).try_data().is_some_and(|data| data.as_str() == Some("presentation"))} && {let member=(&member).member("timeoutMs",false); (&member).try_data().is_some_and(|data| data.as_f64().is_some_and(f64::is_finite))}))} && {let member=(value).member("coldEntryPreparation",false); matches!(&member,Value::Undefined) || (&member).try_data().is_some_and(|data| data.is_boolean())} && {let member=(value).member("appear",false); matches!(&member,Value::Undefined) || (&member).try_data().is_some_and(|data| data.is_boolean())} && {let member=(value).member("enterDuration",false); matches!(&member,Value::Undefined) || (&member).try_data().is_some_and(|data| data.as_f64().is_some_and(f64::is_finite))} && {let member=(value).member("leaveDuration",false); matches!(&member,Value::Undefined) || (&member).try_data().is_some_and(|data| data.as_f64().is_some_and(f64::is_finite))} && {let member=(value).member("interrupt",false); matches!(&member,Value::Undefined) || (&member).try_data().is_some_and(|data| (data.as_str() == Some("reverse") || data.as_str() == Some("wait") || data.as_str() == Some("immediate")))}))) { value_type_error("invalid exposed method arguments") },
        "enter" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "leave" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "complete" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
        "capturePreparation" => if !(arguments.len() <= 0 && true) { value_type_error("invalid exposed method arguments") },
          _ => value_error("unknown exposed method"),
  } }
  
  #[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
#[serde(untagged)]
pub enum GeneratedData1 {
    Alternative0(String),
    Alternative1(String),
    Alternative2(String),
}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize)]
pub struct GeneratedData0 {
    #[serde(rename = "open", default, skip_serializing_if = "Option::is_none")]
    pub field_0: Option<bool>,
    #[serde(rename = "defaultOpen", default, skip_serializing_if = "Option::is_none")]
    pub field_1: Option<bool>,
    #[serde(rename = "appear", default, skip_serializing_if = "Option::is_none")]
    pub field_2: Option<bool>,
    #[serde(rename = "enterDuration", default, skip_serializing_if = "Option::is_none")]
    pub field_3: Option<f64>,
    #[serde(rename = "leaveDuration", default, skip_serializing_if = "Option::is_none")]
    pub field_4: Option<f64>,
    #[serde(rename = "interrupt", default, skip_serializing_if = "Option::is_none")]
    pub field_5: Option<GeneratedData1>,
}
  
  pub type GeneratedProps = GeneratedData0;
  fn authored_hook_0(definition: Value, input: Value) -> Value {
    let owner = definition.owner();
    authored_hook(&owner, "asTransition", "once", input, { let owner = owner.clone();  Value::Function(Rc::new(move |arguments: Vec<Value>| {
        let v_6465665f5f30373161336437333235653436626363: Value = arg(&arguments, 0);
        let v_7472616e736974696f6e53746174655f5f65303163613261316533316464326139: LexicalBinding<Value> = lexical_binding();
        let v_697350726573656e745f5f66326239653330626464653130623137: LexicalBinding<Value> = lexical_binding();
        let v_61707065617244656661756c745f5f63656639393262666666643138656161: LexicalBinding<Value> = lexical_binding();
        let v_636f6c64456e7472795072657061726174696f6e5f5f39643437643330643436356436303333: LexicalBinding<Value> = lexical_binding();
        let v_656e7465724475726174696f6e44656661756c745f5f38323233316533383366323536623961: LexicalBinding<Value> = lexical_binding();
        let v_6c656176654475726174696f6e44656661756c745f5f64333939303762353663333037346431: LexicalBinding<Value> = lexical_binding();
        let v_696e7465727275707444656661756c745f5f63356632373433613335316465323062: LexicalBinding<Value> = lexical_binding();
        let v_696e697469616c4f70656e536f75726365: LexicalBinding<Rc<std::cell::RefCell<Value>>> = lexical_binding();
        let v_70726573656e746174696f6e: LexicalBinding<Value> = lexical_binding();
        let v_636f6d706c6574696f6e: LexicalBinding<Rc<std::cell::RefCell<Value>>> = lexical_binding();
        let v_63757272656e7452756e: LexicalBinding<Rc<std::cell::RefCell<Value>>> = lexical_binding();
        let v_67657450726f7073: LexicalBinding<Value> = lexical_binding();
        let v_6d616368696e65: LexicalBinding<Value> = lexical_binding();
        // Source "transition/as-transition.proto.ts":42:5
        { let v_7075695f6e61746976655f30 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f313e = record(vec![("open", record(vec![("type", Value::string("boolean")), ("empty", Value::string("fallback"))])), ("defaultOpen", record(vec![("type", Value::string("boolean")), ("empty", Value::string("fallback"))])), ("appear", record(vec![("type", Value::string("boolean")), ("empty", Value::string("fallback"))])), ("enterDuration", record(vec![("type", Value::string("number")), ("empty", Value::string("fallback"))])), ("leaveDuration", record(vec![("type", Value::string("number")), ("empty", Value::string("fallback"))])), ("interrupt", record(vec![("type", Value::string("enum")), ("empty", Value::string("fallback")), ("options", Value::Array(Rc::new(vec![Value::string("reverse"), Value::string("wait"), Value::string("immediate")])))]))]); let v_7075695f6e61746976655f32 = props_define(&owner, v_3c636170747572653a7075695f6e61746976655f313e.clone()); capture_effect(&owner, "props", record(vec![("op", Value::string("define")), ("specMap", v_3c636170747572653a7075695f6e61746976655f313e.clone())]));    v_7075695f6e61746976655f32 } };
        // Source "transition/as-transition.proto.ts":54:5
        { let v_7075695f6e61746976655f33 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f343e = record(vec![("defaultOpen", Value::boolean(false)), ("appear", Value::boolean(false)), ("enterDuration", Value::number(300.0_f64)), ("leaveDuration", Value::number(200.0_f64)), ("interrupt", Value::string("reverse"))]); let v_7075695f6e61746976655f35 = set_defaults(&owner, v_3c636170747572653a7075695f6e61746976655f343e.clone()); capture_effect(&owner, "props", record(vec![("op", Value::string("setDefaults")), ("partial", v_3c636170747572653a7075695f6e61746976655f343e.clone())]));    v_7075695f6e61746976655f35 } };
        // Source "transition/as-transition.proto.ts":62:5
        { let v_7075695f6e61746976655f36 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f373e = Value::string("beforeEnter"); let v_3c636170747572653a7075695f6e61746976655f383e = record(vec![("payload", Value::string("void"))]); let v_7075695f6e61746976655f39 = expose_event(&owner, v_3c636170747572653a7075695f6e61746976655f373e.clone()); capture_effect(&owner, "event", record(vec![("op", Value::string("expose.event")), ("key", v_3c636170747572653a7075695f6e61746976655f373e.clone()), ("spec", v_3c636170747572653a7075695f6e61746976655f383e.clone())]));  capture_event_key(&owner, v_3c636170747572653a7075695f6e61746976655f373e.clone());  v_7075695f6e61746976655f39 } };
        // Source "transition/as-transition.proto.ts":63:5
        { let v_7075695f6e61746976655f3130 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f31313e = Value::string("afterEnter"); let v_3c636170747572653a7075695f6e61746976655f31323e = record(vec![("payload", Value::string("void"))]); let v_7075695f6e61746976655f3133 = expose_event(&owner, v_3c636170747572653a7075695f6e61746976655f31313e.clone()); capture_effect(&owner, "event", record(vec![("op", Value::string("expose.event")), ("key", v_3c636170747572653a7075695f6e61746976655f31313e.clone()), ("spec", v_3c636170747572653a7075695f6e61746976655f31323e.clone())]));  capture_event_key(&owner, v_3c636170747572653a7075695f6e61746976655f31313e.clone());  v_7075695f6e61746976655f3133 } };
        // Source "transition/as-transition.proto.ts":64:5
        { let v_7075695f6e61746976655f3134 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f31353e = Value::string("beforeLeave"); let v_3c636170747572653a7075695f6e61746976655f31363e = record(vec![("payload", Value::string("void"))]); let v_7075695f6e61746976655f3137 = expose_event(&owner, v_3c636170747572653a7075695f6e61746976655f31353e.clone()); capture_effect(&owner, "event", record(vec![("op", Value::string("expose.event")), ("key", v_3c636170747572653a7075695f6e61746976655f31353e.clone()), ("spec", v_3c636170747572653a7075695f6e61746976655f31363e.clone())]));  capture_event_key(&owner, v_3c636170747572653a7075695f6e61746976655f31353e.clone());  v_7075695f6e61746976655f3137 } };
        // Source "transition/as-transition.proto.ts":65:5
        { let v_7075695f6e61746976655f3138 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f31393e = Value::string("afterLeave"); let v_3c636170747572653a7075695f6e61746976655f32303e = record(vec![("payload", Value::string("void"))]); let v_7075695f6e61746976655f3231 = expose_event(&owner, v_3c636170747572653a7075695f6e61746976655f31393e.clone()); capture_effect(&owner, "event", record(vec![("op", Value::string("expose.event")), ("key", v_3c636170747572653a7075695f6e61746976655f31393e.clone()), ("spec", v_3c636170747572653a7075695f6e61746976655f32303e.clone())]));  capture_event_key(&owner, v_3c636170747572653a7075695f6e61746976655f31393e.clone());  v_7075695f6e61746976655f3231 } };
        // Source "transition/as-transition.proto.ts":67:11
        v_7472616e736974696f6e53746174655f5f65303163613261316533316464326139.initialize({ let v_7075695f6e61746976655f3232 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f32333e = Value::string("transitionState"); let v_3c636170747572653a7075695f6e61746976655f32343e = Value::string("closed"); let v_3c636170747572653a7075695f6e61746976655f32353e = record(vec![("options", Value::Array(Rc::new(vec![Value::string("closed"), Value::string("preparing"), Value::string("entering"), Value::string("entered"), Value::string("leaving")])))]); let v_7075695f6e61746976655f3236 = create_state(&owner, "enum", v_3c636170747572653a7075695f6e61746976655f32333e.clone(), v_3c636170747572653a7075695f6e61746976655f32343e.clone(), v_3c636170747572653a7075695f6e61746976655f32353e.clone()); capture_effect(&owner, "state", v_7075695f6e61746976655f3236.clone());    v_7075695f6e61746976655f3236 } });
        // Source "transition/as-transition.proto.ts":72:11
        v_697350726573656e745f5f66326239653330626464653130623137.initialize({ let v_7075695f6e61746976655f3237 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f32383e = Value::string("isPresent"); let v_3c636170747572653a7075695f6e61746976655f32393e = Value::boolean(false); let v_7075695f6e61746976655f3330 = create_state(&owner, "bool", v_3c636170747572653a7075695f6e61746976655f32383e.clone(), Value::boolean((v_3c636170747572653a7075695f6e61746976655f32393e.clone()).bool()), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3330.clone());    v_7075695f6e61746976655f3330 } });
        // Source "transition/as-transition.proto.ts":73:11
        v_61707065617244656661756c745f5f63656639393262666666643138656161.initialize({ let v_7075695f6e61746976655f3331 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f33323e = Value::string("transitionAppearDefault"); let v_3c636170747572653a7075695f6e61746976655f33333e = Value::boolean(false); let v_7075695f6e61746976655f3334 = create_state(&owner, "bool", v_3c636170747572653a7075695f6e61746976655f33323e.clone(), Value::boolean((v_3c636170747572653a7075695f6e61746976655f33333e.clone()).bool()), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3334.clone());    v_7075695f6e61746976655f3334 } });
        // Source "transition/as-transition.proto.ts":74:11
        v_636f6c64456e7472795072657061726174696f6e5f5f39643437643330643436356436303333.initialize({ let v_7075695f6e61746976655f3335 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f33363e = Value::string("transitionColdEntryPreparation"); let v_3c636170747572653a7075695f6e61746976655f33373e = Value::boolean(false); let v_7075695f6e61746976655f3338 = create_state(&owner, "bool", v_3c636170747572653a7075695f6e61746976655f33363e.clone(), Value::boolean((v_3c636170747572653a7075695f6e61746976655f33373e.clone()).bool()), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3338.clone());    v_7075695f6e61746976655f3338 } });
        // Source "transition/as-transition.proto.ts":75:11
        v_656e7465724475726174696f6e44656661756c745f5f38323233316533383366323536623961.initialize({ let v_7075695f6e61746976655f3339 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f34303e = Value::string("transitionEnterDurationDefault"); let v_3c636170747572653a7075695f6e61746976655f34313e = Value::number(300.0_f64); let v_7075695f6e61746976655f3432 = create_state(&owner, "discrete", v_3c636170747572653a7075695f6e61746976655f34303e.clone(), Value::number((v_3c636170747572653a7075695f6e61746976655f34313e.clone()).num()), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3432.clone());    v_7075695f6e61746976655f3432 } });
        // Source "transition/as-transition.proto.ts":76:11
        v_6c656176654475726174696f6e44656661756c745f5f64333939303762353663333037346431.initialize({ let v_7075695f6e61746976655f3433 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f34343e = Value::string("transitionLeaveDurationDefault"); let v_3c636170747572653a7075695f6e61746976655f34353e = Value::number(200.0_f64); let v_7075695f6e61746976655f3436 = create_state(&owner, "discrete", v_3c636170747572653a7075695f6e61746976655f34343e.clone(), Value::number((v_3c636170747572653a7075695f6e61746976655f34353e.clone()).num()), Value::Undefined); capture_effect(&owner, "state", v_7075695f6e61746976655f3436.clone());    v_7075695f6e61746976655f3436 } });
        // Source "transition/as-transition.proto.ts":77:11
        v_696e7465727275707444656661756c745f5f63356632373433613335316465323062.initialize({ let v_7075695f6e61746976655f3437 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f34383e = Value::string("transitionInterruptDefault"); let v_3c636170747572653a7075695f6e61746976655f34393e = Value::string("reverse"); let v_3c636170747572653a7075695f6e61746976655f35303e = record(vec![("options", Value::Array(Rc::new(vec![Value::string("reverse"), Value::string("wait"), Value::string("immediate")])))]); let v_7075695f6e61746976655f3531 = create_state(&owner, "enum", v_3c636170747572653a7075695f6e61746976655f34383e.clone(), v_3c636170747572653a7075695f6e61746976655f34393e.clone(), v_3c636170747572653a7075695f6e61746976655f35303e.clone()); capture_effect(&owner, "state", v_7075695f6e61746976655f3531.clone());    v_7075695f6e61746976655f3531 } });
        // Source "transition/as-transition.proto.ts":83:9
        v_696e697469616c4f70656e536f75726365.initialize(Rc::new(std::cell::RefCell::new(Value::Json(Json::Null))));
        // Source "transition/as-transition.proto.ts":85:11
        let v_62696e64496e697469616c4f70656e5f5f32383638643335663934386533643563 = {  let v_61707065617244656661756c745f5f63656639393262666666643138656161 = v_61707065617244656661756c745f5f63656639393262666666643138656161.clone(); let v_696e697469616c4f70656e536f75726365 = v_696e697469616c4f70656e536f75726365.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_736f75726365: Value = arg(&arguments, 0);
            // Source "transition/as-transition.proto.ts":87:7
            { let v_7075695f6e61746976655f3532 = v_61707065617244656661756c745f5f63656639393262666666643138656161.read(); state_default(v_7075695f6e61746976655f3532.clone(), Value::boolean(({ let v_7075695f6e61746976655f3533 = v_61707065617244656661756c745f5f63656639393262666666643138656161.read(); Value::boolean(((v_7075695f6e61746976655f3533.clone()).get()).bool()) }).bool())) };
            // Source "transition/as-transition.proto.ts":88:7
            if { let pui_native_54={ let pui_native_56={ let pui_native_58={ let pui_native_60=!((v_736f75726365.clone()).truthy()); if !(pui_native_60) {(Value::boolean(!strict_equal(&(typeof_value(&((v_736f75726365.clone()).member("field", false)))), &(Value::string("string"))))).bool()} else {pui_native_60} }; if !(pui_native_58) {!(((v_736f75726365.clone()).member("field", false)).truthy())} else {pui_native_58} }; if !(pui_native_56) {!(((v_736f75726365.clone()).member("context", false)).truthy())} else {pui_native_56} }; if !(pui_native_54) {(Value::boolean(!strict_equal(&(((v_736f75726365.clone()).member("context", false)).member("__brand", false)), &(Value::string("ContextKey"))))).bool()} else {pui_native_54} } {
                // Source "transition/as-transition.proto.ts":95:9
                throw_value(record(vec![("name", Value::string("Error")), ("message", (Value::string("[asTransition] initial open source requires a ContextKey and direct field.")).error_message_value())]));
            }
            // Source "transition/as-transition.proto.ts":99:7
            if ({ let value = (v_696e697469616c4f70656e536f75726365.read()).borrow().clone(); value }).truthy() {
                // Source "transition/as-transition.proto.ts":100:9
                if { let pui_native_66=(Value::boolean(strict_equal(&(({ let value = (v_696e697469616c4f70656e536f75726365.read()).borrow().clone(); value }).member("context", false)), &((v_736f75726365.clone()).member("context", false))))).bool(); if (pui_native_66) {(Value::boolean(strict_equal(&(({ let value = (v_696e697469616c4f70656e536f75726365.read()).borrow().clone(); value }).member("field", false)), &((v_736f75726365.clone()).member("field", false))))).bool()} else {pui_native_66} } {
                    // Source "transition/as-transition.proto.ts":104:11
                    return Value::Undefined;
                }
                // Source "transition/as-transition.proto.ts":105:9
                throw_value(record(vec![("name", Value::string("Error")), ("message", (Value::string("[asTransition] initial open source is already bound.")).error_message_value())]));
            }
            // Source "transition/as-transition.proto.ts":107:7
            { let value = freeze(record(vec![("context", (v_736f75726365.clone()).member("context", false)), ("field", (v_736f75726365.clone()).member("field", false))])); *(v_696e697469616c4f70656e536f75726365.read()).borrow_mut() = value; }
            Value::Undefined
        })) };
        // Source "transition/as-transition.proto.ts":109:5
        { let v_7075695f6e61746976655f3732 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f37333e = Value::string("bindInitialOpen"); let v_3c636170747572653a7075695f6e61746976655f37343e = v_62696e64496e697469616c4f70656e5f5f32383638643335663934386533643563.clone(); let v_7075695f6e61746976655f3735 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f37333e.clone(), v_3c636170747572653a7075695f6e61746976655f37343e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f37333e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f37343e.clone())]));    v_7075695f6e61746976655f3735 } };
        // Source "transition/as-transition.proto.ts":111:11
        v_70726573656e746174696f6e.initialize({ let v_7075695f6e61746976655f3736 = v_6465665f5f30373161336437333235653436626363.clone(); presence_owner(&owner) });
        // Source "transition/as-transition.proto.ts":112:9
        v_636f6d706c6574696f6e.initialize(Rc::new(std::cell::RefCell::new(Value::string("timer"))));
        // Source "transition/as-transition.proto.ts":113:5
        { let v_7075695f6e61746976655f3737 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f37383e = Value::string("getPresentationOwner"); let v_3c636170747572653a7075695f6e61746976655f37393e = {  let v_70726573656e746174696f6e = v_70726573656e746174696f6e.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
            // Source "transition/as-transition.proto.ts":113:53
            return (v_70726573656e746174696f6e.read()).member("ref", false);
        })) }; let v_7075695f6e61746976655f3830 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f37383e.clone(), v_3c636170747572653a7075695f6e61746976655f37393e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f37383e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f37393e.clone())]));    v_7075695f6e61746976655f3830 } };
        // Source "transition/as-transition.proto.ts":114:5
        { let v_7075695f6e61746976655f3831 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f3130343e = Value::string("configurePresentation"); let v_3c636170747572653a7075695f6e61746976655f3130353e = {  let v_61707065617244656661756c745f5f63656639393262666666643138656161 = v_61707065617244656661756c745f5f63656639393262666666643138656161.clone(); let v_656e7465724475726174696f6e44656661756c745f5f38323233316533383366323536623961 = v_656e7465724475726174696f6e44656661756c745f5f38323233316533383366323536623961.clone(); let v_6c656176654475726174696f6e44656661756c745f5f64333939303762353663333037346431 = v_6c656176654475726174696f6e44656661756c745f5f64333939303762353663333037346431.clone(); let v_636f6d706c6574696f6e = v_636f6d706c6574696f6e.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_636f6e6669675f5f32303262356132326361623830353061: Value = arg(&arguments, 0);
            // Source "transition/as-transition.proto.ts":115:7
            { let v_7075695f6e61746976655f3832 = v_61707065617244656661756c745f5f63656639393262666666643138656161.read(); state_default(v_7075695f6e61746976655f3832.clone(), Value::boolean(({ let v_7075695f6e61746976655f3833 = v_61707065617244656661756c745f5f63656639393262666666643138656161.read(); Value::boolean(((v_7075695f6e61746976655f3833.clone()).get()).bool()) }).bool())) };
            // Source "transition/as-transition.proto.ts":116:13
            let v_706f6c6963795f5f33396464663834333935343233366538 = snapshot_completion({ let left = (v_636f6e6669675f5f32303262356132326361623830353061.clone()).member("completion", false); if left.nullish() { { let value = (v_636f6d706c6574696f6e.read()).borrow().clone(); value } } else { left } });
            // Source "transition/as-transition.proto.ts":117:13
            let v_656e7465725f5f64643939653831353236633433356434: f64 = { let pui_native_84=(v_636f6e6669675f5f32303262356132326361623830353061.clone()).member("enterDuration", false); if pui_native_84.nullish() {({ let v_7075695f6e61746976655f3836 = v_656e7465724475726174696f6e44656661756c745f5f38323233316533383366323536623961.read(); Value::number(((v_7075695f6e61746976655f3836.clone()).get()).num()) }).num()} else {(pui_native_84).num()} };
            // Source "transition/as-transition.proto.ts":118:13
            let v_6c656176655f5f34356234633965323861383237313164: f64 = { let pui_native_87=(v_636f6e6669675f5f32303262356132326361623830353061.clone()).member("leaveDuration", false); if pui_native_87.nullish() {({ let v_7075695f6e61746976655f3839 = v_6c656176654475726174696f6e44656661756c745f5f64333939303762353663333037346431.read(); Value::number(((v_7075695f6e61746976655f3839.clone()).get()).num()) }).num()} else {(pui_native_87).num()} };
            // Source "transition/as-transition.proto.ts":119:7
            if !((array_every(Value::Array(Rc::new(vec![Value::number(v_656e7465725f5f64643939653831353236633433356434.clone()), Value::number(v_6c656176655f5f34356234633965323861383237313164.clone())])), ({   let call:Rc<dyn Fn(f64)->bool>=Rc::new(move |argument_0: f64| -> bool {
                let v_76616c75655f5f38346337343662626337656435346331: f64 = argument_0;
                // Source "transition/as-transition.proto.ts":119:44
                return { let pui_native_90=(v_76616c75655f5f38346337343662626337656435346331.clone()).is_finite(); if (pui_native_90) {{ let pui_native_92:f64=v_76616c75655f5f38346337343662626337656435346331.clone(); let pui_native_93:f64=0.0_f64; pui_native_92 >= pui_native_93 }} else {pui_native_90} };
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call((arg(&arguments,0)).num()))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable"))).bool()) {
                // Source "transition/as-transition.proto.ts":120:9
                throw_value(record(vec![("name", Value::string("Error")), ("message", (Value::string("[asTransition] durations must be finite non-negative numbers.")).error_message_value())]));
            }
            // Source "transition/as-transition.proto.ts":121:7
            if { let pui_native_94=(Value::boolean(!strict_equal(&(v_706f6c6963795f5f33396464663834333935343233366538.clone()), &(Value::string("timer"))))).bool(); if (pui_native_94) {{ let pui_native_98={ let pui_native_100:f64=v_656e7465725f5f64643939653831353236633433356434.clone(); let pui_native_101:f64=((v_706f6c6963795f5f33396464663834333935343233366538.clone()).member("timeoutMs", false)).num(); pui_native_100 >= pui_native_101 }; if !(pui_native_98) {{ let pui_native_102:f64=v_6c656176655f5f34356234633965323861383237313164.clone(); let pui_native_103:f64=((v_706f6c6963795f5f33396464663834333935343233366538.clone()).member("timeoutMs", false)).num(); pui_native_102 >= pui_native_103 }} else {pui_native_98} }} else {pui_native_94} } {
                // Source "transition/as-transition.proto.ts":122:9
                throw_value(record(vec![("name", Value::string("Error")), ("message", (Value::string("[asTransition] presentation duration must be shorter than timeoutMs.")).error_message_value())]));
            }
            // Source "transition/as-transition.proto.ts":123:7
            { let value = v_706f6c6963795f5f33396464663834333935343233366538.clone(); *(v_636f6d706c6574696f6e.read()).borrow_mut() = value; }
            Value::Undefined
        })) }; let v_7075695f6e61746976655f313036 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3130343e.clone(), v_3c636170747572653a7075695f6e61746976655f3130353e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3130343e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3130353e.clone())]));    v_7075695f6e61746976655f313036 } };
        // Source "transition/as-transition.proto.ts":125:9
        v_63757272656e7452756e.initialize(Rc::new(std::cell::RefCell::new(Value::Json(Json::Null))));
        // Source "transition/as-transition.proto.ts":126:11
        v_67657450726f7073.initialize({  let v_63757272656e7452756e = v_63757272656e7452756e.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
            // Source "transition/as-transition.proto.ts":126:28
            return { let v_7075695f6e61746976655f313037 = { let value = (v_63757272656e7452756e.read()).borrow().clone(); value }; if v_7075695f6e61746976655f313037.nullish() { Value::Undefined } else { read_props(&(v_7075695f6e61746976655f313037.clone()).owner(), false) } };
        })) });
        // Source "transition/as-transition.proto.ts":128:11
        let v_6472697665725f5f62363462623037646239326661613063 = record(vec![("getState", {  let v_7472616e736974696f6e53746174655f5f65303163613261316533316464326139 = v_7472616e736974696f6e53746174655f5f65303163613261316533316464326139.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
            // Source "transition/as-transition.proto.ts":129:23
            return { let v_7075695f6e61746976655f313038 = v_7472616e736974696f6e53746174655f5f65303163613261316533316464326139.read(); (v_7075695f6e61746976655f313038.clone()).get() };
        })) }), ("setState", {  let v_7472616e736974696f6e53746174655f5f65303163613261316533316464326139 = v_7472616e736974696f6e53746174655f5f65303163613261316533316464326139.clone(); let v_697350726573656e745f5f66326239653330626464653130623137 = v_697350726573656e745f5f66326239653330626464653130623137.clone(); let v_63757272656e7452756e = v_63757272656e7452756e.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_73746174655f5f62343437333637316465643230366665: Value = arg(&arguments, 0);
            // Source "transition/as-transition.proto.ts":131:9
            { let v_7075695f6e61746976655f313039 = v_7472616e736974696f6e53746174655f5f65303163613261316533316464326139.read(); state_set(v_7075695f6e61746976655f313039.clone(), v_73746174655f5f62343437333637316465643230366665.clone(), add(Value::string("reason: asTransition => "), v_73746174655f5f62343437333637316465643230366665.clone())) };
            // Source "transition/as-transition.proto.ts":133:9
            if !(({ let value = (v_63757272656e7452756e.read()).borrow().clone(); value }).truthy()) {
                // Source "transition/as-transition.proto.ts":133:26
                return Value::Undefined;
            }
            // Source "transition/as-transition.proto.ts":135:15
            let v_63757272656e745374617465 = { let v_7075695f6e61746976655f313130 = v_7472616e736974696f6e53746174655f5f65303163613261316533316464326139.read(); (v_7075695f6e61746976655f313130.clone()).get() };
            // Source "transition/as-transition.proto.ts":136:9
            { let v_7075695f6e61746976655f313131 = v_697350726573656e745f5f66326239653330626464653130623137.read(); state_set(v_7075695f6e61746976655f313131.clone(), Value::boolean((Value::boolean(!strict_equal(&(v_63757272656e745374617465.clone()), &(Value::string("closed"))))).bool()), add(Value::string("reason: asTransition presence => "), v_63757272656e745374617465.clone())) };
            Value::Undefined
        })) }), ("requiresColdPreparation", ({  let v_636f6c64456e7472795072657061726174696f6e5f5f39643437643330643436356436303333 = v_636f6c64456e7472795072657061726174696f6e5f5f39643437643330643436356436303333.clone(); let call:Rc<dyn Fn()->bool>=Rc::new(move || -> bool {
            // Source "transition/as-transition.proto.ts":141:38
            return ({ let v_7075695f6e61746976655f313134 = v_636f6c64456e7472795072657061726174696f6e5f5f39643437643330643436356436303333.read(); Value::boolean(((v_7075695f6e61746976655f313134.clone()).get()).bool()) }).bool();
        }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")), ("getCompletion", {  let v_636f6d706c6574696f6e = v_636f6d706c6574696f6e.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
            // Source "transition/as-transition.proto.ts":142:28
            return { let value = (v_636f6d706c6574696f6e.read()).borrow().clone(); value };
        })) }), ("publishPresentation", {  let v_70726573656e746174696f6e = v_70726573656e746174696f6e.clone(); let v_63757272656e7452756e = v_63757272656e7452756e.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_6672616d655f5f62333937346364393934613563613537: Value = arg(&arguments, 0);
            // Source "transition/as-transition.proto.ts":144:9
            return { let v_7075695f6e61746976655f313135 = { let value = (v_63757272656e7452756e.read()).borrow().clone(); value }; if v_7075695f6e61746976655f313135.nullish() { Value::Undefined } else { presence_publish(&(v_7075695f6e61746976655f313135.clone()).owner(), (v_70726573656e746174696f6e.read()).member("writer", false), { let mut fields = std::collections::BTreeMap::new(); fields.extend(own_entries(v_6672616d655f5f62333937346364393934613563613537.clone())); fields.insert("owner".into(), (v_70726573656e746174696f6e.read()).member("ref", false)); record_map(fields) }) } };
        })) }), ("settlePresentation", {  let v_70726573656e746174696f6e = v_70726573656e746174696f6e.clone(); let v_63757272656e7452756e = v_63757272656e7452756e.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_6f7574636f6d655f5f34323061653130656263633136373834: Value = arg(&arguments, 0);
            // Source "transition/as-transition.proto.ts":149:9
            return { let v_7075695f6e61746976655f313136 = { let value = (v_63757272656e7452756e.read()).borrow().clone(); value }; if v_7075695f6e61746976655f313136.nullish() { Value::Undefined } else { presence_settle(&(v_7075695f6e61746976655f313136.clone()).owner(), (v_70726573656e746174696f6e.read()).member("writer", false), v_6f7574636f6d655f5f34323061653130656263633136373834.clone()) } };
        })) }), ("getInterrupt", {  let v_696e7465727275707444656661756c745f5f63356632373433613335316465323062 = v_696e7465727275707444656661756c745f5f63356632373433613335316465323062.clone(); let v_63757272656e7452756e = v_63757272656e7452756e.clone(); let v_67657450726f7073 = v_67657450726f7073.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
            // Source "transition/as-transition.proto.ts":151:9
            return if ({ let v_7075695f6e61746976655f313137 = { let value = (v_63757272656e7452756e.read()).borrow().clone(); value }; if v_7075695f6e61746976655f313137.nullish() { Value::Undefined } else { is_provided(&(v_7075695f6e61746976655f313137.clone()).owner(), Value::string("interrupt")) } }).truthy() { { let left = (v_67657450726f7073.read().call_authored(vec![])).member("interrupt", true); if left.nullish() { { let v_7075695f6e61746976655f313138 = v_696e7465727275707444656661756c745f5f63356632373433613335316465323062.read(); (v_7075695f6e61746976655f313138.clone()).get() } } else { left } } } else { { let v_7075695f6e61746976655f313139 = v_696e7465727275707444656661756c745f5f63356632373433613335316465323062.read(); (v_7075695f6e61746976655f313139.clone()).get() } };
        })) }), ("getDuration", ({  let v_656e7465724475726174696f6e44656661756c745f5f38323233316533383366323536623961 = v_656e7465724475726174696f6e44656661756c745f5f38323233316533383366323536623961.clone(); let v_6c656176654475726174696f6e44656661756c745f5f64333939303762353663333037346431 = v_6c656176654475726174696f6e44656661756c745f5f64333939303762353663333037346431.clone(); let v_63757272656e7452756e = v_63757272656e7452756e.clone(); let v_67657450726f7073 = v_67657450726f7073.clone(); let call:Rc<dyn Fn(Value)->f64>=Rc::new(move |argument_0: Value| -> f64 {
            let v_73746174655f5f37363032613434346335633365666237: Value = argument_0;
            // Source "transition/as-transition.proto.ts":158:9
            if (Value::boolean(strict_equal(&({ let v_7075695f6e61746976655f313232 = { let value = (v_63757272656e7452756e.read()).borrow().clone(); value }; if v_7075695f6e61746976655f313232.nullish() { Value::Undefined } else { native_meta_get(&(v_7075695f6e61746976655f313232.clone()).owner(), Value::string("reducedMotion")) } }), &(Value::string("reduce"))))).bool() {
                // Source "transition/as-transition.proto.ts":158:66
                return 0.0_f64;
            }
            // Source "transition/as-transition.proto.ts":159:9
            return if (Value::boolean(strict_equal(&(v_73746174655f5f37363032613434346335633365666237.clone()), &(Value::string("entering"))))).bool() {if ({ let v_7075695f6e61746976655f313235 = { let value = (v_63757272656e7452756e.read()).borrow().clone(); value }; if v_7075695f6e61746976655f313235.nullish() { Value::Undefined } else { is_provided(&(v_7075695f6e61746976655f313235.clone()).owner(), Value::string("enterDuration")) } }).truthy() {{ let pui_native_126=(v_67657450726f7073.read().call_authored(vec![])).member("enterDuration", true); if pui_native_126.nullish() {({ let v_7075695f6e61746976655f313238 = v_656e7465724475726174696f6e44656661756c745f5f38323233316533383366323536623961.read(); Value::number(((v_7075695f6e61746976655f313238.clone()).get()).num()) }).num()} else {(pui_native_126).num()} }} else {({ let v_7075695f6e61746976655f313239 = v_656e7465724475726174696f6e44656661756c745f5f38323233316533383366323536623961.read(); Value::number(((v_7075695f6e61746976655f313239.clone()).get()).num()) }).num()}} else {if ({ let v_7075695f6e61746976655f313330 = { let value = (v_63757272656e7452756e.read()).borrow().clone(); value }; if v_7075695f6e61746976655f313330.nullish() { Value::Undefined } else { is_provided(&(v_7075695f6e61746976655f313330.clone()).owner(), Value::string("leaveDuration")) } }).truthy() {{ let pui_native_131=(v_67657450726f7073.read().call_authored(vec![])).member("leaveDuration", true); if pui_native_131.nullish() {({ let v_7075695f6e61746976655f313333 = v_6c656176654475726174696f6e44656661756c745f5f64333939303762353663333037346431.read(); Value::number(((v_7075695f6e61746976655f313333.clone()).get()).num()) }).num()} else {(pui_native_131).num()} }} else {({ let v_7075695f6e61746976655f313334 = v_6c656176654475726174696f6e44656661756c745f5f64333939303762353663333037346431.read(); Value::number(((v_7075695f6e61746976655f313334.clone()).get()).num()) }).num()}};
        }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::number(ordinary_call(arg(&arguments,0)))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")), ("schedule", ({ let owner = owner.clone();  let call:Rc<dyn Fn(f64, Value)->Value>=Rc::new(move |argument_0: f64, argument_1: Value| -> Value {
            let v_6475726174696f6e4d73: f64 = argument_0;
            let v_63616c6c6261636b: Value = argument_1;
            // Source "transition/as-transition.proto.ts":167:43
            return schedule_delay(&owner, Value::number(v_6475726174696f6e4d73.clone()), v_63616c6c6261636b.clone());
        }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).num(), arg(&arguments,1))}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")), ("setViewPresent", ({  let v_63757272656e7452756e = v_63757272656e7452756e.clone(); let call:Rc<dyn Fn(bool)->Value>=Rc::new(move |argument_0: bool| -> Value {
            let v_70726573656e74: bool = argument_0;
            // Source "transition/as-transition.proto.ts":169:9
            if !(({ let value = (v_63757272656e7452756e.read()).borrow().clone(); value }).truthy()) {
                // Source "transition/as-transition.proto.ts":170:11
                throw_value(record(vec![("name", Value::string("Error")), ("message", (Value::string("[asTransition] runtime lifecycle handle is not available.")).error_message_value())]));
            }
            // Source "transition/as-transition.proto.ts":172:9
            { let v_7075695f6e61746976655f313335 = { let value = (v_63757272656e7452756e.read()).borrow().clone(); value }; set_present(&(v_7075695f6e61746976655f313335.clone()).owner(), Value::boolean(v_70726573656e74.clone())) };
            Value::Undefined
        }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {ordinary_call((arg(&arguments,0)).bool())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")), ("emit", {  let v_63757272656e7452756e = v_63757272656e7452756e.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_6576656e74: Value = arg(&arguments, 0);
            // Source "transition/as-transition.proto.ts":175:9
            { let v_7075695f6e61746976655f313336 = { let value = (v_63757272656e7452756e.read()).borrow().clone(); value }; if v_7075695f6e61746976655f313336.nullish() { Value::Undefined } else { emit(&(v_7075695f6e61746976655f313336.clone()).owner(), v_6576656e74.clone(), Value::Undefined) } };
            Value::Undefined
        })) })]);
        // Source "transition/as-transition.proto.ts":178:11
        v_6d616368696e65.initialize(v_5f5f7075694d6f64756c6530.with(|function| function.call_authored(vec![v_6472697665725f5f62363462623037646239326661613063.clone()])));
        // Source "transition/as-transition.proto.ts":179:5
        { let v_7075695f6e61746976655f313337 = v_70726573656e746174696f6e.read(); (v_7075695f6e61746976655f313337.clone()).member("onCompletionRequest", false).call_authored(vec![{  let v_70726573656e746174696f6e = v_70726573656e746174696f6e.clone(); let v_63757272656e7452756e = v_63757272656e7452756e.clone(); let v_6d616368696e65 = v_6d616368696e65.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_72756e5f5f62656130626463323136636665313336: LexicalBinding<Value> = lexical_binding();
            let v_72657175657374: LexicalBinding<Value> = lexical_binding();
            v_72756e5f5f62656130626463323136636665313336.initialize(arg(&arguments, 0));
            v_72657175657374.initialize(arg(&arguments, 1));
            // Source "transition/as-transition.proto.ts":180:7
            if !(({ let value = (v_63757272656e7452756e.read()).borrow().clone(); value }).truthy()) {
                // Source "transition/as-transition.proto.ts":180:24
                return Value::Undefined;
            }
            // Source "transition/as-transition.proto.ts":181:7
            if !(({ let v_7075695f6e61746976655f313338 = v_72756e5f5f62656130626463323136636665313336.read(); Value::boolean((presence_is_current(&(v_7075695f6e61746976655f313338.clone()).owner(), (v_70726573656e746174696f6e.read()).member("writer", false), (v_72657175657374.read()).member("receipt", false))).bool()) }).bool()) {
                // Source "transition/as-transition.proto.ts":181:83
                return Value::Undefined;
            }
            // Source "transition/as-transition.proto.ts":182:7
            Value::boolean(({ let callable = (v_6d616368696e65.read()).member("completePresentation", false); callable.call_authored(vec![((v_72657175657374.read()).member("receipt", false)).member("attempt", false), ({  let v_70726573656e746174696f6e = v_70726573656e746174696f6e.clone(); let v_63757272656e7452756e = v_63757272656e7452756e.clone(); let v_72756e5f5f62656130626463323136636665313336 = v_72756e5f5f62656130626463323136636665313336.clone(); let v_72657175657374 = v_72657175657374.clone(); let call:Rc<dyn Fn()->bool>=Rc::new(move || -> bool {
                // Source "transition/as-transition.proto.ts":184:15
                return { let pui_native_139=!(!(({ let value = (v_63757272656e7452756e.read()).borrow().clone(); value }).truthy())); if (pui_native_139) {({ let v_7075695f6e61746976655f313431 = v_72756e5f5f62656130626463323136636665313336.read(); Value::boolean((presence_is_current(&(v_7075695f6e61746976655f313431.clone()).owner(), (v_70726573656e746174696f6e.read()).member("writer", false), (v_72657175657374.read()).member("receipt", false))).bool()) }).bool()} else {pui_native_139} };
            }); {
      let ordinary_call=call.clone();
      let ordinary=Value::Function(Rc::new(move |arguments:Vec<Value>| {Value::boolean(ordinary_call())}));
      native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:Some(ordinary) }
    } }).ordinary.clone().expect("checked native data callable")]) }).bool());
            Value::Undefined
        })) }]) };
        // Source "transition/as-transition.proto.ts":188:11
        let v_636f6e74726f6c735f5f66363665636530613038643731663536 = record(vec![("enter", {  let v_6d616368696e65 = v_6d616368696e65.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
            // Source "transition/as-transition.proto.ts":189:20
            return { let callable = (v_6d616368696e65.read()).member("enter", false); callable.call_authored(vec![]) };
        })) }), ("leave", {  let v_6d616368696e65 = v_6d616368696e65.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
            // Source "transition/as-transition.proto.ts":190:20
            return { let callable = (v_6d616368696e65.read()).member("leave", false); callable.call_authored(vec![]) };
        })) }), ("complete", {  let v_6d616368696e65 = v_6d616368696e65.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
            // Source "transition/as-transition.proto.ts":191:23
            return { let callable = (v_6d616368696e65.read()).member("complete", false); callable.call_authored(vec![]) };
        })) }), ("capturePreparation", {  let v_63757272656e7452756e = v_63757272656e7452756e.clone(); let v_6d616368696e65 = v_6d616368696e65.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
            // Source "transition/as-transition.proto.ts":193:9
            if !(({ let value = (v_63757272656e7452756e.read()).borrow().clone(); value }).truthy()) {
                // Source "transition/as-transition.proto.ts":194:11
                throw_value(record(vec![("name", Value::string("Error")), ("message", (Value::string("[asTransition] preparation capture requires a live runtime.")).error_message_value())]));
            }
            // Source "transition/as-transition.proto.ts":195:9
            return { let callable = (v_6d616368696e65.read()).member("capturePreparation", false); callable.call_authored(vec![]) };
        })) })]);
        // Source "transition/as-transition.proto.ts":199:5
        { let v_7075695f6e61746976655f313432 = v_6465665f5f30373161336437333235653436626363.clone(); register_life(&owner, "created", {  let v_61707065617244656661756c745f5f63656639393262666666643138656161 = v_61707065617244656661756c745f5f63656639393262666666643138656161.clone(); let v_696e697469616c4f70656e536f75726365 = v_696e697469616c4f70656e536f75726365.clone(); let v_63757272656e7452756e = v_63757272656e7452756e.clone(); let v_6d616368696e65 = v_6d616368696e65.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_72756e5f5f31613464393839323965313833363462: Value = arg(&arguments, 0);
            // Source "transition/as-transition.proto.ts":200:7
            { let value = v_72756e5f5f31613464393839323965313833363462.clone(); *(v_63757272656e7452756e.read()).borrow_mut() = value; }
            // Source "transition/as-transition.proto.ts":201:13
            let v_70726f7073 = { let v_7075695f6e61746976655f313433 = v_72756e5f5f31613464393839323965313833363462.clone(); read_props(&(v_7075695f6e61746976655f313433.clone()).owner(), false) };
            // Source "transition/as-transition.proto.ts":202:13
            let v_636f6e74726f6c6c6564: bool = ({ let v_7075695f6e61746976655f313434 = v_72756e5f5f31613464393839323965313833363462.clone(); Value::boolean((is_provided(&(v_7075695f6e61746976655f313434.clone()).owner(), Value::string("open"))).bool()) }).bool();
            // Source "transition/as-transition.proto.ts":203:11
            let v_6f70656e5f5f64323332343337393033356463663735: Rc<std::cell::RefCell<bool>> = Rc::new(std::cell::RefCell::new(if v_636f6e74726f6c6c6564.clone() {!(!(((v_70726f7073.clone()).member("open", false)).bool()))} else {!(!(((v_70726f7073.clone()).member("defaultOpen", false)).bool()))}));
            // Source "transition/as-transition.proto.ts":204:7
            if ({ let left = Value::boolean({ let pui_native_145=!(v_636f6e74726f6c6c6564.clone()); if (pui_native_145) {!(({ let v_7075695f6e61746976655f313437 = v_72756e5f5f31613464393839323965313833363462.clone(); Value::boolean((is_provided(&(v_7075695f6e61746976655f313437.clone()).owner(), Value::string("defaultOpen"))).bool()) }).bool())} else {pui_native_145} }); if left.truthy() { { let value = (v_696e697469616c4f70656e536f75726365.read()).borrow().clone(); value } } else { left } }).truthy() {
                // Source "transition/as-transition.proto.ts":205:15
                let v_76616c75655f5f61363830653934313466636632623865 = { let v_7075695f6e61746976655f313438 = v_72756e5f5f31613464393839323965313833363462.clone(); context_read(&(v_7075695f6e61746976655f313438.clone()).owner(), ({ let value = (v_696e697469616c4f70656e536f75726365.read()).borrow().clone(); value }).member("context", false), false) };
                // Source "transition/as-transition.proto.ts":206:15
                let v_696e697469616c4f70656e = { let object = v_76616c75655f5f61363830653934313466636632623865.clone(); object.caught_member(&property_key(&(({ let value = (v_696e697469616c4f70656e536f75726365.read()).borrow().clone(); value }).member("field", false))), false) };
                // Source "transition/as-transition.proto.ts":207:9
                if { let pui_native_149=!((has_own(&(v_76616c75655f5f61363830653934313466636632623865.clone()), &(({ let value = (v_696e697469616c4f70656e536f75726365.read()).borrow().clone(); value }).member("field", false)))).bool()); if !(pui_native_149) {(Value::boolean(!strict_equal(&(typeof_value(&(v_696e697469616c4f70656e.clone()))), &(Value::string("boolean"))))).bool()} else {pui_native_149} } {
                    // Source "transition/as-transition.proto.ts":208:11
                    throw_value(record(vec![("name", Value::string("Error")), ("message", (Value::string("[asTransition] initial open context field must be a required boolean.")).error_message_value())]));
                }
                // Source "transition/as-transition.proto.ts":210:9
                Value::boolean({ let value=(v_696e697469616c4f70656e.clone()).bool(); *(v_6f70656e5f5f64323332343337393033356463663735.clone()).borrow_mut()=value.clone(); value });
            }
            // Source "transition/as-transition.proto.ts":212:13
            let v_6170706561725f5f35393432353331363835303130666632: bool = if ({ let v_7075695f6e61746976655f313533 = v_72756e5f5f31613464393839323965313833363462.clone(); Value::boolean((is_provided(&(v_7075695f6e61746976655f313533.clone()).owner(), Value::string("appear"))).bool()) }).bool() {!(!(((v_70726f7073.clone()).member("appear", false)).bool()))} else {({ let v_7075695f6e61746976655f313534 = v_61707065617244656661756c745f5f63656639393262666666643138656161.read(); Value::boolean(((v_7075695f6e61746976655f313534.clone()).get()).bool()) }).bool()};
            // Source "transition/as-transition.proto.ts":213:7
            { let callable = (v_6d616368696e65.read()).member("initialize", false); callable.call_authored(vec![Value::boolean({ let value=(v_6f70656e5f5f64323332343337393033356463663735.clone()).borrow().clone(); value }), Value::boolean(v_6170706561725f5f35393432353331363835303130666632.clone())]) };
            Value::Undefined
        })) }) };
        // Source "transition/as-transition.proto.ts":216:5
        { let v_7075695f6e61746976655f313535 = v_6465665f5f30373161336437333235653436626363.clone(); register_life(&owner, "mounted", {  let v_63757272656e7452756e = v_63757272656e7452756e.clone(); let v_6d616368696e65 = v_6d616368696e65.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_72756e5f5f30386264363966373030336639396638: Value = arg(&arguments, 0);
            // Source "transition/as-transition.proto.ts":217:7
            { let value = v_72756e5f5f30386264363966373030336639396638.clone(); *(v_63757272656e7452756e.read()).borrow_mut() = value; }
            // Source "transition/as-transition.proto.ts":218:7
            { let callable = (v_6d616368696e65.read()).member("mounted", false); callable.call_authored(vec![]) };
            Value::Undefined
        })) }) };
        // Source "transition/as-transition.proto.ts":221:5
        { let v_7075695f6e61746976655f313536 = v_6465665f5f30373161336437333235653436626363.clone(); register_life(&owner, "unmounted", {  let v_63757272656e7452756e = v_63757272656e7452756e.clone(); let v_6d616368696e65 = v_6d616368696e65.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_72756e5f5f36306132626565633231386538623031: Value = arg(&arguments, 0);
            // Source "transition/as-transition.proto.ts":222:7
            { let value = v_72756e5f5f36306132626565633231386538623031.clone(); *(v_63757272656e7452756e.read()).borrow_mut() = value; }
            // Source "transition/as-transition.proto.ts":223:7
            { let callable = (v_6d616368696e65.read()).member("unmounted", false); callable.call_authored(vec![]) };
            Value::Undefined
        })) }) };
        // Source "transition/as-transition.proto.ts":226:5
        { let v_7075695f6e61746976655f313537 = v_6465665f5f30373161336437333235653436626363.clone(); register_life(&owner, "before-dispose", {  let v_63757272656e7452756e = v_63757272656e7452756e.clone(); let v_6d616368696e65 = v_6d616368696e65.clone(); Value::Function(Rc::new(move |_: Vec<Value>| {
            // Source "transition/as-transition.proto.ts":227:7
            { let callable = (v_6d616368696e65.read()).member("dispose", false); callable.call_authored(vec![]) };
            // Source "transition/as-transition.proto.ts":228:7
            { let value = Value::Json(Json::Null); *(v_63757272656e7452756e.read()).borrow_mut() = value; }
            Value::Undefined
        })) }) };
        // Source "transition/as-transition.proto.ts":231:5
        { let v_7075695f6e61746976655f313538 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f3136303e = Value::Array(Rc::new(vec![Value::string("open"), Value::string("interrupt"), Value::string("enterDuration"), Value::string("leaveDuration")])); let v_3c636170747572653a7075695f6e61746976655f3136313e = {  let v_63757272656e7452756e = v_63757272656e7452756e.clone(); let v_6d616368696e65 = v_6d616368696e65.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_72756e5f5f61613432653137386231306231316134: Value = arg(&arguments, 0);
            let v_6e6578745f5f35323434363333646539353862643662: Value = arg(&arguments, 1);
            // Source "transition/as-transition.proto.ts":232:7
            { let value = v_72756e5f5f61613432653137386231306231316134.clone(); *(v_63757272656e7452756e.read()).borrow_mut() = value; }
            // Source "transition/as-transition.proto.ts":233:7
            if !(({ let v_7075695f6e61746976655f313539 = v_72756e5f5f61613432653137386231306231316134.clone(); Value::boolean((is_provided(&(v_7075695f6e61746976655f313539.clone()).owner(), Value::string("open"))).bool()) }).bool()) {
                // Source "transition/as-transition.proto.ts":233:42
                return Value::Undefined;
            }
            // Source "transition/as-transition.proto.ts":234:7
            { let callable = (v_6d616368696e65.read()).member("setTarget", false); callable.call_authored(vec![Value::boolean(!(!(((v_6e6578745f5f35323434363333646539353862643662.clone()).member("open", false)).bool())))]) };
            Value::Undefined
        })) }; let v_7075695f6e61746976655f313632 = watch_props(&owner, Some(v_3c636170747572653a7075695f6e61746976655f3136303e.clone()), false, v_3c636170747572653a7075695f6e61746976655f3136313e.clone()); capture_effect(&owner, "props", record(vec![("op", Value::string("watch")), ("keys", v_3c636170747572653a7075695f6e61746976655f3136303e.clone()), ("off", v_7075695f6e61746976655f313632.clone())])); capture_disposer(&owner, "props", v_7075695f6e61746976655f313632.clone());   v_7075695f6e61746976655f313632 } };
        // Source "transition/as-transition.proto.ts":237:5
        { let v_7075695f6e61746976655f313633 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f3136343e = Value::string("transitionState"); let v_3c636170747572653a7075695f6e61746976655f3136353e = v_7472616e736974696f6e53746174655f5f65303163613261316533316464326139.read(); let v_7075695f6e61746976655f313636 = expose_state(&owner, v_3c636170747572653a7075695f6e61746976655f3136343e.clone(), v_3c636170747572653a7075695f6e61746976655f3136353e.clone()); capture_effect(&owner, "state", record(vec![("op", Value::string("expose.state")), ("key", v_3c636170747572653a7075695f6e61746976655f3136343e.clone()), ("handle", v_3c636170747572653a7075695f6e61746976655f3136353e.clone())]));   capture_introduced_state(&owner, v_3c636170747572653a7075695f6e61746976655f3136353e.clone()); v_7075695f6e61746976655f313636 } };
        // Source "transition/as-transition.proto.ts":238:5
        { let v_7075695f6e61746976655f313637 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f3136383e = Value::string("isPresent"); let v_3c636170747572653a7075695f6e61746976655f3136393e = v_697350726573656e745f5f66326239653330626464653130623137.read(); let v_7075695f6e61746976655f313730 = expose_state(&owner, v_3c636170747572653a7075695f6e61746976655f3136383e.clone(), v_3c636170747572653a7075695f6e61746976655f3136393e.clone()); capture_effect(&owner, "state", record(vec![("op", Value::string("expose.state")), ("key", v_3c636170747572653a7075695f6e61746976655f3136383e.clone()), ("handle", v_3c636170747572653a7075695f6e61746976655f3136393e.clone())]));   capture_introduced_state(&owner, v_3c636170747572653a7075695f6e61746976655f3136393e.clone()); v_7075695f6e61746976655f313730 } };
        // Source "transition/as-transition.proto.ts":239:5
        { let v_7075695f6e61746976655f313731 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f3137323e = Value::string("enter"); let v_3c636170747572653a7075695f6e61746976655f3137333e = (v_636f6e74726f6c735f5f66363665636530613038643731663536.clone()).member("enter", false); let v_7075695f6e61746976655f313734 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3137323e.clone(), v_3c636170747572653a7075695f6e61746976655f3137333e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3137323e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3137333e.clone())]));    v_7075695f6e61746976655f313734 } };
        // Source "transition/as-transition.proto.ts":240:5
        { let v_7075695f6e61746976655f313735 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f3137363e = Value::string("leave"); let v_3c636170747572653a7075695f6e61746976655f3137373e = (v_636f6e74726f6c735f5f66363665636530613038643731663536.clone()).member("leave", false); let v_7075695f6e61746976655f313738 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3137363e.clone(), v_3c636170747572653a7075695f6e61746976655f3137373e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3137363e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3137373e.clone())]));    v_7075695f6e61746976655f313738 } };
        // Source "transition/as-transition.proto.ts":241:5
        { let v_7075695f6e61746976655f313739 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f3138303e = Value::string("complete"); let v_3c636170747572653a7075695f6e61746976655f3138313e = (v_636f6e74726f6c735f5f66363665636530613038643731663536.clone()).member("complete", false); let v_7075695f6e61746976655f313832 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3138303e.clone(), v_3c636170747572653a7075695f6e61746976655f3138313e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3138303e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3138313e.clone())]));    v_7075695f6e61746976655f313832 } };
        // Source "transition/as-transition.proto.ts":242:5
        { let v_7075695f6e61746976655f313833 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f3138343e = Value::string("capturePreparation"); let v_3c636170747572653a7075695f6e61746976655f3138353e = (v_636f6e74726f6c735f5f66363665636530613038643731663536.clone()).member("capturePreparation", false); let v_7075695f6e61746976655f313836 = expose_method(&owner, v_3c636170747572653a7075695f6e61746976655f3138343e.clone(), v_3c636170747572653a7075695f6e61746976655f3138353e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.method")), ("key", v_3c636170747572653a7075695f6e61746976655f3138343e.clone()), ("fn", v_3c636170747572653a7075695f6e61746976655f3138353e.clone())]));    v_7075695f6e61746976655f313836 } };
        // Source "transition/as-transition.proto.ts":243:5
        { let v_7075695f6e61746976655f313837 = v_6465665f5f30373161336437333235653436626363.clone(); { let v_3c636170747572653a7075695f6e61746976655f3138383e = Value::string("controls"); let v_3c636170747572653a7075695f6e61746976655f3138393e = v_636f6e74726f6c735f5f66363665636530613038643731663536.clone(); let v_7075695f6e61746976655f313930 = expose_value(&owner, v_3c636170747572653a7075695f6e61746976655f3138383e.clone(), v_3c636170747572653a7075695f6e61746976655f3138393e.clone()); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.value")), ("key", v_3c636170747572653a7075695f6e61746976655f3138383e.clone()), ("value", v_3c636170747572653a7075695f6e61746976655f3138393e.clone())]));    v_7075695f6e61746976655f313930 } };
        Value::Undefined
    })) }, {   Value::Function(Rc::new(move |arguments: Vec<Value>| {
        let v_726573756c74: Value = arg(&arguments, 0);
        let v_61707065617244656661756c745f5f64346338623031313034663862376334: LexicalBinding<Value> = lexical_binding();
        let v_656e7465724475726174696f6e44656661756c745f5f64633130623165396533323431393837: LexicalBinding<Value> = lexical_binding();
        let v_6c656176654475726174696f6e44656661756c745f5f33366135663730333531386134373131: LexicalBinding<Value> = lexical_binding();
        let v_696e7465727275707444656661756c745f5f38346665363930333233353163306265: LexicalBinding<Value> = lexical_binding();
        let v_636f6c64456e7472795072657061726174696f6e5f5f35633636346466636262303131386332: LexicalBinding<Value> = lexical_binding();
        let v_636f6e66696775726550726573656e746174696f6e: LexicalBinding<Value> = lexical_binding();
        // Source "transition/as-transition.proto.ts":246:11
        let v_7472616e736974696f6e53746174655f5f39613961633762313035306336363737 = v_5f5f7075694d6f64756c6531.with(|function| function.call_authored(vec![{ let v_7075695f6e61746976655f313931 = v_726573756c74.clone(); { let capture_getter = (v_7075695f6e61746976655f313931.clone()).member("getState", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("transitionState")]) } } }, Value::string("transitionState")]));
        // Source "transition/as-transition.proto.ts":250:11
        let v_697350726573656e745f5f36633764653265326166323739656639 = v_5f5f7075694d6f64756c6532.with(|function| function.call_authored(vec![{ let v_7075695f6e61746976655f313932 = v_726573756c74.clone(); { let capture_getter = (v_7075695f6e61746976655f313932.clone()).member("getState", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("isPresent")]) } } }, Value::string("isPresent")]));
        // Source "transition/as-transition.proto.ts":251:11
        let v_636f6e74726f6c735f5f33393266643438343261373962613061 = record(vec![("capturePreparation", v_5f5f7075694d6f64756c6533.with(|function| function.call_authored(vec![{ let v_7075695f6e61746976655f313933 = v_726573756c74.clone(); { let capture_getter = (v_7075695f6e61746976655f313933.clone()).member("getMethod", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("capturePreparation")]) } } }, Value::string("capturePreparation")]))), ("enter", v_5f5f7075694d6f64756c6534.with(|function| function.call_authored(vec![{ let v_7075695f6e61746976655f313934 = v_726573756c74.clone(); { let capture_getter = (v_7075695f6e61746976655f313934.clone()).member("getMethod", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("enter")]) } } }, Value::string("enter")]))), ("leave", v_5f5f7075694d6f64756c6534.with(|function| function.call_authored(vec![{ let v_7075695f6e61746976655f313935 = v_726573756c74.clone(); { let capture_getter = (v_7075695f6e61746976655f313935.clone()).member("getMethod", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("leave")]) } } }, Value::string("leave")]))), ("complete", v_5f5f7075694d6f64756c6534.with(|function| function.call_authored(vec![{ let v_7075695f6e61746976655f313936 = v_726573756c74.clone(); { let capture_getter = (v_7075695f6e61746976655f313936.clone()).member("getMethod", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("complete")]) } } }, Value::string("complete")])))]);
        // Source "transition/as-transition.proto.ts":270:11
        v_61707065617244656661756c745f5f64346338623031313034663862376334.initialize(v_5f5f7075694d6f64756c6532.with(|function| function.call_authored(vec![{ let v_7075695f6e61746976655f313937 = v_726573756c74.clone(); { let capture_getter = (v_7075695f6e61746976655f313937.clone()).member("getState", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("transitionAppearDefault")]) } } }, Value::string("transitionAppearDefault")])));
        // Source "transition/as-transition.proto.ts":274:11
        v_656e7465724475726174696f6e44656661756c745f5f64633130623165396533323431393837.initialize(v_5f5f7075694d6f64756c6535.with(|function| function.call_authored(vec![{ let v_7075695f6e61746976655f313938 = v_726573756c74.clone(); { let capture_getter = (v_7075695f6e61746976655f313938.clone()).member("getState", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("transitionEnterDurationDefault")]) } } }, Value::string("transitionEnterDurationDefault")])));
        // Source "transition/as-transition.proto.ts":278:11
        v_6c656176654475726174696f6e44656661756c745f5f33366135663730333531386134373131.initialize(v_5f5f7075694d6f64756c6535.with(|function| function.call_authored(vec![{ let v_7075695f6e61746976655f313939 = v_726573756c74.clone(); { let capture_getter = (v_7075695f6e61746976655f313939.clone()).member("getState", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("transitionLeaveDurationDefault")]) } } }, Value::string("transitionLeaveDurationDefault")])));
        // Source "transition/as-transition.proto.ts":282:11
        v_696e7465727275707444656661756c745f5f38346665363930333233353163306265.initialize(v_5f5f7075694d6f64756c6531.with(|function| function.call_authored(vec![{ let v_7075695f6e61746976655f323030 = v_726573756c74.clone(); { let capture_getter = (v_7075695f6e61746976655f323030.clone()).member("getState", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("transitionInterruptDefault")]) } } }, Value::string("transitionInterruptDefault")])));
        // Source "transition/as-transition.proto.ts":287:11
        v_636f6c64456e7472795072657061726174696f6e5f5f35633636346466636262303131386332.initialize(v_5f5f7075694d6f64756c6532.with(|function| function.call_authored(vec![{ let v_7075695f6e61746976655f323031 = v_726573756c74.clone(); { let capture_getter = (v_7075695f6e61746976655f323031.clone()).member("getState", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("transitionColdEntryPreparation")]) } } }, Value::string("transitionColdEntryPreparation")])));
        // Source "transition/as-transition.proto.ts":292:11
        v_636f6e66696775726550726573656e746174696f6e.initialize(v_5f5f7075694d6f64756c6536.with(|function| function.call_authored(vec![{ let v_7075695f6e61746976655f323032 = v_726573756c74.clone(); { let capture_getter = (v_7075695f6e61746976655f323032.clone()).member("getMethod", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("configurePresentation")]) } } }, Value::string("configurePresentation")])));
        // Source "transition/as-transition.proto.ts":298:11
        let v_67657450726573656e746174696f6e4f776e6572 = v_5f5f7075694d6f64756c6537.with(|function| function.call_authored(vec![{ let v_7075695f6e61746976655f323033 = v_726573756c74.clone(); { let capture_getter = (v_7075695f6e61746976655f323033.clone()).member("getMethod", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("getPresentationOwner")]) } } }, Value::string("getPresentationOwner")]));
        // Source "transition/as-transition.proto.ts":302:11
        let v_636f6e666967757265 = {  let v_61707065617244656661756c745f5f64346338623031313034663862376334 = v_61707065617244656661756c745f5f64346338623031313034663862376334.clone(); let v_656e7465724475726174696f6e44656661756c745f5f64633130623165396533323431393837 = v_656e7465724475726174696f6e44656661756c745f5f64633130623165396533323431393837.clone(); let v_6c656176654475726174696f6e44656661756c745f5f33366135663730333531386134373131 = v_6c656176654475726174696f6e44656661756c745f5f33366135663730333531386134373131.clone(); let v_696e7465727275707444656661756c745f5f38346665363930333233353163306265 = v_696e7465727275707444656661756c745f5f38346665363930333233353163306265.clone(); let v_636f6c64456e7472795072657061726174696f6e5f5f35633636346466636262303131386332 = v_636f6c64456e7472795072657061726174696f6e5f5f35633636346466636262303131386332.clone(); let v_636f6e66696775726550726573656e746174696f6e = v_636f6e66696775726550726573656e746174696f6e.clone(); Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_636f6e6669675f5f65386134646162313562306332653431: Value = arg(&arguments, 0);
            // Source "transition/as-transition.proto.ts":304:7
            { let callable = v_636f6e66696775726550726573656e746174696f6e.read(); callable.call_authored(vec![v_636f6e6669675f5f65386134646162313562306332653431.clone()]) };
            // Source "transition/as-transition.proto.ts":305:11
            let v_636f6e66696775726564: Rc<std::cell::RefCell<bool>> = Rc::new(std::cell::RefCell::new(false));
            // Source "transition/as-transition.proto.ts":306:7
            if (Value::boolean(!strict_equal(&(typeof_value(&((v_636f6e6669675f5f65386134646162313562306332653431.clone()).member("coldEntryPreparation", false)))), &(Value::string("undefined"))))).bool() {
                // Source "transition/as-transition.proto.ts":307:9
                { let v_7075695f6e61746976655f323036 = v_636f6c64456e7472795072657061726174696f6e5f5f35633636346466636262303131386332.read(); state_default(v_7075695f6e61746976655f323036.clone(), Value::boolean(((v_636f6e6669675f5f65386134646162313562306332653431.clone()).member("coldEntryPreparation", false)).bool())) };
                // Source "transition/as-transition.proto.ts":308:9
                Value::boolean({ let value=true; *(v_636f6e66696775726564.clone()).borrow_mut()=value.clone(); value });
            }
            // Source "transition/as-transition.proto.ts":310:7
            if (Value::boolean(!strict_equal(&(typeof_value(&((v_636f6e6669675f5f65386134646162313562306332653431.clone()).member("appear", false)))), &(Value::string("undefined"))))).bool() {
                // Source "transition/as-transition.proto.ts":311:9
                { let v_7075695f6e61746976655f323039 = v_61707065617244656661756c745f5f64346338623031313034663862376334.read(); state_default(v_7075695f6e61746976655f323039.clone(), Value::boolean(((v_636f6e6669675f5f65386134646162313562306332653431.clone()).member("appear", false)).bool())) };
                // Source "transition/as-transition.proto.ts":312:9
                Value::boolean({ let value=true; *(v_636f6e66696775726564.clone()).borrow_mut()=value.clone(); value });
            }
            // Source "transition/as-transition.proto.ts":314:7
            if (Value::boolean(!strict_equal(&(typeof_value(&((v_636f6e6669675f5f65386134646162313562306332653431.clone()).member("enterDuration", false)))), &(Value::string("undefined"))))).bool() {
                // Source "transition/as-transition.proto.ts":315:9
                if { let pui_native_212=!((((v_636f6e6669675f5f65386134646162313562306332653431.clone()).member("enterDuration", false)).num()).is_finite()); if !(pui_native_212) {{ let pui_native_214:f64=((v_636f6e6669675f5f65386134646162313562306332653431.clone()).member("enterDuration", false)).num(); let pui_native_215:f64=0.0_f64; pui_native_214 < pui_native_215 }} else {pui_native_212} } {
                    // Source "transition/as-transition.proto.ts":316:11
                    throw_value(record(vec![("name", Value::string("Error")), ("message", (Value::string("[asTransition] enterDuration must be a finite non-negative number.")).error_message_value())]));
                }
                // Source "transition/as-transition.proto.ts":318:9
                { let v_7075695f6e61746976655f323136 = v_656e7465724475726174696f6e44656661756c745f5f64633130623165396533323431393837.read(); state_default(v_7075695f6e61746976655f323136.clone(), Value::number(((v_636f6e6669675f5f65386134646162313562306332653431.clone()).member("enterDuration", false)).num())) };
                // Source "transition/as-transition.proto.ts":319:9
                Value::boolean({ let value=true; *(v_636f6e66696775726564.clone()).borrow_mut()=value.clone(); value });
            }
            // Source "transition/as-transition.proto.ts":321:7
            if (Value::boolean(!strict_equal(&(typeof_value(&((v_636f6e6669675f5f65386134646162313562306332653431.clone()).member("leaveDuration", false)))), &(Value::string("undefined"))))).bool() {
                // Source "transition/as-transition.proto.ts":322:9
                if { let pui_native_219=!((((v_636f6e6669675f5f65386134646162313562306332653431.clone()).member("leaveDuration", false)).num()).is_finite()); if !(pui_native_219) {{ let pui_native_221:f64=((v_636f6e6669675f5f65386134646162313562306332653431.clone()).member("leaveDuration", false)).num(); let pui_native_222:f64=0.0_f64; pui_native_221 < pui_native_222 }} else {pui_native_219} } {
                    // Source "transition/as-transition.proto.ts":323:11
                    throw_value(record(vec![("name", Value::string("Error")), ("message", (Value::string("[asTransition] leaveDuration must be a finite non-negative number.")).error_message_value())]));
                }
                // Source "transition/as-transition.proto.ts":325:9
                { let v_7075695f6e61746976655f323233 = v_6c656176654475726174696f6e44656661756c745f5f33366135663730333531386134373131.read(); state_default(v_7075695f6e61746976655f323233.clone(), Value::number(((v_636f6e6669675f5f65386134646162313562306332653431.clone()).member("leaveDuration", false)).num())) };
                // Source "transition/as-transition.proto.ts":326:9
                Value::boolean({ let value=true; *(v_636f6e66696775726564.clone()).borrow_mut()=value.clone(); value });
            }
            // Source "transition/as-transition.proto.ts":328:7
            if (Value::boolean(!strict_equal(&(typeof_value(&((v_636f6e6669675f5f65386134646162313562306332653431.clone()).member("interrupt", false)))), &(Value::string("undefined"))))).bool() {
                // Source "transition/as-transition.proto.ts":329:9
                { let v_7075695f6e61746976655f323236 = v_696e7465727275707444656661756c745f5f38346665363930333233353163306265.read(); state_default(v_7075695f6e61746976655f323236.clone(), (v_636f6e6669675f5f65386134646162313562306332653431.clone()).member("interrupt", false)) };
                // Source "transition/as-transition.proto.ts":330:9
                Value::boolean({ let value=true; *(v_636f6e66696775726564.clone()).borrow_mut()=value.clone(); value });
            }
            // Source "transition/as-transition.proto.ts":333:7
            if !({ let value=(v_636f6e66696775726564.clone()).borrow().clone(); value }) {
                // Source "transition/as-transition.proto.ts":333:24
                { let v_7075695f6e61746976655f323237 = v_61707065617244656661756c745f5f64346338623031313034663862376334.read(); state_default(v_7075695f6e61746976655f323237.clone(), Value::boolean(({ let v_7075695f6e61746976655f323238 = v_61707065617244656661756c745f5f64346338623031313034663862376334.read(); Value::boolean(((v_7075695f6e61746976655f323238.clone()).get()).bool()) }).bool())) };
            }
            Value::Undefined
        })) };
        // Source "transition/as-transition.proto.ts":336:11
        let v_62696e64496e697469616c4f70656e5f5f38366334303139383939613366613731 = v_5f5f7075694d6f64756c6538.with(|function| function.call_authored(vec![{ let v_7075695f6e61746976655f323239 = v_726573756c74.clone(); { let capture_getter = (v_7075695f6e61746976655f323239.clone()).member("getMethod", false); if capture_getter.nullish() { Value::Undefined } else { capture_getter.call_authored(vec![Value::string("bindInitialOpen")]) } } }, Value::string("bindInitialOpen")]));
        // Source "transition/as-transition.proto.ts":340:5
        return record(vec![("transitionState", v_7472616e736974696f6e53746174655f5f39613961633762313035306336363737.clone()), ("isPresent", v_697350726573656e745f5f36633764653265326166323739656639.clone()), ("controls", v_636f6e74726f6c735f5f33393266643438343261373962613061.clone()), ("configure", v_636f6e666967757265.clone()), ("bindInitialOpen", v_62696e64496e697469616c4f70656e5f5f38366334303139383939613366613731.clone()), ("presentationOwner", { let callable = v_67657450726573656e746174696f6e4f776e6572.clone(); callable.call_authored(vec![]) })]);
    })) }, Value::Undefined)
}
  #[derive(Clone)]
  pub struct CompiledComponentHandle { pub owner: OwnerRef }
  impl CompiledComponentHandle {
      pub fn method_4(&self, argument_0: Value, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![argument_0];
        let callback = self.owner.borrow().exposes.get("bindInitialOpen").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("bindInitialOpen", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_5(&self, window: &mut Window, cx: &mut App) -> Result<Value, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("getPresentationOwner").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("getPresentationOwner", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        result
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_6(&self, argument_0: Value, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![argument_0];
        let callback = self.owner.borrow().exposes.get("configurePresentation").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("configurePresentation", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn state_7(&self) -> Result<String, Value> { self.state("transitionState").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn state_8(&self) -> Result<bool, Value> { self.state("isPresent").map(|value| serde_json::from_value(value).expect("checked exposed State")) }
    pub fn method_9(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("enter").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("enter", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_10(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("leave").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("leave", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_11(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("complete").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("complete", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        let result = if matches!(result, Value::Undefined) { Json::Null } else { result.data() };
        if !(result.is_null()) { value_type_error("exposed method returned invalid portable data") }
        serde_json::from_value(result).expect("checked exposed method result")
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn method_12(&self, window: &mut Window, cx: &mut App) -> Result<Value, Value> {
        let outcome = catch_authored(|| {
        refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
        let arguments = vec![];
        let callback = self.owner.borrow().exposes.get("capturePreparation").cloned().unwrap_or_else(|| value_error("unknown exposed method"));
        check_method("capturePreparation", &arguments);
        let result = invoke(&self.owner, "expose-method", &callback, arguments);
        let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
        result
        });
        if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
        outcome
    }
    pub fn value_13(&self) -> Result<Value, Value> { catch_authored(|| { ensure(&Rc::downgrade(&self.owner)); self.owner.borrow().exposes.get("controls").cloned().unwrap_or_else(|| value_error("unknown exposed value")) }) }
    pub fn value_14(&self) -> Result<Value, Value> { catch_authored(|| { ensure(&Rc::downgrade(&self.owner)); self.owner.borrow().exposes.get("sameHandle").cloned().unwrap_or_else(|| value_error("unknown exposed value")) }) }
      pub fn owner(&self) -> OwnerWeak { Rc::downgrade(&self.owner) }
      pub fn state(&self, name: &str) -> Result<Json, Value> { catch_authored(|| { let state=self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed State")); state.get().data() }) }
      pub fn call(&self, name: &str, arguments: Vec<Json>, window: &mut Window, cx: &mut App) -> Result<Json, Value> {
          let outcome = catch_authored(|| {
          refresh_native_atoms(&self.owner, window, cx);
          #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&self.owner, window);
          let callback = self.owner.borrow().exposes.get(name).cloned().unwrap_or_else(|| value_error("unknown exposed method"));
          let arguments: Vec<Value> = arguments.into_iter().map(Value::json).collect(); check_method(name, &arguments);
          let result = invoke(&self.owner, "expose-method", &callback, arguments);
          let drive = self.owner.borrow().native_drive.clone(); if let Some(drive) = drive { drive(window, cx); }
          if matches!(result, Value::Undefined) { Json::Null } else { result.data() }
          });
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome
      }
      pub fn host_target(&self) -> Result<Value, Value> { catch_authored(|| { ensure(&self.owner()); Value::HostTarget(self.owner()) }) }
      pub fn take_events(&self) -> Vec<(String, Json)> { std::mem::take(&mut self.owner.borrow_mut().emitted) }
      pub fn take_failures(&self) -> Vec<NativeFailure> { take_native_failures(&self.owner) }
      pub fn dispose(&self, window: &mut Window, cx: &mut App) -> Result<(), Value> {
          catch_authored(|| {
          let drive = self.owner.borrow().native_drive.clone();
          let failure = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| Owner::dispose(&self.owner)));
          let driven = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| { if let Some(drive) = drive { drive(window, cx); } }));
          if let Err(failure) = failure { std::panic::resume_unwind(failure); }
          if let Err(failure) = driven { std::panic::resume_unwind(failure); }
          })
      }
  }
  pub struct CompiledComponent { pub owner: OwnerRef, focus: FocusHandle, window_input: Option<FocusHandle>, _focus_subscriptions: Vec<Subscription>, _window_activation: Option<(gpui::WindowId, Subscription)>, _focus_lost: Option<Subscription>, _global_key_capture: Option<Subscription>, _entry_readiness: Option<(gpui::WindowId, Subscription)> }
  impl CompiledComponent {
      pub fn create_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> { Self::create(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn create(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          Self::create_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn create_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut App) -> Result<gpui::Entity<Self>, Value> {
          let mut failure = None;
          let entity = cx.new(|cx| Self::new_with_associations(raw_props, parent, associations, window, cx).unwrap_or_else(|error| {
              failure = Some(error);
              // A failed construction still returns normally through GPUI's
              // entity insertion. This inert temporary is dropped immediately
              // below; it is never published or mounted as a native component.
              let owner = Owner::new(Json::Object(Default::default()), Default::default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
              { let mut owner = owner.borrow_mut(); owner.disposed = true; owner.present = false; }
              Self { owner, focus: cx.focus_handle(), window_input: None, _focus_subscriptions: Vec::new(), _window_activation: None, _focus_lost: None, _global_key_capture: None, _entry_readiness: None }
          }));
          match failure { Some(error) => Err(error), None => Ok(entity) }
      }
      pub fn new_props(props: GeneratedProps, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> { Self::new(serde_json::to_value(props).expect("portable Props"), parent, window, cx) }
      pub fn new(raw_props: Json, parent: Option<OwnerWeak>, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          Self::new_with_associations(raw_props, parent, InstanceAssociations::default(), window, cx)
      }
      pub fn new_with_associations(raw_props: Json, parent: Option<OwnerWeak>, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<Self, Value> {
          catch_authored(|| {
          let owner_ref = Owner::new(raw_props, parent.unwrap_or_default(), accepts_context, accepts_props, prop_valid, style_vocabulary());
          initialize_instance_associations(&owner_ref, associations);
          let owner = Rc::downgrade(&owner_ref);
          let focus = cx.focus_handle();
          let view = cx.entity().downgrade();
          let drive_owner=owner.clone(); let drive_focus=focus.clone();
          let driving = Rc::new(std::cell::Cell::new(false));
          let drive_pending = Rc::new(std::cell::Cell::new(false));
          let drive: Drive = Rc::new(move |window, cx| {
              // Platform effects need owner storage and its real FocusHandle,
              // not another lease of the generated component. Preserve their
              // synchronous effect (notably physical focus) under public calls.
              if !driving.replace(true) {
                  if let Some(owner)=drive_owner.upgrade() {
                      native_host_callback(&owner, "drive", || { modules_drive(&owner, &drive_focus, window, cx); drive_queued_focus(&owner, window, cx); });
                  }
                  driving.set(false);
              }
              if drive_pending.replace(true) { return; }
              let view=view.clone(); let pending=drive_pending.clone();
              // A public handle can be called from Entity::update. Return the
              // current host lease before requesting another component update.
              // Authored calls, State writes and platform commands remain
              // synchronous; component refresh is coalesced at the host boundary.
              window.defer(cx, move |window, cx| {
                  pending.set(false);
                  let _ = view.update(cx, |view, cx| { if let Err(error) = view.drive(window, cx) { report_native_failure(&view.owner, "drive", error); } });
              });
          });
          { let mut owner = owner_ref.borrow_mut(); owner.native_drive = Some(drive); owner.window_id = Some(window.window_handle().window_id()); }
  
          configure_native_atoms(&owner_ref, true, true);
          refresh_native_atoms(&owner_ref, window, cx);
          let _lexical_owner = enter_lexical_owner(&owner);
          let renderer = { let owner = owner.clone();  Value::Function(Rc::new(move |arguments: Vec<Value>| {
            let v_6465665f5f34373533633666316635316532393735: Value = arg(&arguments, 0);
            // Source "transition.proto.ts":1:191
            let v_6669727374 = authored_hook_0(definition_capability(&owner), Value::Undefined);
            // Source "transition.proto.ts":1:218
            let v_7365636f6e64 = authored_hook_0(definition_capability(&owner), Value::Undefined);
            // Source "transition.proto.ts":1:240
            { let v_7075695f6e61746976655f353434 = v_6465665f5f34373533633666316635316532393735.clone(); { let v_3c636170747572653a7075695f6e61746976655f3534373e = Value::string("sameHandle"); let v_3c636170747572653a7075695f6e61746976655f3534383e = Value::boolean((Value::boolean(strict_equal(&(v_6669727374.clone()), &(v_7365636f6e64.clone())))).bool()); let v_7075695f6e61746976655f353439 = expose_value(&owner, v_3c636170747572653a7075695f6e61746976655f3534373e.clone(), Value::boolean((v_3c636170747572653a7075695f6e61746976655f3534383e.clone()).bool())); capture_effect(&owner, "context", record(vec![("op", Value::string("expose.value")), ("key", v_3c636170747572653a7075695f6e61746976655f3534373e.clone()), ("value", v_3c636170747572653a7075695f6e61746976655f3534383e.clone())]));    v_7075695f6e61746976655f353439 } };
            // Source "transition.proto.ts":1:286
            return { let callable={ let pui_native_550={   let call:Rc<dyn Fn(Value)->native::gpui_native_owner::NativeSnapshot>=Rc::new(move |argument_0: Value| -> native::gpui_native_owner::NativeSnapshot {
                let v_72: Value = argument_0;
                // Source "transition.proto.ts":1:296
                return { let v_7075695f6e61746976655f353531 = v_72.clone(); { let pui_native_552 = Value::string("div"); let _ = pui_native_552; let pui_native_553 = Value::Undefined; let pui_native_554 = native::gpui_native_owner::NativeSnapshot::text_value(Value::string("transition"));
      let pui_native_555 = if pui_native_553.nullish() { Vec::new() } else { let style = pui_native_553.member("style",false); if style.nullish(){Vec::new()}else{style_items(vec![style])} };
      let frame_children = pui_native_554.clone(); let text_children = pui_native_554.clone();
      native::gpui_native_owner::NativeSnapshot { identity:Rc::new(()),observation:None,valid:pui_native_554.valid,slot_count:pui_native_554.slot_count,passive_content:pui_native_554.passive_content,
        frame:Rc::new(move |owner,focus,parent_path,drive,slot,index| {
          let path=format!("{parent_path}-{}",*index);*index+=1;
          let tokens:Vec<String> = pui_native_555.iter().map(|(token,_)|token.clone()).collect();
          let(style,fixed,translation)=native_presentation(owner,&tokens);
          let mut element=gpui::div().id(gpui::ElementId::Name(path.to_owned().into())); *element.style()=style;
          let mut child_index=0;for child in (frame_children.frame)(owner,focus,&path,drive,slot,&mut child_index){element=element.child(child);}
          let element=translated_element(element.into_any_element(),translation,None); vec![if fixed{viewport_root(element)}else{element}]
        }),text:Rc::new(move|slot|(text_children.text)(slot)) }
    } };
            }); native::gpui_native_owner::NativeCallable { identity:Rc::new(()), call, ordinary:None } }; Value::NativeFunction{identity:pui_native_550.identity.clone(),render:Rc::new(move |arguments:Vec<Value>| {(pui_native_550.call)(arg(&arguments,0))})} }; match callable {
      Value::NativeFunction{identity,render} => capture_renderer(Value::NativeFunction{identity,render:render.clone()},render),
      Value::Renderer(adapter) => Value::Renderer(adapter),
      Value::Function(callback) => capture_renderer(Value::Function(callback.clone()),Rc::new(move |arguments:Vec<Value>| { panic!("checked native renderer entry has no scalar callback alternative") })),
      _ => panic!("checked setup result must be a callable")
    } };
        })) }.call_authored(vec![definition_capability(&owner)]);
          Owner::finish(&owner_ref, renderer);
          // Establish the App's default-action snapshot before any authored
          // global key capture can replace focus during the same keystroke.
          register_sequential_focus_owner(&owner_ref, cx);
          let focus_subscriptions = if native_focus_observation_needed(&owner_ref) {
          let focus_owner = owner_ref.clone();
          let on_focus = cx.on_focus(&focus, window, move |view, window, cx| {
              native_host_callback(&focus_owner, "focus", || {
              let epoch = focus_owner.borrow().epoch;
              if !ready(&focus_owner) || focus_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&focus_owner, window);
              native_focus_fact(&focus_owner, view.focus.is_focused(window));
              if !ready(&focus_owner) || focus_owner.borrow().epoch != epoch { return; }
              dispatch(&focus_owner, "host:focus", false, event_fields("host:focus"));
              if ready(&focus_owner) && focus_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          let blur_owner = owner_ref.clone();
          let on_blur = cx.on_blur(&focus, window, move |view, window, cx| {
              native_host_callback(&blur_owner, "blur", || {
              let epoch = blur_owner.borrow().epoch;
              if !ready(&blur_owner) || blur_owner.borrow().window_id != Some(window.window_handle().window_id()) { return; }
              #[cfg(feature = "experimental-focus-tree")] refresh_native_entry(&blur_owner, window);
              native_focus_fact(&blur_owner, view.focus.is_focused(window));
              if !ready(&blur_owner) || blur_owner.borrow().epoch != epoch { return; }
              text_blur(&blur_owner, window, cx);
              dispatch(&blur_owner, "host:blur", false, event_fields("host:blur"));
              if ready(&blur_owner) && blur_owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          // A native slot descendant can start this root's keyboard press
          // while the root FocusHandle itself is not focused. Its departure
          // from the physical subtree is distinct from the root's own blur.
          let focus_out_owner = Rc::downgrade(&owner_ref);
          let on_focus_out = cx.on_focus_out(&focus, window, move |view, _, window, cx| {
              let Some(owner) = focus_out_owner.upgrade() else { return; };
              native_host_callback(&owner, "focus-out", || {
              let epoch = owner.borrow().epoch;
              if !ready(&owner) || owner.borrow().window_id != Some(window.window_handle().window_id()) || view.focus.contains_focused(window, cx) { return; }
              // This retires only an existing root press lease. Do not forge
              // host:blur or change the root's own Focus observation here.
              native_press_blur(&owner);
              if ready(&owner) && owner.borrow().epoch == epoch { view.drive(window, cx).unwrap_or_else(|error| throw_value(error)); }
              });
              notify_native_change(cx);
          });
          vec![on_focus, on_blur, on_focus_out]
          } else { Vec::new() };
          let global_key_capture = subscribe_global_key_capture(&owner_ref, cx);
          let window_input = window_input_needed(&owner_ref).then(|| cx.focus_handle().tab_stop(false));
          let focus_lost = window_input.as_ref().map(|_| cx.on_focus_lost(window, |view, window, cx| { let owner=view.owner.clone(); native_host_callback(&owner, "focus-lost", || { if view.owner.borrow().window_id == Some(window.window_handle().window_id()) { if let Some(focus) = &view.window_input { restore_window_input(&view.owner, focus, window, cx); } } }); }));
          let mut view = Self { owner: owner_ref, focus, window_input, _focus_subscriptions: focus_subscriptions, _window_activation: None, _focus_lost: focus_lost, _global_key_capture: global_key_capture, _entry_readiness: None };
          view.bind_window_activation(window, cx);
          view
          })
      }
      #[cfg(feature="test-support")]
      pub fn native_resource_counts(&self) -> Json { let mut counts=native::gpui_native_owner::native_resource_counts(&self.owner); counts["nativeSubscriptions"] = Json::from(self._focus_subscriptions.len() + usize::from(self._window_activation.is_some()) + usize::from(self._focus_lost.is_some()) + usize::from(self._global_key_capture.is_some()) + usize::from(self._entry_readiness.is_some())); counts }
      pub fn handle(&self) -> CompiledComponentHandle { CompiledComponentHandle { owner: self.owner.clone() } }
      pub fn set_props(&mut self, raw: Json, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_props(&self.owner, raw));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; self.drive(window, cx)
      }
      pub fn set_instance_associations(&mut self, associations: InstanceAssociations, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let outcome = catch_authored(|| replace_instance_associations(&self.owner, associations));
          if outcome.is_err() { drive_pending_native_events(&self.owner, window, cx); }
          outcome?; drive_owners(window, cx); self.drive(window, cx)
      }
      pub fn set_slot(&mut self, slot: Vec<native::gpui_native_owner::NativeSnapshot>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { ensure(&Rc::downgrade(&self.owner)); assert_native_slot_children(&slot); let mut owner = self.owner.borrow_mut(); owner.slot = slot; owner.dirty = true; cx.notify(); }) }
      pub fn set_parent(&mut self, parent: Option<OwnerWeak>, cx: &mut Context<Self>) -> Result<(), Value> { catch_authored(|| { if let Err(error)=set_native_parent(&self.owner, parent.unwrap_or_default()){throw_error("NATIVE_PARENT_INVALID", error)} cx.notify(); }) }
      fn bind_window_activation(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !native_focus_observation_needed(&self.owner) && !native::gpui_native_move::move_owner_has_binding(&self.owner) && !control_label_is_label(&self.owner) { self._window_activation.take(); return; }
          let id = window.window_handle().window_id();
          if self._window_activation.as_ref().is_some_and(|(bound, _)| *bound == id) { return; }
          self._window_activation.take();
          let owner = self.owner.clone();
          let subscription = cx.observe_window_activation(window, move |view, window, cx| {
              let deactivated = owner.borrow().window_id == Some(window.window_handle().window_id()) && !window.is_window_active();
              native_host_callback(&owner, "window-activation", || {
                  if deactivated {
                      native_window_blur(&owner);
                      view.drive(window, cx).unwrap_or_else(|error| throw_value(error));
                  }
              });
              if deactivated { notify_native_change(cx); }
          });
          self._window_activation = Some((id, subscription));
      }
      #[cfg(feature = "experimental-focus-tree")]
      fn bind_entry_readiness(&mut self, window: &mut Window, cx: &mut Context<Self>) {
          if !self.owner.borrow().modules.hooks.contains("focus-entry") { return; }
          let window_id = window.window_handle().window_id();
          if self._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window_id) { return; }
          self._entry_readiness.take();
          let view = cx.entity().downgrade();
          let subscription = window.observe_focus_tree(cx, move |_, window, cx| {
              let _ = view.update(cx, |view, cx| {
                  if view._entry_readiness.as_ref().is_some_and(|(bound, _)| *bound == window.window_handle().window_id()) { if let Err(error)=view.drive(window, cx){report_native_failure(&view.owner,"entry-readiness",error)} }
              });
          });
          self._entry_readiness = Some((window_id, subscription));
      }
      fn notify_after_turn(&self, cx: &mut Context<Self>) {
          // GPUI suppresses Entity observer effects while a window is drawing,
          // including its focus/blur phase. Keep authored state synchronous,
          // then publish the host change after that physical draw lease ends.
          // A weak target cannot keep a detached component alive for delivery.
          notify_native_change(cx);
      }
      pub fn drive(&mut self, window: &mut Window, cx: &mut Context<Self>) -> Result<(), Value> {
          let result = catch_authored(|| {
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          modules_drive(&self.owner, &self.focus, window, cx);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); self._focus_subscriptions.clear(); self._focus_lost.take(); self._global_key_capture.take(); return; }
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          drive_queued_focus(&self.owner, window, cx);
          });
          // A callback can publish before failing or retiring its owner. That
          // output is independent from repaint dirtiness and an unread queue.
          let dirty = std::mem::take(&mut self.owner.borrow_mut().dirty);
          if !notify_native_events(&self.owner, cx) && dirty { self.notify_after_turn(cx); }
          result
      }
  }
  impl Drop for CompiledComponent { fn drop(&mut self) { native_host_callback(&self.owner, "drop", || Owner::dispose(&self.owner)); } }
  impl gpui::Focusable for CompiledComponent { fn focus_handle(&self, _: &App) -> FocusHandle { self.focus.clone() } }
  impl Render for CompiledComponent {
      fn render(&mut self, window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
          let report_owner = self.owner.clone();
          native_host_callback(&report_owner, "render", || {
          refresh_native_atoms(&self.owner, window, cx);
          Owner::project(&self.owner);
          if self.owner.borrow().disposed { self._entry_readiness.take(); self._window_activation.take(); return gpui::div().into_any_element(); }
          if !self.owner.borrow().present { self._window_activation.take(); detach_native_view(&self.owner); return gpui::div().into_any_element(); }
          bind_native_focus_window(&self.owner, window);
          self.bind_window_activation(window, cx);
          #[cfg(feature = "experimental-focus-tree")] self.bind_entry_readiness(window, cx);
          let drive = self.owner.borrow().native_drive.as_ref().expect("live native owner drive").clone();
          // Drawing consumes only repaint dirtiness. A parent Render can call
          // an exposed method before this child is laid out: its independent
          // pending_native_events flag survives until the coalesced drive wakes
          // the consumer. Repeated slot projection cannot create a notify loop.
          self.owner.borrow_mut().dirty = false;
          let snapshot = self.owner.borrow().projection.clone().expect("live native projection");
          self.focus = self.focus.clone().tab_stop(native_tab_participation(&self.owner));
          let element = paint_native_root(&snapshot, &self.owner, &self.focus, format!("compiled-root-{}", Rc::as_ptr(&self.owner) as usize), drive);
          if let Some(focus) = &self.window_input { window_input_scope(element, focus, &self.owner) } else { element }
          }).unwrap_or_else(|| gpui::div().into_any_element())
      }
  }
  