"""Independent double-precision XYZ route for bounded color-mix test vectors.

CSS Color 4 (2026-11-23), sections 13 and 19; CSS Color 5 (2026-11-16), section 3.
This script never imports, translates, or invokes the Rust implementation.
All selected mixed results are in sRGB, so no implementation of gamut mapping
is needed to produce their expected values. The Lab input itself is also
reported, to distinguish output mapping from premature input mapping.
"""
import json
import math

RGB_XYZ = [[506752/1228815, 87881/245763, 12673/70218],
           [87098/409605, 175762/245763, 12673/175545],
           [7918/409605, 87881/737289, 1001167/1053270]]
XYZ_RGB = [[12831/3959, -329/214, -1974/3959],
           [-851781/878810, 1648619/878810, 36519/878810],
           [705/12673, -2585/12673, 705/667]]
XYZ_LMS = [[.8190224379967030, .3619062600528904, -.1288737815209879],
           [.0329836539323885, .9292868615863434, .0361446663506424],
           [.0481771893596242, .2642395317527308, .6335478284694309]]
LMS_LAB = [[.2104542683093140, .7936177747023054, -.0040720430116193],
           [1.9779985324311684, -2.4285922420485799, .4505937096174110],
           [.0259040424655478, .7827717124575296, -.8086757549230774]]
LAB_LMS = [[1, .3963377773761749, .2158037573099136],
           [1, -.1055613458156586, -.0638541728258133],
           [1, -.0894841775298119, -1.2914855480194092]]
LMS_XYZ = [[1.2268798758459243, -.5578149944602171, .2813910456659647],
           [-.0405757452148008, 1.1122868032803170, -.0717110580655164],
           [-.0763729366746601, -.4214933324022432, 1.5869240198367816]]
D50_D65 = [[.955473421488075, -.02309845494876471, .06325924320057072],
           [-.0283697093338637, 1.0099953980813041, .021041441191917323],
           [.012314014864481998, -.020507649298898964, 1.330365926242124]]

def mat(matrix, vector):
    return [math.fsum(a*b for a, b in zip(row, vector)) for row in matrix]

def decode(channel):
    return channel/12.92 if channel <= .04045 else ((channel+.055)/1.055)**2.4

def encode(channel):
    return channel*12.92 if channel <= .0031308 else 1.055*channel**(1/2.4)-.055

def from_hex(text):
    rgb = [int(text[i:i+2], 16)/255 for i in (1, 3, 5)]
    return mat(RGB_XYZ, list(map(decode, rgb)))

def from_lab(lightness, a, b):
    f1 = (lightness+16)/116
    f = [f1+a/500, f1, f1-b/200]
    eps, kappa = 216/24389, 24389/27
    white = [.3457/.3585, 1, (1-.3457-.3585)/.3585]
    xyz = [(v**3 if v**3 > eps else (116*v-16)/kappa)*w for v,w in zip(f, white)]
    return mat(D50_D65, xyz)

def xyz_oklab(xyz):
    return mat(LMS_LAB, [math.cbrt(x) for x in mat(XYZ_LMS, xyz)])

def oklab_xyz(lab):
    return mat(LMS_XYZ, [x**3 for x in mat(LAB_LMS, lab)])

def polar(lab):
    chroma = math.hypot(lab[1], lab[2])
    return [lab[0], chroma if chroma > .000004 else 0,
            math.degrees(math.atan2(lab[2], lab[1]))%360 if chroma > .000004 else None]

def mix(left, right, w2=.5, polar_space=False, alpha=(1,1)):
    coords = [xyz_oklab(left), xyz_oklab(right)]
    hue = None
    if polar_space:
        coords = list(map(polar, coords))
        h1, h2 = coords[0][2], coords[1][2]
        if h1 is None: h1 = 0 if h2 is None else h2
        if h2 is None: h2 = h1
        if h2-h1 > 180: h1 += 360
        elif h2-h1 < -180: h2 += 360
        hue = math.radians((1-w2)*h1+w2*h2)
    weights = [(1-w2)*alpha[0], w2*alpha[1]]
    out_alpha = math.fsum(weights)
    out = [math.fsum(c[i]*w for c,w in zip(coords,weights))/out_alpha
           for i in range(2 if polar_space else 3)]
    if polar_space:
        out = [out[0], out[1]*math.cos(hue), out[1]*math.sin(hue)]
    linear = mat(XYZ_RGB, oklab_xyz(out))
    assert all(-1e-9 <= c <= 1+1e-9 for c in linear), linear
    return [*map(encode, linear), out_alpha]

vectors = {
    'bootstrap_hover': mix(from_hex('#f5f5f5'), from_hex('#333333'), .05, True),
    'grey_blue_powerless': mix(from_hex('#808080'), from_hex('#406080'), .5, True),
    'red_blue_oklab': mix(from_hex('#ff0000'), from_hex('#0000ff')),
    'shorter_wrap_oklch': mix(from_hex('#a04060'), from_hex('#6040a0'), .5, True),
    'polar_alpha': mix(from_hex('#a04060'), from_hex('#406080'), .5, True, (.25,.75)),
    'rectangular_alpha': mix(from_hex('#a04060'), from_hex('#406080'), .5, False, (.25,.75)),
    'lab_before_mapping': mix(from_lab(48.4493,77.4328,61.5452), from_hex('#808080')),
    'shadcn_light_hover': mix(from_lab(96.52,-.0000298023,.0000119209), from_lab(2.75381,0,0), .05, True),
    'shadcn_dark_hover': mix(from_lab(15.204,0,-.00000596046), from_lab(98.26,0,0), .05, True),
}
tokens=json.load(open('/workspace/scratch/40da939bdb35/native-color-repair/native/gpui/fixtures/theme-tokens.json'))
print(json.dumps({'vectors':vectors,'lab_input_linear_srgb':mat(XYZ_RGB,from_lab(48.4493,77.4328,61.5452)),
 'theme_values':{name:{mode:{k:v for k,v in values.items() if k in ('--pui-secondary','--pui-foreground')} for mode,values in modes.items()} for name,modes in tokens['themes'].items()}},indent=2))
