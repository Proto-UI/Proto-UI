import base64,datetime,hashlib,json,os,pathlib,re,shutil,signal,subprocess,tarfile,time
root=pathlib.Path('/tank/shared/projects/proto-ui-agent/pui-release-40da-color')
out=root/'results'
out.mkdir(exist_ok=True)
blob=base64.b64decode((root/'native-inputs.b64').read_text())
expected='403a37c4b3959264c53b406a8b8cf142eaae21d30967dc01233ee01d55d17ac9'
assert hashlib.sha256(blob).hexdigest()==expected
(root/'native-inputs.tar.gz').write_bytes(blob)
with tarfile.open(root/'native-inputs.tar.gz') as tf:
    tf.extractall(root/'inputs',filter='data')
baseline=root/'baseline'
candidate=root/'candidate'
assert not baseline.exists() and not candidate.exists(), 'owned validation already started'
baseline.mkdir()
with tarfile.open(root/'inputs/baseline-native.tar') as tf:
    tf.extractall(baseline,filter='data')
shutil.copytree(baseline,candidate)
for name in ('src/color.rs','tests/color.rs','tests/color_mix.rs'):
    dest=candidate/'native/gpui/crates/proto-ui-style'/name
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/'inputs/candidate'/name,dest)
env=dict(os.environ)
env['PATH']='/home/ezra/.cargo/bin:'+env.get('PATH','')
env['RUSTUP_TOOLCHAIN']='stable'
env['RUSTUP_AUTO_INSTALL']='0'
env['CARGO_BUILD_JOBS']='1'
env['CARGO_TARGET_DIR']=str(root/'target')
result={'sourceHead':'337be07287ba4770e1020d300d7d25b4792d06de','inputsSha256':expected,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[]}
def save():
    (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
def run(name,args,cwd,timeout=40):
    log=out/(name+'.log')
    started=time.monotonic()
    with log.open('wb') as stream:
        proc=subprocess.Popen(args,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        try: code=proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGTERM)
            try: proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid,signal.SIGKILL);proc.wait()
            code=124
    result['steps'].append({'name':name,'command':args,'cwd':str(cwd),'exitCode':code,'elapsedSeconds':round(time.monotonic()-started,3),'logSha256':hashlib.sha256(log.read_bytes()).hexdigest()})
    save()
    return code
for exe in ('rustc','cargo','rustfmt'):
    run(exe+'-version',[exe,'--version'],root,10)
def cargo_args(base,new=False):
    args=['cargo','test','--manifest-path',str(base/'native/gpui/Cargo.toml'),'--locked','--offline','-p','proto-ui-style','--test','color']
    if new:args+=['--test','color_mix']
    return args+['--','--test-threads=1']
run('baseline-cargo',cargo_args(baseline),baseline,40)
run('candidate-cargo',cargo_args(candidate,True),candidate,40)
candidate_log=(out/'candidate-cargo.log').read_text()
if 'test result:' not in candidate_log:
    # An environment-blocked Cargo workspace is not a passing crate gate.
    # Compile the complete unmodified parser source with the 9 literal tests;
    # only the fixture/theme integration test requires serde and is omitted here.
    tests=(root/'inputs/candidate/tests/color_mix.rs').read_text()
    tests=tests.replace('use proto_ui_style::color::{parse_rgba, ColorError};','use color::{parse_rgba, ColorError};')
    tests=tests.replace('use proto_ui_style::{themes, vocabulary, ColorScheme, Substitution};','')
    start=tests.index('#[test]\nfn resolves_the_shadcn_secondary_hover_through_the_real_vocabulary_and_theme()')
    end=tests.index('#[test]',start+8)
    tests=tests[:start]+tests[end:]
    tests=re.sub(r'^//!','//',tests,flags=re.M)
    result['standaloneBoundary']='Full original color.rs plus nine literal controls. Real crate, fixture, theme integration, GPUI and Cargo graph remain unverified when Cargo did not reach test result.'
    for label,tree in [('baseline',baseline),('candidate',candidate)]:
        source=tree/'native/gpui/crates/proto-ui-style/src/color.rs'
        harness=out/(label+'-literal-harness.rs')
        harness.write_text('#[path = '+json.dumps(str(source))+']\nmod color;\n'+tests)
        exe=out/(label+'-literal-tests')
        if run(label+'-rustc',['rustc','--edition','2021','--test',str(harness),'-o',str(exe)],root,20)==0:
            run(label+'-literal-tests',[str(exe),'--test-threads=1'],root,20)
files=[candidate/'native/gpui/crates/proto-ui-style'/name for name in ('src/color.rs','tests/color.rs','tests/color_mix.rs')]
result['preFormatFiles']={str(p.relative_to(candidate)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
run('rustfmt',['rustfmt','--edition','2021',*map(str,files)],root,15)
run('rustfmt-check',['rustfmt','--edition','2021','--check',*map(str,files)],root,15)
for p in files:
    relative=p.relative_to(candidate/'native/gpui/crates/proto-ui-style')
    dest=out/'formatted'/relative
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(p,dest)
result['postFormatFiles']={str(p.relative_to(candidate)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
result['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
save()
with tarfile.open(root/'results.tar.gz','w:gz') as tf: tf.add(out,arcname='results')
(root/'DONE').write_text(hashlib.sha256((root/'results.tar.gz').read_bytes()).hexdigest()+'\n')
print(json.dumps(result))

