import datetime,hashlib,json,os,pathlib,signal,subprocess,time
root=pathlib.Path('/tank/shared/projects/proto-ui-agent/pui-release-40da-color')
out=root/'retry-1'
out.mkdir(exist_ok=False)
candidate=root/'candidate'
env=dict(os.environ)
env['PATH']='/home/ezra/.cargo/bin:'+env.get('PATH','')
env['RUSTUP_TOOLCHAIN']='stable'
env['RUSTUP_AUTO_INSTALL']='0'
env['CARGO_BUILD_JOBS']='1'
env['CARGO_TARGET_DIR']=str(root/'candidate-target')
assert not pathlib.Path(env['CARGO_TARGET_DIR']).exists()
files=[candidate/'native/gpui/crates/proto-ui-style'/name for name in ('src/color.rs','tests/color.rs','tests/color_mix.rs')]
result={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Candidate-only clean target directory separates same-name path crates; original baseline and candidate results retained. No source/assertion changes.','sourceSha256':{str(p.relative_to(candidate)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'previousDependencyInputs':{}}
for path in (root/'target/debug/deps').glob('proto_ui_style-*.d'):
    result['previousDependencyInputs'][path.name]=path.read_text()
command=['cargo','test','--manifest-path',str(candidate/'native/gpui/Cargo.toml'),'--locked','--offline','--no-fail-fast','-p','proto-ui-style','--test','color','--test','color_mix','--','--test-threads=1']
result['command']=command
with (out/'candidate-cargo-fresh.log').open('wb') as stream:
    proc=subprocess.Popen(command,cwd=candidate,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    try:result['exitCode']=proc.wait(timeout=40)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid,signal.SIGTERM)
        try:proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL);proc.wait()
        result['exitCode']=124
result['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
result['logSha256']=hashlib.sha256((out/'candidate-cargo-fresh.log').read_bytes()).hexdigest()
result['currentDependencyInputs']={p.name:p.read_text() for p in (root/'candidate-target/debug/deps').glob('proto_ui_style-*.d')}
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('currentDependencyInputs','previousDependencyInputs')}))

