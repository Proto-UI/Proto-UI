// packages/adapters/base/src/material/liquidgl-kernel.generated.ts
var vertex = "\n        attribute vec2 a_position;\n        varying vec2 v_uv;\n        void main(){\n          v_uv = (a_position + 1.0) * 0.5;\n          gl_Position = vec4(a_position, 0.0, 1.0);\n        }";
var fragment = "\n        #ifdef GL_FRAGMENT_PRECISION_HIGH\n        precision highp float;\n        #else\n        precision mediump float;\n        #endif\n        varying vec2 v_uv;\n        uniform sampler2D u_tex;\n        uniform vec2  u_resolution;\n        uniform vec2  u_textureResolution;\n        uniform vec4  u_bounds;\n        uniform float u_refraction;\n        uniform float u_aberration;\n        uniform float u_bevelDepth;\n        uniform float u_bevelWidth;\n        uniform float u_frost;\n        uniform float u_radius;\n        uniform float u_time;\n        uniform bool  u_specular;\n        uniform float u_revealProgress;\n        uniform int   u_revealType;\n        uniform float u_tiltX;\n        uniform float u_tiltY;\n        uniform float u_magnify;\n        uniform vec2  u_subpixel;\n        uniform vec2  u_boxSize;\n        uniform vec4  u_tint;\n        uniform sampler2D u_stack;\n        uniform vec4 u_stackMapping;\n        uniform vec4 u_stackRegion;\n        uniform vec4 u_interaction;\n        uniform float u_interactionRadius;\n        uniform sampler2D u_shadow;\n        uniform vec4 u_shadowMapping;\n\n        vec4 sampleSource(vec2 uv) {\n          vec4 background = texture2D(u_tex, uv);\n          vec2 screenUV = u_stackMapping.xy + uv * u_stackMapping.zw;\n          if (u_stackRegion.z > 0.0 &&\n              all(greaterThanEqual(screenUV, u_stackRegion.xy)) &&\n              all(lessThanEqual(screenUV, u_stackRegion.xy + u_stackRegion.zw))) {\n            vec4 lower = texture2D(u_stack, vec2(screenUV.x, 1.0 - screenUV.y));\n            return lower + background * (1.0 - lower.a);\n          }\n          return background;\n        }\n\n        float udRoundBox( vec2 p, vec2 b, float r ) {\n          return length(max(abs(p)-b+r,0.0))-r;\n        }\n\n        vec2 cornerNormal( vec2 p, vec2 b, float r, vec2 fallback ) {\n          vec2 q = abs(p) - b + r;\n          vec2 m = max(q, 0.0);\n          float l = length(m);\n          if (l <= 0.0) return fallback;\n          float w = smoothstep(0.0, max(r * 0.5, 1.0), min(m.x, m.y));\n          if (w <= 0.0) return fallback;\n          vec2 s = vec2(p.x < 0.0 ? -1.0 : 1.0, p.y < 0.0 ? -1.0 : 1.0);\n          return normalize(mix(fallback, s * (m / l), w));\n        }\n\n        float random(vec2 st) {\n          return fract(sin(dot(st.xy, vec2(12.9898,78.233))) * 43758.5453123);\n        }\n\n        vec2 deformPoint(vec2 point) {\n          if (u_interactionRadius <= 0.0) return point;\n          vec2 centre = (vec2(u_interaction.x, 1.0 - u_interaction.y) - 0.5) * u_boxSize;\n          float reach = u_interactionRadius * min(u_boxSize.x, u_boxSize.y);\n          float influence = 1.0 - smoothstep(0.0, reach, length(point - centre));\n          return point - vec2(u_interaction.z, -u_interaction.w) * u_boxSize * influence;\n        }\n\n        float edgeFactor(vec2 p_px, vec2 b_px, float radius_px){\n          float d = -udRoundBox(p_px, b_px, radius_px);\n          float bevel_px = u_bevelWidth * min(u_boxSize.x, u_boxSize.y);\n          return 1.0 - smoothstep(0.0, bevel_px, d);\n        }\n        void main(){\n          vec2 lensUV = (v_uv * u_resolution - u_subpixel) / u_boxSize;\n          vec2 originalPoint = (lensUV - 0.5) * u_boxSize;\n          vec2 p_px = deformPoint(originalPoint);\n          vec2 b_px = 0.5 * u_boxSize;\n          vec2 p = p_px / u_boxSize.y;\n          float dmask = udRoundBox(p_px, b_px, u_radius);\n          float inShape = 1.0 - smoothstep(-0.5, 0.5, dmask);\n          float shadowAlpha = 0.0;\n          if (u_shadowMapping.z > 0.0 && inShape < 1.0) {\n            vec2 shadowUV = u_shadowMapping.xy + vec2(lensUV.x, 1.0 - lensUV.y) * u_shadowMapping.zw;\n            shadowAlpha = texture2D(u_shadow, shadowUV).r * 0.1 * (1.0 - inShape);\n            if (u_revealType == 1) shadowAlpha *= u_revealProgress;\n            float noise = fract(52.9829189 * fract(dot(floor(gl_FragCoord.xy), vec2(0.06711056, 0.00583715))));\n            shadowAlpha = floor(shadowAlpha * 255.0 + noise) / 255.0;\n          }\n          if (inShape <= 0.0) {\n            gl_FragColor = vec4(0.0, 0.0, 0.0, shadowAlpha);\n            return;\n          }\n\n          float edge = edgeFactor(p_px, b_px, u_radius);\n          float min_dimension = min(u_resolution.x, u_resolution.y);\n          float offsetAmt = (edge * u_refraction + pow(edge, 10.0) * u_bevelDepth);\n          float centreBlend = smoothstep(0.15, 0.45, length(p));\n          vec2 refractDir = cornerNormal(p_px, b_px, u_radius, normalize(p + vec2(0.000001)));\n          if (u_interactionRadius > 0.0) {\n            vec2 gradient = vec2(\n              udRoundBox(deformPoint(originalPoint + vec2(0.5, 0.0)), b_px, u_radius) - udRoundBox(deformPoint(originalPoint - vec2(0.5, 0.0)), b_px, u_radius),\n              udRoundBox(deformPoint(originalPoint + vec2(0.0, 0.5)), b_px, u_radius) - udRoundBox(deformPoint(originalPoint - vec2(0.0, 0.5)), b_px, u_radius)\n            );\n            if (length(gradient) > 0.0001) refractDir = normalize(mix(refractDir, normalize(gradient), min(length(p_px - originalPoint), 1.0)));\n          }\n          vec2 offset = refractDir * offsetAmt * centreBlend;\n\n          float tiltRefractionScale = 0.05;\n          vec2 tiltOffset = vec2(tan(radians(u_tiltY)), -tan(radians(u_tiltX))) * tiltRefractionScale;\n\n          vec2 localUV = (lensUV - 0.5) / u_magnify + 0.5;\n          vec2 flippedUV = vec2(localUV.x, 1.0 - localUV.y);\n          vec2 mapped = u_bounds.xy + flippedUV * u_bounds.zw;\n          vec2 refracted = mapped + offset - tiltOffset;\n\n          float oob = max(max(-refracted.x, refracted.x - 1.0), max(-refracted.y, refracted.y - 1.0));\n          float blend = 1.0 - smoothstep(0.0, 0.01, oob);\n          vec2 sampleUV = mix(mapped, refracted, blend);\n\n          vec4 baseCol   = sampleSource(mapped);\n\n          vec2 texel = 1.0 / u_textureResolution;\n          vec4 refrCol;\n\n          vec2 chroma = offset * u_aberration;\n\n          if (u_frost > 0.0) {\n              float radius = u_frost * 4.0;\n              vec4 sum = vec4(0.0);\n              const int SAMPLES = 16;\n\n              for (int i = 0; i < SAMPLES; i++) {\n                  float angle = random(v_uv + float(i)) * 6.283185;\n                  float dist = sqrt(random(v_uv - float(i))) * radius;\n                  vec2 foff = vec2(cos(angle), sin(angle)) * texel * dist;\n                  if (u_aberration > 0.0) {\n                      sum.r += sampleSource(sampleUV + foff - chroma).r;\n                      sum.g += sampleSource(sampleUV + foff).g;\n                      sum.b += sampleSource(sampleUV + foff + chroma).b;\n                      sum.a += sampleSource(sampleUV + foff).a;\n                  } else {\n                      sum += sampleSource(sampleUV + foff);\n                  }\n              }\n              refrCol = sum / float(SAMPLES);\n          } else {\n              refrCol = sampleSource(sampleUV);\n              refrCol += sampleSource(sampleUV + vec2( texel.x, 0.0));\n              refrCol += sampleSource(sampleUV + vec2(-texel.x, 0.0));\n              refrCol += sampleSource(sampleUV + vec2(0.0,  texel.y));\n              refrCol += sampleSource(sampleUV + vec2(0.0, -texel.y));\n              refrCol /= 5.0;\n\n              if (u_aberration > 0.0) {\n                  refrCol.r = sampleSource(sampleUV - chroma).r;\n                  refrCol.b = sampleSource(sampleUV + chroma).b;\n              }\n          }\n\n          if (refrCol.a < 0.1) {\n              refrCol = baseCol;\n          }\n\n          float diff = clamp(length(refrCol.rgb - baseCol.rgb) * 4.0, 0.0, 1.0);\n\n          float antiHalo = (1.0 - centreBlend) * diff;\n\n          vec4 final    = refrCol;\n\n          final.rgb = mix(final.rgb, final.rgb * u_tint.rgb, u_tint.a);\n\n          if (u_specular) {\n            vec2 lp1 = vec2(sin(u_time*0.2), cos(u_time*0.3))*0.6 + 0.5;\n            vec2 lp2 = vec2(sin(u_time*-0.4+1.5), cos(u_time*0.25-0.5))*0.6 + 0.5;\n            float h = 0.0;\n            h += smoothstep(0.4,0.0,distance((p_px + b_px) / u_boxSize, lp1))*0.1;\n            h += smoothstep(0.5,0.0,distance((p_px + b_px) / u_boxSize, lp2))*0.08;\n            final.rgb += h;\n          }\n\n          if (u_revealType == 1) {\n              final.rgb *= u_revealProgress;\n              final.a  *= u_revealProgress;\n          }\n\n          final.rgb *= inShape;\n          final.a = final.a * inShape + shadowAlpha;\n\n          gl_FragColor = final;\n        }";
var uniformNames = ["u_tex", "u_resolution", "u_textureResolution", "u_bounds", "u_refraction", "u_aberration", "u_bevelDepth", "u_bevelWidth", "u_frost", "u_radius", "u_time", "u_specular", "u_revealProgress", "u_revealType", "u_tiltX", "u_tiltY", "u_magnify", "u_subpixel", "u_boxSize", "u_tint", "u_stack", "u_stackMapping", "u_stackRegion", "u_interaction", "u_interactionRadius", "u_shadow", "u_shadowMapping"];

// packages/adapters/base/src/material/contact-profile.ts
var specularStart = fragment.indexOf("          if (u_specular) {");
var specularEnd = fragment.indexOf("          if (u_revealType == 1)", specularStart);
if (specularStart < 0 || specularEnd < 0) throw new Error("contact-profile-upstream-drift");
var lighting = `          if (u_specular) {
            vec2 point = (p_px + b_px) / u_boxSize;
            vec2 contact = vec2(u_interaction.x, 1.0 - u_interaction.y);
            float localLight = 1.0 - smoothstep(0.0, 0.42, distance(point, contact));
            float rimLight = pow(clamp(edge, 0.0, 1.0), 2.0);
            float active = clamp(u_interactionRadius, 0.0, 1.0);
            final.rgb += vec3(0.035 + localLight * active * (0.075 + rimLight * 0.10));
          }

`;
var contactFragment = (fragment.slice(0, specularStart) + lighting + fragment.slice(specularEnd)).replace("uniform float u_time;", "uniform float u_time;\n        uniform float u_contactShape;").replace(
  "vec2 b_px = 0.5 * u_boxSize;",
  // The same finite field drives the outward silhouette and its normals.
  // The host's style-owned radius scales with that field, never independently.
  `float dilation = 1.0 + 0.045 * clamp(u_contactShape, 0.0, 1.0);
          vec2 b_px = 0.5 * u_boxSize * dilation;
          float shapeRadius = min(u_radius * dilation, min(b_px.x, b_px.y));`
).replaceAll("b_px, u_radius", "b_px, shapeRadius");

// packages/core/src/prototype.ts
var MODULE_DECLARATION_TOKEN_BRAND = Symbol("@proto.ui/module-declaration-token");

// packages/core/src/spec/feedback/style.ts
function isTemplateStyleHandle(v) {
  return v && typeof v === "object" && v.kind === "tw" && Array.isArray(v.tokens) && v.tokens.every((x) => typeof x === "string");
}

// packages/core/src/spec/template.ts
var DEFAULT_NORMALIZE = {
  flatten: "deep",
  keepNull: false
};
function normalizeChildren(input, opt = DEFAULT_NORMALIZE) {
  const cfg = { ...DEFAULT_NORMALIZE, ...opt };
  if (input === void 0) return null;
  const out = [];
  const push = (v) => {
    if (typeof v === "boolean") {
      throw new Error(
        `[Template] boolean child is illegal. Use null for empty, or omit the child.`
      );
    }
    if (v === void 0) {
      throw new Error(
        `[Template] undefined child is illegal. Use null for empty, or omit the child.`
      );
    }
    if (v === null) {
      if (cfg.keepNull) out.push(null);
      return;
    }
    if (typeof v === "string" || typeof v === "number") {
      out.push(v);
      return;
    }
    out.push(v);
  };
  const walk = (v, depth) => {
    if (!Array.isArray(v)) {
      push(v);
      return;
    }
    if (cfg.flatten === "none") {
      throw new Error(`[Template] array children is not allowed when flatten=none.`);
    }
    if (cfg.flatten === "shallow" && depth >= 1) {
      throw new Error(`[Template] nested array children is not allowed when flatten=shallow.`);
    }
    for (const x of v) walk(x, depth + 1);
  };
  walk(input, 0);
  if (out.length === 0) return null;
  if (out.length === 1) return out[0];
  return out;
}
function isTemplateProps(v) {
  if (!v || typeof v !== "object") return false;
  const keys = Object.keys(v);
  if (keys.length === 0) return true;
  if (keys.length === 1 && keys[0] === "style") return true;
  return false;
}
function assertTemplateProps(v) {
  if (!isTemplateProps(v)) {
    throw new Error(
      `[Template] illegal template-props: only { style?: TemplateStyleHandle } is allowed.
 illegal template-props value: ${JSON.stringify(
        v
      )}`
    );
  }
  if (v?.style && !isTemplateStyleHandle(v.style)) {
    throw new Error(`[Template] style must be a TemplateStyleHandle.`);
  }
}
var SVG_ALLOWED_KEYS = {
  svg: [
    "viewBox",
    "width",
    "height",
    "aria-hidden",
    "fill",
    "stroke",
    "strokeWidth",
    "strokeLinecap",
    "strokeLinejoin",
    "fillRule",
    "clipRule",
    "opacity"
  ],
  g: [
    "fill",
    "stroke",
    "strokeWidth",
    "strokeLinecap",
    "strokeLinejoin",
    "fillRule",
    "clipRule",
    "opacity"
  ],
  path: [
    "d",
    "fill",
    "stroke",
    "strokeWidth",
    "strokeLinecap",
    "strokeLinejoin",
    "fillRule",
    "clipRule",
    "opacity"
  ],
  circle: [
    "cx",
    "cy",
    "r",
    "fill",
    "stroke",
    "strokeWidth",
    "strokeLinecap",
    "strokeLinejoin",
    "fillRule",
    "clipRule",
    "opacity"
  ],
  rect: [
    "x",
    "y",
    "width",
    "height",
    "rx",
    "ry",
    "fill",
    "stroke",
    "strokeWidth",
    "strokeLinecap",
    "strokeLinejoin",
    "fillRule",
    "clipRule",
    "opacity"
  ],
  line: [
    "x1",
    "y1",
    "x2",
    "y2",
    "fill",
    "stroke",
    "strokeWidth",
    "strokeLinecap",
    "strokeLinejoin",
    "fillRule",
    "clipRule",
    "opacity"
  ],
  polyline: [
    "points",
    "fill",
    "stroke",
    "strokeWidth",
    "strokeLinecap",
    "strokeLinejoin",
    "fillRule",
    "clipRule",
    "opacity"
  ],
  ellipse: [
    "cx",
    "cy",
    "rx",
    "ry",
    "fill",
    "stroke",
    "strokeWidth",
    "strokeLinecap",
    "strokeLinejoin",
    "fillRule",
    "clipRule",
    "opacity"
  ],
  polygon: [
    "points",
    "fill",
    "stroke",
    "strokeWidth",
    "strokeLinecap",
    "strokeLinejoin",
    "fillRule",
    "clipRule",
    "opacity"
  ]
};
var SVG_REQUIRED_KEYS = {
  svg: ["viewBox"],
  path: ["d"],
  circle: ["cx", "cy", "r"],
  rect: ["width", "height"],
  line: ["x1", "y1", "x2", "y2"],
  polyline: ["points"],
  ellipse: ["cx", "cy", "rx", "ry"],
  polygon: ["points"]
};
function assertSvgProps(tag, props) {
  if (!props || typeof props !== "object" || Array.isArray(props)) {
    throw new Error(`[Template][SVG] ${tag} props must be an object.`);
  }
  const allowed = new Set(SVG_ALLOWED_KEYS[tag]);
  const keys = Object.keys(props);
  for (const key of keys) {
    if (!allowed.has(key)) {
      throw new Error(`[Template][SVG] ${tag} does not support prop '${key}'.`);
    }
  }
  const required = SVG_REQUIRED_KEYS[tag] ?? [];
  for (const key of required) {
    const value = props[key];
    if (value === void 0 || value === null || value === "") {
      throw new Error(`[Template][SVG] ${tag} requires non-empty prop '${key}'.`);
    }
  }
}
function createSvgNode(tag, props, children) {
  assertSvgProps(tag, props);
  return {
    kind: "svg-node",
    tag,
    props: Object.freeze({ ...props }),
    children
  };
}
function createRendererPrimitives(opt = {}) {
  const normOpt = opt.normalize ?? DEFAULT_NORMALIZE;
  const el = function(type, a, b) {
    let props;
    let childrenInput = null;
    if (arguments.length === 1) {
      childrenInput = null;
    } else if (arguments.length === 2) {
      if (isTemplateProps(a)) {
        assertTemplateProps(a);
        props = a;
        childrenInput = null;
      } else {
        childrenInput = a;
      }
    } else {
      assertTemplateProps(a);
      props = a;
      childrenInput = b;
    }
    return {
      type,
      style: props?.style,
      children: normalizeChildren(childrenInput, normOpt)
    };
  };
  const r = {
    slot() {
      if (arguments.length > 0) {
        const args = Array.from(arguments);
        throw new Error(
          `[Template] slot() takes no arguments.
 illegal slot arguments: ${JSON.stringify(args)}`
        );
      }
      return el({ kind: "slot" });
    }
  };
  const slot = r.slot;
  const svg2 = {
    root(props, children = null) {
      return createSvgNode("svg", props, normalizeChildren(children, normOpt));
    },
    g(props = {}, children = null) {
      return createSvgNode("g", props, normalizeChildren(children, normOpt));
    },
    path(props) {
      return createSvgNode("path", props, null);
    },
    circle(props) {
      return createSvgNode("circle", props, null);
    },
    rect(props) {
      return createSvgNode("rect", props, null);
    },
    line(props) {
      return createSvgNode("line", props, null);
    },
    polyline(props) {
      return createSvgNode("polyline", props, null);
    },
    ellipse(props) {
      return createSvgNode("ellipse", props, null);
    },
    polygon(props) {
      return createSvgNode("polygon", props, null);
    }
  };
  const decoration = (target) => {
    if (!target || typeof target !== "object")
      throw new Error("[Template] invalid decoration target");
    return Object.freeze({ type: Object.freeze({ kind: "decoration", target }) });
  };
  return { el, slot, r, svg: svg2, decoration };
}

// packages/core/src/spec/owned-template-blueprint.ts
var svg = createRendererPrimitives().svg;

// packages/core/src/caps/token.ts
function cap(id) {
  return { id };
}

// packages/core/src/caps/host.ts
var HOST_ELEMENT_CAP = cap("@proto.ui/web/hostElement");

// packages/core/src/shader-presentation.ts
var SHADER_PRESENTATION_LIMITS = Object.freeze({
  maxExtent: 1024,
  maxTexels: 262144,
  maxPasses: 16,
  maxResourceBytes: 16 * 1024 * 1024
});

// packages/adapters/base/src/material/style.ts
function opaqueRgba(value) {
  return Array.isArray(value) && value.length === 4 && value[3] === 1 && [0, 1, 2, 3].every(
    (i) => Object.hasOwn(value, i) && Number.isFinite(value[i]) && value[i] >= 0 && value[i] <= 1
  );
}
function colorContrast(a, b) {
  const luminance3 = (c) => c.slice(0, 3).map((v) => v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4).reduce((s, v, i) => s + v * [0.2126, 0.7152, 0.0722][i], 0);
  const x = luminance3(a), y = luminance3(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
}

// packages/adapters/base/src/material/style-tint-profile.ts
var weights = [0.2126, 0.7152, 0.0722];
var decode = (channel) => channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4;
function luminance(value) {
  return weights.reduce((sum, weight, i) => sum + weight * decode(value[i]), 0);
}
function styleTintLightForeground(fill, foreground) {
  if (!opaqueRgba(fill) || !opaqueRgba(foreground) || colorContrast(fill, foreground) < 4.5)
    throw new Error("invalid-style-tint-palette");
  return luminance(foreground) > luminance(fill);
}
function styleTintEnvelope(fill, foreground) {
  const lightForeground = styleTintLightForeground(fill, foreground);
  const shift = (lightForeground ? -1 : 1) * (1.5 / 255);
  const worstForeground = [
    Math.max(0, Math.min(1, foreground[0] + shift)),
    Math.max(0, Math.min(1, foreground[1] + shift)),
    Math.max(0, Math.min(1, foreground[2] + shift)),
    1
  ];
  const foregroundLuma = luminance(worstForeground);
  const raw = lightForeground ? (foregroundLuma + 0.05) / 4.5 - 0.05 : 4.5 * (foregroundLuma + 0.05) - 0.05;
  let bound;
  if (lightForeground) {
    if (raw < 0 || lightReserve(0) > raw) throw new Error("style-tint-empty-budget");
    let low = 0, high = raw;
    for (let step = 0; step < 32; step++) {
      const middle = (low + high) / 2;
      if (middle + lightReserve(middle) <= raw) low = middle;
      else high = middle;
    }
    bound = low;
  } else {
    bound = raw + 0.0675118372261112;
  }
  if (!(bound > 0 && bound < 1)) throw new Error("style-tint-empty-budget");
  const representation = new Float32Array([bound]);
  if (lightForeground ? representation[0] > bound : representation[0] < bound) {
    const bits = new Uint32Array(representation.buffer);
    bits[0] += lightForeground ? -1 : 1;
  }
  const luminanceBound = representation[0];
  if (!(luminanceBound > 0 && luminanceBound < 1)) throw new Error("style-tint-empty-budget");
  return { lightForeground, luminanceBound, worstForeground };
}
var joinCode = 0.04045;
var joinLow = joinCode / 12.92;
var joinHigh = ((joinCode + 0.055) / 1.055) ** 2.4;
var joinJump = joinHigh - joinLow;
var lightCodeError = 5.5 / 255;
function upperInverse(value) {
  if (value <= joinLow) return 12.92 * value;
  if (value < joinHigh) return joinCode;
  return 1.055 * value ** (1 / 2.4) - 0.055;
}
function lightReserve(bound) {
  const continuousDecode = (value) => decode(value) - (value > joinCode ? joinJump : 0);
  return weights.reduce((sum, weight) => {
    const code = Math.min(upperInverse(Math.min(bound / weight, 1)), 1 - lightCodeError);
    return sum + weight * (continuousDecode(code + lightCodeError) - continuousDecode(code) + joinJump);
  }, 0);
}
var helpers = `
        uniform float u_styleTintLightForeground;
        uniform float u_styleTintLuminanceBound;
        uniform vec4 u_styleTintSourceTone;
        vec3 styleTintLinear(vec3 value) {
          return mix(value / 12.92, pow((value + 0.055) / 1.055, vec3(2.4)),
                     step(vec3(0.04045), value));
        }
        vec3 styleTintSrgb(vec3 value) {
          return mix(value * 12.92, 1.055 * pow(value, vec3(1.0 / 2.4)) - 0.055,
                     step(vec3(0.0031308), value));
        }
`;
var mapping = `
          // Retain the admitted optical source's spatial tone and chroma.
          // The safe bound is luminance, not a narrow per-channel solid-fill band.
          vec3 styleTintDetail = clamp(final.rgb, 0.0, 1.0);
          vec3 styleTintBase = styleTintLinear(u_tint.rgb);
          vec3 styleTintWeights = vec3(0.2126, 0.7152, 0.0722);
          float styleTintTone = dot(styleTintDetail, styleTintWeights);
          // The source-derived interval increases local detail with slopes
          // bounded to 0.5..1.5. Its outside term remains strictly positive:
          // this never clamps a continuous input interval to constant tone.
          styleTintTone = clamp(styleTintTone + u_styleTintSourceTone.z *
            (clamp(styleTintTone - u_styleTintSourceTone.x, 0.0, u_styleTintSourceTone.y) -
             u_styleTintSourceTone.y * styleTintTone), 0.0, 1.0);
          vec3 styleTintHue = mix(styleTintBase, styleTintLinear(styleTintDetail), 0.25);
          float styleTintBoundCode = styleTintSrgb(vec3(u_styleTintLuminanceBound)).r;
          float styleTintTargetCode = mix(
            styleTintBoundCode + (1.0 - styleTintBoundCode) * styleTintTone,
            styleTintBoundCode * styleTintTone, u_styleTintLightForeground);
          float styleTintTarget = styleTintLinear(vec3(styleTintTargetCode)).r;
          // 2^-12 remains normal at the inherited minimum mediump precision.
          // Both branches must stay finite, including black/white endpoints.
          vec3 styleTintDark = styleTintHue *
            (styleTintTarget /
             max(dot(styleTintHue, styleTintWeights), 0.000244140625));
          vec3 styleTintComplement = vec3(1.0) - styleTintHue;
          vec3 styleTintLight = vec3(1.0) - styleTintComplement *
            ((1.0 - styleTintTarget) /
             max(dot(styleTintComplement, styleTintWeights), 0.000244140625));
          // Gamut clipping only moves farther onto the foreground-safe side:
          // down in luminance for light text, up for dark text. Readback guards
          // still reject any finite-precision or near-opaque contrast failure.
          final.rgb = styleTintSrgb(clamp(mix(styleTintLight, styleTintDark,
                                             u_styleTintLightForeground), 0.0, 1.0));

`;
var budgetHelpers = `
        #ifdef GL_FRAGMENT_PRECISION_HIGH
        vec2 budgetSide(vec2 margin, vec2 delta, vec2 tau) {
          vec2 m = max(margin, vec2(0.0));
          vec2 square = m * m;
          return square / (square + delta * delta + tau * tau);
        }
        float budgetChannel(vec2 center, vec2 delta, vec2 margin, vec2 tau, float product) {
          vec2 low = budgetSide(center - margin, delta, tau);
          vec2 high = budgetSide(vec2(1.0) - margin - center, delta, tau);
          product = product * low.x;
          product = product * low.y;
          product = product * high.x;
          product = product * high.y;
          return product;
        }
        #endif
`;
var budgetOffset = `          vec2 finalOffset = oldOffset;
          #ifdef GL_FRAGMENT_PRECISION_HIGH
          float budgetShortSide = min(u_boxSize.x, u_boxSize.y);
          // dmask already reflects the applicable static/contact shape radius.
          float budgetDepth = -dmask;
          float budgetGate = smoothstep((2.0 / 38.0) * budgetShortSide,
                                       (4.0 / 38.0) * budgetShortSide, budgetDepth);
          float budgetWide = 1.0 - smoothstep(0.0, 0.44 * budgetShortSide, budgetDepth);
          vec2 budgetDelta = refractDir *
            (u_refraction * centreBlend * budgetGate * (budgetWide - edge));
          vec2 budgetTexel = 1.0 / u_textureResolution;
          float budgetR = 1.0 - u_aberration;
          float budgetB = 1.0 + u_aberration;
          float budgetLambda = budgetChannel(
            mapped + budgetR * oldOffset, budgetR * budgetDelta,
            3.5 / u_textureResolution, budgetTexel, 1.0);
          budgetLambda = budgetChannel(
            mapped + oldOffset, budgetDelta,
            4.5 / u_textureResolution, budgetTexel, budgetLambda);
          budgetLambda = budgetChannel(
            mapped + budgetB * oldOffset, budgetB * budgetDelta,
            3.5 / u_textureResolution, budgetTexel, budgetLambda);
          // BaseCol is unchanged, but its old full footprint must also be safe.
          budgetLambda = budgetChannel(
            mapped, vec2(0.0), 3.5 / u_textureResolution, budgetTexel, budgetLambda);
          finalOffset = oldOffset + budgetLambda * budgetDelta;
          #endif
          // This FINAL declaration becomes the unique diagnostic replacement anchor.
          // strictWarpOff replaces this complete line with vec2 offset = vec2(0.0);
          // No assignment/addition to offset is permitted after this line.
          vec2 offset = finalOffset;
`;
function derive(source) {
  const tint = "          final.rgb = mix(final.rgb, final.rgb * u_tint.rgb, u_tint.a);";
  const reveal = "          if (u_revealType == 1) {";
  const main = "        void main(){";
  const offset = "          vec2 offset = refractDir * offsetAmt * centreBlend;";
  const mapped = "          vec2 mapped = u_bounds.xy + flippedUV * u_bounds.zw;";
  const refracted = "          vec2 refracted = mapped + offset - tiltOffset;";
  const chroma = "          vec2 chroma = offset * u_aberration;";
  if ([tint, reveal, main, offset, mapped, refracted, chroma].some(
    (anchor) => !source.includes(anchor) || source.split(anchor.trim()).length !== 2
  ) || !source.includes(mapped + "\n" + refracted) || source.indexOf(offset) >= source.indexOf(mapped) || source.slice(source.indexOf(main), source.indexOf(refracted)).includes("sampleSource(") || // Only the declaration and the two frozen reads are allowed. This also
  // rejects component/index writes and passing offset to an out parameter.
  source.match(/\boffset\b/g)?.length !== 3)
    throw new Error("style-tint-profile-upstream-drift");
  return source.replace(offset, "          vec2 oldOffset = refractDir * offsetAmt * centreBlend;").replace(refracted, budgetOffset + refracted).replace(tint, "          // The opt-in style tint is applied after all lighting below.").replace(
    "smoothstep(0.4,0.0,distance((p_px + b_px) / u_boxSize, lp1))",
    "(1.0 - smoothstep(0.0,0.4,distance((p_px + b_px) / u_boxSize, lp1)))"
  ).replace(
    "smoothstep(0.5,0.0,distance((p_px + b_px) / u_boxSize, lp2))",
    "(1.0 - smoothstep(0.0,0.5,distance((p_px + b_px) / u_boxSize, lp2)))"
  ).replace(main, helpers + budgetHelpers + main).replace(reveal, mapping + reveal);
}
var styleTintFragment = derive(fragment);
var styleTintContactFragment = derive(contactFragment);

// packages/adapters/base/src/material/program-inputs.ts
function validateOpticalFrameInputs(frame) {
  const { source, geometry, variant, contact } = frame;
  if (frame.tint !== void 0 && (frame.tint !== "style-fill" || variant !== "regular"))
    throw new Error("style-tint-profile-unavailable");
  const tintEnvelope = frame.tint ? styleTintEnvelope(frame.fill, frame.foreground) : null;
  const outset = geometry.paintOutset ?? 0;
  const width = Math.ceil((geometry.width + 2 * outset) * geometry.dpr), height = Math.ceil((geometry.height + 2 * outset) * geometry.dpr);
  if (![width, height, outset, geometry.radius, geometry.dpr, ...geometry.bounds].every(
    Number.isFinite
  ) || outset < 0 || outset > 165 || width < 1 || height < 1 || width > 2048 || height > 2048 || width * height > 1048576 || geometry.dpr < 0.5 || geometry.dpr > 3)
    throw new Error("optical-geometry-budget");
  if (geometry.bounds[0] < 0 || geometry.bounds[1] < 0 || geometry.bounds[2] <= 0 || geometry.bounds[3] <= 0 || geometry.bounds[0] + geometry.bounds[2] > 1 || geometry.bounds[1] + geometry.bounds[3] > 1)
    throw new Error("optical-source-bounds");
  if (!Number.isInteger(source.width) || !Number.isInteger(source.height) || source.width < 1 || source.height < 1 || source.width > 2048 || source.height > 2048 || source.width * source.height > 1048576 || !(source.pixels instanceof Uint8Array) || source.pixels.length !== source.width * source.height * 4)
    throw new Error("invalid-optical-source");
  for (let i = 3; i < source.pixels.length; i += 4)
    if (source.pixels[i] !== 255) throw new Error("nonopaque-optical-source");
  if (contact && ![contact.x, contact.y, contact.deltaX, contact.deltaY, contact.strength].every(Number.isFinite))
    throw new Error("invalid-optical-contact");
  return { width, height, outset, tintEnvelope };
}

// packages/adapters/base/src/material/style-tint-source.ts
function styleTintSourceTone(pixels) {
  if (!(pixels instanceof Uint8Array) || !pixels.length || pixels.length % 4)
    throw new Error("invalid-style-tint-source");
  let minR = pixels[0], minG = pixels[1], minB = pixels[2], maxR = minR, maxG = minG, maxB = minB;
  for (let at = 4; at < pixels.length; at += 4) {
    const r = pixels[at], g = pixels[at + 1], b = pixels[at + 2];
    if (r < minR) minR = r;
    else if (r > maxR) maxR = r;
    if (g < minG) minG = g;
    else if (g > maxG) maxG = g;
    if (b < minB) minB = b;
    else if (b > maxB) maxB = b;
    if (!(minR | minG | minB) && maxR === 255 && maxG === 255 && maxB === 255) break;
  }
  const low = Math.max(0, (0.2126 * minR + 0.7152 * minG + 0.0722 * minB - 1) / 255);
  const high = Math.min(1, (0.2126 * maxR + 0.7152 * maxG + 0.0722 * maxB + 1) / 255 + 0.21);
  const scalar = new Float32Array(1);
  const bits = new Uint32Array(scalar.buffer);
  const inward = (value) => {
    scalar[0] = value;
    if (scalar[0] > value) bits[0]--;
    return scalar[0];
  };
  const representedLow = Math.fround(low);
  const range = inward(Math.max(0, Math.min(high - representedLow, 1 - representedLow)));
  const boost = inward(0.5 / Math.max(range, 1 - range));
  return [representedLow, range, boost, 0];
}

// packages/adapters/base/src/material/program.ts
var decodeSrgb = (channel) => channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4;
var linearBytes = Float64Array.from({ length: 256 }, (_, code) => decodeSrgb(code / 255));
var linearOverWhite = Array.from({ length: 5 }, (_, index) => {
  const alpha = index + 250;
  return Float64Array.from({ length: 256 }, (_2, code) => {
    const composite = code / 255 + (1 - alpha / 255);
    return composite > 1 ? NaN : decodeSrgb(composite);
  });
});
var luminance2 = (color) => decodeSrgb(color[0]) * 0.2126 + decodeSrgb(color[1]) * 0.7152 + decodeSrgb(color[2]) * 0.0722;
var contrast = (a, b) => (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
function createWebOpticalProgram(canvas, diagnostic = null, prefilterFactory = null) {
  let gl = null, buffer = null;
  const pipelines = /* @__PURE__ */ new Map();
  let textures = [];
  const metrics = {
    renders: 0,
    programBuilds: 0,
    sourceUploads: 0,
    sourcePreparations: 0,
    sourcePreparationMilliseconds: 0,
    sourcePreparationCacheHits: 0,
    tintSourcePreparations: 0,
    tintSourcePreparationMilliseconds: 0,
    cpuSourcePreparations: 0,
    cpuSourcePreparationMilliseconds: 0,
    gpuSourcePreparations: 0,
    gpuSourcePreparationSubmitMilliseconds: 0,
    prefilterProgramBuilds: 0,
    readbackAllocations: 0,
    readbackMilliseconds: 0,
    contrastMilliseconds: 0,
    renderMilliseconds: 0,
    encodeMilliseconds: 0
  };
  const FrameReference = typeof WeakRef === "function" ? WeakRef : null;
  const preparedEntryLimit = FrameReference ? 4 : 1, preparedByteLimit = 4 * 1024 * 1024;
  const prepared = [];
  let preparedBytes = 0;
  let uploaded = null;
  let gpuPrefilter;
  let prefilterScratch = null;
  let readback = null;
  function sourceIdentity(source) {
    return {
      frame: FrameReference ? new FrameReference(source) : { deref: () => source },
      // Weak membership preserves identity without keeping old DOM nodes or
      // input buffers alive if a caller replaces fields on the same frame.
      input: new WeakSet([source.pixels]),
      canvas: new WeakSet([source.canvas]),
      scope: new WeakSet([source.scope]),
      revision: source.revision,
      width: source.width,
      height: source.height,
      byteOffset: source.pixels.byteOffset
    };
  }
  function sameSource(identity, source) {
    return identity.frame.deref() === source && identity.revision === source.revision && identity.width === source.width && identity.height === source.height && identity.byteOffset === source.pixels.byteOffset && identity.input.has(source.pixels) && identity.canvas.has(source.canvas) && identity.scope.has(source.scope);
  }
  function retirePrepared(index) {
    const [entry] = prepared.splice(index, 1);
    preparedBytes -= entry.byteLength;
    if (entry.backend === "gpu") entry.release();
  }
  function prunePrepared(source) {
    for (let index = prepared.length - 1; index >= 0; index--) {
      const { identity } = prepared[index], previous = identity.frame.deref();
      if (!previous || !sameSource(identity, previous) || identity.canvas.has(source.canvas) && identity.scope.has(source.scope) && identity.revision !== source.revision)
        retirePrepared(index);
    }
  }
  function prepareSource(source) {
    const index = prepared.findIndex((entry) => sameSource(entry.identity, source));
    if (index >= 0) {
      const [entry] = prepared.splice(index, 1);
      prepared.push(entry);
      metrics.sourcePreparationCacheHits++;
      return entry;
    }
    while (prepared.length >= preparedEntryLimit || preparedBytes + source.pixels.byteLength > preparedByteLimit)
      retirePrepared(0);
    const preparationStarted = performance.now();
    try {
      if (gpuPrefilter === void 0) {
        gpuPrefilter = prefilterFactory?.(gl) ?? null;
        if (gpuPrefilter) metrics.prefilterProgramBuilds++;
      }
      let entry;
      if (gpuPrefilter) {
        const output = gpuPrefilter.filter(source.pixels, source.width, source.height);
        entry = {
          identity: sourceIdentity(source),
          byteLength: source.pixels.byteLength,
          backend: "gpu",
          ...output
        };
        metrics.gpuSourcePreparations++;
        metrics.sourceUploads++;
        metrics.gpuSourcePreparationSubmitMilliseconds += performance.now() - preparationStarted;
      } else {
        if (prefilterScratch?.length !== source.pixels.length / 4)
          prefilterScratch = new Uint32Array(source.pixels.length / 4);
        const pixels = prefilter(source.pixels, source.width, source.height, prefilterScratch);
        entry = {
          identity: sourceIdentity(source),
          byteLength: pixels.byteLength,
          backend: "cpu",
          pixels
        };
        metrics.cpuSourcePreparations++;
        metrics.cpuSourcePreparationMilliseconds += performance.now() - preparationStarted;
      }
      metrics.sourcePreparations++;
      metrics.sourcePreparationMilliseconds += performance.now() - preparationStarted;
      prepared.push(entry);
      preparedBytes += entry.byteLength;
      return entry;
    } catch (error) {
      clear();
      throw error;
    }
  }
  function clear() {
    canvas.width = 0;
    canvas.height = 0;
    gl?.useProgram(null);
    while (prepared.length) retirePrepared(prepared.length - 1);
    gpuPrefilter?.dispose();
    gpuPrefilter = void 0;
    prefilterScratch = null;
    uploaded = null;
    readback = null;
    if (!gl) return;
    for (const texture of textures) gl.deleteTexture(texture);
    if (buffer) gl.deleteBuffer(buffer);
    for (const pipeline of pipelines.values()) gl.deleteProgram(pipeline.program);
    pipelines.clear();
    textures = [];
    buffer = null;
  }
  function initialize(contact, tinted) {
    const key = `${contact ? "contact" : "static"}:${tinted ? "style-tint" : "neutral"}`;
    if (gl?.isContextLost()) {
      clear();
      throw new Error("webgl-unavailable");
    }
    const existing = pipelines.get(key);
    if (existing) return existing;
    metrics.programBuilds++;
    gl ??= canvas.getContext("webgl", {
      alpha: true,
      premultipliedAlpha: true,
      preserveDrawingBuffer: true,
      antialias: false
    });
    if (!gl || gl.isContextLost()) throw new Error("webgl-unavailable");
    const g = gl, shaders = [];
    let program = null;
    try {
      for (const [kind, code] of [
        [g.VERTEX_SHADER, vertex],
        [
          g.FRAGMENT_SHADER,
          tinted ? contact ? styleTintContactFragment : styleTintFragment : contact ? contactFragment : fragment
        ]
      ]) {
        const shader = g.createShader(kind);
        if (!shader) throw new Error("shader-allocation");
        shaders.push(shader);
        g.shaderSource(shader, code);
        g.compileShader(shader);
        if (!g.getShaderParameter(shader, g.COMPILE_STATUS)) throw new Error("shader-compilation");
      }
      program = g.createProgram();
      if (!program) throw new Error("program-allocation");
      for (const shader of shaders) g.attachShader(program, shader);
      g.linkProgram(program);
      if (!g.getProgramParameter(program, g.LINK_STATUS)) throw new Error("program-link");
      const locations = Object.fromEntries(
        [
          ...uniformNames,
          "u_contactShape",
          ...tinted ? ["u_styleTintLightForeground", "u_styleTintLuminanceBound", "u_styleTintSourceTone"] : []
        ].map((name) => [name, g.getUniformLocation(program, name)])
      );
      if (!buffer) {
        buffer = g.createBuffer();
        if (!buffer) throw new Error("buffer-allocation");
        g.bindBuffer(g.ARRAY_BUFFER, buffer);
        g.bufferData(g.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), g.STATIC_DRAW);
      }
      const attribute = g.getAttribLocation(program, "a_position");
      if (attribute < 0) throw new Error("position-attribute");
      if (textures.length === 0)
        for (let i = 0; i < 3; i++) {
          const texture = g.createTexture();
          if (!texture) throw new Error("texture-allocation");
          textures.push(texture);
          g.activeTexture(g.TEXTURE0 + i);
          g.bindTexture(g.TEXTURE_2D, texture);
          g.texParameteri(g.TEXTURE_2D, g.TEXTURE_MIN_FILTER, g.LINEAR);
          g.texParameteri(g.TEXTURE_2D, g.TEXTURE_MAG_FILTER, g.LINEAR);
          g.texParameteri(g.TEXTURE_2D, g.TEXTURE_WRAP_S, g.CLAMP_TO_EDGE);
          g.texParameteri(g.TEXTURE_2D, g.TEXTURE_WRAP_T, g.CLAMP_TO_EDGE);
          g.texImage2D(
            g.TEXTURE_2D,
            0,
            g.RGBA,
            1,
            1,
            0,
            g.RGBA,
            g.UNSIGNED_BYTE,
            new Uint8Array(4)
          );
        }
      const pipeline = { program, locations, attribute };
      pipelines.set(key, pipeline);
      return pipeline;
    } catch (error) {
      if (program) g.deleteProgram(program);
      clear();
      throw error;
    } finally {
      for (const shader of shaders) g.deleteShader(shader);
    }
  }
  return {
    clear,
    inspect: () => ({
      ...metrics,
      sourcePreparationCacheEntries: prepared.length,
      sourcePreparationCacheBytes: preparedBytes,
      sourcePreparationCpuCacheBytes: prepared.reduce(
        (sum, entry) => sum + (entry.backend === "cpu" ? entry.byteLength : 0),
        0
      ),
      sourcePreparationGpuCacheBytes: prepared.reduce(
        (sum, entry) => sum + (entry.backend === "gpu" ? entry.byteLength : 0),
        0
      )
    }),
    dispose() {
      clear();
      const previous = gl;
      gl = null;
      previous?.getExtension("WEBGL_lose_context")?.loseContext();
    },
    render(frame) {
      const started = performance.now();
      const { source, geometry, pressed, variant } = frame;
      const { width, height, outset, tintEnvelope } = validateOpticalFrameInputs(frame);
      const contact = frame.contact;
      const clamp = (n, low, high) => Math.max(low, Math.min(high, n));
      const strength = contact ? clamp(contact.strength, 0, 1) : pressed ? 1 : 0;
      const blend = (rest, held) => strength === 1 ? held : rest + (held - rest) * strength;
      const pipeline = initialize(!!contact, !!frame.tint), { locations } = pipeline, g = gl;
      if (canvas.width !== width) canvas.width = width;
      if (canvas.height !== height) canvas.height = height;
      prunePrepared(source);
      const currentPrepared = variant === "regular" ? prepareSource(source) : null;
      if (tintEnvelope && currentPrepared && !currentPrepared.tintSourceTone) {
        const toneStarted = performance.now();
        currentPrepared.tintSourceTone = styleTintSourceTone(source.pixels);
        const elapsed = performance.now() - toneStarted;
        metrics.tintSourcePreparations++;
        metrics.tintSourcePreparationMilliseconds += elapsed;
        metrics.sourcePreparationMilliseconds += elapsed;
      }
      g.viewport(0, 0, width, height);
      g.useProgram(pipeline.program);
      g.bindBuffer(g.ARRAY_BUFFER, buffer);
      g.enableVertexAttribArray(pipeline.attribute);
      g.vertexAttribPointer(pipeline.attribute, 2, g.FLOAT, false, 0, 0);
      g.activeTexture(g.TEXTURE0);
      const gpuTexture = currentPrepared?.backend === "gpu" ? currentPrepared.texture : null;
      if (gpuTexture) uploaded = null;
      g.bindTexture(g.TEXTURE_2D, gpuTexture ?? textures[0]);
      g.pixelStorei(g.UNPACK_ALIGNMENT, 1);
      if (!gpuTexture && (uploaded?.source !== source || uploaded.variant !== variant || !sameSource(uploaded.identity, source))) {
        g.texImage2D(
          g.TEXTURE_2D,
          0,
          g.RGBA,
          source.width,
          source.height,
          0,
          g.RGBA,
          g.UNSIGNED_BYTE,
          currentPrepared?.backend === "cpu" ? currentPrepared.pixels : source.pixels
        );
        uploaded = {
          source,
          variant,
          identity: currentPrepared?.identity ?? sourceIdentity(source)
        };
        metrics.sourceUploads++;
      }
      const f = (name, value) => g.uniform1f(locations[name], value), i = (name, value) => g.uniform1i(locations[name], value);
      const v2 = (name, value) => g.uniform2fv(locations[name], value), v4 = (name, value) => g.uniform4fv(locations[name], value);
      i("u_tex", 0);
      v2("u_resolution", [width, height]);
      v2("u_textureResolution", [source.width, source.height]);
      v4("u_bounds", geometry.bounds);
      f("u_refraction", diagnostic === "zero-refraction" ? 0 : blend(8e-3, 0.018));
      f(
        "u_aberration",
        contact && diagnostic !== "zero-refraction" && diagnostic !== "zero-aberration" ? 0.12 + 0.18 * strength : 0
      );
      f("u_bevelDepth", diagnostic === "zero-refraction" ? 0 : blend(0.06, 0.12));
      f("u_bevelWidth", 0.22);
      f("u_frost", 0);
      f("u_radius", Math.min(geometry.radius * geometry.dpr, width / 2, height / 2));
      f("u_time", 0);
      i("u_specular", 1);
      f("u_revealProgress", 1);
      i("u_revealType", 0);
      f("u_tiltX", 0);
      f("u_tiltY", 0);
      f("u_magnify", diagnostic === "zero-refraction" ? 1 : blend(1.025, 1.08));
      v2("u_subpixel", [outset * geometry.dpr, outset * geometry.dpr]);
      v2("u_boxSize", [geometry.width * geometry.dpr, geometry.height * geometry.dpr]);
      const dark = frame.foreground[0] + frame.foreground[1] + frame.foreground[2] > 1.5;
      v4(
        "u_tint",
        frame.tint ? [...frame.fill] : dark ? [0.45, 0.45, 0.48, variant === "clear" ? 0.35 : 0.65] : [1.05, 1.05, 1.06, variant === "clear" ? 0.15 : 0.45]
      );
      if (tintEnvelope) {
        f("u_styleTintLightForeground", tintEnvelope.lightForeground ? 1 : 0);
        f("u_styleTintLuminanceBound", tintEnvelope.luminanceBound);
        v4("u_styleTintSourceTone", currentPrepared.tintSourceTone);
      }
      i("u_stack", 1);
      v4("u_stackMapping", [0, 0, 0, 0]);
      v4("u_stackRegion", [0, 0, 0, 0]);
      f("u_contactShape", contact && diagnostic !== "zero-deformation" ? strength : 0);
      v4(
        "u_interaction",
        contact ? [
          clamp(contact.x, 0, 1),
          clamp(contact.y, 0, 1),
          clamp(contact.deltaX, -1, 1) * 0.055 * (diagnostic === "zero-deformation" ? 0 : strength),
          clamp(contact.deltaY, -1, 1) * 0.055 * (diagnostic === "zero-deformation" ? 0 : strength)
        ] : [0.5, 0.5, 0, 0]
      );
      f("u_interactionRadius", contact ? 0.8 * strength : 0);
      i("u_shadow", 2);
      v4("u_shadowMapping", [0, 0, 0, 0]);
      g.clearColor(0, 0, 0, 0);
      g.clear(g.COLOR_BUFFER_BIT);
      g.disable(g.BLEND);
      g.drawArrays(g.TRIANGLE_STRIP, 0, 4);
      if (g.getError() !== g.NO_ERROR || g.isContextLost()) {
        clear();
        throw new Error("gpu-frame-failed");
      }
      const readbackStarted = performance.now();
      const readbackBytes = width * height * 4;
      if (!readback || readback.buffer.byteLength < readbackBytes) {
        readback = new Uint8Array(readbackBytes);
        metrics.readbackAllocations++;
      } else if (readback.length !== readbackBytes) {
        readback = new Uint8Array(readback.buffer, 0, readbackBytes);
      }
      const pixels = readback;
      g.readPixels(0, 0, width, height, g.RGBA, g.UNSIGNED_BYTE, pixels);
      metrics.readbackMilliseconds += performance.now() - readbackStarted;
      if (g.getError() !== g.NO_ERROR || g.isContextLost()) {
        clear();
        throw new Error("gpu-readback-failed");
      }
      const contrastStarted = performance.now();
      const foregroundLuminance = luminance2(tintEnvelope?.worstForeground ?? frame.foreground);
      let opaqueSamples = 0;
      for (let at = 0; at < pixels.length; at += 4) {
        const alpha = pixels[at + 3];
        if (alpha === 255) opaqueSamples++;
        if (alpha < 250) continue;
        const red = pixels[at], green = pixels[at + 1], blue = pixels[at + 2];
        const blackLuminance = linearBytes[red] * 0.2126 + linearBytes[green] * 0.7152 + linearBytes[blue] * 0.0722;
        if (contrast(blackLuminance, foregroundLuminance) < 4.5)
          throw new Error("rendered-contrast-unsafe");
        if (tintEnvelope) {
          if (foregroundLuminance > blackLuminance !== tintEnvelope.lightForeground)
            throw new Error("rendered-contrast-unsafe");
          if (alpha < 255) {
            const table = linearOverWhite[alpha - 250];
            const whiteLuminance = table[red] * 0.2126 + table[green] * 0.7152 + table[blue] * 0.0722;
            if (!Number.isFinite(whiteLuminance) || contrast(whiteLuminance, foregroundLuminance) < 4.5 || foregroundLuminance > whiteLuminance !== tintEnvelope.lightForeground)
              throw new Error("rendered-contrast-unsafe");
          }
        }
      }
      metrics.contrastMilliseconds += performance.now() - contrastStarted;
      if (frame.tint && opaqueSamples === 0) throw new Error("rendered-style-tint-empty");
      const encoding = performance.now();
      const result = canvas.toDataURL("image/png");
      metrics.renders++;
      metrics.encodeMilliseconds += performance.now() - encoding;
      metrics.renderMilliseconds += performance.now() - started;
      if (!result.startsWith("data:image/png;base64,"))
        throw new Error("optical-image-unavailable");
      return result;
    }
  };
}
function prefilter(pixels, width, height, scratch = new Uint32Array(pixels.length / 4), output = new Uint8Array(pixels.length)) {
  const aligned = pixels.byteOffset % 4 === 0 ? pixels : new Uint8Array(pixels);
  const input = new Uint32Array(aligned.buffer, aligned.byteOffset, pixels.length / 4);
  const target = new Uint32Array(output.buffer, output.byteOffset, output.length / 4);
  function sample(a, b, c, center, d, e, f) {
    const even = (a & 16711935) + (f & 16711935) + 6 * ((b & 16711935) + (e & 16711935)) + 15 * ((c & 16711935) + (d & 16711935)) + 20 * (center & 16711935) + 2097184;
    const odd = (a >>> 8 & 16711935) + (f >>> 8 & 16711935) + 6 * ((b >>> 8 & 16711935) + (e >>> 8 & 16711935)) + 15 * ((c >>> 8 & 16711935) + (d >>> 8 & 16711935)) + 20 * (center >>> 8 & 16711935) + 2097184;
    return even >>> 6 & 16711935 | (odd >>> 6 & 16711935) << 8;
  }
  for (let y = 0; y < height; y++) {
    const base = y * width;
    let a = input[base], b = a, c = a, center = a, d = input[base + Math.min(width - 1, 1)], e = input[base + Math.min(width - 1, 2)], f = input[base + Math.min(width - 1, 3)];
    for (let x = 0; x < width; x++) {
      scratch[base + x] = sample(a, b, c, center, d, e, f);
      a = b;
      b = c;
      c = center;
      center = d;
      d = e;
      e = f;
      f = input[base + Math.min(width - 1, x + 4)];
    }
  }
  for (let y = 0; y < height; y++) {
    const base = y * width, a = Math.max(0, y - 3) * width, b = Math.max(0, y - 2) * width, c = Math.max(0, y - 1) * width, d = Math.min(height - 1, y + 1) * width, e = Math.min(height - 1, y + 2) * width, f = Math.min(height - 1, y + 3) * width;
    for (let x = 0; x < width; x++)
      target[base + x] = sample(
        scratch[a + x],
        scratch[b + x],
        scratch[c + x],
        scratch[base + x],
        scratch[d + x],
        scratch[e + x],
        scratch[f + x]
      );
  }
  return output;
}

// packages/adapters/base/src/material/image-prepare.ts
var emptyCounters = () => ({
  pendingImages: 0,
  decodedImages: 0,
  imagePreparations: 0,
  peakPendingImages: 0,
  imageDecodes: 0,
  imageDecodeMilliseconds: 0,
  imageDecodeFailures: 0,
  imageDecodeFailureMilliseconds: 0,
  imageDecodeCancellations: 0,
  imageDecodeCancellationMilliseconds: 0,
  imageReadyCallbacks: 0,
  imageReadyCallbackMilliseconds: 0,
  imageReadyCallbackFailures: 0,
  imageReuseHits: 0
});
var counters = /* @__PURE__ */ new WeakMap();
function inspectOpticalImageResources(document2) {
  return { ...counters.get(document2) ?? emptyCounters() };
}
function prepareOpticalImage(document2, source, ready, failed) {
  return decodeOpticalImage(document2, source, () => ready(), failed);
}
function publishReady(win, stats, ready, failed) {
  const started = win.performance.now();
  stats.imageReadyCallbacks++;
  let callbackFailed = false;
  try {
    ready();
  } catch {
    stats.imageReadyCallbackFailures++;
    callbackFailed = true;
  } finally {
    stats.imageReadyCallbackMilliseconds += win.performance.now() - started;
  }
  if (callbackFailed) failed();
}
function retireAfterFailure(retire, failed) {
  try {
    retire();
  } catch {
  }
  try {
    failed();
  } catch {
  }
}
function decodeOpticalImage(document2, source, ready, failed) {
  const win = document2.defaultView;
  if (!win) throw new Error("image-owner-document-unavailable");
  const image = new win.Image();
  const stats = counters.get(document2) ?? emptyCounters();
  counters.set(document2, stats);
  let live = true, pending = true;
  const started = win.performance.now();
  let observed = false;
  const observe = (outcome) => {
    if (observed) return;
    observed = true;
    const elapsed = win.performance.now() - started;
    if (outcome === "ready") {
      stats.imageDecodes++;
      stats.imageDecodeMilliseconds += elapsed;
    } else if (outcome === "failed") {
      stats.imageDecodeFailures++;
      stats.imageDecodeFailureMilliseconds += elapsed;
    } else {
      stats.imageDecodeCancellations++;
      stats.imageDecodeCancellationMilliseconds += elapsed;
    }
  };
  stats.pendingImages++;
  stats.imagePreparations++;
  stats.peakPendingImages = Math.max(stats.peakPendingImages, stats.pendingImages);
  const clearCallbacks = () => {
    ready = () => {
    };
    failed = () => {
    };
  };
  const retire = () => {
    if (!live) return;
    live = false;
    if (pending) {
      observe("cancelled");
      stats.pendingImages--;
    } else stats.decodedImages--;
    clearCallbacks();
    source = "";
    image.src = "";
  };
  try {
    image.src = source;
    source = "";
    if (typeof image.decode !== "function") throw new Error("image-decode-unavailable");
    const fail = () => {
      if (!live) return;
      if (pending) observe("failed");
      const callback = failed;
      retireAfterFailure(retire, callback);
    };
    void image.decode().then(() => {
      if (!live) return;
      if (!image.complete || image.naturalWidth <= 0) {
        fail();
        return;
      }
      observe("ready");
      pending = false;
      stats.pendingImages--;
      stats.decodedImages++;
      const callback = ready;
      ready = () => {
      };
      publishReady(win, stats, () => callback(image), fail);
      clearCallbacks();
    }, fail).catch(fail);
  } catch (error) {
    observe("failed");
    retire();
    throw error;
  }
  return retire;
}

// experiments/liquid-canvas-transport/owner.ts
function ticketFor(entry) {
  return Object.freeze({
    identity: entry.identity,
    width: entry.width,
    height: entry.height,
    current: () => entry.access?.current(entry) ?? false,
    readPixels: () => entry.access?.read(entry) ?? null,
    release: () => entry.access?.release(entry)
  });
}
function facts(identity) {
  const {
    sourceRevision,
    geometryRevision,
    producerEpoch,
    logicalWidth,
    logicalHeight,
    paintOutset,
    dpr
  } = identity;
  const copy = Object.freeze({
    sourceRevision,
    geometryRevision,
    producerEpoch,
    logicalWidth,
    logicalHeight,
    paintOutset,
    dpr
  });
  if (![sourceRevision, geometryRevision, producerEpoch].every(
    (n) => Number.isSafeInteger(n) && n >= 0
  ) || ![logicalWidth, logicalHeight, paintOutset, dpr].every(Number.isFinite) || logicalWidth <= 0 || logicalHeight <= 0 || paintOutset < 0 || paintOutset > 165 || dpr < 0.5 || dpr > 3)
    throw new Error("snapshot-identity-unavailable");
  const width = Math.ceil((logicalWidth + 2 * paintOutset) * dpr);
  const height = Math.ceil((logicalHeight + 2 * paintOutset) * dpr);
  if (width > 2048 || height > 2048 || width * height > 1048576)
    throw new Error("snapshot-output-budget");
  return { identity: copy, width, height };
}
function createCanvasSnapshotOwner(target, port) {
  let host = target;
  let document2 = target.ownerDocument;
  let transport = port;
  let disposed = false, capturing = false, operation = 0;
  let current = null;
  const owned = /* @__PURE__ */ new Set();
  const counters2 = {
    created: 0,
    retired: 0,
    live: 0,
    bytes: 0,
    peakLive: 0,
    peakBytes: 0,
    captures: 0,
    refusals: 0,
    readbacks: 0,
    cleanupFailures: 0
  };
  const logical = (entry) => !disposed && !entry.retired && owned.has(entry);
  function detach(entries) {
    const resources = [];
    for (const entry of entries) {
      if (entry.retired) continue;
      entry.retired = true;
      owned.delete(entry);
      if (current === entry) current = null;
      entry.ownerCurrent = null;
      entry.access = null;
      if (entry.resource) {
        resources.push(entry.resource);
        counters2.retired++;
        counters2.live--;
        counters2.bytes -= entry.resource.bytes;
        entry.resource = null;
      }
    }
    return resources;
  }
  function clean(resources) {
    let failed = false, first;
    for (const resource of resources) {
      try {
        resource.retire(resource.storage);
      } catch (error) {
        counters2.cleanupFailures++;
        if (!failed) {
          failed = true;
          first = error;
        }
      }
    }
    if (failed) throw first;
  }
  function release(entry) {
    clean(detach([entry]));
  }
  function valid(entry) {
    if (!logical(entry) || !host || !document2 || !transport) return false;
    const sameDocument = host.ownerDocument === document2;
    if (!logical(entry) || !sameDocument) return false;
    const connected = host.isConnected;
    if (!logical(entry) || !connected) return false;
    const dpr = transport.devicePixelRatio(document2);
    if (!logical(entry) || dpr !== entry.identity.dpr) return false;
    const accepted = entry.ownerCurrent?.() === true;
    return logical(entry) && accepted;
  }
  function checkCurrent(entry) {
    try {
      if (current === entry && valid(entry)) return true;
    } catch (error) {
      try {
        release(entry);
      } catch {
      }
      throw error;
    }
    release(entry);
    return false;
  }
  const access = {
    current: checkCurrent,
    read(entry) {
      if (!checkCurrent(entry)) return null;
      const resource = entry.resource;
      try {
        const read = transport.read;
        if (!checkCurrent(entry)) return null;
        const pixels = read.call(transport, resource.storage, entry.width, entry.height);
        counters2.readbacks++;
        if (!checkCurrent(entry)) return null;
        if (!(pixels instanceof Uint8ClampedArray) || pixels.length !== entry.width * entry.height * 4)
          throw new Error("snapshot-readback-unavailable");
        const result = new Uint8ClampedArray(pixels);
        return checkCurrent(entry) ? result : null;
      } catch (error) {
        try {
          release(entry);
        } catch {
        }
        throw error;
      }
    },
    release
  };
  return {
    capture(source, identity, guards) {
      const turn = ++operation;
      if (disposed || capturing) {
        counters2.refusals++;
        return null;
      }
      const resolved = facts(identity);
      if (disposed || turn !== operation || !transport) {
        counters2.refusals++;
        return null;
      }
      const selectedPort = transport;
      const entry = {
        ...resolved,
        ownerCurrent: guards.ownerCurrent,
        resource: null,
        retired: false,
        access
      };
      owned.add(entry);
      capturing = true;
      const isCaptureCurrent = () => {
        if (turn !== operation || !valid(entry)) return false;
        const accepted = guards.producerCurrent() === true;
        return turn === operation && logical(entry) && accepted;
      };
      let committed = false, primaryFailure = false;
      try {
        if (!isCaptureCurrent()) return null;
        const dimensions = selectedPort.dimensions(source);
        if (!isCaptureCurrent() || dimensions.width !== entry.width || dimensions.height !== entry.height)
          return null;
        const create = selectedPort.create;
        if (!isCaptureCurrent()) return null;
        const retire = selectedPort.retire;
        if (!isCaptureCurrent()) return null;
        const storage = create.call(selectedPort, entry.width, entry.height);
        const resource = {
          storage,
          retire: (value) => retire.call(selectedPort, value),
          bytes: entry.width * entry.height * 4
        };
        counters2.created++;
        counters2.live++;
        counters2.bytes += resource.bytes;
        counters2.peakLive = Math.max(counters2.peakLive, counters2.live);
        counters2.peakBytes = Math.max(counters2.peakBytes, counters2.bytes);
        if (entry.retired) {
          counters2.retired++;
          counters2.live--;
          counters2.bytes -= resource.bytes;
          clean([resource]);
          return null;
        }
        entry.resource = resource;
        if (!isCaptureCurrent()) return null;
        const copy = selectedPort.copy;
        if (!isCaptureCurrent()) return null;
        copy.call(selectedPort, storage, source);
        if (!isCaptureCurrent()) return null;
        const after = selectedPort.dimensions(source);
        if (!isCaptureCurrent() || after.width !== entry.width || after.height !== entry.height)
          return null;
        const previous = current;
        current = entry;
        committed = true;
        counters2.captures++;
        const retired = previous ? detach([previous]) : [];
        capturing = false;
        try {
          clean(retired);
        } catch (error) {
          try {
            release(entry);
          } catch {
          }
          throw error;
        }
        if (!checkCurrent(entry)) return null;
        return ticketFor(entry);
      } catch (error) {
        primaryFailure = true;
        throw error;
      } finally {
        capturing = false;
        if (!committed) {
          counters2.refusals++;
          try {
            release(entry);
          } catch (error) {
            if (!primaryFailure) throw error;
          }
        }
      }
    },
    invalidate() {
      operation++;
      clean(detach([...owned]));
    },
    dispose() {
      operation++;
      disposed = true;
      const retired = detach([...owned]);
      host = null;
      document2 = null;
      transport = null;
      clean(retired);
    },
    inspect: () => ({ ...counters2, disposed, capturing })
  };
}
function createNativeCanvasPort(document2) {
  return {
    devicePixelRatio: (owner) => owner.defaultView?.devicePixelRatio ?? NaN,
    dimensions(source) {
      if (source.ownerDocument !== document2) throw new Error("snapshot-producer-document-mismatch");
      return { width: source.width, height: source.height };
    },
    create(width, height) {
      const canvas = document2.createElement("canvas");
      try {
        canvas.width = width;
        canvas.height = height;
        const context = canvas.getContext("2d", {
          alpha: true,
          colorSpace: "srgb",
          willReadFrequently: true
        });
        const attributes = context?.getContextAttributes();
        if (!context || attributes?.alpha !== true || attributes.colorSpace !== "srgb")
          throw new Error("snapshot-srgb-alpha-context-unavailable");
        return { canvas, context };
      } catch (error) {
        try {
          canvas.width = 0;
        } catch {
        }
        try {
          canvas.height = 0;
        } catch {
        }
        throw error;
      }
    },
    copy({ canvas, context }, source) {
      if (context.isContextLost()) throw new Error("snapshot-context-lost");
      context.globalCompositeOperation = "copy";
      context.imageSmoothingEnabled = false;
      context.drawImage(source, 0, 0);
      if (context.isContextLost() || canvas.width !== source.width || canvas.height !== source.height)
        throw new Error("snapshot-copy-unavailable");
    },
    read({ canvas, context }, width, height) {
      if (context.isContextLost() || canvas.width !== width || canvas.height !== height)
        throw new Error("snapshot-readback-unavailable");
      return context.getImageData(0, 0, width, height).data;
    },
    retire({ canvas }) {
      let failed = false, first;
      try {
        canvas.width = 0;
      } catch (error) {
        failed = true;
        first = error;
      }
      try {
        canvas.height = 0;
      } catch (error) {
        if (!failed) {
          failed = true;
          first = error;
        }
      }
      if (failed) throw first;
    }
  };
}

// experiments/liquid-canvas-transport/protocol.mjs
var PROTOCOL = "pui-liquid-owned-canvas-transport-1";
var DPRS = Object.freeze([1, 1.5, 2]);
var GEOMETRY = Object.freeze({ width: 143.25, height: 38, radius: 19, paintOutset: 13 });
var SOURCE = Object.freeze({ width: 416, height: 172, left: 32, top: 32 });
var PIXEL_CASES = Object.freeze(
  DPRS.flatMap(
    (dpr) => ["light", "dark"].flatMap(
      (theme) => ["neutral-regular", "neutral-clear", "style-tint"].flatMap(
        (profile) => ["rest", "contact"].flatMap(
          (state) => ["before", "after"].map(
            (order) => Object.freeze({
              id: `pixels-dpr${String(dpr).replace(".", "p")}-${theme}-${profile}-${state}-${order}`,
              dpr,
              theme,
              profile,
              state,
              order
            })
          )
        )
      )
    )
  )
);
var STAGE_CASES = Object.freeze(
  ["static", "dynamic", "dynamic", "static", "static", "dynamic"].flatMap(
    (workload, block) => Array.from(
      { length: 20 },
      (_, sample) => Object.freeze({
        id: `stage-${workload}-b${block}-s${String(sample).padStart(2, "0")}`,
        workload,
        block,
        sample,
        order: sample % 2 === 0 ? "before" : "after",
        dpr: 1
      })
    )
  )
);
var LIFETIME_REQUIREMENTS = Object.freeze({
  "shared-producer-a-b-a": {
    aRetainedAfterB: true,
    bDifferent: true,
    aOldRetired: true,
    bRetainedAfterA: true
  },
  "source-supersession": { readable: false, live: 0 },
  "geometry-supersession": { readable: false, live: 0 },
  "alternating-physical-sizes": {
    sizes: 3,
    exactDimensions: true,
    oldReadable: false,
    peakLive: 2
  },
  "context-dpr-refusal-recovery": {
    actualDpr: 1,
    wrongRefused: true,
    correctAccepted: true,
    wrongAllocations: 0
  },
  "stale-owner-before-copy": { refused: true, allocations: 0 },
  "invalidate-retire": { readable: false, live: 0 },
  "dispose-no-successor": { readable: false, successorRefused: true, live: 0 },
  "detach": { detachedReadable: false, reattachedReadable: false, live: 0 },
  "adopt": { differentDocument: true, readable: false, live: 0 },
  "same-revision-producer-reentry": {
    refused: true,
    sameSourceRevision: true,
    epochAdvanced: true,
    live: 0
  },
  "failed-render-epoch": { refused: true, failedAttempt: true, epochAdvanced: true, live: 0 },
  "returned-buffer-isolation": { retainedUnchanged: true, otherConsumerUnchanged: true },
  "cancel-reference-decode": {
    readyCallbacks: 0,
    failureCallbacks: 0,
    cancellations: 1,
    pending: 0,
    decoded: 0
  },
  "allocation-dispose": { refused: true, created: 1, retired: 1, live: 0, physicalRetired: true },
  "same-owner-capture-reentry": { refused: true, innerRefused: true, peakLive: 1, live: 0 },
  "invalid-source-no-copy": {
    rejected: true,
    encoderCalls: 0,
    copyCalls: 0,
    error: "nonopaque-optical-source"
  },
  "unsafe-contrast-no-copy": {
    rejected: true,
    encoderCalls: 0,
    copyCalls: 0,
    error: "rendered-contrast-unsafe"
  },
  "source-document-refusal": {
    refused: true,
    allocations: 0,
    error: "snapshot-producer-document-mismatch"
  },
  "producer-context-loss-rejection": {
    contextLost: true,
    rejected: true,
    encoderCalls: 0,
    copyCalls: 0,
    readable: false
  }
});
var CONTROL_IDS = Object.freeze([
  "one-rgb-byte",
  "one-alpha-byte",
  "wrong-source",
  "wrong-dimensions",
  "opaque-substitute",
  "borrowed-producer"
]);
var PLAN = Object.freeze({
  protocol: PROTOCOL,
  pixels: PIXEL_CASES,
  stages: STAGE_CASES,
  lifetime: Object.keys(LIFETIME_REQUIREMENTS),
  controls: CONTROL_IDS
});

// experiments/liquid-canvas-transport/browser.mjs
var message = (error) => error instanceof Error ? error.message : String(error);
var requireFact = (value, reason) => {
  if (!value) throw new Error(reason);
};
var delta = (after, before) => Object.fromEntries(Object.keys(after).map((key) => [key, after[key] - (before[key] ?? 0)]));
var equal = (a, b) => !!a && !!b && a.length === b.length && a.every((value, index) => value === b[index]);
var nextFrame = () => new Promise((resolve) => requestAnimationFrame(resolve));
var digest = async (value) => Array.from(
  new Uint8Array(
    await crypto.subtle.digest(
      "SHA-256",
      typeof value === "string" ? new TextEncoder().encode(value) : value
    )
  ),
  (byte) => byte.toString(16).padStart(2, "0")
).join("");
var plane = (pixels, width, height) => {
  let binary = "";
  for (let at = 0; at < pixels.length; at += 8192)
    binary += String.fromCharCode(...pixels.subarray(at, at + 8192));
  return { width, height, base64: btoa(binary) };
};
var deadline = async (promise, label) => {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error(`${label}-timeout`)), 5e3);
      })
    ]);
  } finally {
    clearTimeout(timer);
  }
};
async function collectCanvasTransport(configuredDpr) {
  const report = {
    protocol: PROTOCOL,
    dpr: configuredDpr,
    environment: {
      devicePixelRatio,
      secureContext: isSecureContext,
      userAgent: navigator.userAgent,
      hardwareConcurrency: navigator.hardwareConcurrency
    },
    pixels: PIXEL_CASES.filter((item) => item.dpr === configuredDpr).map((item) => ({
      ...item,
      status: "unattempted"
    })),
    stages: configuredDpr === 1 ? STAGE_CASES.map((item) => ({ ...item, status: "unattempted" })) : [],
    lifetime: configuredDpr === 1 ? Object.keys(LIFETIME_REQUIREMENTS).map((id) => ({ id, status: "unattempted" })) : [],
    controls: configuredDpr === 1 ? CONTROL_IDS.map((id) => ({ id, status: "unattempted" })) : [],
    errors: [],
    cleanup: {}
  };
  globalThis.__puiOwnedCanvasTransportEvidence = report;
  const ownedCanvases = /* @__PURE__ */ new Set(), oracleCanvases = /* @__PURE__ */ new Set(), oracleImages = /* @__PURE__ */ new Set(), releases = /* @__PURE__ */ new Set();
  const bindings = [], sourceStates = [], sourcesByTheme = /* @__PURE__ */ new Map(), sourceOwners = /* @__PURE__ */ new WeakMap();
  const producer = document.createElement("canvas");
  const originalEncoder = producer.toDataURL;
  const originalDescriptor = Object.getOwnPropertyDescriptor(producer, "toDataURL");
  let program = null, gl = null, producerEpoch = 0, activeFrame = null, sourceDraws = 0;
  const glResources = {}, restoreGlObservers = [];
  const error = (stage, fault) => report.errors.push({ stage, message: message(fault) });
  const trackGl = (kind) => {
    const createName = `create${kind}`, deleteName = `delete${kind}`;
    const create = gl[createName], remove = gl[deleteName], live = /* @__PURE__ */ new Set();
    const row = { created: 0, retired: 0, live: 0, doubleDeletes: 0 };
    glResources[kind] = row;
    gl[createName] = function(...args) {
      const resource = create.apply(this, args);
      if (resource) {
        live.add(resource);
        row.created++;
        row.live = live.size;
      }
      return resource;
    };
    gl[deleteName] = function(resource) {
      if (resource) {
        if (live.delete(resource)) row.retired++;
        else row.doubleDeletes++;
        row.live = live.size;
      }
      return remove.call(this, resource);
    };
    restoreGlObservers.push(() => {
      gl[createName] = create;
      gl[deleteName] = remove;
    });
  };
  function sourceState(theme, name = theme) {
    const scope = document.createElement("div"), canvas = document.createElement("canvas");
    scope.dataset.experimentSource = name;
    scope.style.cssText = `position:relative;width:${SOURCE.width}px;height:${SOURCE.height}px;margin:0;padding:0;border:0`;
    canvas.style.cssText = `display:block;width:${SOURCE.width}px;height:${SOURCE.height}px;margin:0;padding:0;border:0`;
    canvas.width = Math.ceil(SOURCE.width * devicePixelRatio);
    canvas.height = Math.ceil(SOURCE.height * devicePixelRatio);
    scope.append(canvas);
    document.body.append(scope);
    const context = canvas.getContext("2d", {
      alpha: false,
      colorSpace: "srgb",
      willReadFrequently: true
    });
    requireFact(
      context && context.getContextAttributes().colorSpace === "srgb",
      "source-srgb-context-unavailable"
    );
    const state = { scope, canvas, context, revision: 0, frame: null };
    state.update = (phase) => {
      const width = canvas.width, height = canvas.height, data = new Uint8ClampedArray(width * height * 4);
      const base = theme === "light" ? 192 : 0;
      for (let y = 0; y < height; y++)
        for (let x = 0; x < width; x++) {
          const at = (y * width + x) * 4;
          data[at] = base + (Math.floor(x / devicePixelRatio) + phase) % 64;
          data[at + 1] = base + (Math.floor(y / devicePixelRatio) + 3 * phase) % 64;
          data[at + 2] = base + (Math.floor((x + y) / devicePixelRatio) + 5 * phase) % 64;
          data[at + 3] = 255;
        }
      context.putImageData(new ImageData(data, width, height, { colorSpace: "srgb" }), 0, 0);
      const actual = context.getImageData(0, 0, width, height).data;
      requireFact(equal(actual, data), "source-native-readback-differs");
      state.frame = Object.freeze({
        revision: ++state.revision,
        width,
        height,
        pixels: new Uint8Array(actual),
        canvas,
        scope
      });
      sourceOwners.set(state.frame, state);
      sourceDraws++;
      return state.frame;
    };
    state.update(0);
    sourceStates.push(state);
    return state;
  }
  function binding(name) {
    const target = document.createElement("div");
    target.dataset.experimentOwner = name;
    document.body.append(target);
    const native = createNativeCanvasPort(document);
    const state = {
      target,
      live: true,
      frame: null,
      geometryRevision: 0,
      lastStorage: null,
      lastDraw: null,
      native,
      port: null,
      owner: null
    };
    state.port = {
      ...native,
      create(width, height) {
        const resource = native.create(width, height);
        ownedCanvases.add(resource.canvas);
        state.lastStorage = resource;
        return resource;
      },
      copy(storage, source) {
        const started = performance.now();
        native.copy(storage, source);
        state.lastDraw = { started, finished: performance.now() };
      },
      retire(resource) {
        try {
          native.retire(resource);
        } finally {
          if (resource.canvas.width === 0 && resource.canvas.height === 0)
            ownedCanvases.delete(resource.canvas);
        }
      }
    };
    state.owner = createCanvasSnapshotOwner(target, state.port);
    bindings.push(state);
    return state;
  }
  function frameFor(owner, source, item = {}, size = GEOMETRY) {
    source.scope.append(owner.target);
    owner.target.style.cssText = `position:absolute;box-sizing:border-box;left:${SOURCE.left}px;top:${SOURCE.top}px;width:${size.width}px;height:${size.height}px;border:0;padding:0;margin:0;border-radius:${size.radius}px`;
    const box = owner.target.getBoundingClientRect(), sourceBox = source.canvas.getBoundingClientRect();
    const geometry = Object.freeze({
      width: box.width,
      height: box.height,
      radius: size.radius,
      paintOutset: size.paintOutset,
      dpr: devicePixelRatio,
      bounds: [
        (box.left - sourceBox.left) / sourceBox.width,
        (box.top - sourceBox.top) / sourceBox.height,
        box.width / sourceBox.width,
        box.height / sourceBox.height
      ]
    });
    const dark = item.theme === "dark", contact = item.state === "contact";
    const frame = Object.freeze({
      source,
      geometry,
      pressed: contact,
      ...contact ? { contact: { x: 0.5, y: 0.5, deltaX: 0.04, deltaY: -0.03, strength: 1 } } : {},
      variant: item.profile === "neutral-clear" ? "clear" : "regular",
      ...item.profile === "style-tint" ? { tint: "style-fill" } : {},
      fill: dark ? [0.08, 0.14, 0.2, 1] : [0.9, 0.8, 0.6, 1],
      foreground: dark ? [1, 1, 1, 1] : [0, 0, 0, 1]
    });
    owner.frame = frame;
    owner.geometryRevision++;
    return frame;
  }
  function render(frame, owner = null, order = "before") {
    const epoch = ++producerEpoch;
    activeFrame = frame;
    const geometryRevision = owner?.geometryRevision;
    const source = frame.source, geometry = frame.geometry;
    const identity = Object.freeze({
      sourceRevision: source.revision,
      geometryRevision: geometryRevision ?? 0,
      producerEpoch: epoch,
      logicalWidth: geometry.width,
      logicalHeight: geometry.height,
      paintOutset: geometry.paintOutset ?? 0,
      dpr: geometry.dpr
    });
    const guards = {
      ownerCurrent: () => {
        if (owner?.live !== true || owner.frame !== frame || owner.geometryRevision !== geometryRevision || sourceOwners.get(source)?.frame !== source || source.canvas.ownerDocument !== document || source.canvas.parentElement !== source.scope || !source.canvas.isConnected || source.canvas.width !== source.width || source.canvas.height !== source.height)
          return false;
        const box = owner.target.getBoundingClientRect(), sourceBox = source.canvas.getBoundingClientRect();
        return box.width === geometry.width && box.height === geometry.height && (box.left - sourceBox.left) / sourceBox.width === geometry.bounds[0] && (box.top - sourceBox.top) / sourceBox.height === geometry.bounds[1] && box.width / sourceBox.width === geometry.bounds[2] && box.height / sourceBox.height === geometry.bounds[3];
      },
      producerCurrent: () => producerEpoch === epoch && activeFrame === frame
    };
    const row = {
      encoderCalls: 0,
      copyCalls: 0,
      encoderArguments: null,
      encoderReturnMatchesProgram: false,
      timestamps: {},
      identity,
      geometry,
      targetRect: owner ? {
        width: owner.target.getBoundingClientRect().width,
        height: owner.target.getBoundingClientRect().height
      } : null
    };
    const descriptor = Object.getOwnPropertyDescriptor(producer, "toDataURL");
    let encoded, png, ticket = null, candidatePixels = null, copyError = null;
    const beforeProgram = program.inspect();
    const copy = () => {
      if (!owner) return;
      row.copyCalls++;
      row.timestamps.copyStart = performance.now();
      try {
        ticket = owner.owner.capture(producer, identity, guards);
        row.timestamps.copySubmitted = performance.now();
        if (ticket) candidatePixels = ticket.readPixels();
        row.timestamps.copyReadbackEnd = performance.now();
        row.nativeDraw = owner.lastDraw;
      } catch (fault) {
        copyError = message(fault);
        row.timestamps.copyReadbackEnd = performance.now();
      }
    };
    Object.defineProperty(producer, "toDataURL", {
      configurable: true,
      writable: true,
      value(...args) {
        if (order === "before") copy();
        row.encoderCalls++;
        row.encoderArguments = args.slice();
        row.timestamps.encodeStart = performance.now();
        try {
          encoded = originalEncoder.apply(producer, args);
        } finally {
          row.timestamps.encodeEnd = performance.now();
        }
        if (order === "after") copy();
        return encoded;
      }
    });
    row.timestamps.renderStart = performance.now();
    try {
      png = program.render(frame);
    } catch (fault) {
      row.renderError = message(fault);
    } finally {
      row.timestamps.renderEnd = performance.now();
      if (descriptor) Object.defineProperty(producer, "toDataURL", descriptor);
      else delete producer.toDataURL;
    }
    row.programCounters = delta(program.inspect(), beforeProgram);
    row.width = producer.width;
    row.height = producer.height;
    row.encoderReturnMatchesProgram = typeof png === "string" && png === encoded;
    if (copyError) row.copyError = copyError;
    if (owner?.lastStorage) row.copyContext = owner.lastStorage.context.getContextAttributes();
    return { ...row, png, ticket, candidatePixels, storage: owner?.lastStorage ?? null };
  }
  function oracleCanvas(width, height) {
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    oracleCanvases.add(canvas);
    const context = canvas.getContext("2d", {
      alpha: true,
      colorSpace: "srgb",
      willReadFrequently: true
    });
    requireFact(
      context?.getContextAttributes().alpha === true && context.getContextAttributes().colorSpace === "srgb",
      "oracle-srgb-alpha-unavailable"
    );
    return { canvas, context };
  }
  function retireOracle(canvas) {
    canvas.width = 0;
    canvas.height = 0;
    oracleCanvases.delete(canvas);
  }
  function oracleRead(source, width, height, background = null) {
    const { canvas, context } = oracleCanvas(width, height);
    try {
      if (background) {
        context.fillStyle = background;
        context.fillRect(0, 0, width, height);
      }
      context.globalCompositeOperation = "source-over";
      context.imageSmoothingEnabled = false;
      context.drawImage(source, 0, 0);
      requireFact(!context.isContextLost(), "oracle-context-lost");
      return {
        pixels: new Uint8ClampedArray(context.getImageData(0, 0, width, height).data),
        attributes: context.getContextAttributes()
      };
    } finally {
      retireOracle(canvas);
    }
  }
  async function observedPixels(result, composites) {
    requireFact(!result.renderError && !result.copyError, result.renderError ?? result.copyError);
    requireFact(
      result.ticket && result.candidatePixels && result.png?.startsWith("data:image/png;base64,"),
      "same-render-snapshot-unavailable"
    );
    const beforeImages = inspectOpticalImageResources(document), timestamps = result.timestamps;
    let release, oracle;
    try {
      timestamps.decodeStart = performance.now();
      const ready = new Promise((resolve, reject) => {
        release = prepareOpticalImage(
          document,
          result.png,
          () => {
            timestamps.decodeReady = timestamps.callbackStart = performance.now();
            resolve();
            timestamps.callbackEnd = performance.now();
          },
          () => reject(new Error("production-image-decode-failed"))
        );
        releases.add(release);
      });
      await deadline(ready, "production-image-decode");
      const afterImages = inspectOpticalImageResources(document);
      oracle = new Image();
      oracleImages.add(oracle);
      const oracleStarted = performance.now();
      oracle.src = result.png;
      await deadline(oracle.decode(), "independent-png-decode");
      const oracleDecodeMs = performance.now() - oracleStarted;
      requireFact(
        oracle.complete && oracle.naturalWidth === result.width && oracle.naturalHeight === result.height,
        "independent-png-dimensions"
      );
      const reference = oracleRead(oracle, result.width, result.height);
      const planes = {
        candidateRaw: plane(result.candidatePixels, result.width, result.height),
        referenceRaw: plane(reference.pixels, result.width, result.height)
      };
      if (composites) {
        for (const [name, color] of [
          ["Black", "#000000"],
          ["White", "#ffffff"]
        ]) {
          planes[`candidate${name}`] = plane(
            oracleRead(result.storage.canvas, result.width, result.height, color).pixels,
            result.width,
            result.height
          );
          planes[`reference${name}`] = plane(
            oracleRead(oracle, result.width, result.height, color).pixels,
            result.width,
            result.height
          );
        }
      }
      const { png, ticket, candidatePixels, storage, ...serializable } = result;
      return {
        ...serializable,
        sourceRevision: result.identity.sourceRevision,
        planes,
        pngSha256: await digest(result.png),
        png: result.png,
        oracleContext: reference.attributes,
        oracleDecodeMs,
        imageCounters: delta(afterImages, beforeImages),
        referencePixels: reference.pixels
      };
    } finally {
      if (oracle) {
        oracle.src = "";
        oracleImages.delete(oracle);
      }
      if (release) {
        release();
        releases.delete(release);
      }
    }
  }
  async function collectRow(row, owner, source, item, composites) {
    let result;
    try {
      row.status = "failed";
      const frame = frameFor(owner, source, item);
      result = render(frame, owner, row.order);
      const data = await observedPixels(result, composites);
      const reference = data.referencePixels;
      delete data.referencePixels;
      Object.assign(row, data, { status: "ok" });
      return {
        reference,
        candidate: result.candidatePixels.slice(),
        png: result.png,
        width: result.width,
        height: result.height
      };
    } catch (fault) {
      if (result) {
        const { png, ticket, candidatePixels, storage, ...partial } = result;
        Object.assign(row, partial);
        if (png) {
          row.png = png;
          row.pngSha256 = await digest(png);
        }
      }
      row.status = "failed";
      row.error = message(fault);
      return null;
    } finally {
      result?.ticket?.release();
    }
  }
  const lifetime = async (id, operation) => {
    const row = report.lifetime.find((row2) => row2.id === id);
    row.status = "failed";
    try {
      row.actual = await operation(row);
      row.status = "ok";
    } catch (fault) {
      row.error = message(fault);
    }
  };
  const take = (owner, source, item, size) => {
    const result = render(frameFor(owner, source, item, size), owner);
    requireFact(
      !result.renderError && !result.copyError && result.ticket && result.candidatePixels,
      result.renderError ?? result.copyError ?? "lifetime-copy-unavailable"
    );
    return result;
  };
  let lightReference = null, darkReference = null, borrowedControl = null;
  try {
    requireFact(
      configuredDpr === devicePixelRatio && isSecureContext,
      "native-context-does-not-match-request"
    );
    gl = producer.getContext("webgl", {
      alpha: true,
      premultipliedAlpha: true,
      preserveDrawingBuffer: true,
      antialias: false
    });
    requireFact(gl && !gl.isContextLost(), "real-webgl-unavailable");
    report.environment.webglAttributes = gl.getContextAttributes();
    const debug = gl.getExtension("WEBGL_debug_renderer_info");
    report.environment.webglRenderer = gl.getParameter(
      debug?.UNMASKED_RENDERER_WEBGL ?? gl.RENDERER
    );
    report.environment.webglVendor = gl.getParameter(debug?.UNMASKED_VENDOR_WEBGL ?? gl.VENDOR);
    for (const kind of ["Buffer", "Framebuffer", "Program", "Shader", "Texture"]) trackGl(kind);
    program = createWebOpticalProgram(producer);
    for (const theme of ["light", "dark"]) sourcesByTheme.set(theme, sourceState(theme));
    const main = binding("pixel-and-stage-owner");
    for (const row of report.pixels) {
      const result = await collectRow(row, main, sourcesByTheme.get(row.theme).frame, row, true);
      if (row.profile === "neutral-regular" && row.state === "rest" && row.order === "before") {
        if (row.theme === "light") lightReference = result;
        else darkReference = result;
      }
    }
    if (configuredDpr === 1) {
      const dynamic = sourceState("light", "dynamic-source");
      let phase = 0;
      for (const row of report.stages) {
        const source = row.workload === "dynamic" ? dynamic.update(++phase) : sourcesByTheme.get("light").frame;
        await collectRow(
          row,
          main,
          source,
          { theme: "light", profile: "neutral-regular", state: "contact" },
          false
        );
      }
      const light = () => sourcesByTheme.get("light").frame, dark = () => sourcesByTheme.get("dark").frame;
      await lifetime("shared-producer-a-b-a", (row) => {
        const a = binding("consumer-a"), b = binding("consumer-b");
        const first = take(a, light()), savedA = first.candidatePixels.slice();
        const second = take(b, dark(), { theme: "dark" }), savedB = second.candidatePixels.slice();
        const borrowed = oracleRead(producer, second.width, second.height).pixels;
        borrowedControl = {
          candidate: plane(borrowed, second.width, second.height),
          reference: plane(savedA, first.width, first.height)
        };
        const afterB = first.ticket.readPixels();
        const aRetainedAfterB = equal(afterB, savedA), bDifferent = !equal(savedA, savedB);
        take(a, light(), { state: "contact" });
        const afterA = second.ticket.readPixels();
        row.planes = {
          aOriginal: plane(savedA, first.width, first.height),
          aAfter: plane(afterB, first.width, first.height),
          bOriginal: plane(savedB, second.width, second.height),
          bAfter: plane(afterA, second.width, second.height)
        };
        const actual = {
          aRetainedAfterB,
          bDifferent,
          aOldRetired: first.ticket.readPixels() === null,
          bRetainedAfterA: equal(afterA, savedB)
        };
        a.owner.dispose();
        b.owner.dispose();
        return actual;
      });
      for (const kind of ["source", "geometry"])
        await lifetime(`${kind}-supersession`, () => {
          const a = binding(`${kind}-supersession`), source = sourceState("light", `${kind}-supersession`), result = take(a, source.frame);
          if (kind === "source") source.update(1);
          else a.target.style.width = `${GEOMETRY.width + 1}px`;
          const actual = {
            readable: result.ticket.readPixels() !== null,
            live: a.owner.inspect().live
          };
          a.owner.dispose();
          return actual;
        });
      await lifetime("alternating-physical-sizes", () => {
        const a = binding("size-changes"), tickets = [];
        let exactDimensions = true;
        for (const size of [
          GEOMETRY,
          { width: 93.5, height: 26.25, radius: 10, paintOutset: 9 },
          GEOMETRY
        ]) {
          const result = take(a, light(), {}, size);
          tickets.push(result.ticket);
          exactDimensions &&= result.ticket.width === Math.ceil((result.geometry.width + 2 * size.paintOutset) * devicePixelRatio) && result.ticket.height === Math.ceil((result.geometry.height + 2 * size.paintOutset) * devicePixelRatio);
        }
        const actual = {
          sizes: tickets.length,
          exactDimensions,
          oldReadable: tickets.slice(0, -1).some((ticket) => ticket.readPixels() !== null),
          peakLive: a.owner.inspect().peakLive
        };
        a.owner.dispose();
        return actual;
      });
      await lifetime("context-dpr-refusal-recovery", () => {
        const a = binding("dpr-binding"), frame = frameFor(a, light());
        render(frame);
        const epoch = producerEpoch;
        const identity = {
          sourceRevision: frame.source.revision,
          geometryRevision: a.geometryRevision,
          producerEpoch: epoch,
          logicalWidth: producer.width / 2,
          logicalHeight: producer.height / 2,
          paintOutset: 0,
          dpr: 2
        };
        const wrong = a.owner.capture(producer, identity, {
          ownerCurrent: () => true,
          producerCurrent: () => producerEpoch === epoch
        });
        const wrongAllocations = a.owner.inspect().created;
        const correct = take(a, light());
        const actual = {
          actualDpr: devicePixelRatio,
          wrongRefused: wrong === null,
          correctAccepted: !!correct.ticket,
          wrongAllocations
        };
        a.owner.dispose();
        return actual;
      });
      await lifetime("stale-owner-before-copy", () => {
        const a = binding("stale-owner");
        a.live = false;
        const result = render(frameFor(a, light()), a);
        const actual = { refused: result.ticket === null, allocations: a.owner.inspect().created };
        a.owner.dispose();
        return actual;
      });
      await lifetime("invalidate-retire", () => {
        const a = binding("invalidate"), result = take(a, light());
        a.owner.invalidate();
        const actual = {
          readable: result.ticket.readPixels() !== null,
          live: a.owner.inspect().live
        };
        a.owner.dispose();
        return actual;
      });
      await lifetime("dispose-no-successor", () => {
        const a = binding("terminal-dispose"), result = take(a, light());
        a.owner.dispose();
        const successor = render(frameFor(a, light()), a);
        return {
          readable: result.ticket.readPixels() !== null,
          successorRefused: successor.ticket === null,
          live: a.owner.inspect().live
        };
      });
      await lifetime("detach", () => {
        const a = binding("detach"), result = take(a, light());
        a.target.remove();
        const detachedReadable = result.ticket.readPixels() !== null;
        document.body.append(a.target);
        const actual = {
          detachedReadable,
          reattachedReadable: result.ticket.readPixels() !== null,
          live: a.owner.inspect().live
        };
        a.owner.dispose();
        return actual;
      });
      await lifetime("adopt", () => {
        const a = binding("adopt"), result = take(a, light()), other = document.implementation.createHTMLDocument("owned adoption control");
        other.adoptNode(a.target);
        other.body.append(a.target);
        const actual = {
          differentDocument: a.target.ownerDocument !== document,
          readable: result.ticket.readPixels() !== null,
          live: a.owner.inspect().live
        };
        a.target.remove();
        a.owner.dispose();
        return actual;
      });
      await lifetime("same-revision-producer-reentry", () => {
        const a = binding("producer-reentry-a"), b = binding("producer-reentry-b");
        const frameA = frameFor(a, light()), frameB = frameFor(b, dark(), { theme: "dark" });
        const copy = a.port.copy;
        let epochBefore, epochAfter;
        a.port.copy = (storage, source) => {
          epochBefore = producerEpoch;
          const nested = render(frameB);
          requireFact(!nested.renderError, nested.renderError);
          epochAfter = producerEpoch;
          copy(storage, source);
        };
        const result = render(frameA, a);
        const actual = {
          refused: result.ticket === null,
          sameSourceRevision: frameA.source.revision === frameB.source.revision,
          epochAdvanced: epochAfter > epochBefore,
          live: a.owner.inspect().live
        };
        a.owner.dispose();
        b.owner.dispose();
        return actual;
      });
      await lifetime("failed-render-epoch", () => {
        const a = binding("failed-attempt"), frame = frameFor(a, light());
        const invalidPixels = frame.source.pixels.slice();
        invalidPixels[3] = 0;
        const invalid = { ...frame, source: { ...frame.source, pixels: invalidPixels } }, copy = a.port.copy;
        let failedAttempt = false, epochBefore, epochAfter;
        a.port.copy = (storage, source) => {
          epochBefore = producerEpoch;
          failedAttempt = render(invalid).renderError === "nonopaque-optical-source";
          epochAfter = producerEpoch;
          copy(storage, source);
        };
        const result = render(frame, a);
        const actual = {
          refused: result.ticket === null,
          failedAttempt,
          epochAdvanced: epochAfter > epochBefore,
          live: a.owner.inspect().live
        };
        a.owner.dispose();
        return actual;
      });
      await lifetime("returned-buffer-isolation", (row) => {
        const a = binding("returned-a"), b = binding("returned-b"), first = take(a, light()), second = take(b, dark(), { theme: "dark" });
        const beforeA = first.ticket.readPixels(), beforeB = second.ticket.readPixels();
        const escaped = first.ticket.readPixels();
        escaped.fill(37);
        const afterA = first.ticket.readPixels(), afterB = second.ticket.readPixels();
        row.planes = {
          aOriginal: plane(beforeA, first.width, first.height),
          aAfter: plane(afterA, first.width, first.height),
          bOriginal: plane(beforeB, second.width, second.height),
          bAfter: plane(afterB, second.width, second.height)
        };
        const actual = {
          retainedUnchanged: equal(afterA, beforeA),
          otherConsumerUnchanged: equal(afterB, beforeB)
        };
        a.owner.dispose();
        b.owner.dispose();
        return actual;
      });
      await lifetime("cancel-reference-decode", async () => {
        requireFact(lightReference?.png, "cancellation-reference-unavailable");
        const before = inspectOpticalImageResources(document);
        let readyCallbacks = 0, failureCallbacks = 0;
        const release = prepareOpticalImage(
          document,
          lightReference.png,
          () => readyCallbacks++,
          () => failureCallbacks++
        );
        release();
        await nextFrame();
        await nextFrame();
        const after = inspectOpticalImageResources(document), change = delta(after, before);
        return {
          readyCallbacks,
          failureCallbacks,
          cancellations: change.imageDecodeCancellations,
          pending: after.pendingImages,
          decoded: after.decodedImages
        };
      });
      await lifetime("allocation-dispose", () => {
        const a = binding("allocation-dispose"), create = a.port.create;
        a.port.create = (...args) => {
          const resource = create(...args);
          a.owner.dispose();
          return resource;
        };
        const result = render(frameFor(a, light()), a), counters2 = a.owner.inspect();
        return {
          refused: result.ticket === null,
          created: counters2.created,
          retired: counters2.retired,
          live: counters2.live,
          physicalRetired: a.lastStorage.canvas.width === 0 && a.lastStorage.canvas.height === 0
        };
      });
      await lifetime("same-owner-capture-reentry", () => {
        const a = binding("same-owner-reentry"), create = a.port.create;
        let inner = "not-attempted";
        a.port.create = (...args) => {
          inner = a.owner.capture(
            producer,
            {
              sourceRevision: a.frame.source.revision,
              geometryRevision: a.geometryRevision,
              producerEpoch,
              logicalWidth: a.frame.geometry.width,
              logicalHeight: a.frame.geometry.height,
              paintOutset: a.frame.geometry.paintOutset,
              dpr: devicePixelRatio
            },
            { ownerCurrent: () => true, producerCurrent: () => true }
          );
          return create(...args);
        };
        const result = render(frameFor(a, light()), a), counters2 = a.owner.inspect();
        const actual = {
          refused: result.ticket === null,
          innerRefused: inner === null,
          peakLive: counters2.peakLive,
          live: counters2.live
        };
        a.owner.dispose();
        return actual;
      });
      for (const [id, invalidFrame] of [
        [
          "invalid-source-no-copy",
          (frame) => {
            const pixels = frame.source.pixels.slice();
            pixels[3] = 0;
            return { ...frame, source: { ...frame.source, pixels } };
          }
        ],
        ["unsafe-contrast-no-copy", (frame) => ({ ...frame, foreground: [0.5, 0.5, 0.5, 1] })]
      ])
        await lifetime(id, () => {
          const a = binding(id), frame = invalidFrame(frameFor(a, light())), result = render(frame, a);
          const actual = {
            rejected: !!result.renderError,
            encoderCalls: result.encoderCalls,
            copyCalls: result.copyCalls,
            error: result.renderError ?? null
          };
          a.owner.dispose();
          return actual;
        });
      await lifetime("source-document-refusal", () => {
        const a = binding("foreign-producer"), frame = frameFor(a, light());
        render(frame);
        const other = document.implementation.createHTMLDocument("foreign producer");
        const canvas = other.createElement("canvas");
        canvas.width = producer.width;
        canvas.height = producer.height;
        let ticket = null, fault = null;
        try {
          ticket = a.owner.capture(
            canvas,
            {
              sourceRevision: 1,
              geometryRevision: 1,
              producerEpoch,
              logicalWidth: frame.geometry.width,
              logicalHeight: frame.geometry.height,
              paintOutset: frame.geometry.paintOutset,
              dpr: devicePixelRatio
            },
            { ownerCurrent: () => true, producerCurrent: () => true }
          );
        } catch (caught) {
          fault = message(caught);
        }
        const actual = {
          refused: ticket === null,
          allocations: a.owner.inspect().created,
          error: fault
        };
        canvas.width = 0;
        canvas.height = 0;
        a.owner.dispose();
        return actual;
      });
      for (const row of report.controls) {
        row.status = "failed";
        try {
          requireFact(lightReference && darkReference, "native-control-reference-unavailable");
          const { reference, width, height } = lightReference;
          const changed = reference.slice();
          let dimensions = { width, height };
          if (row.id === "one-rgb-byte") {
            let at = 0;
            while (changed[at + 3] !== 255 && at + 4 < changed.length) at += 4;
            changed[at] = changed[at] === 255 ? 254 : changed[at] + 1;
          } else if (row.id === "one-alpha-byte") {
            let at = 3;
            while (!(changed[at] > 0 && changed[at] < 255) && at + 4 < changed.length) at += 4;
            changed[at] = changed[at] === 255 ? 254 : changed[at] + 1;
          } else if (row.id === "wrong-source") changed.set(darkReference.reference);
          else if (row.id === "wrong-dimensions") dimensions = { width: height, height: width };
          else if (row.id === "opaque-substitute")
            for (let at = 3; at < changed.length; at += 4) changed[at] = 255;
          if (row.id === "borrowed-producer") {
            requireFact(borrowedControl, "borrowed-producer-control-unavailable");
            row.planes = borrowedControl;
          } else
            row.planes = {
              candidate: plane(changed, dimensions.width, dimensions.height),
              reference: plane(reference, width, height)
            };
          row.status = "ok";
        } catch (fault) {
          row.error = message(fault);
        }
      }
      await lifetime("producer-context-loss-rejection", async () => {
        const a = binding("lost-producer"), result = take(a, light()), extension = gl.getExtension("WEBGL_lose_context");
        requireFact(extension, "native-context-loss-extension-unavailable");
        const lost = new Promise(
          (resolve) => producer.addEventListener("webglcontextlost", resolve, { once: true })
        );
        extension.loseContext();
        await deadline(lost, "native-context-loss");
        a.live = false;
        const next = render(a.frame, a);
        const actual = {
          contextLost: gl.isContextLost(),
          rejected: !!next.renderError,
          encoderCalls: next.encoderCalls,
          copyCalls: next.copyCalls,
          readable: result.ticket.readPixels() !== null
        };
        a.owner.dispose();
        return actual;
      });
    }
  } catch (fault) {
    error("collection", fault);
  } finally {
    report.programBeforeDispose = program?.inspect() ?? null;
    report.sourceDraws = sourceDraws;
    for (const release of releases) {
      try {
        release();
      } catch (fault) {
        error("production-image-retire", fault);
      }
    }
    releases.clear();
    for (const state of bindings) {
      try {
        state.owner.dispose();
      } catch (fault) {
        error("snapshot-owner-retire", fault);
      }
      state.target.remove();
    }
    for (const image of oracleImages) {
      try {
        image.src = "";
      } catch (fault) {
        error("oracle-image-retire", fault);
      }
    }
    oracleImages.clear();
    for (const canvas of [...oracleCanvases]) {
      try {
        retireOracle(canvas);
      } catch (fault) {
        error("oracle-canvas-retire", fault);
      }
    }
    try {
      program?.dispose();
    } catch (fault) {
      error("program-retire", fault);
    }
    producer.width = 0;
    producer.height = 0;
    for (const state of sourceStates) {
      state.canvas.width = 0;
      state.canvas.height = 0;
      state.scope.remove();
    }
    const cleanup = () => {
      const ownerCounters = bindings.map((state) => state.owner.inspect()), images = inspectOpticalImageResources(document), resources = Object.values(glResources), metrics = program?.inspect();
      return {
        ownersLive: ownerCounters.reduce((sum, row) => sum + row.live, 0),
        ownersBytes: ownerCounters.reduce((sum, row) => sum + row.bytes, 0),
        ownerCleanupFailures: ownerCounters.reduce((sum, row) => sum + row.cleanupFailures, 0),
        ownedPhysicalCanvases: ownedCanvases.size,
        oracleCanvases: oracleCanvases.size,
        oracleImages: oracleImages.size,
        sourceCanvases: sourceStates.filter(
          (state) => state.canvas.width !== 0 || state.canvas.height !== 0
        ).length,
        pendingImages: images.pendingImages,
        decodedImages: images.decodedImages,
        imageCounters: images,
        producerWidth: producer.width,
        producerHeight: producer.height,
        glLive: resources.reduce((sum, row) => sum + row.live, 0),
        glDoubleDeletes: resources.reduce((sum, row) => sum + row.doubleDeletes, 0),
        glResources,
        preparedEntries: metrics?.sourcePreparationCacheEntries ?? 0,
        preparedBytes: metrics?.sourcePreparationCacheBytes ?? 0,
        encoderRestored: producer.toDataURL === originalEncoder && Object.getOwnPropertyDescriptor(producer, "toDataURL") === originalDescriptor,
        ownerCounters
      };
    };
    report.cleanup.immediate = cleanup();
    try {
      report.cleanup.rafTimestamps = [
        await deadline(nextFrame(), "cleanup-first-raf"),
        await deadline(nextFrame(), "cleanup-second-raf")
      ];
    } catch (fault) {
      error("cleanup-frames", fault);
    }
    report.cleanup.afterTwoRaf = cleanup();
    for (const restore of restoreGlObservers) restore();
  }
  return report;
}
export {
  collectCanvasTransport
};
/*!
MIT License

Copyright (c) NaughtyDuk

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

---

Exclusion of Assets

The MIT License above applies only to the source code of this project (the
contents of the `scripts/` and `package/` directories). It does NOT apply to
the contents of the `assets/` directory (including but not limited to the
audio files under `assets/audio/` and `assets/fonts/`), which are provided
for demonstration purposes only and may not be copied, redistributed, or
reused outside of this repository without separate permission from their
respective rights holders.

---

Support Open Source

If this project has been useful to you, please consider supporting its
continued open-source development at https://liquidgl.naughtyduk.com

*/
