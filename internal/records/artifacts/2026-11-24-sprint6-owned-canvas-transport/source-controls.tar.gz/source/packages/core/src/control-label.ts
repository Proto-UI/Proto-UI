import type { AnatomyFamily } from './anatomy';
import type { PropsBaseType } from '@proto.ui/types';
import type { RunHandle } from './handles';

declare const controlLabelBrand: unique symbol;
export type ControlLabelRef = Readonly<{ [controlLabelBrand]: true }>;
type ControlLabelReferenceAuthority = Readonly<{
  version: 1;
  create(): object;
  is(value: unknown): boolean;
}>;

/**
 * Compatible independently bundled implementations share nominal admission.
 * Operations never expose the WeakSet or admit an arbitrary caller object.
 * This interoperability ABI is not a security boundary.
 */
function referenceAuthority(): ControlLabelReferenceAuthority {
  const key = Symbol.for('@proto.ui/control-label/ref/v1');
  const descriptor = Object.getOwnPropertyDescriptor(globalThis, key);
  if (descriptor) {
    const service = descriptor.value as ControlLabelReferenceAuthority | undefined;
    if (
      descriptor.get ||
      descriptor.set ||
      descriptor.configurable ||
      descriptor.writable ||
      !service ||
      !Object.isFrozen(service) ||
      service.version !== 1 ||
      typeof service.create !== 'function' ||
      typeof service.is !== 'function'
    )
      throw new TypeError('[ControlLabel] incompatible same-realm reference ABI; expected v1');
    return service;
  }
  const references = new WeakSet<object>();
  const service: ControlLabelReferenceAuthority = Object.freeze({
    version: 1 as const,
    create() {
      const ref = Object.freeze({
        toJSON(): never {
          throw new TypeError(
            '[ControlLabel] opaque references cannot be serialized; use an explicit renderer association key'
          );
        },
      });
      references.add(ref);
      return ref;
    },
    is(value: unknown) {
      return typeof value === 'object' && value !== null && references.has(value);
    },
  });
  Object.defineProperty(globalThis, key, { value: service });
  return service;
}

/** Explicit pair identity, never a host ID, lookup key or serializable value. */
export function createControlLabelRef(): ControlLabelRef {
  return referenceAuthority().create() as ControlLabelRef;
}

export function isControlLabelRef(value: unknown): value is ControlLabelRef {
  return referenceAuthority().is(value);
}

export type ControlLabelOptions = Readonly<{ naming: boolean; activation: boolean }>;
/**
 * Explicit subject-local content-selection policy for an associated label.
 *
 * - 'policy' derives the declaration from the label's role: a short actionable
 *   label suppresses accidental selection while a passive naming-only label
 *   keeps the host default (C-CONTROL-LABEL-0001-CONTENT).
 * - 'auto' delegates to the host default at the label subject; under a
 *   suppressing ancestor that is not necessarily selectable.
 * - 'text' explicitly restores text selection on the label subject.
 * - 'none' suppresses accidental text selection starting on the label subject.
 *
 * The policy never owns a selection range, editing command, clipboard
 * behavior, control state or focus; it lowers only to the bounded
 * select-auto/select-text/select-none affordance tokens of
 * C-CONTENT-SELECTION-AFFORDANCE-0001.
 */
export type ControlLabelSelectionPolicy = 'policy' | 'auto' | 'text' | 'none';
export const CONTROL_LABEL_SELECTION_POLICIES: readonly ControlLabelSelectionPolicy[] = [
  'policy',
  'auto',
  'text',
  'none',
];
export type ControlLabelActivationSource = 'pointer' | 'accessibility';
export type ControlLabelRequest = Readonly<{
  source: ControlLabelActivationSource;
  isCurrent(): boolean;
}>;
export type ControlLabelHandle = {
  sync(options: ControlLabelOptions): void;
};
/** Setup-only semantic anatomy tuple, never JSON Props or a caller-supplied host identity. */
export type ControlLabelAnatomyPair = Readonly<{
  family: AnatomyFamily;
  labelRole: string;
  targetRole: string;
}>;
export type ControlLabelFacade = {
  label(pair?: ControlLabelAnatomyPair): ControlLabelHandle;
  target<P extends PropsBaseType>(
    activate: (run: RunHandle<P>, request: ControlLabelRequest) => void,
    pair?: ControlLabelAnatomyPair
  ): ControlLabelHandle;
};

/** Dedicated instance-association input; never part of portable JSON Props. */
export type InstanceAssociations = Readonly<{ controlLabel?: ControlLabelRef | null }>;
export function validateInstanceAssociations(input: unknown): InstanceAssociations {
  // Even omitted input needs an own empty value in its normalized snapshot;
  // an empty ordinary object could otherwise expose an inherited association.
  if (input === undefined) return Object.freeze({ controlLabel: null });
  if (
    !input ||
    typeof input !== 'object' ||
    Object.getPrototypeOf(input) !== Object.prototype ||
    Object.getOwnPropertySymbols(input).length
  ) {
    throw new TypeError('[InstanceAssociations] expected the explicit typed association input');
  }
  for (const key of Object.getOwnPropertyNames(input)) {
    if (key !== 'controlLabel')
      throw new TypeError(`[InstanceAssociations] unsupported association: ${key}`);
  }
  const ref = Object.prototype.hasOwnProperty.call(input, 'controlLabel')
    ? (input as InstanceAssociations).controlLabel
    : null;
  if (ref != null && !isControlLabelRef(ref))
    throw new TypeError(
      '[InstanceAssociations] controlLabel requires a public opaque reference; attribute/static JSON values have no lowering'
    );
  return Object.freeze({ controlLabel: ref ?? null });
}
