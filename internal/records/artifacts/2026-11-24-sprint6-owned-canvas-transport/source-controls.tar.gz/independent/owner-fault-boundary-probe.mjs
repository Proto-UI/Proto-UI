import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
const sourcePath = process.argv[2];
const { createCanvasSnapshotOwner, createNativeCanvasPort } = await import(pathToFileURL(sourcePath));

// The native port is exercised with a controlled constructor fault; this is
// lifetime evidence, not a real Canvas2D pixel or browser result.
let width = 300, height = 150, fault = true;
const writes = [];
const canvas = {
  get width() { return width; },
  set width(value) { writes.push(['width', value]); width = value; },
  get height() { return height; },
  set height(value) {
    writes.push(['height', value]);
    if (fault) { fault = false; throw new Error('controlled-height-constructor-fault'); }
    height = value;
  },
};
const nativePort = createNativeCanvasPort({ createElement: () => canvas });
let constructionError = null;
try { nativePort.create(2, 1); } catch (error) { constructionError = String(error); }
const constructorFailure = {
  constructionError, writes, width, height,
  expected: 'Attempt zero-size retirement after any constructor-stage width/height/context failure.',
  failed: width !== 0 || height !== 0,
};

const document = { dpr: 1 };
const target = { ownerDocument: document, isConnected: true };
const input = { width: 2, height: 1, pixels: new Uint8ClampedArray([2, 3, 4, 255, 9, 8, 7, 128]) };
const identity = { sourceRevision: 1, geometryRevision: 1, producerEpoch: 1,
  logicalWidth: 2, logicalHeight: 1, paintOutset: 0, dpr: 1 };
let owner;
const port = {
  devicePixelRatio: (doc) => doc.dpr,
  dimensions: (source) => ({ width: source.width, height: source.height }),
  create: (w, h) => ({ width: w, height: h, pixels: new Uint8ClampedArray(w * h * 4) }),
  copy: (storage, source) => storage.pixels.set(source.pixels),
  read(storage) {
    const pixels = storage.pixels.slice();
    Object.defineProperty(pixels, 'length', { get() { owner.dispose(); return 8; } });
    return pixels;
  },
  retire(storage) { storage.width = 0; storage.height = 0; },
};
owner = createCanvasSnapshotOwner(target, port);
const ticket = owner.capture(input, identity, { ownerCurrent: () => true, producerCurrent: () => true });
const returned = ticket.readPixels();
const readRetirement = {
  returnedPixelsAfterSynchronousRetirement: returned === null ? null : Array.from(returned),
  ticketCurrent: ticket.current(), owner: owner.inspect(),
  expected: 'A callback reached during result validation must not let readPixels publish after owner disposal.',
  failed: returned !== null && owner.inspect().disposed,
};

const result = { source: sourcePath,
  sha256: createHash('sha256').update(readFileSync(sourcePath)).digest('hex'),
  scope: 'Two controlled port/host faults only; no browser, native pixels, build or broad test run.',
  constructorFailure, readRetirement,
};
const output = JSON.stringify(result, null, 2) + '\n';
if (process.argv[3]) writeFileSync(process.argv[3], output);
process.stdout.write(output);
