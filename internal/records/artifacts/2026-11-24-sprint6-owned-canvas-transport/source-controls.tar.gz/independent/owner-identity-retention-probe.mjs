import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
const source = process.argv[2];
const { createCanvasSnapshotOwner } = await import(pathToFileURL(source));
const document = { dpr: 1 }, target = { ownerDocument: document, isConnected: true };
const frame = { target };
const identity = { sourceRevision: 1, geometryRevision: 1, producerEpoch: 1,
  logicalWidth: 2, logicalHeight: 1, paintOutset: 0, dpr: 1, frame };
const port = {
  devicePixelRatio: (doc) => doc.dpr,
  dimensions: () => ({ width: 2, height: 1 }),
  create: () => ({}), copy() {}, read: () => new Uint8ClampedArray(8), retire() {},
};
const owner = createCanvasSnapshotOwner(target, port);
const ticket = owner.capture({}, identity, { ownerCurrent: () => true, producerCurrent: () => true });
owner.dispose();
const result = {
  source, sha256: createHash('sha256').update(readFileSync(source)).digest('hex'),
  scope: 'One structurally compatible identity object with an extra frame field; no native rendering.',
  ticketCurrent: ticket.current(), identityKeys: Object.keys(ticket.identity),
  retiredTicketRetainsFrame: ticket.identity.frame === frame,
  retiredTicketRetainsTarget: ticket.identity.frame?.target === target,
  failed: ticket.identity.frame === frame,
  expected: 'A retired ticket keeps only the validated scalar identity fields; extra caller fields must not retain frame/target resources.',
};
const output = JSON.stringify(result, null, 2) + '\n';
if (process.argv[3]) writeFileSync(process.argv[3], output);
process.stdout.write(output);
