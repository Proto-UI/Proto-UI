import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';

const sourcePath = process.argv[2];
const { PROTOCOL, analyzeReceipt } = await import(pathToFileURL(sourcePath));
const cases = [
  { id: 'missing-sha-and-tree', expectedSha: undefined, sha: undefined, tree: undefined, browser: 'Chromium controlled-header' },
  { id: 'malformed-sha-and-tree', expectedSha: 'not-a-commit', sha: 'not-a-commit', tree: 'not-a-tree', browser: 'Chromium controlled-header' },
  { id: 'empty-browser', expectedSha: 'a'.repeat(40), sha: 'a'.repeat(40), tree: 'b'.repeat(40), browser: '' },
];
const results = [];
for (const row of cases) {
  const report = {
    protocol: PROTOCOL,
    source: {
      expectedSha: row.expectedSha,
      start: { sha: row.sha, tree: row.tree, status: '' },
      end: { sha: row.sha, tree: row.tree, status: '' },
      closureStable: true,
      headBound: true,
    },
    environment: { browser: row.browser, gpu: {} },
    failures: [], contexts: [],
  };
  const analysis = await analyzeReceipt(report, () => { throw new Error('No pixel fixture in a header-only control'); });
  const sourceGate = analysis.checks.find((check) => check.id === 'source-bound-native');
  const browserGate = analysis.checks.find((check) => check.id === 'browser-observed');
  results.push({ id: row.id, sourceGate, browserGate,
    overallAccepted: analysis.accepted,
    failed: row.id === 'empty-browser' ? browserGate.accepted : sourceGate.accepted,
  });
}
const result = {
  source: sourcePath,
  sha256: createHash('sha256').update(readFileSync(sourcePath)).digest('hex'),
  scope: 'Header admission only. Empty inventory deliberately keeps overall acceptance false; this is not native pixel or complete receipt evidence.',
  expected: 'Source binding requires populated full immutable commit/tree identifiers; observed browser identity must be populated.',
  results,
};
const output = JSON.stringify(result, null, 2) + '\n';
if (process.argv[3]) writeFileSync(process.argv[3], output);
process.stdout.write(output);
