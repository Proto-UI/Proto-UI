import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';

const source = process.argv[2];
if (!source) throw new Error('Pass the absolute path of image-prepare.ts');
const { createOpticalImageCache, inspectOpticalImageResources } = await import(pathToFileURL(source).href);
const report = {
  evidence: 'Independent host-unit fault injection; no real browser, PNG decoder or performance claim',
  source,
  sourceSha256: crypto.createHash('sha256').update(fs.readFileSync(source)).digest('hex'),
  node: process.version,
  cases: [],
};
function fixture(onClear) {
  const images = [];
  const document = { defaultView: { performance, Image: function () {
    let source = '';
    let resolve;
    const decoded = new Promise(done => { resolve = done; });
    const image = { complete: true, naturalWidth: 400, naturalHeight: 400, decode: () => decoded, ready: resolve };
    Object.defineProperty(image, 'src', {
      get: () => source,
      set: value => { source = value; if (value === '') onClear?.(image); },
    });
    images.push(image);
    return image;
  } } };
  const cache = createOpticalImageCache(document);
  return { images, document, cache };
}
function check(test, run) {
  try { run(); test.status = 'passed'; }
  catch (error) { test.status = 'failed'; test.failure = String(error); }
  report.cases.push(test);
}

let reentries = 0;
let enableReentry = true;
let successorReady = 0;
let successorRelease;
const reentrant = fixture(() => {
  // The cap makes the faulty live-Set loop finite; it is not a product budget.
  if (enableReentry && reentries++ < 3) {
    successorRelease = reentrant.cache.prepare('data:image/png;base64,reentrant-' + reentries, () => { successorReady++; }, () => {}, true);
  }
});
reentrant.cache.prepare('data:image/png;base64,original', () => {}, () => {}, true);
reentrant.cache.clear();
for (const image of reentrant.images) image.ready();
await Promise.resolve();
check({
  id: 'S6-IMG-CLEAR-REENTRY',
  createdImages: reentrant.images.length,
  clearCallbacks: reentries,
  successorReady,
  remainingSources: reentrant.images.map(image => image.src),
  resources: inspectOpticalImageResources(reentrant.document),
}, () => {
  assert.equal(reentrant.images.length, 2, 'One clear must retire its start-of-call cohort, not recursively acquired successor leases');
  assert.equal(successorReady, 1, 'The separately acquired successor lease must remain live');
});
enableReentry = false;
successorRelease?.();
reentrant.cache.dispose();

let throwCleanup = true;
const exceptional = fixture(() => { if (throwCleanup) throw new Error('cleanup-fault'); });
let releaseFailures = 0;
for (let pair = 0; pair < 4; pair++) {
  const a = exceptional.cache.prepare('data:image/png;base64,same', () => {}, () => {}, true);
  const b = exceptional.cache.prepare('data:image/png;base64,same', () => {}, () => {}, true);
  for (const image of exceptional.images) image.ready();
  await Promise.resolve();
  for (const release of [a, b]) {
    try { release(); } catch { releaseFailures++; }
    release();
  }
}
const resources = inspectOpticalImageResources(exceptional.document);
check({
  id: 'S6-IMG-RELEASE-FAILURE',
  releaseFailures,
  createdImages: exceptional.images.length,
  resources,
  sourceStringsStillOwned: exceptional.images.filter(image => image.src).length,
  decodedPixelBytes: resources.decodedImages * 400 * 400 * 4,
}, () => {
  assert.ok(releaseFailures > 0, 'Fault injection must execute');
  assert.ok(resources.decodedImages <= 1, 'After every caller lease releases, 400x400 idle images must remain within the 1 MiB bound');
});
throwCleanup = false;
exceptional.cache.dispose();
report.cleanup = {
  reentrant: inspectOpticalImageResources(reentrant.document),
  exceptional: inspectOpticalImageResources(exceptional.document),
};
report.status = report.cases.every(test => test.status === 'passed') ? 'passed' : 'failed';
console.log(JSON.stringify(report, null, 2));
if (report.status === 'failed') process.exitCode = 1;
