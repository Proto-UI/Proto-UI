import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';

const source = process.argv[2];
if (!source) throw new Error('Pass the absolute path of image-prepare.ts');
const { createOpticalImageCache, inspectOpticalImageResources } = await import(pathToFileURL(source).href);
const images = [];
let cleanupThrows = true;
let failedCalls = 0;
let nextReady = 0;
const document = { defaultView: { performance, Image: function () {
  let source = '';
  let resolve;
  const decoded = new Promise(done => { resolve = done; });
  const image = { complete: true, naturalWidth: 100, naturalHeight: 40, decode: () => decoded, ready: resolve };
  Object.defineProperty(image, 'src', {
    get: () => source,
    set: value => { source = value; if (!value && cleanupThrows) throw new Error('cleanup-fault'); },
  });
  images.push(image);
  return image;
} } };
const cache = createOpticalImageCache(document);
const firstRelease = cache.prepare('data:image/png;base64,same', () => { throw new Error('publication-fault'); }, () => { failedCalls++; }, true);
images[0].ready();
await new Promise(setImmediate);
const afterFailure = inspectOpticalImageResources(document);
firstRelease();
const nextRelease = cache.prepare('data:image/png;base64,same', () => { nextReady++; }, () => {}, true);
await new Promise(setImmediate);
const report = {
  id: 'S6-IMG-COLD-FAILURE-REUSE',
  evidence: 'Independent injected-host unit; no real browser or decoder claim',
  source,
  sourceSha256: crypto.createHash('sha256').update(fs.readFileSync(source)).digest('hex'),
  node: process.version,
  failedCalls,
  afterFailure,
  imagesConstructed: images.length,
  sources: images.map(image => image.src),
  nextReadyBeforeNextDecode: nextReady,
  resources: inspectOpticalImageResources(document),
};
try {
  assert.equal(failedCalls, 1, 'Cold publication cleanup failure must still notify the cache owner');
  assert.equal(images.length, 2, 'An already retired decode must not seed a reusable cache entry');
  assert.equal(nextReady, 0, 'The replacement request must wait for its new live decode');
  assert.equal(report.afterFailure.imageReadyCallbackFailures, 1);
  assert.equal(report.afterFailure.imageDecodeFailures, 0);
  report.status = 'passed';
} catch (error) {
  report.status = 'failed';
  report.failure = String(error);
  process.exitCode = 1;
}
cleanupThrows = false;
nextRelease();
cache.dispose();
report.cleanup = inspectOpticalImageResources(document);
console.log(JSON.stringify(report, null, 2));
