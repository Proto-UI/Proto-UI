import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';

const source = process.argv[2];
if (!source) throw new Error('Pass the absolute path of image-prepare.ts');
const { createOpticalImageCache, inspectOpticalImageResources } = await import(pathToFileURL(source).href);
const images = [];
let cleanupThrows = false;
let failedCalls = 0;
let uncaught;
const document = { defaultView: { performance, Image: function () {
  let source = '';
  let resolve;
  const decoded = new Promise(done => { resolve = done; });
  const image = { complete: true, naturalWidth: 100, naturalHeight: 40, decode: () => decoded, ready: resolve };
  Object.defineProperty(image, 'src', {
    get: () => source,
    set: value => { source = value; if (!value && cleanupThrows) throw new Error('cleanup-fault'); },
  });
  images.push(image);
  return image;
} } };
const cache = createOpticalImageCache(document);
const initialRelease = cache.prepare('data:image/png;base64,same', () => {}, () => {}, true);
images[0].ready();
await Promise.resolve();
initialRelease();
cleanupThrows = true;
const observeUncaught = error => { uncaught = String(error); };
process.once('uncaughtException', observeUncaught);
const reusedRelease = cache.prepare('data:image/png;base64,same', () => { throw new Error('publication-fault'); }, () => { failedCalls++; }, true);
await new Promise(setImmediate);
process.removeListener('uncaughtException', observeUncaught);
const report = {
  id: 'S6-IMG-CACHED-FAILURE-CALLBACK',
  evidence: 'Independent injected-host unit; no real browser or decoder claim',
  source,
  sourceSha256: crypto.createHash('sha256').update(fs.readFileSync(source)).digest('hex'),
  node: process.version,
  failedCalls,
  uncaught: uncaught ?? null,
  resources: inspectOpticalImageResources(document),
};
try {
  assert.equal(failedCalls, 1, 'Cleanup failure must not prevent the owner failure callback');
  assert.equal(uncaught, undefined, 'Cached callback failure must not escape its microtask');
  assert.equal(report.resources.imageReadyCallbackFailures, 1);
  assert.equal(report.resources.imageDecodeFailures, 0, 'Publication failure is not a second decode failure');
  report.status = 'passed';
} catch (error) {
  report.status = 'failed';
  report.failure = String(error);
  process.exitCode = 1;
}
cleanupThrows = false;
reusedRelease();
cache.dispose();
report.cleanup = inspectOpticalImageResources(document);
console.log(JSON.stringify(report, null, 2));
