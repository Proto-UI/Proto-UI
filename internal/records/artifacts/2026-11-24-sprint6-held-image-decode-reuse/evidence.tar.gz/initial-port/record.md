# Sprint 6 held-image decode reuse: source-bound implementation and host evidence

Observed on 2026-11-23 UTC (2026-11-24 Beijing). This is an uncommitted candidate based on `34cbf089c3e5ff638a27372ab973b54fd364b54b`, prepared for the parent integration task. It does not mark #1053, #1050, a browser acceptance condition, or Sprint 6 complete.

## Request and source

Agent paraphrase: complete the remaining Sprint 6 performance/recovery work while preserving material appearance, fallback, input ownership, source admission, original thresholds and evidence denominators.

The decoded-image reuse source comes from [E9](https://github.com/Proto-UI/Proto-UI/commit/e9d6a66e4c42813e42471573543573c3eb5f70b0), with its original [source-ready record](https://github.com/Proto-UI/Proto-UI/blob/e9d6a66e4c42813e42471573543573c3eb5f70b0/internal/records/2026-11-23-sprint6-source-ready.md). The current port does not import E9's unrelated Bootstrap Text, CLI or generated-file changes. Source attribution is retained; this record is not a new author identity, DCO attestation or formal approval.

| Original E9 path | Git blob |
| --- | --- |
| `packages/adapters/base/src/material/image-prepare.ts` | `15c7fa359dffd8876c94d337377d415f26661d47` |
| `packages/adapters/base/src/material/sink.ts` | `9fcb699dddbbde3133b78cf116b5814af4d26673` |
| `packages/adapters/base/test/web-material-image-cache.test.ts` | `ab0643c6ef781a5b4421777241a966a9f0ef25e1` |

`sink.ts` remains byte-identical to E9. The image cache and its tests include the additional cleanup repair described below. Four existing suites only adapt their image-preparation mock to the new factory shape; existing assertions and deadlines are unchanged. `program.ts`, optical shaders, source preparation, footprint, fixture, browser tests and quality thresholds are untouched.

## Behavior and ownership

Each material binding owns its cache. Every attempt still renders current pixels and performs the same source, geometry, token, palette, preference, input epoch, contrast and ownership checks. The ready callback retains the existing complete revalidation before publication. Cache identity is the exact PNG string produced by that fresh render; a source revision alone is not sufficient.

Only completed, retired held-contact decodes can become idle reusable entries. At most two idle entries survive, with a combined 1 MiB estimate for decoded pixels plus UTF-16 strings beyond active leases. This is not a measurement or bound of total browser/GPU memory. Active and pending requests remain separate leases even when bytes match. Release animation frames do not displace held images. Reuse readiness is asynchronous and remains cancellable. Fallback, binding invalidation, adoption and disposal clear the owner.

`imageReuseHits` counts cache lookups that found an idle entry, including a later-cancelled request. It does not count paint, successful publication or decoder completions. Existing preparation, decode, failure/cancellation and ready-callback timings retain separate meanings. Decode timing is elapsed wall time, including browser scheduling, rather than decoder CPU time or presentation latency.

## Additional reproducible cleanup repair

The new host fixture creates three independently owned resources: a pending image, an active decoded image, and an idle decoded image. It injects a throwing host setter when retirement clears the pending image's `src`.

With the unmodified E9 image module, `clear()` retires the first entry and exits at that exception. The active and idle entries still have their source strings. The exact original run is `cache-E9-red.json`: 10 tests passed, and the all-owned-cleanup assertion failed because the remaining sources were not empty. This is injected host-failure evidence, not a claim that a particular browser currently throws for this operation.

The repair makes each entry forget its cached source in `finally`, attempts retirement of every owned entry, and rethrows the first failure after all attempts. It does not swallow the host error or claim the failing host primitive physically succeeded. The existing active/pending/decoded accounting and callbacks are retired, the other images clear, a late pending settlement cannot publish, and a fresh owner request can recover. The unchanged test passed after the repair (`cache-repair-green.json`, 11/11).

The other two added tests distinguish equal-byte pending/active leases from reusable idle ownership, and verify that cancelled reuse increments the lookup count without inventing another decode or ready callback.

## Executed validation

Environment: Node `v24.22.3`, pnpm `10.32.1`, Vitest `2.1.9`, happy-dom `15.11.7`; offline frozen dependency installation with scripts disabled. Every Vitest command uses `--maxWorkers=1 --minWorkers=1`.

| Run | Observed result | Scope |
| --- | --- | --- |
| E9 plus added cleanup counterexample | 10 pass / 1 fail | Retained failing owner-cleanup observation |
| Repaired cache suite | 11/11 pass | Exact reuse, limits, separate leases, counters, cancellation, failure, reentry and clear/dispose |
| Six material suites | 309/309 pass; no pending tests | adoption 15; image cache 11; image 6; initial paint 120; preferences sequence 8; sink 149 |
| Existing real image/sink controls | 7/7 pass; no pending tests | Real preparer with injected image completion; retirement, late external paint, palette failure and style ownership |
| Reuse-disabled negative control | One selected test fails as expected | 8 Image constructions instead of the independently expected 7; 10 other tests intentionally unselected |
| Strict isolated TypeScript | exit 0 | `image-prepare.ts` only; not a workspace typecheck |
| Prettier and `git diff --check` | exit 0 | Seven changed TypeScript files plus existing image test for formatting; final diff whitespace |

The negative control uses a separate source copy and a temporary Vitest resolver. Only `const cached = idle.get(source)` becomes `const cached = undefined`; production source remains unchanged. Its failure is the expected Image allocation assertion, rather than a missing module, setup failure or weakened test. The separate source copy and configuration remain beside its raw report.

Focused commands:

```sh
corepack pnpm@10.32.1 exec vitest run \
  packages/adapters/base/test/web-material-image.test.ts \
  packages/adapters/base/test/web-material-image-cache.test.ts \
  packages/adapters/base/test/web-material-sink.test.ts \
  packages/adapters/base/test/web-material-adoption.test.ts \
  packages/adapters/base/test/web-material-preferences-sequence.test.ts \
  packages/adapters/base/test/web-material-initial-paint.test.ts \
  --maxWorkers=1 --minWorkers=1

corepack pnpm@10.32.1 exec vitest run \
  packages/adapters/base/test/web-material-independent-review.test.ts \
  --maxWorkers=1 --minWorkers=1

corepack pnpm@10.32.1 exec tsc --noEmit --strict \
  --target ES2022 --module ESNext --moduleResolution Bundler \
  --lib ES2022,DOM --skipLibCheck \
  packages/adapters/base/src/material/image-prepare.ts
```

Full raw results, per-file SHA-256 and Git blobs, environment, patch digest and the command dispositions are in `evidence-report.json`. The complete review patch, including the new test file, is `candidate.patch`, SHA-256 `93e68e750462cbcb73e1494d37838202cc0232aaf617babee4cf61fecc4fe26d`. No commit or external write was performed by this child task.

## Performance interpretation and next acceptance

The inspected historical RGBA comparison (Actions run `45209063310`, artifact `14836901086`, `25dddc948f0a05ac8a02bb486cf833d5e90ffb08` to `831bf10cb311b4445d7312aaa56879f4d4e8e0ad`) contains real headless Chromium/SwiftShader software measurements. Its candidate dynamic-drag p95 values are 13.105, 12.700 and 12.705 ms. Mean dynamic render including encode is about 2.905 ms, readback 1.345 ms, encode 0.426 ms, and image decode wall time 2.522 ms. These stages overlap or nest and must not be summed as an independent cost decomposition.

Fresh-contact tail latency did not uniformly improve in that historical comparison: static listener-to-held p95 was 12.405 to 13.015 ms; dynamic listener-to-held p95 was 16.375 to 48.110 ms, with dynamic median unchanged at 11.75 ms. The zero-allocation RGBA result therefore does not establish the full original latency condition.

The exact-byte cache addresses repeated PNG decoding. A moving source that produces distinct PNGs may receive no reuse benefit. This candidate has no new matched browser benchmark yet, so no latency improvement is claimed. A 60 Hz software browser report cannot establish the original physical 120 Hz or input-to-photon condition.

The parent integration task must review and integrate the exact candidate with the Accordion changes, rerun the affected original four-host browser/optical and cleanup acceptance, then perform a matched baseline/candidate performance run. Keep original contact and drag budgets, hardware/AT requirements and all failed/inconclusive optical classifications. Exact-head CI, independent review, the merge SHA, and earned live Issue updates/readback remain integration work. The logical cache evidence above does not replace any of those conditions.
