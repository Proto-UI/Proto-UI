# Sprint 6 decoded-image cache: independent review repairs

This revision supersedes the earlier uncommitted image-cache candidate for implementation review. The base remains `34cbf089c3e5ff638a27372ab973b54fd364b54b`. The [original port record](../record.md), E9 attribution, original source blobs, earlier failed/passing results and original patch remain unchanged.

Final `image-prepare.ts` SHA-256: `3668b4d200b2da4fbe830038d41f15060b57ab352dbbe1b8ade4279a1aa4da29`.

## Independent counterexamples

The independent review supplied executable Node probes against the earlier source, SHA-256 `512ea1b8d8606b79a8be557456883606b9ec888698609788868e9f8c411525af`. Each original report and source snapshot is retained; no red report is overwritten.

| Case | Earlier observed failure | Repaired observation from the same probe |
| --- | --- | --- |
| `S6-IMG-CLEAR-REENTRY` | Live-Set iteration retired successively acquired owners: four constructed images, zero successor readiness. The probe caps reentry to keep the failure finite. | One original and one successor image; exactly one successor remains live and becomes ready. |
| `S6-IMG-RELEASE-FAILURE` | Four rounds of two equal-byte active leases, all released, retained four decoded images: 2,560,000 pixel bytes. Cleanup errors interrupted the transfer before the current entry was retained or retired. | Four cleanup failures remain observable, but only one idle decoded image remains: 640,000 pixel bytes, within the unchanged 1 MiB pixel/string budget. |
| `S6-IMG-CACHED-FAILURE-CALLBACK` | A throwing ready callback followed by throwing host cleanup suppressed failure notification and escaped the cached microtask. | Failure callback exactly once; no uncaught exception; one ready-callback failure and zero decoder failures. |
| `S6-IMG-COLD-FAILURE-REUSE` | The same combined fault on a cold decode suppressed failure notification, then allowed the already retired decode to seed a reusable entry. A subsequent request became ready without a new decode. | Failure callback exactly once; the next request constructs a second Image and remains unready until that fresh decode completes. |

These are injected-host ownership and failure-path observations. They do not establish native browser frequency, physical resource release when the host primitive itself throws, optical appearance or performance.

## Repair

Retirement now has a logical stage and a host-cleanup stage. Logical retirement removes idle/owned membership and cancels the lease without calling external host code. Host cleanup then attempts the retired image operation and clears its cached source in `finally`.

`clear()` first snapshots and logically retires its entire starting cohort. Only then does it call host cleanup. This matters beyond copying the Set: cleanup of A could otherwise reacquire another still-idle starting entry B, and the later outer iteration would retire B's new lease. The whole cohort is now invalid before any reentry can acquire a successor. `dispose()` sets its terminal state first, so reentrant preparation is refused.

Release now completes idle replacement and selects all count/byte evictions before any host cleanup. Those retired entries are then cleaned independently, preserving and ultimately rethrowing the first explicit cleanup failure. No exception can strand the current lease between active and idle ownership, and no post-cleanup cache write can revive an entry invalidated by reentrant clear/dispose.

Cold and cached asynchronous failure use the same retirement-and-notification helper. The failure callback receives exactly one notification even when host cleanup also throws; cleanup failure does not escape that asynchronous failure channel. Explicit clear/release still propagate their first cleanup error. Decode and ready-callback counters retain their separate meanings.

The two-entry and 1 MiB idle budgets, exact-PNG lookup, asynchronous readiness, fresh renderer/admission checks, source/geometry/palette/preferences/input ownership and all original optical/latency criteria are unchanged. The review repair changes only the image module and its cache tests relative to the prior candidate.

## Validation and retained failures

The first extended unit run observed 12 pass / 6 fail. Its eviction fixture also repeated an injected fault during test teardown. The fixture was changed only to disable that injection in `finally`; the product assertions were retained. A second run against the same unfixed source again observed 12 pass / 6 fail, with the six intended failures and no extra teardown error. Both reports remain available.

The six failing assertions cover successor retirement, reacquiring another original idle PNG, retained-byte growth after failed same-source replacement, incomplete multi-entry eviction, and cold/cached combined publication and cleanup faults. The repaired 18-case suite passed. Two additional controls cover reentrant clear and dispose during idle replacement.

The final combined command selected seven files and ran **325/325 tests, with zero pending tests**:

| Suite | Passed |
| --- | ---: |
| `web-material-adoption.test.ts` | 15 |
| `web-material-image-cache.test.ts` | 20 |
| `web-material-image.test.ts` | 6 |
| `web-material-independent-review.test.ts` | 7 |
| `web-material-initial-paint.test.ts` | 120 |
| `web-material-preferences-sequence.test.ts` | 8 |
| `web-material-sink.test.ts` | 149 |

All three original independent Node probes passed on the final source. The independent reviewer also reran those same probes separately, retaining separate green reports alongside the original red reports. This is independent technical evidence; it is not a formal GitHub approval or full Sprint acceptance.

The lookup-disabled negative control was regenerated from the final source in a separate file. Its selected reuse case still fails for the intended Image-construction assertion, eight instead of seven. The other 19 cases were deliberately unselected in that single-case mutation run. Production source did not change. Strict isolated `image-prepare.ts` TypeScript, Prettier and `git diff --check` passed. The final suite uses Node 24.22.3, pnpm 10.32.1, Vitest 2.1.9, happy-dom 15.11.7 and one worker.

`evidence-report-v2.json` binds the final seven files, all current raw results, original review reds, independent probe reruns, commands and patch hashes. The complete patch against base 34cb is `candidate-v2.patch`, SHA-256 `348e67e12bc5bfe79169f12725ca2e6a27d3735cf2c71790e7c70b92bdc74ce4`. If the prior candidate is already applied, use only the two-file `review-repair.patch`, SHA-256 `cdb1e32857fd46af88a062966edaee2486a174d972ed16d109ee0bb9d14d4cbe`.

The candidate is still uncommitted. The parent owns combination with the Accordion work, exact-head browser/optical/performance validation, review, integration and earned live Issue updates. No fresh latency improvement, physical 120 Hz/input-to-photon acceptance, full #1053/#1050 completion or Sprint 6 completion is claimed here.
