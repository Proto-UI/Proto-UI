import original from '/workspace/scratch/211f6da28b72/s6-decode/vitest.config';
export default {
  ...original,
  plugins: [{
    name: 'reuse-disabled-review-repair-control',
    enforce: 'pre' as const,
    resolveId(id: string) {
      if (id === '../src/material/image-prepare')
        return '/workspace/scratch/211f6da28b72/s6-decode-evidence/review-repair/reuse-disabled-image-prepare.ts';
      return null;
    },
  }, ...original.plugins],
};
